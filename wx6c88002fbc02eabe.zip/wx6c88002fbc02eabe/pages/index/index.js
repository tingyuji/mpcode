(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    8069: function(e, t, n) {
        n.r(t);
        var a = n("da67"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    "98f1": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this, t = (e.$createElement, e._self._c, "mall" !== e.type && "diy" === e.type ? [ 1, 2, 3, 4 ].includes(+e.diy__app_nav_bar.style) : null), n = "mall" !== e.type && "diy" === e.type && t && 1 == e.diy__app_nav_bar.has_banner && e.navbarStatus ? e.__get_style([ e.navItemStyle, {
                background: e.navBg
            } ], {
                position: "absolute",
                width: "100%",
                top: "0"
            }) : null, a = "mall" !== e.type && "diy" === e.type && t && 1 == e.diy__app_nav_bar.has_banner ? e.$utils.colorRgba(e.diy__app_nav_bar.swiper_color, .3) : null, i = e.load_before ? null : e.__get_style([ e.loadStyle ]);
            e._isMounted || (e.e0 = function(t) {
                return e.swiper_index = t;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    s0: n,
                    g1: a,
                    s1: i
                }
            });
        }, i = [];
    },
    ae58: function(e, t) {
        e.exports = require("../siteinfo.js");
    },
    d537: function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("6cdc"), t(n("66fd")), e(t(n("f75a")).default);
        }).call(this, n("543d").createPage);
    },
    da67: function(e, t, n) {
        (function(e) {
            function a(e, t) {
                var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!n) {
                    if (Array.isArray(e) || (n = i(e)) || t && e && "number" == typeof e.length) {
                        n && (e = n);
                        var a = 0, o = function() {};
                        return {
                            s: o,
                            n: function() {
                                return a >= e.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: e[a++]
                                };
                            },
                            e: function(e) {
                                throw e;
                            },
                            f: o
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var r, s = !0, c = !1;
                return {
                    s: function() {
                        n = n.call(e);
                    },
                    n: function() {
                        var e = n.next();
                        return s = e.done, e;
                    },
                    e: function(e) {
                        c = !0, r = e;
                    },
                    f: function() {
                        try {
                            s || null == n.return || n.return();
                        } finally {
                            if (c) throw r;
                        }
                    }
                };
            }
            function i(e, t) {
                if (e) {
                    if ("string" == typeof e) return o(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0;
                }
            }
            function o(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, a = new Array(t); n < t; n++) a[n] = e[n];
                return a;
            }
            function r(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? r(Object(n), !0).forEach(function(t) {
                        c(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function l(e, t, n, a, i, o, r) {
                try {
                    var s = e[o](r), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(a, i);
            }
            function u(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, i) {
                        function o(e) {
                            l(s, a, i, o, r, "next", e);
                        }
                        function r(e) {
                            l(s, a, i, o, r, "throw", e);
                        }
                        var s = e.apply(t, n);
                        o(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var p = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("a34a")), d = n("2f62"), h = null, f = {
                name: "index",
                components: {
                    appIndex: function() {
                        n.e("components/page-component/index/app-index").then(function() {
                            return resolve(n("6f02"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-diy-page": function() {
                        n.e("components/page-component/index/app-diy-page").then(function() {
                            return resolve(n("6a38"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appBuyPrompt: function() {
                        n.e("components/page-component/app-buy-prompt/app-buy-prompt").then(function() {
                            return resolve(n("49f6"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appMyApp: function() {
                        n.e("components/page-component/app-my-app/app-my-app").then(function() {
                            return resolve(n("d7d6"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appNavBar: function() {
                        n.e("components/page-component/index/app-nav-bar").then(function() {
                            return resolve(n("59f3"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    uAttr: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/page-component/goods/u-attr") ]).then(function() {
                            return resolve(n("b4bc"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appSwiper: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/page-component/app-swiper/app-swiper") ]).then(function() {
                            return resolve(n("8af3"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    uSwiper: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/page-component/app-swiper/swiper") ]).then(function() {
                            return resolve(n("b6b4"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        swiper_index: 0,
                        scrollTop: 0,
                        aniData: null,
                        diy__app_nav_bar: {},
                        nav_bar_title: "",
                        homePages: {},
                        box: [],
                        first_data: [],
                        type: "",
                        startHeight: 0,
                        is_storage: !1,
                        haveBackground: !0,
                        destroy: !0,
                        pageHide: !1,
                        is_required: !0,
                        coupon_req: !1,
                        page_id: 0,
                        attrGoods: {
                            goods: null,
                            attrShow: 0,
                            select: null,
                            disable: "disable"
                        },
                        isShowAttention: !1,
                        load_before: !1,
                        loadStyle: {
                            minHeight: "100vh",
                            backgroundColor: "#f5f7f9",
                            position: "relative",
                            zIndex: 1800
                        },
                        is_refresh: !1,
                        mscroll_loading: !1,
                        mscroll_diy: !1,
                        index_options: null,
                        refresh_num: 0,
                        tabbarbool: !1
                    };
                },
                onShow: function() {
                    var e = this;
                    this.pageHide = !1, setTimeout(function(t) {
                        var n = Object.values(e.homePages);
                        n && 0 != n.length || console.log("11");
                    }, 1e3);
                },
                onHide: function() {
                    this.pageHide = !0;
                },
                onLoad: function(t) {
                    var n = this;
                    this.$commonLoad.onload(t), console.log("onload:", t), this.index_options = t, this.load(t);
                    var a = e.createAnimation({
                        duration: 1e3,
                        timingFunction: "linear"
                    });
                    this.ani = a, h = setInterval(function(e) {
                        n.aniData = a.opacity(.5).step().export(), setTimeout(function(e) {
                            n.aniData = a.opacity(1).step().export();
                        }, 1e3);
                    }, 2e3), wx.showShareMenu({
                        menus: [ "shareAppMessage", "shareTimeline" ]
                    });
                    var i = wx.getUpdateManager();
                    i && (i.onCheckForUpdate(function(e) {}), i.onUpdateReady(function() {
                        wx.showModal({
                            title: "更新提示",
                            content: "新版本已经准备好，是否重启应用？",
                            success: function(e) {
                                e.confirm && i.applyUpdate();
                            }
                        });
                    }));
                },
                onPageScroll: function(e) {
                    var t = this;
                    e.scrollTop < 100 ? this.scrollTop = e.scrollTop : 100 != this.scrollTop && (this.scrollTop = 100), 
                    this.$store.dispatch("page/actionSetScrollTop", e.scrollTop), this.isAllGoods && this.$utils.throttle(function() {
                        "diy" === t.type && t.$refs.diy.handleAllGoodsFixed();
                    }, 200);
                },
                onPullDownRefresh: function() {
                    var t = this;
                    this.is_refresh = !0, this.mscroll_loading = !0, this.$storage.removeStorageSync("INDEX_MALL"), 
                    this.load(this.index_options).then(function() {
                        t.is_refresh = !1, setTimeout(function() {
                            t.mscroll_loading = !1;
                        }, 500), e.stopPullDownRefresh();
                    });
                },
                onReachBottom: function() {
                    "diy" === this.type && this.$refs.diy.handleScrolltolower();
                },
                provide: function() {
                    return {
                        t_index: this
                    };
                },
                methods: {
                    getTabbarbool: function(e) {
                        this.tabbarbool = e;
                    },
                    getS: function() {
                        var e = {
                            path: "/pages/index/index",
                            params: {}
                        };
                        return "diy" !== this.type ? (e.title = this.mall.setting.share_title ? this.mall.setting.share_title : this.mall.name, 
                        e.imageUrl = this.mall.setting.share_pic) : (e.title = this.homePages.app_share_title ? this.homePages.app_share_title : this.homePages.title, 
                        e.imageUrl = this.homePages.app_share_pic, e.params.page_id = this.page_id), e;
                    },
                    checkClick: function(e) {
                        var t = e.item;
                        this.attrGoods.select = t;
                    },
                    cartResult: function(e) {
                        "diy" === this.type && this.$refs.diy.getCart(e);
                    },
                    headHeight: function(e) {
                        this.startHeight = e;
                    },
                    clearImage: function() {
                        var e = this;
                        this.$nextTick(function(t) {
                            clearInterval(h), e.aniData = e.ani.opacity(0).step().export(), setTimeout(function(t) {
                                e.load_before = !0;
                            }, 300);
                        });
                    },
                    loadMall: function() {
                        var t = u(p.default.mark(function t() {
                            var n, a, i, o, r = this;
                            return p.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, this.$request({
                                        url: this.$api.index.diy,
                                        data: {
                                            page_id: 0
                                        },
                                        method: "get"
                                    });

                                  case 2:
                                    n = t.sent, a = n.code, i = n.data, this.$hideLoading(), 0 === a && (this.refresh_num += 1, 
                                    this.is_storage = !1, this.$popupAd.show = null, this.type = i.type, this.clearImage(), 
                                    o = this, this.is_required = !0, "diy" === this.type && (this.coupon_req = !0, this.homePages = {}, 
                                    this.box = [], this.first_data = []), this.$nextTick(function() {
                                        "diy" === r.type && i.home_pages.link && (e.showToast({
                                            title: "正在前往新页面",
                                            icon: "none"
                                        }), r.$jump({
                                            url: i.home_pages.link.new_link_url,
                                            open_type: "redirect"
                                        })), r.homePages = i.home_pages, r.nav_bar_title = i.home_pages.title, r.box = i.box, 
                                        r.first_data = i.first_data, r.homePages.navs && o.homePages.navs.length > 0 && r.homePages.navs.forEach(function(e, t) {
                                            e.template.data.forEach(function(e, t) {
                                                "background" === e.id && (o.haveBackground = !1), "app-nav-bar" === e.id && (o.diy__app_nav_bar = e.data);
                                            });
                                        });
                                    }), this.$storage.setStorageSync("INDEX_MALL", i), this.handleShare(), setTimeout(function() {
                                        r.mscroll_diy || (r.mscroll_diy = !0);
                                    }, 1e3));

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }(),
                    loadDiy: function() {
                        var t = u(p.default.mark(function t() {
                            var n, a, i, o, r = this;
                            return p.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, this.$request({
                                        url: this.$api.index.diy,
                                        data: {
                                            page_id: this.page_id
                                        },
                                        method: "get"
                                    });

                                  case 2:
                                    n = t.sent, a = n.code, i = n.data, this.$hideLoading(), 0 === a && (i.home_pages.link && (e.showToast({
                                        title: "正在前往新页面",
                                        icon: "none"
                                    }), this.$jump({
                                        url: i.home_pages.link.new_link_url,
                                        open_type: "redirect"
                                    })), this.refresh_num += 1, this.is_storage = !1, this.$popupAd.show = null, this.homePages = i.home_pages, 
                                    Object.assign(this.homePages, {
                                        _t: new Date().getTime()
                                    }), this.nav_bar_title = i.home_pages.title, this.box = i.box, this.first_data = i.first_data, 
                                    this.type = i.type, this.clearImage(), o = this, this.homePages.navs && o.homePages.navs.length > 0 && this.homePages.navs.forEach(function(e, t) {
                                        e.template.data.forEach(function(e, t) {
                                            "background" === e.id && (o.haveBackground = !1), "app-nav-bar" === e.id && (o.diy__app_nav_bar = e.data);
                                        });
                                    }), this.handleShare(), setTimeout(function() {
                                        r.mscroll_diy || (r.mscroll_diy = !0);
                                    }, 1e3));

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }(),
                    delHistory: function() {},
                    qrcode: function(e) {
                        var t = this;
                        this.$request({
                            url: this.$api.default.qrcode_parameter,
                            data: {
                                token: e.scene
                            }
                        }).then(function(e) {
                            if (0 === e.code) {
                                t.$store.dispatch("page/actionSetQeury", null);
                                var n = e.data.detail, a = n.data, i = n.path, o = "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin" == i ? "".concat(i) : "/".concat(i);
                                a && (o += "?" + t.$utils.objectToUrlParams(a), void 0 !== a.user_id && t.$store.dispatch("user/setTempParentId", a.user_id)), 
                                ("/pages/index/index" != "/".concat(i) || void 0 !== a.page_id && a.page_id != t.homePages.id && 0 != a.page_id) && (t.delHistory(), 
                                t.$jump({
                                    url: o,
                                    open_type: "navigate"
                                }));
                            }
                        }).catch(function() {});
                    },
                    buyProduct: function(e) {
                        this.attrGoods.goods = e.goods, this.attrGoods.select = null, this.attrGoods.attrShow = e.attrShow;
                    },
                    handleShare: function() {},
                    hShareAppMessage: function() {},
                    load: function() {
                        var e = u(p.default.mark(function e(t) {
                            var n, a, i, o, r, s, c = this;
                            return p.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (this.page_id = t && void 0 !== t.page_id ? Number(t.page_id) : 0, 0 !== this.page_id) {
                                        e.next = 16;
                                        break;
                                    }
                                    if (!((n = this.$storage.getStorageSync("INDEX_MALL")) && n.time && ("diy" !== n.type || "diy" == n.type && n.box))) {
                                        e.next = 12;
                                        break;
                                    }
                                    this.type = n.type, (a = new Date(n.time.replace(/-/g, "/"))).setMinutes(a.getMinutes() + 10), 
                                    i = new Date(), (o = i.getTime() - a.getTime()) >= 0 ? this.loadMall() : ("diy" === this.type && (this.coupon_req = !0, 
                                    this.homePages = {}, this.box = [], this.first_data = []), this.$nextTick(function() {
                                        c.homePages = n.home_pages, c.nav_bar_title = n.home_pages.title, c.box = n.box, 
                                        c.first_data = n.first_data;
                                        var e = c;
                                        c.homePages.navs && c.homePages.navs.length > 0 && c.homePages.navs.forEach(function(t, n) {
                                            t.template.data.forEach(function(t, n) {
                                                "background" === t.id && (e.haveBackground = !1), "app-nav-bar" === t.id && (e.diy__app_nav_bar = t.data);
                                            });
                                        }), c.handleShare(), setTimeout(function() {
                                            c.mscroll_diy || (c.mscroll_diy = !0);
                                        }, 1e3);
                                    }), this.is_required = !1, this.clearImage()), e.next = 14;
                                    break;

                                  case 12:
                                    return e.next = 14, this.loadMall();

                                  case 14:
                                    e.next = 19;
                                    break;

                                  case 16:
                                    return this.coupon_req = !0, e.next = 19, this.loadDiy();

                                  case 19:
                                    r = {}, s = "", 0 == this.page_id ? s = this.mall.setting.share_title ? this.mall.setting.share_title : this.mall.name : (s = this.homePages.title, 
                                    r.page_id = this.page_id), this.shareTimelineData = {
                                        title: s,
                                        query: r
                                    };

                                  case 23:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }()
                },
                onShareTimeline: function() {
                    var e = this.getS();
                    return this.$shareTimeline(Object.assign({
                        title: e.title,
                        imageUrl: e.imageUrl
                    }, e.params.page_id ? {
                        query: {
                            page_id: this.page_id
                        }
                    } : {}));
                },
                onShareAppMessage: function() {
                    return this.$shareAppMessage(this.getS());
                },
                computed: s(s(s(s(s({
                    navBg: function() {
                        var e = this.diy__app_nav_bar, t = e.banner_bg_style, n = e.banners;
                        if (n && n[this.swiper_index]) {
                            var a = n[this.swiper_index];
                            return 1 == t ? "linear-gradient(180deg, ".concat(a.bg_color, ", rgba(0,0,0,0))") : a.bg_color;
                        }
                    },
                    navItemStyle: function() {
                        var e, t, n = this.diy__app_nav_bar, a = n.banner_bg_style, i = n.bg_bottom_radius, o = n.duration, r = this.startHeight, s = {};
                        switch (+a) {
                          case 1:
                            t = "calc(".concat(r, "px + 324rpx)"), e = 0;
                            break;

                          case 2:
                            t = "calc(".concat(r, "px + 218rpx)"), e = "0 0 ".concat(i, "rpx ").concat(i, "rpx");
                            break;

                          case 3:
                            t = "calc(".concat(r, "px + 282rpx)"), e = 0, Object.assign(s, {
                                borderBottomRightRadius: "50% 68rpx",
                                borderBottomLeftRadius: "50% 68rpx"
                            });
                        }
                        return Object.assign({
                            height: t,
                            transition: "".concat(o / 1e3, "s ease-in-out"),
                            borderRadius: e
                        }, s);
                    },
                    navbarStatus: function() {
                        return -1 === [ "windows", "mac" ].indexOf(this.systemInfo.platform);
                    }
                }, (0, d.mapGetters)("mallConfig", {
                    tabBarNavs: "getNavBar",
                    getTheme: "getTheme",
                    top_background_color: function(e) {
                        return e.navbar.top_background_color;
                    }
                })), (0, d.mapGetters)({
                    userInfo: "user/info"
                })), (0, d.mapState)({
                    systemInfo: function(e) {
                        return e.gConfig.systemInfo;
                    }
                })), (0, d.mapState)("mallConfig", {
                    config: function(e) {
                        return e.mall.setting;
                    },
                    mall: function(e) {
                        return e.mall;
                    },
                    index_gray: function(e) {
                        return e.mall.setting.is_index_gray;
                    }
                })), {}, {
                    is_index_gray: function() {
                        return this.index_gray && (0 == this.page_id || "mall" === this.type);
                    },
                    isSign: function() {
                        return this.$storage.getStorageSync("isSign");
                    },
                    tabbarbool: function() {
                        var e, t = !1, n = this.page_id > 0 ? "/pages/index/index?page_id=" + this.page_id : "/pages/index/index", i = a(this.tabBarNavs.navs);
                        try {
                            for (i.s(); !(e = i.n()).done; ) e.value.url == n && (t = !0);
                        } catch (e) {
                            i.e(e);
                        } finally {
                            i.f();
                        }
                        return t;
                    },
                    isAllGoods: function() {
                        var e = -1;
                        return this.box && this.box.length > 0 && (e = this.box.findIndex(function(e) {
                            return "all-goods" === e.id;
                        })), e > -1;
                    }
                })
            };
            t.default = f;
        }).call(this, n("543d").default);
    },
    f75a: function(e, t, n) {
        n.r(t);
        var a = n("98f1"), i = n("8069");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        var r = n("f0c5"), s = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = s.exports;
    }
}, [ [ "d537", "common/runtime", "common/vendor" ] ] ]);