module.exports = {
    acid: -1,
    version: "1.0.0",
    siteroot: "http://localhost/app/index.php",
    apiroot: "https://bd-test.zjhejiang.cn/web/index.php?_mall_id=1"
};