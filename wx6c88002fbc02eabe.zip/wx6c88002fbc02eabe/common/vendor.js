var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/vendor" ], {
    "023f": function(e, t, n) {
        function r(e) {
            for (var t = {}, n = e.split(","), r = 0; r < n.length; r += 1) t[n[r]] = !0;
            return t;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = /^<([-A-Za-z0-9_]+)((?:\s+[a-zA-Z0-9_:][-a-zA-Z0-9_:.]*(?:\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/, o = /^<\/([-A-Za-z0-9_]+)[^>]*>/, a = /([a-zA-Z0-9_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g, s = r("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr"), c = r("address,code,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video"), l = r("a,abbr,acronym,applet,b,basefont,bdo,big,br,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), u = r("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr"), p = r("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected");
        t.default = function(e, t) {
            function n(e, n) {
                var r;
                if (n) for (n = n.toLowerCase(), r = g.length - 1; r >= 0 && g[r] !== n; r -= 1) ; else r = 0;
                if (r >= 0) {
                    for (var i = g.length - 1; i >= r; i -= 1) t.end && t.end(g[i]);
                    g.length = r;
                }
            }
            var r, d, f, h = e, g = [];
            for (g.last = function() {
                return g[g.length - 1];
            }; e; ) {
                if (d = !0, 0 === e.indexOf("</") ? (f = e.match(o)) && (e = e.substring(f[0].length), 
                f[0].replace(o, n), d = !1) : 0 === e.indexOf("<") && (f = e.match(i)) && (e = e.substring(f[0].length), 
                f[0].replace(i, function(e, r, i, o) {
                    if (r = r.toLowerCase(), c[r]) for (;g.last() && l[g.last()]; ) n("", g.last());
                    if (u[r] && g.last() === r && n("", r), (o = s[r] || !!o) || g.push(r), t.start) {
                        var d = [];
                        i.replace(a, function(e, t) {
                            var n = arguments[2] || arguments[3] || arguments[4] || (p[t] ? t : "");
                            d.push({
                                name: t,
                                value: n,
                                escaped: n.replace(/(^|[^\\])"/g, '$1\\"')
                            });
                        }), t.start && t.start(r, d, o);
                    }
                }), d = !1), d) {
                    r = e.indexOf("<");
                    for (var v = ""; 0 === r; ) v += "<", r = (e = e.substring(1)).indexOf("<");
                    v += r < 0 ? e : e.substring(0, r), e = r < 0 ? "" : e.substring(r), t.chars && t.chars(v);
                }
                if (e === h) throw new Error("Parse Error: ".concat(e));
                h = e;
            }
            n();
        };
    },
    "0333": function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("9dc1")), o = r(n("27f5")), a = {
            getAward: function(e, t) {
                var n = this;
                return new Promise(function(r, a) {
                    (0, i.default)({
                        url: o.default.check_in.sign_in,
                        data: {
                            status: e,
                            day: t || 1
                        }
                    }).then(function(e) {
                        if (0 != e.code) return a(e.msg);
                        n.checkInResult(e.data.queueId, e.data.token).then(function(e) {
                            return r(e);
                        }).catch(function(e) {
                            return a(e);
                        });
                    }).catch(function(e) {
                        return a(e);
                    });
                });
            },
            checkInResult: function(e, t) {
                var n = this;
                return new Promise(function(r, a) {
                    (0, i.default)({
                        url: o.default.check_in.sign_in_result,
                        data: {
                            queueId: e,
                            token: t
                        }
                    }).then(function(i) {
                        return 0 != i.code ? a(i.msg) : 1 != i.data.retry ? r(i.data) : void n.checkInResult(e, t).then(function(e) {
                            return r(e);
                        }).catch(function(e) {
                            return a(e);
                        });
                    }).catch(function(e) {
                        return a(e);
                    });
                });
            }
        };
        t.default = a;
    },
    "06e6": function(t, n, r) {
        (function(t) {
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function o(t) {
                return (o = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                    return void 0 === t ? "undefined" : e(t);
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
                })(t);
            }
            function a(e, t, n, r, i, o, a) {
                try {
                    var s = e[o](a), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(r, i);
            }
            function s(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, i) {
                        function o(e) {
                            a(c, r, i, o, s, "next", e);
                        }
                        function s(e) {
                            a(c, r, i, o, s, "throw", e);
                        }
                        var c = e.apply(t, n);
                        o(void 0);
                    });
                };
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function l(e, t) {
                var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!n) {
                    if (Array.isArray(e) || (n = u(e)) || t && e && "number" == typeof e.length) {
                        n && (e = n);
                        var r = 0, i = function() {};
                        return {
                            s: i,
                            n: function() {
                                return r >= e.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: e[r++]
                                };
                            },
                            e: function(e) {
                                throw e;
                            },
                            f: i
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var o, a = !0, s = !1;
                return {
                    s: function() {
                        n = n.call(e);
                    },
                    n: function() {
                        var e = n.next();
                        return a = e.done, e;
                    },
                    e: function(e) {
                        s = !0, o = e;
                    },
                    f: function() {
                        try {
                            a || null == n.return || n.return();
                        } finally {
                            if (s) throw o;
                        }
                    }
                };
            }
            function u(e, t) {
                if (e) {
                    if ("string" == typeof e) return p(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? p(e, t) : void 0;
                }
            }
            function p(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var d = i(r("a34a")), f = i(r("fcd1")), h = {
                data: function() {
                    return {
                        nowDate: {
                            year: "",
                            month: "",
                            day: ""
                        },
                        calendar: [],
                        weeks: [],
                        date: {
                            before: "",
                            after: "",
                            data: []
                        },
                        dateData: [],
                        weekList: [],
                        calc_time: null
                    };
                },
                computed: {
                    formatWeeks: function() {
                        var e = this, t = JSON.parse(JSON.stringify(Object.values(this.weeks))), n = this.dateData, r = this.dataConfig, i = this.calendar;
                        if (r.calendar_start && r.calendar_end) return t.map(function(t) {
                            return t.map(function(t) {
                                if (!t) return t;
                                var o = {
                                    fullDate: t.fullDate,
                                    disable: t.disable,
                                    stock: "",
                                    member_price: "",
                                    price: "",
                                    top_content: "",
                                    end_content: "",
                                    text_color: "color: ".concat(t.disable ? "#cccccc" : "#999999")
                                }, a = t.year, s = t.month, c = t.date;
                                if (!o.disable) {
                                    var u = r.calendar_start, p = r.calendar_end, d = new Date(u.replace(/-/g, "/")), f = new Date(p.replace(/-/g, "/")), h = new Date(o.fullDate.replace(/-/g, "/"));
                                    (h < d || h > f) && Object.assign(o, {
                                        disable: !0
                                    });
                                }
                                var g, v = !1, m = l(n);
                                try {
                                    for (m.s(); !(g = m.n()).done; ) {
                                        var y = g.value;
                                        if (Number(y.date.day) == Number(c) && Number(y.date.month) == Number(s) && Number(y.date.year) == Number(a)) {
                                            v = !0;
                                            var _ = y.value, b = _.stock, x = _.member_price, w = _.calc_price;
                                            Object.assign(o, {
                                                stock: b,
                                                member_price: x,
                                                calc_price: w,
                                                end_content: "￥" + w,
                                                disable: 0 == b || o.disable
                                            }), Object.assign(o, {
                                                top_content: "库存" + (b >= 1e3 ? "充足" : b || 0),
                                                text_color: "color: ".concat(o.disable ? "#cccccc" : "#999999")
                                            });
                                            break;
                                        }
                                    }
                                } catch (e) {
                                    m.e(e);
                                } finally {
                                    m.f();
                                }
                                if (v || (o.disable = !0), 1 == r.is_alone) t.fullDate === i.fullDate && Object.assign(o, {
                                    top_content: "预定",
                                    text_color: "color: #333333"
                                }), t.fullDate && e.calendar.fullDate === t.fullDate && Object.assign(e.calendar, {
                                    stock: o.stock,
                                    calc_price: o.calc_price
                                }); else {
                                    var A = e.cale.multipleStatus, S = A.before, k = A.after;
                                    S && !k && 1 == r.has_kuatian ? e.calc_time && new Date(t.fullDate) > new Date(e.calc_time) ? Object.assign(o, {
                                        disable: !0
                                    }) : new Date(S) < new Date(t.fullDate) && 0 == o.stock && (Object.assign(o, {
                                        disable: !1
                                    }), e.calc_time = t.fullDate) : e.calc_time = null, t.afterMultiple && 1 == r.has_kuatian ? Object.assign(o, {
                                        top_content: "预定",
                                        text_color: "color: #333333",
                                        calc_price: 0,
                                        end_content: "￥0"
                                    }) : (t.afterMultiple || t.beforeMultiple || t.multiple || t.fullDate === i.fullDate) && Object.assign(o, {
                                        top_content: "预定",
                                        text_color: "color: #333333"
                                    });
                                }
                                return Object.assign(t, o), Object.assign({
                                    ss: e.handlerDay(t)
                                }, t);
                            });
                        });
                    },
                    dataConfig: function() {
                        return Object.assign({}, this.goods ? this.goods.form_goods : {});
                    }
                },
                filters: {
                    formatDate: function(e) {
                        var t = e.before, n = e.after, r = /\d{4}-0?(\d{1,2})-0?(\d{1,2})/, i = "";
                        return t && (i += t.replace(r, "$1月$2号")), i += " - ", n && (i += n.replace(r, "$1月$2号")), 
                        i;
                    }
                },
                methods: {
                    handlerDay: function(e) {
                        var t = this.calendar, n = this.theme, r = n.background_o, i = n.color, o = n.border, a = {
                            fontSize: "20rpx",
                            color: "#333333"
                        };
                        return e.fullDate ? (0 == this.dataConfig.is_alone ? (e.multiple && Object.assign(a, {
                            backgroundColor: r,
                            width: "102rpx",
                            color: i
                        }), e.beforeMultiple && Object.assign(a, {
                            backgroundColor: n.background_o,
                            borderRadius: "8rpx 0 0 8rpx",
                            boxSizing: "border-box",
                            border: "1px solid ".concat(o),
                            color: i,
                            borderLeftWidth: "1px"
                        }), e.afterMultiple && (Object.assign(a, {
                            backgroundColor: r,
                            borderRadius: "0 8rpx 8rpx 0",
                            boxSizing: "border-box",
                            border: "1px solid ".concat(o),
                            color: i
                        }), this.date.data && 2 == this.date.data.length && Object.assign(a, {
                            paddingLeft: "1px",
                            borderLeftWidth: 0
                        }))) : e.fullDate === t.fullDate && Object.assign(a, {
                            backgroundColor: r,
                            borderRadius: "8rpx",
                            color: i,
                            border: "1px solid ".concat(o)
                        }), e.disable && Object.assign(a, {
                            color: "#cccccc"
                        }), a) : a;
                    },
                    setDate: function(e) {
                        this.cale.setDate(e), this.weeks = this.cale.weeks, this.nowDate = this.cale.getInfo(e);
                    },
                    changeMonth: function(e) {
                        var t = e.value;
                        this.setDate(t);
                    },
                    choiceDate: function(e) {
                        if (!e.disable) try {
                            var n = this.dataConfig, r = n.has_kuatian, i = n.place_unit, o = n.day_max, a = n.is_day;
                            if (0 == n.is_alone) {
                                var s = this.cale.multipleStatus, c = s.before, u = s.after;
                                if (!this.cale.range) return;
                                if (c && !u && e.fullDate > c) {
                                    var p, d = !1, f = l(this.formatWeeks);
                                    try {
                                        for (f.s(); !(p = f.n()).done; ) {
                                            var h, g = l(p.value);
                                            try {
                                                for (g.s(); !(h = g.n()).done; ) {
                                                    var v = h.value;
                                                    if (v.fullDate === c && (d = !0), d && v.disable && (d = !1), void 0 === v.fullDate && (d = !0), 
                                                    v.fullDate === e.fullDate && !d) throw new Error("请选择连续可用日期");
                                                }
                                            } catch (e) {
                                                g.e(e);
                                            } finally {
                                                g.f();
                                            }
                                        }
                                    } catch (e) {
                                        f.e(e);
                                    } finally {
                                        f.f();
                                    }
                                } else if (c && !u && e.fullDate == c) return this.cale.multipleStatus.before = "", 
                                this.cale.multipleStatus.after = "", this.cale.multipleStatus.data = [], this.cale._getWeek(e.fullDate), 
                                this.calendar = e, this.weeks = this.cale.weeks, this.date = this.cale.multipleStatus, 
                                void this.updateStock();
                            }
                            this.cale.setMultiple(e.fullDate, a, o, r, i), this.calendar = e, this.weeks = this.cale.weeks, 
                            this.date = this.cale.multipleStatus, this.updateStock();
                        } catch (e) {
                            t.showToast({
                                title: e.message,
                                icon: "none"
                            });
                        }
                    },
                    handleParam: function() {
                        var e, t, n = this, r = this.checked, i = this.goods, o = (this.number, this.dataConfig), a = this.calendar, s = [], u = l(i.attr);
                        try {
                            for (u.s(); !(e = u.n()).done; ) {
                                var p = e.value;
                                if (p.id == r.id) {
                                    s = p.date;
                                    break;
                                }
                            }
                        } catch (e) {
                            u.e(e);
                        } finally {
                            u.f();
                        }
                        return t = 1 == o.is_alone ? {
                            before: a.fullDate,
                            after: a.fullDate,
                            data: a.fullDate ? [ a.fullDate ] : []
                        } : JSON.parse(JSON.stringify(this.date)), t.data = t.data.map(function(e, r) {
                            var i;
                            return s.forEach(function(o) {
                                var a = o.date, s = (a.day, a.month, a.year, a.value);
                                e === s && (i = 1 == n.dataConfig.has_kuatian && r + 1 == t.data.length ? c({}, e, 0) : c({}, e, o.value.calc_price));
                            }), i;
                        }), t;
                    },
                    handleNext: function() {
                        var e = s(d.default.mark(function e() {
                            var n, r, i, o, a, s, c, u, p, f, h, g, v, m, y, _, b, x, w, A, S, k, P, O;
                            return d.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (this.$user.isLogin()) {
                                        e.next = 3;
                                        break;
                                    }
                                    return e.next = 3, this.$user.getInfo({
                                        no_jump: !0
                                    });

                                  case 3:
                                    if ("form-goods" !== this.goods.type || "calendar" !== this.dataConfig.form_mode_type) {
                                        e.next = 7;
                                        break;
                                    }
                                    if (this.isSelect()) {
                                        e.next = 7;
                                        break;
                                    }
                                    return t.showToast({
                                        title: "请选择日历信息",
                                        icon: "none"
                                    }), e.abrupt("return");

                                  case 7:
                                    n = this.handleParam(), r = this.checked, i = this.goods, o = this.number, a = [], 
                                    r.attr_list.forEach(function(e) {
                                        return a.push({
                                            attr_id: e.attr_id,
                                            attr_group_id: e.attr_group_id
                                        });
                                    }), s = [ {
                                        mch_id: i.mch_id || 0,
                                        goods_list: [ {
                                            id: i.id,
                                            attrs: a,
                                            num: o,
                                            cat_id: 0,
                                            goods_attr_id: r.id
                                        } ]
                                    } ], c = this.dataConfig, u = c.form_mode_type, p = c.is_alone, f = c.has_kuatian, 
                                    h = "calendar" === u ? 1 == p ? 1 : 1 == f ? n.data.length - 1 : n.data.length : 0, 
                                    g = [], v = l(s[0].goods_list[0].attrs);
                                    try {
                                        for (v.s(); !(m = v.n()).done; ) {
                                            y = m.value, _ = l(i.attr_groups);
                                            try {
                                                for (_.s(); !(b = _.n()).done; ) if (x = b.value, y.attr_group_id == x.attr_group_id) {
                                                    w = l(x.attr_list);
                                                    try {
                                                        for (w.s(); !(A = w.n()).done; ) S = A.value, y.attr_id == S.attr_id && g.push({
                                                            label: x.attr_group_name,
                                                            value: S.attr_name
                                                        });
                                                    } catch (e) {
                                                        w.e(e);
                                                    } finally {
                                                        w.f();
                                                    }
                                                }
                                            } catch (e) {
                                                _.e(e);
                                            } finally {
                                                _.f();
                                            }
                                        }
                                    } catch (e) {
                                        v.e(e);
                                    } finally {
                                        v.f();
                                    }
                                    for (O in k = {
                                        attr_value: JSON.stringify(g).replace(/\&/g, "%26"),
                                        mch_list: JSON.stringify(s),
                                        price: r.calc_price,
                                        goods_id: i.id,
                                        stock: o,
                                        date: JSON.stringify(n || []),
                                        real_day_num: h
                                    }, P = "/pages/goods/goods-form?", k) P += O + "=" + k[O] + "&";
                                    t.navigateTo({
                                        url: P
                                    });

                                  case 21:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }(),
                    isSelect: function() {
                        var e = this.dataConfig, t = this.calendar, n = this.date;
                        if (1 == e.is_alone) return !!t.fullDate;
                        var r = n.after, i = n.before;
                        return n.data, Boolean(r && i);
                    },
                    updateStock: function() {
                        var e = this;
                        if (this.isSelect() && this.checked) {
                            var t, n, r = this.dataConfig, i = this.formatWeeks, a = this.date, s = this.calendar;
                            if (1 == r.is_alone) t = s.stock, n = s.calc_price, this.checked.stock = t || 0; else {
                                var c = function() {
                                    var t = [], r = [];
                                    if (a.data.length < 2) return {
                                        v: void 0
                                    };
                                    for (var o in i) i[o].forEach(function(e) {
                                        var n = e.fullDate, i = e.stock, o = e.calc_price;
                                        a.data.forEach(function(e) {
                                            n === e && (t.push(Number(i)), r.push(Number(o)));
                                        });
                                    });
                                    e.checked.stock = Math.min.apply(Math, t), n = Array.from(r).reduce(function(e, t) {
                                        return e + t;
                                    }).toFixed(3).toLocaleString(), n = n.substr(0, n.length - 1);
                                }();
                                if ("object" === o(c)) return c.v;
                            }
                            this.checked.price = n || 0, this.checked.calc_price = n || 0, this.checked.price_member = n || 0;
                        }
                    },
                    createCalendar: function() {
                        var e = this.dataConfig, t = e.calendar_start, n = e.calendar_end, r = e.is_alone, i = e.after_day, o = function(e) {
                            var t = e.getFullYear(), n = e.getMonth() + 1;
                            n = n < 10 ? "0" + n : n;
                            var r = e.getDate();
                            return r = r < 10 ? "0" + r : r, t + "-" + n + "-" + r + " 00:00:00";
                        }, a = "";
                        switch (e.is_today) {
                          case "none":
                            a = t;
                            break;

                          case "today":
                            var s = new Date(t.replace(/-/g, "/")).getTime();
                            a = new Date().getTime() > s ? o(new Date()) : t;
                            break;

                          case "after":
                            var c = new Date(), l = new Date(t.replace(/-/g, "/")).getTime();
                            c = c.setDate(c.getDate() + Number(i)), a = new Date(c).getTime() > l ? o(new Date(c)) : t;
                        }
                        if (a) {
                            var u = new Date(a.replace(/-/g, "/"));
                            this.cale = new f.default({
                                date: u,
                                selected: [],
                                startDate: a,
                                endDate: n,
                                range: 0 == r
                            }), this.setDate(u), this.monthList(this.cale);
                        }
                    },
                    monthList: function(e) {
                        var t = e.startDate, n = e.endDate;
                        if (t && n) {
                            for (var r = new Date(t.replace(/-/g, "/")), i = new Date(n.replace(/-/g, "/")), o = r.getFullYear(), a = r.getMonth() + 1, s = []; i.getFullYear() >= o; ) {
                                for (var c = i.getFullYear() == o ? i.getMonth() + 1 : 12, l = o == r.getFullYear() ? a : 1; l <= c; l++) s.push({
                                    year: o,
                                    month: l,
                                    value: o + "-" + l + "-1",
                                    text: l + "月"
                                });
                                o++;
                            }
                            this.weekList = s;
                        }
                    },
                    upCalendar: function(e) {
                        "form-goods" === this.goods.type && "calendar" === this.dataConfig.form_mode_type && (this.dateData = e.date, 
                        this.updateStock());
                    }
                }
            };
            n.default = h;
        }).call(this, r("543d").default);
    },
    "0be2": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                reportAndError: {
                    boolean: !1,
                    content: "网络开了会儿小差， 请刷新重试下哦~"
                },
                tabBarBoolean: !1,
                systemInfo: {
                    SDKVersion: "",
                    batteryLevel: 0,
                    brand: "",
                    errMsg: "",
                    fontSizeSetting: 0,
                    language: "0",
                    model: "",
                    pixelRatio: 0,
                    platform: "",
                    safeArea: {
                        bottom: 0,
                        height: 0,
                        left: 0,
                        right: 0,
                        top: 0,
                        width: 0
                    },
                    screenHeight: 0,
                    screenWidth: 0,
                    statusBarHeight: 0,
                    system: "",
                    version: "",
                    windowHeight: 0,
                    windowWidth: 0
                },
                mBarHeight: 44,
                tabBarHeight: 0,
                iphone: !1,
                iphoneHeight: 0,
                promptBox: {
                    text: "",
                    show: !1,
                    call: -1
                },
                imageWidth: 0,
                scene: 1001
            },
            getters: {
                reportAndErrorObj: function(e) {
                    return e.reportAndError;
                }
            },
            mutations: {
                reportAndErrorObj: function(e, t) {
                    e.reportAndError = t;
                },
                reportAndErrorB: function(e, t) {
                    e.reportAndError.boolean = t;
                },
                setTabBarBoolean: function(e, t) {
                    var n = getCurrentPages(), r = null;
                    n.length && (r = n[n.length - 1]);
                    var i = void 0;
                    i = "/".concat(r.route.split("?")[0]);
                    for (var o = 0; o < t.length; o++) if (i.includes(t[o].url.split("?")[0])) return e.tabBarBoolean = !0;
                    return e.tabBarBoolean = !1;
                },
                setSystemInfo: function(e, t) {
                    e.systemInfo = t, e.imageWidth = t.windowWidth;
                },
                setPromptBox: function(e, t) {
                    e.promptBox = t;
                },
                setPromptBoxCall: function(e, t) {
                    e.promptBox.call = t;
                },
                setHeight: function(e, t) {
                    e.tabBarHeight = t;
                },
                setiPhoneHeight: function(e, t) {
                    e.iphoneHeight = t;
                },
                setiPhoneBoolean: function(e, t) {
                    e.iphone = t;
                },
                setImageWidth: function(e, t) {
                    e.imageWidth = e.systemInfo.windowWidth - e.systemInfo.windowWidth / 750 * t;
                },
                setScene: function(e, t) {
                    e.scene = t;
                }
            },
            actions: {
                setImageWidth: function(e, t) {
                    e.commit("setImageWidth", t);
                },
                reportAndErrorObj: function(e, t) {
                    e.commit("reportAndErrorObj", t);
                },
                reportAndErrorB: function(e, t) {
                    e.commit("reportAndErrorB", t);
                },
                setTabBarBoolean: function(e, t) {
                    e.commit("setTabBarBoolean", t);
                },
                setSystemInfo: function(e, t) {
                    e.commit("setSystemInfo", t);
                },
                setHeight: function(e, t) {
                    e.commit("setHeight", t);
                },
                setiPhoneBoolean: function(e, t) {
                    e.commit("setiPhoneBoolean", t);
                },
                setPromptBox: function(e, t) {
                    e.commit("setPromptBox", t);
                },
                setPromptBoxCall: function(e, t) {
                    e.commit("setPromptBoxCall", t);
                },
                setiPhoneHeight: function(e, t) {
                    e.commit("setiPhoneHeight", t);
                },
                setScene: function(e, t) {
                    e.commit("setScene", t);
                }
            }
        };
        t.default = r;
    },
    "0c43": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            props: {
                beforeColor: String,
                afterColor: String,
                numColor: String,
                indicatorPos: {
                    type: String,
                    default: "bottomCenter"
                },
                interval: {
                    type: [ String, Number ],
                    default: 3e3
                },
                duration: {
                    type: [ Number, String ],
                    default: 500
                },
                mode: {
                    type: String,
                    default: "round"
                },
                autoplay: {
                    type: Boolean,
                    default: !0
                },
                name: {
                    type: String,
                    default: "image"
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                height: {
                    type: [ Number, String ],
                    default: 250
                },
                cBorderBottom: [ String, Number ],
                cBorderTop: [ String, Number ]
            },
            computed: {
                justifyContent: function() {
                    return "topLeft" == this.indicatorPos || "bottomLeft" == this.indicatorPos ? "flex-start" : "topCenter" == this.indicatorPos || "bottomCenter" == this.indicatorPos ? "center" : "topRight" == this.indicatorPos || "bottomRight" == this.indicatorPos ? "flex-end" : void 0;
                },
                testColor: function() {
                    var e = this;
                    return function(t) {
                        return t == e.current && e.afterColor ? {
                            "background-color": "".concat(e.afterColor)
                        } : t != e.current && e.beforeColor ? {
                            "background-color": "".concat(e.beforeColor)
                        } : void 0;
                    };
                }
            }
        };
        t.default = r;
    },
    "0f9a": function(t, n, r) {
        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function o(e) {
            if ("function" != typeof WeakMap) return null;
            var t = new WeakMap(), n = new WeakMap();
            return (o = function(e) {
                return e ? n : t;
            })(e);
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(r("816e")), s = function(e, t) {
            if (!t && e && e.__esModule) return e;
            if (null === e || "object" !== i(e) && "function" != typeof e) return {
                default: e
            };
            var n = o(t);
            if (n && n.has(e)) return n.get(e);
            var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
                var c = a ? Object.getOwnPropertyDescriptor(e, s) : null;
                c && (c.get || c.set) ? Object.defineProperty(r, s, c) : r[s] = e[s];
            }
            return r.default = e, n && n.set(e, r), r;
        }(r("ac6b")), c = {
            namespaced: !0,
            state: {
                accessToken: null,
                info: null,
                showLoginModal: !1,
                tempParentId: 0,
                cart_nums: 0,
                showAttention: !1,
                showAttentionTwo: !1,
                sign: {
                    mobile: "",
                    pic_captcha: "",
                    sms_captcha: "",
                    validate_code_id: -1
                },
                isSign: !1
            },
            getters: {
                accessToken: function(e) {
                    return e.accessToken;
                },
                info: function(e) {
                    return e.info;
                },
                cart_nums: function(e) {
                    return e.cart_nums;
                },
                showLoginModal: function(e) {
                    return e.showLoginModal;
                },
                tempParentId: function(e) {
                    return e.tempParentId;
                },
                is_vip: function(e) {
                    return e.is_vip_card_user;
                },
                showAttention: function(e) {
                    return e.showAttention;
                },
                showAttentionTwo: function(e) {
                    return e.showAttentionTwo;
                },
                sign: function(e) {
                    return e.sign;
                },
                isSign: function(e) {
                    return e.isSign;
                }
            },
            mutations: {
                accessToken: function(e, t) {
                    e.accessToken = t;
                },
                info: function(e, t) {
                    e.info = t;
                },
                cart_nums: function(e, t) {
                    e.cart_nums = t;
                },
                showLoginModal: function(e, t) {
                    e.showLoginModal = t;
                },
                tempParentId: function(e, t) {
                    e.tempParentId = t;
                },
                showAttention: function(e, t) {
                    e.showAttention = t;
                },
                showAttentionTwo: function(e, t) {
                    e.showAttentionTwo = t;
                },
                sign: function(e, t) {
                    e.sign = t;
                },
                isSign: function(e, t) {
                    e.isSign = t;
                }
            },
            actions: {
                sign: function(e, t) {
                    e.commit("sign", t);
                },
                isSign: function(e, t) {
                    e.commit("isSign", t);
                },
                cart_nums: function(e, t) {
                    e.commit("cart_nums", t);
                },
                accessToken: function(e) {
                    a.default.isLogin() || e.commit("accessToken", null), a.default.getAccessToken().then(function(t) {
                        e.commit("accessToken", t);
                    });
                },
                info: function(e, t) {
                    a.default.isLogin() || e.commit("accessToken", null), a.default.getAccessToken().then(function(n) {
                        e.commit("accessToken", n), a.default.getInfo(t).then(function(t) {
                            e.commit("info", t);
                        });
                    }).catch(function(t) {
                        e.commit("showLoginModal", !0);
                    });
                },
                refreshInfo: function(e) {
                    e.commit("accessToken", null);
                },
                refresh: function(e) {
                    a.default.isLogin() || e.commit("accessToken", null), a.default.getAccessToken().then(function(t) {
                        e.commit("accessToken", t), a.default.getInfo({
                            refresh: !0
                        }).then(function(t) {
                            e.commit("info", t);
                        }).catch(function(e) {});
                    }).catch(function(e) {});
                },
                setTempParentId: function(e, t) {
                    s.setStorageSync("tempParentId", t), e.commit("tempParentId", t);
                },
                loadAccessTokenFormCache: function(e) {
                    e.accessToken || a.default.getAccessToken({
                        cacheOnly: !0
                    }).then(function(t) {
                        t && e.commit("accessToken", t);
                    });
                },
                logout: function(e) {
                    e.commit("accessToken", null), e.commit("info", null), a.default.loginByToken(null), 
                    a.default.logout();
                },
                showAttention: function(e, t) {
                    e.commit("showAttention", t);
                },
                showAttentionTwo: function(e, t) {
                    e.commit("showAttentionTwo", t);
                }
            }
        };
        n.default = c;
    },
    "121d": function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e, t, n, r, i, o, a) {
            try {
                var s = e[o](a), c = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i);
        }
        function o(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(r, o) {
                    function a(e) {
                        i(c, r, o, a, s, "next", e);
                    }
                    function s(e) {
                        i(c, r, o, a, s, "throw", e);
                    }
                    var c = e.apply(t, n);
                    a(void 0);
                });
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = r(n("a34a")), s = r(n("66fd")), c = {
            namespaced: !0,
            state: {
                type: "global",
                text: "加载中",
                color: "#ffffff",
                backgroundImage: "",
                isShow: !1
            },
            getters: {
                getType: function(e) {
                    return e.type;
                },
                getText: function(e) {
                    return e.text;
                },
                getColor: function(e) {
                    return e.color;
                },
                getBackgroundImage: function() {
                    var e = o(a.default.mark(function e(t) {
                        return a.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.abrupt("return", t.backgroundImage);

                              case 1:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }));
                    return function(t) {
                        return e.apply(this, arguments);
                    };
                }(),
                getIsShow: function(e) {
                    return e.isShow;
                }
            },
            mutations: {
                mutSetLoading: function(e, t) {
                    for (var n in t) e[n] = t[n];
                    e.backgroundImage || s.default.prototype.$mallConfig.getConfig().then(function(t) {
                        e.backgroundImage = t.__wxapp_img.mall.loading;
                    });
                }
            },
            actions: {
                actionGetLoading: function(e, t) {
                    e.commit("mutSetLoading", t);
                }
            }
        };
        t.default = c;
    },
    1639: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            onLoad: function() {
                console.log("--商品混入--");
            },
            computed: {
                remindParams: function() {
                    return {
                        sell_time: this.sell_time,
                        goods_id: this.goods ? this.goods.id : 0,
                        template_message_list: this.template_message_list,
                        buy_text: "立即购买"
                    };
                },
                rightRemindText: function() {
                    return this.remindParams.sell_time > 300 ? "开售提醒我" : this.remindParams.sell_time > 0 ? "即将开售" : this.remindParams.buy_text;
                }
            },
            methods: {
                rightTip: function() {
                    this.remindParams.sell_time < 300 ? console.log("小于5分钟不进行开售提醒") : this.$goodsRemind(this.remindParams.template_message_list, this.remindParams.goods_id);
                }
            }
        };
        t.default = r;
    },
    "1fb5": function(e, t, n) {
        function r(e) {
            var t = e.length;
            if (t % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
            var n = e.indexOf("=");
            return -1 === n && (n = t), [ n, n === t ? 0 : 4 - n % 4 ];
        }
        function i(e, t, n) {
            return 3 * (t + n) / 4 - n;
        }
        function o(e) {
            return s[e >> 18 & 63] + s[e >> 12 & 63] + s[e >> 6 & 63] + s[63 & e];
        }
        function a(e, t, n) {
            for (var r, i = [], a = t; a < n; a += 3) r = (e[a] << 16 & 16711680) + (e[a + 1] << 8 & 65280) + (255 & e[a + 2]), 
            i.push(o(r));
            return i.join("");
        }
        t.byteLength = function(e) {
            var t = r(e), n = t[0], i = t[1];
            return 3 * (n + i) / 4 - i;
        }, t.toByteArray = function(e) {
            var t, n, o = r(e), a = o[0], s = o[1], u = new l(i(e, a, s)), p = 0, d = s > 0 ? a - 4 : a;
            for (n = 0; n < d; n += 4) t = c[e.charCodeAt(n)] << 18 | c[e.charCodeAt(n + 1)] << 12 | c[e.charCodeAt(n + 2)] << 6 | c[e.charCodeAt(n + 3)], 
            u[p++] = t >> 16 & 255, u[p++] = t >> 8 & 255, u[p++] = 255 & t;
            return 2 === s && (t = c[e.charCodeAt(n)] << 2 | c[e.charCodeAt(n + 1)] >> 4, u[p++] = 255 & t), 
            1 === s && (t = c[e.charCodeAt(n)] << 10 | c[e.charCodeAt(n + 1)] << 4 | c[e.charCodeAt(n + 2)] >> 2, 
            u[p++] = t >> 8 & 255, u[p++] = 255 & t), u;
        }, t.fromByteArray = function(e) {
            for (var t, n = e.length, r = n % 3, i = [], o = 16383, c = 0, l = n - r; c < l; c += o) i.push(a(e, c, c + o > l ? l : c + o));
            return 1 === r ? (t = e[n - 1], i.push(s[t >> 2] + s[t << 4 & 63] + "==")) : 2 === r && (t = (e[n - 2] << 8) + e[n - 1], 
            i.push(s[t >> 10] + s[t >> 4 & 63] + s[t << 2 & 63] + "=")), i.join("");
        };
        for (var s = [], c = [], l = "undefined" != typeof Uint8Array ? Uint8Array : Array, u = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", p = 0, d = u.length; p < d; ++p) s[p] = u[p], 
        c[u.charCodeAt(p)] = p;
        c["-".charCodeAt(0)] = 62, c["_".charCodeAt(0)] = 63;
    },
    "219f": function(t, n, r) {
        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function o(e) {
            if ("function" != typeof WeakMap) return null;
            var t = new WeakMap(), n = new WeakMap();
            return (o = function(e) {
                return e ? n : t;
            })(e);
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = function(e, t) {
            if (!t && e && e.__esModule) return e;
            if (null === e || "object" !== i(e) && "function" != typeof e) return {
                default: e
            };
            var n = o(t);
            if (n && n.has(e)) return n.get(e);
            var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
                var c = a ? Object.getOwnPropertyDescriptor(e, s) : null;
                c && (c.get || c.set) ? Object.defineProperty(r, s, c) : r[s] = e[s];
            }
            return r.default = e, n && n.set(e, r), r;
        }(r("b1c7"));
        n.default = function(e) {
            void 0 === (e = e || {
                title: "这是一个分享页面",
                query: {}
            }).query && (e.query = {});
            var t = 0;
            return this.$user.isLogin() && this.$store.state.user.info && (t = this.$store.state.user.info.options.user_id), 
            e.query.user_id = t, e.query = a.objectToUrlParams(e.query), e;
        };
    },
    2749: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            EVENT_USER_LOGIN: "event_user_login",
            EVENT_USER_REGISTER: "event_user_register",
            EVENT_VIDEO_END: "event_video_end",
            EVENT_POPUP: "popUpEvent"
        };
        t.default = r;
    },
    "27f5": function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = r(n("36e8")), a = function(e, t) {
            var n = {};
            for (var r in t) {
                var o = i({}, r, {});
                for (var a in t[r]) o[r][a] = "".concat(e).concat(t[r][a]);
                n[r] = o[r];
            }
            return n;
        }, s = function(e) {
            var t = "";
            return t = e.acid > 0 ? e.siteroot.substr(0, e.siteroot.indexOf("app/index.php")) + "addons/zjhj_bd/web/index.php?_acid=" + e.acid + "&r=" : e.apiroot + "&r=", 
            a(t, o.default);
        }(r(n("ae58")).default);
        t.default = s;
    },
    "2a74": function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("27f5")), o = r(n("9dc1")), a = {
            namespaced: !0,
            state: {
                home_pages: {},
                type: ""
            },
            getters: {},
            mutations: {
                getHomePages: function(e, t) {
                    e.type = t.type, e.home_pages = t.home_pages;
                }
            },
            actions: {
                getHomePages: function(e) {
                    (0, o.default)({
                        url: "".concat(i.default.index.index, "&page_id=0&longitude=&latitude=")
                    }).then(function(t) {
                        e.commit("getHomePages", t.data);
                    });
                }
            }
        };
        t.default = a;
    },
    "2c8b": function(t, n, r) {
        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function o(e) {
            switch (i(e)) {
              case "undefined":
                return !0;

              case "string":
                if (0 == e.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, "").length) return !0;
                break;

              case "boolean":
                if (!e) return !0;
                break;

              case "number":
                if (0 === e || isNaN(e)) return !0;
                break;

              case "object":
                if (null === e || 0 === e.length) return !0;
                for (var t in e) return !1;
                return !0;
            }
            return !1;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            email: function(e) {
                return /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/.test(e);
            },
            mobile: function(e) {
                return /^1[23456789]\d{9}$/.test(e);
            },
            url: function(e) {
                return /^((https|http|ftp|rtsp|mms):\/\/)(([0-9a-zA-Z_!~*'().&=+$%-]+: )?[0-9a-zA-Z_!~*'().&=+$%-]+@)?(([0-9]{1,3}.){3}[0-9]{1,3}|([0-9a-zA-Z_!~*'()-]+.)*([0-9a-zA-Z][0-9a-zA-Z-]{0,61})?[0-9a-zA-Z].[a-zA-Z]{2,6})(:[0-9]{1,4})?((\/?)|(\/[0-9a-zA-Z_!~*'().;?:@&=+$,%#-]+)+\/?)$/.test(e);
            },
            date: function(e) {
                return !/Invalid|NaN/.test(new Date(e.replace(/-/g, "/")).toString());
            },
            dateISO: function(e) {
                return /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(e);
            },
            number: function(e) {
                return /^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(e);
            },
            digits: function(e) {
                return /^\d+$/.test(e);
            },
            idCard: function(e) {
                return /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(e);
            },
            carNo: function(e) {
                var t = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}(([0-9]{5}[DF]$)|([DF][A-HJ-NP-Z0-9][0-9]{4}$))/, n = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳]{1}$/;
                return 7 === e.length ? n.test(e) : 8 === e.length && t.test(e);
            },
            amount: function(e) {
                return /^[1-9]\d*(,\d{3})*(\.\d{1,2})?$|^0\.\d{1,2}$/.test(e);
            },
            chinese: function(e) {
                return /^[\u4e00-\u9fa5]+$/gi.test(e);
            },
            letter: function(e) {
                return /^[a-zA-Z]*$/.test(e);
            },
            enOrNum: function(e) {
                return /^[0-9a-zA-Z]*$/g.test(e);
            },
            contains: function(e, t) {
                return e.indexOf(t) >= 0;
            },
            range: function(e, t) {
                return e >= t[0] && e <= t[1];
            },
            rangeLength: function(e, t) {
                return e.length >= t[0] && e.length <= t[1];
            },
            empty: o,
            isEmpty: o,
            jsonString: function(e) {
                if ("string" == typeof e) try {
                    var t = JSON.parse(e);
                    return !("object" != i(t) || !t);
                } catch (e) {
                    return !1;
                }
                return !1;
            },
            landline: function(e) {
                return /^\d{3,4}-\d{7,8}(-\d{3,4})?$/.test(e);
            },
            object: function(e) {
                return "[object Object]" === Object.prototype.toString.call(e);
            },
            array: function(e) {
                return "function" == typeof Array.isArray ? Array.isArray(e) : "[object Array]" === Object.prototype.toString.call(e);
            },
            umobile: function(e) {
                return /(^\d+$)|(^$)|(^([0-9]{3,4}-)?\d{7,8}$)|(^400[0-9]{7}$)|(^800[0-9]{7}$)|(^(400)-(\d{3})-(\d{4})(.)(\d{1,4})$)|(^(400)-(\d{3})-(\d{4}$))/.test(e);
            }
        };
        n.default = a;
    },
    "2d1a": function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAYAAADFeBvrAAAABHNCSVQICAgIfAhkiAAAAxNJREFUaEPd2tF50zAQAOBTCM90BNggTICD7WfaCWgnoEwAbJANKBO0706IOwHpBA0TAM91cpycJrUdWT7Zki3w9/WpiqPfdzrJUgT8Z5f4FzwYBCciTX9z+uo1CKPoEwBeghAngEggMRPz+RcdzFsQxuFXApwrOr+Ch2xaFzEvQRSZzyCAolN71aK8A9F4eQnPx/eM8aJEeQeSEIzfUqqNKOUaryOUlyAzFF6JZHGxp3sB2kVEvCl2zAi1xTOxWNzIzwwOwjA8hZG43j3h8tPeocIr6uZ7ffLhmh7Gq8FBGMcTwO0yn2cOVzuUSOZ5cAaLkBqzV20vRPKdIlNgNkRqUJAe0wp1S6BgkAjxMAYohD+UsoFIklXvIDOMBhVFNzRY3kEF0yuoHUaNkqtvWk1QmRaX+8j0Og89dmBJXzrRl1/df48Lhaq18ypnB3N4/q+rEaminILsYvKuH6pZXSydgaxjZAHIsgm9B611iekE5ARTKM29gobEOCnbGIXXNNGdtq9mxfVOedLk3NNqymn2ATh9KbdRTJqcm1gD+YCxlnJWMbJXCFParko5EbE+D1nHAG9F4GQe8g3TKeUYe2eGGdMtMp0WpwbbTEyUHUyrCPmMMQZZxyB8pGo2Y4aR1Yw9D1nHAH6jradzVi8NGrFA+fpsPF7Ta+8Lg3trmrrBGKXc7hUa0+4odxgjUD6BSxTgj/ZRcotpBNFcs6SXqrPi4VL7seQeowUVonF0ZGGO6gfTACptkndA4R1Vsw67PWYJrqxyu6r27L68iQ4tUHgHD5uAe4Jt1nV1azWo/gTNANU/pjblMI5kJatLEwZqGIwSxDq0RUhpyTItBv3pYGo4jBoUh7S2Eh+a81lxMCWP47Ns1ueYqfbzaAzRrs2vSjHQLWFKB7bND8F9ixLIfH7J1w9eocoguTIQEPCfI40XoHIOo1nTJjr/nt1aHkCsYgA5IIUt/W026ZBjpY79BFL/vuaWUmrlM6C2KFDZpd/XiJ+0J5bKKLTdF+uWMN0/nUfI5Ad23b/S7R1Yb6xuu2D37n8BTwLMRAyIVHsAAAAASUVORK5CYII=";
    },
    "2f62": function(t, n, r) {
        r.r(n), function(t) {
            function i(e) {
                function t() {
                    var e = this.$options;
                    e.store ? this.$store = "function" == typeof e.store ? e.store() : e.store : e.parent && e.parent.$store && (this.$store = e.parent.$store);
                }
                if (Number(e.version.split(".")[0]) >= 2) e.mixin({
                    beforeCreate: t
                }); else {
                    var n = e.prototype._init;
                    e.prototype._init = function(e) {
                        void 0 === e && (e = {}), e.init = e.init ? [ t ].concat(e.init) : t, n.call(this, e);
                    };
                }
            }
            function o(e) {
                R && (e._devtoolHook = R, R.emit("vuex:init", e), R.on("vuex:travel-to-state", function(t) {
                    e.replaceState(t);
                }), e.subscribe(function(e, t) {
                    R.emit("vuex:mutation", e, t);
                }, {
                    prepend: !0
                }), e.subscribeAction(function(e, t) {
                    R.emit("vuex:action", e, t);
                }, {
                    prepend: !0
                }));
            }
            function a(e, t) {
                return e.filter(t)[0];
            }
            function s(t, n) {
                if (void 0 === n && (n = []), null === t || "object" !== (void 0 === t ? "undefined" : e(t))) return t;
                var r = a(n, function(e) {
                    return e.original === t;
                });
                if (r) return r.copy;
                var i = Array.isArray(t) ? [] : {};
                return n.push({
                    original: t,
                    copy: i
                }), Object.keys(t).forEach(function(e) {
                    i[e] = s(t[e], n);
                }), i;
            }
            function c(e, t) {
                Object.keys(e).forEach(function(n) {
                    return t(e[n], n);
                });
            }
            function l(t) {
                return null !== t && "object" === (void 0 === t ? "undefined" : e(t));
            }
            function u(e) {
                return e && "function" == typeof e.then;
            }
            function p(e, t) {
                return function() {
                    return e(t);
                };
            }
            function d(e, t, n) {
                if (t.update(n), n.modules) for (var r in n.modules) {
                    if (!t.getChild(r)) return;
                    d(e.concat(r), t.getChild(r), n.modules[r]);
                }
            }
            function f(e, t, n) {
                return t.indexOf(e) < 0 && (n && n.prepend ? t.unshift(e) : t.push(e)), function() {
                    var n = t.indexOf(e);
                    n > -1 && t.splice(n, 1);
                };
            }
            function h(e, t) {
                e._actions = Object.create(null), e._mutations = Object.create(null), e._wrappedGetters = Object.create(null), 
                e._modulesNamespaceMap = Object.create(null);
                var n = e.state;
                v(e, n, [], e._modules.root, !0), g(e, n, t);
            }
            function g(e, t, n) {
                var r = e._vm;
                e.getters = {}, e._makeLocalGettersCache = Object.create(null);
                var i = {};
                c(e._wrappedGetters, function(t, n) {
                    i[n] = p(t, e), Object.defineProperty(e.getters, n, {
                        get: function() {
                            return e._vm[n];
                        },
                        enumerable: !0
                    });
                });
                var o = z.config.silent;
                z.config.silent = !0, e._vm = new z({
                    data: {
                        $$state: t
                    },
                    computed: i
                }), z.config.silent = o, e.strict && w(e), r && (n && e._withCommit(function() {
                    r._data.$$state = null;
                }), z.nextTick(function() {
                    return r.$destroy();
                }));
            }
            function v(e, t, n, r, i) {
                var o = !n.length, a = e._modules.getNamespace(n);
                if (r.namespaced && (e._modulesNamespaceMap[a], e._modulesNamespaceMap[a] = r), 
                !o && !i) {
                    var s = A(t, n.slice(0, -1)), c = n[n.length - 1];
                    e._withCommit(function() {
                        z.set(s, c, r.state);
                    });
                }
                var l = r.context = m(e, a, n);
                r.forEachMutation(function(t, n) {
                    _(e, a + n, t, l);
                }), r.forEachAction(function(t, n) {
                    var r = t.root ? n : a + n, i = t.handler || t;
                    b(e, r, i, l);
                }), r.forEachGetter(function(t, n) {
                    x(e, a + n, t, l);
                }), r.forEachChild(function(r, o) {
                    v(e, t, n.concat(o), r, i);
                });
            }
            function m(e, t, n) {
                var r = "" === t, i = {
                    dispatch: r ? e.dispatch : function(n, r, i) {
                        var o = S(n, r, i), a = o.payload, s = o.options, c = o.type;
                        return s && s.root || (c = t + c), e.dispatch(c, a);
                    },
                    commit: r ? e.commit : function(n, r, i) {
                        var o = S(n, r, i), a = o.payload, s = o.options, c = o.type;
                        s && s.root || (c = t + c), e.commit(c, a, s);
                    }
                };
                return Object.defineProperties(i, {
                    getters: {
                        get: r ? function() {
                            return e.getters;
                        } : function() {
                            return y(e, t);
                        }
                    },
                    state: {
                        get: function() {
                            return A(e.state, n);
                        }
                    }
                }), i;
            }
            function y(e, t) {
                if (!e._makeLocalGettersCache[t]) {
                    var n = {}, r = t.length;
                    Object.keys(e.getters).forEach(function(i) {
                        if (i.slice(0, r) === t) {
                            var o = i.slice(r);
                            Object.defineProperty(n, o, {
                                get: function() {
                                    return e.getters[i];
                                },
                                enumerable: !0
                            });
                        }
                    }), e._makeLocalGettersCache[t] = n;
                }
                return e._makeLocalGettersCache[t];
            }
            function _(e, t, n, r) {
                (e._mutations[t] || (e._mutations[t] = [])).push(function(t) {
                    n.call(e, r.state, t);
                });
            }
            function b(e, t, n, r) {
                (e._actions[t] || (e._actions[t] = [])).push(function(t) {
                    var i = n.call(e, {
                        dispatch: r.dispatch,
                        commit: r.commit,
                        getters: r.getters,
                        state: r.state,
                        rootGetters: e.getters,
                        rootState: e.state
                    }, t);
                    return u(i) || (i = Promise.resolve(i)), e._devtoolHook ? i.catch(function(t) {
                        throw e._devtoolHook.emit("vuex:error", t), t;
                    }) : i;
                });
            }
            function x(e, t, n, r) {
                e._wrappedGetters[t] || (e._wrappedGetters[t] = function(e) {
                    return n(r.state, r.getters, e.state, e.getters);
                });
            }
            function w(e) {
                e._vm.$watch(function() {
                    return this._data.$$state;
                }, function() {}, {
                    deep: !0,
                    sync: !0
                });
            }
            function A(e, t) {
                return t.reduce(function(e, t) {
                    return e[t];
                }, e);
            }
            function S(e, t, n) {
                return l(e) && e.type && (n = t, t = e, e = e.type), {
                    type: e,
                    payload: t,
                    options: n
                };
            }
            function k(e) {
                z && e === z || (z = e, i(z));
            }
            function P(e) {
                return O(e) ? Array.isArray(e) ? e.map(function(e) {
                    return {
                        key: e,
                        val: e
                    };
                }) : Object.keys(e).map(function(t) {
                    return {
                        key: t,
                        val: e[t]
                    };
                }) : [];
            }
            function O(e) {
                return Array.isArray(e) || l(e);
            }
            function T(e) {
                return function(t, n) {
                    return "string" != typeof t ? (n = t, t = "") : "/" !== t.charAt(t.length - 1) && (t += "/"), 
                    e(t, n);
                };
            }
            function C(e, t, n) {
                return e._modulesNamespaceMap[n];
            }
            function D(e) {
                void 0 === e && (e = {});
                var t = e.collapsed;
                void 0 === t && (t = !0);
                var n = e.filter;
                void 0 === n && (n = function(e, t, n) {
                    return !0;
                });
                var r = e.transformer;
                void 0 === r && (r = function(e) {
                    return e;
                });
                var i = e.mutationTransformer;
                void 0 === i && (i = function(e) {
                    return e;
                });
                var o = e.actionFilter;
                void 0 === o && (o = function(e, t) {
                    return !0;
                });
                var a = e.actionTransformer;
                void 0 === a && (a = function(e) {
                    return e;
                });
                var c = e.logMutations;
                void 0 === c && (c = !0);
                var l = e.logActions;
                void 0 === l && (l = !0);
                var u = e.logger;
                return void 0 === u && (u = console), function(e) {
                    var p = s(e.state);
                    void 0 !== u && (c && e.subscribe(function(e, o) {
                        var a = s(o);
                        if (n(e, p, a)) {
                            var c = E(), l = i(e), d = "mutation " + e.type + c;
                            j(u, d, t), u.log("%c prev state", "color: #9E9E9E; font-weight: bold", r(p)), u.log("%c mutation", "color: #03A9F4; font-weight: bold", l), 
                            u.log("%c next state", "color: #4CAF50; font-weight: bold", r(a)), $(u);
                        }
                        p = a;
                    }), l && e.subscribeAction(function(e, n) {
                        if (o(e, n)) {
                            var r = E(), i = a(e), s = "action " + e.type + r;
                            j(u, s, t), u.log("%c action", "color: #03A9F4; font-weight: bold", i), $(u);
                        }
                    }));
                };
            }
            function j(e, t, n) {
                var r = n ? e.groupCollapsed : e.group;
                try {
                    r.call(e, t);
                } catch (n) {
                    e.log(t);
                }
            }
            function $(e) {
                try {
                    e.groupEnd();
                } catch (t) {
                    e.log("—— log end ——");
                }
            }
            function E() {
                var e = new Date();
                return " @ " + L(e.getHours(), 2) + ":" + L(e.getMinutes(), 2) + ":" + L(e.getSeconds(), 2) + "." + L(e.getMilliseconds(), 3);
            }
            function M(e, t) {
                return new Array(t + 1).join(e);
            }
            function L(e, t) {
                return M("0", t - e.toString().length) + e;
            }
            r.d(n, "Store", function() {
                return B;
            }), r.d(n, "createLogger", function() {
                return D;
            }), r.d(n, "createNamespacedHelpers", function() {
                return X;
            }), r.d(n, "install", function() {
                return k;
            }), r.d(n, "mapActions", function() {
                return V;
            }), r.d(n, "mapGetters", function() {
                return q;
            }), r.d(n, "mapMutations", function() {
                return H;
            }), r.d(n, "mapState", function() {
                return W;
            });
            var R = ("undefined" != typeof window ? window : void 0 !== t ? t : {}).__VUE_DEVTOOLS_GLOBAL_HOOK__, I = function(e, t) {
                this.runtime = t, this._children = Object.create(null), this._rawModule = e;
                var n = e.state;
                this.state = ("function" == typeof n ? n() : n) || {};
            }, F = {
                namespaced: {
                    configurable: !0
                }
            };
            F.namespaced.get = function() {
                return !!this._rawModule.namespaced;
            }, I.prototype.addChild = function(e, t) {
                this._children[e] = t;
            }, I.prototype.removeChild = function(e) {
                delete this._children[e];
            }, I.prototype.getChild = function(e) {
                return this._children[e];
            }, I.prototype.hasChild = function(e) {
                return e in this._children;
            }, I.prototype.update = function(e) {
                this._rawModule.namespaced = e.namespaced, e.actions && (this._rawModule.actions = e.actions), 
                e.mutations && (this._rawModule.mutations = e.mutations), e.getters && (this._rawModule.getters = e.getters);
            }, I.prototype.forEachChild = function(e) {
                c(this._children, e);
            }, I.prototype.forEachGetter = function(e) {
                this._rawModule.getters && c(this._rawModule.getters, e);
            }, I.prototype.forEachAction = function(e) {
                this._rawModule.actions && c(this._rawModule.actions, e);
            }, I.prototype.forEachMutation = function(e) {
                this._rawModule.mutations && c(this._rawModule.mutations, e);
            }, Object.defineProperties(I.prototype, F);
            var N = function(e) {
                this.register([], e, !1);
            };
            N.prototype.get = function(e) {
                return e.reduce(function(e, t) {
                    return e.getChild(t);
                }, this.root);
            }, N.prototype.getNamespace = function(e) {
                var t = this.root;
                return e.reduce(function(e, n) {
                    return t = t.getChild(n), e + (t.namespaced ? n + "/" : "");
                }, "");
            }, N.prototype.update = function(e) {
                d([], this.root, e);
            }, N.prototype.register = function(e, t, n) {
                var r = this;
                void 0 === n && (n = !0);
                var i = new I(t, n);
                0 === e.length ? this.root = i : this.get(e.slice(0, -1)).addChild(e[e.length - 1], i), 
                t.modules && c(t.modules, function(t, i) {
                    r.register(e.concat(i), t, n);
                });
            }, N.prototype.unregister = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1], r = t.getChild(n);
                r && r.runtime && t.removeChild(n);
            }, N.prototype.isRegistered = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1];
                return !!t && t.hasChild(n);
            };
            var z, B = function(e) {
                var t = this;
                void 0 === e && (e = {}), !z && "undefined" != typeof window && window.Vue && k(window.Vue);
                var n = e.plugins;
                void 0 === n && (n = []);
                var r = e.strict;
                void 0 === r && (r = !1), this._committing = !1, this._actions = Object.create(null), 
                this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), 
                this._modules = new N(e), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], 
                this._watcherVM = new z(), this._makeLocalGettersCache = Object.create(null);
                var i = this, a = this, s = a.dispatch, c = a.commit;
                this.dispatch = function(e, t) {
                    return s.call(i, e, t);
                }, this.commit = function(e, t, n) {
                    return c.call(i, e, t, n);
                }, this.strict = r;
                var l = this._modules.root.state;
                v(this, l, [], this._modules.root), g(this, l), n.forEach(function(e) {
                    return e(t);
                }), (void 0 !== e.devtools ? e.devtools : z.config.devtools) && o(this);
            }, U = {
                state: {
                    configurable: !0
                }
            };
            U.state.get = function() {
                return this._vm._data.$$state;
            }, U.state.set = function(e) {}, B.prototype.commit = function(e, t, n) {
                var r = this, i = S(e, t, n), o = i.type, a = i.payload, s = (i.options, {
                    type: o,
                    payload: a
                }), c = this._mutations[o];
                c && (this._withCommit(function() {
                    c.forEach(function(e) {
                        e(a);
                    });
                }), this._subscribers.slice().forEach(function(e) {
                    return e(s, r.state);
                }));
            }, B.prototype.dispatch = function(e, t) {
                var n = this, r = S(e, t), i = r.type, o = r.payload, a = {
                    type: i,
                    payload: o
                }, s = this._actions[i];
                if (s) {
                    try {
                        this._actionSubscribers.slice().filter(function(e) {
                            return e.before;
                        }).forEach(function(e) {
                            return e.before(a, n.state);
                        });
                    } catch (e) {}
                    var c = s.length > 1 ? Promise.all(s.map(function(e) {
                        return e(o);
                    })) : s[0](o);
                    return new Promise(function(e, t) {
                        c.then(function(t) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.after;
                                }).forEach(function(e) {
                                    return e.after(a, n.state);
                                });
                            } catch (e) {}
                            e(t);
                        }, function(e) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.error;
                                }).forEach(function(t) {
                                    return t.error(a, n.state, e);
                                });
                            } catch (e) {}
                            t(e);
                        });
                    });
                }
            }, B.prototype.subscribe = function(e, t) {
                return f(e, this._subscribers, t);
            }, B.prototype.subscribeAction = function(e, t) {
                return f("function" == typeof e ? {
                    before: e
                } : e, this._actionSubscribers, t);
            }, B.prototype.watch = function(e, t, n) {
                var r = this;
                return this._watcherVM.$watch(function() {
                    return e(r.state, r.getters);
                }, t, n);
            }, B.prototype.replaceState = function(e) {
                var t = this;
                this._withCommit(function() {
                    t._vm._data.$$state = e;
                });
            }, B.prototype.registerModule = function(e, t, n) {
                void 0 === n && (n = {}), "string" == typeof e && (e = [ e ]), this._modules.register(e, t), 
                v(this, this.state, e, this._modules.get(e), n.preserveState), g(this, this.state);
            }, B.prototype.unregisterModule = function(e) {
                var t = this;
                "string" == typeof e && (e = [ e ]), this._modules.unregister(e), this._withCommit(function() {
                    var n = A(t.state, e.slice(0, -1));
                    z.delete(n, e[e.length - 1]);
                }), h(this);
            }, B.prototype.hasModule = function(e) {
                return "string" == typeof e && (e = [ e ]), this._modules.isRegistered(e);
            }, B.prototype.hotUpdate = function(e) {
                this._modules.update(e), h(this, !0);
            }, B.prototype._withCommit = function(e) {
                var t = this._committing;
                this._committing = !0, e(), this._committing = t;
            }, Object.defineProperties(B.prototype, U);
            var W = T(function(e, t) {
                var n = {};
                return P(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        var t = this.$store.state, n = this.$store.getters;
                        if (e) {
                            var r = C(this.$store, 0, e);
                            if (!r) return;
                            t = r.context.state, n = r.context.getters;
                        }
                        return "function" == typeof i ? i.call(this, t, n) : t[i];
                    }, n[r].vuex = !0;
                }), n;
            }), H = T(function(e, t) {
                var n = {};
                return P(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.commit;
                        if (e) {
                            var o = C(this.$store, 0, e);
                            if (!o) return;
                            r = o.context.commit;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ i ].concat(t));
                    };
                }), n;
            }), q = T(function(e, t) {
                var n = {};
                return P(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    i = e + i, n[r] = function() {
                        if (!e || C(this.$store, 0, e)) return this.$store.getters[i];
                    }, n[r].vuex = !0;
                }), n;
            }), V = T(function(e, t) {
                var n = {};
                return P(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.dispatch;
                        if (e) {
                            var o = C(this.$store, 0, e);
                            if (!o) return;
                            r = o.context.dispatch;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ i ].concat(t));
                    };
                }), n;
            }), X = function(e) {
                return {
                    mapState: W.bind(null, e),
                    mapGetters: q.bind(null, e),
                    mapMutations: H.bind(null, e),
                    mapActions: V.bind(null, e)
                };
            }, G = {
                Store: B,
                install: k,
                version: "3.6.2",
                mapState: W,
                mapMutations: H,
                mapGetters: q,
                mapActions: V,
                createNamespacedHelpers: X,
                createLogger: D
            };
            n.default = G;
        }.call(this, r("c8ba"));
    },
    3163: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            data: function() {
                return {
                    role: {
                        basic_order: "none",
                        basic_audit: "none",
                        basic_audit_detail: [],
                        basic_cash: "none",
                        basic_cash_detail: [],
                        basic_comments: "none",
                        basic_user_detail: [],
                        basic_user: "none",
                        basic_form: "none",
                        basic_customers_order: "none",
                        end_order: "none",
                        end_goods: "none",
                        end_setting: "none",
                        home_page: []
                    }
                };
            },
            mounted: function() {
                var e = this;
                this.$user.isLogin() && this.before(function(t) {
                    e.role = t;
                });
            },
            computed: {
                menuNum: function() {
                    var e = this.role;
                    return [ e.basic_order, e.basic_audit, e.basic_cash, e.basic_comments, e.basic_user, e.basic_form, e.basic_customers_order ].reduce(function(e, t) {
                        return "none" === t ? e : ++e;
                    }, 0);
                }
            },
            methods: {
                before: function(e) {
                    var t = this, n = this.$storage.getStorageSync("__ADMIN_PER");
                    n && e(n), this.$request({
                        url: this.$api.app_admin.role
                    }).then(function(n) {
                        if (0 === n.code) {
                            var r = n.data.role.permissions;
                            t.$storage.setStorageSync("__ADMIN_PER", r), e(r);
                        }
                    });
                }
            }
        };
        t.default = r;
    },
    "36ce": function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function i(e, t, n, r, i, o, a) {
                try {
                    var s = e[o](a), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(r, i);
            }
            function o(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, o) {
                        function a(e) {
                            i(c, r, o, a, s, "next", e);
                        }
                        function s(e) {
                            i(c, r, o, a, s, "throw", e);
                        }
                        var c = e.apply(t, n);
                        a(void 0);
                    });
                };
            }
            function a(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function s(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                    Object.defineProperty(e, r.key, r);
                }
            }
            function c(e, t, n) {
                return t && s(e.prototype, t), n && s(e, n), e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = r(n("a34a")), u = r(n("9dc1")), p = r(n("66fd")), d = function() {
                function t(e) {
                    a(this, t), this.config = e, this.percent = 0, this.sign = new Date().valueOf(), 
                    this.maxRequest = e.maxRequest || 10, this.filePath = wx.env.USER_DATA_PATH, this.header = {};
                }
                return c(t, [ {
                    key: "handshake",
                    value: function(e) {
                        var t = this;
                        (0, u.default)({
                            url: this.config.url,
                            method: "POST",
                            data: {
                                chunks: this.chunks,
                                sign: this.sign,
                                size: this.config.byteLength,
                                fileName: this.config.fileName,
                                contentType: this.config.type
                            }
                        }).then(function(n) {
                            0 == n.code ? e() : t.config.fail(n.msg);
                        }).catch(function(e) {
                            return t.config.fail("握手失败");
                        });
                    }
                }, {
                    key: "startUpload",
                    value: function() {
                        var t = o(l.default.mark(function t() {
                            var n, r, i = this;
                            return l.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (this.config.filePath) {
                                        t.next = 2;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 2:
                                    return t.next = 4, p.default.prototype.$store.dispatch("user/loadAccessTokenFormCache");

                                  case 4:
                                    return p.default.prototype.$store.state.user && p.default.prototype.$store.state.user.accessToken && (this.header["X-Access-Token"] = p.default.prototype.$store.state.user.accessToken), 
                                    n = e.getFileSystemManager(), r = this, t.next = 9, n.access({
                                        path: "".concat(r.filePath, "/up_temp"),
                                        fail: function(e) {
                                            n.mkdirSync("".concat(r.filePath, "/up_temp"), !1);
                                        }
                                    });

                                  case 9:
                                    this.chunks = Math.ceil(this.config.byteLength / this.config.size), this.requestArr = new Array(this.chunks).fill(0).map(function(e, t) {
                                        return t;
                                    }), this.handshake(function() {
                                        var e = o(l.default.mark(function e(t) {
                                            return l.default.wrap(function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                  case 0:
                                                    for (console.log("循环开始"); i.maxRequest > 0; ) i.maxRequest--, i.loadNext(i.requestArr.shift());

                                                  case 2:
                                                  case "end":
                                                    return e.stop();
                                                }
                                            }, e);
                                        }));
                                        return function(t) {
                                            return e.apply(this, arguments);
                                        };
                                    }());

                                  case 12:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "loadNext",
                    value: function(e) {
                        var t = this;
                        if ("number" == typeof e) {
                            var n = e * this.config.size, r = n + this.config.size >= this.config.byteLength ? this.config.byteLength - n : this.config.size;
                            this.fileSlice(n, r, function(n) {
                                t.uploadFileBinary(n, e);
                            });
                        }
                    }
                }, {
                    key: "uploadFile",
                    value: function(t, n) {
                        var r = this;
                        console.log("切片上传中", n), e.uploadFile({
                            header: this.header,
                            url: this.config.url,
                            filePath: t,
                            name: "file",
                            formData: {
                                sign: this.sign,
                                currentChunk: n,
                                file: t,
                                file_name: this.config.fileName
                            },
                            success: function(e) {
                                r.config.drowSpeed({
                                    percent: parseInt(++r.percent / r.chunks * 100)
                                }), r.percent >= r.chunks ? r.config.success(e) : r.loadNext(r.requestArr.shift());
                            },
                            fail: function(e) {
                                r.fail("切片上传失败");
                            },
                            complete: function(n) {
                                e.getFileSystemManager().unlinkSync(t);
                            }
                        });
                    }
                }, {
                    key: "uploadFileBinary",
                    value: function() {
                        var t = o(l.default.mark(function t(n, r) {
                            var i, o, a = this;
                            return l.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    i = e.getFileSystemManager(), o = "".concat(this.filePath, "/up_temp/").concat(r, ".temp"), 
                                    i.writeFile({
                                        filePath: o,
                                        encoding: "binary",
                                        data: n,
                                        success: function(e) {
                                            return a.uploadFile(o, r);
                                        },
                                        fail: function(e) {
                                            console.error(e), a.fail("文件切片读取失败");
                                        }
                                    });

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments);
                        };
                    }()
                }, {
                    key: "fileSlice",
                    value: function(t, n, r) {
                        var i = this;
                        e.getFileSystemManager().readFile({
                            filePath: this.config.filePath,
                            encoding: "binary",
                            position: t,
                            length: n,
                            success: function(e) {
                                return r(e.data);
                            },
                            fail: function(e) {
                                return i.fail("文件读取失败");
                            }
                        });
                    }
                }, {
                    key: "fail",
                    value: function(e) {
                        "function" == typeof this.config.fail && this.config.fail(e);
                    }
                } ]), t;
            }();
            t.default = d;
        }).call(this, n("543d").default);
    },
    "36e8": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            index: {
                index_img: "api/index/new",
                config: "api/index/config",
                newIndex: "api/index/new-index",
                tplIndex: "api/index/tpl-index",
                index: "api/index/index",
                buy_data: "api/index/purchase",
                extra: "api/index/index-extra",
                status: "api/index/shop-status",
                indexWechat: "api/index/index-wechat",
                diy: "api/index/diy-framework",
                diy_split: "api/index/diy-split",
                diy_module: "api/index/diy-module"
            },
            finance: {
                cash: "api/finance/cash",
                config: "api/finance/config",
                list: "api/finance/list"
            },
            payment: {
                get_payments: "api/payment/get-payments",
                pay_data: "api/payment/pay-data",
                pay_buy_balance: "api/payment/pay-buy-balance",
                pay_buy_huodao: "api/payment/pay-buy-huodao"
            },
            upload: {
                file: "api/attachment/upload"
            },
            default: {
                district: "api/default/district",
                goods_list: "api/default/goods-list",
                search_list: "api/default/search-list",
                cart_list: "api/default/cats-list&cat_id=",
                qrcode_parameter: "api/default/qr-code-parameter",
                cat_list: "api/cat/list",
                cat_goods: "api/cat/goods",
                cat_full_reduce: "api/cat/full-reduce-list"
            },
            passport: {
                login: "api/passport/login"
            },
            user: {
                bill: "api/user/bill",
                member_log: "api/user/member-log",
                user_info: "api/user/user-info",
                address: "api/user/address",
                wechat_district: "api/user/wechat-district",
                address_save: "api/user/address-save",
                address_detail: "api/user/address-detail",
                address_default: "api/user/address-default",
                address_destroy: "api/user/address-destroy",
                auto_address_info: "api/default/auto-address-info",
                my_favorite_goods: "api/user/my-favorite-goods",
                my_favorite_topic: "api/user/my-favorite-topic",
                favorite_add: "api/user/favorite-add",
                favorite_remove: "api/user/favorite-remove",
                favorite_batch_remove: "/api/user/favorite-batch-remove",
                config: "api/user/config",
                is_clerk: "api/user/is-clerk-user",
                edit_user: "api/user/edit-user",
                captcha: "site/pic-captcha",
                sms: "api/user/send-sms-captcha",
                empower: "api/user/phone-empower",
                destroy: "api/user/phone-destroy",
                logout: "api/user/logout"
            },
            article: {
                list: "api/default/article-list",
                detail: "api/default/article"
            },
            coupon: {
                list: "api/coupon/list",
                detail: "api/coupon/detail",
                receive: "api/coupon/receive",
                user_coupon: "api/coupon/user-coupon",
                user_coupon_detail: "api/coupon/user-coupon-detail",
                share_coupon: "api/coupon/share-coupon",
                give: "api/coupon/give",
                receive_send: "/api/coupon/receive-send"
            },
            city: {
                cityName: "api/default/district",
                goodsList: "api/default/goods-list"
            },
            balance: {
                index: "api/balance/index",
                logs: "api/balance/logs",
                log_detail: "api/balance/log-detail"
            },
            order: {
                goods_form: "api/order/goods-form",
                form_order_submit: "api/order/form-order-submit",
                form_order_preview: "api/order/form-order-preview",
                preview: "api/order/preview",
                submit: "api/order/submit",
                pay_data: "api/order/pay-data",
                usable_coupon_list: "api/order/usable-coupon-list",
                store_list: "api/order/store-list",
                list: "api/order/list",
                detail: "api/order/detail",
                appraise: "api/order/appraise",
                express_detail: "api/order/express-detail",
                clerk_affirm_pay: "api/order/clerk-affirm-pay",
                order_clerk: "api/order/order-clerk",
                clerk_qr_code: "api/order/clerk-qr-code",
                apply_refund: "api/order/apply-refund",
                refund_submit: "api/order/refund-submit",
                refund_detail: "api/order/refund-detail",
                refund_send: "api/order/refund-send",
                confirm: "api/order/confirm",
                cancel: "api/order/cancel",
                list_pay_data: "api/order/list-pay-data",
                pay_result: "api/order/pay-result",
                customer: "api/express/get-customer",
                delivery: "api/express/delivery-config",
                order_express_list: "api/express/order-express-list",
                cancel_cause_list: "api/order/cancel-cause-list",
                cancel_refund: "api/order/cancel-refund",
                cancel_apply: "api/order/cancel-apply",
                city_map: "api/order/city-map",
                customization: "api/order/customization",
                batch_refund_list: "api/order/batch-refund-list",
                across_store: "api/order/across-store",
                order_detail_refund_list: "api/order/order-detail-refund-list"
            },
            video: {
                index: "api/video/index"
            },
            topic: {
                type: "api/topic/type",
                list: "api/topic/list",
                detail: "api/topic/detail",
                favorite: "api/topic/favorite",
                qrcode: "api/qrcode/topic",
                poster: "api/topic/poster"
            },
            member: {
                index: "api/mall-member/index",
                all: "api/mall-member/all-member",
                coupon: "api/mall-member/member-coupon",
                goods: "api/mall-member/member-goods",
                cats: "api/mall-member/goods-cats",
                purchase: "api/mall-member/purchase-member",
                receive: "api/mall-member/coupon-receive",
                detail: "api/mall-member/detail",
                set_password: "api/mall-member/set-pay-password",
                update_password: "api/mall-member/update-pay-password",
                verify_password: "api/mall-member/verify-pay-password"
            },
            recharge: {
                index: "api/recharge/index",
                setting: "api/recharge/setting",
                balance_recharge: "api/recharge/balance-recharge"
            },
            store: {
                list: "api/store/list",
                detail: "api/store/detail"
            },
            goods: {
                detail: "api/goods/detail",
                attr: "api/goods/attr",
                comments_list: "api/goods/comments-list",
                recommend: "api/goods/recommend",
                new_recommend: "api/goods/new-recommend",
                cat_style: "api/goods/cat-style",
                goods_video_list: "/api/goods/goods-list",
                poster: "/api/goods/poster",
                hot_search: "/api/goods/hot-search",
                addMaterial: "/api/video-number/add-material",
                articleUrl: "/api/video-number/get-article-url",
                remind: "api/goods/remind",
                form_data: "api/goods/form-data",
                recommend_goods: "/api/goods/recommend-goods",
                params_tpl: "/api/goods/params-tpl",
                attr_tpl: "/api/goods/attr-tpl",
                tag_tpl: "/api/goods/tag-tpl",
                member_tpl: "/api/goods/member-tpl",
                form_tpl: "/api/goods/form-tpl",
                setting: "/api/goods/setting-one",
                buy_scroll: "/api/goods/buy-scroll"
            },
            card: {
                index: "api/card/user-card",
                detail: "api/card/user-card-detail",
                qrcode: "api/card/card-qrcode",
                clerk: "api/card/card-clerk",
                history: "api/card/clerk-history",
                give: "api/card/give",
                receive: "api/card/receive",
                store: "api/card/card-store-list"
            },
            share: {
                apply: "api/share/apply",
                index: "api/share/index",
                setting: "api/share/setting",
                customize: "api/share/customize",
                brokerage: "api/share/brokerage",
                team: "api/share/team",
                cash: "api/share/cash",
                cash_list: "api/share/cash-list",
                apply_status: "api/share/apply-status",
                share_order: "api/share/share-order",
                bind_parent: "api/share/bind-parent",
                poster: "api/qrcode/share",
                new_apply_status: "api/share/new-apply-status",
                level: "api/share/level",
                level_up: "api/share/level-up",
                rank: "api/share/rank"
            },
            pond: {
                index: "plugin/pond/api/pond/index",
                lottery: "plugin/pond/api/pond/lottery",
                prize: "plugin/pond/api/pond/prize",
                send: "plugin/pond/api/pond/send",
                setting: "plugin/pond/api/pond/setting",
                order_preview: "plugin/pond/api/pond/order-preview",
                order_submit: "plugin/pond/api/pond/order-submit",
                poster: "plugin/pond/api/pond/poster"
            },
            scratch: {
                index: "plugin/scratch/api/scratch/index",
                receive: "plugin/scratch/api/scratch/receive",
                setting: "plugin/scratch/api/scratch/setting",
                prize: "plugin/scratch/api/scratch/prize",
                record: "plugin/scratch/api/scratch/record",
                order_preview: "plugin/scratch/api/scratch/order-preview",
                order_submit: "plugin/scratch/api/scratch/order-submit",
                poster: "plugin/scratch/api/scratch/poster"
            },
            bonus: {
                order: "plugin/bonus/api/order/index",
                index: "plugin/bonus/api/index/index",
                apply: "plugin/bonus/api/index/apply",
                status: "plugin/bonus/api/index/apply-status",
                team: "plugin/bonus/api/order/team-bonus",
                setting: "plugin/bonus/api/index/setting",
                clear: "plugin/bonus/api/index/clear-apply",
                cash: "plugin/bonus/api/index/cash",
                detail: "plugin/bonus/api/cash/index",
                member: "plugin/bonus/api/index/all-member",
                data: "plugin/bonus/api/order/data"
            },
            lottery: {
                index: "plugin/lottery/api/lottery/index",
                setting: "plugin/lottery/api/lottery/setting",
                detail: "plugin/lottery/api/lottery/detail",
                prize: "plugin/lottery/api/lottery/prize",
                clerk: "plugin/lottery/api/lottery/clerk",
                code: "plugin/lottery/api/lottery/code",
                order_preview: "plugin/lottery/api/lottery/order-preview",
                order_submit: "plugin/lottery/api/lottery/order-submit",
                goods: "plugin/lottery/api/lottery/goods",
                poster: "plugin/lottery/api/lottery/poster",
                poster_config: "plugin/lottery/api/poster/config",
                poster_generate: "plugin/lottery/api/poster/generate"
            },
            check_in: {
                index: "plugin/check_in/api/index/index",
                user: "plugin/check_in/api/index/user",
                customize: "plugin/check_in/api/index/customize",
                sign_in: "plugin/check_in/api/index/sign-in",
                sign_in_result: "plugin/check_in/api/index/sign-in-result",
                sign_in_day: "plugin/check_in/api/index/sign-in-day"
            },
            quick: {
                index: "api/quick/index",
                goods_list: "api/quick/goods-list",
                cart: "api/quick/cart"
            },
            step: {
                index: "plugin/step/api/step/index",
                setting: "plugin/step/api/step/setting",
                ranking: "plugin/step/api/step/ranking",
                goods: "plugin/step/api/step/goods",
                activity_detail: "plugin/step/api/step/activity-detail",
                activity: "plugin/step/api/step/activity",
                activity_log: "plugin/step/api/step/activity-log",
                activity_join: "plugin/step/api/step/activity-join",
                activity_submit: "plugin/step/api/step/activity-submit",
                invite_list: "plugin/step/api/step/invite-list",
                convert: "plugin/step/api/step/convert",
                log: "plugin/step/api/step/log",
                step_convert: "plugin/step/api/step/step-convert",
                remind: "plugin/step/api/step/remind",
                order_preview: "plugin/step/api/step/order-preview",
                order_submit: "plugin/step/api/step/order-submit",
                goods_detail: "plugin/step/api/step/goods-detail",
                poster: "plugin/step/api/step/poster",
                goods_poster: "plugin/step/api/step/goods-poster",
                receive: "plugin/step/api/step/receive",
                poster_config: "plugin/step/api/poster/config",
                poster_generate: "plugin/step/api/poster/generate"
            },
            cart: {
                edit: "api/cart/edit",
                delete: "api/cart/delete",
                list: "api/cart/list",
                add: "api/cart/add",
                nums: "api/cart/nums",
                diy_info: "api/cart/diy-info"
            },
            fxhb: {
                index: "plugin/fxhb/api/index/index",
                join: "plugin/fxhb/api/index/join",
                join_result: "plugin/fxhb/api/index/join-result",
                detail: "plugin/fxhb/api/index/detail",
                recommend: "plugin/fxhb/api/index/recommend"
            },
            scan_code_pay: {
                index: "plugin/scan_code_pay/api/index/index",
                preview: "plugin/scan_code_pay/api/order/preview",
                submit: "plugin/scan_code_pay/api/order/submit",
                qr_code: "plugin/scan_code_pay/api/index/qr-code",
                coupons: "plugin/scan_code_pay/api/order/coupons",
                cancel: "plugin/scan_code_pay/api/order/cancel"
            },
            phone: {
                send_captcha: "plugin/diy/api/phone/send-captcha",
                binding: "api/phone/binding",
                code: "api/user/phone-code"
            },
            book: {
                cats: "plugin/booking/api/booking/cats",
                clerk_code: "plugin/booking/api/order-list/clerk-code",
                order_submit: "plugin/booking/api/order/order-submit",
                order_preview: "plugin/booking/api/order/order-preview",
                detail: "plugin/booking/api/goods/detail",
                list: "plugin/booking/api/goods/list",
                setting: "plugin/booking/api/booking/setting",
                order_list: "plugin/booking/api/order-list/index",
                order_detail: "plugin/booking/api/order-list/detail",
                store_list: "plugin/booking/api/booking/store-list",
                poster: "plugin/booking/api/booking/poster",
                poster_config: "plugin/booking/api/poster/config",
                poster_generate: "plugin/booking/api/poster/generate"
            },
            poster: {
                share: "api/qrcode/share",
                goods: "api/qrcode/goods",
                topic: "api/qrcode/topic",
                footprint: "api/qrcode/footprint",
                goods_new: "api/qrcode/goods-new",
                card: "api/card/give-poster",
                coupon: "api/coupon/give-poster",
                card_share: "api/qrcode/card-share",
                coupon_share: "api/qrcode/coupon-share",
                mall: "api/index/mall-poster",
                diy: "plugin/diy/api/page/poster"
            },
            bargain: {
                banner: "plugin/bargain/api/index/banner",
                goods_list: "plugin/bargain/api/goods/list",
                goods_detail: "plugin/bargain/api/goods/detail",
                list: "plugin/bargain/api/order/bargain-list",
                bargain_submit: "plugin/bargain/api/order/bargain-submit",
                bargain_result: "plugin/bargain/api/order/bargain-result",
                order_preview: "plugin/bargain/api/order/order-preview",
                order_submit: "plugin/bargain/api/order/order-submit",
                user_join_bargain: "plugin/bargain/api/order/user-join-bargain",
                user_join_bargain_result: "plugin/bargain/api/order/user-join-bargain-result",
                activity: "plugin/bargain/api/order/activity",
                setting: "plugin/bargain/api/index/index",
                poster: "plugin/bargain/api/index/poster",
                poster_config: "plugin/bargain/api/poster/config",
                poster_generate: "plugin/bargain/api/poster/generate"
            },
            integral_mall: {
                index: "plugin/integral_mall/api/index/index",
                coupon: "plugin/integral_mall/api/coupon/index",
                cats: "plugin/integral_mall/api/goods/cats",
                detail: "plugin/integral_mall/api/coupon/detail",
                goods_detail: "plugin/integral_mall/api/goods/detail",
                coupon_submit: "plugin/integral_mall/api/coupon-order/order-submit",
                goods: "plugin/integral_mall/api/goods/index",
                log: "api/integral-log/index",
                order: "plugin/integral_mall/api/order/index",
                coupon_order: "plugin/integral_mall/api/coupon-order/index",
                order_preview: "plugin/integral_mall/api/order/order-preview",
                order_submit: "plugin/integral_mall/api/order/order-submit",
                coupon_pay: "plugin/integral_mall/api/coupon-order/order-pay-data",
                poster: "plugin/integral_mall/api/index/poster",
                poster_config: "plugin/integral_mall/api/poster/config",
                poster_generate: "plugin/integral_mall/api/poster/generate"
            },
            pt: {
                index: "plugin/pintuan/api/v2/index/index",
                goods: "plugin/pintuan/api/v2/goods/index",
                detail: "plugin/pintuan/api/v2/goods/detail",
                cats: "plugin/pintuan/api/v2/goods/cats",
                order_preview: "plugin/pintuan/api/v2/order/order-preview",
                order_submit: "plugin/pintuan/api/v2/order/submit",
                list: "plugin/pintuan/api/v2/order/pintuan-list",
                pt_detail: "plugin/pintuan/api/v2/order/pintuan-detail",
                order: "plugin/pintuan/api/v2/order/list",
                poster: "plugin/pintuan/api/v2/index/poster",
                order_poster: "plugin/pintuan/api/v2/order/poster",
                poster_config: "plugin/pintuan/api/v2/poster/config",
                poster_generate: "plugin/pintuan/api/v2/poster/generate"
            },
            mch: {
                card: "plugin/mch/api/mch/card-list",
                p_order_print: "plugin/mch/api/order/order-print",
                print_list: "plugin/mch/api/order/print-list",
                index: "plugin/mch/api/mch/index",
                detail: "plugin/mch/api/mch/detail",
                category: "plugin/mch/api/mch/category",
                goods: "plugin/mch/api/goods/index",
                goods_detail: "plugin/mch/api/goods/detail",
                cat_style: "plugin/mch/api/goods/cat-style",
                cats_list: "api/cat/list",
                setting: "plugin/mch/api/mch/setting",
                visit: "plugin/mch/api/mch/add-visit",
                order_list: "plugin/mch/api/order/index",
                order_detail: "plugin/mch/api/order/detail",
                manage_index: "plugin/mch/api/mch/manage-index",
                qr_code: "plugin/mch/api/mch/qr-code",
                qr_code_parameter: "api/default/qr-code-parameter",
                statistic: "plugin/mch/api/mch/statistic",
                year_list: "plugin/mch/api/mch/year-list",
                property: "plugin/mch/api/property/index",
                account_log: "plugin/mch/api/property/account-log",
                cash_log: "plugin/mch/api/property/cash-log",
                order_close_log: "plugin/mch/api/property/order-close-log",
                cash_submit: "plugin/mch/api/property/cash-submit",
                order_send: "plugin/mch/api/order/order-send",
                express_list: "api/order/express-list",
                refund_detail: "plugin/mch/api/order/refund-detail",
                mch_status: "plugin/mch/api/mch/mch-status",
                apply: "plugin/mch/api/mch/apply",
                login: "plugin/mch/api/mch/login",
                order_print: "plugin/mch/api/order/print",
                update_total_price: "plugin/mch/api/order/update-total-price",
                update_price: "plugin/mch/api/order/update-price",
                refund_handle: "plugin/mch/api/order/refund-handle",
                update_password: "plugin/mch/api/mch/update-password",
                switch_status: "plugin/mch/api/goods/switch-status",
                destroy: "plugin/mch/api/goods/destroy",
                cancel: "plugin/mch/api/order/cancel",
                order_preview: "plugin/mch/api/order/preview",
                order_submit: "plugin/mch/api/order/submit",
                apply_status: "plugin/mch/api/goods/apply-status",
                qr_code_login: "plugin/mch/api/mch/qr-code-login",
                poster: "plugin/mch/api/mch/poster",
                edit: "plugin/mch/api/goods/edit",
                cat: "plugin/mch/api/goods/cats",
                postage: "plugin/mch/api/goods/rules",
                service: "plugin/mch/api/goods/services",
                mch_cat: "plugin/mch/api/goods/mch-cats",
                mch_cat_edit: "plugin/mch/api/goods/cat-edit",
                mch_cat_destroy: "plugin/mch/api/goods/cat-destroy",
                poster_config: "plugin/mch/api/poster/config",
                poster_generate: "plugin/mch/api/poster/generate",
                update_address: "plugin/mch/api/order/update-address",
                goods_edit: "plugin/mch/api/goods/edit",
                delivery_rules: "plugin/mch/api/goods/free-delivery-rules",
                force_cancel: "plugin/mch/api/order/force-cancel",
                shou_huo: "plugin/mch/api/order/shou-huo",
                diy_index: "plugin/mch/api/diy/index",
                diy_tags: "plugin/mch/api/diy/tags",
                weitao_list: "plugin/mch/api/diy/weitao-list",
                weitao_detail: "plugin/mch/api/diy/weitao-detail",
                diy_nav: "plugin/mch/api/diy/nav",
                favorite: "plugin/mch/api/diy/favorite",
                cancel_favorite: "plugin/mch/api/diy/cancel-favorite",
                store_reflection: "plugin/mch/api/diy/store-reflection",
                my_favorite_mch: "api/user/my-favorite-mch",
                mch_poster: "plugin/mch/api/diy/mch-poster",
                weitao_poster: "plugin/mch/api/diy/weitao-poster",
                self_poster: "plugin/mch/api/mch/self-poster",
                self_save_poster: "plugin/mch/api/mch/self-save-poster",
                coerce_refund_submit: "plugin/mch/api/order/coerce-refund-submit",
                coerce_refund_list: "plugin/mch/api/order/coerce-refund-list",
                order_confirm: "plugin/mch/api/order/confirm",
                seller_remark: "plugin/mch/api/order/seller-remark",
                clerk_user: "plugin/mch/api/order/clerk-user",
                order_clerk: "plugin/mch/api/order/order-clerk",
                customers_order_user: "plugin/customers_order/mch/index/user",
                customers_order_address: "plugin/customers_order/mch/index/address",
                customers_order_address_add: "plugin/customers_order/mch/index/address-add",
                customers_order_address_del: "plugin/customers_order/mch/index/address-del",
                customers_order_preview: "plugin/customers_order/mch/order/preview",
                customers_order_submit: "plugin/customers_order/mch/order/submit",
                customers_order_pay_data: "plugin/customers_order/mch/order/pay-data",
                customers_order_get_payment: "plugin/customers_order/mch/order/get-payment",
                customers_order_pay: "plugin/customers_order/mch/order/pay",
                customers_order_coupon: "plugin/customers_order/mch/order/usable-coupon-list",
                customers_order_goods: "plugin/customers_order/mch/index/goods",
                delivery: "plugin/mch/api/order/delivery",
                send: "plugin/mch/api/order/send"
            },
            app_admin: {
                order_print: "api/admin/order/order-print",
                state: "/api/admin/data-statistics/state",
                quick_dispose: "/api/admin/data-statistics/quick-dispose",
                print_list: "api/admin/order/print-list",
                role: "plugin/app_admin/api/index/role",
                index: "api/admin/data-statistics/all_data",
                send: "api/admin/order/send",
                goods: "api/admin/goods/index",
                table: "api/admin/data-statistics/table",
                express: "api/order/express-list",
                goods_switch: "api/admin/goods/switch-status",
                goods_destroy: "api/admin/goods/destroy",
                comments: "api/admin/order-comments/index",
                comments_top: "api/admin/order-comments/update-top",
                comments_reply: "api/admin/order-comments/reply",
                comments_show: "api/admin/order-comments/show",
                user: "api/admin/user/index",
                share: "api/admin/share/index",
                clerk: "api/admin/user/clerk",
                integral: "api/admin/user/integral",
                balance: "api/admin/user/balance",
                setting: "api/admin/mall/setting",
                review: "api/admin/review/index",
                tabs: "api/admin/review/tabs",
                review_detail: "api/admin/review/detail",
                review_switch: "api/admin/review/switch-status",
                order: "api/admin/order/index",
                order_clerk: "api/admin/order/order-clerk",
                update_price: "api/admin/order/update-total-price",
                update_address: "api/admin/order/update-address",
                address_list: "api/admin/order/address-list",
                express_detail: "api/order/express-detail",
                cancel: "api/admin/order/cancel",
                force_cancel: "api/admin/order/force-cancel",
                detail: "api/admin/order/detail",
                refund: "api/admin/order/refund",
                refund_handle: "api/admin/order/refund-handle",
                edit: "api/admin/goods/edit",
                service: "api/admin/service/options",
                card: "api/admin/card/options",
                coupon: "api/admin/coupon/options",
                cat: "api/admin/cat/options",
                order_num: "api/admin/order/order-num",
                print: "api/admin/order/print",
                refund_address: "api/admin/refund-address/index",
                refund_address_edit: "api/admin/refund-address/edit",
                clerk_destroy: "api/admin/user/clerk-destroy",
                address_destroy: "api/admin/refund-address/destroy",
                clerk_edit: "api/admin/user/clerk-edit",
                cash: "api/admin/cash/list",
                verify: "api/admin/cash/verify",
                user_cash: "api/admin/cash/cash",
                postage: "api/admin/postage-rule/all-list",
                delivery_rules: "api/admin/free-delivery-rules/all-list",
                shou_huo: "api/admin/order/shou-huo",
                delivery: "api/admin/order/delivery",
                remark: "api/admin/user/update-user-remark",
                remarkName: "api/admin/user/update-user-remark-name",
                level: "api/admin/user/update-user-level",
                goods_edit: "api/admin/goods/edit",
                sellerRemark: "api/admin/order/seller-remark",
                confirm: "api/admin/order/confirm",
                queue: "api/admin/review/queue-status",
                cash_save: "api/admin/cash/save",
                goods_config: "/api/admin/goods/goods-config",
                ecard_api_url: "",
                refund_detail: "api/admin/order/refund-detail",
                tabs_v2: "api/admin/v2/review/tabs",
                review_v2: "api/admin/v2/review/index",
                review_switch_v2: "api/admin/v2/review/switch-status",
                cash_tabs: "api/admin/cash/tabs",
                review_detail_v2: "api/admin/v2/review/detail",
                cat_edit: "api/admin/cat/edit",
                cat_destroy: "api/admin/cat/destroy",
                pick_link: "api/admin/cat/pick-link",
                form_index: "api/admin/diy-form/index",
                form_detail: "api/admin/diy-form/detail",
                form_reply: "api/admin/diy-form/reply",
                clerk_user: "api/admin/user/clerk-user-v2",
                goods_list: "/api/admin/order/goods-list",
                coerce_refund: "api/admin/order/coerce-refund-submit",
                coerce_refund_list: "api/admin/order/coerce-refund-list",
                send_list: "api/admin/order/send-list"
            },
            clerk: {
                form_detail: "plugin/clerk/api/index/form-detail",
                reply: "plugin/clerk/api/index/reply",
                info: "plugin/clerk/api/index/clerk-info",
                order: "plugin/clerk/api/index/order",
                my: "plugin/clerk/api/index/my-order",
                detail: "plugin/clerk/api/index/detail",
                card: "plugin/clerk/api/index/card",
                my_card: "plugin/clerk/api/index/my-card",
                card_detail: "api/card/user-card-detail",
                statistics: "plugin/clerk/api/index/statistics",
                qrcode_parameter: "api/default/qr-code-parameter"
            },
            miaosha: {
                goods: "plugin/miaosha/api/v2/goods/index",
                estimate: "plugin/miaosha/api/v2/goods/estimate",
                goods_detail: "plugin/miaosha/api/v2/goods/detail",
                cats: "plugin/miaosha/api/v2/goods/cats",
                goods_info: "plugin/miaosha/api/v2/goods/miaosha",
                order_preview: "plugin/miaosha/api/v2/order/order-preview",
                order_submit: "plugin/miaosha/api/v2/order/submit",
                today_goods: "plugin/miaosha/api/v2/goods/today-miaosha",
                time_list: "plugin/miaosha/api/v2/goods/time-list",
                add_cart: "plugin/miaosha/api/v2/index/add-cart",
                cart_edit: "plugin/miaosha/api/v2/index/cart-edit",
                poster: "plugin/miaosha/api/v2/index/poster",
                poster_config: "plugin/miaosha/api/v2/poster/config",
                poster_generate: "plugin/miaosha/api/v2/poster/generate"
            },
            diy: {
                page_store: "plugin/diy/api/page/store",
                receive: "plugin/diy/api/ad-award/receive",
                coupon_receive: "plugin/diy/api/coupon/receive",
                new_form: "plugin/diy/api/page/new-form",
                form_list: "plugin/diy/api/page/form-list",
                form_detail: "plugin/diy/api/page/form-detail",
                submit_result: "plugin/diy/api/page/submit-result",
                cancel: "plugin/diy/api/page/form-cancel",
                order_submit: "/plugin/diy/api/page/order-submit",
                order_preview: "/plugin/diy/api/page/order-preview",
                usable_coupon_list: "plugin/diy/api/page/usable-coupon-list",
                cat_goods_list: "api/index/diy-goods",
                order_pay: "plugin/diy/api/page/pay-data",
                video_live: "plugin/diy/api/page/video-live"
            },
            vip_card: {
                index: "plugin/vip_card/api/index/index",
                card: "plugin/vip_card/api/index/card",
                order_preview: "plugin/vip_card/api/order/preview",
                card_detail: "plugin/vip_card/api/index/card-detail",
                setting: "plugin/vip_card/api/index/setting",
                right: "plugin/vip_card/api/index/right",
                index_right: "plugin/vip_card/api/index/index-right",
                order_submit: "plugin/vip_card/api/order/submit",
                pay_data: "plugin/vip_card/api/order/pay-data",
                recommend: "plugin/vip_card/api/index/recommend",
                poster: "plugin/vip_card/api/index/poster",
                new_detail: "plugin/vip_card/api/index/new-detail"
            },
            advance: {
                goods: "plugin/advance/api/goods/index",
                banner: "plugin/advance/api/goods/banner",
                detail: "plugin/advance/api/goods/detail",
                poster: "plugin/advance/api/goods/poster",
                order_submit: "plugin/advance/api/order/advance",
                order: "plugin/advance/api/order/my-advance",
                order_preview: "plugin/advance/api/order/order-preview",
                order_sub: "plugin/advance/api/order/order-submit",
                order_detail: "plugin/advance/api/order/detail",
                pay_data: "plugin/advance/api/order/pay-data",
                get_payments: "plugin/advance/api/payment/get-payments",
                goods_list: "plugin/advance/api/goods/index",
                poster_config: "plugin/advance/api/poster/config",
                poster_generate: "plugin/advance/api/poster/generate"
            },
            gift: {
                order_submit: "/plugin/gift/api/gift-order/order-submit",
                order_preview: "/plugin/gift/api/gift-order/order-preview",
                config: "plugin/gift/api/gift-index/config",
                pay_data: "plugin/gift/api/gift-order/pay-data",
                gift: "plugin/gift/api/gift-index/gift",
                poster: "plugin/gift/api/gift-index/poster",
                send_list: "plugin/gift/api/order-list/send-list",
                send_detail: "plugin/gift/api/order-list/send-detail",
                turn: "plugin/gift/api/gift-order/turn",
                get_turn: "plugin/gift/api/gift-order/get-turn",
                my_join: "plugin/gift/api/gift-join/my-join",
                my_win: "plugin/gift/api/gift-join/my-win",
                win_detail: "plugin/gift/api/gift-join/win-detail",
                join: "plugin/gift/api/gift-join/join",
                join_status: "plugin/gift/api/gift-join/join-status",
                join_detail: "plugin/gift/api/gift-join/join-detail",
                preview: "plugin/gift/api/gift-order/gift-convert-preview",
                convert: "plugin/gift/api/gift-order/gift-convert",
                list: "plugin/gift/api/goods/goods-list",
                goods: "plugin/gift/api/goods/detail",
                cancel: "plugin/gift/api/gift-order/order-cancel"
            },
            foot: {
                index: "api/footprint/footprint",
                list: "api/footprint/index",
                del: "api/footprint/footprint-del"
            },
            quick_share: {
                poster_list: "plugin/quick_share/api/goods/poster-list",
                goods: "plugin/quick_share/api/goods/index",
                poster: "plugin/quick_share/api/goods/poster",
                setting: "plugin/quick_share/api/setting/index",
                poster_config: "plugin/quick_share/api/poster/config",
                poster_generate: "plugin/quick_share/api/poster/generate",
                cat: "plugin/quick_share/api/cat/all"
            },
            stock: {
                status: "plugin/stock/api/index/apply-status",
                index: "plugin/stock/api/index/index",
                setting: "plugin/stock/api/index/setting",
                apply: "plugin/stock/api/index/apply",
                clear: "plugin/stock/api/index/clear-apply",
                cash: "plugin/stock/api/index/cash",
                detail: "plugin/stock/api/cash/index",
                level: "plugin/stock/api/index/level",
                info: "plugin/stock/api/index/info",
                up: "plugin/stock/api/index/level-up",
                bonus: "plugin/stock/api/cash/bonus-detail"
            },
            region: {
                status: "plugin/region/api/index/apply-status",
                index: "plugin/region/api/index/index",
                setting: "plugin/region/api/index/setting",
                apply: "plugin/region/api/index/apply",
                clear: "plugin/region/api/index/clear-apply",
                cash: "plugin/region/api/index/cash",
                detail: "plugin/region/api/cash/index",
                level: "plugin/region/api/index/level",
                info: "plugin/region/api/index/info",
                level_up: "plugin/region/api/index/level-up",
                clear_up: "plugin/region/api/index/clear-level-up"
            },
            template: {
                template: "api/message/template"
            },
            pick: {
                goods_list: "plugin/pick/api/index/goods-list",
                goods: "/plugin/pick/api/index/goods-detail",
                order_preview: "/plugin/pick/api/pick-order/order-preview",
                order_submit: "/plugin/pick/api/pick-order/order-submit",
                poster: "plugin/pick/api/index/poster",
                add: "plugin/pick/api/cart/add",
                list: "plugin/pick/api/cart/list",
                edit: "plugin/pick/api/cart/edit",
                delete: "plugin/pick/api/cart/delete",
                poster_config: "plugin/pick/api/poster/config",
                poster_generate: "plugin/pick/api/poster/generate"
            },
            live: {
                index: "api/live/index",
                playback: "api/live/play-back"
            },
            ecard: {
                index: "plugin/ecard/api/index/index"
            },
            composition: {
                index: "plugin/composition/api/index/index",
                config: "plugin/composition/api/index/config",
                detail: "plugin/composition/api/index/detail",
                composition_detail: "plugin/composition/api/index/composition-detail",
                order_preview: "plugin/composition/api/index/order-preview",
                order_submit: "plugin/composition/api/index/order-submit"
            },
            favorite: {
                cats: "api/user/favorite-cats",
                my_favorite_goods: "api/user/my-new-favorite-goods"
            },
            flash_sale: {
                list: "/plugin/flash_sale/api/index/goods-list",
                detail: "/plugin/flash_sale/api/index/goods-detail",
                add_cart: "/plugin/flash_sale/api/index/add-cart",
                poster_config: "plugin/flash_sale/api/poster/config",
                poster_generate: "plugin/flash_sale/api/poster/generate"
            },
            full_reduce: {
                list: "api/goods/full-reduce-goods-list",
                index: "api/full-reduce/index"
            },
            community: {
                setting: "plugin/community/api/index/setting-data",
                index: "plugin/community/api/middleman/index",
                apply: "plugin/community/api/middleman/apply",
                apply_result: "plugin/community/api/middleman/apply-result",
                apply_pay: "plugin/community/api/middleman/apply-pay",
                activity_list: "plugin/community/api/activity/list",
                activity_detail: "plugin/community/api/activity/detail",
                activity_log: "plugin/community/api/activity/log",
                user_activity: "plugin/community/api/activity/activity",
                activity_goods: "plugin/community/api/activity/goods-list",
                middle_list: "plugin/community/api/order/middle-list",
                middle_detail: "plugin/community/api/order/middle-detail",
                order_list: "plugin/community/api/order/list",
                order_detail: "plugin/community/api/order/detail",
                poster: "plugin/community/api/activity/poster-config",
                middleman_list: "plugin/community/api/middleman/list",
                cats: "plugin/community/api/activity/goods-cats",
                cart_add: "plugin/community/api/cart/add",
                cart_result: "plugin/community/api/cart/add-result",
                cart: "plugin/community/api/cart/index",
                cart_delete: "plugin/community/api/cart/delete",
                cart_edit: "plugin/community/api/cart/edit",
                goods_config: "plugin/community/api/goods/config",
                profit_list: "plugin/community/api/middleman/profit-list",
                profit_detail: "plugin/community/api/middleman/profit-detail",
                order_preview: "plugin/community/api/order/order-preview",
                order_submit: "plugin/community/api/order/order-submit",
                notice: "plugin/community/api/middleman/notice",
                list: "plugin/community/api/activity/activity-list",
                bind: "plugin/community/api/middleman/bind",
                goods_detail: "plugin/community/api/goods/detail",
                switch: "plugin/community/api/goods/switch",
                edit_address: "plugin/community/api/middleman/edit-address",
                confirm: "plugin/community/api/order/confirm",
                goods_generate: "plugin/community/api/goods/generate",
                poster_share: "plugin/community/api/poster-share/generate"
            },
            exchange: {
                list: "plugin/exchange/api/index/card-goods-list",
                code: "plugin/exchange/api/index/get-code",
                detail: "plugin/exchange/api/index/card-goods-detail",
                me_list: "plugin/exchange/api/index/me-card-list",
                me_detail: "plugin/exchange/api/index/me-card-detail",
                order_preview: "plugin/exchange/api/index/e-order-preview",
                order_submit: "plugin/exchange/api/index/e-order-submit",
                exchange_preview: "plugin/exchange/api/index/c-order-preview",
                exchange_submit: "plugin/exchange/api/index/c-order-submit",
                setting: "plugin/exchange/api/index/setting",
                log: "plugin/exchange/api/index/me-log",
                info: "plugin/exchange/api/index/show-info",
                unite: "plugin/exchange/api/index/unite",
                covert: "plugin/exchange/api/index/covert",
                log_detail: "plugin/exchange/api/index/me-log-detail",
                qrcode: "plugin/exchange/api/index/qrcode",
                poster_generate: "plugin/exchange/api/poster/generate",
                poster_config: "plugin/exchange/api/poster/config"
            },
            wholesale: {
                index: "plugin/wholesale/api/goods/index",
                detail: "plugin/wholesale/api/goods/detail",
                cart: "plugin/wholesale/api/cart/add-cart",
                cats: "plugin/wholesale/api/goods/cats",
                order_preview: "plugin/wholesale/api/order/order-preview",
                order_submit: "plugin/wholesale/api/order/order-submit",
                poster_config: "plugin/wholesale/api/poster/config",
                poster_generate: "plugin/wholesale/api/poster/generate"
            },
            weekly_buy: {
                index: "plugin/weekly_buy/api/activity/list",
                config: "plugin/weekly_buy/api/activity/config",
                detail: "plugin/weekly_buy/api/activity/detail",
                order_submit: "plugin/weekly_buy/api/order/submit",
                order_preview: "plugin/weekly_buy/api/order/preview",
                delay: "plugin/weekly_buy/api/order/delay",
                express_detail: "plugin/weekly_buy/api/order/express-detail",
                confirm: "plugin/weekly_buy/api/order/confirm",
                stop: "plugin/weekly_buy/api/admin/stop",
                admin_delay: "plugin/weekly_buy/api/admin/delay",
                admin_express: "plugin/weekly_buy/api/admin/express-detail",
                clerk: "plugin/weekly_buy/api/admin/clerk",
                admin_confirm: "plugin/weekly_buy/api/admin/confirm",
                poster_config: "plugin/weekly_buy/api/poster/config",
                poster_generate: "plugin/weekly_buy/api/poster/generate"
            },
            teller: {
                code: "plugin/teller/api/member/pay-code",
                search: "plugin/teller/api/member/search-pay-code"
            },
            fission: {
                index: "plugin/fission/api/index/index",
                setting: "plugin/fission/api/index/setting-data",
                activity: "plugin/fission/api/fission/activity",
                unite: "plugin/fission/api/fission/unite",
                poster: "plugin/fission/api/fission/poster",
                log: "plugin/fission/api/index/log",
                goods: "plugin/fission/api/index/goods",
                order_preview: "plugin/fission/api/order/preview",
                order_submit: "plugin/fission/api/order/submit",
                purchase: "plugin/fission/api/index/purchase",
                wechat: "plugin/fission/api/index/wechat"
            },
            customer: {
                url: "plugin/customer_service/api/index/url"
            },
            polite: {
                setting: "plugin/polite_invitation/api/index/setting",
                award: "plugin/polite_invitation/api/index/award",
                log: "plugin/polite_invitation/api/index/log",
                poster: "plugin/polite_invitation/api/index/poster"
            },
            new_discount: {
                activity: "plugin/new_discount/api/activity/index",
                goods_list: "plugin/new_discount/api/activity/goods-list",
                poster: "plugin/new_discount/api/activity/poster"
            },
            newcomers: {
                activity: "plugin/newcomers/api/activity/index",
                receive: "plugin/newcomers/api/activity/revice",
                poster: "plugin/newcomers/api/activity/poster",
                receive_qualification: "plugin/newcomers/api/activity/revice-qualification"
            },
            mystery: {
                activity_list: "plugin/mystery/api/activity/list",
                activity: "plugin/mystery/api/activity/index",
                order_preview: "plugin/mystery/api/activity/order-preview",
                order_submit: "plugin/mystery/api/activity/order-submit",
                usable_coupon_list: "plugin/mystery/api/activity/usable-coupon-list",
                help_buy: "plugin/mystery/api/activity/help-buy",
                help: "plugin/mystery/api/activity/help",
                poster: "plugin/mystery/api/activity/poster",
                update_goods: "api/admin/order/update-goods",
                goods_list: "plugin/mystery/api/activity/goods-list",
                activity_log: "plugin/mystery/api/activity/activity-log"
            },
            zhongcao: {
                file: "plugin/zhongcao/api/attachment-new/upload",
                chunk_file: "plugin/zhongcao/api/attachment-new/chunk-upload",
                category_list: "plugin/zhongcao/api/index/category-list",
                user_list: "plugin/zhongcao/api/index/user-list",
                recommend_user_list: "plugin/zhongcao/api/index/recommend-user-list",
                fans_list: "plugin/zhongcao/api/index/my-fans-list",
                focus_list: "plugin/zhongcao/api/index/my-focus-list",
                focus: "plugin/zhongcao/api/index/focus",
                cancel_focus: "plugin/zhongcao/api/index/cancel-focus",
                note_collection: "plugin/zhongcao/api/index/note-collection",
                note_cancel_collection: "/plugin/zhongcao/api/index/note-cancel-collection",
                note_like: "plugin/zhongcao/api/index/note-like",
                note_cancel_like: "/plugin/zhongcao/api/index/note-cancel-like",
                topic_list: "plugin/zhongcao/api/index/topic-list",
                goods_list: "/plugin/zhongcao/api/index/goods-list",
                publish_note: "/plugin/zhongcao/api/index/publish-note",
                setting: "/plugin/zhongcao/api/index/setting",
                topic_detail: "plugin/zhongcao/api/index/topic-detail",
                note_detail: "plugin/zhongcao/api/index/note-detail",
                note_comment: "plugin/zhongcao/api/index/note-comment",
                user_edit: "plugin/zhongcao/api/index/user-edit",
                user_center: "plugin/zhongcao/api/index/user-center",
                user_info: "plugin/zhongcao/api/index/user-info",
                my_collect_notes: "plugin/zhongcao/api/index/my-collect-notes",
                my_notes: "plugin/zhongcao/api/index/my-notes",
                my_likes: "plugin/zhongcao/api/index/my-likes",
                note_like_list: "plugin/zhongcao/api/index/note-like-list",
                note_collect_list: "plugin/zhongcao/api/index/note-collect-list",
                note_comment_list: "plugin/zhongcao/api/index/note-comment-list",
                comment_child_list: "plugin/zhongcao/api/index/comment-child-list",
                note_delete: "plugin/zhongcao/api/index/note-delete",
                note_comment_report: "plugin/zhongcao/api/index/note-comment-report",
                note_report: "plugin/zhongcao/api/index/note-report",
                note_comment_like: "plugin/zhongcao/api/index/note-comment-like",
                note_comment_cancel_like: "plugin/zhongcao/api/index/note-comment-cancel-like",
                note_list: "plugin/zhongcao/api/index/note-list",
                my_note_detail: "plugin/zhongcao/api/index/my-note-detail",
                my_awards: "plugin/zhongcao/api/index/my-awards",
                update_bg: "plugin/zhongcao/api/index/update-bg",
                topic_hot_list: "plugin/zhongcao/api/index/topic-hot-list",
                poster: "plugin/zhongcao/api/index/poster",
                note_comment_delete: "plugin/zhongcao/api/index/note-comment-delete",
                order_preview: "plugin/zhongcao/api/index/order-preview",
                order_submit: "plugin/zhongcao/api/index/order-submit",
                video_list: "plugin/zhongcao/api/index/video-list",
                note_goods_list: "plugin/zhongcao/api/index/note-goods-list"
            },
            customers_order: {
                user: "plugin/customers_order/api/index/user",
                address: "plugin/customers_order/api/index/address",
                address_add: "plugin/customers_order/api/index/address-add",
                address_del: "plugin/customers_order/api/index/address-del",
                order_preview: "plugin/customers_order/api/order/preview",
                order_submit: "plugin/customers_order/api/order/submit",
                pay_data: "plugin/customers_order/api/order/pay-data",
                get_payment: "plugin/customers_order/api/order/get-payment",
                pay: "plugin/customers_order/api/order/pay",
                coupon: "plugin/customers_order/api/order/usable-coupon-list",
                goods: "plugin/customers_order/api/index/goods"
            }
        };
        t.default = r;
    },
    "3f7f": function(e, t, n) {
        function r(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = i(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var r = 0, o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            };
                        },
                        e: function(e) {
                            throw e;
                        },
                        f: o
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var a, s = !0, c = !1;
            return {
                s: function() {
                    n = n.call(e);
                },
                n: function() {
                    var e = n.next();
                    return s = e.done, e;
                },
                e: function(e) {
                    c = !0, a = e;
                },
                f: function() {
                    try {
                        s || null == n.return || n.return();
                    } finally {
                        if (c) throw a;
                    }
                }
            };
        }
        function i(e, t) {
            if (e) {
                if ("string" == typeof e) return o(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(e, t) : void 0;
            }
        }
        function o(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = {
            install: function(e) {
                e.mixin({
                    onLoad: function(e) {
                        console.log("全局混入的钩子函数", e), wx.hideShareMenu({
                            menus: [ "shareTimeline" ]
                        });
                    },
                    data: function() {
                        return {
                            shareTimelineData: {
                                app_share_title: null,
                                app_share_pic: null,
                                query: {}
                            }
                        };
                    },
                    onShareTimeline: function() {
                        return this.$shareTimeline(this.shareTimelineData);
                    },
                    methods: {
                        priceUnit: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "￥", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "prev";
                            return (!(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3]) && 0 === Number(e) ? "免费" : "prev" === n ? t + e : e + t;
                        },
                        handlePrice: function(e, t) {
                            var n = !1;
                            (e = e.toString()) < 1e4 ? e = parseFloat(e).toString() : e <= 1e5 ? e = Number(e).toFixed(0) : e > 1e5 && (n = !0, 
                            e = parseFloat((+e / 1e4).toFixed(t || 2)).toString());
                            var r = e.indexOf("."), i = "", o = "";
                            return -1 === r ? (i = e, o = "") : (i = e.slice(0, r), o = e.slice(r)), n && (o += "w"), 
                            i = 0 == e ? "免费" : e > 0 ? i : e, o = 0 == e ? "" : o, {
                                priceInt: i,
                                priceFloat: o
                            };
                        },
                        newHandlePrice: function(e) {
                            var t, n = r(e);
                            try {
                                for (n.s(); !(t = n.n()).done; ) {
                                    var i = t.value;
                                    i.price = parseFloat(i.price).toString();
                                    var o = i.price.indexOf(".");
                                    if (-1 === o ? (i.integer = i.price, i.float = "") : (i.integer = i.price.slice(0, o), 
                                    i.float = i.price.slice(o)), i.price >= 1e4) if (i.price <= 1e5) i.integer = Number(i.price).toFixed(0), 
                                    i.float = ""; else {
                                        var a = +(i.integer.slice(0, i.integer.length - 4) + "." + i.integer.slice(i.integer.length - 4));
                                        -1 === (o = (a = parseFloat(a.toFixed(2))).indexOf(".")) ? (i.integer = a, i.float = "w") : (i.integer = a.slice(0, o), 
                                        i.float = a.slice(o) + "w");
                                    }
                                    if (i.level_price < 1e4) i.level_price = parseFloat(i.level_price); else if (i.level_price <= 1e5) i.level_price = i.level_price.toFixed(0); else {
                                        var s = i.level_price.toFixed(2);
                                        s = +((s = s.slice(0, -3)).slice(0, s.length - 4) + "." + s.slice(s.length - 4)), 
                                        i.level_price = parseFloat(s.toFixed(2)) + "w";
                                    }
                                }
                            } catch (e) {
                                n.e(e);
                            } finally {
                                n.f();
                            }
                            return e;
                        },
                        priceSymbol: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                            return (e ? "+" : "-") + t;
                        },
                        priceColor: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "#ff4544", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "#3fc24c";
                            return e ? t : n;
                        }
                    }
                });
            }
        };
        t.default = a;
    },
    "428c": function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABQCAMAAADY1yDdAAAAq1BMVEUAAADt8f/t8v/u8v/r6//u8v/u8v/t8P/r8v/u8f/t8f/v8v/t8f/t8f/w8P/t8f/t8v/u8v/t8f/u8v/u8v/u8f/u8v/t8v/t8f/t8v/u8f/t8f/t8v/t8//o8v/v8//t8f/t8f/u8f/t8f/u8f/s8v/s8f/r8f/t8f/u8v/t8f/t8v/t8f/t8f/t8f/t8f/u8P/t8v/t8f/t8f/s8P/u8v/w8P/v8v/u8f9RdkImAAAAOHRSTlMAj/eIGPvAYA/vTxPccAPz5sQ1sWZI+enNoph/YiIKBuK3lIRcQS4f2dLIrKicems9vVUodTocJu6ogz0AAALsSURBVFjDtNTBTsJQEIXh8ZbalpZaoNSIktoQMQZUjJvz/k/mtnMsGy7nX87ifsmdZMz3vri7cUlbkvHd4fYVc2dsIKlwyBKSwtj4BaVAElACpG6gKajXzsgJlADJA6gkG/eyb+KRFtTJqHwZjfALVW7cLo1EdvB1K/vfRyTyDN/CJrqPRCq41iZAznC9lgrk043TswmQvnDjL1Mgczf9qSXIEaOamQkQf1LSjUmQjM6JBBkwaqtByhR6pAX0yCBH+LfwJEEyuCoJcrx05bn+8WqkfwC1Xc2mOqxxNfIGQYzsIS5MbFOB1LwSBXIApUAyUAokAaVABlAKpIK6YHUHdcH+urGz3cRhKAzAf41SZQECYS8h0LDTUso6//s/2QyS3ZDUTsJFbua7tCKd+Ng+ls+alRNYsnICC1ZO4MLKCdRYOYERKyfQYeUEXlk5gS0rJ1Bn5QQGrJyAz8oJCGb9X0GsdjyudXw+bxiP5x9OiSDW2xp3UcPhcz7PuJuGraIgfg/Kbcgn9BdQvNf8INYSCW/D8k5IRLvcIHM8CiyWtcejicgpK46NlA+WZN2QEufcjCOkuSzpHWkBpRbw1WdKF2keSxojrSlkjADA+jCv/aNWuIeMvppiTSumFCJjRt61Nbl3kaFW/htaN1MKIM/KDom94cU4obSClk2phrRI/t0RibFh/bqUbOg5qqAYdsxeM2ZNkKLO/Kzw3R0g5V2TGs/S9jjDwh7CmNKuiQc9bZqPuuZg4FNyYbCiEiPxZ6DtPSyovEwhuQ6l1hQmQyqjCNJyoO9nNutUNqF9H1h2+OMCoxN/zA4egOb101ilTkxYm/bQZ6I+hVmbCaveHjp5PZQOTawlcpx9muyayLA3NPhCrgUNBmv8MplRK0aBC7WcABrrLTXmKHSw+NtsBa1oz6yBixK+68zqeOav23zkv9goJRo7fLR1kef61lKbatfwUJrdPfbV7Ec9FJr0wsZhcbXxpCg4dRuhe0bKX+ua5pVSXQrTAAAAAElFTkSuQmCC";
    },
    4360: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("66fd")), o = r(n("2f62")), a = r(n("d30e")), s = r(n("0f9a")), c = r(n("0be2")), l = r(n("2a74")), u = r(n("dcdb")), p = r(n("d1e4")), d = r(n("121d")), f = r(n("9465")), h = r(n("5152")), g = r(n("c3b2")), v = r(n("ce85")), m = r(n("e1fb")), y = r(n("ffa5")), _ = r(n("499b")), b = r(n("a2ca"));
        i.default.use(o.default);
        var x = new o.default.Store({
            modules: {
                mallConfig: a.default,
                user: s.default,
                gConfig: c.default,
                index: l.default,
                orderSubmit: u.default,
                pagination: p.default,
                loading: d.default,
                payment: f.default,
                scanCode: h.default,
                page: g.default,
                userCenter: v.default,
                iPhoneX: m.default,
                gift: y.default,
                cart: _.default,
                share: b.default
            }
        });
        t.default = x;
    },
    "499b": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                reportAndError: {
                    boolean: !1,
                    content: "网络开了会儿小差， 请刷新重试下哦~"
                },
                is_edit: !1
            },
            getters: {
                reportAndErrorObj: function(e) {
                    return e.reportAndError;
                },
                is_edit: function(e) {
                    return e.is_edit;
                }
            },
            mutations: {
                reportAndErrorObj: function(e, t) {
                    e.reportAndError = t;
                },
                is_edit: function(e, t) {
                    e.is_edit = t;
                }
            },
            actions: {
                reportAndErrorObj: function(e, t) {
                    e.commit("reportAndErrorObj", t);
                },
                is_edit: function(e, t) {
                    e.commit("is_edit", t);
                }
            }
        };
        t.default = r;
    },
    "4bca": function(e, t, n) {
        function r(e, t, n, r, i, o, a) {
            try {
                var s = e[o](a), c = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i);
        }
        function i(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(i, o) {
                    function a(e) {
                        r(c, i, o, a, s, "next", e);
                    }
                    function s(e) {
                        r(c, i, o, a, s, "throw", e);
                    }
                    var c = e.apply(t, n);
                    a(void 0);
                });
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("a34a")), a = function() {
            var e = i(o.default.mark(function e(t) {
                var n;
                return o.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        n = {
                            type: "global",
                            text: "加载中",
                            color: "#ffffff",
                            backgroundImage: ""
                        }, (t = Object.assign(n, t)).isShow = !0, this.$store.dispatch("loading/actionGetLoading", t);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }();
        t.default = a;
    },
    5152: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                userCoupon: null
            },
            mutations: {
                mutSetUserCoupon: function(e, t) {
                    e.userCoupon = t;
                }
            },
            actions: {}
        };
        t.default = r;
    },
    "52ba": function(e, t, n) {
        (function(e) {
            function r(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = {
                data: function() {
                    return {};
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? r(Object(n), !0).forEach(function(t) {
                            i(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, n("2f62").mapState)({
                    mysteryImg: function(e) {
                        return e.mallConfig.plugin.mystery.app_image;
                    }
                })),
                methods: {
                    callPhone: function() {
                        e.makePhoneCall({
                            phoneNumber: this.activity.mobile
                        });
                    },
                    rules: function() {
                        var t = {
                            activity_id: this.activity.id
                        };
                        e.navigateTo({
                            url: "/pages/rules/index?url=".concat(encodeURIComponent(this.$api.mystery.activity), "&data=").concat(JSON.stringify(t), "&keys=").concat(JSON.stringify([ "activity", "rules" ]))
                        });
                    },
                    openShare: function() {
                        this.$emit("share");
                    },
                    buy: function() {
                        e.$emit("buy");
                    },
                    help: function() {
                        e.$emit("help");
                    },
                    preview: function(e) {
                        this.$emit("preview", e);
                    },
                    sellout: function() {
                        this.$emit("sellout");
                    }
                }
            };
            t.default = o;
        }).call(this, n("543d").default);
    },
    "543d": function(t, n, r) {
        function i(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function o(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? i(Object(n), !0).forEach(function(t) {
                    u(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function a(e, t) {
            return l(e) || c(e, t) || f(e, t) || s();
        }
        function s() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        function c(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, i, o = [], a = !0, s = !1;
                try {
                    for (n = n.call(e); !(a = (r = n.next()).done) && (o.push(r.value), !t || o.length !== t); a = !0) ;
                } catch (e) {
                    s = !0, i = e;
                } finally {
                    try {
                        a || null == n.return || n.return();
                    } finally {
                        if (s) throw i;
                    }
                }
                return o;
            }
        }
        function l(e) {
            if (Array.isArray(e)) return e;
        }
        function u(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        function p(e) {
            return g(e) || h(e) || f(e) || d();
        }
        function d() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        function f(e, t) {
            if (e) {
                if ("string" == typeof e) return v(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? v(e, t) : void 0;
            }
        }
        function h(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
        }
        function g(e) {
            if (Array.isArray(e)) return v(e);
        }
        function v(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        function m(t) {
            return (m = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function y(e) {
            return decodeURIComponent(atob(e).split("").map(function(e) {
                return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
            }).join(""));
        }
        function _() {
            var e, t = wx.getStorageSync("uni_id_token") || "", n = t.split(".");
            if (!t || 3 !== n.length) return {
                uid: null,
                role: [],
                permission: [],
                tokenExpired: 0
            };
            try {
                e = JSON.parse(y(n[1]));
            } catch (e) {
                throw new Error("获取当前用户信息出错，详细错误信息为：" + e.message);
            }
            return e.tokenExpired = 1e3 * e.exp, delete e.exp, delete e.iat, e;
        }
        function b(e) {
            e.prototype.uniIDHasRole = function(e) {
                return _().role.indexOf(e) > -1;
            }, e.prototype.uniIDHasPermission = function(e) {
                var t = _().permission;
                return this.uniIDHasRole("admin") || t.indexOf(e) > -1;
            }, e.prototype.uniIDTokenValid = function() {
                return _().tokenExpired > Date.now();
            };
        }
        function x(e) {
            return "function" == typeof e;
        }
        function w(e) {
            return "string" == typeof e;
        }
        function A(e) {
            return "[object Object]" === qe.call(e);
        }
        function S(e, t) {
            return Ve.call(e, t);
        }
        function k() {}
        function P(e) {
            var t = Object.create(null);
            return function(n) {
                return t[n] || (t[n] = e(n));
            };
        }
        function O(e, t) {
            var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
            return n ? T(n) : n;
        }
        function T(e) {
            for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
            return t;
        }
        function C(e, t) {
            var n = e.indexOf(t);
            -1 !== n && e.splice(n, 1);
        }
        function D(e, t) {
            Object.keys(t).forEach(function(n) {
                -1 !== Ye.indexOf(n) && x(t[n]) && (e[n] = O(e[n], t[n]));
            });
        }
        function j(e, t) {
            e && t && Object.keys(t).forEach(function(n) {
                -1 !== Ye.indexOf(n) && x(t[n]) && C(e[n], t[n]);
            });
        }
        function $(e) {
            return function(t) {
                return e(t) || t;
            };
        }
        function E(e) {
            return !!e && ("object" === m(e) || "function" == typeof e) && "function" == typeof e.then;
        }
        function M(e, t) {
            for (var n = !1, r = 0; r < e.length; r++) {
                var i = e[r];
                if (n) n = Promise.resolve($(i)); else {
                    var o = i(t);
                    if (E(o) && (n = Promise.resolve(o)), !1 === o) return {
                        then: function() {}
                    };
                }
            }
            return n || {
                then: function(e) {
                    return e(t);
                }
            };
        }
        function L(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return [ "success", "fail", "complete" ].forEach(function(n) {
                if (Array.isArray(e[n])) {
                    var r = t[n];
                    t[n] = function(t) {
                        M(e[n], t).then(function(e) {
                            return x(r) && r(e) || e;
                        });
                    };
                }
            }), t;
        }
        function R(e, t) {
            var n = [];
            Array.isArray(Je.returnValue) && n.push.apply(n, p(Je.returnValue));
            var r = Ke[e];
            return r && Array.isArray(r.returnValue) && n.push.apply(n, p(r.returnValue)), n.forEach(function(e) {
                t = e(t) || t;
            }), t;
        }
        function I(e) {
            var t = Object.create(null);
            Object.keys(Je).forEach(function(e) {
                "returnValue" !== e && (t[e] = Je[e].slice());
            });
            var n = Ke[e];
            return n && Object.keys(n).forEach(function(e) {
                "returnValue" !== e && (t[e] = (t[e] || []).concat(n[e]));
            }), t;
        }
        function F(e, t, n) {
            for (var r = arguments.length, i = new Array(r > 3 ? r - 3 : 0), o = 3; o < r; o++) i[o - 3] = arguments[o];
            var a = I(e);
            return a && Object.keys(a).length ? Array.isArray(a.invoke) ? M(a.invoke, n).then(function(e) {
                return t.apply(void 0, [ L(a, e) ].concat(i));
            }) : t.apply(void 0, [ L(a, n) ].concat(i)) : t.apply(void 0, [ n ].concat(i));
        }
        function N(e) {
            return et.test(e) && -1 === tt.indexOf(e);
        }
        function z(e) {
            return Ze.test(e) && -1 === nt.indexOf(e);
        }
        function B(e) {
            return rt.test(e) && "onPush" !== e;
        }
        function U(e) {
            return e.then(function(e) {
                return [ null, e ];
            }).catch(function(e) {
                return [ e ];
            });
        }
        function W(e) {
            return !(N(e) || z(e) || B(e));
        }
        function H(e, t) {
            return W(e) ? function() {
                for (var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
                return x(n.success) || x(n.fail) || x(n.complete) ? R(e, F.apply(void 0, [ e, t, n ].concat(i))) : R(e, U(new Promise(function(r, o) {
                    F.apply(void 0, [ e, t, Object.assign({}, n, {
                        success: r,
                        fail: o
                    }) ].concat(i));
                })));
            } : t;
        }
        function q() {
            var e = wx.getSystemInfoSync(), t = e.platform, n = e.pixelRatio, r = e.windowWidth;
            ct = r, lt = n, st = "ios" === t;
        }
        function V(e) {
            for (var t = getCurrentPages(), n = t.length; n--; ) {
                var r = t[n];
                if (r.$page && r.$page.fullPath === e) return n;
            }
            return -1;
        }
        function X(e) {
            (it = it || wx.getStorageSync(dt)) || (it = Date.now() + "" + Math.floor(1e7 * Math.random()), 
            wx.setStorage({
                key: dt,
                data: it
            })), e.deviceId = it;
        }
        function G(e) {
            if (e.safeArea) {
                var t = e.safeArea;
                e.safeAreaInsets = {
                    top: t.top,
                    left: t.left,
                    right: e.windowWidth - t.right,
                    bottom: e.windowHeight - t.bottom
                };
            }
        }
        function Y(e, t, n) {
            return function(r) {
                return t(K(e, r, n));
            };
        }
        function J(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            if (A(t)) {
                var o = !0 === i ? t : {};
                for (var a in x(n) && (n = n(t, o) || {}), t) if (S(n, a)) {
                    var s = n[a];
                    x(s) && (s = s(t[a], t, o)), s ? w(s) ? o[s] = t[a] : A(s) && (o[s.name ? s.name : a] = s.value) : console.warn("The '".concat(e, "' method of platform '微信小程序' does not support option '").concat(a, "'"));
                } else -1 !== mt.indexOf(a) ? x(t[a]) && (o[a] = Y(e, t[a], r)) : i || (o[a] = t[a]);
                return o;
            }
            return x(t) && (t = Y(e, t, r)), t;
        }
        function K(e, t, n) {
            var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            return x(ht.returnValue) && (t = ht.returnValue(e, t)), J(e, t, n, {}, r);
        }
        function Q(e, t) {
            if (S(ht, e)) {
                var n = ht[e];
                return n ? function(t, r) {
                    var i = n;
                    x(n) && (i = n(t));
                    var o = [ t = J(e, t, i.args, i.returnValue) ];
                    void 0 !== r && o.push(r), x(i.name) ? e = i.name(t) : w(i.name) && (e = i.name);
                    var a = wx[e].apply(wx, o);
                    return z(e) ? K(e, a, i.returnValue, N(e)) : a;
                } : function() {
                    console.error("Platform '微信小程序' does not support '".concat(e, "'."));
                };
            }
            return t;
        }
        function Z(e) {
            return function(t) {
                var n = t.fail, r = t.complete, i = {
                    errMsg: "".concat(e, ":fail method '").concat(e, "' not supported")
                };
                x(n) && n(i), x(r) && r(i);
            };
        }
        function ee(e, t, n) {
            return e[t].apply(e, n);
        }
        function te(e) {
            if (wx.canIUse && wx.canIUse("nextTick")) {
                var t = e.triggerEvent;
                e.triggerEvent = function(n) {
                    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
                    return t.apply(e, [ Ot(n) ].concat(i));
                };
            }
        }
        function ne(e, t) {
            var n = t[e];
            t[e] = n ? function() {
                te(this);
                for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return n.apply(this, t);
            } : function() {
                te(this);
            };
        }
        function re(e, t) {
            var n = e.$mp[e.mpType];
            t.forEach(function(t) {
                S(n, t) && (e[t] = n[t]);
            });
        }
        function ie(e, t) {
            if (!t) return !0;
            if (He.default.options && Array.isArray(He.default.options[e])) return !0;
            if (t = t.default || t, x(t)) return !!x(t.extendOptions[e]) || !!(t.super && t.super.options && Array.isArray(t.super.options[e]));
            if (x(t[e])) return !0;
            var n = t.mixins;
            return Array.isArray(n) ? !!n.find(function(t) {
                return ie(e, t);
            }) : void 0;
        }
        function oe(e, t, n) {
            t.forEach(function(t) {
                ie(t, n) && (e[t] = function(e) {
                    return this.$vm && this.$vm.__call_hook(t, e);
                });
            });
        }
        function ae(e, t) {
            var n;
            return t = t.default || t, n = x(t) ? t : e.extend(t), t = n.options, [ n, t ];
        }
        function se(e, t) {
            if (Array.isArray(t) && t.length) {
                var n = Object.create(null);
                t.forEach(function(e) {
                    n[e] = !0;
                }), e.$scopedSlots = e.$slots = n;
            }
        }
        function ce(e, t) {
            var n = (e = (e || "").split(",")).length;
            1 === n ? t._$vueId = e[0] : 2 === n && (t._$vueId = e[0], t._$vuePid = e[1]);
        }
        function le(e, t) {
            var n = e.data || {}, r = e.methods || {};
            if ("function" == typeof n) try {
                n = n.call(t);
            } catch (e) {
                Object({
                    NODE_ENV: "production",
                    VUE_APP_NAME: "",
                    VUE_APP_PLATFORM: "mp-weixin",
                    BASE_URL: "/"
                }).VUE_APP_DEBUG && console.warn("根据 Vue 的 data 函数初始化小程序 data 失败，请尽量确保 data 函数中不访问 vm 对象，否则可能影响首次数据渲染速度。", n);
            } else try {
                n = JSON.parse(JSON.stringify(n));
            } catch (e) {}
            return A(n) || (n = {}), Object.keys(r).forEach(function(e) {
                -1 !== t.__lifecycle_hooks__.indexOf(e) || S(n, e) || (n[e] = r[e]);
            }), n;
        }
        function ue(e) {
            return function(t, n) {
                this.$vm && (this.$vm[e] = t);
            };
        }
        function pe(e, t) {
            var n = e.behaviors, r = e.extends, i = e.mixins, o = e.props;
            o || (e.props = o = []);
            var a = [];
            return Array.isArray(n) && n.forEach(function(e) {
                a.push(e.replace("uni://", "wx".concat("://"))), "uni://form-field" === e && (Array.isArray(o) ? (o.push("name"), 
                o.push("value")) : (o.name = {
                    type: String,
                    default: ""
                }, o.value = {
                    type: [ String, Number, Boolean, Array, Object, Date ],
                    default: ""
                }));
            }), A(r) && r.props && a.push(t({
                properties: fe(r.props, !0)
            })), Array.isArray(i) && i.forEach(function(e) {
                A(e) && e.props && a.push(t({
                    properties: fe(e.props, !0)
                }));
            }), a;
        }
        function de(e, t, n, r) {
            return Array.isArray(t) && 1 === t.length ? t[0] : t;
        }
        function fe(e) {
            var t = {};
            return arguments.length > 1 && void 0 !== arguments[1] && arguments[1] || (t.vueId = {
                type: String,
                value: ""
            }, t.generic = {
                type: Object,
                value: null
            }, t.scopedSlotsCompiler = {
                type: String,
                value: ""
            }, t.vueSlots = {
                type: null,
                value: [],
                observer: function(e, t) {
                    var n = Object.create(null);
                    e.forEach(function(e) {
                        n[e] = !0;
                    }), this.setData({
                        $slots: n
                    });
                }
            }), Array.isArray(e) ? e.forEach(function(e) {
                t[e] = {
                    type: null,
                    observer: ue(e)
                };
            }) : A(e) && Object.keys(e).forEach(function(n) {
                var r = e[n];
                if (A(r)) {
                    var i = r.default;
                    x(i) && (i = i()), r.type = de(n, r.type), t[n] = {
                        type: -1 !== Ct.indexOf(r.type) ? r.type : null,
                        value: i,
                        observer: ue(n)
                    };
                } else {
                    var o = de(n, r);
                    t[n] = {
                        type: -1 !== Ct.indexOf(o) ? o : null,
                        observer: ue(n)
                    };
                }
            }), t;
        }
        function he(e) {
            try {
                e.mp = JSON.parse(JSON.stringify(e));
            } catch (e) {}
            return e.stopPropagation = k, e.preventDefault = k, e.target = e.target || {}, S(e, "detail") || (e.detail = {}), 
            S(e, "markerId") && (e.detail = "object" === m(e.detail) ? e.detail : {}, e.detail.markerId = e.markerId), 
            A(e.detail) && (e.target = Object.assign({}, e.target, e.detail)), e;
        }
        function ge(e, t) {
            var n = e;
            return t.forEach(function(t) {
                var r = t[0], i = t[2];
                if (r || void 0 !== i) {
                    var o, a = t[1], s = t[3];
                    Number.isInteger(r) ? o = r : r ? "string" == typeof r && r && (o = 0 === r.indexOf("#s#") ? r.substr(3) : e.__get_value(r, n)) : o = n, 
                    Number.isInteger(o) ? n = i : a ? Array.isArray(o) ? n = o.find(function(t) {
                        return e.__get_value(a, t) === i;
                    }) : A(o) ? n = Object.keys(o).find(function(t) {
                        return e.__get_value(a, o[t]) === i;
                    }) : console.error("v-for 暂不支持循环数据：", o) : n = o[i], s && (n = e.__get_value(s, n));
                }
            }), n;
        }
        function ve(e, t, n) {
            var r = {};
            return Array.isArray(t) && t.length && t.forEach(function(t, i) {
                "string" == typeof t ? t ? "$event" === t ? r["$" + i] = n : "arguments" === t ? n.detail && n.detail.__args__ ? r["$" + i] = n.detail.__args__ : r["$" + i] = [ n ] : 0 === t.indexOf("$event.") ? r["$" + i] = e.__get_value(t.replace("$event.", ""), n) : r["$" + i] = e.__get_value(t) : r["$" + i] = e : r["$" + i] = ge(e, t);
            }), r;
        }
        function me(e) {
            for (var t = {}, n = 1; n < e.length; n++) {
                var r = e[n];
                t[r[0]] = r[1];
            }
            return t;
        }
        function ye(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [], i = arguments.length > 4 ? arguments[4] : void 0, o = arguments.length > 5 ? arguments[5] : void 0, a = !1;
            if (i && (a = t.currentTarget && t.currentTarget.dataset && "wx" === t.currentTarget.dataset.comType, 
            !n.length)) return a ? [ t ] : t.detail.__args__ || t.detail;
            var s = ve(e, r, t), c = [];
            return n.forEach(function(e) {
                "$event" === e ? "__set_model" !== o || i ? i && !a ? c.push(t.detail.__args__[0]) : c.push(t) : c.push(t.target.value) : Array.isArray(e) && "o" === e[0] ? c.push(me(e)) : "string" == typeof e && S(s, e) ? c.push(s[e]) : c.push(e);
            }), c;
        }
        function _e(e, t) {
            return e === t || "regionchange" === t && ("begin" === e || "end" === e);
        }
        function be(e) {
            for (var t = e.$parent; t && t.$parent && (t.$options.generic || t.$parent.$options.generic || t.$scope._$vuePid); ) t = t.$parent;
            return t && t.$parent;
        }
        function xe(e) {
            var t = this, n = ((e = he(e)).currentTarget || e.target).dataset;
            if (!n) return console.warn("事件信息不存在");
            var r = n.eventOpts || n["event-opts"];
            if (!r) return console.warn("事件信息不存在");
            var i = e.type, o = [];
            return r.forEach(function(n) {
                var r = n[0], a = n[1], s = r.charAt(0) === jt, c = (r = s ? r.slice(1) : r).charAt(0) === Dt;
                r = c ? r.slice(1) : r, a && _e(i, r) && a.forEach(function(n) {
                    var r = n[0];
                    if (r) {
                        var i = t.$vm;
                        if (i.$options.generic && (i = be(i) || i), "$emit" === r) return void i.$emit.apply(i, ye(t.$vm, e, n[1], n[2], s, r));
                        var a = i[r];
                        if (!x(a)) throw new Error(" _vm.".concat(r, " is not a function"));
                        if (c) {
                            if (a.once) return;
                            a.once = !0;
                        }
                        var l = ye(t.$vm, e, n[1], n[2], s, r);
                        l = Array.isArray(l) ? l : [], /=\s*\S+\.eventParams\s*\|\|\s*\S+\[['"]event-params['"]\]/.test(a.toString()) && (l = l.concat([ , , , , , , , , , , e ])), 
                        o.push(a.apply(i, l));
                    }
                });
            }), "input" === i && 1 === o.length && void 0 !== o[0] ? o[0] : void 0;
        }
        function we(e) {
            if (e) {
                var t = $t[e];
                return delete $t[e], t;
            }
            return Et.shift();
        }
        function Ae() {
            He.default.prototype.getOpenerEventChannel = function() {
                return this.$scope.getOpenerEventChannel();
            };
            var e = He.default.prototype.__call_hook;
            He.default.prototype.__call_hook = function(t, n) {
                return "onLoad" === t && n && n.__id__ && (this.__eventChannel__ = we(n.__id__), 
                delete n.__id__), e.call(this, t, n);
            };
        }
        function Se() {
            var e = {}, t = {};
            He.default.prototype.$hasScopedSlotsParams = function(n) {
                var r = e[n];
                return r || (t[n] = this, this.$on("hook:destory", function() {
                    delete t[n];
                })), r;
            }, He.default.prototype.$getScopedSlotsParams = function(n, r, i) {
                var o = e[n];
                if (o) {
                    var a = o[r] || {};
                    return i ? a[i] : a;
                }
                t[n] = this, this.$on("hook:destory", function() {
                    delete t[n];
                });
            }, He.default.prototype.$setScopedSlotsParams = function(n, r) {
                var i = this.$options.propsData.vueId;
                if (i) {
                    var o = i.split(",")[0];
                    (e[o] = e[o] || {})[n] = r, t[o] && t[o].$forceUpdate();
                }
            }, He.default.mixin({
                destroyed: function() {
                    var n = this.$options.propsData, r = n && n.vueId;
                    r && (delete e[r], delete t[r]);
                }
            });
        }
        function ke(e, t) {
            var n = t.mocks, r = t.initRefs;
            Ae(), Se(), e.$options.store && (He.default.prototype.$store = e.$options.store), 
            b(He.default), He.default.prototype.mpHost = "mp-weixin", He.default.mixin({
                beforeCreate: function() {
                    if (this.$options.mpType) {
                        if (this.mpType = this.$options.mpType, this.$mp = u({
                            data: {}
                        }, this.mpType, this.$options.mpInstance), this.$scope = this.$options.mpInstance, 
                        delete this.$options.mpType, delete this.$options.mpInstance, "page" === this.mpType && "function" == typeof getApp) {
                            var e = getApp();
                            e.$vm && e.$vm.$i18n && (this._i18n = e.$vm.$i18n);
                        }
                        "app" !== this.mpType && (r(this), re(this, n));
                    }
                }
            });
            var i = {
                onLaunch: function(t) {
                    this.$vm || (wx.canIUse && !wx.canIUse("nextTick") && console.error("当前微信基础库版本过低，请将 微信开发者工具-详情-项目设置-调试基础库版本 更换为`2.3.0`以上"), 
                    this.$vm = e, this.$vm.$mp = {
                        app: this
                    }, this.$vm.$scope = this, this.$vm.globalData = this.globalData, this.$vm._isMounted = !0, 
                    this.$vm.__call_hook("mounted", t), this.$vm.__call_hook("onLaunch", t));
                }
            };
            i.globalData = e.$options.globalData || {};
            var o = e.$options.methods;
            return o && Object.keys(o).forEach(function(e) {
                i[e] = o[e];
            }), oe(i, Mt), i;
        }
        function Pe(e, t) {
            for (var n, r = e.$children, i = r.length - 1; i >= 0; i--) {
                var o = r[i];
                if (o.$scope._$vueId === t) return o;
            }
            for (var a = r.length - 1; a >= 0; a--) if (n = Pe(r[a], t)) return n;
        }
        function Oe(e) {
            return Behavior(e);
        }
        function Te() {
            return !!this.route;
        }
        function Ce(e) {
            this.triggerEvent("__l", e);
        }
        function De(e, t, n) {
            e.selectAllComponents(t).forEach(function(e) {
                var r = e.dataset.ref;
                n[r] = e.$vm || e, "scoped" === e.dataset.vueGeneric && e.selectAllComponents(".scoped-ref").forEach(function(e) {
                    De(e, t, n);
                });
            });
        }
        function je(e) {
            var t = e.$scope;
            Object.defineProperty(e, "$refs", {
                get: function() {
                    var e = {};
                    return De(t, ".vue-ref", e), t.selectAllComponents(".vue-ref-in-for").forEach(function(t) {
                        var n = t.dataset.ref;
                        e[n] || (e[n] = []), e[n].push(t.$vm || t);
                    }), e;
                }
            });
        }
        function $e(e) {
            var t, n = e.detail || e.value, r = n.vuePid, i = n.vueOptions;
            r && (t = Pe(this.$vm, r)), t || (t = this.$vm), i.parent = t;
        }
        function Ee(e) {
            return ke(e, {
                mocks: Lt,
                initRefs: je
            });
        }
        function Me(e) {
            return App(Ee(e)), e;
        }
        function Le(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Nt, n = e ? Object.keys(e).map(function(n) {
                var r = e[n];
                if (void 0 === r) return "";
                if (null === r) return t(n);
                if (Array.isArray(r)) {
                    var i = [];
                    return r.forEach(function(e) {
                        void 0 !== e && (null === e ? i.push(t(n)) : i.push(t(n) + "=" + t(e)));
                    }), i.join("&");
                }
                return t(n) + "=" + t(r);
            }).filter(function(e) {
                return e.length > 0;
            }).join("&") : null;
            return n ? "?".concat(n) : "";
        }
        function Re(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.isPage, r = t.initRelation, i = a(ae(He.default, e), 2), s = i[0], c = i[1], l = o({
                multipleSlots: !0,
                addGlobalClass: !0
            }, c.options || {});
            c["mp-weixin"] && c["mp-weixin"].options && Object.assign(l, c["mp-weixin"].options);
            var u = {
                options: l,
                data: le(c, He.default.prototype),
                behaviors: pe(c, Oe),
                properties: fe(c.props, !1, c.__file),
                lifetimes: {
                    attached: function() {
                        var e = this.properties, t = {
                            mpType: n.call(this) ? "page" : "component",
                            mpInstance: this,
                            propsData: e
                        };
                        ce(e.vueId, this), r.call(this, {
                            vuePid: this._$vuePid,
                            vueOptions: t
                        }), this.$vm = new s(t), se(this.$vm, e.vueSlots), this.$vm.$mount();
                    },
                    ready: function() {
                        this.$vm && (this.$vm._isMounted = !0, this.$vm.__call_hook("mounted"), this.$vm.__call_hook("onReady"));
                    },
                    detached: function() {
                        this.$vm && this.$vm.$destroy();
                    }
                },
                pageLifetimes: {
                    show: function(e) {
                        this.$vm && this.$vm.__call_hook("onPageShow", e);
                    },
                    hide: function() {
                        this.$vm && this.$vm.__call_hook("onPageHide");
                    },
                    resize: function(e) {
                        this.$vm && this.$vm.__call_hook("onPageResize", e);
                    }
                },
                methods: {
                    __l: $e,
                    __e: xe
                }
            };
            return c.externalClasses && (u.externalClasses = c.externalClasses), Array.isArray(c.wxsCallMethods) && c.wxsCallMethods.forEach(function(e) {
                u.methods[e] = function(t) {
                    return this.$vm[e](t);
                };
            }), n ? u : [ u, s ];
        }
        function Ie(e) {
            return Re(e, {
                isPage: Te,
                initRelation: Ce
            });
        }
        function Fe(e, t) {
            t.isPage, t.initRelation;
            var n = Ie(e);
            return oe(n.methods, zt, e), n.methods.onLoad = function(e) {
                this.options = e;
                var t = Object.assign({}, e);
                delete t.__id__, this.$page = {
                    fullPath: "/" + (this.route || this.is) + Le(t)
                }, this.$vm.$mp.query = e, this.$vm.__call_hook("onLoad", e);
            }, n;
        }
        function Ne(e) {
            return Fe(e, {
                isPage: Te,
                initRelation: Ce
            });
        }
        function ze(e) {
            return Component(Ne(e));
        }
        function Be(e) {
            return Component(Ie(e));
        }
        function Ue(e) {
            var t = Ee(e), n = getApp({
                allowDefault: !0
            });
            e.$scope = n;
            var r = n.globalData;
            if (r && Object.keys(t.globalData).forEach(function(e) {
                S(r, e) || (r[e] = t.globalData[e]);
            }), Object.keys(t).forEach(function(e) {
                S(n, e) || (n[e] = t[e]);
            }), x(t.onShow) && wx.onAppShow && wx.onAppShow(function() {
                for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                e.__call_hook("onShow", n);
            }), x(t.onHide) && wx.onAppHide && wx.onAppHide(function() {
                for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                e.__call_hook("onHide", n);
            }), x(t.onLaunch)) {
                var i = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();
                e.__call_hook("onLaunch", i);
            }
            return e;
        }
        function We(e) {
            var t = Ee(e);
            if (x(t.onShow) && wx.onAppShow && wx.onAppShow(function() {
                for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                t.onShow.apply(e, r);
            }), x(t.onHide) && wx.onAppHide && wx.onAppHide(function() {
                for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                t.onHide.apply(e, r);
            }), x(t.onLaunch)) {
                var n = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();
                t.onLaunch.call(e, n);
            }
            return e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.createApp = Me, n.createComponent = Be, n.createPage = ze, n.createPlugin = We, 
        n.createSubpackageApp = Ue, n.default = void 0;
        var He = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(r("66fd")), qe = Object.prototype.toString, Ve = Object.prototype.hasOwnProperty, Xe = /-(\w)/g, Ge = P(function(e) {
            return e.replace(Xe, function(e, t) {
                return t ? t.toUpperCase() : "";
            });
        }), Ye = [ "invoke", "success", "fail", "complete", "returnValue" ], Je = {}, Ke = {}, Qe = {
            returnValue: function(e) {
                return E(e) ? e.then(function(e) {
                    return e[1];
                }).catch(function(e) {
                    return e[0];
                }) : e;
            }
        }, Ze = /^\$|Window$|WindowStyle$|sendNativeEvent|restoreGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64/, et = /^create|Manager$/, tt = [ "createBLEConnection" ], nt = [ "createBLEConnection" ], rt = /^on|^off/;
        Promise.prototype.finally || (Promise.prototype.finally = function(e) {
            var t = this.constructor;
            return this.then(function(n) {
                return t.resolve(e()).then(function() {
                    return n;
                });
            }, function(n) {
                return t.resolve(e()).then(function() {
                    throw n;
                });
            });
        });
        var it, ot = 1e-4, at = 750, st = !1, ct = 0, lt = 0, ut = {
            promiseInterceptor: Qe
        }, pt = Object.freeze({
            __proto__: null,
            upx2px: function(e, t) {
                if (0 === ct && q(), 0 === (e = Number(e))) return 0;
                var n = e / at * (t || ct);
                return n < 0 && (n = -n), 0 === (n = Math.floor(n + ot)) && (n = 1 !== lt && st ? .5 : 1), 
                e < 0 ? -n : n;
            },
            addInterceptor: function(e, t) {
                "string" == typeof e && A(t) ? D(Ke[e] || (Ke[e] = {}), t) : A(e) && D(Je, e);
            },
            removeInterceptor: function(e, t) {
                "string" == typeof e ? A(t) ? j(Ke[e], t) : delete Ke[e] : A(e) && j(Je, e);
            },
            interceptors: ut
        }), dt = "__DC_STAT_UUID", ft = {
            returnValue: function(e) {
                X(e), G(e);
            }
        }, ht = {
            redirectTo: {
                name: function(e) {
                    return "back" === e.exists && e.delta ? "navigateBack" : "redirectTo";
                },
                args: function(e) {
                    if ("back" === e.exists && e.url) {
                        var t = V(e.url);
                        if (-1 !== t) {
                            var n = getCurrentPages().length - 1 - t;
                            n > 0 && (e.delta = n);
                        }
                    }
                }
            },
            previewImage: {
                args: function(e) {
                    var t = parseInt(e.current);
                    if (!isNaN(t)) {
                        var n = e.urls;
                        if (Array.isArray(n)) {
                            var r = n.length;
                            if (r) return t < 0 ? t = 0 : t >= r && (t = r - 1), t > 0 ? (e.current = n[t], 
                            e.urls = n.filter(function(e, r) {
                                return !(r < t) || e !== n[t];
                            })) : e.current = n[0], {
                                indicator: !1,
                                loop: !1
                            };
                        }
                    }
                }
            },
            getSystemInfo: ft,
            getSystemInfoSync: ft
        }, gt = [ "vibrate", "preloadPage", "unPreloadPage", "loadSubPackage" ], vt = [], mt = [ "success", "fail", "cancel", "complete" ], yt = Object.create(null);
        [ "onTabBarMidButtonTap", "subscribePush", "unsubscribePush", "onPush", "offPush", "share" ].forEach(function(e) {
            yt[e] = Z(e);
        });
        var _t = {
            oauth: [ "weixin" ],
            share: [ "weixin" ],
            payment: [ "wxpay" ],
            push: [ "weixin" ]
        }, bt = Object.freeze({
            __proto__: null,
            getProvider: function(e) {
                var t = e.service, n = e.success, r = e.fail, i = e.complete, o = !1;
                _t[t] ? (o = {
                    errMsg: "getProvider:ok",
                    service: t,
                    provider: _t[t]
                }, x(n) && n(o)) : (o = {
                    errMsg: "getProvider:fail service not found"
                }, x(r) && r(o)), x(i) && i(o);
            }
        }), xt = function() {
            var e;
            return function() {
                return e || (e = new He.default()), e;
            };
        }(), wt = Object.freeze({
            __proto__: null,
            $on: function() {
                return ee(xt(), "$on", Array.prototype.slice.call(arguments));
            },
            $off: function() {
                return ee(xt(), "$off", Array.prototype.slice.call(arguments));
            },
            $once: function() {
                return ee(xt(), "$once", Array.prototype.slice.call(arguments));
            },
            $emit: function() {
                return ee(xt(), "$emit", Array.prototype.slice.call(arguments));
            }
        }), At = Object.freeze({
            __proto__: null
        }), St = Page, kt = Component, Pt = /:/g, Ot = P(function(e) {
            return Ge(e.replace(Pt, "-"));
        });
        St.__$wrappered || (St.__$wrappered = !0, Page = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return ne("onLoad", e), St(e);
        }, Page.after = St.after, Component = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return ne("created", e), kt(e);
        });
        var Tt = [ "onPullDownRefresh", "onReachBottom", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ], Ct = [ String, Number, Boolean, Object, Array, null ], Dt = "~", jt = "^", $t = {}, Et = [], Mt = [ "onShow", "onHide", "onError", "onPageNotFound", "onThemeChange", "onUnhandledRejection" ], Lt = [ "__route__", "__wxExparserNodeId__", "__wxWebviewId__" ], Rt = /[!'()*]/g, It = function(e) {
            return "%" + e.charCodeAt(0).toString(16);
        }, Ft = /%2C/g, Nt = function(e) {
            return encodeURIComponent(e).replace(Rt, It).replace(Ft, ",");
        }, zt = [ "onShow", "onHide", "onUnload" ];
        zt.push.apply(zt, Tt), gt.forEach(function(e) {
            ht[e] = !1;
        }), vt.forEach(function(e) {
            var t = ht[e] && ht[e].name ? ht[e].name : e;
            wx.canIUse(t) || (ht[e] = !1);
        });
        var Bt = {};
        "undefined" != typeof Proxy ? Bt = new Proxy({}, {
            get: function(e, t) {
                return S(e, t) ? e[t] : pt[t] ? pt[t] : At[t] ? H(t, At[t]) : bt[t] ? H(t, bt[t]) : yt[t] ? H(t, yt[t]) : wt[t] ? wt[t] : S(wx, t) || S(ht, t) ? H(t, Q(t, wx[t])) : void 0;
            },
            set: function(e, t, n) {
                return e[t] = n, !0;
            }
        }) : (Object.keys(pt).forEach(function(e) {
            Bt[e] = pt[e];
        }), Object.keys(yt).forEach(function(e) {
            Bt[e] = H(e, yt[e]);
        }), Object.keys(bt).forEach(function(e) {
            Bt[e] = H(e, yt[e]);
        }), Object.keys(wt).forEach(function(e) {
            Bt[e] = wt[e];
        }), Object.keys(At).forEach(function(e) {
            Bt[e] = H(e, At[e]);
        }), Object.keys(wx).forEach(function(e) {
            (S(wx, e) || S(ht, e)) && (Bt[e] = H(e, Q(e, wx[e])));
        })), wx.createApp = Me, wx.createPage = ze, wx.createComponent = Be, wx.createSubpackageApp = Ue, 
        wx.createPlugin = We;
        var Ut = Bt;
        n.default = Ut;
    },
    "5b3c": function(e, t, n) {
        function r(e) {
            return e = e.replace(/&forall;/g, "∀"), e = e.replace(/&part;/g, "∂"), e = e.replace(/&exist;/g, "∃"), 
            e = e.replace(/&empty;/g, "∅"), e = e.replace(/&nabla;/g, "∇"), e = e.replace(/&isin;/g, "∈"), 
            e = e.replace(/&notin;/g, "∉"), e = e.replace(/&ni;/g, "∋"), e = e.replace(/&prod;/g, "∏"), 
            e = e.replace(/&sum;/g, "∑"), e = e.replace(/&minus;/g, "−"), e = e.replace(/&lowast;/g, "∗"), 
            e = e.replace(/&radic;/g, "√"), e = e.replace(/&prop;/g, "∝"), e = e.replace(/&infin;/g, "∞"), 
            e = e.replace(/&ang;/g, "∠"), e = e.replace(/&and;/g, "∧"), e = e.replace(/&or;/g, "∨"), 
            e = e.replace(/&cap;/g, "∩"), e = e.replace(/&cup;/g, "∪"), e = e.replace(/&int;/g, "∫"), 
            e = e.replace(/&there4;/g, "∴"), e = e.replace(/&sim;/g, "∼"), e = e.replace(/&cong;/g, "≅"), 
            e = e.replace(/&asymp;/g, "≈"), e = e.replace(/&ne;/g, "≠"), e = e.replace(/&le;/g, "≤"), 
            e = e.replace(/&ge;/g, "≥"), e = e.replace(/&sub;/g, "⊂"), e = e.replace(/&sup;/g, "⊃"), 
            e = e.replace(/&nsub;/g, "⊄"), e = e.replace(/&sube;/g, "⊆"), e = e.replace(/&supe;/g, "⊇"), 
            e = e.replace(/&oplus;/g, "⊕"), e = e.replace(/&otimes;/g, "⊗"), e = e.replace(/&perp;/g, "⊥"), 
            e = e.replace(/&sdot;/g, "⋅");
        }
        function i(e) {
            return e = e.replace(/&Alpha;/g, "Α"), e = e.replace(/&Beta;/g, "Β"), e = e.replace(/&Gamma;/g, "Γ"), 
            e = e.replace(/&Delta;/g, "Δ"), e = e.replace(/&Epsilon;/g, "Ε"), e = e.replace(/&Zeta;/g, "Ζ"), 
            e = e.replace(/&Eta;/g, "Η"), e = e.replace(/&Theta;/g, "Θ"), e = e.replace(/&Iota;/g, "Ι"), 
            e = e.replace(/&Kappa;/g, "Κ"), e = e.replace(/&Lambda;/g, "Λ"), e = e.replace(/&Mu;/g, "Μ"), 
            e = e.replace(/&Nu;/g, "Ν"), e = e.replace(/&Xi;/g, "Ν"), e = e.replace(/&Omicron;/g, "Ο"), 
            e = e.replace(/&Pi;/g, "Π"), e = e.replace(/&Rho;/g, "Ρ"), e = e.replace(/&Sigma;/g, "Σ"), 
            e = e.replace(/&Tau;/g, "Τ"), e = e.replace(/&Upsilon;/g, "Υ"), e = e.replace(/&Phi;/g, "Φ"), 
            e = e.replace(/&Chi;/g, "Χ"), e = e.replace(/&Psi;/g, "Ψ"), e = e.replace(/&Omega;/g, "Ω"), 
            e = e.replace(/&alpha;/g, "α"), e = e.replace(/&beta;/g, "β"), e = e.replace(/&gamma;/g, "γ"), 
            e = e.replace(/&delta;/g, "δ"), e = e.replace(/&epsilon;/g, "ε"), e = e.replace(/&zeta;/g, "ζ"), 
            e = e.replace(/&eta;/g, "η"), e = e.replace(/&theta;/g, "θ"), e = e.replace(/&iota;/g, "ι"), 
            e = e.replace(/&kappa;/g, "κ"), e = e.replace(/&lambda;/g, "λ"), e = e.replace(/&mu;/g, "μ"), 
            e = e.replace(/&nu;/g, "ν"), e = e.replace(/&xi;/g, "ξ"), e = e.replace(/&omicron;/g, "ο"), 
            e = e.replace(/&pi;/g, "π"), e = e.replace(/&rho;/g, "ρ"), e = e.replace(/&sigmaf;/g, "ς"), 
            e = e.replace(/&sigma;/g, "σ"), e = e.replace(/&tau;/g, "τ"), e = e.replace(/&upsilon;/g, "υ"), 
            e = e.replace(/&phi;/g, "φ"), e = e.replace(/&chi;/g, "χ"), e = e.replace(/&psi;/g, "ψ"), 
            e = e.replace(/&omega;/g, "ω"), e = e.replace(/&thetasym;/g, "ϑ"), e = e.replace(/&upsih;/g, "ϒ"), 
            e = e.replace(/&piv;/g, "ϖ"), e = e.replace(/&middot;/g, "·");
        }
        function o(e) {
            return e = e.replace(/&nbsp;/g, " "), e = e.replace(/&ensp;/g, " "), e = e.replace(/&emsp;/g, "　"), 
            e = e.replace(/&quot;/g, "'"), e = e.replace(/&amp;/g, "&"), e = e.replace(/&lt;/g, "<"), 
            e = e.replace(/&gt;/g, ">"), e = e.replace(/&#8226;/g, "•");
        }
        function a(e) {
            return e = e.replace(/&OElig;/g, "Œ"), e = e.replace(/&oelig;/g, "œ"), e = e.replace(/&Scaron;/g, "Š"), 
            e = e.replace(/&scaron;/g, "š"), e = e.replace(/&Yuml;/g, "Ÿ"), e = e.replace(/&fnof;/g, "ƒ"), 
            e = e.replace(/&circ;/g, "ˆ"), e = e.replace(/&tilde;/g, "˜"), e = e.replace(/&ensp;/g, ""), 
            e = e.replace(/&emsp;/g, ""), e = e.replace(/&thinsp;/g, ""), e = e.replace(/&zwnj;/g, ""), 
            e = e.replace(/&zwj;/g, ""), e = e.replace(/&lrm;/g, ""), e = e.replace(/&rlm;/g, ""), 
            e = e.replace(/&ndash;/g, "–"), e = e.replace(/&mdash;/g, "—"), e = e.replace(/&lsquo;/g, "‘"), 
            e = e.replace(/&rsquo;/g, "’"), e = e.replace(/&sbquo;/g, "‚"), e = e.replace(/&ldquo;/g, "“"), 
            e = e.replace(/&rdquo;/g, "”"), e = e.replace(/&bdquo;/g, "„"), e = e.replace(/&dagger;/g, "†"), 
            e = e.replace(/&Dagger;/g, "‡"), e = e.replace(/&bull;/g, "•"), e = e.replace(/&hellip;/g, "…"), 
            e = e.replace(/&permil;/g, "‰"), e = e.replace(/&prime;/g, "′"), e = e.replace(/&Prime;/g, "″"), 
            e = e.replace(/&lsaquo;/g, "‹"), e = e.replace(/&rsaquo;/g, "›"), e = e.replace(/&oline;/g, "‾"), 
            e = e.replace(/&euro;/g, "€"), e = e.replace(/&trade;/g, "™"), e = e.replace(/&larr;/g, "←"), 
            e = e.replace(/&uarr;/g, "↑"), e = e.replace(/&rarr;/g, "→"), e = e.replace(/&darr;/g, "↓"), 
            e = e.replace(/&harr;/g, "↔"), e = e.replace(/&crarr;/g, "↵"), e = e.replace(/&lceil;/g, "⌈"), 
            e = e.replace(/&rceil;/g, "⌉"), e = e.replace(/&lfloor;/g, "⌊"), e = e.replace(/&rfloor;/g, "⌋"), 
            e = e.replace(/&loz;/g, "◊"), e = e.replace(/&spades;/g, "♠"), e = e.replace(/&clubs;/g, "♣"), 
            e = e.replace(/&hearts;/g, "♥"), e = e.replace(/&diams;/g, "♦"), e = e.replace(/&#39;/g, "'");
        }
        function s(e, t) {
            for (var n = 0; n < e.length; n++) if ("" !== e[n]) return /^\/\//.test(e[n]) ? "https:".concat(e[n]) : /^\//.test(e[n]) ? "https://".concat(t).concat(e[n]) : e[n];
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = {
            strDiscode: function(e) {
                return e = r(e), e = i(e), e = o(e), e = a(e);
            },
            urlToHttpUrl: function(e, t) {
                return /^\/\//.test(e) ? "https:".concat(e) : /^\//.test(e) ? "https://".concat(t).concat(e) : Array.isArray(e) ? s(e, t) : e;
            }
        };
        t.default = c;
    },
    "5c35": function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e) {
            for (var t = {}, n = e.split(","), r = 0; r < n.length; r += 1) t[n[r]] = !0;
            return t;
        }
        function o(e) {
            return /<body.*>([^]*)<\/body>/.test(e) ? RegExp.$1 : e;
        }
        function a(e) {
            return e.replace(/<!--.*?-->/gi, "").replace(/\/\*.*?\*\//gi, "").replace(/[ ]+</gi, "<").replace(/<script[^]*<\/script>/gi, "").replace(/<style[^]*<\/style>/gi, "");
        }
        function s() {
            var e = {};
            return wx.getSystemInfo({
                success: function(t) {
                    e.width = t.windowWidth, e.height = t.windowHeight;
                }
            }), e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = r(n("5b3c")), l = r(n("023f")), u = i("br,code,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video"), p = i("a,abbr,acronym,applet,b,basefont,bdo,big,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), d = i("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr");
        t.default = function(e, t, n, r) {
            function i(e) {
                this.node = "element", this.tag = e, this.$screen = g;
            }
            e = a(e = o(e)), e = c.default.strDiscode(e);
            var f = [], h = {
                nodes: [],
                imageUrls: []
            }, g = s();
            return (0, l.default)(e, {
                start: function(e, r, o) {
                    var a = new i(e);
                    if (0 !== f.length) {
                        var s = f[0];
                        void 0 === s.nodes && (s.nodes = []);
                    }
                    if (u[e] ? a.tagType = "block" : p[e] ? a.tagType = "inline" : d[e] && (a.tagType = "closeSelf"), 
                    a.attr = r.reduce(function(e, t) {
                        var n = t.name, r = t.value;
                        return "class" === n && (a.classStr = r), "style" === n && (a.styleStr = r), r.match(/ /) && (r = r.split(" ")), 
                        e[n] ? Array.isArray(e[n]) ? e[n].push(r) : e[n] = [ e[n], r ] : e[n] = r, e;
                    }, {}), a.classStr ? a.classStr += " ".concat(a.tag) : a.classStr = a.tag, "inline" === a.tagType && (a.classStr += " inline"), 
                    "img" === a.tag) {
                        var l = a.attr.src;
                        l = c.default.urlToHttpUrl(l, n.domain), Object.assign(a.attr, n, {
                            src: l || ""
                        }), l && h.imageUrls.push(l);
                    }
                    if ("a" === a.tag && (a.attr.href = a.attr.href || ""), "font" === a.tag) {
                        var g = [ "x-small", "small", "medium", "large", "x-large", "xx-large", "-webkit-xxx-large" ], v = {
                            color: "color",
                            face: "font-family",
                            size: "font-size"
                        };
                        a.styleStr || (a.styleStr = ""), Object.keys(v).forEach(function(e) {
                            if (a.attr[e]) {
                                var t = "size" === e ? g[a.attr[e] - 1] : a.attr[e];
                                a.styleStr += "".concat(v[e], ": ").concat(t, ";");
                            }
                        });
                    }
                    if ("source" === a.tag && (h.source = a.attr.src), t.start && t.start(a, h), o) {
                        var m = f[0] || h;
                        void 0 === m.nodes && (m.nodes = []), m.nodes.push(a);
                    } else f.unshift(a);
                },
                end: function(e) {
                    var n = f.shift();
                    if (n.tag !== e && console.error("invalid state: mismatch end tag"), "video" === n.tag && h.source && (n.attr.src = h.source, 
                    delete h.source), t.end && t.end(n, h), 0 === f.length) h.nodes.push(n); else {
                        var r = f[0];
                        r.nodes || (r.nodes = []), r.nodes.push(n);
                    }
                },
                chars: function(e) {
                    if (e.trim()) {
                        var n = {
                            node: "text",
                            text: e
                        };
                        if (t.chars && t.chars(n, h), 0 === f.length) h.nodes.push(n); else {
                            var r = f[0];
                            void 0 === r.nodes && (r.nodes = []), r.nodes.push(n);
                        }
                    }
                }
            }), h;
        };
    },
    "5cd4": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            t.default = function(t) {
                return new Promise(function(n, r) {
                    wx.requestSubscribeMessage ? wx.requestSubscribeMessage({
                        tmplIds: t,
                        success: function(e) {
                            n(e);
                        },
                        fail: function(e) {
                            r(e);
                        }
                    }) : e.showModal({
                        title: "提示",
                        content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",
                        showCancel: !1,
                        success: function(e) {
                            r({});
                        }
                    });
                });
            };
        }).call(this, n("543d").default);
    },
    "62e4": function(e, t) {
        e.exports = function(e) {
            return e.webpackPolyfill || (e.deprecate = function() {}, e.paths = [], e.children || (e.children = []), 
            Object.defineProperty(e, "loaded", {
                enumerable: !0,
                get: function() {
                    return e.l;
                }
            }), Object.defineProperty(e, "id", {
                enumerable: !0,
                get: function() {
                    return e.i;
                }
            }), e.webpackPolyfill = 1), e;
        };
    },
    "63ad": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.platform = void 0;
        t.platform = "wxapp";
    },
    "66fd": function(t, n, r) {
        r.r(n), function(t) {
            function r(e) {
                return void 0 === e || null === e;
            }
            function i(e) {
                return void 0 !== e && null !== e;
            }
            function o(e) {
                return !0 === e;
            }
            function a(e) {
                return !1 === e;
            }
            function s(t) {
                return "string" == typeof t || "number" == typeof t || "symbol" === (void 0 === t ? "undefined" : e(t)) || "boolean" == typeof t;
            }
            function c(t) {
                return null !== t && "object" === (void 0 === t ? "undefined" : e(t));
            }
            function l(e) {
                return "[object Object]" === yn.call(e);
            }
            function u(e) {
                return "[object RegExp]" === yn.call(e);
            }
            function p(e) {
                var t = parseFloat(String(e));
                return t >= 0 && Math.floor(t) === t && isFinite(e);
            }
            function d(e) {
                return i(e) && "function" == typeof e.then && "function" == typeof e.catch;
            }
            function f(e) {
                return null == e ? "" : Array.isArray(e) || l(e) && e.toString === yn ? JSON.stringify(e, null, 2) : String(e);
            }
            function h(e) {
                var t = parseFloat(e);
                return isNaN(t) ? e : t;
            }
            function g(e, t) {
                for (var n = Object.create(null), r = e.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return t ? function(e) {
                    return n[e.toLowerCase()];
                } : function(e) {
                    return n[e];
                };
            }
            function v(e, t) {
                if (e.length) {
                    var n = e.indexOf(t);
                    if (n > -1) return e.splice(n, 1);
                }
            }
            function m(e, t) {
                return xn.call(e, t);
            }
            function y(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            function _(e, t) {
                t = t || 0;
                for (var n = e.length - t, r = new Array(n); n--; ) r[n] = e[n + t];
                return r;
            }
            function b(e, t) {
                for (var n in t) e[n] = t[n];
                return e;
            }
            function x(e) {
                for (var t = {}, n = 0; n < e.length; n++) e[n] && b(t, e[n]);
                return t;
            }
            function w(e, t, n) {}
            function A(e, t) {
                if (e === t) return !0;
                var n = c(e), r = c(t);
                if (!n || !r) return !n && !r && String(e) === String(t);
                try {
                    var i = Array.isArray(e), o = Array.isArray(t);
                    if (i && o) return e.length === t.length && e.every(function(e, n) {
                        return A(e, t[n]);
                    });
                    if (e instanceof Date && t instanceof Date) return e.getTime() === t.getTime();
                    if (i || o) return !1;
                    var a = Object.keys(e), s = Object.keys(t);
                    return a.length === s.length && a.every(function(n) {
                        return A(e[n], t[n]);
                    });
                } catch (e) {
                    return !1;
                }
            }
            function S(e, t) {
                for (var n = 0; n < e.length; n++) if (A(e[n], t)) return n;
                return -1;
            }
            function k(e) {
                var t = !1;
                return function() {
                    t || (t = !0, e.apply(this, arguments));
                };
            }
            function P(e) {
                var t = (e + "").charCodeAt(0);
                return 36 === t || 95 === t;
            }
            function O(e, t, n, r) {
                Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            function T(e) {
                if (!Mn.test(e)) {
                    var t = e.split(".");
                    return function(e) {
                        for (var n = 0; n < t.length; n++) {
                            if (!e) return;
                            e = e[t[n]];
                        }
                        return e;
                    };
                }
            }
            function C(e) {
                return "function" == typeof e && /native code/.test(e.toString());
            }
            function D(e) {
                Jn.SharedObject.targetStack.push(e), Jn.SharedObject.target = e, Jn.target = e;
            }
            function j() {
                Jn.SharedObject.targetStack.pop(), Jn.SharedObject.target = Jn.SharedObject.targetStack[Jn.SharedObject.targetStack.length - 1], 
                Jn.target = Jn.SharedObject.target;
            }
            function $(e) {
                return new Kn(void 0, void 0, void 0, String(e));
            }
            function E(e) {
                var t = new Kn(e.tag, e.data, e.children && e.children.slice(), e.text, e.elm, e.context, e.componentOptions, e.asyncFactory);
                return t.ns = e.ns, t.isStatic = e.isStatic, t.key = e.key, t.isComment = e.isComment, 
                t.fnContext = e.fnContext, t.fnOptions = e.fnOptions, t.fnScopeId = e.fnScopeId, 
                t.asyncMeta = e.asyncMeta, t.isCloned = !0, t;
            }
            function M(e) {
                rr = e;
            }
            function L(e, t) {
                e.__proto__ = t;
            }
            function R(e, t, n) {
                for (var r = 0, i = n.length; r < i; r++) {
                    var o = n[r];
                    O(e, o, t[o]);
                }
            }
            function I(e, t) {
                var n;
                if (c(e) && !(e instanceof Kn)) return m(e, "__ob__") && e.__ob__ instanceof ir ? n = e.__ob__ : rr && !qn() && (Array.isArray(e) || l(e)) && Object.isExtensible(e) && !e._isVue && (n = new ir(e)), 
                t && n && n.vmCount++, n;
            }
            function F(e, t, n, r, i) {
                var o = new Jn(), a = Object.getOwnPropertyDescriptor(e, t);
                if (!a || !1 !== a.configurable) {
                    var s = a && a.get, c = a && a.set;
                    s && !c || 2 !== arguments.length || (n = e[t]);
                    var l = !i && I(n);
                    Object.defineProperty(e, t, {
                        enumerable: !0,
                        configurable: !0,
                        get: function() {
                            var t = s ? s.call(e) : n;
                            return Jn.SharedObject.target && (o.depend(), l && (l.dep.depend(), Array.isArray(t) && B(t))), 
                            t;
                        },
                        set: function(t) {
                            var r = s ? s.call(e) : n;
                            t === r || t !== t && r !== r || s && !c || (c ? c.call(e, t) : n = t, l = !i && I(t), 
                            o.notify());
                        }
                    });
                }
            }
            function N(e, t, n) {
                if (Array.isArray(e) && p(t)) return e.length = Math.max(e.length, t), e.splice(t, 1, n), 
                n;
                if (t in e && !(t in Object.prototype)) return e[t] = n, n;
                var r = e.__ob__;
                return e._isVue || r && r.vmCount ? n : r ? (F(r.value, t, n), r.dep.notify(), n) : (e[t] = n, 
                n);
            }
            function z(e, t) {
                if (Array.isArray(e) && p(t)) e.splice(t, 1); else {
                    var n = e.__ob__;
                    e._isVue || n && n.vmCount || m(e, t) && (delete e[t], n && n.dep.notify());
                }
            }
            function B(e) {
                for (var t = void 0, n = 0, r = e.length; n < r; n++) (t = e[n]) && t.__ob__ && t.__ob__.dep.depend(), 
                Array.isArray(t) && B(t);
            }
            function U(e, t) {
                if (!t) return e;
                for (var n, r, i, o = Xn ? Reflect.ownKeys(t) : Object.keys(t), a = 0; a < o.length; a++) "__ob__" !== (n = o[a]) && (r = e[n], 
                i = t[n], m(e, n) ? r !== i && l(r) && l(i) && U(r, i) : N(e, n, i));
                return e;
            }
            function W(e, t, n) {
                return n ? function() {
                    var r = "function" == typeof t ? t.call(n, n) : t, i = "function" == typeof e ? e.call(n, n) : e;
                    return r ? U(r, i) : i;
                } : t ? e ? function() {
                    return U("function" == typeof t ? t.call(this, this) : t, "function" == typeof e ? e.call(this, this) : e);
                } : t : e;
            }
            function H(e, t) {
                var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                return n ? q(n) : n;
            }
            function q(e) {
                for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                return t;
            }
            function V(e, t, n, r) {
                var i = Object.create(e || null);
                return t ? b(i, t) : i;
            }
            function X(e, t) {
                var n = e.props;
                if (n) {
                    var r, i, o, a = {};
                    if (Array.isArray(n)) for (r = n.length; r--; ) "string" == typeof (i = n[r]) && (o = An(i), 
                    a[o] = {
                        type: null
                    }); else if (l(n)) for (var s in n) i = n[s], a[o = An(s)] = l(i) ? i : {
                        type: i
                    };
                    e.props = a;
                }
            }
            function G(e, t) {
                var n = e.inject;
                if (n) {
                    var r = e.inject = {};
                    if (Array.isArray(n)) for (var i = 0; i < n.length; i++) r[n[i]] = {
                        from: n[i]
                    }; else if (l(n)) for (var o in n) {
                        var a = n[o];
                        r[o] = l(a) ? b({
                            from: o
                        }, a) : {
                            from: a
                        };
                    }
                }
            }
            function Y(e) {
                var t = e.directives;
                if (t) for (var n in t) {
                    var r = t[n];
                    "function" == typeof r && (t[n] = {
                        bind: r,
                        update: r
                    });
                }
            }
            function J(e, t, n) {
                function r(r) {
                    var i = or[r] || sr;
                    s[r] = i(e[r], t[r], n, r);
                }
                if ("function" == typeof t && (t = t.options), X(t, n), G(t, n), Y(t), !t._base && (t.extends && (e = J(e, t.extends, n)), 
                t.mixins)) for (var i = 0, o = t.mixins.length; i < o; i++) e = J(e, t.mixins[i], n);
                var a, s = {};
                for (a in e) r(a);
                for (a in t) m(e, a) || r(a);
                return s;
            }
            function K(e, t, n, r) {
                if ("string" == typeof n) {
                    var i = e[t];
                    if (m(i, n)) return i[n];
                    var o = An(n);
                    if (m(i, o)) return i[o];
                    var a = Sn(o);
                    return m(i, a) ? i[a] : i[n] || i[o] || i[a];
                }
            }
            function Q(e, t, n, r) {
                var i = t[e], o = !m(n, e), a = n[e], s = ne(Boolean, i.type);
                if (s > -1) if (o && !m(i, "default")) a = !1; else if ("" === a || a === Pn(e)) {
                    var c = ne(String, i.type);
                    (c < 0 || s < c) && (a = !0);
                }
                if (void 0 === a) {
                    a = Z(r, i, e);
                    var l = rr;
                    M(!0), I(a), M(l);
                }
                return a;
            }
            function Z(e, t, n) {
                if (m(t, "default")) {
                    var r = t.default;
                    return e && e.$options.propsData && void 0 === e.$options.propsData[n] && void 0 !== e._props[n] ? e._props[n] : "function" == typeof r && "Function" !== ee(t.type) ? r.call(e) : r;
                }
            }
            function ee(e) {
                var t = e && e.toString().match(/^\s*function (\w+)/);
                return t ? t[1] : "";
            }
            function te(e, t) {
                return ee(e) === ee(t);
            }
            function ne(e, t) {
                if (!Array.isArray(t)) return te(t, e) ? 0 : -1;
                for (var n = 0, r = t.length; n < r; n++) if (te(t[n], e)) return n;
                return -1;
            }
            function re(e, t, n) {
                D();
                try {
                    if (t) for (var r = t; r = r.$parent; ) {
                        var i = r.$options.errorCaptured;
                        if (i) for (var o = 0; o < i.length; o++) try {
                            if (!1 === i[o].call(r, e, t, n)) return;
                        } catch (e) {
                            oe(e, r, "errorCaptured hook");
                        }
                    }
                    oe(e, t, n);
                } finally {
                    j();
                }
            }
            function ie(e, t, n, r, i) {
                var o;
                try {
                    (o = n ? e.apply(t, n) : e.call(t)) && !o._isVue && d(o) && !o._handled && (o.catch(function(e) {
                        return re(e, r, i + " (Promise/async)");
                    }), o._handled = !0);
                } catch (e) {
                    re(e, r, i);
                }
                return o;
            }
            function oe(e, t, n) {
                if ($n.errorHandler) try {
                    return $n.errorHandler.call(null, e, t, n);
                } catch (t) {
                    t !== e && ae(t, null, "config.errorHandler");
                }
                ae(e, t, n);
            }
            function ae(e, t, n) {
                if (!Rn && !In || "undefined" == typeof console) throw e;
                console.error(e);
            }
            function se() {
                lr = !1;
                var e = cr.slice(0);
                cr.length = 0;
                for (var t = 0; t < e.length; t++) e[t]();
            }
            function ce(e, t) {
                var n;
                if (cr.push(function() {
                    if (e) try {
                        e.call(t);
                    } catch (e) {
                        re(e, t, "nextTick");
                    } else n && n(t);
                }), lr || (lr = !0, ar()), !e && "undefined" != typeof Promise) return new Promise(function(e) {
                    n = e;
                });
            }
            function le(e) {
                ue(e, hr), hr.clear();
            }
            function ue(e, t) {
                var n, r, i = Array.isArray(e);
                if (!(!i && !c(e) || Object.isFrozen(e) || e instanceof Kn)) {
                    if (e.__ob__) {
                        var o = e.__ob__.dep.id;
                        if (t.has(o)) return;
                        t.add(o);
                    }
                    if (i) for (n = e.length; n--; ) ue(e[n], t); else for (n = (r = Object.keys(e)).length; n--; ) ue(e[r[n]], t);
                }
            }
            function pe(e, t) {
                function n() {
                    var e = arguments, r = n.fns;
                    if (!Array.isArray(r)) return ie(r, null, arguments, t, "v-on handler");
                    for (var i = r.slice(), o = 0; o < i.length; o++) ie(i[o], null, e, t, "v-on handler");
                }
                return n.fns = e, n;
            }
            function de(e, t, n, i, a, s) {
                var c, l, u, p;
                for (c in e) l = e[c], u = t[c], p = gr(c), r(l) || (r(u) ? (r(l.fns) && (l = e[c] = pe(l, s)), 
                o(p.once) && (l = e[c] = a(p.name, l, p.capture)), n(p.name, l, p.capture, p.passive, p.params)) : l !== u && (u.fns = l, 
                e[c] = u));
                for (c in t) r(e[c]) && (p = gr(c), i(p.name, t[c], p.capture));
            }
            function fe(e, t, n, o) {
                var a = t.options.mpOptions && t.options.mpOptions.properties;
                if (r(a)) return n;
                var s = t.options.mpOptions.externalClasses || [], c = e.attrs, l = e.props;
                if (i(c) || i(l)) for (var u in a) {
                    var p = Pn(u);
                    (ge(n, l, u, p, !0) || ge(n, c, u, p, !1)) && n[u] && -1 !== s.indexOf(p) && o[An(n[u])] && (n[u] = o[An(n[u])]);
                }
                return n;
            }
            function he(e, t, n, o) {
                var a = t.options.props;
                if (r(a)) return fe(e, t, {}, o);
                var s = {}, c = e.attrs, l = e.props;
                if (i(c) || i(l)) for (var u in a) {
                    var p = Pn(u);
                    ge(s, l, u, p, !0) || ge(s, c, u, p, !1);
                }
                return fe(e, t, s, o);
            }
            function ge(e, t, n, r, o) {
                if (i(t)) {
                    if (m(t, n)) return e[n] = t[n], o || delete t[n], !0;
                    if (m(t, r)) return e[n] = t[r], o || delete t[r], !0;
                }
                return !1;
            }
            function ve(e) {
                for (var t = 0; t < e.length; t++) if (Array.isArray(e[t])) return Array.prototype.concat.apply([], e);
                return e;
            }
            function me(e) {
                return s(e) ? [ $(e) ] : Array.isArray(e) ? _e(e) : void 0;
            }
            function ye(e) {
                return i(e) && i(e.text) && a(e.isComment);
            }
            function _e(e, t) {
                var n, a, c, l, u = [];
                for (n = 0; n < e.length; n++) r(a = e[n]) || "boolean" == typeof a || (c = u.length - 1, 
                l = u[c], Array.isArray(a) ? a.length > 0 && (a = _e(a, (t || "") + "_" + n), ye(a[0]) && ye(l) && (u[c] = $(l.text + a[0].text), 
                a.shift()), u.push.apply(u, a)) : s(a) ? ye(l) ? u[c] = $(l.text + a) : "" !== a && u.push($(a)) : ye(a) && ye(l) ? u[c] = $(l.text + a.text) : (o(e._isVList) && i(a.tag) && r(a.key) && i(t) && (a.key = "__vlist" + t + "_" + n + "__"), 
                u.push(a)));
                return u;
            }
            function be(e) {
                var t = e.$options.provide;
                t && (e._provided = "function" == typeof t ? t.call(e) : t);
            }
            function xe(e) {
                var t = we(e.$options.inject, e);
                t && (M(!1), Object.keys(t).forEach(function(n) {
                    F(e, n, t[n]);
                }), M(!0));
            }
            function we(e, t) {
                if (e) {
                    for (var n = Object.create(null), r = Xn ? Reflect.ownKeys(e) : Object.keys(e), i = 0; i < r.length; i++) {
                        var o = r[i];
                        if ("__ob__" !== o) {
                            for (var a = e[o].from, s = t; s; ) {
                                if (s._provided && m(s._provided, a)) {
                                    n[o] = s._provided[a];
                                    break;
                                }
                                s = s.$parent;
                            }
                            if (!s && "default" in e[o]) {
                                var c = e[o].default;
                                n[o] = "function" == typeof c ? c.call(t) : c;
                            }
                        }
                    }
                    return n;
                }
            }
            function Ae(e, t) {
                if (!e || !e.length) return {};
                for (var n = {}, r = 0, i = e.length; r < i; r++) {
                    var o = e[r], a = o.data;
                    if (a && a.attrs && a.attrs.slot && delete a.attrs.slot, o.context !== t && o.fnContext !== t || !a || null == a.slot) o.asyncMeta && o.asyncMeta.data && "page" === o.asyncMeta.data.slot ? (n.page || (n.page = [])).push(o) : (n.default || (n.default = [])).push(o); else {
                        var s = a.slot, c = n[s] || (n[s] = []);
                        "template" === o.tag ? c.push.apply(c, o.children || []) : c.push(o);
                    }
                }
                for (var l in n) n[l].every(Se) && delete n[l];
                return n;
            }
            function Se(e) {
                return e.isComment && !e.asyncFactory || " " === e.text;
            }
            function ke(e, t, n) {
                var r, i = Object.keys(t).length > 0, o = e ? !!e.$stable : !i, a = e && e.$key;
                if (e) {
                    if (e._normalized) return e._normalized;
                    if (o && n && n !== mn && a === n.$key && !i && !n.$hasNormal) return n;
                    for (var s in r = {}, e) e[s] && "$" !== s[0] && (r[s] = Pe(t, s, e[s]));
                } else r = {};
                for (var c in t) c in r || (r[c] = Oe(t, c));
                return e && Object.isExtensible(e) && (e._normalized = r), O(r, "$stable", o), O(r, "$key", a), 
                O(r, "$hasNormal", i), r;
            }
            function Pe(t, n, r) {
                var i = function() {
                    var t = arguments.length ? r.apply(null, arguments) : r({});
                    return (t = t && "object" === (void 0 === t ? "undefined" : e(t)) && !Array.isArray(t) ? [ t ] : me(t)) && (0 === t.length || 1 === t.length && t[0].isComment) ? void 0 : t;
                };
                return r.proxy && Object.defineProperty(t, n, {
                    get: i,
                    enumerable: !0,
                    configurable: !0
                }), i;
            }
            function Oe(e, t) {
                return function() {
                    return e[t];
                };
            }
            function Te(e, t) {
                var n, r, o, a, s;
                if (Array.isArray(e) || "string" == typeof e) for (n = new Array(e.length), r = 0, 
                o = e.length; r < o; r++) n[r] = t(e[r], r, r, r); else if ("number" == typeof e) for (n = new Array(e), 
                r = 0; r < e; r++) n[r] = t(r + 1, r, r, r); else if (c(e)) if (Xn && e[Symbol.iterator]) {
                    n = [];
                    for (var l = e[Symbol.iterator](), u = l.next(); !u.done; ) n.push(t(u.value, n.length, r, r++)), 
                    u = l.next();
                } else for (a = Object.keys(e), n = new Array(a.length), r = 0, o = a.length; r < o; r++) s = a[r], 
                n[r] = t(e[s], s, r, r);
                return i(n) || (n = []), n._isVList = !0, n;
            }
            function Ce(e, t, n, r) {
                var i, o = this.$scopedSlots[e];
                o ? (n = n || {}, r && (n = b(b({}, r), n)), i = o(n, this, n._i) || t) : i = this.$slots[e] || t;
                var a = n && n.slot;
                return a ? this.$createElement("template", {
                    slot: a
                }, i) : i;
            }
            function De(e) {
                return K(this.$options, "filters", e, !0) || Cn;
            }
            function je(e, t) {
                return Array.isArray(e) ? -1 === e.indexOf(t) : e !== t;
            }
            function $e(e, t, n, r, i) {
                var o = $n.keyCodes[t] || n;
                return i && r && !$n.keyCodes[t] ? je(i, r) : o ? je(o, e) : r ? Pn(r) !== t : void 0;
            }
            function Ee(e, t, n, r, i) {
                if (n && c(n)) {
                    var o;
                    Array.isArray(n) && (n = x(n));
                    for (var a in n) !function(a) {
                        if ("class" === a || "style" === a || bn(a)) o = e; else {
                            var s = e.attrs && e.attrs.type;
                            o = r || $n.mustUseProp(t, s, a) ? e.domProps || (e.domProps = {}) : e.attrs || (e.attrs = {});
                        }
                        var c = An(a), l = Pn(a);
                        c in o || l in o || (o[a] = n[a], !i) || ((e.on || (e.on = {}))["update:" + a] = function(e) {
                            n[a] = e;
                        });
                    }(a);
                }
                return e;
            }
            function Me(e, t) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[e];
                return r && !t || (r = n[e] = this.$options.staticRenderFns[e].call(this._renderProxy, null, this), 
                Re(r, "__static__" + e, !1)), r;
            }
            function Le(e, t, n) {
                return Re(e, "__once__" + t + (n ? "_" + n : ""), !0), e;
            }
            function Re(e, t, n) {
                if (Array.isArray(e)) for (var r = 0; r < e.length; r++) e[r] && "string" != typeof e[r] && Ie(e[r], t + "_" + r, n); else Ie(e, t, n);
            }
            function Ie(e, t, n) {
                e.isStatic = !0, e.key = t, e.isOnce = n;
            }
            function Fe(e, t) {
                if (t && l(t)) {
                    var n = e.on = e.on ? b({}, e.on) : {};
                    for (var r in t) {
                        var i = n[r], o = t[r];
                        n[r] = i ? [].concat(i, o) : o;
                    }
                }
                return e;
            }
            function Ne(e, t, n, r) {
                t = t || {
                    $stable: !n
                };
                for (var i = 0; i < e.length; i++) {
                    var o = e[i];
                    Array.isArray(o) ? Ne(o, t, n) : o && (o.proxy && (o.fn.proxy = !0), t[o.key] = o.fn);
                }
                return r && (t.$key = r), t;
            }
            function ze(e, t) {
                for (var n = 0; n < t.length; n += 2) {
                    var r = t[n];
                    "string" == typeof r && r && (e[t[n]] = t[n + 1]);
                }
                return e;
            }
            function Be(e, t) {
                return "string" == typeof e ? t + e : e;
            }
            function Ue(e) {
                e._o = Le, e._n = h, e._s = f, e._l = Te, e._t = Ce, e._q = A, e._i = S, e._m = Me, 
                e._f = De, e._k = $e, e._b = Ee, e._v = $, e._e = Zn, e._u = Ne, e._g = Fe, e._d = ze, 
                e._p = Be;
            }
            function We(e, t, n, r, i) {
                var a, s = this, c = i.options;
                m(r, "_uid") ? (a = Object.create(r), a._original = r) : (a = r, r = r._original);
                var l = o(c._compiled), u = !l;
                this.data = e, this.props = t, this.children = n, this.parent = r, this.listeners = e.on || mn, 
                this.injections = we(c.inject, r), this.slots = function() {
                    return s.$slots || ke(e.scopedSlots, s.$slots = Ae(n, r)), s.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return ke(e.scopedSlots, this.slots());
                    }
                }), l && (this.$options = c, this.$slots = this.slots(), this.$scopedSlots = ke(e.scopedSlots, this.$slots)), 
                c._scopeId ? this._c = function(e, t, n, i) {
                    var o = Qe(a, e, t, n, i, u);
                    return o && !Array.isArray(o) && (o.fnScopeId = c._scopeId, o.fnContext = r), o;
                } : this._c = function(e, t, n, r) {
                    return Qe(a, e, t, n, r, u);
                };
            }
            function He(e, t, n, r, o) {
                var a = e.options, s = {}, c = a.props;
                if (i(c)) for (var l in c) s[l] = Q(l, c, t || mn); else i(n.attrs) && Ve(s, n.attrs), 
                i(n.props) && Ve(s, n.props);
                var u = new We(n, s, o, r, e), p = a.render.call(null, u._c, u);
                if (p instanceof Kn) return qe(p, n, u.parent, a, u);
                if (Array.isArray(p)) {
                    for (var d = me(p) || [], f = new Array(d.length), h = 0; h < d.length; h++) f[h] = qe(d[h], n, u.parent, a, u);
                    return f;
                }
            }
            function qe(e, t, n, r, i) {
                var o = E(e);
                return o.fnContext = n, o.fnOptions = r, t.slot && ((o.data || (o.data = {})).slot = t.slot), 
                o;
            }
            function Ve(e, t) {
                for (var n in t) e[An(n)] = t[n];
            }
            function Xe(e, t, n, a, s) {
                if (!r(e)) {
                    var l = n.$options._base;
                    if (c(e) && (e = l.extend(e)), "function" == typeof e) {
                        var u;
                        if (r(e.cid) && (u = e, void 0 === (e = ot(u, l)))) return it(u, t, n, a, s);
                        t = t || {}, Nt(e), i(t.model) && Ke(e.options, t);
                        var p = he(t, e, s, n);
                        if (o(e.options.functional)) return He(e, p, t, n, a);
                        var d = t.on;
                        if (t.on = t.nativeOn, o(e.options.abstract)) {
                            var f = t.slot;
                            t = {}, f && (t.slot = f);
                        }
                        Ye(t);
                        var h = e.options.name || s;
                        return new Kn("vue-component-" + e.cid + (h ? "-" + h : ""), t, void 0, void 0, void 0, n, {
                            Ctor: e,
                            propsData: p,
                            listeners: d,
                            tag: s,
                            children: a
                        }, u);
                    }
                }
            }
            function Ge(e, t) {
                var n = {
                    _isComponent: !0,
                    _parentVnode: e,
                    parent: t
                }, r = e.data.inlineTemplate;
                return i(r) && (n.render = r.render, n.staticRenderFns = r.staticRenderFns), new e.componentOptions.Ctor(n);
            }
            function Ye(e) {
                for (var t = e.hook || (e.hook = {}), n = 0; n < yr.length; n++) {
                    var r = yr[n], i = t[r], o = mr[r];
                    i === o || i && i._merged || (t[r] = i ? Je(o, i) : o);
                }
            }
            function Je(e, t) {
                var n = function(n, r) {
                    e(n, r), t(n, r);
                };
                return n._merged = !0, n;
            }
            function Ke(e, t) {
                var n = e.model && e.model.prop || "value", r = e.model && e.model.event || "input";
                (t.attrs || (t.attrs = {}))[n] = t.model.value;
                var o = t.on || (t.on = {}), a = o[r], s = t.model.callback;
                i(a) ? (Array.isArray(a) ? -1 === a.indexOf(s) : a !== s) && (o[r] = [ s ].concat(a)) : o[r] = s;
            }
            function Qe(e, t, n, r, i, a) {
                return (Array.isArray(n) || s(n)) && (i = r, r = n, n = void 0), o(a) && (i = br), 
                Ze(e, t, n, r, i);
            }
            function Ze(e, t, n, r, o) {
                if (i(n) && i(n.__ob__)) return Zn();
                if (i(n) && i(n.is) && (t = n.is), !t) return Zn();
                var a, s, c;
                return Array.isArray(r) && "function" == typeof r[0] && (n = n || {}, n.scopedSlots = {
                    default: r[0]
                }, r.length = 0), o === br ? r = me(r) : o === _r && (r = ve(r)), "string" == typeof t ? (s = e.$vnode && e.$vnode.ns || $n.getTagNamespace(t), 
                a = $n.isReservedTag(t) ? new Kn($n.parsePlatformTagName(t), n, r, void 0, void 0, e) : n && n.pre || !i(c = K(e.$options, "components", t)) ? new Kn(t, n, r, void 0, void 0, e) : Xe(c, n, e, r, t)) : a = Xe(t, n, e, r), 
                Array.isArray(a) ? a : i(a) ? (i(s) && et(a, s), i(n) && tt(n), a) : Zn();
            }
            function et(e, t, n) {
                if (e.ns = t, "foreignObject" === e.tag && (t = void 0, n = !0), i(e.children)) for (var a = 0, s = e.children.length; a < s; a++) {
                    var c = e.children[a];
                    i(c.tag) && (r(c.ns) || o(n) && "svg" !== c.tag) && et(c, t, n);
                }
            }
            function tt(e) {
                c(e.style) && le(e.style), c(e.class) && le(e.class);
            }
            function nt(e) {
                e._vnode = null, e._staticTrees = null;
                var t = e.$options, n = e.$vnode = t._parentVnode, r = n && n.context;
                e.$slots = Ae(t._renderChildren, r), e.$scopedSlots = mn, e._c = function(t, n, r, i) {
                    return Qe(e, t, n, r, i, !1);
                }, e.$createElement = function(t, n, r, i) {
                    return Qe(e, t, n, r, i, !0);
                };
                var i = n && n.data;
                F(e, "$attrs", i && i.attrs || mn, null, !0), F(e, "$listeners", t._parentListeners || mn, null, !0);
            }
            function rt(e, t) {
                return (e.__esModule || Xn && "Module" === e[Symbol.toStringTag]) && (e = e.default), 
                c(e) ? t.extend(e) : e;
            }
            function it(e, t, n, r, i) {
                var o = Zn();
                return o.asyncFactory = e, o.asyncMeta = {
                    data: t,
                    context: n,
                    children: r,
                    tag: i
                }, o;
            }
            function ot(e, t) {
                if (o(e.error) && i(e.errorComp)) return e.errorComp;
                if (i(e.resolved)) return e.resolved;
                var n = xr;
                if (n && i(e.owners) && -1 === e.owners.indexOf(n) && e.owners.push(n), o(e.loading) && i(e.loadingComp)) return e.loadingComp;
                if (n && !i(e.owners)) {
                    var a = e.owners = [ n ], s = !0, l = null, u = null;
                    n.$on("hook:destroyed", function() {
                        return v(a, n);
                    });
                    var p = function(e) {
                        for (var t = 0, n = a.length; t < n; t++) a[t].$forceUpdate();
                        e && (a.length = 0, null !== l && (clearTimeout(l), l = null), null !== u && (clearTimeout(u), 
                        u = null));
                    }, f = k(function(n) {
                        e.resolved = rt(n, t), s ? a.length = 0 : p(!0);
                    }), h = k(function(t) {
                        i(e.errorComp) && (e.error = !0, p(!0));
                    }), g = e(f, h);
                    return c(g) && (d(g) ? r(e.resolved) && g.then(f, h) : d(g.component) && (g.component.then(f, h), 
                    i(g.error) && (e.errorComp = rt(g.error, t)), i(g.loading) && (e.loadingComp = rt(g.loading, t), 
                    0 === g.delay ? e.loading = !0 : l = setTimeout(function() {
                        l = null, r(e.resolved) && r(e.error) && (e.loading = !0, p(!1));
                    }, g.delay || 200)), i(g.timeout) && (u = setTimeout(function() {
                        u = null, r(e.resolved) && h(null);
                    }, g.timeout)))), s = !1, e.loading ? e.loadingComp : e.resolved;
                }
            }
            function at(e) {
                return e.isComment && e.asyncFactory;
            }
            function st(e) {
                if (Array.isArray(e)) for (var t = 0; t < e.length; t++) {
                    var n = e[t];
                    if (i(n) && (i(n.componentOptions) || at(n))) return n;
                }
            }
            function ct(e) {
                e._events = Object.create(null), e._hasHookEvent = !1;
                var t = e.$options._parentListeners;
                t && dt(e, t);
            }
            function lt(e, t) {
                vr.$on(e, t);
            }
            function ut(e, t) {
                vr.$off(e, t);
            }
            function pt(e, t) {
                var n = vr;
                return function r() {
                    null !== t.apply(null, arguments) && n.$off(e, r);
                };
            }
            function dt(e, t, n) {
                vr = e, de(t, n || {}, lt, ut, pt, e), vr = void 0;
            }
            function ft(e) {
                var t = wr;
                return wr = e, function() {
                    wr = t;
                };
            }
            function ht(e) {
                var t = e.$options, n = t.parent;
                if (n && !t.abstract) {
                    for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                    n.$children.push(e);
                }
                e.$parent = n, e.$root = n ? n.$root : e, e.$children = [], e.$refs = {}, e._watcher = null, 
                e._inactive = null, e._directInactive = !1, e._isMounted = !1, e._isDestroyed = !1, 
                e._isBeingDestroyed = !1;
            }
            function gt(e, t, n, r, i) {
                var o = r.data.scopedSlots, a = e.$scopedSlots, s = !!(o && !o.$stable || a !== mn && !a.$stable || o && e.$scopedSlots.$key !== o.$key), c = !!(i || e.$options._renderChildren || s);
                if (e.$options._parentVnode = r, e.$vnode = r, e._vnode && (e._vnode.parent = r), 
                e.$options._renderChildren = i, e.$attrs = r.data.attrs || mn, e.$listeners = n || mn, 
                t && e.$options.props) {
                    M(!1);
                    for (var l = e._props, u = e.$options._propKeys || [], p = 0; p < u.length; p++) {
                        var d = u[p], f = e.$options.props;
                        l[d] = Q(d, f, t, e);
                    }
                    M(!0), e.$options.propsData = t;
                }
                e._$updateProperties && e._$updateProperties(e), n = n || mn;
                var h = e.$options._parentListeners;
                e.$options._parentListeners = n, dt(e, n, h), c && (e.$slots = Ae(i, r.context), 
                e.$forceUpdate());
            }
            function vt(e) {
                for (;e && (e = e.$parent); ) if (e._inactive) return !0;
                return !1;
            }
            function mt(e, t) {
                if (t) {
                    if (e._directInactive = !1, vt(e)) return;
                } else if (e._directInactive) return;
                if (e._inactive || null === e._inactive) {
                    e._inactive = !1;
                    for (var n = 0; n < e.$children.length; n++) mt(e.$children[n]);
                    _t(e, "activated");
                }
            }
            function yt(e, t) {
                if (!(t && (e._directInactive = !0, vt(e)) || e._inactive)) {
                    e._inactive = !0;
                    for (var n = 0; n < e.$children.length; n++) yt(e.$children[n]);
                    _t(e, "deactivated");
                }
            }
            function _t(e, t) {
                D();
                var n = e.$options[t], r = t + " hook";
                if (n) for (var i = 0, o = n.length; i < o; i++) ie(n[i], e, null, e, r);
                e._hasHookEvent && e.$emit("hook:" + t), j();
            }
            function bt() {
                Tr = Ar.length = Sr.length = 0, kr = {}, Pr = Or = !1;
            }
            function xt() {
                var e, t;
                for (Cr(), Or = !0, Ar.sort(function(e, t) {
                    return e.id - t.id;
                }), Tr = 0; Tr < Ar.length; Tr++) (e = Ar[Tr]).before && e.before(), t = e.id, kr[t] = null, 
                e.run();
                var n = Sr.slice(), r = Ar.slice();
                bt(), St(n), wt(r), Vn && $n.devtools && Vn.emit("flush");
            }
            function wt(e) {
                for (var t = e.length; t--; ) {
                    var n = e[t], r = n.vm;
                    r._watcher === n && r._isMounted && !r._isDestroyed && _t(r, "updated");
                }
            }
            function At(e) {
                e._inactive = !1, Sr.push(e);
            }
            function St(e) {
                for (var t = 0; t < e.length; t++) e[t]._inactive = !0, mt(e[t], !0);
            }
            function kt(e) {
                var t = e.id;
                if (null == kr[t]) {
                    if (kr[t] = !0, Or) {
                        for (var n = Ar.length - 1; n > Tr && Ar[n].id > e.id; ) n--;
                        Ar.splice(n + 1, 0, e);
                    } else Ar.push(e);
                    Pr || (Pr = !0, ce(xt));
                }
            }
            function Pt(e, t, n) {
                Er.get = function() {
                    return this[t][n];
                }, Er.set = function(e) {
                    this[t][n] = e;
                }, Object.defineProperty(e, n, Er);
            }
            function Ot(e) {
                e._watchers = [];
                var t = e.$options;
                t.props && Tt(e, t.props), t.methods && Lt(e, t.methods), t.data ? Ct(e) : I(e._data = {}, !0), 
                t.computed && jt(e, t.computed), t.watch && t.watch !== Un && Rt(e, t.watch);
            }
            function Tt(e, t) {
                var n = e.$options.propsData || {}, r = e._props = {}, i = e.$options._propKeys = [];
                !e.$parent || M(!1);
                for (var o in t) !function(o) {
                    i.push(o);
                    var a = Q(o, t, n, e);
                    F(r, o, a), o in e || Pt(e, "_props", o);
                }(o);
                M(!0);
            }
            function Ct(e) {
                var t = e.$options.data;
                l(t = e._data = "function" == typeof t ? Dt(t, e) : t || {}) || (t = {});
                for (var n = Object.keys(t), r = e.$options.props, i = (e.$options.methods, n.length); i--; ) {
                    var o = n[i];
                    r && m(r, o) || P(o) || Pt(e, "_data", o);
                }
                I(t, !0);
            }
            function Dt(e, t) {
                D();
                try {
                    return e.call(t, t);
                } catch (e) {
                    return re(e, t, "data()"), {};
                } finally {
                    j();
                }
            }
            function jt(e, t) {
                var n = e._computedWatchers = Object.create(null), r = qn();
                for (var i in t) {
                    var o = t[i], a = "function" == typeof o ? o : o.get;
                    r || (n[i] = new $r(e, a || w, w, Mr)), i in e || $t(e, i, o);
                }
            }
            function $t(e, t, n) {
                var r = !qn();
                "function" == typeof n ? (Er.get = r ? Et(t) : Mt(n), Er.set = w) : (Er.get = n.get ? r && !1 !== n.cache ? Et(t) : Mt(n.get) : w, 
                Er.set = n.set || w), Object.defineProperty(e, t, Er);
            }
            function Et(e) {
                return function() {
                    var t = this._computedWatchers && this._computedWatchers[e];
                    if (t) return t.dirty && t.evaluate(), Jn.SharedObject.target && t.depend(), t.value;
                };
            }
            function Mt(e) {
                return function() {
                    return e.call(this, this);
                };
            }
            function Lt(e, t) {
                e.$options.props;
                for (var n in t) e[n] = "function" != typeof t[n] ? w : On(t[n], e);
            }
            function Rt(e, t) {
                for (var n in t) {
                    var r = t[n];
                    if (Array.isArray(r)) for (var i = 0; i < r.length; i++) It(e, n, r[i]); else It(e, n, r);
                }
            }
            function It(e, t, n, r) {
                return l(n) && (r = n, n = n.handler), "string" == typeof n && (n = e[n]), e.$watch(t, n, r);
            }
            function Ft(e, t) {
                var n = e.$options = Object.create(e.constructor.options), r = t._parentVnode;
                n.parent = t.parent, n._parentVnode = r;
                var i = r.componentOptions;
                n.propsData = i.propsData, n._parentListeners = i.listeners, n._renderChildren = i.children, 
                n._componentTag = i.tag, t.render && (n.render = t.render, n.staticRenderFns = t.staticRenderFns);
            }
            function Nt(e) {
                var t = e.options;
                if (e.super) {
                    var n = Nt(e.super);
                    if (n !== e.superOptions) {
                        e.superOptions = n;
                        var r = zt(e);
                        r && b(e.extendOptions, r), (t = e.options = J(n, e.extendOptions)).name && (t.components[t.name] = e);
                    }
                }
                return t;
            }
            function zt(e) {
                var t, n = e.options, r = e.sealedOptions;
                for (var i in n) n[i] !== r[i] && (t || (t = {}), t[i] = n[i]);
                return t;
            }
            function Bt(e) {
                this._init(e);
            }
            function Ut(e) {
                e.use = function(e) {
                    var t = this._installedPlugins || (this._installedPlugins = []);
                    if (t.indexOf(e) > -1) return this;
                    var n = _(arguments, 1);
                    return n.unshift(this), "function" == typeof e.install ? e.install.apply(e, n) : "function" == typeof e && e.apply(null, n), 
                    t.push(e), this;
                };
            }
            function Wt(e) {
                e.mixin = function(e) {
                    return this.options = J(this.options, e), this;
                };
            }
            function Ht(e) {
                e.cid = 0;
                var t = 1;
                e.extend = function(e) {
                    e = e || {};
                    var n = this, r = n.cid, i = e._Ctor || (e._Ctor = {});
                    if (i[r]) return i[r];
                    var o = e.name || n.options.name, a = function(e) {
                        this._init(e);
                    };
                    return a.prototype = Object.create(n.prototype), a.prototype.constructor = a, a.cid = t++, 
                    a.options = J(n.options, e), a.super = n, a.options.props && qt(a), a.options.computed && Vt(a), 
                    a.extend = n.extend, a.mixin = n.mixin, a.use = n.use, Dn.forEach(function(e) {
                        a[e] = n[e];
                    }), o && (a.options.components[o] = a), a.superOptions = n.options, a.extendOptions = e, 
                    a.sealedOptions = b({}, a.options), i[r] = a, a;
                };
            }
            function qt(e) {
                var t = e.options.props;
                for (var n in t) Pt(e.prototype, "_props", n);
            }
            function Vt(e) {
                var t = e.options.computed;
                for (var n in t) $t(e.prototype, n, t[n]);
            }
            function Xt(e) {
                Dn.forEach(function(t) {
                    e[t] = function(e, n) {
                        return n ? ("component" === t && l(n) && (n.name = n.name || e, n = this.options._base.extend(n)), 
                        "directive" === t && "function" == typeof n && (n = {
                            bind: n,
                            update: n
                        }), this.options[t + "s"][e] = n, n) : this.options[t + "s"][e];
                    };
                });
            }
            function Gt(e) {
                return e && (e.Ctor.options.name || e.tag);
            }
            function Yt(e, t) {
                return Array.isArray(e) ? e.indexOf(t) > -1 : "string" == typeof e ? e.split(",").indexOf(t) > -1 : !!u(e) && e.test(t);
            }
            function Jt(e, t) {
                var n = e.cache, r = e.keys, i = e._vnode;
                for (var o in n) {
                    var a = n[o];
                    if (a) {
                        var s = Gt(a.componentOptions);
                        s && !t(s) && Kt(n, o, r, i);
                    }
                }
            }
            function Kt(e, t, n, r) {
                var i = e[t];
                !i || r && i.tag === r.tag || i.componentInstance.$destroy(), e[t] = null, v(n, t);
            }
            function Qt(e, t) {
                var n = {};
                return Zt(e, t), en(e, t, "", n), n;
            }
            function Zt(e, t) {
                if (e !== t) {
                    var n = nn(e), r = nn(t);
                    if (n == Nr && r == Nr) {
                        if (Object.keys(e).length >= Object.keys(t).length) for (var i in t) {
                            var o = e[i];
                            void 0 === o ? e[i] = null : Zt(o, t[i]);
                        }
                    } else n == Fr && r == Fr && e.length >= t.length && t.forEach(function(t, n) {
                        Zt(e[n], t);
                    });
                }
            }
            function en(e, t, n, r) {
                if (e !== t) {
                    var i = nn(e), o = nn(t);
                    if (i == Nr) if (o != Nr || Object.keys(e).length < Object.keys(t).length) tn(r, n, e); else {
                        for (var a in e) !function(i) {
                            var o = e[i], a = t[i], s = nn(o), c = nn(a);
                            if (s != Fr && s != Nr) o !== t[i] && tn(r, ("" == n ? "" : n + ".") + i, o); else if (s == Fr) c != Fr || o.length < a.length ? tn(r, ("" == n ? "" : n + ".") + i, o) : o.forEach(function(e, t) {
                                en(e, a[t], ("" == n ? "" : n + ".") + i + "[" + t + "]", r);
                            }); else if (s == Nr) if (c != Nr || Object.keys(o).length < Object.keys(a).length) tn(r, ("" == n ? "" : n + ".") + i, o); else for (var l in o) en(o[l], a[l], ("" == n ? "" : n + ".") + i + "." + l, r);
                        }(a);
                    } else i == Fr ? o != Fr || e.length < t.length ? tn(r, n, e) : e.forEach(function(e, i) {
                        en(e, t[i], n + "[" + i + "]", r);
                    }) : tn(r, n, e);
                }
            }
            function tn(e, t, n) {
                e[t] = n;
            }
            function nn(e) {
                return Object.prototype.toString.call(e);
            }
            function rn(e) {
                if (e.__next_tick_callbacks && e.__next_tick_callbacks.length) {
                    if (Object({
                        NODE_ENV: "production",
                        VUE_APP_NAME: "",
                        VUE_APP_PLATFORM: "mp-weixin",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var t = e.$scope;
                        console.log("[" + +new Date() + "][" + (t.is || t.route) + "][" + e._uid + "]:flushCallbacks[" + e.__next_tick_callbacks.length + "]");
                    }
                    var n = e.__next_tick_callbacks.slice(0);
                    e.__next_tick_callbacks.length = 0;
                    for (var r = 0; r < n.length; r++) n[r]();
                }
            }
            function on(e) {
                return Ar.find(function(t) {
                    return e._watcher === t;
                });
            }
            function an(e, t) {
                if (!e.__next_tick_pending && !on(e)) {
                    if (Object({
                        NODE_ENV: "production",
                        VUE_APP_NAME: "",
                        VUE_APP_PLATFORM: "mp-weixin",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var n = e.$scope;
                        console.log("[" + +new Date() + "][" + (n.is || n.route) + "][" + e._uid + "]:nextVueTick");
                    }
                    return ce(t, e);
                }
                if (Object({
                    NODE_ENV: "production",
                    VUE_APP_NAME: "",
                    VUE_APP_PLATFORM: "mp-weixin",
                    BASE_URL: "/"
                }).VUE_APP_DEBUG) {
                    var r = e.$scope;
                    console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + e._uid + "]:nextMPTick");
                }
                var i;
                if (e.__next_tick_callbacks || (e.__next_tick_callbacks = []), e.__next_tick_callbacks.push(function() {
                    if (t) try {
                        t.call(e);
                    } catch (t) {
                        re(t, e, "nextTick");
                    } else i && i(e);
                }), !t && "undefined" != typeof Promise) return new Promise(function(e) {
                    i = e;
                });
            }
            function sn(e) {
                var t = Object.create(null);
                [].concat(Object.keys(e._data || {}), Object.keys(e._computedWatchers || {})).reduce(function(t, n) {
                    return t[n] = e[n], t;
                }, t);
                var n = e.__composition_api_state__ || e.__secret_vfa_state__, r = n && n.rawBindings;
                return r && Object.keys(r).forEach(function(n) {
                    t[n] = e[n];
                }), Object.assign(t, e.$mp.data || {}), Array.isArray(e.$options.behaviors) && -1 !== e.$options.behaviors.indexOf("uni://form-field") && (t.name = e.name, 
                t.value = e.value), JSON.parse(JSON.stringify(t));
            }
            function cn() {}
            function ln(e, t, n) {
                if (!e.mpType) return e;
                "app" === e.mpType && (e.$options.render = cn), e.$options.render || (e.$options.render = cn), 
                !e._$fallback && _t(e, "beforeMount");
                return new $r(e, function() {
                    e._update(e._render(), n);
                }, w, {
                    before: function() {
                        e._isMounted && !e._isDestroyed && _t(e, "beforeUpdate");
                    }
                }, !0), n = !1, e;
            }
            function un(e, t) {
                return i(e) || i(t) ? pn(e, dn(t)) : "";
            }
            function pn(e, t) {
                return e ? t ? e + " " + t : e : t || "";
            }
            function dn(e) {
                return Array.isArray(e) ? fn(e) : c(e) ? hn(e) : "string" == typeof e ? e : "";
            }
            function fn(e) {
                for (var t, n = "", r = 0, o = e.length; r < o; r++) i(t = dn(e[r])) && "" !== t && (n && (n += " "), 
                n += t);
                return n;
            }
            function hn(e) {
                var t = "";
                for (var n in e) e[n] && (t && (t += " "), t += n);
                return t;
            }
            function gn(e) {
                return Array.isArray(e) ? x(e) : "string" == typeof e ? zr(e) : e;
            }
            function vn(e, t) {
                var n = t.split("."), r = n[0];
                return 0 === r.indexOf("__$n") && (r = parseInt(r.replace("__$n", ""))), 1 === n.length ? e[r] : vn(e[r], n.slice(1).join("."));
            }
            var mn = Object.freeze({}), yn = Object.prototype.toString;
            g("slot,component", !0);
            var _n, bn = g("key,ref,slot,slot-scope,is"), xn = Object.prototype.hasOwnProperty, wn = /-(\w)/g, An = y(function(e) {
                return e.replace(wn, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            }), Sn = y(function(e) {
                return e.charAt(0).toUpperCase() + e.slice(1);
            }), kn = /\B([A-Z])/g, Pn = y(function(e) {
                return e.replace(kn, "-$1").toLowerCase();
            }), On = Function.prototype.bind ? function(e, t) {
                return e.bind(t);
            } : function(e, t) {
                function n(n) {
                    var r = arguments.length;
                    return r ? r > 1 ? e.apply(t, arguments) : e.call(t, n) : e.call(t);
                }
                return n._length = e.length, n;
            }, Tn = function(e, t, n) {
                return !1;
            }, Cn = function(e) {
                return e;
            }, Dn = [ "component", "directive", "filter" ], jn = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], $n = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: Tn,
                isReservedAttr: Tn,
                isUnknownElement: Tn,
                getTagNamespace: w,
                parsePlatformTagName: Cn,
                mustUseProp: Tn,
                async: !0,
                _lifecycleHooks: jn
            }, En = /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/, Mn = new RegExp("[^" + En.source + ".$_\\d]"), Ln = "__proto__" in {}, Rn = "undefined" != typeof window, In = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, Fn = In && WXEnvironment.platform.toLowerCase(), Nn = Rn && window.navigator.userAgent.toLowerCase(), zn = Nn && /msie|trident/.test(Nn), Bn = (Nn && Nn.indexOf("msie 9.0"), 
            Nn && Nn.indexOf("edge/"), Nn && Nn.indexOf("android"), Nn && /iphone|ipad|ipod|ios/.test(Nn) || "ios" === Fn), Un = (Nn && /chrome\/\d+/.test(Nn), 
            Nn && /phantomjs/.test(Nn), Nn && Nn.match(/firefox\/(\d+)/), {}.watch);
            if (Rn) try {
                var Wn = {};
                Object.defineProperty(Wn, "passive", {
                    get: function() {}
                }), window.addEventListener("test-passive", null, Wn);
            } catch (e) {}
            var Hn, qn = function() {
                return void 0 === _n && (_n = !Rn && !In && void 0 !== t && t.process && "server" === t.process.env.VUE_ENV), 
                _n;
            }, Vn = Rn && window.__VUE_DEVTOOLS_GLOBAL_HOOK__, Xn = "undefined" != typeof Symbol && C(Symbol) && "undefined" != typeof Reflect && C(Reflect.ownKeys);
            Hn = "undefined" != typeof Set && C(Set) ? Set : function() {
                function e() {
                    this.set = Object.create(null);
                }
                return e.prototype.has = function(e) {
                    return !0 === this.set[e];
                }, e.prototype.add = function(e) {
                    this.set[e] = !0;
                }, e.prototype.clear = function() {
                    this.set = Object.create(null);
                }, e;
            }();
            var Gn = w, Yn = 0, Jn = function() {
                this.id = Yn++, this.subs = [];
            };
            Jn.prototype.addSub = function(e) {
                this.subs.push(e);
            }, Jn.prototype.removeSub = function(e) {
                v(this.subs, e);
            }, Jn.prototype.depend = function() {
                Jn.SharedObject.target && Jn.SharedObject.target.addDep(this);
            }, Jn.prototype.notify = function() {
                for (var e = this.subs.slice(), t = 0, n = e.length; t < n; t++) e[t].update();
            }, Jn.SharedObject = {}, Jn.SharedObject.target = null, Jn.SharedObject.targetStack = [];
            var Kn = function(e, t, n, r, i, o, a, s) {
                this.tag = e, this.data = t, this.children = n, this.text = r, this.elm = i, this.ns = void 0, 
                this.context = o, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = t && t.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = s, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, Qn = {
                child: {
                    configurable: !0
                }
            };
            Qn.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(Kn.prototype, Qn);
            var Zn = function(e) {
                void 0 === e && (e = "");
                var t = new Kn();
                return t.text = e, t.isComment = !0, t;
            }, er = Array.prototype, tr = Object.create(er);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(e) {
                var t = er[e];
                O(tr, e, function() {
                    for (var n = [], r = arguments.length; r--; ) n[r] = arguments[r];
                    var i, o = t.apply(this, n), a = this.__ob__;
                    switch (e) {
                      case "push":
                      case "unshift":
                        i = n;
                        break;

                      case "splice":
                        i = n.slice(2);
                    }
                    return i && a.observeArray(i), a.dep.notify(), o;
                });
            });
            var nr = Object.getOwnPropertyNames(tr), rr = !0, ir = function(e) {
                this.value = e, this.dep = new Jn(), this.vmCount = 0, O(e, "__ob__", this), Array.isArray(e) ? (Ln ? e.push !== e.__proto__.push ? R(e, tr, nr) : L(e, tr) : R(e, tr, nr), 
                this.observeArray(e)) : this.walk(e);
            };
            ir.prototype.walk = function(e) {
                for (var t = Object.keys(e), n = 0; n < t.length; n++) F(e, t[n]);
            }, ir.prototype.observeArray = function(e) {
                for (var t = 0, n = e.length; t < n; t++) I(e[t]);
            };
            var or = $n.optionMergeStrategies;
            or.data = function(e, t, n) {
                return n ? W(e, t, n) : t && "function" != typeof t ? e : W(e, t);
            }, jn.forEach(function(e) {
                or[e] = H;
            }), Dn.forEach(function(e) {
                or[e + "s"] = V;
            }), or.watch = function(e, t, n, r) {
                if (e === Un && (e = void 0), t === Un && (t = void 0), !t) return Object.create(e || null);
                if (!e) return t;
                var i = {};
                for (var o in b(i, e), t) {
                    var a = i[o], s = t[o];
                    a && !Array.isArray(a) && (a = [ a ]), i[o] = a ? a.concat(s) : Array.isArray(s) ? s : [ s ];
                }
                return i;
            }, or.props = or.methods = or.inject = or.computed = function(e, t, n, r) {
                if (!e) return t;
                var i = Object.create(null);
                return b(i, e), t && b(i, t), i;
            }, or.provide = W;
            var ar, sr = function(e, t) {
                return void 0 === t ? e : t;
            }, cr = [], lr = !1;
            if ("undefined" != typeof Promise && C(Promise)) {
                var ur = Promise.resolve();
                ar = function() {
                    ur.then(se), Bn && setTimeout(w);
                };
            } else if (zn || "undefined" == typeof MutationObserver || !C(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString()) ar = "undefined" != typeof setImmediate && C(setImmediate) ? function() {
                setImmediate(se);
            } : function() {
                setTimeout(se, 0);
            }; else {
                var pr = 1, dr = new MutationObserver(se), fr = document.createTextNode(String(pr));
                dr.observe(fr, {
                    characterData: !0
                }), ar = function() {
                    pr = (pr + 1) % 2, fr.data = String(pr);
                };
            }
            var hr = new Hn(), gr = y(function(e) {
                var t = "&" === e.charAt(0), n = "~" === (e = t ? e.slice(1) : e).charAt(0), r = "!" === (e = n ? e.slice(1) : e).charAt(0);
                return e = r ? e.slice(1) : e, {
                    name: e,
                    once: n,
                    capture: r,
                    passive: t
                };
            });
            Ue(We.prototype);
            var vr, mr = {
                init: function(e, t) {
                    if (e.componentInstance && !e.componentInstance._isDestroyed && e.data.keepAlive) {
                        var n = e;
                        mr.prepatch(n, n);
                    } else (e.componentInstance = Ge(e, wr)).$mount(t ? e.elm : void 0, t);
                },
                prepatch: function(e, t) {
                    var n = t.componentOptions;
                    gt(t.componentInstance = e.componentInstance, n.propsData, n.listeners, t, n.children);
                },
                insert: function(e) {
                    var t = e.context, n = e.componentInstance;
                    n._isMounted || (_t(n, "onServiceCreated"), _t(n, "onServiceAttached"), n._isMounted = !0, 
                    _t(n, "mounted")), e.data.keepAlive && (t._isMounted ? At(n) : mt(n, !0));
                },
                destroy: function(e) {
                    var t = e.componentInstance;
                    t._isDestroyed || (e.data.keepAlive ? yt(t, !0) : t.$destroy());
                }
            }, yr = Object.keys(mr), _r = 1, br = 2, xr = null, wr = null, Ar = [], Sr = [], kr = {}, Pr = !1, Or = !1, Tr = 0, Cr = Date.now;
            if (Rn && !zn) {
                var Dr = window.performance;
                Dr && "function" == typeof Dr.now && Cr() > document.createEvent("Event").timeStamp && (Cr = function() {
                    return Dr.now();
                });
            }
            var jr = 0, $r = function(e, t, n, r, i) {
                this.vm = e, i && (e._watcher = this), e._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++jr, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new Hn(), this.newDepIds = new Hn(), this.expression = "", 
                "function" == typeof t ? this.getter = t : (this.getter = T(t), this.getter || (this.getter = w)), 
                this.value = this.lazy ? void 0 : this.get();
            };
            $r.prototype.get = function() {
                var e;
                D(this);
                var t = this.vm;
                try {
                    e = this.getter.call(t, t);
                } catch (e) {
                    if (!this.user) throw e;
                    re(e, t, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && le(e), j(), this.cleanupDeps();
                }
                return e;
            }, $r.prototype.addDep = function(e) {
                var t = e.id;
                this.newDepIds.has(t) || (this.newDepIds.add(t), this.newDeps.push(e), this.depIds.has(t) || e.addSub(this));
            }, $r.prototype.cleanupDeps = function() {
                for (var e = this.deps.length; e--; ) {
                    var t = this.deps[e];
                    this.newDepIds.has(t.id) || t.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, $r.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : kt(this);
            }, $r.prototype.run = function() {
                if (this.active) {
                    var e = this.get();
                    if (e !== this.value || c(e) || this.deep) {
                        var t = this.value;
                        if (this.value = e, this.user) try {
                            this.cb.call(this.vm, e, t);
                        } catch (e) {
                            re(e, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, e, t);
                    }
                }
            }, $r.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, $r.prototype.depend = function() {
                for (var e = this.deps.length; e--; ) this.deps[e].depend();
            }, $r.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || v(this.vm._watchers, this);
                    for (var e = this.deps.length; e--; ) this.deps[e].removeSub(this);
                    this.active = !1;
                }
            };
            var Er = {
                enumerable: !0,
                configurable: !0,
                get: w,
                set: w
            }, Mr = {
                lazy: !0
            }, Lr = 0;
            (function(e) {
                e.prototype._init = function(e) {
                    var t = this;
                    t._uid = Lr++, t._isVue = !0, e && e._isComponent ? Ft(t, e) : t.$options = J(Nt(t.constructor), e || {}, t), 
                    t._renderProxy = t, t._self = t, ht(t), ct(t), nt(t), _t(t, "beforeCreate"), !t._$fallback && xe(t), 
                    Ot(t), !t._$fallback && be(t), !t._$fallback && _t(t, "created"), t.$options.el && t.$mount(t.$options.el);
                };
            })(Bt), function(e) {
                var t = {
                    get: function() {
                        return this._data;
                    }
                }, n = {
                    get: function() {
                        return this._props;
                    }
                };
                Object.defineProperty(e.prototype, "$data", t), Object.defineProperty(e.prototype, "$props", n), 
                e.prototype.$set = N, e.prototype.$delete = z, e.prototype.$watch = function(e, t, n) {
                    var r = this;
                    if (l(t)) return It(r, e, t, n);
                    (n = n || {}).user = !0;
                    var i = new $r(r, e, t, n);
                    if (n.immediate) try {
                        t.call(r, i.value);
                    } catch (e) {
                        re(e, r, 'callback for immediate watcher "' + i.expression + '"');
                    }
                    return function() {
                        i.teardown();
                    };
                };
            }(Bt), function(e) {
                var t = /^hook:/;
                e.prototype.$on = function(e, n) {
                    var r = this;
                    if (Array.isArray(e)) for (var i = 0, o = e.length; i < o; i++) r.$on(e[i], n); else (r._events[e] || (r._events[e] = [])).push(n), 
                    t.test(e) && (r._hasHookEvent = !0);
                    return r;
                }, e.prototype.$once = function(e, t) {
                    function n() {
                        r.$off(e, n), t.apply(r, arguments);
                    }
                    var r = this;
                    return n.fn = t, r.$on(e, n), r;
                }, e.prototype.$off = function(e, t) {
                    var n = this;
                    if (!arguments.length) return n._events = Object.create(null), n;
                    if (Array.isArray(e)) {
                        for (var r = 0, i = e.length; r < i; r++) n.$off(e[r], t);
                        return n;
                    }
                    var o, a = n._events[e];
                    if (!a) return n;
                    if (!t) return n._events[e] = null, n;
                    for (var s = a.length; s--; ) if ((o = a[s]) === t || o.fn === t) {
                        a.splice(s, 1);
                        break;
                    }
                    return n;
                }, e.prototype.$emit = function(e) {
                    var t = this, n = t._events[e];
                    if (n) {
                        n = n.length > 1 ? _(n) : n;
                        for (var r = _(arguments, 1), i = 'event handler for "' + e + '"', o = 0, a = n.length; o < a; o++) ie(n[o], t, r, t, i);
                    }
                    return t;
                };
            }(Bt), function(e) {
                e.prototype._update = function(e, t) {
                    var n = this, r = n.$el, i = n._vnode, o = ft(n);
                    n._vnode = e, n.$el = i ? n.__patch__(i, e) : n.__patch__(n.$el, e, t, !1), o(), 
                    r && (r.__vue__ = null), n.$el && (n.$el.__vue__ = n), n.$vnode && n.$parent && n.$vnode === n.$parent._vnode && (n.$parent.$el = n.$el);
                }, e.prototype.$forceUpdate = function() {
                    var e = this;
                    e._watcher && e._watcher.update();
                }, e.prototype.$destroy = function() {
                    var e = this;
                    if (!e._isBeingDestroyed) {
                        _t(e, "beforeDestroy"), e._isBeingDestroyed = !0;
                        var t = e.$parent;
                        !t || t._isBeingDestroyed || e.$options.abstract || v(t.$children, e), e._watcher && e._watcher.teardown();
                        for (var n = e._watchers.length; n--; ) e._watchers[n].teardown();
                        e._data.__ob__ && e._data.__ob__.vmCount--, e._isDestroyed = !0, e.__patch__(e._vnode, null), 
                        _t(e, "destroyed"), e.$off(), e.$el && (e.$el.__vue__ = null), e.$vnode && (e.$vnode.parent = null);
                    }
                };
            }(Bt), function(e) {
                Ue(e.prototype), e.prototype.$nextTick = function(e) {
                    return ce(e, this);
                }, e.prototype._render = function() {
                    var e, t = this, n = t.$options, r = n.render, i = n._parentVnode;
                    i && (t.$scopedSlots = ke(i.data.scopedSlots, t.$slots, t.$scopedSlots)), t.$vnode = i;
                    try {
                        xr = t, e = r.call(t._renderProxy, t.$createElement);
                    } catch (n) {
                        re(n, t, "render"), e = t._vnode;
                    } finally {
                        xr = null;
                    }
                    return Array.isArray(e) && 1 === e.length && (e = e[0]), e instanceof Kn || (e = Zn()), 
                    e.parent = i, e;
                };
            }(Bt);
            var Rr = [ String, RegExp, Array ], Ir = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: Rr,
                        exclude: Rr,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var e in this.cache) Kt(this.cache, e, this.keys);
                    },
                    mounted: function() {
                        var e = this;
                        this.$watch("include", function(t) {
                            Jt(e, function(e) {
                                return Yt(t, e);
                            });
                        }), this.$watch("exclude", function(t) {
                            Jt(e, function(e) {
                                return !Yt(t, e);
                            });
                        });
                    },
                    render: function() {
                        var e = this.$slots.default, t = st(e), n = t && t.componentOptions;
                        if (n) {
                            var r = Gt(n), i = this, o = i.include, a = i.exclude;
                            if (o && (!r || !Yt(o, r)) || a && r && Yt(a, r)) return t;
                            var s = this, c = s.cache, l = s.keys, u = null == t.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : t.key;
                            c[u] ? (t.componentInstance = c[u].componentInstance, v(l, u), l.push(u)) : (c[u] = t, 
                            l.push(u), this.max && l.length > parseInt(this.max) && Kt(c, l[0], l, this._vnode)), 
                            t.data.keepAlive = !0;
                        }
                        return t || e && e[0];
                    }
                }
            };
            (function(e) {
                var t = {
                    get: function() {
                        return $n;
                    }
                };
                Object.defineProperty(e, "config", t), e.util = {
                    warn: Gn,
                    extend: b,
                    mergeOptions: J,
                    defineReactive: F
                }, e.set = N, e.delete = z, e.nextTick = ce, e.observable = function(e) {
                    return I(e), e;
                }, e.options = Object.create(null), Dn.forEach(function(t) {
                    e.options[t + "s"] = Object.create(null);
                }), e.options._base = e, b(e.options.components, Ir), Ut(e), Wt(e), Ht(e), Xt(e);
            })(Bt), Object.defineProperty(Bt.prototype, "$isServer", {
                get: qn
            }), Object.defineProperty(Bt.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(Bt, "FunctionalRenderContext", {
                value: We
            }), Bt.version = "2.6.11";
            var Fr = "[object Array]", Nr = "[object Object]", zr = y(function(e) {
                var t = {}, n = /;(?![^(]*\))/g, r = /:(.+)/;
                return e.split(n).forEach(function(e) {
                    if (e) {
                        var n = e.split(r);
                        n.length > 1 && (t[n[0].trim()] = n[1].trim());
                    }
                }), t;
            }), Br = [ "createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent" ], Ur = [ "onLaunch", "onShow", "onHide", "onUniNViewMessage", "onPageNotFound", "onThemeChange", "onError", "onUnhandledRejection", "onInit", "onLoad", "onReady", "onUnload", "onPullDownRefresh", "onReachBottom", "onTabItemTap", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onResize", "onPageScroll", "onNavigationBarButtonTap", "onBackPress", "onNavigationBarSearchInputChanged", "onNavigationBarSearchInputConfirmed", "onNavigationBarSearchInputClicked", "onPageShow", "onPageHide", "onPageResize" ];
            Bt.prototype.__patch__ = function(e, t) {
                var n = this;
                if (null !== t && ("page" === this.mpType || "component" === this.mpType)) {
                    var r = this.$scope, i = Object.create(null);
                    try {
                        i = sn(this);
                    } catch (e) {
                        console.error(e);
                    }
                    i.__webviewId__ = r.data.__webviewId__;
                    var o = Object.create(null);
                    Object.keys(i).forEach(function(e) {
                        o[e] = r.data[e];
                    });
                    var a = !1 === this.$shouldDiffData ? i : Qt(i, o);
                    Object.keys(a).length ? (Object({
                        NODE_ENV: "production",
                        VUE_APP_NAME: "",
                        VUE_APP_PLATFORM: "mp-weixin",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + this._uid + "]差量更新", JSON.stringify(a)), 
                    this.__next_tick_pending = !0, r.setData(a, function() {
                        n.__next_tick_pending = !1, rn(n);
                    })) : rn(this);
                }
            }, Bt.prototype.$mount = function(e, t) {
                return ln(this, 0, t);
            }, function(e) {
                var t = e.extend;
                e.extend = function(e) {
                    var n = (e = e || {}).methods;
                    return n && Object.keys(n).forEach(function(t) {
                        -1 !== Ur.indexOf(t) && (e[t] = n[t], delete n[t]);
                    }), t.call(this, e);
                };
                var n = e.config.optionMergeStrategies, r = n.created;
                Ur.forEach(function(e) {
                    n[e] = r;
                }), e.prototype.__lifecycle_hooks__ = Ur;
            }(Bt), function(e) {
                e.config.errorHandler = function(t, n, r) {
                    e.util.warn("Error in " + r + ': "' + t.toString() + '"', n), console.error(t);
                    var i = "function" == typeof getApp && getApp();
                    i && i.onError && i.onError(t);
                };
                var t = e.prototype.$emit;
                e.prototype.$emit = function(e) {
                    return this.$scope && e && this.$scope.triggerEvent(e, {
                        __args__: _(arguments, 1)
                    }), t.apply(this, arguments);
                }, e.prototype.$nextTick = function(e) {
                    return an(this, e);
                }, Br.forEach(function(t) {
                    e.prototype[t] = function(e) {
                        return this.$scope && this.$scope[t] ? this.$scope[t](e) : "undefined" != typeof my ? "createSelectorQuery" === t ? my.createSelectorQuery(e) : "createIntersectionObserver" === t ? my.createIntersectionObserver(e) : void 0 : void 0;
                    };
                }), e.prototype.__init_provide = be, e.prototype.__init_injections = xe, e.prototype.__call_hook = function(e, t) {
                    var n = this;
                    D();
                    var r, i = n.$options[e], o = e + " hook";
                    if (i) for (var a = 0, s = i.length; a < s; a++) r = ie(i[a], n, t ? [ t ] : null, n, o);
                    return n._hasHookEvent && n.$emit("hook:" + e, t), j(), r;
                }, e.prototype.__set_model = function(e, t, n, r) {
                    Array.isArray(r) && (-1 !== r.indexOf("trim") && (n = n.trim()), -1 !== r.indexOf("number") && (n = this._n(n))), 
                    e || (e = this), e[t] = n;
                }, e.prototype.__set_sync = function(e, t, n) {
                    e || (e = this), e[t] = n;
                }, e.prototype.__get_orig = function(e) {
                    return l(e) && e.$orig || e;
                }, e.prototype.__get_value = function(e, t) {
                    return vn(t || this, e);
                }, e.prototype.__get_class = function(e, t) {
                    return un(t, e);
                }, e.prototype.__get_style = function(e, t) {
                    if (!e && !t) return "";
                    var n = gn(e), r = t ? b(t, n) : n;
                    return Object.keys(r).map(function(e) {
                        return Pn(e) + ":" + r[e];
                    }).join(";");
                }, e.prototype.__map = function(e, t) {
                    var n, r, i, o, a;
                    if (Array.isArray(e)) {
                        for (n = new Array(e.length), r = 0, i = e.length; r < i; r++) n[r] = t(e[r], r);
                        return n;
                    }
                    if (c(e)) {
                        for (o = Object.keys(e), n = Object.create(null), r = 0, i = o.length; r < i; r++) n[a = o[r]] = t(e[a], a, r);
                        return n;
                    }
                    if ("number" == typeof e) {
                        for (n = new Array(e), r = 0, i = e; r < i; r++) n[r] = t(r, r);
                        return n;
                    }
                    return [];
                };
            }(Bt), n.default = Bt;
        }.call(this, r("c8ba"));
    },
    "6cdc": function(e, t, n) {},
    "728b": function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("4360")), o = r(n("816e")), a = n("ac6b");
            t.default = function(t) {
                if (t.open_type || t.params || t.page_url) {
                    var n = t.open_type, r = t.params, s = t.page_url;
                    switch (!Array.isArray(r) && "[object String]" === Object.prototype.toString.call(r) && r && (r = JSON.parse(r)), 
                    n) {
                      case "reLaunch":
                        e.reLaunch({
                            url: r[0].value
                        });
                        break;

                      case "redirect":
                        e.redirectTo({
                            url: r[0].value
                        });
                        break;

                      case "navigate":
                        for (var c = s.split("?")[0], l = "?", u = 0; u < r.length; u++) l += "".concat(r[u].key, "=").concat(r[u].value, "&");
                        c += l.slice(0, l.length - 1), "?" === l && (c = s), e.navigateTo({
                            url: c
                        });
                        break;

                      case "app_admin":
                        1 == i.default.state.user.info.identity.is_admin && e.navigateTo({
                            url: t.url
                        });
                        break;

                      case "back":
                        e.navigateBack({});
                        break;

                      case "tel":
                        e.makePhoneCall({
                            phoneNumber: r[0].value
                        });
                        break;

                      case "web":
                        e.navigateTo({
                            url: "".concat(s.split("?")[0], "?url=").concat(encodeURIComponent(r[0].value))
                        });
                        break;

                      case "app":
                        for (var p = "", d = 0; d < r.length; d++) p += "".concat(r[d].key, "=").concat(r[d].value, "&");
                        if ("string" != typeof p) return;
                        var f = p.split("&"), h = {};
                        for (var g in f) if ("string" == typeof f[g] && f[g].length) {
                            var v = f[g].split("=");
                            if (2 !== v.length) {
                                for (var m = "", y = 1; y < v.length; y++) y + 1 !== v.length && (m += "".concat(v[y], "=").concat(v[y + 1]));
                                h[v[0]] = m;
                            } else h[v[0]] = v[1];
                        }
                        var _ = h, b = "", x = "";
                        b = _.app_id || "", x = _.path || "", e.navigateToMiniProgram({
                            appId: b,
                            path: x
                        });
                        break;

                      case "clear_cache":
                        e.showModal({
                            title: "提示",
                            content: "确认清理缓存？",
                            cancelText: "取消",
                            confirmText: "确认",
                            success: function(t) {
                                t.confirm && (e.showLoading({
                                    title: "清理缓存..."
                                }), (0, a.clearStorage)(), o.default && i.default && i.default.state.user.accessToken && o.default.loginByToken(i.default.state.user.accessToken), 
                                i.default.dispatch("mallConfig/actionResetConfig"), e.hideLoading(), e.showToast({
                                    title: "清理完成",
                                    duration: 1e3
                                }));
                            }
                        });
                    }
                }
            };
        }).call(this, n("543d").default);
    },
    7319: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = function(e) {
            var t = this;
            return new Promise(function(n, r) {
                try {
                    var i = null;
                    (i = t.createSelectorQuery()).select(".".concat(e)).boundingClientRect(), i.exec(function(e) {
                        n(e);
                    });
                } catch (e) {
                    r(e);
                }
            });
        };
    },
    7622: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.onload = void 0, r(n("f169")), r(n("66fd"));
        t.onload = function() {};
    },
    "816e": function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("27f5")), o = r(n("9d0f")), a = r(n("2749")), s = r(n("4360")), c = r(n("66fd")), l = (r(n("f2b3")), 
            r(n("dd00"))), u = "_USER_ACCESS_TOKEN", p = null, d = {
                getUserInfoResolve: null,
                getUserInfoReject: null,
                getAccessToken: function(t) {
                    var n = this;
                    return void 0 === (t = t || {}).cacheOnly && (t.cacheOnly = !1), new Promise(function(r, i) {
                        var s = c.default.prototype.$storage.getStorageSync(u);
                        if (s) return r(s);
                        if (t.cacheOnly) return r(s);
                        var p = getCurrentPages();
                        p[p.length - 1].$vm.$store.commit("user/showLoginModal", !0), t.no_jump || o.default.on(a.default.EVENT_USER_LOGIN, !0).then(function() {
                            e.redirectTo({
                                url: l.default.routeWithOption()
                            });
                        }), n.silentLogin().then(function(e) {
                            r(e);
                        }).catch(function(e) {
                            i(e);
                        });
                    });
                },
                getInfo: function(t) {
                    var n = this;
                    return void 0 === (t = t || {}).refresh && (t.refresh = !1), new Promise(function(r, l) {
                        if (t.refresh && (p = null), p) return r(p);
                        n.getAccessToken(t).then(function(t) {
                            e.showNavigationBarLoading(), c.default.prototype.$request({
                                url: i.default.user.user_info
                            }).then(function(t) {
                                if (e.hideNavigationBarLoading(), 0 === t.code) {
                                    var n = t.data.platform;
                                    if (c.default.prototype.$storage.setStorageSync("platform", n), getCurrentPages(), 
                                    s.default.commit("user/cart_nums", t.data.cart_nums), p = JSON.parse(JSON.stringify(t.data)), 
                                    o.default.trigger(a.default.EVENT_USER_REGISTER, p), void 0 !== p.register) {
                                        var i = p.register;
                                        if (i.coupon_list) {
                                            var u = {
                                                list: i.coupon_list,
                                                type: "register"
                                            };
                                            s.default.dispatch("page/actionSetCoupon", u);
                                        }
                                        i.polite_invitation && s.default.dispatch("page/actionSetPolite", i.polite_invitation);
                                    }
                                    if (void 0 !== p.login) {
                                        var d = p.login;
                                        d.newcomers && s.default.dispatch("page/actionSetNewcomers", d.newcomers);
                                    }
                                    return r(p);
                                }
                                return l(t.msg);
                            }).catch(function(t) {
                                return e.hideNavigationBarLoading(), l(t);
                            });
                        }).catch(function(e) {
                            return l(e);
                        });
                    });
                },
                isLogin: function() {
                    return !!(s.default && s.default.state.user && s.default.state.user.accessToken) || !!c.default.prototype.$storage.getStorageSync(u);
                },
                loginByToken: function(e) {
                    c.default.prototype.$storage.setStorageSync(u, e);
                },
                silentLogin: function() {
                    return new Promise(function(t, n) {
                        e.login({
                            success: function(e) {
                                c.default.prototype.$request({
                                    url: i.default.passport.login,
                                    method: "post",
                                    data: {
                                        code: e.code
                                    }
                                }).then(function(e) {
                                    0 === e.code ? (o.default.trigger(a.default.EVENT_USER_LOGIN), c.default.prototype.$storage.setStorageSync(u, e.data.access_token), 
                                    s.default.state.user.accessToken = e.data.access_token, t(e.data)) : n(e.data);
                                }).catch(function(e) {
                                    n(e);
                                });
                            },
                            fail: function(e) {
                                n(e);
                            }
                        });
                    });
                },
                getUserProfile: function(e) {
                    return new Promise(function(t, n) {
                        wx.canIUse("getUserProfile") || t(e), wx.getUserProfile({
                            desc: "用于完善会员资料",
                            success: function(e) {
                                t({
                                    detail: {
                                        encryptedData: e.encryptedData,
                                        iv: e.iv,
                                        rawData: e.rawData,
                                        signature: e.signature,
                                        errMsg: "getUserInfo:ok"
                                    }
                                });
                            },
                            fail: function(e) {
                                n(e);
                            }
                        });
                    });
                },
                canIUseGetUserProfile: function() {
                    return !!wx.getUserProfile;
                },
                logout: function() {
                    p = null;
                }
            };
            t.default = d;
        }).call(this, n("543d").default);
    },
    "89f3": function(e, t, n) {},
    "8de3d": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.push = t.popAll = void 0;
        var r = n("b1c7"), i = n("ac6b");
        t.popAll = function() {
            var e = (0, i.getStorageSync)("_FORM_ID_LIST");
            return (0, i.setStorageSync)("_FORM_ID_LIST", []), e || [];
        };
        t.push = function(e) {
            if (!e || "the formId is a mock one" === e) return !1;
            var t = (0, i.getStorageSync)("_FORM_ID_LIST");
            t && t.length || (t = []);
            var n = {
                value: e,
                type: 0,
                remains: 1,
                expires_at: (0, r.datetime)(null, (0, r.time)() + 604800 - 60)
            };
            t.push(n), (0, i.setStorageSync)("_FORM_ID_LIST", t);
        };
    },
    9152: function(e, t) {
        t.read = function(e, t, n, r, i) {
            var o, a, s = 8 * i - r - 1, c = (1 << s) - 1, l = c >> 1, u = -7, p = n ? i - 1 : 0, d = n ? -1 : 1, f = e[t + p];
            for (p += d, o = f & (1 << -u) - 1, f >>= -u, u += s; u > 0; o = 256 * o + e[t + p], 
            p += d, u -= 8) ;
            for (a = o & (1 << -u) - 1, o >>= -u, u += r; u > 0; a = 256 * a + e[t + p], p += d, 
            u -= 8) ;
            if (0 === o) o = 1 - l; else {
                if (o === c) return a ? NaN : 1 / 0 * (f ? -1 : 1);
                a += Math.pow(2, r), o -= l;
            }
            return (f ? -1 : 1) * a * Math.pow(2, o - r);
        }, t.write = function(e, t, n, r, i, o) {
            var a, s, c, l = 8 * o - i - 1, u = (1 << l) - 1, p = u >> 1, d = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0, f = r ? 0 : o - 1, h = r ? 1 : -1, g = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
            for (t = Math.abs(t), isNaN(t) || t === 1 / 0 ? (s = isNaN(t) ? 1 : 0, a = u) : (a = Math.floor(Math.log(t) / Math.LN2), 
            t * (c = Math.pow(2, -a)) < 1 && (a--, c *= 2), (t += a + p >= 1 ? d / c : d * Math.pow(2, 1 - p)) * c >= 2 && (a++, 
            c /= 2), a + p >= u ? (s = 0, a = u) : a + p >= 1 ? (s = (t * c - 1) * Math.pow(2, i), 
            a += p) : (s = t * Math.pow(2, p - 1) * Math.pow(2, i), a = 0)); i >= 8; e[n + f] = 255 & s, 
            f += h, s /= 256, i -= 8) ;
            for (a = a << i | s, l += i; l > 0; e[n + f] = 255 & a, f += h, a /= 256, l -= 8) ;
            e[n + f - h] |= 128 * g;
        };
    },
    9465: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                id: null,
                showPayment: !1,
                payData: null,
                payType: null,
                resolve: null,
                reject: null
            },
            getters: {
                id: function(e) {
                    return e.id;
                },
                showPayment: function(e) {
                    return e.showPayment;
                },
                payData: function(e) {
                    return e.payData;
                },
                payType: function(e) {
                    return e.payType;
                },
                resolve: function(e) {
                    return e.resolve;
                },
                reject: function(e) {
                    return e.reject;
                }
            },
            mutations: {
                id: function(e, t) {
                    e.id = t;
                },
                showPayment: function(e, t) {
                    e.showPayment = t;
                },
                payData: function(e, t) {
                    e.payData = t;
                },
                payType: function(e, t) {
                    e.payType = t;
                },
                resolve: function(e, t) {
                    e.resolve = t;
                },
                reject: function(e, t) {
                    e.reject = t;
                },
                setAll: function(e, t) {
                    for (var n in t) e[n] = t[n];
                }
            },
            actions: {
                reset: function(e) {
                    e.commit("id", null), e.commit("showPayment", !1), e.commit("payData", null), e.commit("payType", null), 
                    e.commit("resolve", null), e.commit("reject", null);
                }
            }
        };
        t.default = r;
    },
    "947e": function(e, t, n) {
        (function(e) {
            function n(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? n(Object(r), !0).forEach(function(t) {
                        i(e, t, r[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
                    });
                }
                return e;
            }
            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function o(t) {
                a.$request({
                    url: a.$api.advance.pay_data,
                    method: "post",
                    data: r({}, t)
                }).then(function(n) {
                    0 === n.code ? n.data.hasOwnProperty("id") ? a.$payment.pay(n.data.id).then(function() {
                        e.navigateTo({
                            url: "/plugins/advance/order/order"
                        });
                    }).catch(function() {
                        e.navigateTo({
                            url: "/plugins/advance/order/order"
                        });
                    }) : setTimeout(function() {
                        o(t);
                    }, 1e3) : e.showModal({
                        title: "提示",
                        content: n.msg
                    });
                });
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = null;
            t.default = function(t, n, i, s) {
                switch (a = i, n) {
                  case "advance":
                    var c = {
                        goods_id: t.goods_id,
                        goods_attr_id: t.id,
                        goods_num: t.number
                    };
                    a.$request({
                        url: a.$api.advance.order_submit,
                        method: "post",
                        data: r({}, c)
                    }).then(function(e) {
                        0 === e.code && o(e.data);
                    });
                    break;

                  case "gift":
                    for (var l = {
                        name: s.name,
                        price: t.price,
                        attr: {
                            id: t.id,
                            attr_list: t.attr_list,
                            stock: t.stock,
                            goods_id: t.goods_id
                        },
                        attr_str: "",
                        pic_url: t.pic_url ? t.pic_url : s.cover_pic,
                        number: t.number
                    }, u = 0; u < t.attr_list.length; u++) l.attr_str += "".concat(t.attr_list[u].attr_group_name, ":").concat(t.attr_list[u].attr_name, " ");
                    if (a.$storage.getStorageSync("GIFT_CART")) {
                        for (var p = 0, d = a.$storage.getStorageSync("GIFT_CART"), f = 0; f < d.length; f++) d[f].attr.id === t.id ? d[f].number += t.number : p += 1;
                        p === d.length && d.push(l), a.$storage.setStorageSync("GIFT_CART", d);
                    } else a.$storage.setStorageSync("GIFT_CART", [ l ]);
                    e.showToast({
                        title: "加入成功",
                        icon: "none"
                    });
                }
            };
        }).call(this, n("543d").default);
    },
    9587: function(t, n, r) {
        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function o(e) {
            if ("function" != typeof WeakMap) return null;
            var t = new WeakMap(), n = new WeakMap();
            return (o = function(e) {
                return e ? n : t;
            })(e);
        }
        function a(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var s = a(r("5cd4")), c = function(e, t) {
            if (!t && e && e.__esModule) return e;
            if (null === e || "object" !== i(e) && "function" != typeof e) return {
                default: e
            };
            var n = o(t);
            if (n && n.has(e)) return n.get(e);
            var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
                var c = a ? Object.getOwnPropertyDescriptor(e, s) : null;
                c && (c.get || c.set) ? Object.defineProperty(r, s, c) : r[s] = e[s];
            }
            return r.default = e, n && n.set(e, r), r;
        }(r("a716")), l = a(r("27f5")), u = a(r("9dc1")), p = function(e) {
            c.showLoading({
                mask: !0
            }), (0, u.default)({
                url: l.default.goods.remind,
                data: {
                    goods_id: e
                }
            }).then(function(e) {
                c.hideLoading(), 0 === e.code && c.showToast({
                    title: "订阅成功，开售前5分钟提醒您",
                    icon: "none"
                });
            }).catch(function(e) {
                c.hideLoading();
            });
        };
        n.default = function(e, t) {
            (0, s.default)(e).then(function(e) {
                p(t);
            }).catch(function(e) {
                p(t);
            });
        };
    },
    "96b1": function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAYAAADFeBvrAAAABHNCSVQICAgIfAhkiAAAAy5JREFUaEPd2jtsEzEYAOA/CX0kaYVURJcyQAUTjxG6tkwMMMCCeEw0awMLryCgEil0Qlc2ygYIFgZAgonC2HaEbiBYYEFiafPoKxT/J13IJbbP9tlng5dK7fXO3/32f/Z/l9oiDf6jlvoXQNX6FuSzKaHb7jTo+ds1ePV+DQLQidEeOH2shwtzFuQ9qcPcwnpH5/cMZaBczDMj5iTo2ZtVwOiwGg/lHOjnr99QuL0SOV9YKOdAKHk3vw4zT+tKKCdBMqixI91QPJdt4p0AYUSWvjRCHZNBXSvkYORQl4+yDpr/uAF3Z2t+Z9rvNv7Oe1yDucUN7vAbHEjD7GS/fdDX7w24MVP1nzNBU0W9fLDdLoiGCVATZ7NwdKQ7FJWoSFkF8TAqqP17MzBV7LMTIRGMDCrXC2Tl0AfDuzLJg2QwPFT5YRUWP21COybRLKeCYaEwiSBq/FS2GZng2ETSNnag5FXh249G5NOfdQAtUdCONQ7SgQk6fv/K37nCghsF6cQgoDWbJQ7SjcEE4F3th8Edae6wNRIhE5jW1MwTaQfZxBhJ21NkoblAFpw6Gu05E3VerRFi1QGiOkH7uwpGa4RcwGgD6cRgp+5M5OHgvm0qgY2/wdONEV0RGHkOuYaJNeSiamey4yVuZGItTkXLTKIoXRilCLmMkQbpxlw42QtYgNfZhB+sujFjh7ugeD6n0+KfSwiE67Pxm8tQW9VzfVMYYRAeiFvokleJjTKJkQIFqEvTFeUwmcZEgkqkqnmd1I1bXweqzqUkMFwQDjGMBu09jCwqKQwX1Fp6jYPaPZT2t85JNWqWw6xWuLUSKqKroBCDJVrRN9g60FQQa0jJoGxgmEPu4r0KsygogrKFoYJEXtoeIJuvMtmEtbZgztnEUEGPXtTh9YfO7wPaxzftxRRuKXBtluScae9Xxxw6c3k5lAx4E5WG0jGx45wjBJJ9vuCFXUOFQLgyWPq8KXyDcL4Mk09VjpNhFrxwEv5nQwc2QSLJAAFYjcGkgD9tzhXW/WiCaDUCrPbjnXcZwEwKuDLYOZAKRcDQqDB6Wj9CMh/YGe2NhpML7Vg1XCexU/wBxI16g8tLyzEAAAAASUVORK5CYII=";
    },
    "96cf": function(t, n) {
        !function(n) {
            function r(e, t, n, r) {
                var i = t && t.prototype instanceof o ? t : o, a = Object.create(i.prototype), s = new h(r || []);
                return a._invoke = u(e, n, s), a;
            }
            function i(e, t, n) {
                try {
                    return {
                        type: "normal",
                        arg: e.call(t, n)
                    };
                } catch (e) {
                    return {
                        type: "throw",
                        arg: e
                    };
                }
            }
            function o() {}
            function a() {}
            function s() {}
            function c(e) {
                [ "next", "throw", "return" ].forEach(function(t) {
                    e[t] = function(e) {
                        return this._invoke(t, e);
                    };
                });
            }
            function l(t) {
                function n(r, o, a, s) {
                    var c = i(t[r], t, o);
                    if ("throw" !== c.type) {
                        var l = c.arg, u = l.value;
                        return u && "object" === (void 0 === u ? "undefined" : e(u)) && _.call(u, "__await") ? Promise.resolve(u.__await).then(function(e) {
                            n("next", e, a, s);
                        }, function(e) {
                            n("throw", e, a, s);
                        }) : Promise.resolve(u).then(function(e) {
                            l.value = e, a(l);
                        }, function(e) {
                            return n("throw", e, a, s);
                        });
                    }
                    s(c.arg);
                }
                var r;
                this._invoke = function(e, t) {
                    function i() {
                        return new Promise(function(r, i) {
                            n(e, t, r, i);
                        });
                    }
                    return r = r ? r.then(i, i) : i();
                };
            }
            function u(e, t, n) {
                var r = P;
                return function(o, a) {
                    if (r === T) throw new Error("Generator is already running");
                    if (r === C) {
                        if ("throw" === o) throw a;
                        return v();
                    }
                    for (n.method = o, n.arg = a; ;) {
                        var s = n.delegate;
                        if (s) {
                            var c = p(s, n);
                            if (c) {
                                if (c === D) continue;
                                return c;
                            }
                        }
                        if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                            if (r === P) throw r = C, n.arg;
                            n.dispatchException(n.arg);
                        } else "return" === n.method && n.abrupt("return", n.arg);
                        r = T;
                        var l = i(e, t, n);
                        if ("normal" === l.type) {
                            if (r = n.done ? C : O, l.arg === D) continue;
                            return {
                                value: l.arg,
                                done: n.done
                            };
                        }
                        "throw" === l.type && (r = C, n.method = "throw", n.arg = l.arg);
                    }
                };
            }
            function p(e, t) {
                var n = e.iterator[t.method];
                if (n === m) {
                    if (t.delegate = null, "throw" === t.method) {
                        if (e.iterator.return && (t.method = "return", t.arg = m, p(e, t), "throw" === t.method)) return D;
                        t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method");
                    }
                    return D;
                }
                var r = i(n, e.iterator, t.arg);
                if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, 
                D;
                var o = r.arg;
                return o ? o.done ? (t[e.resultName] = o.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", 
                t.arg = m), t.delegate = null, D) : o : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), 
                t.delegate = null, D);
            }
            function d(e) {
                var t = {
                    tryLoc: e[0]
                };
                1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), 
                this.tryEntries.push(t);
            }
            function f(e) {
                var t = e.completion || {};
                t.type = "normal", delete t.arg, e.completion = t;
            }
            function h(e) {
                this.tryEntries = [ {
                    tryLoc: "root"
                } ], e.forEach(d, this), this.reset(!0);
            }
            function g(e) {
                if (e) {
                    var t = e[x];
                    if (t) return t.call(e);
                    if ("function" == typeof e.next) return e;
                    if (!isNaN(e.length)) {
                        var n = -1, r = function t() {
                            for (;++n < e.length; ) if (_.call(e, n)) return t.value = e[n], t.done = !1, t;
                            return t.value = m, t.done = !0, t;
                        };
                        return r.next = r;
                    }
                }
                return {
                    next: v
                };
            }
            function v() {
                return {
                    value: m,
                    done: !0
                };
            }
            var m, y = Object.prototype, _ = y.hasOwnProperty, b = "function" == typeof Symbol ? Symbol : {}, x = b.iterator || "@@iterator", w = b.asyncIterator || "@@asyncIterator", A = b.toStringTag || "@@toStringTag", S = "object" === (void 0 === t ? "undefined" : e(t)), k = n.regeneratorRuntime;
            if (k) S && (t.exports = k); else {
                (k = n.regeneratorRuntime = S ? t.exports : {}).wrap = r;
                var P = "suspendedStart", O = "suspendedYield", T = "executing", C = "completed", D = {}, j = {};
                j[x] = function() {
                    return this;
                };
                var $ = Object.getPrototypeOf, E = $ && $($(g([])));
                E && E !== y && _.call(E, x) && (j = E);
                var M = s.prototype = o.prototype = Object.create(j);
                a.prototype = M.constructor = s, s.constructor = a, s[A] = a.displayName = "GeneratorFunction", 
                k.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === a || "GeneratorFunction" === (t.displayName || t.name));
                }, k.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, s) : (e.__proto__ = s, A in e || (e[A] = "GeneratorFunction")), 
                    e.prototype = Object.create(M), e;
                }, k.awrap = function(e) {
                    return {
                        __await: e
                    };
                }, c(l.prototype), l.prototype[w] = function() {
                    return this;
                }, k.AsyncIterator = l, k.async = function(e, t, n, i) {
                    var o = new l(r(e, t, n, i));
                    return k.isGeneratorFunction(t) ? o : o.next().then(function(e) {
                        return e.done ? e.value : o.next();
                    });
                }, c(M), M[A] = "Generator", M[x] = function() {
                    return this;
                }, M.toString = function() {
                    return "[object Generator]";
                }, k.keys = function(e) {
                    var t = [];
                    for (var n in e) t.push(n);
                    return t.reverse(), function n() {
                        for (;t.length; ) {
                            var r = t.pop();
                            if (r in e) return n.value = r, n.done = !1, n;
                        }
                        return n.done = !0, n;
                    };
                }, k.values = g, h.prototype = {
                    constructor: h,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = m, this.done = !1, this.delegate = null, 
                        this.method = "next", this.arg = m, this.tryEntries.forEach(f), !e) for (var t in this) "t" === t.charAt(0) && _.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = m);
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval;
                    },
                    dispatchException: function(e) {
                        function t(t, r) {
                            return o.type = "throw", o.arg = e, n.next = t, r && (n.method = "next", n.arg = m), 
                            !!r;
                        }
                        if (this.done) throw e;
                        for (var n = this, r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r], o = i.completion;
                            if ("root" === i.tryLoc) return t("end");
                            if (i.tryLoc <= this.prev) {
                                var a = _.call(i, "catchLoc"), s = _.call(i, "finallyLoc");
                                if (a && s) {
                                    if (this.prev < i.catchLoc) return t(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return t(i.finallyLoc);
                                } else if (a) {
                                    if (this.prev < i.catchLoc) return t(i.catchLoc, !0);
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return t(i.finallyLoc);
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var r = this.tryEntries[n];
                            if (r.tryLoc <= this.prev && _.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                var i = r;
                                break;
                            }
                        }
                        i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                        var o = i ? i.completion : {};
                        return o.type = e, o.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, 
                        D) : this.complete(o);
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, 
                        this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), 
                        D;
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), f(n), D;
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var i = r.arg;
                                    f(n);
                                }
                                return i;
                            }
                        }
                        throw new Error("illegal catch attempt");
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: g(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = m), D;
                    }
                };
            }
        }(function() {
            return this || "object" === ("undefined" == typeof self ? "undefined" : e(self)) && self;
        }() || Function("return this")());
    },
    "972f": function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n("8de3d"), o = n("ac6b"), a = r(n("9dc1")), s = r(n("27f5"));
            t.default = function(t) {
                switch (t.form && (0, i.push)(t.e.detail.formId), t.open_type) {
                  case "redirect":
                    e.redirectTo({
                        url: t.url
                    });
                    break;

                  case "navigate":
                    e.navigateTo({
                        url: t.url
                    });
                    break;

                  case "app_admin":
                    1 == t.$store.state.user.info.identity.is_admin && e.navigateTo({
                        url: t.url
                    });
                    break;

                  case "tel":
                    t.params ? e.makePhoneCall({
                        phoneNumber: t.params[0].value
                    }) : t.number && e.makePhoneCall({
                        phoneNumber: t.number
                    });
                    break;

                  case "web":
                    e.navigateTo({
                        url: t.url
                    });
                    break;

                  case "app":
                    if (t.url) {
                        var n = t.url.split("?")[1];
                        e.navigateToMiniProgram({
                            appId: n.slice(0, 25).split("=")[1],
                            path: n.slice(n.indexOf("&") + 1, n.length).split("=")[1]
                        });
                    } else t.appId && e.navigateToMiniProgram({
                        appId: t.appId
                    });
                    break;

                  case "clear_cache":
                    (0, o.clearStorage)();
                    break;

                  case "map":
                    e.openLocation({
                        latitude: Number(t.latitude),
                        longitude: Number(t.longitude),
                        name: t.address
                    });
                    break;

                  case "reload":
                    e.redirectTo({
                        url: this.$platDiff.routeWithOption()
                    });
                    break;

                  case "customer_service":
                    (0, a.default)({
                        url: s.default.customer.url,
                        data: {
                            id: t.id
                        }
                    }).then(function(e) {
                        if (0 === e.code) {
                            var n = {
                                extInfo: {
                                    url: e.data.url
                                },
                                corpId: e.data.enterprise_id,
                                compplete: function(e) {
                                    console.log("complete"), console.log(e);
                                }
                            };
                            void 0 !== t.showMessage && (n = Object.assign(n, t.showMessage)), wx.openCustomerServiceChat(n);
                        }
                    });
                }
            };
        }).call(this, n("543d").default);
    },
    "9d0f": function(e, t, n) {
        function r(e) {
            this.resolveFunc = function() {}, this.rejectFunc = function() {}, e(this.resolve.bind(this), this.reject.bind(this));
        }
        r.prototype.resolve = function(e) {
            var t = this;
            setTimeout(function() {
                t.resolveFunc(e);
            }, 0);
        }, r.prototype.reject = function(e) {
            var t = this;
            setTimeout(function() {
                t.rejectFunc(e);
            }, 0);
        }, r.prototype.then = function(e, t) {
            return this.resolveFunc = e, this.rejectFunc = t, this;
        }, e.exports = {
            _resolveStorage: {},
            _addResolve: function(e, t, n) {
                this._resolveStorage[e] || (this._resolveStorage[e] = []), this._resolveStorage[e].push({
                    resolve: t,
                    removeEventAfterTrigger: n
                });
            },
            on: function(e, t) {
                var n = this;
                return new r(function(r) {
                    void 0 === t && (t = !0), n._addResolve(e, r, t);
                });
            },
            trigger: function(e, t) {
                if (this._resolveStorage[e] && this._resolveStorage[e].length) {
                    var n = [];
                    for (var r in this._resolveStorage[e]) this._resolveStorage[e][r].resolve(t), this._resolveStorage[e][r].removeEventAfterTrigger || n.push(this._resolveStorage[e][r]);
                    this._resolveStorage[e] = n;
                }
            }
        };
    },
    "9dc1": function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function i(e, t) {
                return l(e) || c(e, t) || a(e, t) || o();
            }
            function o() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function a(e, t) {
                if (e) {
                    if ("string" == typeof e) return s(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? s(e, t) : void 0;
                }
            }
            function s(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            function c(e, t) {
                var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (null != n) {
                    var r, i, o = [], a = !0, s = !1;
                    try {
                        for (n = n.call(e); !(a = (r = n.next()).done) && (o.push(r.value), !t || o.length !== t); a = !0) ;
                    } catch (e) {
                        s = !0, i = e;
                    } finally {
                        try {
                            a || null == n.return || n.return();
                        } finally {
                            if (s) throw i;
                        }
                    }
                    return o;
                }
            }
            function l(e) {
                if (Array.isArray(e)) return e;
            }
            function u(e, t, n, r, i, o, a) {
                try {
                    var s = e[o](a), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(r, i);
            }
            function p(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, i) {
                        function o(e) {
                            u(s, r, i, o, a, "next", e);
                        }
                        function a(e) {
                            u(s, r, i, o, a, "throw", e);
                        }
                        var s = e.apply(t, n);
                        o(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var d = r(n("a34a")), f = r(n("66fd")), h = n("8de3d"), g = r(n("36e8"));
            r(n("ae58"));
            var v = function() {
                var t = p(d.default.mark(function t(n) {
                    var r, o, a, s, c, l, u, p;
                    return d.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return r = {
                                "X-App-Platform": n.header && n.header["X-App-Platform"] ? n.header["X-App-Platform"] : f.default.prototype.$platform,
                                "X-Form-Id-List": JSON.stringify((0, h.popAll)()),
                                "X-Requested-With": n.header && n.header["X-Requested-With"] ? n.header["X-Requested-With"] : "XMLHttpRequest",
                                "X-App-Version": f.default.prototype.$appVersion,
                                "content-type": n.header && n.header.contentType ? n.header["content-type"] : "application/x-www-form-urlencoded"
                            }, t.next = 3, f.default.prototype.$store.dispatch("user/loadAccessTokenFormCache");

                          case 3:
                            return f.default.prototype.$store.state.user && f.default.prototype.$store.state.user.accessToken && (r["X-Access-Token"] = f.default.prototype.$store.state.user.accessToken), 
                            f.default.prototype.$store.state.user && 0 !== f.default.prototype.$store.state.user.tempParentId && (r["X-User-Id"] = f.default.prototype.$store.state.user.tempParentId + ""), 
                            o = {}, n.url.replace(/([^=&]+)=([^&]*)/g, function(e, t, n) {
                                o[decodeURIComponent(t)] = decodeURIComponent(n);
                            }), -1 !== f.default.prototype.$utils.objectValues(g.default.mch).indexOf(o.r) && (a = f.default.prototype.$storage.getStorageSync("MCH2019"), 
                            r["Mch-Access-Token"] = a.token), t.next = 10, e.request({
                                url: n.url,
                                method: n.method || "get",
                                data: n.data,
                                header: r
                            });

                          case 10:
                            if (s = t.sent, c = i(s, 2), l = c[0], u = c[1], !l) {
                                t.next = 20;
                                break;
                            }
                            return p = {
                                code: 400,
                                msg: l.errMsg,
                                data: l
                            }, y(p), t.abrupt("return", Promise.reject(p));

                          case 20:
                            return t.abrupt("return", b(u));

                          case 21:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }));
                return function(e) {
                    return t.apply(this, arguments);
                };
            }(), m = function() {
                var t = getCurrentPages(), n = t[t.length - 1], r = n.options || {}, i = n.route || "";
                0 !== i.indexOf("/") && (i = "/" + i);
                var o = "";
                for (var a in r) o += "".concat(a, "=").concat(r[a], "&");
                e.redirectTo({
                    url: i + (o ? "?".concat(o) : "")
                });
            }, y = function(t) {
                e.showModal({
                    title: "网络错误",
                    content: "网络开了小差，请刷新重试下哦~",
                    cancelText: "复制错误",
                    confirmText: "刷新页面",
                    success: function(e) {
                        if (e.cancel) {
                            var n = "code: ".concat(t.code, ", \r\nmsg: ").concat(t.msg, ", \r\ndetail: ") + (t.data ? "string" == typeof t.data ? t.data : JSON.stringify(t.data) : null);
                            f.default.prototype.$utils.uniCopy({
                                data: n
                            });
                        }
                        e.confirm && m();
                    }
                });
            }, _ = function(t) {
                if (!t.data) return Promise.reject({
                    code: 200,
                    msg: "数据不存在",
                    data: t
                });
                var n = t.data, r = n.msg, i = n.code;
                return i >= 400 && 1001 !== i ? (y({
                    code: i,
                    msg: r,
                    data: t.data.error || t.data.data || r
                }), Promise.reject(r)) : 2 === i ? Promise.reject(r) : -1 === i ? (f.default.prototype.$store.dispatch("user/logout"), 
                f.default.prototype.$store.dispatch("user/accessToken"), Promise.reject(r)) : -2 !== i ? -3 === i ? (e.redirectTo({
                    url: "/plugins/mch/mch/login/login"
                }), Promise.reject(r)) : Promise.resolve(t.data) : void e.redirectTo({
                    url: "/pages/disabled/disabled?text=" + t.data.data.text
                });
            }, b = function(e) {
                var t = {
                    code: 500,
                    msg: "服务器内部错误",
                    data: e
                };
                switch (e.statusCode) {
                  case 200:
                    return _(e);

                  case 404:
                    t = {
                        code: 404,
                        msg: "资源获取不到",
                        data: e
                    };
                    break;

                  case 500:
                    t = {
                        code: 500,
                        msg: "服务器内部错误",
                        data: e
                    };
                    break;

                  case 503:
                    t = {
                        code: 503,
                        msg: "服务不可用",
                        data: e
                    };
                    break;

                  case 504:
                    t = {
                        code: 504,
                        msg: "网关超时",
                        data: e
                    };
                    break;

                  case 400:
                    t = {
                        code: 400,
                        msg: "服务器不理解请求的语法",
                        data: e
                    };
                    break;

                  case 403:
                    t = {
                        code: 403,
                        msg: "服务器拒绝请求",
                        data: e
                    };
                    break;

                  case 405:
                    t = {
                        code: 405,
                        msg: "方法禁用",
                        data: e
                    };
                    break;

                  case 406:
                    t = {
                        code: 406,
                        msg: "无法使用请求的内容特性响应请求的网页",
                        data: e
                    };
                    break;

                  case 407:
                    t = {
                        code: 407,
                        msg: "需要代理授权",
                        data: e
                    };
                    break;

                  case 408:
                    t = {
                        code: 408,
                        msg: "请求超时",
                        data: e
                    };
                    break;

                  case 409:
                    t = {
                        code: 409,
                        msg: "冲突",
                        data: e
                    };
                    break;

                  case 410:
                    t = {
                        code: 410,
                        msg: "已删除",
                        data: e
                    };
                    break;

                  case 411:
                    t = {
                        code: 411,
                        msg: "需要有效长度",
                        data: e
                    };
                    break;

                  case 412:
                    t = {
                        code: 412,
                        msg: "服务器未满足请求者在请求中设置的其中一个前提条件",
                        data: e
                    };
                    break;

                  case 413:
                    t = {
                        code: 413,
                        msg: "请求实体过大",
                        data: e
                    };
                    break;

                  case 414:
                    t = {
                        code: 414,
                        msg: "求情URI过长",
                        data: e
                    };
                    break;

                  case 415:
                    t = {
                        code: 415,
                        msg: "不支持的媒体类型",
                        data: e
                    };
                    break;

                  case 416:
                    t = {
                        code: 416,
                        msg: "请求范围不符合要求",
                        data: e
                    };
                    break;

                  case 417:
                    t = {
                        code: 417,
                        msg: "未满足期望值",
                        data: e
                    };
                }
                return y(t), Promise.reject(t);
            }, x = v;
            t.default = x;
        }).call(this, n("543d").default);
    },
    a067: function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABYCAMAAAA9bwLKAAAArlBMVEUAAADu8v/u9v/p6//t8f/t8f/t7f/t8v/t8f/t8f/t8v/t8v/t8v/t8f/t8v/u8v/u8f/t8v/r8f/x8v/t8f/t8f/u8//t8f/t8f/t8v/u8v/t8f/s8v/u8P/t8f/u8f/u8f/t8v/u8f/t8f/u8v/u8P/u8//t8P/u8f/t8f/t8f/t8f/u8//t8f/s8f/t8f/u8v/t8f/t8f/t8f/r8P/u8f/t8f/t8f/t8f/u8f8rFEM+AAAAOXRSTlMA/A4G90QKwF7LxumLdyoS0ZMhFeJ0V92u5Ts1Jh7y725R69Waey6oYbmFZRlqWtmhp39KMeC0TqkEWD5rAAAETklEQVRo3s2Y2ZKiMBhGP0DBDcF9wV3Hdt+dnv/9X2wal/6bCIEwXsy5Uos6p1IhhoBouquPg11FEoxm5Thb6FChWiAfrWIilnOdfIYLBf+8SA+s2EJOower5P4JfVPQ4/1cUPFzIc7PlJT8XJD7VQvlIlF8gf2qBfYzlhFx/7CfCwp+ZoQw9NBrSyn8VEcYIyLFAvtFegjhN0kKan7KIgSXJAU1P3kIIU+Sgppf0xHCjCQFJT+1EUaWoqko+TO3OTaemLqumzzLyQq9DkWifQLjQoYCuGvAcWWF5P4x8IteWeoxhdR+3itiCmn9XIgfQ7y/yf5XCjGFRSK/TZS2YCfxN4hiCnlZIL2fC3peEujXY/1pChwoKPjVCzbOKn71go2Z1L8mSlfggCXzOwMSmLaP7UInvsCBgsSPnbgzX3DDydrtorTAgUOEP4cvGoK/CjDl0TJDTJ4LgcA40u/xCNhfPa1+LboO7pi5TEzBhuFG+JsDE85A9D8WzfW4LcMnKxQKLwGUh6H+sUY7YPviZzqHphld4AC8YbifpgZgh/gZK7ZggwuC/4sZz/OV/fEFMYDL5MXP+0WzRaS1N+xXKth8IHjxP8eAnueA/WqFBR/JBP+DtoM72Q5R4oL1+vjVb9+sbhc4Z4iYyWluQD+3iYkrODBOt2ltNQGmn2usL+BrGY1/SVYwATO7XngxZ4rinu8utUIJEhoPe2MDoFzKpClkdEnAIp/lc27L+zSFT0mgTl+0DcDI7jwANTdFYSQJXB/+sT8X0znQH6oXtpLAb9//ff4deoBNyoWuJLBgv8/VgKOpFuqGJGCUHn6eL5cUCzlICfipASxJrVBR8dMaMGrng5a8UFLya33cuCRfD0p+OgH6vKawHnR/HiGhKbxf2vh/s1b5q9ChJOy3zT8FSaE2CPr7LfIZdoEdyRgI445i/eK/M3FgFCX+X4FTdguRrF78/PfyIQvgZ0FDJNsIPx2AEiUtXBHJJiP6efvfdNfLuEL8jrMN99MON7qtBAVXh4S1PwZtJfjzxvM2y8sK15t/AylVe3aaC/5pDdupNjxWAUc2BnM9m+0MJMEK+o0D+Uw86UuiLBJTFvwfz/WwCb5IW42ImA8kZiz42RhYK1oXPwsuEpON8JMF5IgZBAoWEmMOw/1UAPqLlRtesJGcheAX1tC5HlKYmlBge38aFvyDKq8HLtyv3W+gxGVm/R4ZQX8mi/nMzZe+VM7+u+DBO+QtW0caToJ/l3muB0+jB0UHqTEGAf/3hjrs/Xxp2kBq5i/+B0f/PuAvqelF+GkCeMSbRXo6QT/ngItw1EtHLtxPecBc0h3XQEr4yDMQ/LTDd6G1wT+RXQ6LH2XBXwH0tmnYe61TcfAOuqIfM2rjjSxFv01EF7yPjOBv8FnsPWghfmrgfRRC/NTF+/gM8Vt4JyP21ybks6/hrXy6RK01fHpLjTLHGt6N7vDHqon/g7+Z7bipi7qAeQAAAABJRU5ErkJggg==";
    },
    a2ca: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                status: !1
            },
            getters: {
                getStatus: function(e) {
                    return e.status;
                }
            },
            mutations: {
                status: function(e, t) {
                    e.status = t;
                }
            },
            actions: {}
        };
        t.default = r;
    },
    a34a: function(e, t, n) {
        e.exports = n("bbdd");
    },
    a716: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.showActionSheet = t.showModal = t.hideLoading = t.showLoading = t.hideToast = t.showToast = void 0;
            t.showToast = function(t) {
                e.showToast(t);
            };
            t.hideToast = function() {
                e.hideToast();
            };
            t.showLoading = function(t) {
                e.showLoading(t);
            };
            t.hideLoading = function() {
                e.hideLoading();
            };
            t.showModal = function(t) {
                e.showModal(t);
            };
            t.showActionSheet = function(t) {
                e.showActionSheet(t);
            };
        }).call(this, n("543d").default);
    },
    a95b: function(t, n, r) {
        function i(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = o(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var r = 0, i = function() {};
                    return {
                        s: i,
                        n: function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            };
                        },
                        e: function(e) {
                            throw e;
                        },
                        f: i
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var a, s = !0, c = !1;
            return {
                s: function() {
                    n = n.call(e);
                },
                n: function() {
                    var e = n.next();
                    return s = e.done, e;
                },
                e: function(e) {
                    c = !0, a = e;
                },
                f: function() {
                    try {
                        s || null == n.return || n.return();
                    } finally {
                        if (c) throw a;
                    }
                }
            };
        }
        function o(e, t) {
            if (e) {
                if ("string" == typeof e) return a(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? a(e, t) : void 0;
            }
        }
        function a(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        function s(t) {
            return (s = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = function(e, t, n, r, i) {
            var o = t.province || [], a = t.city || [], s = t.area || [], c = [], l = "";
            if (0 === o.length) {
                for (var u = 1; u < e.length; u++) {
                    var p = e.substring(0, u + 1), d = new RegExp('{"code":"[0-9]{1,6}","name":"'.concat(p, '[一-龥]*?"}'), "g"), f = n.match(d);
                    if (!f) break;
                    var h = JSON.parse(f[0]);
                    1 === f.length && (o = [], l = p, o.push(h));
                }
                o[0] && (e = e.replace(l, ""));
            }
            if (0 === a.length) {
                for (var g = 1; g < e.length; g++) {
                    var v = e.substring(0, g + 1), m = new RegExp('{"code":"[0-9]{1,6}","name":"'.concat(v, '[一-龥]*?","provinceCode":"').concat(o[0] ? "".concat(o[0].code) : "[0-9]{1,6}", '"}'), "g"), y = r.match(m);
                    if (!y) break;
                    var _ = JSON.parse(y[0]);
                    1 === y.length && (a = [], l = v, a.push(_));
                }
                if (a[0]) {
                    var b = a[0].provinceCode;
                    if (e = e.replace(l, ""), 0 === o.length) {
                        var x = new RegExp('{"code":"'.concat(b, '","name":"[一-龥]+?"}'), "g"), w = n.match(x);
                        o.push(JSON.parse(w[0]));
                    }
                }
            }
            if (0 === s.length) {
                for (var A = 1; A < e.length; A++) {
                    var S = e.substring(0, A + 1), k = new RegExp('{"code":"[0-9]{1,6}","name":"'.concat(S, '[一-龥]*?","cityCode":"').concat(a[0] ? a[0].code : "[0-9]{1,6}", '","provinceCode":"').concat(o[0] ? "".concat(o[0].code) : "[0-9]{1,6}", '"}'), "g"), P = i.match(k);
                    if (!P) break;
                    var O = JSON.parse(P[0]);
                    1 === P.length && (s = [], l = S, s.push(O));
                }
                if (s[0]) {
                    var T = s[0], C = T.provinceCode, D = T.cityCode;
                    if (e = e.replace(l, ""), 0 === o.length) {
                        var j = new RegExp('{"code":"'.concat(C, '","name":"[一-龥]+?"}'), "g"), $ = n.match(j);
                        o.push(JSON.parse($[0]));
                    }
                    if (0 === a.length) {
                        var E = new RegExp('{"code":"'.concat(D, '","name":"[一-龥]+?","provinceCode":"').concat(C, '"}'), "g"), M = r.match(E);
                        a.push(JSON.parse(M[0]));
                    }
                }
            }
            return e.length > 0 && c.push(e), {
                province: o,
                city: a,
                area: s,
                detail: c
            };
        }, l = function(e, t) {
            var n = [], r = [], o = [], a = [];
            if (t.province[0]) n = t.province; else {
                var s, c = i(provinces);
                try {
                    for (c.s(); !(s = c.n()).done; ) {
                        for (var l = s.value, u = l.name, p = "", d = u.length; d > 1; d--) {
                            var f = u.substring(0, d);
                            if (0 === e.indexOf(f)) {
                                p = f;
                                break;
                            }
                        }
                        if (p) {
                            n.push(l), e = e.replace(p, "");
                            break;
                        }
                    }
                } catch (e) {
                    c.e(e);
                } finally {
                    c.f();
                }
            }
            if (t.city[0]) r = t.city; else {
                var h, g = i(cities);
                try {
                    for (g.s(); !(h = g.n()).done && "break" !== function() {
                        var t = h.value, i = t.name, o = t.provinceCode, a = n[0];
                        if (a) {
                            if (a.code === o) {
                                for (var s = "", c = i.length; c > 1; c--) {
                                    var l = i.substring(0, c);
                                    if (0 === e.indexOf(l)) {
                                        s = l;
                                        break;
                                    }
                                }
                                if (s) return r.push(t), e = e.replace(s, ""), "break";
                            }
                        } else {
                            for (var u = i.length; u > 1; u--) {
                                var p = i.substring(0, u);
                                if (0 === e.indexOf(p)) {
                                    r.push(t), n.push(provinces.find(function(e) {
                                        return e.code === o;
                                    })), e = e.replace(p, "");
                                    break;
                                }
                            }
                            if (r.length > 0) return "break";
                        }
                    }(); ) ;
                } catch (e) {
                    g.e(e);
                } finally {
                    g.f();
                }
            }
            var v, m = i(areas);
            try {
                for (m.s(); !(v = m.n()).done && "break" !== function() {
                    var t = v.value, i = t.name, a = t.provinceCode, s = t.cityCode, c = n[0], l = r[0];
                    if (c || l) {
                        if (c && c.code === a || (l && l.code) === s) {
                            for (var u = "", p = i.length; p > 1; p--) {
                                var d = i.substring(0, p);
                                if (0 === e.indexOf(d)) {
                                    u = d;
                                    break;
                                }
                            }
                            if (u) return o.push(t), !l && r.push(cities.find(function(e) {
                                return e.code === s;
                            })), !c && n.push(provinces.find(function(e) {
                                return e.code === a;
                            })), e = e.replace(u, ""), "break";
                        }
                    } else {
                        for (var f = i.length; f > 1; f--) {
                            var h = i.substring(0, f);
                            if (0 === e.indexOf(h)) {
                                o.push(t), r.push(cities.find(function(e) {
                                    return e.code === s;
                                })), n.push(provinces.find(function(e) {
                                    return e.code === a;
                                })), e = e.replace(h, "");
                                break;
                            }
                        }
                        if (o.length > 0) return "break";
                    }
                }(); ) ;
            } catch (e) {
                m.e(e);
            } finally {
                m.f();
            }
            return e.length > 0 && a.push(e), {
                province: n,
                city: r,
                area: o,
                detail: a
            };
        }, u = function(e) {
            var t = "";
            e = (e = (e = (e = e.replace(/(\d{3})-(\d{4})-(\d{4})/g, "$1$2$3")).replace(/(\d{3}) (\d{4}) (\d{4})/g, "$1$2$3")).replace(/(\d{4}) \d{4} \d{4}/g, "$1$2$3")).replace(/(\d{4})/g, "$1");
            var n = /(\d{7,12})|(\d{3,4}-\d{6,8})|(86-[1][0-9]{10})|(86[1][0-9]{10})|([1][0-9]{10})/g.exec(e);
            return n && (t = n[0], e = e.replace(n[0], " ")), {
                address: e,
                phone: t
            };
        }, p = function(e) {
            var t = "", n = /\d{6}/g.exec(e);
            return n && (t = n[0], e = e.replace(n[0], " ")), {
                address: e,
                postalCode: t
            };
        }, d = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            e = e.replace(/\r\n/g, " ").replace(/\n/g, " ").replace(/\t/g, " "), [ "详细地址", "收货地址", "收件地址", "地址", "所在地区", "地区", "姓名", "收货人", "收件人", "联系人", "收", "邮编", "联系电话", "电话", "联系人手机号码", "手机号码", "手机号" ].concat(t).forEach(function(t) {
                e = e.replace(new RegExp(t, "g"), " ");
            });
            var n = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“’。，、？]", "g");
            return e = e.replace(n, " "), e = e.replace(/ {2,}/g, " ");
        };
        n.default = function(e, t, n, r, i) {
            var o = "object" === s(t) ? t : {}, a = o.type, f = void 0 === a ? 0 : a, h = o.textFilter, g = void 0 === h ? [] : h;
            if (!e) return {};
            var v = {
                phone: "",
                province: [],
                city: [],
                area: [],
                detail: [],
                name: ""
            };
            e = d(e, g);
            var m = u(e);
            e = m.address, v.phone = m.phone;
            var y = p(e);
            if (e = y.address, v.postalCode = y.postalCode, e.split(" ").filter(function(e) {
                return e;
            }).map(function(e) {
                return e.trim();
            }).forEach(function(e) {
                if (v.province[0] && v.city[0] && v.area[0]) v.detail.push(e); else {
                    var t;
                    1 === f && (t = l(e, v)), 0 === f && (t = c(e, v, n, r, i));
                    var o = t, a = o.province, s = o.city, u = o.area, p = o.detail;
                    v.province = a || [], v.area = u || [], v.city = s || [], v.detail = v.detail.concat(p || []);
                }
            }), !v.name) {
                var _ = JSON.parse(JSON.stringify(v.detail));
                _.sort(function(e, t) {
                    return e.length - t.length;
                }), v.name = _[0];
                var b = v.detail.findIndex(function(e) {
                    return e === v.name;
                });
                v.detail.splice(b, 1);
            }
            var x = v.province[0], w = v.city[0], A = v.area[0], S = v.detail;
            return Object.assign(v, {
                province: x && x.name || "",
                city: w && w.name || "",
                area: A && A.name || "",
                detail: S && S.length > 0 && S.join("") || ""
            });
        };
    },
    a9cc: function(t, n, r) {
        (function(t, n) {
            function r(t) {
                return (r = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                    return void 0 === t ? "undefined" : e(t);
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
                })(t);
            }
            function i(e, t) {
                var n = /^#?([a-f\d])([a-f\d])([a-f\d])$/i, r = e.replace(n, function(e, t, n, r) {
                    return t + t + n + n + r + r;
                }), i = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(r);
                return "rgba(" + parseInt(i[1], 16) + "," + parseInt(i[2], 16) + "," + parseInt(i[3], 16) + "," + t + ")";
            }
            function o(e, t, n) {
                if (isNaN(e)) throw new Error("[uCharts] unvalid series data!");
                n = n || 10, t = t || "upper";
                for (var r = 1; 1 > n; ) n *= 10, r *= 10;
                for (e = "upper" === t ? Math.ceil(e * r) : Math.floor(e * r); 0 != e % n; ) "upper" === t ? e++ : e--;
                return e / r;
            }
            function a(e, t, n, r) {
                for (var i, o = [], a = 0; a < e.length; a++) {
                    i = {
                        data: [],
                        name: t[a],
                        color: n[a]
                    };
                    for (var s = 0, c = r.length; s < c; s++) if (s < e[a]) i.data.push(null); else {
                        for (var l = 0, u = 0; u < e[a]; u++) l += r[s - u][1];
                        i.data.push(+(l / e[a]).toFixed(3));
                    }
                    o.push(i);
                }
                return o;
            }
            function s(e, t, n, r, i) {
                var o = i.width - i.area[1] - i.area[3], a = n.eachSpacing * (i.chartData.xAxisData.xAxisPoints.length - 1), s = t;
                return 0 <= t ? (s = 0, e.event.trigger("scrollLeft")) : Math.abs(t) >= a - o && (s = o - a, 
                e.event.trigger("scrollRight")), s;
            }
            function c(e, t, n) {
                function r(e) {
                    for (;0 > e; ) e += 2 * i;
                    for (;e > 2 * i; ) e -= 2 * i;
                    return e;
                }
                var i = Math.PI;
                return e = r(e), t = r(t), n = r(n), t > n && (n += 2 * i, e < t && (e += 2 * i)), 
                e >= t && e <= n;
            }
            function l(e, t, n) {
                var r = e, i = n - t, o = r + (n - i - r) / 1.4142135623730951;
                return o *= -1, {
                    transX: o,
                    transY: .41421356237309515 * (n - i) - (n - i - r) / 1.4142135623730951
                };
            }
            function u(e, t) {
                function n(e, t) {
                    return !(!e[t - 1] || !e[t + 1]) && (e[t].y >= i(e[t - 1].y, e[t + 1].y) || e[t].y <= r(e[t - 1].y, e[t + 1].y));
                }
                var r = Math.min, i = Math.max, o = null, a = null, s = null, c = null;
                if (1 > t ? (o = e[0].x + .2 * (e[1].x - e[0].x), a = e[0].y + .2 * (e[1].y - e[0].y)) : (o = e[t].x + .2 * (e[t + 1].x - e[t - 1].x), 
                a = e[t].y + .2 * (e[t + 1].y - e[t - 1].y)), t > e.length - 3) {
                    var l = e.length - 1;
                    s = e[l].x - .2 * (e[l].x - e[l - 1].x), c = e[l].y - .2 * (e[l].y - e[l - 1].y);
                } else s = e[t + 1].x - .2 * (e[t + 2].x - e[t].x), c = e[t + 1].y - .2 * (e[t + 2].y - e[t].y);
                return n(e, t + 1) && (c = e[t + 1].y), n(e, t) && (a = e[t].y), (a >= i(e[t].y, e[t + 1].y) || a <= r(e[t].y, e[t + 1].y)) && (a = e[t].y), 
                (c >= i(e[t].y, e[t + 1].y) || c <= r(e[t].y, e[t + 1].y)) && (c = e[t + 1].y), 
                {
                    ctrA: {
                        x: o,
                        y: a
                    },
                    ctrB: {
                        x: s,
                        y: c
                    }
                };
            }
            function p(e, t, n) {
                return {
                    x: n.x + e,
                    y: n.y - t
                };
            }
            function d(e, t) {
                if (t) for (;Ke.isCollision(e, t); ) 0 < e.start.x ? e.start.y-- : 0 > e.start.x || 0 < e.start.y ? e.start.y++ : e.start.y--;
                return e;
            }
            function f(e, t, n) {
                var r = 0;
                return e.map(function(e) {
                    if (e.color || (e.color = n.colors[r], r = (r + 1) % n.colors.length), e.index || (e.index = 0), 
                    e.type || (e.type = t.type), void 0 === e.show && (e.show = !0), e.type || (e.type = t.type), 
                    e.pointShape || (e.pointShape = "circle"), !e.legendShape) switch (e.type) {
                      case "line":
                        e.legendShape = "line";
                        break;

                      case "column":
                        e.legendShape = "rect";
                        break;

                      case "area":
                        e.legendShape = "triangle";
                        break;

                      default:
                        e.legendShape = "circle";
                    }
                    return e;
                });
            }
            function h(e, t) {
                var n = 0, r = t - e;
                return n = 1e4 <= r ? 1e3 : 1e3 <= r ? 100 : 100 <= r ? 10 : 10 <= r ? 5 : 1 <= r ? 1 : .1 <= r ? .1 : .01 <= r ? .01 : .001 <= r ? .001 : 1e-4 <= r ? 1e-4 : 1e-5 <= r ? 1e-5 : 1e-6, 
                {
                    minRange: o(e, "lower", n),
                    maxRange: o(t, "upper", n)
                };
            }
            function g(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : Ye.fontSize;
                e = (e += "").split("");
                for (var n, r = 0, i = 0; i < e.length; i++) n = e[i], r += /[a-zA-Z]/.test(n) ? 7 : /[0-9]/.test(n) ? 5.5 : /\./.test(n) ? 2.7 : /-/.test(n) ? 3.25 : /[\u4e00-\u9fa5]/.test(n) ? 10 : /\(|\)/.test(n) ? 3.73 : /\s/.test(n) ? 2.5 : /%/.test(n) ? 8 : 10;
                return r * t / 10;
            }
            function v(e) {
                return e.reduce(function(e, t) {
                    return (e.data ? e.data : e).concat(t.data);
                }, []);
            }
            function m(e, t) {
                for (var n = Array(t), r = 0; r < n.length; r++) n[r] = 0;
                for (var i = 0; i < e.length; i++) for (r = 0; r < n.length; r++) n[r] += e[i].data[r];
                return e.reduce(function(e, t) {
                    return (e.data ? e.data : e).concat(t.data).concat(n);
                }, []);
            }
            function y(e, t, n) {
                var r, i;
                return e.clientX ? t.rotate ? (i = t.height - e.clientX * t.pixelRatio, r = (e.pageY - n.currentTarget.offsetTop - t.height / t.pixelRatio / 2 * (t.pixelRatio - 1)) * t.pixelRatio) : (r = e.clientX * t.pixelRatio, 
                i = (e.pageY - n.currentTarget.offsetTop - t.height / t.pixelRatio / 2 * (t.pixelRatio - 1)) * t.pixelRatio) : t.rotate ? (i = t.height - e.x * t.pixelRatio, 
                r = e.y * t.pixelRatio) : (r = e.x * t.pixelRatio, i = e.y * t.pixelRatio), {
                    x: r,
                    y: i
                };
            }
            function _(e, t) {
                for (var n, r = [], i = 0; i < e.length; i++) if (null !== (n = e[i]).data[t] && void 0 !== n.data[t] && n.show) {
                    var o = {};
                    o.color = n.color, o.type = n.type, o.style = n.style, o.pointShape = n.pointShape, 
                    o.disableLegend = n.disableLegend, o.name = n.name, o.show = n.show, o.data = n.format ? n.format(n.data[t]) : n.data[t], 
                    r.push(o);
                }
                return r;
            }
            function b(e) {
                var t = e.map(function(e) {
                    return g(e);
                });
                return Math.max.apply(null, t);
            }
            function x(e) {
                for (var t = Math.PI, n = [], r = 0; r < e; r++) n.push(2 * t / e * r);
                return n.map(function(e) {
                    return -1 * e + t / 2;
                });
            }
            function w(e, t, n, r) {
                for (var i, o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : {}, a = e.map(function(e) {
                    var t = [];
                    return t = r || e.data, {
                        text: o.format ? o.format(e, t[n]) : e.name + ": " + e.data,
                        color: e.color
                    };
                }), s = [], c = {
                    x: 0,
                    y: 0
                }, l = 0; l < t.length; l++) void 0 !== (i = t[l])[n] && null !== i[n] && s.push(i[n]);
                for (var u, p = 0; p < s.length; p++) u = s[p], c.x = Math.round(u.x), c.y += u.y;
                return c.y /= s.length, {
                    textList: a,
                    offset: c
                };
            }
            function A(e, t, n, r) {
                var i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : {}, o = e.map(function(e) {
                    return {
                        text: i.format ? i.format(e, r[n]) : e.name + ": " + e.data,
                        color: e.color,
                        disableLegend: !!e.disableLegend
                    };
                });
                o = o.filter(function(e) {
                    if (!0 !== e.disableLegend) return e;
                });
                for (var a, s = [], c = {
                    x: 0,
                    y: 0
                }, l = 0; l < t.length; l++) void 0 !== (a = t[l])[n] && null !== a[n] && s.push(a[n]);
                for (var u, p = 0; p < s.length; p++) u = s[p], c.x = Math.round(u.x), c.y += u.y;
                return c.y /= s.length, {
                    textList: o,
                    offset: c
                };
            }
            function S(e, t, n, r, i, o) {
                var a = o.color.upFill, s = o.color.downFill, c = [ a, a, s, a ], l = [], u = {
                    text: i[r],
                    color: null
                };
                l.push(u), t.map(function(t) {
                    0 == r && 0 > t.data[1] - t.data[0] ? c[1] = s : (t.data[0] < e[r - 1][1] && (c[0] = s), 
                    t.data[1] < t.data[0] && (c[1] = s), t.data[2] > e[r - 1][1] && (c[2] = a), t.data[3] < e[r - 1][1] && (c[3] = s));
                    var n = {
                        text: "开盘：" + t.data[0],
                        color: c[0]
                    }, i = {
                        text: "收盘：" + t.data[1],
                        color: c[1]
                    }, o = {
                        text: "最低：" + t.data[2],
                        color: c[2]
                    }, u = {
                        text: "最高：" + t.data[3],
                        color: c[3]
                    };
                    l.push(n, i, o, u);
                });
                for (var p, d = [], f = {
                    x: 0,
                    y: 0
                }, h = 0; h < n.length; h++) void 0 !== (p = n[h])[r] && null !== p[r] && d.push(p[r]);
                return f.x = Math.round(d[0][0].x), {
                    textList: l,
                    offset: f
                };
            }
            function k(e) {
                for (var t = [], n = 0; n < e.length; n++) 1 == e[n].show && t.push(e[n]);
                return t;
            }
            function P(e, t, n, r) {
                for (var i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 0, o = -1, a = 0, s = [], c = 0; c < t[0].length; c++) s.push(t[0][c].x);
                return ("line" == n.type || "area" == n.type) && "justify" == n.xAxis.boundaryGap && (a = n.chartData.eachSpacing / 2), 
                n.categories || (a = 0), C(e, n) && s.forEach(function(t, n) {
                    e.x + i + a > t && (o = n);
                }), o;
            }
            function O(e, t) {
                var n = -1;
                if (T(e, t.area)) {
                    for (var r, i = t.points, o = -1, a = 0, s = i.length; a < s; a++) {
                        r = i[a];
                        for (var c = 0; c < r.length; c++) {
                            o += 1;
                            var l = r[c].area;
                            if (e.x > l[0] && e.x < l[2] && e.y > l[1] && e.y < l[3]) {
                                n = o;
                                break;
                            }
                        }
                    }
                    return n;
                }
                return n;
            }
            function T(e, t) {
                return e.x > t.start.x && e.x < t.end.x && e.y > t.start.y && e.y < t.end.y;
            }
            function C(e, t) {
                return e.x <= t.width - t.area[1] + 10 && e.x >= t.area[3] - 10 && e.y >= t.area[0] && e.y <= t.height - t.area[2];
            }
            function D(e, t, n) {
                var r = Math.PI, i = 2 * r / n, o = -1;
                if (L(e, t.center, t.radius)) {
                    var a = function(e) {
                        return 0 > e && (e += 2 * r), e > 2 * r && (e -= 2 * r), e;
                    }, s = Math.atan2(t.center.y - e.y, e.x - t.center.x);
                    0 > (s *= -1) && (s += 2 * r), t.angleList.map(function(e) {
                        return e = a(-1 * e);
                    }).forEach(function(e, t) {
                        var n = a(e - i / 2), c = a(e + i / 2);
                        c < n && (c += 2 * r), (s >= n && s <= c || s + 2 * r >= n && s + 2 * r <= c) && (o = t);
                    });
                }
                return o;
            }
            function j(e, t) {
                for (var n, r = -1, i = 0, o = t.series.length; i < o; i++) if (n = t.series[i], 
                e.x > n.funnelArea[0] && e.x < n.funnelArea[2] && e.y > n.funnelArea[1] && e.y < n.funnelArea[3]) {
                    r = i;
                    break;
                }
                return r;
            }
            function $(e, t) {
                for (var n, r = -1, i = 0, o = t.length; i < o; i++) if (n = t[i], e.x > n.area[0] && e.x < n.area[2] && e.y > n.area[1] && e.y < n.area[3]) {
                    r = i;
                    break;
                }
                return r;
            }
            function E(e, t) {
                for (var n, r = -1, i = t.chartData.mapData, o = t.series, a = Ie(e.y, e.x, i.bounds, i.scale, i.xoffset, i.yoffset), s = [ a.x, a.y ], c = 0, l = o.length; c < l; c++) if (n = o[c].geometry.coordinates, 
                Ne(s, n)) {
                    r = c;
                    break;
                }
                return r;
            }
            function M(e, t) {
                var n = -1;
                if (L(e, t.center, t.radius)) {
                    var r = Math.atan2(t.center.y - e.y, e.x - t.center.x);
                    r = -r;
                    for (var i, o = 0, a = t.series.length; o < a; o++) if (i = t.series[o], c(r, i._start_, i._start_ + 2 * i._proportion_ * Math.PI)) {
                        n = o;
                        break;
                    }
                }
                return n;
            }
            function L(e, t, n) {
                var r = Math.pow;
                return r(e.x - t.x, 2) + r(e.y - t.y, 2) <= r(n, 2);
            }
            function R(e) {
                var t = [], n = [];
                return e.forEach(function(e) {
                    null === e ? (n.length && t.push(n), n = []) : n.push(e);
                }), n.length && t.push(n), t;
            }
            function I(e, t, n, r) {
                var i = Math.max, o = Math.floor, a = {
                    area: {
                        start: {
                            x: 0,
                            y: 0
                        },
                        end: {
                            x: 0,
                            y: 0
                        },
                        width: 0,
                        height: 0,
                        wholeWidth: 0,
                        wholeHeight: 0
                    },
                    points: [],
                    widthArr: [],
                    heightArr: []
                };
                if (!1 === t.legend.show) return r.legendData = a, a;
                var s = t.legend.padding, c = t.legend.margin, l = t.legend.fontSize, u = 15 * t.pixelRatio, p = 5 * t.pixelRatio, d = i(t.legend.lineHeight * t.pixelRatio, l);
                if ("top" == t.legend.position || "bottom" == t.legend.position) {
                    for (var f = [], h = 0, v = [], m = [], y = 0; y < e.length; y++) {
                        var _ = e[y], b = u + p + g(_.name || "undefined", l) + t.legend.itemGap;
                        h + b > t.width - t.padding[1] - t.padding[3] ? (f.push(m), v.push(h - t.legend.itemGap), 
                        h = b, m = [ _ ]) : (h += b, m.push(_));
                    }
                    if (m.length) {
                        f.push(m), v.push(h - t.legend.itemGap), a.widthArr = v;
                        var x = i.apply(null, v);
                        switch (t.legend.float) {
                          case "left":
                            a.area.start.x = t.padding[3], a.area.end.x = t.padding[3] + 2 * s;
                            break;

                          case "right":
                            a.area.start.x = t.width - t.padding[1] - x - 2 * s, a.area.end.x = t.width - t.padding[1];
                            break;

                          default:
                            a.area.start.x = (t.width - x) / 2 - s, a.area.end.x = (t.width + x) / 2 + s;
                        }
                        a.area.width = x + 2 * s, a.area.wholeWidth = x + 2 * s, a.area.height = f.length * d + 2 * s, 
                        a.area.wholeHeight = f.length * d + 2 * s + 2 * c, a.points = f;
                    }
                } else {
                    var w = e.length, A = t.height - t.padding[0] - t.padding[2] - 2 * c - 2 * s, S = Math.min(o(A / d), w);
                    switch (a.area.height = S * d + 2 * s, a.area.wholeHeight = S * d + 2 * s, t.legend.float) {
                      case "top":
                        a.area.start.y = t.padding[0] + c, a.area.end.y = t.padding[0] + c + a.area.height;
                        break;

                      case "bottom":
                        a.area.start.y = t.height - t.padding[2] - c - a.area.height, a.area.end.y = t.height - t.padding[2] - c;
                        break;

                      default:
                        a.area.start.y = (t.height - a.area.height) / 2, a.area.end.y = (t.height + a.area.height) / 2;
                    }
                    for (var k, P = 0 == w % S ? w / S : o(w / S + 1), O = [], T = 0; T < P; T++) k = e.slice(T * S, T * S + S), 
                    O.push(k);
                    if (a.points = O, O.length) {
                        for (var C = 0; C < O.length; C++) {
                            for (var D, j = O[C], $ = 0, E = 0; E < j.length; E++) (D = u + p + g(j[E].name || "undefined", l) + t.legend.itemGap) > $ && ($ = D);
                            a.widthArr.push($), a.heightArr.push(j.length * d + 2 * s);
                        }
                        for (var M = 0, L = 0; L < a.widthArr.length; L++) M += a.widthArr[L];
                        a.area.width = M - t.legend.itemGap + 2 * s, a.area.wholeWidth = a.area.width + s;
                    }
                }
                switch (t.legend.position) {
                  case "top":
                    a.area.start.y = t.padding[0] + c, a.area.end.y = t.padding[0] + c + a.area.height;
                    break;

                  case "bottom":
                    a.area.start.y = t.height - t.padding[2] - a.area.height - c, a.area.end.y = t.height - t.padding[2] - c;
                    break;

                  case "left":
                    a.area.start.x = t.padding[3], a.area.end.x = t.padding[3] + a.area.width;
                    break;

                  case "right":
                    a.area.start.x = t.width - t.padding[1] - a.area.width, a.area.end.x = t.width - t.padding[1];
                }
                return r.legendData = a, a;
            }
            function F(e, t, n, r) {
                var i = {
                    angle: 0,
                    xAxisHeight: n.xAxisHeight
                }, o = e.map(function(e) {
                    return g(e, t.xAxis.fontSize || n.fontSize);
                }), a = Math.max.apply(this, o);
                return 1 == t.xAxis.rotateLabel && a + 2 * n.xAxisTextPadding > r && (i.angle = 45 * Math.PI / 180, 
                i.xAxisHeight = 2 * n.xAxisTextPadding + a * Math.sin(i.angle)), i;
            }
            function N(e, t) {
                var n = Math.min, i = Math.max, o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : -1, a = v(e), s = [];
                (a = a.filter(function(e) {
                    return "object" == r(e) && null !== e ? e.constructor == Array ? null !== e : null !== e.value : null !== e;
                })).map(function(e) {
                    "object" == r(e) ? e.constructor == Array ? "candle" == t.type ? e.map(function(e) {
                        s.push(e);
                    }) : s.push(e[0]) : s.push(e.value) : s.push(e);
                });
                var c = 0, l = 0;
                0 < s.length && (c = n.apply(this, s), l = i.apply(this, s)), -1 < o ? ("number" == typeof t.xAxis.data[o].min && (c = n(t.xAxis.data[o].min, c)), 
                "number" == typeof t.xAxis.data[o].max && (l = i(t.xAxis.data[o].max, l))) : ("number" == typeof t.xAxis.min && (c = n(t.xAxis.min, c)), 
                "number" == typeof t.xAxis.max && (l = i(t.xAxis.max, l))), c === l && (l += l || 10);
                for (var u = h(c, l), p = u.minRange, d = [], f = (u.maxRange - p) / t.xAxis.splitNumber, g = 0; g <= t.xAxis.splitNumber; g++) d.push(p + f * g);
                return d;
            }
            function z(e, t, n) {
                var r = {
                    angle: 0,
                    xAxisHeight: n.xAxisHeight
                };
                r.ranges = N(e, t, n), r.rangesFormat = r.ranges.map(function(e) {
                    return e = t.xAxis.format ? t.xAxis.format(e) : Ke.toFixed(e, 2);
                });
                var i = r.ranges.map(function(e) {
                    return e = Ke.toFixed(e, 2), e = t.xAxis.format ? t.xAxis.format(+e) : e;
                }), o = (r = Object.assign(r, Q(i, t, n))).eachSpacing, a = i.map(function(e) {
                    return g(e);
                }), s = Math.max.apply(this, a);
                return s + 2 * n.xAxisTextPadding > o && (r.angle = 45 * Math.PI / 180, r.xAxisHeight = 2 * n.xAxisTextPadding + s * Math.sin(r.angle)), 
                !0 === t.xAxis.disabled && (r.xAxisHeight = 0), r;
            }
            function B(e, t, n, r, i) {
                var o = Math.max, a = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : 1, s = i.extra.radar || {};
                s.max = s.max || 0;
                for (var c = o(s.max, o.apply(null, v(r))), l = [], u = 0; u < r.length; u++) !function(i) {
                    var o = r[i], s = {};
                    s.color = o.color, s.legendShape = o.legendShape, s.pointShape = o.pointShape, s.data = [], 
                    o.data.forEach(function(r, i) {
                        var o = {};
                        o.angle = e[i], o.proportion = r / c, o.position = p(n * o.proportion * a * Math.cos(o.angle), n * o.proportion * a * Math.sin(o.angle), t), 
                        s.data.push(o);
                    }), l.push(s);
                }(u);
                return l;
            }
            function U(e, t) {
                for (var n, r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 1, i = 0, o = 0, a = 0; a < e.length; a++) (n = e[a]).data = null === n.data ? 0 : n.data, 
                i += n.data;
                for (var s, c = 0; c < e.length; c++) (s = e[c]).data = null === s.data ? 0 : s.data, 
                s._proportion_ = 0 === i ? 1 / e.length * r : s.data / i * r, s._radius_ = t;
                for (var l, u = 0; u < e.length; u++) (l = e[u])._start_ = o, o += 2 * l._proportion_ * Math.PI;
                return e;
            }
            function W(e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 1;
                e = e.sort(function(e, t) {
                    return parseInt(t.data) - parseInt(e.data);
                });
                for (var r = 0; r < e.length; r++) e[r].radius = e[r].data / e[0].data * t * n, 
                e[r]._proportion_ = e[r].data / e[0].data;
                return e.reverse();
            }
            function H(e, t, n, r) {
                for (var i, o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, a = 0, s = 0, c = [], l = 0; l < e.length; l++) (i = e[l]).data = null === i.data ? 0 : i.data, 
                a += i.data, c.push(i.data);
                for (var u, p = Math.min.apply(null, c), d = Math.max.apply(null, c), f = 0; f < e.length; f++) (u = e[f]).data = null === u.data ? 0 : u.data, 
                0 === a || "area" == t ? (u._proportion_ = u.data / a * o, u._rose_proportion_ = 1 / e.length * o) : (u._proportion_ = u.data / a * o, 
                u._rose_proportion_ = u.data / a * o), u._radius_ = n + (r - n) * ((u.data - p) / (d - p));
                for (var h, g = 0; g < e.length; g++) (h = e[g])._start_ = s, s += 2 * h._rose_proportion_ * Math.PI;
                return e;
            }
            function q(e, t) {
                var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 1;
                1 == n && (n = .999999);
                for (var r, i = 0; i < e.length; i++) {
                    (r = e[i]).data = null === r.data ? 0 : r.data;
                    var o = void 0;
                    o = "circle" == t.type ? 2 : t.endAngle < t.startAngle ? 2 + t.endAngle - t.startAngle : t.startAngle - t.endAngle, 
                    r._proportion_ = o * r.data * n + t.startAngle, 2 <= r._proportion_ && (r._proportion_ %= 2);
                }
                return e;
            }
            function V(e, t, n) {
                for (var r = t, i = 0; i < e.length; i++) e[i].value = null === e[i].value ? 0 : e[i].value, 
                e[i]._startAngle_ = r, e[i]._endAngle_ = (t - n + 1) * e[i].value + t, 2 <= e[i]._endAngle_ && (e[i]._endAngle_ %= 2), 
                r = e[i]._endAngle_;
                return e;
            }
            function X(e, t, n) {
                for (var r, i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : 1, o = 0; o < e.length; o++) {
                    if (r = e[o], r.data = null === r.data ? 0 : r.data, "auto" == n.pointer.color) {
                        for (var a = 0; a < t.length; a++) if (r.data <= t[a].value) {
                            r.color = t[a].color;
                            break;
                        }
                    } else r.color = n.pointer.color;
                    var s = n.startAngle - n.endAngle + 1;
                    r._endAngle_ = s * r.data + n.startAngle, r._oldAngle_ = n.oldAngle, n.oldAngle < n.endAngle && (r._oldAngle_ += 2), 
                    r._proportion_ = r.data >= n.oldData ? (r._endAngle_ - r._oldAngle_) * i + n.oldAngle : r._oldAngle_ - (r._oldAngle_ - r._endAngle_) * i, 
                    2 <= r._proportion_ && (r._proportion_ %= 2);
                }
                return e;
            }
            function G(e) {
                e = U(e);
                for (var t = 0, n = 0; n < e.length; n++) {
                    var r = e[n], i = r.format ? r.format(+r._proportion_.toFixed(2)) : Ke.toFixed(100 * r._proportion_) + "%";
                    t = Math.max(t, g(i));
                }
                return t;
            }
            function Y(e, t, n, r, i, o) {
                return e.map(function(e) {
                    return null === e ? null : (e.width = Math.ceil((t - 2 * i.columePadding) / n), 
                    o.extra.column && o.extra.column.width && 0 < +o.extra.column.width && (e.width = Math.min(e.width, +o.extra.column.width)), 
                    0 >= e.width && (e.width = 1), e.x += (r + .5 - n / 2) * e.width, e);
                });
            }
            function J(e, t, n, r, i, o, a) {
                return e.map(function(e) {
                    return null === e ? null : (e.width = Math.ceil((t - 2 * i.columePadding) / 2), 
                    o.extra.column && o.extra.column.width && 0 < +o.extra.column.width && (e.width = Math.min(e.width, +o.extra.column.width)), 
                    0 < r && (e.width -= 2 * a), e);
                });
            }
            function K(e, t, n, r, i, o) {
                return e.map(function(e) {
                    return null === e ? null : (e.width = Math.ceil((t - 2 * i.columePadding) / 2), 
                    o.extra.column && o.extra.column.width && 0 < +o.extra.column.width && (e.width = Math.min(e.width, +o.extra.column.width)), 
                    e);
                });
            }
            function Q(e, t) {
                var n = t.width - t.area[1] - t.area[3], r = t.enableScroll ? Math.min(t.xAxis.itemCount, e.length) : e.length;
                ("line" == t.type || "area" == t.type) && 1 < r && "justify" == t.xAxis.boundaryGap && (r -= 1);
                var i = n / r, o = [], a = t.area[3], s = t.width - t.area[1];
                return e.forEach(function(e, t) {
                    o.push(a + t * i);
                }), "justify" !== t.xAxis.boundaryGap && (!0 === t.enableScroll ? o.push(a + e.length * i) : o.push(s)), 
                {
                    xAxisPoints: o,
                    startX: a,
                    endX: s,
                    eachSpacing: i
                };
            }
            function Z(e, t, n, r, i, o) {
                var a = Math.round, s = 7 < arguments.length && void 0 !== arguments[7] ? arguments[7] : 1, c = [], l = o.height - o.area[0] - o.area[2];
                return e.forEach(function(e, u) {
                    if (null === e) c.push(null); else {
                        var p = [];
                        e.forEach(function(e) {
                            var c = {
                                x: r[u] + a(i / 2)
                            }, d = e.value || e, f = l * (d - t) / (n - t);
                            f *= s, c.y = o.height - a(f) - o.area[2], p.push(c);
                        }), c.push(p);
                    }
                }), c;
            }
            function ee(e, t, n, i, o, a) {
                var s = Math.round, c = 7 < arguments.length && void 0 !== arguments[7] ? arguments[7] : 1, l = "center";
                ("line" == a.type || "area" == a.type) && (l = a.xAxis.boundaryGap);
                var u = [], p = a.height - a.area[0] - a.area[2], d = a.width - a.area[1] - a.area[3];
                return e.forEach(function(e, f) {
                    if (null === e) u.push(null); else {
                        var h = {
                            color: e.color,
                            x: i[f]
                        }, g = e;
                        if ("object" == r(e) && null !== e) if (e.constructor == Array) {
                            var v, m, y;
                            m = (v = [].concat(a.chartData.xAxisData.ranges)).shift(), y = v.pop(), g = e[1], 
                            h.x = a.area[3] + d * (e[0] - m) / (y - m);
                        } else g = e.value;
                        "center" == l && (h.x += s(o / 2));
                        var _ = p * (g - t) / (n - t);
                        _ *= c, h.y = a.height - s(_) - a.area[2], u.push(h);
                    }
                }), u;
            }
            function te(e, t, n, r, i, o, a, s, c) {
                var l = Math.round, u = 9 < arguments.length && void 0 !== arguments[9] ? arguments[9] : 1, p = [], d = o.height - o.area[0] - o.area[2];
                return e.forEach(function(e, a) {
                    if (null === e) p.push(null); else {
                        var f = {
                            color: e.color,
                            x: r[a] + l(i / 2)
                        };
                        if (0 < s) {
                            for (var h = 0, g = 0; g <= s; g++) h += c[g].data[a];
                            var v = d * (h - t) / (n - t), m = d * (h - e - t) / (n - t);
                        } else h = e, v = d * (h - t) / (n - t), m = 0;
                        var y = m;
                        v *= u, y *= u, f.y = o.height - l(v) - o.area[2], f.y0 = o.height - l(y) - o.area[2], 
                        p.push(f);
                    }
                }), p;
            }
            function ne(e, t, n, i) {
                var o = Math.min, a = Math.max, s = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : -1, c = [];
                ("stack" == i ? m(e, t.categories.length) : v(e)).filter(function(e) {
                    return "object" == r(e) && null !== e ? e.constructor == Array ? null !== e : null !== e.value : null !== e;
                }).map(function(e) {
                    "object" == r(e) ? e.constructor == Array ? "candle" == t.type ? e.map(function(e) {
                        c.push(e);
                    }) : c.push(e[1]) : c.push(e.value) : c.push(e);
                });
                var l = 0, u = 0;
                0 < c.length && (l = o.apply(this, c), u = a.apply(this, c)), -1 < s ? ("number" == typeof t.yAxis.data[s].min && (l = o(t.yAxis.data[s].min, l)), 
                "number" == typeof t.yAxis.data[s].max && (u = a(t.yAxis.data[s].max, u))) : ("number" == typeof t.yAxis.min && (l = o(t.yAxis.min, l)), 
                "number" == typeof t.yAxis.max && (u = a(t.yAxis.max, u))), l === u && (u += u || 10);
                for (var p = h(l, u), d = p.minRange, f = [], g = (p.maxRange - d) / t.yAxis.splitNumber, y = 0; y <= t.yAxis.splitNumber; y++) f.push(d + g * y);
                return f.reverse();
            }
            function re(e, t, n) {
                var r = Math.max, i = Je({}, {
                    type: ""
                }, t.extra.column), o = t.yAxis.data.length, a = Array(o);
                if (0 < o) {
                    for (var s = 0; s < o; s++) {
                        a[s] = [];
                        for (var c = 0; c < e.length; c++) e[c].index == s && a[s].push(e[c]);
                    }
                    for (var l, u = Array(o), p = Array(o), d = Array(o), f = 0; f < o; f++) !function(e, o) {
                        o = t.yAxis.data[e], 1 == t.yAxis.disabled && (o.disabled = !0), u[e] = ne(a[e], t, n, i.type, e);
                        var s = o.fontSize || n.fontSize;
                        d[e] = {
                            position: o.position ? o.position : "left",
                            width: 0
                        }, p[e] = u[e].map(function(t) {
                            return l = o, t = Ke.toFixed(t, 6), t = o.format ? o.format(+t) : t, d[e].width = r(d[e].width, g(t, s) + 5), 
                            t;
                        });
                        var c = o.calibration ? 4 * t.pixelRatio : 0;
                        d[e].width += c + 3 * t.pixelRatio, !0 === o.disabled && (d[e].width = 0), l = o;
                    }(f, l);
                } else {
                    p = [ ,  ], d = [ ,  ], (u = [ ,  ])[0] = ne(e, t, n, i.type), d[0] = {
                        position: "left",
                        width: 0
                    };
                    var h = t.yAxis.fontSize || n.fontSize;
                    p[0] = u[0].map(function(e) {
                        return e = Ke.toFixed(e, 6), e = t.yAxis.format ? t.yAxis.format(+e) : e, d[0].width = r(d[0].width, g(e, h) + 5), 
                        e;
                    }), d[0].width += 3 * t.pixelRatio, !0 === t.yAxis.disabled ? (d[0] = {
                        position: "left",
                        width: 0
                    }, t.yAxis.data[0] = {
                        disabled: !0
                    }) : t.yAxis.data[0] = {
                        disabled: !1,
                        position: "left",
                        max: t.yAxis.max,
                        min: t.yAxis.min,
                        format: t.yAxis.format
                    };
                }
                return {
                    rangesFormat: p,
                    ranges: u,
                    yAxisWidth: d
                };
            }
            function ie(e, t, n) {
                for (var r = [].concat(n.chartData.yAxisData.ranges), i = n.height - n.area[0] - n.area[2], o = n.area[0], a = [], s = 0; s < r.length; s++) {
                    var c = r[s].shift(), l = c - (c - r[s].pop()) * (e - o) / i;
                    l = n.yAxis.data[s].format ? n.yAxis.data[s].format(+l) : l.toFixed(0), a.push(l + "");
                }
                return a;
            }
            function oe(e, t) {
                for (var n, r, i = t.height - t.area[0] - t.area[2], o = 0; o < e.length; o++) {
                    e[o].yAxisIndex = e[o].yAxisIndex ? e[o].yAxisIndex : 0;
                    var a = [].concat(t.chartData.yAxisData.ranges[e[o].yAxisIndex]);
                    n = a.pop(), r = a.shift();
                    var s = i * (e[o].value - n) / (r - n);
                    e[o].y = t.height - Math.round(s) - t.area[2];
                }
                return e;
            }
            function ae(e, t) {
                var n = Math.PI;
                !0 === t.rotateLock ? !0 !== t._rotate_ && (e.translate(t.height, 0), e.rotate(90 * n / 180), 
                t._rotate_ = !0) : (e.translate(t.height, 0), e.rotate(90 * n / 180));
            }
            function se(e, t, n, r, i) {
                r.beginPath(), "hollow" == i.dataPointShapeType ? (r.setStrokeStyle(t), r.setFillStyle(i.background), 
                r.setLineWidth(2 * i.pixelRatio)) : (r.setStrokeStyle("#ffffff"), r.setFillStyle(t), 
                r.setLineWidth(1 * i.pixelRatio)), "diamond" === n ? e.forEach(function(e) {
                    null !== e && (r.moveTo(e.x, e.y - 4.5), r.lineTo(e.x - 4.5, e.y), r.lineTo(e.x, e.y + 4.5), 
                    r.lineTo(e.x + 4.5, e.y), r.lineTo(e.x, e.y - 4.5));
                }) : "circle" === n ? e.forEach(function(e) {
                    null !== e && (r.moveTo(e.x + 2.5 * i.pixelRatio, e.y), r.arc(e.x, e.y, 3 * i.pixelRatio, 0, 2 * Math.PI, !1));
                }) : "rect" === n ? e.forEach(function(e) {
                    null !== e && (r.moveTo(e.x - 3.5, e.y - 3.5), r.rect(e.x - 3.5, e.y - 3.5, 7, 7));
                }) : "triangle" == n && e.forEach(function(e) {
                    null !== e && (r.moveTo(e.x, e.y - 4.5), r.lineTo(e.x - 4.5, e.y + 4.5), r.lineTo(e.x + 4.5, e.y + 4.5), 
                    r.lineTo(e.x, e.y - 4.5));
                }), r.closePath(), r.fill(), r.stroke();
            }
            function ce(e, t, n, r) {
                var i = e.title.fontSize || t.titleFontSize, o = e.subtitle.fontSize || t.subtitleFontSize, a = e.title.name || "", s = e.subtitle.name || "", c = e.title.color || t.titleColor, l = e.subtitle.color || t.subtitleColor, u = a ? i : 0, p = s ? o : 0;
                if (s) {
                    var d = g(s, o), f = r.x - d / 2 + (e.subtitle.offsetX || 0), h = r.y + o / 2 + (e.subtitle.offsetY || 0);
                    a && (h += (u + 5) / 2), n.beginPath(), n.setFontSize(o), n.setFillStyle(l), n.fillText(s, f, h), 
                    n.closePath(), n.stroke();
                }
                if (a) {
                    var v = g(a, i), m = r.x - v / 2 + (e.title.offsetX || 0), y = r.y + i / 2 + (e.title.offsetY || 0);
                    s && (y -= (p + 5) / 2), n.beginPath(), n.setFontSize(i), n.setFillStyle(c), n.fillText(a, m, y), 
                    n.closePath(), n.stroke();
                }
            }
            function le(e, t, n, i) {
                var o = t.data;
                e.forEach(function(e, a) {
                    if (null !== e) {
                        i.beginPath(), i.setFontSize(t.textSize || n.fontSize), i.setFillStyle(t.textColor || "#666666");
                        var s = o[a];
                        "object" == r(o[a]) && null !== o[a] && (s = o[a].constructor == Array ? o[a][1] : o[a].value);
                        var c = t.format ? t.format(s) : s;
                        i.fillText(c + "", e.x - g(c, t.textSize || n.fontSize) / 2, e.y - 4), i.closePath(), 
                        i.stroke();
                    }
                });
            }
            function ue(e, t, n, r, i, o) {
                var a = Math.PI;
                t -= e.width / 2 + i.gaugeLabelTextMargin;
                for (var s = (e.startAngle - e.endAngle + 1) / e.splitLine.splitNumber, c = (e.endNumber - e.startNumber) / e.splitLine.splitNumber, l = e.startAngle, u = e.startNumber, p = 0; p < e.splitLine.splitNumber + 1; p++) {
                    var d = {
                        x: t * Math.cos(l * a),
                        y: t * Math.sin(l * a)
                    }, f = e.labelFormat ? e.labelFormat(u) : u;
                    d.x += n.x - g(f) / 2, d.y += n.y;
                    var h = d.x, v = d.y;
                    o.beginPath(), o.setFontSize(i.fontSize), o.setFillStyle(e.labelColor || "#666666"), 
                    o.fillText(f, h, v + i.fontSize / 2), o.closePath(), o.stroke(), 2 <= (l += s) && (l %= 2), 
                    u += c;
                }
            }
            function pe(e, t, n, r, i, o) {
                var a = r.extra.radar || {};
                t += i.radarLabelTextMargin, e.forEach(function(e, s) {
                    var c = {
                        x: t * Math.cos(e),
                        y: t * Math.sin(e)
                    }, l = p(c.x, c.y, n), u = l.x, d = l.y;
                    Ke.approximatelyEqual(c.x, 0) ? u -= g(r.categories[s] || "") / 2 : 0 > c.x && (u -= g(r.categories[s] || "")), 
                    o.beginPath(), o.setFontSize(i.fontSize), o.setFillStyle(a.labelColor || "#666666"), 
                    o.fillText(r.categories[s] || "", u, d + i.fontSize / 2), o.closePath(), o.stroke();
                });
            }
            function de(e, t, n, r, i, o) {
                for (var a = Math.cos, s = Math.sin, c = Math.min, l = Math.max, u = Math.PI, f = n.pieChartLinePadding, h = [], v = null, m = e.map(function(e) {
                    var t = e.format ? e.format(+e._proportion_.toFixed(2)) : Ke.toFixed(100 * e._proportion_.toFixed(4)) + "%";
                    return e._rose_proportion_ && (e._proportion_ = e._rose_proportion_), {
                        arc: 2 * u - (e._start_ + 2 * u * e._proportion_ / 2),
                        text: t,
                        color: e.color,
                        radius: e._radius_,
                        textColor: e.textColor,
                        textSize: e.textSize
                    };
                }), y = 0; y < m.length; y++) {
                    var _ = m[y], b = a(_.arc) * (_.radius + f), x = s(_.arc) * (_.radius + f), w = a(_.arc) * _.radius, A = s(_.arc) * _.radius, S = 0 <= b ? b + n.pieChartTextPadding : b - n.pieChartTextPadding, k = x, P = g(_.text, _.textSize || n.fontSize), O = k;
                    v && Ke.isSameXCoordinateArea(v.start, {
                        x: S
                    }) && (O = 0 < S ? c(k, v.start.y) : 0 > b || 0 < k ? l(k, v.start.y) : c(k, v.start.y)), 
                    0 > S && (S -= P), v = d({
                        lineStart: {
                            x: w,
                            y: A
                        },
                        lineEnd: {
                            x: b,
                            y: x
                        },
                        start: {
                            x: S,
                            y: O
                        },
                        width: P,
                        height: n.fontSize,
                        text: _.text,
                        color: _.color,
                        textColor: _.textColor,
                        textSize: _.textSize
                    }, v), h.push(v);
                }
                for (var T = 0; T < h.length; T++) {
                    var C = h[T], D = p(C.lineStart.x, C.lineStart.y, o), j = p(C.lineEnd.x, C.lineEnd.y, o), $ = p(C.start.x, C.start.y, o);
                    r.setLineWidth(1 * t.pixelRatio), r.setFontSize(n.fontSize), r.beginPath(), r.setStrokeStyle(C.color), 
                    r.setFillStyle(C.color), r.moveTo(D.x, D.y);
                    var E = 0 > C.start.x ? $.x + C.width : $.x, M = 0 > C.start.x ? $.x - 5 : $.x + 5;
                    r.quadraticCurveTo(j.x, j.y, E, $.y), r.moveTo(D.x, D.y), r.stroke(), r.closePath(), 
                    r.beginPath(), r.moveTo($.x + C.width, $.y), r.arc(E, $.y, 2, 0, 2 * u), r.closePath(), 
                    r.fill(), r.beginPath(), r.setFontSize(C.textSize || n.fontSize), r.setFillStyle(C.textColor || "#666666"), 
                    r.fillText(C.text, M, $.y + 3), r.closePath(), r.stroke(), r.closePath();
                }
            }
            function fe(e, t, n, r) {
                var o = t.extra.tooltip || {};
                o.gridType = null == o.gridType ? "solid" : o.gridType, o.dashLength = null == o.dashLength ? 4 : o.dashLength;
                var a = t.area[0], s = t.height - t.area[2];
                if ("dash" == o.gridType && r.setLineDash([ o.dashLength, o.dashLength ]), r.setStrokeStyle(o.gridColor || "#cccccc"), 
                r.setLineWidth(1 * t.pixelRatio), r.beginPath(), r.moveTo(e, a), r.lineTo(e, s), 
                r.stroke(), r.setLineDash([]), o.xAxisLabel) {
                    var c = t.categories[t.tooltip.index];
                    r.setFontSize(n.fontSize);
                    var l = g(c, n.fontSize), u = e - .5 * l, p = s;
                    r.beginPath(), r.setFillStyle(i(o.labelBgColor || n.toolTipBackground, o.labelBgOpacity || n.toolTipOpacity)), 
                    r.setStrokeStyle(o.labelBgColor || n.toolTipBackground), r.setLineWidth(1 * t.pixelRatio), 
                    r.rect(u - n.toolTipPadding, p, l + 2 * n.toolTipPadding, n.fontSize + 2 * n.toolTipPadding), 
                    r.closePath(), r.stroke(), r.fill(), r.beginPath(), r.setFontSize(n.fontSize), r.setFillStyle(o.labelFontColor || n.fontColor), 
                    r.fillText(c + "", u, p + n.toolTipPadding + n.fontSize), r.closePath(), r.stroke();
                }
            }
            function he(e, t, n) {
                for (var r, o = Je({}, {
                    type: "solid",
                    dashLength: 4,
                    data: []
                }, e.extra.markLine), a = e.area[3], s = e.width - e.area[1], c = oe(o.data, e), l = 0; l < c.length; l++) if (r = Je({}, {
                    lineColor: "#DE4A42",
                    showLabel: !1,
                    labelFontColor: "#666666",
                    labelBgColor: "#DFE8FF",
                    labelBgOpacity: .8,
                    yAxisIndex: 0
                }, c[l]), "dash" == o.type && n.setLineDash([ o.dashLength, o.dashLength ]), n.setStrokeStyle(r.lineColor), 
                n.setLineWidth(1 * e.pixelRatio), n.beginPath(), n.moveTo(a, r.y), n.lineTo(s, r.y), 
                n.stroke(), n.setLineDash([]), r.showLabel) {
                    var u = e.yAxis.format ? e.yAxis.format(+r.value) : r.value;
                    n.setFontSize(t.fontSize);
                    var p = g(u, t.fontSize), d = e.padding[3] + t.yAxisTitleWidth - t.toolTipPadding, f = Math.max(e.area[3], p + 2 * t.toolTipPadding) - d, h = r.y;
                    n.setFillStyle(i(r.labelBgColor, r.labelBgOpacity)), n.setStrokeStyle(r.labelBgColor), 
                    n.setLineWidth(1 * e.pixelRatio), n.beginPath(), n.rect(d, h - .5 * t.fontSize - t.toolTipPadding, f, t.fontSize + 2 * t.toolTipPadding), 
                    n.closePath(), n.stroke(), n.fill(), n.beginPath(), n.setFontSize(t.fontSize), n.setFillStyle(r.labelFontColor), 
                    n.fillText(u + "", d + (f - p) / 2, h + .5 * t.fontSize), n.stroke();
                }
            }
            function ge(e, t, n, r) {
                var o = Math.max, a = Je({}, {
                    gridType: "solid",
                    dashLength: 4
                }, e.extra.tooltip), s = e.area[3], c = e.width - e.area[1];
                if ("dash" == a.gridType && n.setLineDash([ a.dashLength, a.dashLength ]), n.setStrokeStyle(a.gridColor || "#cccccc"), 
                n.setLineWidth(1 * e.pixelRatio), n.beginPath(), n.moveTo(s, e.tooltip.offset.y), 
                n.lineTo(c, e.tooltip.offset.y), n.stroke(), n.setLineDash([]), a.yAxisLabel) for (var l = ie(e.tooltip.offset.y, e.series, e, t, r), u = e.chartData.yAxisData.yAxisWidth, p = e.area[3], d = e.width - e.area[1], f = 0; f < l.length; f++) {
                    n.setFontSize(t.fontSize);
                    var h = void 0, v = void 0, m = void 0, y = g(l[f], t.fontSize);
                    "left" == u[f].position ? (h = p - u[f].width, v = o(h, h + y + 2 * t.toolTipPadding)) : (h = d, 
                    v = o(h + u[f].width, h + y + 2 * t.toolTipPadding));
                    var _ = h + ((m = v - h) - y) / 2, b = e.tooltip.offset.y;
                    n.beginPath(), n.setFillStyle(i(a.labelBgColor || t.toolTipBackground, a.labelBgOpacity || t.toolTipOpacity)), 
                    n.setStrokeStyle(a.labelBgColor || t.toolTipBackground), n.setLineWidth(1 * e.pixelRatio), 
                    n.rect(h, b - .5 * t.fontSize - t.toolTipPadding, m, t.fontSize + 2 * t.toolTipPadding), 
                    n.closePath(), n.stroke(), n.fill(), n.beginPath(), n.setFontSize(t.fontSize), n.setFillStyle(a.labelFontColor || t.fontColor), 
                    n.fillText(l[f], _, b + .5 * t.fontSize), n.closePath(), n.stroke(), "left" == u[f].position ? p -= u[f].width + e.yAxis.padding : d += u[f].width + e.yAxis.padding;
                }
            }
            function ve(e, t, n, r, o) {
                var a = Je({}, {
                    activeBgColor: "#000000",
                    activeBgOpacity: .08
                }, t.extra.tooltip), s = t.area[0], c = t.height - t.area[2];
                r.beginPath(), r.setFillStyle(i(a.activeBgColor, a.activeBgOpacity)), r.rect(e - o / 2, s, o, c - s), 
                r.closePath(), r.fill();
            }
            function me(e, t, n, r, o) {
                var a = Math.round, s = Je({}, {
                    showBox: !0,
                    bgColor: "#000000",
                    bgOpacity: .7,
                    fontColor: "#FFFFFF"
                }, n.extra.tooltip), c = 4 * n.pixelRatio, l = 5 * n.pixelRatio, u = 8 * n.pixelRatio, p = !1;
                ("line" == n.type || "area" == n.type || "candle" == n.type || "mix" == n.type) && fe(n.tooltip.offset.x, n, r, o), 
                (t = Je({
                    x: 0,
                    y: 0
                }, t)).y -= 8 * n.pixelRatio;
                var d = e.map(function(e) {
                    return g(e.text, r.fontSize);
                }), f = c + l + 4 * r.toolTipPadding + Math.max.apply(null, d), h = 2 * r.toolTipPadding + e.length * r.toolTipLineHeight;
                0 == s.showBox || (t.x - Math.abs(n._scrollDistance_) + u + f > n.width && (p = !0), 
                h + t.y > n.height && (t.y = n.height - h), o.beginPath(), o.setFillStyle(i(s.bgColor || r.toolTipBackground, s.bgOpacity || r.toolTipOpacity)), 
                p ? (o.moveTo(t.x, t.y + 10 * n.pixelRatio), o.lineTo(t.x - u, t.y + 10 * n.pixelRatio - 5 * n.pixelRatio), 
                o.lineTo(t.x - u, t.y), o.lineTo(t.x - u - a(f), t.y), o.lineTo(t.x - u - a(f), t.y + h), 
                o.lineTo(t.x - u, t.y + h), o.lineTo(t.x - u, t.y + 10 * n.pixelRatio + 5 * n.pixelRatio), 
                o.lineTo(t.x, t.y + 10 * n.pixelRatio)) : (o.moveTo(t.x, t.y + 10 * n.pixelRatio), 
                o.lineTo(t.x + u, t.y + 10 * n.pixelRatio - 5 * n.pixelRatio), o.lineTo(t.x + u, t.y), 
                o.lineTo(t.x + u + a(f), t.y), o.lineTo(t.x + u + a(f), t.y + h), o.lineTo(t.x + u, t.y + h), 
                o.lineTo(t.x + u, t.y + 10 * n.pixelRatio + 5 * n.pixelRatio), o.lineTo(t.x, t.y + 10 * n.pixelRatio)), 
                o.closePath(), o.fill(), e.forEach(function(e, n) {
                    if (null !== e.color) {
                        o.beginPath(), o.setFillStyle(e.color);
                        var i = t.x + u + 2 * r.toolTipPadding, a = t.y + (r.toolTipLineHeight - r.fontSize) / 2 + r.toolTipLineHeight * n + r.toolTipPadding + 1;
                        p && (i = t.x - f - u + 2 * r.toolTipPadding), o.fillRect(i, a, c, r.fontSize), 
                        o.closePath();
                    }
                }), e.forEach(function(e, n) {
                    var i = t.x + u + 2 * r.toolTipPadding + c + l;
                    p && (i = t.x - f - u + 2 * r.toolTipPadding + +c + l);
                    var a = t.y + (r.toolTipLineHeight - r.fontSize) / 2 + r.toolTipLineHeight * n + r.toolTipPadding;
                    o.beginPath(), o.setFontSize(r.fontSize), o.setFillStyle(s.fontColor), o.fillText(e.text, i, a + r.fontSize), 
                    o.closePath(), o.stroke();
                }));
            }
            function ye(e, t, n, r) {
                var i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, o = t.chartData.xAxisData, a = o.xAxisPoints, s = o.eachSpacing, c = Je({}, {
                    type: "group",
                    width: s / 2,
                    meter: {
                        border: 4,
                        fillColor: "#FFFFFF"
                    }
                }, t.extra.column), l = [];
                r.save();
                var u = -2, p = a.length + 2;
                return t._scrollDistance_ && 0 !== t._scrollDistance_ && !0 === t.enableScroll && (r.translate(t._scrollDistance_, 0), 
                u = Math.floor(-t._scrollDistance_ / s) - 2, p = u + t.xAxis.itemCount + 4), t.tooltip && t.tooltip.textList && t.tooltip.textList.length && 1 === i && ve(t.tooltip.offset.x, t, n, r, s), 
                e.forEach(function(o, d) {
                    var f, h, g;
                    h = (f = [].concat(t.chartData.yAxisData.ranges[o.index])).pop(), g = f.shift();
                    var v = o.data;
                    switch (c.type) {
                      case "group":
                        var m = ee(v, h, g, a, s, t, n, i), y = te(v, h, g, a, s, t, n, d, e, i);
                        l.push(y), m = Y(m, s, e.length, d, n, t);
                        for (var _, b = 0; b < m.length; b++) if (null !== (_ = m[b]) && b > u && b < p) {
                            r.beginPath(), r.setStrokeStyle(_.color || o.color), r.setLineWidth(1), r.setFillStyle(_.color || o.color);
                            var x = _.x - _.width / 2, w = t.height - _.y - t.area[2];
                            r.moveTo(x - 1, _.y), r.lineTo(x + _.width - 2, _.y), r.lineTo(x + _.width - 2, t.height - t.area[2]), 
                            r.lineTo(x, t.height - t.area[2]), r.lineTo(x, _.y), r.closePath(), r.stroke(), 
                            r.fill();
                        }
                        break;

                      case "stack":
                        m = te(v, h, g, a, s, t, n, d, e, i), l.push(m), m = K(m, s, e.length, d, n, t, e);
                        for (var A, S = 0; S < m.length; S++) if (null !== (A = m[S]) && S > u && S < p) {
                            r.beginPath(), r.setFillStyle(A.color || o.color), x = A.x - A.width / 2 + 1, w = t.height - A.y - t.area[2];
                            var k = t.height - A.y0 - t.area[2];
                            0 < d && (w -= k), r.moveTo(x, A.y), r.fillRect(x, A.y, A.width - 2, w), r.closePath(), 
                            r.fill();
                        }
                        break;

                      case "meter":
                        if (m = ee(v, h, g, a, s, t, n, i), l.push(m), m = J(m, s, e.length, d, n, t, c.meter.border), 
                        0 == d) for (var P, O = 0; O < m.length; O++) null !== (P = m[O]) && O > u && O < p && (r.beginPath(), 
                        r.setFillStyle(c.meter.fillColor), x = P.x - P.width / 2, w = t.height - P.y - t.area[2], 
                        r.moveTo(x, P.y), r.fillRect(x, P.y, P.width, w), r.closePath(), r.fill(), 0 < c.meter.border && (r.beginPath(), 
                        r.setStrokeStyle(o.color), r.setLineWidth(c.meter.border * t.pixelRatio), r.moveTo(x + .5 * c.meter.border, P.y + w), 
                        r.lineTo(x + .5 * c.meter.border, P.y + .5 * c.meter.border), r.lineTo(x + P.width - .5 * c.meter.border, P.y + .5 * c.meter.border), 
                        r.lineTo(x + P.width - .5 * c.meter.border, P.y + w), r.stroke())); else for (var T, C = 0; C < m.length; C++) null !== (T = m[C]) && C > u && C < p && (r.beginPath(), 
                        r.setFillStyle(T.color || o.color), x = T.x - T.width / 2, w = t.height - T.y - t.area[2], 
                        r.moveTo(x, T.y), r.fillRect(x, T.y, T.width, w), r.closePath(), r.fill());
                    }
                }), !1 !== t.dataLabel && 1 === i && e.forEach(function(o, l) {
                    var u, p, d;
                    p = (u = [].concat(t.chartData.yAxisData.ranges[o.index])).pop(), d = u.shift();
                    var f = o.data;
                    switch (c.type) {
                      case "group":
                        var h = ee(f, p, d, a, s, t, n, i);
                        le(h = Y(h, s, e.length, l, n, t), o, n, r);
                        break;

                      case "stack":
                        le(h = te(f, p, d, a, s, t, n, l, e, i), o, n, r);
                        break;

                      case "meter":
                        le(h = ee(f, p, d, a, s, t, n, i), o, n, r);
                    }
                }), r.restore(), {
                    xAxisPoints: a,
                    calPoints: l,
                    eachSpacing: s
                };
            }
            function _e(e, t, n, r, i) {
                var o = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : 1, a = Je({}, {
                    color: {},
                    average: {}
                }, n.extra.candle);
                a.color = Je({}, {
                    upLine: "#f04864",
                    upFill: "#f04864",
                    downLine: "#2fc25b",
                    downFill: "#2fc25b"
                }, a.color), a.average = Je({}, {
                    show: !1,
                    name: [],
                    day: [],
                    color: r.colors
                }, a.average), n.extra.candle = a;
                var s = n.chartData.xAxisData, c = s.xAxisPoints, l = s.eachSpacing, p = [];
                i.save();
                var d = -2, f = c.length + 2, h = 0, g = n.width + l;
                return n._scrollDistance_ && 0 !== n._scrollDistance_ && !0 === n.enableScroll && (i.translate(n._scrollDistance_, 0), 
                d = Math.floor(-n._scrollDistance_ / l) - 2, f = d + n.xAxis.itemCount + 4, h = -n._scrollDistance_ - l + n.area[3], 
                g = h + (n.xAxis.itemCount + 4) * l), a.average.show && t.forEach(function(e) {
                    var t, a, s;
                    a = (t = [].concat(n.chartData.yAxisData.ranges[e.index])).pop(), s = t.shift();
                    for (var p, d = R(ee(e.data, a, s, c, l, n, r, o)), f = 0; f < d.length; f++) {
                        if (p = d[f], i.beginPath(), i.setStrokeStyle(e.color), i.setLineWidth(1), 1 === p.length) i.moveTo(p[0].x, p[0].y), 
                        i.arc(p[0].x, p[0].y, 1, 0, 2 * Math.PI); else {
                            i.moveTo(p[0].x, p[0].y);
                            for (var v, m = 0, y = 0; y < p.length; y++) if (v = p[y], 0 == m && v.x > h && (i.moveTo(v.x, v.y), 
                            m = 1), 0 < y && v.x > h && v.x < g) {
                                var _ = u(p, y - 1);
                                i.bezierCurveTo(_.ctrA.x, _.ctrA.y, _.ctrB.x, _.ctrB.y, v.x, v.y);
                            }
                            i.moveTo(p[0].x, p[0].y);
                        }
                        i.closePath(), i.stroke();
                    }
                }), e.forEach(function(e) {
                    var t, s, u;
                    s = (t = [].concat(n.chartData.yAxisData.ranges[e.index])).pop(), u = t.shift();
                    var h = e.data, g = Z(h, s, u, c, l, n, r, o);
                    p.push(g);
                    for (var v = R(g), m = 0; m < v[0].length; m++) if (m > d && m < f) {
                        var y = v[0][m];
                        i.beginPath(), 0 < h[m][1] - h[m][0] ? (i.setStrokeStyle(a.color.upLine), i.setFillStyle(a.color.upFill), 
                        i.setLineWidth(1 * n.pixelRatio), i.moveTo(y[3].x, y[3].y), i.lineTo(y[1].x, y[1].y), 
                        i.lineTo(y[1].x - l / 4, y[1].y), i.lineTo(y[0].x - l / 4, y[0].y), i.lineTo(y[0].x, y[0].y), 
                        i.lineTo(y[2].x, y[2].y), i.lineTo(y[0].x, y[0].y), i.lineTo(y[0].x + l / 4, y[0].y), 
                        i.lineTo(y[1].x + l / 4, y[1].y), i.lineTo(y[1].x, y[1].y), i.moveTo(y[3].x, y[3].y)) : (i.setStrokeStyle(a.color.downLine), 
                        i.setFillStyle(a.color.downFill), i.setLineWidth(1 * n.pixelRatio), i.moveTo(y[3].x, y[3].y), 
                        i.lineTo(y[0].x, y[0].y), i.lineTo(y[0].x - l / 4, y[0].y), i.lineTo(y[1].x - l / 4, y[1].y), 
                        i.lineTo(y[1].x, y[1].y), i.lineTo(y[2].x, y[2].y), i.lineTo(y[1].x, y[1].y), i.lineTo(y[1].x + l / 4, y[1].y), 
                        i.lineTo(y[0].x + l / 4, y[0].y), i.lineTo(y[0].x, y[0].y), i.moveTo(y[3].x, y[3].y)), 
                        i.closePath(), i.fill(), i.stroke();
                    }
                }), i.restore(), {
                    xAxisPoints: c,
                    calPoints: p,
                    eachSpacing: l
                };
            }
            function be(e, t, n, r) {
                var o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, a = Je({}, {
                    type: "straight",
                    opacity: .2,
                    addLine: !1,
                    width: 2,
                    gradient: !1
                }, t.extra.area), s = t.chartData.xAxisData, c = s.xAxisPoints, l = s.eachSpacing, p = t.height - t.area[2], d = [];
                r.save();
                var f = 0, h = t.width + l;
                return t._scrollDistance_ && 0 !== t._scrollDistance_ && !0 === t.enableScroll && (r.translate(t._scrollDistance_, 0), 
                f = -t._scrollDistance_ - l + t.area[3], h = f + (t.xAxis.itemCount + 4) * l), e.forEach(function(e) {
                    var s, g, v;
                    g = (s = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), v = s.shift();
                    var m = ee(e.data, g, v, c, l, t, n, o);
                    d.push(m);
                    for (var y, _ = R(m), b = 0; b < _.length; b++) {
                        if (y = _[b], r.beginPath(), r.setStrokeStyle(i(e.color, a.opacity)), a.gradient) {
                            var x = r.createLinearGradient(0, t.area[0], 0, t.height - t.area[2]);
                            x.addColorStop("0", i(e.color, a.opacity)), x.addColorStop("1.0", i("#FFFFFF", .1)), 
                            r.setFillStyle(x);
                        } else r.setFillStyle(i(e.color, a.opacity));
                        if (r.setLineWidth(a.width * t.pixelRatio), 1 < y.length) {
                            var w = y[0], A = y[y.length - 1];
                            r.moveTo(w.x, w.y);
                            var S = 0;
                            if ("curve" === a.type) {
                                for (var k, P = 0; P < y.length; P++) if (k = y[P], 0 == S && k.x > f && (r.moveTo(k.x, k.y), 
                                S = 1), 0 < P && k.x > f && k.x < h) {
                                    var O = u(y, P - 1);
                                    r.bezierCurveTo(O.ctrA.x, O.ctrA.y, O.ctrB.x, O.ctrB.y, k.x, k.y);
                                }
                            } else for (var T, C = 0; C < y.length; C++) T = y[C], 0 == S && T.x > f && (r.moveTo(T.x, T.y), 
                            S = 1), 0 < C && T.x > f && T.x < h && r.lineTo(T.x, T.y);
                            r.lineTo(A.x, p), r.lineTo(w.x, p), r.lineTo(w.x, w.y);
                        } else {
                            var D = y[0];
                            r.moveTo(D.x - l / 2, D.y), r.lineTo(D.x + l / 2, D.y), r.lineTo(D.x + l / 2, p), 
                            r.lineTo(D.x - l / 2, p), r.moveTo(D.x - l / 2, D.y);
                        }
                        if (r.closePath(), r.fill(), a.addLine) {
                            if ("dash" == e.lineType) {
                                var j = e.dashLength ? e.dashLength : 8;
                                j *= t.pixelRatio, r.setLineDash([ j, j ]);
                            }
                            if (r.beginPath(), r.setStrokeStyle(e.color), r.setLineWidth(a.width * t.pixelRatio), 
                            1 === y.length) r.moveTo(y[0].x, y[0].y), r.arc(y[0].x, y[0].y, 1, 0, 2 * Math.PI); else {
                                r.moveTo(y[0].x, y[0].y);
                                var $ = 0;
                                if ("curve" === a.type) {
                                    for (var E, M = 0; M < y.length; M++) if (E = y[M], 0 == $ && E.x > f && (r.moveTo(E.x, E.y), 
                                    $ = 1), 0 < M && E.x > f && E.x < h) {
                                        var L = u(y, M - 1);
                                        r.bezierCurveTo(L.ctrA.x, L.ctrA.y, L.ctrB.x, L.ctrB.y, E.x, E.y);
                                    }
                                } else for (var I, F = 0; F < y.length; F++) I = y[F], 0 == $ && I.x > f && (r.moveTo(I.x, I.y), 
                                $ = 1), 0 < F && I.x > f && I.x < h && r.lineTo(I.x, I.y);
                                r.moveTo(y[0].x, y[0].y);
                            }
                            r.stroke(), r.setLineDash([]);
                        }
                    }
                    !1 !== t.dataPointShape && se(m, e.color, e.pointShape, r, t);
                }), !1 !== t.dataLabel && 1 === o && e.forEach(function(e) {
                    var i, a, s;
                    a = (i = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), s = i.shift(), 
                    le(ee(e.data, a, s, c, l, t, n, o), e, n, r);
                }), r.restore(), {
                    xAxisPoints: c,
                    calPoints: d,
                    eachSpacing: l
                };
            }
            function xe(e, t, n, r) {
                var i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, o = Je({}, {
                    type: "straight",
                    width: 2
                }, t.extra.line);
                o.width *= t.pixelRatio;
                var a = t.chartData.xAxisData, s = a.xAxisPoints, c = a.eachSpacing, l = [];
                r.save();
                var p = 0, d = t.width + c;
                return t._scrollDistance_ && 0 !== t._scrollDistance_ && !0 === t.enableScroll && (r.translate(t._scrollDistance_, 0), 
                p = -t._scrollDistance_ - c + t.area[3], d = p + (t.xAxis.itemCount + 4) * c), e.forEach(function(e) {
                    var a, f, h;
                    f = (a = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), h = a.shift();
                    var g = ee(e.data, f, h, s, c, t, n, i);
                    l.push(g);
                    var v = R(g);
                    if ("dash" == e.lineType) {
                        var m = e.dashLength ? e.dashLength : 8;
                        m *= t.pixelRatio, r.setLineDash([ m, m ]);
                    }
                    r.beginPath(), r.setStrokeStyle(e.color), r.setLineWidth(o.width), v.forEach(function(e) {
                        if (1 === e.length) r.moveTo(e[0].x, e[0].y), r.arc(e[0].x, e[0].y, 1, 0, 2 * Math.PI); else {
                            r.moveTo(e[0].x, e[0].y);
                            var t = 0;
                            if ("curve" === o.type) {
                                for (var n, i = 0; i < e.length; i++) if (n = e[i], 0 == t && n.x > p && (r.moveTo(n.x, n.y), 
                                t = 1), 0 < i && n.x > p && n.x < d) {
                                    var a = u(e, i - 1);
                                    r.bezierCurveTo(a.ctrA.x, a.ctrA.y, a.ctrB.x, a.ctrB.y, n.x, n.y);
                                }
                            } else for (var s, c = 0; c < e.length; c++) s = e[c], 0 == t && s.x > p && (r.moveTo(s.x, s.y), 
                            t = 1), 0 < c && s.x > p && s.x < d && r.lineTo(s.x, s.y);
                            r.moveTo(e[0].x, e[0].y);
                        }
                    }), r.stroke(), r.setLineDash([]), !1 !== t.dataPointShape && se(g, e.color, e.pointShape, r, t);
                }), !1 !== t.dataLabel && 1 === i && e.forEach(function(e) {
                    var o, a, l;
                    a = (o = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), l = o.shift(), 
                    le(ee(e.data, a, l, s, c, t, n, i), e, n, r);
                }), r.restore(), {
                    xAxisPoints: s,
                    calPoints: l,
                    eachSpacing: c
                };
            }
            function we(e, t, n, r) {
                var o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, a = t.chartData.xAxisData, s = a.xAxisPoints, c = a.eachSpacing, l = t.height - t.area[2], p = [], d = 0, f = 0;
                e.forEach(function(e) {
                    "column" == e.type && (f += 1);
                }), r.save();
                var h = -2, g = s.length + 2, v = 0, m = t.width + c;
                return t._scrollDistance_ && 0 !== t._scrollDistance_ && !0 === t.enableScroll && (r.translate(t._scrollDistance_, 0), 
                h = Math.floor(-t._scrollDistance_ / c) - 2, g = h + t.xAxis.itemCount + 4, v = -t._scrollDistance_ - c + t.area[3], 
                m = v + (t.xAxis.itemCount + 4) * c), e.forEach(function(e) {
                    var a, y, _;
                    y = (a = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), _ = a.shift();
                    var b = ee(e.data, y, _, s, c, t, n, o);
                    if (p.push(b), "column" == e.type) {
                        b = Y(b, c, f, d, n, t);
                        for (var x, w = 0; w < b.length; w++) if (null !== (x = b[w]) && w > h && w < g) {
                            r.beginPath(), r.setStrokeStyle(x.color || e.color), r.setLineWidth(1), r.setFillStyle(x.color || e.color);
                            var A = x.x - x.width / 2;
                            t.height, x.y, t.area[2], r.moveTo(A, x.y), r.moveTo(A - 1, x.y), r.lineTo(A + x.width - 2, x.y), 
                            r.lineTo(A + x.width - 2, t.height - t.area[2]), r.lineTo(A, t.height - t.area[2]), 
                            r.lineTo(A, x.y), r.closePath(), r.stroke(), r.fill(), r.closePath(), r.fill();
                        }
                        d += 1;
                    }
                    if ("area" == e.type) for (var S, k = R(b), P = 0; P < k.length; P++) {
                        if (S = k[P], r.beginPath(), r.setStrokeStyle(e.color), r.setFillStyle(i(e.color, .2)), 
                        r.setLineWidth(2 * t.pixelRatio), 1 < S.length) {
                            var O = S[0], T = S[S.length - 1];
                            r.moveTo(O.x, O.y);
                            var C = 0;
                            if ("curve" === e.style) {
                                for (var D, j = 0; j < S.length; j++) if (D = S[j], 0 == C && D.x > v && (r.moveTo(D.x, D.y), 
                                C = 1), 0 < j && D.x > v && D.x < m) {
                                    var $ = u(S, j - 1);
                                    r.bezierCurveTo($.ctrA.x, $.ctrA.y, $.ctrB.x, $.ctrB.y, D.x, D.y);
                                }
                            } else for (var E, M = 0; M < S.length; M++) E = S[M], 0 == C && E.x > v && (r.moveTo(E.x, E.y), 
                            C = 1), 0 < M && E.x > v && E.x < m && r.lineTo(E.x, E.y);
                            r.lineTo(T.x, l), r.lineTo(O.x, l), r.lineTo(O.x, O.y);
                        } else {
                            var L = S[0];
                            r.moveTo(L.x - c / 2, L.y), r.lineTo(L.x + c / 2, L.y), r.lineTo(L.x + c / 2, l), 
                            r.lineTo(L.x - c / 2, l), r.moveTo(L.x - c / 2, L.y);
                        }
                        r.closePath(), r.fill();
                    }
                    "line" == e.type && R(b).forEach(function(n) {
                        if ("dash" == e.lineType) {
                            var i = e.dashLength ? e.dashLength : 8;
                            i *= t.pixelRatio, r.setLineDash([ i, i ]);
                        }
                        if (r.beginPath(), r.setStrokeStyle(e.color), r.setLineWidth(2 * t.pixelRatio), 
                        1 === n.length) r.moveTo(n[0].x, n[0].y), r.arc(n[0].x, n[0].y, 1, 0, 2 * Math.PI); else {
                            r.moveTo(n[0].x, n[0].y);
                            var o = 0;
                            if ("curve" == e.style) {
                                for (var a, s = 0; s < n.length; s++) if (a = n[s], 0 == o && a.x > v && (r.moveTo(a.x, a.y), 
                                o = 1), 0 < s && a.x > v && a.x < m) {
                                    var c = u(n, s - 1);
                                    r.bezierCurveTo(c.ctrA.x, c.ctrA.y, c.ctrB.x, c.ctrB.y, a.x, a.y);
                                }
                            } else for (var l, p = 0; p < n.length; p++) l = n[p], 0 == o && l.x > v && (r.moveTo(l.x, l.y), 
                            o = 1), 0 < p && l.x > v && l.x < m && r.lineTo(l.x, l.y);
                            r.moveTo(n[0].x, n[0].y);
                        }
                        r.stroke(), r.setLineDash([]);
                    }), "point" == e.type && (e.addPoint = !0), 1 == e.addPoint && "column" !== e.type && se(b, e.color, e.pointShape, r, t);
                }), !1 !== t.dataLabel && 1 === o && (d = 0, e.forEach(function(e) {
                    var i, a, l;
                    a = (i = [].concat(t.chartData.yAxisData.ranges[e.index])).pop(), l = i.shift();
                    var u = ee(e.data, a, l, s, c, t, n, o);
                    "column" === e.type ? (u = Y(u, c, f, d, n, t), le(u, e, n, r), d += 1) : le(u, e, n, r);
                })), r.restore(), {
                    xAxisPoints: s,
                    calPoints: p,
                    eachSpacing: c
                };
            }
            function Ae(e, t, n, r, i, o) {
                (e.extra.tooltip || {}).horizentalLine && e.tooltip && 1 === r && ("line" == e.type || "area" == e.type || "column" == e.type || "candle" == e.type || "mix" == e.type) && ge(e, t, n, i, o), 
                n.save(), e._scrollDistance_ && 0 !== e._scrollDistance_ && !0 === e.enableScroll && n.translate(e._scrollDistance_, 0), 
                e.tooltip && e.tooltip.textList && e.tooltip.textList.length && 1 === r && me(e.tooltip.textList, e.tooltip.offset, e, t, n, i, o), 
                n.restore();
            }
            function Se(e, t, n, r) {
                var i = Math.ceil, o = t.chartData.xAxisData, a = o.xAxisPoints, s = o.startX, c = o.endX, u = o.eachSpacing, p = "center";
                ("line" == t.type || "area" == t.type) && (p = t.xAxis.boundaryGap);
                var d = t.height - t.area[2], f = t.area[0];
                if (t.enableScroll && t.xAxis.scrollShow) {
                    var h = t.height - t.area[2] + n.xAxisHeight, v = c - s, m = u * (a.length - 1), y = 0;
                    t._scrollDistance_ && (y = -t._scrollDistance_ * v / m), r.beginPath(), r.setLineCap("round"), 
                    r.setLineWidth(6 * t.pixelRatio), r.setStrokeStyle(t.xAxis.scrollBackgroundColor || "#EFEBEF"), 
                    r.moveTo(s, h), r.lineTo(c, h), r.stroke(), r.closePath(), r.beginPath(), r.setLineCap("round"), 
                    r.setLineWidth(6 * t.pixelRatio), r.setStrokeStyle(t.xAxis.scrollColor || "#A6A6A6"), 
                    r.moveTo(s + y, h), r.lineTo(s + y + v * v / m, h), r.stroke(), r.closePath(), r.setLineCap("butt");
                }
                if (r.save(), t._scrollDistance_ && 0 !== t._scrollDistance_ && r.translate(t._scrollDistance_, 0), 
                !0 === t.xAxis.calibration && (r.setStrokeStyle(t.xAxis.gridColor || "#cccccc"), 
                r.setLineCap("butt"), r.setLineWidth(1 * t.pixelRatio), a.forEach(function(e, n) {
                    0 < n && (r.beginPath(), r.moveTo(e - u / 2, d), r.lineTo(e - u / 2, d + 3 * t.pixelRatio), 
                    r.closePath(), r.stroke());
                })), !0 !== t.xAxis.disableGrid && (r.setStrokeStyle(t.xAxis.gridColor || "#cccccc"), 
                r.setLineCap("butt"), r.setLineWidth(1 * t.pixelRatio), "dash" == t.xAxis.gridType && r.setLineDash([ t.xAxis.dashLength, t.xAxis.dashLength ]), 
                t.xAxis.gridEval = t.xAxis.gridEval || 1, a.forEach(function(e, n) {
                    0 == n % t.xAxis.gridEval && (r.beginPath(), r.moveTo(e, d), r.lineTo(e, f), r.stroke());
                }), r.setLineDash([])), !0 !== t.xAxis.disabled) {
                    var _ = e.length;
                    t.xAxis.labelCount && (_ = t.xAxis.itemCount ? i(e.length / t.xAxis.itemCount * t.xAxis.labelCount) : t.xAxis.labelCount, 
                    _ -= 1);
                    for (var b = i(e.length / _), x = [], w = e.length, A = 0; A < w; A++) 0 == A % b ? x.push(e[A]) : x.push("");
                    x[w - 1] = e[w - 1];
                    var S = t.xAxis.fontSize || n.fontSize;
                    0 === n._xAxisTextAngle_ ? x.forEach(function(e, i) {
                        var o = -g(e + "", S) / 2;
                        "center" == p && (o += u / 2);
                        var s = 0;
                        t.xAxis.scrollShow && (s = 6 * t.pixelRatio), r.beginPath(), r.setFontSize(S), r.setFillStyle(t.xAxis.fontColor || "#666666"), 
                        r.fillText(e + "", a[i] + o, d + S + (n.xAxisHeight - s - S) / 2), r.closePath(), 
                        r.stroke();
                    }) : x.forEach(function(e, i) {
                        r.save(), r.beginPath(), r.setFontSize(S), r.setFillStyle(t.xAxis.fontColor || "#666666");
                        var o = -g(e + "", S);
                        "center" == p && (o += u / 2);
                        var s = l(a[i] + u / 2, d + S / 2 + 5, t.height), c = s.transX, f = s.transY;
                        r.rotate(-1 * n._xAxisTextAngle_), r.translate(c, f), r.fillText(e + "", a[i] + o, d + S + 5), 
                        r.closePath(), r.stroke(), r.restore();
                    });
                }
                r.restore(), t.xAxis.axisLine && (r.beginPath(), r.setStrokeStyle(t.xAxis.axisLineColor), 
                r.setLineWidth(1 * t.pixelRatio), r.moveTo(s, t.height - t.area[2]), r.lineTo(c, t.height - t.area[2]), 
                r.stroke());
            }
            function ke(e, t, n, r) {
                if (!0 !== t.yAxis.disableGrid) {
                    for (var i = (t.height - t.area[0] - t.area[2]) / t.yAxis.splitNumber, o = t.area[3], a = t.chartData.xAxisData.xAxisPoints, s = t.chartData.xAxisData.eachSpacing * (a.length - 1), c = [], l = 0; l < t.yAxis.splitNumber + 1; l++) c.push(t.height - t.area[2] - i * l);
                    r.save(), t._scrollDistance_ && 0 !== t._scrollDistance_ && r.translate(t._scrollDistance_, 0), 
                    "dash" == t.yAxis.gridType && r.setLineDash([ t.yAxis.dashLength, t.yAxis.dashLength ]), 
                    r.setStrokeStyle(t.yAxis.gridColor), r.setLineWidth(1 * t.pixelRatio), c.forEach(function(e) {
                        r.beginPath(), r.moveTo(o, e), r.lineTo(o + s, e), r.stroke();
                    }), r.setLineDash([]), r.restore();
                }
            }
            function Pe(e, t, n, r) {
                if (!0 !== t.yAxis.disabled) {
                    var i = (t.height - t.area[0] - t.area[2]) / t.yAxis.splitNumber, o = t.area[3], a = t.width - t.area[1], s = t.height - t.area[2], c = s + n.xAxisHeight;
                    t.xAxis.scrollShow && (c -= 3 * t.pixelRatio), t.xAxis.rotateLabel && (c = t.height - t.area[2] + 3), 
                    r.beginPath(), r.setFillStyle(t.background || "#ffffff"), 0 > t._scrollDistance_ && r.fillRect(0, 0, o, c), 
                    1 == t.enableScroll && r.fillRect(a, 0, t.width, c), r.closePath(), r.stroke();
                    for (var l = [], u = 0; u <= t.yAxis.splitNumber; u++) l.push(t.area[0] + i * u);
                    for (var p, d = t.area[3], f = t.width - t.area[1], h = 0; h < t.yAxis.data.length; h++) !function(e, i) {
                        if (!0 !== (e = t.yAxis.data[i]).disabled) {
                            var o = t.chartData.yAxisData.rangesFormat[i], a = e.fontSize || n.fontSize, c = t.chartData.yAxisData.yAxisWidth[i];
                            if (o.forEach(function(n, i) {
                                var o = l[i] ? l[i] : s;
                                r.beginPath(), r.setFontSize(a), r.setLineWidth(1 * t.pixelRatio), r.setStrokeStyle(e.axisLineColor || "#cccccc"), 
                                r.setFillStyle(e.fontColor || "#666666"), "left" == c.position ? (r.fillText(n + "", d - c.width, o + a / 2), 
                                1 == e.calibration && (r.moveTo(d, o), r.lineTo(d - 3 * t.pixelRatio, o))) : (r.fillText(n + "", f + 4 * t.pixelRatio, o + a / 2), 
                                1 == e.calibration && (r.moveTo(f, o), r.lineTo(f + 3 * t.pixelRatio, o))), r.closePath(), 
                                r.stroke();
                            }), !1 !== e.axisLine && (r.beginPath(), r.setStrokeStyle(e.axisLineColor || "#cccccc"), 
                            r.setLineWidth(1 * t.pixelRatio), "left" == c.position ? (r.moveTo(d, t.height - t.area[2]), 
                            r.lineTo(d, t.area[0])) : (r.moveTo(f, t.height - t.area[2]), r.lineTo(f, t.area[0])), 
                            r.stroke()), t.yAxis.showTitle) {
                                var u = e.titleFontSize || n.fontSize, h = e.title;
                                r.beginPath(), r.setFontSize(u), r.setFillStyle(e.titleFontColor || "#666666"), 
                                "left" == c.position ? r.fillText(h, d - g(h, u) / 2, t.area[0] - 10 * t.pixelRatio) : r.fillText(h, f - g(h, u) / 2, t.area[0] - 10 * t.pixelRatio), 
                                r.closePath(), r.stroke();
                            }
                            "left" == c.position ? d -= c.width + t.yAxis.padding : f += c.width + t.yAxis.padding;
                        }
                        p = e;
                    }(p, h);
                }
            }
            function Oe(e, t, n, r, i) {
                if (!1 !== t.legend.show) {
                    var o = i.legendData, a = o.points, s = o.area, c = t.legend.padding, l = t.legend.fontSize, u = 15 * t.pixelRatio, p = 5 * t.pixelRatio, d = t.legend.itemGap, f = Math.max(t.legend.lineHeight * t.pixelRatio, l);
                    r.beginPath(), r.setLineWidth(t.legend.borderWidth), r.setStrokeStyle(t.legend.borderColor), 
                    r.setFillStyle(t.legend.backgroundColor), r.moveTo(s.start.x, s.start.y), r.rect(s.start.x, s.start.y, s.width, s.height), 
                    r.closePath(), r.fill(), r.stroke(), a.forEach(function(e, i) {
                        var a = 0, h = 0;
                        a = o.widthArr[i], h = o.heightArr[i];
                        var v = 0, m = 0;
                        "top" == t.legend.position || "bottom" == t.legend.position ? (v = s.start.x + (s.width - a) / 2, 
                        m = s.start.y + c + i * f) : (a = 0 == i ? 0 : o.widthArr[i - 1], v = s.start.x + c + a, 
                        m = s.start.y + c + (s.height - h) / 2), r.setFontSize(n.fontSize);
                        for (var y, _ = 0; _ < e.length; _++) {
                            switch (y = e[_], y.area = [ 0, 0, 0, 0 ], y.area[0] = v, y.area[1] = m, y.area[3] = m + f, 
                            r.beginPath(), r.setLineWidth(1 * t.pixelRatio), r.setStrokeStyle(y.show ? y.color : t.legend.hiddenColor), 
                            r.setFillStyle(y.show ? y.color : t.legend.hiddenColor), y.legendShape) {
                              case "line":
                                r.moveTo(v, m + .5 * f - 2 * t.pixelRatio), r.fillRect(v, m + .5 * f - 2 * t.pixelRatio, 15 * t.pixelRatio, 4 * t.pixelRatio);
                                break;

                              case "triangle":
                                r.moveTo(v + 7.5 * t.pixelRatio, m + .5 * f - 5 * t.pixelRatio), r.lineTo(v + 2.5 * t.pixelRatio, m + .5 * f + 5 * t.pixelRatio), 
                                r.lineTo(v + 12.5 * t.pixelRatio, m + .5 * f + 5 * t.pixelRatio), r.lineTo(v + 7.5 * t.pixelRatio, m + .5 * f - 5 * t.pixelRatio);
                                break;

                              case "diamond":
                                r.moveTo(v + 7.5 * t.pixelRatio, m + .5 * f - 5 * t.pixelRatio), r.lineTo(v + 2.5 * t.pixelRatio, m + .5 * f), 
                                r.lineTo(v + 7.5 * t.pixelRatio, m + .5 * f + 5 * t.pixelRatio), r.lineTo(v + 12.5 * t.pixelRatio, m + .5 * f), 
                                r.lineTo(v + 7.5 * t.pixelRatio, m + .5 * f - 5 * t.pixelRatio);
                                break;

                              case "circle":
                                r.moveTo(v + 7.5 * t.pixelRatio, m + .5 * f), r.arc(v + 7.5 * t.pixelRatio, m + .5 * f, 5 * t.pixelRatio, 0, 2 * Math.PI);
                                break;

                              case "rect":
                                r.moveTo(v, m + .5 * f - 5 * t.pixelRatio), r.fillRect(v, m + .5 * f - 5 * t.pixelRatio, 15 * t.pixelRatio, 10 * t.pixelRatio);
                                break;

                              default:
                                r.moveTo(v, m + .5 * f - 5 * t.pixelRatio), r.fillRect(v, m + .5 * f - 5 * t.pixelRatio, 15 * t.pixelRatio, 10 * t.pixelRatio);
                            }
                            r.closePath(), r.fill(), r.stroke(), v += u + p, r.beginPath(), r.setFontSize(l), 
                            r.setFillStyle(y.show ? t.legend.fontColor : t.legend.hiddenColor), r.fillText(y.name, v, m + (.5 * f + .5 * l - 2)), 
                            r.closePath(), r.stroke(), "top" == t.legend.position || "bottom" == t.legend.position ? (v += g(y.name, l) + d, 
                            y.area[2] = v) : (y.area[2] = v + g(y.name, l) + d, v -= u + p, m += f);
                        }
                    });
                }
            }
            function Te(e, t, n, r) {
                var o = Math.PI, a = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, s = Je({}, {
                    activeOpacity: .5,
                    activeRadius: 10 * t.pixelRatio,
                    offsetAngle: 0,
                    labelWidth: 15 * t.pixelRatio,
                    ringWidth: 0,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF"
                }, t.extra.pie), c = {
                    x: t.area[3] + (t.width - t.area[1] - t.area[3]) / 2,
                    y: t.area[0] + (t.height - t.area[0] - t.area[2]) / 2
                };
                0 == n.pieChartLinePadding && (n.pieChartLinePadding = s.activeRadius);
                var l = Math.min((t.width - t.area[1] - t.area[3]) / 2 - n.pieChartLinePadding - n.pieChartTextPadding - n._pieTextMaxLength_, (t.height - t.area[0] - t.area[2]) / 2 - n.pieChartLinePadding - n.pieChartTextPadding);
                e = U(e, l, a);
                var u = s.activeRadius;
                if ((e = e.map(function(e) {
                    return e._start_ += s.offsetAngle * o / 180, e;
                })).forEach(function(e, n) {
                    t.tooltip && t.tooltip.index == n && (r.beginPath(), r.setFillStyle(i(e.color, t.extra.pie.activeOpacity || .5)), 
                    r.moveTo(c.x, c.y), r.arc(c.x, c.y, e._radius_ + u, e._start_, e._start_ + 2 * e._proportion_ * o), 
                    r.closePath(), r.fill()), r.beginPath(), r.setLineWidth(s.borderWidth * t.pixelRatio), 
                    r.lineJoin = "round", r.setStrokeStyle(s.borderColor), r.setFillStyle(e.color), 
                    r.moveTo(c.x, c.y), r.arc(c.x, c.y, e._radius_, e._start_, e._start_ + 2 * e._proportion_ * o), 
                    r.closePath(), r.fill(), 1 == s.border && r.stroke();
                }), "ring" === t.type) {
                    var p = .6 * l;
                    "number" == typeof t.extra.pie.ringWidth && 0 < t.extra.pie.ringWidth && (p = Math.max(0, l - t.extra.pie.ringWidth)), 
                    r.beginPath(), r.setFillStyle(t.background || "#ffffff"), r.moveTo(c.x, c.y), r.arc(c.x, c.y, p, 0, 2 * o), 
                    r.closePath(), r.fill();
                }
                if (!1 !== t.dataLabel && 1 === a) {
                    for (var d = !1, f = 0, h = e.length; f < h; f++) if (0 < e[f].data) {
                        d = !0;
                        break;
                    }
                    d && de(e, t, n, r, l, c);
                }
                return 1 === a && "ring" === t.type && ce(t, n, r, c), {
                    center: c,
                    radius: l,
                    series: e
                };
            }
            function Ce(e, t, n, r) {
                var o = Math.PI, a = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, s = Je({}, {
                    type: "area",
                    activeOpacity: .5,
                    activeRadius: 10 * t.pixelRatio,
                    offsetAngle: 0,
                    labelWidth: 15 * t.pixelRatio,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF"
                }, t.extra.rose);
                0 == n.pieChartLinePadding && (n.pieChartLinePadding = s.activeRadius);
                var c = {
                    x: t.area[3] + (t.width - t.area[1] - t.area[3]) / 2,
                    y: t.area[0] + (t.height - t.area[0] - t.area[2]) / 2
                }, l = Math.min((t.width - t.area[1] - t.area[3]) / 2 - n.pieChartLinePadding - n.pieChartTextPadding - n._pieTextMaxLength_, (t.height - t.area[0] - t.area[2]) / 2 - n.pieChartLinePadding - n.pieChartTextPadding), u = s.minRadius || .5 * l;
                e = H(e, s.type, u, l, a);
                var p = s.activeRadius;
                if ((e = e.map(function(e) {
                    return e._start_ += (s.offsetAngle || 0) * o / 180, e;
                })).forEach(function(e, n) {
                    t.tooltip && t.tooltip.index == n && (r.beginPath(), r.setFillStyle(i(e.color, s.activeOpacity || .5)), 
                    r.moveTo(c.x, c.y), r.arc(c.x, c.y, p + e._radius_, e._start_, e._start_ + 2 * e._rose_proportion_ * o), 
                    r.closePath(), r.fill()), r.beginPath(), r.setLineWidth(s.borderWidth * t.pixelRatio), 
                    r.lineJoin = "round", r.setStrokeStyle(s.borderColor), r.setFillStyle(e.color), 
                    r.moveTo(c.x, c.y), r.arc(c.x, c.y, e._radius_, e._start_, e._start_ + 2 * e._rose_proportion_ * o), 
                    r.closePath(), r.fill(), 1 == s.border && r.stroke();
                }), !1 !== t.dataLabel && 1 === a) {
                    for (var d = !1, f = 0, h = e.length; f < h; f++) if (0 < e[f].data) {
                        d = !0;
                        break;
                    }
                    d && de(e, t, n, r, l, c);
                }
                return {
                    center: c,
                    radius: l,
                    series: e
                };
            }
            function De(e, t, n, r) {
                var i = Math.PI, o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, a = Je({}, {
                    startAngle: .75,
                    endAngle: .25,
                    type: "default",
                    width: 12 * t.pixelRatio,
                    gap: 2 * t.pixelRatio
                }, t.extra.arcbar);
                e = q(e, a, o);
                var s, c = a.center ? a.center : {
                    x: t.width / 2,
                    y: t.height / 2
                };
                a.radius ? s = a.radius : (s = Math.min(c.x, c.y), s -= 5 * t.pixelRatio, s -= a.width / 2);
                for (var l, u = 0; u < e.length; u++) l = e[u], r.setLineWidth(a.width), r.setStrokeStyle(a.backgroundColor || "#E9E9E9"), 
                r.setLineCap("round"), r.beginPath(), "default" == a.type ? r.arc(c.x, c.y, s - (a.width + a.gap) * u, a.startAngle * i, a.endAngle * i, !1) : r.arc(c.x, c.y, s - (a.width + a.gap) * u, 0, 2 * i, !1), 
                r.stroke(), r.setLineWidth(a.width), r.setStrokeStyle(l.color), r.setLineCap("round"), 
                r.beginPath(), r.arc(c.x, c.y, s - (a.width + a.gap) * u, a.startAngle * i, l._proportion_ * i, !1), 
                r.stroke();
                return ce(t, n, r, c), {
                    center: c,
                    radius: s,
                    series: e
                };
            }
            function je(e, t, n, r, o) {
                var a = Math.PI, s = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : 1, c = Je({}, {
                    type: "default",
                    startAngle: .75,
                    endAngle: .25,
                    width: 15,
                    splitLine: {
                        fixRadius: 0,
                        splitNumber: 10,
                        width: 15,
                        color: "#FFFFFF",
                        childNumber: 5,
                        childWidth: 5
                    },
                    pointer: {
                        width: 15,
                        color: "auto"
                    }
                }, n.extra.gauge);
                null == c.oldAngle && (c.oldAngle = c.startAngle), null == c.oldData && (c.oldData = 0), 
                e = V(e, c.startAngle, c.endAngle);
                var l = {
                    x: n.width / 2,
                    y: n.height / 2
                }, u = Math.min(l.x, l.y);
                u -= 5 * n.pixelRatio;
                var p = (u -= c.width / 2) - c.width, d = 0;
                if ("progress" == c.type) {
                    var f = u - 3 * c.width;
                    o.beginPath();
                    var h = o.createLinearGradient(l.x, l.y - f, l.x, l.y + f);
                    h.addColorStop("0", i(t[0].color, .3)), h.addColorStop("1.0", i("#FFFFFF", .1)), 
                    o.setFillStyle(h), o.arc(l.x, l.y, f, 0, 2 * a, !1), o.fill(), o.setLineWidth(c.width), 
                    o.setStrokeStyle(i(t[0].color, .3)), o.setLineCap("round"), o.beginPath(), o.arc(l.x, l.y, p, c.startAngle * a, c.endAngle * a, !1), 
                    o.stroke(), d = c.startAngle - c.endAngle + 1, c.splitLine.splitNumber;
                    var g = d / c.splitLine.splitNumber / c.splitLine.childNumber, v = -u - .5 * c.width - c.splitLine.fixRadius, m = -u - c.width - c.splitLine.fixRadius + c.splitLine.width;
                    o.save(), o.translate(l.x, l.y), o.rotate((c.startAngle - 1) * a);
                    for (var y = c.splitLine.splitNumber * c.splitLine.childNumber + 1, _ = t[0].data * s, b = 0; b < y; b++) o.beginPath(), 
                    _ > b / y ? o.setStrokeStyle(i(t[0].color, 1)) : o.setStrokeStyle(i(t[0].color, .3)), 
                    o.setLineWidth(3 * n.pixelRatio), o.moveTo(v, 0), o.lineTo(m, 0), o.stroke(), o.rotate(g * a);
                    o.restore(), t = q(t, c, s), o.setLineWidth(c.width), o.setStrokeStyle(t[0].color), 
                    o.setLineCap("round"), o.beginPath(), o.arc(l.x, l.y, p, c.startAngle * a, t[0]._proportion_ * a, !1), 
                    o.stroke();
                    var x = u - 2.5 * c.width;
                    o.save(), o.translate(l.x, l.y), o.rotate((t[0]._proportion_ - 1) * a), o.beginPath(), 
                    o.setLineWidth(c.width / 3);
                    var w = o.createLinearGradient(0, .6 * -x, 0, .6 * x);
                    w.addColorStop("0", i("#FFFFFF", 0)), w.addColorStop("0.5", i(t[0].color, 1)), w.addColorStop("1.0", i("#FFFFFF", 0)), 
                    o.setStrokeStyle(w), o.arc(0, 0, x, .85 * a, 1.15 * a, !1), o.stroke(), o.beginPath(), 
                    o.setLineWidth(1), o.setStrokeStyle(t[0].color), o.setFillStyle(t[0].color), o.moveTo(-x - c.width / 3 / 2, -4), 
                    o.lineTo(-x - c.width / 3 / 2 - 4, 0), o.lineTo(-x - c.width / 3 / 2, 4), o.lineTo(-x - c.width / 3 / 2, -4), 
                    o.stroke(), o.fill(), o.restore();
                } else {
                    o.setLineWidth(c.width), o.setLineCap("butt");
                    for (var A, S = 0; S < e.length; S++) A = e[S], o.beginPath(), o.setStrokeStyle(A.color), 
                    o.arc(l.x, l.y, u, A._startAngle_ * a, A._endAngle_ * a, !1), o.stroke();
                    o.save();
                    var k = (d = c.startAngle - c.endAngle + 1) / c.splitLine.splitNumber, P = d / c.splitLine.splitNumber / c.splitLine.childNumber, O = -u - .5 * c.width - c.splitLine.fixRadius, T = -u - .5 * c.width - c.splitLine.fixRadius + c.splitLine.width, C = -u - .5 * c.width - c.splitLine.fixRadius + c.splitLine.childWidth;
                    o.translate(l.x, l.y), o.rotate((c.startAngle - 1) * a);
                    for (var D = 0; D < c.splitLine.splitNumber + 1; D++) o.beginPath(), o.setStrokeStyle(c.splitLine.color), 
                    o.setLineWidth(2 * n.pixelRatio), o.moveTo(O, 0), o.lineTo(T, 0), o.stroke(), o.rotate(k * a);
                    o.restore(), o.save(), o.translate(l.x, l.y), o.rotate((c.startAngle - 1) * a);
                    for (var j = 0; j < c.splitLine.splitNumber * c.splitLine.childNumber + 1; j++) o.beginPath(), 
                    o.setStrokeStyle(c.splitLine.color), o.setLineWidth(1 * n.pixelRatio), o.moveTo(O, 0), 
                    o.lineTo(C, 0), o.stroke(), o.rotate(P * a);
                    o.restore(), t = X(t, e, c, s);
                    for (var $, E = 0; E < t.length; E++) $ = t[E], o.save(), o.translate(l.x, l.y), 
                    o.rotate(($._proportion_ - 1) * a), o.beginPath(), o.setFillStyle($.color), o.moveTo(c.pointer.width, 0), 
                    o.lineTo(0, -c.pointer.width / 2), o.lineTo(-p, 0), o.lineTo(0, c.pointer.width / 2), 
                    o.lineTo(c.pointer.width, 0), o.closePath(), o.fill(), o.beginPath(), o.setFillStyle("#FFFFFF"), 
                    o.arc(0, 0, c.pointer.width / 6, 0, 2 * a, !1), o.fill(), o.restore();
                    !1 !== n.dataLabel && ue(c, u, l, n, r, o);
                }
                return ce(n, r, o, l), 1 === s && "gauge" === n.type && (n.extra.gauge.oldAngle = t[0]._proportion_, 
                n.extra.gauge.oldData = t[0].data), {
                    center: l,
                    radius: u,
                    innerRadius: p,
                    categories: e,
                    totalAngle: d
                };
            }
            function $e(e, t, n, r) {
                var o = Math.cos, a = Math.sin, s = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, c = Je({}, {
                    gridColor: "#cccccc",
                    labelColor: "#666666",
                    opacity: .2,
                    gridCount: 3
                }, t.extra.radar), l = x(t.categories.length), u = {
                    x: t.area[3] + (t.width - t.area[1] - t.area[3]) / 2,
                    y: t.area[0] + (t.height - t.area[0] - t.area[2]) / 2
                }, d = Math.min(u.x - (b(t.categories) + n.radarLabelTextMargin), u.y - n.radarLabelTextMargin);
                d -= t.padding[1], r.beginPath(), r.setLineWidth(1 * t.pixelRatio), r.setStrokeStyle(c.gridColor), 
                l.forEach(function(e) {
                    var t = p(d * o(e), d * a(e), u);
                    r.moveTo(u.x, u.y), r.lineTo(t.x, t.y);
                }), r.stroke(), r.closePath();
                for (var f = 1; f <= c.gridCount; f++) !function(e) {
                    var n = {};
                    r.beginPath(), r.setLineWidth(1 * t.pixelRatio), r.setStrokeStyle(c.gridColor), 
                    l.forEach(function(t, i) {
                        var s = p(d / c.gridCount * e * o(t), d / c.gridCount * e * a(t), u);
                        0 === i ? (n = s, r.moveTo(s.x, s.y)) : r.lineTo(s.x, s.y);
                    }), r.lineTo(n.x, n.y), r.stroke(), r.closePath();
                }(f);
                return B(l, u, d, e, t, s).forEach(function(e) {
                    r.beginPath(), r.setFillStyle(i(e.color, c.opacity)), e.data.forEach(function(e, t) {
                        0 === t ? r.moveTo(e.position.x, e.position.y) : r.lineTo(e.position.x, e.position.y);
                    }), r.closePath(), r.fill(), !1 !== t.dataPointShape && se(e.data.map(function(e) {
                        return e.position;
                    }), e.color, e.pointShape, r, t);
                }), pe(l, d, u, t, n, r), {
                    center: u,
                    radius: d,
                    angleList: l
                };
            }
            function Ee(e, t, n) {
                n = 0 == n ? 1 : n;
                for (var r = [], i = 0; i < n; i++) r[i] = Math.random();
                return Math.floor(r.reduce(function(e, t) {
                    return e + t;
                }) / n * (t - e)) + e;
            }
            function Me(e, t, n, r) {
                for (var i = !1, o = 0; o < t.length; o++) if (t[o].area) {
                    if (!(e[3] < t[o].area[1] || e[0] > t[o].area[2] || e[1] > t[o].area[3] || e[2] < t[o].area[0])) {
                        i = !0;
                        break;
                    }
                    if (0 > e[0] || 0 > e[1] || e[2] > n || e[3] > r) {
                        i = !0;
                        break;
                    }
                    i = !1;
                }
                return i;
            }
            function Le(e) {
                for (var t, n, r = {
                    xMin: 180,
                    xMax: 0,
                    yMin: 90,
                    yMax: 0
                }, i = 0; i < e.length; i++) {
                    n = e[i].geometry.coordinates;
                    for (var o = 0; o < n.length; o++) {
                        1 == (t = n[o]).length && (t = t[0]);
                        for (var a = 0; a < t.length; a++) {
                            var s = {
                                x: t[a][0],
                                y: t[a][1]
                            };
                            r.xMin = r.xMin < s.x ? r.xMin : s.x, r.xMax = r.xMax > s.x ? r.xMax : s.x, r.yMin = r.yMin < s.y ? r.yMin : s.y, 
                            r.yMax = r.yMax > s.y ? r.yMax : s.y;
                        }
                    }
                }
                return r;
            }
            function Re(e, t, n, r, i, o) {
                return {
                    x: (t - n.xMin) * r + i,
                    y: (n.yMax - e) * r + o
                };
            }
            function Ie(e, t, n, r, i, o) {
                return {
                    x: (t - i) / r + n.xMin,
                    y: n.yMax - (e - o) / r
                };
            }
            function Fe(e, t, n) {
                return t[1] != n[1] && (!(t[1] > e[1] && n[1] > e[1]) && (!(t[1] < e[1] && n[1] < e[1]) && (!(t[1] == e[1] && n[1] > e[1]) && (!(n[1] == e[1] && t[1] > e[1]) && (!(t[0] < e[0] && n[1] < e[1]) && !(n[0] - (n[0] - t[0]) * (n[1] - e[1]) / (n[1] - t[1]) < e[0]))))));
            }
            function Ne(e, t) {
                for (var n, r = 0, i = 0; i < t.length; i++) {
                    n = t[i][0], 1 == t.length && (n = t[i][0]);
                    for (var o = 0; o < n.length - 1; o++) Fe(e, n[o], n[o + 1]) && (r += 1);
                }
                return !(1 != r % 2);
            }
            function ze(e, t, n, r) {
                var o, a, s = Math.abs, c = Je({}, {
                    border: !0,
                    borderWidth: 1,
                    borderColor: "#666666",
                    fillOpacity: .6,
                    activeBorderColor: "#f04864",
                    activeFillColor: "#facc14",
                    activeFillOpacity: 1
                }, t.extra.map), l = e, u = Le(l), p = t.width / s(u.xMax - u.xMin), d = t.height / s(u.yMax - u.yMin), f = p < d ? p : d, h = t.width / 2 - s(u.xMax - u.xMin) / 2 * f, v = t.height / 2 - s(u.yMax - u.yMin) / 2 * f;
                r.beginPath(), r.clearRect(0, 0, t.width, t.height), r.setFillStyle(t.background || "#FFFFFF"), 
                r.rect(0, 0, t.width, t.height), r.fill();
                for (var m = 0; m < l.length; m++) {
                    r.beginPath(), r.setLineWidth(c.borderWidth * t.pixelRatio), r.setStrokeStyle(c.borderColor), 
                    r.setFillStyle(i(e[m].color, c.fillOpacity)), t.tooltip && t.tooltip.index == m && (r.setStrokeStyle(c.activeBorderColor), 
                    r.setFillStyle(i(c.activeFillColor, c.activeFillOpacity)));
                    for (var y = l[m].geometry.coordinates, _ = 0; _ < y.length; _++) {
                        1 == (o = y[_]).length && (o = o[0]);
                        for (var b = 0; b < o.length; b++) a = Re(o[b][1], o[b][0], u, f, h, v), 0 == b ? (r.beginPath(), 
                        r.moveTo(a.x, a.y)) : r.lineTo(a.x, a.y);
                        r.fill(), 1 == c.border && r.stroke();
                    }
                    if (1 == t.dataLabel) {
                        var x = l[m].properties.centroid;
                        if (x) {
                            a = Re(x[1], x[0], u, f, h, v);
                            var w = l[m].textSize || n.fontSize, A = l[m].properties.name;
                            r.beginPath(), r.setFontSize(w), r.setFillStyle(l[m].textColor || "#666666"), r.fillText(A, a.x - g(A, w) / 2, a.y + w / 2), 
                            r.closePath(), r.stroke();
                        }
                    }
                }
                t.chartData.mapData = {
                    bounds: u,
                    scale: f,
                    xoffset: h,
                    yoffset: v
                }, Ae(t, n, r, 1), r.draw();
            }
            function Be(e, t) {
                var n = e.series.sort(function(e, t) {
                    return parseInt(t.textSize) - parseInt(e.textSize);
                });
                switch (t) {
                  case "normal":
                    for (var r = 0; r < n.length; r++) {
                        for (var i = void 0, o = void 0, a = void 0, s = n[r].name, c = n[r].textSize, l = g(s, c), u = 0; u++, 
                        i = Ee(-e.width / 2, e.width / 2, 5) - l / 2, o = Ee(-e.height / 2, e.height / 2, 5) + c / 2, 
                        Me(a = [ i - 5 + e.width / 2, o - 5 - c + e.height / 2, i + l + 5 + e.width / 2, o + 5 + e.height / 2 ], n, e.width, e.height); ) if (1e3 == u) {
                            a = [ -100, -100, -100, -100 ];
                            break;
                        }
                        n[r].area = a;
                    }
                    break;

                  case "vertical":
                    for (var p = 0; p < n.length; p++) {
                        for (var d = void 0, f = void 0, h = void 0, v = void 0, m = n[p].name, y = n[p].textSize, _ = g(m, y), b = !!(.7 < Math.random()), x = 0; ;) {
                            x++;
                            var w = void 0;
                            if (b ? (d = Ee(-e.width / 2, e.width / 2, 5) - _ / 2, f = Ee(-e.height / 2, e.height / 2, 5) + y / 2, 
                            h = [ f - 5 - _ + e.width / 2, -d - 5 + e.height / 2, f + 5 + e.width / 2, -d + y + 5 + e.height / 2 ], 
                            v = [ e.width - (e.width / 2 - e.height / 2) - (-d + y + 5 + e.height / 2) - 5, e.height / 2 - e.width / 2 + (f - 5 - _ + e.width / 2) - 5, e.width - (e.width / 2 - e.height / 2) - (-d + y + 5 + e.height / 2) + y, e.height / 2 - e.width / 2 + (f - 5 - _ + e.width / 2) + _ + 5 ], 
                            w = Me(v, n, e.height, e.width)) : (d = Ee(-e.width / 2, e.width / 2, 5) - _ / 2, 
                            f = Ee(-e.height / 2, e.height / 2, 5) + y / 2, h = [ d - 5 + e.width / 2, f - 5 - y + e.height / 2, d + _ + 5 + e.width / 2, f + 5 + e.height / 2 ], 
                            w = Me(h, n, e.width, e.height)), !w) break;
                            if (1e3 == x) {
                                h = [ -1e3, -1e3, -1e3, -1e3 ];
                                break;
                            }
                        }
                        b ? (n[p].area = v, n[p].areav = h) : n[p].area = h, n[p].rotate = b;
                    }
                }
                return n;
            }
            function Ue(e, t, n, r) {
                var i = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1;
                Je({}, {
                    type: "normal",
                    autoColors: !0
                }, t.extra.word), r.beginPath(), r.setFillStyle(t.background || "#FFFFFF"), r.rect(0, 0, t.width, t.height), 
                r.fill(), r.save();
                var o = t.chartData.wordCloudData;
                r.translate(t.width / 2, t.height / 2);
                for (var a = 0; a < o.length; a++) {
                    r.save(), o[a].rotate && r.rotate(90 * Math.PI / 180);
                    var s = o[a].name, c = o[a].textSize, l = g(s, c);
                    r.beginPath(), r.setStrokeStyle(o[a].color), r.setFillStyle(o[a].color), r.setFontSize(c), 
                    o[a].rotate ? 0 < o[a].areav[0] && (t.tooltip && t.tooltip.index == a ? r.strokeText(s, (o[a].areav[0] + 5 - t.width / 2) * i - l * (1 - i) / 2, (o[a].areav[1] + 5 + c - t.height / 2) * i) : r.fillText(s, (o[a].areav[0] + 5 - t.width / 2) * i - l * (1 - i) / 2, (o[a].areav[1] + 5 + c - t.height / 2) * i)) : 0 < o[a].area[0] && (t.tooltip && t.tooltip.index == a ? r.strokeText(s, (o[a].area[0] + 5 - t.width / 2) * i - l * (1 - i) / 2, (o[a].area[1] + 5 + c - t.height / 2) * i) : r.fillText(s, (o[a].area[0] + 5 - t.width / 2) * i - l * (1 - i) / 2, (o[a].area[1] + 5 + c - t.height / 2) * i)), 
                    r.stroke(), r.restore();
                }
                r.restore();
            }
            function We(e, t, n, r) {
                var o = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : 1, a = Je({}, {
                    activeWidth: 10,
                    activeOpacity: .3,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF",
                    fillOpacity: 1,
                    labelAlign: "right"
                }, t.extra.funnel), s = (t.height - t.area[0] - t.area[2]) / e.length, c = {
                    x: t.area[3] + (t.width - t.area[1] - t.area[3]) / 2,
                    y: t.height - t.area[2]
                }, l = a.activeWidth, u = Math.min((t.width - t.area[1] - t.area[3]) / 2 - l, (t.height - t.area[0] - t.area[2]) / 2 - l);
                e = W(e, u, o), r.save(), r.translate(c.x, c.y);
                for (var p = 0; p < e.length; p++) 0 == p ? (t.tooltip && t.tooltip.index == p && (r.beginPath(), 
                r.setFillStyle(i(e[p].color, a.activeOpacity)), r.moveTo(-l, 0), r.lineTo(-e[p].radius - l, -s), 
                r.lineTo(e[p].radius + l, -s), r.lineTo(l, 0), r.lineTo(-l, 0), r.closePath(), r.fill()), 
                e[p].funnelArea = [ c.x - e[p].radius, c.y - s, c.x + e[p].radius, c.y ], r.beginPath(), 
                r.setLineWidth(a.borderWidth * t.pixelRatio), r.setStrokeStyle(a.borderColor), r.setFillStyle(i(e[p].color, a.fillOpacity)), 
                r.moveTo(0, 0), r.lineTo(-e[p].radius, -s), r.lineTo(e[p].radius, -s), r.lineTo(0, 0), 
                r.closePath(), r.fill(), 1 == a.border && r.stroke()) : (t.tooltip && t.tooltip.index == p && (r.beginPath(), 
                r.setFillStyle(i(e[p].color, a.activeOpacity)), r.moveTo(0, 0), r.lineTo(-e[p - 1].radius - l, 0), 
                r.lineTo(-e[p].radius - l, -s), r.lineTo(e[p].radius + l, -s), r.lineTo(e[p - 1].radius + l, 0), 
                r.lineTo(0, 0), r.closePath(), r.fill()), e[p].funnelArea = [ c.x - e[p].radius, c.y - s * (p + 1), c.x + e[p].radius, c.y - s * p ], 
                r.beginPath(), r.setLineWidth(a.borderWidth * t.pixelRatio), r.setStrokeStyle(a.borderColor), 
                r.setFillStyle(i(e[p].color, a.fillOpacity)), r.moveTo(0, 0), r.lineTo(-e[p - 1].radius, 0), 
                r.lineTo(-e[p].radius, -s), r.lineTo(e[p].radius, -s), r.lineTo(e[p - 1].radius, 0), 
                r.lineTo(0, 0), r.closePath(), r.fill(), 1 == a.border && r.stroke()), r.translate(0, -s);
                return r.restore(), !1 !== t.dataLabel && 1 === o && He(e, t, r, s, a.labelAlign, l, c), 
                {
                    center: c,
                    radius: u,
                    series: e
                };
            }
            function He(e, t, n, r, i, o, a) {
                for (var s = Math.PI, c = 0; c < e.length; c++) {
                    var l = void 0, u = void 0, p = void 0, d = void 0, f = e[c], h = f.format ? f.format(+f._proportion_.toFixed(2)) : Ke.toFixed(100 * f._proportion_) + "%";
                    "right" == i ? (l = 0 == c ? (f.funnelArea[2] + a.x) / 2 : (f.funnelArea[2] + e[c - 1].funnelArea[2]) / 2, 
                    u = l + 2 * o, p = f.funnelArea[1] + r / 2, d = f.textSize || t.fontSize, n.setLineWidth(1 * t.pixelRatio), 
                    n.setStrokeStyle(f.color), n.setFillStyle(f.color), n.beginPath(), n.moveTo(l, p), 
                    n.lineTo(u, p), n.stroke(), n.closePath(), n.beginPath(), n.moveTo(u, p), n.arc(u, p, 2, 0, 2 * s), 
                    n.closePath(), n.fill(), n.beginPath(), n.setFontSize(d), n.setFillStyle(f.textColor || "#666666"), 
                    n.fillText(h, u + 5, p + d / 2 - 2), n.closePath(), n.stroke(), n.closePath()) : (l = 0 == c ? (f.funnelArea[0] + a.x) / 2 : (f.funnelArea[0] + e[c - 1].funnelArea[0]) / 2, 
                    u = l - 2 * o, p = f.funnelArea[1] + r / 2, d = f.textSize || t.fontSize, n.setLineWidth(1 * t.pixelRatio), 
                    n.setStrokeStyle(f.color), n.setFillStyle(f.color), n.beginPath(), n.moveTo(l, p), 
                    n.lineTo(u, p), n.stroke(), n.closePath(), n.beginPath(), n.moveTo(u, p), n.arc(u, p, 2, 0, 2 * s), 
                    n.closePath(), n.fill(), n.beginPath(), n.setFontSize(d), n.setFillStyle(f.textColor || "#666666"), 
                    n.fillText(h, u - 5 - g(h), p + d / 2 - 2), n.closePath(), n.stroke(), n.closePath());
                }
            }
            function qe(e, t) {
                t.draw();
            }
            function Ve(e) {
                this.isStop = !1, e.duration = void 0 === e.duration ? 1e3 : e.duration, e.timing = e.timing || "linear";
                var t = "undefined" == typeof setTimeout ? "undefined" == typeof requestAnimationFrame ? function(e) {
                    e(null);
                } : requestAnimationFrame : function(e, t) {
                    setTimeout(function() {
                        var t = +new Date();
                        e(t);
                    }, t);
                }, n = null, r = function(i) {
                    if (null === i || !0 === this.isStop) return e.onProcess && e.onProcess(1), void (e.onAnimationFinish && e.onAnimationFinish());
                    if (null === n && (n = i), i - n < e.duration) {
                        var o = (i - n) / e.duration;
                        o = (0, Qe[e.timing])(o), e.onProcess && e.onProcess(o), t(r, 17);
                    } else e.onProcess && e.onProcess(1), e.onAnimationFinish && e.onAnimationFinish();
                };
                r = r.bind(this), t(r, 17);
            }
            function Xe(e, t, n, r) {
                var i = this, o = t.series, s = t.categories;
                o = f(o, t, n);
                var c = t.animation ? t.duration : 0;
                i.animationInstance && i.animationInstance.stop();
                var l = null;
                if ("candle" == e) {
                    var u = Je({}, t.extra.candle.average);
                    u.show ? (l = a(u.day, u.name, u.color, o[0].data), l = f(l, t, n), t.seriesMA = l) : l = t.seriesMA ? t.seriesMA = f(t.seriesMA, t, n) : o;
                } else l = o;
                t._series_ = o = k(o), t.area = [ , , , ,  ];
                for (var p = 0; 4 > p; p++) t.area[p] = t.padding[p];
                var d = I(l, t, n, t.chartData), h = d.area.wholeHeight, g = d.area.wholeWidth;
                switch (t.legend.position) {
                  case "top":
                    t.area[0] += h;
                    break;

                  case "bottom":
                    t.area[2] += h;
                    break;

                  case "left":
                    t.area[3] += g;
                    break;

                  case "right":
                    t.area[1] += g;
                }
                var v = {}, m = 0;
                if ("line" === t.type || "column" === t.type || "area" === t.type || "mix" === t.type || "candle" === t.type) {
                    if (v = re(o, t, n), m = v.yAxisWidth, t.yAxis.showTitle) {
                        for (var y = 0, _ = 0; _ < t.yAxis.data.length; _++) y = Math.max(y, t.yAxis.data[_].titleFontSize ? t.yAxis.data[_].titleFontSize : n.fontSize);
                        t.area[0] += (y + 6) * t.pixelRatio;
                    }
                    for (var b = 0, x = 0, w = 0; w < m.length; w++) "left" == m[w].position ? (t.area[3] += 0 < x ? m[w].width + t.yAxis.padding : m[w].width, 
                    x += 1) : (t.area[1] += 0 < b ? m[w].width + t.yAxis.padding : m[w].width, b += 1);
                } else n.yAxisWidth = m;
                if (t.chartData.yAxisData = v, t.categories && t.categories.length) {
                    t.chartData.xAxisData = Q(t.categories, t, n);
                    var A = F(t.categories, t, n, t.chartData.xAxisData.eachSpacing), S = A.xAxisHeight, P = A.angle;
                    n.xAxisHeight = S, n._xAxisTextAngle_ = P, t.area[2] += S, t.chartData.categoriesData = A;
                } else if ("line" === t.type || "area" === t.type || "points" === t.type) {
                    t.chartData.xAxisData = z(o, t, n);
                    var O = F(s = t.chartData.xAxisData.rangesFormat, t, n, t.chartData.xAxisData.eachSpacing), T = O.xAxisHeight, C = O.angle;
                    n.xAxisHeight = T, n._xAxisTextAngle_ = C, t.area[2] += T, t.chartData.categoriesData = O;
                } else t.chartData.xAxisData = {
                    xAxisPoints: []
                };
                if (t.enableScroll && "right" == t.xAxis.scrollAlign && void 0 === t._scrollDistance_) {
                    var D = 0, j = t.chartData.xAxisData.xAxisPoints, $ = t.chartData.xAxisData.startX;
                    D = t.chartData.xAxisData.endX - $ - t.chartData.xAxisData.eachSpacing * (j.length - 1), 
                    i.scrollOption = {
                        currentOffset: D,
                        startTouchX: D,
                        distance: 0,
                        lastMoveTime: 0
                    }, t._scrollDistance_ = D;
                }
                switch (("pie" === e || "ring" === e || "rose" === e) && (n._pieTextMaxLength_ = !1 === t.dataLabel ? 0 : G(l)), 
                e) {
                  case "word":
                    var E = Je({}, {
                        type: "normal",
                        autoColors: !0
                    }, t.extra.word);
                    (1 == t.updateData || null == t.updateData) && (t.chartData.wordCloudData = Be(t, E.type)), 
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), Ue(o, t, n, r, e), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "map":
                    r.clearRect(0, 0, t.width, t.height), ze(o, t, n, r);
                    break;

                  case "funnel":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.funnelData = We(o, t, n, r, e), 
                            Oe(t.series, t, n, r, t.chartData), Ae(t, n, r, e), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "line":
                    this.animationInstance = new Ve({
                        timing: "easeIn",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), ke(s, t, n, r), Se(s, t, n, r);
                            var i = xe(o, t, n, r, e), a = i.xAxisPoints, c = i.calPoints, l = i.eachSpacing;
                            t.chartData.xAxisPoints = a, t.chartData.calPoints = c, t.chartData.eachSpacing = l, 
                            Pe(o, t, n, r), !1 !== t.enableMarkLine && 1 === e && he(t, n, r), Oe(t.series, t, n, r, t.chartData), 
                            Ae(t, n, r, e, l, a), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "mix":
                    this.animationInstance = new Ve({
                        timing: "easeIn",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), ke(s, t, n, r), Se(s, t, n, r);
                            var i = we(o, t, n, r, e), a = i.xAxisPoints, c = i.calPoints, l = i.eachSpacing;
                            t.chartData.xAxisPoints = a, t.chartData.calPoints = c, t.chartData.eachSpacing = l, 
                            Pe(o, t, n, r), !1 !== t.enableMarkLine && 1 === e && he(t, n, r), Oe(t.series, t, n, r, t.chartData), 
                            Ae(t, n, r, e, l, a), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "column":
                    this.animationInstance = new Ve({
                        timing: "easeIn",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), ke(s, t, n, r), Se(s, t, n, r);
                            var i = ye(o, t, n, r, e), a = i.xAxisPoints, c = i.calPoints, l = i.eachSpacing;
                            t.chartData.xAxisPoints = a, t.chartData.calPoints = c, t.chartData.eachSpacing = l, 
                            Pe(o, t, n, r), !1 !== t.enableMarkLine && 1 === e && he(t, n, r), Oe(t.series, t, n, r, t.chartData), 
                            Ae(t, n, r, e, l, a), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "area":
                    this.animationInstance = new Ve({
                        timing: "easeIn",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), ke(s, t, n, r), Se(s, t, n, r);
                            var i = be(o, t, n, r, e), a = i.xAxisPoints, c = i.calPoints, l = i.eachSpacing;
                            t.chartData.xAxisPoints = a, t.chartData.calPoints = c, t.chartData.eachSpacing = l, 
                            Pe(o, t, n, r), !1 !== t.enableMarkLine && 1 === e && he(t, n, r), Oe(t.series, t, n, r, t.chartData), 
                            Ae(t, n, r, e, l, a), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "ring":
                  case "pie":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.pieData = Te(o, t, n, r, e), 
                            Oe(t.series, t, n, r, t.chartData), Ae(t, n, r, e), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "rose":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.pieData = Ce(o, t, n, r, e), 
                            Oe(t.series, t, n, r, t.chartData), Ae(t, n, r, e), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "radar":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.radarData = $e(o, t, n, r, e), 
                            Oe(t.series, t, n, r, t.chartData), Ae(t, n, r, e), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "arcbar":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.arcbarData = De(o, t, n, r, e), 
                            qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "gauge":
                    this.animationInstance = new Ve({
                        timing: "easeInOut",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), t.chartData.gaugeData = je(s, o, t, n, r, e), 
                            qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "candle":
                    this.animationInstance = new Ve({
                        timing: "easeIn",
                        duration: c,
                        onProcess: function(e) {
                            r.clearRect(0, 0, t.width, t.height), t.rotate && ae(r, t), ke(s, t, n, r), Se(s, t, n, r);
                            var i = _e(o, l, t, n, r, e), a = i.xAxisPoints, c = i.calPoints, u = i.eachSpacing;
                            t.chartData.xAxisPoints = a, t.chartData.calPoints = c, t.chartData.eachSpacing = u, 
                            Pe(o, t, n, r), !1 !== t.enableMarkLine && 1 === e && he(t, n, r), Oe(l || t.series, t, n, r, t.chartData), 
                            Ae(t, n, r, e, u, a), qe(t, r);
                        },
                        onAnimationFinish: function() {
                            i.event.trigger("renderComplete");
                        }
                    });
                }
            }
            function Ge() {
                this.events = {};
            }
            var Ye = {
                yAxisWidth: 15,
                yAxisSplit: 5,
                xAxisHeight: 15,
                xAxisLineHeight: 15,
                legendHeight: 15,
                yAxisTitleWidth: 15,
                padding: [ 10, 10, 10, 10 ],
                pixelRatio: 1,
                rotate: !1,
                columePadding: 3,
                fontSize: 13,
                dataPointShape: [ "circle", "circle", "circle", "circle" ],
                colors: [ "#1890ff", "#2fc25b", "#facc14", "#f04864", "#8543e0", "#90ed7d" ],
                pieChartLinePadding: 15,
                pieChartTextPadding: 5,
                xAxisTextPadding: 3,
                titleColor: "#333333",
                titleFontSize: 20,
                subtitleColor: "#999999",
                subtitleFontSize: 15,
                toolTipPadding: 3,
                toolTipBackground: "#000000",
                toolTipOpacity: .7,
                toolTipLineHeight: 20,
                radarLabelTextMargin: 15,
                gaugeLabelTextMargin: 15
            }, Je = function(e) {
                function t(e, n) {
                    for (var r in n) e[r] = e[r] && "[object Object]" === e[r].toString() ? t(e[r], n[r]) : e[r] = n[r];
                    return e;
                }
                for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) r[i - 1] = arguments[i];
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                return !r || 0 >= r.length || r.forEach(function(n) {
                    e = t(e, n);
                }), e;
            }, Ke = {
                toFixed: function(e, t) {
                    return t = t || 2, this.isFloat(e) && (e = e.toFixed(t)), e;
                },
                isFloat: function(e) {
                    return 0 != e % 1;
                },
                approximatelyEqual: function(e, t) {
                    return 1e-10 > Math.abs(e - t);
                },
                isSameSign: function(e, t) {
                    var n = Math.abs;
                    return n(e) === e && n(t) === t || n(e) !== e && n(t) !== t;
                },
                isSameXCoordinateArea: function(e, t) {
                    return this.isSameSign(e.x, t.x);
                },
                isCollision: function(e, t) {
                    return e.end = {}, e.end.x = e.start.x + e.width, e.end.y = e.start.y - e.height, 
                    t.end = {}, t.end.x = t.start.x + t.width, t.end.y = t.start.y - t.height, !(t.start.x > e.end.x || t.end.x < e.start.x || t.end.y > e.start.y || t.start.y < e.end.y);
                }
            }, Qe = {
                easeIn: function(e) {
                    return Math.pow(e, 3);
                },
                easeOut: function(e) {
                    return Math.pow(e - 1, 3) + 1;
                },
                easeInOut: function(e) {
                    var t = Math.pow;
                    return 1 > (e /= .5) ? .5 * t(e, 3) : .5 * (t(e - 2, 3) + 2);
                },
                linear: function(e) {
                    return e;
                }
            };
            Ve.prototype.stop = function() {
                this.isStop = !0;
            }, Ge.prototype.addEventListener = function(e, t) {
                this.events[e] = this.events[e] || [], this.events[e].push(t);
            }, Ge.prototype.trigger = function() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                var r = t[0], i = t.slice(1);
                !this.events[r] || this.events[r].forEach(function(e) {
                    try {
                        e.apply(null, i);
                    } catch (e) {
                        console.error(e);
                    }
                });
            };
            var Ze = function(e) {
                e.pixelRatio = e.pixelRatio ? e.pixelRatio : 1, e.fontSize = e.fontSize ? e.fontSize * e.pixelRatio : 13 * e.pixelRatio, 
                e.title = Je({}, e.title), e.subtitle = Je({}, e.subtitle), e.duration = e.duration ? e.duration : 1e3, 
                e.yAxis = Je({}, {
                    data: [],
                    showTitle: !1,
                    disabled: !1,
                    disableGrid: !1,
                    splitNumber: 5,
                    gridType: "solid",
                    dashLength: 4 * e.pixelRatio,
                    gridColor: "#cccccc",
                    padding: 10,
                    fontColor: "#666666"
                }, e.yAxis), e.yAxis.dashLength *= e.pixelRatio, e.yAxis.padding *= e.pixelRatio, 
                e.xAxis = Je({}, {
                    rotateLabel: !1,
                    type: "calibration",
                    gridType: "solid",
                    dashLength: 4,
                    scrollAlign: "left",
                    boundaryGap: "center",
                    axisLine: !0,
                    axisLineColor: "#cccccc"
                }, e.xAxis), e.xAxis.dashLength *= e.pixelRatio, e.legend = Je({}, {
                    show: !0,
                    position: "bottom",
                    float: "center",
                    backgroundColor: "rgba(0,0,0,0)",
                    borderColor: "rgba(0,0,0,0)",
                    borderWidth: 0,
                    padding: 5,
                    margin: 5,
                    itemGap: 10,
                    fontSize: e.fontSize,
                    lineHeight: e.fontSize,
                    fontColor: "#333333",
                    format: {},
                    hiddenColor: "#CECECE"
                }, e.legend), e.legend.borderWidth *= e.pixelRatio, e.legend.itemGap *= e.pixelRatio, 
                e.legend.padding *= e.pixelRatio, e.legend.margin *= e.pixelRatio, e.extra = Je({}, e.extra), 
                e.rotate = !!e.rotate, e.animation = !!e.animation, e.rotate = !!e.rotate;
                var n = JSON.parse(JSON.stringify(Ye));
                if (n.colors = e.colors ? e.colors : n.colors, n.yAxisTitleWidth = !0 !== e.yAxis.disabled && e.yAxis.title ? n.yAxisTitleWidth : 0, 
                ("pie" == e.type || "ring" == e.type) && (n.pieChartLinePadding = !1 === e.dataLabel ? 0 : e.extra.pie.labelWidth * e.pixelRatio || n.pieChartLinePadding * e.pixelRatio), 
                "rose" == e.type && (n.pieChartLinePadding = !1 === e.dataLabel ? 0 : e.extra.rose.labelWidth * e.pixelRatio || n.pieChartLinePadding * e.pixelRatio), 
                n.pieChartTextPadding = !1 === e.dataLabel ? 0 : n.pieChartTextPadding * e.pixelRatio, 
                n.yAxisSplit = e.yAxis.splitNumber ? e.yAxis.splitNumber : Ye.yAxisSplit, n.rotate = e.rotate, 
                e.rotate) {
                    var r = e.width, i = e.height;
                    e.width = i, e.height = r;
                }
                e.padding = e.padding ? e.padding : n.padding;
                for (var o = 0; 4 > o; o++) e.padding[o] *= e.pixelRatio;
                n.yAxisWidth = Ye.yAxisWidth * e.pixelRatio, n.xAxisHeight = Ye.xAxisHeight * e.pixelRatio, 
                e.enableScroll && e.xAxis.scrollShow && (n.xAxisHeight += 6 * e.pixelRatio), n.xAxisLineHeight = Ye.xAxisLineHeight * e.pixelRatio, 
                n.fontSize = e.fontSize, n.titleFontSize = Ye.titleFontSize * e.pixelRatio, n.subtitleFontSize = Ye.subtitleFontSize * e.pixelRatio, 
                n.toolTipPadding = Ye.toolTipPadding * e.pixelRatio, n.toolTipLineHeight = Ye.toolTipLineHeight * e.pixelRatio, 
                n.columePadding = Ye.columePadding * e.pixelRatio, e.$this = e.$this ? e.$this : this, 
                this.context = t.createCanvasContext(e.canvasId, e.$this), e.chartData = {}, this.event = new Ge(), 
                this.scrollOption = {
                    currentOffset: 0,
                    startTouchX: 0,
                    distance: 0,
                    lastMoveTime: 0
                }, this.opts = e, this.config = n, Xe.call(this, e.type, e, n, this.context);
            };
            Ze.prototype.updateData = function() {
                var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                switch (this.opts = Je({}, this.opts, e), this.opts.updateData = !0, e.scrollPosition || "current") {
                  case "current":
                    this.opts._scrollDistance_ = this.scrollOption.currentOffset;
                    break;

                  case "left":
                    this.opts._scrollDistance_ = 0, this.scrollOption = {
                        currentOffset: 0,
                        startTouchX: 0,
                        distance: 0,
                        lastMoveTime: 0
                    };
                    break;

                  case "right":
                    var t = re(this.opts.series, this.opts, this.config).yAxisWidth;
                    this.config.yAxisWidth = t;
                    var n = 0, r = Q(this.opts.categories, this.opts, this.config), i = r.xAxisPoints, o = r.startX;
                    n = r.endX - o - r.eachSpacing * (i.length - 1), this.scrollOption = {
                        currentOffset: n,
                        startTouchX: n,
                        distance: 0,
                        lastMoveTime: 0
                    }, this.opts._scrollDistance_ = n;
                }
                Xe.call(this, this.opts.type, this.opts, this.config, this.context);
            }, Ze.prototype.zoom = function() {
                var e = Math.round, t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : this.opts.xAxis.itemCount;
                if (!0 === this.opts.enableScroll) {
                    var n = e(Math.abs(this.scrollOption.currentOffset) / this.opts.chartData.eachSpacing) + e(this.opts.xAxis.itemCount / 2);
                    this.opts.animation = !1, this.opts.xAxis.itemCount = t.itemCount;
                    var r = re(this.opts.series, this.opts, this.config).yAxisWidth;
                    this.config.yAxisWidth = r;
                    var i = 0, o = Q(this.opts.categories, this.opts, this.config), a = o.xAxisPoints, s = o.startX, c = o.endX, l = o.eachSpacing, u = c - s, p = u - l * (a.length - 1);
                    0 < (i = u / 2 - l * n) && (i = 0), i < p && (i = p), this.scrollOption = {
                        currentOffset: i,
                        startTouchX: i,
                        distance: 0,
                        lastMoveTime: 0
                    }, this.opts._scrollDistance_ = i, Xe.call(this, this.opts.type, this.opts, this.config, this.context);
                } else console.log("请启用滚动条后使用！");
            }, Ze.prototype.stopAnimation = function() {
                this.animationInstance && this.animationInstance.stop();
            }, Ze.prototype.addEventListener = function(e, t) {
                this.event.addEventListener(e, t);
            }, Ze.prototype.getCurrentDataIndex = function(e) {
                var t = null;
                if (t = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0]) {
                    var n = y(t, this.opts, e);
                    return "pie" === this.opts.type || "ring" === this.opts.type || "rose" === this.opts.type ? M({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.pieData) : "radar" === this.opts.type ? D({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.radarData, this.opts.categories.length) : "funnel" === this.opts.type ? j({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.funnelData) : "map" === this.opts.type ? E({
                        x: n.x,
                        y: n.y
                    }, this.opts) : "word" === this.opts.type ? $({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.wordCloudData) : P({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.calPoints, this.opts, this.config, Math.abs(this.scrollOption.currentOffset));
                }
                return -1;
            }, Ze.prototype.getLegendDataIndex = function(e) {
                var t = null;
                if (t = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0]) {
                    var n = y(t, this.opts, e);
                    return O({
                        x: n.x,
                        y: n.y
                    }, this.opts.chartData.legendData);
                }
                return -1;
            }, Ze.prototype.touchLegend = function(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = null;
                if (n = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0]) {
                    y(n, this.opts, e);
                    var r = this.getLegendDataIndex(e);
                    0 <= r && (this.opts.series[r].show = !this.opts.series[r].show, this.opts.animation = !!t.animation, 
                    this.opts._scrollDistance_ = this.scrollOption.currentOffset, Xe.call(this, this.opts.type, this.opts, this.config, this.context));
                }
            }, Ze.prototype.showToolTip = function(e) {
                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = null;
                (n = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0]) || console.log("touchError");
                var r = y(n, this.opts, e), i = this.scrollOption.currentOffset, o = Je({}, this.opts, {
                    _scrollDistance_: i,
                    animation: !1
                });
                if ("line" === this.opts.type || "area" === this.opts.type || "column" === this.opts.type) {
                    var a = this.getCurrentDataIndex(e);
                    if (-1 < a) {
                        var s = _(this.opts.series, a);
                        if (0 !== s.length) {
                            var c = w(s, this.opts.chartData.calPoints, a, this.opts.categories, t), l = c.textList, u = c.offset;
                            u.y = r.y, o.tooltip = {
                                textList: l,
                                offset: u,
                                option: t,
                                index: a
                            };
                        }
                    }
                    Xe.call(this, o.type, o, this.config, this.context);
                }
                if ("mix" === this.opts.type) {
                    if (-1 < (a = this.getCurrentDataIndex(e)) && (i = this.scrollOption.currentOffset, 
                    o = Je({}, this.opts, {
                        _scrollDistance_: i,
                        animation: !1
                    }), 0 !== (s = _(this.opts.series, a)).length)) {
                        var p = A(s, this.opts.chartData.calPoints, a, this.opts.categories, t);
                        l = p.textList, (u = p.offset).y = r.y, o.tooltip = {
                            textList: l,
                            offset: u,
                            option: t,
                            index: a
                        };
                    }
                    Xe.call(this, o.type, o, this.config, this.context);
                }
                "candle" === this.opts.type && (-1 < (a = this.getCurrentDataIndex(e)) && (i = this.scrollOption.currentOffset, 
                o = Je({}, this.opts, {
                    _scrollDistance_: i,
                    animation: !1
                }), 0 !== (s = _(this.opts.series, a)).length && (l = (c = S(this.opts.series[0].data, s, this.opts.chartData.calPoints, a, this.opts.categories, this.opts.extra.candle)).textList, 
                (u = c.offset).y = r.y, o.tooltip = {
                    textList: l,
                    offset: u,
                    option: t,
                    index: a
                })), Xe.call(this, o.type, o, this.config, this.context)), "pie" !== this.opts.type && "ring" !== this.opts.type && "rose" !== this.opts.type && "funnel" !== this.opts.type || (-1 < (a = this.getCurrentDataIndex(e)) && (i = this.scrollOption.currentOffset, 
                o = Je({}, this.opts, {
                    _scrollDistance_: i,
                    animation: !1
                }), s = this.opts._series_[a], l = [ {
                    text: t.format ? t.format(s) : s.name + ": " + s.data,
                    color: s.color
                } ], u = {
                    x: r.x,
                    y: r.y
                }, o.tooltip = {
                    textList: l,
                    offset: u,
                    option: t,
                    index: a
                }), Xe.call(this, o.type, o, this.config, this.context)), "map" !== this.opts.type && "word" !== this.opts.type || (-1 < (a = this.getCurrentDataIndex(e)) && (i = this.scrollOption.currentOffset, 
                o = Je({}, this.opts, {
                    _scrollDistance_: i,
                    animation: !1
                }), s = this.opts._series_[a], l = [ {
                    text: t.format ? t.format(s) : s.properties.name,
                    color: s.color
                } ], u = {
                    x: r.x,
                    y: r.y
                }, o.tooltip = {
                    textList: l,
                    offset: u,
                    option: t,
                    index: a
                }), o.updateData = !1, Xe.call(this, o.type, o, this.config, this.context)), "radar" === this.opts.type && (-1 < (a = this.getCurrentDataIndex(e)) && (i = this.scrollOption.currentOffset, 
                o = Je({}, this.opts, {
                    _scrollDistance_: i,
                    animation: !1
                }), 0 !== (s = _(this.opts.series, a)).length && (l = s.map(function(e) {
                    return {
                        text: t.format ? t.format(e) : e.name + ": " + e.data,
                        color: e.color
                    };
                }), u = {
                    x: r.x,
                    y: r.y
                }, o.tooltip = {
                    textList: l,
                    offset: u,
                    option: t,
                    index: a
                })), Xe.call(this, o.type, o, this.config, this.context));
            }, Ze.prototype.translate = function(e) {
                this.scrollOption = {
                    currentOffset: e,
                    startTouchX: e,
                    distance: 0,
                    lastMoveTime: 0
                };
                var t = Je({}, this.opts, {
                    _scrollDistance_: e,
                    animation: !1
                });
                Xe.call(this, this.opts.type, t, this.config, this.context);
            }, Ze.prototype.scrollStart = function(e) {
                var t = null, n = y(t = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0], this.opts, e);
                t && !0 === this.opts.enableScroll && (this.scrollOption.startTouchX = n.x);
            }, Ze.prototype.scroll = function(e) {
                0 === this.scrollOption.lastMoveTime && (this.scrollOption.lastMoveTime = Date.now());
                var t = this.opts.extra.touchMoveLimit || 20, n = Date.now();
                if (!(n - this.scrollOption.lastMoveTime < Math.floor(1e3 / t))) {
                    this.scrollOption.lastMoveTime = n;
                    var r = null;
                    if ((r = e.changedTouches ? e.changedTouches[0] : e.mp.changedTouches[0]) && !0 === this.opts.enableScroll) {
                        var i;
                        i = y(r, this.opts, e).x - this.scrollOption.startTouchX;
                        var o = this.scrollOption.currentOffset, a = s(this, o + i, this.opts.chartData, this.config, this.opts);
                        this.scrollOption.distance = i = a - o;
                        var c = Je({}, this.opts, {
                            _scrollDistance_: o + i,
                            animation: !1
                        });
                        return Xe.call(this, c.type, c, this.config, this.context), o + i;
                    }
                }
            }, Ze.prototype.scrollEnd = function() {
                if (!0 === this.opts.enableScroll) {
                    var e = this.scrollOption, t = e.currentOffset, n = e.distance;
                    this.scrollOption.currentOffset = t + n, this.scrollOption.distance = 0;
                }
            }, "object" == r(n) && "object" == r(n.exports) && (n.exports = Ze);
        }).call(this, r("543d").default, r("62e4")(t));
    },
    ab4f: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            list: {},
            show: null,
            first: {},
            is_storage: !1,
            setList: function(e) {
                void 0 === this.list[e] && (this.list[e] = !0);
            }
        };
        t.default = r;
    },
    ac6b: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.removeStorage = t.setStorage = t.getStorage = t.removeStorageSync = t.getStorageSync = t.setStorageSync = t.clearStorage = void 0, 
            function(e) {
                e && e.__esModule;
            }(n("ae58"));
            t.clearStorage = function() {
                e.clearStorageSync();
            };
            t.setStorageSync = function(t, n) {
                e.setStorageSync(t, n);
            };
            t.getStorageSync = function(t) {
                return e.getStorageSync(t);
            };
            t.getStorage = function(t) {
                var n = t.key, r = t.success, i = t.fail;
                e.getStorage({
                    key: n,
                    success: function(e) {
                        r && r(e);
                    },
                    fail: function() {
                        i && i();
                    }
                });
            };
            t.setStorage = function(t) {
                var n = t.key, r = t.data, i = t.success, o = t.fail;
                e.setStorage({
                    key: n,
                    data: r,
                    success: function(e) {
                        i && i(e);
                    },
                    fail: function() {
                        o && o();
                    }
                });
            };
            t.removeStorageSync = function(t) {
                e.removeStorageSync(t);
            };
            t.removeStorage = function(t) {
                var n = t.key, r = t.success, i = t.fail;
                e.removeStorage({
                    key: n,
                    success: function(e) {
                        r && r(e);
                    },
                    fail: function() {
                        i && i();
                    }
                });
            };
        }).call(this, n("543d").default);
    },
    b1c7: function(t, n, r) {
        (function(t) {
            function r(t) {
                return (r = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                    return void 0 === t ? "undefined" : e(t);
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
                })(t);
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.compareVersion = n.showtime = n.checkIphone = n.h5Address = n.getUrlParam = n.uniCopy = n.deepClone = n.debounce = n.throttle = n.colorRgba = n.deleteUrlParam = n.batchSave = n.hideLoading = n.showLoading = n.urlParamsToObject = n.randomString = n.objectValues = n.earthDistance = n.timeDifference = n.objectToUrlParams = n.strtotime = n.datetime = n.time = void 0;
            n.time = function() {
                return parseInt(Math.round(new Date() / 1e3));
            };
            n.datetime = function(e, t) {
                void 0 !== e && null !== e || (e = "Y-m-d h:i:s"), void 0 !== t && null !== t || (t = this.time());
                var n = new Date();
                n.setTime(1e3 * t);
                var r = {
                    Y: n.getFullYear(),
                    "m+": n.getMonth() + 1 < 10 ? "0".concat(n.getMonth() + 1) : n.getMonth() + 1,
                    "d+": n.getDate() < 10 ? "0".concat(n.getDate()) : n.getDate(),
                    "h+": n.getHours() < 10 ? "0".concat(n.getHours()) : n.getHours(),
                    "i+": n.getMinutes() < 10 ? "0".concat(n.getMinutes()) : n.getMinutes(),
                    "s+": n.getSeconds() < 10 ? "0".concat(n.getSeconds()) : n.getSeconds(),
                    "q+": Math.floor((n.getMonth() + 3) / 3),
                    "S+": n.getMilliseconds()
                };
                for (var i in r) new RegExp("(" + i + ")").test(e) && (e = e.replace(RegExp.$1, 1 === RegExp.$1.length ? r[i] : ("00" + r[i]).substr(("" + r[i]).length)));
                return e;
            };
            n.strtotime = function(e) {};
            n.objectToUrlParams = function(e, t) {
                var n = "";
                for (var r in e) n += "&" + r + "=" + (t ? encodeURIComponent(e[r]) : e[r]);
                return n.substr(1);
            };
            n.timeDifference = function(e, t) {
                var n = parseInt((t - e) / 1e3), r = 0, i = 0, o = 0, a = 0;
                return n >= 0 ? (r = Math.floor(n / 86400), i = Math.floor(n / 3600) - 24 * r, o = Math.floor(n / 60) - 24 * r * 60 - 60 * i, 
                a = Math.floor(n) - 24 * r * 60 * 60 - 60 * i * 60 - 60 * o, {
                    d: r.toString(),
                    h: i < 10 ? "0" + i : i.toString(),
                    m: o < 10 ? "0" + o : o.toString(),
                    s: a < 10 ? "0" + a : a.toString()
                }) : null;
            };
            n.earthDistance = function(e, t) {
                function n(e) {
                    return e * h / 180;
                }
                var r, i, o, a, s, c, l, u = parseFloat(e.lat), p = parseFloat(e.lng), d = parseFloat(t.lat), f = parseFloat(t.lng), h = Math.PI, g = n((u + d) / 2), v = n((u - d) / 2), m = n((p - f) / 2), y = Math.sin(v), _ = Math.sin(m), b = Math.sin(g);
                return y *= y, _ *= _, b *= b, r = y * (1 - _) + (1 - b) * _, i = (1 - y) * (1 - _) + b * _, 
                o = Math.atan(Math.sqrt(r / i)), a = Math.sqrt(r * i) / o, s = 2 * o * 6378137, 
                c = (3 * a - 1) / 2 / i, l = (3 * a + 1) / 2 / r, s * (1 + 1 / 298.257 * (c * b * (1 - y) - l * (1 - b) * y));
            };
            n.objectValues = function(e) {
                var t = [];
                for (var n in e) t.push(e[n]);
                return t;
            };
            n.randomString = function(e) {
                for (var t = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", n = "", r = e; r > 0; --r) n += t[Math.floor(Math.random() * t.length)];
                return n;
            };
            n.urlParamsToObject = function(e) {
                var t = e.split("&"), n = {};
                for (var r in t) if ("string" == typeof t[r] && t[r].length) {
                    var i = t[r].split("=");
                    2 === i.length && (n[i[0]] = i[1]);
                }
                return n;
            };
            n.showLoading = function() {
                t.showLoading({
                    title: "加载中",
                    mask: !0
                });
            };
            n.hideLoading = function() {
                t.hideLoading();
            };
            n.h5Address = function(e) {
                e.success, e.fail;
            };
            var i = !1;
            n.batchSave = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "image";
                return new Promise(function(r, o) {
                    e instanceof Array || (e = [ e ]);
                    var a = "image" === n ? "图片" : "视频";
                    new Promise(function(e, n) {
                        var r = null;
                        r = "scope.writePhotosAlbum", t.authorize({
                            scope: r,
                            success: function(t) {
                                e("success");
                            },
                            fail: function(i) {
                                t.showModal({
                                    title: "提示",
                                    content: "您好,请先授权保存到相册权限",
                                    showCancel: !1,
                                    success: function(i) {
                                        i.confirm && t.openSetting({
                                            success: function(t) {
                                                t.authSetting[r] ? e("success") : n("fail");
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }).then(function(e) {
                        i || (i = !0), t.showLoading({
                            title: a + "保存中",
                            mask: !0
                        });
                    }).then(function(a) {
                        Promise.all(e.map(function(e) {
                            return new Promise(function(r, i) {
                                try {
                                    var o = t.downloadFile({
                                        url: e,
                                        success: function(e) {
                                            "image" === n && t.saveImageToPhotosAlbum({
                                                filePath: e.tempFilePath,
                                                success: function() {
                                                    r("success");
                                                },
                                                fail: function(e) {
                                                    i("fail");
                                                }
                                            }), "video" === n && t.saveVideoToPhotosAlbum({
                                                filePath: e.tempFilePath,
                                                success: function() {
                                                    r("success");
                                                },
                                                fail: function(e) {
                                                    i("fail");
                                                }
                                            });
                                        },
                                        fail: function(e) {
                                            i("fail");
                                        }
                                    });
                                    if ("video" === n) {
                                        var a = new Date().getTime();
                                        o.onProgressUpdate(function(e) {
                                            new Date().getTime() - a > 6e4 && (o.abort(), i("fail"));
                                        });
                                    }
                                } catch (e) {
                                    i("fail");
                                }
                            });
                        })).then(function() {
                            i = !1, t.hideLoading(), r("success");
                        }).catch(function() {
                            i = !1, t.hideLoading(), t.showToast({
                                title: "下载失败"
                            }), o("fail");
                        });
                    }).catch(function() {
                        t.showModal({
                            title: "提示",
                            content: "授权失败，请稍后重新获取",
                            showCancel: !1
                        }), o("fail");
                    });
                });
            };
            n.deleteUrlParam = function(e, t, n) {
                if (isNaN(e.indexOf("?")) || e.indexOf("?") < 0) return e;
                var i = e.substr(e.indexOf("?") + 1), o = e.substr(0, e.indexOf("?"));
                if (n) return o;
                var a = [];
                a = "object" === r(t) ? t : [ t ];
                var s = {}, c = i.split("&");
                for (var l in c) c[l] = c[l].split("="), s[c[l][0]] = c[l][1];
                for (var u in a) delete s[a[u]];
                return (i = JSON.stringify(s).replace(/[\"\{\}]/g, "").replace(/\:/g, "=").replace(/\,/g, "&")).length ? o + "?" + i : o;
            };
            var o;
            n.colorRgba = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, n = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/, r = e ? e.toLowerCase() : "";
                if (r && n.test(r)) {
                    if (4 === r.length) {
                        for (var i = "#", o = 1; o < 4; o += 1) i += r.slice(o, o + 1).concat(r.slice(o, o + 1));
                        r = i;
                    }
                    for (var a = [], s = 1; s < 7; s += 2) a.push(parseInt("0x" + r.slice(s, s + 2)));
                    return "rgba(" + a.join(",") + "," + t + ")";
                }
                return r;
            };
            n.throttle = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500;
                arguments.length > 2 && void 0 !== arguments[2] && !arguments[2] ? o || (o = !0, 
                setTimeout(function() {
                    o = !1, "function" == typeof e && e();
                }, t)) : o || (o = !0, "function" == typeof e && e(), setTimeout(function() {
                    o = !1;
                }, t));
            };
            var a = null;
            n.debounce = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                if (null !== a && clearTimeout(a), n) {
                    var r = !a;
                    a = setTimeout(function() {
                        a = null;
                    }, t), r && "function" == typeof e && e();
                } else a = setTimeout(function() {
                    "function" == typeof e && e();
                }, t);
            };
            n.deepClone = function e(t) {
                if ([ null, void 0, NaN, !1 ].includes(t)) return t;
                if ("object" !== r(t) && "function" != typeof t) return t;
                var n = function(e) {
                    return "[object Array]" === Object.prototype.toString.call(e);
                }(t) ? [] : {};
                for (var i in t) t.hasOwnProperty(i) && (n[i] = "object" === r(t[i]) ? e(t[i]) : t[i]);
                return n;
            };
            n.uniCopy = function(e) {
                var n = e.data, r = e.success;
                e.error, t.setClipboardData({
                    data: n,
                    success: function() {
                        r && r();
                    }
                });
            };
            n.getUrlParam = function(e) {};
            n.checkIphone = function() {
                var e = t.getSystemInfoSync();
                return e.model.indexOf("iPhone X") > -1 || e.model.indexOf("iPhone 11") > -1 || e.model.indexOf("iPhone11") > -1 || e.model.indexOf("iPhone12") > -1 || e.model.indexOf("iPhone 12") > -1 || e.model.indexOf("iPhone13") > -1 || e.model.indexOf("iPhone 13") > -1 || e.model.indexOf("Unknown Device") > -1;
            };
            n.showtime = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, n = new Date(), r = new Date(e).getTime() - n.getTime(), i = Math.floor(r / 864e5), o = Math.floor(r / 36e5 % 24), a = Math.floor(r / 6e4 % 60), s = Math.floor(r / 1e3 % 60);
                return 2 === t ? {
                    day: i,
                    hour: o,
                    min: a,
                    sec: s
                } : i + "天" + o + ":" + a + ":" + s;
            };
            n.compareVersion = function(e, t) {
                for (var n = e.split(".").map(function(e) {
                    return parseInt(e);
                }), r = t.split(".").map(function(e) {
                    return parseInt(e);
                }), i = n.length, o = r.length, a = Math.min(i, o), s = 0; s < a; ++s) if (n[s] != r[s]) return n[s] < r[s] ? -1 : 1;
                return i === o ? 0 : i < o ? -1 : 1;
            };
        }).call(this, r("543d").default);
    },
    b639: function(e, t, n) {
        (function(e) {
            function r() {
                return o.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
            }
            function i(e, t) {
                if (r() < t) throw new RangeError("Invalid typed array length");
                return o.TYPED_ARRAY_SUPPORT ? (e = new Uint8Array(t), e.__proto__ = o.prototype) : (null === e && (e = new o(t)), 
                e.length = t), e;
            }
            function o(e, t, n) {
                if (!(o.TYPED_ARRAY_SUPPORT || this instanceof o)) return new o(e, t, n);
                if ("number" == typeof e) {
                    if ("string" == typeof t) throw new Error("If encoding is specified then the first argument must be a string");
                    return l(this, e);
                }
                return a(this, e, t, n);
            }
            function a(e, t, n, r) {
                if ("number" == typeof t) throw new TypeError('"value" argument must not be a number');
                return "undefined" != typeof ArrayBuffer && t instanceof ArrayBuffer ? d(e, t, n, r) : "string" == typeof t ? u(e, t, n) : f(e, t);
            }
            function s(e) {
                if ("number" != typeof e) throw new TypeError('"size" argument must be a number');
                if (e < 0) throw new RangeError('"size" argument must not be negative');
            }
            function c(e, t, n, r) {
                return s(t), t <= 0 ? i(e, t) : void 0 !== n ? "string" == typeof r ? i(e, t).fill(n, r) : i(e, t).fill(n) : i(e, t);
            }
            function l(e, t) {
                if (s(t), e = i(e, t < 0 ? 0 : 0 | h(t)), !o.TYPED_ARRAY_SUPPORT) for (var n = 0; n < t; ++n) e[n] = 0;
                return e;
            }
            function u(e, t, n) {
                if ("string" == typeof n && "" !== n || (n = "utf8"), !o.isEncoding(n)) throw new TypeError('"encoding" must be a valid string encoding');
                var r = 0 | g(t, n), a = (e = i(e, r)).write(t, n);
                return a !== r && (e = e.slice(0, a)), e;
            }
            function p(e, t) {
                var n = t.length < 0 ? 0 : 0 | h(t.length);
                e = i(e, n);
                for (var r = 0; r < n; r += 1) e[r] = 255 & t[r];
                return e;
            }
            function d(e, t, n, r) {
                if (t.byteLength, n < 0 || t.byteLength < n) throw new RangeError("'offset' is out of bounds");
                if (t.byteLength < n + (r || 0)) throw new RangeError("'length' is out of bounds");
                return t = void 0 === n && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, n) : new Uint8Array(t, n, r), 
                o.TYPED_ARRAY_SUPPORT ? (e = t, e.__proto__ = o.prototype) : e = p(e, t), e;
            }
            function f(e, t) {
                if (o.isBuffer(t)) {
                    var n = 0 | h(t.length);
                    return 0 === (e = i(e, n)).length ? e : (t.copy(e, 0, 0, n), e);
                }
                if (t) {
                    if ("undefined" != typeof ArrayBuffer && t.buffer instanceof ArrayBuffer || "length" in t) return "number" != typeof t.length || G(t.length) ? i(e, 0) : p(e, t);
                    if ("Buffer" === t.type && K(t.data)) return p(e, t.data);
                }
                throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
            }
            function h(e) {
                if (e >= r()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + r().toString(16) + " bytes");
                return 0 | e;
            }
            function g(e, t) {
                if (o.isBuffer(e)) return e.length;
                if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)) return e.byteLength;
                "string" != typeof e && (e = "" + e);
                var n = e.length;
                if (0 === n) return 0;
                for (var r = !1; ;) switch (t) {
                  case "ascii":
                  case "latin1":
                  case "binary":
                    return n;

                  case "utf8":
                  case "utf-8":
                  case void 0:
                    return W(e).length;

                  case "ucs2":
                  case "ucs-2":
                  case "utf16le":
                  case "utf-16le":
                    return 2 * n;

                  case "hex":
                    return n >>> 1;

                  case "base64":
                    return V(e).length;

                  default:
                    if (r) return W(e).length;
                    t = ("" + t).toLowerCase(), r = !0;
                }
            }
            function v(e, t, n) {
                var r = !1;
                if ((void 0 === t || t < 0) && (t = 0), t > this.length) return "";
                if ((void 0 === n || n > this.length) && (n = this.length), n <= 0) return "";
                if (n >>>= 0, t >>>= 0, n <= t) return "";
                for (e || (e = "utf8"); ;) switch (e) {
                  case "hex":
                    return j(this, t, n);

                  case "utf8":
                  case "utf-8":
                    return O(this, t, n);

                  case "ascii":
                    return C(this, t, n);

                  case "latin1":
                  case "binary":
                    return D(this, t, n);

                  case "base64":
                    return P(this, t, n);

                  case "ucs2":
                  case "ucs-2":
                  case "utf16le":
                  case "utf-16le":
                    return $(this, t, n);

                  default:
                    if (r) throw new TypeError("Unknown encoding: " + e);
                    e = (e + "").toLowerCase(), r = !0;
                }
            }
            function m(e, t, n) {
                var r = e[t];
                e[t] = e[n], e[n] = r;
            }
            function y(e, t, n, r, i) {
                if (0 === e.length) return -1;
                if ("string" == typeof n ? (r = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), 
                n = +n, isNaN(n) && (n = i ? 0 : e.length - 1), n < 0 && (n = e.length + n), n >= e.length) {
                    if (i) return -1;
                    n = e.length - 1;
                } else if (n < 0) {
                    if (!i) return -1;
                    n = 0;
                }
                if ("string" == typeof t && (t = o.from(t, r)), o.isBuffer(t)) return 0 === t.length ? -1 : _(e, t, n, r, i);
                if ("number" == typeof t) return t &= 255, o.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(e, t, n) : Uint8Array.prototype.lastIndexOf.call(e, t, n) : _(e, [ t ], n, r, i);
                throw new TypeError("val must be string, number or Buffer");
            }
            function _(e, t, n, r, i) {
                function o(e, t) {
                    return 1 === s ? e[t] : e.readUInt16BE(t * s);
                }
                var a, s = 1, c = e.length, l = t.length;
                if (void 0 !== r && ("ucs2" === (r = String(r).toLowerCase()) || "ucs-2" === r || "utf16le" === r || "utf-16le" === r)) {
                    if (e.length < 2 || t.length < 2) return -1;
                    s = 2, c /= 2, l /= 2, n /= 2;
                }
                if (i) {
                    var u = -1;
                    for (a = n; a < c; a++) if (o(e, a) === o(t, -1 === u ? 0 : a - u)) {
                        if (-1 === u && (u = a), a - u + 1 === l) return u * s;
                    } else -1 !== u && (a -= a - u), u = -1;
                } else for (n + l > c && (n = c - l), a = n; a >= 0; a--) {
                    for (var p = !0, d = 0; d < l; d++) if (o(e, a + d) !== o(t, d)) {
                        p = !1;
                        break;
                    }
                    if (p) return a;
                }
                return -1;
            }
            function b(e, t, n, r) {
                n = Number(n) || 0;
                var i = e.length - n;
                r ? (r = Number(r)) > i && (r = i) : r = i;
                var o = t.length;
                if (o % 2 != 0) throw new TypeError("Invalid hex string");
                r > o / 2 && (r = o / 2);
                for (var a = 0; a < r; ++a) {
                    var s = parseInt(t.substr(2 * a, 2), 16);
                    if (isNaN(s)) return a;
                    e[n + a] = s;
                }
                return a;
            }
            function x(e, t, n, r) {
                return X(W(t, e.length - n), e, n, r);
            }
            function w(e, t, n, r) {
                return X(H(t), e, n, r);
            }
            function A(e, t, n, r) {
                return w(e, t, n, r);
            }
            function S(e, t, n, r) {
                return X(V(t), e, n, r);
            }
            function k(e, t, n, r) {
                return X(q(t, e.length - n), e, n, r);
            }
            function P(e, t, n) {
                return 0 === t && n === e.length ? Y.fromByteArray(e) : Y.fromByteArray(e.slice(t, n));
            }
            function O(e, t, n) {
                n = Math.min(e.length, n);
                for (var r = [], i = t; i < n; ) {
                    var o, a, s, c, l = e[i], u = null, p = l > 239 ? 4 : l > 223 ? 3 : l > 191 ? 2 : 1;
                    if (i + p <= n) switch (p) {
                      case 1:
                        l < 128 && (u = l);
                        break;

                      case 2:
                        128 == (192 & (o = e[i + 1])) && (c = (31 & l) << 6 | 63 & o) > 127 && (u = c);
                        break;

                      case 3:
                        o = e[i + 1], a = e[i + 2], 128 == (192 & o) && 128 == (192 & a) && (c = (15 & l) << 12 | (63 & o) << 6 | 63 & a) > 2047 && (c < 55296 || c > 57343) && (u = c);
                        break;

                      case 4:
                        o = e[i + 1], a = e[i + 2], s = e[i + 3], 128 == (192 & o) && 128 == (192 & a) && 128 == (192 & s) && (c = (15 & l) << 18 | (63 & o) << 12 | (63 & a) << 6 | 63 & s) > 65535 && c < 1114112 && (u = c);
                    }
                    null === u ? (u = 65533, p = 1) : u > 65535 && (u -= 65536, r.push(u >>> 10 & 1023 | 55296), 
                    u = 56320 | 1023 & u), r.push(u), i += p;
                }
                return T(r);
            }
            function T(e) {
                var t = e.length;
                if (t <= Q) return String.fromCharCode.apply(String, e);
                for (var n = "", r = 0; r < t; ) n += String.fromCharCode.apply(String, e.slice(r, r += Q));
                return n;
            }
            function C(e, t, n) {
                var r = "";
                n = Math.min(e.length, n);
                for (var i = t; i < n; ++i) r += String.fromCharCode(127 & e[i]);
                return r;
            }
            function D(e, t, n) {
                var r = "";
                n = Math.min(e.length, n);
                for (var i = t; i < n; ++i) r += String.fromCharCode(e[i]);
                return r;
            }
            function j(e, t, n) {
                var r = e.length;
                (!t || t < 0) && (t = 0), (!n || n < 0 || n > r) && (n = r);
                for (var i = "", o = t; o < n; ++o) i += U(e[o]);
                return i;
            }
            function $(e, t, n) {
                for (var r = e.slice(t, n), i = "", o = 0; o < r.length; o += 2) i += String.fromCharCode(r[o] + 256 * r[o + 1]);
                return i;
            }
            function E(e, t, n) {
                if (e % 1 != 0 || e < 0) throw new RangeError("offset is not uint");
                if (e + t > n) throw new RangeError("Trying to access beyond buffer length");
            }
            function M(e, t, n, r, i, a) {
                if (!o.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
                if (t > i || t < a) throw new RangeError('"value" argument is out of bounds');
                if (n + r > e.length) throw new RangeError("Index out of range");
            }
            function L(e, t, n, r) {
                t < 0 && (t = 65535 + t + 1);
                for (var i = 0, o = Math.min(e.length - n, 2); i < o; ++i) e[n + i] = (t & 255 << 8 * (r ? i : 1 - i)) >>> 8 * (r ? i : 1 - i);
            }
            function R(e, t, n, r) {
                t < 0 && (t = 4294967295 + t + 1);
                for (var i = 0, o = Math.min(e.length - n, 4); i < o; ++i) e[n + i] = t >>> 8 * (r ? i : 3 - i) & 255;
            }
            function I(e, t, n, r, i, o) {
                if (n + r > e.length) throw new RangeError("Index out of range");
                if (n < 0) throw new RangeError("Index out of range");
            }
            function F(e, t, n, r, i) {
                return i || I(e, t, n, 4, 3.4028234663852886e38, -3.4028234663852886e38), J.write(e, t, n, r, 23, 4), 
                n + 4;
            }
            function N(e, t, n, r, i) {
                return i || I(e, t, n, 8, 1.7976931348623157e308, -1.7976931348623157e308), J.write(e, t, n, r, 52, 8), 
                n + 8;
            }
            function z(e) {
                if ((e = B(e).replace(Z, "")).length < 2) return "";
                for (;e.length % 4 != 0; ) e += "=";
                return e;
            }
            function B(e) {
                return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, "");
            }
            function U(e) {
                return e < 16 ? "0" + e.toString(16) : e.toString(16);
            }
            function W(e, t) {
                var n;
                t = t || 1 / 0;
                for (var r = e.length, i = null, o = [], a = 0; a < r; ++a) {
                    if ((n = e.charCodeAt(a)) > 55295 && n < 57344) {
                        if (!i) {
                            if (n > 56319) {
                                (t -= 3) > -1 && o.push(239, 191, 189);
                                continue;
                            }
                            if (a + 1 === r) {
                                (t -= 3) > -1 && o.push(239, 191, 189);
                                continue;
                            }
                            i = n;
                            continue;
                        }
                        if (n < 56320) {
                            (t -= 3) > -1 && o.push(239, 191, 189), i = n;
                            continue;
                        }
                        n = 65536 + (i - 55296 << 10 | n - 56320);
                    } else i && (t -= 3) > -1 && o.push(239, 191, 189);
                    if (i = null, n < 128) {
                        if ((t -= 1) < 0) break;
                        o.push(n);
                    } else if (n < 2048) {
                        if ((t -= 2) < 0) break;
                        o.push(n >> 6 | 192, 63 & n | 128);
                    } else if (n < 65536) {
                        if ((t -= 3) < 0) break;
                        o.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128);
                    } else {
                        if (!(n < 1114112)) throw new Error("Invalid code point");
                        if ((t -= 4) < 0) break;
                        o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128);
                    }
                }
                return o;
            }
            function H(e) {
                for (var t = [], n = 0; n < e.length; ++n) t.push(255 & e.charCodeAt(n));
                return t;
            }
            function q(e, t) {
                for (var n, r, i, o = [], a = 0; a < e.length && !((t -= 2) < 0); ++a) r = (n = e.charCodeAt(a)) >> 8, 
                i = n % 256, o.push(i), o.push(r);
                return o;
            }
            function V(e) {
                return Y.toByteArray(z(e));
            }
            function X(e, t, n, r) {
                for (var i = 0; i < r && !(i + n >= t.length || i >= e.length); ++i) t[i + n] = e[i];
                return i;
            }
            function G(e) {
                return e !== e;
            }
            var Y = n("1fb5"), J = n("9152"), K = n("e3db");
            t.Buffer = o, t.SlowBuffer = function(e) {
                return +e != e && (e = 0), o.alloc(+e);
            }, t.INSPECT_MAX_BYTES = 50, o.TYPED_ARRAY_SUPPORT = void 0 !== e.TYPED_ARRAY_SUPPORT ? e.TYPED_ARRAY_SUPPORT : function() {
                try {
                    var e = new Uint8Array(1);
                    return e.__proto__ = {
                        __proto__: Uint8Array.prototype,
                        foo: function() {
                            return 42;
                        }
                    }, 42 === e.foo() && "function" == typeof e.subarray && 0 === e.subarray(1, 1).byteLength;
                } catch (e) {
                    return !1;
                }
            }(), t.kMaxLength = r(), o.poolSize = 8192, o._augment = function(e) {
                return e.__proto__ = o.prototype, e;
            }, o.from = function(e, t, n) {
                return a(null, e, t, n);
            }, o.TYPED_ARRAY_SUPPORT && (o.prototype.__proto__ = Uint8Array.prototype, o.__proto__ = Uint8Array, 
            "undefined" != typeof Symbol && Symbol.species && o[Symbol.species] === o && Object.defineProperty(o, Symbol.species, {
                value: null,
                configurable: !0
            })), o.alloc = function(e, t, n) {
                return c(null, e, t, n);
            }, o.allocUnsafe = function(e) {
                return l(null, e);
            }, o.allocUnsafeSlow = function(e) {
                return l(null, e);
            }, o.isBuffer = function(e) {
                return !(null == e || !e._isBuffer);
            }, o.compare = function(e, t) {
                if (!o.isBuffer(e) || !o.isBuffer(t)) throw new TypeError("Arguments must be Buffers");
                if (e === t) return 0;
                for (var n = e.length, r = t.length, i = 0, a = Math.min(n, r); i < a; ++i) if (e[i] !== t[i]) {
                    n = e[i], r = t[i];
                    break;
                }
                return n < r ? -1 : r < n ? 1 : 0;
            }, o.isEncoding = function(e) {
                switch (String(e).toLowerCase()) {
                  case "hex":
                  case "utf8":
                  case "utf-8":
                  case "ascii":
                  case "latin1":
                  case "binary":
                  case "base64":
                  case "ucs2":
                  case "ucs-2":
                  case "utf16le":
                  case "utf-16le":
                    return !0;

                  default:
                    return !1;
                }
            }, o.concat = function(e, t) {
                if (!K(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                if (0 === e.length) return o.alloc(0);
                var n;
                if (void 0 === t) for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
                var r = o.allocUnsafe(t), i = 0;
                for (n = 0; n < e.length; ++n) {
                    var a = e[n];
                    if (!o.isBuffer(a)) throw new TypeError('"list" argument must be an Array of Buffers');
                    a.copy(r, i), i += a.length;
                }
                return r;
            }, o.byteLength = g, o.prototype._isBuffer = !0, o.prototype.swap16 = function() {
                var e = this.length;
                if (e % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
                for (var t = 0; t < e; t += 2) m(this, t, t + 1);
                return this;
            }, o.prototype.swap32 = function() {
                var e = this.length;
                if (e % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
                for (var t = 0; t < e; t += 4) m(this, t, t + 3), m(this, t + 1, t + 2);
                return this;
            }, o.prototype.swap64 = function() {
                var e = this.length;
                if (e % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
                for (var t = 0; t < e; t += 8) m(this, t, t + 7), m(this, t + 1, t + 6), m(this, t + 2, t + 5), 
                m(this, t + 3, t + 4);
                return this;
            }, o.prototype.toString = function() {
                var e = 0 | this.length;
                return 0 === e ? "" : 0 === arguments.length ? O(this, 0, e) : v.apply(this, arguments);
            }, o.prototype.equals = function(e) {
                if (!o.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
                return this === e || 0 === o.compare(this, e);
            }, o.prototype.inspect = function() {
                var e = "", n = t.INSPECT_MAX_BYTES;
                return this.length > 0 && (e = this.toString("hex", 0, n).match(/.{2}/g).join(" "), 
                this.length > n && (e += " ... ")), "<Buffer " + e + ">";
            }, o.prototype.compare = function(e, t, n, r, i) {
                if (!o.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
                if (void 0 === t && (t = 0), void 0 === n && (n = e ? e.length : 0), void 0 === r && (r = 0), 
                void 0 === i && (i = this.length), t < 0 || n > e.length || r < 0 || i > this.length) throw new RangeError("out of range index");
                if (r >= i && t >= n) return 0;
                if (r >= i) return -1;
                if (t >= n) return 1;
                if (t >>>= 0, n >>>= 0, r >>>= 0, i >>>= 0, this === e) return 0;
                for (var a = i - r, s = n - t, c = Math.min(a, s), l = this.slice(r, i), u = e.slice(t, n), p = 0; p < c; ++p) if (l[p] !== u[p]) {
                    a = l[p], s = u[p];
                    break;
                }
                return a < s ? -1 : s < a ? 1 : 0;
            }, o.prototype.includes = function(e, t, n) {
                return -1 !== this.indexOf(e, t, n);
            }, o.prototype.indexOf = function(e, t, n) {
                return y(this, e, t, n, !0);
            }, o.prototype.lastIndexOf = function(e, t, n) {
                return y(this, e, t, n, !1);
            }, o.prototype.write = function(e, t, n, r) {
                if (void 0 === t) r = "utf8", n = this.length, t = 0; else if (void 0 === n && "string" == typeof t) r = t, 
                n = this.length, t = 0; else {
                    if (!isFinite(t)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                    t |= 0, isFinite(n) ? (n |= 0, void 0 === r && (r = "utf8")) : (r = n, n = void 0);
                }
                var i = this.length - t;
                if ((void 0 === n || n > i) && (n = i), e.length > 0 && (n < 0 || t < 0) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
                r || (r = "utf8");
                for (var o = !1; ;) switch (r) {
                  case "hex":
                    return b(this, e, t, n);

                  case "utf8":
                  case "utf-8":
                    return x(this, e, t, n);

                  case "ascii":
                    return w(this, e, t, n);

                  case "latin1":
                  case "binary":
                    return A(this, e, t, n);

                  case "base64":
                    return S(this, e, t, n);

                  case "ucs2":
                  case "ucs-2":
                  case "utf16le":
                  case "utf-16le":
                    return k(this, e, t, n);

                  default:
                    if (o) throw new TypeError("Unknown encoding: " + r);
                    r = ("" + r).toLowerCase(), o = !0;
                }
            }, o.prototype.toJSON = function() {
                return {
                    type: "Buffer",
                    data: Array.prototype.slice.call(this._arr || this, 0)
                };
            };
            var Q = 4096;
            o.prototype.slice = function(e, t) {
                var n, r = this.length;
                if (e = ~~e, t = void 0 === t ? r : ~~t, e < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), 
                t < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), t < e && (t = e), o.TYPED_ARRAY_SUPPORT) n = this.subarray(e, t), 
                n.__proto__ = o.prototype; else {
                    var i = t - e;
                    n = new o(i, void 0);
                    for (var a = 0; a < i; ++a) n[a] = this[a + e];
                }
                return n;
            }, o.prototype.readUIntLE = function(e, t, n) {
                e |= 0, t |= 0, n || E(e, t, this.length);
                for (var r = this[e], i = 1, o = 0; ++o < t && (i *= 256); ) r += this[e + o] * i;
                return r;
            }, o.prototype.readUIntBE = function(e, t, n) {
                e |= 0, t |= 0, n || E(e, t, this.length);
                for (var r = this[e + --t], i = 1; t > 0 && (i *= 256); ) r += this[e + --t] * i;
                return r;
            }, o.prototype.readUInt8 = function(e, t) {
                return t || E(e, 1, this.length), this[e];
            }, o.prototype.readUInt16LE = function(e, t) {
                return t || E(e, 2, this.length), this[e] | this[e + 1] << 8;
            }, o.prototype.readUInt16BE = function(e, t) {
                return t || E(e, 2, this.length), this[e] << 8 | this[e + 1];
            }, o.prototype.readUInt32LE = function(e, t) {
                return t || E(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3];
            }, o.prototype.readUInt32BE = function(e, t) {
                return t || E(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
            }, o.prototype.readIntLE = function(e, t, n) {
                e |= 0, t |= 0, n || E(e, t, this.length);
                for (var r = this[e], i = 1, o = 0; ++o < t && (i *= 256); ) r += this[e + o] * i;
                return i *= 128, r >= i && (r -= Math.pow(2, 8 * t)), r;
            }, o.prototype.readIntBE = function(e, t, n) {
                e |= 0, t |= 0, n || E(e, t, this.length);
                for (var r = t, i = 1, o = this[e + --r]; r > 0 && (i *= 256); ) o += this[e + --r] * i;
                return i *= 128, o >= i && (o -= Math.pow(2, 8 * t)), o;
            }, o.prototype.readInt8 = function(e, t) {
                return t || E(e, 1, this.length), 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e];
            }, o.prototype.readInt16LE = function(e, t) {
                t || E(e, 2, this.length);
                var n = this[e] | this[e + 1] << 8;
                return 32768 & n ? 4294901760 | n : n;
            }, o.prototype.readInt16BE = function(e, t) {
                t || E(e, 2, this.length);
                var n = this[e + 1] | this[e] << 8;
                return 32768 & n ? 4294901760 | n : n;
            }, o.prototype.readInt32LE = function(e, t) {
                return t || E(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
            }, o.prototype.readInt32BE = function(e, t) {
                return t || E(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
            }, o.prototype.readFloatLE = function(e, t) {
                return t || E(e, 4, this.length), J.read(this, e, !0, 23, 4);
            }, o.prototype.readFloatBE = function(e, t) {
                return t || E(e, 4, this.length), J.read(this, e, !1, 23, 4);
            }, o.prototype.readDoubleLE = function(e, t) {
                return t || E(e, 8, this.length), J.read(this, e, !0, 52, 8);
            }, o.prototype.readDoubleBE = function(e, t) {
                return t || E(e, 8, this.length), J.read(this, e, !1, 52, 8);
            }, o.prototype.writeUIntLE = function(e, t, n, r) {
                e = +e, t |= 0, n |= 0, r || M(this, e, t, n, Math.pow(2, 8 * n) - 1, 0);
                var i = 1, o = 0;
                for (this[t] = 255 & e; ++o < n && (i *= 256); ) this[t + o] = e / i & 255;
                return t + n;
            }, o.prototype.writeUIntBE = function(e, t, n, r) {
                e = +e, t |= 0, n |= 0, r || M(this, e, t, n, Math.pow(2, 8 * n) - 1, 0);
                var i = n - 1, o = 1;
                for (this[t + i] = 255 & e; --i >= 0 && (o *= 256); ) this[t + i] = e / o & 255;
                return t + n;
            }, o.prototype.writeUInt8 = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 1, 255, 0), o.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), 
                this[t] = 255 & e, t + 1;
            }, o.prototype.writeUInt16LE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 2, 65535, 0), o.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, 
                this[t + 1] = e >>> 8) : L(this, e, t, !0), t + 2;
            }, o.prototype.writeUInt16BE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 2, 65535, 0), o.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, 
                this[t + 1] = 255 & e) : L(this, e, t, !1), t + 2;
            }, o.prototype.writeUInt32LE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 4, 4294967295, 0), o.TYPED_ARRAY_SUPPORT ? (this[t + 3] = e >>> 24, 
                this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e) : R(this, e, t, !0), 
                t + 4;
            }, o.prototype.writeUInt32BE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 4, 4294967295, 0), o.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, 
                this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e) : R(this, e, t, !1), 
                t + 4;
            }, o.prototype.writeIntLE = function(e, t, n, r) {
                if (e = +e, t |= 0, !r) {
                    var i = Math.pow(2, 8 * n - 1);
                    M(this, e, t, n, i - 1, -i);
                }
                var o = 0, a = 1, s = 0;
                for (this[t] = 255 & e; ++o < n && (a *= 256); ) e < 0 && 0 === s && 0 !== this[t + o - 1] && (s = 1), 
                this[t + o] = (e / a >> 0) - s & 255;
                return t + n;
            }, o.prototype.writeIntBE = function(e, t, n, r) {
                if (e = +e, t |= 0, !r) {
                    var i = Math.pow(2, 8 * n - 1);
                    M(this, e, t, n, i - 1, -i);
                }
                var o = n - 1, a = 1, s = 0;
                for (this[t + o] = 255 & e; --o >= 0 && (a *= 256); ) e < 0 && 0 === s && 0 !== this[t + o + 1] && (s = 1), 
                this[t + o] = (e / a >> 0) - s & 255;
                return t + n;
            }, o.prototype.writeInt8 = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 1, 127, -128), o.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), 
                e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1;
            }, o.prototype.writeInt16LE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 2, 32767, -32768), o.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, 
                this[t + 1] = e >>> 8) : L(this, e, t, !0), t + 2;
            }, o.prototype.writeInt16BE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 2, 32767, -32768), o.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, 
                this[t + 1] = 255 & e) : L(this, e, t, !1), t + 2;
            }, o.prototype.writeInt32LE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 4, 2147483647, -2147483648), o.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, 
                this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24) : R(this, e, t, !0), 
                t + 4;
            }, o.prototype.writeInt32BE = function(e, t, n) {
                return e = +e, t |= 0, n || M(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), 
                o.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, 
                this[t + 3] = 255 & e) : R(this, e, t, !1), t + 4;
            }, o.prototype.writeFloatLE = function(e, t, n) {
                return F(this, e, t, !0, n);
            }, o.prototype.writeFloatBE = function(e, t, n) {
                return F(this, e, t, !1, n);
            }, o.prototype.writeDoubleLE = function(e, t, n) {
                return N(this, e, t, !0, n);
            }, o.prototype.writeDoubleBE = function(e, t, n) {
                return N(this, e, t, !1, n);
            }, o.prototype.copy = function(e, t, n, r) {
                if (n || (n = 0), r || 0 === r || (r = this.length), t >= e.length && (t = e.length), 
                t || (t = 0), r > 0 && r < n && (r = n), r === n) return 0;
                if (0 === e.length || 0 === this.length) return 0;
                if (t < 0) throw new RangeError("targetStart out of bounds");
                if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
                if (r < 0) throw new RangeError("sourceEnd out of bounds");
                r > this.length && (r = this.length), e.length - t < r - n && (r = e.length - t + n);
                var i, a = r - n;
                if (this === e && n < t && t < r) for (i = a - 1; i >= 0; --i) e[i + t] = this[i + n]; else if (a < 1e3 || !o.TYPED_ARRAY_SUPPORT) for (i = 0; i < a; ++i) e[i + t] = this[i + n]; else Uint8Array.prototype.set.call(e, this.subarray(n, n + a), t);
                return a;
            }, o.prototype.fill = function(e, t, n, r) {
                if ("string" == typeof e) {
                    if ("string" == typeof t ? (r = t, t = 0, n = this.length) : "string" == typeof n && (r = n, 
                    n = this.length), 1 === e.length) {
                        var i = e.charCodeAt(0);
                        i < 256 && (e = i);
                    }
                    if (void 0 !== r && "string" != typeof r) throw new TypeError("encoding must be a string");
                    if ("string" == typeof r && !o.isEncoding(r)) throw new TypeError("Unknown encoding: " + r);
                } else "number" == typeof e && (e &= 255);
                if (t < 0 || this.length < t || this.length < n) throw new RangeError("Out of range index");
                if (n <= t) return this;
                var a;
                if (t >>>= 0, n = void 0 === n ? this.length : n >>> 0, e || (e = 0), "number" == typeof e) for (a = t; a < n; ++a) this[a] = e; else {
                    var s = o.isBuffer(e) ? e : W(new o(e, r).toString()), c = s.length;
                    for (a = 0; a < n - t; ++a) this[a + t] = s[a % c];
                }
                return this;
            };
            var Z = /[^+\/0-9A-Za-z-_]/g;
        }).call(this, n("c8ba"));
    },
    b7dd: function(e, t, n) {
        function r(e, t, n, r, i, o, a) {
            try {
                var s = e[o](a), c = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i);
        }
        function i(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(i, o) {
                    function a(e) {
                        r(c, i, o, a, s, "next", e);
                    }
                    function s(e) {
                        r(c, i, o, a, s, "throw", e);
                    }
                    var c = e.apply(t, n);
                    a(void 0);
                });
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("a34a")), a = function() {
            var e = i(o.default.mark(function e(t) {
                return o.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (t = t || {}).isShow = !1, this.$store.dispatch("loading/actionGetLoading", t);

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }();
        t.default = a;
    },
    bbdd: function(t, n, r) {
        var i = function() {
            return this || "object" === ("undefined" == typeof self ? "undefined" : e(self)) && self;
        }() || Function("return this")(), o = i.regeneratorRuntime && Object.getOwnPropertyNames(i).indexOf("regeneratorRuntime") >= 0, a = o && i.regeneratorRuntime;
        if (i.regeneratorRuntime = void 0, t.exports = r("96cf"), o) i.regeneratorRuntime = a; else try {
            delete i.regeneratorRuntime;
        } catch (e) {
            i.regeneratorRuntime = void 0;
        }
    },
    c3b2: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                scrollTop: 0,
                isScanQrCode: !1,
                coupon: {
                    list: [],
                    type: ""
                },
                query: null,
                polite: null,
                newcomers: null
            },
            getters: {
                getScrollTop: function(e) {
                    return e.scrollTop;
                },
                getIsScanQrCode: function(e) {
                    return e.isScanQrCode;
                },
                getCoupon: function(e) {
                    return e.coupon;
                },
                getQuery: function(e) {
                    return e.query;
                },
                getPolite: function(e) {
                    return e.polite;
                },
                getNewcomers: function(e) {
                    return e.newcomers;
                }
            },
            mutations: {
                mutSetScrollTop: function(e, t) {
                    e.scrollTop = t;
                },
                mutSetIsScanQrCode: function(e, t) {
                    e.isScanQrCode = t;
                },
                mutSetCoupon: function(e, t) {
                    e.coupon = t;
                },
                mutSetQuery: function(e, t) {
                    e.query = t;
                },
                mutSetPolite: function(e, t) {
                    e.polite = t;
                },
                mutSetNewcomers: function(e, t) {
                    e.newcomers = t;
                }
            },
            actions: {
                actionSetScrollTop: function(e, t) {
                    e.commit("mutSetScrollTop", t);
                },
                actionSetIsScanQrCode: function(e, t) {
                    e.commit("mutSetIsScanQrCode", t);
                },
                actionSetCoupon: function(e, t) {
                    e.commit("mutSetCoupon", t);
                },
                actionSetQeury: function(e, t) {
                    e.commit("mutSetQuery", t);
                },
                actionSetPolite: function(e, t) {
                    e.commit("mutSetPolite", t);
                },
                actionSetNewcomers: function(e, t) {
                    e.commit("mutSetNewcomers", t);
                }
            }
        };
        t.default = r;
    },
    c8ba: function(t, n) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" === ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    ce85: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e, t, n, r, i, o, a) {
            try {
                var s = e[o](a), c = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i);
        }
        function o(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(r, o) {
                    function a(e) {
                        i(c, r, o, a, s, "next", e);
                    }
                    function s(e) {
                        i(c, r, o, a, s, "throw", e);
                    }
                    var c = e.apply(t, n);
                    a(void 0);
                });
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = r(n("a34a")), s = r(n("66fd")), c = {
            namespaced: !0,
            state: {
                data: {},
                title: "",
                zero_tpl: [],
                quick_navigation: {}
            },
            getters: {
                data: function(e) {
                    return e.data;
                },
                title: function(e) {
                    return e.title;
                },
                userCenter: function(e) {
                    return e.data;
                },
                quick_navigation: function(e) {
                    return e.data;
                },
                zero_tpl: function(e) {
                    return e.zero_tpl;
                }
            },
            mutations: {
                data: function(e, t) {
                    e.data = t;
                },
                title: function(e, t) {
                    e.title = t;
                },
                quick_navigation: function(e, t) {
                    e.quick_navigation = t;
                },
                zero_tpl: function(e, t) {
                    e.zero_tpl = t;
                }
            },
            actions: {
                data: function() {
                    var e = o(a.default.mark(function e(t) {
                        return a.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, s.default.prototype.$request({
                                    url: s.default.prototype.$api.user.config
                                }).then(function(e) {
                                    var n = e.data;
                                    if (0 === e.code) {
                                        var r = n.config;
                                        n && r && (r.user_center && t.commit("data", r.user_center), r.user_center_title && t.commit("title", r.user_center_title), 
                                        r.user_center_title && t.commit("quick_navigation", r.quick_navigation), r.zero_tpl && t.commit("zero_tpl", r.zero_tpl));
                                    }
                                });

                              case 2:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }));
                    return function(t) {
                        return e.apply(this, arguments);
                    };
                }()
            }
        };
        t.default = c;
    },
    d1e4: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                year: 1
            }
        };
        t.default = r;
    },
    d30e: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("66fd")), i = {
            namespaced: !0,
            state: {
                auth_page: {
                    pic_url: ""
                },
                bar_title: {},
                cat_style: {},
                copyright: {},
                mall: {
                    setting: {
                        theme_color: "classic-red"
                    }
                },
                navbar: {
                    navs: []
                },
                plugin: {
                    vip_card: {
                        setting: {
                            background: "#f7f7f7"
                        }
                    }
                },
                share_setting: [],
                share_setting_custom: {},
                user_center: {},
                __wxapp_img: {},
                theme_color: {
                    key: "a",
                    color: "#ff4544",
                    background: "#ff4544",
                    border: "#ff4544",
                    border_s: "#f39800",
                    background_s: "#f39800",
                    main_text: "#ffffff",
                    secondary_text: "#ffffff",
                    border_m: "border-color: #ff4544;border-bottom-color: transparent;border-left-color: transparent;border-right-color: transparent;",
                    background_o: "rgba(255,69,68, 0.1)",
                    background_p: "rgba(255,69,68, 0.2)",
                    background_l: "rgba(255,69,68, 0.35)",
                    background_q: "rgba(255,69,68, 0.8)",
                    background_gradient: "linear-gradient(140deg, #ff4544, #f39800)",
                    background_gradient_l: "linear-gradient(to right, rgba(255,69,68, 1), rgba(255,69,68, 0.5))",
                    background_gradient_o: "linear-gradient(to right, rgba(255,69,68, 1), rgba(255,69,68, 0.7))",
                    background_s_gradient_o: "linear-gradient(to right, rgb(243,152,0),rgba(243,152,0, 0.7))",
                    background_gradient_btn: "linear-gradient(to left, rgb(255,69,68),rgba(255,69,68, 0.7))",
                    background_s_gradient_btn: "linear-gradient(to right, rgb(243,152,0),rgba(243,152,0, 0.7))"
                },
                theme: "classic-red",
                windowHeight: {
                    height: 0,
                    width: 0,
                    boolean: !1
                },
                negotiable_text: "",
                permissions: []
            },
            getters: {
                getNavBar: function(e) {
                    return e.navbar;
                },
                getPermissions: function(e) {
                    return e.permissions;
                },
                getNegotiableText: function(e) {
                    return e.mall.setting.negotiable_text;
                },
                getNavBarNavs: function(e) {
                    for (var t = 0, n = e.navbar.navs.length; t < n; t++) ;
                },
                getUserCenter: function(e) {
                    return e.user_center;
                },
                getWxappImg: function(e) {
                    return e.__wxapp_img;
                },
                getCatStyle: function(e) {
                    return e.cat_style;
                },
                getVip: function(e) {
                    return e.plugin.vip_card;
                },
                getVideo: function(e) {
                    return e.mall.setting.is_goods_video;
                },
                getShowCart: function(e) {
                    return e.mall.setting.is_show_cart;
                },
                getTheme: function(e) {
                    return e.theme_color;
                },
                getSetting: function(e) {
                    return e.mall.setting;
                }
            },
            mutations: {
                mutSetConfig: function(e, t) {
                    for (var n in t) {
                        if ("navbar" === n) for (var r = 0; r < t[n].navs.length; r++) t[n].navs[r].id = r;
                        e[n] = t[n];
                    }
                },
                mutSetHeight: function(e, t) {
                    e.windowHeight = t;
                }
            },
            actions: {
                actionGetConfig: function(e) {
                    r.default.prototype.$mallConfig.getConfig().then(function(t) {
                        e.commit("mutSetConfig", t);
                    }).catch(function() {});
                },
                actionHeight: function(e, t) {
                    e.commit("mutSetHeight", t);
                },
                actionResetConfig: function(e) {
                    r.default.prototype.$mallConfig.resetConfig(), r.default.prototype.$mallConfig.getConfig().then(function(t) {
                        e.commit("mutSetConfig", t);
                    }).catch(function() {});
                }
            }
        };
        t.default = i;
    },
    d3b5: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("9dc1")), o = r(n("27f5")), a = r(n("66fd")), s = !0, c = !1, l = null, u = "_APP_CONFIG", p = [], d = [], f = function(e, t) {
            e && p.push(e), t && d.push(t), c || (c = !0, (0, i.default)({
                url: o.default.index.config
            }).then(function(e) {
                if (c = !1, 0 === e.code) {
                    for (var t in l = e.data, a.default.prototype.$storage.setStorageSync(u, l), p) p[t](l);
                    p = [];
                } else {
                    for (var n in d) d[n](e.msg);
                    d = [];
                }
            }).catch(function(e) {
                for (var t in c = !1, d) d[t](e.msg);
                d = [];
            }));
        }, h = {
            getConfig: function(e) {
                return new Promise(function(e, t) {
                    return l ? e(l) : (l = a.default.prototype.$storage.getStorageSync(u)) ? (s && (s = !1, 
                    f()), e(l)) : void f(e, t);
                });
            },
            resetConfig: function() {
                l = null, a.default.prototype.$storage.removeStorageSync(u), c = !1;
            }
        };
        t.default = h;
    },
    d5ea: function(e, t, n) {
        (function(e) {
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("f854"));
            r(n("66fd"));
            t.default = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return new Promise(function(n, r) {
                    (0, i.default)(t, "file").then(function(i) {
                        e.uploadFile({
                            url: t.url,
                            filePath: t.filePath,
                            name: "file",
                            fileType: t.fileType,
                            formData: {
                                file: t.filePath,
                                file_name: t.fileName,
                                mch_id: t.mch_id
                            },
                            header: i,
                            success: function(e) {
                                return n(e);
                            },
                            fail: function(e) {
                                return r(e);
                            }
                        });
                    });
                });
            };
        }).call(this, n("543d").default);
    },
    dc83: function(e, t, n) {
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function i(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        function o(e, t, n) {
            return t && i(e.prototype, t), n && i(e, n), e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = function() {
            function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.key, i = t.label, o = t.value, a = t.required;
                r(this, e), this.key = n, this.label = i, this.value = o, this.required = a || 0;
            }
            return o(e, [ {
                key: "add",
                value: function(e) {
                    Object.assign(this, e);
                }
            }, {
                key: "getObject",
                value: function() {
                    return this;
                }
            } ]), e;
        }();
        t.default = a;
    },
    dcdb: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                formData: null,
                mchNoCouponStatusList: []
            },
            getters: {
                getMchNoCouponStatusList: function(e) {
                    return e.mchNoCouponStatusList;
                }
            },
            mutations: {
                mutSetFormData: function(e, t) {
                    e.formData = t;
                },
                mutSetMchNoCouponStatusList: function(e, t) {
                    e.mchNoCouponStatusList = t;
                }
            },
            actions: {}
        };
        t.default = r;
    },
    dd00: function(t, n, r) {
        function i(t) {
            return (i = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function o(e) {
            if ("function" != typeof WeakMap) return null;
            var t = new WeakMap(), n = new WeakMap();
            return (o = function(e) {
                return e ? n : t;
            })(e);
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = function(e, t) {
            if (!t && e && e.__esModule) return e;
            if (null === e || "object" !== i(e) && "function" != typeof e) return {
                default: e
            };
            var n = o(t);
            if (n && n.has(e)) return n.get(e);
            var r = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var s in e) if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
                var c = a ? Object.getOwnPropertyDescriptor(e, s) : null;
                c && (c.get || c.set) ? Object.defineProperty(r, s, c) : r[s] = e[s];
            }
            return r.default = e, n && n.set(e, r), r;
        }(r("b1c7")), s = {
            route: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                if (!e) {
                    var t = getCurrentPages();
                    t.length && (e = t[t.length - 1]);
                }
                return "/".concat(e.route.split("?")[0]);
            },
            routeWithOption: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                if (!e) {
                    var t = getCurrentPages();
                    t.length && (e = t[t.length - 1]);
                }
                var n = "";
                return n = "/".concat(e.route.split("?")[0]), e.options && (n += "?" + a.objectToUrlParams(e.options)), 
                n;
            },
            tabBarUrl: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                if (!e) {
                    var n = getCurrentPages();
                    if (n.length) {
                        var r = n.length - t > 0 && t > 0 ? n.length - t : 0;
                        e = n[n.length - 1 - r];
                    }
                }
                var i = "";
                i = "/".concat(e.route.split("?")[0]);
                var o = {};
                if (o = e.options) {
                    var s = {};
                    for (var c in o) ("user_id" != c && "scene" != c && "params" != c && "first_id" != c && "select_cat_id" != c && "path" != c && "share_openid" != c && "custom_params" != c && "room_id" != c && "openid" != c && "multipleSlots" != c && "addGlobalClass" != c && "__id__" != c && "qr_code_id" != c || "_swebFromHost" == c || "_swebfr" == c) && ("page_id" == c ? o[c] > 0 && (s[c] = o[c]) : s[c] = o[c]);
                    (s = a.objectToUrlParams(s)) && (i += "?" + s);
                }
                return i;
            },
            reload: function() {
                getCurrentPages()[getCurrentPages().length - 1].onShow();
            }
        };
        n.default = s;
    },
    e1435: function(t, n, r) {
        r.r(n), function(t, r) {
            function i(e) {
                return void 0 === e || null === e;
            }
            function o(e) {
                return void 0 !== e && null !== e;
            }
            function a(e) {
                return !0 === e;
            }
            function s(e) {
                return !1 === e;
            }
            function c(t) {
                return "string" == typeof t || "number" == typeof t || "symbol" === (void 0 === t ? "undefined" : e(t)) || "boolean" == typeof t;
            }
            function l(t) {
                return null !== t && "object" === (void 0 === t ? "undefined" : e(t));
            }
            function u(e) {
                return "[object Object]" === vr.call(e);
            }
            function p(e) {
                return "[object RegExp]" === vr.call(e);
            }
            function d(e) {
                var t = parseFloat(String(e));
                return t >= 0 && Math.floor(t) === t && isFinite(e);
            }
            function f(e) {
                return o(e) && "function" == typeof e.then && "function" == typeof e.catch;
            }
            function h(e) {
                return null == e ? "" : Array.isArray(e) || u(e) && e.toString === vr ? JSON.stringify(e, null, 2) : String(e);
            }
            function g(e) {
                var t = parseFloat(e);
                return isNaN(t) ? e : t;
            }
            function v(e, t) {
                for (var n = Object.create(null), r = e.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return t ? function(e) {
                    return n[e.toLowerCase()];
                } : function(e) {
                    return n[e];
                };
            }
            function m(e, t) {
                if (e.length) {
                    var n = e.indexOf(t);
                    if (n > -1) return e.splice(n, 1);
                }
            }
            function y(e, t) {
                return _r.call(e, t);
            }
            function _(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            function b(e, t) {
                t = t || 0;
                for (var n = e.length - t, r = new Array(n); n--; ) r[n] = e[n + t];
                return r;
            }
            function x(e, t) {
                for (var n in t) e[n] = t[n];
                return e;
            }
            function w(e) {
                for (var t = {}, n = 0; n < e.length; n++) e[n] && x(t, e[n]);
                return t;
            }
            function A(e, t, n) {}
            function S(e, t) {
                if (e === t) return !0;
                var n = l(e), r = l(t);
                if (!n || !r) return !n && !r && String(e) === String(t);
                try {
                    var i = Array.isArray(e), o = Array.isArray(t);
                    if (i && o) return e.length === t.length && e.every(function(e, n) {
                        return S(e, t[n]);
                    });
                    if (e instanceof Date && t instanceof Date) return e.getTime() === t.getTime();
                    if (i || o) return !1;
                    var a = Object.keys(e), s = Object.keys(t);
                    return a.length === s.length && a.every(function(n) {
                        return S(e[n], t[n]);
                    });
                } catch (e) {
                    return !1;
                }
            }
            function k(e, t) {
                for (var n = 0; n < e.length; n++) if (S(e[n], t)) return n;
                return -1;
            }
            function P(e) {
                var t = !1;
                return function() {
                    t || (t = !0, e.apply(this, arguments));
                };
            }
            function O(e) {
                var t = (e + "").charCodeAt(0);
                return 36 === t || 95 === t;
            }
            function T(e, t, n, r) {
                Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            function C(e) {
                if (!Er.test(e)) {
                    var t = e.split(".");
                    return function(e) {
                        for (var n = 0; n < t.length; n++) {
                            if (!e) return;
                            e = e[t[n]];
                        }
                        return e;
                    };
                }
            }
            function D(e) {
                return "function" == typeof e && /native code/.test(e.toString());
            }
            function j(e) {
                Zr.SharedObject.targetStack.push(e), Zr.SharedObject.target = e, Zr.target = e;
            }
            function $() {
                Zr.SharedObject.targetStack.pop(), Zr.SharedObject.target = Zr.SharedObject.targetStack[Zr.SharedObject.targetStack.length - 1], 
                Zr.target = Zr.SharedObject.target;
            }
            function E(e) {
                return new ei(void 0, void 0, void 0, String(e));
            }
            function M(e) {
                var t = new ei(e.tag, e.data, e.children && e.children.slice(), e.text, e.elm, e.context, e.componentOptions, e.asyncFactory);
                return t.ns = e.ns, t.isStatic = e.isStatic, t.key = e.key, t.isComment = e.isComment, 
                t.fnContext = e.fnContext, t.fnOptions = e.fnOptions, t.fnScopeId = e.fnScopeId, 
                t.asyncMeta = e.asyncMeta, t.isCloned = !0, t;
            }
            function L(e) {
                ai = e;
            }
            function R(e, t) {
                e.__proto__ = t;
            }
            function I(e, t, n) {
                for (var r = 0, i = n.length; r < i; r++) {
                    var o = n[r];
                    T(e, o, t[o]);
                }
            }
            function F(e, t) {
                var n;
                if (l(e) && !(e instanceof ei)) return y(e, "__ob__") && e.__ob__ instanceof si ? n = e.__ob__ : ai && !Gr() && (Array.isArray(e) || u(e)) && Object.isExtensible(e) && !e._isVue && (n = new si(e)), 
                t && n && n.vmCount++, n;
            }
            function N(e, t, n, r, i) {
                var o = new Zr(), a = Object.getOwnPropertyDescriptor(e, t);
                if (!a || !1 !== a.configurable) {
                    var s = a && a.get, c = a && a.set;
                    s && !c || 2 !== arguments.length || (n = e[t]);
                    var l = !i && F(n);
                    Object.defineProperty(e, t, {
                        enumerable: !0,
                        configurable: !0,
                        get: function() {
                            var t = s ? s.call(e) : n;
                            return Zr.SharedObject.target && (o.depend(), l && (l.dep.depend(), Array.isArray(t) && U(t))), 
                            t;
                        },
                        set: function(t) {
                            var r = s ? s.call(e) : n;
                            t === r || t !== t && r !== r || s && !c || (c ? c.call(e, t) : n = t, l = !i && F(t), 
                            o.notify());
                        }
                    });
                }
            }
            function z(e, t, n) {
                if (Array.isArray(e) && d(t)) return e.length = Math.max(e.length, t), e.splice(t, 1, n), 
                n;
                if (t in e && !(t in Object.prototype)) return e[t] = n, n;
                var r = e.__ob__;
                return e._isVue || r && r.vmCount ? n : r ? (N(r.value, t, n), r.dep.notify(), n) : (e[t] = n, 
                n);
            }
            function B(e, t) {
                if (Array.isArray(e) && d(t)) e.splice(t, 1); else {
                    var n = e.__ob__;
                    e._isVue || n && n.vmCount || y(e, t) && (delete e[t], n && n.dep.notify());
                }
            }
            function U(e) {
                for (var t = void 0, n = 0, r = e.length; n < r; n++) (t = e[n]) && t.__ob__ && t.__ob__.dep.depend(), 
                Array.isArray(t) && U(t);
            }
            function W(e, t) {
                if (!t) return e;
                for (var n, r, i, o = Jr ? Reflect.ownKeys(t) : Object.keys(t), a = 0; a < o.length; a++) "__ob__" !== (n = o[a]) && (r = e[n], 
                i = t[n], y(e, n) ? r !== i && u(r) && u(i) && W(r, i) : z(e, n, i));
                return e;
            }
            function H(e, t, n) {
                return n ? function() {
                    var r = "function" == typeof t ? t.call(n, n) : t, i = "function" == typeof e ? e.call(n, n) : e;
                    return r ? W(r, i) : i;
                } : t ? e ? function() {
                    return W("function" == typeof t ? t.call(this, this) : t, "function" == typeof e ? e.call(this, this) : e);
                } : t : e;
            }
            function q(e, t) {
                var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                return n ? V(n) : n;
            }
            function V(e) {
                for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                return t;
            }
            function X(e, t, n, r) {
                var i = Object.create(e || null);
                return t ? x(i, t) : i;
            }
            function G(e, t) {
                var n = e.props;
                if (n) {
                    var r, i, o, a = {};
                    if (Array.isArray(n)) for (r = n.length; r--; ) "string" == typeof (i = n[r]) && (o = xr(i), 
                    a[o] = {
                        type: null
                    }); else if (u(n)) for (var s in n) i = n[s], a[o = xr(s)] = u(i) ? i : {
                        type: i
                    };
                    e.props = a;
                }
            }
            function Y(e, t) {
                var n = e.inject;
                if (n) {
                    var r = e.inject = {};
                    if (Array.isArray(n)) for (var i = 0; i < n.length; i++) r[n[i]] = {
                        from: n[i]
                    }; else if (u(n)) for (var o in n) {
                        var a = n[o];
                        r[o] = u(a) ? x({
                            from: o
                        }, a) : {
                            from: a
                        };
                    }
                }
            }
            function J(e) {
                var t = e.directives;
                if (t) for (var n in t) {
                    var r = t[n];
                    "function" == typeof r && (t[n] = {
                        bind: r,
                        update: r
                    });
                }
            }
            function K(e, t, n) {
                function r(r) {
                    var i = ci[r] || ui;
                    s[r] = i(e[r], t[r], n, r);
                }
                if ("function" == typeof t && (t = t.options), G(t, n), Y(t, n), J(t), !t._base && (t.extends && (e = K(e, t.extends, n)), 
                t.mixins)) for (var i = 0, o = t.mixins.length; i < o; i++) e = K(e, t.mixins[i], n);
                var a, s = {};
                for (a in e) r(a);
                for (a in t) y(e, a) || r(a);
                return s;
            }
            function Q(e, t, n, r) {
                if ("string" == typeof n) {
                    var i = e[t];
                    if (y(i, n)) return i[n];
                    var o = xr(n);
                    if (y(i, o)) return i[o];
                    var a = wr(o);
                    return y(i, a) ? i[a] : i[n] || i[o] || i[a];
                }
            }
            function Z(e, t, n, r) {
                var i = t[e], o = !y(n, e), a = n[e], s = re(Boolean, i.type);
                if (s > -1) if (o && !y(i, "default")) a = !1; else if ("" === a || a === Sr(e)) {
                    var c = re(String, i.type);
                    (c < 0 || s < c) && (a = !0);
                }
                if (void 0 === a) {
                    a = ee(r, i, e);
                    var l = ai;
                    L(!0), F(a), L(l);
                }
                return a;
            }
            function ee(e, t, n) {
                if (y(t, "default")) {
                    var r = t.default;
                    return e && e.$options.propsData && void 0 === e.$options.propsData[n] && void 0 !== e._props[n] ? e._props[n] : "function" == typeof r && "Function" !== te(t.type) ? r.call(e) : r;
                }
            }
            function te(e) {
                var t = e && e.toString().match(/^\s*function (\w+)/);
                return t ? t[1] : "";
            }
            function ne(e, t) {
                return te(e) === te(t);
            }
            function re(e, t) {
                if (!Array.isArray(t)) return ne(t, e) ? 0 : -1;
                for (var n = 0, r = t.length; n < r; n++) if (ne(t[n], e)) return n;
                return -1;
            }
            function ie(e, t, n) {
                j();
                try {
                    if (t) for (var r = t; r = r.$parent; ) {
                        var i = r.$options.errorCaptured;
                        if (i) for (var o = 0; o < i.length; o++) try {
                            if (!1 === i[o].call(r, e, t, n)) return;
                        } catch (e) {
                            ae(e, r, "errorCaptured hook");
                        }
                    }
                    ae(e, t, n);
                } finally {
                    $();
                }
            }
            function oe(e, t, n, r, i) {
                var o;
                try {
                    (o = n ? e.apply(t, n) : e.call(t)) && !o._isVue && f(o) && !o._handled && (o.catch(function(e) {
                        return ie(e, r, i + " (Promise/async)");
                    }), o._handled = !0);
                } catch (e) {
                    ie(e, r, i);
                }
                return o;
            }
            function ae(e, t, n) {
                if (jr.errorHandler) try {
                    return jr.errorHandler.call(null, e, t, n);
                } catch (t) {
                    t !== e && se(t, null, "config.errorHandler");
                }
                se(e, t, n);
            }
            function se(e, t, n) {
                if (!Lr && !Rr || "undefined" == typeof console) throw e;
                console.error(e);
            }
            function ce() {
                fi = !1;
                var e = di.slice(0);
                di.length = 0;
                for (var t = 0; t < e.length; t++) e[t]();
            }
            function le(e, t) {
                var n;
                if (di.push(function() {
                    if (e) try {
                        e.call(t);
                    } catch (e) {
                        ie(e, t, "nextTick");
                    } else n && n(t);
                }), fi || (fi = !0, li()), !e && "undefined" != typeof Promise) return new Promise(function(e) {
                    n = e;
                });
            }
            function ue(e) {
                pe(e, yi), yi.clear();
            }
            function pe(e, t) {
                var n, r, i = Array.isArray(e);
                if (!(!i && !l(e) || Object.isFrozen(e) || e instanceof ei)) {
                    if (e.__ob__) {
                        var o = e.__ob__.dep.id;
                        if (t.has(o)) return;
                        t.add(o);
                    }
                    if (i) for (n = e.length; n--; ) pe(e[n], t); else for (n = (r = Object.keys(e)).length; n--; ) pe(e[r[n]], t);
                }
            }
            function de(e, t) {
                function n() {
                    var e = arguments, r = n.fns;
                    if (!Array.isArray(r)) return oe(r, null, arguments, t, "v-on handler");
                    for (var i = r.slice(), o = 0; o < i.length; o++) oe(i[o], null, e, t, "v-on handler");
                }
                return n.fns = e, n;
            }
            function fe(e, t, n, r, o, s) {
                var c, l, u, p;
                for (c in e) l = e[c], u = t[c], p = _i(c), i(l) || (i(u) ? (i(l.fns) && (l = e[c] = de(l, s)), 
                a(p.once) && (l = e[c] = o(p.name, l, p.capture)), n(p.name, l, p.capture, p.passive, p.params)) : l !== u && (u.fns = l, 
                e[c] = u));
                for (c in t) i(e[c]) && (p = _i(c), r(p.name, t[c], p.capture));
            }
            function he(e, t, n) {
                function r() {
                    n.apply(this, arguments), m(s.fns, r);
                }
                var s;
                e instanceof ei && (e = e.data.hook || (e.data.hook = {}));
                var c = e[t];
                i(c) ? s = de([ r ]) : o(c.fns) && a(c.merged) ? (s = c).fns.push(r) : s = de([ c, r ]), 
                s.merged = !0, e[t] = s;
            }
            function ge(e, t, n, r) {
                var a = t.options.mpOptions && t.options.mpOptions.properties;
                if (i(a)) return n;
                var s = t.options.mpOptions.externalClasses || [], c = e.attrs, l = e.props;
                if (o(c) || o(l)) for (var u in a) {
                    var p = Sr(u);
                    (me(n, l, u, p, !0) || me(n, c, u, p, !1)) && n[u] && -1 !== s.indexOf(p) && r[xr(n[u])] && (n[u] = r[xr(n[u])]);
                }
                return n;
            }
            function ve(e, t, n, r) {
                var a = t.options.props;
                if (i(a)) return ge(e, t, {}, r);
                var s = {}, c = e.attrs, l = e.props;
                if (o(c) || o(l)) for (var u in a) {
                    var p = Sr(u);
                    me(s, l, u, p, !0) || me(s, c, u, p, !1);
                }
                return ge(e, t, s, r);
            }
            function me(e, t, n, r, i) {
                if (o(t)) {
                    if (y(t, n)) return e[n] = t[n], i || delete t[n], !0;
                    if (y(t, r)) return e[n] = t[r], i || delete t[r], !0;
                }
                return !1;
            }
            function ye(e) {
                for (var t = 0; t < e.length; t++) if (Array.isArray(e[t])) return Array.prototype.concat.apply([], e);
                return e;
            }
            function _e(e) {
                return c(e) ? [ E(e) ] : Array.isArray(e) ? xe(e) : void 0;
            }
            function be(e) {
                return o(e) && o(e.text) && s(e.isComment);
            }
            function xe(e, t) {
                var n, r, s, l, u = [];
                for (n = 0; n < e.length; n++) i(r = e[n]) || "boolean" == typeof r || (s = u.length - 1, 
                l = u[s], Array.isArray(r) ? r.length > 0 && (r = xe(r, (t || "") + "_" + n), be(r[0]) && be(l) && (u[s] = E(l.text + r[0].text), 
                r.shift()), u.push.apply(u, r)) : c(r) ? be(l) ? u[s] = E(l.text + r) : "" !== r && u.push(E(r)) : be(r) && be(l) ? u[s] = E(l.text + r.text) : (a(e._isVList) && o(r.tag) && i(r.key) && o(t) && (r.key = "__vlist" + t + "_" + n + "__"), 
                u.push(r)));
                return u;
            }
            function we(e) {
                var t = e.$options.provide;
                t && (e._provided = "function" == typeof t ? t.call(e) : t);
            }
            function Ae(e) {
                var t = Se(e.$options.inject, e);
                t && (L(!1), Object.keys(t).forEach(function(n) {
                    N(e, n, t[n]);
                }), L(!0));
            }
            function Se(e, t) {
                if (e) {
                    for (var n = Object.create(null), r = Jr ? Reflect.ownKeys(e) : Object.keys(e), i = 0; i < r.length; i++) {
                        var o = r[i];
                        if ("__ob__" !== o) {
                            for (var a = e[o].from, s = t; s; ) {
                                if (s._provided && y(s._provided, a)) {
                                    n[o] = s._provided[a];
                                    break;
                                }
                                s = s.$parent;
                            }
                            if (!s && "default" in e[o]) {
                                var c = e[o].default;
                                n[o] = "function" == typeof c ? c.call(t) : c;
                            }
                        }
                    }
                    return n;
                }
            }
            function ke(e, t) {
                if (!e || !e.length) return {};
                for (var n = {}, r = 0, i = e.length; r < i; r++) {
                    var o = e[r], a = o.data;
                    if (a && a.attrs && a.attrs.slot && delete a.attrs.slot, o.context !== t && o.fnContext !== t || !a || null == a.slot) o.asyncMeta && o.asyncMeta.data && "page" === o.asyncMeta.data.slot ? (n.page || (n.page = [])).push(o) : (n.default || (n.default = [])).push(o); else {
                        var s = a.slot, c = n[s] || (n[s] = []);
                        "template" === o.tag ? c.push.apply(c, o.children || []) : c.push(o);
                    }
                }
                for (var l in n) n[l].every(Pe) && delete n[l];
                return n;
            }
            function Pe(e) {
                return e.isComment && !e.asyncFactory || " " === e.text;
            }
            function Oe(e, t, n) {
                var r, i = Object.keys(t).length > 0, o = e ? !!e.$stable : !i, a = e && e.$key;
                if (e) {
                    if (e._normalized) return e._normalized;
                    if (o && n && n !== gr && a === n.$key && !i && !n.$hasNormal) return n;
                    for (var s in r = {}, e) e[s] && "$" !== s[0] && (r[s] = Te(t, s, e[s]));
                } else r = {};
                for (var c in t) c in r || (r[c] = Ce(t, c));
                return e && Object.isExtensible(e) && (e._normalized = r), T(r, "$stable", o), T(r, "$key", a), 
                T(r, "$hasNormal", i), r;
            }
            function Te(t, n, r) {
                var i = function() {
                    var t = arguments.length ? r.apply(null, arguments) : r({});
                    return (t = t && "object" === (void 0 === t ? "undefined" : e(t)) && !Array.isArray(t) ? [ t ] : _e(t)) && (0 === t.length || 1 === t.length && t[0].isComment) ? void 0 : t;
                };
                return r.proxy && Object.defineProperty(t, n, {
                    get: i,
                    enumerable: !0,
                    configurable: !0
                }), i;
            }
            function Ce(e, t) {
                return function() {
                    return e[t];
                };
            }
            function De(e, t) {
                var n, r, i, a, s;
                if (Array.isArray(e) || "string" == typeof e) for (n = new Array(e.length), r = 0, 
                i = e.length; r < i; r++) n[r] = t(e[r], r, r, r); else if ("number" == typeof e) for (n = new Array(e), 
                r = 0; r < e; r++) n[r] = t(r + 1, r, r, r); else if (l(e)) if (Jr && e[Symbol.iterator]) {
                    n = [];
                    for (var c = e[Symbol.iterator](), u = c.next(); !u.done; ) n.push(t(u.value, n.length, r, r++)), 
                    u = c.next();
                } else for (a = Object.keys(e), n = new Array(a.length), r = 0, i = a.length; r < i; r++) s = a[r], 
                n[r] = t(e[s], s, r, r);
                return o(n) || (n = []), n._isVList = !0, n;
            }
            function je(e, t, n, r) {
                var i, o = this.$scopedSlots[e];
                o ? (n = n || {}, r && (n = x(x({}, r), n)), i = o(n, this, n._i) || t) : i = this.$slots[e] || t;
                var a = n && n.slot;
                return a ? this.$createElement("template", {
                    slot: a
                }, i) : i;
            }
            function $e(e) {
                return Q(this.$options, "filters", e, !0) || Or;
            }
            function Ee(e, t) {
                return Array.isArray(e) ? -1 === e.indexOf(t) : e !== t;
            }
            function Me(e, t, n, r, i) {
                var o = jr.keyCodes[t] || n;
                return i && r && !jr.keyCodes[t] ? Ee(i, r) : o ? Ee(o, e) : r ? Sr(r) !== t : void 0;
            }
            function Le(e, t, n, r, i) {
                if (n && l(n)) {
                    var o;
                    Array.isArray(n) && (n = w(n));
                    for (var a in n) !function(a) {
                        if ("class" === a || "style" === a || yr(a)) o = e; else {
                            var s = e.attrs && e.attrs.type;
                            o = r || jr.mustUseProp(t, s, a) ? e.domProps || (e.domProps = {}) : e.attrs || (e.attrs = {});
                        }
                        var c = xr(a), l = Sr(a);
                        c in o || l in o || (o[a] = n[a], !i) || ((e.on || (e.on = {}))["update:" + a] = function(e) {
                            n[a] = e;
                        });
                    }(a);
                }
                return e;
            }
            function Re(e, t) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[e];
                return r && !t || (r = n[e] = this.$options.staticRenderFns[e].call(this._renderProxy, null, this), 
                Fe(r, "__static__" + e, !1)), r;
            }
            function Ie(e, t, n) {
                return Fe(e, "__once__" + t + (n ? "_" + n : ""), !0), e;
            }
            function Fe(e, t, n) {
                if (Array.isArray(e)) for (var r = 0; r < e.length; r++) e[r] && "string" != typeof e[r] && Ne(e[r], t + "_" + r, n); else Ne(e, t, n);
            }
            function Ne(e, t, n) {
                e.isStatic = !0, e.key = t, e.isOnce = n;
            }
            function ze(e, t) {
                if (t && u(t)) {
                    var n = e.on = e.on ? x({}, e.on) : {};
                    for (var r in t) {
                        var i = n[r], o = t[r];
                        n[r] = i ? [].concat(i, o) : o;
                    }
                }
                return e;
            }
            function Be(e, t, n, r) {
                t = t || {
                    $stable: !n
                };
                for (var i = 0; i < e.length; i++) {
                    var o = e[i];
                    Array.isArray(o) ? Be(o, t, n) : o && (o.proxy && (o.fn.proxy = !0), t[o.key] = o.fn);
                }
                return r && (t.$key = r), t;
            }
            function Ue(e, t) {
                for (var n = 0; n < t.length; n += 2) {
                    var r = t[n];
                    "string" == typeof r && r && (e[t[n]] = t[n + 1]);
                }
                return e;
            }
            function We(e, t) {
                return "string" == typeof e ? t + e : e;
            }
            function He(e) {
                e._o = Ie, e._n = g, e._s = h, e._l = De, e._t = je, e._q = S, e._i = k, e._m = Re, 
                e._f = $e, e._k = Me, e._b = Le, e._v = E, e._e = ni, e._u = Be, e._g = ze, e._d = Ue, 
                e._p = We;
            }
            function qe(e, t, n, r, i) {
                var o, s = this, c = i.options;
                y(r, "_uid") ? (o = Object.create(r), o._original = r) : (o = r, r = r._original);
                var l = a(c._compiled), u = !l;
                this.data = e, this.props = t, this.children = n, this.parent = r, this.listeners = e.on || gr, 
                this.injections = Se(c.inject, r), this.slots = function() {
                    return s.$slots || Oe(e.scopedSlots, s.$slots = ke(n, r)), s.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return Oe(e.scopedSlots, this.slots());
                    }
                }), l && (this.$options = c, this.$slots = this.slots(), this.$scopedSlots = Oe(e.scopedSlots, this.$slots)), 
                c._scopeId ? this._c = function(e, t, n, i) {
                    var a = et(o, e, t, n, i, u);
                    return a && !Array.isArray(a) && (a.fnScopeId = c._scopeId, a.fnContext = r), a;
                } : this._c = function(e, t, n, r) {
                    return et(o, e, t, n, r, u);
                };
            }
            function Ve(e, t, n, r, i) {
                var a = e.options, s = {}, c = a.props;
                if (o(c)) for (var l in c) s[l] = Z(l, c, t || gr); else o(n.attrs) && Ge(s, n.attrs), 
                o(n.props) && Ge(s, n.props);
                var u = new qe(n, s, i, r, e), p = a.render.call(null, u._c, u);
                if (p instanceof ei) return Xe(p, n, u.parent, a, u);
                if (Array.isArray(p)) {
                    for (var d = _e(p) || [], f = new Array(d.length), h = 0; h < d.length; h++) f[h] = Xe(d[h], n, u.parent, a, u);
                    return f;
                }
            }
            function Xe(e, t, n, r, i) {
                var o = M(e);
                return o.fnContext = n, o.fnOptions = r, t.slot && ((o.data || (o.data = {})).slot = t.slot), 
                o;
            }
            function Ge(e, t) {
                for (var n in t) e[xr(n)] = t[n];
            }
            function Ye(e, t, n, r, s) {
                if (!i(e)) {
                    var c = n.$options._base;
                    if (l(e) && (e = c.extend(e)), "function" == typeof e) {
                        var u;
                        if (i(e.cid) && (u = e, void 0 === (e = st(u, c)))) return at(u, t, n, r, s);
                        t = t || {}, Ut(e), o(t.model) && Ze(e.options, t);
                        var p = ve(t, e, s, n);
                        if (a(e.options.functional)) return Ve(e, p, t, n, r);
                        var d = t.on;
                        if (t.on = t.nativeOn, a(e.options.abstract)) {
                            var f = t.slot;
                            t = {}, f && (t.slot = f);
                        }
                        Ke(t);
                        var h = e.options.name || s;
                        return new ei("vue-component-" + e.cid + (h ? "-" + h : ""), t, void 0, void 0, void 0, n, {
                            Ctor: e,
                            propsData: p,
                            listeners: d,
                            tag: s,
                            children: r
                        }, u);
                    }
                }
            }
            function Je(e, t) {
                var n = {
                    _isComponent: !0,
                    _parentVnode: e,
                    parent: t
                }, r = e.data.inlineTemplate;
                return o(r) && (n.render = r.render, n.staticRenderFns = r.staticRenderFns), new e.componentOptions.Ctor(n);
            }
            function Ke(e) {
                for (var t = e.hook || (e.hook = {}), n = 0; n < wi.length; n++) {
                    var r = wi[n], i = t[r], o = xi[r];
                    i === o || i && i._merged || (t[r] = i ? Qe(o, i) : o);
                }
            }
            function Qe(e, t) {
                var n = function(n, r) {
                    e(n, r), t(n, r);
                };
                return n._merged = !0, n;
            }
            function Ze(e, t) {
                var n = e.model && e.model.prop || "value", r = e.model && e.model.event || "input";
                (t.attrs || (t.attrs = {}))[n] = t.model.value;
                var i = t.on || (t.on = {}), a = i[r], s = t.model.callback;
                o(a) ? (Array.isArray(a) ? -1 === a.indexOf(s) : a !== s) && (i[r] = [ s ].concat(a)) : i[r] = s;
            }
            function et(e, t, n, r, i, o) {
                return (Array.isArray(n) || c(n)) && (i = r, r = n, n = void 0), a(o) && (i = Si), 
                tt(e, t, n, r, i);
            }
            function tt(e, t, n, r, i) {
                if (o(n) && o(n.__ob__)) return ni();
                if (o(n) && o(n.is) && (t = n.is), !t) return ni();
                var a, s, c;
                return Array.isArray(r) && "function" == typeof r[0] && (n = n || {}, n.scopedSlots = {
                    default: r[0]
                }, r.length = 0), i === Si ? r = _e(r) : i === Ai && (r = ye(r)), "string" == typeof t ? (s = e.$vnode && e.$vnode.ns || jr.getTagNamespace(t), 
                a = jr.isReservedTag(t) ? new ei(jr.parsePlatformTagName(t), n, r, void 0, void 0, e) : n && n.pre || !o(c = Q(e.$options, "components", t)) ? new ei(t, n, r, void 0, void 0, e) : Ye(c, n, e, r, t)) : a = Ye(t, n, e, r), 
                Array.isArray(a) ? a : o(a) ? (o(s) && nt(a, s), o(n) && rt(n), a) : ni();
            }
            function nt(e, t, n) {
                if (e.ns = t, "foreignObject" === e.tag && (t = void 0, n = !0), o(e.children)) for (var r = 0, s = e.children.length; r < s; r++) {
                    var c = e.children[r];
                    o(c.tag) && (i(c.ns) || a(n) && "svg" !== c.tag) && nt(c, t, n);
                }
            }
            function rt(e) {
                l(e.style) && ue(e.style), l(e.class) && ue(e.class);
            }
            function it(e) {
                e._vnode = null, e._staticTrees = null;
                var t = e.$options, n = e.$vnode = t._parentVnode, r = n && n.context;
                e.$slots = ke(t._renderChildren, r), e.$scopedSlots = gr, e._c = function(t, n, r, i) {
                    return et(e, t, n, r, i, !1);
                }, e.$createElement = function(t, n, r, i) {
                    return et(e, t, n, r, i, !0);
                };
                var i = n && n.data;
                N(e, "$attrs", i && i.attrs || gr, null, !0), N(e, "$listeners", t._parentListeners || gr, null, !0);
            }
            function ot(e, t) {
                return (e.__esModule || Jr && "Module" === e[Symbol.toStringTag]) && (e = e.default), 
                l(e) ? t.extend(e) : e;
            }
            function at(e, t, n, r, i) {
                var o = ni();
                return o.asyncFactory = e, o.asyncMeta = {
                    data: t,
                    context: n,
                    children: r,
                    tag: i
                }, o;
            }
            function st(e, t) {
                if (a(e.error) && o(e.errorComp)) return e.errorComp;
                if (o(e.resolved)) return e.resolved;
                var n = ki;
                if (n && o(e.owners) && -1 === e.owners.indexOf(n) && e.owners.push(n), a(e.loading) && o(e.loadingComp)) return e.loadingComp;
                if (n && !o(e.owners)) {
                    var r = e.owners = [ n ], s = !0, c = null, u = null;
                    n.$on("hook:destroyed", function() {
                        return m(r, n);
                    });
                    var p = function(e) {
                        for (var t = 0, n = r.length; t < n; t++) r[t].$forceUpdate();
                        e && (r.length = 0, null !== c && (clearTimeout(c), c = null), null !== u && (clearTimeout(u), 
                        u = null));
                    }, d = P(function(n) {
                        e.resolved = ot(n, t), s ? r.length = 0 : p(!0);
                    }), h = P(function(t) {
                        o(e.errorComp) && (e.error = !0, p(!0));
                    }), g = e(d, h);
                    return l(g) && (f(g) ? i(e.resolved) && g.then(d, h) : f(g.component) && (g.component.then(d, h), 
                    o(g.error) && (e.errorComp = ot(g.error, t)), o(g.loading) && (e.loadingComp = ot(g.loading, t), 
                    0 === g.delay ? e.loading = !0 : c = setTimeout(function() {
                        c = null, i(e.resolved) && i(e.error) && (e.loading = !0, p(!1));
                    }, g.delay || 200)), o(g.timeout) && (u = setTimeout(function() {
                        u = null, i(e.resolved) && h(null);
                    }, g.timeout)))), s = !1, e.loading ? e.loadingComp : e.resolved;
                }
            }
            function ct(e) {
                return e.isComment && e.asyncFactory;
            }
            function lt(e) {
                if (Array.isArray(e)) for (var t = 0; t < e.length; t++) {
                    var n = e[t];
                    if (o(n) && (o(n.componentOptions) || ct(n))) return n;
                }
            }
            function ut(e) {
                e._events = Object.create(null), e._hasHookEvent = !1;
                var t = e.$options._parentListeners;
                t && ht(e, t);
            }
            function pt(e, t) {
                bi.$on(e, t);
            }
            function dt(e, t) {
                bi.$off(e, t);
            }
            function ft(e, t) {
                var n = bi;
                return function r() {
                    null !== t.apply(null, arguments) && n.$off(e, r);
                };
            }
            function ht(e, t, n) {
                bi = e, fe(t, n || {}, pt, dt, ft, e), bi = void 0;
            }
            function gt(e) {
                var t = Pi;
                return Pi = e, function() {
                    Pi = t;
                };
            }
            function vt(e) {
                var t = e.$options, n = t.parent;
                if (n && !t.abstract) {
                    for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                    n.$children.push(e);
                }
                e.$parent = n, e.$root = n ? n.$root : e, e.$children = [], e.$refs = {}, e._watcher = null, 
                e._inactive = null, e._directInactive = !1, e._isMounted = !1, e._isDestroyed = !1, 
                e._isBeingDestroyed = !1;
            }
            function mt(e, t, n) {
                var r;
                return e.$el = t, e.$options.render || (e.$options.render = ni), wt(e, "beforeMount"), 
                r = function() {
                    e._update(e._render(), n);
                }, new Ii(e, r, A, {
                    before: function() {
                        e._isMounted && !e._isDestroyed && wt(e, "beforeUpdate");
                    }
                }, !0), n = !1, null == e.$vnode && (wt(e, "onServiceCreated"), wt(e, "onServiceAttached"), 
                e._isMounted = !0, wt(e, "mounted")), e;
            }
            function yt(e, t, n, r, i) {
                var o = r.data.scopedSlots, a = e.$scopedSlots, s = !!(o && !o.$stable || a !== gr && !a.$stable || o && e.$scopedSlots.$key !== o.$key), c = !!(i || e.$options._renderChildren || s);
                if (e.$options._parentVnode = r, e.$vnode = r, e._vnode && (e._vnode.parent = r), 
                e.$options._renderChildren = i, e.$attrs = r.data.attrs || gr, e.$listeners = n || gr, 
                t && e.$options.props) {
                    L(!1);
                    for (var l = e._props, u = e.$options._propKeys || [], p = 0; p < u.length; p++) {
                        var d = u[p], f = e.$options.props;
                        l[d] = Z(d, f, t, e);
                    }
                    L(!0), e.$options.propsData = t;
                }
                e._$updateProperties && e._$updateProperties(e), n = n || gr;
                var h = e.$options._parentListeners;
                e.$options._parentListeners = n, ht(e, n, h), c && (e.$slots = ke(i, r.context), 
                e.$forceUpdate());
            }
            function _t(e) {
                for (;e && (e = e.$parent); ) if (e._inactive) return !0;
                return !1;
            }
            function bt(e, t) {
                if (t) {
                    if (e._directInactive = !1, _t(e)) return;
                } else if (e._directInactive) return;
                if (e._inactive || null === e._inactive) {
                    e._inactive = !1;
                    for (var n = 0; n < e.$children.length; n++) bt(e.$children[n]);
                    wt(e, "activated");
                }
            }
            function xt(e, t) {
                if (!(t && (e._directInactive = !0, _t(e)) || e._inactive)) {
                    e._inactive = !0;
                    for (var n = 0; n < e.$children.length; n++) xt(e.$children[n]);
                    wt(e, "deactivated");
                }
            }
            function wt(e, t) {
                j();
                var n = e.$options[t], r = t + " hook";
                if (n) for (var i = 0, o = n.length; i < o; i++) oe(n[i], e, null, e, r);
                e._hasHookEvent && e.$emit("hook:" + t), $();
            }
            function At() {
                $i = Oi.length = Ti.length = 0, Ci = {}, Di = ji = !1;
            }
            function St() {
                var e, t;
                for (Ei = Mi(), ji = !0, Oi.sort(function(e, t) {
                    return e.id - t.id;
                }), $i = 0; $i < Oi.length; $i++) (e = Oi[$i]).before && e.before(), t = e.id, Ci[t] = null, 
                e.run();
                var n = Ti.slice(), r = Oi.slice();
                At(), Ot(n), kt(r), Yr && jr.devtools && Yr.emit("flush");
            }
            function kt(e) {
                for (var t = e.length; t--; ) {
                    var n = e[t], r = n.vm;
                    r._watcher === n && r._isMounted && !r._isDestroyed && wt(r, "updated");
                }
            }
            function Pt(e) {
                e._inactive = !1, Ti.push(e);
            }
            function Ot(e) {
                for (var t = 0; t < e.length; t++) e[t]._inactive = !0, bt(e[t], !0);
            }
            function Tt(e) {
                var t = e.id;
                if (null == Ci[t]) {
                    if (Ci[t] = !0, ji) {
                        for (var n = Oi.length - 1; n > $i && Oi[n].id > e.id; ) n--;
                        Oi.splice(n + 1, 0, e);
                    } else Oi.push(e);
                    Di || (Di = !0, le(St));
                }
            }
            function Ct(e, t, n) {
                Fi.get = function() {
                    return this[t][n];
                }, Fi.set = function(e) {
                    this[t][n] = e;
                }, Object.defineProperty(e, n, Fi);
            }
            function Dt(e) {
                e._watchers = [];
                var t = e.$options;
                t.props && jt(e, t.props), t.methods && Ft(e, t.methods), t.data ? $t(e) : F(e._data = {}, !0), 
                t.computed && Mt(e, t.computed), t.watch && t.watch !== Hr && Nt(e, t.watch);
            }
            function jt(e, t) {
                var n = e.$options.propsData || {}, r = e._props = {}, i = e.$options._propKeys = [];
                !e.$parent || L(!1);
                for (var o in t) !function(o) {
                    i.push(o);
                    var a = Z(o, t, n, e);
                    N(r, o, a), o in e || Ct(e, "_props", o);
                }(o);
                L(!0);
            }
            function $t(e) {
                var t = e.$options.data;
                u(t = e._data = "function" == typeof t ? Et(t, e) : t || {}) || (t = {});
                for (var n = Object.keys(t), r = e.$options.props, i = (e.$options.methods, n.length); i--; ) {
                    var o = n[i];
                    r && y(r, o) || O(o) || Ct(e, "_data", o);
                }
                F(t, !0);
            }
            function Et(e, t) {
                j();
                try {
                    return e.call(t, t);
                } catch (e) {
                    return ie(e, t, "data()"), {};
                } finally {
                    $();
                }
            }
            function Mt(e, t) {
                var n = e._computedWatchers = Object.create(null), r = Gr();
                for (var i in t) {
                    var o = t[i], a = "function" == typeof o ? o : o.get;
                    r || (n[i] = new Ii(e, a || A, A, Ni)), i in e || Lt(e, i, o);
                }
            }
            function Lt(e, t, n) {
                var r = !Gr();
                "function" == typeof n ? (Fi.get = r ? Rt(t) : It(n), Fi.set = A) : (Fi.get = n.get ? r && !1 !== n.cache ? Rt(t) : It(n.get) : A, 
                Fi.set = n.set || A), Object.defineProperty(e, t, Fi);
            }
            function Rt(e) {
                return function() {
                    var t = this._computedWatchers && this._computedWatchers[e];
                    if (t) return t.dirty && t.evaluate(), Zr.SharedObject.target && t.depend(), t.value;
                };
            }
            function It(e) {
                return function() {
                    return e.call(this, this);
                };
            }
            function Ft(e, t) {
                e.$options.props;
                for (var n in t) e[n] = "function" != typeof t[n] ? A : kr(t[n], e);
            }
            function Nt(e, t) {
                for (var n in t) {
                    var r = t[n];
                    if (Array.isArray(r)) for (var i = 0; i < r.length; i++) zt(e, n, r[i]); else zt(e, n, r);
                }
            }
            function zt(e, t, n, r) {
                return u(n) && (r = n, n = n.handler), "string" == typeof n && (n = e[n]), e.$watch(t, n, r);
            }
            function Bt(e, t) {
                var n = e.$options = Object.create(e.constructor.options), r = t._parentVnode;
                n.parent = t.parent, n._parentVnode = r;
                var i = r.componentOptions;
                n.propsData = i.propsData, n._parentListeners = i.listeners, n._renderChildren = i.children, 
                n._componentTag = i.tag, t.render && (n.render = t.render, n.staticRenderFns = t.staticRenderFns);
            }
            function Ut(e) {
                var t = e.options;
                if (e.super) {
                    var n = Ut(e.super);
                    if (n !== e.superOptions) {
                        e.superOptions = n;
                        var r = Wt(e);
                        r && x(e.extendOptions, r), (t = e.options = K(n, e.extendOptions)).name && (t.components[t.name] = e);
                    }
                }
                return t;
            }
            function Wt(e) {
                var t, n = e.options, r = e.sealedOptions;
                for (var i in n) n[i] !== r[i] && (t || (t = {}), t[i] = n[i]);
                return t;
            }
            function Ht(e) {
                this._init(e);
            }
            function qt(e) {
                e.use = function(e) {
                    var t = this._installedPlugins || (this._installedPlugins = []);
                    if (t.indexOf(e) > -1) return this;
                    var n = b(arguments, 1);
                    return n.unshift(this), "function" == typeof e.install ? e.install.apply(e, n) : "function" == typeof e && e.apply(null, n), 
                    t.push(e), this;
                };
            }
            function Vt(e) {
                e.mixin = function(e) {
                    return this.options = K(this.options, e), this;
                };
            }
            function Xt(e) {
                e.cid = 0;
                var t = 1;
                e.extend = function(e) {
                    e = e || {};
                    var n = this, r = n.cid, i = e._Ctor || (e._Ctor = {});
                    if (i[r]) return i[r];
                    var o = e.name || n.options.name, a = function(e) {
                        this._init(e);
                    };
                    return a.prototype = Object.create(n.prototype), a.prototype.constructor = a, a.cid = t++, 
                    a.options = K(n.options, e), a.super = n, a.options.props && Gt(a), a.options.computed && Yt(a), 
                    a.extend = n.extend, a.mixin = n.mixin, a.use = n.use, Cr.forEach(function(e) {
                        a[e] = n[e];
                    }), o && (a.options.components[o] = a), a.superOptions = n.options, a.extendOptions = e, 
                    a.sealedOptions = x({}, a.options), i[r] = a, a;
                };
            }
            function Gt(e) {
                var t = e.options.props;
                for (var n in t) Ct(e.prototype, "_props", n);
            }
            function Yt(e) {
                var t = e.options.computed;
                for (var n in t) Lt(e.prototype, n, t[n]);
            }
            function Jt(e) {
                Cr.forEach(function(t) {
                    e[t] = function(e, n) {
                        return n ? ("component" === t && u(n) && (n.name = n.name || e, n = this.options._base.extend(n)), 
                        "directive" === t && "function" == typeof n && (n = {
                            bind: n,
                            update: n
                        }), this.options[t + "s"][e] = n, n) : this.options[t + "s"][e];
                    };
                });
            }
            function Kt(e) {
                return e && (e.Ctor.options.name || e.tag);
            }
            function Qt(e, t) {
                return Array.isArray(e) ? e.indexOf(t) > -1 : "string" == typeof e ? e.split(",").indexOf(t) > -1 : !!p(e) && e.test(t);
            }
            function Zt(e, t) {
                var n = e.cache, r = e.keys, i = e._vnode;
                for (var o in n) {
                    var a = n[o];
                    if (a) {
                        var s = Kt(a.componentOptions);
                        s && !t(s) && en(n, o, r, i);
                    }
                }
            }
            function en(e, t, n, r) {
                var i = e[t];
                !i || r && i.tag === r.tag || i.componentInstance.$destroy(), e[t] = null, m(n, t);
            }
            function tn(e) {
                for (var t = e.data, n = e, r = e; o(r.componentInstance); ) (r = r.componentInstance._vnode) && r.data && (t = nn(r.data, t));
                for (;o(n = n.parent); ) n && n.data && (t = nn(t, n.data));
                return rn(t.staticClass, t.class);
            }
            function nn(e, t) {
                return {
                    staticClass: on(e.staticClass, t.staticClass),
                    class: o(e.class) ? [ e.class, t.class ] : t.class
                };
            }
            function rn(e, t) {
                return o(e) || o(t) ? on(e, an(t)) : "";
            }
            function on(e, t) {
                return e ? t ? e + " " + t : e : t || "";
            }
            function an(e) {
                return Array.isArray(e) ? sn(e) : l(e) ? cn(e) : "string" == typeof e ? e : "";
            }
            function sn(e) {
                for (var t, n = "", r = 0, i = e.length; r < i; r++) o(t = an(e[r])) && "" !== t && (n && (n += " "), 
                n += t);
                return n;
            }
            function cn(e) {
                var t = "";
                for (var n in e) e[n] && (t && (t += " "), t += n);
                return t;
            }
            function ln(e) {
                return "string" == typeof e ? document.querySelector(e) || document.createElement("div") : e;
            }
            function un(e, t) {
                var n = e.data.ref;
                if (o(n)) {
                    var r = e.context, i = e.componentInstance || e.elm, a = r.$refs;
                    t ? Array.isArray(a[n]) ? m(a[n], i) : a[n] === i && (a[n] = void 0) : e.data.refInFor ? Array.isArray(a[n]) ? a[n].indexOf(i) < 0 && a[n].push(i) : a[n] = [ i ] : a[n] = i;
                }
            }
            function pn(e, t) {
                return e.key === t.key && (e.tag === t.tag && e.isComment === t.isComment && o(e.data) === o(t.data) && dn(e, t) || a(e.isAsyncPlaceholder) && e.asyncFactory === t.asyncFactory && i(t.asyncFactory.error));
            }
            function dn(e, t) {
                if ("input" !== e.tag) return !0;
                var n, r = o(n = e.data) && o(n = n.attrs) && n.type, i = o(n = t.data) && o(n = n.attrs) && n.type;
                return r === i || so(r) && so(i);
            }
            function fn(e, t, n) {
                var r, i, a = {};
                for (r = t; r <= n; ++r) o(i = e[r].key) && (a[i] = r);
                return a;
            }
            function hn(e, t) {
                (e.data.directives || t.data.directives) && gn(e, t);
            }
            function gn(e, t) {
                var n, r, i, o = e === uo, a = t === uo, s = vn(e.data.directives, e.context), c = vn(t.data.directives, t.context), l = [], u = [];
                for (n in c) r = s[n], i = c[n], r ? (i.oldValue = r.value, i.oldArg = r.arg, yn(i, "update", t, e), 
                i.def && i.def.componentUpdated && u.push(i)) : (yn(i, "bind", t, e), i.def && i.def.inserted && l.push(i));
                if (l.length) {
                    var p = function() {
                        for (var n = 0; n < l.length; n++) yn(l[n], "inserted", t, e);
                    };
                    o ? he(t, "insert", p) : p();
                }
                if (u.length && he(t, "postpatch", function() {
                    for (var n = 0; n < u.length; n++) yn(u[n], "componentUpdated", t, e);
                }), !o) for (n in s) c[n] || yn(s[n], "unbind", e, e, a);
            }
            function vn(e, t) {
                var n, r, i = Object.create(null);
                if (!e) return i;
                for (n = 0; n < e.length; n++) (r = e[n]).modifiers || (r.modifiers = ho), i[mn(r)] = r, 
                r.def = Q(t.$options, "directives", r.name, !0);
                return i;
            }
            function mn(e) {
                return e.rawName || e.name + "." + Object.keys(e.modifiers || {}).join(".");
            }
            function yn(e, t, n, r, i) {
                var o = e.def && e.def[t];
                if (o) try {
                    o(n.elm, e, n, r, i);
                } catch (r) {
                    ie(r, n.context, "directive " + e.name + " " + t + " hook");
                }
            }
            function _n(e, t) {
                var n = {};
                return Object.keys(e).forEach(function(r) {
                    t[r] && (n[e[r]] = t[r], delete t[r]);
                }), n;
            }
            function bn(e, t) {
                if (!i(e.data.wxsProps) || !i(t.data.wxsProps)) {
                    var n = e.$wxsWatches, r = Object.keys(t.data.wxsProps);
                    if (n || r.length) {
                        n || (n = {});
                        var o = _n(t.data.wxsProps, t.data.attrs), a = t.context;
                        t.$wxsWatches = {}, Object.keys(o).forEach(function(e) {
                            var r = e;
                            t.context.wxsProps && (r = "wxsProps." + e), t.$wxsWatches[e] = n[e] || t.context.$watch(r, function(n, r) {
                                o[e](n, r, a.$getComponentDescriptor(a, !0), t.elm.__vue__.$getComponentDescriptor(t.elm.__vue__, !1));
                            }, {
                                deep: !0
                            });
                        }), Object.keys(n).forEach(function(e) {
                            t.$wxsWatches[e] || (n[e](), delete n[e]);
                        });
                    }
                }
            }
            function xn(e, t) {
                var n = t.componentOptions;
                if (!(o(n) && !1 === n.Ctor.options.inheritAttrs || i(e.data.attrs) && i(t.data.attrs))) {
                    var r, a, s = t.elm, c = e.data.attrs || {}, l = t.data.attrs || {};
                    for (r in o(l.__ob__) && (l = t.data.attrs = x({}, l)), l) a = l[r], c[r] !== a && wn(s, r, a);
                    for (r in (Nr || Br) && l.value !== c.value && wn(s, "value", l.value), c) i(l[r]) && (Zi(r) ? s.removeAttributeNS(Qi, eo(r)) : Gi(r) || s.removeAttribute(r));
                }
            }
            function wn(e, t, n) {
                e.tagName.indexOf("-") > -1 ? An(e, t, n) : Ki(t) ? to(n) ? e.removeAttribute(t) : (n = "allowfullscreen" === t && "EMBED" === e.tagName ? "true" : t, 
                e.setAttribute(t, n)) : Gi(t) ? e.setAttribute(t, Ji(t, n)) : Zi(t) ? to(n) ? e.removeAttributeNS(Qi, eo(t)) : e.setAttributeNS(Qi, t, n) : An(e, t, n);
            }
            function An(e, t, n) {
                if (to(n)) e.removeAttribute(t); else {
                    if (Nr && !zr && "TEXTAREA" === e.tagName && "placeholder" === t && "" !== n && !e.__ieph) {
                        e.addEventListener("input", function t(n) {
                            n.stopImmediatePropagation(), e.removeEventListener("input", t);
                        }), e.__ieph = !0;
                    }
                    e.setAttribute(t, n);
                }
            }
            function Sn(e, t) {
                var n = t.elm, r = t.data, a = e.data;
                if (!(i(r.staticClass) && i(r.class) && (i(a) || i(a.staticClass) && i(a.class)) && i(n.__wxsAddClass) && i(n.__wxsRemoveClass))) {
                    var s = tn(t), c = n._transitionClasses;
                    if (o(c) && (s = on(s, an(c))), Array.isArray(n.__wxsRemoveClass) && n.__wxsRemoveClass.length) {
                        var l = s.split(/\s+/);
                        n.__wxsRemoveClass.forEach(function(e) {
                            var t = l.findIndex(function(t) {
                                return t === e;
                            });
                            -1 !== t && l.splice(t, 1);
                        }), s = l.join(" "), n.__wxsRemoveClass.length = 0;
                    }
                    if (n.__wxsAddClass) {
                        var u = s.split(/\s+/).concat(n.__wxsAddClass.split(/\s+/)), p = Object.create(null);
                        u.forEach(function(e) {
                            e && (p[e] = 1);
                        }), s = Object.keys(p).join(" ");
                    }
                    var d = t.context, f = d.$options.mpOptions && d.$options.mpOptions.externalClasses;
                    Array.isArray(f) && f.forEach(function(e) {
                        var t = d[xr(e)];
                        t && (s = s.replace(e, t));
                    }), s !== n._prevClass && (n.setAttribute("class", s), n._prevClass = s);
                }
            }
            function kn(e) {
                if (o(e[_o])) {
                    var t = Nr ? "change" : "input";
                    e[t] = [].concat(e[_o], e[t] || []), delete e[_o];
                }
                o(e[bo]) && (e.change = [].concat(e[bo], e.change || []), delete e[bo]);
            }
            function Pn(e, t, n) {
                var r = Wi;
                return function i() {
                    null !== t.apply(null, arguments) && Tn(e, i, n, r);
                };
            }
            function On(e, t, n, r) {
                if (xo) {
                    var i = Ei, o = t;
                    t = o._wrapper = function(e) {
                        if (e.target === e.currentTarget || e.timeStamp >= i || e.timeStamp <= 0 || e.target.ownerDocument !== document) return o.apply(this, arguments);
                    };
                }
                Wi.addEventListener(e, t, qr ? {
                    capture: n,
                    passive: r
                } : n);
            }
            function Tn(e, t, n, r) {
                (r || Wi).removeEventListener(e, t._wrapper || t, n);
            }
            function Cn(e, t) {
                if (!i(e.data.on) || !i(t.data.on)) {
                    var n = t.data.on || {}, r = e.data.on || {};
                    Wi = t.elm, kn(n), fe(n, r, On, Tn, Pn, t.context), Wi = void 0;
                }
            }
            function Dn(e, t) {
                if (!i(e.data.domProps) || !i(t.data.domProps)) {
                    var n, r, a = t.elm, s = e.data.domProps || {}, c = t.data.domProps || {};
                    for (n in o(c.__ob__) && (c = t.data.domProps = x({}, c)), s) n in c || (a[n] = "");
                    for (n in c) {
                        if (r = c[n], "textContent" === n || "innerHTML" === n) {
                            if (t.children && (t.children.length = 0), r === s[n]) continue;
                            1 === a.childNodes.length && a.removeChild(a.childNodes[0]);
                        }
                        if ("value" === n && "PROGRESS" !== a.tagName) {
                            a._value = r;
                            var l = i(r) ? "" : String(r);
                            jn(a, l) && (a.value = l);
                        } else if ("innerHTML" === n && io(a.tagName) && i(a.innerHTML)) {
                            (Hi = Hi || document.createElement("div")).innerHTML = "<svg>" + r + "</svg>";
                            for (var u = Hi.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
                            for (;u.firstChild; ) a.appendChild(u.firstChild);
                        } else if (r !== s[n]) try {
                            a[n] = r;
                        } catch (e) {}
                    }
                }
            }
            function jn(e, t) {
                return !e.composing && ("OPTION" === e.tagName || $n(e, t) || En(e, t));
            }
            function $n(e, t) {
                var n = !0;
                try {
                    n = document.activeElement !== e;
                } catch (e) {}
                return n && e.value !== t;
            }
            function En(e, t) {
                var n = e.value, r = e._vModifiers;
                if (o(r)) {
                    if (r.number) return g(n) !== g(t);
                    if (r.trim) return n.trim() !== t.trim();
                }
                return n !== t;
            }
            function Mn(e) {
                var t = Ln(e.style);
                return e.staticStyle ? x(e.staticStyle, t) : t;
            }
            function Ln(e) {
                return Array.isArray(e) ? w(e) : "string" == typeof e ? So(e) : e;
            }
            function Rn(e, t) {
                var n, r = {};
                if (t) for (var i = e; i.componentInstance; ) (i = i.componentInstance._vnode) && i.data && (n = Mn(i.data)) && x(r, n);
                (n = Mn(e.data)) && x(r, n);
                for (var o = e; o = o.parent; ) o.data && (n = Mn(o.data)) && x(r, n);
                return r;
            }
            function In(e, t) {
                var n = t.data, r = e.data, a = t.elm;
                if (!(i(n.staticStyle) && i(n.style) && i(r.staticStyle) && i(r.style) && i(a.__wxsStyle))) {
                    var s, c, l = r.staticStyle, u = r.normalizedStyle || r.style || {}, p = l || u, d = Ln(t.data.style) || {};
                    t.data.normalizedStyle = o(d.__ob__) ? x({}, d) : d;
                    var f = Rn(t, !0);
                    for (c in a.__wxsStyle && (Object.assign(t.data.normalizedStyle, a.__wxsStyle), 
                    Object.assign(f, a.__wxsStyle)), p) i(f[c]) && $o(a, c, "");
                    for (c in f) (s = f[c]) !== p[c] && $o(a, c, null == s ? "" : s, t.context);
                }
            }
            function Fn(e, t) {
                if (t && (t = t.trim())) if (e.classList) t.indexOf(" ") > -1 ? t.split(Ro).forEach(function(t) {
                    return e.classList.add(t);
                }) : e.classList.add(t); else {
                    var n = " " + (e.getAttribute("class") || "") + " ";
                    n.indexOf(" " + t + " ") < 0 && e.setAttribute("class", (n + t).trim());
                }
            }
            function Nn(e, t) {
                if (t && (t = t.trim())) if (e.classList) t.indexOf(" ") > -1 ? t.split(Ro).forEach(function(t) {
                    return e.classList.remove(t);
                }) : e.classList.remove(t), e.classList.length || e.removeAttribute("class"); else {
                    for (var n = " " + (e.getAttribute("class") || "") + " ", r = " " + t + " "; n.indexOf(r) >= 0; ) n = n.replace(r, " ");
                    (n = n.trim()) ? e.setAttribute("class", n) : e.removeAttribute("class");
                }
            }
            function zn(t) {
                if (t) {
                    if ("object" === (void 0 === t ? "undefined" : e(t))) {
                        var n = {};
                        return !1 !== t.css && x(n, Io(t.name || "v")), x(n, t), n;
                    }
                    return "string" == typeof t ? Io(t) : void 0;
                }
            }
            function Bn(e) {
                qo(function() {
                    qo(e);
                });
            }
            function Un(e, t) {
                var n = e._transitionClasses || (e._transitionClasses = []);
                n.indexOf(t) < 0 && (n.push(t), Fn(e, t));
            }
            function Wn(e, t) {
                e._transitionClasses && m(e._transitionClasses, t), Nn(e, t);
            }
            function Hn(e, t, n) {
                var r = qn(e, t), i = r.type, o = r.timeout, a = r.propCount;
                if (!i) return n();
                var s = i === No ? Uo : Ho, c = 0, l = function() {
                    e.removeEventListener(s, u), n();
                }, u = function(t) {
                    t.target === e && ++c >= a && l();
                };
                setTimeout(function() {
                    c < a && l();
                }, o + 1), e.addEventListener(s, u);
            }
            function qn(e, t) {
                var n, r = window.getComputedStyle(e), i = (r[Bo + "Delay"] || "").split(", "), o = (r[Bo + "Duration"] || "").split(", "), a = Vn(i, o), s = (r[Wo + "Delay"] || "").split(", "), c = (r[Wo + "Duration"] || "").split(", "), l = Vn(s, c), u = 0, p = 0;
                return t === No ? a > 0 && (n = No, u = a, p = o.length) : t === zo ? l > 0 && (n = zo, 
                u = l, p = c.length) : (u = Math.max(a, l), n = u > 0 ? a > l ? No : zo : null, 
                p = n ? n === No ? o.length : c.length : 0), {
                    type: n,
                    timeout: u,
                    propCount: p,
                    hasTransform: n === No && Vo.test(r[Bo + "Property"])
                };
            }
            function Vn(e, t) {
                for (;e.length < t.length; ) e = e.concat(e);
                return Math.max.apply(null, t.map(function(t, n) {
                    return Xn(t) + Xn(e[n]);
                }));
            }
            function Xn(e) {
                return 1e3 * Number(e.slice(0, -1).replace(",", "."));
            }
            function Gn(e, t) {
                var n = e.elm;
                o(n._leaveCb) && (n._leaveCb.cancelled = !0, n._leaveCb());
                var r = zn(e.data.transition);
                if (!i(r) && !o(n._enterCb) && 1 === n.nodeType) {
                    for (var a = r.css, s = r.type, c = r.enterClass, u = r.enterToClass, p = r.enterActiveClass, d = r.appearClass, f = r.appearToClass, h = r.appearActiveClass, v = r.beforeEnter, m = r.enter, y = r.afterEnter, _ = r.enterCancelled, b = r.beforeAppear, x = r.appear, w = r.afterAppear, A = r.appearCancelled, S = r.duration, k = Pi, O = Pi.$vnode; O && O.parent; ) k = O.context, 
                    O = O.parent;
                    var T = !k._isMounted || !e.isRootInsert;
                    if (!T || x || "" === x) {
                        var C = T && d ? d : c, D = T && h ? h : p, j = T && f ? f : u, $ = T && b || v, E = T && "function" == typeof x ? x : m, M = T && w || y, L = T && A || _, R = g(l(S) ? S.enter : S), I = !1 !== a && !zr, F = Kn(E), N = n._enterCb = P(function() {
                            I && (Wn(n, j), Wn(n, D)), N.cancelled ? (I && Wn(n, C), L && L(n)) : M && M(n), 
                            n._enterCb = null;
                        });
                        e.data.show || he(e, "insert", function() {
                            var t = n.parentNode, r = t && t._pending && t._pending[e.key];
                            r && r.tag === e.tag && r.elm._leaveCb && r.elm._leaveCb(), E && E(n, N);
                        }), $ && $(n), I && (Un(n, C), Un(n, D), Bn(function() {
                            Wn(n, C), N.cancelled || (Un(n, j), F || (Jn(R) ? setTimeout(N, R) : Hn(n, s, N)));
                        })), e.data.show && (t && t(), E && E(n, N)), I || F || N();
                    }
                }
            }
            function Yn(e, t) {
                function n() {
                    A.cancelled || (!e.data.show && r.parentNode && ((r.parentNode._pending || (r.parentNode._pending = {}))[e.key] = e), 
                    f && f(r), b && (Un(r, u), Un(r, d), Bn(function() {
                        Wn(r, u), A.cancelled || (Un(r, p), x || (Jn(w) ? setTimeout(A, w) : Hn(r, c, A)));
                    })), h && h(r, A), b || x || A());
                }
                var r = e.elm;
                o(r._enterCb) && (r._enterCb.cancelled = !0, r._enterCb());
                var a = zn(e.data.transition);
                if (i(a) || 1 !== r.nodeType) return t();
                if (!o(r._leaveCb)) {
                    var s = a.css, c = a.type, u = a.leaveClass, p = a.leaveToClass, d = a.leaveActiveClass, f = a.beforeLeave, h = a.leave, v = a.afterLeave, m = a.leaveCancelled, y = a.delayLeave, _ = a.duration, b = !1 !== s && !zr, x = Kn(h), w = g(l(_) ? _.leave : _), A = r._leaveCb = P(function() {
                        r.parentNode && r.parentNode._pending && (r.parentNode._pending[e.key] = null), 
                        b && (Wn(r, p), Wn(r, d)), A.cancelled ? (b && Wn(r, u), m && m(r)) : (t(), v && v(r)), 
                        r._leaveCb = null;
                    });
                    y ? y(n) : n();
                }
            }
            function Jn(e) {
                return "number" == typeof e && !isNaN(e);
            }
            function Kn(e) {
                if (i(e)) return !1;
                var t = e.fns;
                return o(t) ? Kn(Array.isArray(t) ? t[0] : t) : (e._length || e.length) > 1;
            }
            function Qn(e, t) {
                !0 !== t.data.show && Gn(t);
            }
            function Zn(e, t, n) {
                er(e, t, n), (Nr || Br) && setTimeout(function() {
                    er(e, t, n);
                }, 0);
            }
            function er(e, t, n) {
                var r = t.value, i = e.multiple;
                if (!i || Array.isArray(r)) {
                    for (var o, a, s = 0, c = e.options.length; s < c; s++) if (a = e.options[s], i) o = k(r, nr(a)) > -1, 
                    a.selected !== o && (a.selected = o); else if (S(nr(a), r)) return void (e.selectedIndex !== s && (e.selectedIndex = s));
                    i || (e.selectedIndex = -1);
                }
            }
            function tr(e, t) {
                return t.every(function(t) {
                    return !S(t, e);
                });
            }
            function nr(e) {
                return "_value" in e ? e._value : e.value;
            }
            function rr(e) {
                e.target.composing = !0;
            }
            function ir(e) {
                e.target.composing && (e.target.composing = !1, or(e.target, "input"));
            }
            function or(e, t) {
                var n = document.createEvent("HTMLEvents");
                n.initEvent(t, !0, !0), e.dispatchEvent(n);
            }
            function ar(e) {
                return !e.componentInstance || e.data && e.data.transition ? e : ar(e.componentInstance._vnode);
            }
            function sr(e) {
                var t = e && e.componentOptions;
                return t && t.Ctor.options.abstract ? sr(lt(t.children)) : e;
            }
            function cr(e) {
                var t = {}, n = e.$options;
                for (var r in n.propsData) t[r] = e[r];
                var i = n._parentListeners;
                for (var o in i) t[xr(o)] = i[o];
                return t;
            }
            function lr(e, t) {
                if (/\d-keep-alive$/.test(t.tag)) return e("keep-alive", {
                    props: t.componentOptions.propsData
                });
            }
            function ur(e) {
                for (;e = e.parent; ) if (e.data.transition) return !0;
            }
            function pr(e, t) {
                return t.key === e.key && t.tag === e.tag;
            }
            function dr(e) {
                e.elm._moveCb && e.elm._moveCb(), e.elm._enterCb && e.elm._enterCb();
            }
            function fr(e) {
                e.data.newPos = e.elm.getBoundingClientRect();
            }
            function hr(e) {
                var t = e.data.pos, n = e.data.newPos, r = t.left - n.left, i = t.top - n.top;
                if (r || i) {
                    e.data.moved = !0;
                    var o = e.elm.style;
                    o.transform = o.WebkitTransform = "translate(" + r + "px," + i + "px)", o.transitionDuration = "0s";
                }
            }
            var gr = Object.freeze({}), vr = Object.prototype.toString;
            v("slot,component", !0);
            var mr, yr = v("key,ref,slot,slot-scope,is"), _r = Object.prototype.hasOwnProperty, br = /-(\w)/g, xr = _(function(e) {
                return e.replace(br, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            }), wr = _(function(e) {
                return e.charAt(0).toUpperCase() + e.slice(1);
            }), Ar = /\B([A-Z])/g, Sr = _(function(e) {
                return e.replace(Ar, "-$1").toLowerCase();
            }), kr = Function.prototype.bind ? function(e, t) {
                return e.bind(t);
            } : function(e, t) {
                function n(n) {
                    var r = arguments.length;
                    return r ? r > 1 ? e.apply(t, arguments) : e.call(t, n) : e.call(t);
                }
                return n._length = e.length, n;
            }, Pr = function(e, t, n) {
                return !1;
            }, Or = function(e) {
                return e;
            }, Tr = "data-server-rendered", Cr = [ "component", "directive", "filter" ], Dr = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], jr = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: Pr,
                isReservedAttr: Pr,
                isUnknownElement: Pr,
                getTagNamespace: A,
                parsePlatformTagName: Or,
                mustUseProp: Pr,
                async: !0,
                _lifecycleHooks: Dr
            }, $r = /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/, Er = new RegExp("[^" + $r.source + ".$_\\d]"), Mr = "__proto__" in {}, Lr = "undefined" != typeof window, Rr = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, Ir = Rr && WXEnvironment.platform.toLowerCase(), Fr = Lr && window.navigator.userAgent.toLowerCase(), Nr = Fr && /msie|trident/.test(Fr), zr = Fr && Fr.indexOf("msie 9.0") > 0, Br = Fr && Fr.indexOf("edge/") > 0, Ur = (Fr && Fr.indexOf("android"), 
            Fr && /iphone|ipad|ipod|ios/.test(Fr) || "ios" === Ir), Wr = (Fr && /chrome\/\d+/.test(Fr), 
            Fr && /phantomjs/.test(Fr), Fr && Fr.match(/firefox\/(\d+)/)), Hr = {}.watch, qr = !1;
            if (Lr) try {
                var Vr = {};
                Object.defineProperty(Vr, "passive", {
                    get: function() {
                        qr = !0;
                    }
                }), window.addEventListener("test-passive", null, Vr);
            } catch (e) {}
            var Xr, Gr = function() {
                return void 0 === mr && (mr = !Lr && !Rr && void 0 !== t && t.process && "server" === t.process.env.VUE_ENV), 
                mr;
            }, Yr = Lr && window.__VUE_DEVTOOLS_GLOBAL_HOOK__, Jr = "undefined" != typeof Symbol && D(Symbol) && "undefined" != typeof Reflect && D(Reflect.ownKeys);
            Xr = "undefined" != typeof Set && D(Set) ? Set : function() {
                function e() {
                    this.set = Object.create(null);
                }
                return e.prototype.has = function(e) {
                    return !0 === this.set[e];
                }, e.prototype.add = function(e) {
                    this.set[e] = !0;
                }, e.prototype.clear = function() {
                    this.set = Object.create(null);
                }, e;
            }();
            var Kr = A, Qr = 0, Zr = function() {
                this.id = Qr++, this.subs = [];
            };
            Zr.prototype.addSub = function(e) {
                this.subs.push(e);
            }, Zr.prototype.removeSub = function(e) {
                m(this.subs, e);
            }, Zr.prototype.depend = function() {
                Zr.SharedObject.target && Zr.SharedObject.target.addDep(this);
            }, Zr.prototype.notify = function() {
                for (var e = this.subs.slice(), t = 0, n = e.length; t < n; t++) e[t].update();
            }, Zr.SharedObject = {}, Zr.SharedObject.target = null, Zr.SharedObject.targetStack = [];
            var ei = function(e, t, n, r, i, o, a, s) {
                this.tag = e, this.data = t, this.children = n, this.text = r, this.elm = i, this.ns = void 0, 
                this.context = o, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = t && t.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = s, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, ti = {
                child: {
                    configurable: !0
                }
            };
            ti.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(ei.prototype, ti);
            var ni = function(e) {
                void 0 === e && (e = "");
                var t = new ei();
                return t.text = e, t.isComment = !0, t;
            }, ri = Array.prototype, ii = Object.create(ri);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(e) {
                var t = ri[e];
                T(ii, e, function() {
                    for (var n = [], r = arguments.length; r--; ) n[r] = arguments[r];
                    var i, o = t.apply(this, n), a = this.__ob__;
                    switch (e) {
                      case "push":
                      case "unshift":
                        i = n;
                        break;

                      case "splice":
                        i = n.slice(2);
                    }
                    return i && a.observeArray(i), a.dep.notify(), o;
                });
            });
            var oi = Object.getOwnPropertyNames(ii), ai = !0, si = function(e) {
                this.value = e, this.dep = new Zr(), this.vmCount = 0, T(e, "__ob__", this), Array.isArray(e) ? (Mr ? R(e, ii) : I(e, ii, oi), 
                this.observeArray(e)) : this.walk(e);
            };
            si.prototype.walk = function(e) {
                for (var t = Object.keys(e), n = 0; n < t.length; n++) N(e, t[n]);
            }, si.prototype.observeArray = function(e) {
                for (var t = 0, n = e.length; t < n; t++) F(e[t]);
            };
            var ci = jr.optionMergeStrategies;
            ci.data = function(e, t, n) {
                return n ? H(e, t, n) : t && "function" != typeof t ? e : H(e, t);
            }, Dr.forEach(function(e) {
                ci[e] = q;
            }), Cr.forEach(function(e) {
                ci[e + "s"] = X;
            }), ci.watch = function(e, t, n, r) {
                if (e === Hr && (e = void 0), t === Hr && (t = void 0), !t) return Object.create(e || null);
                if (!e) return t;
                var i = {};
                for (var o in x(i, e), t) {
                    var a = i[o], s = t[o];
                    a && !Array.isArray(a) && (a = [ a ]), i[o] = a ? a.concat(s) : Array.isArray(s) ? s : [ s ];
                }
                return i;
            }, ci.props = ci.methods = ci.inject = ci.computed = function(e, t, n, r) {
                if (!e) return t;
                var i = Object.create(null);
                return x(i, e), t && x(i, t), i;
            }, ci.provide = H;
            var li, ui = function(e, t) {
                return void 0 === t ? e : t;
            }, pi = !1, di = [], fi = !1;
            if ("undefined" != typeof Promise && D(Promise)) {
                var hi = Promise.resolve();
                li = function() {
                    hi.then(ce), Ur && setTimeout(A);
                }, pi = !0;
            } else if (Nr || "undefined" == typeof MutationObserver || !D(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString()) li = "undefined" != typeof setImmediate && D(setImmediate) ? function() {
                setImmediate(ce);
            } : function() {
                setTimeout(ce, 0);
            }; else {
                var gi = 1, vi = new MutationObserver(ce), mi = document.createTextNode(String(gi));
                vi.observe(mi, {
                    characterData: !0
                }), li = function() {
                    gi = (gi + 1) % 2, mi.data = String(gi);
                }, pi = !0;
            }
            var yi = new Xr(), _i = _(function(e) {
                var t = "&" === e.charAt(0), n = "~" === (e = t ? e.slice(1) : e).charAt(0), r = "!" === (e = n ? e.slice(1) : e).charAt(0);
                return e = r ? e.slice(1) : e, {
                    name: e,
                    once: n,
                    capture: r,
                    passive: t
                };
            });
            He(qe.prototype);
            var bi, xi = {
                init: function(e, t) {
                    if (e.componentInstance && !e.componentInstance._isDestroyed && e.data.keepAlive) {
                        var n = e;
                        xi.prepatch(n, n);
                    } else (e.componentInstance = Je(e, Pi)).$mount(t ? e.elm : void 0, t);
                },
                prepatch: function(e, t) {
                    var n = t.componentOptions;
                    yt(t.componentInstance = e.componentInstance, n.propsData, n.listeners, t, n.children);
                },
                insert: function(e) {
                    var t = e.context, n = e.componentInstance;
                    n._isMounted || (wt(n, "onServiceCreated"), wt(n, "onServiceAttached"), n._isMounted = !0, 
                    wt(n, "mounted")), e.data.keepAlive && (t._isMounted ? Pt(n) : bt(n, !0));
                },
                destroy: function(e) {
                    var t = e.componentInstance;
                    t._isDestroyed || (e.data.keepAlive ? xt(t, !0) : t.$destroy());
                }
            }, wi = Object.keys(xi), Ai = 1, Si = 2, ki = null, Pi = null, Oi = [], Ti = [], Ci = {}, Di = !1, ji = !1, $i = 0, Ei = 0, Mi = Date.now;
            if (Lr && !Nr) {
                var Li = window.performance;
                Li && "function" == typeof Li.now && Mi() > document.createEvent("Event").timeStamp && (Mi = function() {
                    return Li.now();
                });
            }
            var Ri = 0, Ii = function(e, t, n, r, i) {
                this.vm = e, i && (e._watcher = this), e._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++Ri, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new Xr(), this.newDepIds = new Xr(), this.expression = "", 
                "function" == typeof t ? this.getter = t : (this.getter = C(t), this.getter || (this.getter = A)), 
                this.value = this.lazy ? void 0 : this.get();
            };
            Ii.prototype.get = function() {
                var e;
                j(this);
                var t = this.vm;
                try {
                    e = this.getter.call(t, t);
                } catch (e) {
                    if (!this.user) throw e;
                    ie(e, t, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && ue(e), $(), this.cleanupDeps();
                }
                return e;
            }, Ii.prototype.addDep = function(e) {
                var t = e.id;
                this.newDepIds.has(t) || (this.newDepIds.add(t), this.newDeps.push(e), this.depIds.has(t) || e.addSub(this));
            }, Ii.prototype.cleanupDeps = function() {
                for (var e = this.deps.length; e--; ) {
                    var t = this.deps[e];
                    this.newDepIds.has(t.id) || t.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, Ii.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : Tt(this);
            }, Ii.prototype.run = function() {
                if (this.active) {
                    var e = this.get();
                    if (e !== this.value || l(e) || this.deep) {
                        var t = this.value;
                        if (this.value = e, this.user) try {
                            this.cb.call(this.vm, e, t);
                        } catch (e) {
                            ie(e, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, e, t);
                    }
                }
            }, Ii.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, Ii.prototype.depend = function() {
                for (var e = this.deps.length; e--; ) this.deps[e].depend();
            }, Ii.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || m(this.vm._watchers, this);
                    for (var e = this.deps.length; e--; ) this.deps[e].removeSub(this);
                    this.active = !1;
                }
            };
            var Fi = {
                enumerable: !0,
                configurable: !0,
                get: A,
                set: A
            }, Ni = {
                lazy: !0
            }, zi = 0;
            (function(e) {
                e.prototype._init = function(e) {
                    var t = this;
                    t._uid = zi++, t._isVue = !0, e && e._isComponent ? Bt(t, e) : t.$options = K(Ut(t.constructor), e || {}, t), 
                    t._renderProxy = t, t._self = t, vt(t), ut(t), it(t), wt(t, "beforeCreate"), !t._$fallback && Ae(t), 
                    Dt(t), !t._$fallback && we(t), !t._$fallback && wt(t, "created"), t.$options.el && t.$mount(t.$options.el);
                };
            })(Ht), function(e) {
                var t = {
                    get: function() {
                        return this._data;
                    }
                }, n = {
                    get: function() {
                        return this._props;
                    }
                };
                Object.defineProperty(e.prototype, "$data", t), Object.defineProperty(e.prototype, "$props", n), 
                e.prototype.$set = z, e.prototype.$delete = B, e.prototype.$watch = function(e, t, n) {
                    var r = this;
                    if (u(t)) return zt(r, e, t, n);
                    (n = n || {}).user = !0;
                    var i = new Ii(r, e, t, n);
                    if (n.immediate) try {
                        t.call(r, i.value);
                    } catch (e) {
                        ie(e, r, 'callback for immediate watcher "' + i.expression + '"');
                    }
                    return function() {
                        i.teardown();
                    };
                };
            }(Ht), function(e) {
                var t = /^hook:/;
                e.prototype.$on = function(e, n) {
                    var r = this;
                    if (Array.isArray(e)) for (var i = 0, o = e.length; i < o; i++) r.$on(e[i], n); else (r._events[e] || (r._events[e] = [])).push(n), 
                    t.test(e) && (r._hasHookEvent = !0);
                    return r;
                }, e.prototype.$once = function(e, t) {
                    function n() {
                        r.$off(e, n), t.apply(r, arguments);
                    }
                    var r = this;
                    return n.fn = t, r.$on(e, n), r;
                }, e.prototype.$off = function(e, t) {
                    var n = this;
                    if (!arguments.length) return n._events = Object.create(null), n;
                    if (Array.isArray(e)) {
                        for (var r = 0, i = e.length; r < i; r++) n.$off(e[r], t);
                        return n;
                    }
                    var o, a = n._events[e];
                    if (!a) return n;
                    if (!t) return n._events[e] = null, n;
                    for (var s = a.length; s--; ) if ((o = a[s]) === t || o.fn === t) {
                        a.splice(s, 1);
                        break;
                    }
                    return n;
                }, e.prototype.$emit = function(e) {
                    var t = this, n = t._events[e];
                    if (n) {
                        n = n.length > 1 ? b(n) : n;
                        for (var r = b(arguments, 1), i = 'event handler for "' + e + '"', o = 0, a = n.length; o < a; o++) oe(n[o], t, r, t, i);
                    }
                    return t;
                };
            }(Ht), function(e) {
                e.prototype._update = function(e, t) {
                    var n = this, r = n.$el, i = n._vnode, o = gt(n);
                    n._vnode = e, n.$el = i ? n.__patch__(i, e) : n.__patch__(n.$el, e, t, !1), o(), 
                    r && (r.__vue__ = null), n.$el && (n.$el.__vue__ = n), n.$vnode && n.$parent && n.$vnode === n.$parent._vnode && (n.$parent.$el = n.$el);
                }, e.prototype.$forceUpdate = function() {
                    var e = this;
                    e._watcher && e._watcher.update();
                }, e.prototype.$destroy = function() {
                    var e = this;
                    if (!e._isBeingDestroyed) {
                        wt(e, "beforeDestroy"), e._isBeingDestroyed = !0;
                        var t = e.$parent;
                        !t || t._isBeingDestroyed || e.$options.abstract || m(t.$children, e), e._watcher && e._watcher.teardown();
                        for (var n = e._watchers.length; n--; ) e._watchers[n].teardown();
                        e._data.__ob__ && e._data.__ob__.vmCount--, e._isDestroyed = !0, e.__patch__(e._vnode, null), 
                        wt(e, "destroyed"), e.$off(), e.$el && (e.$el.__vue__ = null), e.$vnode && (e.$vnode.parent = null);
                    }
                };
            }(Ht), function(e) {
                He(e.prototype), e.prototype.$nextTick = function(e) {
                    return le(e, this);
                }, e.prototype._render = function() {
                    var e, t = this, n = t.$options, r = n.render, i = n._parentVnode;
                    i && (t.$scopedSlots = Oe(i.data.scopedSlots, t.$slots, t.$scopedSlots)), t.$vnode = i;
                    try {
                        ki = t, e = r.call(t._renderProxy, t.$createElement);
                    } catch (n) {
                        ie(n, t, "render"), e = t._vnode;
                    } finally {
                        ki = null;
                    }
                    return Array.isArray(e) && 1 === e.length && (e = e[0]), e instanceof ei || (e = ni()), 
                    e.parent = i, e;
                };
            }(Ht);
            var Bi = [ String, RegExp, Array ], Ui = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: Bi,
                        exclude: Bi,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var e in this.cache) en(this.cache, e, this.keys);
                    },
                    mounted: function() {
                        var e = this;
                        this.$watch("include", function(t) {
                            Zt(e, function(e) {
                                return Qt(t, e);
                            });
                        }), this.$watch("exclude", function(t) {
                            Zt(e, function(e) {
                                return !Qt(t, e);
                            });
                        });
                    },
                    render: function() {
                        var e = this.$slots.default, t = lt(e), n = t && t.componentOptions;
                        if (n) {
                            var r = Kt(n), i = this, o = i.include, a = i.exclude;
                            if (o && (!r || !Qt(o, r)) || a && r && Qt(a, r)) return t;
                            var s = this, c = s.cache, l = s.keys, u = null == t.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : t.key;
                            c[u] ? (t.componentInstance = c[u].componentInstance, m(l, u), l.push(u)) : (c[u] = t, 
                            l.push(u), this.max && l.length > parseInt(this.max) && en(c, l[0], l, this._vnode)), 
                            t.data.keepAlive = !0;
                        }
                        return t || e && e[0];
                    }
                }
            };
            (function(e) {
                var t = {
                    get: function() {
                        return jr;
                    }
                };
                Object.defineProperty(e, "config", t), e.util = {
                    warn: Kr,
                    extend: x,
                    mergeOptions: K,
                    defineReactive: N
                }, e.set = z, e.delete = B, e.nextTick = le, e.observable = function(e) {
                    return F(e), e;
                }, e.options = Object.create(null), Cr.forEach(function(t) {
                    e.options[t + "s"] = Object.create(null);
                }), e.options._base = e, x(e.options.components, Ui), qt(e), Vt(e), Xt(e), Jt(e);
            })(Ht), Object.defineProperty(Ht.prototype, "$isServer", {
                get: Gr
            }), Object.defineProperty(Ht.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(Ht, "FunctionalRenderContext", {
                value: qe
            }), Ht.version = "2.6.11";
            var Wi, Hi, qi, Vi = v("style,class"), Xi = v("input,textarea,option,select,progress"), Gi = v("contenteditable,draggable,spellcheck"), Yi = v("events,caret,typing,plaintext-only"), Ji = function(e, t) {
                return to(t) || "false" === t ? "false" : "contenteditable" === e && Yi(t) ? t : "true";
            }, Ki = v("allowfullscreen,async,autofocus,autoplay,checked,compact,controls,declare,default,defaultchecked,defaultmuted,defaultselected,defer,disabled,enabled,formnovalidate,hidden,indeterminate,inert,ismap,itemscope,loop,multiple,muted,nohref,noresize,noshade,novalidate,nowrap,open,pauseonexit,readonly,required,reversed,scoped,seamless,selected,sortable,translate,truespeed,typemustmatch,visible"), Qi = "http://www.w3.org/1999/xlink", Zi = function(e) {
                return ":" === e.charAt(5) && "xlink" === e.slice(0, 5);
            }, eo = function(e) {
                return Zi(e) ? e.slice(6, e.length) : "";
            }, to = function(e) {
                return null == e || !1 === e;
            }, no = {
                svg: "http://www.w3.org/2000/svg",
                math: "http://www.w3.org/1998/Math/MathML"
            }, ro = v("html,body,base,head,link,meta,style,title,address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,hgroup,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,rtc,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,menuitem,summary,content,element,shadow,template,blockquote,iframe,tfoot"), io = v("svg,animate,circle,clippath,cursor,defs,desc,ellipse,filter,font-face,foreignObject,g,glyph,image,line,marker,mask,missing-glyph,path,pattern,polygon,polyline,rect,switch,symbol,text,textpath,tspan,use,view", !0), oo = function(e) {
                return ro(e) || io(e);
            }, ao = Object.create(null), so = v("text,number,password,search,email,tel,url"), co = Object.freeze({
                createElement: function(e, t) {
                    var n = document.createElement(e);
                    return "select" !== e || t.data && t.data.attrs && void 0 !== t.data.attrs.multiple && n.setAttribute("multiple", "multiple"), 
                    n;
                },
                createElementNS: function(e, t) {
                    return document.createElementNS(no[e], t);
                },
                createTextNode: function(e) {
                    return document.createTextNode(e);
                },
                createComment: function(e) {
                    return document.createComment(e);
                },
                insertBefore: function(e, t, n) {
                    e.insertBefore(t, n);
                },
                removeChild: function(e, t) {
                    e.removeChild(t);
                },
                appendChild: function(e, t) {
                    e.appendChild(t);
                },
                parentNode: function(e) {
                    return e.parentNode;
                },
                nextSibling: function(e) {
                    return e.nextSibling;
                },
                tagName: function(e) {
                    return e.tagName;
                },
                setTextContent: function(e, t) {
                    e.textContent = t;
                },
                setStyleScope: function(e, t) {
                    e.setAttribute(t, "");
                }
            }), lo = {
                create: function(e, t) {
                    un(t);
                },
                update: function(e, t) {
                    e.data.ref !== t.data.ref && (un(e, !0), un(t));
                },
                destroy: function(e) {
                    un(e, !0);
                }
            }, uo = new ei("", {}, []), po = [ "create", "activate", "update", "remove", "destroy" ], fo = {
                create: hn,
                update: hn,
                destroy: function(e) {
                    hn(e, uo);
                }
            }, ho = Object.create(null), go = [ lo, fo ], vo = {
                create: bn,
                update: bn
            }, mo = {
                create: xn,
                update: xn
            }, yo = {
                create: Sn,
                update: Sn
            }, _o = "__r", bo = "__c", xo = pi && !(Wr && Number(Wr[1]) <= 53), wo = {
                create: Cn,
                update: Cn
            }, Ao = {
                create: Dn,
                update: Dn
            }, So = _(function(e) {
                var t = {}, n = /;(?![^(]*\))/g, r = /:(.+)/;
                return e.split(n).forEach(function(e) {
                    if (e) {
                        var n = e.split(r);
                        n.length > 1 && (t[n[0].trim()] = n[1].trim());
                    }
                }), t;
            }), ko = /^--/, Po = /\s*!important$/, Oo = /\b([+-]?\d+(\.\d+)?)[r|u]px\b/g, To = function(e) {
                return "string" == typeof e ? e.replace(Oo, function(e, t) {
                    return r.upx2px(t) + "px";
                }) : e;
            }, Co = /url\(\s*['"](.+?\.(jpg|gif|png))['"]\s*\)/, Do = /url\(\s*([a-zA-Z0-9\.\-\_\/]+?\.(jpg|gif|png))\s*\)/, jo = function(e, t) {
                if ("string" == typeof e && -1 !== e.indexOf("url(")) {
                    var n = e.match(Co) || e.match(Do);
                    n && 3 === n.length && (e = e.replace(n[1], t._$getRealPath(n[1])));
                }
                return e;
            }, $o = function(e, t, n, r) {
                if (r && r._$getRealPath && n && (n = jo(n, r)), ko.test(t)) e.style.setProperty(t, n); else if (Po.test(n)) e.style.setProperty(Sr(t), n.replace(Po, ""), "important"); else {
                    var i = Mo(t);
                    if (Array.isArray(n)) for (var o = 0, a = n.length; o < a; o++) e.style[i] = To(n[o]); else e.style[i] = To(n);
                }
            }, Eo = [ "Webkit", "Moz", "ms" ], Mo = _(function(e) {
                if (qi = qi || document.createElement("div").style, "filter" !== (e = xr(e)) && e in qi) return e;
                for (var t = e.charAt(0).toUpperCase() + e.slice(1), n = 0; n < Eo.length; n++) {
                    var r = Eo[n] + t;
                    if (r in qi) return r;
                }
            }), Lo = {
                create: In,
                update: In
            }, Ro = /\s+/, Io = _(function(e) {
                return {
                    enterClass: e + "-enter",
                    enterToClass: e + "-enter-to",
                    enterActiveClass: e + "-enter-active",
                    leaveClass: e + "-leave",
                    leaveToClass: e + "-leave-to",
                    leaveActiveClass: e + "-leave-active"
                };
            }), Fo = Lr && !zr, No = "transition", zo = "animation", Bo = "transition", Uo = "transitionend", Wo = "animation", Ho = "animationend";
            Fo && (void 0 === window.ontransitionend && void 0 !== window.onwebkittransitionend && (Bo = "WebkitTransition", 
            Uo = "webkitTransitionEnd"), void 0 === window.onanimationend && void 0 !== window.onwebkitanimationend && (Wo = "WebkitAnimation", 
            Ho = "webkitAnimationEnd"));
            var qo = Lr ? window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : setTimeout : function(e) {
                return e();
            }, Vo = /\b(transform|all)(,|$)/, Xo = function(e) {
                function t(e) {
                    return new ei(j.tagName(e).toLowerCase(), {}, [], void 0, e);
                }
                function n(e, t) {
                    function n() {
                        0 == --n.listeners && r(e);
                    }
                    return n.listeners = t, n;
                }
                function r(e) {
                    var t = j.parentNode(e);
                    o(t) && j.removeChild(t, e);
                }
                function s(e, t, n, r, i, s, c) {
                    if (o(e.elm) && o(s) && (e = s[c] = M(e)), e.isRootInsert = !i, !l(e, t, n, r)) {
                        var u = e.data, p = e.children, h = e.tag;
                        o(h) ? (e.elm = e.ns ? j.createElementNS(e.ns, h) : j.createElement(h, e), m(e), 
                        f(e, p, t), o(u) && g(e, t), d(n, e.elm, r)) : a(e.isComment) ? (e.elm = j.createComment(e.text), 
                        d(n, e.elm, r)) : (e.elm = j.createTextNode(e.text), d(n, e.elm, r));
                    }
                }
                function l(e, t, n, r) {
                    var i = e.data;
                    if (o(i)) {
                        var s = o(e.componentInstance) && i.keepAlive;
                        if (o(i = i.hook) && o(i = i.init) && i(e, !1), o(e.componentInstance)) return u(e, t), 
                        d(n, e.elm, r), a(s) && p(e, t, n, r), !0;
                    }
                }
                function u(e, t) {
                    o(e.data.pendingInsert) && (t.push.apply(t, e.data.pendingInsert), e.data.pendingInsert = null), 
                    e.elm = e.componentInstance.$el, h(e) ? (g(e, t), m(e)) : (un(e), t.push(e));
                }
                function p(e, t, n, r) {
                    for (var i, a = e; a.componentInstance; ) if (a = a.componentInstance._vnode, o(i = a.data) && o(i = i.transition)) {
                        for (i = 0; i < C.activate.length; ++i) C.activate[i](uo, a);
                        t.push(a);
                        break;
                    }
                    d(n, e.elm, r);
                }
                function d(e, t, n) {
                    o(e) && (o(n) ? j.parentNode(n) === e && j.insertBefore(e, t, n) : j.appendChild(e, t));
                }
                function f(e, t, n) {
                    if (Array.isArray(t)) for (var r = 0; r < t.length; ++r) s(t[r], n, e.elm, null, !0, t, r); else c(e.text) && j.appendChild(e.elm, j.createTextNode(String(e.text)));
                }
                function h(e) {
                    for (;e.componentInstance; ) e = e.componentInstance._vnode;
                    return o(e.tag);
                }
                function g(e, t) {
                    for (var n = 0; n < C.create.length; ++n) C.create[n](uo, e);
                    o(O = e.data.hook) && (o(O.create) && O.create(uo, e), o(O.insert) && t.push(e));
                }
                function m(e) {
                    var t;
                    if (o(t = e.fnScopeId)) j.setStyleScope(e.elm, t); else for (var n = e; n; ) o(t = n.context) && o(t = t.$options._scopeId) && j.setStyleScope(e.elm, t), 
                    n = n.parent;
                    o(t = Pi) && t !== e.context && t !== e.fnContext && o(t = t.$options._scopeId) && j.setStyleScope(e.elm, t);
                }
                function y(e, t, n, r, i, o) {
                    for (;r <= i; ++r) s(n[r], o, e, t, !1, n, r);
                }
                function _(e) {
                    var t, n, r = e.data;
                    if (o(r)) for (o(t = r.hook) && o(t = t.destroy) && t(e), t = 0; t < C.destroy.length; ++t) C.destroy[t](e);
                    if (o(t = e.children)) for (n = 0; n < e.children.length; ++n) _(e.children[n]);
                }
                function b(e, t, n) {
                    for (;t <= n; ++t) {
                        var i = e[t];
                        o(i) && (o(i.tag) ? (x(i), _(i)) : r(i.elm));
                    }
                }
                function x(e, t) {
                    if (o(t) || o(e.data)) {
                        var i, a = C.remove.length + 1;
                        for (o(t) ? t.listeners += a : t = n(e.elm, a), o(i = e.componentInstance) && o(i = i._vnode) && o(i.data) && x(i, t), 
                        i = 0; i < C.remove.length; ++i) C.remove[i](e, t);
                        o(i = e.data.hook) && o(i = i.remove) ? i(e, t) : t();
                    } else r(e.elm);
                }
                function w(e, t, n, r, a) {
                    for (var c, l, u, p, d = 0, f = 0, h = t.length - 1, g = t[0], v = t[h], m = n.length - 1, _ = n[0], x = n[m], w = !a; d <= h && f <= m; ) i(g) ? g = t[++d] : i(v) ? v = t[--h] : pn(g, _) ? (S(g, _, r, n, f), 
                    g = t[++d], _ = n[++f]) : pn(v, x) ? (S(v, x, r, n, m), v = t[--h], x = n[--m]) : pn(g, x) ? (S(g, x, r, n, m), 
                    w && j.insertBefore(e, g.elm, j.nextSibling(v.elm)), g = t[++d], x = n[--m]) : pn(v, _) ? (S(v, _, r, n, f), 
                    w && j.insertBefore(e, v.elm, g.elm), v = t[--h], _ = n[++f]) : (i(c) && (c = fn(t, d, h)), 
                    l = o(_.key) ? c[_.key] : A(_, t, d, h), i(l) ? s(_, r, e, g.elm, !1, n, f) : (u = t[l], 
                    pn(u, _) ? (S(u, _, r, n, f), t[l] = void 0, w && j.insertBefore(e, u.elm, g.elm)) : s(_, r, e, g.elm, !1, n, f)), 
                    _ = n[++f]);
                    d > h ? (p = i(n[m + 1]) ? null : n[m + 1].elm, y(e, p, n, f, m, r)) : f > m && b(t, d, h);
                }
                function A(e, t, n, r) {
                    for (var i = n; i < r; i++) {
                        var a = t[i];
                        if (o(a) && pn(e, a)) return i;
                    }
                }
                function S(e, t, n, r, s, c) {
                    if (e !== t) {
                        o(t.elm) && o(r) && (t = r[s] = M(t));
                        var l = t.elm = e.elm;
                        if (a(e.isAsyncPlaceholder)) o(t.asyncFactory.resolved) ? P(e.elm, t, n) : t.isAsyncPlaceholder = !0; else if (a(t.isStatic) && a(e.isStatic) && t.key === e.key && (a(t.isCloned) || a(t.isOnce))) t.componentInstance = e.componentInstance; else {
                            var u, p = t.data;
                            o(p) && o(u = p.hook) && o(u = u.prepatch) && u(e, t);
                            var d = e.children, f = t.children;
                            if (o(p) && h(t)) {
                                for (u = 0; u < C.update.length; ++u) C.update[u](e, t);
                                o(u = p.hook) && o(u = u.update) && u(e, t);
                            }
                            i(t.text) ? o(d) && o(f) ? d !== f && w(l, d, f, n, c) : o(f) ? (o(e.text) && j.setTextContent(l, ""), 
                            y(l, null, f, 0, f.length - 1, n)) : o(d) ? b(d, 0, d.length - 1) : o(e.text) && j.setTextContent(l, "") : e.text !== t.text && j.setTextContent(l, t.text), 
                            o(p) && o(u = p.hook) && o(u = u.postpatch) && u(e, t);
                        }
                    }
                }
                function k(e, t, n) {
                    if (a(n) && o(e.parent)) e.parent.data.pendingInsert = t; else for (var r = 0; r < t.length; ++r) t[r].data.hook.insert(t[r]);
                }
                function P(e, t, n, r) {
                    var i, s = t.tag, c = t.data, l = t.children;
                    if (r = r || c && c.pre, t.elm = e, a(t.isComment) && o(t.asyncFactory)) return t.isAsyncPlaceholder = !0, 
                    !0;
                    if (o(c) && (o(i = c.hook) && o(i = i.init) && i(t, !0), o(i = t.componentInstance))) return u(t, n), 
                    !0;
                    if (o(s)) {
                        if (o(l)) if (e.hasChildNodes()) if (o(i = c) && o(i = i.domProps) && o(i = i.innerHTML)) {
                            if (i !== e.innerHTML) return !1;
                        } else {
                            for (var p = !0, d = e.firstChild, h = 0; h < l.length; h++) {
                                if (!d || !P(d, l[h], n, r)) {
                                    p = !1;
                                    break;
                                }
                                d = d.nextSibling;
                            }
                            if (!p || d) return !1;
                        } else f(t, l, n);
                        if (o(c)) {
                            var v = !1;
                            for (var m in c) if (!$(m)) {
                                v = !0, g(t, n);
                                break;
                            }
                            !v && c.class && ue(c.class);
                        }
                    } else e.data !== t.text && (e.data = t.text);
                    return !0;
                }
                var O, T, C = {}, D = e.modules, j = e.nodeOps;
                for (O = 0; O < po.length; ++O) for (C[po[O]] = [], T = 0; T < D.length; ++T) o(D[T][po[O]]) && C[po[O]].push(D[T][po[O]]);
                var $ = v("attrs,class,staticClass,staticStyle,key");
                return function(e, n, r, c) {
                    if (!i(n)) {
                        var l = !1, u = [];
                        if (i(e)) l = !0, s(n, u); else {
                            var p = o(e.nodeType);
                            if (!p && pn(e, n)) S(e, n, u, null, null, c); else {
                                if (p) {
                                    if (1 === e.nodeType && e.hasAttribute(Tr) && (e.removeAttribute(Tr), r = !0), a(r) && P(e, n, u)) return k(n, u, !0), 
                                    e;
                                    e = t(e);
                                }
                                var d = e.elm, f = j.parentNode(d);
                                if (s(n, u, d._leaveCb ? null : f, j.nextSibling(d)), o(n.parent)) for (var g = n.parent, v = h(n); g; ) {
                                    for (var m = 0; m < C.destroy.length; ++m) C.destroy[m](g);
                                    if (g.elm = n.elm, v) {
                                        for (var y = 0; y < C.create.length; ++y) C.create[y](uo, g);
                                        var x = g.data.hook.insert;
                                        if (x.merged) for (var w = 1; w < x.fns.length; w++) x.fns[w]();
                                    } else un(g);
                                    g = g.parent;
                                }
                                o(f) ? b([ e ], 0, 0) : o(e.tag) && _(e);
                            }
                        }
                        return k(n, u, l), n.elm;
                    }
                    o(e) && _(e);
                };
            }({
                nodeOps: co,
                modules: [ vo, mo, yo, wo, Ao, Lo, Lr ? {
                    create: Qn,
                    activate: Qn,
                    remove: function(e, t) {
                        !0 !== e.data.show ? Yn(e, t) : t();
                    }
                } : {} ].concat(go)
            });
            zr && document.addEventListener("selectionchange", function() {
                var e = document.activeElement;
                e && e.vmodel && or(e, "input");
            });
            var Go = {
                inserted: function(e, t, n, r) {
                    "select" === n.tag ? (r.elm && !r.elm._vOptions ? he(n, "postpatch", function() {
                        Go.componentUpdated(e, t, n);
                    }) : Zn(e, t, n.context), e._vOptions = [].map.call(e.options, nr)) : ("textarea" === n.tag || so(e.type)) && (e._vModifiers = t.modifiers, 
                    t.modifiers.lazy || (e.addEventListener("compositionstart", rr), e.addEventListener("compositionend", ir), 
                    e.addEventListener("change", ir), zr && (e.vmodel = !0)));
                },
                componentUpdated: function(e, t, n) {
                    if ("select" === n.tag) {
                        Zn(e, t, n.context);
                        var r = e._vOptions, i = e._vOptions = [].map.call(e.options, nr);
                        i.some(function(e, t) {
                            return !S(e, r[t]);
                        }) && (e.multiple ? t.value.some(function(e) {
                            return tr(e, i);
                        }) : t.value !== t.oldValue && tr(t.value, i)) && or(e, "change");
                    }
                }
            }, Yo = {
                model: Go,
                show: {
                    bind: function(e, t, n) {
                        var r = t.value, i = (n = ar(n)).data && n.data.transition, o = e.__vOriginalDisplay = "none" === e.style.display ? "" : e.style.display;
                        r && i ? (n.data.show = !0, Gn(n, function() {
                            e.style.display = o;
                        })) : e.style.display = r ? o : "none";
                    },
                    update: function(e, t, n) {
                        var r = t.value;
                        !r != !t.oldValue && ((n = ar(n)).data && n.data.transition ? (n.data.show = !0, 
                        r ? Gn(n, function() {
                            e.style.display = e.__vOriginalDisplay;
                        }) : Yn(n, function() {
                            e.style.display = "none";
                        })) : e.style.display = r ? e.__vOriginalDisplay : "none");
                    },
                    unbind: function(e, t, n, r, i) {
                        i || (e.style.display = e.__vOriginalDisplay);
                    }
                }
            }, Jo = {
                name: String,
                appear: Boolean,
                css: Boolean,
                mode: String,
                type: String,
                enterClass: String,
                leaveClass: String,
                enterToClass: String,
                leaveToClass: String,
                enterActiveClass: String,
                leaveActiveClass: String,
                appearClass: String,
                appearActiveClass: String,
                appearToClass: String,
                duration: [ Number, String, Object ]
            }, Ko = function(e) {
                return e.tag || ct(e);
            }, Qo = function(e) {
                return "show" === e.name;
            }, Zo = {
                name: "transition",
                props: Jo,
                abstract: !0,
                render: function(e) {
                    var t = this, n = this.$slots.default;
                    if (n && (n = n.filter(Ko)).length) {
                        var r = this.mode, i = n[0];
                        if (ur(this.$vnode)) return i;
                        var o = sr(i);
                        if (!o) return i;
                        if (this._leaving) return lr(e, i);
                        var a = "__transition-" + this._uid + "-";
                        o.key = null == o.key ? o.isComment ? a + "comment" : a + o.tag : c(o.key) ? 0 === String(o.key).indexOf(a) ? o.key : a + o.key : o.key;
                        var s = (o.data || (o.data = {})).transition = cr(this), l = this._vnode, u = sr(l);
                        if (o.data.directives && o.data.directives.some(Qo) && (o.data.show = !0), u && u.data && !pr(o, u) && !ct(u) && (!u.componentInstance || !u.componentInstance._vnode.isComment)) {
                            var p = u.data.transition = x({}, s);
                            if ("out-in" === r) return this._leaving = !0, he(p, "afterLeave", function() {
                                t._leaving = !1, t.$forceUpdate();
                            }), lr(e, i);
                            if ("in-out" === r) {
                                if (ct(o)) return l;
                                var d, f = function() {
                                    d();
                                };
                                he(s, "afterEnter", f), he(s, "enterCancelled", f), he(p, "delayLeave", function(e) {
                                    d = e;
                                });
                            }
                        }
                        return i;
                    }
                }
            }, ea = x({
                tag: String,
                moveClass: String
            }, Jo);
            delete ea.mode;
            var ta = {
                Transition: Zo,
                TransitionGroup: {
                    props: ea,
                    beforeMount: function() {
                        var e = this, t = this._update;
                        this._update = function(n, r) {
                            var i = gt(e);
                            e.__patch__(e._vnode, e.kept, !1, !0), e._vnode = e.kept, i(), t.call(e, n, r);
                        };
                    },
                    render: function(e) {
                        for (var t = this.tag || this.$vnode.data.tag || "span", n = Object.create(null), r = this.prevChildren = this.children, i = this.$slots.default || [], o = this.children = [], a = cr(this), s = 0; s < i.length; s++) {
                            var c = i[s];
                            c.tag && null != c.key && 0 !== String(c.key).indexOf("__vlist") && (o.push(c), 
                            n[c.key] = c, (c.data || (c.data = {})).transition = a);
                        }
                        if (r) {
                            for (var l = [], u = [], p = 0; p < r.length; p++) {
                                var d = r[p];
                                d.data.transition = a, d.data.pos = d.elm.getBoundingClientRect(), n[d.key] ? l.push(d) : u.push(d);
                            }
                            this.kept = e(t, null, l), this.removed = u;
                        }
                        return e(t, null, o);
                    },
                    updated: function() {
                        var e = this.prevChildren, t = this.moveClass || (this.name || "v") + "-move";
                        e.length && this.hasMove(e[0].elm, t) && (e.forEach(dr), e.forEach(fr), e.forEach(hr), 
                        this._reflow = document.body.offsetHeight, e.forEach(function(e) {
                            if (e.data.moved) {
                                var n = e.elm, r = n.style;
                                Un(n, t), r.transform = r.WebkitTransform = r.transitionDuration = "", n.addEventListener(Uo, n._moveCb = function e(r) {
                                    r && r.target !== n || r && !/transform$/.test(r.propertyName) || (n.removeEventListener(Uo, e), 
                                    n._moveCb = null, Wn(n, t));
                                });
                            }
                        }));
                    },
                    methods: {
                        hasMove: function(e, t) {
                            if (!Fo) return !1;
                            if (this._hasMove) return this._hasMove;
                            var n = e.cloneNode();
                            e._transitionClasses && e._transitionClasses.forEach(function(e) {
                                Nn(n, e);
                            }), Fn(n, t), n.style.display = "none", this.$el.appendChild(n);
                            var r = qn(n);
                            return this.$el.removeChild(n), this._hasMove = r.hasTransform;
                        }
                    }
                }
            };
            Ht.config.mustUseProp = function(e, t, n) {
                return "value" === n && Xi(e) && "button" !== t || "selected" === n && "option" === e || "checked" === n && "input" === e || "muted" === n && "video" === e;
            }, Ht.config.isReservedTag = oo, Ht.config.isReservedAttr = Vi, Ht.config.getTagNamespace = function(e) {
                return io(e) ? "svg" : "math" === e ? "math" : void 0;
            }, Ht.config.isUnknownElement = function(e) {
                if (!Lr) return !0;
                if (oo(e)) return !1;
                if (e = e.toLowerCase(), null != ao[e]) return ao[e];
                var t = document.createElement(e);
                return e.indexOf("-") > -1 ? ao[e] = t.constructor === window.HTMLUnknownElement || t.constructor === window.HTMLElement : ao[e] = /HTMLUnknownElement/.test(t.toString());
            }, x(Ht.options.directives, Yo), x(Ht.options.components, ta), Ht.prototype.__patch__ = Lr ? Xo : A, 
            Ht.prototype.__call_hook = function(e, t) {
                var n = this;
                j();
                var r, i = n.$options[e], o = e + " hook";
                if (i) for (var a = 0, s = i.length; a < s; a++) r = oe(i[a], n, t ? [ t ] : null, n, o);
                return n._hasHookEvent && n.$emit("hook:" + e, t), $(), r;
            }, Ht.prototype.$mount = function(e, t) {
                return e = e && Lr ? ln(e) : void 0, mt(this, e, t);
            }, Lr && setTimeout(function() {
                jr.devtools && Yr && Yr.emit("init", Ht);
            }, 0), n.default = Ht;
        }.call(this, r("c8ba"), r("543d").default);
    },
    e1fb: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            namespaced: !0,
            state: {
                emptyHeight: 0,
                botNavHei: 100,
                XBoolean: !1
            },
            getters: {
                getBoolEmpty: function(e) {
                    return {
                        emptyHeight: e.emptyHeight,
                        XBoolean: e.XBoolean
                    };
                },
                getNavHei: function(e) {
                    return e.botNavHei;
                },
                getBotHeight: function(e) {
                    return e.emptyHeight + e.botNavHei;
                },
                getAll: function(e) {
                    return e;
                },
                getEmpty: function(e) {
                    return e.emptyHeight;
                }
            },
            mutations: {
                setXBoolean: function(e, t) {
                    e.XBoolean = t;
                },
                setEmptyHeight: function(e, t) {
                    e.emptyHeight = t;
                }
            },
            actions: {
                setIphone: function(e, t) {
                    (t.model.indexOf("iPhone X") > -1 || t.model.indexOf("iPhone12") > -1 || t.model.indexOf("iPhone 13") > -1 || t.model.indexOf("iPhone13") > -1 || t.model.indexOf("iPhone 11") > -1) && (e.commit("setXBoolean", !0), 
                    e.commit("setEmptyHeight", 70));
                }
            }
        };
        t.default = r;
    },
    e3db: function(e, t) {
        var n = {}.toString;
        e.exports = Array.isArray || function(e) {
            return "[object Array]" == n.call(e);
        };
    },
    ee50: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                copyText: function(t) {
                    this.$utils.uniCopy({
                        data: t,
                        success: function() {
                            e.hideLoading(), e.showToast({
                                title: "复制成功",
                                icon: "none"
                            });
                        }
                    });
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    f0c5: function(e, t, n) {
        function r(e, t, n, r, i, o, a, s, c, l) {
            var u, p = "function" == typeof e ? e.options : e;
            if (c) {
                p.components || (p.components = {});
                var d = Object.prototype.hasOwnProperty;
                for (var f in c) d.call(c, f) && !d.call(p.components, f) && (p.components[f] = c[f]);
            }
            if (l && ((l.beforeCreate || (l.beforeCreate = [])).unshift(function() {
                this[l.__module] = this;
            }), (p.mixins || (p.mixins = [])).push(l)), t && (p.render = t, p.staticRenderFns = n, 
            p._compiled = !0), r && (p.functional = !0), o && (p._scopeId = "data-v-" + o), 
            a ? (u = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), 
                i && i.call(this, e), e && e._registeredComponents && e._registeredComponents.add(a);
            }, p._ssrRegister = u) : i && (u = s ? function() {
                i.call(this, this.$root.$options.shadowRoot);
            } : i), u) if (p.functional) {
                p._injectStyles = u;
                var h = p.render;
                p.render = function(e, t) {
                    return u.call(t), h(e, t);
                };
            } else {
                var g = p.beforeCreate;
                p.beforeCreate = g ? [].concat(g, u) : [ u ];
            }
            return {
                exports: e,
                options: p
            };
        }
        n.d(t, "a", function() {
            return r;
        });
    },
    f169: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = n("b1c7"), o = r(n("9dc1")), a = r(n("27f5")), s = r(n("4360")), c = r(n("816e")), l = r(n("66fd"));
        t.default = function(e, t) {
            void 0 === (e = e || {
                title: "这是一个分享页面",
                path: "/pages/index/index",
                params: {}
            }).params && (e.params = {});
            var n = 0;
            return c.default.isLogin() && l.default.prototype.$store.state.user.info && (n = l.default.prototype.$store.state.user.info.options.user_id), 
            void 0 === e.path || "/pages/index/index" === e.path && void 0 === e.params.page_id ? (e.path = "/pages/index/index?user_id=".concat(n), 
            0 != Object.keys(e.params).length && (e.path += "&" + (0, i.objectToUrlParams)(e.params))) : (e.params.path = e.path, 
            e.params.user_id = n, e.path = "/pages/index/index?scene=share&user_id=".concat(n, "&params=").concat(JSON.stringify(e.params))), 
            setTimeout(function() {
                (0, o.default)({
                    url: a.default.coupon.share_coupon
                }).then(function(e) {
                    if (0 === e.code) {
                        var t = {
                            list: e.data.list,
                            type: "share"
                        };
                        s.default.dispatch("page/actionSetCoupon", t);
                    }
                }).catch(function() {});
            }, 1e3), e;
        };
    },
    f2b3: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("66fd")), i = {
                login: function(e) {
                    return new Promise(function(t, n) {
                        var i = e.userInfoResult;
                        r.default.prototype.$request({
                            url: r.default.prototype.$api.passport.login,
                            method: "post",
                            data: {
                                encryptedData: i.detail.encryptedData,
                                iv: i.detail.iv,
                                rawData: i.detail.rawData,
                                signature: i.detail.signature,
                                code: e.code
                            }
                        }).then(function(e) {
                            t(e);
                        }).catch(function(e) {
                            n(e);
                        });
                    });
                },
                check: function() {
                    return new Promise(function(e, t) {
                        wx.checkBeforeAddOrder || (console.log("error canIUse"), e({
                            requireOrder: 0,
                            traceId: ""
                        })), wx.checkBeforeAddOrder({
                            success: function(t) {
                                console.log(t), e({
                                    requireOrder: t.data.requireOrder,
                                    traceId: t.data.traceId
                                });
                            },
                            fail: function(e) {
                                t(e);
                            }
                        });
                    });
                },
                getLoginCode: function(t) {
                    return new Promise(function(n, r) {
                        var i = {
                            scopes: t.scopes || "auth_base",
                            success: function(e) {
                                "function" == typeof t.success && t.success(e), n(e);
                            },
                            fail: function(e) {
                                "function" == typeof t.fail && t.fail(e), r(e);
                            }
                        };
                        e.login(i);
                    });
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    f82a: function(e, t, n) {
        (function(e) {
            function n(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function r(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                    Object.defineProperty(e, r.key, r);
                }
            }
            function i(e, t, n) {
                return t && r(e.prototype, t), n && r(e, n), e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.Mcaptcha = void 0;
            var o = function() {
                function t(e) {
                    n(this, t), this.options = e, this.fontSize = 3 * e.height / 6, this.init(), this.refresh();
                }
                return i(t, [ {
                    key: "init",
                    value: function() {
                        this.ctx = e.createCanvasContext(this.options.el), this.ctx.setTextBaseline("middle"), 
                        this.ctx.setFillStyle(this.randomColor(180, 240));
                    }
                }, {
                    key: "refresh",
                    value: function() {
                        for (var e = this, t = "", n = [ "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ], r = 0; r < 4; r++) t += n[this.randomNum(0, n.length)];
                        this.options.createCodeImg = t;
                        var i = (t + "").split("");
                        0 === i.length && (i = [ "e", "r", "r", "o", "r" ]);
                        var o = .6 * this.options.width / (i.length - 1), a = .2 * this.options.width;
                        for (i.forEach(function(t, n) {
                            e.ctx.setFillStyle(e.randomColor(0, 180));
                            var r = e.randomNum(24, e.fontSize);
                            e.ctx.setFontSize(r);
                            var i = o * n + a - .3 * r, s = e.randomNum(-30, 30);
                            e.ctx.translate(i, .5 * e.options.height), e.ctx.rotate(s * Math.PI / 180), e.ctx.fillText(t, 0, 0), 
                            e.ctx.rotate(-s * Math.PI / 180), e.ctx.translate(-i, .5 * -e.options.height);
                        }), r = 0; r < 4; r++) this.ctx.strokeStyle = this.randomColor(40, 180), this.ctx.beginPath(), 
                        this.ctx.moveTo(this.randomNum(0, this.options.width), this.randomNum(0, this.options.height)), 
                        this.ctx.lineTo(this.randomNum(0, this.options.width), this.randomNum(0, this.options.height)), 
                        this.ctx.stroke();
                        for (r = 0; r < this.options.width / 4; r++) this.ctx.fillStyle = this.randomColor(0, 255), 
                        this.ctx.beginPath(), this.ctx.arc(this.randomNum(0, this.options.width), this.randomNum(0, this.options.height), 1, 0, 2 * Math.PI), 
                        this.ctx.fill();
                        this.ctx.draw();
                    }
                }, {
                    key: "validate",
                    value: function(e) {
                        e = e.toLowerCase();
                        var t = this.options.createCodeImg.toLowerCase();
                        return e == t.substring(t.length - 4);
                    }
                }, {
                    key: "randomNum",
                    value: function(e, t) {
                        return Math.floor(Math.random() * (t - e) + e);
                    }
                }, {
                    key: "randomColor",
                    value: function(e, t) {
                        return "rgb(" + this.randomNum(e, t) + "," + this.randomNum(e, t) + "," + this.randomNum(e, t) + ")";
                    }
                } ]), t;
            }();
            t.Mcaptcha = o;
        }).call(this, n("543d").default);
    },
    f854: function(e, t, n) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e, t, n, r, i, o, a) {
            try {
                var s = e[o](a), c = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i);
        }
        function o(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(r, o) {
                    function a(e) {
                        i(c, r, o, a, s, "next", e);
                    }
                    function s(e) {
                        i(c, r, o, a, s, "throw", e);
                    }
                    var c = e.apply(t, n);
                    a(void 0);
                });
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = r(n("a34a")), s = n("8de3d"), c = r(n("66fd")), l = r(n("4360")), u = n("b1c7"), p = r(n("36e8")), d = function() {
            var e = o(a.default.mark(function e(t, n) {
                var r, i, o;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return r = {
                            "X-App-Platform": t.header && t.header["X-App-Platform"] ? t.header["X-App-Platform"] : c.default.prototype.$platform,
                            "X-Form-Id-List": JSON.stringify((0, s.popAll)()),
                            "X-Requested-With": t.header && t.header["X-Requested-With"] ? t.header["X-Requested-With"] : "XMLHttpRequest",
                            "X-App-Version": c.default.prototype.$appVersion,
                            "content-type": n ? "multipart/form-data" : "application/x-www-form-urlencoded"
                        }, e.next = 3, l.default.dispatch("user/loadAccessTokenFormCache");

                      case 3:
                        return l.default.state.user && l.default.state.user.accessToken && (r["X-Access-Token"] = l.default.state.user.accessToken), 
                        l.default.state.user && 0 !== l.default.state.user.tempParentId && (r["X-User-Id"] = l.default.state.user.tempParentId + ""), 
                        i = {}, t.url.replace(/([^=&]+)=([^&]*)/g, function(e, t, n) {
                            i[decodeURIComponent(t)] = decodeURIComponent(n);
                        }), -1 !== (0, u.objectValues)(p.default.mch).indexOf(i.r) && (o = c.default.prototype.$storage.getStorageSync("MCH2019"), 
                        r["Mch-Access-Token"] = o.token), e.abrupt("return", r);

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t, n) {
                return e.apply(this, arguments);
            };
        }();
        t.default = d;
    },
    fcd1: function(t, n, r) {
        function i(e) {
            return c(e) || s(e) || a(e) || o();
        }
        function o() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }
        function a(e, t) {
            if (e) {
                if ("string" == typeof e) return l(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0;
            }
        }
        function s(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
        }
        function c(e) {
            if (Array.isArray(e)) return l(e);
        }
        function l(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        function u(t) {
            return (u = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                return void 0 === t ? "undefined" : e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
            })(t);
        }
        function p(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function d(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        function f(e, t, n) {
            return t && d(e.prototype, t), n && d(e, n), e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var h = function() {
            function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.date, r = void 0 === n ? new Date() : n, i = t.selected, o = t.startDate, a = t.endDate, s = t.range;
                p(this, e), this.date = this.getDate(r), this.selected = i || [], this.startDate = o, 
                this.endDate = a, this.range = s, this.cleanMultipleStatus(), this.weeks = {};
            }
            return f(e, [ {
                key: "setDate",
                value: function(e) {
                    this.selectDate = this.getDate(e), this._getWeek(this.selectDate.fullDate);
                }
            }, {
                key: "cleanMultipleStatus",
                value: function() {
                    this.multipleStatus = {
                        before: "",
                        after: "",
                        data: []
                    };
                }
            }, {
                key: "resetSatrtDate",
                value: function(e) {
                    this.startDate = e;
                }
            }, {
                key: "resetEndDate",
                value: function(e) {
                    this.endDate = e;
                }
            }, {
                key: "getDate",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "day";
                    e || (e = new Date()), "object" !== u(e) && (e = e.replace(/-/g, "/"));
                    var r = new Date(e);
                    switch (n) {
                      case "day":
                        r.setDate(r.getDate() + t);
                        break;

                      case "month":
                        31 === r.getDate() ? r.setDate(r.getDate() + t) : r.setMonth(r.getMonth() + t);
                        break;

                      case "year":
                        r.setFullYear(r.getFullYear() + t);
                    }
                    var i = r.getFullYear(), o = r.getMonth() + 1 < 10 ? "0" + (r.getMonth() + 1) : r.getMonth() + 1, a = r.getDate() < 10 ? "0" + r.getDate() : r.getDate();
                    return {
                        fullDate: i + "-" + o + "-" + a,
                        year: i,
                        month: o,
                        date: a,
                        day: r.getDay()
                    };
                }
            }, {
                key: "_getLastMonthDays",
                value: function(e, t) {
                    for (var n = [], r = e; r > 0; r--) {
                        var i = new Date(t.year, t.month - 1, 1 - r).getDate();
                        n.push({
                            date: i,
                            month: t.month - 1,
                            disable: !0
                        });
                    }
                    return n;
                }
            }, {
                key: "_currentMonthDys",
                value: function(e, t) {
                    for (var n = this, r = [], i = this.date.fullDate, o = 1; o <= e; o++) !function(e) {
                        var o = t.year + "-" + (t.month, t.month + "-") + (e < 10 ? "0" + e : e), a = i === o, s = n.selected && n.selected.find(function(e) {
                            if (n.dateEqual(o, e.date)) return e;
                        }), c = !0, l = !0;
                        if (n.startDate) {
                            var u = n.dateCompare(n.startDate, i);
                            c = n.dateCompare(u ? i : n.startDate, o);
                        }
                        if (n.endDate) {
                            var p = n.dateCompare(i, n.endDate);
                            l = n.dateCompare(o, p ? n.endDate : i);
                        }
                        var d = n.multipleStatus.data, f = !1, h = -1;
                        n.range && (d && (h = d.findIndex(function(e) {
                            return n.dateEqual(e, o);
                        })), -1 !== h && (f = !0));
                        var g = {
                            fullDate: o,
                            year: t.year,
                            date: e,
                            multiple: !!n.range && f,
                            beforeMultiple: n.dateEqual(n.multipleStatus.before, o),
                            afterMultiple: n.dateEqual(n.multipleStatus.after, o),
                            month: t.month,
                            disable: !c || !l,
                            isDay: a,
                            dayNum: n.range ? n.multipleStatus.data.length : 1,
                            afterTime: n.multipleStatus.after
                        };
                        s && (g.extraInfo = s), r.push(g);
                    }(o);
                    return r;
                }
            }, {
                key: "_getNextMonthDays",
                value: function(e, t) {
                    for (var n = [], r = 1; r < e + 1; r++) n.push({
                        date: r,
                        month: Number(t.month) + 1,
                        disable: !0
                    });
                    return n;
                }
            }, {
                key: "getInfo",
                value: function(e) {
                    var t = this;
                    return e || (e = new Date()), this.canlender.find(function(n) {
                        return n.fullDate === t.getDate(e).fullDate;
                    });
                }
            }, {
                key: "dateCompare",
                value: function(e, t) {
                    return e = new Date(e.replace("-", "/").replace("-", "/")), t = new Date(t.replace("-", "/").replace("-", "/")), 
                    e <= t;
                }
            }, {
                key: "dateEqual",
                value: function(e, t) {
                    return e = new Date(e.replace("-", "/").replace("-", "/")), t = new Date(t.replace("-", "/").replace("-", "/")), 
                    e.getTime() - t.getTime() == 0;
                }
            }, {
                key: "geDateAll",
                value: function(e, t) {
                    var n = [], r = e.split("-"), i = t.split("-"), o = new Date();
                    o.setFullYear(r[0], r[1] - 1, r[2]);
                    var a = new Date();
                    a.setFullYear(i[0], i[1] - 1, i[2]);
                    for (var s = o.getTime() - 864e5, c = a.getTime() - 864e5, l = s; l <= c; ) l += 864e5, 
                    n.push(this.getDate(new Date(parseInt(l))).fullDate);
                    return n;
                }
            }, {
                key: "setSelectInfo",
                value: function(e, t) {
                    this.selected = t, this._getWeek(e);
                }
            }, {
                key: "setMultiple",
                value: function(e, t, n, r, o) {
                    var a = this.multipleStatus, s = a.before, c = a.after;
                    if (this.range) {
                        if (s && !c && e > s) {
                            var l = [ s, e ], u = this.dateCompare.apply(this, l) ? this.geDateAll.apply(this, l) : this.geDateAll.apply(this, i(l.reverse()));
                            if (1 == t && n < u.length - r) throw new Error("选择天数不能超过" + n + o);
                            this.multipleStatus.after = e, this.multipleStatus.data = u;
                        } else this.multipleStatus.before = e, this.multipleStatus.after = "", this.multipleStatus.data = [];
                        this._getWeek(e);
                    }
                }
            }, {
                key: "_getWeek",
                value: function(e) {
                    var t = this.getDate(e), n = (t.fullDate, t.year), r = t.month, i = (t.date, t.day, 
                    new Date(n, r - 1, 1).getDay()), o = new Date(n, r, 0).getDate(), a = {
                        lastMonthDays: this._getLastMonthDays(i, this.getDate(e)),
                        currentMonthDys: this._currentMonthDys(o, this.getDate(e)),
                        nextMonthDays: [],
                        weeks: []
                    }, s = [], c = 42 - (a.lastMonthDays.length + a.currentMonthDys.length);
                    a.nextMonthDays = this._getNextMonthDays(c, this.getDate(e));
                    var l = a.nextMonthDays.length >= 7 ? a.nextMonthDays.slice(0, a.nextMonthDays.length - 7) : a.nextMonthDays;
                    s = s.concat(a.lastMonthDays, a.currentMonthDys, l);
                    for (var u = {}, p = 0; p < s.length; p++) p % 7 == 0 && (u[parseInt(p / 7)] = new Array(7)), 
                    u[parseInt(p / 7)][p % 7] = s[p];
                    this.canlender = s, this.weeks = u;
                }
            } ]), e;
        }();
        n.default = h;
    },
    ff69: function(e, t, n) {
        (function(e) {
            function r(e, t, n, r, i, o, a) {
                try {
                    var s = e[o](a), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(r, i);
            }
            function i(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(i, o) {
                        function a(e) {
                            r(c, i, o, a, s, "next", e);
                        }
                        function s(e) {
                            r(c, i, o, a, s, "throw", e);
                        }
                        var c = e.apply(t, n);
                        a(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("a34a")), a = {
                setNavigationBarTitle: function() {
                    var t = i(o.default.mark(function t(n, r) {
                        var i, a;
                        return o.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (!(Object.keys(n).length > 0)) {
                                    t.next = 9;
                                    break;
                                }
                                i = 0, a = n.length;

                              case 2:
                                if (!(i < a)) {
                                    t.next = 9;
                                    break;
                                }
                                if (!r.includes(n[i].value)) {
                                    t.next = 6;
                                    break;
                                }
                                return e.setNavigationBarTitle({
                                    title: n[i].new_name
                                }), t.abrupt("return", n[i].new_name);

                              case 6:
                                i++, t.next = 2;
                                break;

                              case 9:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }));
                    return function(e, n) {
                        return t.apply(this, arguments);
                    };
                }()
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    ffa5: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("9dc1")), i = {
                namespaced: !0,
                state: {
                    theme: "",
                    theme_color: null,
                    address_id: "",
                    store_id: "",
                    form_data: {},
                    big_gift_pic: "",
                    theme_id: ""
                },
                getters: {
                    theme_color: function(e) {
                        return e.theme_color;
                    }
                },
                mutations: {
                    addressId: function(e, t) {
                        e.address_id = t;
                    },
                    theme_color: function(e, t) {
                        e.theme_color = t;
                    },
                    storeId: function(e, t) {
                        e.store_id = t;
                    },
                    setGiftPic: function(e, t) {
                        e.big_gift_pic = t;
                    },
                    setTheme: function(e, t) {
                        switch (t) {
                          case 1:
                            e.theme = "streamer-gold-gift", e.theme_id = "d";
                            break;

                          case 2:
                            e.theme = "romantic-powder-gift", e.theme_id = "c";
                            break;

                          case 3:
                            e.theme = "taste-red-gift", e.theme_id = "f";
                            break;

                          case 4:
                            e.theme = "elegant-purple-gift", e.theme_id = "e";
                            break;

                          case 5:
                            e.theme = "fresh-green-gift", e.theme_id = "g";
                            break;

                          case 6:
                            e.theme = "business-blue-gift", e.theme_id = "h";
                            break;

                          default:
                            e.theme = "streamer-gold-gift", e.theme_id = "d";
                        }
                    },
                    setFormData: function(e, t) {
                        e.form_data = t;
                    }
                },
                actions: {
                    getConfig: function(t, n) {
                        (0, r.default)({
                            url: n,
                            method: "get"
                        }).then(function(t) {
                            e.hideLoading(), 0 === t.code && (context.commit("setTheme", Number(t.data.theme.id)), 
                            context.commit("theme_color", t.data.theme_color));
                        }).catch(function() {
                            e.hideLoading();
                        });
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    }
} ]);