var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "23be": function(e, t, o) {
        o.r(t);
        var n = o("e4a4"), r = o.n(n);
        for (var p in n) [ "default" ].indexOf(p) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(p);
        t.default = r.a;
    },
    "3dfd": function(e, t, o) {
        o.r(t);
        var n = o("23be");
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(r);
        o("5c0b");
        var p = o("f0c5"), a = Object(p.a)(n.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = a.exports;
    },
    "56d7": function(t, o, n) {
        (function(t) {
            function o(t) {
                return (o = "function" == typeof Symbol && "symbol" === e(Symbol.iterator) ? function(t) {
                    return void 0 === t ? "undefined" : e(t);
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : e(t);
                })(t);
            }
            function r(e) {
                if ("function" != typeof WeakMap) return null;
                var t = new WeakMap(), o = new WeakMap();
                return (r = function(e) {
                    return e ? o : t;
                })(e);
            }
            function p(e, t) {
                if (!t && e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" != typeof e) return {
                    default: e
                };
                var n = r(t);
                if (n && n.has(e)) return n.get(e);
                var p = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                    var i = a ? Object.getOwnPropertyDescriptor(e, c) : null;
                    i && (i.get || i.set) ? Object.defineProperty(p, c, i) : p[c] = e[c];
                }
                return p.default = e, n && n.set(e, p), p;
            }
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function i(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e;
            }
            n("6cdc");
            var u = a(n("66fd")), s = a(n("3dfd")), l = a(n("4360")), f = a(n("58b6"));
            a(n("ae58")), n("89f3");
            var d = a(n("9dc1")), m = a(n("816e")), y = a(n("27f5")), b = n("63ad"), h = a(n("d3b5")), g = p(n("ac6b")), v = p(n("b1c7")), $ = a(n("2749")), j = a(n("9d0f")), O = a(n("4bca")), S = a(n("b7dd")), w = a(n("dd00")), P = a(n("7319")), _ = a(n("972f")), x = a(n("ab4f")), q = a(n("5cd4")), L = a(n("2c8b")), D = p(n("7622")), k = a(n("219f")), C = a(n("f169")), M = p(n("a716")), T = a(n("9587")), I = a(n("3f7f")), A = a(n("f2b3"));
            u.default.component("app-button", function() {
                n.e("components/basic-component/app-button/app-button").then(function() {
                    return resolve(n("aec9"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-form-id", function() {
                n.e("components/basic-component/app-form-id/app-form-id").then(function() {
                    return resolve(n("8ee9"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-layout", function() {
                Promise.all([ n.e("common/vendor"), n.e("components/basic-component/app-layout/app-layout") ]).then(function() {
                    return resolve(n("0b17"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-input", function() {
                n.e("components/basic-component/app-input/app-input").then(function() {
                    return resolve(n("75e2"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-jump-button", function() {
                n.e("components/basic-component/app-jump-button/app-jump-button").then(function() {
                    return resolve(n("b362"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-load-text", function() {
                n.e("components/basic-component/app-load-text/app-load-text").then(function() {
                    return resolve(n("cae62"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-image", function() {
                n.e("components/basic-component/app-image/app-image").then(function() {
                    return resolve(n("f54c"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-member-price", function() {
                n.e("components/page-component/app-member-mark/app-member-price").then(function() {
                    return resolve(n("dd88"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.component("app-sup-vip", function() {
                n.e("components/page-component/app-sup-vip/app-sup-vip").then(function() {
                    return resolve(n("348c"));
                }.bind(null, n)).catch(n.oe);
            }), u.default.use({
                install: function(e, t) {
                    e.prototype.$appVersion = f.default, e.prototype.$store = l.default, e.prototype.$platform = b.platform, 
                    e.prototype.$api = y.default, e.prototype.$request = d.default, e.prototype.$storage = g, 
                    e.prototype.$user = m.default, e.prototype.$mallConfig = h.default, e.prototype.$utils = v, 
                    e.prototype.$const = $.default, e.prototype.$event = j.default, e.prototype.$showLoading = O.default, 
                    e.prototype.$hideLoading = S.default, e.prototype.$platDiff = w.default, e.prototype.$lazyLoadingData = P.default, 
                    e.prototype.$jump = _.default, e.prototype.$popupAd = x.default, e.prototype.$subscribe = q.default, 
                    e.prototype.$appScene = 1001, e.prototype.$validation = L.default, e.prototype.$tips = M, 
                    e.prototype.$commonLoad = D, e.prototype.$shareAppMessage = C.default, e.prototype.$goodsRemind = T.default, 
                    e.prototype.$zjhj = A.default, e.prototype.$shareTimeline = k.default;
                }
            }), u.default.use(I.default), u.default.config.productionTip = !1, s.default.mpType = "app", 
            t(new u.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(o), !0).forEach(function(t) {
                        i(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : c(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }({
                store: l.default
            }, s.default))).$mount();
        }).call(this, n("543d").createApp);
    },
    "58b6": function(e, t) {
        e.exports = require("../version.js");
    },
    "5c0b": function(e, t, o) {
        var n = o("a102");
        o.n(n).a;
    },
    a102: function(e, t, o) {},
    ae58: function(e, t) {
        e.exports = require("../siteinfo.js");
    },
    e4a4: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = {
            globalData: function() {
                return {
                    stystem: {},
                    text: ""
                };
            },
            onLaunch: function(e) {
                console.log("app onLaunch---\x3e"), console.log(e), console.log("<---app onLaunch"), 
                e && e.scene && (this.$appScene = e.scene, this.$store.commit("gConfig/setScene", e.scene)), 
                this.$store.dispatch("mallConfig/actionGetConfig");
                var t = this;
                wx.getSystemInfo({
                    success: function(e) {
                        t.$store.dispatch("gConfig/setSystemInfo", e), t.$store.dispatch("iPhoneX/setIphone", e);
                    }
                }), "1011" != e.scene && "1012" != e.scene && "1013" != e.scene && "1047" != e.scene && "1048" != e.scene && "1049" != e.scene || this.$store.dispatch("page/actionSetIsScanQrCode", !0), 
                e.query && void 0 !== e.query.user_id && this.$store.dispatch("user/setTempParentId", e.query.user_id), 
                this.$store.dispatch("userCenter/data");
            },
            onShow: function(e) {
                var t = this;
                console.log("app onShow---\x3e"), console.log(e), console.log("<---app onShow"), 
                e && e.scene && (this.$appScene = e.scene, this.$store.commit("gConfig/setScene", e.scene)), 
                e.query && void 0 !== e.query.scene ? "share" === e.query.scene ? (this.share(e.query), 
                this.$user.silentLogin()) : this.qrcode(e.query).then(function(e) {
                    t.$user.silentLogin();
                }) : this.$user.silentLogin();
            },
            methods: {
                share: function(e) {
                    var t, o = this, n = this.$storage.getStorageSync("INDEX_MALL").home_pages || {};
                    void 0 !== e.params && ("/pages/index/index" != (t = JSON.parse(e.params)).path || void 0 !== t.page_id && t.page_id != n.id && 0 != t.page_id) && setTimeout(function() {
                        o.$jump({
                            url: t.path + "?" + o.$utils.objectToUrlParams(t),
                            open_type: "navigate"
                        });
                    });
                },
                qrcode: function(e) {
                    var t = this;
                    return new Promise(function(o, n) {
                        t.$request({
                            url: t.$api.default.qrcode_parameter,
                            data: {
                                token: e.scene
                            }
                        }).then(function(e) {
                            if (0 === e.code) {
                                t.$store.dispatch("page/actionSetQeury", null);
                                var r = e.data.detail, p = r.data, a = r.path, c = "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin" == a ? "".concat(a) : "/".concat(a);
                                p && (c += "?" + t.$utils.objectToUrlParams(p), void 0 !== p.user_id && t.$store.dispatch("user/setTempParentId", p.user_id)), 
                                o(p), ("/pages/index/index" != "/".concat(a) || void 0 !== p.page_id && 0 != p.page_id) && (t.delHistory(), 
                                t.$jump({
                                    url: c,
                                    open_type: "navigate"
                                }));
                            } else n(e.msg);
                        }).catch(function(e) {
                            n(e);
                        });
                    });
                },
                delHistory: function() {}
            }
        };
        t.default = n;
    }
}, [ [ "56d7", "common/runtime", "common/vendor" ] ] ]);