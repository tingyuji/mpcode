(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-rich/components/wxParseTemplate1" ], {
    "1c24": function(n, e, o) {
        o.r(e);
        var t = o("67cf"), c = o("4ea4");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return c[n];
            });
        }(a);
        var r = o("f0c5"), p = Object(r.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = p.exports;
    },
    "4ea4": function(n, e, o) {
        o.r(e);
        var t = o("647f"), c = o.n(t);
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        e.default = c.a;
    },
    "647f": function(n, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var t = {
            name: "wxParseTemplate1",
            props: {
                node: {},
                parentNode: {}
            },
            components: {
                wxParseTemplate: function() {
                    Promise.resolve().then(function() {
                        return resolve(o("8085"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseImg: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/basic-component/app-rich/components/wxParseImg") ]).then(function() {
                        return resolve(o("50a5"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseVideo: function() {
                    o.e("components/basic-component/app-rich/components/wxParseVideo").then(function() {
                        return resolve(o("b9a8"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseAudio: function() {
                    o.e("components/basic-component/app-rich/components/wxParseAudio").then(function() {
                        return resolve(o("d2fa5"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseTable: function() {
                    o.e("components/basic-component/app-rich/components/wxParseTable").then(function() {
                        return resolve(o("7194"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            methods: {
                wxParseATap: function(n, e) {
                    var o = e.currentTarget.dataset.href;
                    if (o) {
                        for (var t = this.$parent; !t.preview || "function" != typeof t.preview; ) t = t.$parent;
                        t.navigate(o, e, n);
                    }
                }
            }
        };
        e.default = t;
    },
    "67cf": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return c;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-rich/components/wxParseTemplate1-create-component", {
    "components/basic-component/app-rich/components/wxParseTemplate1-create-component": function(n, e, o) {
        o("543d").createComponent(o("1c24"));
    }
}, [ [ "components/basic-component/app-rich/components/wxParseTemplate1-create-component" ] ] ]);