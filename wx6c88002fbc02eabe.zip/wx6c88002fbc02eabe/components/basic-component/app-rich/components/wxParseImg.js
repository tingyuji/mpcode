(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-rich/components/wxParseImg" ], {
    "156b": function(e, t, n) {
        var r = n("178f");
        n.n(r).a;
    },
    "178f": function(e, t, n) {},
    "200e": function(e, t, n) {
        (function(e) {
            function r(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? r(Object(n), !0).forEach(function(t) {
                        o(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function o(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n("2f62"), c = {
                name: "wxParseImg",
                data: function() {
                    return {
                        style: "",
                        preview: !0
                    };
                },
                props: {
                    node: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    parentNode: {}
                },
                computed: i(i({
                    newStyleStr: function() {
                        return this.parentNode && this.parentNode.styleStr && this.parentNode.styleStr.indexOf("text-align: center") > -1 ? this.style += "margin: 0 auto" : this.style += "margin: 0", 
                        this.style;
                    }
                }, (0, a.mapState)("gConfig", {
                    windowWidth: function(e) {
                        return e.imageWidth;
                    }
                })), {}, {
                    newNode: function() {
                        return this.node;
                    }
                }),
                methods: {
                    wxParseImgTap: function(e) {
                        if (this.preview) {
                            var t = e.currentTarget.dataset.src;
                            if (t) {
                                for (var n = this.$parent; !n.preview || "function" != typeof n.preview; ) n = n.$parent;
                                n.preview(t, e);
                            }
                        }
                    },
                    wxParseImgLoad: function(e) {
                        var t = this;
                        if (e.currentTarget.dataset.src) {
                            var n = e.mp.detail, r = n.width, i = n.height, o = this.wxAutoImageCal(r, i), a = o.imageheight, c = o.imageWidth, p = this.newNode.attr, u = p.padding, s = p.mode, f = p.paddinglimit, d = this.newNode.styleStr;
                            f && "100%" === c && (a = a * (750 - f) / 750);
                            var l = "widthFix" === s ? "" : "height: ".concat(a, "px;");
                            this.$nextTick().then(function() {
                                t.style = "".concat(d || null, "; ").concat(l, "; width: ").concat(c, "; padding: 0 ").concat(+u, "px;display:block;");
                            });
                        }
                    },
                    wxAutoImageCal: function(t, n) {
                        var r = this.windowWidth, i = {};
                        if (t < 60 || n < 60) {
                            for (var o = this.newNode.attr.src, a = this.$parent; !a.preview || "function" != typeof a.preview; ) a = a.$parent;
                            a.removeImageUrl(o), this.preview = !1;
                        }
                        return i.imageWidth = t, i.imageheight = n, t > r ? (i.imageWidth = "100%", i.imageheight = r * (e.upx2px(n) / e.upx2px(t))) : (i.imageWidth = "".concat(e.upx2px(t), "px"), 
                        i.imageheight = e.upx2px(n)), i;
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    "50a5": function(e, t, n) {
        n.r(t);
        var r = n("8a98"), i = n("93a7");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("156b");
        var a = n("f0c5"), c = Object(a.a)(i.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = c.exports;
    },
    "8a98": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, i = [];
    },
    "93a7": function(e, t, n) {
        n.r(t);
        var r = n("200e"), i = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = i.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-rich/components/wxParseImg-create-component", {
    "components/basic-component/app-rich/components/wxParseImg-create-component": function(e, t, n) {
        n("543d").createComponent(n("50a5"));
    }
}, [ [ "components/basic-component/app-rich/components/wxParseImg-create-component" ] ] ]);