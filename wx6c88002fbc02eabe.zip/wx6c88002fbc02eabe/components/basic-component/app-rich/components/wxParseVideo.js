(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-rich/components/wxParseVideo" ], {
    "26a1": function(n, e, o) {
        o.r(e);
        var c = o("4fec"), t = o.n(c);
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return c[n];
            });
        }(a);
        e.default = t.a;
    },
    "4fec": function(n, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = {
            name: "wxParseVideo",
            props: {
                node: {}
            }
        };
        e.default = c;
    },
    b9a8: function(n, e, o) {
        o.r(e);
        var c = o("dc89"), t = o("26a1");
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        var r = o("f0c5"), p = Object(r.a)(t.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        e.default = p.exports;
    },
    dc89: function(n, e, o) {
        o.d(e, "b", function() {
            return c;
        }), o.d(e, "c", function() {
            return t;
        }), o.d(e, "a", function() {});
        var c = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, t = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-rich/components/wxParseVideo-create-component", {
    "components/basic-component/app-rich/components/wxParseVideo-create-component": function(n, e, o) {
        o("543d").createComponent(o("b9a8"));
    }
}, [ [ "components/basic-component/app-rich/components/wxParseVideo-create-component" ] ] ]);