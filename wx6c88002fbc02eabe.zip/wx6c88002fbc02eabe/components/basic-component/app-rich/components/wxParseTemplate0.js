(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-rich/components/wxParseTemplate0" ], {
    "29f3": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return c;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    },
    8085: function(n, e, o) {
        o.r(e);
        var t = o("29f3"), c = o("f75e");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return c[n];
            });
        }(a);
        var r = o("f0c5"), p = Object(r.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = p.exports;
    },
    "9cc2": function(n, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var t = {
            name: "wxParseTemplate0",
            props: {
                node: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                parentNode: {}
            },
            components: {
                "we-parse-template-1": function() {
                    o.e("components/basic-component/app-rich/components/wxParseTemplate1").then(function() {
                        return resolve(o("1c24"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseImg: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/basic-component/app-rich/components/wxParseImg") ]).then(function() {
                        return resolve(o("50a5"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseVideo: function() {
                    o.e("components/basic-component/app-rich/components/wxParseVideo").then(function() {
                        return resolve(o("b9a8"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseAudio: function() {
                    o.e("components/basic-component/app-rich/components/wxParseAudio").then(function() {
                        return resolve(o("d2fa5"));
                    }.bind(null, o)).catch(o.oe);
                },
                wxParseTable: function() {
                    o.e("components/basic-component/app-rich/components/wxParseTable").then(function() {
                        return resolve(o("7194"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            methods: {
                wxParseATap: function(n, e) {
                    var o = e.currentTarget.dataset.href;
                    if (o) {
                        for (var t = this.$parent; !t.preview || "function" != typeof t.preview; ) t = t.$parent;
                        t.navigate(o, e, n);
                    }
                }
            }
        };
        e.default = t;
    },
    f75e: function(n, e, o) {
        o.r(e);
        var t = o("9cc2"), c = o.n(t);
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        e.default = c.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-rich/components/wxParseTemplate0-create-component", {
    "components/basic-component/app-rich/components/wxParseTemplate0-create-component": function(n, e, o) {
        o("543d").createComponent(o("8085"));
    }
}, [ [ "components/basic-component/app-rich/components/wxParseTemplate0-create-component" ] ] ]);