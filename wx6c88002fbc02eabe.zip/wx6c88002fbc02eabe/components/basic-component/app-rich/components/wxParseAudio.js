(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-rich/components/wxParseAudio" ], {
    3415: function(n, o, e) {
        e.d(o, "b", function() {
            return c;
        }), e.d(o, "c", function() {
            return t;
        }), e.d(o, "a", function() {});
        var c = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, t = [];
    },
    d2fa5: function(n, o, e) {
        e.r(o);
        var c = e("3415"), t = e("fcf3");
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(a);
        var r = e("f0c5"), u = Object(r.a)(t.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        o.default = u.exports;
    },
    dc53: function(n, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var c = {
            name: "wxParseAudio",
            props: {
                node: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            }
        };
        o.default = c;
    },
    fcf3: function(n, o, e) {
        e.r(o);
        var c = e("dc53"), t = e.n(c);
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(o, n, function() {
                return c[n];
            });
        }(a);
        o.default = t.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-rich/components/wxParseAudio-create-component", {
    "components/basic-component/app-rich/components/wxParseAudio-create-component": function(n, o, e) {
        e("543d").createComponent(e("d2fa5"));
    }
}, [ [ "components/basic-component/app-rich/components/wxParseAudio-create-component" ] ] ]);