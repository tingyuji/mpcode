(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-tab-bar/app-tab-bar" ], {
    "1d56": function(t, e, n) {
        n.r(e);
        var a = n("d84f"), r = n("ef0f");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        n("8db21");
        var c = n("f0c5"), i = Object(c.a)(r.default, a.b, a.c, !1, null, "b0a91532", null, !1, a.a, void 0);
        e.default = i.exports;
    },
    "59e8": function(t, e, n) {},
    "7dee": function(t, e, n) {
        function a(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(t);
                e && (a = a.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, a);
            }
            return n;
        }
        function r(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? a(Object(n), !0).forEach(function(e) {
                    o(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function o(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = n("2f62"), i = {
            data: function() {
                return {
                    router: ""
                };
            },
            props: {
                pageCount: Number
            },
            computed: r(r(r({}, (0, c.mapGetters)("iPhoneX", {
                botNavHei: "getNavHei"
            })), (0, c.mapState)("mallConfig", {
                bottom_background_color: function(t) {
                    return t.navbar.bottom_background_color;
                },
                tabBarNavs: function(t) {
                    return t.navbar;
                }
            })), {}, {
                boxShadow: function() {
                    if (this.tabBarNavs.highlight_shadow) {
                        var t = this.hexToRgb(this.tabBarNavs.highlight_shadow, .3);
                        return "0rpx 4rpx 12rpx ".concat(t);
                    }
                    return "";
                },
                isShowBgImg: function() {
                    var t = this.tabBarNavs;
                    return 1 == t.nav_mode && 2 == t.background_type || 2 == t.nav_mode && (3 === t.navs.length || 5 == t.navs.length);
                },
                isShowShadow: function() {
                    var t = this.tabBarNavs;
                    return !!t.shadow && (1 == t.nav_mode && 1 == t.background_type || 2 == t.nav_mode && 3 !== t.navs.length && 5 !== t.navs.length);
                }
            }),
            created: function() {
                this.router = this.$platDiff.tabBarUrl(null, this.pageCount);
            },
            watch: {},
            methods: {
                hexToRgb: function(t, e) {
                    return "rgba(" + parseInt("0x" + t.slice(1, 3)) + "," + parseInt("0x" + t.slice(3, 5)) + "," + parseInt("0x" + t.slice(5, 7)) + "," + e + ")";
                }
            }
        };
        e.default = i;
    },
    "8db21": function(t, e, n) {
        var a = n("59e8");
        n.n(a).a;
    },
    d84f: function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var a = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, r = [];
    },
    ef0f: function(t, e, n) {
        n.r(e);
        var a = n("7dee"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-tab-bar/app-tab-bar-create-component", {
    "components/basic-component/app-tab-bar/app-tab-bar-create-component": function(t, e, n) {
        n("543d").createComponent(n("1d56"));
    }
}, [ [ "components/basic-component/app-tab-bar/app-tab-bar-create-component" ] ] ]);