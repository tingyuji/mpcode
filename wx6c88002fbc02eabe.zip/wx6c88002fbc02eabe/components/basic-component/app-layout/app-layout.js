(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-layout/app-layout" ], {
    "0b17": function(t, o, n) {
        n.r(o);
        var e = n("cd082"), r = n("6adc");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(o, t, function() {
                return r[t];
            });
        }(i);
        n("453b");
        var a = n("f0c5"), c = Object(a.a)(r.default, e.b, e.c, !1, null, "256bc2b6", null, !1, e.a, void 0);
        o.default = c.exports;
    },
    "1db5": function(t, o, n) {
        (function(t) {
            function e(t, o) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var e = Object.getOwnPropertySymbols(t);
                    o && (e = e.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(t, o).enumerable;
                    })), n.push.apply(n, e);
                }
                return n;
            }
            function r(t) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? e(Object(n), !0).forEach(function(o) {
                        i(t, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : e(Object(n)).forEach(function(o) {
                        Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return t;
            }
            function i(t, o, n) {
                return o in t ? Object.defineProperty(t, o, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[o] = n, t;
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = n("2f62"), c = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("ff69")), u = [ "/pages/binding/binding", "/pages/binding/manual_binding", "/pages/setting/setting", "/pages/setting/edit", "/pages/address/address" ], s = {
                name: "app-layout",
                data: function() {
                    return {
                        currentRoute: "",
                        tabbarbool: !0,
                        navigationBarTitle: "",
                        page_count: getCurrentPages().length,
                        isAttention: !1
                    };
                },
                components: {
                    appPoliteModal: function() {
                        n.e("components/basic-component/app-layout/app-polite-modal").then(function() {
                            return resolve(n("804b"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appNewcomersModal: function() {
                        n.e("components/basic-component/app-layout/app-newcomers-modal").then(function() {
                            return resolve(n("3b53"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-tab-bar": function() {
                        n.e("components/basic-component/app-tab-bar/app-tab-bar").then(function() {
                            return resolve(n("1d56"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-payment": function() {
                        n.e("components/basic-component/app-layout/app-payment/app-payment").then(function() {
                            return resolve(n("bb6d"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-user-login": function() {
                        n.e("components/basic-component/app-layout/app-user-login/app-user-login").then(function() {
                            return resolve(n("ce0f"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-loading": function() {
                        n.e("components/basic-component/app-loading/app-loading").then(function() {
                            return resolve(n("2428"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-report-error": function() {
                        n.e("components/basic-component/app-report-error/app-report-error").then(function() {
                            return resolve(n("1031"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-prompt-box": function() {
                        n.e("components/basic-component/app-prompt-box/app-prompt-box").then(function() {
                            return resolve(n("387a"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    "app-coupon-modal": function() {
                        n.e("components/basic-component/app-layout/app-coupon-modal/app-coupon-modal").then(function() {
                            return resolve(n("a3b2"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    haveBackground: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    overflow: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    isOverflowHidden: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    top_color: {
                        type: String
                    },
                    extraTheme: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    confirmText: {
                        type: String,
                        default: function() {
                            return "提交订单";
                        }
                    }
                },
                computed: r(r(r(r(r(r(r({}, (0, a.mapState)("mallConfig", {
                    tabBarNavs: function(t) {
                        return t.navbar.navs;
                    },
                    bar_title: function(t) {
                        return t.bar_title;
                    },
                    top_background_color: function(t) {
                        return t.navbar.top_background_color;
                    },
                    top_text_color: function(t) {
                        return t.navbar.top_text_color;
                    },
                    bottom_background_color: function(t) {
                        return t.navbar.bottom_background_color;
                    },
                    is_must_login: function(t) {
                        return t.mall.setting.is_must_login;
                    },
                    is_mobile_auth: function(t) {
                        return t.mall.setting.is_mobile_auth;
                    }
                })), (0, a.mapState)("user", {
                    accessToken: function(t) {
                        return t.accessToken;
                    }
                })), (0, a.mapState)("gConfig", {
                    reportAndError: function(t) {
                        return t.reportAndError;
                    },
                    promptBox: function(t) {
                        return t.promptBox;
                    },
                    iphone: function(t) {
                        return t.iphone;
                    }
                })), {}, {
                    isGuest: function() {
                        return "" === this.$store.state.user.accessToken || null === this.$store.state.user.accessToken;
                    }
                }, (0, a.mapState)("loading", {
                    loadingType: function(t) {
                        return t.type;
                    },
                    loadingText: function(t) {
                        return t.text;
                    },
                    loadingColor: function(t) {
                        return t.color;
                    },
                    loadingBackgroundImage: function(t) {
                        return t.backgroundImage;
                    },
                    loadingIsShow: function(t) {
                        return t.isShow;
                    }
                })), (0, a.mapGetters)("iPhoneX", {
                    BotHeight: "getBotHeight",
                    getNavHei: "getNavHei"
                })), (0, a.mapGetters)({
                    userInfo: "user/info"
                })), {}, {
                    layoutStyle: function() {
                        return this.overflow && this.isOverflowHidden ? {
                            overflow: "hidden"
                        } : "";
                    },
                    isShowBinding: function() {
                        return !this.isGuest && 1 == this.is_mobile_auth && this.userInfo && this.$validation.isEmpty(this.userInfo.mobile);
                    }
                }),
                watch: {
                    tabBarNavs: {
                        handler: function() {
                            this.setTabbar(), (void 0 !== this.top_background_color || this.top_color) && t.setNavigationBarColor({
                                backgroundColor: this.top_color ? this.top_color : this.top_background_color,
                                frontColor: this.top_color ? "#ffffff" : this.top_text_color
                            });
                        },
                        immediate: !0
                    },
                    top_color: {
                        handler: function(o) {
                            (void 0 !== this.top_background_color || this.top_color) && t.setNavigationBarColor({
                                backgroundColor: this.top_color ? this.top_color : this.top_background_color,
                                frontColor: this.top_color ? "#ffffff" : this.top_text_color
                            });
                        }
                    },
                    isShowBinding: {
                        handler: function(o, n) {
                            var e = this, r = this.$storage.getStorageSync("hideBinding");
                            if (o && o !== n && !r) {
                                var i = this.$platDiff.route();
                                -1 === u.indexOf(i) && (this.$storage.setStorageSync("hideBinding", !0), t.navigateTo({
                                    url: "/pages/binding/binding"
                                }), setTimeout(function() {
                                    e.$storage.setStorageSync("hideBinding", !1);
                                }, 3e3));
                            }
                        },
                        immediate: !0
                    },
                    tabbarbool: {
                        handler: function(t) {
                            this.$emit("toTabbarbool", this.tabbarbool);
                        },
                        immediate: !0
                    }
                },
                created: function() {
                    console.log("--app layout created -- "), this.$store.dispatch("mallConfig/actionGetConfig"), 
                    !this.$user.isLogin() && 1 !== this.is_must_login || "/pages/disabled/disabled" == this.$platDiff.route() || this.$store.dispatch("user/info"), 
                    this.$hideLoading();
                },
                mounted: function() {
                    try {
                        var o = getCurrentPages();
                        if (o.length) {
                            var n = o[o.length - 1].options, e = {};
                            void 0 !== n.custom_params && (e = JSON.parse(decodeURIComponent(n.custom_params))), 
                            void 0 !== n.user_id ? this.$store.dispatch("user/setTempParentId", n.user_id) : void 0 !== e.user_id && this.$store.dispatch("user/setTempParentId", e.user_id);
                        }
                    } catch (t) {}
                    console.log("--app layout mounted -- "), this.currentRoute = this.$platDiff.tabBarUrl(null, this.page_count), 
                    this.setTabbar(), this.setTitle(), (void 0 !== this.top_background_color || this.top_color) && t.setNavigationBarColor({
                        backgroundColor: this.top_color ? this.top_color : this.top_background_color,
                        frontColor: this.top_color ? "#ffffff" : this.top_text_color
                    });
                },
                beforeDestroy: function() {
                    this.$hideLoading();
                },
                methods: {
                    touchMove: function() {
                        return !0;
                    },
                    setTabbar: function() {
                        console.log();
                        var t = this.currentRoute;
                        console.log(t), this.$appScene && [ 1001, 1045, 1046, 1058, 1067, 1084, 1091, 1119, 1120, 1121, 1048, 1107, 1104 ].indexOf(this.$appScene) > -1 && (t.indexOf("appid") > -1 || t.indexOf("appmsg_compact_url") > -1 || t.indexOf("wxwork_userid") > -1 || t.indexOf("weixinadinfo") > -1 || t.indexOf("gdt_vid") > -1 || t.indexOf("wxwwork_userid") > -1 || t.indexOf("qr_code_id") > -1 || t.indexOf("out_trade_no") > -1 || t.indexOf("transaction_id") > -1) && (t = this.$utils.deleteUrlParam(t, [ "appid", "appmsg_compact_url", "wxwork_userid", "weixinadinfo", "gdt_vid", "wxwwork_userid", "qr_code_id", "out_trade_no", "transaction_id" ], !1));
                        for (var o = 0; o < this.tabBarNavs.length; o++) if (t == this.tabBarNavs[o].url) return this.tabbarbool = !0;
                        return this.tabbarbool = !1;
                    },
                    setTitle: function() {
                        var t = this, o = this.$platDiff.route(), n = this.bar_title || [];
                        c.default.setNavigationBarTitle(n, o).then(function(n) {
                            "/pages/article/article-detail/article-detail" != o && (t.navigationBarTitle = n);
                        });
                    }
                }
            };
            o.default = s;
        }).call(this, n("543d").default);
    },
    "2ac1": function(t, o, n) {},
    "453b": function(t, o, n) {
        var e = n("2ac1");
        n.n(e).a;
    },
    "6adc": function(t, o, n) {
        n.r(o);
        var e = n("1db5"), r = n.n(e);
        for (var i in e) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(o, t, function() {
                return e[t];
            });
        }(i);
        o.default = r.a;
    },
    cd082: function(t, o, n) {
        n.d(o, "b", function() {
            return e;
        }), n.d(o, "c", function() {
            return r;
        }), n.d(o, "a", function() {});
        var e = function() {
            var t = this, o = (t.$createElement, t._self._c, t.__get_style([ t.layoutStyle ]));
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: o
                }
            });
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-layout/app-layout-create-component", {
    "components/basic-component/app-layout/app-layout-create-component": function(t, o, n) {
        n("543d").createComponent(n("0b17"));
    }
}, [ [ "components/basic-component/app-layout/app-layout-create-component" ] ] ]);