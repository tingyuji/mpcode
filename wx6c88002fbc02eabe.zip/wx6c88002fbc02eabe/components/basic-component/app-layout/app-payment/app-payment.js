(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-layout/app-payment/app-payment" ], {
    "371e": function(t, e, a) {
        a.d(e, "b", function() {
            return s;
        }), a.d(e, "c", function() {
            return n;
        }), a.d(e, "a", function() {});
        var s = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(e) {
                t.setPassword = !t.setPassword, t.password = "";
            }, t.e1 = function(e) {
                t.printPassword = !1, t.setPassword = !1, t.verifyPassword = !1;
            }, t.e2 = function(e) {
                t.getFocus = !1;
            });
        }, n = [];
    },
    6643: function(t, e, a) {
        (function(t) {
            function s(t, e) {
                var a = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!a) {
                    if (Array.isArray(t) || (a = n(t)) || e && t && "number" == typeof t.length) {
                        a && (t = a);
                        var s = 0, o = function() {};
                        return {
                            s: o,
                            n: function() {
                                return s >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[s++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: o
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var r, i = !0, p = !1;
                return {
                    s: function() {
                        a = a.call(t);
                    },
                    n: function() {
                        var t = a.next();
                        return i = t.done, t;
                    },
                    e: function(t) {
                        p = !0, r = t;
                    },
                    f: function() {
                        try {
                            i || null == a.return || a.return();
                        } finally {
                            if (p) throw r;
                        }
                    }
                };
            }
            function n(t, e) {
                if (t) {
                    if ("string" == typeof t) return o(t, e);
                    var a = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === a && t.constructor && (a = t.constructor.name), "Map" === a || "Set" === a ? Array.from(t) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? o(t, e) : void 0;
                }
            }
            function o(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var a = 0, s = new Array(e); a < e; a++) s[a] = t[a];
                return s;
            }
            function r(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var s = Object.getOwnPropertySymbols(t);
                    e && (s = s.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), a.push.apply(a, s);
                }
                return a;
            }
            function i(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? r(Object(a), !0).forEach(function(e) {
                        p(t, e, a[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : r(Object(a)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e));
                    });
                }
                return t;
            }
            function p(t, e, a) {
                return e in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var c = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(a("66fd")), y = a("2f62"), l = "", u = {
                name: "app-payment",
                components: {
                    AppRadio: function() {
                        a.e("components/basic-component/app-radio/app-radio").then(function() {
                            return resolve(a("3ac8"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                props: {
                    extraTheme: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    confirmText: {
                        type: String,
                        default: function() {
                            return "提交订单";
                        }
                    }
                },
                computed: i(i(i({}, (0, y.mapState)({
                    mall: function(t) {
                        return t.mallConfig.mall;
                    },
                    userInfo: function(t) {
                        return t.user.info;
                    },
                    showPayment: function(t) {
                        return t.payment.showPayment;
                    },
                    payData: function(t) {
                        return t.payment.payData;
                    }
                })), (0, y.mapGetters)("mallConfig", {
                    getTheme: "getTheme"
                })), {}, {
                    theme: function() {
                        return i(i({}, this.getTheme), this.extraTheme);
                    }
                }),
                data: function() {
                    return {
                        is_need_pay_password: 0,
                        haveFocus: !1,
                        getFocus: !1,
                        printPassword: !1,
                        setPassword: !1,
                        verifyPassword: !1,
                        password: "",
                        verify_pay_password: "",
                        pay_password: "",
                        payPassword: ""
                    };
                },
                created: function() {
                    this.setPayment();
                },
                methods: {
                    getInputFocus: function() {
                        var t = this;
                        this.$nextTick(function() {
                            t.getFocus = !0;
                        });
                    },
                    passwordInput: function() {
                        var e = this;
                        6 == this.password.length && setTimeout(function() {
                            e.setPassword ? e.setPayPassword() : (t.showLoading({
                                mask: !0
                            }), t.hideKeyboard(), e.verifyPayPassword());
                        });
                    },
                    setPayPassword: function() {
                        var e = this;
                        if (this.password.length < 6) return !1;
                        if (this.verifyPassword) if (this.verify_pay_password = this.password.toString().substring(0, 6), 
                        this.pay_password === this.verify_pay_password) {
                            t.showLoading({
                                mask: !0
                            });
                            var a = {
                                pay_password: this.pay_password,
                                verify_pay_password: this.verify_pay_password
                            };
                            this.$request({
                                url: this.$api.member.set_password,
                                method: "post",
                                data: a
                            }).then(function(a) {
                                t.hideLoading(), 0 === a.code ? (e.payPassword = e.pay_password, e.printPassword = !1, 
                                e.setPassword = !1, e.verifyPassword = !1, e.password = "", e.pay_password = "", 
                                e.verify_pay_password = "", e.$store.commit("payment/showPayment", !1), e.payByBalance()) : (e.password = "", 
                                e.pay_password = "", e.verify_pay_password = "", t.showToast({
                                    icon: "none",
                                    title: a.msg
                                }));
                            });
                        } else this.verifyPassword = !1, this.password = "", this.pay_password = "", this.verify_pay_password = "", 
                        t.showToast({
                            icon: "none",
                            title: "两次输入的密码不一致"
                        }); else this.pay_password = this.password.toString().substring(0, 6), this.verifyPassword = !0, 
                        this.password = "";
                    },
                    navPay: function() {
                        this.$store.commit("payment/showPayment", !1), this.$store.state.payment.reject({
                            errMsg: "5b03b6e009796c698d132908cb635fca"
                        }), t.navigateTo({
                            url: "/pages/balance/recharge"
                        });
                    },
                    setPayment: function() {
                        var t = this;
                        c.default.use({
                            install: function(e, a) {
                                e.prototype.$payment = {
                                    pay: t.pay
                                };
                            }
                        });
                    },
                    pay: function(e) {
                        var a = this, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
                        return l = o, new Promise(function(o, r) {
                            a.$store.commit("payment/setAll", {
                                showPayment: !1,
                                payData: null,
                                payType: null,
                                id: e,
                                resolve: o,
                                reject: r
                            }), console.log("debug payment, setAll ok, id:", a.$store.state.payment.id), console.log("debug payment, setAll ok, resolve:", a.$store.state.payment.resolve), 
                            console.log("debug payment, setAll ok, reject:", a.$store.state.payment.reject), 
                            t.showLoading({
                                mask: !0,
                                title: "请求支付..."
                            }), a.$request({
                                url: s || a.$api.payment.get_payments,
                                data: i({
                                    id: e
                                }, n)
                            }).then(function(e) {
                                return t.hideLoading(), console.log("debug 1---\x3e", e), 0 === e.code ? (console.log("debug payment, set resolve 2,", a.$store.state.payment.resolve), 
                                a.showPaymentModal(e.data)) : (e.errMsg = e.msg || "", a.$store.state.payment.reject(e.msg));
                            }).catch(function(e) {
                                return t.hideLoading(), e.errMsg = e.msg || "", a.$store.state.payment.reject(e);
                            });
                        });
                    },
                    showPaymentModal: function(t) {
                        for (var e in console.log("debug 2---\x3e", t), t.list) void 0 === t.list[e].checked && (t.list[e].checked = !1);
                        if (this.$store.commit("payment/payData", t), 0 !== t.amount && 0 !== t.amount && "0" !== t.amount && "0.00" !== t.amount) this.$store.commit("payment/showPayment", !0); else {
                            for (var a in this.$store.commit("payment/payType", "balance"), this.$store.state.payment.payData.list) "balance" === this.$store.state.payment.payData.list[a].key ? this.$store.state.payment.payData.list[a].checked = !0 : this.$store.state.payment.payData.list[a].checked = !1;
                            this.confirm();
                        }
                    },
                    confirm: function() {
                        for (var e in console.log("payment confirm 1:"), console.log("debug payment, confirm 1,", this.$store.state.payment.resolve), 
                        this.$store.state.payment.payData.list) this.$store.state.payment.payData.list[e].checked && this.$store.commit("payment/payType", this.$store.state.payment.payData.list[e].key);
                        if (this.$store.state.payment.payType) return this.$store.commit("payment/showPayment", !1), 
                        console.log("payment confirm 2:", this.$store.state.payment.payType), console.log("debug payment, confirm 2,", this.$store.state.payment.resolve), 
                        "customers_order" === l ? void t.$emit("pay") : this.getPayData();
                        t.showModal({
                            title: "提示",
                            content: "请选择支付方式",
                            showCancel: !1
                        });
                    },
                    cancel: function() {
                        return this.$store.commit("payment/showPayment", !1), this.$store.state.payment.reject({
                            errMsg: "支付取消"
                        });
                    },
                    checkPayType: function(t) {
                        if (this.$store.state.payment.payData.list[t].disabled || this.$store.state.payment.payData.list[t].checked) return !1;
                        var e = this.$store.state.payment.payData;
                        for (var a in e.list) e.list[a].checked = a == t;
                        this.$store.commit("payment/payData", e);
                    },
                    getPayData: function() {
                        var e = this;
                        console.log("debug payment, getPayData 1,", this.$store.state.payment.resolve), 
                        t.showLoading({
                            mask: !0,
                            title: "请求支付..."
                        });
                        var a = {
                            id: this.$store.state.payment.id,
                            pay_type: this.$store.state.payment.payType
                        };
                        this.$request({
                            url: this.$api.payment.pay_data,
                            data: a
                        }).then(function(a) {
                            if (t.hideLoading(), 0 !== a.code) return e.$store.state.payment.reject(a.msg);
                            switch (e.$store.state.payment.payType) {
                              case "balance":
                                e.callBranch(a.data);
                                break;

                              case "huodao":
                                e.callHuodao(a.data);
                                break;

                              default:
                                console.log("debug payment, getPayData 2,", e.$store.state.payment.resolve), e.callPlatformPayment(a.data);
                            }
                        }).catch(function(a) {
                            return t.hideLoading(), a.errMsg = a.msg || "", e.$store.state.payment.reject(a);
                        });
                    },
                    callBranch: function(e) {
                        var a = this;
                        0 === e.order_amount || 0 === e.order_amount || "0" === e.order_amount || "0.00" === e.order_amount ? this.payByBalance() : t.showModal({
                            title: "余额支付确认",
                            content: "账户余额：".concat(e.balance_amount, "，支付金额：").concat(e.order_amount),
                            success: function(t) {
                                if (!t.confirm) return a.$store.state.payment.reject({
                                    errMsg: "支付取消"
                                });
                                var e, n = s(a.payData.list);
                                try {
                                    for (n.s(); !(e = n.n()).done; ) {
                                        var o = e.value;
                                        if ("balance" == o.key) {
                                            1 == o.is_open_pay_password ? (a.payPassword = "", a.is_need_pay_password = o.is_pay_password, 
                                            a.password = "", a.$store.commit("payment/showPayment", !0), a.printPassword = !0, 
                                            setTimeout(function() {
                                                a.getFocus = !0;
                                            }, 800)) : a.payByBalance();
                                            break;
                                        }
                                    }
                                } catch (t) {
                                    n.e(t);
                                } finally {
                                    n.f();
                                }
                            }
                        });
                    },
                    verifyPayPassword: function() {
                        var e = this;
                        if (this.password.length < 6) return !1;
                        this.payPassword = this.password.toString().substring(0, 6), this.$request({
                            url: this.$api.member.verify_password,
                            data: {
                                pay_password: this.payPassword
                            },
                            method: "post"
                        }).then(function(a) {
                            e.password = "", t.hideLoading(), 0 === a.code ? (e.$store.commit("payment/showPayment", !1), 
                            e.payByBalance()) : (e.password = "", e.payPassword = "", t.showModal({
                                title: "提示",
                                content: a.msg,
                                showCancel: !1
                            }));
                        }).catch(function(a) {
                            return t.hideLoading(), a.errMsg = a.msg || "", e.$store.state.payment.reject(a);
                        });
                    },
                    payByBalance: function() {
                        var e = this;
                        t.showLoading({
                            mask: !0,
                            title: "支付中..."
                        });
                        var a = {
                            id: this.$store.state.payment.id,
                            pay_password: this.payPassword ? this.payPassword : "",
                            is_need_pay_password: this.is_need_pay_password
                        };
                        this.$request({
                            url: this.$api.payment.pay_buy_balance,
                            data: a
                        }).then(function(a) {
                            return t.hideLoading(), 0 === a.code ? (e.$store.commit("payment/showPayment", !1), 
                            e.$store.state.payment.resolve({
                                errMsg: "支付成功"
                            })) : e.$store.state.payment.reject({
                                errMsg: a.msg
                            });
                        }).catch(function(t) {
                            return t.errMsg = t.msg || "", e.$store.state.payment.reject(t);
                        });
                    },
                    callHuodao: function() {
                        var e = this;
                        t.showLoading({
                            mask: !0,
                            title: "提交中..."
                        }), this.$request({
                            url: this.$api.payment.pay_buy_huodao,
                            data: {
                                id: this.$store.state.payment.id
                            }
                        }).then(function(a) {
                            return t.hideLoading(), 0 === a.code ? e.$store.state.payment.resolve({
                                errMsg: "支付成功"
                            }) : e.$store.state.payment.reject({
                                errMsg: a.msg
                            });
                        }).catch(function(a) {
                            return t.hideLoading(), a.errMsg = a.msg || "", e.$store.state.payment.reject(a);
                        });
                    },
                    callPlatformPayment: function(e) {
                        var a = this;
                        console.log("debug payment, callPlatformPayment 1,", this.$store.state.payment.resolve);
                        var s = null, n = i({
                            provider: s = [ "wxpay" ],
                            success: function(t) {
                                return console.log("debug payment, callPlatformPayment 3,", a.$store.state.payment.resolve), 
                                console.log("success:", t), a.$store.state.payment.resolve(t);
                            },
                            fail: function(t) {
                                var e = [ "requestPayment:fail cancel", "requestOrderPayment:fail cancel" ];
                                return t.errMsg && e.indexOf(t.errMsg) >= 0 && (t.errMsg = "取消支付"), console.log("debug payment, callPlatformPayment 4,", a.$store.state.payment.resolve), 
                                console.log("fail:", t), a.$store.state.payment.reject(t);
                            }
                        }, e);
                        void 0 !== n.orderInfo ? (console.log("requestOrderPayment"), wx.requestOrderPayment(n)) : t.requestPayment(n);
                    }
                }
            };
            e.default = u;
        }).call(this, a("543d").default);
    },
    "84be": function(t, e, a) {},
    a779: function(t, e, a) {
        a.r(e);
        var s = a("6643"), n = a.n(s);
        for (var o in s) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(e, t, function() {
                return s[t];
            });
        }(o);
        e.default = n.a;
    },
    bb6d: function(t, e, a) {
        a.r(e);
        var s = a("371e"), n = a("a779");
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(o);
        a("df46");
        var r = a("f0c5"), i = Object(r.a)(n.default, s.b, s.c, !1, null, "8a7d07f0", null, !1, s.a, void 0);
        e.default = i.exports;
    },
    df46: function(t, e, a) {
        var s = a("84be");
        a.n(s).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-layout/app-payment/app-payment-create-component", {
    "components/basic-component/app-layout/app-payment/app-payment-create-component": function(t, e, a) {
        a("543d").createComponent(a("bb6d"));
    }
}, [ [ "components/basic-component/app-layout/app-payment/app-payment-create-component" ] ] ]);