(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-layout/app-permissions-auth/app-permissions-auth" ], {
    "1c4d": function(n, t, a) {
        a.r(t);
        var e = a("69518"), o = a("8111");
        for (var p in o) [ "default" ].indexOf(p) < 0 && function(n) {
            a.d(t, n, function() {
                return o[n];
            });
        }(p);
        a("ba01");
        var c = a("f0c5"), i = Object(c.a)(o.default, e.b, e.c, !1, null, "c3b0f4c0", null, !1, e.a, void 0);
        t.default = i.exports;
    },
    69518: function(n, t, a) {
        a.d(t, "b", function() {
            return e;
        }), a.d(t, "c", function() {
            return o;
        }), a.d(t, "a", function() {});
        var e = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, o = [];
    },
    7814: function(n, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var e = {
            name: "app-permissions-auth",
            data: function() {
                return {};
            },
            props: {
                isShow: {
                    type: Boolean,
                    default: !1
                },
                text: {
                    type: String,
                    default: "请在设置中打开相应权限"
                }
            },
            methods: {
                cancel: function() {
                    this.$emit("cancel", !1);
                }
            }
        };
        t.default = e;
    },
    8111: function(n, t, a) {
        a.r(t);
        var e = a("7814"), o = a.n(e);
        for (var p in e) [ "default" ].indexOf(p) < 0 && function(n) {
            a.d(t, n, function() {
                return e[n];
            });
        }(p);
        t.default = o.a;
    },
    "8be9": function(n, t, a) {},
    ba01: function(n, t, a) {
        var e = a("8be9");
        a.n(e).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component", {
    "components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component": function(n, t, a) {
        a("543d").createComponent(a("1c4d"));
    }
}, [ [ "components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component" ] ] ]);