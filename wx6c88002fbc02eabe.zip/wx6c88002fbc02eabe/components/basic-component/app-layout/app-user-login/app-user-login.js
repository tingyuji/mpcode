(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-layout/app-user-login/app-user-login" ], {
    "1b9f": function(e, n, t) {},
    6694: function(e, n, t) {
        function o(e, n) {
            var t = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                n && (o = o.filter(function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable;
                })), t.push.apply(t, o);
            }
            return t;
        }
        function r(e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = null != arguments[n] ? arguments[n] : {};
                n % 2 ? o(Object(t), !0).forEach(function(n) {
                    c(e, n, t[n]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                    Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                });
            }
            return e;
        }
        function c(e, n, t) {
            return n in e ? Object.defineProperty(e, n, {
                value: t,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[n] = t, e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(t("66fd")), a = t("2f62"), u = {
            name: "app-user-login",
            components: {
                appHotspot: function() {
                    t.e("components/basic-component/app-hotspot/app-hotspot").then(function() {
                        return resolve(t("9c0a"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {};
            },
            computed: r(r(r({
                openType: function() {
                    return "getUserInfo";
                }
            }, (0, a.mapState)("mallConfig", {
                auth_page: function(e) {
                    return e.auth_page;
                }
            })), (0, a.mapState)({
                showLoginModal: function(e) {
                    return e.user.showLoginModal;
                }
            })), {}, {
                canIUseGetUserProfile: function() {
                    return this.$user.canIUseGetUserProfile();
                }
            }),
            created: function() {
                var e = this;
                i.default.use({
                    install: function(n, t) {
                        n.prototype.$layout = {
                            getUserInfo: function() {
                                return e.showLoginModal = !0, new Promise(function(n, t) {
                                    e.getUserInfo = function(e) {};
                                });
                            }
                        };
                    }
                });
            },
            methods: {
                link: function() {
                    this.$store.commit("user/showLoginModal", !1);
                },
                cancel: function() {
                    this.$store.commit("user/showLoginModal", !1), this.$user.getUserInfoReject("getUserInfo fail: cancel.");
                },
                getUserInfoClick: function(e) {
                    var n = this;
                    this.$user.getUserProfile(e).then(function(e) {
                        console.log(e), n.getUserInfo(e);
                    }).catch(function(e) {
                        console.log(e);
                    });
                },
                getUserInfo: function(e) {
                    var n = this;
                    this.$store.commit("user/showLoginModal", !1);
                    var t = this.$user.getUserInfoResolve, o = this.$user.getUserInfoReject;
                    return this.$event.on(this.$const.EVENT_USER_LOGIN, !0).then(function() {
                        n.$jump({
                            open_type: "reload"
                        });
                    }), "getUserInfo:ok" !== e.detail.errMsg ? (this.$store.commit("user/showLoginModal", !0), 
                    o(e.detail.errMsg)) : t(e);
                }
            }
        };
        n.default = u;
    },
    "78fc": function(e, n, t) {
        var o = t("1b9f");
        t.n(o).a;
    },
    "994a": function(e, n, t) {
        t.r(n);
        var o = t("6694"), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    },
    b1f4: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    ce0f: function(e, n, t) {
        t.r(n);
        var o = t("b1f4"), r = t("994a");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        t("78fc");
        var i = t("f0c5"), a = Object(i.a)(r.default, o.b, o.c, !1, null, "7fe988d4", null, !1, o.a, void 0);
        n.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-layout/app-user-login/app-user-login-create-component", {
    "components/basic-component/app-layout/app-user-login/app-user-login-create-component": function(e, n, t) {
        t("543d").createComponent(t("ce0f"));
    }
}, [ [ "components/basic-component/app-layout/app-user-login/app-user-login-create-component" ] ] ]);