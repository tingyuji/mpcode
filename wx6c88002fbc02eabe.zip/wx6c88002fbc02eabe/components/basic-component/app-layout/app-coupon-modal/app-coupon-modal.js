(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-layout/app-coupon-modal/app-coupon-modal" ], {
    4216: function(o, n, t) {
        (function(o) {
            function e(o, n) {
                var t = Object.keys(o);
                if (Object.getOwnPropertySymbols) {
                    var e = Object.getOwnPropertySymbols(o);
                    n && (e = e.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(o, n).enumerable;
                    })), t.push.apply(t, e);
                }
                return t;
            }
            function c(o) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? e(Object(t), !0).forEach(function(n) {
                        a(o, n, t[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(t)) : e(Object(t)).forEach(function(n) {
                        Object.defineProperty(o, n, Object.getOwnPropertyDescriptor(t, n));
                    });
                }
                return o;
            }
            function a(o, n, t) {
                return n in o ? Object.defineProperty(o, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : o[n] = t, o;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var p = {
                name: "app-coupon-modal",
                components: {
                    "app-price": function() {
                        t.e("components/page-component/goods/app-price").then(function() {
                            return resolve(t("6c9f"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {};
                },
                computed: c(c({}, (0, t("2f62").mapState)({
                    mallConfig: function(o) {
                        return o.mallConfig;
                    },
                    coupon: function(o) {
                        return o.page.coupon;
                    },
                    integralCustomer: function(o) {
                        return o.mallConfig.mall.setting.integral_customer;
                    },
                    commonImg: function(o) {
                        return o.mallConfig.__wxapp_img.common;
                    }
                })), {}, {
                    labelText: function() {
                        if (this.coupon && this.coupon.list && this.coupon.list.length) switch (this.coupon.list[0].share_type) {
                          case 4:
                            return "优惠券已发放到账户，请到我的优惠券查看";

                          case 2:
                            return "".concat(this.integralCustomer, "已发放到账户，请到我的").concat(this.integralCustomer, "查看");

                          case 1:
                            return "余额红包已发放到账户，请到我的余额查看";

                          case 3:
                            return "卡劵已发放到账户，请到我的卡劵查看";

                          default:
                            return "";
                        }
                    },
                    img: function() {
                        var o = "";
                        return "register" == this.coupon.type ? o = this.mallConfig.__wxapp_img.coupon.get_coupon_title : "share" == this.coupon.type ? o = this.mallConfig.__wxapp_img.coupon.get_coupon_share : "receive" == this.coupon.type ? o = this.mallConfig.__wxapp_img.coupon.get_coupon_receive : "award" === this.coupon.type && (o = this.mallConfig.__wxapp_img.coupon.get_coupon_award), 
                        o;
                    }
                }),
                methods: {
                    closeCouponBox: function() {
                        var o = {
                            list: [],
                            type: ""
                        };
                        this.$store.dispatch("page/actionSetCoupon", o);
                    },
                    toGoods: function(n) {
                        o.navigateTo({
                            url: n
                        }), this.closeCouponBox();
                    }
                }
            };
            n.default = p;
        }).call(this, t("543d").default);
    },
    "6c5e": function(o, n, t) {
        var e = t("d6ab8");
        t.n(e).a;
    },
    8339: function(o, n, t) {
        t.d(n, "b", function() {
            return e;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var e = function() {
            var o = this, n = (o.$createElement, o._self._c, o.coupon && o.coupon.list && o.coupon.list.length > 0 ? o.__map(o.coupon.list, function(n, t) {
                return {
                    $orig: o.__get_orig(n),
                    g0: [ 1, 2, 3 ].includes(n.share_type)
                };
            }) : null);
            o.$mp.data = Object.assign({}, {
                $root: {
                    l0: n
                }
            });
        }, c = [];
    },
    93551: function(o, n, t) {
        t.r(n);
        var e = t("4216"), c = t.n(e);
        for (var a in e) [ "default" ].indexOf(a) < 0 && function(o) {
            t.d(n, o, function() {
                return e[o];
            });
        }(a);
        n.default = c.a;
    },
    a3b2: function(o, n, t) {
        t.r(n);
        var e = t("8339"), c = t("93551");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(o) {
            t.d(n, o, function() {
                return c[o];
            });
        }(a);
        t("6c5e");
        var p = t("f0c5"), r = Object(p.a)(c.default, e.b, e.c, !1, null, "56658375", null, !1, e.a, void 0);
        n.default = r.exports;
    },
    d6ab8: function(o, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-layout/app-coupon-modal/app-coupon-modal-create-component", {
    "components/basic-component/app-layout/app-coupon-modal/app-coupon-modal-create-component": function(o, n, t) {
        t("543d").createComponent(t("a3b2"));
    }
}, [ [ "components/basic-component/app-layout/app-coupon-modal/app-coupon-modal-create-component" ] ] ]);