(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-iphone-x/app-iphone-x" ], {
    3262: function(e, n, t) {
        var o = t("7cb8");
        t.n(o).a;
    },
    "421d": function(e, n, t) {
        t.r(n);
        var o = t("8b7c"), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    },
    7598: function(e, n, t) {
        t.r(n);
        var o = t("b056"), r = t("421d");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        t("3262");
        var p = t("f0c5"), a = Object(p.a)(r.default, o.b, o.c, !1, null, "07ff1c96", null, !1, o.a, void 0);
        n.default = a.exports;
    },
    "7cb8": function(e, n, t) {},
    "8b7c": function(e, n, t) {
        function o(e, n) {
            var t = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                n && (o = o.filter(function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable;
                })), t.push.apply(t, o);
            }
            return t;
        }
        function r(e, n, t) {
            return n in e ? Object.defineProperty(e, n, {
                value: t,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[n] = t, e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = t("2f62"), p = {
            props: {
                backgroundColor: {
                    type: String,
                    default: function() {
                        return "white";
                    }
                }
            },
            computed: function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? o(Object(t), !0).forEach(function(n) {
                        r(e, n, t[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                    });
                }
                return e;
            }({}, (0, c.mapGetters)("iPhoneX", {
                getBoolEmpty: "getBoolEmpty"
            }))
        };
        n.default = p;
    },
    b056: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-iphone-x/app-iphone-x-create-component", {
    "components/basic-component/app-iphone-x/app-iphone-x-create-component": function(e, n, t) {
        t("543d").createComponent(t("7598"));
    }
}, [ [ "components/basic-component/app-iphone-x/app-iphone-x-create-component" ] ] ]);