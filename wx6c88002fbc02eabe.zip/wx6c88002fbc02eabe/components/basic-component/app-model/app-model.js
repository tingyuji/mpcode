(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-model/app-model" ], {
    "000e": function(n, e, t) {
        var o = t("be68");
        t.n(o).a;
    },
    "046d": function(n, e, t) {
        t.r(e);
        var o = t("4197"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    4197: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            name: "app-model",
            props: {
                type: {
                    type: String,
                    default: function() {
                        return "1";
                    }
                },
                background: {
                    type: String,
                    default: function() {
                        return "white";
                    }
                },
                height: {
                    type: Number,
                    default: function() {
                        return 500;
                    }
                },
                value: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                }
            },
            data: function() {
                return {
                    display: this.value
                };
            },
            methods: {
                bubble: function() {
                    return !1;
                },
                close: function() {
                    this.display = !1, this.$emit("input", this.display);
                }
            },
            computed: {
                setHeight: function() {
                    return !0 === this.display ? "0" : "-".concat(this.height + 108, "rpx");
                }
            },
            watch: {
                value: function() {
                    this.display = this.value;
                }
            }
        };
        e.default = o;
    },
    "7a11": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    be68: function(n, e, t) {},
    cf2f: function(n, e, t) {
        t.r(e);
        var o = t("7a11"), a = t("046d");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("000e");
        var u = t("f0c5"), i = Object(u.a)(a.default, o.b, o.c, !1, null, "e473a898", null, !1, o.a, void 0);
        e.default = i.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-model/app-model-create-component", {
    "components/basic-component/app-model/app-model-create-component": function(n, e, t) {
        t("543d").createComponent(t("cf2f"));
    }
}, [ [ "components/basic-component/app-model/app-model-create-component" ] ] ]);