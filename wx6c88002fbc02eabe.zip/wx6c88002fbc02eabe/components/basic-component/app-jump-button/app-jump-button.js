(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-jump-button/app-jump-button" ], {
    "436a": function(e, t, n) {
        var a = n("e8dc");
        n.n(a).a;
    },
    "86fc": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n("8de3d"), r = {
                name: "app-jump-button",
                data: function() {
                    return {
                        finderUserName: "",
                        feedId: "",
                        nonceId: "",
                        videoNumberType: "live"
                    };
                },
                props: {
                    item: Object,
                    pos: String,
                    arrangement: {
                        type: String,
                        default: function() {
                            return "row";
                        },
                        required: !1
                    },
                    backgroundColor: {
                        type: String,
                        required: !1
                    },
                    form: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        },
                        required: !1
                    },
                    height: {
                        type: String,
                        default: function() {
                            return "100";
                        },
                        required: !1
                    },
                    width: {
                        type: String,
                        default: function() {
                            return "100";
                        },
                        required: !1
                    },
                    open_type: {
                        type: String,
                        default: function() {
                            return "navigate";
                        },
                        required: !1
                    },
                    url: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    params: {
                        type: [ Array, String ],
                        default: function() {
                            return [];
                        },
                        required: !1
                    },
                    number: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    appId: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    path: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    latitude: {
                        type: String,
                        default: function() {
                            return "0";
                        },
                        required: !1
                    },
                    longitude: {
                        type: String,
                        default: function() {
                            return "0";
                        },
                        required: !1
                    },
                    address: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    }
                },
                created: function() {
                    var e = this;
                    "video_number" == this.open_type && this.params && this.params.length > 0 && (1 == this.params.length && this.params.forEach(function(t) {
                        if ("video_id" == t.key) {
                            var n = t.value;
                            wx.getChannelsLiveInfo({
                                finderUserName: n,
                                success: function(t) {
                                    e.finderUserName = n, e.feedId = t.feedId, e.nonceId = t.nonceId;
                                }
                            });
                        }
                    }), 2 == this.params.length && (this.videoNumberType = "video"));
                },
                methods: {
                    jumpLogic: function(t) {
                        var n = this;
                        switch (this.form && (0, a.push)(t.detail.formId), this.open_type) {
                          case "reLaunch":
                            e.reLaunch({
                                url: this.url
                            });
                            break;

                          case "redirect":
                            e.redirectTo({
                                url: this.url
                            });
                            break;

                          case "navigate":
                            if (this.url) {
                                var r = this.url;
                                if ('""' != this.params && this.params && this.params.length > 0) {
                                    for (var i = "?", s = 0; s < this.params.length; s++) i += "".concat(this.params[s].key, "=").concat(this.params[s].value, "&");
                                    r = r.split("?")[0], r += i.slice(0, i.length - 1);
                                }
                                e.navigateTo({
                                    url: r
                                });
                            }
                            break;

                          case "app_admin":
                            1 == this.$store.state.user.info.identity.is_admin && e.navigateTo({
                                url: this.url
                            });
                            break;

                          case "back":
                            e.navigateBack({});
                            break;

                          case "tel":
                            1 === this.params.length ? e.makePhoneCall({
                                phoneNumber: this.params[0].value
                            }) : this.number ? e.makePhoneCall({
                                phoneNumber: this.number
                            }) : e.makePhoneCall({
                                phoneNumber: this.url.split("?")[1].split("=")[1]
                            });
                            break;

                          case "web":
                            if (this.params.length > 0) {
                                var o = this.url.split("?")[0];
                                e.navigateTo({
                                    url: "".concat(o, "?url=").concat(encodeURIComponent(this.params[0].value))
                                });
                            } else e.navigateTo({
                                url: this.url
                            });
                            break;

                          case "app":
                            if (this.url) {
                                var u = "";
                                if ("app" !== this.url) u = this.url.split("app?")[1]; else for (var p = 0; p < this.params.length; p++) u += "".concat(this.params[p].key, "=").concat(this.params[p].value, "&");
                                if ("string" != typeof u) return;
                                var c = [];
                                c.push(u.slice(u.indexOf("&app_id"), u.indexOf("&path")).slice(1)), c.push(u.slice(u.indexOf("&path"), u.indexOf("&ali_app_id")).slice(1));
                                var l = {};
                                for (var d in c) if ("string" == typeof c[d] && c[d].length) {
                                    var h = c[d].split("=");
                                    if (2 !== h.length) {
                                        for (var f = "", m = 1; m < h.length && (f += "".concat(h[m]), m + 1 !== h.length); ) f += "=", 
                                        m++;
                                        l[h[0]] = f;
                                    } else l[h[0]] = h[1];
                                }
                                var v = l, b = "", g = "";
                                b = v.app_id || "", g = v.path || "", e.navigateToMiniProgram({
                                    appId: b,
                                    path: g
                                });
                            } else this.appId && e.navigateToMiniProgram({
                                appId: this.appId,
                                path: this.path ? this.path : ""
                            });
                            break;

                          case "clear_cache":
                            e.showModal({
                                content: "确定要清理缓存？",
                                cancelText: "取消",
                                confirmText: "确认",
                                success: function(t) {
                                    t.confirm && (n.$storage.clearStorage(), n.$user && n.$store && n.$store.state.user.accessToken && n.$user.loginByToken(n.$store.state.user.accessToken), 
                                    n.$store.dispatch("mallConfig/actionResetConfig"), e.showToast({
                                        title: "清理完成",
                                        duration: 1e3,
                                        icon: "none"
                                    }));
                                }
                            });
                            break;

                          case "map":
                            e.openLocation({
                                latitude: Number(this.latitude),
                                longitude: Number(this.longitude),
                                name: this.pos || this.address,
                                address: this.address
                            });
                            break;

                          case "share":
                          case "video_number":
                            console.log(this.videoNumberType), console.log(this.params), "live" == this.videoNumberType && wx.openChannelsLive({
                                finderUserName: this.finderUserName,
                                feedId: this.feedId,
                                nonceId: this.nonceId
                            }), "video" == this.videoNumberType && wx.openChannelsActivity({
                                finderUserName: this.params[0].value,
                                feedId: this.params[1].value
                            });
                            break;

                          case "customer_service":
                            var y = "", k = [];
                            this.params.length > 0 ? (k = this.params, this.params.forEach(function(e) {
                                "id" === e.key && (y = e.value);
                            })) : this.url.split("?")[1].split("&").forEach(function(e) {
                                var t = e.split("=");
                                "id" === t[0] && (y = t[1]), k.push({
                                    key: t[0],
                                    value: t[1]
                                });
                            }), this.$jump({
                                open_type: "customer_service",
                                params: k,
                                id: y
                            });
                        }
                    },
                    getUrlParam: function(e, t) {
                        var n = e.split("?")[1];
                        if (n) {
                            var a = n.substr(0).match(new RegExp("(^|&)" + t + "=([^&]*)(&|$)"));
                            return null !== a ? unescape(a[2]) : null;
                        }
                        return null;
                    }
                },
                computed: {
                    newForm: function() {
                        return this.form && "customer_service" !== this.open_type && "video_number" !== this.open_type && "app" !== this.open_type;
                    }
                }
            };
            t.default = r;
        }).call(this, n("543d").default);
    },
    "8bf9": function(e, t, n) {
        n.r(t);
        var a = n("86fc"), r = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = r.a;
    },
    b362: function(e, t, n) {
        n.r(t);
        var a = n("fd7e"), r = n("8bf9");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        n("436a");
        var s = n("f0c5"), o = Object(s.a)(r.default, a.b, a.c, !1, null, "3d2cb872", null, !1, a.a, void 0);
        t.default = o.exports;
    },
    e8dc: function(e, t, n) {},
    fd7e: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-jump-button/app-jump-button-create-component", {
    "components/basic-component/app-jump-button/app-jump-button-create-component": function(e, t, n) {
        n("543d").createComponent(n("b362"));
    }
}, [ [ "components/basic-component/app-jump-button/app-jump-button-create-component" ] ] ]);