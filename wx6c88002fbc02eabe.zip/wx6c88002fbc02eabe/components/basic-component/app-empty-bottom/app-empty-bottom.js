(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-empty-bottom/app-empty-bottom" ], {
    "09fc": function(t, e, n) {
        function o(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(t);
                e && (o = o.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function r(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = n("2f62"), p = {
            name: "app-empty-bottom",
            props: {
                backgroundColor: {
                    type: String,
                    default: function() {
                        return "white";
                    }
                },
                height: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                },
                botBool: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                }
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }({}, (0, c.mapGetters)("iPhoneX", {
                BotHeight: "getBotHeight",
                emptyHeight: "getEmpty"
            }))
        };
        e.default = p;
    },
    "0c06": function(t, e, n) {
        n.r(e);
        var o = n("31c3"), r = n("f5f7");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        n("a9e0");
        var p = n("f0c5"), a = Object(p.a)(r.default, o.b, o.c, !1, null, "b274d5d4", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    "31c3": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, r = [];
    },
    "9d80": function(t, e, n) {},
    a9e0: function(t, e, n) {
        var o = n("9d80");
        n.n(o).a;
    },
    f5f7: function(t, e, n) {
        n.r(e);
        var o = n("09fc"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-empty-bottom/app-empty-bottom-create-component", {
    "components/basic-component/app-empty-bottom/app-empty-bottom-create-component": function(t, e, n) {
        n("543d").createComponent(n("0c06"));
    }
}, [ [ "components/basic-component/app-empty-bottom/app-empty-bottom-create-component" ] ] ]);