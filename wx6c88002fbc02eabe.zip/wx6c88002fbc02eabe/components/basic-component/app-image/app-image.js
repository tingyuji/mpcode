(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-image/app-image" ], {
    "281c": function(e, t, n) {
        n.r(t);
        var o = n("a4f2"), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = r.a;
    },
    4820: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, e.imgSrc && e.is_loading ? e.__get_style([ e.imgStyle, e.otherStyle ]) : null), n = e.imgSrc && !e.is_error ? e.__get_style([ e.imgStyle, e.otherStyle ]) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t,
                    s1: n
                }
            });
        }, r = [];
    },
    "82f2": function(e, t, n) {},
    a2ea: function(e, t, n) {
        var o = n("82f2");
        n.n(o).a;
    },
    a4f2: function(e, t, n) {
        function o(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                t && (o = o.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function r(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = n("2f62"), a = {
            name: "app-image",
            props: {
                imgSrc: String,
                width: String,
                height: String,
                otherStyle: Object,
                mode: {
                    type: String,
                    default: function() {
                        return "aspectFill";
                    }
                },
                borderRadius: String,
                isAbsolute: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    is_loading: !0,
                    is_error: !1
                };
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        r(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({
                appBackground: function() {
                    return "width: ".concat(this.width, ";height: ").concat(this.height, ";");
                },
                imgStyle: function() {
                    return {
                        borderRadius: "".concat(this.borderRadius)
                    };
                }
            }, (0, i.mapState)({
                commonImg: function(e) {
                    return e.mallConfig.__wxapp_img.common;
                }
            })),
            methods: {
                imgError: function() {
                    this.is_error = !0;
                },
                imgLoad: function() {
                    this.is_loading = !1;
                }
            }
        };
        t.default = a;
    },
    f54c: function(e, t, n) {
        n.r(t);
        var o = n("4820"), r = n("281c");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        n("a2ea");
        var a = n("f0c5"), c = Object(a.a)(r.default, o.b, o.c, !1, null, "042e357d", null, !1, o.a, void 0);
        t.default = c.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-image/app-image-create-component", {
    "components/basic-component/app-image/app-image-create-component": function(e, t, n) {
        n("543d").createComponent(n("f54c"));
    }
}, [ [ "components/basic-component/app-image/app-image-create-component" ] ] ]);