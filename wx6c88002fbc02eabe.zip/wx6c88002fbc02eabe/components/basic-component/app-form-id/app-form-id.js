(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-form-id/app-form-id" ], {
    "2f32": function(n, o, e) {
        e.r(o);
        var t = e("e9fb"), a = e.n(t);
        for (var c in t) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(c);
        o.default = a.a;
    },
    32849: function(n, o, e) {
        var t = e("ce44");
        e.n(t).a;
    },
    81122: function(n, o, e) {
        e.d(o, "b", function() {
            return t;
        }), e.d(o, "c", function() {
            return a;
        }), e.d(o, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    "8ee9": function(n, o, e) {
        e.r(o);
        var t = e("81122"), a = e("2f32");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(o, n, function() {
                return a[n];
            });
        }(c);
        e("32849");
        var i = e("f0c5"), f = Object(i.a)(a.default, t.b, t.c, !1, null, "beba4aa8", null, !1, t.a, void 0);
        o.default = f.exports;
    },
    ce44: function(n, o, e) {},
    e9fb: function(n, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var t = e("8de3d"), a = {
            name: "app-form-id",
            props: {
                color: String,
                item: Object
            },
            methods: {
                formSubmit: function(n) {
                    (0, t.push)(n.detail.formId), this.$emit("click", n, this.item);
                }
            }
        };
        o.default = a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-form-id/app-form-id-create-component", {
    "components/basic-component/app-form-id/app-form-id-create-component": function(n, o, e) {
        e("543d").createComponent(e("8ee9"));
    }
}, [ [ "components/basic-component/app-form-id/app-form-id-create-component" ] ] ]);