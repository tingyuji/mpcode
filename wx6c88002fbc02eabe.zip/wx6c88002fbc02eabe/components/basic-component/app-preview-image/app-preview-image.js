(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-preview-image/app-preview-image" ], {
    "37d2": function(e, n, t) {
        t.d(n, "b", function() {
            return i;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    "669c": function(e, n, t) {},
    "8f77": function(e, n, t) {
        t.r(n);
        var i = t("37d2"), a = t("ebb8");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(r);
        t("f116");
        var c = t("f0c5"), o = Object(c.a)(a.default, i.b, i.c, !1, null, "5781ec10", null, !1, i.a, void 0);
        n.default = o.exports;
    },
    b533: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = {
            name: "app-preview-image",
            data: function() {
                return {
                    currentIndex: 0,
                    currentName: "",
                    list: []
                };
            },
            props: {
                cover_list: Array,
                index: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                }
            },
            created: function() {
                this.list = JSON.parse(JSON.stringify(this.cover_list)), this.currentIndex = this.index, 
                this.currentName = this.list[this.currentIndex].name;
            },
            methods: {
                close: function() {
                    this.$emit("change", this.currentIndex);
                },
                changIndex: function(e) {
                    this.currentIndex = e.detail.current, this.currentName = this.list[e.detail.current].name;
                },
                imageLoad: function(e, n) {
                    var t = n.detail.height * (750 / n.detail.width);
                    this.list[e].height = t + "rpx", this.$forceUpdate();
                }
            }
        };
        n.default = i;
    },
    ebb8: function(e, n, t) {
        t.r(n);
        var i = t("b533"), a = t.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(r);
        n.default = a.a;
    },
    f116: function(e, n, t) {
        var i = t("669c");
        t.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-preview-image/app-preview-image-create-component", {
    "components/basic-component/app-preview-image/app-preview-image-create-component": function(e, n, t) {
        t("543d").createComponent(t("8f77"));
    }
}, [ [ "components/basic-component/app-preview-image/app-preview-image-create-component" ] ] ]);