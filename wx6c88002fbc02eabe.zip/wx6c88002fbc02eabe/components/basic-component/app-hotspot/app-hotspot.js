(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-hotspot/app-hotspot" ], {
    "05ff": function(t, o, n) {
        n.r(o);
        var c = n("8a062"), p = n.n(c);
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(o, t, function() {
                return c[t];
            });
        }(a);
        o.default = p.a;
    },
    "0ca1": function(t, o, n) {},
    "18bc": function(t, o, n) {
        var c = n("0ca1");
        n.n(c).a;
    },
    "8a062": function(t, o, n) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var c = {
            name: "app-hotspot",
            props: {
                hotspot: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            },
            data: function() {
                return {};
            },
            onLoad: function() {},
            computed: {
                aa: function() {
                    return this.hotspot ? "left:".concat(this.hotspot.left, "rpx;top:").concat(this.hotspot.top, "rpx;width:").concat(this.hotspot.width, "rpx;height:").concat(this.hotspot.height, "rpx;") : "";
                }
            }
        };
        o.default = c;
    },
    "9c0a": function(t, o, n) {
        n.r(o);
        var c = n("c562"), p = n("05ff");
        for (var a in p) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(o, t, function() {
                return p[t];
            });
        }(a);
        n("18bc");
        var e = n("f0c5"), u = Object(e.a)(p.default, c.b, c.c, !1, null, "050d04cc", null, !1, c.a, void 0);
        o.default = u.exports;
    },
    c562: function(t, o, n) {
        n.d(o, "b", function() {
            return c;
        }), n.d(o, "c", function() {
            return p;
        }), n.d(o, "a", function() {});
        var c = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, p = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-hotspot/app-hotspot-create-component", {
    "components/basic-component/app-hotspot/app-hotspot-create-component": function(t, o, n) {
        n("543d").createComponent(n("9c0a"));
    }
}, [ [ "components/basic-component/app-hotspot/app-hotspot-create-component" ] ] ]);