(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-empty/app-empty" ], {
    "4d00": function(n, e, t) {
        var o = t("f9f3");
        t.n(o).a;
    },
    "5ded": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return p;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, p = [];
    },
    a7c3: function(n, e, t) {
        t.r(e);
        var o = t("5ded"), p = t("bc75");
        for (var a in p) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return p[n];
            });
        }(a);
        t("4d00");
        var c = t("f0c5"), f = Object(c.a)(p.default, o.b, o.c, !1, null, "75975ffc", null, !1, o.a, void 0);
        e.default = f.exports;
    },
    bc75: function(n, e, t) {
        t.r(e);
        var o = t("e74e"), p = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = p.a;
    },
    e74e: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            name: "app-empty",
            props: {
                height: {
                    type: Number,
                    default: function() {
                        return 10;
                    }
                },
                backgroundColor: {
                    type: String,
                    default: function() {
                        return "#ffffff";
                    }
                }
            }
        };
        e.default = o;
    },
    f9f3: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-empty/app-empty-create-component", {
    "components/basic-component/app-empty/app-empty-create-component": function(n, e, t) {
        t("543d").createComponent(t("a7c3"));
    }
}, [ [ "components/basic-component/app-empty/app-empty-create-component" ] ] ]);