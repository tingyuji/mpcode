(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/basic-component/app-load-text/app-load-text" ], {
    "29c2": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    "7a2a": function(e, t, n) {
        function a(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, a);
            }
            return n;
        }
        function o(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? a(Object(n), !0).forEach(function(t) {
                    o(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }({
            name: "app-load-data"
        }, (0, n("2f62").mapState)({
            appImg: function(e) {
                return e.mallConfig.__wxapp_img.mall;
            }
        }));
        t.default = r;
    },
    a225: function(e, t, n) {
        var a = n("ab7f");
        n.n(a).a;
    },
    ab7f: function(e, t, n) {},
    ad6f: function(e, t, n) {
        n.r(t);
        var a = n("7a2a"), o = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = o.a;
    },
    cae62: function(e, t, n) {
        n.r(t);
        var a = n("29c2"), o = n("ad6f");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("a225");
        var c = n("f0c5"), p = Object(c.a)(o.default, a.b, a.c, !1, null, "7afea661", null, !1, a.a, void 0);
        t.default = p.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/basic-component/app-load-text/app-load-text-create-component", {
    "components/basic-component/app-load-text/app-load-text-create-component": function(e, t, n) {
        n("543d").createComponent(n("cae62"));
    }
}, [ [ "components/basic-component/app-load-text/app-load-text-create-component" ] ] ]);