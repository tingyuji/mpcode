(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-share-video-number/app-share-video-number" ], {
    "06a0": function(e, t, n) {},
    "1a67": function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n("2f62"), i = {
                name: "app-share-video-number",
                props: {
                    title: {
                        type: String,
                        default: function() {
                            return "生成商品海报";
                        }
                    },
                    isShow: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    goodsId: null
                },
                data: function() {
                    return {
                        article_url: "",
                        number: 0,
                        isLoading: !1,
                        interval: null
                    };
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? o(Object(n), !0).forEach(function(t) {
                            a(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, r.mapState)({
                    sph: function(e) {
                        return e.mallConfig.__wxapp_img.sph;
                    }
                })),
                watch: {
                    isShow: function(e, t) {
                        e && this.addMaterial();
                    }
                },
                methods: {
                    addMaterial: function() {
                        var t = this;
                        e.showLoading({
                            title: "加载中"
                        }), this.$request({
                            url: this.$api.goods.addMaterial,
                            data: {
                                goods_id: this.goodsId
                            }
                        }).then(function(n) {
                            e.hideLoading(), 0 === n.code ? t.getArticleUrl(n.data.media_id) : t.showModal(n.msg, t.interval);
                        }).catch(function() {});
                    },
                    getArticleUrl: function(t) {
                        var n = this;
                        this.article_url = "", this.isLoading = !0;
                        var o = setInterval(function() {
                            n.number++, n.number > 15 && n.showModal("获取视频号链接异常,请稍后重试", o), n.$request({
                                url: n.$api.goods.articleUrl,
                                data: {
                                    media_id: t
                                }
                            }).then(function(t) {
                                e.hideLoading(), 0 === t.code ? (n.article_url = t.data.url, n.article_url && clearInterval(o)) : n.showModal(t.msg, o);
                            });
                        }, 1e3);
                        this.interval = o;
                    },
                    showModal: function(t, n) {
                        var o = this;
                        this.isLoading = !1, this.number = 0, e.showModal({
                            content: t,
                            showCancel: !1,
                            success: function() {
                                o.close();
                            }
                        }), clearInterval(n);
                    },
                    copyText: function() {
                        this.$utils.uniCopy({
                            data: this.article_url,
                            success: function() {
                                e.showToast({
                                    title: "复制成功"
                                }), this.close();
                            }
                        });
                    },
                    close: function() {
                        this.isLoading = !1, clearInterval(this.interval), this.$emit("close", !1);
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    "29ab": function(e, t, n) {
        n.r(t);
        var o = n("6f19"), a = n("60e8");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("ecff");
        var i = n("f0c5"), c = Object(i.a)(a.default, o.b, o.c, !1, null, "2e6f762b", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "60e8": function(e, t, n) {
        n.r(t);
        var o = n("1a67"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    "6f19": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    ecff: function(e, t, n) {
        var o = n("06a0");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-share-video-number/app-share-video-number-create-component", {
    "components/page-component/app-share-video-number/app-share-video-number-create-component": function(e, t, n) {
        n("543d").createComponent(n("29ab"));
    }
}, [ [ "components/page-component/app-share-video-number/app-share-video-number-create-component" ] ] ]);