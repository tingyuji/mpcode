(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-check-in/app-check-in" ], {
    "007b": function(e, n, t) {},
    "25a8": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, c = [];
    },
    "2a5a": function(e, n, t) {
        (function(e) {
            function o(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function c(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = t("2f62"), a = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(t("0333")), i = {
                name: "app-check-in",
                components: {
                    "app-hotspot": function() {
                        t.e("components/basic-component/app-hotspot/app-hotspot").then(function() {
                            return resolve(t("9c0a"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                props: {
                    backgroundPicUrl: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    hotspot: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    showText: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    tpl: Array,
                    textColor: String,
                    textPosition: String
                },
                computed: function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = null != arguments[n] ? arguments[n] : {};
                        n % 2 ? o(Object(t), !0).forEach(function(n) {
                            c(e, n, t[n]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                        });
                    }
                    return e;
                }({}, (0, r.mapGetters)({
                    userInfo: "user/info"
                })),
                methods: {
                    subscribe: function() {
                        var e = this;
                        this.$subscribe(this.tpl).then(function(n) {
                            return e.checkIn();
                        }).catch(function(n) {
                            return e.checkIn();
                        });
                    },
                    checkIn: function() {
                        var n = this;
                        e.showLoading({
                            title: "签到中"
                        }), a.default.getAward(1, 1).then(function(t) {
                            e.hideLoading(), e.showToast({
                                title: "签到成功",
                                icon: "success",
                                mask: !1
                            }), n.$store.dispatch("user/info", {
                                refresh: !0
                            });
                        }).catch(function(n) {
                            e.hideLoading(), e.showToast({
                                title: n,
                                mask: !1,
                                icon: "none"
                            });
                        });
                    }
                }
            };
            n.default = i;
        }).call(this, t("543d").default);
    },
    "374b": function(e, n, t) {
        t.r(n);
        var o = t("2a5a"), c = t.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(r);
        n.default = c.a;
    },
    bfb2: function(e, n, t) {
        t.r(n);
        var o = t("25a8"), c = t("374b");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(r);
        t("f380");
        var a = t("f0c5"), i = Object(a.a)(c.default, o.b, o.c, !1, null, "2d8f0b71", null, !1, o.a, void 0);
        n.default = i.exports;
    },
    f380: function(e, n, t) {
        var o = t("007b");
        t.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-check-in/app-check-in-create-component", {
    "components/page-component/app-check-in/app-check-in-create-component": function(e, n, t) {
        t("543d").createComponent(t("bfb2"));
    }
}, [ [ "components/page-component/app-check-in/app-check-in-create-component" ] ] ]);