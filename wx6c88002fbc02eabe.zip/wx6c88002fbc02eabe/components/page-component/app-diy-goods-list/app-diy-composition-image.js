(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-goods-list/app-diy-composition-image" ], {
    3448: function(o, n, e) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var t = {
            name: "app-diy-composition-image",
            props: {
                imageList: Array,
                mode: String
            },
            computed: {
                imageClass: function() {
                    switch (this.imageList.length) {
                      case 1:
                        return "goods-one";

                      case 2:
                        return "goods-two";

                      case 3:
                        return "goods-three";

                      case 4:
                        return "goods-four";

                      case 5:
                        return "goods-five";
                    }
                }
            }
        };
        n.default = t;
    },
    "92f0": function(o, n, e) {
        e.r(n);
        var t = e("b18e"), a = e("a297");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(o) {
            e.d(n, o, function() {
                return a[o];
            });
        }(i);
        e("c63e");
        var c = e("f0c5"), p = Object(c.a)(a.default, t.b, t.c, !1, null, "2b2eaab8", null, !1, t.a, void 0);
        n.default = p.exports;
    },
    "99b1": function(o, n, e) {},
    a297: function(o, n, e) {
        e.r(n);
        var t = e("3448"), a = e.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(o) {
            e.d(n, o, function() {
                return t[o];
            });
        }(i);
        n.default = a.a;
    },
    b18e: function(o, n, e) {
        e.d(n, "b", function() {
            return t;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {});
        var t = function() {
            var o = this;
            o.$createElement;
            o._self._c;
        }, a = [];
    },
    c63e: function(o, n, e) {
        var t = e("99b1");
        e.n(t).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-goods-list/app-diy-composition-image-create-component", {
    "components/page-component/app-diy-goods-list/app-diy-composition-image-create-component": function(o, n, e) {
        e("543d").createComponent(e("92f0"));
    }
}, [ [ "components/page-component/app-diy-goods-list/app-diy-composition-image-create-component" ] ] ]);