(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-goods-list/app-goods-timer" ], {
    "2c94": function(e, t, n) {
        n.r(t);
        var i = n("7038"), a = n("b613");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("943e");
        var o = n("f0c5"), s = Object(o.a)(a.default, i.b, i.c, !1, null, "61c40c8c", null, !1, i.a, void 0);
        t.default = s.exports;
    },
    "5fa1": function(e, t, n) {},
    7038: function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    "943e": function(e, t, n) {
        var i = n("5fa1");
        n.n(i).a;
    },
    "9e53": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = {
            name: "app-goods-timer",
            props: {
                startDateTime: String,
                endDateTime: String,
                listStyle: {
                    type: Number,
                    default: function() {
                        return -1;
                    }
                },
                sign: String,
                pageHide: Boolean,
                theme: Object
            },
            data: function() {
                return {
                    timeInterval: null,
                    timer: null,
                    timerStr: null
                };
            },
            computed: {
                time: function() {
                    return {
                        startDateTime: this.startDateTime,
                        endDateTime: this.endDateTime,
                        pageHide: this.pageHide
                    };
                },
                listClass: function() {
                    var e = "";
                    return 2 == this.listStyle && (e = "main-center"), e;
                },
                signName: function() {
                    var e = "";
                    switch (this.sign) {
                      case "miaosha":
                        e = "秒杀";
                        break;

                      case "bargain":
                        e = "砍价";
                        break;

                      case "lottery":
                        e = "抽奖";
                        break;

                      case "advance":
                        e = "预售";
                        break;

                      case "flash-sale":
                        e = "限时抢购";
                    }
                    return e;
                }
            },
            methods: {
                timing: function(e, t) {
                    var n = null, i = this.$utils.timeDifference(new Date().getTime(), new Date(e).getTime());
                    i && (this.timer = "距开始 ", n = (i.d > 0 ? i.d + "天" : "") + i.h + ":" + i.m + ":" + i.s);
                    var a = null;
                    n || (a = this.$utils.timeDifference(new Date().getTime(), new Date(t).getTime())) && (this.timer = "距结束 ", 
                    n = (a.d > 0 ? a.d + "天" : "") + a.h + ":" + a.m + ":" + a.s), n || (this.timer = "活动已结束", 
                    clearInterval(this.timeInterval)), this.timerStr = n;
                }
            },
            watch: {
                time: {
                    handler: function() {
                        var e = this;
                        if (this.pageHide) clearInterval(this.timeInterval); else {
                            var t = this.startDateTime, n = this.endDateTime;
                            t = t.replace(/-/g, "/"), n = n.replace(/-/g, "/"), this.timing(t, n), this.timeInterval = setInterval(function() {
                                e.timing(t, n);
                            }, 1e3);
                        }
                    },
                    immediate: !0
                }
            },
            beforeDestroy: function() {
                clearInterval(this.timeInterval);
            }
        };
        t.default = i;
    },
    b613: function(e, t, n) {
        n.r(t);
        var i = n("9e53"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-goods-list/app-goods-timer-create-component", {
    "components/page-component/app-diy-goods-list/app-goods-timer-create-component": function(e, t, n) {
        n("543d").createComponent(n("2c94"));
    }
}, [ [ "components/page-component/app-diy-goods-list/app-goods-timer-create-component" ] ] ]);