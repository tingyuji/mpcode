(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-goods-list/app-diy-m-goods-list" ], {
    "7cfe": function(t, e, n) {
        var i = n("9e0a");
        n.n(i).a;
    },
    "98a5": function(t, e, n) {
        n.r(e);
        var i = n("d154"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    "99b9": function(t, e, n) {
        n.r(e);
        var i = n("c5a90"), a = n("98a5");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("7cfe");
        var r = n("f0c5"), s = Object(r.a)(a.default, i.b, i.c, !1, null, "d02a68ca", null, !1, i.a, void 0);
        e.default = s.exports;
    },
    "9e0a": function(t, e, n) {},
    c5a90: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, a = [];
    },
    d154: function(t, e, n) {
        (function(t) {
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        o(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function o(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n("2f62"), s = {
                name: "app-diy-m-goods-list",
                components: {
                    appGoods: function() {
                        n.e("components/basic-component/app-goods/app-goods").then(function() {
                            return resolve(n("ad05"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    cBorderBottom: [ Number, String ],
                    cBorderTop: [ Number, String ],
                    cPaddingLr: [ Number, String ],
                    cPaddingTop: [ Number, String ],
                    cPaddingBottom: [ Number, String ],
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    mTitle: String,
                    mColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    mTitleSecondColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    mBgType: {
                        type: String,
                        default: "gradient"
                    },
                    mBgColor: {
                        type: String,
                        default: "#FF366F"
                    },
                    mBgGradientColor: {
                        type: String,
                        default: "#FF4242"
                    },
                    mTimeColor: {
                        type: String,
                        default: "#353535"
                    },
                    mTimeBgColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    mGoodsBgColor: {
                        type: String,
                        default: "#FFE7E7"
                    },
                    showProgressBar: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    showGoodsName: {
                        type: [ Boolean, String ],
                        default: !0
                    },
                    showGoodsPrice: {
                        type: [ Boolean, String ],
                        default: !0
                    },
                    showGoodsTag: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    customizeGoodsTag: {
                        type: [ Boolean, String ],
                        default: "#FFFFFF"
                    },
                    goodsTagPicUrl: {
                        type: String,
                        default: ""
                    },
                    isUnderLinePrice: {
                        type: [ Boolean, String ],
                        default: !0
                    },
                    backgroundColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    sign: String,
                    theme: Object,
                    mData: Object
                },
                data: function() {
                    return {
                        timer: null,
                        timer_text: "",
                        tempData: this.mData,
                        after_title: "",
                        mTimeIntegral: null
                    };
                },
                watch: {
                    mData: {
                        handler: function(t) {
                            this.tempData = t;
                        },
                        immediate: !0
                    }
                },
                computed: a(a(a({}, (0, r.mapState)({
                    appImg: function(t) {
                        return t.mallConfig.__wxapp_img.mall;
                    },
                    appSetting: function(t) {
                        return t.mallConfig.mall.setting;
                    },
                    platform: function(t) {
                        return t.gConfig.systemInfo.platform;
                    }
                })), (0, r.mapGetters)("mallConfig", {
                    getVideo: "getVideo"
                })), {}, {
                    newData: function() {
                        return this.list;
                    },
                    signAlone: function() {
                        switch (this.sign) {
                          case "miaosha":
                            return {
                                sign: this.sign,
                                title: "秒杀",
                                empty_title: "暂无秒杀活动",
                                more_url: "/plugins/miaosha/advance/advance"
                            };

                          case "flash-sale":
                            return {
                                sign: this.sign,
                                title: "限时抢购",
                                empty_title: "暂无抢购活动",
                                more_url: "/plugins/flash_sale/index/index"
                            };
                        }
                    }
                }),
                mounted: function() {
                    var t = this;
                    this.$nextTick(function() {
                        setTimeout(function() {
                            "miaosha" === t.signAlone.sign && t.sTime(), "flash-sale" === t.signAlone.sign && t.fTime();
                        });
                    });
                },
                beforeDestroy: function() {
                    clearInterval(this.mTimeIntegral);
                },
                methods: {
                    isShowMemPrice: function(t) {
                        return 1 === t.is_level && 1 !== t.is_negotiable && (t.level_price > 0 || 0 == t.level_price) ? 1 : 0;
                    },
                    isShowVip: function(t) {
                        return t.vip_card_appoint && t.vip_card_appoint.discount > 0 && 1 !== t.is_negotiable ? 1 : 0;
                    },
                    isShowStock: function(t) {
                        return 1 === this.appSetting.is_show_stock && 0 === t.goods_stock ? 1 : 0;
                    },
                    set_time: function(t) {
                        var e = this;
                        clearInterval(this.mTimeIntegral);
                        var n = new Date(t.replace(/-/g, "/"));
                        this.now_time(n), this.mTimeIntegral = setInterval(function() {
                            e.now_time(n);
                        }, 1e3);
                    },
                    now_time: function(t) {
                        var e = t.getTime() - new Date().getTime();
                        e < 0 && clearInterval(this.mTimeIntegral);
                        var n = parseInt(e / 1e3 / 60 / 60), i = parseInt(e / 1e3 / 60 % 60), a = parseInt(e / 1e3 % 60);
                        this.timer = {
                            hour: n < 10 ? "0" + n : n,
                            min: i < 10 ? "0" + i : i,
                            sec: a < 10 ? "0" + a : a
                        };
                    },
                    fTime: function() {
                        this.tempData.activity ? (this.after_title = "距结束", this.set_time(this.tempData.activity.end_at)) : this.tempData.next_activity && (this.after_title = "距开始", 
                        this.tempData.next_activity && this.tempData.next_activity.start_at && this.set_time(this.tempData.next_activity.start_at));
                    },
                    sTime: function() {
                        var t = this, e = new Date();
                        if (new Date(this.tempData.open_date).getDate() != e.getDate()) this.timer_text = "预告 " + this.tempData.open_date + " " + this.tempData.open_time + "点场"; else if (this.tempData.open_time != e.getHours()) this.timer_text = "预告 " + this.tempData.open_time + "点场"; else {
                            this.timer_text = this.tempData.open_time + "点场";
                            var n = 1e3 * this.tempData.date_time - e.getTime();
                            this.mTimeIntegral = setInterval(function() {
                                if ((n -= 1e3) <= 0) clearInterval(t.mTimeIntegral); else {
                                    var e = parseInt(n / 1e3 / 60 / 60), i = parseInt(n / 1e3 / 60 % 60), a = parseInt(n / 1e3 % 60);
                                    t.timer = {
                                        hour: e < 10 ? "0" + e : e,
                                        min: i < 10 ? "0" + i : i,
                                        sec: a < 10 ? "0" + a : a
                                    };
                                }
                            }, 1e3);
                        }
                    },
                    jumpMore: function() {
                        t.navigateTo({
                            url: this.signAlone.more_url
                        });
                    },
                    isShowOriginalPrice: function(t) {
                        return this.isUnderLinePrice && t.original_price && this.showGoodsPrice && 1 !== t.is_negotiable;
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-goods-list/app-diy-m-goods-list-create-component", {
    "components/page-component/app-diy-goods-list/app-diy-m-goods-list-create-component": function(t, e, n) {
        n("543d").createComponent(n("99b9"));
    }
}, [ [ "components/page-component/app-diy-goods-list/app-diy-m-goods-list-create-component" ] ] ]);