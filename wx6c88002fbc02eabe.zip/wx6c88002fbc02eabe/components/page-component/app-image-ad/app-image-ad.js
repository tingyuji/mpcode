(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-image-ad/app-image-ad" ], {
    "605d": function(e, n, t) {
        t.r(n);
        var a = t("a4bd"), o = t("d2f01");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(u);
        t("c933");
        var p = t("f0c5"), r = Object(p.a)(o.default, a.b, a.c, !1, null, "1d9e55e8", null, !1, a.a, void 0);
        n.default = r.exports;
    },
    "6b38": function(e, n, t) {},
    "861a": function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            name: "app-image-ad",
            props: {
                h: {
                    type: Number,
                    default: function() {
                        return 1;
                    }
                },
                height: {
                    default: function() {
                        return "auto";
                    }
                },
                hotspot: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                space: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                },
                imageStyle: {
                    type: Number,
                    default: function() {
                        return 2;
                    }
                },
                w: {
                    type: Number,
                    default: function() {
                        return 25;
                    }
                }
            }
        };
        n.default = a;
    },
    a4bd: function(e, n, t) {
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    c933: function(e, n, t) {
        var a = t("6b38");
        t.n(a).a;
    },
    d2f01: function(e, n, t) {
        t.r(n);
        var a = t("861a"), o = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-image-ad/app-image-ad-create-component", {
    "components/page-component/app-image-ad/app-image-ad-create-component": function(e, n, t) {
        t("543d").createComponent(t("605d"));
    }
}, [ [ "components/page-component/app-image-ad/app-image-ad-create-component" ] ] ]);