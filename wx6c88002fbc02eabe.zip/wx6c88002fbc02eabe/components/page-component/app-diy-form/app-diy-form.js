(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-form/app-diy-form" ], {
    "005c2": function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.myList, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    m0: "img_upload" == e.key && 1 == e.img_type ? t.uploadShowImage(e) : null
                };
            }));
            t._isMounted || (t.e0 = function(e) {
                t.showAllItems = !t.showAllItems;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
    },
    2821: function(t, e, n) {
        n.r(e);
        var a = n("c914"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    },
    "7d93": function(t, e, n) {
        n.r(e);
        var a = n("005c2"), i = n("2821");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("b8be");
        var r = n("f0c5"), l = Object(r.a)(i.default, a.b, a.c, !1, null, "3cbb364d", null, !1, a.a, void 0);
        e.default = l.exports;
    },
    "9cf0": function(t, e, n) {},
    b8be: function(t, e, n) {
        var a = n("9cf0");
        n.n(a).a;
    },
    c914: function(t, e, n) {
        (function(t) {
            function a(t, e) {
                var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!n) {
                    if (Array.isArray(t) || (n = i(t)) || e && t && "number" == typeof t.length) {
                        n && (t = n);
                        var a = 0, o = function() {};
                        return {
                            s: o,
                            n: function() {
                                return a >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[a++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: o
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var r, l = !0, u = !1;
                return {
                    s: function() {
                        n = n.call(t);
                    },
                    n: function() {
                        var t = n.next();
                        return l = t.done, t;
                    },
                    e: function(t) {
                        u = !0, r = t;
                    },
                    f: function() {
                        try {
                            l || null == n.return || n.return();
                        } finally {
                            if (u) throw r;
                        }
                    }
                };
            }
            function i(t, e) {
                if (t) {
                    if ("string" == typeof t) return o(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(t, e) : void 0;
                }
            }
            function o(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, a = new Array(e); n < e; n++) a[n] = t[n];
                return a;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = {
                name: "app-diy-form",
                components: {
                    AppTextarea: function() {
                        n.e("components/basic-component/app-textarea/app-textarea").then(function() {
                            return resolve(n("47cb"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    AppUploadImage: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/basic-component/app-upload-image/app-upload-image") ]).then(function() {
                            return resolve(n("798e"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    AppDiyFormCheckboxGroup: function() {
                        n.e("components/page-component/app-diy-form/app-diy-form-checkbox-group").then(function() {
                            return resolve(n("274d"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    AppRadioGroup: function() {
                        n.e("components/basic-component/app-radio/app-radio-group").then(function() {
                            return resolve(n("bf87"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    AppRadio: function() {
                        n.e("components/basic-component/app-radio/app-radio").then(function() {
                            return resolve(n("3ac8"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    AppDatetimePicker: function() {
                        n.e("components/basic-component/app-datetime-picker/app-datetime-picker").then(function() {
                            return resolve(n("3e52"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    sign: {
                        default: null
                    },
                    datePadding: {
                        type: String,
                        default: "0 24rpx"
                    },
                    title: {
                        type: String,
                        default: null
                    },
                    backgroundColor: {
                        default: "#ffffff"
                    },
                    backgroundImage: {
                        default: null
                    },
                    backgroundPosition: {
                        default: "center"
                    },
                    backgroundWidth: {
                        default: 100
                    },
                    backgroundHeight: {
                        default: 100
                    },
                    backgroundRepeat: {
                        default: "no-repeat"
                    },
                    marginTop: {
                        default: 0
                    },
                    marginBottom: {
                        default: 0
                    },
                    paddingTop: {
                        default: 0
                    },
                    paddingBottom: {
                        default: 0
                    },
                    list: {
                        type: Array,
                        default: []
                    },
                    showRequiredIcon: {
                        type: Boolean,
                        default: !1
                    },
                    itemPaddingX: {
                        default: 24
                    },
                    itemMarginY: {
                        default: 0
                    },
                    itemHeight: {
                        type: Number,
                        default: 88
                    },
                    showItemBorder: {
                        default: !0
                    },
                    labelPosition: {
                        default: "left"
                    },
                    labelColor: {
                        default: "#666666"
                    },
                    labelTextAlign: {
                        default: "right"
                    },
                    showInputBorder: {
                        type: Boolean,
                        default: !1
                    },
                    inputBackground: {
                        default: "#ffffff"
                    },
                    inputBorderColor: {
                        default: "#c0c4cc"
                    },
                    inputTextColor: {
                        default: "#666666"
                    },
                    inputPlaceholderColor: {
                        default: "#bbbbbb"
                    },
                    inputRadius: {
                        default: 0
                    },
                    showSubmit: {
                        type: Boolean,
                        default: !1
                    },
                    submitUrl: {
                        type: String,
                        default: null
                    },
                    submitBtnText: {
                        default: "提交"
                    },
                    submitBtnHeight: {
                        default: 80
                    },
                    submitBtnPadding: {
                        default: 24
                    },
                    submitBtnMargin: {
                        default: 40
                    },
                    submitBtnRadius: {
                        default: 40
                    },
                    submitBtnBackground: {
                        default: "#ff4544"
                    },
                    submitBtnBorderColor: {
                        default: "#ff4544"
                    },
                    submitBtnTextColor: {
                        default: "#ffffff"
                    },
                    showScrollBtn: {
                        default: !1
                    },
                    labelFs28: {
                        default: !1
                    },
                    marginColor: {
                        default: "#ffffff"
                    },
                    selectBoxColor: {
                        default: "#ff4544"
                    }
                },
                data: function() {
                    var t = [];
                    for (var e in this.list) {
                        var n = this.list[e];
                        if (void 0 !== n.default && null !== n.default && "" !== n.default || ("text" !== n.key && "textarea" !== n.key && "time" !== n.key && "date" !== n.key || (n.default = ""), 
                        "radio" !== n.key && "checkbox" !== n.key || (n.default = [])), void 0 !== n.value && null !== n.value && "" !== n.value || (n.value = n.default), 
                        n.hint = n.hint || "", "radio" === n.key || "checkbox" === n.key) for (var a in n.list || (n.list = []), 
                        n.list) n.list[a].value && !1 !== n.list[a].value && "false" !== n.list[a].value ? n.list[a].value = !0 : n.list[a].value = !1;
                        "img_upload" !== n.key || 2 !== n.img_type && "2" !== n.img_type || n.value || (n.value = [ "", "" ]), 
                        n.key, t[e] = n;
                    }
                    return {
                        myList: t,
                        randomString: "",
                        validateResult: {
                            hasError: !1,
                            errors: []
                        },
                        showAllItems: !0
                    };
                },
                computed: {
                    uploadShowImage: function() {
                        return function(t) {
                            return Array.isArray(t.value) ? t.value : t.value ? [ t.value ] : null;
                        };
                    },
                    itemClass: function() {
                        return "left" === this.labelPosition ? "label-left dir-left-nowrap cross-top" : "inset" === this.labelPosition ? "label-inset dir-left-nowrap cross-top" : "top" === this.labelPosition ? "label-top" : void 0;
                    },
                    getDateTimeTextPosition: function() {
                        return "top" === this.labelPosition ? "left" : "right";
                    },
                    getInputPaddingLeft: function() {
                        return "top" === this.labelPosition ? this.showInputBorder ? 24 : 0 : 24;
                    }
                },
                created: function() {
                    this.validate(), this.outputData();
                },
                methods: {
                    textInput: function() {
                        this.outputData();
                    },
                    datetimeChange: function() {
                        this.outputData();
                    },
                    checkChange: function() {
                        var t = this;
                        setTimeout(function() {
                            t.outputData();
                        }, 10);
                    },
                    handleImageUpload: function(t) {
                        var e = t.sign, n = t.imageList, a = parseInt(e);
                        1 === n.length ? this.myList[a].value = n[0] : n.length > 0 ? this.myList[a].value = n : this.myList[a].value = "", 
                        this.outputData();
                    },
                    handleUserIdFrontUpload: function(t) {
                        var e = t.sign, n = t.imageList, a = parseInt(e);
                        n.length > 0 ? this.myList[a].value[0] = n[0] : this.myList[a].value[0] = "", this.outputData();
                    },
                    handleUserIdBackUpload: function(t) {
                        var e = t.sign, n = t.imageList, a = parseInt(e);
                        n.length > 0 ? this.myList[a].value[1] = n[0] : this.myList[a].value[1] = "", this.outputData();
                    },
                    validate: function() {
                        for (var t in this.validateResult = {
                            hasError: !1,
                            errors: []
                        }, this.myList) {
                            var e = this.myList[t];
                            if (1 === e.is_required || "1" === e.is_required) {
                                if (void 0 === e.value || null === e.value || "" === e.value || -1 !== [ "radio", "checkbox" ].indexOf(e.key) && !e.value.length) {
                                    this.validateResult.hasError = !0, this.validateResult.errors.push({
                                        index: t,
                                        msg: '"'.concat(e.name, '"不能为空。')
                                    });
                                    continue;
                                }
                                if (e.img_type && 2 === parseInt(e.img_type)) {
                                    if (!e.value || !e.value.length) {
                                        this.validateResult.hasError = !0, this.validateResult.errors.push({
                                            index: t,
                                            msg: '"'.concat(e.name, '"不能为空。')
                                        });
                                        continue;
                                    }
                                    var n = !1;
                                    for (var a in e.value) if (null === e.value[a] || "" === e.value[a]) {
                                        n = !0;
                                        break;
                                    }
                                    if (n) {
                                        this.validateResult.hasError = !0, this.validateResult.errors.push({
                                            index: t,
                                            msg: '"'.concat(e.name, '"不能为空。')
                                        });
                                        continue;
                                    }
                                }
                            }
                        }
                        this.$emit("validate", {
                            result: this.validateResult,
                            sign: this.sign
                        });
                    },
                    outputData: function() {
                        for (var t in this.validate(), this.myList) this.myList[t].label = this.myList[t].name, 
                        this.myList[t].required = this.myList[t].is_required;
                        this.$emit("input", {
                            data: this.myList,
                            sign: this.sign
                        });
                    },
                    submit: function() {
                        var e = this;
                        this.outputData(), this.validateResult.hasError && this.validateResult.errors ? t.showModal({
                            title: "提示",
                            content: this.validateResult.errors[0].msg,
                            showCancel: !1
                        }) : (t.showLoading({
                            mask: !0,
                            title: "正在提交..."
                        }), this.$request({
                            url: this.submitUrl ? this.submitUrl : this.$api.diy.page_store,
                            method: "post",
                            data: {
                                form_data: JSON.stringify(this.myList)
                            }
                        }).then(function(n) {
                            t.hideLoading(), 0 === n.code ? (setTimeout(function() {
                                var t = e.myList;
                                for (var n in t) if (t[n].value = t[n].default, ("radio" === t[n].key || "checkbox" === t[n].key) && t[n].list && t[n].list.length > 0) {
                                    var i, o = a(t[n].list);
                                    try {
                                        for (o.s(); !(i = o.n()).done; ) i.value.value = !1;
                                    } catch (t) {
                                        o.e(t);
                                    } finally {
                                        o.f();
                                    }
                                }
                                e.myList = [], setTimeout(function() {
                                    e.myList = t;
                                }, 0);
                            }, 300), t.showModal({
                                title: "提示",
                                content: n.msg || "提交成功",
                                showCancel: !1
                            })) : t.showModal({
                                title: "提示",
                                content: n.msg || "提交失败",
                                showCancel: !1
                            });
                        }).catch(function() {
                            t.hideLoading();
                        }));
                    }
                }
            };
            e.default = r;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-form/app-diy-form-create-component", {
    "components/page-component/app-diy-form/app-diy-form-create-component": function(t, e, n) {
        n("543d").createComponent(n("7d93"));
    }
}, [ [ "components/page-component/app-diy-form/app-diy-form-create-component" ] ] ]);