(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-form/app-diy-form-checkbox-group" ], {
    "274d": function(e, o, n) {
        n.r(o);
        var t = n("b2dd"), a = n("85e5");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(o, e, function() {
                return a[e];
            });
        }(c);
        n("d25c");
        var i = n("f0c5"), r = Object(i.a)(a.default, t.b, t.c, !1, null, "6168174c", null, !1, t.a, void 0);
        o.default = r.exports;
    },
    "541d": function(e, o, n) {},
    "85e5": function(e, o, n) {
        n.r(o);
        var t = n("96c3"), a = n.n(t);
        for (var c in t) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(c);
        o.default = a.a;
    },
    "96c3": function(e, o, n) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var t = {
            name: "app-diy-form-checkbox-group",
            props: {
                sign: {
                    default: null
                },
                value: {
                    type: Array,
                    default: []
                },
                list: {
                    type: Array,
                    default: []
                },
                color: {
                    default: "#ff4544"
                }
            },
            data: function() {
                var e = this.list;
                for (var o in e) {
                    var n = !1;
                    for (var t in this.value) if (e[o].label === this.value[t]) {
                        n = !0;
                        break;
                    }
                    n && (e[o].value = !0);
                }
                return {
                    model: e
                };
            },
            methods: {
                handleClick: function(e) {
                    this.model[e].value = !this.model[e].value, this.outputData();
                },
                outputData: function() {
                    var e = [];
                    for (var o in this.model) !0 === this.model[o].value && e.push(this.model[o].label);
                    this.$emit("change", e, this.sign), this.$emit("input", e, this.sign);
                }
            }
        };
        o.default = t;
    },
    b2dd: function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    d25c: function(e, o, n) {
        var t = n("541d");
        n.n(t).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-form/app-diy-form-checkbox-group-create-component", {
    "components/page-component/app-diy-form/app-diy-form-checkbox-group-create-component": function(e, o, n) {
        n("543d").createComponent(n("274d"));
    }
}, [ [ "components/page-component/app-diy-form/app-diy-form-checkbox-group-create-component" ] ] ]);