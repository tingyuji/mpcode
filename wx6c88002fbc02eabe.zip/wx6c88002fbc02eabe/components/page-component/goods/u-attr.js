(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/u-attr" ], {
    "3c1e": function(t, e, i) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function o(t, e) {
                var i = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!i) {
                    if (Array.isArray(t) || (i = r(t)) || e && t && "number" == typeof t.length) {
                        i && (t = i);
                        var n = 0, o = function() {};
                        return {
                            s: o,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: o
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var s, c = !0, a = !1;
                return {
                    s: function() {
                        i = i.call(t);
                    },
                    n: function() {
                        var t = i.next();
                        return c = t.done, t;
                    },
                    e: function(t) {
                        a = !0, s = t;
                    },
                    f: function() {
                        try {
                            c || null == i.return || i.return();
                        } finally {
                            if (a) throw s;
                        }
                    }
                };
            }
            function r(t, e) {
                if (t) {
                    if ("string" == typeof t) return s(t, e);
                    var i = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === i && t.constructor && (i = t.constructor.name), "Map" === i || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? s(t, e) : void 0;
                }
            }
            function s(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
                return n;
            }
            function c(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), i.push.apply(i, n);
                }
                return i;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(i), !0).forEach(function(e) {
                        u(t, e, i[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : c(Object(i)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
                    });
                }
                return t;
            }
            function u(t, e, i) {
                return e in t ? Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = i, t;
            }
            function h(t, e, i, n, o, r, s) {
                try {
                    var c = t[r](s), a = c.value;
                } catch (t) {
                    return void i(t);
                }
                c.done ? e(a) : Promise.resolve(a).then(n, o);
            }
            function l(t) {
                return function() {
                    var e = this, i = arguments;
                    return new Promise(function(n, o) {
                        function r(t) {
                            h(c, n, o, r, s, "next", t);
                        }
                        function s(t) {
                            h(c, n, o, r, s, "throw", t);
                        }
                        var c = t.apply(e, i);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var d = n(i("a34a")), f = i("2f62"), p = n(i("1639")), m = n(i("06e6")), _ = {
                name: "u-attr",
                mixins: [ p.default, m.default ],
                props: {
                    value: {
                        type: [ Boolean, Number ]
                    },
                    goods: {
                        type: Object,
                        default: function() {
                            return {};
                        },
                        required: !0
                    },
                    theme: {
                        type: Object
                    },
                    checked: {
                        type: Object
                    },
                    week_number: {
                        type: [ String, Number ]
                    },
                    is_show_price: {
                        type: Boolean,
                        default: !0
                    },
                    is_show_left: {
                        type: Boolean,
                        default: !0
                    },
                    is_must_left: {
                        type: Boolean,
                        default: !1
                    },
                    is_show_right: {
                        type: Boolean,
                        default: !0
                    },
                    is_choose_number: {
                        type: Boolean,
                        default: !0
                    },
                    leftText: {
                        type: String,
                        default: "加入购物车"
                    },
                    rightText: {
                        type: String,
                        default: "立即购买"
                    },
                    leftFunc: {
                        type: Boolean
                    },
                    autoClose: {
                        type: Boolean,
                        default: !0
                    },
                    rightFunc: {
                        type: Boolean
                    },
                    sign: {
                        type: String
                    },
                    again: {
                        type: Number
                    },
                    attentionSign: {
                        type: String
                    },
                    isMore: {
                        type: Boolean,
                        default: !1
                    },
                    isLimit: {
                        type: Boolean,
                        default: !0
                    }
                },
                data: function() {
                    return {
                        newValue: !1,
                        picUrl: null,
                        newGroup: [],
                        showAttrImg: !1,
                        number: 1,
                        sell_time: 0,
                        showPreview: !1,
                        cover_list: [],
                        attrIndex: 0,
                        min_number: 1,
                        ignore_list: []
                    };
                },
                created: function() {
                    this.isMore || (this.min_number = !isNaN(this.goods.min_number) && this.goods.min_number > 0 ? this.goods.min_number : 1, 
                    this.number = this.goods.use_attr ? 1 : this.min_number, this.createCalendar());
                },
                methods: {
                    closePreview: function(t) {
                        if (console.log(t, this.attrIndex), t != this.attrIndex) {
                            var e = this.newGroup[0], i = e.attr_list[t];
                            this.storeAttr(i.attr_id, e.attr_group_id, i.num_0, t);
                        }
                        this.showPreview = !1;
                    },
                    previewCover: function(t, e) {
                        if (console.log(t, this.attrIndex), !e) {
                            var i = this.newGroup[0], n = i.attr_list[t];
                            this.storeAttr(n.attr_id, i.attr_group_id, n.num_0, t);
                        }
                        this.showPreview = !0;
                    },
                    close: function() {
                        this.newGroup.forEach(function(t) {
                            t.attr_list.forEach(function(t) {});
                        }), this.$emit("input", !1);
                    },
                    turnOn: function() {
                        this.$emit("input", !0);
                    },
                    inArray: function(t, e) {
                        return e.some(function(e) {
                            return t === e;
                        });
                    },
                    identifier: function(t, e, i) {
                        var n = this;
                        t.forEach(function(t) {
                            t.attr_list.forEach(function(o) {
                                var r = "".concat(t.attr_group_id, "-").concat(o.attr_id);
                                n.inArray(r, e) && !n.inArray(r, i) ? o.num_0 = !0 : o.num_0 = !1;
                            });
                        });
                    },
                    selectCheck: function(t, e, i) {
                        var n = this, o = i.map(function(t) {
                            return t.split("-");
                        }).map(function(t) {
                            return +t[0];
                        }), r = new Set();
                        this.copyGroup.forEach(function(t) {
                            return t.attr_list.forEach(function(e) {
                                return r.add("".concat(t.attr_group_id, "-").concat(e.attr_id));
                            });
                        }), this.copyGroup.forEach(function(e) {
                            var n = o.indexOf(e.attr_group_id);
                            t.forEach(function(t) {
                                var o = t.attr_list.map(function(t) {
                                    return "".concat(t.attr_group_id, "-").concat(t.attr_id);
                                });
                                if (i.every(function(t) {
                                    return o.includes(t);
                                }) && e.attr_list.forEach(function(t) {
                                    var i = "".concat(e.attr_group_id, "-").concat(t.attr_id);
                                    o.includes(i) && r.delete(i);
                                }), -1 !== n) {
                                    var s = i.slice(0, n).concat(i.slice(n + 1, i.length));
                                    e.attr_list.forEach(function(t) {
                                        var i = "".concat(e.attr_group_id, "-").concat(t.attr_id);
                                        [ i ].concat(s).every(function(t) {
                                            return o.includes(t);
                                        }) && r.delete(i);
                                    });
                                }
                            });
                        }), Array.prototype.push.apply(e, Array.from(r)), t.forEach(function(t) {
                            var o = [], r = 0;
                            t.attr_list.forEach(function(t) {
                                var e = "".concat(t.attr_group_id, "-").concat(t.attr_id);
                                n.inArray(e, i) || (r += 1, o.push(e));
                            }), 0 == t.stock && r <= 1 && Array.prototype.push.apply(e, o), 0 === r && (n.upCalendar(t), 
                            n.checked && "form-goods" === n.goods.type && n.isSelect() && (t.stock = n.checked.stock, 
                            t.price = n.checked.price, t.calc_price = n.checked.price, t.price_member = n.checked.price), 
                            n.$emit("check", {
                                item: t,
                                number: n.number
                            }));
                        });
                    },
                    storeAttr: function(t, e, i, n, o) {
                        var r = this;
                        if ((1 != o || "form-goods" !== this.goods.type) && !0 !== i) {
                            n > -1 && (this.attrIndex = n);
                            var s = this.newGroup, c = this.copyAttr, a = [];
                            s.forEach(function(i, n) {
                                i.attr_list.forEach(function(o) {
                                    i.attr_group_id === e && (o.attr_id === t ? !0 === o.select ? o.select = !1 : o.select = !0 : o.select = !1), 
                                    !0 === o.select && (a.push("".concat(i.attr_group_id, "-").concat(o.attr_id)), 0 === n && (r.picUrl = o.pic_url));
                                });
                            });
                            var u = [];
                            this.selectCheck(c, u, a), this.$nextTick(function() {
                                r.number > r.stock && (r.number = r.stock);
                            }), this.identifier(s, u, a), a.length !== s.length && (this.$emit("check", {
                                item: null
                            }), this.upCalendar(null));
                        }
                    },
                    firstSelect: function() {
                        var t = this;
                        if (this.copyGroup && this.copyAttr) {
                            var e = this.copyGroup, i = this.copyAttr, n = e.length, o = [];
                            i.forEach(function(i) {
                                i.attr_list.forEach(function(r) {
                                    for (var s = r.attr_group_id, c = 0; c < e.length; c++) !function(c) {
                                        var a = e[c];
                                        if (s === a.attr_group_id) {
                                            var u = a.attr_list;
                                            if (u.length > 1) return "continue";
                                            u.forEach(function(s, c) {
                                                s.attr_id === r.attr_id && i.stock > 0 && n > 0 && (s.select = !0, o.push("".concat(a.attr_group_id, "-").concat(s.attr_id)), 
                                                n === e.length && (t.picUrl = s.pic_url), n--);
                                            });
                                        }
                                    }(c);
                                });
                            });
                            var r = [];
                            this.selectCheck(i, r, o), this.identifier(e, r, o), this.newGroup = e;
                        }
                    },
                    numberBlur: function(e) {
                        var i = parseInt(e.detail.value);
                        i || (i = 1);
                        var n = this.stock;
                        "weekly_buy" == this.sign && this.week_number > 0 && (n = Math.floor(+this.stock / +this.week_number), 
                        console.log(n)), i > n && (i = n, t.showToast({
                            title: "库存不足",
                            icon: "none"
                        })), this.number = i;
                    },
                    numberSub: function() {
                        var t = this.number;
                        (t > this.min_number || 1 == this.goods.use_attr && t > 1) && (t--, this.number = t);
                    },
                    numberAdd: function() {
                        var e = this.number, i = this.stock;
                        "weekly_buy" == this.sign && this.week_number > 0 && (i = Math.floor(+this.stock / +this.week_number), 
                        console.log(i)), ++e > i && (e = i, t.showToast({
                            title: "库存不足",
                            icon: "none"
                        })), this.checkLimitBuy(e) || (e = this.goods.limit_buy.rest_number), this.number = e;
                    },
                    leftSubmit: function() {
                        var t = l(d.default.mark(function t() {
                            return d.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (this.$user.isLogin()) {
                                        t.next = 3;
                                        break;
                                    }
                                    return t.next = 3, this.$user.silentLogin();

                                  case 3:
                                    !0 === this.leftFunc ? this.$emit("leftFunc", this.number) : this.cart(), this.close();

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function() {
                            return t.apply(this, arguments);
                        };
                    }(),
                    rightSubmit: function() {
                        var e = l(d.default.mark(function e() {
                            var i, n;
                            return d.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (this.checked) {
                                        e.next = 3;
                                        break;
                                    }
                                    return t.showToast({
                                        title: "请先选规格",
                                        icon: "none"
                                    }), e.abrupt("return", !1);

                                  case 3:
                                    if (this.$user.isLogin()) {
                                        e.next = 6;
                                        break;
                                    }
                                    return e.next = 6, this.$user.getInfo({
                                        no_jump: !0
                                    });

                                  case 6:
                                    if (i = [], this.checked.attr_list.forEach(function(t) {
                                        i.push({
                                            attr_id: t.attr_id,
                                            attr_group_id: t.attr_group_id
                                        });
                                    }), n = {
                                        mch_id: this.goods.mch_id ? this.goods.mch_id : 0,
                                        goods_list: [ {
                                            id: this.goods.id,
                                            attrs: i,
                                            num: this.number,
                                            cat_id: 0,
                                            goods_attr_id: this.checked.id
                                        } ]
                                    }, !this.isLimit) {
                                        e.next = 14;
                                        break;
                                    }
                                    if (this.checkMinNUmber()) {
                                        e.next = 12;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 12:
                                    if (this.checkLimitBuy(this.number)) {
                                        e.next = 14;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 14:
                                    if (!0 !== this.rightFunc) {
                                        e.next = 21;
                                        break;
                                    }
                                    if (this.$emit("rightFunc", n), this.autoClose) {
                                        e.next = 18;
                                        break;
                                    }
                                    return e.abrupt("return", !1);

                                  case 18:
                                    this.close(), e.next = 22;
                                    break;

                                  case 21:
                                    this.shop(n);

                                  case 22:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }(),
                    shop: function(e) {
                        if ("form-goods" === this.goods.type && "calendar" === this.dataConfig.form_mode_type) {
                            if (!this.isSelect()) return void t.showToast({
                                title: "请选择日历信息",
                                icon: "none"
                            });
                            var i = this.handleParam();
                            return Object.assign(e, {
                                date: JSON.stringify(i),
                                stock: this.number
                            }), t.navigateTo({
                                url: "/pages/order-submit/order-submit?&date=".concat(i, "&preview_url=").concat(encodeURIComponent(this.$api.order.form_order_preview), "&submit_url=").concat(encodeURIComponent(this.$api.order.form_order_submit), "&mch_list=").concat(JSON.stringify([ e ]))
                            }), void this.close();
                        }
                        t.navigateTo({
                            url: "/pages/order-submit/order-submit?mch_list=".concat(JSON.stringify([ e ]))
                        }), this.close();
                    },
                    cart: function() {
                        var e = this;
                        if (!this.checked) return t.showToast({
                            title: "请先选规格",
                            icon: "none"
                        }), !1;
                        if ("ecard" !== this.goods.type) {
                            var i = this.number;
                            this.$request({
                                url: this.$api.cart.add,
                                method: "post",
                                data: {
                                    goods_id: this.checked.goods_id,
                                    attr: this.checked.id,
                                    num: this.number
                                }
                            }).then(function(n) {
                                0 === n.code ? (t.showToast({
                                    title: n.msg,
                                    icon: "none"
                                }), e.getNumber(), e.$emit("cart", {
                                    checked: e.checked,
                                    number: i
                                }), e.close()) : t.showToast({
                                    title: n.msg,
                                    icon: "none",
                                    duration: 2500
                                });
                            });
                        }
                    },
                    getNumber: function() {
                        var t = this;
                        this.$request({
                            url: this.$api.cart.nums
                        }).then(function(e) {
                            0 === e.code && t.$store.commit("user/cart_nums", e.data.nums);
                        }).catch(function(t) {});
                    },
                    clickImg: function() {
                        this.picUrl ? this.previewCover(this.attrIndex, !0) : t.previewImage({
                            current: 0,
                            urls: [ this.goods.cover_pic ]
                        });
                    },
                    checkMinNUmber: function() {
                        return !(this.goods.min_number > this.number && (this.$tips.showToast({
                            title: "该商品" + this.goods.min_number + this.goods.unit + "起售",
                            icon: "none"
                        }), 1));
                    },
                    checkLimitBuy: function(t) {
                        return !(void 0 !== this.goods.limit_buy && 1 == this.goods.limit_buy.status && this.goods.limit_buy.rest_number < t && (this.$tips.showToast({
                            title: this.goods.limit_buy.text,
                            icon: "none"
                        }), 1));
                    },
                    changeTime: function(t) {
                        this.sell_time = t;
                    }
                },
                components: {
                    uPopup: function() {
                        i.e("components/basic-component/u-popup/u-popup").then(function() {
                            return resolve(i("d55a"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    appPrice: function() {
                        i.e("components/page-component/goods/app-price").then(function() {
                            return resolve(i("6c9f"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    appMemberMark: function() {
                        i.e("components/page-component/app-member-mark/app-member-mark").then(function() {
                            return resolve(i("1ed7"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    appSellTip: function() {
                        i.e("components/page-component/goods/app-sell-tip").then(function() {
                            return resolve(i("571a"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    appPreviewImage: function() {
                        i.e("components/basic-component/app-preview-image/app-preview-image").then(function() {
                            return resolve(i("8f77"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                computed: a(a(a({
                    stock: function() {
                        return this.$validation.isEmpty(this.checked) ? this.$validation.isEmpty(this.goods) ? void 0 : void 0 === this.goods.goods_num ? this.goods.goods_stock : this.goods.goods_num : this.checked.stock;
                    },
                    sellPrice: function() {
                        return this.$validation.isEmpty(this.checked) ? this.$validation.isEmpty(this.goods) ? void 0 : 1 !== this.goods.level_show ? this.goods.hasOwnProperty("price_min") ? this.goods.price_min : this.goods.price : this.goods.price_member_min : "form-goods" !== this.goods.type || "calendar" !== this.dataConfig.form_mode_type || this.isSelect() ? 1 === this.goods.level_show ? this.checked.price_member : this.checked.price : 1 !== this.goods.level_show ? this.goods.hasOwnProperty("price_min") ? this.goods.price_min : this.goods.price : this.goods.price_member_min;
                    },
                    copyGroup: function() {
                        if (this.goods) {
                            for (var t = this.$utils.deepClone(this.goods.attr_groups), e = 0; e < t.length; e++) t[e].attr_list.forEach(function(t) {
                                t.select = !1, t.num_0 = !1;
                            });
                            return t;
                        }
                    },
                    copyAttr: function() {
                        if (this.goods) return this.$utils.deepClone(this.goods.attr);
                    }
                }, (0, f.mapGetters)({
                    userInfo: "user/info"
                })), (0, f.mapState)({
                    isTip: function(t) {
                        return t.mallConfig.mall.setting.is_remind_sell_time;
                    }
                })), {}, {
                    remindParams: function() {
                        return {
                            sell_time: this.sell_time,
                            goods_id: this.goods.id,
                            template_message_list: this.goods.template_message_list,
                            buy_text: this.rightText
                        };
                    }
                }),
                watch: {
                    value: {
                        handler: function(t) {
                            if (t && this.isMore && (this.min_number = !isNaN(this.goods.min_number) && this.goods.min_number > 0 ? this.goods.min_number : 1, 
                            this.number = this.goods.use_attr ? 1 : this.min_number, this.createCalendar(), 
                            this.firstSelect()), this.newValue = t, !1 === t) return this.cover_list = [], this.showAttrImg = !1, 
                            void (this.number = this.goods.use_attr ? 1 : this.min_number);
                            this.cover_list = [], this.showAttrImg = !1;
                            var e, i = o(this.goods.attr_groups[0].attr_list);
                            try {
                                for (i.s(); !(e = i.n()).done; ) {
                                    var n = e.value;
                                    this.cover_list.push({
                                        pic_url: n.pic_url ? n.pic_url : this.goods.cover_pic,
                                        name: n.attr_name
                                    }), n.pic_url && (this.showAttrImg = !0);
                                }
                            } catch (t) {
                                i.e(t);
                            } finally {
                                i.f();
                            }
                            this.sell_time = this.goods.sell_time, this.$validation.isEmpty(this.checked) && this.$utils.throttle(this.firstSelect, 800);
                        },
                        immediate: !0
                    },
                    number: {
                        handler: function(t) {
                            this.$emit("check", {
                                item: this.checked,
                                number: this.number
                            }), this.upCalendar(this.checked);
                        }
                    },
                    again: {
                        handler: function() {
                            this.firstSelect();
                        }
                    }
                }
            };
            e.default = _;
        }).call(this, i("543d").default);
    },
    "5df9": function(t, e, i) {},
    a6341: function(t, e, i) {
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return o;
        }), i.d(e, "a", function() {});
        var n = function() {
            var t = this, e = (t.$createElement, t._self._c, t.goods && "form-goods" === t.goods.type && "calendar" === t.dataConfig.form_mode_type && 0 == t.dataConfig.is_alone ? t._f("formatDate")(t.date) : null), i = t.goods && "form-goods" === t.goods.type && "calendar" === t.dataConfig.form_mode_type ? t.__map(t.formatWeeks, function(e, i) {
                return {
                    $orig: t.__get_orig(e),
                    l0: t.__map(e, function(e, i) {
                        return {
                            $orig: t.__get_orig(e),
                            s0: e && e.year == t.nowDate.year && e.month == t.nowDate.month ? t.__get_style([ e.ss ]) : null
                        };
                    })
                };
            }) : null, n = t.is_choose_number && t.isLimit && (t.goods.min_number > 1 || 1 == t.goods.limit_buy.status) && 1 == t.goods.limit_buy.status ? t.__map(t.goods.limit_buy.msg.split(""), function(e, i) {
                return {
                    $orig: t.__get_orig(e),
                    m0: isNaN(Number(e))
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    f0: e,
                    l1: i,
                    l2: n
                }
            });
        }, o = [];
    },
    aded: function(t, e, i) {
        var n = i("5df9");
        i.n(n).a;
    },
    b4bc: function(t, e, i) {
        i.r(e);
        var n = i("a6341"), o = i("f066");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(r);
        i("aded");
        var s = i("f0c5"), c = Object(s.a)(o.default, n.b, n.c, !1, null, "3bf6fa27", null, !1, n.a, void 0);
        e.default = c.exports;
    },
    f066: function(t, e, i) {
        i.r(e);
        var n = i("3c1e"), o = i.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(r);
        e.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/u-attr-create-component", {
    "components/page-component/goods/u-attr-create-component": function(t, e, i) {
        i("543d").createComponent(i("b4bc"));
    }
}, [ [ "components/page-component/goods/u-attr-create-component" ] ] ]);