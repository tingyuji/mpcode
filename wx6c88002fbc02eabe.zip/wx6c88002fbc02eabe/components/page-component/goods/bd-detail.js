(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-detail" ], {
    1727: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            name: "bd-detail",
            components: {
                "app-rich-text": function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/basic-component/app-rich/parse") ]).then(function() {
                        return resolve(t("cb0e"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            props: {
                detail: {
                    type: String,
                    default: function() {
                        return "";
                    }
                }
            },
            created: function() {
                this.$store.dispatch("gConfig/setImageWidth", 48);
            },
            data: function() {
                return {
                    imageProp: {
                        mode: "aspectFit",
                        padding: 0,
                        lazyLoad: !1,
                        domain: "",
                        paddinglimit: ""
                    }
                };
            },
            computed: {
                newDetail: function() {
                    var n = "";
                    return this.detail && (n = this.detail), n;
                }
            }
        };
        e.default = o;
    },
    "1bab": function(n, e, t) {
        var o = t("c000");
        t.n(o).a;
    },
    "3e70": function(n, e, t) {
        t.r(e);
        var o = t("8cbb"), a = t("41ce");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("1bab");
        var i = t("f0c5"), d = Object(i.a)(a.default, o.b, o.c, !1, null, "14cf845c", null, !1, o.a, void 0);
        e.default = d.exports;
    },
    "41ce": function(n, e, t) {
        t.r(e);
        var o = t("1727"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    "8cbb": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    c000: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-detail-create-component", {
    "components/page-component/goods/bd-detail-create-component": function(n, e, t) {
        t("543d").createComponent(t("3e70"));
    }
}, [ [ "components/page-component/goods/bd-detail-create-component" ] ] ]);