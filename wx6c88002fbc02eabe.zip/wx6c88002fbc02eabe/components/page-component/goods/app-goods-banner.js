(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-goods-banner" ], {
    "0c16": function(e, n, t) {
        (function(e) {
            function o(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function r(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var t = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? o(Object(t), !0).forEach(function(n) {
                        c(e, n, t[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                    });
                }
                return e;
            }
            function c(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t("2f62"), i = {
                components: {
                    "app-video": function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-video/app-video") ]).then(function() {
                            return resolve(t("d824"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                props: {
                    picList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    share: {
                        type: Number
                    },
                    videoUrl: {
                        type: String
                    },
                    goods_id: {
                        type: [ Number, String ]
                    },
                    sign: {
                        type: String
                    }
                },
                data: function() {
                    return {
                        autoplay: !0,
                        videoPlay: !0,
                        currentBanner: 1
                    };
                },
                methods: {
                    bannerChange: function(e) {
                        this.videoPlay = !this.videoPlay, this.currentBanner = e.detail.current + 1;
                    },
                    videoStart: function(e) {
                        this.autoplay = !e;
                    },
                    preventD: function() {},
                    clickImage: function(n) {
                        var t = [];
                        this.picList.forEach(function(e) {
                            t.push(e.pic_url);
                        }), e.previewImage({
                            current: n,
                            urls: t
                        });
                    },
                    routeJumpT: function() {
                        e.navigateTo({
                            url: "/pages/goods/video?goods_id=".concat(this.goods_id, "&sign=").concat(this.sign)
                        });
                    }
                },
                computed: r(r({}, (0, a.mapState)({
                    mallConfig: function(e) {
                        return e.mallConfig;
                    },
                    commonImg: function(e) {
                        return e.mallConfig.__wxapp_img.common;
                    }
                })), (0, a.mapGetters)("mallConfig", {
                    getVideo: "getVideo"
                }))
            };
            n.default = i;
        }).call(this, t("543d").default);
    },
    "12b6": function(e, n, t) {
        t.r(n);
        var o = t("532d"), r = t("f689");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        t("894c");
        var a = t("f0c5"), i = Object(a.a)(r.default, o.b, o.c, !1, null, "6b28faea", null, !1, o.a, void 0);
        n.default = i.exports;
    },
    "532d": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    "894c": function(e, n, t) {
        var o = t("f7e8");
        t.n(o).a;
    },
    f689: function(e, n, t) {
        t.r(n);
        var o = t("0c16"), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    },
    f7e8: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-goods-banner-create-component", {
    "components/page-component/goods/app-goods-banner-create-component": function(e, n, t) {
        t("543d").createComponent(t("12b6"));
    }
}, [ [ "components/page-component/goods/app-goods-banner-create-component" ] ] ]);