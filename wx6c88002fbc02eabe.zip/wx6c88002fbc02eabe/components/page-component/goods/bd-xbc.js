(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-xbc" ], {
    "296c": function(t, e, n) {},
    5608: function(t, e, n) {
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var r = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(e) {
                t.show = !1;
            }, t.e1 = function(e) {
                t.show = !1;
            }, t.e2 = function(e) {
                t.showCoupon = !1;
            }, t.e3 = function(e) {
                t.showCoupon = !1;
            });
        }, o = [];
    },
    "5f17": function(t, e, n) {
        function r(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function o(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = n("2f62"), c = {
            name: "bd-xbc",
            props: {
                attrGroups: Array,
                services: Array,
                attrList: Array,
                guaranteeTitle: String,
                guaranteePic: String,
                param_content: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                param_name: String,
                type: String,
                goodsStock: Number,
                coAttr: {
                    type: [ Number, Boolean ],
                    default: 1
                },
                card: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                integral: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                balance: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                coupon: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                theme: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            },
            data: function() {
                return {
                    attrStr: "请选择规格",
                    serviceStr: "",
                    paramStr: "",
                    newAttrGroups: [],
                    attrCount: [],
                    attrName: "",
                    pictureList: [],
                    show: !1,
                    isShow: "",
                    showCoupon: !1,
                    showModal: "",
                    title: ""
                };
            },
            watch: {
                attrList: {
                    deep: !0,
                    immediate: !0,
                    handler: function(t) {
                        var e = "";
                        this.$validation.isEmpty(t) ? e = "请选择规格" : t.forEach(function(t) {
                            e += "".concat(t.attr_group_name, ":").concat(t.attr_name, " ");
                        }), this.attrStr = e;
                    }
                },
                services: {
                    immediate: !0,
                    handler: function() {
                        var t = "";
                        this.$validation.isEmpty(this.services) || this.services.forEach(function(e) {
                            t += "".concat(e.name, " · ");
                        }), t = t.substring(0, t.lastIndexOf(" · ") + 1), this.serviceStr = t;
                    }
                },
                attrGroups: {
                    immediate: !0,
                    handler: function(t) {
                        var e = this;
                        this.newAttrGroups = [], this.pictureList = [], this.attrCount = 0, this.attrName = "", 
                        t && t.length > 0 && t.forEach(function(t, n) {
                            e.attrName || (e.attrName = t.attr_group_name, t.attr_list.forEach(function() {
                                e.attrCount += 1;
                            })), 0 === n && t.attr_list.forEach(function(t) {
                                e.newAttrGroups.length < 3 && e.newAttrGroups.push(t), t.pic_url && e.pictureList.length < 5 && e.pictureList.push(t.pic_url);
                            });
                        });
                    }
                },
                param_content: {
                    immediate: !0,
                    handler: function(t) {
                        var e = "";
                        this.$validation.isEmpty(t) || t.forEach(function(t) {
                            e += "".concat(t.key, " ");
                        }), e = e.substring(0, e.lastIndexOf(" ") + 1), this.paramStr = e;
                    }
                }
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? r(Object(n), !0).forEach(function(e) {
                        o(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }({}, (0, a.mapState)({
                integralCustomer: function(t) {
                    return t.mallConfig.mall.setting.integral_customer;
                }
            })),
            components: {
                uPopup: function() {
                    n.e("components/basic-component/u-popup/u-popup").then(function() {
                        return resolve(n("d55a"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            methods: {
                open: function(t) {
                    "attr" === t ? this.$emit("openAttr") : (this.show = !0, this.isShow = t);
                },
                change: function(t, e) {
                    this.showModal = t, this.title = e, this.showCoupon = !0;
                }
            }
        };
        e.default = c;
    },
    8639: function(t, e, n) {
        n.r(e);
        var r = n("5608"), o = n("f9ad");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("ef15");
        var c = n("f0c5"), i = Object(c.a)(o.default, r.b, r.c, !1, null, "4fa5c40c", null, !1, r.a, void 0);
        e.default = i.exports;
    },
    ef15: function(t, e, n) {
        var r = n("296c");
        n.n(r).a;
    },
    f9ad: function(t, e, n) {
        n.r(e);
        var r = n("5f17"), o = n.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        e.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-xbc-create-component", {
    "components/page-component/goods/bd-xbc-create-component": function(t, e, n) {
        n("543d").createComponent(n("8639"));
    }
}, [ [ "components/page-component/goods/bd-xbc-create-component" ] ] ]);