(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-kb" ], {
    3517: function(n, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var t = {
            name: "bd-kb",
            props: {
                limit: String,
                shipping: String,
                express: String,
                pickup: String,
                userAddress: String
            },
            components: {
                uPopup: function() {
                    e.e("components/basic-component/u-popup/u-popup").then(function() {
                        return resolve(e("d55a"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    show: !1,
                    showText: "",
                    showTitle: ""
                };
            },
            methods: {
                openPopup: function(n, o) {
                    this.showText = this[n], this.showTitle = o, this.show = !0;
                }
            }
        };
        o.default = t;
    },
    "4c29": function(n, o, e) {
        e.r(o);
        var t = e("8a0d"), c = e("b1a6");
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(o, n, function() {
                return c[n];
            });
        }(u);
        e("d8a0");
        var a = e("f0c5"), i = Object(a.a)(c.default, t.b, t.c, !1, null, "390b84be", null, !1, t.a, void 0);
        o.default = i.exports;
    },
    "8a0d": function(n, o, e) {
        e.d(o, "b", function() {
            return t;
        }), e.d(o, "c", function() {
            return c;
        }), e.d(o, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(o) {
                n.show = !1;
            }, n.e1 = function(o) {
                n.show = !1;
            });
        }, c = [];
    },
    b1a6: function(n, o, e) {
        e.r(o);
        var t = e("3517"), c = e.n(t);
        for (var u in t) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(u);
        o.default = c.a;
    },
    d8a0: function(n, o, e) {
        var t = e("fec46");
        e.n(t).a;
    },
    fec46: function(n, o, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-kb-create-component", {
    "components/page-component/goods/bd-kb-create-component": function(n, o, e) {
        e("543d").createComponent(e("4c29"));
    }
}, [ [ "components/page-component/goods/bd-kb-create-component" ] ] ]);