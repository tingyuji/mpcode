(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-comments" ], {
    "754e": function(t, e, n) {
        n.r(e);
        var o = n("aa14"), c = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e.default = c.a;
    },
    9470: function(t, e, n) {
        n.r(e);
        var o = n("9d2b"), c = n("754e");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(r);
        n("a754");
        var i = n("f0c5"), a = Object(i.a)(c.default, o.b, o.c, !1, null, "1d6f5c69", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    "9d2b": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, c = [];
    },
    a754: function(t, e, n) {
        var o = n("ed4f");
        n.n(o).a;
    },
    aa14: function(t, e, n) {
        (function(t) {
            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("2f62"), a = {
                name: "bd-comments",
                props: {
                    goodsId: [ String, Number ]
                },
                data: function() {
                    return {
                        list: [],
                        total: "",
                        categorys: []
                    };
                },
                computed: c(c({}, (0, i.mapState)({
                    isComment: function(t) {
                        return t.mallConfig.mall.setting.is_comment;
                    }
                })), (0, i.mapGetters)("mallConfig", {
                    getTheme: "getTheme"
                })),
                methods: {
                    getList: function(e) {
                        var n = this;
                        this.$request({
                            url: this.$api.goods.comments_list,
                            data: {
                                goods_id: e,
                                ignore_auto: 1
                            }
                        }).then(function(e) {
                            0 === e.code ? (n.list = e.data.comments.slice(0, 2), n.total = e.data.comment_count[0].count, 
                            n.categorys = e.data.categorys) : t.showToast({
                                icon: "none",
                                title: e.msg
                            });
                        });
                    },
                    imgPreview: function(e, n) {
                        this.list && this.list[e] && this.list[e].pic_url && this.list[e].pic_url.length > 0 && t.previewImage({
                            current: n,
                            urls: this.list[e].pic_url
                        });
                    },
                    goto: function() {
                        t.navigateTo({
                            url: "/pages/comments/comments?goods_id=".concat(this.goodsId)
                        });
                    }
                },
                watch: {
                    goodsId: {
                        immediate: !0,
                        handler: function(t) {
                            this.getList(t);
                        }
                    }
                }
            };
            e.default = a;
        }).call(this, n("543d").default);
    },
    ed4f: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-comments-create-component", {
    "components/page-component/goods/bd-comments-create-component": function(t, e, n) {
        n("543d").createComponent(n("9470"));
    }
}, [ [ "components/page-component/goods/bd-comments-create-component" ] ] ]);