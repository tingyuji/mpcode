(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-info" ], {
    "0e01": function(e, n, t) {
        t.r(n);
        var o = t("f524"), r = t("102c");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        t("de85");
        var c = t("f0c5"), a = Object(c.a)(r.default, o.b, o.c, !1, null, "14da98cb", null, !1, o.a, void 0);
        n.default = a.exports;
    },
    "102c": function(e, n, t) {
        t.r(n);
        var o = t("3d24"), r = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = r.a;
    },
    "3d24": function(e, n, t) {
        function o(e, n) {
            var t = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                n && (o = o.filter(function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable;
                })), t.push.apply(t, o);
            }
            return t;
        }
        function r(e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = null != arguments[n] ? arguments[n] : {};
                n % 2 ? o(Object(t), !0).forEach(function(n) {
                    i(e, n, t[n]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                    Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                });
            }
            return e;
        }
        function i(e, n, t) {
            return n in e ? Object.defineProperty(e, n, {
                value: t,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[n] = t, e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = t("2f62"), a = {
            name: "u-info",
            props: {
                name: String,
                subtitle: String,
                isNegotiable: Number,
                theme: Object,
                flashSale: {
                    type: [ Boolean, Object ],
                    default: function() {
                        return !1;
                    }
                },
                levelShow: Number,
                price: {
                    type: [ Number, String ]
                },
                originalPrice: {
                    type: [ Number, String ]
                },
                priceMax: Number,
                priceMin: Number,
                priceMemberMax: Number,
                priceMemberMin: Number,
                isShowMember: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                discount: {
                    type: [ Number, String ]
                },
                isVipCardUser: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                },
                sales: {
                    type: [ Number, String ]
                },
                unit: String,
                isSales: Number,
                goodsId: [ String, Number ],
                goods: Object,
                isVip: Boolean,
                isShowShare: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                posterConfig: String,
                posterGenerate: String,
                hasPosterNav: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                },
                shareUrl: String,
                appShareTitle: String,
                appSharePic: String,
                extraQuickShare: Object,
                hasUnderlinePrice: {
                    type: [ Boolean, String ],
                    default: !0
                },
                negotiableText: String,
                coupons: Array,
                isShowPrice: {
                    type: Boolean,
                    default: !0
                }
            },
            data: function() {
                return {
                    shareShow: !1,
                    quickShareShow: !1,
                    memberPrizeSize: {
                        rmb: "22rpx",
                        int: "28rpx",
                        float: "28rpx"
                    },
                    originPrizeSize: {
                        rmb: "24rpx",
                        int: "24rp",
                        float: "24rp"
                    }
                };
            },
            components: {
                AppVipCard: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-vip-card/app-vip-card") ]).then(function() {
                        return resolve(t("19f0"));
                    }.bind(null, t)).catch(t.oe);
                },
                bdFlashSale: function() {
                    t.e("components/page-component/goods/bd-flash-sale").then(function() {
                        return resolve(t("975a"));
                    }.bind(null, t)).catch(t.oe);
                },
                appPrice: function() {
                    t.e("components/page-component/goods/app-price").then(function() {
                        return resolve(t("6c9f"));
                    }.bind(null, t)).catch(t.oe);
                },
                appMemberMark: function() {
                    t.e("components/page-component/app-member-mark/app-member-mark").then(function() {
                        return resolve(t("1ed7"));
                    }.bind(null, t)).catch(t.oe);
                },
                bdJoinMember: function() {
                    t.e("components/page-component/goods/bd-join-member").then(function() {
                        return resolve(t("6c27"));
                    }.bind(null, t)).catch(t.oe);
                },
                bdQuickShare: function() {
                    t.e("components/page-component/goods/bd-quick-share").then(function() {
                        return resolve(t("519b"));
                    }.bind(null, t)).catch(t.oe);
                },
                appShareQrCode: function() {
                    t.e("components/page-component/app-share-qr-code-poster/app-share-qr-code-poster").then(function() {
                        return resolve(t("409e"));
                    }.bind(null, t)).catch(t.oe);
                },
                bdCoupon: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/goods/bd-coupon") ]).then(function() {
                        return resolve(t("11b2"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            computed: r(r({
                isUnderlinePrice: function() {
                    return Number(this.is_underline_price) && this.hasUnderlinePrice;
                }
            }, (0, c.mapState)({
                negotiable_text: function(e) {
                    return e.mallConfig.mall.setting.negotiable_text;
                },
                is_underline_price: function(e) {
                    return e.mallConfig.mall.setting.is_underline_price;
                },
                is_share_btn: function(e) {
                    return e.mallConfig.mall.setting.is_share_btn;
                },
                is_share_text: function(e) {
                    return e.mallConfig.mall.setting.is_share_text;
                },
                is_show_favorite: function(e) {
                    return e.mallConfig.mall.setting.is_show_favorite;
                }
            })), {}, {
                newShareUrl: function() {
                    return this.shareUrl ? this.shareUrl : this.goodsId ? this.$api.poster.goods + "&goods_id=" + this.goodsId : "";
                }
            }),
            methods: {
                testShare: function(e) {
                    this.$emit("share", e);
                },
                quickShare: function(e) {
                    this.$emit("quickShare", e);
                },
                shareClick: function() {
                    this.$user.isLogin() ? this.extraQuickShare ? this.quickShareShow = !0 : this.shareShow = !0 : this.$user.getInfo().then(function() {});
                },
                setCoupon: function(e) {
                    this.$emit("change", e);
                }
            }
        };
        n.default = a;
    },
    c8f5: function(e, n, t) {},
    de85: function(e, n, t) {
        var o = t("c8f5");
        t.n(o).a;
    },
    f524: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-info-create-component", {
    "components/page-component/goods/bd-info-create-component": function(e, n, t) {
        t("543d").createComponent(t("0e01"));
    }
}, [ [ "components/page-component/goods/bd-info-create-component" ] ] ]);