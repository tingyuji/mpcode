(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-quick-share" ], {
    "519b": function(e, t, n) {
        n.r(t);
        var o = n("9b92"), i = n("97e4");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("8261");
        var a = n("f0c5"), c = Object(a.a)(i.default, o.b, o.c, !1, null, "e6dd78a2", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    8261: function(e, t, n) {
        var o = n("dc54");
        n.n(o).a;
    },
    9385: function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n("2f62"), a = {
                name: "bd-quick-share",
                components: {
                    appGoodsPreviewPoster: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/page-component/goods/app-goods-preview-poster") ]).then(function() {
                            return resolve(n("7dc7"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appShareVideoNumber: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/page-component/app-share-video-number/app-share-video-number") ]).then(function() {
                            return resolve(n("29ab"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    value: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    goodsId: {
                        type: [ Number, String ]
                    },
                    extraQuickShare: {
                        type: Object,
                        required: !1
                    },
                    isVideoNumber: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    appSharePic: String,
                    appShareTitle: String
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? o(Object(n), !0).forEach(function(t) {
                            i(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, r.mapState)({
                    appImg: function(e) {
                        return e.mallConfig.__wxapp_img.quick_share;
                    }
                })),
                data: function() {
                    return {
                        friendModel: !1,
                        posterUrl: "",
                        is_all_btn: !1,
                        is_limit: !0,
                        shareData: null,
                        posterShow: !1,
                        isShowVideoNumber: !1
                    };
                },
                watch: {
                    value: function(t, n) {
                        var o = this;
                        t && setTimeout(function() {
                            var t = o;
                            e.createSelectorQuery().in(t).select("#opacity-hide").boundingClientRect(function(n) {
                                e.createSelectorQuery().in(t).select("#all_hide_text_0").boundingClientRect(function(e) {
                                    t.is_all_btn = e.height + 1 >= n.height;
                                }).exec();
                            }).exec();
                        });
                    }
                },
                methods: {
                    showText: function() {
                        this.is_limit = !this.is_limit;
                    },
                    close: function() {
                        this.$emit("input", !1), this.posterShow = !1;
                    },
                    open: function() {
                        var t, n = this.$api.quick_share.poster_config + "&goods_id=" + this.goodsId, o = this.$api.quick_share.poster_generate + "&goods_id=" + this.goodsId;
                        t = "/pages/poster/goods?poster_config=".concat(escape(n), "&poster_generate=").concat(escape(o)), 
                        e.navigateTo({
                            url: t
                        });
                    },
                    batchCopy: function() {
                        this.copyText(), this.saveImage(!0);
                    },
                    copyText: function() {
                        this.$utils.uniCopy({
                            data: this.extraQuickShare.share_text,
                            success: function() {}
                        });
                    },
                    saveImage: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
                        if (!n.extraQuickShare.share_pic) return "";
                        e.showLoading({
                            title: "图片保存中"
                        }), n.$request({
                            url: n.$api.quick_share.poster_list,
                            data: {
                                goods_id: n.goodsId
                            }
                        }).then(function(o) {
                            if (0 === o.code) {
                                var i = n.extraQuickShare.share_pic.map(function(e) {
                                    return e.pic_url;
                                });
                                i.splice(0, 1, o.data.pic_url), n.$utils.batchSave(i, "image").then(function(o) {
                                    t ? (n.friendModel = !0, setTimeout(function() {
                                        n.friendModel = !1;
                                    }, 1500)) : e.showToast({
                                        title: "保存成功"
                                    });
                                });
                            }
                        }).catch(function(t) {
                            e.hideLoading();
                        });
                    },
                    shareCard: function() {
                        var e = this.appShareTitle ? this.appShareTitle : this.extraQuickShare.share_text, t = "";
                        this.extraQuickShare.share_pic[0].pic_url && (t = this.extraQuickShare.share_pic[0].pic_url), 
                        this.appSharePic && (t = this.appSharePic), this.$emit("quickShare", {
                            title: e,
                            imageUrl: t,
                            path: 0 === this.goodsId ? "/pages/index/index" : "/pages/goods/goods",
                            params: 0 === this.goodsId ? {} : {
                                id: this.goodsId
                            }
                        });
                    },
                    previewImage: function(t) {
                        if (!this.extraQuickShare.share_pic) return "";
                        var n = this.extraQuickShare.share_pic.map(function(e) {
                            return e.pic_url;
                        });
                        e.previewImage({
                            urls: n,
                            current: t
                        });
                    },
                    closeVideoNumber: function() {
                        this.isShowVideoNumber = !1;
                    },
                    videoNumber: function() {
                        this.isShowVideoNumber = !0;
                    }
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    "97e4": function(e, t, n) {
        n.r(t);
        var o = n("9385"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    "9b92": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, i = [];
    },
    dc54: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-quick-share-create-component", {
    "components/page-component/goods/bd-quick-share-create-component": function(e, t, n) {
        n("543d").createComponent(n("519b"));
    }
}, [ [ "components/page-component/goods/bd-quick-share-create-component" ] ] ]);