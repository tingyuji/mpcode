(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-sell-tip" ], {
    "345f": function(e, t, n) {},
    5205: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    "571a": function(e, t, n) {
        n.r(t);
        var o = n("5205"), r = n("9fde");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("8ef6");
        var i = n("f0c5"), a = Object(i.a)(r.default, o.b, o.c, !1, null, "6c2b0bd4", null, !1, o.a, void 0);
        t.default = a.exports;
    },
    "6bb5": function(e, t, n) {
        function o(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                t && (o = o.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function r(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? o(Object(n), !0).forEach(function(t) {
                    c(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function c(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = n("2f62"), a = {
            name: "app-sell-tip",
            components: {},
            props: {
                time: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                }
            },
            data: function() {
                return {
                    timer: null,
                    timeLog: 0
                };
            },
            watch: {
                time: {
                    handler: function() {
                        var e = this, t = this.time;
                        if (!(t <= 0)) {
                            var n = parseInt(t / 60 / 60 / 24), o = parseInt(t / 60 / 60 % 24), r = parseInt(t / 60 % 60), c = parseInt(t % 60);
                            this.timer = {
                                day: n,
                                hour: o < 10 ? "0" + o : o,
                                min: r < 10 ? "0" + r : r,
                                sec: c < 10 ? "0" + c : c
                            }, setTimeout(function() {
                                t -= 1, e.$emit("changeTime", t);
                            }, 1e3);
                        }
                    },
                    immediate: !0
                }
            },
            computed: r(r({}, (0, i.mapState)({
                isTip: function(e) {
                    return e.mallConfig.mall.setting.is_remind_sell_time;
                }
            })), {}, {
                content: function() {
                    var e = "即将开售";
                    return 1 == this.isTip && (e += "，记得设置提醒"), e;
                }
            })
        };
        t.default = a;
    },
    "8ef6": function(e, t, n) {
        var o = n("345f");
        n.n(o).a;
    },
    "9fde": function(e, t, n) {
        n.r(t);
        var o = n("6bb5"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-sell-tip-create-component", {
    "components/page-component/goods/app-sell-tip-create-component": function(e, t, n) {
        n("543d").createComponent(n("571a"));
    }
}, [ [ "components/page-component/goods/app-sell-tip-create-component" ] ] ]);