(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-price" ], {
    "30b3": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = {
            props: {
                max: {
                    type: String,
                    default: function() {
                        return "-1";
                    }
                },
                min: {
                    type: String,
                    default: function() {
                        return "-1";
                    }
                },
                defaultPrice: {
                    type: String,
                    default: function() {
                        return "-1";
                    }
                },
                price: {
                    type: [ String, Number ],
                    default: function() {
                        return "-1";
                    }
                },
                type: {
                    type: String,
                    default: function() {
                        return "text-price";
                    }
                },
                theme: [ Object, String ],
                sign: String,
                priceStyle: {
                    type: [ Number, String ],
                    default: 1
                },
                sizeStyle: {
                    type: Object,
                    default: function() {
                        return {
                            rmb: "32rpx",
                            int: "50rpx",
                            float: "32rpx"
                        };
                    }
                },
                bold: {
                    type: Boolean,
                    default: !1
                },
                alibabaFont: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    priceType: this.type
                };
            },
            computed: {
                actual: function() {
                    var t = -1, e = -1, n = -1, i = -1, r = -1, o = this.type;
                    return "undefined" !== this.price && null !== this.price && (e = Number(this.price)), 
                    "undefined" !== this.min && null !== this.min && (n = Number(this.min)), "undefined" !== this.max && null !== this.max && (i = Number(this.max)), 
                    "undefined" !== this.defaultPrice && null !== this.defaultPrice && (r = Number(this.defaultPrice)), 
                    1 == this.priceStyle ? (!isNaN(e) && e >= 0 ? t = e : i > n && n >= 0 ? t = n + "-" + i : i === n && n >= 0 ? t = n : r >= 0 && (t = r), 
                    0 === t && (t = "免费", o = ""), "integral_mall" === this.sign && "免费" === t && (t = ""), 
                    {
                        price: t,
                        type: o
                    }) : (t = [], !isNaN(e) && e >= 0 ? t = [ this.splitPrice(e) ] : i > n && n >= 0 ? t = [ this.splitPrice(n), this.splitPrice(i) ] : i === n && n >= 0 ? t = [ this.splitPrice(n) ] : r >= 0 && (t = [ this.splitPrice(r) ]), 
                    1 != t.length || 0 != t[0].int || t[0].float || (t = "integral_mall" === this.sign ? [] : [ {
                        int: "免费"
                    } ], o = ""), {
                        price: t,
                        type: o
                    });
                }
            },
            methods: {
                splitPrice: function(t) {
                    var e = t.toString().split(".");
                    return {
                        int: e[0],
                        float: e[1]
                    };
                }
            }
        };
        e.default = i;
    },
    5471: function(t, e, n) {
        n.r(e);
        var i = n("30b3"), r = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = r.a;
    },
    "6c9f": function(t, e, n) {
        n.r(e);
        var i = n("d9d4"), r = n("5471");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        n("fcf4");
        var c = n("f0c5"), a = Object(c.a)(r.default, i.b, i.c, !1, null, "5085a490", null, !1, i.a, void 0);
        e.default = a.exports;
    },
    d9d4: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, r = [];
    },
    e9b9: function(t, e, n) {},
    fcf4: function(t, e, n) {
        var i = n("e9b9");
        n.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-price-create-component", {
    "components/page-component/goods/app-price-create-component": function(t, e, n) {
        n("543d").createComponent(n("6c9f"));
    }
}, [ [ "components/page-component/goods/app-price-create-component" ] ] ]);