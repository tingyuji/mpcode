(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-floating-btn" ], {
    "14de": function(e, t, n) {
        var o = n("c666");
        n.n(o).a;
    },
    "161e": function(e, t, n) {
        n.r(t);
        var o = n("8701"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    "7c8b": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    8701: function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        a(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = n("2f62"), i = {
                name: "app-floating-btn",
                components: {
                    bdQuickShare: function() {
                        n.e("components/page-component/goods/bd-quick-share").then(function() {
                            return resolve(n("519b"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    appShareQrCode: function() {
                        n.e("components/page-component/app-share-qr-code-poster/app-share-qr-code-poster").then(function() {
                            return resolve(n("409e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    isCart: {
                        type: Boolean,
                        default: !0
                    },
                    isShare: {
                        type: Boolean,
                        default: !0
                    },
                    isToTop: {
                        type: Boolean,
                        default: !1
                    },
                    extraQuickShare: Object,
                    goodsId: [ String, Number ],
                    goods: Object,
                    appSharePic: String,
                    appShareTitle: String,
                    shareUrl: String,
                    posterConfig: String,
                    posterGenerate: String,
                    hasPosterNav: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    }
                },
                data: function() {
                    return {
                        shareShow: !1,
                        quickShareShow: !1
                    };
                },
                watch: {},
                computed: r(r(r({}, (0, c.mapState)("user", {
                    cart_nums: function(e) {
                        return e.cart_nums;
                    }
                })), (0, c.mapState)({
                    is_share_btn: function(e) {
                        return e.mallConfig.mall.setting.is_share_btn;
                    },
                    suspension_icon: function(e) {
                        return e.mallConfig.mall.setting.suspension_icon;
                    }
                })), (0, c.mapGetters)("iPhoneX", {
                    getBoolEmpty: "getBoolEmpty"
                })),
                methods: {
                    backTop: function() {
                        e.pageScrollTo({
                            scrollTop: 0,
                            duration: 300
                        });
                    },
                    shareClick: function() {
                        this.$user.isLogin() ? this.extraQuickShare ? this.quickShareShow = !0 : this.shareShow = !0 : this.$user.getInfo().then(function() {});
                    },
                    testShare: function(e) {
                        this.$emit("share", e);
                    },
                    quickShare: function(e) {
                        this.$emit("quickShare", e);
                    },
                    newShareUrl: function() {
                        return this.shareUrl ? this.shareUrl : this.goodsId ? this.$api.poster.goods + "&goods_id=" + this.goodsId : "";
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    c666: function(e, t, n) {},
    d816: function(e, t, n) {
        n.r(t);
        var o = n("7c8b"), r = n("161e");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        n("14de");
        var c = n("f0c5"), i = Object(c.a)(r.default, o.b, o.c, !1, null, "96739350", null, !1, o.a, void 0);
        t.default = i.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-floating-btn-create-component", {
    "components/page-component/goods/app-floating-btn-create-component": function(e, t, n) {
        n("543d").createComponent(n("d816"));
    }
}, [ [ "components/page-component/goods/app-floating-btn-create-component" ] ] ]);