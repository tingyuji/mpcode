(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-goods-preview-poster" ], {
    "33fe": function(e, t, n) {
        n.r(t);
        var o = n("93e5"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    "6a44": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    "7dc7": function(e, t, n) {
        n.r(t);
        var o = n("6a44"), r = n("33fe");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        n("89e6");
        var i = n("f0c5"), c = Object(i.a)(r.default, o.b, o.c, !1, null, "6329a454", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "89e6": function(e, t, n) {
        var o = n("dd7f");
        n.n(o).a;
    },
    "93e5": function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function r(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n("2f62"), i = {
                name: "app-goods-preview-poster",
                props: {
                    value: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    url: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    disabled: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    }
                },
                created: function() {
                    this.showHidden = this.value;
                },
                watch: {
                    value: function(e) {
                        this.showHidden = e;
                    },
                    showHidden: function(e) {
                        e && this.getShareImg();
                    }
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? o(Object(n), !0).forEach(function(t) {
                            r(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, a.mapState)({
                    commonImg: function(e) {
                        return e.mallConfig.__wxapp_img.common;
                    }
                })),
                data: function() {
                    return {
                        showHidden: !1,
                        loading: !0,
                        shareImage: ""
                    };
                },
                methods: {
                    showHiddenClick: function() {
                        this.$emit("close", !1);
                    },
                    savePicture: function() {
                        this.loading || this.$utils.batchSave(this.shareImage, "image").then(function() {
                            e.showToast({
                                title: "保存成功"
                            });
                        });
                    },
                    getShareImg: function() {
                        var t = this;
                        this.url && (this.loading = !0, this.$request({
                            url: this.url
                        }).then(function(n) {
                            0 === n.code ? (t.shareImage = n.data.pic_url, t.loading = !1) : e.showModal({
                                content: n.msg,
                                showCancel: !1
                            });
                        }));
                    },
                    preview: function() {
                        e.previewImage({
                            urls: [ this.shareImage ]
                        });
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    dd7f: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-goods-preview-poster-create-component", {
    "components/page-component/goods/app-goods-preview-poster-create-component": function(e, t, n) {
        n("543d").createComponent(n("7dc7"));
    }
}, [ [ "components/page-component/goods/app-goods-preview-poster-create-component" ] ] ]);