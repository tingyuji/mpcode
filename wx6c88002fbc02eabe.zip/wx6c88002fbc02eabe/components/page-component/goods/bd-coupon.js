(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-coupon" ], {
    "11b2": function(e, n, t) {
        t.r(n);
        var o = t("1eb7"), c = t("fe55");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(r);
        t("c117");
        var u = t("f0c5"), a = Object(u.a)(c.default, o.b, o.c, !1, null, "9c70d85c", null, !1, o.a, void 0);
        n.default = a.exports;
    },
    "1eb7": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(n) {
                e.show = !1;
            }, e.e1 = function(n) {
                e.show = !1;
            });
        }, c = [];
    },
    "6da3": function(e, n, t) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function r(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            function u(e, n, t, o, c, r, u) {
                try {
                    var a = e[r](u), i = a.value;
                } catch (e) {
                    return void t(e);
                }
                a.done ? n(i) : Promise.resolve(i).then(o, c);
            }
            function a(e) {
                return function() {
                    var n = this, t = arguments;
                    return new Promise(function(o, c) {
                        function r(e) {
                            u(i, o, c, r, a, "next", e);
                        }
                        function a(e) {
                            u(i, o, c, r, a, "throw", e);
                        }
                        var i = e.apply(n, t);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = o(t("a34a")), p = t("2f62"), s = o(t("816e")), f = {
                name: "bd-coupon",
                props: {
                    coupons: Array,
                    theme: Object,
                    guarantee_title: {
                        type: String
                    },
                    type: {
                        type: [ String, Number ],
                        default: 1
                    }
                },
                data: function() {
                    return {
                        show: !1,
                        newCoupons: []
                    };
                },
                methods: {
                    receive: function() {
                        var n = a(i.default.mark(function n(t, o) {
                            var c, r, u = arguments;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return c = u.length > 2 && void 0 !== u[2] ? u[2] : 0, e.showLoading({
                                        mask: !0,
                                        title: "领取中"
                                    }), n.next = 4, this.$request({
                                        url: this.$api.coupon.receive,
                                        data: {
                                            coupon_id: t,
                                            mch_id: c
                                        }
                                    });

                                  case 4:
                                    r = n.sent, e.hideLoading(), 1 === r.code ? e.showModal({
                                        title: "提示",
                                        content: r.msg,
                                        showCancel: !1
                                    }) : (0 == r.data.rest && this.$emit("change", o), e.showToast({
                                        icon: "none",
                                        title: "领取成功",
                                        duration: 1e3
                                    }));

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, this);
                        }));
                        return function(e, t) {
                            return n.apply(this, arguments);
                        };
                    }(),
                    setShow: function() {
                        s.default.isLogin() ? this.show = !0 : this.$user.getInfo();
                    }
                },
                computed: function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = null != arguments[n] ? arguments[n] : {};
                        n % 2 ? c(Object(t), !0).forEach(function(n) {
                            r(e, n, t[n]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : c(Object(t)).forEach(function(n) {
                            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                        });
                    }
                    return e;
                }({}, (0, p.mapState)({
                    couponImg: function(e) {
                        return e.mallConfig.__wxapp_img.coupon;
                    },
                    goodImg: function(e) {
                        return e.mallConfig.__wxapp_img.goods;
                    }
                })),
                components: {
                    uPopup: function() {
                        t.e("components/basic-component/u-popup/u-popup").then(function() {
                            return resolve(t("d55a"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    appExclusiveCoupon: function() {
                        t.e("components/page-component/app-exclusive-coupon/app-exclusive-coupon").then(function() {
                            return resolve(t("bdfc"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                watch: {
                    coupons: {
                        handler: function(e) {
                            this.newCoupons = e.slice(0, 3);
                        },
                        deep: !0,
                        immediate: !0
                    }
                }
            };
            n.default = f;
        }).call(this, t("543d").default);
    },
    c117: function(e, n, t) {
        var o = t("ea19");
        t.n(o).a;
    },
    ea19: function(e, n, t) {},
    fe55: function(e, n, t) {
        t.r(n);
        var o = t("6da3"), c = t.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(r);
        n.default = c.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-coupon-create-component", {
    "components/page-component/goods/bd-coupon-create-component": function(e, n, t) {
        t("543d").createComponent(t("11b2"));
    }
}, [ [ "components/page-component/goods/bd-coupon-create-component" ] ] ]);