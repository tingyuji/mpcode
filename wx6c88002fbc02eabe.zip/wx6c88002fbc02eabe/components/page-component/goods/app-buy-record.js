(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-buy-record" ], {
    "035c": function(e, t, n) {
        n.r(t);
        var o = n("455c"), r = n("2cb0f");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("e47f");
        var a = n("f0c5"), i = Object(a.a)(r.default, o.b, o.c, !1, null, "4c049305", null, !1, o.a, void 0);
        t.default = i.exports;
    },
    "130b": function(e, t, n) {},
    "2cb0f": function(e, t, n) {
        n.r(t);
        var o = n("cca0"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = r.a;
    },
    "455c": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    cca0: function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        c(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n("2f62"), i = {
                data: function() {
                    return {
                        data: [],
                        records_num: 0
                    };
                },
                props: {
                    goodsId: [ Number, String ]
                },
                computed: r(r({}, (0, a.mapGetters)("mallConfig", {
                    getTheme: "getTheme"
                })), (0, a.mapState)({
                    buy_scroll: function(e) {
                        return e.mallConfig.mall.setting.buy_scroll;
                    }
                })),
                watch: {
                    goodsId: {
                        handler: function(e) {
                            e && this.buy_scroll && this.getList(e);
                        },
                        immediate: !0
                    }
                },
                methods: {
                    getList: function(t) {
                        var n = this;
                        this.$request({
                            url: this.$api.goods.buy_scroll,
                            data: {
                                id: t
                            }
                        }).then(function(t) {
                            if (0 === t.code) {
                                var o = t.data.list.map(function(e) {
                                    return e.show_attr = n.handlerAttr(e.attr_list), e.pay_time = n.handlerTime(e.pay_time), 
                                    e;
                                });
                                if (n.records_num = o.length, o.length <= 2) n.data = o; else {
                                    var r = o.length % 2 == 0 ? o : o.concat(o);
                                    r.forEach(function(e, t) {
                                        t % 2 != 0 && n.data.push([ r[t - 1], e ]);
                                    });
                                }
                            } else e.showToast({
                                title: t.msg,
                                icon: "none"
                            });
                        });
                    },
                    handlerAttr: function(e) {
                        var t = "";
                        return e.forEach(function(e) {
                            t ? t += "  ".concat(e.attr_group_name, ":").concat(e.attr_name) : t = "".concat(e.attr_group_name, ":").concat(e.attr_name);
                        }), t;
                    },
                    handlerTime: function(e) {
                        var t = new Date(e).getTime();
                        if (t) {
                            var n = this.$utils.timeDifference(t, new Date().getTime()), o = n.h.replace(/\b(0+)/gi, ""), r = n.m.replace(/\b(0+)/gi, "");
                            return n.d >= 1 ? "1天前" : o >= 1 ? "".concat(o, "小时前") : r >= 1 ? "".concat(r, "分钟前") : "刚刚";
                        }
                        return "1天前";
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    e47f: function(e, t, n) {
        var o = n("130b");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-buy-record-create-component", {
    "components/page-component/goods/app-buy-record-create-component": function(e, t, n) {
        n("543d").createComponent(n("035c"));
    }
}, [ [ "components/page-component/goods/app-buy-record-create-component" ] ] ]);