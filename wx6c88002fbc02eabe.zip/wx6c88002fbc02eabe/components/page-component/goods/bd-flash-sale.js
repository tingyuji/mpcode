(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/bd-flash-sale" ], {
    2479: function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        r(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function r(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = n("2f62"), u = {
                name: "bd-flash-sale",
                props: {
                    flashSale: {
                        type: Object,
                        default: function() {
                            return {
                                time_status: 1,
                                start_at: "",
                                end_at: "",
                                min_discount: ""
                            };
                        }
                    },
                    theme: Object
                },
                computed: a(a({}, (0, c.mapState)({
                    appImg: function(e) {
                        return e.mallConfig.__wxapp_img;
                    }
                })), {}, {
                    flashStyle: function() {
                        return "a" == this.theme.theme && this.flashSale.cover ? "background-image: url('" + this.flashSale.cover + ")" : "background:" + this.theme.background_p;
                    }
                }),
                methods: {
                    navigator: function() {
                        e.navigateTo({
                            url: this.flashSale.url
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    "28dc": function(e, t, n) {
        n.r(t);
        var o = n("2479"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    "8cd8": function(e, t, n) {},
    "975a": function(e, t, n) {
        n.r(t);
        var o = n("a9e6"), a = n("28dc");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("d5e5");
        var c = n("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, "53a3e5bc", null, !1, o.a, void 0);
        t.default = u.exports;
    },
    a9e6: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    d5e5: function(e, t, n) {
        var o = n("8cd8");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/bd-flash-sale-create-component", {
    "components/page-component/goods/bd-flash-sale-create-component": function(e, t, n) {
        n("543d").createComponent(n("975a"));
    }
}, [ [ "components/page-component/goods/bd-flash-sale-create-component" ] ] ]);