(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/goods/app-goods-full-reduce" ], {
    "0a5f": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, i = [];
    },
    "245f": function(t, e, n) {
        n.r(e);
        var o = n("973c"), i = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e.default = i.a;
    },
    6132: function(t, e, n) {
        n.r(e);
        var o = n("0a5f"), i = n("245f");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(c);
        n("86c1");
        var u = n("f0c5"), a = Object(u.a)(i.default, o.b, o.c, !1, null, "680ae576", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    "86c1": function(t, e, n) {
        var o = n("96dd");
        n.n(o).a;
    },
    "96dd": function(t, e, n) {},
    "973c": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                name: "app-goods-full-reduce",
                props: {
                    theme: Object,
                    full_reduce: Object,
                    sign: String
                },
                data: function() {
                    return {
                        textWidth: 0,
                        resultWidth: 0,
                        list: [],
                        opacity: !1
                    };
                },
                methods: {
                    route: function() {
                        t.navigateTo({
                            url: "/pages/full_reduce/index/index"
                        });
                    },
                    initSize: function() {
                        for (var e = this, n = [], o = 0; o < this.list.length; o++) !function(o) {
                            n.push(new Promise(function(n) {
                                t.createSelectorQuery().in(e).select("#bd-".concat(o, "-text")).boundingClientRect().exec(function(o) {
                                    o[0] && (e.textWidth += o[0].width + t.upx2px(10)), n();
                                });
                            }));
                        }(o);
                        Promise.all(n).then(function() {
                            e.resultWidth = e.textWidth;
                        });
                    }
                },
                watch: {
                    "full_reduce.rule": {
                        immediate: !0,
                        handler: function(t) {
                            var e = this;
                            this.list = t, this.textWidth = 0, setTimeout(function() {
                                e.initSize();
                            }, 500);
                        },
                        deep: !0
                    },
                    resultWidth: {
                        handler: function(e) {
                            var n = this;
                            e > t.upx2px(552) ? (this.list = this.list.slice(0, this.list.length - 1), this.textWidth = 0, 
                            this.$nextTick(function() {
                                n.initSize();
                            })) : this.opacity = !0;
                        }
                    }
                },
                mounted: function() {
                    var t = this;
                    setTimeout(function() {
                        t.list = t.full_reduce.rule, t.textWidth = 0, setTimeout(function() {
                            t.initSize();
                        }, 500);
                    }, 500);
                }
            };
            e.default = n;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/goods/app-goods-full-reduce-create-component", {
    "components/page-component/goods/app-goods-full-reduce-create-component": function(t, e, n) {
        n("543d").createComponent(n("6132"));
    }
}, [ [ "components/page-component/goods/app-goods-full-reduce-create-component" ] ] ]);