(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-popup-ad/app-popup-ad" ], {
    "06e7": function(t, p, e) {
        Object.defineProperty(p, "__esModule", {
            value: !0
        }), p.default = void 0, e("2f62");
        var n = {
            name: "app-popup-ad",
            props: {
                opened: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                times: {
                    type: Number,
                    default: function() {
                        return 1;
                    }
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                multiple: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                },
                mark: {
                    type: String,
                    default: function() {
                        return "fxhb";
                    }
                },
                is_storage: Boolean,
                isIndexGray: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    newList: [],
                    popupActive: -1
                };
            },
            computed: {
                listenChange: function() {
                    return {
                        multiple: this.multiple,
                        list: this.list,
                        is_storage: this.is_storage,
                        times: this.times
                    };
                }
            },
            watch: {
                listenChange: {
                    handler: function(t) {
                        this.init();
                    },
                    immediate: !0
                }
            },
            methods: {
                init: function() {
                    var t = this;
                    this.multiple ? this.newList = this.list : this.newList = [ this.list ], this.opened && (void 0 === this.$popupAd.list[this.mark] && (this.$popupAd.list[this.mark] = !0, 
                    this.$event.on(this.$const.EVENT_POPUP, !1).then(function(p) {
                        p === t.mark && t.showPopupModal();
                    })), this.showPopupModal());
                },
                showPopupModal: function() {
                    if (!this.$popupAd.show) {
                        var t = "popUpFirst" + this.mark;
                        this.$popupAd.show = this.mark;
                        var p = -1;
                        p = 0 === this.times ? 0 : this.$popupAd.first[t] ? -1 : 0, this.is_storage || (this.$popupAd.first[t] = !0), 
                        this.popupActive = p, this.nextModal();
                    }
                },
                nextModal: function() {
                    if (this.list.length <= this.popupActive || -1 === this.popupActive) {
                        var t = this.$popupAd.list, p = !1;
                        for (var e in t) {
                            if (p) {
                                p = !1, this.$event.trigger(this.$const.EVENT_POPUP, e);
                                break;
                            }
                            e === this.mark && (p = !0);
                        }
                        p || (this.$popupAd.show = null);
                    }
                },
                closePopupModal: function() {
                    var t = this.popupActive;
                    t += 1, this.popupActive = t, this.$popupAd.show = null, this.nextModal();
                }
            }
        };
        p.default = n;
    },
    "23d0": function(t, p, e) {
        var n = e("4e92");
        e.n(n).a;
    },
    "4e92": function(t, p, e) {},
    "7ec9": function(t, p, e) {
        e.r(p);
        var n = e("aa16"), o = e("9eaea");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(p, t, function() {
                return o[t];
            });
        }(i);
        e("23d0");
        var a = e("f0c5"), s = Object(a.a)(o.default, n.b, n.c, !1, null, "136ca006", null, !1, n.a, void 0);
        p.default = s.exports;
    },
    "9eaea": function(t, p, e) {
        e.r(p);
        var n = e("06e7"), o = e.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(p, t, function() {
                return n[t];
            });
        }(i);
        p.default = o.a;
    },
    aa16: function(t, p, e) {
        e.d(p, "b", function() {
            return n;
        }), e.d(p, "c", function() {
            return o;
        }), e.d(p, "a", function() {});
        var n = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, o = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-popup-ad/app-popup-ad-create-component", {
    "components/page-component/app-popup-ad/app-popup-ad-create-component": function(t, p, e) {
        e("543d").createComponent(e("7ec9"));
    }
}, [ [ "components/page-component/app-popup-ad/app-popup-ad-create-component" ] ] ]);