(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-member-mark/app-member-mark" ], {
    "0eb7": function(e, n, t) {
        var r = t("8198");
        t.n(r).a;
    },
    "1ed7": function(e, n, t) {
        t.r(n);
        var r = t("42b2"), a = t("975a5");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(o);
        t("0eb7");
        var p = t("f0c5"), c = Object(p.a)(a.default, r.b, r.c, !1, null, "3e899e4a", null, !1, r.a, void 0);
        n.default = c.exports;
    },
    "42b2": function(e, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    8198: function(e, n, t) {},
    "975a5": function(e, n, t) {
        t.r(n);
        var r = t("b4cf"), a = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = a.a;
    },
    b4cf: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = {
            name: "app-member-mark",
            props: {
                sign: String,
                width: {
                    type: String,
                    default: function() {
                        return "92rpx";
                    }
                },
                mode: {
                    type: String,
                    default: function() {
                        return "normal";
                    }
                },
                font: {
                    type: String,
                    default: function() {
                        return "20rpx";
                    }
                },
                height: {
                    type: Number,
                    default: function() {
                        return 40;
                    }
                },
                theme: [ Object, String ],
                label: {
                    type: String,
                    default: function() {
                        return "会员价";
                    }
                }
            }
        };
        n.default = r;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-member-mark/app-member-mark-create-component", {
    "components/page-component/app-member-mark/app-member-mark-create-component": function(e, n, t) {
        t("543d").createComponent(t("1ed7"));
    }
}, [ [ "components/page-component/app-member-mark/app-member-mark-create-component" ] ] ]);