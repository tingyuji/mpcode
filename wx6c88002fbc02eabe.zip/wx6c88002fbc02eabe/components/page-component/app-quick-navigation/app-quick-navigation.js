(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-quick-navigation/app-quick-navigation" ], {
    "12e0": function(e, t, n) {
        var a = n("e4a3");
        n.n(a).a;
    },
    "17ab": function(e, t, n) {
        (function(e) {
            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach(function(t) {
                        o(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function o(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var p = n("2f62"), c = {
                name: "app-quick-navigation",
                props: {
                    value: {
                        type: Object,
                        default: function() {
                            return {
                                closedPicUrl: "",
                                customerService: {
                                    opened: !1,
                                    picUrl: ""
                                },
                                home: {
                                    opened: !1,
                                    picUrl: "g"
                                },
                                mApp: {
                                    appId: "",
                                    opened: !1,
                                    page: "",
                                    picUrl: ""
                                },
                                mapNav: {
                                    address: "南湖",
                                    latitude: "",
                                    location: "",
                                    longitude: "",
                                    opened: !1,
                                    picUrl: ""
                                },
                                navStyle: 1,
                                navSwitch: 1,
                                openedPicUrl: "",
                                tel: {
                                    number: "",
                                    opened: !1,
                                    picUrl: ""
                                },
                                useMallConfig: !1,
                                web: {
                                    opened: !0,
                                    picUrl: "",
                                    url: ""
                                },
                                customize: {}
                            };
                        }
                    },
                    useMallConfig: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    quickNavBottom: {
                        type: Number,
                        default: 0
                    },
                    page_id: {
                        type: [ Number, String ],
                        default: ""
                    }
                },
                components: {
                    appShareQrCode: function() {
                        n.e("components/page-component/app-share-qr-code-poster/app-share-qr-code-poster").then(function() {
                            return resolve(n("409e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        collapse: !1,
                        oldData: this.value,
                        shareShow: !1
                    };
                },
                computed: i(i({
                    newData: function() {
                        var e = {};
                        if (this.useMallConfig) {
                            var t = this.mall.setting;
                            e = {
                                closedPicUrl: t.quick_navigation_closed_pic,
                                openedPicUrl: t.quick_navigation_opened_pic,
                                share_button: {
                                    is_share_button: 1 == t.is_share_button,
                                    share_button_pic: t.share_button_pic,
                                    poster_data: t.share_poster_data
                                },
                                customerService: {
                                    opened: 1 == t.is_customer_services,
                                    picUrl: t.customer_services_pic,
                                    open_type: "contact"
                                },
                                home: {
                                    opened: 1 == t.is_quick_home && this.oldData.home.opened,
                                    picUrl: t.quick_home_pic,
                                    open_type: "redirect",
                                    link_url: "/pages/index/index"
                                },
                                mApp: {
                                    appId: t.small_app_id,
                                    opened: 1 == t.is_small_app,
                                    page: t.small_app_url,
                                    picUrl: t.small_app_pic,
                                    open_type: "app"
                                },
                                mapNav: {
                                    opened: 1 == t.is_quick_map,
                                    address: t.quick_map_address,
                                    latitude: t.latitude,
                                    longitude: t.longitude,
                                    picUrl: t.quick_map_pic,
                                    open_type: "map"
                                },
                                tel: {
                                    opened: 1 == t.is_dial,
                                    number: t.contact_tel,
                                    picUrl: t.dial_pic,
                                    open_type: "tel"
                                },
                                web: {
                                    opened: 1 == t.is_web_service,
                                    url: "/pages/web/web?url=" + t.web_service_url,
                                    picUrl: t.web_service_pic,
                                    open_type: "web"
                                },
                                customize: {
                                    opened: 1 == t.is_quick_customize,
                                    picUrl: t.quick_customize_pic,
                                    link_url: t.quick_customize_link_url,
                                    params: t.quick_customize_new_params,
                                    open_type: t.quick_customize_open_type
                                },
                                navStyle: t.quick_navigation_style,
                                navSwitch: t.is_quick_navigation
                            };
                        } else for (var n in e = {
                            customerService: {
                                open_type: "contact"
                            },
                            home: {
                                open_type: "redirect",
                                link_url: "/pages/index/index"
                            },
                            mApp: {
                                open_type: "app"
                            },
                            mapNav: {
                                open_type: "map"
                            },
                            tel: {
                                open_type: "tel"
                            },
                            web: {
                                open_type: "web"
                            },
                            customize: {
                                open_type: ""
                            },
                            share_button: {}
                        }, this.oldData) if ("customerService" === n || "home" === n || "mApp" === n || "mapNav" === n || "tel" === n) e[n] = i(i({}, e[n]), this.oldData[n]); else if ("web" === n) {
                            var a = "../web/web?url=".concat(this.oldData[n].url);
                            e.web = i(i(i({}, e.web), this.oldData[n]), {}, {
                                url: a
                            });
                        } else e[n] = this.oldData[n];
                        return e;
                    }
                }, (0, p.mapState)({
                    mall: function(e) {
                        return e.mallConfig.mall;
                    },
                    plugin: function(e) {
                        return e.mallConfig.plugin;
                    }
                })), (0, p.mapGetters)("iPhoneX", {
                    getBoolEmpty: "getBoolEmpty"
                })),
                onLoad: function() {},
                watch: {
                    oldData: {
                        handler: function() {
                            var e = getCurrentPages(), t = null;
                            e.length && (t = e[e.length - 1]), this.currentRoute = "/".concat(t.route.split("?")[0]), 
                            "/pages/index/index" === this.currentRoute && getCurrentPages().length <= 1 ? this.oldData.home.opened = !1 : this.oldData.home.opened = !0;
                        },
                        immediate: !0
                    },
                    value: {
                        handler: function(e) {
                            this.oldData = e;
                        }
                    }
                },
                methods: {
                    webService: function() {
                        function t(t) {
                            e.navigateTo({
                                url: t
                            });
                        }
                        var n = this;
                        void 0 === this.plugin.dianqilai ? t(this.newData.web.url) : this.$subscribe(this.plugin.dianqilai.template_message_captain).then(function(e) {
                            t(n.newData.web.url);
                        }).catch(function(e) {
                            t(n.newData.web.url);
                        });
                    },
                    toShare: function() {
                        this.shareShow = !0;
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    3422: function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.collapse = !e.collapse;
            });
        }, i = [];
    },
    "4d92a": function(e, t, n) {
        n.r(t);
        var a = n("3422"), i = n("5f480");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("12e0");
        var p = n("f0c5"), c = Object(p.a)(i.default, a.b, a.c, !1, null, "25f0b6a3", null, !1, a.a, void 0);
        t.default = c.exports;
    },
    "5f480": function(e, t, n) {
        n.r(t);
        var a = n("17ab"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    },
    e4a3: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-quick-navigation/app-quick-navigation-create-component", {
    "components/page-component/app-quick-navigation/app-quick-navigation-create-component": function(e, t, n) {
        n("543d").createComponent(n("4d92a"));
    }
}, [ [ "components/page-component/app-quick-navigation/app-quick-navigation-create-component" ] ] ]);