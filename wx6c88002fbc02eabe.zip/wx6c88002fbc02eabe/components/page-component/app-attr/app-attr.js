(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-attr/app-attr" ], {
    "0421": function(t, e, r) {
        var i = r("8005");
        r.n(i).a;
    },
    "7c03e": function(t, e, r) {
        r.d(e, "b", function() {
            return i;
        }), r.d(e, "c", function() {
            return o;
        }), r.d(e, "a", function() {});
        var i = function() {
            var t = this, e = (t.$createElement, t._self._c, "block" === t.display && t.chooseNumber && (t.goods.min_number > 1 || 1 == t.goods.limit_buy.status) && 1 == t.goods.limit_buy.status ? t.__map(t.goods.limit_buy.msg.split(""), function(e, r) {
                return {
                    $orig: t.__get_orig(e),
                    m0: isNaN(Number(e))
                };
            }) : null), r = "block" === t.display && "wholesale" === t.sign && (t.goods.wholesaleGoods.rise_num > 1 || 1 == t.goods.limit_buy.status) && 1 == t.goods.limit_buy.status ? t.__map(t.goods.limit_buy.msg.split(""), function(e, r) {
                return {
                    $orig: t.__get_orig(e),
                    m1: isNaN(Number(e))
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e,
                    l1: r
                }
            });
        }, o = [];
    },
    8005: function(t, e, r) {},
    a031: function(t, e, r) {
        (function(t) {
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function o(t, e) {
                var r = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), r.push.apply(r, i);
                }
                return r;
            }
            function s(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(r), !0).forEach(function(e) {
                        n(t, e, r[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : o(Object(r)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
                    });
                }
                return t;
            }
            function n(t, e, r) {
                return e in t ? Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = r, t;
            }
            function a(t, e, r, i, o, s, n) {
                try {
                    var a = t[s](n), u = a.value;
                } catch (t) {
                    return void r(t);
                }
                a.done ? e(u) : Promise.resolve(u).then(i, o);
            }
            function u(t) {
                return function() {
                    var e = this, r = arguments;
                    return new Promise(function(i, o) {
                        function s(t) {
                            a(u, i, o, s, n, "next", t);
                        }
                        function n(t) {
                            a(u, i, o, s, n, "throw", t);
                        }
                        var u = t.apply(e, r);
                        s(void 0);
                    });
                };
            }
            function l(t, e) {
                var r = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!r) {
                    if (Array.isArray(t) || (r = c(t)) || e && t && "number" == typeof t.length) {
                        r && (t = r);
                        var i = 0, o = function() {};
                        return {
                            s: o,
                            n: function() {
                                return i >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[i++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: o
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var s, n = !0, a = !1;
                return {
                    s: function() {
                        r = r.call(t);
                    },
                    n: function() {
                        var t = r.next();
                        return n = t.done, t;
                    },
                    e: function(t) {
                        a = !0, s = t;
                    },
                    f: function() {
                        try {
                            n || null == r.return || r.return();
                        } finally {
                            if (a) throw s;
                        }
                    }
                };
            }
            function c(t, e) {
                if (t) {
                    if ("string" == typeof t) return h(t, e);
                    var r = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === r && t.constructor && (r = t.constructor.name), "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? h(t, e) : void 0;
                }
            }
            function h(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var r = 0, i = new Array(e); r < e; r++) i[r] = t[r];
                return i;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var d = i(r("a34a")), p = r("2f62"), m = {
                name: "app-attr",
                mixins: [ i(r("1639")).default ],
                components: {
                    appPrice: function() {
                        r.e("components/page-component/goods/app-price").then(function() {
                            return resolve(r("6c9f"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    appMemberMark: function() {
                        r.e("components/page-component/app-member-mark/app-member-mark").then(function() {
                            return resolve(r("1ed7"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    appSellTip: function() {
                        r.e("components/page-component/goods/app-sell-tip").then(function() {
                            return resolve(r("571a"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    appPreviewImage: function() {
                        r.e("components/basic-component/app-preview-image/app-preview-image").then(function() {
                            return resolve(r("8f77"));
                        }.bind(null, r)).catch(r.oe);
                    }
                },
                props: {
                    goods: Object,
                    attrGroupList: Array,
                    attrCart: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    cartShow: {
                        type: [ Boolean, Number ],
                        default: function() {
                            return !0;
                        }
                    },
                    previewUrl: String,
                    submitUrl: String,
                    goodsId: {
                        type: Number,
                        default: function() {
                            return 0;
                        }
                    },
                    show: Number,
                    buyText: {
                        type: String,
                        default: function() {
                            return "立即购买";
                        }
                    },
                    plugin: {
                        default: ""
                    },
                    theme: {
                        type: Object
                    },
                    chooseNumber: {
                        type: Boolean,
                        default: !0
                    },
                    noPay: {
                        type: Boolean,
                        default: !1
                    },
                    buyClick: {
                        type: Boolean,
                        default: !1
                    },
                    addText: {
                        type: String,
                        default: "加入购物车"
                    },
                    is_show_buy: {
                        type: Boolean,
                        default: !0
                    },
                    sign: {
                        type: String
                    },
                    totalPrice: {
                        type: String,
                        default: "0.00"
                    },
                    totalNumber: {
                        type: Number,
                        default: 0
                    },
                    discount: {
                        type: Number,
                        default: 0
                    },
                    wholesaleType: {
                        type: Number,
                        default: 0
                    },
                    attentionSign: {
                        type: String
                    }
                },
                data: function() {
                    return {
                        display: "none",
                        number: 1,
                        selectAttr: null,
                        newAttrGroupList: null,
                        pic_url: null,
                        showAttrImg: !1,
                        activeAttr: [],
                        goodsAttr: [],
                        sell_time: 0,
                        showPreview: !1,
                        cover_list: [],
                        attrIndex: 0,
                        x_s: 0,
                        g_s: 0,
                        priceSize: {
                            rmb: "26rpx",
                            int: "36rpx",
                            float: "36rpx"
                        }
                    };
                },
                watch: {
                    show: function() {
                        "block" === this.display ? (this.selectAttr = null, this.close()) : "none" === this.display && this.alert();
                    },
                    newData: {
                        handler: function() {
                            this.$emit("attr", this.newData);
                        },
                        immediate: !0
                    },
                    attrGroupList: {
                        handler: function() {
                            this.newAttrGroupList = this.attrGroupList, "block" == this.display && this.alert();
                        },
                        immediate: !0
                    },
                    goods: {
                        handler: function() {
                            "block" == this.display && this.alert(), this.goods && (this.sell_time = this.goods.sell_time);
                        },
                        immediate: !0
                    }
                },
                mounted: function() {
                    if ("wholesale" == this.sign) if (this.pic_url = this.goods.attr_groups[0].attr_list[0].pic_url, 
                    1 == this.goods.attr_groups.length) this.goodsAttr = this.goods.attr; else {
                        var t, e = l(this.goods.attr_groups);
                        try {
                            for (e.s(); !(t = e.n()).done; ) {
                                var r = t.value, i = {
                                    attr_group_name: "",
                                    attr_group_id: "",
                                    attr_id: "",
                                    attr_name: ""
                                };
                                i.attr_group_name = r.attr_group_name, i.attr_group_id = r.attr_group_id, i.attr_id = r.attr_list[0].attr_id, 
                                i.attr_name = r.attr_list[0].attr_name, this.activeAttr.push(i);
                            }
                        } catch (t) {
                            e.e(t);
                        } finally {
                            e.f();
                        }
                        var o, s = l(this.goods.attr);
                        try {
                            for (s.s(); !(o = s.n()).done; ) {
                                for (var n = o.value, a = !0, u = 0; u < n.attr_list.length - 1; u++) {
                                    var c = {
                                        attr_group_name: n.attr_list[u].attr_group_name,
                                        attr_group_id: n.attr_list[u].attr_group_id,
                                        attr_id: n.attr_list[u].attr_id,
                                        attr_name: n.attr_list[u].attr_name
                                    };
                                    JSON.stringify(c) != JSON.stringify(this.activeAttr[u]) && (a = !1);
                                }
                                a && this.goodsAttr.push(n);
                            }
                        } catch (t) {
                            s.e(t);
                        } finally {
                            s.f();
                        }
                    }
                },
                methods: {
                    closePreview: function(t) {
                        if (t != this.attrIndex) {
                            var e = this.goods.attr_groups[0], r = e.attr_list[t];
                            this.storeAttrClick(r.attr_id, e.attr_group_id);
                        }
                        this.attrIndex = t, this.showPreview = !1;
                    },
                    previewCover: function(t, e) {
                        if (this.attrIndex = t, !e) {
                            var r = this.goods.attr_groups[0], i = r.attr_list[t];
                            this.storeAttrClick(i.attr_id, r.attr_group_id);
                        }
                        this.showPreview = !0;
                    },
                    alert: function() {
                        if (!this.attrGroupList || 0 !== this.attrGroupList.length) {
                            if ("wholesale" !== this.sign) {
                                var t = this.attrGroupList, e = this.goods.attr, r = null;
                                if (this.number = 1, 1 === t.length) {
                                    for (var i in e) for (var o in t[0].attr_list) t[0].attr_list[o].attr_id == e[i].attr_list[0].attr_id && (e[i].stock > 0 ? (1 === e.length && (t[0].attr_list[o].checked = !0), 
                                    t[0].attr_list[o].attr_num_0 = !1, this.pic_url = t[0].attr_list[o].pic_url) : (this.number = 0, 
                                    t[0].attr_list[o].checked = !1, t[0].attr_list[o].attr_num_0 = !0));
                                    1 === e.length && (r = e[0], this.$emit("attrtap", r));
                                }
                                this.newAttrGroupList = t, this.cover_list = [], this.showAttrImg = !1;
                                var s, n = l(this.newAttrGroupList[0].attr_list);
                                try {
                                    for (n.s(); !(s = n.n()).done; ) {
                                        var a = s.value;
                                        this.cover_list.push({
                                            pic_url: a.pic_url ? a.pic_url : this.goods.cover_pic,
                                            name: a.attr_name
                                        }), a.pic_url && (this.showAttrImg = !0);
                                    }
                                } catch (t) {
                                    n.e(t);
                                } finally {
                                    n.f();
                                }
                                this.goods.selectAttr ? this.selectAttr = this.goods.selectAttr : this.selectAttr = r;
                            }
                            this.display = "block";
                        }
                    },
                    scrollGet: function(t, e) {
                        this.goods.attr_groups[e].scrollLeft = t.detail.scrollLeft, this.$forceUpdate();
                    },
                    toBottom: function(t) {
                        var e = this;
                        this.$nextTick().then(function() {
                            e.goods.attr_groups[t].scrollLeft = 99999, e.$forceUpdate();
                        });
                    },
                    chooseAttr: function(t, e, r) {
                        console.log(t, e);
                        var i, o = this, s = l(o.goods.attr_groups[t].attr_list);
                        try {
                            for (s.s(); !(i = s.n()).done; ) {
                                var n = i.value;
                                n.active = !1, n.attr_id == e.attr_id && n.attr_name == e.attr_name && (n.active = !0);
                            }
                        } catch (t) {
                            s.e(t);
                        } finally {
                            s.f();
                        }
                        0 == t && (o.pic_url = e.pic_url, o.attrIndex = r), o.activeAttr[t].attr_id = e.attr_id, 
                        o.activeAttr[t].attr_name = e.attr_name, o.goodsAttr = [];
                        var a, u = l(o.goods.attr);
                        try {
                            for (u.s(); !(a = u.n()).done; ) {
                                for (var c = a.value, h = !0, d = 0; d < c.attr_list.length - 1; d++) {
                                    var p = {
                                        attr_group_name: c.attr_list[d].attr_group_name,
                                        attr_group_id: c.attr_list[d].attr_group_id,
                                        attr_id: c.attr_list[d].attr_id,
                                        attr_name: c.attr_list[d].attr_name
                                    };
                                    JSON.stringify(p) != JSON.stringify(this.activeAttr[d]) && (h = !1);
                                }
                                h && o.goodsAttr.push(c);
                            }
                        } catch (t) {
                            u.e(t);
                        } finally {
                            u.f();
                        }
                        o.$forceUpdate(), o.count();
                    },
                    wholesaleNumberSub: function(t) {
                        if (0 == this.goodsAttr[t].number) return !1;
                        this.goodsAttr[t].number--, 1 == this.goods.attr_groups.length && (this.pic_url = this.goodsAttr[t].pic_url, 
                        this.attrIndex = t), this.count(t);
                    },
                    wholesaleNumberAdd: function(t) {
                        if (this.goodsAttr[t].number > this.goodsAttr[t].stock || this.goodsAttr[t].number == this.goodsAttr[t].stock) return !1;
                        this.goodsAttr[t].number++, 1 == this.goods.attr_groups.length && (this.pic_url = this.goodsAttr[t].pic_url, 
                        this.attrIndex = t), this.count(t);
                    },
                    wholesaleNumberBlur: function(t) {
                        +this.goodsAttr[t].number > +this.goodsAttr[t].stock && (this.goodsAttr[t].number = this.goodsAttr[t].stock), 
                        1 == this.goods.attr_groups.length && (this.pic_url = this.goodsAttr[t].pic_url, 
                        this.attrIndex = t), this.count(t);
                    },
                    count: function(t) {
                        var e = this;
                        this.$emit("attrtap", {
                            goods: e.goods,
                            goodsAttr: e.goodsAttr
                        }), setTimeout(function() {
                            e.selectAttr = e.goodsAttr[t];
                        });
                    },
                    close: function() {
                        this.display = "none", this.$emit("close", !1);
                    },
                    preventD: function() {},
                    storeAttrClick: function(e, r) {
                        function i(t, e) {
                            return e.some(function(e) {
                                return t == e;
                            });
                        }
                        var o = JSON.parse(JSON.stringify(this.newAttrGroupList)), s = this.goods.attr, n = [], a = this.attrCart;
                        for (var u in o) for (var l in o[u].attr_list) {
                            var c = o[u].attr_list[l];
                            if (parseInt(o[u].attr_group_id) == parseInt(r)) if (parseInt(c.attr_id) === parseInt(e)) {
                                if (c.checked ? c.checked = !1 : c.checked = !0, c.attr_num_0) return;
                            } else c.checked = !1;
                            c.checked && (0 == u && (this.pic_url = o[0].attr_list[l].pic_url, this.attrIndex = l), 
                            n.push(o[u].attr_group_id + "-" + c.attr_id));
                        }
                        var h = [], d = null, p = 1;
                        for (var m in s) {
                            var g = [], f = 0;
                            for (var _ in s[m].attr_list) {
                                var b = s[m].attr_list[_].attr_group_id + "-" + s[m].attr_list[_].attr_id;
                                i(b, n) || (f += 1, g.push(b));
                            }
                            if (0 == s[m].stock && f <= 1 && (h = h.concat(g)), 0 == f) {
                                if (d || (d = {}), d = s[m], a.forEach(function(t) {
                                    t.attr_id == d.id && (p = t.num);
                                }), d.stock <= 0) return void t.showToast({
                                    title: "库存不足",
                                    icon: "none"
                                });
                                d.stock <= p && (p = d.stock);
                            }
                        }
                        for (var v in 0 == n.length && (d = null), o) for (var y in o[v].attr_list) {
                            var w = o[v].attr_list[y], A = o[v].attr_group_id + "-" + w.attr_id;
                            i(A, h) && !i(A, n) ? w.attr_num_0 = !0 : w.attr_num_0 = !1;
                        }
                        this.newAttrGroupList = o, this.selectAttr = d, this.number = p, this.$emit("attrtap", this.selectAttr);
                    },
                    numberBlur: function(e) {
                        return (e = parseInt(e.value)) > this.attrNum && (t.showToast({
                            title: "库存不足",
                            icon: "none"
                        }), e = this.attrNum), this.$emit("attrtap", this.selectAttr), this.number = e;
                    },
                    numberSub: function() {
                        var t = this.number;
                        if (t <= 1) return !0;
                        t--, this.number = t, this.$emit("attrtap", this.selectAttr);
                    },
                    numberAdd: function() {
                        var e = this.number;
                        if (++e > this.attrNum) return t.showToast({
                            title: "库存不足",
                            icon: "none"
                        }), void (this.number = this.attrNum);
                        this.number = e, this.$emit("attrtap", this.selectAttr);
                    },
                    cart: function() {
                        var e = this;
                        if (!this.submit()) return !1;
                        var r = this.selectAttr;
                        if ("pick" !== this.goods.sign && "community" !== this.goods.sign) if ("goods" === this.goods.type) if ("miaosha" === this.goods.sign) this.$request({
                            url: this.$api.miaosha.add_cart,
                            data: {
                                miaosha_goods_id: r.goods_id,
                                attr_id: r.id,
                                num: this.number
                            },
                            method: "post"
                        }).then(function(r) {
                            t.showToast({
                                title: r.msg,
                                type: "success"
                            }), e.display = "none", e.selectAttr.number = e.number, e.$emit("selectNumber", e.selectAttr);
                        }).catch(function() {
                            e.display = "none";
                        }); else if ("flash_sale" === this.goods.sign) this.$request({
                            url: this.$api.flash_sale.add_cart,
                            data: {
                                flash_goods_id: r.goods_id,
                                attr_id: r.id,
                                num: this.number
                            },
                            method: "post"
                        }).then(function(r) {
                            t.showToast({
                                title: r.msg,
                                type: "success"
                            }), e.display = "none", e.selectAttr.number = e.number, e.$emit("selectNumber", e.selectAttr);
                        }).catch(function() {
                            e.display = "none";
                        }); else if ("wholesale" == this.goods.sign) {
                            if (this.totalNumber < this.goods.wholesaleGoods.rise_num) return t.showToast({
                                title: "至少采购" + this.goods.wholesaleGoods.rise_num + this.goods.unit,
                                image: "/static/image/plugins/tip.png",
                                duration: 1e3
                            }), !1;
                            var i, o = [], s = l(this.goods.attr);
                            try {
                                for (s.s(); !(i = s.n()).done; ) {
                                    var n = i.value;
                                    n.number > 0 && o.push(n);
                                }
                            } catch (t) {
                                s.e(t);
                            } finally {
                                s.f();
                            }
                            this.$request({
                                url: this.$api.wholesale.cart,
                                data: {
                                    attr: JSON.stringify(o)
                                },
                                method: "post"
                            }).then(function(r) {
                                if (e.display = "none", 0 === r.code) {
                                    var i, o = l(e.goods.attr);
                                    try {
                                        for (o.s(); !(i = o.n()).done; ) i.value.number = "0";
                                    } catch (t) {
                                        o.e(t);
                                    } finally {
                                        o.f();
                                    }
                                    var s, n = l(e.goodsAttr);
                                    try {
                                        for (n.s(); !(s = n.n()).done; ) s.value.number = "0";
                                    } catch (t) {
                                        n.e(t);
                                    } finally {
                                        n.f();
                                    }
                                    e.count(), t.hideLoading(), t.showToast({
                                        title: "添加成功",
                                        duration: 1e3
                                    });
                                }
                            }).catch(function(t) {
                                e.display = "none";
                            });
                        } else this.$request({
                            url: this.$api.cart.add,
                            data: {
                                goods_id: r.goods_id,
                                attr: r.id,
                                num: this.number
                            },
                            method: "post"
                        }).then(function(r) {
                            0 === r.code ? (t.showToast({
                                title: r.msg,
                                type: "success"
                            }), e.display = "none", e.selectAttr.number = e.number, e.getNumber(), e.$emit("selectNumber", e.selectAttr)) : (t.showToast({
                                title: r.msg,
                                icon: "none",
                                duration: 2500
                            }), e.display = "none");
                        }).catch(function() {
                            e.display = "none";
                        }); else "ecard" === this.goods.type && t.showToast({
                            title: "虚拟商品不允许加入购物车",
                            icon: "none"
                        }); else this.$emit("add", r, this.number);
                    },
                    getNumber: function() {
                        var t = this;
                        this.$request({
                            url: this.$api.cart.nums
                        }).then(function(e) {
                            0 === e.code && t.$store.commit("user/cart_nums", e.data.nums);
                        }).catch(function(t) {});
                    },
                    buy: function() {
                        var e = u(d.default.mark(function e() {
                            var r, i, o, s, n, a, u, c, h, p, m, g, f, _, b, v, y, w;
                            return d.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (console.log("buy=======>"), this.$user.isLogin()) {
                                        e.next = 5;
                                        break;
                                    }
                                    return console.log("判断登入"), e.next = 5, this.$user.getInfo({
                                        no_jump: !0
                                    });

                                  case 5:
                                    if (!(this.goods.sell_time > 0)) {
                                        e.next = 9;
                                        break;
                                    }
                                    return console.log("起售时间"), this.rightTip(), e.abrupt("return");

                                  case 9:
                                    if (this.submit()) {
                                        e.next = 11;
                                        break;
                                    }
                                    return e.abrupt("return", !1);

                                  case 11:
                                    if (!(this.goods.min_number > this.number)) {
                                        e.next = 14;
                                        break;
                                    }
                                    return this.$tips.showToast({
                                        title: "该商品" + this.goods.min_number + this.goods.unit + "起售",
                                        icon: "none"
                                    }), e.abrupt("return", !1);

                                  case 14:
                                    if (!(void 0 !== this.goods.limit_buy && 1 == this.goods.limit_buy.status && this.goods.limit_buy.rest_number < this.number)) {
                                        e.next = 17;
                                        break;
                                    }
                                    return this.$tips.showToast({
                                        title: this.goods.limit_buy.text,
                                        icon: "none"
                                    }), e.abrupt("return", !1);

                                  case 17:
                                    if (!this.noPay) {
                                        e.next = 20;
                                        break;
                                    }
                                    return this.$emit("pay", this.number), e.abrupt("return");

                                  case 20:
                                    if (!this.buyClick) {
                                        e.next = 25;
                                        break;
                                    }
                                    return this.display = "none", this.selectAttr.number = this.number, this.$emit("buyClick", this.selectAttr), 
                                    e.abrupt("return", !1);

                                  case 25:
                                    if ("wholesale" != this.goods.sign) {
                                        e.next = 38;
                                        break;
                                    }
                                    if (!(this.totalNumber && this.totalNumber < this.goods.wholesaleGoods.rise_num)) {
                                        e.next = 29;
                                        break;
                                    }
                                    return t.showToast({
                                        title: "至少采购" + this.goods.wholesaleGoods.rise_num + this.goods.unit,
                                        image: "/static/image/plugins/tip.png",
                                        duration: 1e3
                                    }), e.abrupt("return", !1);

                                  case 29:
                                    r = {}, i = [ {
                                        mch_id: 0,
                                        goods_list: []
                                    } ], o = l(this.goods.attr);
                                    try {
                                        for (o.s(); !(s = o.n()).done; ) if ((n = s.value).number > 0) {
                                            r = {
                                                id: n.goods_id,
                                                attr: [],
                                                num: n.number,
                                                cat_id: 0,
                                                goods_attr_id: n.id
                                            }, a = l(n.attr_list);
                                            try {
                                                for (a.s(); !(u = a.n()).done; ) c = u.value, h = {
                                                    attr_id: c.attr_id,
                                                    attr_group_id: c.attr_group_id
                                                }, r.attr.push(h);
                                            } catch (t) {
                                                a.e(t);
                                            } finally {
                                                a.f();
                                            }
                                            i[0].goods_list.push(r);
                                        }
                                    } catch (t) {
                                        o.e(t);
                                    } finally {
                                        o.f();
                                    }
                                    p = "/pages/order-submit/order-submit?mch_list=".concat(JSON.stringify(i)), this.submitUrl && this.previewUrl && (p += "&preview_url=".concat(encodeURIComponent(this.previewUrl), "&submit_url=").concat(encodeURIComponent(this.submitUrl), "&plugin=").concat(this.plugin)), 
                                    t.navigateTo({
                                        url: p
                                    }), e.next = 48;
                                    break;

                                  case 38:
                                    for (v in m = this.goods, g = this.number, f = this.selectAttr, _ = f.id, b = [], 
                                    f.attr_list) b.push({
                                        attr_id: f.attr_list[v].attr_id,
                                        attr_group_id: f.attr_list[v].attr_group_id
                                    });
                                    y = [ {
                                        mch_id: m.mch_id ? m.mch_id : 0,
                                        goods_list: [ {
                                            id: this.goodsId ? this.goodsId : m.id,
                                            attr: b,
                                            num: g,
                                            cat_id: 0,
                                            goods_attr_id: _
                                        } ]
                                    } ], w = "/pages/order-submit/order-submit?mch_list=".concat(JSON.stringify(y)), 
                                    this.submitUrl && this.previewUrl && (w += "&preview_url=".concat(encodeURIComponent(this.previewUrl), "&submit_url=").concat(encodeURIComponent(this.submitUrl), "&plugin=").concat(this.plugin)), 
                                    t.navigateTo({
                                        url: w
                                    });

                                  case 48:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }(),
                    submit: function() {
                        var e = this.selectAttr;
                        return !("wholesale" !== this.goods.sign && (e ? e.stock <= 0 ? (t.showToast({
                            title: "库存不足",
                            icon: "none"
                        }), 1) : this.number <= 0 ? (t.showToast({
                            title: "数量不能为0",
                            icon: "none"
                        }), 1) : !this.goods : (t.showToast({
                            title: "请先选规格",
                            icon: "none"
                        }), 1)));
                    },
                    clickImg: function() {
                        this.pic_url ? this.previewCover(this.attrIndex, !0) : t.previewImage({
                            current: 0,
                            urls: [ this.goods.cover_pic ]
                        });
                    },
                    changeTime: function(t) {
                        this.sell_time = t;
                    }
                },
                computed: s(s(s(s({}, (0, p.mapState)({
                    gConfig: function(t) {
                        return t.gConfig;
                    },
                    isTip: function(t) {
                        return t.mallConfig.mall.setting.is_remind_sell_time;
                    }
                })), {}, {
                    attrPic: function() {
                        return this.pic_url ? this.pic_url : this.goods ? this.goods.cover_pic : "";
                    },
                    priceColorStyle: function() {
                        return this.goods && 1 === this.goods.level_show ? "member" : this.theme + "-color";
                    },
                    attrNum: function() {
                        return this.selectAttr ? this.selectAttr.stock : this.goods ? this.goods.goods_num : 0;
                    },
                    attrPrice: function() {
                        var t;
                        return this.selectAttr ? (t = 1 === this.goods.level_show ? this.selectAttr.price_member : this.selectAttr.price, 
                        "wholesale" == this.sign ? 0 == this.selectAttr.number ? "undefined" : t = 0 == this.wholesaleType ? (t * (this.discount / 10)).toFixed(2) : (t - this.discount).toFixed(2) : t) : "wholesale" == this.sign ? "undefined" : this.goods ? this.goods.video_url && 1 == this.goods.level_show ? this.goods.level_price : this.goods.hasOwnProperty("price_min") ? this.goods.price_min : this.goods.price : 0;
                    },
                    newData: function() {
                        return {
                            number: this.number,
                            display: this.display,
                            selectAttr: this.selectAttr
                        };
                    }
                }, (0, p.mapGetters)("iPhoneX", {
                    boolEmpty: "getBoolEmpty"
                })), (0, p.mapGetters)({
                    userInfo: "user/info"
                })), {}, {
                    showRight: function() {
                        return !(0 == this.isTip && this.goods.sell_time > 0) && this.is_show_buy;
                    },
                    remindParams: function() {
                        return {
                            sell_time: this.sell_time,
                            goods_id: this.goods.id,
                            template_message_list: this.goods.template_message_list,
                            buy_text: this.buyText
                        };
                    }
                })
            };
            e.default = m;
        }).call(this, r("543d").default);
    },
    a8f8: function(t, e, r) {
        r.r(e);
        var i = r("a031"), o = r.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(t) {
            r.d(e, t, function() {
                return i[t];
            });
        }(s);
        e.default = o.a;
    },
    d3c4: function(t, e, r) {
        r.r(e);
        var i = r("7c03e"), o = r("a8f8");
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(t) {
            r.d(e, t, function() {
                return o[t];
            });
        }(s);
        r("0421");
        var n = r("f0c5"), a = Object(n.a)(o.default, i.b, i.c, !1, null, "f675b9a2", null, !1, i.a, void 0);
        e.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-attr/app-attr-create-component", {
    "components/page-component/app-attr/app-attr-create-component": function(t, e, r) {
        r("543d").createComponent(r("d3c4"));
    }
}, [ [ "components/page-component/app-attr/app-attr-create-component" ] ] ]);