(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-recommended-product/app-recommended-product-list" ], {
    "33f1": function(t, e, o) {
        o.r(e);
        var n = o("f4d5"), r = o.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(i);
        e.default = r.a;
    },
    "57ba": function(t, e, o) {
        o.r(e);
        var n = o("99c9"), r = o("33f1");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            o.d(e, t, function() {
                return r[t];
            });
        }(i);
        o("5f4f");
        var c = o("f0c5"), a = Object(c.a)(r.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        e.default = a.exports;
    },
    "5f4f": function(t, e, o) {
        var n = o("b6d8");
        o.n(n).a;
    },
    "99c9": function(t, e, o) {
        o.d(e, "b", function() {
            return n;
        }), o.d(e, "c", function() {
            return r;
        }), o.d(e, "a", function() {});
        var n = function() {
            var t = this, e = (t.$createElement, t._self._c, t.catList && t.catList.length ? t.__get_style([ t.calcWidth(750) ]) : null), o = t.catList && t.catList.length ? t.__map(t.catList, function(e, o) {
                return {
                    $orig: t.__get_orig(e),
                    s1: t.activeIndex === o ? t.__get_style([ t.calcWidth(566) ]) : null,
                    s2: t.activeIndex === o ? t.__get_style([ t.calcWidth(566) ]) : null,
                    s3: t.__get_style([ t.styleBox, t.calcWidth(554) ]),
                    m0: t.getLength(t.list),
                    s4: t.__get_style([ t.calcWidth(554) ]),
                    s5: t.__get_style([ t.calcWidth(354) ]),
                    s6: t.showGoodsName ? t.__get_style([ t.calcWidth(330) ]) : null,
                    l0: t.activeIndex === o ? t.__map(t.list, function(e, o) {
                        return {
                            $orig: t.__get_orig(e),
                            m1: 1 === e.is_level && (e.level_price > 0 || 0 == e.level_price) && 1 != e.is_negotiable ? null : t.isShowOriginalPrice(e)
                        };
                    }) : null
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e,
                    l1: o
                }
            });
        }, r = [];
    },
    b6d8: function(t, e, o) {},
    f4d5: function(t, e, o) {
        (function(t) {
            function n(t, e) {
                var o = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function r(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var o = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? n(Object(o), !0).forEach(function(e) {
                        i(t, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : n(Object(o)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return t;
            }
            function i(t, e, o) {
                return e in t ? Object.defineProperty(t, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = o, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var c = o("2f62"), a = {
                name: "app-recommended-product-list",
                data: function() {
                    return {
                        scrollIndex: 0,
                        height: 0,
                        cartIndex: -1,
                        show: 0,
                        selectAttr: {},
                        goods: {},
                        disableColor: "#999999",
                        disable: "disable",
                        attrGoods: {
                            goods: {},
                            attrShow: 0
                        }
                    };
                },
                props: {
                    bg: [ String ],
                    cPaddingLr: [ String, Number ],
                    cBorderBottom: [ String, Number ],
                    cBorderTop: [ String, Number ],
                    catList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    fill: {
                        type: Number,
                        default: function() {
                            return 1;
                        }
                    },
                    buyBtnText: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    buyBtnStyle: {
                        type: Number,
                        default: function() {
                            return 4;
                        }
                    },
                    showBuyBtn: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    showGoodsPrice: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    buyBtn: {
                        type: String,
                        default: function() {
                            return "cart";
                        }
                    },
                    goodsStyle: {
                        type: Number,
                        default: function() {
                            return 1;
                        }
                    },
                    goodsTagPicUrl: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    showGoodsTag: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    showGoodsName: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    buttonColor: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    theme: Object,
                    isUnderLinePrice: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    isBuy: {
                        type: Boolean,
                        default: !0
                    },
                    isShowAttr: {
                        type: Boolean,
                        default: !1
                    },
                    tagColor: {
                        type: String
                    },
                    catSelectedColor: {
                        type: String
                    },
                    catUnselectedColor: {
                        type: String
                    },
                    catBgColor: {
                        type: String
                    },
                    activeIndex: {
                        type: Number,
                        default: 0
                    },
                    list: {
                        type: Array,
                        default: []
                    },
                    goodsIndex: {
                        type: Number,
                        default: -1
                    },
                    loading: {
                        type: Boolean,
                        default: !1
                    },
                    tempId: {
                        type: String,
                        default: ""
                    }
                },
                computed: r(r(r({
                    calcWidth: function() {
                        var t = this;
                        return function(e) {
                            var o = void 0 === t.cPaddingLr ? 0 : 2 * Number(t.cPaddingLr);
                            return {
                                width: "".concat(e - o, "rpx")
                            };
                        };
                    },
                    styleBox: function() {
                        var t = this.bg, e = this.cBorderTop, o = this.cBorderBottom, n = this.goodsStyle;
                        return void 0 === e ? {} : {
                            borderTopLeftRadius: "".concat(e, "rpx"),
                            borderTopRightRadius: "".concat(e, "rpx"),
                            borderBottomLeftRadius: "".concat(o, "rpx"),
                            borderBottomRightRadius: "".concat(o, "rpx"),
                            background: 3 === n ? t : "#FFFFFF"
                        };
                    },
                    calcPicRadius: function() {
                        var t = this.cBorderTop;
                        return void 0 === t ? "16rpx" : "".concat(t, "rpx");
                    }
                }, (0, c.mapState)({
                    appImg: function(t) {
                        return t.mallConfig.__wxapp_img.mall;
                    },
                    appSetting: function(t) {
                        return t.mallConfig.mall.setting;
                    },
                    goodsImg: function(t) {
                        return t.mallConfig.__wxapp_img.goods;
                    },
                    commonImg: function(t) {
                        return t.mallConfig.__wxapp_img.common;
                    },
                    platform: function(t) {
                        return t.gConfig.systemInfo.platform;
                    }
                })), (0, c.mapGetters)("mallConfig", {
                    getVideo: "getVideo"
                })), {}, {
                    btnStyle: function() {
                        var t = "";
                        return 1 === this.buyBtnStyle || 3 === this.buyBtnStyle ? t += "background-color: ".concat(this.buttonColor, ";color: #ffffff;") : t += "border-color: ".concat(this.buttonColor, ";color: ").concat(this.buttonColor, ";"), 
                        t;
                    },
                    disableBtnStyle: function() {
                        var t = "";
                        return 1 === this.buyBtnStyle || 3 === this.buyBtnStyle ? t += "background-color: ".concat(this.disableColor, ";color: #ffffff;") : t += "border-color: ".concat(this.disableColor, ";color: ").concat(this.disableColor, ";"), 
                        t;
                    }
                }),
                created: function() {
                    var t = this;
                    wx.getSystemInfo({
                        success: function(e) {
                            t.height = 750 / e.windowWidth * e.windowHeight;
                        }
                    });
                },
                methods: {
                    getLength: function(t) {
                        return t.length - 1;
                    },
                    buyProduct: function(e) {
                        var o = this;
                        this.isBuy ? this.isShowAttr ? (this.attrGoods.goods = e, this.attrGoods.attrShow = Math.random()) : (t.showLoading({
                            text: "",
                            mask: !0
                        }), this.$request({
                            url: this.$api.goods.attr,
                            data: {
                                id: e.id,
                                mch_id: e.mch_id
                            }
                        }).then(function(n) {
                            if (t.hideLoading(), 0 === n.code) {
                                var r = Object.assign(e, n.data);
                                o.$emit("buyProduct", {
                                    goods: r,
                                    attrShow: Math.random()
                                });
                            } else t.showToast({
                                title: n.msg,
                                icon: "none"
                            });
                        })) : this.jump_router(e);
                    },
                    goClass: function(t) {
                        this.$emit("change", t, this.goodsIndex);
                    },
                    attr: function(t) {},
                    jump_router: function(e) {
                        e.video_url && 1 == this.getVideo ? t.navigateTo({
                            url: "/pages/goods/video?goods_id=".concat(e.id, "&sign=").concat(e.sign)
                        }) : t.navigateTo({
                            url: e.page_url
                        });
                    },
                    isShowOriginalPrice: function(t) {
                        return this.isUnderLinePrice && 1 !== t.is_negotiable ? 1 : 0;
                    },
                    getMoreGoods: function() {
                        this.$emit("getGoods", this.activeIndex);
                    },
                    changeCart: function(t) {
                        this.$emit("cart", t);
                    }
                },
                components: {
                    "app-attr": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-attr/app-attr") ]).then(function() {
                            return resolve(o("d3c4"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    AppAddSubtract: function() {
                        o.e("components/page-component/app-add-subtract/app-add-subtract").then(function() {
                            return resolve(o("60a2"));
                        }.bind(null, o)).catch(o.oe);
                    }
                }
            };
            e.default = a;
        }).call(this, o("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-recommended-product/app-recommended-product-list-create-component", {
    "components/page-component/app-recommended-product/app-recommended-product-list-create-component": function(t, e, o) {
        o("543d").createComponent(o("57ba"));
    }
}, [ [ "components/page-component/app-recommended-product/app-recommended-product-list-create-component" ] ] ]);