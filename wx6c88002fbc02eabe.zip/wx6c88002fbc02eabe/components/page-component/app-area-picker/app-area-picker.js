(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-area-picker/app-area-picker" ], {
    "08bc": function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = {
            name: "app-area-picker",
            props: {
                ids: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    tempIds: this.ids,
                    area_picker_show: "",
                    list: [],
                    multiIndex: [],
                    multiArray: [],
                    place: ""
                };
            },
            created: function() {
                this.tempIds = this.tempIds.concat();
            },
            watch: {
                ids: {
                    handler: function(t, e) {
                        this.tempIds = this.ids;
                    }
                },
                tempIds: {
                    handler: function(t, e) {
                        var i = this;
                        i.before(function(t) {
                            i.init(t);
                        }), this.$emit("ids", this.tempIds);
                    },
                    deep: !0,
                    immediate: !0
                }
            },
            methods: {
                before: function(t) {
                    var e = this, i = this, n = this.$storage.getStorageSync("_DISTRICT");
                    n ? t(n) : this.$request({
                        url: i.$api.default.district
                    }).then(function(i) {
                        0 === i.code && (e.$storage.setStorageSync("_DISTRICT", i.data.list), t(i.data.list));
                    });
                },
                init: function(t) {
                    var e = 3 === this.tempIds.length && 0 != this.tempIds[0], i = e ? this.tempIds : [ t[0].id, t[0].list[0].id, t[0].list[0].list[0].id ], n = this.getIndex(t, i), a = [ t, t[n[0]].list, t[n[0]].list[n[1]].list ], s = a[0][n[0]].name + "，" + a[1][n[1]].name + "，" + a[2][n[2]].name, r = [ a[0][n[0]], a[1][n[1]], a[2][n[2]] ];
                    this.setEvent(r, e);
                    var l = [ t, a, n, e ? s : "请选择" ];
                    this.list = l[0], this.multiArray = l[1], this.multiIndex = l[2], this.place = l[3];
                },
                getIndex: function(t, e) {
                    var i = [];
                    return t.map(function(t, n) {
                        e[0] == t.id && i.push(n);
                    }), t[i[0]].list.map(function(t, n) {
                        e[1] == t.id && i.push(n);
                    }), t[i[0]].list[i[1]].list.map(function(t, n) {
                        e[2] == t.id && i.push(n);
                    }), i;
                },
                bindMultiPickerChange: function(t) {
                    var e = [ this.multiArray[0][t.detail.value[0]], this.multiArray[1][t.detail.value[1]], this.multiArray[2][t.detail.value[2]] ], i = e[0].name + "，" + e[1].name + "，" + e[2].name, n = [ t.detail.value, i ];
                    this.multiIndex = n[0], this.place = n[1], this.setEvent(e);
                },
                setEvent: function(t) {
                    var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], i = {
                        province: {
                            id: t[0].id,
                            name: t[0].name
                        },
                        city: {
                            id: t[1].id,
                            name: t[1].name
                        },
                        district: {
                            id: t[2].id,
                            name: t[2].name
                        }
                    };
                    this.$emit("customevent", e ? i : null);
                },
                bindMultiPickerColumnChange: function(t) {
                    var e = {
                        multiArray: this.multiArray,
                        multiIndex: this.multiIndex
                    };
                    switch (e.multiIndex[t.detail.column] = t.detail.value, t.detail.column) {
                      case 0:
                        e.multiIndex.splice(1, 1, 0), e.multiIndex.splice(2, 1, 0), e.multiArray.splice(1, 1, this.list[e.multiIndex[0]].list), 
                        e.multiArray.splice(2, 1, this.list[e.multiIndex[0]].list[e.multiIndex[1]].list);
                        break;

                      case 1:
                        e.multiIndex.splice(2, 1, 0), e.multiArray.splice(2, 1, this.list[e.multiIndex[0]].list[e.multiIndex[1]].list);
                    }
                    var i = [ e.multiArray, e.multiIndex ];
                    this.multiArray = i[0], this.multiIndex = i[1];
                }
            }
        };
        e.default = n;
    },
    "4a19": function(t, e, i) {},
    5286: function(t, e, i) {
        i.r(e);
        var n = i("08bc"), a = i.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(s);
        e.default = a.a;
    },
    "8e44": function(t, e, i) {
        i.r(e);
        var n = i("d446"), a = i("5286");
        for (var s in a) [ "default" ].indexOf(s) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(s);
        i("d27a");
        var r = i("f0c5"), l = Object(r.a)(a.default, n.b, n.c, !1, null, "bb0dca8a", null, !1, n.a, void 0);
        e.default = l.exports;
    },
    d27a: function(t, e, i) {
        var n = i("4a19");
        i.n(n).a;
    },
    d446: function(t, e, i) {
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return a;
        }), i.d(e, "a", function() {});
        var n = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-area-picker/app-area-picker-create-component", {
    "components/page-component/app-area-picker/app-area-picker-create-component": function(t, e, i) {
        i("543d").createComponent(i("8e44"));
    }
}, [ [ "components/page-component/app-area-picker/app-area-picker-create-component" ] ] ]);