(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-announcement/u-announcement" ], {
    "0dc7": function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, i = [];
    },
    "4ca7": function(t, n, e) {
        (function(t) {
            function o(t, n) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(t, n).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function i(t) {
                for (var n = 1; n < arguments.length; n++) {
                    var e = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? o(Object(e), !0).forEach(function(n) {
                        c(t, n, e[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : o(Object(e)).forEach(function(n) {
                        Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(e, n));
                    });
                }
                return t;
            }
            function c(t, n, e) {
                return n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e, t;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = e("2f62"), a = {
                data: function() {
                    return {
                        animationDuration: "10s",
                        animationPlayState: "paused",
                        showText: "",
                        visibleSync: !1,
                        showDrawer: !1,
                        timer: null
                    };
                },
                components: {
                    uPopup: function() {
                        e.e("components/basic-component/u-popup/u-popup").then(function() {
                            return resolve(e("d55a"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                props: {
                    content: String,
                    bgColor: {
                        type: String,
                        default: "#f67f79"
                    },
                    icon: {
                        type: String,
                        default: ""
                    },
                    name: {
                        type: String,
                        default: "公告"
                    },
                    textColor: {
                        type: String,
                        default: "#ffffff"
                    },
                    headerUrl: {
                        type: String,
                        default: ""
                    },
                    btnText: {
                        type: String,
                        default: "我知道了"
                    },
                    btnTextColor: {
                        type: String,
                        default: "#ffffff"
                    },
                    btnColor: {
                        type: String,
                        default: "#ff4544"
                    },
                    btnRadius: {
                        type: String,
                        default: "40rpx"
                    },
                    btnWidth: {
                        type: Number,
                        default: 500
                    },
                    arrow: {
                        type: String,
                        default: "white"
                    },
                    isIndexGray: {
                        type: Boolean,
                        default: !1
                    }
                },
                watch: {
                    content: {
                        immediate: !0,
                        handler: function(t) {
                            var n = this;
                            t && (this.showText = t.replace(/[\r\n]/g, ""), this.$nextTick(function() {
                                n.initSize();
                            }));
                        }
                    }
                },
                methods: {
                    initSize: function() {
                        var n = this, e = [];
                        setTimeout(function() {
                            var o = new Promise(function(e) {
                                t.createSelectorQuery().in(n).select("#u-notice-content").boundingClientRect().exec(function(t) {
                                    n.textWidth = t[0].width, e();
                                });
                            });
                            e.push(o), Promise.all(e).then(function() {
                                console.log(n.textWidth), n.animationDuration = "".concat(n.textWidth / t.upx2px(100), "s"), 
                                n.animationPlayState = "paused", setTimeout(function() {
                                    n.animationPlayState = "running";
                                }, 10);
                            });
                        }, 500);
                    },
                    take: function(t) {
                        this.visibleSync = t;
                    }
                },
                computed: i(i({}, (0, r.mapState)({
                    diyImg: function(t) {
                        return t.mallConfig.__wxapp_img.diy;
                    },
                    commonImg: function(t) {
                        return t.mallConfig.__wxapp_img.common;
                    }
                })), {}, {
                    btnStyle: function() {
                        return "width: ".concat(this.btnWidth, "rpx;color:").concat(this.btnTextColor, ";background-color:").concat(this.btnColor, ";border-radius: ").concat(this.btnRadius, ";");
                    }
                }),
                mounted: function() {
                    var t = this;
                    this.$nextTick(function() {
                        t.initSize();
                    });
                }
            };
            n.default = a;
        }).call(this, e("543d").default);
    },
    "696b": function(t, n, e) {
        var o = e("7493");
        e.n(o).a;
    },
    7493: function(t, n, e) {},
    94703: function(t, n, e) {
        e.r(n);
        var o = e("0dc7"), i = e("e97c");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(c);
        e("696b");
        var r = e("f0c5"), a = Object(r.a)(i.default, o.b, o.c, !1, null, "205d619a", null, !1, o.a, void 0);
        n.default = a.exports;
    },
    e97c: function(t, n, e) {
        e.r(n);
        var o = e("4ca7"), i = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        n.default = i.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-announcement/u-announcement-create-component", {
    "components/page-component/u-announcement/u-announcement-create-component": function(t, n, e) {
        e("543d").createComponent(e("94703"));
    }
}, [ [ "components/page-component/u-announcement/u-announcement-create-component" ] ] ]);