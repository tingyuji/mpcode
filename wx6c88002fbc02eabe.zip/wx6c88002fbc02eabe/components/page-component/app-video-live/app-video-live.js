(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-video-live/app-video-live" ], {
    "10df": function(e, t, n) {
        n.r(t);
        var o = n("9bb1"), i = n("98f3");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("8899");
        var c = n("f0c5"), s = Object(c.a)(i.default, o.b, o.c, !1, null, "779d41c6", null, !1, o.a, void 0);
        t.default = s.exports;
    },
    "7ed2": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                name: "app-video-live",
                data: function() {
                    return {
                        dateText: "",
                        liveInfo: {},
                        s: 0,
                        form: this.data
                    };
                },
                props: {
                    data: {
                        type: Object,
                        default: function() {
                            return {
                                status: -2
                            };
                        }
                    }
                },
                mounted: function() {
                    var e = this;
                    this.$nextTick(function(t) {
                        e.getInfo();
                    });
                },
                computed: {
                    btnStyle: function() {
                        var e = 2 == this.form.status ? "live" : "booking";
                        return {
                            background: this.form["".concat(e) + "_bg"],
                            color: this.form["".concat(e) + "_color"]
                        };
                    }
                },
                methods: {
                    booking: function() {
                        var t = this;
                        if (2 == t.form.status) return wx.openChannelsLive({
                            finderUserName: t.form.video_id
                        });
                        wx.reserveChannelsLive({
                            noticeId: t.liveInfo.noticeId,
                            success: function(n) {
                                switch (n.state) {
                                  case 1:
                                  case 2:
                                    return t.form.status = 2;

                                  case 3:
                                    return e.showToast({
                                        title: "预告已取消",
                                        icon: "none"
                                    });

                                  case 4:
                                    return void e.showToast({
                                        title: "直播已结束",
                                        icon: "none"
                                    });

                                  case 6:
                                    t.form.status = 1;
                                    break;

                                  case 7:
                                  case 9:
                                    t.form.status = 0;
                                    break;

                                  case 10:
                                    return void e.showToast({
                                        title: "直播预约已过期",
                                        icon: "none"
                                    });

                                  default:
                                    return !1;
                                }
                                t.$forceUpdate(), t.$request({
                                    url: t.$api.diy.video_live,
                                    method: "POST",
                                    data: {
                                        video_id: t.form.video_id,
                                        type: 1 == t.form.status ? "booking" : "cancel"
                                    }
                                });
                            },
                            fail: function(t) {
                                e.showToast({
                                    title: t.errMsg,
                                    icon: "none"
                                });
                            }
                        });
                    },
                    getInfo: function() {
                        var e = this;
                        wx.getChannelsLiveNoticeInfo({
                            finderUserName: e.data.video_id,
                            success: function(t) {
                                e.liveInfo = t, e.s = 1, e.dateText = e.$utils.datetime("m月d日 h:i:s开播", e.liveInfo.startTime);
                            },
                            fail: function(t) {
                                e.s = 2, e.dateText = "当前暂无可预约的直播";
                            }
                        });
                    }
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    "87df": function(e, t, n) {},
    8899: function(e, t, n) {
        var o = n("87df");
        n.n(o).a;
    },
    "98f3": function(e, t, n) {
        n.r(t);
        var o = n("7ed2"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    "9bb1": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, 1 == e.s ? e.__get_style([ e.btnStyle ]) : null);
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t
                }
            });
        }, i = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-video-live/app-video-live-create-component", {
    "components/page-component/app-video-live/app-video-live-create-component": function(e, t, n) {
        n("543d").createComponent(n("10df"));
    }
}, [ [ "components/page-component/app-video-live/app-video-live-create-component" ] ] ]);