var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-video/app-video" ], {
    "05d2": function(t, e, n) {
        var o = n("b4e4");
        n.n(o).a;
    },
    "5aab": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__get_style([ t.styleA ])), n = t.start ? null : t.__get_style([ t.styleB ], {
                width: "100%",
                height: "100%"
            }), o = t.start ? t.__get_style([ Object.assign({
                width: t.calcWidth,
                height: t.height
            }, t.styleB) ]) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e,
                    s1: n,
                    s2: o
                }
            });
        }, r = [];
    },
    b4e4: function(t, e, n) {},
    d824: function(t, e, n) {
        n.r(e);
        var o = n("5aab"), r = n("f1a9");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n("05d2");
        var c = n("f0c5"), a = Object(c.a)(r.default, o.b, o.c, !1, null, "051c3140", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    ebfc: function(e, n, o) {
        (function(e) {
            function r(e) {
                return (r = "function" == typeof Symbol && "symbol" === t(Symbol.iterator) ? function(e) {
                    return void 0 === e ? "undefined" : t(e);
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : t(e);
                })(e);
            }
            function i(t) {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap(), n = new WeakMap();
                return (i = function(t) {
                    return t ? n : e;
                })(t);
            }
            function c(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(n), !0).forEach(function(e) {
                        u(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function u(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var l = function(t, e) {
                if (!e && t && t.__esModule) return t;
                if (null === t || "object" !== r(t) && "function" != typeof t) return {
                    default: t
                };
                var n = i(e);
                if (n && n.has(t)) return n.get(t);
                var o = {}, c = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in t) if ("default" !== a && Object.prototype.hasOwnProperty.call(t, a)) {
                    var u = c ? Object.getOwnPropertyDescriptor(t, a) : null;
                    u && (u.get || u.set) ? Object.defineProperty(o, a, u) : o[a] = t[a];
                }
                return o.default = t, n && n.set(t, o), o;
            }(o("9d0f")), p = o("2f62"), f = {
                name: "app-video",
                data: function() {
                    return {
                        start: !1,
                        fullScreen: !1,
                        maxTop: 0
                    };
                },
                props: {
                    bgPadding: [ String, Number ],
                    cBorderBottom: [ String, Number ],
                    cBorderTop: [ String, Number ],
                    cPaddingTop: [ String, Number ],
                    cPaddingLr: [ String, Number ],
                    cPaddingBottom: [ String, Number ],
                    hasAuto: {
                        type: [ Boolean, String, Number ],
                        default: function() {
                            return !1;
                        }
                    },
                    hasCycle: {
                        type: [ Boolean, String, Number ],
                        default: function() {
                            return !1;
                        }
                    },
                    picUrl: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    url: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    width: {
                        type: String,
                        default: function() {
                            return "750rpx";
                        }
                    },
                    height: {
                        type: String,
                        default: function() {
                            return "422rpx";
                        }
                    },
                    videoPlay: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    }
                },
                methods: {
                    getInfo: function(t) {
                        console.log(t);
                    },
                    fullscreenChange: function(t) {
                        this.fullScreen = t.detail.fullScreen;
                    },
                    play: function() {
                        var t = this;
                        this.$nextTick().then(function() {
                            t.start = !0;
                        }), l.trigger(this.$const.EVENT_VIDEO_END), this.$emit("video-start", !0), l.on(this.$const.EVENT_VIDEO_END, !0).then(function() {
                            t.start = !1, t.$emit("video-start", !1);
                        });
                    },
                    autoPlay: function() {
                        var t = this;
                        e.createSelectorQuery().in(this).select("#video").boundingClientRect(function(e) {
                            console.log(22, e), e && e.top >= 0 && e.top < 1e3 && (console.log(11), t.$utils.throttle(t.play, 500));
                        }).exec();
                    },
                    autoEnd: function() {
                        var t = this, e = null;
                        (e = this.createSelectorQuery()).select(".video").boundingClientRect(), e.selectViewport().scrollOffset(), 
                        e.exec(function(e) {
                            (e[0].top <= -200 || e[0].top >= t.maxTop - 57) && l.trigger(t.$const.EVENT_VIDEO_END);
                        });
                    },
                    preventD: function() {}
                },
                computed: a(a({}, (0, p.mapState)({
                    commonImg: function(t) {
                        return t.mallConfig.__wxapp_img.common;
                    }
                })), {}, {
                    calcWidth: function() {
                        return "calc(".concat(this.width, " - ").concat(2 * this.cPaddingLr, "rpx)");
                    },
                    styleA: function() {
                        var t = this.bgPadding, e = this.cPaddingTop, n = this.cPaddingLr, o = this.cPaddingBottom;
                        return {
                            backgroundColor: t,
                            padding: "".concat(e, "rpx ").concat(n, "rpx ").concat(o, "rpx")
                        };
                    },
                    styleB: function() {
                        var t = this.cBorderTop, e = this.cBorderBottom;
                        return {
                            borderTopLeftRadius: "".concat(t, "rpx"),
                            borderTopRightRadius: "".concat(t, "rpx"),
                            borderBottomLeftRadius: "".concat(e, "rpx"),
                            borderBottomRightRadius: "".concat(e, "rpx")
                        };
                    },
                    scrollTop: function() {
                        return this.$store.state.page.scrollTop;
                    }
                }),
                created: function() {
                    this.maxTop = e.getSystemInfoSync().windowHeight;
                },
                watch: {
                    scrollTop: {
                        handler: function() {
                            this.start && !this.fullScreen && this.$utils.throttle(this.autoEnd, 500), !this.start && this.hasAuto && this.autoPlay();
                        },
                        immediate: !0
                    },
                    videoPlay: {
                        handler: function() {
                            this.start && l.trigger(this.$const.EVENT_VIDEO_END);
                        }
                    }
                }
            };
            n.default = f;
        }).call(this, o("543d").default);
    },
    f1a9: function(t, e, n) {
        n.r(e);
        var o = n("ebfc"), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-video/app-video-create-component", {
    "components/page-component/app-video/app-video-create-component": function(t, e, n) {
        n("543d").createComponent(n("d824"));
    }
}, [ [ "components/page-component/app-video/app-video-create-component" ] ] ]);