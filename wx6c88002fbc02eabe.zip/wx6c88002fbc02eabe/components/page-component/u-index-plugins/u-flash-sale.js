(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-flash-sale" ], {
    "06f4": function(t, e, n) {
        n.r(e);
        var i = n("ce72"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    "8a31": function(t, e, n) {
        var i = n("cea5");
        n.n(i).a;
    },
    ad4e: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, a = [];
    },
    ce72: function(t, e, n) {
        function i(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(t);
                e && (i = i.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, i);
            }
            return n;
        }
        function a(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? i(Object(n), !0).forEach(function(e) {
                    o(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function o(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var s = n("2f62"), r = {
            name: "u-flash-sale",
            props: {
                theme: Object,
                index: Number,
                page_id: Number,
                is_required: Boolean,
                appImg: {
                    type: Object,
                    default: function() {
                        return {
                            plugins_out: ""
                        };
                    }
                },
                appSetting: {
                    type: Object,
                    default: function() {
                        return {
                            is_show_stock: 1,
                            sell_out_pic: "",
                            is_use_stock: 1
                        };
                    }
                }
            },
            data: function() {
                return {
                    newData: {},
                    tempList: [],
                    goodsList: [],
                    time: 0,
                    time_str: {
                        hou: "00",
                        min: "00",
                        sec: "00"
                    },
                    timing: null,
                    style: "1",
                    goods_num: 20
                };
            },
            components: {
                uIndexPlugins: function() {
                    n.e("components/page-component/u-index-plugins/u-index-plugins").then(function() {
                        return resolve(n("03c5"));
                    }.bind(null, n)).catch(n.oe);
                },
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            computed: a(a({}, (0, s.mapGetters)("mallConfig", {
                getTheme: "getTheme"
            })), {}, {
                copyList: function() {
                    return this.newData.list;
                }
            }),
            methods: {
                loadData: function() {
                    var t = this, e = {
                        type: 0 === this.page_id ? "mall" : "diy",
                        key: "flash_sale",
                        page_id: this.page_id,
                        index: this.index
                    };
                    this.goods_num && (e.goods_num = this.goods_num), this.$request({
                        url: this.$api.index.extra,
                        data: e
                    }).then(function(e) {
                        0 === e.code && (t.newData = e.data, t.newData.activity ? (t.newData.str = "结束", 
                        t.set_time(t.newData.activity.end_at)) : (t.newData.str = "开始", t.newData.next_activity && t.newData.next_activity.start_at && t.set_time(t.newData.next_activity.start_at)));
                    });
                },
                cloneData: function(t) {
                    return JSON.parse(JSON.stringify(t));
                },
                splitData: function() {
                    var t = this;
                    if (this.tempList.length) {
                        var e = this.tempList[0];
                        this.goodsList.push(e), this.tempList.splice(0, 1), this.tempList.length && (this.timeOut = setTimeout(function() {
                            t.splitData();
                        }, 200));
                    }
                },
                set_time: function(t) {
                    var e = this;
                    clearInterval(this.timing);
                    var n = new Date(t.replace(/-/g, "/"));
                    this.now_time(n), this.timing = setInterval(function() {
                        e.now_time(n);
                    }, 1e3);
                },
                now_time: function(t) {
                    var e = t.getTime() - new Date().getTime();
                    e < 0 && clearInterval(this.timing);
                    var n = parseInt(e / 1e3 / 60 / 60), i = parseInt(e / 1e3 / 60 % 60), a = parseInt(e / 1e3 % 60);
                    this.time_str.hou = n < 10 ? "0" + n : n, this.time_str.min = i < 10 ? "0" + i : i, 
                    this.time_str.sec = a < 10 ? "0" + a : a;
                }
            },
            mounted: function() {
                var t = this.$storage.getStorageSync("INDEX_MALL");
                this.style = t.home_pages[this.index].style, this.goods_num = t.home_pages[this.index].goods_num, 
                this.loadData();
            },
            watch: {
                copyList: {
                    handler: function(t) {
                        this.$validation.empty(t) || (this.tempList = this.cloneData(t), this.splitData());
                    }
                },
                pageHide: {
                    handler: function(t) {
                        t ? clearInterval(this.timing) : this.newData.activity ? (this.newData.str = "结束", 
                        this.set_time(this.newData.activity.end_at)) : this.newData.next_activity && (this.newData.str = "开始", 
                        this.set_time(this.newData.next_activity.start_at));
                    },
                    immediate: !0
                }
            },
            destroyed: function() {
                clearTimeout(this.time);
            },
            beforeDestroy: function() {
                clearInterval(this.timing);
            }
        };
        e.default = r;
    },
    cea5: function(t, e, n) {},
    ed45: function(t, e, n) {
        n.r(e);
        var i = n("ad4e"), a = n("06f4");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("8a31");
        var s = n("f0c5"), r = Object(s.a)(a.default, i.b, i.c, !1, null, "59336699", null, !1, i.a, void 0);
        e.default = r.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-flash-sale-create-component", {
    "components/page-component/u-index-plugins/u-flash-sale-create-component": function(t, e, n) {
        n("543d").createComponent(n("ed45"));
    }
}, [ [ "components/page-component/u-index-plugins/u-flash-sale-create-component" ] ] ]);