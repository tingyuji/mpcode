(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-advance" ], {
    "035d": function(e, t, n) {},
    "166f": function(e, t, n) {
        function i(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(e);
                t && (i = i.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, i);
            }
            return n;
        }
        function o(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = n("2f62"), s = {
            name: "u-advance",
            props: {
                index: Number,
                page_id: Number,
                is_required: Boolean,
                theme: {
                    type: Object
                },
                appImg: {
                    type: Object,
                    default: function() {
                        return {
                            plugins_out: ""
                        };
                    }
                },
                appSetting: {
                    type: Object,
                    default: function() {
                        return {
                            is_show_stock: 1,
                            sell_out_pic: "",
                            is_use_stock: 1
                        };
                    }
                },
                refresh_num: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    newData: {},
                    tempList: [],
                    goodsList: [],
                    time: 0,
                    style: "1",
                    goods_num: 20
                };
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach(function(t) {
                        o(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, (0, a.mapGetters)("mallConfig", {
                getTheme: "getTheme"
            })),
            components: {
                uIndexPlugins: function() {
                    n.e("components/page-component/u-index-plugins/u-index-plugins").then(function() {
                        return resolve(n("03c5"));
                    }.bind(null, n)).catch(n.oe);
                },
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            methods: {
                loadData: function() {
                    var e = this, t = {
                        type: 0 === this.page_id ? "mall" : "diy",
                        key: "advance",
                        page_id: this.page_id,
                        index: this.index
                    };
                    this.goods_num && (t.goods_num = this.goods_num), this.$request({
                        url: this.$api.index.extra,
                        data: t
                    }).then(function(t) {
                        if (0 === t.code && t.data && (e.newData = t.data.list, 0 === e.page_id)) {
                            var n = e.$storage.getStorageSync("INDEX_MALL");
                            n.home_pages[e.index].list = e.newData, e.$storage.setStorageSync("INDEX_MALL", n);
                        }
                    });
                },
                cloneData: function(e) {
                    return JSON.parse(JSON.stringify(e));
                },
                splitData: function() {
                    var e = this;
                    if (this.tempList.length) {
                        var t = this.tempList[0];
                        this.goodsList.push(t), this.tempList.splice(0, 1), this.tempList.length && (this.time = setTimeout(function() {
                            e.splitData();
                        }, 200));
                    }
                },
                initData: function() {
                    var e = this.$storage.getStorageSync("INDEX_MALL");
                    this.style = e.home_pages[this.index].style, this.goods_num = e.home_pages[this.index].goods_num, 
                    this.is_required ? this.loadData() : this.newData = e.home_pages[this.index].list;
                }
            },
            mounted: function() {
                this.initData();
            },
            watch: {
                newData: {
                    handler: function(e) {
                        this.$validation.empty(e) || (this.tempList = this.cloneData(e), this.splitData());
                    },
                    immediate: !0
                },
                refresh_num: function(e) {
                    this.initData();
                }
            },
            destroyed: function() {
                clearTimeout(this.time);
            }
        };
        t.default = s;
    },
    "5fc6": function(e, t, n) {
        n.r(t);
        var i = n("9159"), o = n("8c1c");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("bf30");
        var s = n("f0c5"), c = Object(s.a)(o.default, i.b, i.c, !1, null, "5fb6b482", null, !1, i.a, void 0);
        t.default = c.exports;
    },
    "8c1c": function(e, t, n) {
        n.r(t);
        var i = n("166f"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        t.default = o.a;
    },
    9159: function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    bf30: function(e, t, n) {
        var i = n("035d");
        n.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-advance-create-component", {
    "components/page-component/u-index-plugins/u-advance-create-component": function(e, t, n) {
        n("543d").createComponent(n("5fc6"));
    }
}, [ [ "components/page-component/u-index-plugins/u-advance-create-component" ] ] ]);