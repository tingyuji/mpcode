(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-miaosha" ], {
    "130ba": function(e, t, n) {},
    "154f5": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var a = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, i = [];
    },
    "1a7f": function(e, t, n) {
        var a = n("130ba");
        n.n(a).a;
    },
    "4cea": function(e, t, n) {
        function a(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, a);
            }
            return n;
        }
        function i(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = n("2f62"), s = {
            name: "u-miaosha",
            props: {
                value: {
                    type: Object,
                    default: function() {
                        return {
                            open_date: null,
                            list: []
                        };
                    }
                },
                pageHide: Boolean,
                theme: Object,
                index: Number,
                page_id: Number,
                is_required: Boolean,
                appImg: {
                    type: Object,
                    default: function() {
                        return {
                            plugins_out: ""
                        };
                    }
                },
                appSetting: {
                    type: Object,
                    default: function() {
                        return {
                            is_show_stock: 1,
                            sell_out_pic: "",
                            is_use_stock: 1
                        };
                    }
                }
            },
            data: function() {
                return {
                    style: "1",
                    goods_num: 20,
                    newData: {},
                    timer: null,
                    time: null,
                    is_vip: !0,
                    tempList: [],
                    goodsList: [],
                    timeOut: 0
                };
            },
            components: {
                uIndexPlugins: function() {
                    n.e("components/page-component/u-index-plugins/u-index-plugins").then(function() {
                        return resolve(n("03c5"));
                    }.bind(null, n)).catch(n.oe);
                },
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach(function(t) {
                        i(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, (0, o.mapGetters)("mallConfig", {
                getTheme: "getTheme"
            })),
            beforeDestroy: function() {
                clearInterval(this.time), clearTimeout(this.timeOut);
            },
            watch: {
                pageHide: {
                    handler: function(e) {
                        if (e) return clearInterval(this.time), void clearTimeout(this.timeOut);
                    },
                    immediate: !0
                },
                newData: {
                    handler: function(e) {
                        this.$validation.isEmpty(e) || (this.tempList = this.cloneData(e.list), this.splitData());
                    },
                    immediate: !0
                }
            },
            methods: {
                loadData: function() {
                    var e = this, t = {
                        type: 0 === this.page_id ? "mall" : "diy",
                        key: "miaosha",
                        page_id: this.page_id,
                        index: this.index
                    };
                    this.goods_num && (t.goods_num = this.goods_num), this.$request({
                        url: this.$api.index.extra,
                        data: t
                    }).then(function(t) {
                        if (0 === t.code && t.data) {
                            e.newData = t.data, e.newData.str = "00:00:00 点场";
                            var n = new Date();
                            if (new Date(e.newData.open_date).getDate() != n.getDate()) e.newData.str = "预告 " + e.newData.open_date + " " + e.newData.open_time + "点场"; else if (e.newData.open_time != n.getHours()) e.newData.str = "预告 " + e.newData.open_time + "点场"; else {
                                var a = 1e3 * e.newData.date_time - n.getTime();
                                e.time = setInterval(function() {
                                    if (a -= 1e3, e.newData.str = e.newData.open_time + "点场", a <= 0) clearInterval(e.time); else {
                                        var t = parseInt(a / 1e3 / 60 / 60), n = parseInt(a / 1e3 / 60 % 60), i = parseInt(a / 1e3 % 60);
                                        e.timer = {
                                            hour: t < 10 ? "0" + t : t,
                                            min: n < 10 ? "0" + n : n,
                                            sec: i < 10 ? "0" + i : i
                                        };
                                    }
                                }, 1e3);
                            }
                        }
                    });
                },
                cloneData: function(e) {
                    return JSON.parse(JSON.stringify(e));
                },
                splitData: function() {
                    var e = this;
                    if (this.tempList.length) {
                        var t = this.tempList[0];
                        this.goodsList.push(t), this.tempList.splice(0, 1), this.tempList.length && (this.timeOut = setTimeout(function() {
                            e.splitData();
                        }, 200));
                    }
                }
            },
            mounted: function() {
                var e = this.$storage.getStorageSync("INDEX_MALL");
                this.style = e.home_pages[this.index].style, this.goods_num = e.home_pages[this.index].goods_num, 
                this.loadData();
            }
        };
        t.default = s;
    },
    a40b: function(e, t, n) {
        n.r(t);
        var a = n("154f5"), i = n("c737");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("1a7f");
        var s = n("f0c5"), r = Object(s.a)(i.default, a.b, a.c, !1, null, "359a899c", null, !1, a.a, void 0);
        t.default = r.exports;
    },
    c737: function(e, t, n) {
        n.r(t);
        var a = n("4cea"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = i.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-miaosha-create-component", {
    "components/page-component/u-index-plugins/u-miaosha-create-component": function(e, t, n) {
        n("543d").createComponent(n("a40b"));
    }
}, [ [ "components/page-component/u-index-plugins/u-miaosha-create-component" ] ] ]);