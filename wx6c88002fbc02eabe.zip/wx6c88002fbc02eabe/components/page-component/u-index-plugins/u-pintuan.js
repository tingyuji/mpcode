(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-pintuan" ], {
    "22d5": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, o = [];
    },
    6799: function(t, e, n) {
        n.r(e);
        var i = n("22d5"), o = n("b889");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("9c11");
        var r = n("f0c5"), u = Object(r.a)(o.default, i.b, i.c, !1, null, "2e50689f", null, !1, i.a, void 0);
        e.default = u.exports;
    },
    "9c11": function(t, e, n) {
        var i = n("bac9");
        n.n(i).a;
    },
    b889: function(t, e, n) {
        n.r(e);
        var i = n("ffe0"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e.default = o.a;
    },
    bac9: function(t, e, n) {},
    ffe0: function(t, e, n) {
        function i(t, e, n, i, o, a, r) {
            try {
                var u = t[a](r), s = u.value;
            } catch (t) {
                return void n(t);
            }
            u.done ? e(s) : Promise.resolve(s).then(i, o);
        }
        function o(t) {
            return function() {
                var e = this, n = arguments;
                return new Promise(function(o, a) {
                    function r(t) {
                        i(s, o, a, r, u, "next", t);
                    }
                    function u(t) {
                        i(s, o, a, r, u, "throw", t);
                    }
                    var s = t.apply(e, n);
                    r(void 0);
                });
            };
        }
        function a(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(t);
                e && (i = i.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, i);
            }
            return n;
        }
        function r(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? a(Object(n), !0).forEach(function(e) {
                    u(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function u(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var s = function(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }(n("a34a")), c = n("2f62"), p = {
            name: "u-pintuan",
            props: {
                theme: {
                    type: Object
                },
                index: {
                    type: Number
                },
                page_id: {
                    type: Number
                },
                is_required: {
                    type: Boolean
                },
                appImg: {
                    type: Object,
                    default: function() {
                        return {
                            plugins_out: ""
                        };
                    }
                },
                appSetting: {
                    type: Object,
                    default: function() {
                        return {
                            is_show_stock: 1,
                            sell_out_pic: "",
                            is_use_stock: 1
                        };
                    }
                },
                refresh_num: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    newData: {},
                    tempList: [],
                    goodsList: [],
                    time: 0,
                    style: "1",
                    goods_num: 10
                };
            },
            components: {
                uIndexPlugins: function() {
                    n.e("components/page-component/u-index-plugins/u-index-plugins").then(function() {
                        return resolve(n("03c5"));
                    }.bind(null, n)).catch(n.oe);
                },
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            computed: r(r({}, (0, c.mapGetters)("mallConfig", {
                getTheme: "getTheme"
            })), {}, {
                copyList: function() {
                    return this.newData;
                }
            }),
            mounted: function() {
                this.initData();
            },
            methods: {
                loadData: function() {
                    var t = o(s.default.mark(function t() {
                        var e, n, i;
                        return s.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return e = {
                                    type: 0 === this.page_id ? "mall" : "diy",
                                    key: "pintuan",
                                    page_id: this.page_id,
                                    index: this.index
                                }, this.goods_num && (e.goods_num = this.goods_num), t.next = 4, this.$request({
                                    url: this.$api.index.extra,
                                    data: e
                                });

                              case 4:
                                n = t.sent, this.newData = n.data, 0 === n.code && n.data && 0 === this.page_id && (i = this.$storage.getStorageSync("INDEX_MALL"), 
                                i.home_pages[this.index].list = this.newData, this.$storage.setStorageSync("INDEX_MALL", i));

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, t, this);
                    }));
                    return function() {
                        return t.apply(this, arguments);
                    };
                }(),
                cloneData: function(t) {
                    return JSON.parse(JSON.stringify(t));
                },
                splitData: function() {
                    var t = this;
                    if (this.tempList.length) {
                        var e = this.tempList[0];
                        this.goodsList.push(e), this.tempList.splice(0, 1), this.tempList.length && (this.timeOut = setTimeout(function() {
                            t.splitData();
                        }, 200));
                    }
                },
                initData: function() {
                    var t = this.$storage.getStorageSync("INDEX_MALL");
                    this.style = t.home_pages[this.index].style, this.goods_num = t.home_pages[this.index].goods_num, 
                    this.is_required ? this.loadData() : this.newData = t.home_pages[this.index].list;
                }
            },
            watch: {
                copyList: {
                    handler: function(t) {
                        this.$validation.empty(t) || (this.tempList = this.cloneData(t), this.splitData());
                    }
                },
                refresh_num: function(t) {
                    this.initData();
                }
            },
            destroyed: function() {
                clearTimeout(this.time);
            }
        };
        e.default = p;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-pintuan-create-component", {
    "components/page-component/u-index-plugins/u-pintuan-create-component": function(t, e, n) {
        n("543d").createComponent(n("6799"));
    }
}, [ [ "components/page-component/u-index-plugins/u-pintuan-create-component" ] ] ]);