(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-weekly-buy" ], {
    "3f21": function(e, t, n) {
        n.r(t);
        var i = n("5dee"), o = n("9209");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("e59a");
        var r = n("f0c5"), s = Object(r.a)(o.default, i.b, i.c, !1, null, "c45d0304", null, !1, i.a, void 0);
        t.default = s.exports;
    },
    "5dee": function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    8490: function(e, t, n) {
        function i(e, t, n, i, o, a, r) {
            try {
                var s = e[a](r), u = s.value;
            } catch (e) {
                return void n(e);
            }
            s.done ? t(u) : Promise.resolve(u).then(i, o);
        }
        function o(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(o, a) {
                    function r(e) {
                        i(u, o, a, r, s, "next", e);
                    }
                    function s(e) {
                        i(u, o, a, r, s, "throw", e);
                    }
                    var u = e.apply(t, n);
                    r(void 0);
                });
            };
        }
        function a(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(e);
                t && (i = i.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, i);
            }
            return n;
        }
        function r(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? a(Object(n), !0).forEach(function(t) {
                    s(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function s(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("a34a")), c = n("2f62"), p = {
            name: "u-weekly-buy",
            props: {
                theme: {
                    type: Object
                },
                index: {
                    type: Number
                },
                page_id: {
                    type: Number
                },
                is_required: {
                    type: Boolean
                },
                appImg: {
                    type: Object,
                    default: function() {
                        return {
                            plugins_out: ""
                        };
                    }
                },
                appSetting: {
                    type: Object,
                    default: function() {
                        return {
                            is_show_stock: 1,
                            sell_out_pic: "",
                            is_use_stock: 1
                        };
                    }
                },
                refresh_num: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    isIndex: !0,
                    newData: {},
                    tempList: [],
                    goodsList: [],
                    time: 0,
                    style: "1",
                    goods_num: 10
                };
            },
            components: {
                uIndexPlugins: function() {
                    n.e("components/page-component/u-index-plugins/u-index-plugins").then(function() {
                        return resolve(n("03c5"));
                    }.bind(null, n)).catch(n.oe);
                },
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            computed: r(r({}, (0, c.mapGetters)("mallConfig", {
                getTheme: "getTheme"
            })), {}, {
                copyList: function() {
                    return this.newData;
                }
            }),
            mounted: function() {
                this.initData();
            },
            methods: {
                loadData: function() {
                    var e = o(u.default.mark(function e() {
                        var t, n, i;
                        return u.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return t = {
                                    type: 0 === this.page_id ? "mall" : "diy",
                                    key: "weekly_buy",
                                    page_id: this.page_id,
                                    index: this.index
                                }, this.goods_num && (t.goods_num = this.goods_num), e.next = 4, this.$request({
                                    url: this.$api.index.extra,
                                    data: t
                                });

                              case 4:
                                n = e.sent, this.newData = n.data, 0 === n.code && n.data && 0 === this.page_id && (i = this.$storage.getStorageSync("INDEX_MALL"), 
                                i.home_pages[this.index].list = this.newData, this.$storage.setStorageSync("INDEX_MALL", i));

                              case 7:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    return function() {
                        return e.apply(this, arguments);
                    };
                }(),
                cloneData: function(e) {
                    return JSON.parse(JSON.stringify(e));
                },
                splitData: function() {
                    var e = this;
                    if (this.tempList.length) {
                        var t = this.tempList[0];
                        this.goodsList.push(t), this.tempList.splice(0, 1), this.tempList.length && (this.timeOut = setTimeout(function() {
                            e.splitData();
                        }, 200));
                    }
                },
                initData: function() {
                    var e = this.$storage.getStorageSync("INDEX_MALL");
                    this.style = e.home_pages[this.index].style, this.goods_num = e.home_pages[this.index].goods_num, 
                    this.is_required ? this.loadData() : this.newData = e.home_pages[this.index].list;
                }
            },
            watch: {
                copyList: {
                    handler: function(e) {
                        var t = e && e.list;
                        this.$validation.empty(t) || (this.tempList = this.cloneData(t), this.splitData());
                    }
                },
                refresh_num: function(e) {
                    this.initData();
                }
            },
            destroyed: function() {
                clearTimeout(this.time);
            }
        };
        t.default = p;
    },
    9209: function(e, t, n) {
        n.r(t);
        var i = n("8490"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        t.default = o.a;
    },
    c30e: function(e, t, n) {},
    e59a: function(e, t, n) {
        var i = n("c30e");
        n.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-weekly-buy-create-component", {
    "components/page-component/u-index-plugins/u-weekly-buy-create-component": function(e, t, n) {
        n("543d").createComponent(n("3f21"));
    }
}, [ [ "components/page-component/u-index-plugins/u-weekly-buy-create-component" ] ] ]);