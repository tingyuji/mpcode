(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-index-plugins/u-index-plugins" ], {
    "03c5": function(n, e, t) {
        t.r(e);
        var o = t("1377"), u = t("505b");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(c);
        t("c29c");
        var i = t("f0c5"), a = Object(i.a)(u.default, o.b, o.c, !1, null, "14eab77d", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    1377: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, u = [];
    },
    "505b": function(n, e, t) {
        t.r(e);
        var o = t("5f1d"), u = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = u.a;
    },
    "5f1d": function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "u-index-plugins",
                props: {
                    list: {
                        type: Array
                    },
                    url: {
                        type: String
                    }
                },
                methods: {
                    router: function() {
                        n.navigateTo({
                            url: this.url
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, t("543d").default);
    },
    a342: function(n, e, t) {},
    c29c: function(n, e, t) {
        var o = t("a342");
        t.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-index-plugins/u-index-plugins-create-component", {
    "components/page-component/u-index-plugins/u-index-plugins-create-component": function(n, e, t) {
        t("543d").createComponent(t("03c5"));
    }
}, [ [ "components/page-component/u-index-plugins/u-index-plugins-create-component" ] ] ]);