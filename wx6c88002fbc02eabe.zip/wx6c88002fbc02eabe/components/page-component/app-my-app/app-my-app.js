(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-my-app/app-my-app" ], {
    "2f31": function(t, e, n) {
        (function(t) {
            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var p = n("2f62"), c = {
                name: "app-my-app",
                data: function() {
                    return {
                        is_add_show: !1
                    };
                },
                computed: a(a({
                    hiddenHeight: function() {
                        var e = this;
                        return function(n) {
                            var o, a = null;
                            return o = e.systemInfo.statusBarHeight + e.mBarHeight, o = o || 0, a = {
                                top: o + function(e) {
                                    return t.upx2px(e);
                                }(16) + "px"
                            }, Object.assign({
                                backgroundColor: e.setting.add_app_bg_color,
                                opacity: e.setting.add_app_bg_transparency / 100,
                                borderRadius: e.setting.add_app_bg_radius + "rpx"
                            }, a);
                        };
                    }
                }, (0, p.mapState)({
                    systemInfo: function(t) {
                        return t.gConfig.systemInfo;
                    },
                    mBarHeight: function(t) {
                        return t.gConfig.mBarHeight;
                    }
                })), (0, p.mapState)("mallConfig", {
                    setting: function(t) {
                        return t.mall.setting;
                    }
                })),
                methods: {
                    close: function() {
                        this.is_add_show = !1, this.$storage.setStorageSync("_IS_ADD_APP", !this.is_add_show);
                    }
                },
                created: function() {
                    this.is_add_show = !this.$storage.getStorageSync("_IS_ADD_APP");
                }
            };
            e.default = c;
        }).call(this, n("543d").default);
    },
    "699d": function(t, e, n) {},
    b24e: function(t, e, n) {
        var o = n("699d");
        n.n(o).a;
    },
    d7d6: function(t, e, n) {
        n.r(e);
        var o = n("dc88"), a = n("ff76");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        n("b24e");
        var p = n("f0c5"), c = Object(p.a)(a.default, o.b, o.c, !1, null, "2635f228", null, !1, o.a, void 0);
        e.default = c.exports;
    },
    dc88: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.is_add_show ? t.__get_style([ t.hiddenHeight() ]) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e
                }
            });
        }, a = [];
    },
    ff76: function(t, e, n) {
        n.r(e);
        var o = n("2f31"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-my-app/app-my-app-create-component", {
    "components/page-component/app-my-app/app-my-app-create-component": function(t, e, n) {
        n("543d").createComponent(n("d7d6"));
    }
}, [ [ "components/page-component/app-my-app/app-my-app-create-component" ] ] ]);