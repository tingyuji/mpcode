(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-swiper/app-swiper" ], {
    1358: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = function(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }(n("0c43")), r = {
            name: "u-swiper",
            props: {
                title: {
                    type: Boolean,
                    default: !1
                },
                indicator: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                borderRadius: {
                    type: [ Number, String ],
                    default: 0
                },
                effect3d: {
                    type: Boolean,
                    default: !1
                },
                effect3dPreviousMargin: {
                    type: [ Number, String ],
                    default: -10
                },
                margin: {
                    type: [ Number, String ],
                    default: 0
                },
                circular: {
                    type: Boolean,
                    default: !0
                },
                imgMode: {
                    type: String,
                    default: "aspectFill"
                },
                openTypeKey: {
                    type: String,
                    default: "open_type"
                },
                bgColor: {
                    type: String,
                    default: "#f3f4f6"
                },
                otherStyle: Object
            },
            watch: {
                list: {
                    handler: function(t, e) {
                        e = e || [], t.length !== e.length && (this.current = 0);
                    },
                    immediate: !0
                }
            },
            data: function() {
                return {
                    current: 0
                };
            },
            mixins: [ o.default ],
            computed: {
                calcBolderRadius: function() {
                    var t = this.borderRadius, e = this.cBorderTop, n = this.cBorderBottom;
                    return t ? "".concat(t, "rpx") : "".concat(e, "rpx ").concat(e, "rpx ").concat(n, "rpx ").concat(n, "rpx");
                },
                titlePaddingBottom: function() {
                    return "none" == this.mode ? "12rpx" : [ "bottomLeft", "bottomCenter", "bottomRight" ].indexOf(this.indicatorPos) >= 0 && "number" == this.mode ? "60rpx" : [ "bottomLeft", "bottomCenter", "bottomRight" ].indexOf(this.indicatorPos) >= 0 && "number" != this.mode ? "40rpx" : "12rpx";
                }
            },
            methods: {
                listClick: function(t) {
                    this.$emit("click", t);
                },
                change: function(t) {
                    var e = t.detail.current;
                    this.current = e, this.$emit("change", e);
                },
                animationfinish: function(t) {}
            }
        };
        e.default = r;
    },
    "8af3": function(t, e, n) {
        n.r(e);
        var o = n("9ea0"), r = n("a5de");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n("bc08");
        var a = n("f0c5"), c = Object(a.a)(r.default, o.b, o.c, !1, null, "35a9e781", null, !1, o.a, void 0);
        e.default = c.exports;
    },
    "9ea0": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s0: t.__get_style([ {
                        borderRadius: t.effect3d ? t.calcBolderRadius : 0,
                        height: t.height + "rpx",
                        transform: t.effect3d && t.current != n ? "scaleY(0.7)" : "scaleY(1)",
                        margin: t.effect3d && t.current != n ? "0 0" : "0 " + t.margin + "rpx"
                    }, t.otherStyle ])
                };
            })), n = t.list && t.list.length > 1 && "rect" == t.mode ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s1: t.__get_style([ t.testColor(n) ])
                };
            }) : null, o = t.list && t.list.length > 1 && "dot" == t.mode ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s2: t.__get_style([ t.testColor(n) ])
                };
            }) : null, r = t.list && t.list.length > 1 && "round" == t.mode ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s3: t.__get_style([ t.testColor(n) ])
                };
            }) : null, i = t.list && t.list.length > 1 && "number" == t.mode ? t.$utils.colorRgba(t.afterColor, .3) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e,
                    l1: n,
                    l2: o,
                    l3: r,
                    g0: i
                }
            });
        }, r = [];
    },
    a5de: function(t, e, n) {
        n.r(e);
        var o = n("1358"), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    },
    bc08: function(t, e, n) {
        var o = n("ce18");
        n.n(o).a;
    },
    ce18: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-swiper/app-swiper-create-component", {
    "components/page-component/app-swiper/app-swiper-create-component": function(t, e, n) {
        n("543d").createComponent(n("8af3"));
    }
}, [ [ "components/page-component/app-swiper/app-swiper-create-component" ] ] ]);