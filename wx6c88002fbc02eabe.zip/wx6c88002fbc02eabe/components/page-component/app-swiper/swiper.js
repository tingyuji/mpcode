(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-swiper/swiper" ], {
    "04d1": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__get_style([ Object.assign({
                height: t.height + "rpx",
                width: "100%"
            }, t.styleB) ])), n = "rect" === t.mode ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s1: t.__get_style([ t.testColor(n) ])
                };
            }) : null, o = "round" === t.mode ? t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s2: t.__get_style([ t.testColor(n) ])
                };
            }) : null, r = "number" == t.mode ? t.$utils.colorRgba(t.afterColor, .3) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e,
                    l0: n,
                    l1: o,
                    g0: r
                }
            });
        }, r = [];
    },
    "4ec4": function(t, e, n) {
        var o = n("cb53");
        n.n(o).a;
    },
    a0bb: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("0c43")), r = {
                name: "u-swiper",
                props: {
                    imgMode: {
                        type: String,
                        default: "aspectFill"
                    }
                },
                data: function() {
                    return {
                        current: 0,
                        zIndex: 0,
                        showpic: null,
                        hidepic: null,
                        setTime: 0,
                        touchDot: 0
                    };
                },
                mixins: [ o.default ],
                methods: {
                    touchstart: function(t) {
                        this.touchDot = t.touches[0].pageX;
                    },
                    touchend: function(t) {
                        var e = this, n = t.changedTouches[0].pageX;
                        n - this.touchDot <= -40 && (this.current = this.current - 1, this.current < 0 && (this.current = this.list.length - 1), 
                        setTimeout(function() {
                            e.zIndex = e.current;
                        }, 1e3)), n - this.touchDot >= 40 && (this.current = this.current + 1, this.current >= this.list.length && (this.current = 0), 
                        setTimeout(function() {
                            e.zIndex = e.current;
                        }, 1e3));
                    }
                },
                destroyed: function() {
                    clearInterval(this.setTime);
                },
                watch: {
                    list: {
                        handler: function(e) {
                            var n = this;
                            if (0 !== e.length) {
                                var o = t.createAnimation({});
                                o.opacity(1).step({
                                    duration: this.duration
                                }), this.showpic = o.export(), o.opacity(0).step({
                                    duration: this.duration
                                }), this.hidepic = o.export(), this.autoplay && (clearInterval(this.setTime), this.setTime = setInterval(function() {
                                    n.current = n.current + 1, n.current >= n.list.length && (n.current = 0), setTimeout(function() {
                                        n.zIndex = n.current;
                                    }, n.interval + 1e3);
                                }, this.interval));
                            }
                        },
                        immediate: !0
                    }
                },
                computed: {
                    styleB: function() {
                        var t = this.cBorderTop, e = this.cBorderBottom;
                        return {
                            borderTopLeftRadius: "".concat(t, "rpx"),
                            borderTopRightRadius: "".concat(t, "rpx"),
                            borderBottomLeftRadius: "".concat(e, "rpx"),
                            borderBottomRightRadius: "".concat(e, "rpx")
                        };
                    }
                }
            };
            e.default = r;
        }).call(this, n("543d").default);
    },
    b6b4: function(t, e, n) {
        n.r(e);
        var o = n("04d1"), r = n("fbbc5");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n("4ec4");
        var c = n("f0c5"), u = Object(c.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = u.exports;
    },
    cb53: function(t, e, n) {},
    fbbc5: function(t, e, n) {
        n.r(e);
        var o = n("a0bb"), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-swiper/swiper-create-component", {
    "components/page-component/app-swiper/swiper-create-component": function(t, e, n) {
        n("543d").createComponent(n("b6b4"));
    }
}, [ [ "components/page-component/app-swiper/swiper-create-component" ] ] ]);