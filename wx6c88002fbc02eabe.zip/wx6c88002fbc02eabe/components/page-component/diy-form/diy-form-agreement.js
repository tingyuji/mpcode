(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form-agreement" ], {
    "106e": function(t, e, i) {
        i.r(e);
        var o = i("3aaf"), n = i("e049");
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(c);
        i("a206");
        var a = i("f0c5"), r = Object(a.a)(n.default, o.b, o.c, !1, null, "4be7b59e", null, !1, o.a, void 0);
        e.default = r.exports;
    },
    "3aaf": function(t, e, i) {
        i.d(e, "b", function() {
            return o;
        }), i.d(e, "c", function() {
            return n;
        }), i.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(e) {
                t.is_show = !1;
            });
        }, n = [];
    },
    "3ae6": function(t, e, i) {},
    a206: function(t, e, i) {
        var o = i("3ae6");
        i.n(o).a;
    },
    c484: function(t, e, i) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0, i("2f62");
            var o = {
                name: "diy-form-agreement",
                data: function() {
                    return {
                        is_check: !1,
                        is_show: !1,
                        is_over: !1,
                        scrollHeight: 476,
                        data: {},
                        titleHeight: 0
                    };
                },
                props: {
                    index: [ Number, String ],
                    value: {
                        type: Object
                    }
                },
                computed: {
                    cDialogStyle: function() {
                        return "background-color:".concat(this.data.fill_color, ";color:").concat(this.data.content_color, ";border-radius:").concat(this.data.radius, "px;height:").concat(this.data.height, "rpx;");
                    },
                    cRadioStyle: function() {
                        return "background-color:".concat(this.data.bg_color, ";width:100%;padding: 0 24rpx;");
                    },
                    cTitleStyle: function() {
                        return "color:".concat(this.data.title_color, ";");
                    }
                },
                created: function() {
                    this.data = this.value;
                    var t = {
                        is_check: this.is_check,
                        title: this.data.title,
                        content: this.data.content,
                        title_color: this.data.title_color
                    };
                    this.$emit("updateValue", {
                        index: this.index,
                        value: t
                    });
                },
                methods: {
                    close: function(t) {
                        if (this.is_over) {
                            this.is_check = !!t, this.is_show = !1;
                            var e = {
                                is_check: this.is_check,
                                title: this.data.title,
                                content: this.data.content,
                                title_color: this.data.title_color
                            };
                            this.$emit("updateValue", {
                                index: this.index,
                                value: e
                            });
                        }
                    },
                    toggleCheck: function() {
                        this.is_check ? this.is_check = !1 : this.showAgreement();
                        var t = {
                            is_check: this.is_check,
                            title: this.data.title,
                            content: this.data.content,
                            title_color: this.data.title_color
                        };
                        this.$emit("updateValue", {
                            index: this.index,
                            value: t
                        });
                    },
                    showAgreement: function() {
                        var e = this;
                        e.is_show = !e.is_show, e.is_over = "1" != e.data.is_read;
                        setTimeout(function() {
                            var i = t.createSelectorQuery().in(e);
                            i.select("#agreement-dialog-title").boundingClientRect(function(o) {
                                e.titleHeight = o.height / (t.upx2px(100) / 100), i.selectAll(".agreement-dialog-content-hidden").fields({
                                    size: !0
                                }, function(t) {
                                    e.scrollHeight = t[0].height - (e.data.height / 2 - 136), e.scrollHeight < 0 && (e.is_over = !0);
                                }).exec();
                            }).exec();
                        }, 0);
                    },
                    showScroll: function(t) {
                        t.detail.scrollTop < this.scrollHeight || (this.is_over = !0);
                    }
                }
            };
            e.default = o;
        }).call(this, i("543d").default);
    },
    e049: function(t, e, i) {
        i.r(e);
        var o = i("c484"), n = i.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(c);
        e.default = n.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-agreement-create-component", {
    "components/page-component/diy-form/diy-form-agreement-create-component": function(t, e, i) {
        i("543d").createComponent(i("106e"));
    }
}, [ [ "components/page-component/diy-form/diy-form-agreement-create-component" ] ] ]);