(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form" ], {
    "03c0": function(e, i, t) {
        var n = t("7a8d");
        t.n(n).a;
    },
    2026: function(e, i, t) {
        t.r(i);
        var n = t("abb1"), o = t("c8cf");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(i, e, function() {
                return o[e];
            });
        }(a);
        t("03c0");
        var d = t("f0c5"), r = Object(d.a)(o.default, n.b, n.c, !1, null, "e6eb1fa6", null, !1, n.a, void 0);
        i.default = r.exports;
    },
    "7a8d": function(e, i, t) {},
    abb1: function(e, i, t) {
        t.d(i, "b", function() {
            return n;
        }), t.d(i, "c", function() {
            return o;
        }), t.d(i, "a", function() {});
        var n = function() {
            var e = this, i = (e.$createElement, e._self._c, e.__map(e.formList, function(i, t) {
                var n = e.__get_orig(i), o = "image-text" !== i.id && "banner" === i.id && i.data.banners.length > 0 && (1 == i.data.effect || !i.data.effect) ? e.$utils.colorRgba(i.data.swiper_color, .3) : null, a = "image-text" !== i.id && "banner" === i.id && i.data.banners.length > 0 && 2 == i.data.effect ? e.$utils.colorRgba(i.data.swiper_color, .3) : null, d = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" === i.id ? e.__map(i.data.hotspot, function(i, t) {
                    return {
                        $orig: e.__get_orig(i),
                        m0: e.rubikHotspot(i)
                    };
                }) : null, r = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" === i.id ? e.componentShow(i) : null, u = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" === i.id ? e.componentShow(i) : null, l = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" === i.id ? e.componentShow(i) : null, c = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" === i.id ? e.componentShow(i) : null, s = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" === i.id ? e.componentShow(i) : null, m = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" === i.id ? e.componentShow(i) : null, p = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" === i.id ? e.componentShow(i) : null, f = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" === i.id ? e.componentShow(i) : null, h = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" === i.id ? e.componentShow(i) : null, v = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" === i.id ? e.componentShow(i) : null, g = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" === i.id ? e.componentShow(i) : null, y = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" === i.id ? e.componentShow(i) : null, b = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" === i.id ? e.componentShow(i) : null, k = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" !== i.id && "position" === i.id ? e.componentShow(i) : null, _ = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" !== i.id && "position" !== i.id && "button" === i.id ? e.hideIdsStatus.filter(function(i) {
                    return !e.t_hide.includes(i);
                }) : null, w = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" !== i.id && "position" !== i.id && "button" === i.id ? new Date((i.data.time_at || "").replace(/-/g, "/")).getTime() : null, x = "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" !== i.id && "position" !== i.id && "button" === i.id ? new Date().getTime() : null;
                return {
                    $orig: n,
                    g0: o,
                    g1: a,
                    l0: d,
                    m1: r,
                    m2: u,
                    m3: l,
                    m4: c,
                    m5: s,
                    m6: m,
                    m7: p,
                    m8: f,
                    m9: h,
                    m10: v,
                    m11: g,
                    m12: y,
                    m13: b,
                    m14: k,
                    g2: _,
                    g3: w,
                    g4: x,
                    s0: "image-text" !== i.id && "banner" !== i.id && "link" !== i.id && "copyright" !== i.id && "rubik" !== i.id && "video" !== i.id && "empty" !== i.id && "uimage" !== i.id && "uvideo" !== i.id && "phone" !== i.id && "menu" !== i.id && "calendar" !== i.id && "switch" !== i.id && "agreement" !== i.id && "time" !== i.id && "radio" !== i.id && "select" !== i.id && "input" !== i.id && "text" !== i.id && "position" !== i.id && "button" === i.id && 1 == i.data.time_status && w < x ? e.__get_style([ e.btnStyle(i.data), {
                        background: "#cccccc",
                        color: "white",
                        borderColor: "#cccccc"
                    } ]) : null,
                    s1: "image-text" === i.id || "banner" === i.id || "link" === i.id || "copyright" === i.id || "rubik" === i.id || "video" === i.id || "empty" === i.id || "uimage" === i.id || "uvideo" === i.id || "phone" === i.id || "menu" === i.id || "calendar" === i.id || "switch" === i.id || "agreement" === i.id || "time" === i.id || "radio" === i.id || "select" === i.id || "input" === i.id || "text" === i.id || "position" === i.id || "button" !== i.id || 1 == i.data.time_status && w < x ? null : e.__get_style([ e.btnStyle(i.data) ])
                };
            }));
            e._isMounted || (e.e0 = function(i) {
                e.video_url = "";
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    l1: i
                }
            });
        }, o = [];
    },
    bd92: function(e, i, t) {
        function n(e, i) {
            var t = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!t) {
                if (Array.isArray(e) || (t = o(e)) || i && e && "number" == typeof e.length) {
                    t && (e = t);
                    var n = 0, a = function() {};
                    return {
                        s: a,
                        n: function() {
                            return n >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[n++]
                            };
                        },
                        e: function(e) {
                            throw e;
                        },
                        f: a
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var d, r = !0, u = !1;
            return {
                s: function() {
                    t = t.call(e);
                },
                n: function() {
                    var e = t.next();
                    return r = e.done, e;
                },
                e: function(e) {
                    u = !0, d = e;
                },
                f: function() {
                    try {
                        r || null == t.return || t.return();
                    } finally {
                        if (u) throw d;
                    }
                }
            };
        }
        function o(e, i) {
            if (e) {
                if ("string" == typeof e) return a(e, i);
                var t = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? a(e, i) : void 0;
            }
        }
        function a(e, i) {
            (null == i || i > e.length) && (i = e.length);
            for (var t = 0, n = new Array(i); t < i; t++) n[t] = e[t];
            return n;
        }
        Object.defineProperty(i, "__esModule", {
            value: !0
        }), i.default = void 0;
        var d = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(t("dc83"));
        t("ac6b");
        var r = {
            name: "diy-form",
            components: {
                "app-rich": function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/basic-component/app-rich/parse") ]).then(function() {
                        return resolve(t("cb0e"));
                    }.bind(null, t)).catch(t.oe);
                },
                appEmpty: function() {
                    t.e("components/basic-component/app-empty/app-empty").then(function() {
                        return resolve(t("a7c3"));
                    }.bind(null, t)).catch(t.oe);
                },
                appImageAd: function() {
                    t.e("components/page-component/app-image-ad/app-image-ad").then(function() {
                        return resolve(t("605d"));
                    }.bind(null, t)).catch(t.oe);
                },
                appHotspot: function() {
                    t.e("components/basic-component/app-hotspot/app-hotspot").then(function() {
                        return resolve(t("9c0a"));
                    }.bind(null, t)).catch(t.oe);
                },
                appVideo: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-video/app-video") ]).then(function() {
                        return resolve(t("d824"));
                    }.bind(null, t)).catch(t.oe);
                },
                appCopyright: function() {
                    t.e("components/page-component/app-copyright/app-copyright").then(function() {
                        return resolve(t("7fe8"));
                    }.bind(null, t)).catch(t.oe);
                },
                appAssociatedLink: function() {
                    t.e("components/page-component/app-associated-link/app-associated-link").then(function() {
                        return resolve(t("1cff"));
                    }.bind(null, t)).catch(t.oe);
                },
                appSwiper: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-swiper/app-swiper") ]).then(function() {
                        return resolve(t("8af3"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormRadio: function() {
                    t.e("components/page-component/diy-form/diy-form-radio").then(function() {
                        return resolve(t("3af0"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormInput: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/diy-form/diy-form-input") ]).then(function() {
                        return resolve(t("6382"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormButton: function() {
                    t.e("components/page-component/diy-form/diy-form-button").then(function() {
                        return resolve(t("8584"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormCalendar: function() {
                    t.e("components/page-component/diy-form/diy-form-calendar").then(function() {
                        return resolve(t("5448"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormMenu: function() {
                    t.e("components/page-component/diy-form/diy-form-menu").then(function() {
                        return resolve(t("285f"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormPhone: function() {
                    t.e("components/page-component/diy-form/diy-form-phone").then(function() {
                        return resolve(t("08d3"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormTime: function() {
                    t.e("components/page-component/diy-form/diy-form-time").then(function() {
                        return resolve(t("779a"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormUimage: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/diy-form/diy-form-uimage") ]).then(function() {
                        return resolve(t("3520"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormUvideo: function() {
                    t.e("components/page-component/diy-form/diy-form-uvideo").then(function() {
                        return resolve(t("6018"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormSwitch: function() {
                    t.e("components/page-component/diy-form/diy-form-switch").then(function() {
                        return resolve(t("6229"));
                    }.bind(null, t)).catch(t.oe);
                },
                diyFormAgreement: function() {
                    t.e("components/page-component/diy-form/diy-form-agreement").then(function() {
                        return resolve(t("106e"));
                    }.bind(null, t)).catch(t.oe);
                },
                uSwiper: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-swiper/swiper") ]).then(function() {
                        return resolve(t("b6b4"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    video_url: "",
                    error: "",
                    formList: [],
                    otherForm: [],
                    is_start_show: !1,
                    logicData: [],
                    hideIds: [],
                    hideIdsStatus: [],
                    t_hide: [],
                    t: "",
                    f_id: ""
                };
            },
            inject: [ "t_index" ],
            computed: {
                btnStyle: function() {
                    var e = this;
                    return function(i) {
                        return {
                            height: "".concat(i.btn_height, "rpx"),
                            background: i.btn_bg,
                            margin: "0 ".concat(i.btn_padding, "rpx 20rpx"),
                            color: i.btn_color,
                            borderWidth: "1px",
                            borderStyle: "solid",
                            borderColor: i.btn_border_color,
                            borderRadius: "".concat(i.btn_radius, "rpx"),
                            position: 1 == i.is_sticky ? "sticky" : "static",
                            bottom: "calc(".concat(e.t_index.tabbarbool ? "100rpx" : "0px", " + 40rpx + env(safe-area-inset-bottom))")
                        };
                    };
                },
                componentShow: {
                    get: function() {
                        var e = this;
                        return function(i) {
                            var t = i.data;
                            return -1 === [].concat(e.hideIds).indexOf(t.key);
                        };
                    },
                    set: function(e) {
                        var i, t = [], o = n(e);
                        try {
                            for (o.s(); !(i = o.n()).done; ) {
                                var a = i.value.data, d = a.has_show, r = a.key;
                                0 == d && t.push(r);
                            }
                        } catch (e) {
                            o.e(e);
                        } finally {
                            o.f();
                        }
                        this.hideIdsStatus = t, this.hideIds = [].concat(this.hideIdsStatus);
                    }
                }
            },
            props: {
                pageId: [ Number, String ],
                template_message_list: Array,
                value: {
                    type: Object
                }
            },
            watch: {
                formList: {
                    handler: function(e) {
                        if (this.t && this.f_id && e && e.length) try {
                            this.$storage.setStorageSync("DFORM-" + this.f_id, {
                                data: e,
                                t: this.t
                            });
                        } catch (e) {}
                        this.setError(e), this.handlerLogicData();
                    },
                    immediate: !0,
                    deep: !0
                }
            },
            created: function() {
                this.t = this.value.updated_at, this.f_id = this.value.form_id;
                var e = JSON.parse(JSON.stringify(this.value)), i = this.$storage.getStorageSync("DFORM-" + this.f_id);
                this.formList = i && this.t && i.t === this.t ? i.data : e.list, this.logicData = e.logic_data, 
                this.componentShow = e.list;
            },
            methods: {
                validSubmit: function() {
                    this.$refs.button[0].validSubmit();
                },
                setError: function(e) {
                    this.otherForm = [], this.error = "";
                    var i, t = n(e);
                    try {
                        for (t.s(); !(i = t.n()).done; ) {
                            var o = i.value;
                            if ("button" != o.id && o.data.title && "link" != o.id) {
                                var a = new d.default({
                                    key: o.id,
                                    label: o.data.title,
                                    value: o.value || null,
                                    required: o.data.is_required
                                });
                                if (a.add({
                                    unique: o.data.key || ""
                                }), this.otherForm.push(a.getObject()), -1 !== this.hideIds.indexOf(o.data.key || "")) continue;
                                if ("input" === a.key && !o.data.is_disabled && a.value && a.value.text && a.value.text.length < o.data.min) {
                                    this.error = a.label + "最少输入" + o.data.min + "个字符";
                                    continue;
                                }
                                if ("text" === a.key && !o.data.is_disabled && a.value && a.value.length < o.data.min) {
                                    this.error = a.label + "最少输入" + o.data.min + "个字符";
                                    continue;
                                }
                                if ("select" === a.key) {
                                    if (a.value && a.value.length > 0 && a.value.length < o.data.min) {
                                        this.error = a.label + "最少选择" + o.data.min + "项";
                                        continue;
                                    }
                                    if (a.value && a.value.length > 0 && a.value.length > o.data.max) {
                                        this.error = a.label + "最多选择" + o.data.max + "项";
                                        continue;
                                    }
                                }
                                if ("uvideo" === a.key) {
                                    if (a.value && a.value.length > 0 && a.value.length < o.data.min_num) {
                                        this.error = a.label + "最少上传" + o.data.min_num + "个";
                                        continue;
                                    }
                                    if (a.value && a.value.length > 0 && a.value.length > o.data.max_num) {
                                        this.error = a.label + "最多上传" + o.data.max_num + "个";
                                        continue;
                                    }
                                }
                                if ("uimage" === a.key && "ordinary" === o.data.type) {
                                    if (a.value && a.value.length > 0 && a.value.length < o.data.min_num) {
                                        this.error = a.label + "最少上传" + o.data.min_num + "张";
                                        continue;
                                    }
                                    if (a.value && a.value.length > 0 && a.value.length > o.data.max_num) {
                                        this.error = a.label + "最多上传" + o.data.max_num + "张";
                                        continue;
                                    }
                                }
                                if (1 == a.required) {
                                    if (null == a.value) {
                                        "input" !== a.key && "text" !== a.key && "phone" !== a.key ? this.error = "请选择" + a.label : this.error = "请填写" + a.label;
                                        continue;
                                    }
                                    if ("menu" === a.key) "date" === o.data.type && a.value && (o.data.data_type && 1 == o.data.data_type.is_now ? a.value.fulldate || (this.error = "请填写" + a.label) : a.value.alone_at || a.value.begin_at && a.value.end_at || (this.error = "请将" + a.label + "填写完整")); else if ("uimage" === a.key) if ("ordinary" === o.data.type) {
                                        if (a.value && 0 == a.value.length) {
                                            this.error = "请选择" + a.label;
                                            continue;
                                        }
                                    } else {
                                        var r = "license" === o.data.type ? 1 : 2;
                                        if (!a.value || a.value.filter(function(e) {
                                            return !!e;
                                        }).length < r) {
                                            this.error = "请将" + a.label + "填写完整";
                                            continue;
                                        }
                                    } else if ("uvideo" === a.key) {
                                        if (a.value && 0 == a.value.length) {
                                            this.error = "请选择" + a.label;
                                            continue;
                                        }
                                    } else if ("calendar" === a.key) {
                                        if (!(a.value.fulldate || a.value.before && a.value.after)) {
                                            this.error = "请将" + a.label + "填写完整";
                                            continue;
                                        }
                                    } else if ("agreement" === a.key) {
                                        if (!a.value.is_check) {
                                            this.error = "请阅读并勾选" + a.label;
                                            continue;
                                        }
                                    } else "select" === a.key ? a.value && 0 == a.value.length && (this.error = "请选择" + a.label) : "input" === a.key && (a.value.text || (this.error = "请填写" + a.label));
                                }
                            }
                        }
                    } catch (e) {
                        t.e(e);
                    } finally {
                        t.f();
                    }
                },
                rubikHotspot: function(e) {
                    return e && e.link && (e.link.url = e.link.value, e.link.openType = e.link.open_type), 
                    e;
                },
                play: function(e) {
                    this.video_url = e.video;
                },
                reset: function(e) {
                    var i = this;
                    this.formList = [], this.$nextTick(function() {
                        i.formList = JSON.parse(JSON.stringify(i.value.list)), i.$forceUpdate();
                    });
                },
                updateValue: function(e) {
                    var i = e.index, t = e.value, n = this;
                    setTimeout(function(e) {
                        var o = n.formList[i];
                        o.value = t, n.formList.splice(i, 1, o), n.$forceUpdate();
                    }, 100);
                },
                handlerLogicData: function() {
                    var e = this;
                    if (!this.is_start_show) {
                        this.is_start_show = !0;
                        var i = new Set(this.hideIdsStatus), t = this.logicData, o = !1;
                        for (var a in t) {
                            var d = t[a], r = d.rule_after, u = d.rule_begin, l = 0;
                            o = !0;
                            var c, s = n(u);
                            try {
                                for (s.s(); !(c = s.n()).done; ) {
                                    var m, p = c.value, f = n(this.otherForm);
                                    try {
                                        for (f.s(); !(m = f.n()).done; ) {
                                            var h = m.value;
                                            if (h.unique === p.k && h.value) {
                                                var v = h.key, g = h.value;
                                                if (-1 !== Array.from(i).indexOf(p.k)) continue;
                                                !function() {
                                                    switch (v) {
                                                      case "menu":
                                                        var e = g.type;
                                                        if ("date" === e) {
                                                            var i = g.alone_at, t = g.begin_at, n = g.end_at;
                                                            (i && p.v === i || t && n && t <= p.v && n >= p.v) && l++;
                                                        }
                                                        if ("store" === e) {
                                                            var o = g.store_id, a = o instanceof Array ? o[0] : o;
                                                            o == a && a && l++;
                                                        }
                                                        if ("address" === e || "basic" === e) {
                                                            var d = g.text;
                                                            (d = d.split("-")) && JSON.stringify(d.map(function(e) {
                                                                return e.trim();
                                                            })) === JSON.stringify(p.v.map(function(e) {
                                                                return e.trim();
                                                            })) && l++;
                                                        }
                                                        if ("time" === e) {
                                                            var r = g.alone_time, u = g.begin_time, c = g.end_time;
                                                            p.v instanceof Array ? u >= p.v[0] && c <= p.v[1] && l++ : p.v === r && l++;
                                                        }
                                                        break;

                                                      case "radio":
                                                        g.value === p.v[0] && l++;
                                                        break;

                                                      case "select":
                                                        var s = g.sort(), m = p.v.sort();
                                                        m[0] && s.find(function(e) {
                                                            return e.value === m[0];
                                                        }) && l++;
                                                    }
                                                }();
                                            }
                                        }
                                    } catch (e) {
                                        f.e(e);
                                    } finally {
                                        f.f();
                                    }
                                    l && l === u.length && (i = this.playup(r, i));
                                }
                            } catch (e) {
                                s.e(e);
                            } finally {
                                s.f();
                            }
                        }
                        return o ? this.$nextTick(function() {
                            e.hideIds = Array.from(i), e.setError(e.formList), e.is_start_show = !1;
                        }) : this.$nextTick(function() {
                            e.is_start_show = !1;
                        }), t;
                    }
                },
                playup: function(e, i) {
                    console.log("触发success => ", e);
                    var t, o = n(e);
                    try {
                        for (o.s(); !(t = o.n()).done; ) {
                            var a = t.value;
                            for (var d in this.otherForm) {
                                var r = this.otherForm[d];
                                if (r.unique === a.k) {
                                    if (this.t_hide = Array.from(new Set(this.t_hide).add(r.unique)), -1 == a.v) {
                                        i.has(r.unique) && i.delete(r.unique);
                                        continue;
                                    }
                                    if (-2 == a.v) {
                                        if (this.t_hide.push(r.unique), i.has(r.unique)) continue;
                                        if (-1 !== this.hideIdsStatus.indexOf(r.unique)) continue;
                                        for (var u in this.formList) {
                                            if ("radio" === this.formList[u].id && this.formList[u].data.key === a.k) {
                                                this.formList[u].value = null, this.formList[u].data.list.forEach(function(e) {
                                                    e.value = !1;
                                                });
                                                var l = "refradio" + a.k;
                                                this.$refs[l] && this.$refs[l][0].updateNewList(this.formList[u].data.list);
                                            }
                                            if ("select" === this.formList[u].id && this.formList[u].data.key === a.k) {
                                                this.formList[u].value = [], this.formList[u].data.list.forEach(function(e) {
                                                    e.value = !1;
                                                });
                                                var c = "refselect" + a.k;
                                                this.$refs[c] && this.$refs[c][0].updateNewList(this.formList[u].data.list);
                                            }
                                        }
                                        this.otherForm[d].value = null, i.add(r.unique);
                                        continue;
                                    }
                                }
                            }
                        }
                    } catch (e) {
                        o.e(e);
                    } finally {
                        o.f();
                    }
                    return i;
                },
                imageEvent: function(e) {
                    console.log(e);
                }
            }
        };
        i.default = r;
    },
    c8cf: function(e, i, t) {
        t.r(i);
        var n = t("bd92"), o = t.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(i, e, function() {
                return n[e];
            });
        }(a);
        i.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-create-component", {
    "components/page-component/diy-form/diy-form-create-component": function(e, i, t) {
        t("543d").createComponent(t("2026"));
    }
}, [ [ "components/page-component/diy-form/diy-form-create-component" ] ] ]);