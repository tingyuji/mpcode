(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form-input" ], {
    "4da6": function(t, e, a) {
        a.d(e, "b", function() {
            return n;
        }), a.d(e, "c", function() {
            return r;
        }), a.d(e, "a", function() {});
        var n = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, r = [];
    },
    "5ae3": function(t, e, a) {
        var n = a("aaa0");
        a.n(n).a;
    },
    6382: function(t, e, a) {
        a.r(e);
        var n = a("4da6"), r = a("dfa0");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            a.d(e, t, function() {
                return r[t];
            });
        }(i);
        a("5ae3");
        var o = a("f0c5"), s = Object(o.a)(r.default, n.b, n.c, !1, null, "0bd6618e", null, !1, n.a, void 0);
        e.default = s.exports;
    },
    "7e64": function(t, a, n) {
        (function(t) {
            function r(t, e) {
                return s(t) || o(t, e) || h(t, e) || i();
            }
            function i() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function o(t, e) {
                var a = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (null != a) {
                    var n, r, i = [], o = !0, s = !1;
                    try {
                        for (a = a.call(t); !(o = (n = a.next()).done) && (i.push(n.value), !e || i.length !== e); o = !0) ;
                    } catch (t) {
                        s = !0, r = t;
                    } finally {
                        try {
                            o || null == a.return || a.return();
                        } finally {
                            if (s) throw r;
                        }
                    }
                    return i;
                }
            }
            function s(t) {
                if (Array.isArray(t)) return t;
            }
            function d(t, e, a, n, r, i, o) {
                try {
                    var s = t[i](o), d = s.value;
                } catch (t) {
                    return void a(t);
                }
                s.done ? e(d) : Promise.resolve(d).then(n, r);
            }
            function c(t) {
                return function() {
                    var e = this, a = arguments;
                    return new Promise(function(n, r) {
                        function i(t) {
                            d(s, n, r, i, o, "next", t);
                        }
                        function o(t) {
                            d(s, n, r, i, o, "throw", t);
                        }
                        var s = t.apply(e, a);
                        i(void 0);
                    });
                };
            }
            function u(t, e) {
                var a = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (!a) {
                    if (Array.isArray(t) || (a = h(t)) || e && t && "number" == typeof t.length) {
                        a && (t = a);
                        var n = 0, r = function() {};
                        return {
                            s: r,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                };
                            },
                            e: function(t) {
                                function e(e) {
                                    return t.apply(this, arguments);
                                }
                                return e.toString = function() {
                                    return t.toString();
                                }, e;
                            }(function(t) {
                                throw t;
                            }),
                            f: r
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var i, o = !0, s = !1;
                return {
                    s: function() {
                        a = a.call(t);
                    },
                    n: function() {
                        var t = a.next();
                        return o = t.done, t;
                    },
                    e: function(t) {
                        function e(e) {
                            return t.apply(this, arguments);
                        }
                        return e.toString = function() {
                            return t.toString();
                        }, e;
                    }(function(t) {
                        s = !0, i = t;
                    }),
                    f: function() {
                        try {
                            o || null == a.return || a.return();
                        } finally {
                            if (s) throw i;
                        }
                    }
                };
            }
            function h(t, e) {
                if (t) {
                    if ("string" == typeof t) return l(t, e);
                    var a = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === a && t.constructor && (a = t.constructor.name), "Map" === a || "Set" === a ? Array.from(t) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? l(t, e) : void 0;
                }
            }
            function l(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var a = 0, n = new Array(e); a < e; a++) n[a] = t[a];
                return n;
            }
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var f = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("a34a"));
            n("2f62");
            var p = {
                name: "diy-form-input",
                data: function() {
                    return {
                        text: "",
                        max: 300,
                        hiddenCount: !1,
                        number: 0,
                        data: {}
                    };
                },
                props: {
                    index: [ Number, String ],
                    mode: {
                        type: String,
                        default: "input"
                    },
                    value: {
                        type: Object
                    }
                },
                computed: {
                    hasError: function() {
                        if (this.text) {
                            if (1 == this.data.mode && this.data.allow) {
                                var t = function(t, e) {
                                    for (var a = 0; a < e.length; a++) for (var n = 0; n < t.length; n++) t[n] == e[a] && (t.splice(n, 1), 
                                    n -= 1);
                                    return t;
                                }([ "1", "2", "3", "4" ], this.data.allow);
                                if (-1 !== t.indexOf("1") && /[\u4e00-\u9fa5]+/.test(this.text)) return !0;
                                if (-1 !== t.indexOf("2") && /[A-Za-z]/.test(this.text)) return !0;
                                if (-1 !== t.indexOf("3") && /[0-9]/.test(this.text)) return !0;
                                if (-1 !== t.indexOf("4") && /\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\|/.test(this.text)) return !0;
                            }
                            if (3 == this.data.mode && this.text && !/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(this.text)) return !0;
                            if (2 == this.data.mode && this.text && (11 != this.text.length || !this.text.startsWith(1))) return !0;
                            if (4 == this.data.mode && this.text && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.text)) return !0;
                        }
                        return !1;
                    },
                    inputType: function() {
                        return 1 == this.data.mode && "input" == this.mode && this.data.allow && "number" == this.data.allow[0] && 1 == this.data.allow.length || 2 == this.data.mode ? "number" : 4 == this.data.mode ? "idcard" : "text";
                    },
                    cRadioStyle: function() {
                        return "background-color:".concat(this.data.bg_color, ";width:100%;padding: 16rpx ").concat(+this.data.inputPadding, "rpx;");
                    },
                    cTitleStyle: function() {
                        var t = "color:".concat(this.data.title_color, ";");
                        return 3 == this.data.style && (t += "left:".concat(+this.data.inputPadding, "rpx;"), 
                        "input" == this.mode && (t += "line-height: 1;")), t;
                    },
                    endStyle: function() {
                        var t = "";
                        return (1 == this.data.is_scan_code && 0 == this.data.is_disabled || this.text) && (t += "padding-bottom: 58rpx"), 
                        t;
                    },
                    inputItemStyle: function() {
                        var t = "border-radius:".concat(this.data.radius, "rpx;overflow:hidden;background-color:").concat(this.data.fill_color, ";padding-top: 16rpx;padding-bottom: 16rpx;");
                        return this.data.border_color && (t += "border: 2rpx solid ".concat(this.data.border_color, ";")), 
                        t;
                    },
                    inputStyle: function() {
                        var t = "color:".concat(this.data.text_color, ";width: 100%;");
                        return "position" != this.mode || this.text || (t = "color:".concat(this.data.placeholder_color, ";")), 
                        "text" == this.mode && (t += "min-height: ".concat(1 != this.data.style && this.data.height ? this.data.height : 56, "rpx;")), 
                        1 != this.data.style ? t += "background-color:".concat(this.data.fill_color, ";border-radius:").concat("text" == this.mode && 2 == this.data.style ? 0 : this.data.radius, "rpx;") : t += "background-color:".concat(this.data.bg_color, ";"), 
                        this.data.border_color && 1 == this.data.style && (t += "border: 2rpx solid ".concat(this.data.bg_color, ";border-bottom: 2rpx solid ").concat(this.data.border_color, ";")), 
                        3 == this.data.style && "text" != this.mode && (t += "padding-left: 160rpx;text-align: right;"), 
                        "text" == this.mode && (1 == this.data.style && (t += "border-bottom-width: 0"), 
                        2 == this.data.style && (this.text || 1 == this.data.is_scan_code && 0 == this.data.is_disabled) && (t += "margin-bottom: 12px")), 
                        1 == this.data.is_scan_code && 0 == this.data.is_disabled && "text" !== this.mode && (t += "padding-right: 65rpx;"), 
                        t;
                    },
                    placeholderStyle: function() {
                        return "color:".concat(this.data.placeholder_color, ";");
                    },
                    itemStyle: function() {
                        var t = "", e = 3 == this.data.style && "text" == this.mode ? 12 : 6;
                        return (3 == this.data.style && "text" == this.mode || 1 != this.data.style && "text" != this.mode) && (t += "background-color:".concat(this.data.fill_color, ";border-radius:").concat(this.data.radius, "rpx;padding: ").concat(e, "rpx 0;"), 
                        this.data.border_color && (t += "border: 2rpx solid ".concat(this.data.border_color, ";"))), 
                        1 == this.data.style && "text" === this.mode && (t += "border-bottom: 1px solid ".concat(this.data.border_color)), 
                        t;
                    }
                },
                created: function() {
                    if (this.data = this.value, this.max = 10 * this.data.max, this.data.default) {
                        this.text = this.data.default, this.number = 0;
                        var t, e = u(this.text);
                        try {
                            for (e.s(); !(t = e.n()).done; ) t.value, this.number++;
                        } catch (t) {
                            e.e(t);
                        } finally {
                            e.f();
                        }
                        var a = this.text;
                        "input" == this.mode && (a = {
                            text: this.text,
                            type: this.data.mode
                        }, 1 == this.data.mode && (a.allow = this.data.allow)), this.$emit("updateValue", {
                            index: this.index,
                            value: a
                        });
                    }
                },
                methods: {
                    getCode: function() {
                        var e = this;
                        t.scanCode({
                            success: function(t) {
                                e.text = t.result, e.cancelIndex();
                            }
                        });
                    },
                    getIndex: function() {
                        this.$storage.setStorageSync("input", this.index);
                    },
                    cancelIndex: function() {
                        this.checkInput(this.text), this.$storage.removeStorageSync("input");
                    },
                    cancelFocus: function() {
                        var e = this.$storage.getStorageSync("index");
                        e != this.index && t.hideKeyboard(), console.log(e, this.index);
                    },
                    getChooseLocation: function() {
                        var e = c(f.default.mark(function e() {
                            var a, n, i, o, s, d, c, u, h, l;
                            return f.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if ("position" == (a = this).mode) {
                                        e.next = 3;
                                        break;
                                    }
                                    return e.abrupt("return", !1);

                                  case 3:
                                    return e.next = 5, t.chooseLocation();

                                  case 5:
                                    if (n = e.sent, i = r(n, 2), o = i[0], !(s = i[1])) {
                                        e.next = 26;
                                        break;
                                    }
                                    if ("我的位置" != s.name && "我的位置" != s.address && "" != s.address) {
                                        e.next = 13;
                                        break;
                                    }
                                    return t.showToast({
                                        title: "请选择具体位置",
                                        icon: "none"
                                    }), e.abrupt("return", !1);

                                  case 13:
                                    d = "", c = "", u = "", h = s.name, s.address || (s.address = "其他其他其他"), s.address = s.address.replace("北京市北京市", "北京市"), 
                                    s.address = s.address.replace("天津市天津市", "天津市"), s.address = s.address.replace("上海市上海市", "上海市"), 
                                    s.address = s.address.replace("重庆市重庆市", "重庆市"), s.address = s.address.replace("香港特别行政区香港特别行政区", "香港特别行政区"), 
                                    s.address = s.address.replace("澳门特别行政区澳门特别行政区", "澳门特别行政区"), a.text = d == c ? d + " " + u + " " + h : d + " " + c + " " + u + " " + h, 
                                    a.$emit("updateValue", {
                                        index: a.index,
                                        value: {
                                            latitude: s.latitude,
                                            longitude: s.longitude,
                                            text: a.text
                                        }
                                    });

                                  case 26:
                                    o && (l = function() {
                                        t.showModal({
                                            title: "授权权限",
                                            content: "请先授权地理位置权限",
                                            success: function(e) {
                                                e.confirm && t.openSetting({
                                                    success: function(e) {
                                                        e.authSetting["scope.userLocation"] ? t.chooseLocation({
                                                            success: function(t) {
                                                                a.getChooseLocation();
                                                            }
                                                        }) : t.showToast({
                                                            title: "授权失败",
                                                            icon: "none"
                                                        });
                                                    }
                                                });
                                            }
                                        });
                                    }, "chooseLocation:fail auth deny" === o.errMsg && l());

                                  case 27:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    }(),
                    isEmojiCharacter: function(t) {
                        for (var e = 0; e < t.length; e++) {
                            var a = t.charCodeAt(e);
                            if (!(55296 <= a && a <= 56319)) return t.length > 1 ? 8419 == (n = t.charCodeAt(e + 1)) : 8448 <= a && a <= 10239 || 11013 <= a && a <= 11015 || 10548 <= a && a <= 10549 || 12951 <= a && a <= 12953 || 169 == a || 174 == a || 12349 == a || 12336 == a || 11093 == a || 11036 == a || 11035 == a || 11088 == a;
                            if (t.length > 1) {
                                var n = t.charCodeAt(e + 1), r = 1024 * (a - 55296) + (n - 56320) + 65536;
                                return 118784 <= r && r <= 128895;
                            }
                        }
                    },
                    checkInput: function(t) {
                        this.max = 10 * this.data.max, this.number = 0;
                        var a, n = 0, r = !1, i = u(t);
                        try {
                            for (i.s(); !(a = i.n()).done; ) {
                                var o = a.value;
                                this.number++, r = this.isEmojiCharacter(o), this.isEmojiCharacter(o) && n++;
                            }
                        } catch (t) {
                            i.e(t);
                        } finally {
                            i.f();
                        }
                        (this.number == this.data.max || this.number > this.data.max) && (this.max = r ? e.detail.value.length : +this.data.max + +n);
                        var s = t.toString();
                        this.text = s;
                        var d = {
                            text: this.text,
                            type: this.data.mode
                        };
                        return 1 == this.data.mode && (d.allow = this.data.allow), this.data.default = this.text, 
                        this.$emit("updateValue", {
                            index: this.index,
                            value: d
                        }), s;
                    },
                    textInput: function() {
                        var t = this.text;
                        this.max = 10 * this.data.max, this.number = 0;
                        var e, a = 0, n = !1, r = u(t);
                        try {
                            for (r.s(); !(e = r.n()).done; ) {
                                var i = e.value;
                                this.number++, n = this.isEmojiCharacter(i), this.isEmojiCharacter(i) && a++;
                            }
                        } catch (t) {
                            r.e(t);
                        } finally {
                            r.f();
                        }
                        (this.number == this.data.max || this.number > this.data.max) && (this.max = n ? t.length : +this.data.max + +a, 
                        this.number = this.data.max), this.data.default = this.text, this.$emit("updateValue", {
                            index: this.index,
                            value: this.text
                        });
                    }
                }
            };
            a.default = p;
        }).call(this, n("543d").default);
    },
    aaa0: function(t, e, a) {},
    dfa0: function(t, e, a) {
        a.r(e);
        var n = a("7e64"), r = a.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(i);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-input-create-component", {
    "components/page-component/diy-form/diy-form-input-create-component": function(t, e, a) {
        a("543d").createComponent(a("6382"));
    }
}, [ [ "components/page-component/diy-form/diy-form-input-create-component" ] ] ]);