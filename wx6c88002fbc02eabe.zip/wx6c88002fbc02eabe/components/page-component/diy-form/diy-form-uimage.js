(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form-uimage" ], {
    "015f": function(e, t, n) {},
    "28b3": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__get_style([ e.boxStyle ])), n = "ordinary" === e.data.type ? e.__get_style([ e.uploadStyle ]) : null, r = "idcard" === e.data.type ? e.__get_style([ e.uploadStyle ]) : null, a = "idcard" === e.data.type ? e.__get_style([ e.uploadStyle ]) : null, o = "license" === e.data.type ? e.__get_style([ e.uploadStyle ]) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t,
                    s1: n,
                    s2: r,
                    s3: a,
                    s4: o
                }
            });
        }, a = [];
    },
    3520: function(e, t, n) {
        n.r(t);
        var r = n("28b3"), a = n("652c");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        n("4a50");
        var i = n("f0c5"), c = Object(i.a)(a.default, r.b, r.c, !1, null, "cdfc9da4", null, !1, r.a, void 0);
        t.default = c.exports;
    },
    "4a50": function(e, t, n) {
        var r = n("015f");
        n.n(r).a;
    },
    "652c": function(e, t, n) {
        n.r(t);
        var r = n("fb6b"), a = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = a.a;
    },
    fb6b: function(e, t, n) {
        (function(e) {
            function r(e) {
                return c(e) || i(e) || o(e) || a();
            }
            function a() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function o(e, t) {
                if (e) {
                    if ("string" == typeof e) return u(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0;
                }
            }
            function i(e) {
                if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
            }
            function c(e) {
                if (Array.isArray(e)) return u(e);
            }
            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        f(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function f(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var d = n("2f62");
            !function(e) {
                e && e.__esModule;
            }(n("d5ea"));
            var p = {
                name: "diy-form-uimage",
                props: {
                    index: [ Number, String ],
                    value: {
                        type: Object
                    }
                },
                computed: s(s({}, (0, d.mapState)({
                    appImg: function(e) {
                        return e.mallConfig.plugin.diy.app_image;
                    }
                })), {}, {
                    boxStyle: function() {
                        var e = this.data, t = e.bg_color, n = e.box_padding;
                        return {
                            backgroundColor: t,
                            padding: "20rpx ".concat(n, "rpx")
                        };
                    },
                    uploadStyle: function() {
                        var e = this.data, t = e.border_color, n = e.pd_color, r = e.type, a = {
                            borderWidth: "1px",
                            borderStyle: "solid",
                            borderColor: t || n,
                            backgroundColor: n,
                            borderRadius: "12rpx"
                        };
                        return "ordinary" === r && Object.assign(a, {
                            padding: "16rpx 44rpx 0 3rpx"
                        }), a;
                    }
                }),
                data: function() {
                    return {
                        imageList: [],
                        data: null
                    };
                },
                created: function() {
                    this.data = this.value;
                },
                methods: {
                    validateRules: function() {
                        var e = this.data, t = e.min_num, n = e.max_num, r = e.is_required, a = this.imageList;
                        if (0 == r) return !0;
                        if (a < t) throw new Error("最少上传".concat(t, "张图片"));
                        if (a > n) throw new Error("最多上传${max_num}张图片");
                        return !0;
                    },
                    previewImage: function(t) {
                        var n = this.imageList;
                        e.previewImage({
                            current: n[t],
                            urls: n
                        });
                    },
                    imageEvent: function() {
                        this.$emit("updateValue", {
                            index: this.index,
                            value: this.imageList
                        });
                    },
                    delImage: function(e) {
                        this.imageList.splice(e, 1), this.imageEvent();
                    },
                    chooseImage: function(t) {
                        var n = this, a = n.imageList;
                        e.chooseImage({
                            count: "ordinary" === n.data.type ? Number(n.data.max_num) - a.length : 1,
                            success: function(a) {
                                for (var o in a.tempFilePaths) {
                                    e.uploadFile({
                                        url: n.$api.upload.file,
                                        filePath: a.tempFilePaths[o],
                                        name: "file",
                                        fileType: "image",
                                        formData: {
                                            file: a.tempFilePaths[o],
                                            file_name: ""
                                        },
                                        success: function(a) {
                                            var o = a.data, i = null;
                                            if (0 == (i = "string" == typeof o ? JSON.parse(o) : o).code) {
                                                var c, u = t > n.imageList.length ? t - n.imageList.length : 0, l = new Array(u).concat(i.data.url);
                                                (c = n.imageList).splice.apply(c, [ t, n.imageList.hasOwnProperty(t) ? 1 : 0 ].concat(r(l))), 
                                                n.imageEvent();
                                            } else e.showModal({
                                                title: "",
                                                content: i.msg,
                                                showCancel: !1
                                            });
                                        },
                                        fail: function(t) {
                                            t && t.errMsg && e.showModal({
                                                title: "错误",
                                                content: t.errMsg,
                                                showCancel: !1
                                            });
                                        }
                                    });
                                }
                            },
                            complete: function(e) {
                                n.imageEvent();
                            }
                        });
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-uimage-create-component", {
    "components/page-component/diy-form/diy-form-uimage-create-component": function(e, t, n) {
        n("543d").createComponent(n("3520"));
    }
}, [ [ "components/page-component/diy-form/diy-form-uimage-create-component" ] ] ]);