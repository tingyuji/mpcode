(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form-uvideo" ], {
    "1eda": function(e, t, n) {},
    5933: function(e, t, n) {
        (function(e) {
            function o(e) {
                return c(e) || a(e) || i(e) || r();
            }
            function r() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function i(e, t) {
                if (e) {
                    if ("string" == typeof e) return u(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0;
                }
            }
            function a(e) {
                if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
            }
            function c(e) {
                if (Array.isArray(e)) return u(e);
            }
            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, o = new Array(t); n < t; n++) o[n] = e[n];
                return o;
            }
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        f(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function f(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = n("2f62"), p = {
                name: "diy-form-uvideo",
                props: {
                    index: [ Number, String ],
                    value: {
                        type: Object
                    }
                },
                computed: d(d({}, (0, s.mapState)({
                    appImg: function(e) {
                        return e.mallConfig.plugin.diy.app_image;
                    }
                })), {}, {
                    boxStyle: function() {
                        var e = this.data, t = e.bg_color, n = e.box_padding;
                        return {
                            backgroundColor: t,
                            padding: "20rpx ".concat(n, "rpx")
                        };
                    },
                    uploadStyle: function() {
                        var e = this.data, t = e.border_color, n = e.pd_color;
                        return {
                            borderWidth: "1px",
                            borderStyle: "solid",
                            borderColor: t || n,
                            backgroundColor: n,
                            borderRadius: "12rpx",
                            padding: "16rpx 44rpx 0 3rpx"
                        };
                    }
                }),
                data: function() {
                    return {
                        videoList: [],
                        data: null
                    };
                },
                created: function() {
                    this.data = this.value;
                },
                methods: {
                    playVideo: function(e) {
                        this.$emit("show", {
                            video: e
                        });
                    },
                    validateRules: function() {
                        var e = this.data, t = e.min_num, n = e.max_num, o = e.is_required, r = this.videoList;
                        if (0 == o) return !0;
                        if (r < t) throw new Error("最少上传".concat(t, "张视频"));
                        if (r > n) throw new Error("最多上传${max_num}张视频");
                        return !0;
                    },
                    videoEvent: function() {
                        this.$emit("updateValue", {
                            index: this.index,
                            value: this.videoList
                        });
                    },
                    delImage: function(e) {
                        this.videoList.splice(e, 1), this.videoEvent();
                    },
                    chooseImage: function(t) {
                        var n = this;
                        n.videoList, e.chooseVideo({
                            count: 1,
                            success: function(r) {
                                console.log(r);
                                e.uploadFile({
                                    url: n.$api.upload.file,
                                    filePath: r.tempFilePath,
                                    name: "file",
                                    fileType: "mp4",
                                    formData: {
                                        file: r.tempFilePath,
                                        file_name: ""
                                    },
                                    success: function(r) {
                                        var i = r.data, a = null;
                                        if (0 == (a = "string" == typeof i ? JSON.parse(i) : i).code) {
                                            var c, u = t > n.videoList.length ? t - n.videoList.length : 0, l = new Array(u).concat(a.data.url);
                                            (c = n.videoList).splice.apply(c, [ t, n.videoList[t] ? 1 : 0 ].concat(o(l))), n.videoEvent();
                                        } else e.showModal({
                                            title: "",
                                            content: a.msg,
                                            showCancel: !1
                                        });
                                    },
                                    fail: function(t) {
                                        t && t.errMsg && e.showModal({
                                            title: "错误",
                                            content: t.errMsg,
                                            showCancel: !1
                                        });
                                    }
                                });
                            },
                            complete: function(e) {
                                n.videoEvent();
                            }
                        });
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    6018: function(e, t, n) {
        n.r(t);
        var o = n("fac6"), r = n("b880");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        n("eae1");
        var a = n("f0c5"), c = Object(a.a)(r.default, o.b, o.c, !1, null, "7d25c9a4", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    b880: function(e, t, n) {
        n.r(t);
        var o = n("5933"), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = r.a;
    },
    eae1: function(e, t, n) {
        var o = n("1eda");
        n.n(o).a;
    },
    fac6: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__get_style([ e.boxStyle ])), n = e.__get_style([ e.uploadStyle ]);
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t,
                    s1: n
                }
            });
        }, r = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-uvideo-create-component", {
    "components/page-component/diy-form/diy-form-uvideo-create-component": function(e, t, n) {
        n("543d").createComponent(n("6018"));
    }
}, [ [ "components/page-component/diy-form/diy-form-uvideo-create-component" ] ] ]);