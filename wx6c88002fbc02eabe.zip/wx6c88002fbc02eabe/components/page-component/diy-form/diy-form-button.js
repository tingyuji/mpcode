(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/diy-form/diy-form-button" ], {
    "0f88": function(t, e, a) {},
    "45c1": function(t, e, a) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(a("dc83")), n = {
                name: "diy-form-button",
                props: {
                    value: {
                        type: Object
                    },
                    error: String,
                    template_message_list: Array,
                    otherForm: Array,
                    hideIds: Array,
                    formId: [ Number, String ],
                    pageId: [ Number, String ],
                    h_ids: Array
                },
                components: {
                    appModel: function() {
                        a.e("components/basic-component/app-model/app-model").then(function() {
                            return resolve(a("cf2f"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    appCalendarAttr: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/page-component/diy-form/app-calendar-attr") ]).then(function() {
                            return resolve(a("6242"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        secondModel: !1,
                        limitModel: !1,
                        limitText: null,
                        updateModel: !1,
                        clickSubmit: !1,
                        tempOtherForm: this.otherForm,
                        pay_select_index: 0,
                        temp_pay_price: "",
                        pay_price: "",
                        data: {},
                        chen: 1,
                        pay_num: 1,
                        has_limit_max_stock: 0,
                        maxStock: 0,
                        calendarModel: !1,
                        button_attr_name: "",
                        hasFlush: !1,
                        paramsConfig: {
                            date_list: [],
                            time: "",
                            title: ""
                        },
                        advancePrice: 0
                    };
                },
                created: function() {
                    var t = this.value, e = t.pay_price_list, a = (t.mode, t.has_limit_stock_num);
                    this.has_limit_max_stock = a, this.maxStock = e[this.pay_select_index].stock_num, 
                    this.data = this.value;
                },
                watch: {
                    otherForm: {
                        handler: function(t) {
                            this.tempOtherForm = t || [];
                            var e = this.data, a = e.has_calendar, i = e.calendar_key;
                            if (1 == a) {
                                for (var n = 1, o = 0; o < this.tempOtherForm.length; o++) {
                                    var s = this.tempOtherForm[o], r = s.key, c = s.value;
                                    if ("calendar" === r && c && c.s.key === i && c.after && c.before && 0 == c.s.is_alone) {
                                        n = 0 == c.s.has_kuatian ? c.data.length : c.data.length - 1;
                                        break;
                                    }
                                }
                                this.chen = n;
                            }
                            console.warn("表单数据刷新=>", this.tempOtherForm);
                        },
                        immediate: !0,
                        deep: !0
                    }
                },
                methods: {
                    openImg: function(e) {
                        t.previewImage({
                            urls: [ e ]
                        });
                    },
                    submitAttr: function(t) {
                        this.button_attr_name = t.title, this.advancePrice = t.price, this.maxStock = t.stock;
                        var e = t[t.advance_type];
                        if ("calendar" === t.advance_type) {
                            var a = e.data, i = e.fullDate;
                            this.paramsConfig = {
                                title: t.title,
                                date_list: i ? [ i ] : a,
                                time: ""
                            };
                        }
                        if ("calendar_and_time" === t.advance_type) {
                            var n = e.time, o = e.date;
                            this.paramsConfig = {
                                title: t.title,
                                date_list: [ o ],
                                time: n
                            };
                        }
                        "time" === t.advance_type && (e.time, this.paramsConfig = {
                            title: t.title,
                            date_list: [],
                            time: e
                        }), console.log(this.paramsConfig);
                    },
                    openForm: function() {
                        this.calendarModel = !0;
                    },
                    FloatMul: function(t, e) {
                        if (!t || !e) return 0;
                        var a = 0, i = t.toString(), n = e.toString();
                        try {
                            a += i.split(".")[1].length;
                        } catch (t) {}
                        try {
                            a += n.split(".")[1].length;
                        } catch (t) {}
                        var o = Number(i.replace(".", "")) * Number(n.replace(".", "")) / Math.pow(10, a);
                        return Number(o.toString().match(/^\d+(?:\.\d{0,2})?/));
                    },
                    toExchange: function() {
                        var e = this.data.goods, a = [ {
                            mch_id: 0,
                            goods_list: [ {
                                id: e.id,
                                attr: e.attrs,
                                num: 1,
                                cat_id: 0,
                                goods_attr_id: e.attr_id
                            } ]
                        } ], i = "/pages/order-submit/order-submit?mch_list=".concat(JSON.stringify(a));
                        i += "&preview_url=".concat(encodeURIComponent(this.$api.diy.order_preview), "&submit_url=").concat(encodeURIComponent(this.$api.diy.order_submit), "&plugin=diy"), 
                        t.navigateTo({
                            url: i
                        });
                    },
                    changeInput: function(e) {
                        var a = this;
                        this.$nextTick(function() {
                            e.target.value < 1 ? a.pay_num = 1 : e.target.value > a.maxStock && 0 == a.has_limit_max_stock && (a.pay_num = a.maxStock || 1, 
                            t.showToast({
                                title: "库存不足",
                                icon: "none"
                            }));
                        });
                    },
                    changeLess: function() {
                        this.pay_num = this.pay_num > 1 ? --this.pay_num : 1;
                    },
                    changeAdd: function() {
                        this.pay_num >= this.maxStock && 0 == this.has_limit_max_stock ? (this.pay_num = this.maxStock || 1, 
                        t.showToast({
                            title: "库存不足",
                            icon: "none"
                        })) : this.pay_num = ++this.pay_num;
                    },
                    choosePay: function(t, e) {
                        this.maxStock = t.stock_num, this.pay_num = 1, "advance" === this.data.mode ? (this.pay_select_index == e ? this.hasFlush = !1 : (this.hasFlush = !0, 
                        this.paramsConfig = {
                            title: "",
                            date_list: [],
                            time: ""
                        }, this.pay_select_index = e), this.calendarModel = !0) : this.pay_select_index = e;
                    },
                    validSubmit: function() {
                        if (this.error) return t.showToast({
                            title: this.error,
                            icon: "none"
                        }), !1;
                        "advance" !== this.data.mode || this.paramsConfig.title || 1 != this.data.is_pay ? 1 == this.data.before_status ? this.secondModel = !0 : this.afterSubmit() : t.showToast({
                            title: "calendar" === this.data.advance_type ? "请选择日期" : "请选择时间",
                            icon: "none"
                        });
                    },
                    afterSubmit: function() {
                        var t = this;
                        if (this.clickSubmit) return !1;
                        this.clickSubmit = !0, this.$subscribe(this.template_message_list).then(function(e) {
                            t.handleSubmit();
                        }).catch(function() {
                            t.handleSubmit();
                        });
                    },
                    getValue: function() {
                        var e, a, i, n = this.data.pay_price_list[this.pay_select_index];
                        if (n) {
                            e = n.title, i = n.key, a = 1 == this.data.pay_price_list.length ? this.pay_price || this.data.pay_price_list[0].pay_price : n.pay_price;
                            var o = {}, s = this.paramsConfig, r = s.date_list, c = s.time;
                            return o.date_list = r, o.time = c, o.mode = this.data.mode, o.title = e, o.pay_price = a, 
                            o.attr_key = i, o.num = this.pay_num, o.is_pay = this.data.is_pay, o.after_send_status = this.data.after_send_status, 
                            o.after_send = {
                                after_send_plugin: this.data.after_send_plugin,
                                after_send_lottery_limit: this.data.after_send_lottery_limit,
                                after_send_price: this.data.after_send_price,
                                after_send_integral: this.data.after_send_integral,
                                after_send_member_name: this.data.after_send_member_name,
                                after_send_coupon: this.data.after_send_coupon,
                                after_send_card: this.data.after_send_card
                            }, o;
                        }
                        t.showToast({
                            title: "请选择",
                            icon: "none"
                        });
                    },
                    handleSubmit: function() {
                        var e = this;
                        t.showLoading({
                            mask: !0
                        }), this.secondModel = !1;
                        var a = [].concat(this.tempOtherForm.filter(function(t) {
                            return !(!e.h_ids.includes(t.unique) || !t.value) || -1 === e.hideIds.indexOf(t.unique);
                        }), new i.default({
                            key: "button",
                            label: this.data.title,
                            value: this.getValue(),
                            required: 0
                        }).getObject()), n = {
                            form_list_id: this.formId,
                            page_id: this.pageId,
                            form_data: JSON.stringify(a)
                        };
                        1 == this.data.is_pay && (n.new_price = this.pay_price || 0, n.new_index = this.pay_select_index), 
                        this.$request({
                            url: this.$api.diy.new_form,
                            data: n,
                            method: "POST"
                        }).then(function(a) {
                            if (t.hideLoading(), e.clickSubmit = !1, 0 === a.code) if (1 == a.data.is_pay) {
                                var i = e.data;
                                if ("basic" === i.mode && 0 == i.has_limit_stock_num && i.pay_price_list[e.pay_select_index] && 0 == i.pay_price_list[e.pay_select_index].stock_num) return t.showToast({
                                    title: "库存不足",
                                    icon: "none"
                                });
                                e.toExchange();
                            } else e.$emit("click", !0), e.getPayOrderId(a.data.queue_id, a.data.token); else e.limitText = a.msg, 
                            e.limitModel = !0;
                        }).catch(function(a) {
                            e.clickSubmit = !1, t.hideLoading();
                        });
                    },
                    getPayOrderId: function(e, a) {
                        var i = this;
                        t.showLoading({
                            mask: !0
                        }), this.$request({
                            url: this.$api.diy.order_pay,
                            method: "post",
                            data: {
                                queue_id: e,
                                token: a
                            }
                        }).then(function(n) {
                            0 === n.code ? n.data.retry && 1 === n.data.retry ? i.getPayDataTimer = setTimeout(function() {
                                i.getPayOrderId(e, a);
                            }, 1e3) : (t.hideLoading(), t.navigateTo({
                                url: "/plugins/diy/detail/form-success?form_id=" + n.data.form_id
                            })) : (i.submitLock = !1, t.hideLoading(), t.showModal({
                                title: "提示",
                                content: n.msg,
                                showCancel: !1
                            }));
                        }).catch(function(e) {
                            i.submitLock = !1, t.hideLoading(), t.showModal({
                                title: "提示",
                                content: e.errMsg,
                                showCancel: !1
                            });
                        });
                    },
                    onPay: function(e, a) {
                        var i = this;
                        this.$payment.pay(e).then(function(e) {
                            i.$emit("click", !0), t.navigateTo({
                                url: "/plugins/diy/detail/form-success?form_id=" + a
                            });
                        }).catch(function(t) {
                            console.log(e), i.cancel(e);
                        });
                    },
                    cancel: function(e) {
                        t.showLoading({
                            mask: !0
                        }), this.$request({
                            url: this.$api.diy.cancel,
                            data: {
                                pay_id: e
                            },
                            method: "post"
                        }).then(function(e) {
                            t.hideLoading(), 0 === e.code ? t.navigateTo({
                                url: "/plugins/diy/detail/form-success?is_error=1"
                            }) : t.showToast({
                                title: e.msg,
                                icon: "none",
                                duration: 1e3
                            });
                        }).catch(function() {
                            t.hideLoading();
                        });
                    },
                    stopClick: function() {},
                    openUpdate: function() {
                        this.temp_pay_price = this.pay_price || this.data.pay_price_list[0].user_member_price, 
                        this.updateModel = !0;
                    },
                    money: function(t) {
                        var e = t.toString();
                        return 0 == e.indexOf(".") && (e = "0" + e), e = e.replace(/[^\d.]/g, ""), e = e.replace(/\.{2,}/g, "."), 
                        e = e.replace(".", "$#$").replace(/\./g, "").replace("$#$", "."), (e = e.replace(/^(\-)*(\d+)\.(\d\d).*$/, "$1$2.$3")).indexOf(".") < 0 && "" != e && (e = parseFloat(e)), 
                        +e;
                    },
                    submitUpdate: function() {
                        this.temp_pay_price > 0 ? this.temp_pay_price > 9999999 ? this.pay_price = 9999999 : this.pay_price = this.money(this.temp_pay_price) : t.showToast({
                            title: "价格需大于0",
                            icon: "none"
                        });
                    }
                }
            };
            e.default = n;
        }).call(this, a("543d").default);
    },
    4696: function(t, e, a) {
        a.r(e);
        var i = a("45c1"), n = a.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = n.a;
    },
    "7f39": function(t, e, a) {
        var i = a("0f88");
        a.n(i).a;
    },
    8584: function(t, e, a) {
        a.r(e);
        var i = a("f5b6"), n = a("4696");
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(o);
        a("7f39");
        var s = a("f0c5"), r = Object(s.a)(n.default, i.b, i.c, !1, null, "6d37dd6a", null, !1, i.a, void 0);
        e.default = r.exports;
    },
    f5b6: function(t, e, a) {
        a.d(e, "b", function() {
            return i;
        }), a.d(e, "c", function() {
            return n;
        }), a.d(e, "a", function() {});
        var i = function() {
            var t = this, e = (t.$createElement, t._self._c, 1 == t.data.is_pay && ("basic" === t.data.mode || t.pay_select_index >= 0) && "basic" === t.data.mode ? t.FloatMul(t.pay_num * t.chen, t.pay_price || t.data.pay_price_list[t.pay_select_index].user_member_price) : null), a = 1 == t.data.is_pay && ("basic" === t.data.mode || t.pay_select_index >= 0) && "basic" === t.data.mode && 0 != e ? t.FloatMul(t.pay_num * t.chen, t.pay_price || t.data.pay_price_list[t.pay_select_index].user_member_price) : null, i = 1 == t.data.is_pay && ("basic" === t.data.mode || t.pay_select_index >= 0) && "basic" !== t.data.mode && t.paramsConfig.title ? t.FloatMul(t.pay_num, t.advancePrice) : null, n = 1 == t.data.is_pay && ("basic" === t.data.mode || t.pay_select_index >= 0) && "basic" !== t.data.mode && t.paramsConfig.title && 0 != i ? t.FloatMul(t.pay_num, t.advancePrice) : null;
            t._isMounted || (t.e0 = function(e) {
                t.updateModel = !1;
            }, t.e1 = function(e) {
                t.limitModel = !1;
            }, t.e2 = function(e) {
                t.secondModel = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    m1: a,
                    m2: i,
                    m3: n
                }
            });
        }, n = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/diy-form/diy-form-button-create-component", {
    "components/page-component/diy-form/diy-form-button-create-component": function(t, e, a) {
        a("543d").createComponent(a("8584"));
    }
}, [ [ "components/page-component/diy-form/diy-form-button-create-component" ] ] ]);