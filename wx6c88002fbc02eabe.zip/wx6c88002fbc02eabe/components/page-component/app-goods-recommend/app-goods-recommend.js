(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-goods-recommend/app-goods-recommend" ], {
    "3a50": function(e, t, n) {
        function o(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                t && (o = o.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function r(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = n("2f62"), a = {
            name: "app-goods-recommend",
            components: {
                appGoods: function() {
                    n.e("components/basic-component/app-goods/app-goods").then(function() {
                        return resolve(n("ad05"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            props: {
                commentStyle: {
                    type: Object,
                    default: function() {
                        return {
                            pic_url: "../../../static/image/icon/icon-favorite.png",
                            text_color: "#999",
                            text: "您或许喜欢",
                            list_style: 2
                        };
                    }
                },
                goodsList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                theme: Object,
                sureCart: Boolean,
                showSales: Boolean,
                showBuyBtn: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                showUnderlinePrice: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                newList: Boolean,
                activity: Object,
                onlyShowTitle: Boolean,
                is_show_member: {
                    type: Boolean,
                    default: function() {
                        return !0;
                    }
                },
                sign: String,
                detail: Object
            },
            methods: {
                cartResult: function() {
                    this.$emit("cart", !0);
                },
                cartShow: function(e) {
                    this.$emit("show", e);
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(n), !0).forEach(function(t) {
                        r(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, (0, c.mapState)({
                isListUnderlinePrice: function(e) {
                    return e.mallConfig.mall.setting.is_list_underline_price;
                },
                goodsImg: function(e) {
                    return e.mallConfig.__wxapp_img.goods;
                }
            }))
        };
        t.default = a;
    },
    "80e1": function(e, t, n) {
        n.r(t);
        var o = n("3a50"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = r.a;
    },
    "8e97": function(e, t, n) {
        n.r(t);
        var o = n("c9c0"), r = n("80e1");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("f64e");
        var a = n("f0c5"), i = Object(a.a)(r.default, o.b, o.c, !1, null, "13244375", null, !1, o.a, void 0);
        t.default = i.exports;
    },
    "8f80": function(e, t, n) {},
    c9c0: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, parseInt(e.commentStyle ? e.commentStyle.list_style : 2)), n = parseInt(e.commentStyle ? e.commentStyle.list_style : 2);
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: n
                }
            });
        }, r = [];
    },
    f64e: function(e, t, n) {
        var o = n("8f80");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-goods-recommend/app-goods-recommend-create-component", {
    "components/page-component/app-goods-recommend/app-goods-recommend-create-component": function(e, t, n) {
        n("543d").createComponent(n("8e97"));
    }
}, [ [ "components/page-component/app-goods-recommend/app-goods-recommend-create-component" ] ] ]);