(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/u-goods-list/u-new-price" ], {
    "11f8": function(e, t, n) {
        function r(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function o(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? r(Object(n), !0).forEach(function(t) {
                    i(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function i(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = n("2f62"), a = {
            name: "u-new-price",
            props: {
                listStyle: [ Number, String ],
                priceContent: String,
                isNegotiable: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {};
            },
            computed: o(o({}, (0, c.mapState)({
                negotiable_text: function(e) {
                    return e.mallConfig.mall.setting.negotiable_text;
                },
                integralCustomer: function(e) {
                    return e.mallConfig.mall.setting.integral_customer;
                }
            })), {}, {
                isIntegral: function() {
                    return this.priceContent.indexOf(this.integralCustomer) > -1;
                },
                isPriceFree: function() {
                    var e = new RegExp("\\S" + this.integralCustomer);
                    return "免费" === this.priceContent || this.priceContent === this.negotiable_text || e.test(this.priceContent);
                },
                priceLabel: function() {
                    return /^￥\d/.test(this.priceContent) ? "￥" : "";
                },
                priceInt: function() {
                    var e = this.priceContent.match(/(\d+)(.\d*)?$/);
                    return e ? e[1] : "";
                },
                priceFloat: function() {
                    var e = this.priceContent.match(/(\d+)(.\d*)?$/);
                    return e && e[2] && "." !== e[2] ? e[2] : "";
                }
            })
        };
        t.default = a;
    },
    "27b1": function(e, t, n) {
        n.r(t);
        var r = n("11f8"), o = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = o.a;
    },
    "3f1f": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    6152: function(e, t, n) {},
    "6d0a": function(e, t, n) {
        var r = n("6152");
        n.n(r).a;
    },
    f901: function(e, t, n) {
        n.r(t);
        var r = n("3f1f"), o = n("27b1");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("6d0a");
        var c = n("f0c5"), a = Object(c.a)(o.default, r.b, r.c, !1, null, "6f13eaed", null, !1, r.a, void 0);
        t.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/u-goods-list/u-new-price-create-component", {
    "components/page-component/u-goods-list/u-new-price-create-component": function(e, t, n) {
        n("543d").createComponent(n("f901"));
    }
}, [ [ "components/page-component/u-goods-list/u-new-price-create-component" ] ] ]);