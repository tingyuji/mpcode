(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-shop/app-shop" ], {
    2191: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                name: "app-shop",
                props: {
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    navPicUrl: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    scorePicUrl: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    showName: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    showScore: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    showTel: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    showNav: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    scrollTop: {
                        type: Number,
                        default: function() {
                            return 0;
                        }
                    },
                    value: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    paddingX: {
                        type: Number,
                        default: function() {
                            return 24;
                        }
                    },
                    paddingY: {
                        type: Number,
                        default: function() {
                            return 20;
                        }
                    }
                },
                data: function() {
                    return {
                        height: 0,
                        request: !0
                    };
                },
                created: function() {
                    var t = this;
                    n.getSystemInfo({
                        success: function(n) {
                            t.height = n.windowHeight;
                        }
                    });
                },
                methods: {
                    autoEnd: function() {
                        var n = this;
                        this.$lazyLoadingData("app-shop").then(function(t) {
                            t[0].height + t[0].top < n.height && (n.request = !1, n.$emit("input", n.request));
                        });
                    }
                },
                watch: {
                    scrollTop: {
                        handler: function(n, t) {
                            n > t && this.request && this.autoEnd();
                        }
                    }
                },
                computed: {
                    carCount: function() {
                        return function(n) {
                            return new Array(n.score);
                        };
                    },
                    newList: function() {
                        return this.list ? (this.list.forEach(function(n) {
                            n.score instanceof Array || (n.score = new Array(n.score));
                        }), this.list) : [];
                    }
                }
            };
            t.default = e;
        }).call(this, e("543d").default);
    },
    "400c": function(n, t, e) {
        e.r(t);
        var o = e("8e9f"), a = e("dad3");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(u);
        e("460a");
        var r = e("f0c5"), c = Object(r.a)(a.default, o.b, o.c, !1, null, "736f9f4a", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "460a": function(n, t, e) {
        var o = e("d003");
        e.n(o).a;
    },
    "8e9f": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    d003: function(n, t, e) {},
    dad3: function(n, t, e) {
        e.r(t);
        var o = e("2191"), a = e.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        t.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-shop/app-shop-create-component", {
    "components/page-component/app-shop/app-shop-create-component": function(n, t, e) {
        e("543d").createComponent(e("400c"));
    }
}, [ [ "components/page-component/app-shop/app-shop-create-component" ] ] ]);