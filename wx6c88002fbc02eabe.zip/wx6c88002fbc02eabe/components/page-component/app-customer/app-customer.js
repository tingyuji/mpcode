(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-customer/app-customer" ], {
    3785: function(t, o, e) {
        e.r(o);
        var r = e("4ff6"), n = e.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(o, t, function() {
                return r[t];
            });
        }(c);
        o.default = n.a;
    },
    "4ce4": function(t, o, e) {},
    "4ff6": function(t, o, e) {
        (function(t) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var e = {
                name: "app-customer",
                props: {
                    bg: String,
                    bgPadding: [ String, Number ],
                    title: String,
                    titleColor: String,
                    wechat: Array,
                    wechatColor: String,
                    cBorderBottom: [ String, Number ],
                    cBorderTop: [ String, Number ],
                    cPaddingTop: [ String, Number ],
                    cPaddingLr: [ String, Number ],
                    cPaddingBottom: [ String, Number ],
                    copyBg: String,
                    copyBorder: String,
                    copyColor: String,
                    copyRadius: [ String, Number ],
                    copyTitle: String,
                    saveBg: String,
                    saveBorder: String,
                    saveColor: String,
                    saveRadius: [ String, Number ],
                    saveTitle: String,
                    twoIcon: String,
                    twoBg: String,
                    twoBorder: String,
                    twoColor: String,
                    twoRadius: [ String, Number ],
                    twoTitle: String,
                    subTitle: String,
                    subTitleColor: String,
                    selectStyle: [ Number, String ]
                },
                computed: {
                    we: function() {
                        var t = this.wechat;
                        return t && t.length ? t[parseInt(Math.random() * t.length)] : {
                            qrcode: "",
                            name: ""
                        };
                    },
                    styleA: function() {
                        var t = this.bgPadding, o = this.cPaddingTop, e = this.cPaddingLr, r = this.cPaddingBottom;
                        return {
                            backgroundColor: t,
                            padding: "".concat(o, "rpx ").concat(e, "rpx ").concat(r, "rpx")
                        };
                    },
                    styleB: function() {
                        var t = this.bg, o = this.cBorderTop, e = this.cBorderBottom;
                        return {
                            backgroundColor: "".concat(t),
                            borderTopLeftRadius: "".concat(o, "rpx"),
                            borderTopRightRadius: "".concat(o, "rpx"),
                            borderBottomLeftRadius: "".concat(e, "rpx"),
                            borderBottomRightRadius: "".concat(e, "rpx")
                        };
                    },
                    styleC: function() {
                        var t = this.copyBg, o = this.copyBorder, e = this.copyColor, r = this.copyRadius;
                        return {
                            backgroundColor: t,
                            borderColor: o || t,
                            color: e,
                            borderRadius: r + "rpx"
                        };
                    },
                    styleD: function() {
                        var t = this.saveBg, o = this.saveBorder, e = this.saveColor, r = this.saveRadius;
                        return {
                            backgroundColor: t,
                            borderColor: o || t,
                            color: e,
                            borderRadius: r + "rpx"
                        };
                    },
                    styleE: function() {
                        var t = this.twoBg, o = this.twoBorder, e = this.twoColor, r = this.twoRadius;
                        return {
                            backgroundColor: t,
                            borderColor: o || t,
                            color: e,
                            borderRadius: r + "rpx"
                        };
                    }
                },
                methods: {
                    clickImg: function(o) {
                        t.previewImage({
                            current: 0,
                            urls: [ o ]
                        });
                    },
                    handleCopy: function() {
                        this.$utils.uniCopy({
                            data: this.we.name,
                            success: function() {
                                t.showToast({
                                    title: "复制成功",
                                    icon: "none"
                                });
                            }
                        });
                    },
                    handlerSave: function() {
                        this.$utils.batchSave(this.we.qrcode).then(function() {
                            t.showToast({
                                title: "保存成功"
                            });
                        });
                    }
                }
            };
            o.default = e;
        }).call(this, e("543d").default);
    },
    "69af": function(t, o, e) {
        e.d(o, "b", function() {
            return r;
        }), e.d(o, "c", function() {
            return n;
        }), e.d(o, "a", function() {});
        var r = function() {
            var t = this, o = (t.$createElement, t._self._c, t.__get_style([ t.styleA ])), e = "1" === t.selectStyle ? t.__get_style([ t.styleB ]) : null, r = "1" === t.selectStyle ? t.__get_style([ t.styleD ]) : null, n = "1" === t.selectStyle ? t.__get_style([ t.styleC ]) : null, c = "2" === t.selectStyle ? t.__get_style([ t.styleB ]) : null, i = "2" === t.selectStyle ? t.__get_style([ t.styleE ]) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: o,
                    s1: e,
                    s2: r,
                    s3: n,
                    s4: c,
                    s5: i
                }
            });
        }, n = [];
    },
    b552: function(t, o, e) {
        var r = e("4ce4");
        e.n(r).a;
    },
    ef76: function(t, o, e) {
        e.r(o);
        var r = e("69af"), n = e("3785");
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(o, t, function() {
                return n[t];
            });
        }(c);
        e("b552");
        var i = e("f0c5"), a = Object(i.a)(n.default, r.b, r.c, !1, null, "751def9e", null, !1, r.a, void 0);
        o.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-customer/app-customer-create-component", {
    "components/page-component/app-customer/app-customer-create-component": function(t, o, e) {
        e("543d").createComponent(e("ef76"));
    }
}, [ [ "components/page-component/app-customer/app-customer-create-component" ] ] ]);