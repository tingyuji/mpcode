(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-special-topic/app-special-topic-list" ], {
    "1bf2": function(t, e, n) {
        n.r(e);
        var i = n("830a"), a = n("8fce");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("389a");
        var r = n("f0c5"), c = Object(r.a)(a.default, i.b, i.c, !1, null, "610c443a", null, !1, i.a, void 0);
        e.default = c.exports;
    },
    "389a": function(t, e, n) {
        var i = n("3d9d");
        n.n(i).a;
    },
    "3d9d": function(t, e, n) {},
    "830a": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.dataList, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    m0: t.colorRgba(e.tag.extra_attributes.color)
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, a = [];
    },
    "8fce": function(t, e, n) {
        n.r(e);
        var i = n("d2ba"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    d2ba: function(t, e, n) {
        (function(t) {
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        o(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function o(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n("2f62"), c = {
                props: {
                    catShow: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    topicList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    tagColor: {
                        type: String
                    },
                    catSelectedColor: {
                        type: String
                    },
                    catUnselectedColor: {
                        type: String
                    },
                    catBgColor: {
                        type: String
                    }
                },
                components: {
                    preTopic: function() {
                        n.e("components/page-component/app-special-topic/pre-topic").then(function() {
                            return resolve(n("a7d4"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                computed: a(a({}, (0, r.mapGetters)("mallConfig", {
                    getTheme: "getTheme"
                })), {}, {
                    dataList: function() {
                        var t = this;
                        if (this.catShow) {
                            var e = [];
                            return this.list.forEach(function(n, i) {
                                t.tabCurrentIndex === i && (e = n.children);
                            }), e;
                        }
                        return this.topicList;
                    }
                }),
                data: function() {
                    return {
                        tabCurrentIndex: 0,
                        page: 1,
                        tags: [],
                        search: {
                            keyword: "",
                            tag_id: ""
                        },
                        args: !1,
                        load: !1,
                        scrollLeft: 0,
                        previewItem: null,
                        swiperCurrent: 0,
                        previewStatus: !1
                    };
                },
                onLoad: function(t) {
                    this.$commonLoad.onload(t), this.loadData(), this.getTags();
                },
                methods: {
                    openPre: function(t, e) {
                        this.previewStatus = !0, this.swiperCurrent = e, this.previewItem = t;
                    },
                    tabClick: function(t) {
                        this.tabCurrentIndex = t;
                    },
                    loadData: function() {
                        var e = this;
                        this.page = 1, this.$showLoading({
                            title: "加载中"
                        }), this.$request({
                            url: this.$api.topic.list,
                            data: Object.assign({
                                page: this.page
                            }, this.search)
                        }).then(function(n) {
                            e.$hideLoading(), 0 === n.code ? e.list = n.data.list : t.showToast({
                                title: n.msg,
                                icon: "none"
                            });
                        }).catch(function(t) {
                            e.$hideLoading();
                        });
                    },
                    getTags: function() {
                        var e = this;
                        this.$request({
                            url: this.$api.topic.type
                        }).then(function(n) {
                            if (0 === n.code) {
                                e.tags = n.data.list;
                                var i = e;
                                e.$nextTick(function(e) {
                                    var n = null;
                                    n = t.createSelectorQuery(), i.tags.map(function(t) {
                                        n.select("#tag_id_".concat(t.id)).boundingClientRect(function(e) {
                                            e && (t.width = e.width);
                                        }).exec();
                                    });
                                });
                            }
                        });
                    },
                    colorRgba: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .75;
                        return this.$utils.colorRgba(t, e);
                    },
                    searchKeyword: function(t) {
                        var e = t.detail;
                        Object.assign(this.search, {
                            keyword: e.value.trim()
                        });
                    },
                    searchTab: function(e) {
                        for (var n = e.id, i = 0, a = 0; a < this.tags.length; a++) {
                            if (this.tags[a].id === n) {
                                i += this.tags[a].width / 2;
                                break;
                            }
                            i += this.tags[a].width + t.upx2px(24);
                        }
                        this.scrollLeft = i - t.upx2px(351) || 0, n = this.search.tag_id === n ? "" : n, 
                        Object.assign(this.search, {
                            tag_id: n
                        }), this.loadData();
                    },
                    jumpDetail: function(e) {
                        var n = e.id;
                        t.navigateTo({
                            url: "/pages/topic/topic?id=".concat(n)
                        });
                    },
                    jumpGoods: function(e) {
                        var n = e.page_url;
                        t.navigateTo({
                            url: n
                        });
                    },
                    previewImage: function(e, n) {
                        t.previewImage({
                            urls: n.map(function(t) {
                                return t.pic_url;
                            }),
                            current: e
                        });
                    }
                }
            };
            e.default = c;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-special-topic/app-special-topic-list-create-component", {
    "components/page-component/app-special-topic/app-special-topic-list-create-component": function(t, e, n) {
        n("543d").createComponent(n("1bf2"));
    }
}, [ [ "components/page-component/app-special-topic/app-special-topic-list-create-component" ] ] ]);