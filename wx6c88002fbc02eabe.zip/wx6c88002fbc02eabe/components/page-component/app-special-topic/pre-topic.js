(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-special-topic/pre-topic" ], {
    "113c": function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                props: {
                    previewStatus: Boolean,
                    swiperCurrent: Number,
                    previewItem: Object,
                    jumpUrl: String
                },
                data: function() {
                    return {
                        dx: 0,
                        selectCurrent: 0,
                        isJump: !1,
                        previewIndex: 0
                    };
                },
                watch: {
                    swiperCurrent: function(t) {
                        this.selectCurrent = t;
                    }
                },
                methods: {
                    sStop: function() {},
                    closePri: function() {
                        this.$emit("update:previewStatus", !1), this.$emit("update:previewItem", null);
                    },
                    touchend: function() {
                        ((arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null) || this.isJump) && (this.jumpDetail(this.previewItem), 
                        this.closePri());
                    },
                    jumpDetail: function(e) {
                        var n = e.id;
                        t.navigateTo({
                            url: this.jumpUrl || "/pages/topic/topic?id=".concat(n)
                        });
                    },
                    swiperChange: function(t) {
                        var e = t.detail;
                        this.selectCurrent = e.current;
                    },
                    swiperTransition: function(t) {
                        var e = t.detail;
                        this.isJump = e.dx > this.dx && this.dx > 50 && this.selectCurrent === this.previewItem.pic_url.length - 1, 
                        this.dx = e.dx;
                    }
                }
            };
            e.default = n;
        }).call(this, n("543d").default);
    },
    "5a2c": function(t, e, n) {
        var i = n("948a");
        n.n(i).a;
    },
    9436: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, c = [];
    },
    "948a": function(t, e, n) {},
    a7d4: function(t, e, n) {
        n.r(e);
        var i = n("9436"), c = n("ca8a");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(o);
        n("5a2c");
        var a = n("f0c5"), p = Object(a.a)(c.default, i.b, i.c, !1, null, "5e590fcf", null, !1, i.a, void 0);
        e.default = p.exports;
    },
    ca8a: function(t, e, n) {
        n.r(e);
        var i = n("113c"), c = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = c.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-special-topic/pre-topic-create-component", {
    "components/page-component/app-special-topic/pre-topic-create-component": function(t, e, n) {
        n("543d").createComponent(n("a7d4"));
    }
}, [ [ "components/page-component/app-special-topic/pre-topic-create-component" ] ] ]);