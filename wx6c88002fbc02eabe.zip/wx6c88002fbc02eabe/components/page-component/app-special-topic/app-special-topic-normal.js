(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-special-topic/app-special-topic-normal" ], {
    "069b": function(n, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var e = {
            name: "app-special-topic",
            props: {
                topic_list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                count: {
                    type: Number,
                    default: function() {
                        return 2;
                    }
                },
                icon: String,
                logo_1: String,
                logo_2: String
            },
            computed: {
                newDataList: function() {
                    if (2 === this.count) {
                        for (var n = [], t = 0; t < Math.ceil(this.topic_list.length / this.count); t++) n.push(this.topic_list.slice(t * this.count, (t + 1) * this.count));
                        return n;
                    }
                }
            }
        };
        t.default = e;
    },
    "26a4": function(n, t, o) {
        o.r(t);
        var e = o("8280"), c = o("a70e");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(t, n, function() {
                return c[n];
            });
        }(a);
        o("5853");
        var p = o("f0c5"), i = Object(p.a)(c.default, e.b, e.c, !1, null, "2b4328d4", null, !1, e.a, void 0);
        t.default = i.exports;
    },
    5853: function(n, t, o) {
        var e = o("c15a");
        o.n(e).a;
    },
    8280: function(n, t, o) {
        o.d(t, "b", function() {
            return e;
        }), o.d(t, "c", function() {
            return c;
        }), o.d(t, "a", function() {});
        var e = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    },
    a70e: function(n, t, o) {
        o.r(t);
        var e = o("069b"), c = o.n(e);
        for (var a in e) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(t, n, function() {
                return e[n];
            });
        }(a);
        t.default = c.a;
    },
    c15a: function(n, t, o) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-special-topic/app-special-topic-normal-create-component", {
    "components/page-component/app-special-topic/app-special-topic-normal-create-component": function(n, t, o) {
        o("543d").createComponent(o("26a4"));
    }
}, [ [ "components/page-component/app-special-topic/app-special-topic-normal-create-component" ] ] ]);