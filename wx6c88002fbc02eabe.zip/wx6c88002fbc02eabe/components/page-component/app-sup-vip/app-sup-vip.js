(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-sup-vip/app-sup-vip" ], {
    "348c": function(e, n, t) {
        t.r(n);
        var r = t("6aac"), o = t("43ea");
        for (var p in o) [ "default" ].indexOf(p) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(p);
        t("8ef9");
        var i = t("f0c5"), c = Object(i.a)(o.default, r.b, r.c, !1, null, "636ddd8c", null, !1, r.a, void 0);
        n.default = c.exports;
    },
    "43ea": function(e, n, t) {
        t.r(n);
        var r = t("f945"), o = t.n(r);
        for (var p in r) [ "default" ].indexOf(p) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(p);
        n.default = o.a;
    },
    "6aac": function(e, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    "8ef9": function(e, n, t) {
        var r = t("93e6");
        t.n(r).a;
    },
    "93e6": function(e, n, t) {},
    f945: function(e, n, t) {
        function r(e, n) {
            var t = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                n && (r = r.filter(function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable;
                })), t.push.apply(t, r);
            }
            return t;
        }
        function o(e) {
            for (var n = 1; n < arguments.length; n++) {
                var t = null != arguments[n] ? arguments[n] : {};
                n % 2 ? r(Object(t), !0).forEach(function(n) {
                    p(e, n, t[n]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : r(Object(t)).forEach(function(n) {
                    Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                });
            }
            return e;
        }
        function p(e, n, t) {
            return n in e ? Object.defineProperty(e, n, {
                value: t,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[n] = t, e;
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = t("2f62"), c = {
            name: "app-sup-vip",
            props: {
                discount: {
                    type: String,
                    default: function() {
                        return null;
                    }
                },
                is_vip_card_user: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                },
                margin: {
                    type: String,
                    default: function() {
                        return "0";
                    }
                },
                new_icon: Boolean
            },
            data: function() {
                return {
                    is_show: !1
                };
            },
            created: function() {
                var e = this;
                1 == e.is_vip_card_user ? "1" == e.mall.setting.is_show_super_vip ? e.is_show = !0 : e.is_show = !1 : "1" == e.mall.setting.is_show_normal_vip ? e.is_show = !0 : e.is_show = !1;
            },
            computed: o(o({}, (0, i.mapState)({
                mall: function(e) {
                    return e.mallConfig.mall;
                },
                userInfo: function(e) {
                    return e.user.info;
                }
            })), {}, {
                vipText: function() {
                    return this.priceUnit(this.discount, "折", "after");
                }
            })
        };
        n.default = c;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-sup-vip/app-sup-vip-create-component", {
    "components/page-component/app-sup-vip/app-sup-vip-create-component": function(e, n, t) {
        t("543d").createComponent(t("348c"));
    }
}, [ [ "components/page-component/app-sup-vip/app-sup-vip-create-component" ] ] ]);