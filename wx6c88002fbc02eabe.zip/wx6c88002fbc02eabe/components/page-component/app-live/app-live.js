(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-live/app-live" ], {
    1845: function(e, n, t) {},
    "45f1": function(e, n, t) {
        (function(e) {
            function o(e, n) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function r(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t("2f62"), c = {
                name: "app-live",
                components: {},
                props: {
                    value: {
                        type: Object,
                        default: function() {
                            return {
                                background: "#f7f7f7",
                                live_list: [],
                                is_show_goods: !0,
                                number: 5,
                                style_type: 1
                            };
                        }
                    }
                },
                data: function() {
                    return {};
                },
                computed: function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var t = null != arguments[n] ? arguments[n] : {};
                        n % 2 ? o(Object(t), !0).forEach(function(n) {
                            r(e, n, t[n]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(n) {
                            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
                        });
                    }
                    return e;
                }({
                    newValue: function() {
                        var e = this, n = [ {
                            background: e.value.background,
                            is_show_goods: e.value.is_show_goods,
                            number: e.value.number,
                            style_type: e.value.style_type,
                            live_list: []
                        }, {
                            background: e.value.background,
                            is_show_goods: e.value.is_show_goods,
                            number: e.value.number,
                            style_type: e.value.style_type,
                            live_list: []
                        } ], t = 0, o = 0;
                        return e.value.live_list.forEach(function(e, r) {
                            var a = e.goods.length > 0;
                            0 == t || t <= o ? (t = a ? t + 2 : t + 1, n[0].live_list.push(e)) : (o = a ? o + 2 : o + 1, 
                            n[1].live_list.push(e));
                        }), n;
                    }
                }, (0, a.mapState)({
                    userInfo: function(e) {
                        return e.user.info;
                    },
                    commonImg: function(e) {
                        return e.mallConfig.__wxapp_img.common;
                    }
                })),
                methods: {
                    liveClick: function(n) {
                        var t = {
                            user_id: this.userInfo ? this.userInfo.options.user_id : 0
                        };
                        e.navigateTo({
                            url: "plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=".concat(n.roomid, "&custom_params=").concat(encodeURIComponent(JSON.stringify(t)))
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, t("543d").default);
    },
    "6b66": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, r = [];
    },
    "97a9": function(e, n, t) {
        t.r(n);
        var o = t("45f1"), r = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = r.a;
    },
    bb25: function(e, n, t) {
        t.r(n);
        var o = t("6b66"), r = t("97a9");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(a);
        t("f59c");
        var c = t("f0c5"), i = Object(c.a)(r.default, o.b, o.c, !1, null, "2939e758", null, !1, o.a, void 0);
        n.default = i.exports;
    },
    f59c: function(e, n, t) {
        var o = t("1845");
        t.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-live/app-live-create-component", {
    "components/page-component/app-live/app-live-create-component": function(e, n, t) {
        t("543d").createComponent(t("bb25"));
    }
}, [ [ "components/page-component/app-live/app-live-create-component" ] ] ]);