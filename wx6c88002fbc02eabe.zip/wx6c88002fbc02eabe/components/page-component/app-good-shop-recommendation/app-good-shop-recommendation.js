(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-good-shop-recommendation/app-good-shop-recommendation" ], {
    "06d5": function(e, t, o) {},
    "38a5": function(e, t, o) {
        o.r(t);
        var n = o("d7cc"), i = o.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = i.a;
    },
    "3da2": function(e, t, o) {
        o.r(t);
        var n = o("e846"), i = o("38a5");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(r);
        o("9447");
        var a = o("f0c5"), c = Object(a.a)(i.default, n.b, n.c, !1, null, "7c7a6e06", null, !1, n.a, void 0);
        t.default = c.exports;
    },
    9447: function(e, t, o) {
        var n = o("06d5");
        o.n(n).a;
    },
    d7cc: function(e, t, o) {
        (function(e) {
            function n(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function i(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? n(Object(o), !0).forEach(function(t) {
                        r(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : n(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }
            function r(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o("2f62"), c = {
                name: "app-good-shop-recommendation",
                props: {
                    cPaddingTb: {
                        type: Number,
                        default: 24
                    },
                    cPaddingLf: {
                        type: Number,
                        default: 24
                    },
                    cPaddingCen: {
                        type: Number,
                        default: 20
                    },
                    borderColor: {
                        type: String,
                        default: "#62D30C"
                    },
                    showGoods: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        },
                        required: !1
                    },
                    cardStyle: {
                        type: String,
                        default: function() {
                            return "1";
                        },
                        required: !1
                    },
                    type: {
                        type: String,
                        default: function() {
                            return "mch";
                        },
                        required: !1
                    },
                    backgroundColor: {
                        type: String,
                        default: function() {
                            return "#fff";
                        },
                        required: !1
                    },
                    theme: {
                        type: [ String, Object ],
                        required: !1
                    },
                    page_id: {
                        type: Number,
                        required: !1
                    },
                    index: {
                        type: Number,
                        required: !1
                    },
                    is_required: {
                        type: Boolean,
                        required: !1
                    },
                    mch_list: {
                        type: Array,
                        required: !1
                    },
                    coupon_req: {
                        type: Boolean,
                        required: !1
                    },
                    refresh_num: {
                        type: Number,
                        default: 0
                    }
                },
                computed: i(i(i({}, (0, a.mapGetters)("mallConfig", {
                    getVideo: "getVideo"
                })), (0, a.mapState)({
                    platform: function(e) {
                        return e.gConfig.systemInfo.platform;
                    }
                })), {}, {
                    itemStyle: function() {
                        return function(e, t) {
                            var o = {};
                            return Object.assign(o, {
                                display: "flex",
                                flexGrow: 1,
                                flexShrink: 1
                            }), e < 2 && Object.assign(o, {
                                marginRight: "22rpx"
                            }), o;
                        };
                    }
                }),
                methods: {
                    jump: function(e) {
                        this.$jump({
                            url: "/plugins/mch/shop/shop?mch_id=".concat(e),
                            open_type: "navigate"
                        });
                    },
                    router_jump: function(t, o) {
                        t.goodsWarehouse.video_url && 1 == this.getVideo ? e.navigateTo({
                            url: "/pages/goods/video?goods_id=".concat(t.id, "&sign=mch")
                        }) : e.navigateTo({
                            url: "/plugins/mch/goods/goods?id=".concat(t.id, "&mch_id=").concat(o)
                        });
                    },
                    loadData: function() {
                        var e = this;
                        this.$request({
                            url: this.$api.index.extra,
                            data: {
                                type: 0 === this.page_id ? "mall" : "diy",
                                key: "mch",
                                page_id: this.page_id,
                                index: this.index,
                                longitude: 0,
                                latitude: 0
                            }
                        }).then(function(t) {
                            if (e.list = t.data, 0 === e.page_id) {
                                var o = e.$storage.getStorageSync("INDEX_MALL");
                                o.home_pages[e.index].list = e.list, e.$storage.setStorageSync("INDEX_MALL", o);
                            }
                        });
                    },
                    initData: function() {
                        if (this.coupon_req) this.list = this.mch_list; else if (this.is_required) this.loadData(); else {
                            var e = this.$storage.getStorageSync("INDEX_MALL");
                            this.list = e.home_pages[this.index].list;
                        }
                    }
                },
                data: function() {
                    return {
                        list: []
                    };
                },
                watch: {
                    mch_list: {
                        handler: function(e) {
                            this.coupon_req && (this.list = e);
                        },
                        deep: !0
                    },
                    refresh_num: function(e) {
                        this.initData();
                    }
                },
                mounted: function() {
                    this.initData();
                }
            };
            t.default = c;
        }).call(this, o("543d").default);
    },
    e846: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, e.showGoods ? e.__map(e.list, function(t, o) {
                return {
                    $orig: e.__get_orig(t),
                    l0: t.goodsList && 0 !== t.goodsList.length ? e.__map(t.goodsList, function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            s0: e.__get_style([ e.itemStyle(n, t.goodsList.length) ], {
                                height: "100%"
                            })
                        };
                    }) : null,
                    l1: t.goodsList && 0 !== t.goodsList.length ? e.__map(new Array(3 - t.goodsList.length), function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            s1: 3 >= t.goodsList.length ? e.__get_style([ e.itemStyle(n, t.goodsList.length) ], {
                                height: "100%"
                            }) : null
                        };
                    }) : null
                };
            }) : null);
            e.$mp.data = Object.assign({}, {
                $root: {
                    l2: t
                }
            });
        }, i = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-good-shop-recommendation/app-good-shop-recommendation-create-component", {
    "components/page-component/app-good-shop-recommendation/app-good-shop-recommendation-create-component": function(e, t, o) {
        o("543d").createComponent(o("3da2"));
    }
}, [ [ "components/page-component/app-good-shop-recommendation/app-good-shop-recommendation-create-component" ] ] ]);