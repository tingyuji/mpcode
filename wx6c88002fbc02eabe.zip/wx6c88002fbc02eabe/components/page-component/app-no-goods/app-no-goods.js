(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-no-goods/app-no-goods" ], {
    "17f3": function(n, e, o) {
        var t = o("6100");
        o.n(t).a;
    },
    "3da24": function(n, e, o) {
        o.r(e);
        var t = o("f90d"), r = o.n(t);
        for (var c in t) [ "default" ].indexOf(c) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(c);
        e.default = r.a;
    },
    6100: function(n, e, o) {},
    8112: function(n, e, o) {
        o.r(e);
        var t = o("c7a7a"), r = o("3da24");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(n) {
            o.d(e, n, function() {
                return r[n];
            });
        }(c);
        o("17f3");
        var a = o("f0c5"), p = Object(a.a)(r.default, t.b, t.c, !1, null, "a7d12dc0", null, !1, t.a, void 0);
        e.default = p.exports;
    },
    c7a7a: function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return r;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, r = [];
    },
    f90d: function(n, e, o) {
        function t(n, e) {
            var o = Object.keys(n);
            if (Object.getOwnPropertySymbols) {
                var t = Object.getOwnPropertySymbols(n);
                e && (t = t.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable;
                })), o.push.apply(o, t);
            }
            return o;
        }
        function r(n, e, o) {
            return e in n ? Object.defineProperty(n, e, {
                value: o,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : n[e] = o, n;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = o("2f62"), a = {
            name: "app-no-goods",
            props: {
                background: {
                    type: String,
                    default: function() {
                        return "#ffffff";
                    }
                },
                color: {
                    type: String,
                    default: function() {
                        return "#666666";
                    }
                },
                title: {
                    type: String,
                    default: function() {
                        return "没有任何商品哦~";
                    }
                },
                is_image: {
                    type: Number,
                    default: function() {
                        return 0;
                    }
                }
            },
            computed: function(n) {
                for (var e = 1; e < arguments.length; e++) {
                    var o = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? t(Object(o), !0).forEach(function(e) {
                        r(n, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(o)) : t(Object(o)).forEach(function(e) {
                        Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return n;
            }({}, (0, c.mapState)({
                commonImg: function(n) {
                    return n.mallConfig.__wxapp_img.common;
                }
            }))
        };
        e.default = a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-no-goods/app-no-goods-create-component", {
    "components/page-component/app-no-goods/app-no-goods-create-component": function(n, e, o) {
        o("543d").createComponent(o("8112"));
    }
}, [ [ "components/page-component/app-no-goods/app-no-goods-create-component" ] ] ]);