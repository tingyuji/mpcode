(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-ad/app-ad" ], {
    "0dd1": function(t, n, e) {
        e.d(n, "b", function() {
            return i;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, o = [];
    },
    ba36: function(t, n, e) {
        e.r(n);
        var i = e("0dd1"), o = e("bcb4");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("db5e");
        var d = e("f0c5"), r = Object(d.a)(o.default, i.b, i.c, !1, null, "2b6c6fcc", null, !1, i.a, void 0);
        n.default = r.exports;
    },
    bcb4: function(t, n, e) {
        e.r(n);
        var i = e("c876"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        n.default = o.a;
    },
    c876: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                name: "app-ad",
                props: {
                    type: String,
                    unitId: String,
                    picUrl: String,
                    videoUrl: String,
                    theme: {
                        type: String,
                        default: function() {
                            return "white";
                        }
                    },
                    couponUrl: String,
                    couponParams: Object
                },
                data: function() {
                    return {
                        rewardedVideoAd: null,
                        interstitialAd: null
                    };
                },
                created: function() {
                    this.init();
                },
                methods: {
                    onAdLoad: function() {},
                    onAdPlay: function() {},
                    onAdClose: function() {},
                    onAdError: function() {},
                    init: function() {
                        switch (this.type) {
                          case "rewarded-video":
                            this.initRewardedVideoAd();
                            break;

                          case "interstitial":
                            this.initInterstitialAd();
                        }
                    },
                    initRewardedVideoAd: function() {
                        var t = this;
                        wx.createRewardedVideoAd && (this.rewardedVideoAd = wx.createRewardedVideoAd({
                            adUnitId: this.unitId
                        }), this.rewardedVideoAd.onClose(function(n) {
                            n && n.isEnded && t.getUserCoupon();
                        }));
                    },
                    initInterstitialAd: function() {
                        wx.createInterstitialAd && (this.interstitialAd = wx.createInterstitialAd({
                            adUnitId: this.unitId
                        }));
                    },
                    showRewardedVideoAd: function() {
                        var n = this;
                        this.rewardedVideoAd.show().catch(function() {
                            n.rewardedVideoAd.load().then(function() {
                                return n.rewardedVideoAd.show();
                            }).catch(function(n) {
                                t.showToast({
                                    title: n.errMsg,
                                    icon: "none"
                                });
                            });
                        });
                    },
                    showInterstitialAd: function() {
                        this.interstitialAd.show().catch(function(n) {
                            t.showToast({
                                title: n.errMsg,
                                icon: "none"
                            });
                        });
                    },
                    getUserCoupon: function() {
                        var n = this;
                        this.$request({
                            url: this.couponUrl,
                            method: "POST",
                            data: Object.assign({}, this.couponParams)
                        }).then(function(e) {
                            0 === e.code ? n.$store.dispatch("page/actionSetCoupon", {
                                list: e.data.list,
                                type: "award"
                            }) : t.showToast({
                                title: e.msg,
                                icon: "none"
                            });
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e("543d").default);
    },
    d77b: function(t, n, e) {},
    db5e: function(t, n, e) {
        var i = e("d77b");
        e.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-ad/app-ad-create-component", {
    "components/page-component/app-ad/app-ad-create-component": function(t, n, e) {
        e("543d").createComponent(e("ba36"));
    }
}, [ [ "components/page-component/app-ad/app-ad-create-component" ] ] ]);