(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-copyright/app-copyright" ], {
    "2b47": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return p;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, p = [];
    },
    "4e34": function(n, t, e) {},
    "7d109": function(n, t, e) {
        e.r(t);
        var o = e("b7bb"), p = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = p.a;
    },
    "7fe8": function(n, t, e) {
        e.r(t);
        var o = e("2b47"), p = e("7d109");
        for (var c in p) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return p[n];
            });
        }(c);
        e("93c9");
        var r = e("f0c5"), a = Object(r.a)(p.default, o.b, o.c, !1, null, "6c4b53c0", null, !1, o.a, void 0);
        t.default = a.exports;
    },
    "93c9": function(n, t, e) {
        var o = e("4e34");
        e.n(o).a;
    },
    b7bb: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            name: "app-copyright",
            props: {
                backgroundColor: {
                    type: String,
                    default: function() {
                        return "#ff4544";
                    }
                },
                link: {
                    type: Object,
                    default: function() {
                        return null;
                    }
                },
                subDescription: String,
                picUrl: String,
                text: String,
                paddingBottom: {
                    type: String,
                    default: function() {
                        return "24rpx";
                    }
                }
            }
        };
        t.default = o;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-copyright/app-copyright-create-component", {
    "components/page-component/app-copyright/app-copyright-create-component": function(n, t, e) {
        e("543d").createComponent(e("7fe8"));
    }
}, [ [ "components/page-component/app-copyright/app-copyright-create-component" ] ] ]);