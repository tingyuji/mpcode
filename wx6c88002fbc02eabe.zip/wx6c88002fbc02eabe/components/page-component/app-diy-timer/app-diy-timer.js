(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-diy-timer/app-diy-timer" ], {
    "05ee": function(e, t, n) {
        var r = n("7e74");
        n.n(r).a;
    },
    "0eac": function(e, t, n) {
        n.r(t);
        var r = n("d1aea"), i = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = i.a;
    },
    "7e74": function(e, t, n) {},
    "8fb8": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this, t = (e.$createElement, e._self._c, 2 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null), n = 2 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, r = 2 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, i = 2 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, o = 3 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, a = 3 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, l = 3 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, p = 3 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, u = 4 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, c = 4 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, s = 4 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null, f = 4 == e.info.type && e.timerStr ? e.__get_style([ e.typeFour ]) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t,
                    s1: n,
                    s2: r,
                    s3: i,
                    s4: o,
                    s5: a,
                    s6: l,
                    s7: p,
                    s8: u,
                    s9: c,
                    s10: s,
                    s11: f
                }
            });
        }, i = [];
    },
    d1aea: function(e, t, n) {
        function r(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function i(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? r(Object(n), !0).forEach(function(t) {
                    o(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function o(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = n("2f62"), l = {
            name: "app-timer",
            props: {
                info: Object
            },
            data: function() {
                return {
                    timeInterval: null,
                    startTime: null,
                    endTime: null,
                    timerStr: null,
                    realTime: {
                        d: "00",
                        h: "00",
                        m: "00",
                        s: "00"
                    }
                };
            },
            computed: i(i({}, (0, a.mapState)({
                appImg: function(e) {
                    return e.mallConfig.__wxapp_img;
                }
            })), {}, {
                titleText: function() {
                    var e = this.info, t = e.title_before, n = e.title_progress, r = e.title_after;
                    return this.startTime ? t : null === this.startTime && this.endTime ? n : null === this.startTime && null === this.endTime ? r : void 0;
                },
                typeFour: function() {
                    var e = this.info;
                    return {
                        background: e.bg_color,
                        color: e.text_color
                    };
                },
                time: function() {
                    return {
                        startDateTime: this.info.startDateTime,
                        endDateTime: this.info.endDateTime,
                        pageHide: this.info.pageHide
                    };
                }
            }),
            beforeDestroy: function() {
                clearInterval(this.timeInterval);
            },
            watch: {
                time: {
                    handler: function() {
                        var e = this;
                        if (this.info.pageHide) clearInterval(this.timeInterval); else {
                            var t = this.info.startDateTime, n = this.info.endDateTime;
                            this.timeInterval = setInterval(function() {
                                var r = null, i = null, o = null;
                                t && (t = t.replace(/-/g, "/"), (r = e.$utils.timeDifference(new Date().getTime(), new Date(t).getTime())) && (o = (r.d > 0 ? r.d + "天" : "") + r.h + "小时" + r.m + "分" + r.s + "秒", 
                                e.realTime = r)), n && !o && (n = n.replace(/-/g, "/"), (i = e.$utils.timeDifference(new Date().getTime(), new Date(n).getTime())) && (o = (i.d > 0 ? i.d + "天" : "") + i.h + "小时" + i.m + "分" + i.s + "秒", 
                                e.realTime = i)), e.startTime = r, e.endTime = i, e.timerStr = o;
                            }, 1e3);
                        }
                    },
                    immediate: !0
                }
            }
        };
        t.default = l;
    },
    e2d1: function(e, t, n) {
        n.r(t);
        var r = n("8fb8"), i = n("0eac");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("05ee");
        var a = n("f0c5"), l = Object(a.a)(i.default, r.b, r.c, !1, null, "8317b9ee", null, !1, r.a, void 0);
        t.default = l.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-diy-timer/app-diy-timer-create-component", {
    "components/page-component/app-diy-timer/app-diy-timer-create-component": function(e, t, n) {
        n("543d").createComponent(n("e2d1"));
    }
}, [ [ "components/page-component/app-diy-timer/app-diy-timer-create-component" ] ] ]);