(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-index-cat/app-index-cat" ], {
    "1c7e": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    },
    "258a": function(e, t, n) {
        n.r(t);
        var o = n("1c7e"), a = n("ed8c");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("9280");
        var i = n("f0c5"), c = Object(i.a)(a.default, o.b, o.c, !1, null, "396e909c", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "75c3": function(e, t, n) {},
    9280: function(e, t, n) {
        var o = n("75c3");
        n.n(o).a;
    },
    b858: function(e, t, n) {
        (function(e) {
            function o(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n("2f62"), i = {
                name: "app-index-cat",
                components: {
                    appGoods: function() {
                        n.e("components/basic-component/app-goods/app-goods").then(function() {
                            return resolve(n("ad05"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                props: {
                    theme: {
                        type: Object
                    },
                    page_id: {
                        type: Number
                    },
                    index: {
                        type: Number
                    },
                    is_required: {
                        type: Boolean
                    },
                    refresh_num: {
                        type: Number,
                        default: 0
                    }
                },
                data: function() {
                    return {
                        newData: {}
                    };
                },
                methods: {
                    route: function(t) {
                        e.navigateTo({
                            url: "/pages/goods/list?cat_id=".concat(t)
                        });
                    },
                    loadData: function() {
                        var e = this;
                        this.$request({
                            url: this.$api.index.extra,
                            data: {
                                type: "mall",
                                key: "cat",
                                page_id: this.page_id,
                                index: this.index
                            }
                        }).then(function(t) {
                            if (e.newData = t.data, 0 === t.code && t.data) {
                                var n = e.$storage.getStorageSync("INDEX_MALL");
                                n.home_pages[e.index].list = e.newData, e.$storage.setStorageSync("INDEX_MALL", n);
                            }
                        });
                    },
                    getStorage: function() {
                        var e = this.$storage.getStorageSync("INDEX_MALL");
                        this.newData = e.home_pages[this.index].list;
                    },
                    buyProduct: function(e) {
                        this.$emit("buyProduct", e);
                    }
                },
                mounted: function() {
                    this.is_required ? this.loadData() : this.getStorage();
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? o(Object(n), !0).forEach(function(t) {
                            a(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, r.mapState)({
                    goodsImg: function(e) {
                        return e.mallConfig.__wxapp_img.goods;
                    },
                    isListUnderlinePrice: function(e) {
                        return e.mallConfig.mall.setting.is_list_underline_price;
                    }
                })),
                watch: {
                    refresh_num: function(e) {
                        this.is_required ? this.loadData() : this.getStorage();
                    }
                },
                filters: {
                    listStyle: function(e) {
                        return 1 === e ? -1 : 2 === e ? 2 : 3 === e ? 3 : null;
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    ed8c: function(e, t, n) {
        n.r(t);
        var o = n("b858"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-index-cat/app-index-cat-create-component", {
    "components/page-component/app-index-cat/app-index-cat-create-component": function(e, t, n) {
        n("543d").createComponent(n("258a"));
    }
}, [ [ "components/page-component/app-index-cat/app-index-cat-create-component" ] ] ]);