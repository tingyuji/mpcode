(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/index/app-nav-bar" ], {
    "1eec": function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.hasHeight ? t.__get_style([ t.hiddenHeight ]) : null), n = t.__get_style([ t.ordinaryStyle ]), a = t.isCustom || t.detailSearch || !t.showLeftIcon ? null : t.__get_style([ t.hw_style ]), r = !t.isCustom && !t.detailSearch && t.showTitle && t.hasJump ? t.__get_style([ t.maxWidth ]) : null, o = t.isCustom || t.detailSearch || !t.showTitle || t.hasJump ? null : t.__get_style([ t.maxWidth ]), i = t.isCustom || t.detailSearch || !t.showLink ? null : t.__get_style([ t.searchStyle ]);
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e,
                    s1: n,
                    s2: a,
                    s3: r,
                    s4: o,
                    s5: i
                }
            });
        }, r = [];
    },
    "2fe6": function(t, e, n) {
        (function(t) {
            function a(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    e && (a = a.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function r(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? a(Object(n), !0).forEach(function(e) {
                        o(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function o(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("2f62"), s = {
                name: "app-nav-bar",
                data: function() {
                    return {
                        h: 0,
                        hw_style: {}
                    };
                },
                watch: {
                    leftIcon: function() {
                        this.doSomething();
                    }
                },
                props: {
                    opacity: {
                        type: Number,
                        default: 1
                    },
                    fixed: {
                        type: [ Boolean, String ],
                        default: !0
                    },
                    shadow: {
                        type: [ String, Boolean ],
                        default: !1
                    },
                    hasHeight: {
                        type: Boolean,
                        default: !0
                    },
                    border: {
                        type: [ String, Boolean ],
                        default: !1
                    },
                    backgroundColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    leftIcon: {
                        type: String,
                        default: ""
                    },
                    link: {
                        type: [ Object, Array ]
                    },
                    title: {
                        type: String,
                        default: ""
                    },
                    xStyle: {
                        type: [ Number, String ],
                        default: 1
                    },
                    hasMallSetting: {
                        type: [ Number, String ],
                        default: 1
                    },
                    color: {
                        type: String,
                        default: "#000000"
                    },
                    position: {
                        type: String,
                        default: "center"
                    },
                    placeholder: {
                        type: String,
                        default: "搜索"
                    },
                    placeholderColor: {
                        type: String,
                        default: "#666666"
                    },
                    backColor: {
                        type: String,
                        default: "black"
                    },
                    detailSearch: {
                        type: Boolean,
                        default: !1
                    },
                    isCustom: {
                        type: Boolean,
                        default: !1
                    },
                    back: Boolean,
                    appNavBar: Object,
                    scroll: Number,
                    isIndex: {
                        type: Boolean,
                        default: !1
                    }
                },
                computed: r(r({}, (0, i.mapState)({
                    statusBarHeight: function(t) {
                        return t.gConfig.systemInfo.statusBarHeight;
                    },
                    mBarHeight: function(t) {
                        return t.gConfig.mBarHeight;
                    },
                    appImg: function(t) {
                        return t.mallConfig.__wxapp_img.mall;
                    },
                    mallNavbar: function(t) {
                        return t.mallConfig.navbar;
                    },
                    index_gray: function(t) {
                        return t.mallConfig.mall.setting.is_index_gray;
                    }
                })), {}, {
                    is_index_gray: function() {
                        return this.index_gray && this.isIndex;
                    },
                    maxWidth: function() {
                        var e = 0;
                        switch (parseInt(this.xStyle)) {
                          case 1:
                            e = "center" === this.position ? t.upx2px(360) : t.upx2px(500);
                            break;

                          case 2:
                            e = this.showLeftIcon || this.pagesLength > 1 ? t.upx2px(400) : "auto";
                            break;

                          case 4:
                            e = t.upx2px(200);
                        }
                        return e && this.pagesLength > 1 && (e -= t.upx2px(42)), Object.assign({}, {
                            "max-width": e + "px",
                            "white-space": "normal !important"
                        });
                    },
                    hiddenHeight: function() {
                        return {
                            background: 6 == this.xStyle ? this.appNavBar.after_bg : "",
                            height: 5 == this.xStyle ? 0 : this.h + "px"
                        };
                    },
                    searchStyle: function() {
                        if (6 == this.xStyle) return {
                            width: "100%",
                            background: this.appNavBar.s_search_bg,
                            borderColor: this.appNavBar.s_search_border || "rgba(0,0,0,0)",
                            color: this.placeholderColor
                        };
                    },
                    ordinaryStyle: function() {
                        var e, n, a = {};
                        if (6 == this.xStyle) n = this.scroll > 10 ? this.backgroundColor : this.appNavBar.after_bg, 
                        a = {
                            transition: "0.6s ease-in-out"
                        }; else if (5 == this.xStyle) n = ""; else {
                            1 == this.hasMallSetting ? (e = this.mallNavbar.top_text_color, n = this.mallNavbar.top_background_color) : (e = this.color, 
                            n = this.backgroundColor);
                            var r = this.opacity;
                            1 == r && (r = .0156 * this.scroll > 1 || !this.appNavBar || 0 == this.appNavBar.has_banner ? 1 : .0156 * this.scroll), 
                            n = this.$utils.colorRgba(n, r);
                        }
                        return t.setBackgroundColor({
                            backgroundColor: n,
                            backgroundColorTop: n,
                            backgroundColorBottom: n
                        }), Object.assign({}, {
                            color: e || "#000000",
                            backgroundColor: n || "rgba(0,0,0,0)",
                            height: this.h + "px",
                            padding: "".concat(this.statusBarHeight, "px 0 0 ").concat(this.pagesLength > 1 ? 0 : "26rpx")
                        }, a);
                    },
                    hasJump: function() {
                        return [ 2, 4 ].includes(+this.xStyle);
                    },
                    showLeftIcon: function() {
                        return [ 2, 3 ].includes(+this.xStyle) && (0 == this.appNavBar.has_banner || this.scroll > 64) || 6 == this.xStyle && 1 == this.appNavBar.s_left_show;
                    },
                    showTitle: function() {
                        return [ 1, 2, 4 ].includes(+this.xStyle) && this.title;
                    },
                    showLink: function() {
                        return [ 3, 4 ].includes(+this.xStyle) || 6 == this.xStyle && 1 == this.appNavBar.s_search;
                    },
                    showRight: function() {
                        return 6 == this.xStyle && 1 == this.appNavBar.s_right_show;
                    },
                    pagesLength: function() {
                        return getCurrentPages().length;
                    }
                }),
                created: function() {
                    var t;
                    t = (t = this.statusBarHeight) || 0, this.h = t + this.mBarHeight, this.$emit("headHeight", this.h);
                },
                mounted: function() {
                    this.doSomething();
                },
                methods: {
                    hShareAppMessage: function() {},
                    doSomething: function() {
                        var e = 54, n = 100, a = this;
                        t.getImageInfo({
                            src: a.leftIcon,
                            success: function(r) {
                                var o = r.height, i = r.width;
                                o <= e && i >= n && (o /= i / n, i = n), o >= e && i <= n && (o = e, i /= o / e), 
                                o > e && i >= n && (n / e > i / o ? (i /= o / e, o = e) : (o /= i / n, i = n)), 
                                a.hw_style = {
                                    height: t.upx2px(o) + "px",
                                    width: t.upx2px(i) + "px"
                                };
                            }
                        });
                    },
                    navGoodsSearch: function() {
                        t.navigateTo({
                            url: "/pages/search/search"
                        });
                    },
                    onClickBack: function() {
                        t.navigateBack({
                            delta: 1
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    },
    34780: function(t, e, n) {},
    "59f3": function(t, e, n) {
        n.r(e);
        var a = n("1eec"), r = n("b7ce");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        n("912c");
        var i = n("f0c5"), s = Object(i.a)(r.default, a.b, a.c, !1, null, "3c5e85e3", null, !1, a.a, void 0);
        e.default = s.exports;
    },
    "912c": function(t, e, n) {
        var a = n("34780");
        n.n(a).a;
    },
    b7ce: function(t, e, n) {
        n.r(e);
        var a = n("2fe6"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/index/app-nav-bar-create-component", {
    "components/page-component/index/app-nav-bar-create-component": function(t, e, n) {
        n("543d").createComponent(n("59f3"));
    }
}, [ [ "components/page-component/index/app-nav-bar-create-component" ] ] ]);