(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/index/app-diy-page" ], {
    "0969": function(i, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return n;
        }), o.d(e, "a", function() {});
        var t = function() {
            var i = this, e = (i.$createElement, i._self._c, i.__map(i.navs, function(e, o) {
                return {
                    $orig: i.__get_orig(e),
                    m0: i.nav_active === o && i.background ? i.transLabelBackgroundPosition(i.background.position) : null,
                    m1: i.nav_active === o && i.background ? i.transLabelBackgroundRepeat(i.background.mode) : null,
                    l1: i.nav_active === o ? i.__map(i.new_box, function(o, t) {
                        var n = i.__get_orig(o), a = (t < i.show_pos - 1 || !i.is_module) && "search" !== o.id && "banner" === o.id && i.banner_list[o.index].banners.length > 0 && (1 == i.banner_list[o.index].effect || !i.banner_list[o.index].effect) ? i.$utils.colorRgba(i.banner_list[o.index].swiper_color, .3) : null, s = (t < i.show_pos - 1 || !i.is_module) && "search" !== o.id && "banner" === o.id && i.banner_list[o.index].banners.length > 0 && 1 != i.banner_list[o.index].effect && i.banner_list[o.index].effect && 2 == i.banner_list[o.index].effect ? i.$utils.colorRgba(i.banner_list[o.index].swiper_color, .3) : null, d = (t < i.show_pos - 1 || !i.is_module) && "search" !== o.id && "banner" !== o.id && "goods" !== o.id ? [ "miaosha", "flash-sale" ].indexOf(o.id) : null, r = !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType ? null : i.plugin_goods.indexOf(o.id);
                        return {
                            $orig: n,
                            g0: a,
                            g1: s,
                            g2: d,
                            g3: r,
                            a0: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 === r || 0 == i.plugin_goods_list[o.id][o.index].listStyle ? null : {
                                data: i.plugin_goods_list[o.id][o.index],
                                id: o.id
                            },
                            a1: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 === r || 0 != i.plugin_goods_list[o.id][o.index].listStyle ? null : {
                                data: i.plugin_goods_list[o.id][o.index],
                                id: o.id
                            },
                            l0: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" !== o.id ? null : i.__map(i.rubik_list[o.index].hotspot, function(e, o) {
                                return {
                                    $orig: i.__get_orig(e),
                                    m2: i.rubikHotspot(e)
                                };
                            }),
                            m3: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" !== o.id || i.nav_list[o.index].modeType ? null : i.transLabelBackgroundPosition(i.nav_list[o.index].position),
                            m4: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" !== o.id || i.nav_list[o.index].modeType ? null : i.transLabelBackgroundRepeat(i.nav_list[o.index].mode),
                            g4: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" !== o.id ? null : Object.assign({}, i.link_list[o.index].link),
                            g5: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" !== o.id ? null : Number.parseInt(e.template_id),
                            m5: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" !== o.id ? null : i.transLabelBackgroundPosition(i.mch_list[o.index].position),
                            m6: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" !== o.id ? null : i.transLabelBackgroundRepeat(i.mch_list[o.index].mode),
                            f0: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" !== o.id ? null : i._f("getObje")(e),
                            m7: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" !== o.id ? null : i.transLabelPosition(i.form_list[o.index].data.style),
                            m8: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" !== o.id ? null : i.transLabelBackgroundPosition(i.form_list[o.index].data.position),
                            m9: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" !== o.id ? null : i.transLabelBackgroundRepeat(i.form_list[o.index].data.mode),
                            m10: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" === o.id || "vip-card" === o.id || "live" === o.id || "video-live" === o.id || "customer" === o.id || "module" === o.id && i.is_module || "access_limit" !== o.id ? null : i.hiddenHeight("top"),
                            m11: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" === o.id || "vip-card" === o.id || "live" === o.id || "video-live" === o.id || "customer" === o.id || "module" === o.id && i.is_module || "access_limit" === o.id || "zhongcao" === o.id || !i.is_module || "all-goods" !== o.id || t != i.new_box.length - 1 ? null : i.transLabelBackgroundPosition(i.all_goods.position),
                            m12: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" === o.id || "vip-card" === o.id || "live" === o.id || "video-live" === o.id || "customer" === o.id || "module" === o.id && i.is_module || "access_limit" === o.id || "zhongcao" === o.id || !i.is_module || "all-goods" !== o.id || t != i.new_box.length - 1 ? null : i.transLabelBackgroundRepeat(i.all_goods.mode),
                            a2: !(t < i.show_pos - 1) && i.is_module || "search" === o.id || "banner" === o.id || "goods" === o.id || -1 !== d && 0 == i.plugin_goods_list[o.id][o.index].addGoodsType || -1 !== r || "rubik" === o.id || "notice" === o.id || "nav" === o.id || "video" === o.id || "link" === o.id || "topic" === o.id || "store" === o.id || "copyright" === o.id || "user-info" === o.id || "user-order" === o.id || "coupon" === o.id || "timer" === o.id || "mch" === o.id || "empty" === o.id || "ad" === o.id || "map" === o.id || "check-in" === o.id || "image-text" === o.id || "form-module" === o.id || "form" === o.id || "vip-card" === o.id || "live" === o.id || "video-live" === o.id || "customer" === o.id || "module" === o.id && i.is_module || "access_limit" === o.id || "zhongcao" === o.id || !i.is_module || "all-goods" !== o.id || t != i.new_box.length - 1 || "top" !== i.all_goods.catPosition ? null : {
                                data: i.all_goods,
                                id: o.id
                            },
                            m13: (t < i.show_pos - 1 || !i.is_module) && ("mp-link" === o.id || "top" === i.mp_link.position && 0 == t) ? i.hiddenHeight(i.mp_link.position) : null
                        };
                    }) : null
                };
            }));
            i._isMounted || (i.e0 = function(e, o) {
                return i.changeTopNav(e, o, "quick-shop");
            }), i.$mp.data = Object.assign({}, {
                $root: {
                    l2: e
                }
            });
        }, n = [];
    },
    "687c": function(i, e, o) {
        var t = o("9a26");
        o.n(t).a;
    },
    "6a38": function(i, e, o) {
        o.r(e);
        var t = o("0969"), n = o("9659");
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(i) {
            o.d(e, i, function() {
                return n[i];
            });
        }(a);
        o("687c");
        var s = o("f0c5"), d = Object(s.a)(n.default, t.b, t.c, !1, null, "25175d16", null, !1, t.a, void 0);
        e.default = d.exports;
    },
    "7f74": function(i, e, o) {
        (function(i) {
            function t(i, e) {
                var o = "undefined" != typeof Symbol && i[Symbol.iterator] || i["@@iterator"];
                if (!o) {
                    if (Array.isArray(i) || (o = n(i)) || e && i && "number" == typeof i.length) {
                        o && (i = o);
                        var t = 0, a = function() {};
                        return {
                            s: a,
                            n: function() {
                                return t >= i.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: i[t++]
                                };
                            },
                            e: function(i) {
                                throw i;
                            },
                            f: a
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var s, d = !0, r = !1;
                return {
                    s: function() {
                        o = o.call(i);
                    },
                    n: function() {
                        var i = o.next();
                        return d = i.done, i;
                    },
                    e: function(i) {
                        r = !0, s = i;
                    },
                    f: function() {
                        try {
                            d || null == o.return || o.return();
                        } finally {
                            if (r) throw s;
                        }
                    }
                };
            }
            function n(i, e) {
                if (i) {
                    if ("string" == typeof i) return a(i, e);
                    var o = Object.prototype.toString.call(i).slice(8, -1);
                    return "Object" === o && i.constructor && (o = i.constructor.name), "Map" === o || "Set" === o ? Array.from(i) : "Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o) ? a(i, e) : void 0;
                }
            }
            function a(i, e) {
                (null == e || e > i.length) && (e = i.length);
                for (var o = 0, t = new Array(e); o < e; o++) t[o] = i[o];
                return t;
            }
            function s(i, e, o, t, n, a, s) {
                try {
                    var d = i[a](s), r = d.value;
                } catch (i) {
                    return void o(i);
                }
                d.done ? e(r) : Promise.resolve(r).then(t, n);
            }
            function d(i) {
                return function() {
                    var e = this, o = arguments;
                    return new Promise(function(t, n) {
                        function a(i) {
                            s(r, t, n, a, d, "next", i);
                        }
                        function d(i) {
                            s(r, t, n, a, d, "throw", i);
                        }
                        var r = i.apply(e, o);
                        a(void 0);
                    });
                };
            }
            function r(i, e) {
                var o = Object.keys(i);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(i);
                    e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(i, e).enumerable;
                    })), o.push.apply(o, t);
                }
                return o;
            }
            function l(i) {
                for (var e = 1; e < arguments.length; e++) {
                    var o = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? r(Object(o), !0).forEach(function(e) {
                        c(i, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(o)) : r(Object(o)).forEach(function(e) {
                        Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return i;
            }
            function c(i, e, o) {
                return e in i ? Object.defineProperty(i, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : i[e] = o, i;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var p = function(i) {
                return i && i.__esModule ? i : {
                    default: i
                };
            }(o("a34a")), u = o("2f62"), h = i.getSystemInfoSync().screenHeight, g = {
                name: "app-diy-page",
                components: {
                    appDiyList: function() {
                        o.e("components/page-component/index/app-diy-list").then(function() {
                            return resolve(o("a401"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-search-for": function() {
                        o.e("components/page-component/app-search-for/app-search-for").then(function() {
                            return resolve(o("73f4"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-swiper": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-swiper/app-swiper") ]).then(function() {
                            return resolve(o("8af3"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    uAnnouncement: function() {
                        o.e("components/page-component/u-announcement/u-announcement").then(function() {
                            return resolve(o("94703"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-navigation-icon": function() {
                        o.e("components/page-component/app-navigation-icon/app-navigation-icon").then(function() {
                            return resolve(o("047c"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-navigation-two-icon": function() {
                        o.e("components/page-component/app-navigation-icon/app-navigation-two-icon").then(function() {
                            return resolve(o("5091b"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-video": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-video/app-video") ]).then(function() {
                            return resolve(o("d824"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-associated-link": function() {
                        o.e("components/page-component/app-associated-link/app-associated-link").then(function() {
                            return resolve(o("1cff"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-special-topic": function() {
                        o.e("components/page-component/app-special-topic/app-special-topic-normal").then(function() {
                            return resolve(o("26a4"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-special-topic-list": function() {
                        o.e("components/page-component/app-special-topic/app-special-topic-list").then(function() {
                            return resolve(o("1bf2"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-image-ad": function() {
                        o.e("components/page-component/app-image-ad/app-image-ad").then(function() {
                            return resolve(o("605d"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-hotspot": function() {
                        o.e("components/basic-component/app-hotspot/app-hotspot").then(function() {
                            return resolve(o("9c0a"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-shop": function() {
                        o.e("components/page-component/app-shop/app-shop").then(function() {
                            return resolve(o("400c"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-copyright": function() {
                        o.e("components/page-component/app-copyright/app-copyright").then(function() {
                            return resolve(o("7fe8"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-user-center": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-user-center-top/app-user-center-top") ]).then(function() {
                            return resolve(o("a527"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-my-order": function() {
                        o.e("components/page-component/app-my-order/app-my-order").then(function() {
                            return resolve(o("d650"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-recommended-product-list": function() {
                        o.e("components/page-component/app-recommended-product/app-recommended-product-list").then(function() {
                            return resolve(o("57ba"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-exclusive-coupon": function() {
                        o.e("components/page-component/app-exclusive-coupon/app-exclusive-coupon").then(function() {
                            return resolve(o("bdfc"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appExclusiveCouponTwo: function() {
                        o.e("components/page-component/app-exclusive-coupon/app-exclusive-coupon-two").then(function() {
                            return resolve(o("9da3"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-diy-timer": function() {
                        o.e("components/page-component/app-diy-timer/app-diy-timer").then(function() {
                            return resolve(o("e2d1"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-goods-shop": function() {
                        o.e("components/page-component/app-good-shop-recommendation/app-good-shop-recommendation").then(function() {
                            return resolve(o("3da2"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-empty": function() {
                        o.e("components/basic-component/app-empty/app-empty").then(function() {
                            return resolve(o("a7c3"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-popup-ad": function() {
                        o.e("components/page-component/app-popup-ad/app-popup-ad").then(function() {
                            return resolve(o("7ec9"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-quick-navigation": function() {
                        o.e("components/page-component/app-quick-navigation/app-quick-navigation").then(function() {
                            return resolve(o("4d92a"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-check-in": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-check-in/app-check-in") ]).then(function() {
                            return resolve(o("bfb2"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-rich": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/basic-component/app-rich/parse") ]).then(function() {
                            return resolve(o("cb0e"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "diy-form": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/diy-form/diy-form") ]).then(function() {
                            return resolve(o("2026"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-diy-form": function() {
                        o.e("components/page-component/app-diy-form/app-diy-form").then(function() {
                            return resolve(o("7d93"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    "app-vip-card": function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-vip-card/app-vip-card") ]).then(function() {
                            return resolve(o("19f0"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appDiyMGoodsList: function() {
                        o.e("components/page-component/app-diy-goods-list/app-diy-m-goods-list").then(function() {
                            return resolve(o("99b9"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appMap: function() {
                        o.e("components/page-component/app-map/app-map").then(function() {
                            return resolve(o("4ba9"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appAd: function() {
                        o.e("components/page-component/app-ad/app-ad").then(function() {
                            return resolve(o("ba36"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appModule: function() {
                        o.e("components/page-component/index/app-module").then(function() {
                            return resolve(o("1722"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appVideoLive: function() {
                        o.e("components/page-component/app-video-live/app-video-live").then(function() {
                            return resolve(o("10df"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appLive: function() {
                        o.e("components/page-component/app-live/app-live").then(function() {
                            return resolve(o("bb25"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    uSwiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/page-component/app-swiper/swiper") ]).then(function() {
                            return resolve(o("b6b4"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appCustomer: function() {
                        o.e("components/page-component/app-customer/app-customer").then(function() {
                            return resolve(o("ef76"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appZhongcao: function() {
                        o.e("components/page-component/app-zhongcao/app-zhongcao").then(function() {
                            return resolve(o("c41a"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appGoodsListCat: function() {
                        o.e("components/page-component/app-goods-list-cat/app-goods-list-cat").then(function() {
                            return resolve(o("7f03"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    appQuickShopCart: function() {
                        o.e("components/page-component/app-goods-list-cat/app-quick-shop-cart").then(function() {
                            return resolve(o("a44b"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                props: {
                    dType: String,
                    homePages: {
                        type: Object,
                        default: function() {
                            return {
                                navs: []
                            };
                        }
                    },
                    scrollTop: {
                        type: Number,
                        default: function() {
                            return 0;
                        }
                    },
                    is_storage: Boolean,
                    pageHide: Boolean,
                    hasTabs: Boolean,
                    theme: Object,
                    coupon_req: Boolean,
                    is_required: Boolean,
                    scroll: Number,
                    page_id: [ Number, String ],
                    is_module: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        }
                    },
                    box: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    first_data: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    isRefresh: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    refresh_num: {
                        type: Number,
                        default: 0
                    },
                    tabbarbool: {
                        type: Boolean,
                        default: !1
                    }
                },
                computed: l(l(l(l({
                    hiddenHeight: function() {
                        var i = this;
                        return function(e) {
                            return "top" === e ? i.systemInfo.statusBarHeight + i.mBarHeight + "px" : "0px";
                        };
                    }
                }, (0, u.mapState)({
                    tabBarNavs: function(i) {
                        return i.mallConfig.navbar.navs;
                    },
                    systemInfo: function(i) {
                        return i.gConfig.systemInfo;
                    },
                    userCenter: function(i) {
                        return i.mallConfig.user_center;
                    },
                    mBarHeight: function(i) {
                        return i.gConfig.mBarHeight;
                    },
                    appSetting: function(i) {
                        return i.mallConfig.mall.setting;
                    },
                    diyImg: function(i) {
                        return i.mallConfig.__wxapp_img.diy;
                    },
                    commonImg: function(i) {
                        return i.mallConfig.__wxapp_img.common;
                    },
                    index_gray: function(i) {
                        return i.mallConfig.mall.setting.is_index_gray;
                    }
                })), {}, {
                    is_index_gray: function() {
                        return this.index_gray && 0 == this.page_id;
                    }
                }, (0, u.mapGetters)({
                    userInfo: "user/info"
                })), (0, u.mapGetters)("iPhoneX", {
                    BotHeight: "getBotHeight",
                    getEmpty: "getEmpty"
                })), {}, {
                    bottomHeight: function() {
                        var e = this;
                        return this.tabBarNavs.find(function(i) {
                            return -1 !== i.url.indexOf("/pages/index/index") && -1 !== i.url.indexOf("page_id=".concat(e.page_id));
                        }) ? i.upx2px(this.BotHeight) + "px" : "0px";
                    },
                    pageScroll: function() {
                        var e = "";
                        console.log(i.getSystemInfoSync(), this.scroll, this.hasTabs);
                        var o = i.getSystemInfoSync().windowHeight, t = i.getSystemInfoSync().screenHeight;
                        return 0 === t && (t = o), i.getSystemInfoSync().titleBarHeight, i.getSystemInfoSync().statusBarHeight, 
                        i.getSystemInfoSync().navigationBarHeight, this.scroll > 0 ? e += "height:calc(".concat(t, "px - ").concat(this.scroll, "px").concat(this.hasTabs ? " - env(safe-area-inset-bottom)" : "", ");overflow-y: auto;") : this.hasTabs && (e += "height:calc(".concat(t, "px - env(safe-area-inset-bottom));overflow-y: auto;")), 
                        e;
                    },
                    diyFormSubmitUrl: function() {
                        return this.$api.diy.page_store;
                    }
                }),
                watch: {
                    homePages: {
                        handler: function(e) {
                            var o = this;
                            e && 0 !== Object.keys(e).length ? (this.initData(), this.is_module ? (e.title && i.setNavigationBarTitle({
                                title: e.title
                            }), e.navs.length > 0 && (this.navs = e.navs.map(function(i) {
                                return {
                                    id: i.id,
                                    name: i.name,
                                    template_id: i.template_id
                                };
                            }), e.navs[this.nav_active].template.data.forEach(function(i) {
                                -1 !== o.only_comp.indexOf(i.id) && (o["".concat(i.id.replace(/-/g, "_"))] = i.data, 
                                "all-goods" === i.id && o.handleGoods(i.data, "all-goods").then(function(e) {
                                    i.data = e;
                                }));
                            }), this.new_box = JSON.parse(JSON.stringify(this.box)), this.first_data.forEach(function(i) {
                                o.splitData(i);
                            }), this.start_pos = this.first_data.length + 1, this.end_pos = this.first_data.length + 1, 
                            this.getData())) : (this.navs = e.navs.map(function(i) {
                                return {
                                    id: i.id,
                                    name: i.name,
                                    template_id: i.template_id
                                };
                            }), this.new_box = e.navs[0].template.data.map(function(i) {
                                var e = {
                                    id: i.id,
                                    index: 0
                                };
                                if (-1 !== o.only_comp.indexOf(i.id)) o["".concat(i.id.replace(/-/g, "_"))] = i.data, 
                                "all-goods" === i.id && o.handleGoods(i.data, "all-goods").then(function(e) {
                                    i.data = e;
                                }); else if (-1 !== o.basic_comp.indexOf(i.id)) {
                                    var t = "".concat(i.id.replace(/-/g, "_"), "_list");
                                    o[t].push(i.data), e.index = o[t].length - 1;
                                } else "goods" === i.id ? (o.handleGoods(i.data).then(function(e) {
                                    i.data = e;
                                }), o.goods_list.push(i.data), e.index = o.goods_list.length - 1) : -1 !== o.plugin_goods.indexOf(i.id) ? (o.plugin_goods_list[i.id] ? o.plugin_goods_list[i.id].push(i.data) : o.plugin_goods_list[i.id] = [ i.data ], 
                                e.index = o.plugin_goods_list[i.id].length - 1) : "form" === i.id && (o.form_list.push(i), 
                                e.index = o.form_list.length - 1);
                                return e;
                            }))) : this.new_box = [];
                        },
                        immediate: !0
                    }
                },
                data: function() {
                    return {
                        nav_active: 0,
                        mp_link_top: !1,
                        coupon_url: this.$api.diy.receive,
                        plugin_goods: [ "weekly-buy", "pintuan", "advance", "wholesale", "gift", "booking", "pick", "bargain", "composition", "lottery", "flash-sale", "miaosha", "integral-mall", "step", "exchange", "mystery" ],
                        navs: [],
                        new_box: [],
                        background: null,
                        search_list: [],
                        nav_list: [],
                        banner_list: [],
                        notice_list: [],
                        topic_list: [],
                        link_list: [],
                        rubik_list: [],
                        video_list: [],
                        goods_list: [],
                        store_list: [],
                        copyright_list: [],
                        check_in_list: [],
                        user_info_list: [],
                        user_order_list: [],
                        map_list: [],
                        mp_link: {},
                        image_text_list: [],
                        coupon_list: [],
                        timer_list: [],
                        mch_list: [],
                        plugin_goods_list: {},
                        vip_card_list: [],
                        live_list: [],
                        zhongcao_list: [],
                        empty_list: [],
                        ad: {},
                        modal: null,
                        quick_nav: null,
                        module_list: [],
                        customer_list: [],
                        form_module: {},
                        form_list: [],
                        video_live: {},
                        all_goods: {},
                        quick_shop: {},
                        only_comp: [ "background", "modal", "quick-nav", "mp-link", "ad", "form-module", "video-live", "all-goods", "quick-shop" ],
                        basic_comp: [ "search", "nav", "banner", "notice", "topic", "link", "rubik", "video", "store", "copyright", "check-in", "user-info", "user-order", "map", "image-text", "coupon", "timer", "mch", "vip-card", "live", "zhongcao", "empty", "module", "customer" ],
                        start_pos: 1,
                        end_pos: 1,
                        show_pos: 1,
                        is_show_next: !0,
                        loading: !1,
                        all_goods_loading: !1,
                        all_goods_page: 1,
                        all_goods_more: !0,
                        catFixed: !1,
                        cartInfo: {}
                    };
                },
                filters: {
                    getObje: function(i) {
                        if (i) return {
                            template_id: i.template_id
                        };
                    }
                },
                methods: {
                    initData: function() {
                        this.new_box = [], this.show_pos = 1, this.search_list = [], this.nav_list = [], 
                        this.banner_list = [], this.notice_list = [], this.topic_list = [], this.link_list = [], 
                        this.rubik_list = [], this.video_list = [], this.goods_list = [], this.store_list = [], 
                        this.copyright_list = [], this.check_in_list = [], this.user_info_list = [], this.user_order_list = [], 
                        this.map_list = [], this.mp_link = {}, this.image_text_list = [], this.coupon_list = [], 
                        this.timer_list = [], this.mch_list = [], this.plugin_goods_list = {}, this.vip_card_list = [], 
                        this.live_list = [], this.zhongcao_list = [], this.empty_list = [], this.ad = {}, 
                        this.modal = null, this.quick_nav = null, this.module_list = [], this.customer_list = [], 
                        this.form_module = {}, this.form_list = [], this.video_live = {}, this.all_goods = {}, 
                        this.all_goods_page = 1, this.all_goods_more = !0;
                    },
                    cloneData: function(i) {
                        return JSON.parse(JSON.stringify(i));
                    },
                    upDiyGoods: function(i, e) {
                        var o = this, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", n = i.catList[e], a = n.id, s = n.goodsNum, d = n.staticGoods, r = n.goodsList;
                        d ? (i.list = r, this.$forceUpdate()) : this.$request({
                            url: this.$api.diy.cat_goods_list,
                            data: {
                                cat_id: a,
                                goodsNum: s,
                                order_by: i.orderBy,
                                type: "quick-shop" === t ? "quick" : ""
                            }
                        }).then(function(e) {
                            0 === e.code && (i.list = e.data.list.map(function(i) {
                                return 1 != i.is_negotiable ? (i.priceList = o.handlePrice(i.price), 1 === i.is_level && (i.level_price > 0 || 0 == i.level_price) && (i.memberList = o.handlePrice(i.level_price))) : i.priceList = o.handlePrice(o.appSetting.negotiable_text), 
                                i;
                            }), o.$forceUpdate());
                        });
                    },
                    upDiyAllGoods: function() {
                        var e = this, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
                        if (!this.all_goods_loading && this.all_goods_more) {
                            this.all_goods_loading = !0;
                            var t = "top" === this.all_goods.catPosition && 3 == this.all_goods.listStyle ? 30 : 20, n = {
                                page: this.all_goods_page,
                                goodsNum: t,
                                order_by: this.all_goods.orderBy
                            };
                            o > -1 && (n.cat_id = this.all_goods.catList[o].id), this.$request({
                                url: this.$api.diy.cat_goods_list,
                                method: "get",
                                data: n
                            }).then(function(o) {
                                if (0 === o.code) {
                                    var n = o.data.list.map(function(i) {
                                        return 1 != i.is_negotiable ? (i.priceList = e.handlePrice(i.price), 1 === i.is_level && (i.level_price > 0 || 0 == i.level_price) && (i.memberList = e.handlePrice(i.level_price))) : i.priceList = e.handlePrice(e.appSetting.negotiable_text), 
                                        i;
                                    });
                                    1 == e.all_goods_page ? e.all_goods.list = n : e.all_goods.list = e.all_goods.list.concat(n), 
                                    n.length == t ? (e.all_goods_more = !0, e.all_goods_page++) : e.all_goods_more = !1;
                                } else i.showModal({
                                    title: "提示",
                                    content: o.msg
                                });
                                e.all_goods_loading = !1;
                            }).catch(function() {
                                e.all_goods_loading = !1;
                            });
                        }
                    },
                    changeTopNav: function(e) {
                        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", n = {};
                        if (-1 === o) {
                            if (this.all_goods_loading) return;
                            this.all_goods.activeCurrent = e, n = this.all_goods, this.all_goods_page = 1, this.all_goods_more = !0, 
                            this.upDiyAllGoods(e);
                        } else n = "quick-shop" === t ? this.quick_shop : this.goods_list[o], n.activeCurrent = e, 
                        this.upDiyGoods(n, e, t);
                        for (var a = 0, s = 0; s < n.catList.length; s++) {
                            if (s === e) {
                                a += n.catList[s].width / 2;
                                break;
                            }
                            a += n.catList[s].width + i.upx2px(44);
                        }
                        n.scrollLeft = a - i.upx2px(335) || 0;
                    },
                    changeNav: function(i) {
                        this.nav_active = i, this.mp_link_top = !1;
                    },
                    rubikHotspot: function(i) {
                        return i && i.link && (i.link.url = i.link.value, i.link.openType = i.link.open_type), 
                        i;
                    },
                    mpLink: function(i) {
                        "top" === i && (this.mp_link_top = !0);
                    },
                    transLabelPosition: function(i) {
                        switch (i = Number(i)) {
                          case 3:
                            return "top";

                          case 2:
                            return "inset";

                          default:
                            return "left";
                        }
                    },
                    transLabelBackgroundPosition: function(i) {
                        switch (+i) {
                          case 1:
                            return "left top";

                          case 2:
                            return "center top";

                          case 3:
                            return "right top";

                          case 4:
                            return "left center";

                          case 5:
                            return "center center";

                          case 6:
                            return "right center";

                          case 7:
                            return "left bottom";

                          case 8:
                            return "center bottom";

                          case 9:
                            return "right bottom";

                          default:
                            return "center";
                        }
                    },
                    transLabelBackgroundRepeat: function(i) {
                        switch (+i) {
                          case 1:
                            return "no-repeat";

                          case 2:
                            return "repeat-x";

                          case 3:
                            return "repeat-y";

                          case 4:
                            return "repeat";

                          default:
                            return "no-repeat";
                        }
                    },
                    mpLinkError: function() {
                        this.mp_link_top = !1;
                    },
                    buyProduct: function(i) {
                        this.$emit("buyProduct", i);
                    },
                    handleScrolltolower: function() {
                        if (this.isRefresh) this.is_show_next = !0; else if (this.show_pos <= this.new_box.length) this.loading ? this.is_show_next = !1 : (this.is_show_next = !0, 
                        this.getData()); else if (this.show_pos == this.new_box.length + 1 && this.all_goods && "{}" !== JSON.stringify(this.all_goods) && this.all_goods_more) if (this.all_goods.showCat) {
                            if ("left" === this.all_goods.catPosition && this.all_goods_page > 1) return;
                            this.upDiyAllGoods(this.all_goods.activeCurrent);
                        } else this.upDiyAllGoods();
                    },
                    handleGoods: function() {
                        var i = d(p.default.mark(function i(e) {
                            var o, n, a, s, d, r, l, c = arguments;
                            return p.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    if (o = c.length > 1 && void 0 !== c[1] ? c[1] : "", !e.showCat) {
                                        i.next = 18;
                                        break;
                                    }
                                    e.activeCurrent = 0, e.scrollLeft = 0, n = t(e.catList);
                                    try {
                                        for (n.s(); !(a = n.n()).done; ) if ((s = a.value).goodsList) {
                                            d = t(s.goodsList);
                                            try {
                                                for (d.s(); !(r = d.n()).done; ) 1 != (l = r.value).is_negotiable ? (l.priceList = this.handlePrice(l.price), 
                                                1 === l.is_level && (l.level_price > 0 || 0 == l.level_price) && (l.memberList = this.handlePrice(l.level_price))) : l.priceList = this.handlePrice(this.appSetting.negotiable_text);
                                            } catch (i) {
                                                d.e(i);
                                            } finally {
                                                d.f();
                                            }
                                        }
                                    } catch (i) {
                                        n.e(i);
                                    } finally {
                                        n.f();
                                    }
                                    return i.next = 8, e.catList;

                                  case 8:
                                    if (i.t0 = i.sent, !i.t0) {
                                        i.next = 11;
                                        break;
                                    }
                                    i.t0 = e.catList.length > 0;

                                  case 11:
                                    if (!i.t0) {
                                        i.next = 15;
                                        break;
                                    }
                                    "all-goods" === o ? this.upDiyAllGoods(0) : this.upDiyGoods(e, 0, o), i.next = 16;
                                    break;

                                  case 15:
                                    e.list = [];

                                  case 16:
                                    i.next = 21;
                                    break;

                                  case 18:
                                    if ("all-goods" !== o) {
                                        i.next = 21;
                                        break;
                                    }
                                    return i.next = 21, this.upDiyAllGoods();

                                  case 21:
                                    return i.abrupt("return", e);

                                  case 22:
                                  case "end":
                                    return i.stop();
                                }
                            }, i, this);
                        }));
                        return function(e) {
                            return i.apply(this, arguments);
                        };
                    }(),
                    getData: function() {
                        var e = this;
                        if (this.show_pos = this.end_pos, this.end_pos !== this.new_box.length + 1) {
                            for (var o = this.new_box.length, t = this.end_pos, n = 0, a = t; a <= o; a++) if (this.new_box[a - 1].height && (n += this.new_box[a - 1].height), 
                            n > 4 * h || a == o) {
                                t = a;
                                break;
                            }
                            this.loading = !0, this.$request({
                                url: this.$api.index.diy_split,
                                data: {
                                    page_id: this.homePages.id,
                                    start_pos: this.start_pos,
                                    end_pos: t
                                }
                            }).then(function(o) {
                                e.loading = !1, 0 == o.code ? (o.data.data.forEach(function(i, o) {
                                    var t = e.start_pos + o - 1;
                                    e.new_box[t].id === i.id ? e.splitData(i) : e.$storage.removeStorageSync("INDEX_MALL");
                                }), e.start_pos = t + 1, e.end_pos = t + 1, e.is_show_next || (e.is_show_next = !0, 
                                e.getData())) : i.showToast({
                                    title: o.msg,
                                    icon: "none"
                                });
                            }).catch(function() {
                                e.loading = !1;
                            });
                        }
                    },
                    splitData: function(i) {
                        -1 !== this.only_comp.indexOf(i.id) ? (this["".concat(i.id.replace(/-/g, "_"))] = i.data, 
                        "all-goods" === i.id ? this.handleGoods(i.data, "all-goods").then(function(e) {
                            i.data = e;
                        }) : "quick-shop" === i.id && (this.handleGoods(i.data, "quick-shop").then(function(e) {
                            i.data = e;
                        }), this.getCart())) : -1 !== this.basic_comp.indexOf(i.id) ? this["".concat(i.id.replace(/-/g, "_"), "_list")].push(i.data) : "goods" === i.id ? (this.handleGoods(i.data).then(function(e) {
                            i.data = e;
                        }), this.goods_list.push(i.data)) : -1 !== this.plugin_goods.indexOf(i.id) ? this.plugin_goods_list[i.id] ? this.plugin_goods_list[i.id].push(i.data) : this.plugin_goods_list[i.id] = [ i.data ] : "form" === i.id && this.form_list.push(i);
                    },
                    handleAllGoodsFixed: function() {
                        var e = this;
                        this.show_pos > this.new_box.length && this.all_goods.showCat && "top" === this.all_goods.catPosition && 3 == this.all_goods.catStyle && i.createSelectorQuery().in(this).select("#all-goods-scroll").boundingClientRect(function(i) {
                            e.catFixed = i.top <= e.scroll;
                        }).exec();
                    },
                    getCart: function() {
                        var e = this, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                        o && i.showLoading(), this.$request({
                            url: this.$api.cart.diy_info
                        }).then(function(t) {
                            0 == t.code && (e.cartInfo = l(l({}, t.data), {}, {
                                price: (t.data.total_price - t.data.member_discount).toFixed(2)
                            })), o && i.hideLoading();
                        });
                    }
                }
            };
            e.default = g;
        }).call(this, o("543d").default);
    },
    9659: function(i, e, o) {
        o.r(e);
        var t = o("7f74"), n = o.n(t);
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(i) {
            o.d(e, i, function() {
                return t[i];
            });
        }(a);
        e.default = n.a;
    },
    "9a26": function(i, e, o) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/index/app-diy-page-create-component", {
    "components/page-component/index/app-diy-page-create-component": function(i, e, o) {
        o("543d").createComponent(o("6a38"));
    }
}, [ [ "components/page-component/index/app-diy-page-create-component" ] ] ]);