(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/index/app-index" ], {
    "03e6": function(n, e, t) {
        (function(n) {
            function o(n, e) {
                var t = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function i(n) {
                for (var e = 1; e < arguments.length; e++) {
                    var t = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(t), !0).forEach(function(e) {
                        a(n, e, t[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : o(Object(t)).forEach(function(e) {
                        Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(t, e));
                    });
                }
                return n;
            }
            function a(n, e, t) {
                return e in n ? Object.defineProperty(n, e, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[e] = t, n;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var c = t("2f62"), p = {
                name: "app-index",
                data: function() {
                    return {
                        newPage: [],
                        time: -1,
                        tempList: [],
                        timeout: 0,
                        flash_salse: !1
                    };
                },
                props: {
                    homePages: {
                        type: [ Array, Object ],
                        default: function() {
                            return [];
                        }
                    },
                    is_storage: Boolean,
                    pageHide: Boolean,
                    theme: Object,
                    page_id: Number,
                    is_required: Boolean,
                    coupon_req: Boolean,
                    isShowAttention: Boolean,
                    refresh_num: {
                        type: Number,
                        default: 0
                    }
                },
                computed: i(i(i({}, (0, c.mapState)("mallConfig", {
                    mall: function(n) {
                        return n.mall;
                    },
                    appImg: function(n) {
                        return n.__wxapp_img.mall;
                    },
                    appSetting: function(n) {
                        return n.mall.setting;
                    },
                    is_index_gray: function(n) {
                        return n.mall.setting.is_index_gray;
                    }
                })), (0, c.mapGetters)({
                    userInfo: "user/info"
                })), (0, c.mapState)({
                    platform: function(n) {
                        return n.gConfig.systemInfo.platform;
                    }
                })),
                watch: {
                    homePages: {
                        handler: function(e) {
                            var t = this;
                            setTimeout(function(e) {
                                n.setNavigationBarTitle({
                                    title: t.mall.name
                                });
                            }, void 0 === this.mall.name ? 500 : 0), this.tempList = [], clearTimeout(this.timeout), 
                            this.newPage = [], this.tempList = this.cloneData(e), this.splitData();
                        },
                        immediate: !0
                    }
                },
                methods: {
                    changeCoupon: function(n, e) {
                        this.newPage[e].coupons[n].is_receive = "1";
                    },
                    buyProduct: function(n) {
                        this.$emit("buyProduct", n);
                    },
                    splitData: function() {
                        var n = this;
                        if (this.tempList.length) {
                            var e = this.tempList[0];
                            this.newPage.push(e), this.tempList.splice(0, 1), this.tempList.length && (this.timeout = setTimeout(function() {
                                n.splitData();
                            }, 100));
                        }
                    },
                    cloneData: function(n) {
                        return JSON.parse(JSON.stringify(n));
                    },
                    router: function(e) {
                        !e.video_url || 1 != this.getVideo || "flash_sale" != e.sign && "miaosha" != e.sign && "mch" != e.sign && "" != e.sign ? n.navigateTo({
                            url: e.page_url
                        }) : n.navigateTo({
                            url: "/pages/goods/video?goods_id=".concat(e.id, "&sign=").concat(e.sign)
                        });
                    }
                },
                components: {
                    "app-search-for": function() {
                        t.e("components/page-component/app-search-for/app-search-for").then(function() {
                            return resolve(t("73f4"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-swiper": function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-swiper/app-swiper") ]).then(function() {
                            return resolve(t("8af3"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-navigation-icon": function() {
                        t.e("components/page-component/app-navigation-icon/app-navigation-icon").then(function() {
                            return resolve(t("047c"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uAnnouncement: function() {
                        t.e("components/page-component/u-announcement/u-announcement").then(function() {
                            return resolve(t("94703"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-video": function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/page-component/app-video/app-video") ]).then(function() {
                            return resolve(t("d824"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-topic": function() {
                        t.e("components/page-component/app-special-topic/app-special-topic-normal").then(function() {
                            return resolve(t("26a4"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-exclusive-coupon": function() {
                        t.e("components/page-component/app-exclusive-coupon/app-exclusive-coupon").then(function() {
                            return resolve(t("bdfc"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-image-ad": function() {
                        t.e("components/page-component/app-image-ad/app-image-ad").then(function() {
                            return resolve(t("605d"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "bd-g-s-r": function() {
                        t.e("components/page-component/app-good-shop-recommendation/app-good-shop-recommendation").then(function() {
                            return resolve(t("3da2"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-quick-navigation": function() {
                        t.e("components/page-component/app-quick-navigation/app-quick-navigation").then(function() {
                            return resolve(t("4d92a"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-popup-ad": function() {
                        t.e("components/page-component/app-popup-ad/app-popup-ad").then(function() {
                            return resolve(t("7ec9"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    "app-index-cat": function() {
                        t.e("components/page-component/app-index-cat/app-index-cat").then(function() {
                            return resolve(t("258a"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uWholesale: function() {
                        t.e("components/page-component/u-index-plugins/u-wholesale").then(function() {
                            return resolve(t("817f"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uAdvance: function() {
                        t.e("components/page-component/u-index-plugins/u-advance").then(function() {
                            return resolve(t("5fc6"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uMiaosha: function() {
                        t.e("components/page-component/u-index-plugins/u-miaosha").then(function() {
                            return resolve(t("a40b"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uPintuan: function() {
                        t.e("components/page-component/u-index-plugins/u-pintuan").then(function() {
                            return resolve(t("6799"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uBooking: function() {
                        t.e("components/page-component/u-index-plugins/u-booking").then(function() {
                            return resolve(t("2b78"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uFlashSale: function() {
                        t.e("components/page-component/u-index-plugins/u-flash-sale").then(function() {
                            return resolve(t("ed45"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uPick: function() {
                        t.e("components/page-component/u-index-plugins/u-pick").then(function() {
                            return resolve(t("d44c"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    uWeeklyBuy: function() {
                        t.e("components/page-component/u-index-plugins/u-weekly-buy").then(function() {
                            return resolve(t("3f21"));
                        }.bind(null, t)).catch(t.oe);
                    }
                }
            };
            e.default = p;
        }).call(this, t("543d").default);
    },
    "046c1": function(n, e, t) {
        var o = t("94ef");
        t.n(o).a;
    },
    "52c3": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this, e = (n.$createElement, n._self._c, n.__map(n.newPage, function(e, t) {
                return {
                    $orig: n.__get_orig(e),
                    m0: "search" !== e.key && "banner" !== e.key && "cat" !== e.key && "home_nav" === e.key ? Number(e.row_num) : null,
                    m1: "search" !== e.key && "banner" !== e.key && "cat" !== e.key && "home_nav" !== e.key && "notice" !== e.key && "video" !== e.key && "topic" === e.key ? Number(e.topic_num) : null
                };
            }));
            n.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
    },
    "5fb2": function(n, e, t) {
        t.r(e);
        var o = t("03e6"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = i.a;
    },
    "6f02": function(n, e, t) {
        t.r(e);
        var o = t("52c3"), i = t("5fb2");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        t("046c1");
        var c = t("f0c5"), p = Object(c.a)(i.default, o.b, o.c, !1, null, "564fe2a3", null, !1, o.a, void 0);
        e.default = p.exports;
    },
    "94ef": function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/index/app-index-create-component", {
    "components/page-component/index/app-index-create-component": function(n, e, t) {
        t("543d").createComponent(t("6f02"));
    }
}, [ [ "components/page-component/index/app-index-create-component" ] ] ]);