(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-exclusive-coupon/app-exclusive-coupon" ], {
    "13c1": function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    "29ce": function(e, t, n) {
        var i = n("d9ae");
        n.n(i).a;
    },
    aa4c: function(e, t, n) {
        n.r(t);
        var i = n("c193"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        t.default = o.a;
    },
    bdfc: function(e, t, n) {
        n.r(t);
        var i = n("13c1"), o = n("aa4c");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("29ce");
        var u = n("f0c5"), r = Object(u.a)(o.default, i.b, i.c, !1, null, "c6698f2e", null, !1, i.a, void 0);
        t.default = r.exports;
    },
    c193: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                name: "app-exclusive-coupon",
                props: {
                    receiveBg: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        },
                        required: !1
                    },
                    textColor: {
                        type: String,
                        default: function() {
                            return "#ffffff";
                        },
                        required: !1
                    },
                    unclaimedBg: {
                        type: String,
                        default: function() {
                            return "";
                        },
                        required: !1
                    },
                    index: {
                        type: Number,
                        required: !1
                    },
                    sign: {
                        type: String,
                        required: !1
                    },
                    showTop: {
                        type: Boolean,
                        default: function() {
                            return !0;
                        },
                        required: !1
                    },
                    noneColor: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        },
                        required: !1
                    },
                    background: {
                        type: String,
                        required: !1
                    },
                    page_id: {
                        type: Number,
                        required: !1
                    },
                    padding: {
                        type: Number,
                        default: function() {
                            return 0;
                        },
                        required: !1
                    },
                    is_required: {
                        type: Boolean,
                        required: !1
                    },
                    coupon_req: {
                        type: Boolean,
                        required: !1
                    },
                    refresh_num: {
                        type: Number,
                        default: 0
                    }
                },
                data: function() {
                    return {
                        coupon_list: [],
                        tempList: []
                    };
                },
                computed: {
                    allWidth: function() {
                        return 750 - 2 * this.padding;
                    },
                    receiveTip: function() {
                        var e = "立即领取";
                        return "integral-mall" === this.sign && (e = "立即兑换"), e;
                    }
                },
                watch: {
                    refresh_num: function(e) {
                        this.initData();
                    }
                },
                methods: {
                    receive: function(t) {
                        var n = this, i = this.coupon_list;
                        if ("integral-mall" !== this.sign) {
                            if (1 == i[t].is_receive) return e.showToast({
                                mask: !0,
                                title: "已领取",
                                icon: "none"
                            }), !0;
                            e.showLoading({
                                mask: !0,
                                title: "领取中"
                            }), this.$request({
                                url: this.$api.coupon.receive,
                                data: {
                                    coupon_id: i[t].id
                                }
                            }).then(function(o) {
                                if (e.hideLoading(), 0 === o.code) {
                                    0 == o.data.rest && (o.data.is_receive = 1), n.coupon_list[t] = Object.assign(i[t], o.data);
                                    var a = n.$storage.getStorageSync("INDEX_MALL");
                                    a.home_pages[n.index].list = n.coupon_list, n.$storage.setStorageSync("INDEX_MALL", a), 
                                    n.$store.dispatch("page/actionSetCoupon", {
                                        list: [ n.coupon_list[t] ],
                                        type: "receive"
                                    });
                                } else e.showModal({
                                    title: "提示",
                                    content: o.msg,
                                    showCancel: !1
                                });
                            }).catch(function() {
                                e.hideLoading();
                            });
                        } else this.$jump({
                            url: i[t].page_url,
                            open_type: "navigate"
                        });
                    },
                    loadData: function() {
                        var e = this;
                        this.$request({
                            url: this.$api.index.extra,
                            data: {
                                type: "mall",
                                key: "coupon",
                                page_id: this.page_id,
                                index: this.index
                            }
                        }).then(function(t) {
                            if (e.coupon_list = t.data, 0 === e.page_id) {
                                var n = e.$storage.getStorageSync("INDEX_MALL");
                                n.home_pages[e.index] && (n.home_pages[e.index].list = t.data), e.$storage.setStorageSync("INDEX_MALL", n);
                            }
                        });
                    },
                    cloneData: function(e) {
                        return JSON.parse(JSON.stringify(e));
                    },
                    splitData: function() {
                        var e = this;
                        if (this.tempList.length) {
                            var t = this.tempList[0];
                            this.coupon_list.push(t), this.tempList.splice(0, 1), this.tempList.length && setTimeout(function() {
                                e.splitData();
                            }, 300);
                        }
                    },
                    route: function() {
                        e.navigateTo({
                            url: "/pages/coupon/list/list"
                        });
                    },
                    initData: function() {
                        if (this.coupon_req) this.coupon_list = this.list; else if (this.is_required) this.loadData(); else {
                            var e = this.$storage.getStorageSync("INDEX_MALL");
                            this.coupon_list = e.home_pages[this.index].list ? e.home_pages[this.index].list : [];
                        }
                    }
                },
                mounted: function() {
                    this.initData();
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    d9ae: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-exclusive-coupon/app-exclusive-coupon-create-component", {
    "components/page-component/app-exclusive-coupon/app-exclusive-coupon-create-component": function(e, t, n) {
        n("543d").createComponent(n("bdfc"));
    }
}, [ [ "components/page-component/app-exclusive-coupon/app-exclusive-coupon-create-component" ] ] ]);