(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-exclusive-coupon/app-exclusive-coupon-two" ], {
    "5b07": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, [ 1, 2, 3 ].indexOf(e.coupon_list.length)), n = e.coupon_list.length > 0 ? e.__map(e.coupon_list, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    s0: e.__get_style([ e.couponBoxStyle(t, n) ])
                };
            }) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    l0: n
                }
            });
        }, a = [];
    },
    "85f6f": function(e, t, n) {},
    "9da3": function(e, t, n) {
        n.r(t);
        var o = n("5b07"), a = n("b35c");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("e4ed");
        var c = n("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, "4b9f3d9a", null, !1, o.a, void 0);
        t.default = u.exports;
    },
    b35c: function(e, t, n) {
        n.r(t);
        var o = n("d7c2"), a = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = a.a;
    },
    d7c2: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                name: "app-exclusive-coupon-two",
                props: {
                    receiveBg: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    textColor: {
                        type: String,
                        default: function() {
                            return "#ffffff";
                        }
                    },
                    unclaimedBg: {
                        type: String,
                        default: function() {
                            return "";
                        }
                    },
                    index: {
                        type: Number
                    },
                    sign: {
                        type: String
                    },
                    noneColor: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    background: String,
                    page_id: Number,
                    template_id: Number,
                    is_required: Boolean,
                    coupon_req: Boolean,
                    couponBg: {
                        type: String,
                        default: "#D9BC8B"
                    },
                    addType: String,
                    couponBgType: {
                        type: String,
                        default: function() {
                            return "#pure";
                        }
                    },
                    dIndex: {
                        type: Array,
                        default: function() {
                            return [ 0, 0 ];
                        }
                    },
                    mIndex: {
                        type: Array,
                        default: function() {
                            return [ 0, 0 ];
                        }
                    },
                    dType: String,
                    paddingY: {
                        type: Number,
                        default: 16
                    }
                },
                data: function() {
                    return {
                        coupon_list: []
                    };
                },
                computed: {
                    receiveTip: function() {
                        var e = "立即领取";
                        return "integral-mall" === this.sign && (e = "立即兑换"), e;
                    },
                    couponBoxStyle: function() {
                        var t = this;
                        return function(n, o) {
                            var a, i, c = t.coupon_list, u = 750 / e.getSystemInfoSync().windowWidth;
                            switch (c.length) {
                              case 1:
                                a = "".concat(parseInt(702 / u), "px");
                                break;

                              case 2:
                                a = "".concat(parseInt(341 / u), "px");
                                break;

                              case 3:
                                a = "".concat(parseInt(220 / u), "px");
                                break;

                              default:
                                a = "".concat(parseInt(274 / u), "px");
                            }
                            var r = {
                                "margin-left": "".concat(20 / u, "px")
                            };
                            return 0 === o && (r = Object.assign(r, {
                                "margin-left": "".concat(24 / u, "px")
                            })), o === t.coupon_list.length - 1 && (r = Object.assign(r, {
                                "margin-right": "".concat(24 / u, "px")
                            })), i = n.is_receive > 0 ? "#B4B4B4" : "gradient" === t.couponBgType ? "linear-gradient(to left, " + t.couponBg + "," + t.$utils.colorRgba(t.couponBg, .5) + ")" : t.couponBg, 
                            Object.assign(r, {
                                background: i,
                                width: a,
                                "min-width": c.length > 3 ? a : "auto"
                            });
                        };
                    }
                },
                methods: {
                    flushCache: function(e) {
                        if (0 == this.page_id) {
                            var t = this.$storage.getStorageSync("INDEX_MALL"), n = this.dIndex, o = this.mIndex;
                            "module" === this.dType ? t.home_pages.navs[o[0]].template.data[o[1]].data.list[n[0]].data[n[1]].data.coupon_list = e : t.home_pages.navs[n[0]].template.data[n[1]].data.coupon_list = e, 
                            this.$storage.setStorageSync("INDEX_MALL", t);
                        }
                    },
                    receive: function(t) {
                        var n = this, o = this.coupon_list;
                        if ("integral-mall" != this.sign) {
                            if (1 == o[t].is_receive) return e.showToast({
                                mask: !0,
                                title: "已领取",
                                icon: "none"
                            }), !0;
                            e.showLoading({
                                mask: !0,
                                title: "领取中"
                            }), this.$request({
                                url: this.$api.coupon.receive,
                                data: {
                                    coupon_id: o[t].id,
                                    mch_id: o[t].mch_id > 0 ? o[t].mch_id : 0
                                }
                            }).then(function(o) {
                                if (e.hideLoading(), 0 === o.code) {
                                    0 == o.data.rest && (n.coupon_list[t].is_receive = "1");
                                    var a = n.coupon_list;
                                    n.flushCache(a), n.$store.dispatch("page/actionSetCoupon", {
                                        list: [ Object.assign(a[t], o.data) ],
                                        type: "receive"
                                    });
                                } else e.showToast({
                                    title: o.msg,
                                    icon: "none"
                                });
                            }).catch(function() {
                                e.hideLoading();
                            });
                        } else this.$jump({
                            url: o[t].page_url,
                            open_type: "navigate"
                        });
                    },
                    loadData: function() {
                        var e = this;
                        this.$request({
                            url: this.$api.index.extra,
                            data: {
                                type: "mall",
                                key: "coupon",
                                page_id: this.page_id,
                                index: this.index
                            }
                        }).then(function(t) {
                            if (e.coupon_list = t.data, 0 === e.page_id) {
                                var n = e.$storage.getStorageSync("INDEX_MALL");
                                n.home_pages[e.index] && (n.home_pages[e.index].list = e.coupon_list), e.$storage.setStorageSync("INDEX_MALL", n);
                            }
                        });
                    }
                },
                mounted: function() {
                    if (this.coupon_req) this.coupon_list = this.list; else if (this.is_required) this.loadData(); else {
                        var e = this.$storage.getStorageSync("INDEX_MALL");
                        this.coupon_list = e && e.home_pages[this.index] ? e.home_pages[this.index].list : [];
                    }
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    e4ed: function(e, t, n) {
        var o = n("85f6f");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-exclusive-coupon/app-exclusive-coupon-two-create-component", {
    "components/page-component/app-exclusive-coupon/app-exclusive-coupon-two-create-component": function(e, t, n) {
        n("543d").createComponent(n("9da3"));
    }
}, [ [ "components/page-component/app-exclusive-coupon/app-exclusive-coupon-two-create-component" ] ] ]);