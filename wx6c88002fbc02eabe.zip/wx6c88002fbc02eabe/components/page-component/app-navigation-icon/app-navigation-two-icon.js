(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-navigation-icon/app-navigation-two-icon" ], {
    1908: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                name: "app-navigation-two-icon",
                props: {
                    background: {
                        type: String,
                        default: function() {
                            return "#ffffff";
                        }
                    },
                    imgHeight: {
                        type: Number,
                        default: function() {
                            return 200;
                        }
                    },
                    modeType: {
                        type: String,
                        default: function() {
                            return "img";
                        }
                    },
                    color: {
                        type: String,
                        default: function() {
                            return "#333333";
                        }
                    },
                    columns: {
                        type: Number,
                        default: function() {
                            return 3;
                        }
                    },
                    navs: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    navType: String,
                    aloneNum: Number,
                    lineNum: Number,
                    swiperType: String,
                    swiperColor: String,
                    swiperNoColor: String,
                    tempIndex: Number,
                    bgType: String,
                    backgroundPicUrl: String
                },
                data: function() {
                    return {
                        current: 0,
                        multiswiper: "80px",
                        defaultInfo: {
                            imgHeight: 88,
                            left: 32,
                            limit: 30
                        }
                    };
                },
                onLoad: function() {},
                methods: {
                    calcHeight: function() {
                        var t = this;
                        setTimeout(function() {
                            n.createSelectorQuery().in(t).select(".nav-swiper-".concat(t.tempIndex)).boundingClientRect(function(n) {
                                n && (t.multiswiper = n.height + "px");
                            }).exec();
                        }, 500);
                    },
                    changeSwiper: function(n) {
                        this.current = n.detail.current;
                    },
                    group: function(n, t) {
                        t = parseInt(t);
                        for (var e = 0, i = []; e < n.length; ) i.push(n.slice(e, e += t));
                        return i;
                    },
                    addNull: function() {
                        var n = this.columns, t = this.navs.length, e = t % n == 0 ? 0 : n - t % n;
                        return this.navs.concat(new Array(e).fill({
                            url: "",
                            openType: "",
                            icon_url: "",
                            name: ""
                        }));
                    }
                },
                created: function() {
                    this.calcHeight();
                },
                beforeUpdate: function() {
                    this.calcHeight();
                },
                computed: {
                    beforeMargin: function() {
                        var n = this;
                        return function(t, e) {
                            return "image" === n.modeType ? {
                                marginLeft: 0 === t ? "24rpx" : "20rpx",
                                marginRight: t === e.length - 1 ? "24rpx" : "0"
                            } : {
                                marginRight: t === e.length - 1 ? "auto" : "0",
                                marginLeft: "auto"
                            };
                        };
                    },
                    aloneNav: function() {
                        return this.navs;
                    },
                    bgStyle: function() {
                        return "color" === this.bgType ? "background-color: ".concat(this.background, ";") : "pic" === this.bgType ? "background-size: 100% 100%;background-repeat: no-repeat;background-position: center center;background-image: url(".concat(this.backgroundPicUrl, ")") : void 0;
                    },
                    newNavs: function() {
                        var n = this.addNull();
                        return this.group(n, this.columns);
                    },
                    muitiNavs: function() {
                        var n = this.addNull();
                        return n = this.group(n, this.columns), n = this.group(n, this.lineNum);
                    },
                    aloneWidth: function() {
                        return "100rpx";
                    },
                    formatB: function() {
                        var t = this;
                        return function(e) {
                            if ("image" === t.modeType) {
                                var i = 1.7 * t.imgHeight, o = {
                                    width: "".concat(i, "rpx"),
                                    "min-width": "".concat(i, "rpx"),
                                    marginLeft: "20rpx"
                                };
                                return 0 === e ? Object.assign(o, {
                                    marginLeft: "24rpx"
                                }) : e === t.aloneNav.length - 1 && Object.assign(o, {
                                    marginRight: "24rpx"
                                }), o;
                            }
                            var a = Number(t.aloneNum), r = {
                                width: t.aloneWidth,
                                "min-width": t.aloneWidth
                            };
                            return r = a < 5 ? Object.assign(r, {
                                marginLeft: "".concat(n.upx2px(750 - parseFloat(t.aloneWidth) * a) / (a + 1), "px")
                            }) : Object.assign(r, {
                                marginLeft: "".concat(n.upx2px((750 - parseFloat(t.aloneWidth) * a + parseFloat(t.aloneWidth) / 2) / a), "px")
                            }), e === t.navs.length - 1 && (r = Object.assign(r, {
                                "margin-right": r.marginLeft
                            })), r;
                        };
                    }
                }
            };
            t.default = e;
        }).call(this, e("543d").default);
    },
    "5091b": function(n, t, e) {
        e.r(t);
        var i = e("72f0"), o = e("bada");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        e("dd34");
        var r = e("f0c5"), u = Object(r.a)(o.default, i.b, i.c, !1, null, "e6d73e60", null, !1, i.a, void 0);
        t.default = u.exports;
    },
    "72f0": function(n, t, e) {
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {});
        var i = function() {
            var n = this, t = (n.$createElement, n._self._c, "fixed" === n.navType ? n.__map(n.newNavs, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    l0: n.__map(t, function(e, i) {
                        return {
                            $orig: n.__get_orig(e),
                            s0: n.__get_style([ n.beforeMargin(i, t) ]),
                            g0: e.name && "image" !== n.modeType ? e.name.substring(0, n.columns > 5 ? 4 : 5) : null
                        };
                    })
                };
            }) : null), e = "alone" === n.navType ? n.__map(n.aloneNav, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    s1: n.__get_style([ n.formatB(e) ]),
                    m0: "image" === n.modeType ? n.formatB(e) : null,
                    g1: t.name && "image" !== n.modeType ? t.name.substring(0, n.aloneNum > 5 ? 4 : 5) : null
                };
            }) : null, i = "multi" === n.navType ? n.__map(n.muitiNavs, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    g2: e.toString(),
                    l4: n.__map(t, function(t, e) {
                        return {
                            $orig: n.__get_orig(t),
                            l3: n.__map(t, function(t, e) {
                                return {
                                    $orig: n.__get_orig(t),
                                    g3: t.name ? t.name.substring(0, n.columns > 5 ? 4 : 5) : null
                                };
                            })
                        };
                    })
                };
            }) : null;
            n.$mp.data = Object.assign({}, {
                $root: {
                    l1: t,
                    l2: e,
                    l5: i
                }
            });
        }, o = [];
    },
    bada: function(n, t, e) {
        e.r(t);
        var i = e("1908"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(a);
        t.default = o.a;
    },
    dd34: function(n, t, e) {
        var i = e("e8f3");
        e.n(i).a;
    },
    e8f3: function(n, t, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-navigation-icon/app-navigation-two-icon-create-component", {
    "components/page-component/app-navigation-icon/app-navigation-two-icon-create-component": function(n, t, e) {
        e("543d").createComponent(e("5091b"));
    }
}, [ [ "components/page-component/app-navigation-icon/app-navigation-two-icon-create-component" ] ] ]);