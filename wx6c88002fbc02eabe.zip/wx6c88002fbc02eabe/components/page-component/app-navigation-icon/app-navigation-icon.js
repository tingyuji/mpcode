(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-navigation-icon/app-navigation-icon" ], {
    "047c": function(n, t, e) {
        e.r(t);
        var o = e("fbf6"), a = e("4083");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e("f4f2");
        var c = e("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, "3b840cad", null, !1, o.a, void 0);
        t.default = u.exports;
    },
    4083: function(n, t, e) {
        e.r(t);
        var o = e("b62c"), a = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    "8b83": function(n, t, e) {},
    b62c: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                name: "app-navigation-icon",
                data: function() {
                    return {
                        width: n.upx2px(0) + "px",
                        height: 0
                    };
                },
                props: {
                    background: {
                        type: String,
                        default: function() {
                            return "#ffffff";
                        }
                    },
                    color: {
                        type: String,
                        default: function() {
                            return "#353535";
                        }
                    },
                    columns: {
                        type: Number,
                        default: function() {
                            return 3;
                        }
                    },
                    rows: {
                        type: Number,
                        default: function() {
                            return 4;
                        }
                    },
                    scroll: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    },
                    navs: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    }
                },
                computed: {
                    newData: function() {
                        this.width = "".concat(n.upx2px(750 / this.columns), "px");
                        var t = [], e = [], o = Number(this.columns) * this.rows;
                        if (!0 === this.scroll) {
                            for (var a = 0; a < Math.ceil(this.navs.length / o); a++) t.push(this.navs.slice(a * o, (a + 1) * o));
                            for (var i = 0; i < t.length; i++) {
                                for (var c = [], u = 0; u < Math.ceil(t[i].length / Number(this.columns)); u++) {
                                    var r = t[i].slice(u * Number(this.columns), (u + 1) * Number(this.columns));
                                    c.push(r);
                                }
                                e.push(c);
                            }
                        } else {
                            -1 === this.rows ? t = [ this.navs ] : t.push(this.navs.slice(0, o));
                            for (var p = 0; p < t.length; p++) {
                                for (var f = [], s = 0; s < Math.ceil(t[p].length / Number(this.columns)); s++) {
                                    var l = t[p].slice(s * Number(this.columns), (s + 1) * Number(this.columns));
                                    f.push(l);
                                }
                                e.push(f);
                            }
                        }
                        return e.length, e;
                    }
                },
                watch: {
                    newData: {
                        handler: function(t) {
                            this.height = "".concat(n.upx2px(156 * t[0].length), "px");
                        },
                        immediate: !0
                    }
                }
            };
            t.default = e;
        }).call(this, e("543d").default);
    },
    f4f2: function(n, t, e) {
        var o = e("8b83");
        e.n(o).a;
    },
    fbf6: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-navigation-icon/app-navigation-icon-create-component", {
    "components/page-component/app-navigation-icon/app-navigation-icon-create-component": function(n, t, e) {
        e("543d").createComponent(e("047c"));
    }
}, [ [ "components/page-component/app-navigation-icon/app-navigation-icon-create-component" ] ] ]);