(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-goods-list-cat/app-goods-list-cat" ], {
    "2a68": function(t, e, n) {},
    "4be3": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            data: function() {
                return {};
            },
            props: {
                data: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                theme: Object,
                tempId: String,
                tempIndex: Number
            },
            components: {
                appDiyList: function() {
                    n.e("components/page-component/index/app-diy-list").then(function() {
                        return resolve(n("a401"));
                    }.bind(null, n)).catch(n.oe);
                },
                appRecommendedProductList: function() {
                    n.e("components/page-component/app-recommended-product/app-recommended-product-list").then(function() {
                        return resolve(n("57ba"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            methods: {
                transLabelBackgroundPosition: function(t) {
                    switch (+t) {
                      case 1:
                        return "left top";

                      case 2:
                        return "center top";

                      case 3:
                        return "right top";

                      case 4:
                        return "left center";

                      case 5:
                        return "center center";

                      case 6:
                        return "right center";

                      case 7:
                        return "left bottom";

                      case 8:
                        return "center bottom";

                      case 9:
                        return "right bottom";

                      default:
                        return "center";
                    }
                },
                transLabelBackgroundRepeat: function(t) {
                    switch (+t) {
                      case 1:
                        return "no-repeat";

                      case 2:
                        return "repeat-x";

                      case 3:
                        return "repeat-y";

                      case 4:
                        return "repeat";

                      default:
                        return "no-repeat";
                    }
                },
                changeTopNav: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
                    this.$emit("changeTopNav", t, e);
                },
                buyProduct: function(t) {
                    this.$emit("buyProduct", t);
                },
                handleCart: function(t) {
                    this.$emit("cart", t);
                },
                attrShow: function(t) {
                    this.$emit("show", t);
                }
            }
        };
        e.default = o;
    },
    "5b43": function(t, e, n) {
        n.r(e);
        var o = n("4be3"), a = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e.default = a.a;
    },
    "6d4a": function(t, e, n) {
        var o = n("2a68");
        n.n(o).a;
    },
    "7f03": function(t, e, n) {
        n.r(e);
        var o = n("a8e0"), a = n("5b43");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(c);
        n("6d4a");
        var r = n("f0c5"), p = Object(r.a)(a.default, o.b, o.c, !1, null, "58bf288e", null, !1, o.a, void 0);
        e.default = p.exports;
    },
    a8e0: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this, e = (t.$createElement, t._self._c, t.transLabelBackgroundPosition(t.data.position)), n = t.transLabelBackgroundRepeat(t.data.mode);
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    m1: n
                }
            });
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-goods-list-cat/app-goods-list-cat-create-component", {
    "components/page-component/app-goods-list-cat/app-goods-list-cat-create-component": function(t, e, n) {
        n("543d").createComponent(n("7f03"));
    }
}, [ [ "components/page-component/app-goods-list-cat/app-goods-list-cat-create-component" ] ] ]);