(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-associated-link/app-associated-link" ], {
    "1cff": function(t, e, n) {
        n.r(e);
        var o = n("6a40"), r = n("260c");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        n("5e95");
        var c = n("f0c5"), i = Object(c.a)(r.default, o.b, o.c, !1, null, "73b99aeb", null, !1, o.a, void 0);
        e.default = i.exports;
    },
    "260c": function(t, e, n) {
        n.r(e);
        var o = n("6301"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = r.a;
    },
    "5e95": function(t, e, n) {
        var o = n("f1ea");
        n.n(o).a;
    },
    6301: function(t, e, n) {
        function o(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(t);
                e && (o = o.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function r(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            name: "app-associated-link",
            data: function() {
                return {
                    className: ""
                };
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }({}, (0, n("2f62").mapState)({
                styleImg: function(t) {
                    return t.mallConfig.__wxapp_img.diy;
                }
            })),
            props: {
                arrowsSwitch: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                },
                background: {
                    type: String,
                    default: function() {
                        return "#E11B1B";
                    }
                },
                color: {
                    type: String,
                    default: function() {
                        return "#F4EBEB";
                    }
                },
                link: {
                    type: Object,
                    default: function() {
                        return {
                            open_type: "tel",
                            params: [ {
                                value: "111"
                            } ]
                        };
                    }
                },
                styleColor: {
                    type: String,
                    default: function() {
                        return "#353535";
                    }
                },
                picSwitch: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                },
                picUrl: {
                    type: String,
                    default: function() {
                        return "";
                    }
                },
                position: {
                    type: String,
                    default: function() {
                        return "left";
                    }
                },
                title: {
                    type: String,
                    default: function() {
                        return "";
                    }
                },
                styleNum: {
                    type: String,
                    default: function() {
                        return "1";
                    }
                },
                fontSize: {
                    type: String,
                    default: function() {
                        return "36";
                    }
                }
            },
            created: function() {
                "36" == this.fontSize ? this.className = "big-style" : "28" == this.fontSize ? this.className = "medium-style" : this.className = "small-style";
            }
        };
        e.default = a;
    },
    "6a40": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, r = [];
    },
    f1ea: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-associated-link/app-associated-link-create-component", {
    "components/page-component/app-associated-link/app-associated-link-create-component": function(t, e, n) {
        n("543d").createComponent(n("1cff"));
    }
}, [ [ "components/page-component/app-associated-link/app-associated-link-create-component" ] ] ]);