(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-component/app-user-center-top/app-user-center-top" ], {
    "095d": function(e, t, n) {},
    2065: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
    },
    a527: function(e, t, n) {
        n.r(t);
        var r = n("2065"), o = n("a7c2");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("b237");
        var c = n("f0c5"), u = Object(c.a)(o.default, r.b, r.c, !1, null, "6cab8fe0", null, !1, r.a, void 0);
        t.default = u.exports;
    },
    a7c2: function(e, t, n) {
        n.r(t);
        var r = n("dadc"), o = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = o.a;
    },
    b237: function(e, t, n) {
        var r = n("095d");
        n.n(r).a;
    },
    dadc: function(e, t, n) {
        (function(e) {
            function r(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function o(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? r(Object(n), !0).forEach(function(t) {
                        i(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function i(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = n("2f62");
            !function(e) {
                e && e.__esModule;
            }(n("e1435"));
            var u = {
                name: "app-user-center-top",
                props: {
                    address: {
                        type: Object,
                        default: function() {
                            return {
                                status: 1,
                                bg_color: "#ff4544",
                                text_color: "#FFFFFF",
                                pic_url: "/static/image/icon/address-white.png"
                            };
                        }
                    },
                    topStyle: String,
                    topPicUrl: String,
                    memberPicUrl: String,
                    userNameColor: String,
                    bgColor: String,
                    is_icon_super_vip: {
                        type: [ String, Number ],
                        default: function() {
                            return "0";
                        }
                    },
                    loginStyle: {
                        type: Number,
                        default: 1
                    },
                    loginColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    loginBtnColor: {
                        type: String,
                        default: "#FFFFFF"
                    },
                    topSize: {
                        type: [ Number, String ],
                        default: 112
                    },
                    nicknameSize: {
                        type: [ Number, String ],
                        default: 40
                    },
                    code: {
                        type: Number,
                        default: 1
                    },
                    whiteCodePic: String,
                    whiteSettingPic: String,
                    whiteAddrPic: String,
                    codePic: String,
                    settingPic: String,
                    addrPic: String,
                    isAddress: {
                        type: Number,
                        default: 1
                    },
                    bgStyle: {
                        type: Number,
                        default: 2
                    },
                    bg: {
                        type: String,
                        default: "#FF4B46"
                    },
                    topMargin: {
                        type: [ Number, String ],
                        default: 50
                    }
                },
                computed: o(o(o({
                    isLogin: function() {
                        return this.$user.isLogin();
                    }
                }, (0, c.mapState)({
                    mall: function(e) {
                        return e.mallConfig.mall;
                    },
                    is_vip_card_user: function(e) {
                        return e.user.info && e.user.info.is_vip_card_user ? 1 : 0;
                    },
                    commonImg: function(e) {
                        return e.mallConfig.__wxapp_img.common;
                    },
                    userCenterImg: function(e) {
                        return e.mallConfig.__wxapp_img.user_center;
                    }
                })), (0, c.mapGetters)({
                    userCenter: "mallConfig/getUserCenter",
                    userInfo: "user/info"
                })), {}, {
                    avatar: function() {
                        return this.isLogin && this.userInfo ? this.userInfo.avatar : this.commonImg.user_default_avatar;
                    },
                    getMemberPicUrl: function() {
                        return this.memberPicUrl ? this.memberPicUrl : this.userInfo && this.userInfo.identity ? this.userInfo.identity.member_pic_url : "";
                    },
                    canIUseGetUserProfile: function() {
                        return this.$user.canIUseGetUserProfile();
                    }
                }),
                watch: {
                    isLogin: {
                        handler: function(e) {
                            e && this.$store.dispatch("user/info", {
                                refresh: !0
                            });
                        },
                        immediate: !0
                    }
                },
                methods: {
                    callLogin: function() {
                        this.$store.dispatch("user/accessToken");
                    },
                    goMember: function() {
                        e.navigateTo({
                            url: "/pages/member/index/index"
                        });
                    },
                    router: function(t) {
                        e.navigateTo({
                            url: t
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-component/app-user-center-top/app-user-center-top-create-component", {
    "components/page-component/app-user-center-top/app-user-center-top-create-component": function(e, t, n) {
        n("543d").createComponent(n("a527"));
    }
}, [ [ "components/page-component/app-user-center-top/app-user-center-top-create-component" ] ] ]);