Page({
    data: {}
});