var a = getApp();

Page({
    data: {
        x: 614,
        y: 288,
        rankList: [],
        roomId: null
    },
    onLoad: function(t) {
        a.mta();
        var o = t.roomId, e = this;
        o ? (this.setData({
            roomId: o,
            uid: a.globalData.userInfo.uid
        }), a.ajaxData({
            url: "/xcxapi/group/resultget",
            method: "POST",
            data: {
                roomid: o
            },
            cb: function(a) {
                e.setData({
                    rankList: a.data.data
                });
            }
        })) : wx.showModal({
            title: "提示",
            content: "房间号不存在！",
            complete: function() {
                wx.reLaunch({
                    url: "/pages/index/index"
                });
            }
        });
    }
});