var a = getApp();

Page({
    data: {
        userInfo: {},
        nickName: null,
        showClear: !1
    },
    onLoad: function() {
        a.mta(), this.setData({
            userInfo: a.globalData.userInfo,
            nickName: a.globalData.userInfo.nickName,
            showClear: a.globalData.userInfo.nickName.length > 0
        });
    },
    _handleInput: function(a) {
        var t = a.detail.value.trim();
        this.setData({
            nickName: t,
            showClear: t.length > 0
        });
    },
    _clear: function() {
        this.setData({
            nickName: "",
            showClear: !1
        });
    },
    _handleSumit: function(t) {
        var e = this;
        a.ajaxData({
            url: "/xcxapi/user/infoset",
            method: "POST",
            data: {
                nick: this.data.nickName
            },
            cb: function(t) {
                t.data.errcode ? wx.showModal({
                    title: "提示",
                    content: t.data.errmsg,
                    showCancel: !1
                }) : (a.getInfo(!0), wx.showModal({
                    title: "提示",
                    content: "昵称修改成功",
                    showCancel: !1,
                    success: function() {
                        a.globalData.userInfo.nickName = e.data.nickName, wx.navigateBack();
                    }
                }));
            }
        });
    }
});