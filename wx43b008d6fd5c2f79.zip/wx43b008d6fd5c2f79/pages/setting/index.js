var a = getApp();

Page({
    data: {
        userInfo: {}
    },
    onLoad: function() {
        a.mta();
    },
    onShow: function() {
        this.setData({
            userInfo: a.globalData.userInfo
        });
    },
    _updateAvatar: function() {
        var t = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var o = e.tempFilePaths;
                a.upload({
                    url: "/xcxapi/tool/imgupload",
                    filePath: o[0],
                    name: "img",
                    success: function(e) {
                        var o = JSON.parse(e.data).data;
                        a.ajaxData({
                            url: "/xcxapi/user/infoset",
                            method: "POST",
                            data: {
                                avatar: o
                            },
                            cb: function(e) {
                                if (e.data.errcode) wx.showModal({
                                    title: "提示",
                                    content: e.data.errmsg,
                                    showCancel: !1
                                }); else {
                                    var s = t.data.userInfo;
                                    s.avatarUrl = o, t.setData({
                                        userInfo: s
                                    }), a.getInfo("asdf");
                                }
                            }
                        });
                    }
                });
            }
        });
    }
});