var a = getApp();

Page({
    data: {
        userInfo: {},
        phone: null,
        showClear: !1
    },
    onLoad: function() {
        a.mta();
        var t = a.globalData.userInfo.tel ? a.globalData.userInfo.tel : null;
        this.setData({
            userInfo: a.globalData.userInfo,
            phone: t,
            showClear: t > 0
        });
    },
    _handleInput: function(a) {
        var t = a.detail.value.trim();
        this.setData({
            phone: t,
            showClear: t.length > 0
        });
    },
    _clear: function() {
        this.setData({
            phone: "",
            showClear: !1
        });
    },
    _handleSumit: function(t) {
        a.ajaxData({
            url: "/xcxapi/user/infoset",
            method: "POST",
            data: {
                tel: this.data.phone
            },
            cb: function(t) {
                t.data.errcode ? wx.showModal({
                    title: "提示",
                    content: t.data.errmsg,
                    showCancel: !1
                }) : (a.getInfo(!0), wx.showModal({
                    title: "提示",
                    content: "电话号码绑定成功",
                    showCancel: !1,
                    success: function() {
                        wx.navigateBack();
                    }
                }));
            }
        });
    }
});