var t = getApp(), a = require("../../utils/weapp.socket.io.js");

Page({
    data: {
        numArr: [ 5, 10, 20, 30 ],
        peopleArr: [ 2, 5, 10, 20, 30 ],
        timeArr: [ 5, 10, 20, 30 ],
        currentTab: 0,
        key: -1,
        type: -1,
        total: 10,
        people: 0,
        time: 10,
        title: "",
        name: "",
        modalConfig: {
            content: "",
            showCancel: !1
        },
        userInfo: null,
        roomId: null,
        cate: [],
        showShare: !1
    },
    onLoad: function(a) {
        t.mta();
        var e = this;
        t.ajaxData({
            url: "/xcxapi/question/category",
            method: "GET",
            cb: function(t) {
                var a = t.data.data, o = [ {
                    key: 0,
                    value: "随机题目"
                } ];
                for (var s in a) o.push({
                    key: s,
                    value: a[s]
                });
                e.setData({
                    cate: o
                });
            }
        }), e.setData({
            userInfo: {
                nickName: t.globalData.userInfo.nickName,
                avatarUrl: t.globalData.userInfo.avatarUrl
            }
        });
    },
    onReady: function() {
        wx.hideShareMenu();
    },
    _handleSelect: function(t) {
        var a = t.target.dataset.type;
        this.setData({
            type: +a
        });
    },
    _choseType: function(t) {
        var a = t.detail.value, e = this.data.cate[a].key;
        this.setData({
            type: +e,
            key: +a
        });
    },
    _handleShare: function() {
        this.setData({
            currentTab: 1
        });
    },
    _bindPickerChange: function(t) {
        this.setData({
            total: this.data.numArr[t.detail.value]
        });
    },
    _inputPeople: function(t) {
        this.setData({
            people: t.detail.value
        });
    },
    _pickTime: function(t) {
        this.setData({
            time: this.data.timeArr[t.detail.value]
        });
    },
    _inputTitle: function(t) {
        this.setData({
            title: t.detail.value
        });
    },
    _inputName: function(t) {
        this.setData({
            name: t.detail.value
        });
    },
    showModal: function(t) {
        this.setData({
            showModal: !0,
            modalConfig: t
        });
    },
    onUnload: function() {
        this.closeConnect();
    },
    _createRoom: function() {
        var a = this;
        if (this.data.type < 0) a.showModal({
            type: "error",
            content: "请选择题库"
        }); else {
            var e = {
                category: this.data.type,
                roomname: this.data.title,
                companyname: this.data.name,
                membercount: this.data.people,
                questioncount: this.data.total,
                waittime: this.data.time
            };
            console.log(e), t.ajaxData({
                url: "/xcxapi/group/roomcreate",
                method: "POST",
                data: e,
                cb: function(t) {
                    t.data.errcode ? a.showModal({
                        type: "error",
                        content: t.data.errmsg
                    }) : (a.createConnect(t.data.roomid), a.setData({
                        roomId: t.data.roomid,
                        showShare: !0
                    }));
                }
            });
        }
    },
    onShareAppMessage: function(t) {
        this.setData({
            showShare: !1
        });
        var a = {
            title: "快来团战吧！！！",
            path: "/pages/mutil/play?scene=roomId_" + this.data.roomId,
            imageUrl: "../../statics/images/share.jpg",
            success: function(t) {},
            fail: function() {
                "shareAppMessage:fail cancel" == res.errMsg ? (console.log("cancel"), wx.showModal({
                    title: "cancel"
                })) : "shareAppMessage:fail" == res.errMsg && (console.log("fail"), wx.showModal({
                    title: "fail"
                }));
            },
            complete: function(t) {
                console.log(t), "shareAppMessage:ok" == t.errMsg && wx.redirectTo({
                    url: a.path
                });
            }
        };
        if (null != this.data.roomId) return "button" == t.from && (a.path = "/pages/mutil/play?scene=roomId_" + this.data.roomId, 
        a.imageUrl = "../../statics/images/share.jpg"), a;
        this.data.type, this.data.title, this.data.name, this.data.people, this.data.total, 
        this.data.time;
    },
    createConnect: function(t) {
        var e = this;
        (this.socket = a("wss://popularizinglaw-pay.gzsfj.gov.cn")).on("connect", function() {
            console.log("连接成功"), e.createRoom(t);
        });
    },
    enterRoom: function() {
        var t = this;
        wx.showModal({
            title: "提示",
            content: "即将进入房间，请确定已分享给好友",
            success: function(a) {
                a.confirm && wx.navigateTo({
                    url: "/pages/mutil/play?scene=roomId_" + t.data.roomId
                });
            }
        });
    },
    closeConnect: function() {
        this.socket && (this.socket.close(), this.socket = null);
    },
    createRoom: function(t) {
        var a = this.data.userInfo;
        a.isOver = !1, this.socket.emit("createRoom", {
            roomId: t,
            userInfo: a,
            roomInfo: this.data.roomInfo
        });
    }
});