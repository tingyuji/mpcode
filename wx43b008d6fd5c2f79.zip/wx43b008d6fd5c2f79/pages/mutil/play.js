function t(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var e, a = require("../../utils/weapp.socket.io.js"), o = getApp(), n = null, s = !1;

Page((t(e = {
    data: {
        currentTab: 0,
        type: 0,
        showAuth: !1,
        modalConfig: {
            content: "",
            showCancel: !1
        },
        showErwei: !1,
        showErweiBtn: !1,
        questions: [],
        userInfo: null,
        roomId: null,
        onlineUsers: [],
        roomInfo: null,
        start: !1,
        entered: !1,
        gameover: !1,
        currentPage: 0,
        current: -1,
        shake: !1,
        anmiateIndex: -1,
        isAnswered: !1,
        initTotal: 10,
        total: 10,
        score: 0,
        correctNum: 0,
        dataid: null,
        allNum: 0,
        initAllNum: 0,
        leave: 0,
        rankList: [],
        forceLeave: !1,
        uid: 1
    },
    catchTouchMove: function(t) {
        return !1;
    },
    _pageInit: function(t) {
        var e = this;
        wx.showLoading({
            title: "正在拉取房间信息"
        }), o.ajaxData({
            url: "/xcxapi/group/roominfoget",
            method: "POST",
            data: {
                roomid: t
            },
            cb: function(a) {
                wx.hideLoading();
                for (var o = a.data.data.question, n = 0; n < o.length; n++) o[n].myAnswer = -1;
                e.setData({
                    roomInfo: a.data.data,
                    questions: o,
                    initTotal: a.data.data.waittime,
                    total: a.data.data.waittime
                }), 2 == a.data.data.status ? wx.showModal({
                    title: "提示",
                    content: "游戏已经开始了，不能加入",
                    showCancel: !1,
                    complete: function() {
                        wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }) : 3 == a.data.data.status ? wx.showModal({
                    title: "提示",
                    content: "游戏已结束！",
                    showCancel: !1,
                    complete: function() {
                        wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }) : (console.log("加入房间"), e.createConnect(t, a.data.data.iscreater));
            }
        }), o.ajaxData({
            url: "/xcxapi/act/roomqrcode",
            method: "POST",
            data: {
                roomid: t
            },
            cb: function(t) {
                var a = t.data;
                a.errcode ? wx.showModal({
                    title: "提示",
                    content: a.errmsg,
                    showCancel: !1
                }) : (e.setData({
                    showErweiBtn: !0,
                    erweiUrl: "data:image/png;base64," + a.data.qrcode
                }), console.log(t.data));
            }
        }), e.setData({
            userInfo: {
                nickName: o.globalData.userInfo.nickName,
                avatarUrl: o.globalData.userInfo.avatarUrl
            },
            uid: o.globalData.userInfo.uid
        });
    },
    onLoad: function(t) {
        o.mta();
        var e = wx.getStorageSync("token"), a = o.getParams(t.scene);
        a ? (this.setData({
            roomId: a
        }), e ? (this.setData({
            showAuth: !1
        }), this._pageInit(a)) : this.setData({
            showAuth: !0
        })) : wx.showModal({
            title: "错误",
            content: "房间号不存在",
            showCancel: !1,
            success: function() {
                wx.navigateBack();
            }
        });
    },
    toggleErwei: function() {
        this.setData({
            showErwei: !this.data.showErwei
        });
    },
    onHide: function() {
        console.log("离开房间");
    },
    onUnload: function() {
        this.setData({
            forceLeave: !0
        }), this.closeConnect(), wx.hideLoading(), console.log("离开房间"), clearInterval(n);
    }
}, "catchTouchMove", function(t) {
    return !1;
}), t(e, "showModal", function(t) {
    this.setData({
        showModal: !0,
        modalConfig: t
    });
}), t(e, "createConnect", function(t, e) {
    var s = this, r = this.socket = a("wss://popularizinglaw-pay.gzsfj.gov.cn");
    r.on("connect", function() {
        console.log("连接成功"), s.setData({
            entered: !0
        }), s.data.start || s.enterRoom(t), r.emit("getGameStatus", {
            roomId: t
        });
    }), r.on("gameStatus", function(t) {
        t.gameStart && !s.data.gameover && (s.closeConnect(), clearInterval(n), wx.showModal({
            title: "抱歉",
            content: "游戏已经开始了，无法进入",
            showCancel: !1,
            success: function() {
                wx.redirectTo({
                    url: "/pages/index/index"
                });
            }
        }));
    }), r.on("reconnecting", function() {
        console.log("正在重连");
    }), r.on("connect_failed", function() {
        console.log("websocket 连接失败");
    }), r.on("reconnect", function() {
        console.log("重新连接到服务器");
    }), r.on("disconnect", function() {
        s.data.start && !s.data.gameover ? (s.closeConnect(), clearInterval(n), wx.showModal({
            title: "抱歉",
            content: "网络异常，与服务器断开连接，游戏终止！",
            showCancel: !1,
            success: function() {
                wx.redirectTo({
                    url: "/pages/index/index"
                });
            }
        })) : s.data.gameover && !s.data.forceLeave && (s.closeConnect(), clearInterval(n), 
        wx.showModal({
            title: "抱歉",
            content: "检测到您离开游戏，请去个人中心查看个人战绩",
            showCancel: !1,
            success: function() {
                wx.redirectTo({
                    url: "/pages/history/index"
                });
            }
        }));
    }), r.on("message", function(t) {
        console.log(t.content);
    }), r.on("all", function(t) {
        console.log(t), s.setData({
            onlineUsers: t.msg
        });
    }), r.on("start", function(t) {
        s._gameStart();
    }), r.on("warning", function(t) {
        wx.showModal({
            title: "提示",
            content: t.content,
            showCancel: !1,
            complete: function() {
                wx.reLaunch({
                    url: "/pages/index/index"
                });
            }
        });
    }), r.on("empty", function(t) {
        wx.showModal({
            title: "提示",
            content: t.content,
            showCancel: !1,
            complete: function() {
                wx.reLaunch({
                    url: "/pages/index/index"
                });
            }
        });
    }), r.on("gameOver", function(t) {
        var e = t.msg.over, a = t.msg.total;
        s.setData({
            allNum: a,
            leave: e
        });
    }), r.on("gameEnd", function(t) {
        console.log("服务器end"), s._showResult();
    }), r.on("enterSuccess", function(e) {
        o.ajaxData({
            url: "/xcxapi/group/memberin",
            method: "POST",
            data: {
                roomid: t
            },
            cb: function(t) {
                console.log(t);
            }
        });
    });
}), t(e, "createRoom", function(t) {
    var e = this.data.userInfo;
    e.isOver = !1, this.socket.emit("createRoom", {
        roomId: t,
        userInfo: e,
        roomInfo: this.data.roomInfo
    });
}), t(e, "enterRoom", function(t) {
    var e = this.data.userInfo;
    e.isOver = !1, this.socket.emit("enterRoom", {
        roomId: t,
        userInfo: e,
        roomInfo: this.data.roomInfo
    });
}), t(e, "closeConnect", function() {
    this.socket && (this.socket.close(), this.socket = null);
}), t(e, "_handleStart", function() {
    var t = this;
    this.data.onlineUsers.length > 1 ? (this.socket.emit("start", {
        roomId: t.data.roomId
    }), o.ajaxData({
        url: "/xcxapi/group/gamestart",
        method: "POST",
        data: {
            roomid: t.data.roomId
        },
        cb: function(t) {
            console.log(t);
        }
    }), t.setData({
        initAllNum: t.data.onlineUsers.length
    })) : console.log("人数不够无法开始");
}), t(e, "_gameStart", function() {
    var t = this;
    this.setData({
        currentTab: 1,
        start: !0,
        anmiateIndex: 0,
        current: 0
    }), setTimeout(function() {
        t._countDown();
    }, 2e3);
}), t(e, "_handleChose", function(t) {
    if (this.data.isAnswered) console.log("isAnswered:" + s), console.log("data.isAnswered:" + this.data.isAnswered); else {
        s = !0, clearInterval(n);
        var e = t.currentTarget.dataset.index, a = this.data.current, o = this.data.questions, r = 1 == o[a].answer[e].right;
        o[a].myAnswer = e, o[a].isCorrect = r, o[a].spend = this.data.initTotal - this.data.total;
        var i = r ? this.data.correctNum + 1 : this.data.correctNum;
        this.setData({
            questions: o,
            shake: !r,
            correctNum: i,
            isAnswered: !0
        }), this._next();
    }
}), t(e, "_bindChange", function(t) {
    var e = this;
    setTimeout(function() {
        e.setData({
            anmiateIndex: e.data.current,
            isAnswered: !1
        });
    }, 1e3);
}), t(e, "_next", function() {
    var t = this, e = this.data.current;
    ++e > t.data.questions.length - 1 ? t._gameOver() : (setTimeout(function() {
        t.setData({
            total: t.data.initTotal,
            current: e,
            shake: !1
        });
    }, 1e3), setTimeout(function() {
        s = !1, t._countDown();
    }, 4e3));
}), t(e, "_countDown", function() {
    var t = this.data.total, e = this;
    clearInterval(n), n = setInterval(function() {
        if (--t < 0) {
            clearInterval(n), e.data.isAnswerd || e.shake();
            var a = e.data.current, o = e.data.questions;
            return o[a].isCorrect = !1, e.setData({
                questions: o,
                isAnswered: !0
            }), void e._next();
        }
        e.setData({
            total: t
        });
    }, 1e3);
}), t(e, "shake", function() {
    this.setData({
        shake: !0
    });
}), t(e, "_gameOver", function() {
    clearInterval(n);
    for (var t = this, e = [], a = 0; a < this.data.questions.length; a++) e.push({
        myAnswer: this.data.questions[a].myAnswer
    });
    var s = {
        roomid: this.data.roomId,
        answer: e
    };
    o.ajaxData({
        url: "/xcxapi/group/resultsend",
        method: "POST",
        data: s,
        cb: function(e) {
            t.socket.emit("gameOver", {
                roomId: t.data.roomId
            }), t.setData({
                currentTab: 2,
                isAnswered: !1,
                score: e.data.score,
                gameover: !0
            });
        }
    });
}), t(e, "_showResult", function() {
    clearInterval(n);
    var t = this;
    o.ajaxData({
        url: "/xcxapi/group/resultget",
        method: "POST",
        data: {
            roomid: t.data.roomId
        },
        cb: function(e) {
            t.setData({
                rankList: e.data.data,
                currentTab: 3
            });
        }
    });
}), t(e, "setUserInfo", function() {
    var t = this;
    return this.setData({
        showAuth: !1
    }), o.getInfo("/pages/mutil/play", function() {
        t._pageInit(t.data.roomId);
    }), !1;
}), e));