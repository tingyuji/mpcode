var t = getApp();

Page({
    data: {
        currentTab: 0,
        currentIndex: 1,
        dataid: null,
        roomId: null,
        questions: []
    },
    onLoad: function(a) {
        t.mta();
        var n = this, e = a.dataid;
        e ? t.ajaxData({
            url: "/xcxapi/open/infoget",
            method: "POST",
            data: {
                dataid: e
            },
            cb: function(t) {
                var a = JSON.parse(t.data.data.content);
                n.setData({
                    questions: a
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "答题记录不存在！",
            complete: function() {
                wx.reLaunch({
                    url: "/pages/index/index"
                });
            }
        });
    },
    _next: function() {
        var t = this.data.currentTab, a = this.data.questions.length;
        ++t >= a && (t = a - 1), this.setData({
            currentTab: t
        });
    },
    _prev: function() {
        var t = this.data.currentTab;
        --t <= 0 && (t = 0), this.setData({
            currentTab: t
        });
    },
    _handleChange: function(t) {
        this.setData({
            currentIndex: t.detail.current + 1
        });
    }
});