getApp(), Page({
    data: {
        uid: 2,
        timeid: 99
    },
    onLoad: function(i) {
        this.setData({
            uid: i.uid,
            timeid: i.timeid
        });
    }
});