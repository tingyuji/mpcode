var t = getApp();

Page({
    data: {
        vList: []
    },
    onLoad: function(a) {
        t.mta();
        var e = this;
        a.id ? t.ajaxData({
            url: "/xcxapi/act/timevideo",
            method: "POST",
            data: {
                timeid: a.id
            },
            cb: function(t) {
                var a = t.data;
                a.errcode ? wx.showModal({
                    title: "提示",
                    content: a.errmsg,
                    showCancel: !1,
                    complete: function() {
                        wx.navigateBack();
                    }
                }) : a.data.length <= 0 ? wx.showModal({
                    title: "提示",
                    content: "活动暂无视频回放",
                    showCancel: !1,
                    complete: function() {
                        wx.navigateBack();
                    }
                }) : (e.setData({
                    vList: a.data
                }), console.log(t));
            }
        }) : wx.showModal({
            content: "场次不存在",
            showCancel: !1,
            success: function() {
                wx.navigateBack();
            }
        });
    }
});