Page({
    data: {
        currentTab: 0,
        currentIndex: 1
    },
    _next: function() {
        var t = this.data.currentTab;
        ++t >= 5 && (t = 4), this.setData({
            currentTab: t
        });
    },
    _prev: function() {
        var t = this.data.currentTab;
        --t <= 0 && (t = 0), this.setData({
            currentTab: t
        });
    },
    _handleChange: function(t) {
        console.log(t), this.setData({
            currentIndex: t.detail.current + 1
        });
    }
});