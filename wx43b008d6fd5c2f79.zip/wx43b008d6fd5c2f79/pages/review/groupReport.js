getApp(), Page({
    data: {
        uid: 2,
        roomid: 99
    },
    onLoad: function(i) {
        this.setData({
            uid: i.uid,
            roomid: i.roomid
        });
    }
});