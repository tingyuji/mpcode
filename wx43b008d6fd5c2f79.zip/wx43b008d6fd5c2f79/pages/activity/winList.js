var a = getApp();

Page({
    data: {
        winList: [ {
            nickName: "老王",
            avatarUrl: "../../statics/images/avatar_man.png"
        } ],
        result: []
    },
    onLoad: function(t) {
        a.mta();
        var i = this, s = t.timeid, r = t.goodsid;
        a.ajaxData({
            url: "/xcxapi/act/lotteryresult",
            method: "POST",
            data: {
                timeid: s
            },
            cb: function(a) {
                var t = a.data.data;
                for (var s in t) +t[s].goodsid == +r && i.setData({
                    winList: t[s].users,
                    result: t[s]
                });
            }
        });
    }
});