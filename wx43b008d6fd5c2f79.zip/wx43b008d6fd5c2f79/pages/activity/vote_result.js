var t = getApp();

Page({
    data: {
        voteResult: []
    },
    onLoad: function(a) {
        t.mta(), this.setData({
            timeid: a.id
        }), this.pullVoteResult(a.id);
    },
    pullVoteResult: function(a) {
        var e = this;
        t.ajaxData({
            url: "/xcxapi/act/votedataget",
            method: "POST",
            data: {
                timeid: a
            },
            cb: function(t) {
                for (var a = t.data.data, o = 0, i = 0; i < a.length; i++) o += +a[i].pcount;
                for (i = 0; i < a.length; i++) a[i].percent = o <= 0 ? "0%" : a[i].pcount / o * 100 + "%";
                e.setData({
                    voteResult: a
                });
            }
        });
    }
});