var a = getApp();

Page({
    data: {
        keywords: "",
        msg: [ {
            nick_name: "老王",
            avatar: "../../statics/images/avatar_woman.png",
            content: "欢迎大家参加活动",
            isMe: !1
        } ]
    },
    onLoad: function(t) {
        a.mta();
        var e = a.getParams(t.scene);
        this.setData({
            timeid: e
        });
    },
    _handleInput: function(a) {
        var t = a.detail.value.trim();
        this.setData({
            keywords: t
        });
    },
    _insertDefault: function(a) {
        this.setData({
            keywords: a.target.dataset.key
        });
    },
    send: function(t) {
        var e = this, s = t.detail.value.msg.trim();
        if (!(s.length <= 0)) {
            var n = this.data.msg;
            a.ajaxData({
                url: "/xcxapi/act/talksend",
                method: "POST",
                data: {
                    timeid: e.data.timeid,
                    content: s
                },
                cb: function(t) {
                    t.data.errcode ? wx.showModal({
                        title: "提示",
                        content: t.data.errmsg,
                        showCancel: !1
                    }) : (n.push({
                        nick_name: "老王",
                        avatar: a.globalData.userInfo.avatarUrl,
                        content: s,
                        isMe: !0
                    }), e.setData({
                        msg: n,
                        keywords: ""
                    }));
                }
            });
        }
    }
});