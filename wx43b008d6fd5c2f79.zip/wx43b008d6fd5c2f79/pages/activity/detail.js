var t = getApp(), a = require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        bannerUrls: [ "../../statics/images/banner2.png", "../../statics/images/banner.jpg" ],
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 500,
        actid: null,
        currentId: null,
        currentTime: [],
        detail: null,
        timeArr: []
    },
    onShow: function() {
        this.data.actid && this.getData(this.data.actid);
    },
    onLoad: function(a) {
        t.mta(), this.setData({
            actid: a.id
        }), this.getData(a.id);
    },
    getData: function(i) {
        var e = this;
        t.ajaxData({
            url: "/xcxapi/act/infoget",
            method: "POST",
            data: {
                actid: i
            },
            cb: function(t) {
                for (var i = t.data.data.timelist, n = [], d = 0; d < i.length; d++) n.push({
                    id: i[d].timeid,
                    name: i[d].time,
                    detail: i[d]
                });
                var r = t.data.data.content;
                a.wxParse("article", "html", r, e, 5), e.setData({
                    detail: t.data.data,
                    currentTime: i[0],
                    currentId: i[0].timeid,
                    timeList: n
                });
            }
        });
    },
    baoming: function() {
        null == this.data.currentId ? wx.showModal({
            title: "提示",
            content: "请先选择活动场次",
            showCancel: !1
        }) : wx.navigateTo({
            url: "/pages/activity/enroll?actid=" + this.data.actid + "&id=" + this.data.currentId
        });
    },
    bindTimeChange: function(t) {
        var a = t.detail.value, i = this.data.timeList[a].detail;
        this.setData({
            currentId: i.timeid,
            currentTime: i
        });
    }
});