var t = getApp(), a = require("../../utils/wxParse/wxParse.js");

Page({
    data: {
        isSigned: !1,
        timeid: "",
        clicked: !1,
        detail: null,
        showAuth: !1,
        vList: []
    },
    onLoad: function(a) {
        t.mta();
        var e = wx.getStorageSync("token");
        if (a.scene) i = t.getParams(a.scene); else var i = a.id;
        i ? (this.setData({
            timeid: i,
            userInfo: t.globalData.userInfo
        }), e ? (this.setData({
            showAuth: !1
        }), this.initPage(i)) : this.setData({
            showAuth: !0
        })) : wx.showModal({
            title: "提示",
            content: "活动不存在",
            showCancel: !1,
            complete: function() {
                wx.reLaunch({
                    url: "/pages/index/index"
                });
            }
        });
    },
    initPage: function(e) {
        var i = this;
        t.ajaxData({
            url: "/xcxapi/act/timeinfoget",
            method: "POST",
            data: {
                timeid: e
            },
            cb: function(t) {
                i.setData({
                    detail: t.data.data
                });
            }
        }), t.ajaxData({
            url: "/xcxapi/act/timevideo",
            method: "POST",
            data: {
                timeid: e
            },
            cb: function(t) {
                var e = t.data;
                if (e.errcode) wx.showModal({
                    title: "提示",
                    content: e.errmsg,
                    showCancel: !1,
                    complete: function() {
                        wx.navigateBack();
                    }
                }); else if (!(e.data.length <= 0)) {
                    for (var o = e.data, n = 0; n < o.length; n++) o[n].url && (o[n].url = encodeURI(o[n].url));
                    var d = t.data.data[0].content;
                    a.wxParse("article", "html", d, i, 5), i.setData({
                        vList: o
                    });
                }
            }
        });
    },
    signUp: function() {
        if (this.data.clicked) return !1;
        this.setData({
            clicked: !0
        });
        var a = this;
        this.data.isSigned || t.ajaxData({
            url: "/xcxapi/act/signin",
            method: "POST",
            data: {
                timeid: a.data.timeid
            },
            cb: function(t) {
                a.setData({
                    clicked: !1
                }), t.data.errcode ? 8 == t.data.errcode ? wx.showModal({
                    title: t.data.errmsg,
                    content: "立即前去报名？",
                    success: function(t) {
                        t.confirm && wx.navigateTo({
                            url: "/pages/activity/enrolllive?actid=1&id=" + a.data.timeid
                        });
                    }
                }) : a.showModal({
                    type: "error",
                    content: t.data.errmsg
                }) : (a.setData({
                    isSigned: !0
                }), a.showModal({
                    type: "sign",
                    content: "恭喜你,签到成功"
                }));
            }
        });
    },
    showResult: function() {
        var a = this;
        t.ajaxData({
            url: "/xcxapi/act/timeinfoget",
            method: "POST",
            data: {
                timeid: a.data.timeid
            },
            cb: function(t) {
                t.data.errcode ? wx.showModal({
                    title: "提示",
                    content: t.data.errmsg,
                    showCancel: !1
                }) : t.data.data.status < 3 ? wx.showModal({
                    title: "提示",
                    content: "活动尚未结束，无法生成报表!",
                    showCancel: !1
                }) : wx.navigateTo({
                    url: "/pages/review/report?timeid=" + a.data.timeid + "&uid=" + a.data.userInfo.uid
                });
            }
        });
    },
    enterRoom: function() {
        t.ajaxData({
            url: "/xcxapi/act/timeroominfo",
            method: "POST",
            data: {
                timeid: this.data.timeid
            },
            cb: function(t) {
                t.data.errcode ? wx.showModal({
                    title: "提示",
                    content: t.data.errmsg,
                    showCancel: !1
                }) : wx.navigateTo({
                    url: "/pages/mutil/play?scene=roomId_" + t.data.data.roomid
                });
            }
        });
    },
    getLocation: function() {
        wx.getLocation({
            type: "gcj02",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                wx.openLocation({
                    latitude: a,
                    longitude: e,
                    scale: 28
                });
            }
        });
    },
    showModal: function(t) {
        this.setData({
            showModal: !0,
            modalConfig: t
        });
    },
    setUserInfo: function() {
        var a = this;
        return this.setData({
            showAuth: !1
        }), t.getInfo(!0, function() {
            console.log(111), a.initPage(a.data.timeid);
        }), !1;
    }
});