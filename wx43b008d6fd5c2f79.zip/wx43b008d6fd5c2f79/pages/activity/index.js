var a = getApp();

Page({
    data: {
        bannerUrls: [ "../../statics/images/banner2.png", "../../statics/images/banner.jpg" ],
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 500,
        list: [],
        allList: [],
        nearList: [],
        choseArr: [ "全部", "附近" ],
        choseType: 0,
        moreText: "点击加载更多",
        perpage: 20,
        page: 1,
        showGetMoreBtn: !0,
        current: []
    },
    onShow: function() {
        this.setData({
            list: [],
            allList: [],
            nearList: [],
            page: 1,
            showGetMoreBtn: !0,
            current: [],
            moreText: "点击加载更多"
        }), this.getData(1, this.data.perpage);
        var t = this;
        this.setData({
            isFirst: !1
        }), a.ajaxData({
            url: "/xcxapi/act/lastlist",
            method: "GET",
            cb: function(a) {
                t.setData({
                    bannerUrls: a.data.data
                });
            }
        }), a.ajaxData({
            url: "/xcxapi/act/actusertop",
            method: "GET",
            cb: function(a) {
                if (console.log(a.data), a.data.errcode) wx.showModal({
                    title: "提示",
                    content: a.data.errmsg,
                    showCancel: !1,
                    complete: function() {}
                }); else {
                    var e = a.data.data;
                    t.setData({
                        current: e
                    });
                }
            }
        });
    },
    onLoad: function() {
        a.mta();
    },
    getData: function(t, e) {
        var i = this, s = [];
        a.globalData.isLocation ? wx.getLocation({
            type: "wgs84",
            success: function(o) {
                a.globalData.isLocation = !0, i.setData({
                    isLocation: !0
                });
                var n = o.latitude, r = o.longitude;
                a.ajaxData({
                    url: "/xcxapi/act/actlist",
                    method: "POST",
                    data: {
                        page: t,
                        per: e
                    },
                    cb: function(t) {
                        wx.hideLoading();
                        var e = t.data.data;
                        e.length < i.data.perpage ? i.setData({
                            showGetMoreBtn: !1,
                            moreText: "没有更多了"
                        }) : i.setData({
                            moreText: "点击加载更多"
                        });
                        for (var o = 0; o < e.length; o++) {
                            for (var c = e[o].timelist, l = !1, d = 0; d < c.length; d++) {
                                var h = Math.floor(a.getDistance(n, r, c[d].lat, c[d].lon));
                                h < 1e3 && (l = !0), h >= 1e3 ? h = (h / 1e3).toFixed(1) + "km" : h += "m", e[o].timelist[d].distance = h;
                            }
                            l && (s.push(e[o]), l = !1);
                        }
                        i.setData({
                            list: i.data.list.concat(e),
                            allList: i.data.list.concat(e),
                            nearList: i.data.nearList.concat(s)
                        });
                    }
                });
            },
            fail: function() {
                i.setData({
                    isLocation: !1
                }), a.globalData.isLocation = !1, i.getData();
            }
        }) : a.ajaxData({
            url: "/xcxapi/act/actlist",
            method: "POST",
            data: {
                page: t,
                per: e
            },
            cb: function(a) {
                var t = a.data.data;
                t.length < i.data.perpage ? i.setData({
                    showGetMoreBtn: !1,
                    moreText: "没有更多了"
                }) : i.setData({
                    moreText: "点击加载更多"
                }), i.setData({
                    list: i.data.list.concat(t),
                    allList: i.data.list.concat(t),
                    nearList: i.data.list.concat(t),
                    choseArr: [ "全部" ]
                }), wx.hideLoading();
            }
        });
    },
    bindPickerChange: function(a) {
        var t = a.detail.value;
        1 == t ? this.setData({
            choseType: t,
            list: this.data.nearList
        }) : this.setData({
            choseType: t,
            list: this.data.allList
        });
    },
    handleSearch: function(a) {
        var t = a.detail.value.trim();
        console.log(t), t.length <= 0 || wx.navigateTo({
            url: "/pages/search/index?keywords=" + t
        });
    },
    getMore: function() {
        if (this.data.showGetMoreBtn) {
            var a = this.data.page + 1;
            wx.showLoading({
                title: "加载中",
                mask: !0
            }), this.getData(a, this.data.perpage), this.setData({
                moreText: "加载中，请稍后",
                page: a
            });
        }
    }
});