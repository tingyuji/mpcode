var t = getApp();

Page({
    data: {
        winList: [],
        timeid: null
    },
    onLoad: function(a) {
        t.mta();
        var i = t.getParams(a.scene);
        this.setData({
            timeid: i
        }), this.pullWinInfo(i);
    },
    pullWinInfo: function(a) {
        var i = this;
        t.ajaxData({
            url: "/xcxapi/act/lotteryresult",
            method: "POST",
            data: {
                timeid: a
            },
            cb: function(t) {
                i.setData({
                    winList: t.data.data
                });
            }
        });
    }
});