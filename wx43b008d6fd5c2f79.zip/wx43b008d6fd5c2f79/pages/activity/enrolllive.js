var a = getApp();

Page({
    data: {
        numArr: [ 5, 10, 20, 30 ],
        peopleArr: [ 5, 10, 20, 30 ],
        timeArr: [ 5, 10, 20, 30 ],
        jobArr: [ "国家机关、党群组织工作人员", "企业、事业单位人员", "专业技术人员", "商业", "服务业从业人员", "农林牧渔水利从业人员", "生产、运输设备操作人员", "军人", "不便分类的其他从业人员" ],
        job: null,
        currentTab: 0,
        type: 0,
        total: 10,
        people: 10,
        time: 10,
        title: "",
        name: ""
    },
    onLoad: function(t) {
        a.mta(), t.id ? this.setData({
            timeid: t.id,
            actid: t.actid,
            userInfo: a.globalData.userInfo
        }) : wx.showModal({
            content: "场次不存在",
            showCancel: !1,
            success: function() {
                wx.navigateBack();
            }
        });
    },
    bindPickerChange: function(a) {
        var t = this.data.jobArr[a.detail.value];
        this.setData({
            job: t
        });
    },
    formSubmit: function(t) {
        var o = t.detail.value;
        o.timeid = this.data.timeid, o.formId = t.detail.formId, o.local = 1, this.data.job ? (o.job = this.data.job, 
        a.ajaxData({
            url: "/xcxapi/act/sign",
            method: "POST",
            data: o,
            cb: function(a) {
                console.log(a), a.data.errcode ? wx.showModal({
                    content: a.data.errmsg,
                    showCancel: !1
                }) : wx.showModal({
                    content: "报名成功",
                    showCancel: !1,
                    success: function() {
                        wx.navigateBack();
                    }
                });
            }
        })) : wx.showModal({
            content: "请选择职业",
            showCancel: !1
        });
    },
    showModal: function(a) {
        this.setData({
            showModal: !0,
            modalConfig: a
        });
    }
});