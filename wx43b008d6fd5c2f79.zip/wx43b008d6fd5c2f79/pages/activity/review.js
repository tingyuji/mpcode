getApp(), Page({
    data: {
        link: ""
    },
    onLoad: function(t) {
        t.link ? this.setData({
            link: t.link
        }) : wx.showModal({
            title: "提示",
            content: "链接地址出错",
            showCancel: !1,
            complete: function() {
                wx.navigateBack();
            }
        });
    }
});