var t = getApp(), e = null;

Page({
    data: {
        votelist: [],
        timeid: null,
        voteTotal: [],
        currentVoteId: null,
        voteResult: [],
        voteLimit: 0,
        voteName: "",
        voteArr: [],
        showAuth: !1,
        voted: !1
    },
    onLoad: function(e) {
        t.mta();
        var a = wx.getStorageSync("token"), o = t.getParams(e.scene);
        this.setData({
            timeid: o
        }), a ? (this.setData({
            showAuth: !1
        }), this.initVote(o)) : this.setData({
            showAuth: !0
        });
    },
    onUnload: function() {
        clearInterval(e);
    },
    initVote: function(a) {
        var o = this;
        t.ajaxData({
            url: "/xcxapi/act/votelist",
            method: "POST",
            data: {
                timeid: a
            },
            cb: function(t) {
                console.log(t.data.data);
                var a = t.data.data;
                a.length <= 0 || (o.setData({
                    voteTotal: a,
                    currentVoteId: a[0].voteid
                }), o.pullVoteInfo(a[0].voteid), o.pullVoteResult(a[0].voteid), e = setInterval(function() {
                    o.pullVoteResult(a[0].voteid);
                }, 2e3));
            }
        });
    },
    handleVote: function(t) {
        var e = t.currentTarget.dataset.itemid, a = t.currentTarget.dataset.index, o = this.data.voteArr, i = o.indexOf(e);
        if (i > -1) o.splice(i, 1); else {
            if (this.data.voteArr.length >= this.data.voteLimit) return void wx.showModal({
                title: "提示",
                content: "投票项数量超出限制",
                showCancel: !1,
                complete: function() {}
            });
            o.push(e);
        }
        var n = this.data.votelist;
        n[a].selected = !n[a].selected, this.setData({
            voteArr: o,
            votelist: n
        });
    },
    pullVoteInfo: function(e) {
        var a = this;
        t.ajaxData({
            url: "/xcxapi/act/voteitemget",
            method: "POST",
            data: {
                voteid: e
            },
            cb: function(t) {
                for (var e = t.data.data, o = 0; o < e.length; o++) e[o].selected = !1;
                a.setData({
                    votelist: t.data.data,
                    voteLimit: t.data.votecount,
                    voteName: t.data.votename,
                    voted: t.data.voted
                });
            }
        });
    },
    pullVoteResult: function(e) {
        var a = this;
        t.ajaxData({
            url: "/xcxapi/act/votedataget",
            method: "POST",
            data: {
                voteid: e
            },
            cb: function(t) {
                for (var e = t.data.data, o = 0, i = 0; i < e.length; i++) o += +e[i].pcount;
                for (i = 0; i < e.length; i++) e[i].percent = o <= 0 ? "0%" : e[i].pcount / o * 100 + "%";
                a.setData({
                    voteResult: e
                });
            }
        });
    },
    submit: function() {
        var e = this;
        t.ajaxData({
            url: "/xcxapi/act/votesend",
            method: "POST",
            data: {
                voteid: this.data.currentVoteId,
                itemid: this.data.voteArr.join(",")
            },
            cb: function(t) {
                t.data.errcode ? wx.showModal({
                    title: "提示",
                    content: t.data.errmsg,
                    showCancel: !1
                }) : (e.setData({
                    voteArr: []
                }), e.pullVoteInfo(e.data.currentVoteId));
            }
        });
    },
    bindChange: function(t) {
        var a = t.detail.value, o = this.data.voteTotal[a], i = this;
        this.setData({
            currentVoteId: o.voteid,
            voteArr: []
        }), clearInterval(e), i.pullVoteInfo(o.voteid), i.pullVoteResult(o.voteid), e = setInterval(function() {
            i.pullVoteResult(o.voteid);
        }, 2e3);
    },
    setUserInfo: function() {
        var e = this;
        return this.setData({
            showAuth: !1
        }), t.getInfo(!0, function() {
            e.initVote(e.data.timeid);
        }), !1;
    }
});