var a = getApp();

Page({
    data: {
        current: 0,
        going: [],
        end: [],
        enrolled: [],
        showModal: !1,
        modalConfig: {
            content: "",
            showCancel: !1
        }
    },
    catchTouchMove: function(a) {
        return !1;
    },
    onLoad: function() {
        a.mta();
        var t = this;
        a.ajaxData({
            url: "/xcxapi/act/mytime",
            method: "GET",
            cb: function(o) {
                for (var e = o.data.data, n = [], s = [], c = [], r = 0; r < e.length; r++) switch (+e[r].timestatus) {
                  case 1:
                    c.push(e[r]);
                    break;

                  case 2:
                    n.push(e[r]);
                    break;

                  case 3:
                    s.push(e[r]);
                }
                t.setData({
                    going: n,
                    end: s,
                    enrolled: c,
                    uid: a.globalData.userInfo.uid
                });
            }
        });
    },
    _handleChange: function(a) {
        var t = a.currentTarget.dataset.id;
        this.setData({
            current: t
        });
    },
    showError: function() {
        this.showModal({
            content: "活动已下线",
            showCancel: !1
        });
    },
    showModal: function(a) {
        this.setData({
            showModal: !0,
            modalConfig: a
        });
    }
});