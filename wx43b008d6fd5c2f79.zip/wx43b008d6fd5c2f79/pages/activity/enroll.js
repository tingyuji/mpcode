var a = getApp();

Page({
    data: {
        showSuccess: !1,
        numArr: [ 5, 10, 20, 30 ],
        peopleArr: [ 5, 10, 20, 30 ],
        timeArr: [ 5, 10, 20, 30 ],
        jobArr: [ "国家机关、党群组织工作人员", "企业、事业单位人员", "专业技术人员", "商业", "服务业从业人员", "农林牧渔水利从业人员", "生产、运输设备操作人员", "军人", "不便分类的其他从业人员" ],
        job: null,
        currentTab: 0,
        type: 0,
        total: 10,
        people: 10,
        time: 10,
        title: "",
        name: ""
    },
    onLoad: function(e) {
        a.mta(), e.id ? this.setData({
            timeid: e.id,
            actid: e.actid,
            userInfo: a.globalData.userInfo,
            job: a.globalData.userInfo.sign_position
        }) : wx.showModal({
            content: "场次不存在",
            showCancel: !1,
            success: function() {
                wx.navigateBack();
            }
        });
    },
    bindPickerChange: function(a) {
        var e = this.data.jobArr[a.detail.value];
        this.setData({
            job: e
        });
    },
    formSubmit: function(e) {
        var t = e.detail.value;
        t.timeid = this.data.timeid, t.formId = e.detail.formId;
        var o = this;
        a.ajaxData({
            url: "/xcxapi/act/sign",
            method: "POST",
            data: t,
            cb: function(e) {
                e.data.errcode ? wx.showModal({
                    content: e.data.errmsg,
                    showCancel: !1
                }) : wx.showModal({
                    content: "报名成功",
                    showCancel: !1,
                    success: function() {
                        o.setData({
                            showSuccess: !0
                        }), a.globalData.userInfo.sign_tel = t.tel, a.globalData.userInfo.sign_name = t.name;
                    }
                });
            }
        });
    },
    back: function() {
        wx.navigateBack();
    },
    showModal: function(a) {
        this.setData({
            showModal: !0,
            modalConfig: a
        });
    },
    onShareAppMessage: function(a) {
        var e = {
            title: "广州普法",
            path: "/pages/welcome/welcome",
            imageUrl: "../../statics/images/share2.jpg",
            success: function(a) {
                console.log(a), wx.navigateBack();
            },
            fail: function() {
                "shareAppMessage:fail cancel" == res.errMsg ? (console.log("cancel"), wx.showModal({
                    title: "cancel"
                })) : "shareAppMessage:fail" == res.errMsg && (console.log("fail"), wx.showModal({
                    title: "fail"
                }));
            },
            complete: function(a) {
                console.log(111111), wx.navigateBack();
            }
        };
        return "button" == a.from && (e.path = "/pages/welcome/welcome", e.imageUrl = "../../statics/images/share2.jpg"), 
        e;
    }
});