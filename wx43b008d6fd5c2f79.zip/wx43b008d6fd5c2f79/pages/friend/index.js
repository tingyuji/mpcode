Page({
    data: {
        currentTab: 0,
        type: 0
    },
    catchTouchMove: function(e) {
        return !1;
    },
    onShareAppMessage: function(e) {
        var t = {
            title: "转发的标题",
            path: "/pages/share/share",
            imgUrl: "",
            success: function(e) {
                console.log(e), "shareAppMessage:ok" == e.errMsg && console.log(111);
            },
            fail: function(e) {
                "shareAppMessage:fail cancel" == e.errMsg || e.errMsg;
            },
            complete: function() {
                console.log(111);
            }
        };
        if ("button" == e.from) {
            var a = e.target.dataset;
            t.path = "/pages/btnname/btnname?btn_name=" + a.name;
        }
        return t;
    },
    _handleSelect: function(e) {
        var t = e.target.dataset.type;
        this.setData({
            type: +t
        });
    },
    _handleShare: function() {
        this.setData({
            currentTab: 1
        });
    }
});