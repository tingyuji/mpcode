var t = getApp();

Page({
    data: {
        showAuth: !1,
        showScore: !1,
        dataId: null,
        result: null
    },
    onLoad: function(a) {
        t.mta();
        var e = this;
        if (wx.getStorageSync("token")) {
            var o = t.getParams(a.scene);
            this.setData({
                showAuth: !1,
                dataId: o
            }), t.ajaxData({
                url: "/xcxapi/open/robotresult",
                method: "POST",
                data: {
                    dataid: o
                },
                cb: function(t) {
                    t.data.errcode ? wx.showModal({
                        title: "提示",
                        content: t.data.errmsg,
                        showCancel: !1,
                        complete: function() {
                            wx.reLaunch({
                                url: "/pages/index/index"
                            });
                        }
                    }) : e.setData({
                        result: t.data.data
                    });
                }
            });
        } else this.setData({
            showAuth: !0
        });
    },
    closeScore: function() {
        this.setData({
            showScore: !1
        });
    },
    setUserInfo: function() {
        return this.setData({
            showAuth: !1
        }), t.getInfo("/pages/mutil/play", function() {}), !1;
    }
});