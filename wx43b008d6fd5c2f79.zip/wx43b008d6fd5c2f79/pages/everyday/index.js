var t = getApp(), a = null;

Page({
    data: {
        start: !1,
        tipsText: "每日答题开启中...",
        currentPage: 0,
        current: -1,
        shake: !1,
        anmiateIndex: -1,
        questions: [ {
            questionid: 1,
            content: "我国《刑法》对毒品犯罪的刑事责任年龄的规定，对已满14周岁不满16周岁的人，犯贩卖毒品罪的，应当（　　）。",
            answer: [ {
                content: "负刑事责任",
                right: 1
            }, {
                content: "从轻或减轻处罚",
                right: 2
            }, {
                content: "不予刑事处罚",
                right: 2
            }, {
                content: "责令其家长或者监护人加以管教，必要时，也可以由政府收容教养",
                right: 2
            } ],
            type: "禁毒法"
        } ],
        isAnswered: !1,
        initTotal: 10,
        total: 10,
        correctNum: 0,
        dataid: null,
        score: null,
        userInfo: null,
        gradeChange: [],
        showScore: !1,
        right: 0,
        wrong: 0,
        selected: 100,
        showCorrect: !1,
        showAuth: !1
    },
    catchTouchMove: function(t) {
        return !1;
    },
    onShow: function() {},
    onUnload: function() {
        clearInterval(a);
    },
    onLoad: function() {
        var a = this;
        t.mta(), wx.getStorageSync("token") ? (this.setData({
            showAuth: !1
        }), this.setData({
            userInfo: t.globalData.userInfo
        }, function() {
            a.pageInit();
        })) : this.setData({
            showAuth: !0
        });
    },
    pageInit: function() {
        var a = this;
        t.ajaxData({
            url: "/xcxapi/daily/questionget",
            method: "GET",
            cb: function(t) {
                for (var e = t.data.data, n = 0; n < e.length; n++) e[n].myAnswer = -1, e[n].isCorrect = null, 
                e[n].spend = a.data.initTotal;
                a.setData({
                    questions: e,
                    total: t.data.waittime,
                    initTotal: t.data.waittime
                }, function() {
                    a.start();
                });
            }
        });
    },
    start: function() {
        var a = this;
        t.ajaxData({
            url: "/xcxapi/daily/todayright",
            method: "GET",
            cb: function(t) {
                1 == +t.data.data ? (setTimeout(function() {
                    a.setData({
                        tipsText: "正在生成题库..."
                    });
                }, 1e3), setTimeout(function() {
                    a.setData({
                        start: !0,
                        anmiateIndex: 0,
                        current: 0
                    }), setTimeout(function() {
                        a._countDown();
                    }, 2e3);
                }, 2e3)) : wx.showModal({
                    title: "提示",
                    content: "今日份的答题次数用完喽",
                    showCancel: !1,
                    complete: function() {
                        wx.navigateTo({
                            url: "/pages/index/index"
                        });
                    }
                });
            }
        });
    },
    _handleChose: function(t) {
        var e = this;
        if (!this.data.isAnswered) {
            !0, clearInterval(a);
            var n = t.currentTarget.dataset.index, o = this.data.current, s = this.data.questions;
            this.setData({
                isAnswered: !0,
                selected: n
            });
            var r = 1 == s[o].answer[n].right;
            s[o].myAnswer = n, s[o].isCorrect = r, s[o].spend = this.data.initTotal - this.data.total;
            var i = r ? this.data.correctNum + 1 : this.data.correctNum;
            setTimeout(function() {
                e.setData({
                    questions: s,
                    shake: !r,
                    correctNum: i,
                    selected: 100,
                    showCorrect: !0
                }), clearInterval(a), e._next();
            }, 1e3);
        }
    },
    _bindChange: function(t) {
        console.log("change");
        var a = this;
        setTimeout(function() {
            !1, a.setData({
                anmiateIndex: a.data.current,
                isAnswered: !1,
                showCorrect: !1
            });
        }, 618);
    },
    _next: function() {
        console.log("next");
        var t = this, a = this.data.current;
        ++a > t.data.questions.length - 1 ? t._gameOver() : (setTimeout(function() {
            t.setData({
                current: a,
                shake: !1
            });
        }, 1e3), setTimeout(function() {
            t.setData({
                total: t.data.initTotal
            }), t._countDown();
        }, 4e3));
    },
    _countDown: function() {
        console.log("countdown");
        var t = this.data.total, e = this;
        clearInterval(a), a = setInterval(function() {
            if (--t < 0) return clearInterval(a), e.data.isAnswerd || e.shake(), e.setData({
                isAnswerd: !0
            }), void e._next();
            e.setData({
                total: t
            });
        }, 1e3);
    },
    shake: function() {
        this.setData({
            showCorrect: !0,
            shake: !0
        });
    },
    _gameOver: function() {
        var e = this;
        clearInterval(a), t.ajaxData({
            url: "/xcxapi/daily/resultsend",
            method: "POST",
            data: e.data.questions,
            cb: function(t) {
                var a = t.data.dataid;
                e.setData({
                    currentPage: 1,
                    score: t.data.score,
                    dataid: a,
                    gradeChange: t.data.grade_change,
                    right: t.data.right,
                    wrong: t.data.wrong,
                    isAnswered: !1
                }), t.data.grade_change.length > 0 && e.setData({
                    showScore: !0
                });
            }
        });
    },
    closeScore: function() {
        this.setData({
            showScore: !1
        });
    },
    setUserInfo: function() {
        var a = this;
        return this.setData({
            showAuth: !1
        }), t.getInfo(!0, function() {
            a.setData({
                userInfo: t.globalData.userInfo
            }), a.pageInit();
        }), !1;
    },
    onShareAppMessage: function(t) {
        return "button" === t.from && console.log(t.target), {
            title: "答题学法律，你也来试试",
            path: "/page/everyday/index"
        };
    }
});