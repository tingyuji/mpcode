var e = getApp();

Page({
    data: {
        showLoginBtn: !1,
        fromUrl: ""
    },
    onLoad: function(a) {
        return e.mta(), wx.login({
            success: function(a) {
                a.code && wx.request({
                    url: e.globalData.baseUrl + "/xcxapi/accesstoken",
                    method: "POST",
                    data: {
                        code: a.code,
                        appid: "130890112807",
                        appsecret: "2ed9b3gy109iup73yuqsx3ha0cid2au5"
                    },
                    headers: {
                        "content-type": "application/json"
                    },
                    success: function(e) {
                        var a = e.data.accesstoken;
                        console.log(e), wx.setStorageSync("token", a), wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            }
        }), !1;
    },
    setUserInfo: function() {
        e.getInfo(this.data.fromUrl, null);
    }
});