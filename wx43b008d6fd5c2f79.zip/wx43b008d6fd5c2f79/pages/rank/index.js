var a = getApp();

Page({
    data: {
        type: "all",
        currentTab: 0,
        isLocation: !1,
        today_myRank: null,
        today: null,
        all_myRank: null,
        all: null
    },
    onLoad: function() {
        a.mta();
        var t = this;
        a.ajaxData({
            url: "/xcxapi/top/score",
            method: "POST",
            data: {
                type: "today"
            },
            cb: function(a) {
                console.log(a), t.setData({
                    today_myRank: a.data.mydata,
                    today: a.data.topdata
                });
            }
        }), a.ajaxData({
            url: "/xcxapi/top/score",
            method: "POST",
            data: {
                type: "all"
            },
            cb: function(a) {
                t.setData({
                    all_myRank: a.data.mydata,
                    all: a.data.topdata
                });
            }
        });
    },
    _handleChange: function(a) {
        var t = a.target.dataset.type;
        this.setData({
            type: t,
            currentTab: "all" == t ? 0 : 1
        });
    },
    catchTouchMove: function(a) {
        return !1;
    }
});