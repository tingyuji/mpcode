var t = getApp();

Page({
    data: {
        list: [],
        moreText: "点击加载更多",
        perpage: 200,
        page: 1,
        showGetMoreBtn: !0
    },
    onLoad: function() {
        t.mta(), this.getData(1, this.data.perpage);
    },
    getData: function(a, e) {
        var o = this;
        t.ajaxData({
            url: "/xcxapi/act/actlist",
            method: "POST",
            data: {
                page: a,
                per: e,
                over: 1
            },
            cb: function(t) {
                var a = t.data;
                a.errcode ? wx.showModal({
                    title: "提示",
                    content: a.errmsg,
                    showCancel: !1,
                    complete: function() {}
                }) : (a.data.length < o.data.perpage ? o.setData({
                    showGetMoreBtn: !1,
                    moreText: "没有更多了"
                }) : o.setData({
                    moreText: "点击加载更多"
                }), o.setData({
                    list: o.data.list.concat(a.data)
                }), wx.hideLoading());
            }
        });
    },
    getMore: function() {
        if (this.data.showGetMoreBtn) {
            var t = this.data.page + 1;
            wx.showLoading({
                title: "加载中",
                mask: !0
            }), this.getData(t, this.data.perpage), this.setData({
                moreText: "加载中，请稍后",
                page: t
            });
        }
    }
});