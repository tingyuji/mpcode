var a = getApp();

Page({
    data: {
        uid: null,
        list: [],
        current: 0,
        going: [],
        end: [],
        enrolled: []
    },
    onLoad: function() {
        a.mta();
        var t = this;
        a.ajaxData({
            url: "/xcxapi/user/playlog",
            method: "GET",
            cb: function(a) {
                t.setData({
                    list: a.data.data
                }), console.log(a);
            }
        }), a.ajaxData({
            url: "/xcxapi/act/mytime",
            method: "GET",
            cb: function(e) {
                for (var n = e.data.data, s = [], r = [], i = [], u = 0; u < n.length; u++) switch (+n[u].timestatus) {
                  case 1:
                    i.push(n[u]);
                    break;

                  case 2:
                    s.push(n[u]);
                    break;

                  case 3:
                    r.push(n[u]);
                }
                t.setData({
                    going: s,
                    end: r,
                    enrolled: i,
                    uid: a.globalData.userInfo.uid
                });
            }
        });
    },
    _handleChange: function(a) {
        var t = a.currentTarget.dataset.id;
        this.setData({
            current: t
        });
    }
});