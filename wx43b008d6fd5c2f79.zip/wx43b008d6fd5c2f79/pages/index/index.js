var a = getApp(), t = a.globalData, e = t.marginTop, o = t.marginBot, n = t.canUse, s = t.height;

Page({
    data: {
        marginTop: e,
        marginBot: o,
        canUse: n,
        userInfo: {},
        height: s,
        showModal: !1,
        modalConfig: {
            content: "",
            showCancel: !1
        },
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 500,
        showLayer: !1,
        isLocation: !1,
        showScore: !1,
        percent: "0%",
        list: [],
        scope: !1,
        ad: []
    },
    onShow: function() {
        var t = this;
        wx.getStorageSync("token") && a.ajaxData({
            url: "/xcxapi/user/infoget",
            method: "GET",
            cb: function(e) {
                if (e.data.errcode) t.setData({
                    showAuth: !0
                }); else {
                    var o, n = e.data.data;
                    a.globalData.userInfo = n, wx.setStorageSync("userInfo", n), o = +n.score >= +n.max_score ? "100%" : Math.round(n.score / n.max_score * 100) + "%", 
                    t.setData({
                        userInfo: n,
                        percent: o
                    });
                }
            }
        });
    },
    onLoad: function() {
        a.mta(), this.checkScope(), this.setData({
            userInfo: a.globalData.userInfo
        }), this.getAd();
    },
    getAd: function() {
        var t = this;
        a.ajaxData({
            url: "/xcxapi/act/indexadv",
            method: "GET",
            cb: function(a) {
                var e = a.data;
                e.errcode ? wx.showModal({
                    title: "提示",
                    content: e.errmsg,
                    showCancel: !1,
                    complete: function() {}
                }) : t.setData({
                    ad: e.data
                });
            }
        });
    },
    checkScope: function() {
        var a = this;
        wx.getSetting({
            success: function(t) {
                1 == t.authSetting["scope.userLocation"] && (a.getSignData(), a.setData({
                    scope: !0
                }), console.log("用户已开启定位授权"));
            }
        });
    },
    setScope: function() {
        var a = this;
        wx.openSetting({
            success: function() {
                a.getSignData(), a.checkScope();
            },
            fail: function() {
                console.log("openSetting.failed");
            }
        });
    },
    getSignData: function() {
        var t = this;
        wx.getLocation({
            type: "wgs84",
            success: function(e) {
                a.globalData.isLocation = !0, t.setData({
                    isLocation: !0
                });
                var o = e.latitude, n = e.longitude;
                a.ajaxData({
                    url: "/xcxapi/act/cansignin",
                    method: "GET",
                    cb: function(e) {
                        var s = e.data.data, c = [];
                        for (var i in s) {
                            var r = Math.floor(a.getDistance(o, n, s[i].lat, s[i].lon));
                            r <= 5e3 && (r >= 1e3 ? r = (r / 1e3).toFixed(1) + "km" : r += "m", s[i].distance = r, 
                            c.push(s[i]));
                        }
                        t.setData({
                            list: c
                        });
                    }
                });
            },
            fail: function() {
                t.setData({
                    isLocation: !1
                }), a.globalData.isLocation = !1;
            }
        });
    },
    _checkEveryDayAuth: function() {
        if (wx.getStorageSync("userInfo")) {
            var t = this;
            a.ajaxData({
                url: "/xcxapi/daily/todayright",
                method: "GET",
                cb: function(a) {
                    1 == +a.data.data ? wx.navigateTo({
                        url: "/pages/everyday/index"
                    }) : t.showModal({
                        content: "今日份的答题次数用完喽~",
                        showCancel: !1
                    });
                }
            });
        } else this.setData({
            showAuth: !0
        });
    },
    catchTouchMove: function(a) {
        return !1;
    },
    showModal: function(a) {
        this.setData({
            showModal: !0,
            modalConfig: a
        });
    },
    _showLayer: function() {
        this.setData({
            showLayer: !0
        });
    },
    _hideLayer: function() {
        this.setData({
            showLayer: !1
        });
    },
    closeScore: function() {
        this.setData({
            showScore: !1
        });
    },
    onShareAppMessage: function(a) {
        this.setData({
            showSuccess: !1
        });
        var t = {
            title: "广州普法",
            path: "/pages/welcome/welcome",
            imageUrl: "../../statics/images/share2.jpg",
            success: function(a) {
                console.log(a), wx.navigateBack();
            },
            fail: function() {
                "shareAppMessage:fail cancel" == res.errMsg ? (console.log("cancel"), wx.showModal({
                    title: "cancel"
                })) : "shareAppMessage:fail" == res.errMsg && (console.log("fail"), wx.showModal({
                    title: "fail"
                }));
            },
            complete: function(a) {
                console.log(111111), wx.navigateBack();
            }
        };
        return "button" == a.from && (t.path = "/pages/welcome/welcome", t.imageUrl = "../../statics/images/share2.jpg"), 
        t;
    },
    jumpMini: function() {
        wx.navigateToMiniProgram({
            appId: "wx1ce51435207793c9",
            path: "/pages/index/index",
            success: function() {
                console.log("jump success!");
            },
            fail: function() {
                console.log("jump fail!");
            }
        });
    },
    setUserInfo: function() {
        a.getInfo();
    },
    closeAuth: function() {
        this.setData({
            showAuth: !1
        });
    },
    goto: function(a) {
        var t = a.currentTarget.dataset.url;
        wx.getStorageSync("userInfo") ? wx.navigateTo({
            url: t
        }) : this.setData({
            showAuth: !0
        });
    }
});