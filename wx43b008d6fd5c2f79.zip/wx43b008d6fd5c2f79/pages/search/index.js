var a = getApp();

Page({
    data: {
        list: [],
        keywords: ""
    },
    onLoad: function(t) {
        a.mta();
        var e = this, c = t.keywords;
        this.setData({
            keywords: c
        }), c ? a.ajaxData({
            url: "/xcxapi/act/actlist",
            method: "POST",
            data: {
                page: 1,
                per: 20,
                search: c
            },
            cb: function(a) {
                e.setData({
                    list: a.data.data
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "搜索关键词为空",
            showCancel: !1,
            complete: function() {
                wx.navigateBack();
            }
        });
    },
    back: function() {
        wx.navigateBack();
    }
});