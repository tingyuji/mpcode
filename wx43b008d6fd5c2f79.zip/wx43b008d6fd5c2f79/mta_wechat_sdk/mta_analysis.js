function t() {
    try {
        var t = "s" + n();
        return wx.setStorageSync(i.prefix + "ssid", t), t;
    } catch (t) {}
}

function n(t) {
    for (var n = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ], e = 10; 1 < e; e--) {
        var a = Math.floor(10 * Math.random()), r = n[a];
        n[a] = n[e - 1], n[e - 1] = r;
    }
    for (e = a = 0; 5 > e; e++) a = 10 * a + n[e];
    return (t || "") + (a + "") + +new Date();
}

function e() {
    try {
        var t = getCurrentPages(), n = "/";
        return 0 < t.length && (n = t.pop().__route__), n;
    } catch (t) {
        console.log("get current page path error:" + t);
    }
}

function a() {
    var a = {
        dm: "wechat.apps.xx",
        url: e(),
        pvi: "",
        si: "",
        ty: 0
    };
    return a.pvi = function() {
        var t = function() {
            try {
                return wx.getStorageSync(i.prefix + "auid");
            } catch (t) {}
        }();
        return t || (t = function() {
            try {
                var t = n();
                return wx.setStorageSync(i.prefix + "auid", t), t;
            } catch (t) {}
        }(), a.ty = 1), t;
    }(), a.si = function() {
        var n = function() {
            try {
                return wx.getStorageSync(i.prefix + "ssid");
            } catch (t) {}
        }();
        return n || (n = t()), n;
    }(), a;
}

function r() {
    var t = function() {
        var t = wx.getSystemInfoSync();
        return {
            adt: encodeURIComponent(t.model),
            scl: t.pixelRatio,
            scr: t.windowWidth + "x" + t.windowHeight,
            lg: t.language,
            fl: t.version,
            jv: encodeURIComponent(t.system),
            tz: encodeURIComponent(t.platform)
        };
    }();
    return function(t) {
        wx.getNetworkType({
            success: function(n) {
                t(n.networkType);
            }
        });
    }(function(t) {
        try {
            wx.setStorageSync(i.prefix + "ntdata", t);
        } catch (t) {}
    }), t.ct = wx.getStorageSync(i.prefix + "ntdata") || "4g", t;
}

function o() {
    var t, n = s.Data.userInfo, e = [];
    for (t in n) n.hasOwnProperty(t) && e.push(t + "=" + n[t]);
    return n = e.join(";"), {
        r2: i.app_id,
        r4: "wx",
        ext: "v=" + i.version + (null !== n && "" !== n ? ";ui=" + encodeURIComponent(n) : "")
    };
}

var i = {
    app_id: "",
    event_id: "",
    api_base: "https://pingtas.qq.com/pingd",
    prefix: "_mta_",
    version: "1.3.6",
    stat_share_app: !1,
    stat_pull_down_fresh: !1,
    stat_reach_bottom: !1
}, s = {
    App: {
        init: function(n) {
            "appID" in n && (i.app_id = n.appID), "eventID" in n && (i.event_id = n.eventID), 
            "statShareApp" in n && (i.stat_share_app = n.statShareApp), "statPullDownFresh" in n && (i.stat_pull_down_fresh = n.statPullDownFresh), 
            "statReachBottom" in n && (i.stat_reach_bottom = n.statReachBottom), t();
            try {
                "lauchOpts" in n && (s.Data.lanchInfo = n.lauchOpts, s.Data.lanchInfo.landing = 1);
            } catch (n) {}
        }
    },
    Page: {
        init: function() {
            var t = getCurrentPages()[getCurrentPages().length - 1];
            t.onShow && function() {
                var n = t.onShow;
                t.onShow = function() {
                    s.Page.stat(), n.call(this, arguments);
                };
            }(), i.stat_pull_down_fresh && t.onPullDownRefresh && function() {
                var n = t.onPullDownRefresh;
                t.onPullDownRefresh = function() {
                    s.Event.stat(i.prefix + "pulldownfresh", {
                        url: t.__route__
                    }), n.call(this, arguments);
                };
            }(), i.stat_reach_bottom && t.onReachBottom && function() {
                var n = t.onReachBottom;
                t.onReachBottom = function() {
                    s.Event.stat(i.prefix + "reachbottom", {
                        url: t.__route__
                    }), n.call(this, arguments);
                };
            }(), i.stat_share_app && t.onShareAppMessage && function() {
                var n = t.onShareAppMessage;
                t.onShareAppMessage = function() {
                    return s.Event.stat(i.prefix + "shareapp", {
                        url: t.__route__
                    }), n.call(this, arguments);
                };
            }();
        },
        multiStat: function(t, n) {
            if (1 == n) s.Page.stat(t); else {
                var e = getCurrentPages()[getCurrentPages().length - 1];
                e.onShow && function() {
                    var n = e.onShow;
                    e.onShow = function() {
                        s.Page.stat(t), n.call(this, arguments);
                    };
                }();
            }
        },
        stat: function(t) {
            if ("" != i.app_id) {
                var n = [], e = o();
                if (t && (e.r2 = t), t = [ a(), e, r() ], s.Data.lanchInfo) {
                    t.push({
                        ht: s.Data.lanchInfo.scene,
                        rdm: "/",
                        rurl: s.Data.lanchInfo.path
                    }), s.Data.lanchInfo.query && s.Data.lanchInfo.query._mta_ref_id && t.push({
                        rarg: s.Data.lanchInfo.query._mta_ref_id
                    });
                    try {
                        1 == s.Data.lanchInfo.landing && (e.ext += ";lp=1", s.Data.lanchInfo.landing = 0);
                    } catch (t) {}
                }
                t.push({
                    rand: +new Date()
                }), e = 0;
                for (var c = t.length; e < c; e++) for (var u in t[e]) t[e].hasOwnProperty(u) && n.push(u + "=" + (void 0 === t[e][u] ? "" : t[e][u]));
                wx.request({
                    url: i.api_base + "?" + n.join("&").toLowerCase()
                });
            }
        }
    },
    Event: {
        stat: function(t, n) {
            if ("" != i.event_id) {
                var e = [], s = a(), c = o();
                s.dm = "wxapps.click", s.url = t, c.r2 = i.event_id;
                var u, p = void 0 === n ? {} : n, h = [];
                for (u in p) p.hasOwnProperty(u) && h.push(encodeURIComponent(u) + "=" + encodeURIComponent(p[u]));
                for (p = h.join(";"), c.r5 = p, p = 0, c = (s = [ s, c, r(), {
                    rand: +new Date()
                } ]).length; p < c; p++) for (var f in s[p]) s[p].hasOwnProperty(f) && e.push(f + "=" + (void 0 === s[p][f] ? "" : s[p][f]));
                wx.request({
                    url: i.api_base + "?" + e.join("&").toLowerCase()
                });
            }
        }
    },
    Data: {
        userInfo: null,
        lanchInfo: null
    }
};

module.exports = s;