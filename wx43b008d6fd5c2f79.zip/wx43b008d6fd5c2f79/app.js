var e = require("@babel/runtime/helpers/regeneratorRuntime"), a = require("@babel/runtime/helpers/asyncToGenerator");

require("@babel/runtime/helpers/Arrayincludes");

var t = require("mta_wechat_sdk/mta_analysis.js");

App({
    onLaunch: function() {
        var e = this;
        t.App.init({
            appID: "500649013",
            eventID: "500649014",
            statPullDownFresh: !0,
            statShareApp: !0,
            statReachBottom: !0
        });
        var a = this, n = wx.getStorageSync("userInfo");
        wx.getStorageSync("token") && ("" != n ? this.globalData.userInfo = n : this.ajaxData({
            url: "/xcxapi/user/infoget",
            method: "GET",
            cb: function(e) {
                var t = e.data.data;
                a.globalData.userInfo = t, wx.setStorageSync("userInfo", t);
            }
        })), wx.getSystemInfo({
            success: function(a) {
                e.globalData.height = a.statusBarHeight, e.globalData.version = a.version, e.globalData.canUse = e.compareVersion(a.version, "7.0.0"), 
                e.globalData.model = a.model, e.globalData.marginTop = e.isIphonex(a.model) ? a.statusBarHeight + "rpx" : 2 * a.statusBarHeight + "rpx", 
                e.globalData.marginBot = e.isIphonex(a.model) ? "68rpx" : "0";
            }
        });
    },
    isIphonex: function(e) {
        return [ "iPhone X", "iPhone11" ].some(function(a) {
            return a.includes(e);
        });
    },
    compareVersion: function(e, a) {
        e = e.split("."), a = a.split(".");
        for (var t = Math.max(e.length, a.length); e.length < t; ) e.push("0");
        for (;a.length < t; ) a.push("0");
        for (var n = 0; n < t; n++) {
            var o = parseInt(e[n]), r = parseInt(a[n]);
            if (o > r) return 1;
            if (o < r) return -1;
        }
        return 0;
    },
    getInfo: function(t, n) {
        var o = this;
        return a(e().mark(function a() {
            var r, s, i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = {}, !0 === t) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 4, wx.getUserProfile({
                        desc: "用于完善会员资料"
                    });

                  case 4:
                    s = e.sent, r = s.userInfo;

                  case 6:
                    i = o, wx.login({
                        success: function(e) {
                            e.code && wx.request({
                                url: i.globalData.baseUrl + "/xcxapi/accesstoken",
                                method: "POST",
                                data: {
                                    code: e.code,
                                    appid: "130890112807",
                                    appsecret: "2ed9b3gy109iup73yuqsx3ha0cid2au5"
                                },
                                headers: {
                                    "content-type": "application/json"
                                },
                                success: function(e) {
                                    var a = e.data.accesstoken;
                                    if (wx.setStorageSync("token", a), 1 == +e.data.userinfo.needUpdate) {
                                        if (r.grade = "小菜鸟", r.uid = e.data.userinfo.uid, i.globalData.userInfo = r, wx.setStorageSync("userInfo", r), 
                                        i.ajaxData({
                                            url: "/xcxapi/user/infoupdate",
                                            method: "POST",
                                            data: {
                                                nick: r.nickName,
                                                avatar: r.avatarUrl,
                                                gender: r.gender
                                            },
                                            cb: function(e) {
                                                console.log(e);
                                            }
                                        }), t) return n && n();
                                        wx.reLaunch({
                                            url: "/pages/index/index"
                                        });
                                    } else {
                                        if (i.globalData.userInfo = e.data.userinfo, wx.setStorageSync("userInfo", e.data.userinfo), 
                                        t) return n && n();
                                        wx.reLaunch({
                                            url: "/pages/index/index"
                                        });
                                    }
                                }
                            });
                        },
                        fail: function(e) {
                            console.log(e);
                        }
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    ajaxData: function(e) {
        var a = this, t = this.globalData.baseUrl, n = wx.getStorageSync("token");
        wx.request({
            url: t + e.url,
            data: e.data,
            method: e.method,
            header: {
                "content-type": "application/json",
                Authorization: n
            },
            success: function(t) {
                switch (+t.data.errcode) {
                  case -1001:
                    console.log("reget"), a.getInfo(!0, function() {
                        a.ajaxData(e);
                    });
                    break;

                  case -1002:
                    a.getInfo(!0, function() {
                        a.ajaxData(e);
                    });
                    break;

                  default:
                    e.cb && e.cb(t);
                }
            },
            fail: function(e) {
                wx.showToast({
                    title: "网络开了小差~",
                    icon: "none"
                });
            },
            complete: function(e) {
                setTimeout(function() {
                    wx.hideLoading();
                }, 8e3);
            }
        });
    },
    upload: function(e) {
        var a = wx.getStorageSync("token");
        wx.uploadFile({
            url: this.globalData.baseUrl + e.url,
            filePath: e.filePath,
            name: e.name,
            formData: {
                type: e.type
            },
            header: {
                "content-type": "multipart/form-data",
                Authorization: a
            },
            success: function(a) {
                e.success && e.success(a);
            },
            fail: function(e) {
                console.log(e);
            }
        });
    },
    getDistance: function(e, a, t, n) {
        a = a || 0, t = t || 0, n = n || 0;
        var o = (e = e || 0) * Math.PI / 180, r = t * Math.PI / 180, s = o - r, i = a * Math.PI / 180 - n * Math.PI / 180;
        return 12756274 * Math.asin(Math.sqrt(Math.pow(Math.sin(s / 2), 2) + Math.cos(o) * Math.cos(r) * Math.pow(Math.sin(i / 2), 2)));
    },
    mta: function() {
        t.Page.init();
    },
    getParams: function(e) {
        return e.split("_")[1];
    },
    globalData: {
        height: 0,
        version: "7.0.0",
        canUse: 1,
        marginTop: 0,
        marginBot: 0,
        model: "",
        userInfo: null,
        isLocation: !1,
        baseUrl: "https://popularizinglaw.gzsfj.gov.cn"
    }
});