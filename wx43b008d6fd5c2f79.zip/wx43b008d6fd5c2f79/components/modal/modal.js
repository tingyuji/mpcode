Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        type: {
            type: String,
            value: "normal"
        },
        showCancel: {
            type: Boolean,
            value: !1
        },
        showConfirm: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        clickMask: function() {},
        cancel: function() {
            this.setData({
                show: !1
            }), this.triggerEvent("cancel");
        },
        confirm: function() {
            this.setData({
                show: !1
            }), this.triggerEvent("confirm");
        },
        catchTouchMove: function(t) {
            return !1;
        }
    }
});