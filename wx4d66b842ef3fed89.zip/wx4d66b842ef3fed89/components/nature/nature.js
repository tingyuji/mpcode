var t = require("../../utils/util.js").formatTime;

require("../../utils/lunar");

Component({
    properties: {
        showNature: {
            type: Boolean,
            value: !1,
            observer: function(a) {
                var s = this;
                if (a) {
                    var e, o = +new Date(), i = wx.getStorageSync("startAt"), n = parseInt(wx.getStorageSync("remainDuration"));
                    parseInt((o - i) / 1e3) < n && wx.getStorageSync("mute") || this.start(), e = this.data.date !== t(new Date(), "yyyy-MM-dd") ? "当日声音" : "今日声音", 
                    wx.setNavigationBarTitle({
                        title: e
                    }), wx.getStorageSync("guided") || this.setData({
                        showGuide: !0
                    });
                } else wx.setNavigationBarTitle({
                    title: "潮汐日历"
                }), this.setData({
                    showGuide: !1
                });
                setTimeout(function() {
                    s.setData({
                        ted: a
                    });
                }, 300);
            }
        },
        showGuide: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && wx.setStorageSync("guided", !0);
            }
        },
        soundName: String,
        soundUrl: String,
        soundIconUrl: String,
        date: {
            type: String,
            value: "2018-01-01",
            observer: function(a) {
                if (a) {
                    var s = t(a, "MM月dd日"), e = "https://pics.tide.moreless.io/tidetime/share/".concat(a, ".png"), o = {};
                    s !== this.data.title && (o.title = s), e !== this.data.bgm_cover && (o.bgm_cover = e), 
                    this.setData(o);
                    var i = this.data, n = i.status, r = i.BGM;
                    "playing" === n && (r.src && r.src === this.data.soundUrl || this.start());
                }
            }
        },
        imgUrl: {
            type: String,
            value: "",
            observer: function(t) {
                var a = "";
                t && (a = "".concat(t, "/blur/32x32")), this.setData({
                    bg: a
                });
            }
        }
    },
    data: {
        title: "",
        BGM: null,
        status: "stop",
        tomatoStatus: "stop",
        tomatoPickerShow: !1,
        tomatoDuration: 15,
        mute: !1,
        size: "1",
        bg: "",
        bgm_cover: "",
        tips: "",
        tipsHandle: null,
        showTips: !1,
        showGuide: !1,
        ted: !1
    },
    ready: function() {
        var t = "";
        this.data.imgUrl && (t = "".concat(this.data.imgUrl, "/blur/32x32")), this.setData({
            bg: t
        }), this.initBGM();
    },
    methods: {
        showTips: function(t) {
            var a = this;
            clearTimeout(this.data.tipsHandle), this.setData({
                showTips: !0,
                tips: t,
                tipsHandle: setTimeout(function() {
                    a.setData({
                        showTips: !1
                    });
                }, 3e3)
            });
        },
        hideGuide: function() {
            this.setData({
                showGuide: !1
            });
        },
        initBGM: function() {
            var t = this, a = this.data.date, s = "stop", e = !1;
            try {
                s = (s = wx.getStorageSync("status") || "stop") || "stop";
                var o = +new Date(), i = wx.getStorageSync("startAt"), n = parseInt(wx.getStorageSync("remainDuration")), r = parseInt((o - i) / 1e3);
                e = "playing" === s || r < n;
            } catch (t) {
                console.log(t);
            }
            var u = wx.getBackgroundAudioManager(), h = {
                BGM: u,
                showNature: e,
                bgm_cover: "https://pics.tide.moreless.io/tidetime/share/".concat(a, ".png")
            };
            this.setData(h), u.onPlay(function() {
                t.setData({
                    status: "playing"
                });
            }), u.onPause(function() {
                console.log("pause"), t.pause();
            }), u.onStop(function() {
                console.log("stop"), t.setData({
                    status: "stop"
                });
            }), u.onEnded(function() {
                console.log("end"), t.encore();
            });
        },
        start: function() {
            this.setData({
                status: "playing",
                mute: !1
            }), this.playBGM(), wx.setStorageSync("status", "playing"), wx.removeStorage({
                key: "mute"
            });
        },
        pause: function() {
            this.pauseBGM(), this.setData({
                status: "pause"
            }), wx.setStorageSync("status", "pause");
        },
        stop: function() {
            this.stopBGM(), this.setData({
                tomatoStatus: !1,
                showNature: !1
            }), wx.setStorageSync("status", "stop"), wx.removeStorage({
                key: "startAt"
            }), wx.removeStorage({
                key: "remainDuration"
            });
        },
        playBGM: function() {
            console.log(this.data);
            var t = this.data, a = (t.date, t.BGM), s = t.soundUrl, e = t.bgm_cover;
            a || this.initBGM(), console.log("playBGM"), console.log(s), a.title = "潮汐日历 · 今日声音", 
            a.src = s, a.coverImgUrl = e, a.play();
        },
        pauseBGM: function() {
            wx.pauseBackgroundAudio();
        },
        stopBGM: function() {
            wx.stopBackgroundAudio();
        },
        encore: function() {
            "playing" === this.data.status && this.playBGM();
        },
        toggleMute: function() {
            if ("playing" !== this.data.status) this.start(), wx.removeStorage({
                key: "mute"
            }), this.showTips("声音已恢复播放"); else {
                var t = !this.data.mute;
                this.pause(), this.setData({
                    mute: t
                }), wx.setStorage({
                    key: "mute",
                    data: !0
                }), this.showTips("声音已停止，点击圆圈恢复");
            }
        },
        hideTomatoPicker: function() {
            this.setData({
                tomatoPickerShow: !1
            });
        },
        toggleTomato: function() {
            this.setData({
                tomatoPickerShow: !0
            });
        },
        startTomato: function(t) {
            this.setData({
                tomatoStatus: !1
            });
            var a = t.detail.duration;
            a > 0 && (this.setData({
                tomatoDuration: a,
                tomatoStatus: "playing"
            }), this.data.mute || "pause" !== this.data.status || this.start()), this.setData({
                tomatoPickerShow: !1
            });
        },
        stopTomato: function() {
            this.showTips("计时已结束"), this.setData({
                tomatoStatus: !1
            }), this.pause();
        }
    }
});