Component({
    properties: {
        enabled: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t ? (console.log("start"), this.start()) : (console.log("stop"), this.reset());
            }
        },
        duration: {
            type: Number,
            value: 15
        },
        soundName: String,
        soundUrl: String,
        soundIconUrl: String,
        date: {
            type: String,
            value: "",
            observer: function(t) {
                var e = t ? "https://pics.tide.moreless.io/tidetime/icons/".concat(t, ".png?").concat(+new Date()) : "";
                this.setData({
                    iconUrl: e
                });
            }
        }
    },
    data: {
        startAt: 0,
        remain: 0,
        remainDuration: 0,
        remainStr: "25:00",
        ring: null,
        iconUrl: ""
    },
    ready: function() {
        var t = this;
        this.setData({
            iconUrl: "https://pics.tide.moreless.io/tidetime/icons/".concat(this.data.date, ".png?").concat(+new Date())
        }), wx.downloadFile({
            url: "https://pics.tide.moreless.io/tidetime/ring.mp3",
            success: function(e) {
                var a = wx.createInnerAudioContext();
                a.obeyMuteSwitch = !1, a.src = "https://pics.tide.moreless.io/tidetime/ring.mp3", 
                t.setData({
                    ring: a
                });
            }
        });
        var e = +new Date(), a = wx.getStorageSync("startAt"), r = parseInt(wx.getStorageSync("remainDuration")), n = parseInt((e - a) / 1e3);
        n < r && this.setData({
            startAt: a,
            remainDuration: r,
            duration: r - n,
            enabled: !0
        });
    },
    methods: {
        start: function() {
            if (this.data.enabled) {
                var t = this.data.duration, e = +new Date(), a = t;
                this.setData({
                    remainDuration: t,
                    startAt: e
                }), wx.setStorage({
                    key: "startAt",
                    data: e
                }), wx.setStorage({
                    key: "remainDuration",
                    data: a
                }), this.progress();
            }
        },
        reset: function() {
            wx.removeStorage({
                key: "startAt"
            }), wx.removeStorage({
                key: "remainDuration"
            }), this.setData({
                startAt: 0
            });
        },
        stop: function() {
            this.reset(), this.triggerEvent("stop", {}), this.data.ring.play();
        },
        progress: function() {
            var t = this, e = this.data, a = e.remainDuration, r = e.startAt;
            if (this.data.enabled) {
                var n = a - parseInt((+new Date() - r) / 1e3);
                this.setData({
                    remain: n,
                    remainStr: this.convertTime(n)
                }), wx.setStorageSync("remain", n), n <= 0 ? this.stop() : setTimeout(function() {
                    t.progress();
                }, 1e3);
            }
        },
        convertTime: function(t) {
            var e = parseInt(t / 60), a = t % 60;
            return e = e < 10 ? "0".concat(e) : e, a = a < 10 ? "0".concat(a) : a, "".concat(e, ":").concat(a);
        }
    }
});