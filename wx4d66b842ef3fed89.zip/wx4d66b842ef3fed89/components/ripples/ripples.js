var a = require("../../@babel/runtime/helpers/toConsumableArray");

Component({
    properties: {
        enabled: {
            type: Boolean,
            value: !1,
            observer: function(a) {
                var e = this;
                a ? (this.waveLoop(), clearInterval(this.data.loopHandle), this.setData({
                    loopHandle: setInterval(function() {
                        e.waveLoop();
                    }, 1700)
                })) : clearInterval(this.data.loopHandle);
            }
        }
    },
    data: {
        loopHandle: null,
        currWave: 0,
        waves: [ {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        } ]
    },
    methods: {
        waveLoop: function() {
            var e = this.data, l = e.waves, s = e.currWave, t = s >= l.length - 1 ? 0 : s + 1, i = a(l);
            i[s].display = !0, i[t].display = !1, this.setData({
                waves: i,
                currWave: t
            });
        }
    }
});