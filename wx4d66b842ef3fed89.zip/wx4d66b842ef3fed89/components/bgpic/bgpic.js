Component({
    properties: {
        dailies: {
            type: Array,
            value: [],
            observer: function(t) {
                var a = this.data.date, e = t.findIndex(function(t) {
                    return t.date === a;
                });
                this.setData({
                    dailyCurrent: e
                });
            }
        },
        date: {
            type: String,
            value: "2017-12-27"
        }
    },
    data: {
        sensors: [ 0, 1, 2 ],
        dailyCurrent: 0,
        current: 1,
        touching: !1,
        originPoint: 0,
        width: 0,
        prevBgOpacity: 0,
        nextBgOpacity: 0,
        changeHandle: null
    },
    ready: function() {
        var t = wx.getSystemInfoSync();
        this.setData({
            width: t.windowWidth
        });
    },
    methods: {
        touchstart: function(t) {
            this.setData({
                touching: !0,
                originPoint: t.touches[0].clientX
            });
        },
        touchend: function(t) {
            var a = this;
            this.setData({
                touching: !1,
                originPoint: 0
            }), clearTimeout(this.data.changeHandle), this.setData({
                changeHandle: setTimeout(function() {
                    a.setData({
                        prevBgOpacity: 0,
                        nextBgOpacity: 0
                    });
                }, 200)
            });
        },
        touchmove: function(t) {
            var a = t.touches[0].clientX, e = this.data, i = e.touching, n = e.originPoint, r = e.width;
            if (i) {
                var c = a - n, o = {
                    prevBgOpacity: 0,
                    nextBgOpacity: 0
                };
                c < 0 ? (c *= -1, o.prevBgOpacity = c / r) : o.nextBgOpacity = c / r, this.setData(o);
            }
        },
        bgChange: function(t) {
            clearTimeout(this.data.changeHandle);
            var a, e = this.data.current, i = t.detail.current;
            a = 0 === i && 2 === e ? "left" : 2 === i && 0 === e || i > e ? "right" : "left";
            var n = {
                prevBgOpacity: 0,
                nextBgOpacity: 0,
                current: i
            };
            n.dailyCurrent = "left" === a ? this.data.dailyCurrent - 1 : this.data.dailyCurrent + 1, 
            this.setData(n);
        }
    }
});