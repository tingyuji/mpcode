var t = require("utils/wxRequest"), e = require("utils/wxApi"), n = require("utils/util"), a = n.Promise;

App({
    onShow: function(t) {},
    init: function() {
        var t = this;
        return new a(function(e, n) {
            t.checkSetting().then(function() {
                return t.checkSession();
            }).then(function() {
                e();
            }).catch(function(t) {
                e();
            });
        });
    },
    checkSession: function() {
        return new a(function(t, n) {
            var a = wx.getStorageSync("sid", a);
            a ? e.wxCheckSession()().then(function() {
                t();
            }).catch(function() {
                n();
            }) : n();
        });
    },
    checkSetting: function() {
        var t = this;
        return new a(function(n, a) {
            wx.canIUse("button.open-type.getUserInfo") ? setTimeout(function() {
                e.wxGetSetting()().then(function(e) {
                    e.authSetting["scope.userInfo"] ? t.globalData.userAuth = !0 : t.globalData.userAuth = !1, 
                    n();
                }).catch(function(t) {
                    a(t);
                });
            }) : e.wxGetUserInfo()().then(function(e) {
                t.globalData.userAuth = !0, n(e);
            }).catch(function(n) {
                t.globalData.userAuth = !1, a(n), e.wxShowModal()({
                    title: "_(:_」∠)_ 哎呀，被拒绝了",
                    content: "请返回小程序列表删除后重新打开，同意授权即可正常使用。",
                    showCancel: !1
                });
            });
        });
    },
    login: function() {
        return e.wxLogin()().then(function(e) {
            return t({
                url: "/login",
                method: "POST",
                data: {
                    code: e.code
                }
            });
        }).then(function(t) {
            var e = t.data.sid;
            wx.setStorageSync("sid", e);
        });
    },
    setUserInfo: function(e) {
        this.globalData.userInfo = e;
        var n = wx.getStorageSync("sid");
        return t({
            url: "/user",
            method: "POST",
            data: {
                rawData: e.rawData,
                signature: e.signature,
                encryptedData: e.encryptedData,
                iv: e.iv,
                sid: n
            }
        });
    },
    getUserInfo: function() {
        var t = this;
        return new a(function(n, a) {
            if (t.globalData.userInfo) n(t.globalData.userInfo); else if (t.globalData.userAuth) {
                e.wxGetUserInfo()({
                    withCredentials: !0
                }).then(function(e) {
                    t.globalData.userInfo = e, n(e);
                }).catch(function(t) {
                    a(t);
                });
            } else a({
                errMsg: "getUserInfo:fail auth deny"
            });
        });
    },
    getMine: function(e) {
        var i = this, o = n.getUTC8Date(), u = o.getDate() - o.getDay(), r = o.getDate() + (6 - o.getDay()), c = n.getUTC8Date(o.getFullYear(), o.getMonth(), u), s = n.getUTC8Date(o.getFullYear(), o.getMonth(), r), l = n.formatTime(c, "yyyy-MM-dd"), f = n.formatTime(s, "yyyy-MM-dd");
        return new a(function(n, a) {
            e || !i.globalData.mine ? t({
                url: "/mine",
                data: {
                    start: l,
                    end: f
                }
            }).then(function(t) {
                i.globalData.mine = t.data, n(i.globalData.mine);
            }).catch(function(t) {
                a(t);
            }) : n(i.globalData.mine);
        });
    },
    getSID: function() {
        return wx.getStorageSync("sid");
    },
    getApiBaseUrl: function() {
        return "https://tide-api.moreless.io";
    },
    globalData: {
        inited: null,
        mine: null,
        userInfo: null,
        userAuth: !1
    }
});