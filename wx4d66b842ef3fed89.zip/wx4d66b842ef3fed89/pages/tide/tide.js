var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("../../utils/util.js"), e = a.formatNumber, i = a.formatTime, s = (a.unique, 
a.getDateStrings, getApp(), require("../../utils/wxRequest"));

require("../../utils/wxApi");

Page({
    onShareAppMessage: function() {
        i(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历 · 专注",
            imageUrl: "http://davinci.tide.moreless.io/static/img/logo.f4ea62a.png",
            path: "/pages/tide/tide"
        };
    },
    data: {
        BGM: null,
        current: 0,
        startAt: 0,
        duration: 1500,
        remainDuration: 1500,
        remain: 1500,
        durationStr: "25:00",
        remainStr: "",
        status: "stop",
        picUrl: "",
        bgPosition: 60,
        width: 375,
        height: 0,
        loopHandle: null,
        currWave: 0,
        waves: [ {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        }, {
            display: !1
        } ],
        scenes: [ {
            id: "forest",
            name: "森林",
            color: "0,0,0,0.08",
            iconUrl: "/imgs/ic_forest_white.png",
            audioUrl: "http://pics.tide.moreless.io/demo_sounds/lvXeVL_M7RhTL6A1d8iAp54vuoo3"
        }, {
            id: "ocean",
            name: "浪花",
            color: "0,0,255,0.48",
            iconUrl: "/imgs/ic_ship_white.png",
            audioUrl: "http://pics.tide.moreless.io/demo_sounds/FtVu5WLJ1D4FaPBb7kE60fBR_Y4e"
        }, {
            id: "rain",
            name: "雨天",
            color: "0,0,255,0.08",
            iconUrl: "/imgs/ic_rain_white.png",
            audioUrl: "http://pics.tide.moreless.io/demo_sounds/Frx9B1QIusm-q-xqSh57ePCrF3_8"
        } ]
    },
    convertTime: function(t) {
        var a = parseInt(t / 60), e = t % 60;
        return a = a < 10 ? "0".concat(a) : a, e = e < 10 ? "0".concat(e) : e, "".concat(a, ":").concat(e);
    },
    convertCodeToDate: function(t) {
        var a = parseInt(t / 1e4), i = parseInt(t / 100) % (100 * a), s = t % (100 * (100 * a + i));
        return "".concat(a, "-").concat(e(i), "-").concat(e(s));
    },
    init: function(t) {
        var a = this;
        s({
            url: "/v1/dailypics/".concat(t),
            method: "get"
        }).then(function(t) {
            var e = a.data, i = e.height * e.pixelRatio;
            a.setData({
                picUrl: "".concat(t.data.pic_url, "?imageMogr2/thumbnail/").concat(i, "x").concat(i, "!/quality/90")
            });
        });
    },
    start: function() {
        var t = this.data, a = t.status, e = t.scenes, i = t.duration, s = t.current;
        if ("playing" !== a) {
            var n = e[s], o = wx.getStorageSync("startAt") || +new Date();
            this.playBGM(n), this.setData({
                status: "playing",
                remainDuration: i,
                startAt: o
            }), wx.setStorage({
                key: "status",
                data: "playing"
            }), wx.setStorage({
                key: "startAt",
                data: o
            }), this.progress(), this.toggle();
        }
    },
    continue: function() {
        var t = this.data, a = t.status, e = t.scenes, i = t.remain, s = t.current;
        if ("playing" !== a) {
            var n = e[s], o = +new Date();
            this.playBGM(n), this.setData({
                status: "playing",
                remainDuration: i,
                startAt: o
            }), wx.setStorage({
                key: "status",
                data: "playing"
            }), wx.setStorage({
                key: "startAt",
                data: o
            }), wx.setStorage({
                key: "remainDuration",
                data: i
            }), this.progress(), this.toggle();
        }
    },
    pause: function() {
        var t = this.data.remain;
        this.setData({
            status: "pause",
            remainDuration: t
        }), this.pauseBGM(), this.toggle(), wx.setStorage({
            key: "status",
            data: "pause"
        }), wx.setStorage({
            key: "remainDuration",
            data: t
        });
    },
    stop: function() {
        this.setData({
            status: "stop",
            startAt: 0
        }), this.stopBGM(), this.toggle(), wx.setStorage({
            key: "status",
            data: "stop"
        }), wx.setStorage({
            key: "startAt",
            data: 0
        }), wx.setStorage({
            key: "remainDuration",
            data: 1500
        });
    },
    progress: function() {
        var t = this, a = this.data, e = a.remainDuration, i = a.startAt;
        if ("playing" === a.status) {
            var s = e - parseInt((+new Date() - i) / 1e3);
            s <= 0 ? this.stop() : (this.setData({
                remain: s,
                remainStr: this.convertTime(s)
            }), wx.setStorageSync("remain", s), setTimeout(function() {
                t.progress();
            }, 1e3));
        }
    },
    correctBgPosition: function() {
        var t = this;
        setTimeout(function() {
            var a = 60 * (t.data.current + 1);
            t.setData({
                bgPosition: a
            });
        }, 50);
    },
    tapScene: function(t) {
        var a = t.target.dataset.index;
        this.setData({
            current: a
        }), wx.setStorageSync("current", a);
        var e = this.status, i = this.scenes;
        if ("playing" === e) {
            var s = i[a];
            this.playBGM(s);
        }
        this.correctBgPosition();
    },
    switchScene: function(t) {
        var a = t.detail.current;
        if (console.log("switchScene:", 60 * (a + 1)), this.setData({
            current: a
        }), wx.setStorageSync("current", a), "playing" === this.data.status) {
            var e = this.data.scenes[a];
            this.playBGM(e);
        }
        this.correctBgPosition();
    },
    nextScene: function() {
        var t, a = this.data, e = a.current, i = a.scenes;
        if (t = e === i.length - 1 ? 0 : e + 1, this.setData({
            current: t
        }), wx.setStorageSync("current", t), "playing" === this.data.status) {
            var s = i[t];
            this.playBGM(s);
        }
        this.correctBgPosition();
    },
    prevScene: function() {
        var t, a = this.data, e = a.current, i = a.scenes;
        if (t = 0 === e ? i.length - 1 : e - 1, this.setData({
            current: t
        }), wx.setStorageSync("current", t), "playing" === this.data.status) {
            var s = i[t];
            this.playBGM(s);
        }
        this.correctBgPosition();
    },
    initBGM: function() {
        var t = this, a = "stop", e = 0;
        try {
            a = wx.getStorageSync("status") || "stop", e = wx.getStorageSync("startAt") || 0, 
            remainDuration = wx.getStorageSync("remainDuration") || this.data.duration, console.log(a), 
            console.log(e);
            var i = remainDuration - parseInt((+new Date() - e) / 1e3);
            this.setData({
                status: a || "stop",
                startAt: e || 0,
                remain: i,
                remainStr: this.convertTime(i)
            }), "playing" === a && (this.progress(), this.toggle());
        } catch (t) {
            console.log(t);
        }
        var s = wx.getBackgroundAudioManager();
        this.setData({
            BGM: s
        }), "playing" !== a || s.src || this.encore(), s.onPlay(function() {
            console.log("play"), t.continue();
        }), s.onPause(function() {
            console.log("pause"), t.pause();
        }), s.onStop(function() {
            console.log("stop");
        }), s.onEnded(function() {
            console.log("end"), t.encore();
        }), s.onPrev(function() {
            t.prevScene();
        }), s.onNext(function() {
            t.nextScene();
        }), this.setData({
            BGM: s
        });
    },
    playBGM: function(t) {
        var a = t.name, e = t.audioUrl;
        wx.playBackgroundAudio({
            title: "潮汐日历 · ".concat(a),
            coverImgUrl: this.data.picUrl,
            dataUrl: e
        });
    },
    pauseBGM: function() {
        wx.pauseBackgroundAudio();
    },
    stopBGM: function() {
        wx.stopBackgroundAudio();
    },
    encore: function() {
        var t = this.data, a = t.status, e = t.scenes, i = t.current;
        if ("playing" === a) {
            var s = e[i];
            this.playBGM(s);
        }
    },
    touchstart: function() {
        this.setData({
            touching: !0
        });
    },
    touchend: function() {
        this.setData({
            touching: !1
        }), this.correctBgPosition();
    },
    touchmove: function() {
        var t = this, a = this.data, e = a.width;
        a.touching && wx.createSelectorQuery().select("#scene_0").fields({
            rect: !0
        }, function(a) {
            var i = (1 + ~a.left) / e * 60;
            console.log(i), t.setData({
                bgPosition: i
            });
        }).exec();
    },
    onLoad: function(t) {
        wx.showShareMenu();
        var a = wx.getStorageSync("current"), e = wx.getSystemInfoSync();
        this.setData({
            current: a,
            width: e.windowWidth,
            height: e.windowHeight,
            pixelRatio: e.pixelRatio
        }), this.initBGM();
        var s = t.date;
        if (s) {
            var n = s % (1e4 * parseInt(s / 1e4));
            n < 100 ? this.specialCodeHandle_A(s) : n % 100 ? this.init(this.convertCodeToDate(s)) : this.specialCodeHandle_B(s);
        } else this.init(i(new Date(), "yyyy-MM-dd"));
    },
    onUnload: function() {},
    waveLoop: function() {
        var a = this.data, e = a.waves, i = a.currWave;
        console.log(e, i);
        var s = i >= e.length - 1 ? 0 : i + 1, n = t(e);
        n[i].display = !0, n[s].display = !1, this.setData({
            waves: n,
            currWave: s
        });
    },
    toggle: function() {
        "playing" === this.data.status ? (this.waveLoop(), clearInterval(this.data.loopHandle), 
        this.setData({
            loopHandle: setInterval(this.waveLoop, 1500)
        })) : (clearInterval(this.data.loopHandle), this.setData({
            loopHandle: null
        }));
    }
});