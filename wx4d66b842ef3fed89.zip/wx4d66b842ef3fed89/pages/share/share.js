var t = require("../../utils/util.js"), e = t.formatNumber, i = t.formatTime, n = (t.unique, 
t.getDateStrings, getApp(), require("../../utils/wxRequest"), require("../../utils/wxApi"));

Page({
    onShareAppMessage: function(t) {
        return {
            title: "潮汐日历",
            imageUrl: this.data.picUrl,
            path: "/pages/index/index"
        };
    },
    data: {
        height: 0,
        sdkVersion: "",
        picUrl: "",
        dateData: {}
    },
    convertCodeToDate: function(t) {
        var i = parseInt(t / 1e4), n = parseInt(t / 100) % (100 * i), o = t % (100 * (100 * i + n));
        return "".concat(i, "-").concat(e(n), "-").concat(e(o));
    },
    init: function(t) {
        this.setData({
            date: t,
            picUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png")
        });
    },
    checkAuth: function(t) {
        wx.getSetting({
            fail: function(e) {
                t(!1);
            },
            success: function(e) {
                e.authSetting["scope.writePhotosAlbum"] || void 0 === e.authSetting["scope.writePhotosAlbum"] ? t(!0) : wx.showModal({
                    title: "需要打开保存到相册的权限",
                    success: function(e) {
                        e.confirm ? wx.openSetting({
                            fail: function(e) {
                                t(!1);
                            },
                            success: function(e) {
                                e.authSetting["scope.writePhotosAlbum"] ? t(!0) : t(!1);
                            }
                        }) : t(!1);
                    }
                });
            }
        });
    },
    preview: function() {
        n.wxPreviewImage()({
            urls: [ this.data.picUrl ]
        });
    },
    save: function() {
        var t = this;
        this.checkAuth(function(e) {
            if (e) {
                var i = t.data.picUrl;
                n.wxDownloadFile();
                wx.showLoading({
                    title: "正在生成海报"
                }), wx.downloadFile({
                    url: i,
                    fail: function(t) {
                        wx.hideLoading(), wx.showModal({
                            title: "未能保存",
                            content: "海报下载失败",
                            confirmText: "确定",
                            showCancel: !1
                        });
                    },
                    success: function(t) {
                        var e = t.tempFilePath;
                        wx.saveImageToPhotosAlbum({
                            filePath: e,
                            fail: function() {
                                wx.hideLoading(), wx.showModal({
                                    title: "未能保存",
                                    content: "保存到系统相册时失败",
                                    confirmText: "确定",
                                    showCancel: !1
                                });
                            },
                            success: function() {
                                wx.hideLoading(), wx.showModal({
                                    title: "潮汐日历已保存到系统相册",
                                    content: "快去分享给朋友，叫伙伴们来围观吧",
                                    confirmText: "我知道了",
                                    showCancel: !1
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    onLoad: function(t) {
        wx.showShareMenu();
        var e = wx.getSystemInfoSync();
        this.setData({
            sdkVersion: e.SDKVersion,
            height: e.windowHeight
        });
        var n = t.date;
        n ? this.init(n) : this.init(i(new Date(), "yyyy-MM-dd"));
    }
});