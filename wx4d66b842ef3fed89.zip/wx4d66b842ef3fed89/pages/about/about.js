var e = require("../../utils/util.js"), t = (e.formatNumber, e.formatTime);

e.unique, e.getDateStrings, getApp(), require("../../utils/wxRequest"), require("../../utils/wxApi");

Page({
    onShareAppMessage: function() {
        var e = t(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(e, ".png"),
            path: "/pages/index/index"
        };
    },
    gotoMinshop: function() {
        wx.navigateToMiniProgram({
            appId: "wx0fb2deb433acffc4",
            path: "pages/detail/detail?id=2260"
        });
    },
    onLoad: function(e) {
        wx.showShareMenu();
    }
});