var t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../utils/util.js"), e = a.formatNumber, n = a.formatTime, i = (a.unique, 
getApp(), require("../../utils/wxRequest")), s = (require("../../utils/wxApi"), 
require("../../utils/lunar"));

Page({
    onShareAppMessage: function() {
        var t = n(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png"),
            path: "/pages/index/index"
        };
    },
    data: {
        settings: {},
        width: 0,
        height: 0,
        current: 0,
        duration: 300,
        audioStatus: "stop",
        offset: 20,
        calendar: [],
        dailypics: {},
        noToday: !1,
        lock: !1,
        refreshCalendarHandle: null
    },
    fetchDays: function(t) {
        var a = this, e = new Date(t), s = e.getFullYear(), o = e.getMonth(), r = e.getDate(), d = r + 2, c = new Date(s, o, r - 2), l = new Date(s, o, d), u = n(c, "yyyy-MM-dd"), h = n(l, "yyyy-MM-dd");
        i({
            url: "/v1/dailypics",
            method: "get",
            data: {
                from: u,
                to: h
            }
        }).then(function(t) {
            var e = t.data;
            a.syncData(e);
        });
    },
    generateCalendar: function(t) {
        console.log(t);
        for (var a = new Date(t), e = a.getFullYear(), i = a.getMonth(), s = a.getDate(), o = this.data.offset, r = 2 * o + 1, d = s + o, c = new Date(e, i, s - o), l = new Date(e, i, d), u = [], h = n(c, "yyyy-MM-dd"), y = n(l, "yyyy-MM-dd"), g = h; g !== y; ) {
            u.push(g);
            var p = new Date(g);
            p.setDate(p.getDate() + 1), g = n(p, "yyyy-MM-dd");
        }
        u.push(g);
        var f = this.data.calendar.findIndex(function(a) {
            return a === t;
        }), D = [], w = {};
        D.length = r;
        var v = f - o, m = n(new Date(), "yyyy-MM-dd");
        this.data.calendar[this.data.current] === m && 0 === this.data.current && (v -= 1, 
        w.current = u.length - 1), u.forEach(function(t) {
            v < 0 ? D[r + v] = t : v > 2 * o ? D[v - r] = t : D[v] = t, v++;
        }), w.calendar = D, this.setData(w);
    },
    syncData: function(a) {
        var e = this, i = n(new Date(), "yyyy-MM-dd"), o = {};
        a.forEach(function(a) {
            var n = a.date, r = n.split("-"), d = t(r, 3), c = d[0], l = d[1], u = d[2], h = e.data.settings.bg_blur;
            o[n] = {
                show: !1,
                day: u,
                month: l,
                year: c,
                date: n,
                noToday: n !== i,
                lunar: s(n),
                pic_url: "".concat(a.pic_url, "?imageMogr2/thumbnail/1024x1024!").concat(h ? "/blur/20x5" : "", "/quality/90"),
                quote: a.content["zh-Hans"].quote.text,
                author: a.content["zh-Hans"].author.text
            };
        }), this.setData({
            dailypics: Object.assign(o, this.data.dailypics)
        });
    },
    convertCodeToDate: function(t) {
        var a = parseInt(t / 1e4), n = parseInt(t / 100) % (100 * a), i = t % (100 * (100 * a + n));
        return "".concat(a, "-").concat(e(n), "-").concat(e(i));
    },
    touchstart: function(t) {
        console.log(t);
    },
    dateChanged: function(t) {
        var a = this, e = t.detail, n = e.current;
        if ("touch" === e.source) {
            var i = this.data.calendar[n], s = this.data.dailypics[i].noToday, o = {
                current: n
            };
            o["dailypics.".concat(i, ".show")] = !0, console.log(this.data.noToday, s), this.data.noToday === s || s || (o.lock = !0), 
            this.setData(o), this.fetchDays(i), clearTimeout(this.refreshCalendarHandle), this.refreshCalendarHandle = setTimeout(function() {
                a.generateCalendar(i), a.setData({
                    lock: !1,
                    noToday: a.data.dailypics[i].noToday
                });
            }, 200);
        }
    },
    prevDate: function() {
        var t = this.data.current;
        0 === t ? t = this.data.calendar.length - 1 : t -= 1, console.log(t);
        var a = this.data.calendar[t], e = {
            current: t
        };
        e["dailypics.".concat(a, ".show")] = !0, this.setData(e), this.fetchDays(a), clearTimeout(this.refreshCalendarHandle);
    },
    nextDate: function() {
        var t = this, a = this.data.current;
        a === this.data.calendar.length - 1 ? a = 0 : a += 1;
        var e = this.data.calendar[a], n = {
            current: a
        };
        n["dailypics.".concat(e, ".show")] = !0, this.setData(n), this.fetchDays(e), clearTimeout(this.refreshCalendarHandle), 
        this.refreshCalendarHandle = setTimeout(function() {
            t.generateCalendar(e);
        }, 500);
    },
    playAudio: function() {
        console.log(this.data.calendar), console.log(this.data.current);
        var t = this.data.calendar[this.data.current];
        console.log(t);
        var a = this.data.dailypics[t];
        console.log(this.data.dailypics);
        var e = this.data.current % 2;
        wx.playBackgroundAudio({
            title: "潮汐日历 · ".concat(a.date),
            dataUrl: [ "http://pics.tide.moreless.io/demo_sounds/lowwxwth4ujxfDDUYeNhfQXllT7K", "http://pics.tide.moreless.io/demo_sounds/FtVu5WLJ1D4FaPBb7kE60fBR_Y4e" ][e],
            coverImgUrl: a.pic_url
        });
    },
    stopAudio: function() {
        this.setData({
            audioStatus: "stop"
        }), wx.stopBackgroundAudio(), console.log(stopBackgroundAudio);
    },
    listenAudio: function() {
        var t = this;
        wx.onBackgroundAudioPlay(function() {
            t.setData({
                audioStatus: "playing"
            });
        }), wx.onBackgroundAudioStop(function() {
            "playing" === t.data.audioStatus && t.playAudio();
        });
    },
    openSettings: function(t) {
        wx.navigateTo({
            url: "/pages/settings/settings"
        });
    },
    openMenology: function(t) {
        var a = new Date(t.target.dataset.date);
        wx.navigateTo({
            url: "/pages/menology/menology?year=".concat(a.getFullYear(), "&month=").concat(a.getMonth() + 1)
        });
    },
    getSettings: function() {
        var t = {
            style: "classics",
            bg_blur: !1,
            auto_play: !1
        }, a = wx.getStorageSync("settings");
        return a && (t = JSON.parse(a)), t;
    },
    showDaily: function(t) {
        var a = this;
        this.setData({
            calendar: [ t ]
        }), i({
            url: "/v1/dailypics/".concat(t),
            method: "get"
        }).then(function(e) {
            var n = e.data;
            a.syncData([ n ]);
            var i = {};
            i["dailypics.".concat(t, ".show")] = !0, a.setData(i);
        }).then(function() {
            a.fetchDays(t), a.generateCalendar(t), a.data.settings.auto_play && a.playAudio();
        });
    },
    specialCodeHandle_A: function(t) {
        console.log("specialCode_A: ", t);
    },
    specialCodeHandle_B: function(t) {
        console.log("specialCode_B: ", t);
    },
    init: function(t) {
        var a = t % (1e4 * parseInt(t / 1e4));
        a < 100 ? this.specialCodeHandle_A(t) : a % 100 ? this.showDaily(this.convertCodeToDate(t)) : this.specialCodeHandle_B(t);
    },
    onLoad: function(t) {
        var a = new Date(), e = this.getSettings();
        this.setData({
            settings: e,
            date: t.date
        }), t.date ? this.init(t.date) : this.showDaily(n(a, "yyyy-MM-dd")), this.listenAudio(), 
        wx.showShareMenu();
        var i = wx.getSystemInfoSync();
        this.setData({
            width: i.windowWidth,
            height: i.windowHeight
        });
    },
    onShow: function() {
        var t = this.getSettings();
        if ("classics" === t.style) {
            var a = this.data.date, e = "/pages/calendar/calendar";
            a && (e = "".concat(e, "?date=").concat(a)), wx.redirectTo({
                url: e
            });
        } else this.setData({
            settings: t
        });
    }
});