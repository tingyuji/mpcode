var t = require("../../utils/util.js"), e = (t.formatNumber, t.formatTime);

t.unique, t.getDateStrings, getApp(), require("../../utils/wxRequest"), require("../../utils/wxApi");

Page({
    onShareAppMessage: function() {
        var t = e(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png"),
            path: "/pages/index/index"
        };
    },
    data: {
        tab: "white",
        height: 0
    },
    switchWhite: function() {
        this.setData({
            tab: "white"
        });
    },
    switchBlack: function() {
        this.setData({
            tab: "black"
        });
    },
    gotoShare: function() {
        wx.navigateBack();
    },
    onLoad: function(t) {
        wx.showShareMenu();
        var e = wx.getSystemInfoSync();
        this.setData({
            height: e.windowHeight
        });
    }
});