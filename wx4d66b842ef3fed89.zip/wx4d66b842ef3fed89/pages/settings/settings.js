var t = require("../../utils/util.js"), e = (t.formatNumber, t.formatTime);

t.unique, t.getDateStrings, getApp(), require("../../utils/wxRequest"), require("../../utils/wxApi");

Page({
    onShareAppMessage: function() {
        var t = e(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png"),
            path: "/pages/index/index"
        };
    },
    data: {
        height: 0,
        version: "",
        settings: {
            style: "classics",
            bg_blur: !1,
            auto_play: !1
        }
    },
    setNewSettings: function(t) {
        var e = this.data.settings, s = Object.assign({}, e, t);
        this.setData({
            settings: s
        }), wx.setStorage({
            key: "settings",
            data: JSON.stringify(s)
        });
    },
    selectStyle: function(t) {
        var e = t.currentTarget.dataset.style;
        this.setNewSettings({
            style: e
        });
    },
    changeBgBlur: function() {
        var t = this.data.settings.bg_blur;
        this.setNewSettings({
            bg_blur: !t
        });
    },
    changeAutoPlay: function() {
        var t = this.data.settings.auto_play;
        this.setNewSettings({
            auto_play: !t
        });
    },
    gotoAbout: function() {
        wx.navigateTo({
            url: "/pages/about/about"
        });
    },
    onLoad: function(t) {
        wx.showShareMenu();
        var e = wx.getSystemInfoSync();
        console.log(e), this.setData({
            height: e.windowHeight
        });
        var s = JSON.parse(wx.getStorageSync("settings"));
        this.setNewSettings(s);
    }
});