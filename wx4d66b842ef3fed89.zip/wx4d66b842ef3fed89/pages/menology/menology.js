var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("../../utils/util.js"), e = a.formatNumber, n = a.formatTime, o = (a.unique, 
a.getDateStrings), s = (getApp(), require("../../utils/wxRequest"));

require("../../utils/wxApi");

Page({
    onShareAppMessage: function() {
        var t = n(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png"),
            path: "/pages/index/index"
        };
    },
    data: {
        pullDownBusy: !1,
        reachBottomBusy: !1,
        year: 0,
        month: 0,
        paddings: [],
        months: [],
        dailypics: {}
    },
    prevMonth: function() {
        var t = this.data.months[this.data.months.length - 1], a = t.year, n = t.month;
        0 === (n = parseInt(n) - 1) && (a = parseInt(a) - 1, n = 12), n = e(n), this.setData({
            year: a,
            month: n
        }), this.buildMenology(a, n, "prev"), this.fetchDailypics(a, n, "prev");
    },
    nextMonth: function() {
        var t = this.data.months[0], a = t.year, n = t.month;
        (n = parseInt(n) + 1) > 12 && (a = "".concat(parseInt(a) + 1), n = 1), n = e(n), 
        this.setData({
            year: a,
            month: n
        }), this.buildMenology(a, n, "next"), this.fetchDailypics(a, n, "next");
    },
    buildMenology: function(a, e, o) {
        var s, i = new Date();
        this.data.months;
        i.getFullYear() === 1 * a && i.getMonth() === e - 1 ? (s = i.getDate(), this.setData({
            finish: !0
        })) : ((s = new Date("".concat(a, "-").concat(e))).setMonth(s.getMonth() + 1), s.setDate(0), 
        s = s.getDate());
        for (var h = [], r = 0; r < s; r++) {
            var c = n(new Date(a, e - 1, 1 + r), "yyyy-MM-dd");
            h.push(c);
        }
        var l = [], u = h.length % 3, d = 0;
        u && (d = 3 - u);
        for (var y = 0; y < d; y++) l.push(y);
        console.log(l.length, d), "prev" === o ? this.setData({
            months: [].concat(t(this.data.months), [ {
                key: "".concat(a, "-").concat(e),
                year: a,
                month: e,
                menology: h,
                paddings: l
            } ])
        }) : this.setData({
            months: [ {
                key: "".concat(a, "-").concat(e),
                year: a,
                month: e,
                menology: h,
                paddings: l
            } ].concat(t(this.data.months))
        }), console.log(this.data.months);
    },
    fetchDailypics: function(t, a, e) {
        var n = this, o = this.data.months.find(function(e) {
            return e.year === t && e.month === a;
        }).menology, i = o[0], h = o[o.length - 1];
        s({
            url: "/v1/dailypics",
            method: "get",
            data: {
                from: i,
                to: h
            }
        }).then(function(t) {
            var a = t.data;
            n.syncData(a), "prev" === e ? n.setData({
                reachBottomBusy: !1
            }) : (n.setData({
                pullDownBusy: !1
            }), wx.stopPullDownRefresh());
        });
    },
    syncData: function(t) {
        var a = {};
        t.forEach(function(t) {
            var e = o(t.date), s = e.day, i = e.month, h = e.year;
            a[t.date] = {
                show: "01" === s,
                day: s,
                month: i,
                year: h,
                date: t.date,
                routekey: n(t.date, "yyyyMMdd"),
                pic_url: "".concat(t.pic_url, "?imageMogr2/thumbnail/160x160!/quality/90"),
                quote: t.content["zh-Hans"].quote.text,
                author: t.content["zh-Hans"].author.text
            };
        }), this.setData({
            dailypics: Object.assign(a, this.data.dailypics)
        });
    },
    picLoaded: function(t) {
        var a = t.currentTarget.dataset, e = a.index, n = a.days;
        e += 1, this.loadPic(e, n);
    },
    loadPic: function(t, a) {
        if (t < a.length) {
            var e = a[t];
            if (this.data.dailypics[e]) {
                var n = {};
                n["dailypics.".concat(e, ".show")] = !0, this.setData(n);
            } else this.loadPic(t + 1, a);
        }
    },
    onLoad: function(t) {
        var a = t.year, n = t.month;
        n = e(n), this.setData({
            year: a,
            month: n
        }), this.buildMenology(a, n, "prev"), this.fetchDailypics(a, n, "prev"), wx.showShareMenu();
    },
    onPullDownRefresh: function() {
        this.data.finish ? wx.stopPullDownRefresh() : this.data.pullDownBusy || (this.setData({
            pullDownBusy: !0
        }), this.nextMonth());
    },
    onReachBottom: function() {
        this.data.reachBottomBusy || (this.setData({
            reachBottomBusy: !0
        }), this.prevMonth());
    }
});