var t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../utils/util.js"), e = a.formatNumber, n = a.formatTime, i = (a.unique, 
getApp(), require("../../utils/wxRequest")), s = (require("../../utils/wxApi"), 
require("../../utils/lunar")), r = require("../../utils/sounds");

Page({
    onShareAppMessage: function() {
        var t = n(new Date(), "yyyyMMdd"), a = this.data.calendar[this.data.current], e = this.data.dailypics[a];
        return {
            title: e.quote,
            imageUrl: e.pic_url,
            path: "/pages/daily/daily?date=".concat(t)
        };
    },
    data: {
        firstShow: !0,
        circular: !0,
        showNature: !1,
        width: 0,
        height: 0,
        current: 0,
        duration: 300,
        offset: 20,
        calendar: [],
        dailypics: {},
        dailies: [],
        noCircular: !1,
        date: "",
        firstDay: "2018-01-01",
        lastDay: "2018-12-31",
        lock: !1,
        refreshCalendarHandle: null,
        showNatureGuide: !1,
        retryTimes: 0
    },
    start: function() {
        this.setData({
            showNature: !0
        });
    },
    fetchDays: function(t) {
        var a = this, e = new Date(t), s = e.getFullYear(), r = e.getMonth(), o = e.getDate(), d = o + 2, c = new Date(s, r, o - 2), l = new Date(s, r, d), h = n(c, "yyyy-MM-dd"), u = n(l, "yyyy-MM-dd");
        i({
            url: "/v1/dailypics",
            method: "get",
            data: {
                from: h,
                to: u
            }
        }).then(function(t) {
            var e = t.data;
            console.log(e), a.setData({
                dailies: e
            }), a.syncData(e);
        });
    },
    generateCalendar: function(t) {
        var a = this, e = new Date(t), i = e.getFullYear(), s = e.getMonth(), r = e.getDate(), o = this.data.offset, d = r + o, c = new Date(i, s, r - o), l = new Date(i, s, d), h = new Date(this.data.firstDay), u = new Date(this.data.lastDay);
        +c < +h && (c = h), +l > +u && (l = u);
        for (var y = [], D = n(c, "yyyy-MM-dd"), f = n(l, "yyyy-MM-dd"), g = D; g !== f; ) {
            y.push(g);
            var w = new Date(g);
            w.setDate(w.getDate() + 1), g = n(w, "yyyy-MM-dd");
        }
        y.push(g);
        var p = this.data.calendar.findIndex(function(a) {
            return a === t;
        }), v = [], m = {}, M = y.length;
        v.length = M;
        var C = 0;
        t === f ? (C = M, m.current = M - 1) : t === D ? (C = 0, m.current = 0) : C = p - y.findIndex(function(a) {
            return a === t;
        }), y.forEach(function(t) {
            C < 0 ? v[M + C] = t : C > M - 1 ? v[C - M] = t : v[C] = t, C++;
        }), m.calendar = v, this.setData(m), setTimeout(function() {
            var t = a.data, e = t.calendar, n = t.current, i = t.firstDay, s = t.lastDay, r = e[n] !== i && e[n] !== s;
            (a.data.circular && !r || !a.data.circular && r) && a.setData({
                circular: r,
                lock: !1
            });
        }, 400);
    },
    syncData: function(a) {
        var e = {};
        a.forEach(function(a) {
            var n = a.date, i = n.split("-"), o = t(i, 3), d = o[0], c = o[1], l = o[2], h = "2018-".concat(c, "-").concat(l);
            e[n] = {
                show: !1,
                day: l,
                month: c,
                year: d,
                date: n,
                lunar: s(n),
                pic_url: a.pic_url ? "".concat(a.pic_url, "?imageMogr2/thumbnail/1024x1024!/quality/90") : "",
                sound_name: r[h].sound_name,
                sound_url: r[h].sound_url,
                sound_icon_url: r[h].sound_icon_url,
                quote: a.content["zh-Hans"].quote.text,
                author: a.content["zh-Hans"].author.text ? a.content["zh-Hans"].author_title.text + "，" + a.content["zh-Hans"].author.text : ""
            };
        }), console.log(e), this.setData({
            dailypics: Object.assign({}, this.data.dailypics, e)
        });
    },
    touchstart: function(t) {},
    dateChanged: function(t) {
        var a = this, e = t.detail, n = e.current;
        if ("touch" === e.source) {
            var i = this.data.calendar[n], s = "dailypics.".concat(i, ".show"), r = {
                current: n
            }, o = this.data, d = o.firstDay, c = o.lastDay, l = i !== d && i !== c;
            this.data.circular && !l ? r.lock = !0 : !this.data.circular && l && (r.lock = !1), 
            r[s] = !0, this.setData(r), this.fetchDays(i), clearTimeout(this.refreshCalendarHandle), 
            this.refreshCalendarHandle = setTimeout(function() {
                a.generateCalendar(i);
            }, 200);
        }
    },
    prevDate: function() {
        var t = this, a = this.data.current;
        0 === a ? a = this.data.calendar.length - 1 : a -= 1;
        var e = this.data.calendar[a], n = {
            current: a
        };
        n["dailypics.".concat(e, ".show")] = !0, this.setData(n), this.fetchDays(e), clearTimeout(this.refreshCalendarHandle), 
        this.refreshCalendarHandle = setTimeout(function() {
            t.generateCalendar(e);
        }, 500);
    },
    nextDate: function() {
        var t = this, a = this.data.current;
        a === this.data.calendar.length - 1 ? a = 0 : a += 1;
        var e = this.data.calendar[a], n = {
            current: a
        };
        n["dailypics.".concat(e, ".show")] = !0, this.setData(n), this.fetchDays(e), clearTimeout(this.refreshCalendarHandle), 
        this.refreshCalendarHandle = setTimeout(function() {
            t.generateCalendar(e);
        }, 500);
    },
    openMenology: function(t) {
        var a = new Date(t.target.dataset.date);
        wx.navigateTo({
            url: "/pages/menology/menology?year=".concat(a.getFullYear(), "&month=").concat(a.getMonth() + 1)
        });
    },
    getSettings: function() {
        var t = {
            style: "classics",
            bg_blur: !1,
            auto_play: !1
        }, a = wx.getStorageSync("settings");
        return a && (t = JSON.parse(a)), t;
    },
    showToday: function() {
        var t = new Date();
        wx.redirectTo({
            url: "/pages/daily/daily?date=".concat(n(t, "yyyyMMdd"))
        });
    },
    showDaily: function(t) {
        var a = this;
        console.log("showDaily"), this.setData({
            calendar: [ t ]
        }), i({
            url: "/v1/dailypics/".concat(t),
            method: "get"
        }).then(function(e) {
            var n = e.data;
            a.syncData([ n ]);
            var i = {
                retryTimes: 0
            };
            i["dailypics.".concat(t, ".show")] = !0, a.setData(i);
        }, function(e) {
            console.log(a.data.retryTimes);
            var n = a.data.retryTimes;
            n < 3 && (a.setData({
                retryTimes: n + 1
            }), a.showDaily(t));
        }).then(function() {
            a.fetchDays(t), a.generateCalendar(t);
        });
    },
    specialCodeHandle_A: function(t) {
        console.log("specialCode_A: ", t);
    },
    specialCodeHandle_B: function(t) {
        console.log("specialCode_B: ", t);
    },
    init: function(t) {
        var a = t % (1e4 * parseInt(t / 1e4)), e = new Date(), i = n(e, "yyyy-MM-dd");
        if (a < 100) this.showDaily(i); else if (a % 100) {
            var s = this.convertCodeToDate(t);
            +new Date(s) > +e ? this.showDaily(i) : this.showDaily(s);
        } else this.showDaily(i);
    },
    convertCodeToDate: function(t) {
        var a = parseInt(t / 1e4), n = parseInt(t / 100) % (100 * a), i = t % (100 * (100 * a + n));
        return "".concat(a, "-").concat(e(n), "-").concat(e(i));
    },
    parseDateCode: function(t) {
        var a, e = t % (1e4 * parseInt(t / 1e4)), i = new Date(), s = n(i, "yyyy-MM-dd");
        if (e < 100) a = s; else if (e % 100) {
            var r = this.convertCodeToDate(t);
            a = +new Date(r) > +i ? s : r;
        } else a = s;
        return a;
    },
    onLoad: function(t) {
        var a = wx.getSystemInfoSync(), e = this.data.firstDay, i = new Date(), s = n(i, "yyyy-MM-dd"), r = {
            width: a.windowWidth,
            height: a.windowHeight,
            lastDay: s
        };
        +new Date(e) > i && (r.firstDay = s), console.log("===="), console.log(t.date), 
        t.date ? r.date = this.parseDateCode(t.date) : r.date = s, this.setData(r), wx.showShareMenu();
    },
    onShow: function() {
        var t = this.data, a = t.firstShow, e = t.firstDay, i = t.date, s = new Date(), r = n(s, "yyyy-MM-dd"), o = {
            settings: this.getSettings(),
            firstShow: !1
        };
        this.data.lastDay !== r && (o.lastDay = r, o.date = r), a && (o.date = i), this.data.firstDay !== e && +new Date(e) > +s && (o.firstDay = r), 
        this.setData(o), console.log("-----"), console.log(this.data.date), console.log(o), 
        o.date ? this.showDaily(o.date) : this.data.dailypics[this.data.date] && this.data.dailypics[this.data.date].show || this.showDaily(this.data.date);
    },
    onHide: function() {
        this.setData({
            showNatureGuide: !1
        });
    }
});