var t = require("../../utils/util.js"), e = t.formatNumber, a = t.formatTime, i = (t.unique, 
t.getDateStrings, getApp(), require("../../utils/wxRequest")), n = (require("../../utils/wxApi"), 
require("../../utils/lunar"));

Page({
    onShareAppMessage: function() {
        var t = a(new Date(), "yyyy-MM-dd");
        return {
            title: "潮汐日历",
            imageUrl: "https://pics.tide.moreless.io/tidetime/share/".concat(t, ".png"),
            path: "/pages/index/index"
        };
    },
    data: {
        pixelRatio: 1,
        width: 0,
        height: 0,
        picUrl: "",
        quote: "",
        author: "",
        remainDay: 0,
        dateData: {}
    },
    convertCodeToDate: function(t) {
        var a = parseInt(t / 1e4), i = parseInt(t / 100) % (100 * a), n = t % (100 * (100 * a + i));
        return "".concat(a, "-").concat(e(i), "-").concat(e(n));
    },
    gotoTide: function() {
        wx.navigateTo({
            url: "/pages/tide/tide"
        });
    },
    init: function(t) {
        var e = this, a = n(t);
        this.setData({
            month: a.oDate.getMonth() + 1,
            lunar: a,
            remainDay: parseInt((+new Date("2018") - new Date(t)) / 864e5)
        });
        this.data.width, this.data.height;
        i({
            url: "/v1/dailypics/".concat(t),
            method: "get"
        }).then(function(t) {
            var a = e.data, i = a.height * a.pixelRatio, n = t.data.pic_url.replace(/http:/, "https:");
            e.setData({
                picUrl: "".concat(n, "?imageMogr2/thumbnail/").concat(i, "x").concat(i, "!/quality/90"),
                quote: t.data.content["zh-Hans"].quote.text,
                author: t.data.content["zh-Hans"].author.text
            });
        });
    },
    onLoad: function(t) {
        wx.redirectTo({
            url: "/pages/daily/daily"
        });
    }
});