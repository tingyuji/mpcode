var e = require("../plugins/es6-promise.js");

e.prototype.finally = function(e) {
    var t = this.constructor;
    return this.then(function(n) {
        return t.resolve(e()).then(function() {
            return n;
        });
    }, function(n) {
        return t.resolve(e()).then(function() {
            throw n;
        });
    });
};

var t = function(e) {
    return (e = e.toString())[1] ? "".concat(e) : "0".concat(e);
}, n = [ "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" ], r = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], o = [ "十", "一", "二", "三", "四", "五", "六", "七", "八", "九" ], a = [ "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" ];

module.exports = {
    Promise: e,
    getUTC8Date: function(e, t, n) {
        var r, o = (r = n ? new Date(e, t, n) : t ? new Date(e, t) : e ? new Date(e) : new Date()).getTime(), a = 6e4 * r.getTimezoneOffset();
        return new Date(o + a - -288e5);
    },
    formatTime: function(e, t) {
        t = t || "yyyy-MM-dd hh:mm:ss";
        var n = {
            "M+": (e = new Date(e)).getMonth() + 1,
            "d+": e.getDate(),
            "h+": e.getHours(),
            "m+": e.getMinutes(),
            "s+": e.getSeconds(),
            "q+": Math.floor((e.getMonth() + 3) / 3),
            S: e.getMilliseconds()
        };
        for (var r in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), 
        n) new RegExp("(" + r + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
        return t;
    },
    formatNumber: t,
    unique: function(e, t) {
        for (var n = {}, r = [], o = 0; o < e.length; o++) n[e[o][t]] = e[o];
        for (var a in n) r.push(n[a]);
        return r;
    },
    getDateStrings: function(e) {
        return e = new Date(e), {
            day: t(e.getDate()),
            month: n[e.getMonth()],
            year: "".concat(e.getFullYear())
        };
    },
    getZHDateStrings: function(e) {
        var t = (e = new Date(e)).getMonth(), n = e.getDay(), u = "", i = "".concat(e.getDate());
        return i.split("").forEach(function(e) {
            u += o[parseInt(e)];
        }), {
            day: i,
            month: t + 1,
            zhDay: u,
            zhMonth: a[t],
            zhWeekday: r[n]
        };
    },
    calcSize: function(e) {
        return e / 1.4;
    }
};