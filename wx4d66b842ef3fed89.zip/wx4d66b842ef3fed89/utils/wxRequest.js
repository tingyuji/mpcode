var e, t = require("./base64.min.js").Base64, r = require("../plugins/es6-promise.js");

r.prototype.finally = function(e) {
    var t = this.constructor;
    return this.then(function(r) {
        return t.resolve(e()).then(function() {
            return r;
        });
    }, function(r) {
        return t.resolve(e()).then(function() {
            throw r;
        });
    });
}, module.exports = function(n) {
    var o, a = (o = wx.request, function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new r(function(t, r) {
            e.success = function(e) {
                200 === e.statusCode ? t(e) : r({
                    errMsg: e.data.message,
                    error: e.data.error,
                    details: e.data.details
                });
            }, e.fail = function(e) {
                r(e);
            }, o(e);
        });
    });
    e || (e = getApp());
    var s = wx.getStorageSync("sid");
    return n.header || (n.header = {}), n.header["content-type"] = "application/x-www-form-urlencoded", 
    n.header.Authorization = "Basic ".concat(t.encode("W8TxC2uDKWy6P8G7u4mjV:khsvJs9pjhoP943o7VK9A")), 
    n.url = "https://tide-api.moreless.io".concat(n.url), n.data ? n.data.sid = s : n.data = {
        sid: s
    }, a(n);
};