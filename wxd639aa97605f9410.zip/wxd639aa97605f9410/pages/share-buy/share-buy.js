var e = require("../../utils/ajax"), a = require("../../utils/util"), n = getApp();

Page({
    loadData: function() {
        var t = this;
        a.showLoading("获取数据中"), e.mercury.get("vip/loadShareBuy", {
            id: this.shareId,
            openid: n.globalData.userData.openid
        }).finally(a.hideLoading).then(function(e) {
            e ? (e.cardTypeDesc = "", /^month/.test(e.cardType) ? e.cardTypeDesc = "1个月" : /^season/.test(e.cardType) ? e.cardTypeDesc = "3个月" : /^year2/.test(e.cardType) ? e.cardTypeDesc = "2年" : /^year/.test(e.cardType) ? e.cardTypeDesc = "1年" : e.days > 0 && (e.cardTypeDesc = e.days + "天"), 
            e.typeDesc = "pallet" === e.type ? "货主" : "船主", e.amountValue = e.amount, e.amount = (+e.amount || 0).toFixed(2), 
            t.setData(e)) : t.expired();
        }).catch(function(e) {
            t.loadTimes++, t.loadTimes < 3 ? setTimeout(function() {
                return t.loadData();
            }, 2e3) : t.expired();
        });
    },
    expired: function() {
        var e = this;
        a.alert("支付信息已过期，请您的朋友重发新的代付申请").then(function() {
            return e.doneClose();
        });
    },
    doneClose: function() {
        wx.navigateBack();
    },
    pay: function() {
        var t = this;
        a.showLoading("获取信息中"), e.mercury.post("vip/shareBuy", {
            id: this.shareId,
            openid: n.globalData.userData.openid
        }).finally(a.hideLoading).then(function(e) {
            var n = e.payInfo;
            wx.requestPayment({
                timeStamp: n.timeStamp.toString(),
                nonceStr: n.nonceStr,
                package: n.package,
                signType: n.signType || "MD5",
                paySign: n.paySign,
                success: function(e) {
                    return t.payDone();
                },
                fail: function(e) {
                    var n = e.errMsg.indexOf("fail"), t = e.errMsg.slice(n + 4).trim();
                    "cancel" !== t && a.alert("付款失败，" + t);
                }
            });
        }).catch(function(a) {
            return e.showError("获取支付信息", a);
        });
    },
    payDone: function() {
        var e = this;
        a.alert("支付成功").then(function() {
            return e.doneClose();
        });
    },
    data: {},
    onLoad: function(e) {
        this.shareId = +e.id || 0, this.loadTimes = 0, this.loadData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});