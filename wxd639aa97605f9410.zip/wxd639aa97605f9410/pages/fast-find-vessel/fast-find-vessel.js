var n = require("../../utils/ajax.js");

Page({
    dial: function() {
        n.mercury.post("mapps/log", {
            action: "fast_find_vessel.dial",
            target: "4008030092"
        }), wx.makePhoneCall({
            phoneNumber: "4008030092"
        });
    },
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});