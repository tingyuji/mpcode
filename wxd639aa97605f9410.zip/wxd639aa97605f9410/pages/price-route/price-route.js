var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../utils/util"), i = require("../../utils/ajax");

Page({
    data: {
        items: []
    },
    onLoad: function(t) {
        this.load();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    },
    dial: function() {
        i.mercury.post("mapps/log", {
            action: "priceRoute.dail400",
            target: "list"
        }), e.dial400();
    },
    load: function() {
        var a = this;
        e.showLoading("获取运价数据"), i.mercury.get("priceRoute/list").finally(e.hideLoading).then(function(e) {
            var i, n = t(e);
            try {
                for (n.s(); !(i = n.n()).done; ) {
                    var r = i.value;
                    r.avgPrice = (r.minPrice + r.maxPrice) / 2, r.lastAvgPrice = (r.lastMinPrice + r.lastMaxPrice) / 2, 
                    r.priceDelta = +(r.avgPrice - r.lastAvgPrice).toFixed(1);
                }
            } catch (t) {
                n.e(t);
            } finally {
                n.f();
            }
            a.setData({
                items: e
            });
        }).catch(function(t) {
            return i.showError("获取运价数据", t);
        });
    },
    detail: function(t) {
        var e = t.currentTarget.dataset.item;
        wx.navigateTo({
            url: "./detail/detail?id=".concat(e.id)
        });
    }
});