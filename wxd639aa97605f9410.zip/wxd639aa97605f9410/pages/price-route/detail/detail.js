var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../utils/util"), a = require("../../../utils/ajax"), n = require("../../../modules/moment");

Page({
    data: {
        id: 0,
        route: null,
        chartImage: ""
    },
    onLoad: function(e) {
        this.setData({
            id: +e.id || 0
        }), this.load();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    },
    dial: function() {
        a.mercury.post("mapps/log", {
            action: "priceRoute.dail400",
            target: "detail",
            result: this.data.id
        }), t.dial400();
    },
    load: function() {
        var i = this;
        t.showLoading("获取运价数据"), a.mercury.get("priceRoute/detail", {
            id: this.data.id
        }).finally(t.hideLoading).then(function(t) {
            var a = "";
            if (t) {
                var r = t.days[t.days.length - 1];
                t.date = r.date, t.dateText = n(t.date).format("M月D日"), t.minPrice = r.minPrice, 
                t.maxPrice = r.maxPrice, t.avgPrice = (t.minPrice + t.maxPrice) / 2;
                var c = t.days[t.days.length - 2];
                c && (t.lastAvgPrice = (c.minPrice + c.maxPrice) / 2, t.priceDelta = +(t.avgPrice - t.lastAvgPrice).toFixed(1)), 
                t.minDate = n(t.date).subtract(6, "days"), t.minDateText = n(t.minDate).format("M月D日"), 
                t.weekMinPrice = Number.MAX_SAFE_INTEGER, t.weekMaxPrice = Number.MIN_SAFE_INTEGER;
                var o, d = e(t.days);
                try {
                    for (d.s(); !(o = d.n()).done; ) {
                        var s = o.value;
                        s.dateValue = n(s.date).valueOf(), t.weekMinPrice = Math.min(t.weekMinPrice, s.minPrice), 
                        t.weekMaxPrice = Math.max(t.weekMaxPrice, s.maxPrice);
                    }
                } catch (e) {
                    d.e(e);
                } finally {
                    d.f();
                }
                t.baseX = 160, t.weekMaxPrice >= 100 && (t.baseX = 180), t.weekDays = [];
                for (var l = t.weekMaxPrice - t.weekMinPrice, u = t.days.slice().sort(function(e, t) {
                    return t.dateValue - e.dateValue;
                }), x = function(e) {
                    var a = t.weekDays[e] = {
                        x: t.baseX + 50 + 110 * e,
                        y: 0,
                        w: 60,
                        h: 0,
                        color: "dimgrey"
                    }, i = n(t.date).subtract(6 - e, "days").valueOf(), r = u.find(function(e) {
                        return e.dateValue === i;
                    });
                    if (r) {
                        a.y = 150, a.h = 400, l > 0 && (a.y += 400 * (t.weekMaxPrice - r.maxPrice) / l, 
                        a.h = 400 * (r.maxPrice - r.minPrice) / l);
                        var c = u.find(function(e) {
                            return e.dateValue < i;
                        });
                        if (c) {
                            var o = (c.minPrice + c.maxPrice) / 2, d = +((r.minPrice + r.maxPrice) / 2 - o).toFixed(1);
                            d <= -.5 ? a.color = "green" : d >= .5 && (a.color = "red");
                        }
                    }
                }, m = 0; m < 7; m++) x(m);
                var h = '\n          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 730"\n               stroke="black" stroke-width="2" fill="black" font-size="48">\n              <path d="M'.concat(t.baseX + 10, ',650H995"/>\n              <text x="995" y="660" style="text-anchor: end; dominant-baseline: text-before-edge">日期</text>\n              <text x="500" y="660" style="text-anchor: middle; dominant-baseline: text-before-edge">\n                  ').concat(t.minDateText, "~").concat(t.dateText, '运价趋势\n              </text>\n              <path d="M').concat(t.baseX + 10, ',650V5"/>\n              <text x="').concat(t.baseX, '" y="5" style="text-anchor: end; dominant-baseline: text-before-edge">\n                  运价\n              </text>\n              <text x="').concat(t.baseX, '" y="150" style="text-anchor: end; dominant-baseline: middle">\n                  ').concat(t.weekMaxPrice, '元\n              </text>\n              <path stroke-dasharray="30,30" d="M').concat(t.baseX + 10, ',150H980"/>\n              <text x="').concat(t.baseX, '" y="550" style="text-anchor: end; dominant-baseline: middle">\n                  ').concat(t.weekMinPrice, '元\n              </text>\n              <path stroke-dasharray="30,30" d="M').concat(t.baseX + 10, ',550H980"/>\n              ').concat(t.weekDays.map(function(e) {
                    return '<rect fill="'.concat(e.color, '" x="').concat(e.x, '" y="').concat(e.y, '" width="').concat(e.w, '" height="').concat(e.h, '" stroke-width="0"/>');
                }).join(""), "\n          </svg>\n        ");
                a = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(h);
            } else t = null;
            i.setData({
                route: t,
                chartImage: a
            });
        }).catch(function(e) {
            return a.showError("获取运价数据", e);
        });
    }
});