var t = require("../../utils/ajax"), e = require("../../utils/env"), a = require("../../modules/moment"), i = require("../../dao/ship"), o = require("../../dao/vessel"), s = require("../../utils/user"), n = require("../../utils/util");

Page({
    data: {
        id: 0,
        vessel: null,
        weight: null,
        aimPorts: [],
        blankPorts: [],
        startPort: null,
        note: ""
    },
    onLoad: function(t) {
        this.updateDate = t.updateDate;
        var r = parseInt(t && t.id) || 0;
        if (this.setData({
            id: r,
            today: a().format("YYYY-MM-DD")
        }), s.id.get()) {
            var l = o.get();
            if (l) {
                var h = {
                    vessel: l
                }, u = l.photo;
                u && (u.timeDesc = n.getTimeText(u.time), u.url = e.mercury("vessels/photo?file=".concat(u.file, "&thumbnail=1")), 
                h.photo = u);
                var d = i.get();
                if (d) {
                    h.startPort = {
                        id: d.startPortId,
                        title: d.startPort
                    }, h.note = d.note, h.aimPorts = this.makePorts(d.aimPortId, d.aimPort);
                    var c = a().format("YYYY-MM-DD");
                    if (d.date) {
                        var f = a(d.date);
                        (!this.updateDate || f.valueOf() > a().startOf("day").valueOf()) && (c = f.format("YYYY-MM-DD"));
                    }
                    h.date = c;
                    var g = l.deadweightTonnage;
                    d.weight && (g = d.weight), h.weight = g, h.blankPorts = this.makePorts(d.blankStartId, d.blankStart);
                }
                this.setData(h);
            } else wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel"
            });
        } else wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    makePorts: function(t, e) {
        var a = (t || "").split(",").map(function(t) {
            return t.trim();
        }).filter(function(t) {
            return t;
        }), i = (e || "").split(",").map(function(t) {
            return t.trim();
        }).filter(function(t) {
            return t;
        });
        return a.map(function(t, e) {
            return {
                id: t,
                title: i[e] || t
            };
        });
    },
    onReady: function() {},
    onShow: function() {
        if (s.id.get()) {
            var t = o.get();
            if (t) {
                var e = this.data.weight;
                null == e && (e = t.deadweightTonnage);
                var i = this.data.date;
                null == i && (i = a().format("YYYY-MM-DD")), this.setData({
                    vessel: t,
                    weight: e,
                    date: i
                });
            } else wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel"
            });
        } else wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    _publishBack: function() {
        var t = getCurrentPages(), e = t[t.length - 2], a = e && e.route;
        a && a.startsWith("pages/zhaohuo/zhaohuo") ? wx.navigateBack() : wx.redirectTo({
            url: "/pages/zhaohuo/zhaohuo?tab=1"
        });
    },
    _back: function() {
        var t = getCurrentPages();
        if (t.length >= 2) {
            var e = t[t.length - 2];
            e && "function" == typeof e.scrollTop && e.scrollTop();
        }
        wx.navigateBack();
    },
    cancel: function() {
        this._back();
    },
    publish: function() {
        var e = this;
        if (this.data.vessel) if (this.data.weight) {
            var r = this.data.date, l = a().format("YYYY-MM-DD");
            if (r) if (r < l) wx.showModal({
                title: "温馨提示",
                content: "空船日期不能小于今天",
                showCancel: !1
            }); else if (this.data.startPort && this.data.startPort.id) this.data.vessel.certified ? (n.showLoading("发布空船中"), 
            t.mercury.post("ships/saveMobile", {
                id: this.data.id,
                startPort: this.data.startPort && this.data.startPort.id,
                aimPort: this.data.aimPorts.map(function(t) {
                    return t.id;
                }).join(","),
                blankStart: this.data.blankPorts.map(function(t) {
                    return t.id;
                }).join(","),
                date: this.data.date,
                duration: 2,
                mobiles: s.mobile.get(),
                note: this.data.note,
                vessel: this.data.vessel.id,
                weight: this.data.weight
            }).then(function() {
                var a = o.get();
                if (e.data.photo && a.photo && e.data.photo.file !== a.photo.file || e.data.photo && !a.photo || !e.data.photo && a.photo) return t.mercury.post("vessels/savePhoto", {
                    vessel: e.data.vessel.id,
                    file: e.data.photo && e.data.photo.file || null
                }).then(function() {
                    o.refresh(), i.refresh(), this._publishBack();
                }.bind(e));
                i.refresh(), e._publishBack();
            }).finally(n.hideLoading).catch(function(e) {
                return t.showError("发布空船", e);
            })) : n.authShipCreateModal(); else wx.showModal({
                title: "温馨提示",
                content: "空船港不能为空",
                showCancel: !1
            }); else wx.showModal({
                title: "温馨提示",
                content: "空船日期不能为空",
                showCancel: !1
            });
        } else wx.showModal({
            title: "温馨提示",
            content: "船皮不能为空",
            showCancel: !1
        }); else wx.showModal({
            title: "温馨提示",
            content: "没有船舶档案",
            showCancel: !1
        });
    },
    preview: function() {
        var a = this.data.photo;
        a && wx.previewImage({
            urls: [ e.mercury("vessels/photo?file=".concat(a.file, "&authentication=").concat(t.getToken())) ]
        });
    },
    previewSample: function() {
        var a = e.mercury("vessels/demoPhoto?authentication=".concat(t.getToken()));
        wx.previewImage({
            urls: [ a ]
        });
    },
    removePhoto: function() {
        wx.showModal({
            title: "删除照片",
            content: "是否删除照片？",
            success: function(t) {
                t.confirm && this.setData({
                    photo: null
                });
            }.bind(this)
        });
    },
    takePhoto: function() {
        n.showLoading("获取位置中"), wx.getLocation({
            success: function(a) {
                n.hideLoading(), wx.chooseImage({
                    count: 1,
                    sizeType: [ "compressed" ],
                    sourceType: [ "camera" ],
                    success: function(i) {
                        wx.showLoading({
                            title: "正在上传空船照片..."
                        }), t.mercury.upload("vessels/uploadPhoto", i.tempFilePaths[0], "image/jpeg", {
                            position: JSON.stringify({
                                coords: a
                            }),
                            suffix: "jpg"
                        }, null, {}).finally(function() {
                            wx.hideLoading();
                        }).then(function(t) {
                            t.timeDesc = n.getTimeText(t.time), t.url = e.mercury("vessels/photo?file=".concat(t.file, "&thumbnail=1")), 
                            this.setData({
                                photo: t
                            });
                        }.bind(this)).catch(function(e) {
                            return t.showError("上传空船照片", e);
                        });
                    }.bind(this)
                });
            }.bind(this),
            fail: function(t) {
                n.hideLoading(), n.alert("无法获取您的位置信息，请检查您是否开启了手机定位功能及权限", {
                    title: "定位错误"
                });
            }
        });
    },
    startPortChange: function(t) {
        this.setData({
            startPort: t.detail
        });
    },
    aimPortsChange: function(t) {
        this.setData({
            aimPorts: t.detail
        });
    },
    blankPortsChange: function(t) {
        this.setData({
            blankPorts: t.detail
        });
    },
    noteChange: function(t) {
        this.data.note = t.detail;
    },
    setWeight: function(t) {
        this.data.weight = t.detail.value;
    },
    setDate: function(t) {
        this.setData({
            date: t.detail.value
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});