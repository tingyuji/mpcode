var e = require("../../../utils/ajax"), t = require("../../../dao/relation"), a = require("../../../utils/util");

Page({
    data: {
        keyword: null,
        relations: []
    },
    setName: function(e) {
        this.data.name = e.detail.value;
    },
    setMobile: function(e) {
        this.data.mobile = e.detail.value;
    },
    setMessage: function(e) {
        this.data.message = e.detail.value;
    },
    ensureAddFriend: function() {
        this.data.name ? /1\d{10}/.test(this.data.mobile) ? this.data.message ? e.mercury.post("relations/requestFriend", {
            targetMobile: this.data.mobile,
            targetName: this.data.name,
            message: this.data.message
        }).then(function() {
            t.refresh(), this.data.addFriend.hideModal();
        }.bind(this)).catch(function(t) {
            return e.showError("添加朋友", t);
        }) : a.alert("验证信息不能为空") : a.alert("联系电话不合法") : a.alert("对方姓名不能为空");
    },
    typeKeyword: function(e) {
        this.data.keyword = e.detail.value;
    },
    _refresh: function() {
        var e = t.get();
        if (e) {
            var i = e.friend, n = this.data.keyword;
            n && (i = i.filter(function(e) {
                return e.mobile.indexOf(n) >= 0 || e.name.indexOf(n) >= 0;
            }));
            var r = a.refactorRelation(i);
            this.setData({
                relations: r
            });
        }
    },
    search: function() {
        this.setData({
            keyword: this.data.keyword
        }), this._refresh();
    },
    onLoad: function(e) {
        this.syncRelation = t.subscribeAndFireOnce(this._refresh);
        var a = this.selectComponent("#addFriend");
        this.setData({
            addFriend: a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncRelation.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});