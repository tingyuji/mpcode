var e = require("../../../utils/ajax"), t = require("../../../dao/relation"), n = require("../../../utils/util");

Page({
    data: {
        relations: []
    },
    setName: function(e) {
        this.data.name = e.detail.value;
    },
    accept: function(e) {
        var t = e.currentTarget.dataset.mobile, n = e.currentTarget.dataset.name;
        this.setData({
            name: n,
            mobile: t
        }), this.data.acceptFriend.showModal();
    },
    cancelAcceptFriend: function() {
        this.data.acceptFriend.hideModal();
    },
    ensureAcceptFriend: function() {
        e.mercury.post("relations/acceptFriendRequest", {
            targetName: this.data.name,
            targetMobile: this.data.mobile
        }).then(function() {
            t.refresh(), this.data.acceptFriend.hideModal();
        }.bind(this)).catch(function(t) {
            return e.showError("接受朋友", t);
        });
    },
    refuse: function(n) {
        var a = n.currentTarget.dataset.mobile;
        e.mercury.post("relations/rejectFriendRequest", {
            targetMobile: a
        }).then(function() {
            t.refresh();
        }).catch(function(t) {
            return e.showError("拒绝朋友", t);
        });
    },
    onLoad: function(e) {
        this.syncRelation = t.subscribeAndFireOnce(function(e) {
            if (e) {
                var t = e.friendReceived;
                this.setData({
                    relations: t
                });
            }
        }.bind(this));
        var n = this.selectComponent("#acceptFriend");
        this.setData({
            acceptFriend: n
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncRelation.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});