var e = require("../../../utils/ajax"), t = require("../../../utils/util"), a = require("../../../dao/relation"), i = require("../../../utils/globalMap");

Page({
    data: {
        name: "",
        mobile: "",
        message: ""
    },
    setName: function(e) {
        this.data.name = e.detail.value;
    },
    setMobile: function(e) {
        this.data.mobile = e.detail.value;
    },
    setMessage: function(e) {
        this.data.message = e.detail.value;
    },
    _ensureAlert: function() {
        t.alert("好友请求已发送，请等待对方回应").then(function() {
            wx.navigateBack();
        });
    },
    ensure: function() {
        this.data.name ? /1\d{10}/.test(this.data.mobile) ? this.data.message ? e.mercury.post("relations/requestFriend", {
            targetMobile: this.data.mobile,
            targetName: this.data.name,
            message: this.data.message
        }).then(function() {
            a.refresh(), this.callback && this.callback(), this._ensureAlert();
        }.bind(this)).catch(function(t) {
            return e.showError("添加好友", t);
        }) : t.alert("验证信息不能为空") : t.alert("联系电话不合法") : t.alert("对方姓名不能为空");
    },
    onLoad: function(t) {
        this.setData({
            mobile: t.mobile || "",
            presetMobile: !!t.mobile,
            name: t.name || "",
            presetName: !!t.name
        }), this.callback = i.unRegister(t.callback), e.mercury.get("relations/addFriendNote").then(function(e) {
            this.setData({
                message: e
            });
        }.bind(this));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});