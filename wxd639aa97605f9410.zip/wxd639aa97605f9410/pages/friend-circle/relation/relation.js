var t = require("../../../utils/ajax"), e = require("../../../utils/globalMap"), n = require("../../../dao/relation"), a = require("../../../utils/util");

Page({
    data: {},
    removeBaddie: function() {
        a.confirm("是否从黑名单中移除？").then(function() {
            t.mercury.post("relations/removeBaddie", {
                targetMobile: this.data.relation.mobile
            }).then(function() {
                n.refresh(), wx.navigateBack();
            }).catch(function(e) {
                return t.showError("从黑名单中移除", e);
            });
        }.bind(this)).catch(function() {});
    },
    removeFriend: function() {
        a.confirm("是否解除朋友？").then(function() {
            t.mercury.post("relations/removeFriend", {
                targetMobile: this.data.relation.mobile
            }).then(function() {
                n.refresh(), wx.navigateBack();
            }).catch(function(e) {
                return t.showError("解除朋友", e);
            });
        }.bind(this)).catch(function() {});
    },
    editName: function() {
        this.callbackId = e.register(this.nameChange.bind(this));
        var t = "/pages/friend-circle/relation/edit-relation-name/edit-relation-name?callback=".concat(this.callbackId);
        this.data.relation && this.data.relation.name && (t += "&name=".concat(this.data.relation.name)), 
        wx.navigateTo({
            url: t
        });
    },
    nameChange: function(e) {
        var a = e.name, i = this.data.relation;
        t.mercury.post("relations/update", {
            targetName: a,
            targetMobile: i.mobile
        }).then(function() {
            i.name = a, this.setData({
                relation: i
            }), n.refresh();
        }.bind(this));
    },
    noteChange: function(e) {
        var a = this, i = e.detail, r = this.data.relation;
        t.mercury.post("relations/update", {
            remark: i,
            targetMobile: r.mobile
        }).then(function() {
            r.remark = i, a.setData({
                relation: r
            }), n.refresh();
        });
    },
    onLoad: function(t) {
        var e = getApp().globalData.currentRelation;
        e && this.setData({
            relation: e
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});