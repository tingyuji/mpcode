var a = require("../../../../utils/util"), n = require("../../../../utils/globalMap");

Page({
    data: {
        name: null
    },
    setName: function(a) {
        this.data.name = a.detail.value;
    },
    ensure: function() {
        var a = n.get(this.data.callback);
        a && a({
            name: this.data.name
        }), wx.navigateBack();
    },
    onLoad: function(a) {
        var n = {
            callback: a.callback
        };
        a.name && (n = Object.assign(n, {
            name: a.name
        })), this.setData(n);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});