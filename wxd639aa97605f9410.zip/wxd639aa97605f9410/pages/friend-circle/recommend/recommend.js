var e = require("../../../utils/user"), t = require("../../../utils/ajax"), n = require("../../../utils/util"), a = require("../../../utils/globalMap"), i = require("./daemon");

Page({
    selectChange: function(e) {
        var t = e.currentTarget.dataset.item, n = this.data.selected.findIndex(function(e) {
            return t.name === e.name && t.mobile === e.mobile;
        });
        e.detail.value ? n < 0 && this.setData({
            selected: this.data.selected.concat(t)
        }) : n >= 0 && (this.data.selected.splice(n, 1), this.setData({
            selected: this.data.selected
        }));
    },
    confirm: function() {
        this.data.selected.length > 0 && (n.showLoading("请求发送中"), t.mercury.post("relations/batchRequestFriend", {
            targets: this.data.selected,
            message: "我是" + e.name.get()
        }).finally(n.hideLoading).then(function() {
            return n.alert("请求已发送，请等待对方回应。");
        }).then(function() {
            return wx.navigateBack();
        }).catch(function(e) {
            return t.showError("请求发送", e);
        }));
    },
    data: {
        items: [],
        selected: []
    },
    onLoad: function(e) {
        i.setPageLive(!0);
        var t = a.unRegister(e.items) || [];
        this.setData({
            items: t,
            selected: t.slice()
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        i.setPageLive(!1);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});