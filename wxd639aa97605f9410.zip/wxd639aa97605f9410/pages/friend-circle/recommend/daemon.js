var e = require("../../../utils/user"), r = require("../../../utils/ajax"), t = require("../../../utils/util"), i = require("../../../utils/globalMap"), n = !1, u = !1, s = 0;

function a() {
    var e = t.getCurrentPageName().replace(/^pages\//, "");
    "home/home" === e.indexOf(e) >= 0 && o();
}

function o() {
    var t = new Date().getTime();
    return e.id.get() && !n && !u && t - s > 42e4 ? (n = !0, s = t, r.mercury.post("relations/recommendFriends").finally(function() {
        return n = !1;
    }).then(function(e) {
        return !!(e.items && e.items.length > 0) && (wx.navigateTo({
            url: "/pages/friend-circle/recommend/recommend?items=".concat(i.register(e.items))
        }), !0);
    }).catch(function(e) {
        return !1;
    })) : Promise.resolve(!1);
}

module.exports = {
    startup: function() {
        return getApp().globalData.resumeEvent.subscribe(a), e.id.subscribe(a), o();
    },
    setPageLive: function(e) {
        u = e;
    }
};