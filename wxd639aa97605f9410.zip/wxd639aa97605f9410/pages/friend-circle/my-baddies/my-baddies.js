var e = require("../../../dao/relation"), t = require("../../../utils/util");

Page({
    data: {
        keyword: null,
        relations: []
    },
    typeKeyword: function(e) {
        this.data.keyword = e.detail.value;
    },
    _refresh: function() {
        var n = e.get();
        if (n) {
            var i = n.baddie, o = this.data.keyword;
            o && (i = i.filter(function(e) {
                return e.mobile.indexOf(o) >= 0 || e.name.indexOf(o) >= 0;
            }));
            var r = t.refactorRelation(i);
            this.setData({
                relations: r
            });
        }
    },
    search: function() {
        this.setData({
            keyword: this.data.keyword
        }), this._refresh();
    },
    onLoad: function(t) {
        this.syncRelation = e.subscribeAndFireOnce(this._refresh);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncRelation.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});