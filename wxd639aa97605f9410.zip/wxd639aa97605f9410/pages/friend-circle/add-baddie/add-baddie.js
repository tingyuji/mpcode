var e = require("../../../utils/ajax"), a = require("../../../utils/util"), t = require("../../../dao/relation"), i = require("../../../utils/globalMap");

Page({
    data: {
        name: "",
        mobile: "",
        message: ""
    },
    setName: function(e) {
        this.data.name = e.detail.value;
    },
    setMobile: function(e) {
        this.data.mobile = e.detail.value;
    },
    setMessage: function(e) {
        this.data.message = e.detail.value;
    },
    ensure: function() {
        this.data.name ? /1\d{10}/.test(this.data.mobile) ? this.data.message ? e.mercury.post("relations/addBaddie", {
            targetMobile: this.data.mobile,
            targetName: this.data.name,
            remark: this.data.message
        }).then(function() {
            t.refresh(), this.callback && this.callback(), wx.navigateBack();
        }.bind(this)).catch(function(a) {
            return e.showError("添加黑名单", a);
        }) : a.alert("拉黑理由不能为空") : a.alert("联系电话不合法") : a.alert("对方姓名不能为空");
    },
    onLoad: function(e) {
        this.setData({
            mobile: e.mobile || "",
            presetMobile: !!e.mobile,
            name: e.name || "",
            presetName: !!e.name
        }), this.callback = i.unRegister(e.callback);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/friend-circle/friend-circle")
        };
    }
});