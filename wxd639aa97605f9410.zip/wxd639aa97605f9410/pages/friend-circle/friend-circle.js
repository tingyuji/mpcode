var e = require("../../dao/relation"), n = require("../../utils/util"), t = require("../../utils/user");

Page({
    data: {
        newFriends: 0,
        keyword: null,
        relations: []
    },
    typeKeyword: function(e) {
        this.data.keyword = e.detail.value;
    },
    search: function() {
        this.setData({
            keyword: this.data.keyword
        });
        var t = e.get().relation, i = this.data.keyword;
        i && (t = t.filter(function(e) {
            return e.mobile.indexOf(i) >= 0 || e.name.indexOf(i) >= 0;
        }));
        var r = n.refactorRelation(t);
        this.setData({
            relations: r
        });
    },
    navTo: function(e) {
        var n = e.currentTarget.dataset.url;
        wx.navigateTo({
            url: "/pages/friend-circle/".concat(n, "/").concat(n)
        });
    },
    onLoad: function(i) {
        var r = this;
        n.checkUserLogin(this), this.syncUserId = t.id.subscribeAndFireOnce(function(e) {
            return r.setData({
                userId: e
            });
        }), this.syncRelation = e.subscribeAndFireOnce(function(e) {
            if (e) {
                var t = e.relation, i = r.data.keyword;
                i && (t = t.filter(function(e) {
                    return e.mobile.indexOf(i) >= 0 || e.name.indexOf(i) >= 0;
                }));
                var a = n.refactorRelation(t);
                r.setData({
                    newFriends: e.friendReceived.length,
                    relations: a
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        n.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncRelation.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.sharePath()
        };
    }
});