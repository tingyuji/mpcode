var e = require("../../utils/util"), t = require("../../utils/ajax"), n = require("../../utils/env"), s = require("../../utils/user"), i = require("../../dao/function"), a = require("../../dao/pallet"), r = require("../../dao/ship"), o = require("../../dao/vessel"), u = require("../../dao/relation"), c = require("../../dao/recentContact"), l = require("../../dao/unseenServices"), h = require("../../dao/redPacket"), f = require("../../utils/settingBadge"), d = require("../../dao/vipStatus"), p = require("../../dao/usedVesselSellAlert"), g = getApp();

Page({
    onResume: function() {
        this.updateOfficialPallets(), this.updateBadges(), a.pallets.refreshMask(), r.refreshMask();
    },
    updateBadges: function() {
        var e = new Date().getTime();
        e - (this.lastCheckBadgesTime || 0) > 3e4 && (this.lastCheckBadgesTime = e, u.refresh(), 
        c.pendingCount.refresh());
    },
    updateOfficialPallets: function() {
        new Date().getTime() - (this.lastLoadOfficialPalletsTime || 0) > 6e5 && this.loadOfficialPallets();
    },
    bindMobile: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    toContractHelper: function() {
        l.see("contractHelper"), wx.navigateTo({
            url: "/pages/contract-helper/contract-helper"
        });
    },
    toFuel: function() {
        l.see("fuel"), wx.navigateTo({
            url: "/pages/fuel/fuel"
        });
    },
    toRecentContact: function() {
        l.see("recentContact"), wx.navigateTo({
            url: "/pages/recent-contact/recent-contact"
        });
    },
    toWeather: function() {
        l.see("weather"), wx.navigateTo({
            url: "/pages/weather/weather"
        });
    },
    toPriceRoute: function() {
        l.see("priceRoute"), wx.navigateTo({
            url: "/pages/price-route/price-route"
        });
    },
    toPublishAd: function() {
        l.see("publishAd"), wx.navigateTo({
            url: "/pages/publish-ad/publishAd?source=home"
        });
    },
    toFriendCircle: function() {
        l.see("friendCircle"), wx.navigateTo({
            url: "/pages/friend-circle/friend-circle"
        });
    },
    toRedPacket: function() {
        l.see("redPacket"), wx.navigateTo({
            url: "/pages/settings/red-packet/red-packet?source=home"
        });
    },
    toAntiFakePhoto: function() {
        l.see("antiFakePhoto"), wx.navigateTo({
            url: "/pages/anti-fake-photo/anti-fake-photo"
        });
    },
    toSandstone: function() {
        l.see("sandstone"), e.jumpToSandstoneMiniProgram("home");
    },
    toSailorRecruit: function() {
        l.see("sailorRecruit"), wx.navigateTo({
            url: "/pages/section-ad/section-ad?section=recruit&source=home"
        });
    },
    toVesselTrade: function() {
        l.see("vesselTrade"), wx.navigateTo({
            url: "/pages/section-ad/section-ad?section=vessel&source=home"
        });
    },
    toUsedVessel: function() {
        l.see("usedVessel"), wx.navigateTo({
            url: "/pages/used-vessel/list/list?source=home"
        });
    },
    toSailorExam: function() {
        l.see("sailorExam"), wx.navigateTo({
            url: "/pages/sailor-exam/sailor-exam?source=home"
        });
    },
    toZhaoHuo: function() {
        wx.navigateTo({
            url: "/pages/zhaohuo/zhaohuo"
        });
    },
    toZhaoChuan: function() {
        wx.navigateTo({
            url: "/pages/zhaochuan/zhaochuan"
        });
    },
    toSettings: function() {
        wx.navigateTo({
            url: "/pages/settings/settings"
        });
    },
    toFastFindVessel: function() {
        l.see("fastFindVessel"), this.deadbeatBlockModal.check("fast_find_vessel").then(function(e) {
            e && wx.navigateTo({
                url: "/pages/fast-find-vessel/fast-find-vessel"
            });
        });
    },
    toSafeTrade: function() {
        wx.navigateTo({
            url: "/pages/safe-trade/safe-trade"
        });
    },
    toShipVip: function() {
        t.mercury.post("vip/log", {
            action: "vip_user_click",
            target: "home_to_vip_ship"
        }), wx.navigateTo({
            url: "/pages/settings/vip-ship/vip-ship"
        });
    },
    toPalletVip: function() {
        t.mercury.post("vip/log", {
            action: "vip_user_click",
            target: "home_to_vip_pallet"
        }), wx.navigateTo({
            url: "/pages/settings/vip-pallet/vip-pallet"
        });
    },
    toPageTop: function() {
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        });
    },
    loadOfficialPallets: function() {
        var e = this;
        return this.lastLoadOfficialPalletsTime = new Date().getTime(), t.mercury.get("utils/officialPallets").then(function(t) {
            t.forEach(function(e, t) {
                return e.showIndex = t;
            }), e.setData({
                officialPallets: {
                    items: t.map(e.formatPalletItem)
                }
            });
        });
    },
    formatPalletItem: function(e) {
        return e.tag.media.length > 0 && (e.user.avatarUrl = n.mercury("files/media/".concat(e.tag.media[0].hash, "?thumbnail=1"))), 
        e.isGreat = e.great && !e.great.pause, e.isGreat && (e.user.avatarUrl = "/images/great-pallet-avatar.jpg"), 
        e.user.avatarUrl || (e.user.newAvatar ? e.user.avatarUrl = e.user.newAvatar : e.user.avatarUrl = "/images/avatar-none.png"), 
        e;
    },
    refreshAdverts: function() {
        this.selectComponent("#top-advert").refresh();
    },
    unlockAccount: function(e) {
        return s.unlockingAccount = !0, this.waitFor(function() {
            return !g.globalData.backingHome;
        }).then(function() {
            setTimeout(function() {
                return wx.navigateTo({
                    url: "/pages/settings/unlock-account/unlock-account?mobile=".concat(e)
                });
            }, 100);
        });
    },
    checkShipAlarm: function() {
        Promise.all([ r.refresh(), o.refresh() ]).then(function() {
            var n = r.get(), s = o.get();
            t.mercury.get("ships/alarm", {
                ship: n && n.id,
                vessel: s && s.id
            }).then(function(t) {
                switch (t) {
                  case "publish":
                    e.confirm("您还没有发布空船信息！免费发布空船后系统会将最新官方实货短信通知您！", {
                        cancelText: "不是空船",
                        confirmText: "免费发布"
                    }).then(function() {
                        return wx.navigateTo({
                            url: "/pages/edit-ship/edit-ship?updateDate=1"
                        });
                    }).catch(function() {});
                    break;

                  case "update":
                    e.confirm("您的空船信息已过期，请及时更新！", {
                        cancelText: "暂不更新",
                        confirmText: "更新空船"
                    }).then(function() {
                        return wx.navigateTo({
                            url: "/pages/edit-ship/edit-ship?updateDate=1"
                        });
                    }).catch(function() {});
                }
            });
        });
    },
    resume: function() {
        var e = this;
        return s.id.get() > 0 ? t.mercury.get("account/my-profile?errorInResult=2").then(function(t) {
            return !t || 404 !== t.errorCode && 401 !== t.errorCode && 403 !== t.errorCode || (s.reset(), 
            e.waitFor(function() {
                return e.securityWarningModal;
            }).then(function() {
                return e.doSecurityWarning(t.reason, t.mobile);
            }), !1);
        }).catch(function() {
            return !0;
        }) : Promise.resolve(!0);
    },
    waitFor: function(e, t) {
        return new Promise(function(n) {
            !function s() {
                e() ? n() : setTimeout(s, Number.isFinite(t) ? t : 100);
            }();
        });
    },
    doSecurityWarning: function(t, n) {
        if ("MULTI_LOGIN" === t) this.unlockAccount(n); else {
            var s, i, a;
            switch (t) {
              case "CHEAT_DANGER":
                s = "系统监测到您的账号可能被其他人盗用，为了您的信息安全，请重新绑定手机号。如果是您将账号借给其他人使用，请通知对方停止使用您的账号，否则您的账号可能被封号", 
                i = "重新绑定手机号", a = function() {
                    return wx.navigateTo({
                        url: "/pages/bind-mobile/bindMobile"
                    });
                };
                break;

              case "CHEAT_FREEZE":
              default:
                s = "系统监测到您的账号多次被其他人盗用，为保护账号安全，已将当前账号封号，请向管理员申诉找回账号", i = "联系客服", a = function() {
                    return e.dial400();
                };
            }
            this.securityWarningModal.doModal(s, i).then(a);
        }
    },
    data: {
        officialPallets: null,
        maskPalletCount: 0,
        maskShipCount: 0,
        palletVip: 0,
        shipVip: 0
    },
    onLoad: function(e) {
        var t = this;
        this.syncFunctions = i.subscribeAndFireOnce(function(e) {
            return t.setData(i.obj());
        }), this.syncUserId = s.id.subscribeAndFireOnce(function(e) {
            return t.setData({
                userId: e
            });
        }), this.syncRecentContact = c.pendingCount.subscribeAndFireOnce(function(e) {
            return t.setData({
                newContacts: e
            });
        }), this.syncRelation = u.subscribeAndFireOnce(function(e) {
            return t.setData({
                newFriends: e ? e.friendReceived.length : 0
            });
        }), this.syncRedPacket = h.subscribeAndFireOnce(function(e) {
            return t.setData({
                redPacket: +(e && e.remain || 0).toFixed(2),
                redPacketUnseen: e && e.unseen || 0
            });
        }), this.syncUnseen = l.subscribeAndFireOnce(function(e) {
            var n = {};
            Object.getOwnPropertyNames(t.data).filter(function(e) {
                return e.startsWith("unseen_");
            }).forEach(function(e) {
                return n[e] = !1;
            }), e.forEach(function(e) {
                n["unseen_".concat(e)] = !0, [ "safeTrade" ].forEach(function(t) {
                    e.startsWith(t) && (n["unseen_group_".concat(t)] = !0);
                });
            }), t.setData(n);
        }), this.syncSettingsBadge = f.badge.subscribeAndFireOnce(function(e) {
            return t.setData({
                settingsBadge: e
            });
        }), this.syncMaskPalletCount = a.maskPalletCount.subscribeAndFireOnce(function(e) {
            return t.setData({
                maskPalletCount: e
            });
        }), this.syncMaskShipCount = r.maskShipCount.subscribeAndFireOnce(function(e) {
            return t.setData({
                maskShipCount: e
            });
        }), this.subResume = g.globalData.resumeEvent.subscribeAndFireOnce(function() {
            return t.onResume();
        }), this.syncVipStatus = d.subscribeAndFireOnce(function(e) {
            return t.setData({
                palletVip: e && e.palletLeftDays || 0,
                shipVip: e && e.shipLeftDays || 0
            });
        }), this.syncUsedVesselSellAlert = p.subscribeAndFireOnce(function(e) {
            return t.setData({
                usedVesselSellAlert: e
            });
        }), this.subCheatMobile = g.globalData.cheatMobileEvent.subscribe(function() {
            var e = g.globalData.cheatMobile;
            e && t.unlockAccount(e);
        }), this.resume().then(function(n) {
            t.subResumeAccount = g.globalData.resumeEvent.subscribe(function() {
                return t.resume();
            }), n && e.checkShipAlarm && t.checkShipAlarm();
        });
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal"), this.securityWarningModal = this.selectComponent("#securityWarning");
    },
    onShow: function() {
        g.globalData.backingHome = !1, this.onResume(), this.refreshAdverts(), this.refreshMaskInterval = setInterval(function() {
            a.pallets.refreshMask(), r.refreshMask();
        }, 6e4);
    },
    onHide: function() {
        this.refreshMaskInterval && (clearInterval(this.refreshMaskInterval), this.refreshMaskInterval = null);
    },
    onUnload: function() {
        this.syncFunctions.dispose(), this.syncUserId.dispose(), this.syncRecentContact.dispose(), 
        this.syncRelation.dispose(), this.syncUnseen.dispose(), this.syncRedPacket.dispose(), 
        this.syncSettingsBadge.dispose(), this.syncMaskPalletCount.dispose(), this.syncMaskShipCount.dispose(), 
        this.subResume.dispose(), this.syncVipStatus.dispose(), this.syncUsedVesselSellAlert.dispose(), 
        this.subCheatMobile.dispose(), this.subResumeAccount && this.subResumeAccount.dispose();
    },
    onPullDownRefresh: function() {
        this.refreshAdverts(), this.loadOfficialPallets().then(function() {
            return wx.stopPullDownRefresh();
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    }
});