var a = require("../../modules/moment");

module.exports = {
    getDateText: function(e) {
        e = a(e).startOf("day");
        var t = a().startOf("day");
        return e.valueOf() === t.valueOf() ? "今天" : e.valueOf() === a(t).add(1, "day").valueOf() ? "明天" : e.valueOf() === a(t).add(2, "day").valueOf() ? "后天" : e.format("M/D");
    }
};