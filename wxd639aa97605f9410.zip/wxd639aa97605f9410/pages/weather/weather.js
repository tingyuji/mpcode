var t = require("../../utils/util"), e = require("../../utils/ajax"), n = require("./common");

Page({
    data: {
        dates: [],
        items: []
    },
    load: function() {
        var t = this;
        e.mercury.get("weather/mainCities").then(function(e) {
            var a = e[0].weathers.map(function(t) {
                return n.getDateText(t.date);
            });
            t.setData({
                dates: a,
                items: e
            });
        }).catch(function(t) {
            return e.showError("获取天气数据", t);
        });
    },
    toCity: function(t) {
        var e = t.currentTarget.dataset.city;
        wx.navigateTo({
            url: "city/city?city=" + e
        });
    },
    onLoad: function(t) {
        e.mercury.post("weather/log", {
            action: "page_list",
            result: t.source
        }), this.load();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});