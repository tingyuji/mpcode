var t = require("../../../utils/globalMap"), i = require("../../../utils/ajax"), e = require("../../../utils/util"), r = require("../../../dao/port_hierarchy"), o = require("../../../modules/spark-md5"), a = {
    root: "国",
    "国": {}
};

Page({
    data: {
        options: [],
        root: "",
        level: ""
    },
    backToRoot: function() {
        this.setData({
            level: this.data.root,
            options: this.getOptions(this.data.root)
        });
    },
    select: function(t) {
        var e = t.currentTarget.dataset.option;
        if (this.hierarchy[e.id].children) this.setData({
            level: e.id,
            options: this.getOptions(e.id)
        }); else {
            var r = e.text;
            i.mercury.post("weather/log", {
                action: "change_city",
                result: r
            }), this.callback && this.callback(r), wx.navigateBack();
        }
    },
    getOptions: function(t) {
        var i = this, e = [];
        t && (this.hierarchy[t].children || []).forEach(function(t) {
            return e.push(t.map(function(t) {
                return {
                    id: t,
                    text: i.hierarchy[t].title,
                    count: i.hierarchy[t].count,
                    isSubArea: !!i.hierarchy[t].children
                };
            }));
        });
        return e.forEach(function(t) {
            return t.hash = o.hash(JSON.stringify(t));
        }), e;
    },
    onLoad: function(o) {
        var n = this, s = "shipStart", h = t.unRegister(o.query);
        this.city = h.city, this.callback = h.callback, i.mercury.post("weather/log", {
            action: "page_change_city",
            target: this.city,
            result: o.source
        });
        var c = r.get()[s];
        this.hierarchy = c || a;
        var u = this.hierarchy.root;
        this.setData({
            root: u
        }), this.setData({
            level: u,
            options: this.getOptions(u)
        }), this.syncHierachy = r.subscribe(function(t) {
            n.hierarchy = t[s], n.setData({
                root: n.hierarchy.root,
                options: n.getOptions(n.data.level)
            });
        }), c ? r.refresh(s) : (e.showLoading("加载数据中"), r.refresh(s).finally(e.hideLoading));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncHierachy.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});