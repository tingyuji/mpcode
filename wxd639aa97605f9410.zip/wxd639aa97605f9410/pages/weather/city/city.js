var t = require("../../../utils/util"), e = require("../../../utils/ajax"), i = require("../common"), n = require("../../../utils/globalMap");

Page({
    data: {
        city: "",
        cityText: "",
        items: []
    },
    load: function(t) {
        var n = this;
        e.mercury.get("weather/city", {
            city: t
        }).then(function(e) {
            e.forEach(function(t) {
                return t.dateText = i.getDateText(t.date);
            }), n.setData({
                city: t,
                cityText: t.split("").join(" "),
                items: e
            });
        }).catch(function(t) {
            return e.showError("获取天气数据", t);
        });
    },
    changeCity: function() {
        var t = {
            city: this.data.city,
            callback: this.load.bind(this)
        };
        wx.navigateTo({
            url: "../change-city/change-city?query=" + n.register(t)
        });
    },
    onLoad: function(t) {
        var i = t.city || "";
        e.mercury.post("weather/log", {
            action: "page_city",
            target: i,
            result: t.source
        }), this.load(i);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});