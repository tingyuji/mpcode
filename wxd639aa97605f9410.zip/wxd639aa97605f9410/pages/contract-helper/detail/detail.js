var t = require("../../../utils/util"), e = require("../../../utils/globalMap"), c = require("../../../utils/ajax");

Page({
    toEdit: function() {
        c.mercury.post("contractHelper/log", {
            action: "contract_helper.click_edit",
            target: this.data.item.id
        });
    },
    createText: function(t) {
        var e = this;
        this.lines = [], t.senderCompany ? (this.lines.push("托运方：".concat(t.senderCompany)), 
        this.lines.push("联系人：".concat(t.senderName, "，电话：").concat(t.senderMobile))) : this.lines.push("托运方：".concat(t.senderName, "，电话：").concat(t.senderMobile)), 
        this.lines.push("承运方：".concat(t.vesselName)), this.lines.push("联系人：".concat(t.carrierName, "，电话：").concat(t.carrierMobile));
        var c = 1;
        (this.lines.push("".concat(c++, ". 货物名称：").concat(t.cargoName)), this.lines.push("".concat(c++, ". 托运量：").concat(t.cargoWeight)), 
        this.lines.push("".concat(c++, ". 起运港：").concat(t.startPort)), this.lines.push("".concat(c++, ". 到达港：").concat(t.targetPort)), 
        this.lines.push("".concat(c++, ". 运费：").concat(t.freight)), t.deposit && this.lines.push("".concat(c++, ". 定金：").concat(t.deposit)), 
        t.startFee && this.lines.push("".concat(c++, ". 开航费：").concat(t.startFee)), this.lines.push("".concat(c++, ". 运费结算：").concat(t.settlement)), 
        this.lines.push("".concat(c++, ". 约定装货日期：").concat(t.loadDate)), this.lines.push("".concat(c++, ". 装卸天数：").concat(t.handlingTime)), 
        this.lines.push("".concat(c++, ". 滞期费：").concat(t.demurrage)), this.lines.push("".concat(c++, ". 货物交接：").concat(t.handOver)), 
        t.cargoLoss && this.lines.push("".concat(c++, ". 货物损耗：").concat(t.cargoLoss)), t.memo) && (this.lines.push("".concat(c++, ". 其他约定：")), 
        t.memo.split("\n").forEach(function(t) {
            return e.lines.push("    " + t);
        }));
        return this.lines.push(""), t.deposit ? this.lines.push("本合同自承运方收到定金起生效") : (this.lines.push("本合同双方同意后生效"), 
        this.lines.push("签订时间以双方微信回复同意为准")), this.lines.join("\n");
    },
    getShareText: function() {
        return [ "货物运输合同：" ].concat(this.lines).join("\n");
    },
    doCopy: function() {
        var e = this;
        c.mercury.post("contractHelper/log", {
            action: "contract_helper.click_copy",
            target: this.data.item.id
        }), wx.setClipboardData({
            data: this.getShareText(),
            success: function() {
                return e.copySuccessModal.show();
            },
            fail: function() {
                return t.alert("合同文本失败，请长按文本手动选择并复制");
            }
        });
    },
    successConfirm: function() {
        this.copySuccessModal.hide();
    },
    data: {
        item: {}
    },
    onLoad: function(t) {
        var n = e.unRegister(t.item) || {}, s = this.createText(n);
        this.setData({
            item: n,
            content: s,
            target: "carrier" === n.userType ? "货主" : "船主"
        }), c.mercury.post("contractHelper/log", {
            action: "contract_helper.page_detail",
            target: this.data.item.id
        });
    },
    onReady: function() {
        this.copySuccessModal = this.selectComponent("#copySuccessModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/contract-helper/contract-helper")
        };
    }
});