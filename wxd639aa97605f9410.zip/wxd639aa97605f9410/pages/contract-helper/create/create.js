var e = require("../../../utils/util"), t = require("../../../utils/ajax"), r = require("../../../utils/globalMap"), a = require("../../../modules/moment");

Page({
    select: function(e) {
        var n = e.currentTarget.dataset.item, o = null;
        if (!n.longTerm && !n.loadOnArrived) {
            var l = a(n.date);
            l.isValid() && (o = l.format("M月D日"));
        }
        var i = {
            userType: "sender",
            cargoName: n.name,
            cargoWeight: n.cargo,
            startPort: n.startPort,
            targetPort: n.aimPort,
            freight: n.price || null,
            startFee: n.startPrice || null,
            settlement: n.settlement || null,
            loadDate: o,
            handlingTime: n.handlingTime || null,
            demurrage: n.demurrage || null
        };
        /^\d+$/.test(i.cargoWeight) && (i.cargoWeight += "吨"), t.mercury.post("contractHelper/log", {
            action: "contract_helper.create_by_pallet",
            target: n.id,
            result: n.version
        }), wx.redirectTo({
            url: "../edit/edit?item=" + r.register(i)
        });
    },
    data: {
        pallets: []
    },
    onLoad: function(e) {
        this.setData({
            pallets: r.unRegister(e.pallets) || []
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/contract-helper/contract-helper")
        };
    }
});