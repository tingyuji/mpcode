var e = require("../../../utils/util"), t = require("../../../utils/globalMap"), i = require("../../../utils/user"), a = require("../../../utils/ajax"), n = require("../../../dao/vessel"), r = require("../../../dao/enterprise"), o = require("../common");

Page({
    load: function(t) {
        var i = this;
        e.showLoading("获取合同中"), a.mercury.get("contractHelper/load", {
            id: t
        }).finally(e.hideLoading).then(function(e) {
            return i.setData({
                item: e
            });
        }).catch(function(e) {
            return a.showError("获取合同信息", e);
        });
    },
    save: function(e) {
        var t = this;
        if (e = +e || 0, this.data.item && e < 30) if (this.saving) setTimeout(function() {
            return t.save(e + 1);
        }, 500); else {
            var i = Object.assign({}, this.data.item);
            JSON.stringify(i) !== JSON.stringify(this.lastItem) && (this.saving = !0, a.mercury.post("contractHelper/save", {
                item: i
            }).finally(function() {
                return t.saving = !1;
            }).then(function(e) {
                t.lastItem = i, i.id || (t.data.item.id = e);
            }).catch(function() {
                return setTimeout(function() {
                    return t.save(e + 1);
                }, 500);
            }));
        }
    },
    init: function(e) {
        "carrier" === e.userType ? (e.carrierName = i.name.get() || null, e.carrierMobile = i.mobile.get() || null, 
        e.vesselName = n.get() && n.get().name || null) : (e.senderName = i.name.get() || null, 
        e.senderMobile = i.mobile.get() || null, e.senderCompany = r.get() && r.get().name || null), 
        e.memo = o.defaultMemo(), this.setData({
            item: e
        }), this.save();
    },
    toDetail: function() {
        var i = this.data.item, a = o.requiredFields.filter(function(e) {
            return !i[e];
        }).map(function(e) {
            return o.fieldDesc[e] || e;
        });
        if (a.length > 0) return this.setData({
            validate: !0
        }), void e.alert("以下项目需要填写内容：" + a.join("，"));
        this.setData({
            validate: !1
        }), wx.navigateTo({
            url: "../detail/detail?item=" + t.register(i)
        });
    },
    edit: function(e) {
        var t = this, i = e.currentTarget.dataset.field;
        o.fieldDesc[i] && this.prompt(i, this.data.item).then(function(e) {
            if (e) {
                var i = Object.assign({}, t.data.item, e);
                JSON.stringify(t.data.item) !== JSON.stringify(i) && (t.setData({
                    item: i
                }), t.save());
            }
        });
    },
    prompt: function(e, i) {
        return new Promise(function(a) {
            var n = {
                type: e,
                item: i,
                callback: a
            };
            wx.navigateTo({
                url: "../memo/memo?params=" + t.register(n)
            });
        });
    },
    data: {
        item: {},
        validate: !1
    },
    onLoad: function(e) {
        var i = +e.id || null;
        if (a.mercury.post("contractHelper/log", {
            action: "contract_helper.page_edit",
            target: i
        }), i) this.load(i); else {
            var n = t.unRegister(e.item) || {};
            n.userType = n.userType || e.userType || "carrier", this.init(n);
        }
    },
    onReady: function() {
        this.fieldModal = this.selectComponent("#fieldModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/contract-helper/contract-helper")
        };
    }
});