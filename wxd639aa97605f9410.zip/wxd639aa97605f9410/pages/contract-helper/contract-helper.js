var e = require("../../utils/util"), t = require("../../utils/env"), r = require("../../utils/user"), n = require("../../utils/ajax"), a = require("../../utils/globalMap"), o = require("../../modules/moment");

Page({
    load: function() {
        var t = this;
        e.showLoading("读取合同中"), n.mercury.get("contractHelper/list").finally(e.hideLoading).then(function(e) {
            e.forEach(function(e) {
                return e.time = o(e.updateTime).format("M月D日");
            }), t.setData({
                items: e
            });
        }).catch(function(e) {
            return n.showError("获取历史合同", e);
        }), n.mercury.get("search/recentContacts").then(function(e) {
            return t.setData({
                recentContact: e.filter(function(e) {
                    return !e.passive;
                })
            });
        }), n.mercury.get("pallets/list").then(function(e) {
            var r = o().startOf("day").subtract(7, "days").valueOf();
            (e = e.filter(function(e) {
                return o(e.createTime).valueOf() >= r;
            })).sort(function(e, t) {
                return t.id - e.id;
            }), t.setData({
                pallets: e
            });
        });
    },
    toHelp: function() {
        e.browse(t.resource("app-help/how-to-use-contract-helper.html?ts=".concat(new Date().getTime())), "contract_helper.help");
    },
    remove: function(t) {
        var r = this, a = t.currentTarget.dataset.item;
        e.confirm("是否删除此合同？").then(function() {
            e.showLoading("删除合同中"), n.mercury.post("contractHelper/remove", {
                id: a.id
            }).finally(e.hideLoading).then(function() {
                return r.load();
            }).catch(function(e) {
                return n.showError("删除合同", e);
            });
        }).catch(function(e) {});
    },
    dial: function(e) {
        var t = e.currentTarget.dataset.item, r = "carrier" === t.userType ? t.senderMobile : t.carrierMobile;
        r = (r || "").trim(), /^[\d\(\)\s\+\-]+$/.test(r) && (n.mercury.post("contractHelper/log", {
            action: "contract_helper.dial",
            target: r,
            result: "carrier" === t.userType ? t.senderName : t.vesselName
        }), wx.makePhoneCall({
            phoneNumber: r
        }));
    },
    chooseUserType: function() {
        return e.confirm("请选择您是合同中的船方还是货方", {
            cancelText: "我是船方",
            confirmText: "我是货方",
            confirmColor: "#000000"
        });
    },
    manualCreate: function(e) {
        this.chooseUserType().then(function() {
            wx.navigateTo({
                url: "edit/edit?userType=sender"
            });
        }).catch(function() {
            wx.navigateTo({
                url: "edit/edit?userType=carrier"
            });
        });
    },
    fastCreate: function(t) {
        var r = this;
        this.chooseUserType().then(function() {
            r.data.pallets.length > 0 ? wx.navigateTo({
                url: "create/create?pallets=" + a.register(r.data.pallets)
            }) : e.alert("您当前没有已发布的货源，请选择手动新建合同");
        }).catch(function() {
            r.data.recentContact.length > 0 ? wx.navigateTo({
                url: "/pages/recent-contact/recent-contact?mode=contract"
            }) : e.alert("您没有最近查看过的货源，请选择手动新建合同");
        });
    },
    data: {
        items: null,
        recentContact: [],
        pallets: [],
        helpImage: t.resource("images/contract-helper.jpg")
    },
    onLoad: function(t) {
        var a = this;
        e.checkUserLogin(this), this.syncUserId = r.id.subscribeAndFireOnce(function(e) {
            return a.setData({
                userId: e
            });
        }), r.id.get() && (n.mercury.post("contractHelper/log", {
            action: "contract_helper.page_list"
        }), this.load());
    },
    onReady: function() {},
    onShow: function() {
        var t = this.notFirstShow;
        e.checkUserShow(this), t && r.id.get() && this.load();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    }
});