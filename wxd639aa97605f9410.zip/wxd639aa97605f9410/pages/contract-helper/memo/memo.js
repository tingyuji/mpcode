var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../modules/moment"), a = require("../../../utils/util"), r = require("../../../utils/globalMap"), i = require("../common");

function s() {
    return getApp().globalData.systemInfo.system.indexOf("iOS") >= 0;
}

Page({
    memoChange: function(e) {
        this.data.memo = e.detail.value, this.data.cursor = e.detail.cursor;
    },
    memoFocus: function() {
        this.isFocus = !0;
    },
    memoBlur: function(e) {
        this.isFocus = !1, this.data.cursor = e.detail.cursor;
    },
    getLinesInfo: function(e) {
        return e.split("\n").map(function(e) {
            var t = e.trim();
            /[;；.。]/.test(t.slice(-1)) && (t = t.slice(0, -1));
            var a = 0, r = t.match(/^(\d+)[)）]/);
            return r && (t = t.slice(r[0].length), a = +r[1] || 0), {
                index: a,
                content: t.trim()
            };
        }).filter(function(e) {
            return e.content;
        });
    },
    getFreightFees: function(e, t) {
        var a = this, r = t + "支付", i = r.length;
        return (e || "").slice(-i) === r ? e.slice(0, -i).split("、").map(function(e) {
            return a.nameToFee(e);
        }).filter(function(e) {
            return e;
        }) : [];
    },
    nameToFee: function(t) {
        var a, r = e(i.feeNameIds);
        try {
            for (r.s(); !(a = r.n()).done; ) {
                var s = a.value;
                if (i.feeNames[s] === t) return s;
            }
        } catch (e) {
            r.e(e);
        } finally {
            r.f();
        }
        return null;
    },
    getHandlingTimeChecks: function(e) {
        var t = this, a = "不计算装卸天数".length;
        return "不计算装卸天数" === (e || "").slice(-a) ? e.slice(0, -a).split("、").map(function(e) {
            return t.nameToHandlingTimeChecks(e);
        }).filter(function(e) {
            return e;
        }) : [];
    },
    nameToHandlingTimeChecks: function(t) {
        var a, r = e(i.handlingTimeCheckIds);
        try {
            for (r.s(); !(a = r.n()).done; ) {
                var s = a.value;
                if (i.handlingTimeChecks[s] === t) return s;
            }
        } catch (e) {
            r.e(e);
        } finally {
            r.f();
        }
        return null;
    },
    initValues: function(a, r) {
        var s = r.extra || null, n = i.fieldDesc[a], o = i.placeholders[a] || "请在这里输入".concat(n), l = i.titles[a] || "请输入".concat(n, "："), c = !!i.titles[a], h = r[a], d = {
            type: a,
            memo: null,
            extra: s,
            placeholder: o,
            title: l,
            infoExtra: c,
            focus: !c
        }, u = null == h;
        if ("memo" === a) {
            var m = this.getLinesInfo(h || "").map(function(e) {
                return e.content;
            }), f = [];
            if (!u) {
                d.memo_check = {}, i.memoChecksIds.forEach(function(e) {
                    return d.memo_check[e] = !1;
                });
                var _, g = e(m);
                try {
                    for (g.s(); !(_ = g.n()).done; ) {
                        var p, v = _.value, k = !0, x = e(i.memoChecksIds);
                        try {
                            for (x.s(); !(p = x.n()).done; ) {
                                var y = p.value;
                                if (!d.memo_check[y]) {
                                    var b = new RegExp("^" + i.memoChecks[y].replace("$days$", "(\\d+)") + "$"), F = v.match(b);
                                    if (F) {
                                        d.memo_check[y] = !0, F[1] && void 0 !== this.data["memo_check_".concat(y, "_days")] && (d["memo_check_".concat(y, "_days")] = F[1]), 
                                        k = !1;
                                        break;
                                    }
                                }
                            }
                        } catch (e) {
                            x.e(e);
                        } finally {
                            x.f();
                        }
                        k && f.push({
                            check: !0,
                            content: v
                        });
                    }
                } catch (e) {
                    g.e(e);
                } finally {
                    g.f();
                }
            }
            this.getLinesInfo(s || "").sort(function(e, t) {
                return e.index - t.index;
            }).forEach(function(e) {
                f.splice(e.index - 1, 0, {
                    check: !1,
                    content: e.content
                });
            }), f.forEach(function(e, t) {
                return e.id = t + 1;
            }), d.memo_extras = f;
        } else {
            var C = (h || "").split(/[;；]/).filter(function(e) {
                return e;
            });
            switch (d.sel = this.data.sel, a) {
              case "freight":
                if (u) d.sel.freight = "0"; else {
                    d.sel.freight = "2";
                    var I = (C[0] || "").match(/^(\d+\.?\d*)元\/吨$/);
                    I ? (d.sel.freight = "0", d.freight_ton = I[1]) : (I = (C[0] || "").match(/^(\d+\.?\d*)元\/船$/)) && (d.sel.freight = "1", 
                    d.freight_vessel = I[1]), I && C.shift();
                    var N = new Set(this.getFreightFees(C[0], "托运方"));
                    N.size > 0 && C.shift();
                    var E = new Set(this.getFreightFees(C[0], "承运方"));
                    E.size > 0 && C.shift(), i.feeNameIds.forEach(function(e) {
                        d.sel[e] = N.has(e) ? "1" : E.has(e) ? "2" : "0";
                    });
                }
                break;

              case "startFee":
                d.start_fee_check = this.data.start_fee_check, d.start_fee_check.cash = u;
                var $ = (C[0] || "").match(/^现金(-?\d+\.?\d*)元$/);
                $ && (d.start_fee_check.cash = !0, d.start_fee_amount = $[1], C.shift()), ($ = (C[0] || "").match(/^加油(-?\d+\.?\d*)吨(（油价按(-?\d+\.?\d*)元\/吨计算）)?$/)) && (d.start_fee_check.oil = !0, 
                d.start_fee_oil_ton = $[1], d.start_fee_oil_price = $[3] || null, C.shift());
                break;

              case "settlement":
                d.sel.settlement = u ? "0" : "3";
                var D = (C[0] || "").match(/^卸前付清$/);
                D ? d.sel.settlement = "0" : (D = (C[0] || "").match(/^卸前付(.+)，收到回单后(\d+)个工作日内结清尾款$/)) ? (d.sel.settlement = "1", 
                d.settlement_1_ratio = D[1], d.settlement_1_days = D[2]) : (D = (C[0] || "").match(/^卸前付(.+)，吨位出来后(\d+)个工作日内结清尾款$/)) && (d.sel.settlement = "2", 
                d.settlement_2_ratio = D[1], d.settlement_2_days = D[2]), D && C.shift();
                break;

              case "loadDate":
                d.sel.load_date = u ? "0" : "2";
                var T = (C[0] || "").match(/^(\d+)年(\d+)月(\d+)日$/);
                if (T) {
                    d.sel.load_date = "0";
                    var Y = new Date(+T[1], +T[2] - 1, +T[3]);
                    d.load_date = t(Y).format("YYYY-MM-DD"), d.load_date_display = t(Y).format("YYYY年M月D日");
                } else (T = (C[0] || "").match(/^按船到港日起算$/)) && (d.sel.load_date = "1");
                T && C.shift();
                break;

              case "handlingTime":
                d.sel.handling_time = u ? "0" : "3";
                var M = (C[0] || "").match(/^装三卸四，两港七天$/);
                if (M ? d.sel.handling_time = "0" : (M = (C[0] || "").match(/^两港装卸不超过(\d+)天$/)) ? (d.sel.handling_time = "1", 
                d.handling_time_1_days = M[1]) : (M = (C[0] || "").match(/^卸货不超过(\d+)天$/)) && (d.sel.handling_time = "2", 
                d.handling_time_2_days = M[1]), M && C.shift(), !u) {
                    var w = new Set(this.getHandlingTimeChecks(C[0]));
                    w.size > 0 && C.shift(), d.handling_time_check = {}, i.handlingTimeCheckIds.forEach(function(e) {
                        return d.handling_time_check[e] = w.has(e);
                    });
                }
                break;

              case "demurrage":
                d.sel.demurrage = u ? "0" : "4";
                var O = (C[0] || "").match(/^1元\/吨\/天$/);
                O ? d.sel.demurrage = "0" : (O = (C[0] || "").match(/^0.5元\/吨\/天$/)) ? d.sel.demurrage = "1" : (O = (C[0] || "").match(/^(\d+\.?\d*)元\/吨\/天$/)) ? (d.sel.demurrage = "2", 
                d.demurrage_ton_price = O[1]) : (O = (C[0] || "").match(/^1天(\d+\.?\d*)元$/)) && (d.sel.demurrage = "3", 
                d.demurrage_day_price = O[1]), O && C.shift();
                break;

              case "handOver":
                d.sel.hand_over = u ? "0" : "6";
                var R = i.handOvers.indexOf(C[0] || "");
                R >= 0 && (d.sel.hand_over = R.toString(), C.shift());
                break;

              case "cargoLoss":
                d.sel.cargo_loss = u ? "0" : "3";
                var S = (C[0] || "").match(/^不超过千分之(\d+\.?\d*)，超耗部分按(\d+\.?\d*)元\/吨赔偿$/);
                S ? (d.sel.cargo_loss = "0", d.cargo_loss_0_ratio = S[1], d.cargo_loss_0_price = S[2]) : (S = (C[0] || "").match(/^不超过百分之(\d+\.?\d*)，超耗部分按(\d+\.?\d*)元\/吨赔偿$/)) ? (d.sel.cargo_loss = "1", 
                d.cargo_loss_1_ratio = S[1], d.cargo_loss_1_price = S[2]) : (S = (C[0] || "").match(/^不约定货物损耗$/)) && (d.sel.cargo_loss = "2"), 
                S && C.shift();
            }
            d.memo = C.join("；");
        }
        return d;
    },
    linesToMemo: function(e, t) {
        for (var a = 0; a < e.length; a++) {
            var r = (t ? t[a] : a) + 1;
            e[a] = "".concat(r, ") ") + e[a] + (a === e.length - 1 ? "。" : "；");
        }
        return e.join("\r\n");
    },
    generateResult: function() {
        var t = this;
        if ("memo" === this.data.type) {
            var r, s = [], n = [], o = [], l = e(i.memoChecksIds);
            try {
                for (l.s(); !(r = l.n()).done; ) {
                    var c = r.value;
                    if (this.data.memo_check[c]) {
                        var h = i.memoChecks[c], d = "memo_check_".concat(c, "_days");
                        if (void 0 !== this.data[d]) {
                            var u = parseInt(this.data[d]);
                            if (!Number.isFinite(u)) return a.alert("请在勾选的条款中输入天数"), !1;
                            h = h.replace("$days$", u);
                        }
                        s.push(h);
                    }
                }
            } catch (e) {
                l.e(e);
            } finally {
                l.f();
            }
            this.data.memo_extras.forEach(function(e, t) {
                e.check ? s.push(e.content) : (n.push(e.content), o.push(t));
            }), this.doneResult = {
                memo: this.linesToMemo(s),
                extra: this.linesToMemo(n, o)
            };
        } else {
            var m = [];
            switch (this.data.type) {
              case "freight":
                if ("0" === this.data.sel.freight) {
                    var f = parseFloat(this.data.freight_ton);
                    if (!Number.isFinite(f)) return a.alert("请输入按吨计价价格，或选择其他运费计价方式"), !1;
                    m.push("".concat(f, "元/吨"));
                } else if ("1" === this.data.sel.freight) {
                    var _ = parseFloat(this.data.freight_vessel);
                    if (!Number.isFinite(_)) return a.alert("请输入包船计价价格，或选择其他运费计价方式"), !1;
                    m.push("".concat(_, "元/船"));
                }
                if (!m.length) return a.alert("请选择一种运费计价方式"), !1;
                var g = i.feeNameIds.filter(function(e) {
                    return "1" === t.data.sel[e];
                });
                g.length > 0 && m.push(g.map(function(e) {
                    return i.feeNames[e];
                }).join("、") + "托运方支付");
                var p = i.feeNameIds.filter(function(e) {
                    return "2" === t.data.sel[e];
                });
                p.length > 0 && m.push(p.map(function(e) {
                    return i.feeNames[e];
                }).join("、") + "承运方支付");
                break;

              case "startFee":
                if (this.data.start_fee_check.cash) {
                    var v = parseFloat(this.data.start_fee_amount);
                    if (!Number.isFinite(v)) return a.alert("请输入开航费金额，或去除现金勾选"), !1;
                    m.push("现金".concat(v, "元"));
                }
                if (this.data.start_fee_check.oil) {
                    var k = parseFloat(this.data.start_fee_oil_ton), x = parseFloat(this.data.start_fee_oil_price);
                    if (!Number.isFinite(k)) return a.alert("请输入加油吨数，或去除加油勾选"), !1;
                    m.push("加油".concat(k, "吨") + (Number.isFinite(x) && x ? "（油价按".concat(x, "元/吨计算）") : ""));
                }
                break;

              case "settlement":
                if ("0" === this.data.sel.settlement) m.push("卸前付清"); else if ("1" === this.data.sel.settlement) {
                    var y = (this.data.settlement_1_ratio || "").trim(), b = parseInt(this.data.settlement_1_days);
                    if (!y || !Number.isFinite(b)) return a.alert("请输入卸前付比例及收到回单后日期，或选择其他结算方式"), !1;
                    m.push("卸前付".concat(y, "，收到回单后").concat(b, "个工作日内结清尾款"));
                } else if ("2" === this.data.sel.settlement) {
                    var F = (this.data.settlement_2_ratio || "").trim(), C = parseInt(this.data.settlement_2_days);
                    if (!F || !Number.isFinite(C)) return a.alert("请输入卸前付比例及吨位出来后日期，或选择其他结算方式"), !1;
                    m.push("卸前付".concat(F, "，吨位出来后").concat(C, "个工作日内结清尾款"));
                }
                if (!m.length && !this.data.memo) return a.alert("请选择一种运费结算方式，或在补充说明中输入运费结算相关说明"), 
                !1;
                break;

              case "loadDate":
                "0" === this.data.sel.load_date ? m.push(this.data.load_date_display) : "1" === this.data.sel.load_date && m.push("按船到港日起算");
                break;

              case "handlingTime":
                if ("0" === this.data.sel.handling_time) m.push("装三卸四，两港七天"); else if ("1" === this.data.sel.handling_time) {
                    var I = parseInt(this.data.handling_time_1_days);
                    if (!Number.isFinite(I)) return a.alert("请输入两港装卸不超过的天数，或选择其他装卸天数约定"), !1;
                    m.push("两港装卸不超过".concat(I, "天"));
                } else if ("2" === this.data.sel.handling_time) {
                    var N = parseInt(this.data.handling_time_2_days);
                    if (!Number.isFinite(N)) return a.alert("请输入卸货不超过的天数，或选择其他装卸天数约定"), !1;
                    m.push("卸货不超过".concat(N, "天"));
                }
                if (!m.length && !this.data.memo) return a.alert("请选择并输入装卸天数约定，或在补充说明中输入装卸天数相关说明"), 
                !1;
                var E = i.handlingTimeCheckIds.filter(function(e) {
                    return t.data.handling_time_check[e];
                });
                E.length > 0 && m.push(E.map(function(e) {
                    return i.handlingTimeChecks[e];
                }).join("、") + "不计算装卸天数");
                break;

              case "demurrage":
                if ("0" === this.data.sel.demurrage) m.push("1元/吨/天"); else if ("1" === this.data.sel.demurrage) m.push("0.5元/吨/天"); else if ("2" === this.data.sel.demurrage) {
                    var $ = parseFloat(this.data.demurrage_ton_price);
                    if (!Number.isFinite($)) return a.alert("请输入滞期费，或选择其他滞期费金额"), !1;
                    m.push("".concat($, "元/吨/天"));
                } else if ("3" === this.data.sel.demurrage) {
                    var D = parseFloat(this.data.demurrage_day_price);
                    if (!Number.isFinite(D)) return a.alert("请输入滞期费，或选择其他滞期费金额"), !1;
                    m.push("1天".concat(D, "元"));
                }
                if (!m.length && !this.data.memo) return a.alert("请选择并输入滞期费信息，或在补充说明中输入滞期费相关说明"), 
                !1;
                break;

              case "handOver":
                var T = +this.data.sel.hand_over;
                if (Number.isFinite(T) && T >= 0 && T < i.handOvers.length && m.push(i.handOvers[T]), 
                !m.length && !this.data.memo) return a.alert("请选择货物交接方式，或在补充说明中输入货物交接方式相关说明"), !1;
                break;

              case "cargoLoss":
                if ("0" === this.data.sel.cargo_loss) {
                    var Y = parseFloat(this.data.cargo_loss_0_ratio), M = parseFloat(this.data.cargo_loss_0_price);
                    if (!Number.isFinite(Y) || !Number.isFinite(M)) return a.alert("请输入损耗千分比及超耗赔偿金额，或选择其他损耗类型"), 
                    !1;
                    m.push("不超过千分之".concat(Y, "，超耗部分按").concat(M, "元/吨赔偿"));
                } else if ("1" === this.data.sel.cargo_loss) {
                    var w = parseFloat(this.data.cargo_loss_0_ratio), O = parseFloat(this.data.cargo_loss_1_price);
                    if (!Number.isFinite(w) || !Number.isFinite(O)) return a.alert("请输入损耗百分比及超耗赔偿金额，或选择其他损耗类型"), 
                    !1;
                    m.push("不超过百分之".concat(w, "，超耗部分按").concat(O, "元/吨赔偿"));
                } else "2" === this.data.sel.cargo_loss && m.push("不约定货物损耗");
            }
            this.doneResult = {}, this.doneResult[this.data.type] = m.concat((this.data.memo || "").split(/[;；]/).filter(function(e) {
                return e;
            })).join("；");
        }
        return !0;
    },
    loadDateChange: function(e) {
        this.data.load_date = e.detail.value, this.setData({
            load_date_display: t(this.data.load_date).format("YYYY年M月D日")
        });
    },
    radioChange: function(e) {
        this.data.sel[e.target.dataset.name] = e.detail.value, this.setData({
            sel: this.data.sel
        });
    },
    checkboxChange: function(e) {
        var t = e.target.dataset.name, a = new Set(e.detail.value), r = {};
        Object.getOwnPropertyNames(this.data[t]).forEach(function(e) {
            return r[e] = a.has(e);
        });
        var i = {};
        i[t] = r, this.setData(i);
    },
    memoExtraCheckChange: function(e) {
        var t = new Set(e.detail.value);
        this.data.memo_extras.forEach(function(e) {
            return e.check = t.has(e.id.toString());
        });
    },
    inputTap: function(e) {},
    inputChange: function(e) {
        this.data[e.target.dataset.name] = e.detail.value;
    },
    inputBlur: function(e) {
        var t = {};
        t[e.target.dataset.name] = e.detail.value, this.setData(t);
    },
    extraChange: function(e) {
        this.data.extraContent = e.detail.value;
    },
    addExtra: function() {
        this.currentExtra = {
            check: !0,
            content: ""
        }, this.setData({
            extraContent: ""
        }), this.extraModal.show();
    },
    editExtra: function(e) {
        var t = e.currentTarget.dataset.item;
        this.setData({
            extraContent: t.content
        }), this.currentExtra = t, this.extraModal.show();
    },
    confirmExtra: function() {
        var e = this;
        if (this.currentExtra.content = this.data.extraContent, !this.currentExtra.id) for (var t = function(t) {
            if (e.currentExtra.id = t, !e.data.memo_extras.find(function(e) {
                return e.id === t;
            })) return "break";
        }, a = 1; ;a++) {
            if ("break" === t(a)) break;
        }
        var r = this.data.memo_extras.slice(), i = r.findIndex(function(t) {
            return t.id === e.currentExtra.id;
        });
        i >= 0 ? r[i] = this.currentExtra : r.push(this.currentExtra), this.setData({
            memo_extras: r
        }), this.extraModal.hide();
    },
    removeExtra: function(e) {
        var t = this, r = e.currentTarget.dataset.item;
        a.confirm("确定要删除条款“".concat(r.content, "”吗？")).then(function() {
            var e = t.data.memo_extras, a = e.findIndex(function(e) {
                return e.id === r.id;
            });
            a >= 0 && (e.splice(a, 1), t.setData({
                memo_extras: e
            }));
        });
    },
    confirm: function() {
        this.generateResult() && wx.navigateBack();
    },
    data: {
        type: "",
        focus: !1,
        autoHeight: !0,
        isIOS: s(),
        memo: "",
        memoHeight: 90,
        cursor: 0,
        title: "",
        placeholder: "",
        infoExtra: !1,
        freightFees: i.feeNameIds.map(function(e) {
            return {
                id: e,
                name: i.feeNames[e]
            };
        }),
        freightFeeItems: i.freightFeeItems,
        handOverItems: i.handOvers.concat("其它交接方式").map(function(e, t) {
            return {
                id: t,
                name: e
            };
        }),
        sel: {
            freight: "0",
            gang_jian: "1",
            ma_tou: "1",
            mao_di: "2",
            qian_zheng: "2",
            settlement: "0",
            load_date: "0",
            handling_time: "0",
            demurrage: "0",
            hand_over: "0",
            cargo_loss: "0"
        },
        freight_ton: null,
        freight_vessel: null,
        start_fee_check: {
            cash: !0,
            oil: !1
        },
        start_fee_amount: null,
        start_fee_oil_ton: null,
        start_fee_oil_price: null,
        settlement_1_ratio: "90%",
        settlement_1_days: "7",
        settlement_2_ratio: "90%",
        settlement_2_days: "3",
        load_date: t().format("YYYY-MM-DD"),
        load_date_display: t().format("YYYY年M月D日"),
        handling_time_check: {
            1: !1,
            2: !0,
            3: !1,
            4: !1,
            5: !1
        },
        handling_time_1_days: null,
        handling_time_2_days: null,
        demurrage_ton_price: null,
        demurrage_day_price: null,
        cargo_loss_0_ratio: "3",
        cargo_loss_0_price: null,
        cargo_loss_1_ratio: "3",
        cargo_loss_1_price: null,
        memo_check: {
            1: !0,
            2: !0,
            3: !0,
            4: !0,
            5: !0,
            6: !0,
            7: !0,
            8: !1,
            9: !1,
            10: !0,
            11: !0
        },
        memo_check_3_days: "3",
        memo_check_9_days: "7",
        memo_extras: [],
        memo_extra_check: {},
        extraContent: ""
    },
    onLoad: function(e) {
        var t = r.unRegister(e.params);
        this.doneCallback = t.callback;
        var a = this.initValues(t.type, t.item || {});
        a.cursor = (a.memo || "").length, a.autoHeight = s(), this.setData(a);
    },
    onReady: function() {
        this.extraModal = this.selectComponent("#extraModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.unloaded = !0, this.doneCallback && this.doneCallback(this.doneResult);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/contract-helper/contract-helper")
        };
    }
});