var e = {
    gang_jian: "港建费",
    ma_tou: "码头费",
    mao_di: "锚地费",
    qian_zheng: "签证费"
}, r = Object.getOwnPropertyNames(e), a = {
    1: "雨天",
    2: "春节假期",
    3: "十一假期",
    4: "查环保",
    5: "停电"
}, t = Object.getOwnPropertyNames(a).sort(), n = {
    1: "船舶于中午12点前到港，从到港当天算起；船舶于中午12点后到港，从第二天算起",
    2: "如遇不可抗力，装卸时间另行商定",
    3: "如果托运方在约定装货期$days$天内不能给船装货，托运方可追加定金要求船舶继续等待（追加的定金金额不低于滞期费标准），承运方不能拒绝托运方追加定金的要求，否则需双倍退还已收定金；若托运方不给承运方追加定金，承运方可于第三天24:00后不退定金，开船离港，承运方无责",
    4: "如需转港，需支付转港费，费用另行约定",
    5: "承运方收到定金不按约定时间到港装货，需将收到的定金双倍退还托运方",
    6: "承运方需保证货物安全，如因承运方原因发生货物损失，需照价赔偿",
    12: "承运方在运输途中应按托运方货物质量要求保证货物安全到达，运输过程中必须封仓防止雨水进入，严禁动用明火电焊等危险作业，由此造成的一切后果由承运方承担；因承运方原因造成货雨淋进水由承运方全权负责并照价赔偿。不可抗的风险除外，协商解决",
    7: "货物运输保险由托运方负责购买",
    8: "承运方需根据托运方的书面要求核对货物规格、品名数量、质量及包装要求等，并对其负责。破损、受潮、污染货物不允许上船，否则造成货物短少和质量问题，承运方要负相应责任",
    9: "承运方需于装货完成后$days$日内将货物运抵到达港",
    13: "合同没有约定的，双方同意适用于《国内水路货物运输规则》",
    10: "如有纠纷双方协商解决，协商不成向南京海事法院诉讼，律师费由败诉方承担",
    11: "若因承运方原因导致合同无效，无法履行的，应当向托运方双倍返还已收取的全部费用，本条独立于合同其他条款，不因合同的无效而丧失效力"
}, s = Object.getOwnPropertyNames(n), o = {
    1: !0,
    2: !0,
    3: !0,
    4: !0,
    5: !0,
    6: !0,
    7: !0,
    8: !1,
    9: !1,
    10: !0,
    11: !0,
    12: !1,
    13: !0,
    "3_days": "3",
    "9_days": "7"
};

function d(e) {
    for (var r = 0; r < e.length; r++) e[r] = "".concat(r + 1, ") ") + e[r] + (r === e.length - 1 ? "。" : "；");
    return e.join("\r\n");
}

module.exports = {
    requiredFields: [ "senderName", "senderMobile", "carrierName", "carrierMobile", "vesselName", "cargoName", "cargoWeight", "startPort", "targetPort", "freight", "settlement", "loadDate", "handlingTime", "demurrage", "handOver" ],
    fieldDesc: {
        senderName: "托运方姓名",
        senderMobile: "托运方电话",
        senderCompany: "托运方公司名称",
        senderIdCard: "托运方身份证号",
        carrierName: "承运方姓名",
        carrierMobile: "承运方电话",
        vesselName: "承运方船名",
        carrierIdCard: "承运方身份证号",
        cargoName: "货物名称",
        cargoWeight: "托运量",
        startPort: "起运港",
        targetPort: "到达港",
        freight: "运费信息",
        deposit: "定金信息",
        startFee: "开航费信息",
        settlement: "运费结算信息",
        loadDate: "约定装货日期",
        handlingTime: "装卸天数",
        demurrage: "滞期费信息",
        handOver: "货物交接方式",
        cargoLoss: "货物损耗",
        memo: "其他约定内容"
    },
    feeNames: e,
    feeNameIds: r,
    freightFeeItems: [ {
        name: "托运方",
        value: "1"
    }, {
        name: "承运方",
        value: "2"
    }, {
        name: "无费用",
        value: "0"
    } ],
    handlingTimeChecks: a,
    handlingTimeCheckIds: t,
    handOvers: [ "按装货港过磅吨位结算", "按卸货港过磅吨位结算", "量方", "交件数", "量水尺", "封舱盖印" ],
    memoChecks: n,
    memoChecksIds: s,
    titles: {
        freight: "请选择并输入运费信息（单选）：",
        startFee: "请选择并输入开航费信息（多选）：",
        settlement: "请选择运费结算方式（单选）：",
        loadDate: "请选择约定装货日期（单选）：",
        handlingTime: "请选择装卸天数（单选）：",
        demurrage: "请选择并输入滞期费信息（单选）：",
        handOver: "请选择货物交接方式（单选）：",
        cargoLoss: "请选择货物损耗（单选）：",
        memo: "请根据需要选择您的合同条款（多选）："
    },
    placeholders: {
        freight: "请输入其他与运费相关的补充说明",
        startFee: "请输入开航费相关补充说明",
        settlement: "请输入运费结算相关补充说明",
        loadDate: "请输入约定装货日期相关补充说明",
        handlingTime: "请输入装卸天数相关补充说明",
        demurrage: "请输入滞期费相关补充说明",
        handOver: "请输入货物交接方式相关补充说明",
        cargoLoss: "请输入货物损耗相关补充说明"
    },
    linesToMemo: d,
    defaultMemo: function() {
        return d(s.filter(function(e) {
            return o[e];
        }).map(function(e) {
            return n[e].replace("$days$", o[e + "_days"]);
        }));
    }
};