var i = require("../../utils/ajax");

require("../../utils/util");

Page({
    data: {
        vessel: Object
    },
    onLoad: function(n) {
        this.shipId = n.shipId, this.shipId && i.mercury.get("vessels/loadByShip", {
            id: this.shipId
        }).then(function(i) {
            this.setData({
                vessel: i
            });
        }.bind(this));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});