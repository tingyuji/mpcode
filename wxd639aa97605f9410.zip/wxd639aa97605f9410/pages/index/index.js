require("../../utils/user");

var t = require("../../utils/ajax"), e = require("../../utils/util"), i = require("../friend-circle/recommend/daemon"), s = (require("../../dao/unseenServices"), 
getApp());

Page({
    data: {
        loading: !0
    },
    onLoad: function(t) {
        var e = this;
        this.loadOptions = Object.assign({}, t);
        var i = new Set(Object.getOwnPropertyNames(this.loadOptions));
        [ "origin", "target", "result" ].forEach(function(t) {
            return i.delete(t);
        }), this.emptyOptions = !i.size, this.loadOptions.shareBuy && (this.loadOptions.shareBuy = +this.loadOptions.shareBuy || 0), 
        [ "launch", "navigate", "share" ].forEach(function(t) {
            e.loadOptions[t] && (e.loadOptions[t] = decodeURIComponent(e.loadOptions[t]), e.loadOptions.source && (e.loadOptions[t] += (e.loadOptions[t].indexOf("?") >= 0 ? "&" : "?") + "source=" + e.loadOptions.source));
        });
    },
    onReady: function() {
        var t = this, e = s.globalData.loginEvent.subscribeAndFireOnce(function(i) {
            i && (setTimeout(function() {
                return e.dispose();
            }, 0), t.onLogin());
        });
        this.noticeModal = this.selectComponent("#noticeModal");
    },
    onLogin: function() {
        this.step = 1, this.loadOptions.shareBuy ? (this.step = 0, wx.navigateTo({
            url: "/pages/share-buy/share-buy?id=" + this.loadOptions.shareBuy
        })) : this.afterLogin();
    },
    afterLogin: function() {
        var e = wx.getLaunchOptionsSync().scene;
        t.mercury.post("miniProgram/afterLogin", {
            options: this.loadOptions,
            scene: e
        }), this.loadOptions.launch ? wx.navigateTo({
            url: this.loadOptions.launch
        }) : this.loadOptions.navigate ? wx.navigateTo({
            url: this.loadOptions.navigate
        }) : "sms_marketing" === this.loadOptions.origin ? this.smsMarketing() : "sms_marketing_certify_vessel" === this.loadOptions.origin ? this.smsMarketingCertifyVessel() : (this.step = 0, 
        this.checkStep());
    },
    smsMarketing: function() {
        var e = this, i = this.loadOptions.target;
        t.mercury.post("sms/clickLink", {
            hash: i
        }), t.mercury.get("sms/detail", {
            token: i
        }).then(function(t) {
            var e = "/pages/home/home";
            "location" !== t.type && "friend_location" !== t.type || (e = "/pages/zhaohuo/zhaohuo", 
            (t.start || t.target) && (e += "?cacheQuery=1&startPorts=" + (t.start || []).map(function(t) {
                return t.id;
            }).join() + "&startPortTitles=" + (t.start || []).map(function(t) {
                return t.title;
            }).join() + "&targetPorts=" + (t.target || []).map(function(t) {
                return t.id;
            }).join() + "&targetPortTitles=" + (t.target || []).map(function(t) {
                return t.title;
            }).join() + "&minWeight=" + t.minWeight + "&maxWeight=" + t.maxWeight)), wx.navigateTo({
                url: e
            });
        }).catch(function(t) {
            console.error(t), e.step = 0, e.checkStep();
        });
    },
    smsMarketingCertifyVessel: function() {
        t.mercury.post("sms/clickCertifyVesselLink", {
            hash: this.loadOptions.target
        }), wx.navigateTo({
            url: "/pages/settings/certify-vessel/certifyVessel?source=sms_marketing"
        });
    },
    onShow: function() {
        this.notFirst ? this.checkStep() : this.notFirst = !0;
    },
    checkStep: function() {
        var t = this;
        switch (this.step++) {
          case 0:
            i.startup().then(function(e) {
                e || t.checkStep();
            });
            break;

          case 1:
            this.checkNotice();
            break;

          case 2:
            this.switchTab();
            break;

          default:
            this.toHome();
        }
    },
    switchTab: function() {
        if (this.loadOptions.tab) {
            var t = e.getTabPage(this.loadOptions.tab);
            t ? wx.navigateTo({
                url: t
            }) : this.toHome();
        } else this.toHome();
    },
    toHome: function() {
        wx.redirectTo({
            url: "/pages/home/home" + (this.emptyOptions ? "?checkShipAlarm=1" : "")
        });
    },
    checkNotice: function() {
        var t = this;
        this.noticeModal.check(function() {
            return t.setData({
                loading: !1
            });
        }, function() {
            return t.setData({
                loading: !0
            });
        }).finally(function() {
            return t.checkStep();
        });
    }
});