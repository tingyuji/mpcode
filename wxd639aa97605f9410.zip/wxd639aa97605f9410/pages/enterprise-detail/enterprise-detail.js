var e = require("../../utils/ajax.js"), t = require("../../utils/env"), n = require("../../utils/util");

Page({
    data: {
        enterprise: Object
    },
    onLoad: function(n) {
        this.entId = n.id, e.mercury.get("starEnterprises/detail?id=".concat(this.entId)).then(function(e) {
            e.logo ? e.logoUrl = t.mercury("store/logo/".concat(e.logo, "?size=100&mode=pad")) : e.logoUrl = "/images/star_logo_none.png", 
            e.name = e.name || "", e.brief = e.brief || "", this.setData({
                enterprise: e
            });
        }.bind(this));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.sharePath({
                id: this.entId
            })
        };
    }
});