var t = require("../../utils/globalMap");

Page({
    data: {
        price: null,
        startPrice: null,
        demurrage: null,
        handlingTime: null,
        settlement: null,
        payment: null
    },
    onLoad: function(t) {
        var e = {
            callback: t.callback,
            price: t.price || null,
            startPrice: t.startPrice || null,
            demurrage: t.demurrage || null,
            handlingTime: t.handlingTime || null,
            settlement: t.settlement || null,
            payment: t.payment || null
        };
        this.setData(e);
    },
    setPrice: function(t) {
        this.data.price = t.detail.value;
    },
    setStartPrice: function(t) {
        this.data.startPrice = t.detail.value;
    },
    setDemurrage: function(t) {
        this.data.demurrage = t.detail.value;
    },
    setHandlingTime: function(t) {
        this.data.handlingTime = t.detail.value;
    },
    setSettlement: function(t) {
        this.data.settlement = t.detail.value;
    },
    setPayment: function(t) {
        this.data.payment = t.detail.value;
    },
    ensure: function() {
        var e = t.get(this.data.callback);
        e && e({
            price: this.data.price,
            startPrice: this.data.startPrice,
            demurrage: this.data.demurrage,
            handlingTime: this.data.handlingTime,
            settlement: this.data.settlement,
            payment: this.data.payment
        }), wx.navigateBack();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});