var e = require("../../utils/env"), t = require("../../modules/moment"), n = {
    sandstone: "砂石交易",
    vessel: "船舶买卖",
    recruit: "船员招聘"
}, r = [ {
    name: "monday",
    desc: "每周一自动提升排名"
}, {
    name: "tuesday",
    desc: "每周二自动提升排名"
}, {
    name: "wednesday",
    desc: "每周三自动提升排名"
}, {
    name: "thursday",
    desc: "每周四自动提升排名"
}, {
    name: "friday",
    desc: "每周五自动提升排名"
}, {
    name: "saturday",
    desc: "每周六自动提升排名"
}, {
    name: "sunday",
    desc: "每周日自动提升排名"
}, {
    name: "manual",
    desc: "手动提升排名"
} ], a = [ {
    name: "daily",
    desc: "每天自动提升排名"
}, {
    name: "manual",
    desc: "手动提升排名"
} ], s = e.resource("mp/section_ad_pro_back.jpg"), c = e.resource("mp/section_ad_pro_header.png"), i = e.resource("mp/section_ad_pro_intro.jpg"), o = function(t) {
    return e.mercury("sectionAd/mediaUrl?hash=".concat(t));
}, u = function(t, n, r) {
    return e.mercury("sectionAd/mediaThumbnail?hash=".concat(t, "&thumbnail=").concat(n, "&level=").concat(r));
};

module.exports = {
    sectionText: function(e) {
        return n[e] || e || "";
    },
    proBackUrl: s,
    proHeaderImage: c,
    proIntroImage: i,
    getMediaUrl: o,
    getThumbUrl: u,
    getMediaLines: function(e) {
        var t = [];
        if ((e || []).forEach(function(e, n) {
            n % 3 == 0 && t.push({
                items: []
            }), t[t.length - 1].items.push(Object.assign({}, e, {
                index: n
            }));
        }), t.length > 0) {
            var n = Math.max(2, t[0].items.length), r = 6 / n;
            for (t.forEach(function(e) {
                return e.items.forEach(function(e) {
                    e.isVideo = (e.type || "").toLowerCase().startsWith("video"), e.url = o(e.hash), 
                    e.thumbUrl = u(e.hash, r, n);
                });
            }); t[t.length - 1].items.length < n; ) t[t.length - 1].items.push({
                thumbUrl: "/images/empty-white.png",
                hash: "empty-white" + t[t.length - 1].items.length
            });
            t.forEach(function(e) {
                return e.hash = e.items.reduce(function(e, t) {
                    return e + t.hash;
                }, "");
            });
        }
        return t;
    },
    getElevateTimeDesc: function(e) {
        return e ? t(e).format("YYYY-MM-DD HH:mm") : "";
    },
    getElevateSettingDesc: function(e) {
        var t = r.concat(a).find(function(t) {
            return t.name === e;
        });
        return t && t.desc || "";
    },
    getElevateMinute: function(e) {
        var n = t("2000-01-01 " + e);
        return n.isValid() || (n = t()), n;
    },
    allElevateSettings: r,
    allElevateSettingsPro: a,
    getTimeLeft: function(e) {
        if (e.daysLeft > 1 || void 0 === e.secondsLeft || null === e.secondsLeft) return "".concat(e.daysLeft, "天");
        if (e.secondsLeft > 0) {
            var t = Math.floor(e.secondsLeft / 3600);
            if (t > 0) return "".concat(t, "小时");
            var n = Math.floor(e.secondsLeft / 60);
            return "".concat(n + 1, "分钟");
        }
        return "已过期";
    }
};