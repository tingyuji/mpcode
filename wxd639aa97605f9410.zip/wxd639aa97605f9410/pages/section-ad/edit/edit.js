var t = require("../../../utils/util"), e = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), a = require("../common");

Page({
    fixMedia: function(t) {
        return t.url = a.getMediaUrl(t.hash), t.thumbUrl = a.getThumbUrl(t.hash, 2, 3), 
        t;
    },
    contentChange: function(t) {
        this.data.content = t.detail.value;
    },
    enlarge: function(i) {
        var a = this.data.medias.map(function(t) {
            return t.hash;
        }), n = a.findIndex(function(t) {
            return t === i.hash;
        });
        t.showLoading("获取照片中"), e.mercury.post("sectionAd/getMediaUrls", {
            hashes: a
        }).finally(t.hideLoading).then(function(t) {
            wx.previewImage({
                current: t[n],
                urls: t
            });
        }).catch(function(t) {
            return e.showError("获取照片信息", t);
        });
    },
    confirm: function() {
        var a = this;
        if (!this.data.content && !this.data.medias.length) return t.alert("请先输入文字或上传图片");
        var n = {
            id: this.data.item.id,
            section: this.section,
            content: this.data.content,
            medias: this.data.medias.map(function(t, e) {
                return {
                    hash: t.hash,
                    idx: e + 1
                };
            })
        };
        if (n.id) t.showLoading("保存信息中"), e.mercury.post("sectionAd/edit", n).finally(t.hideLoading).then(function() {
            a.onChange && a.onChange(), wx.navigateBack();
        }).catch(function(t) {
            return e.showError("修改".concat(a.data.sectionText, "信息"), t);
        }); else {
            var o = {
                item: n,
                source: "".concat(this.section, ".edit"),
                onChange: this.onChange
            };
            wx.navigateTo({
                url: "../pay/pay?query=".concat(i.register(o))
            });
        }
    },
    upload: function() {
        var t = this;
        wx.chooseImage({
            count: Math.max(0, 9 - this.data.medias.length),
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var i = e.tempFilePaths;
                i.length > 0 && t.uploadFiles(i);
            }
        });
    },
    uploadFiles: function(i) {
        var a = this;
        this.setData({
            showUploadProgress: !0,
            uploadProgress: 0
        }), t.showLoading("图片上传中"), i = i.slice();
        var n = 0, o = i.length, s = [], h = function() {
            s.length > 0 && (a.setData({
                medias: a.data.medias.concat(s),
                showUploadProgress: !1
            }), t.hideLoading());
        };
        !function r() {
            var c = i.shift();
            if (c) return n++, e.mercury.upload("sectionAd/mediaUpload", c, "image/jpeg", {
                id: a.data.item.id,
                suffix: "jpg"
            }, null, {
                onProgress: function(t) {
                    return a.setData({
                        uploadProgress: (100 * n + t.progress) / o
                    });
                }
            }).then(function(t) {
                s.push(a.fixMedia(t)), r();
            }).catch(function(i) {
                h(), 403 === i.statusCode && "ILLEGAL_IMAGE" === i.data.code ? t.alert("您上传的图片涉及内容违规，请更换图片重新上传") : e.showError("上传图片", i);
            });
            h();
        }();
    },
    touchStart: function(t) {
        var e = this, i = t.currentTarget.dataset.item;
        this.tapHoldTimeout && clearTimeout(this.tapHoldTimeout), this.tapHoldFired = !1, 
        this.startX = t.touches[0].clientX, this.startY = t.touches[0].clientY, this.startTime = new Date().getTime(), 
        this.tapHoldTimeout = setTimeout(function() {
            e.tapHoldTimeout = null, t && t.touches && t.touches.length > 1 || (e.tapHoldFired = !0, 
            e.dragStart(i, t));
        }, 500);
    },
    touchMove: function(t) {
        var e = t.currentTarget.dataset.item;
        if (this.data.dragging) this.dragMove(e, t); else {
            var i = t.changedTouches[0].clientX, a = t.changedTouches[0].clientY;
            Math.abs(i - this.startX) < 6 && Math.abs(a - this.startY) < 6 || this.tapHoldTimeout && (clearTimeout(this.tapHoldTimeout), 
            this.tapHoldTimeout = null);
        }
    },
    touchEnd: function(t) {
        var e = t.currentTarget.dataset.item;
        if (this.data.dragging) this.dragEnd(e, t); else if (this.tapHoldTimeout && (clearTimeout(this.tapHoldTimeout), 
        this.tapHoldTimeout = null), !this.tapHoldFired) {
            var i = t.changedTouches[0].clientX, a = t.changedTouches[0].clientY;
            Math.abs(i - this.startX) < 6 && Math.abs(a - this.startY) < 6 && this.enlarge(e);
        }
    },
    movingTouchEnd: function(t) {
        this.data.dragging && this.dragEnd(this.data.movingItem, t);
    },
    dragStart: function(t, e) {
        var i = this, a = wx.createSelectorQuery();
        this.data.medias.forEach(function(t) {
            return a.select("#image-".concat(t.hash)).boundingClientRect();
        }), a.exec(function(e) {
            i.positions = [], i.data.medias.forEach(function(t, a) {
                var n = e[a], o = {
                    left: n.left - 10,
                    top: n.top - 10,
                    width: n.width + 20,
                    height: n.height + 20
                }, s = {
                    left: n.left - 5,
                    top: n.top - 5,
                    right: n.left + n.width + 5,
                    bottom: n.top + n.height + 5
                };
                i.positions[a] = {
                    item: n,
                    enlarge: o,
                    bound: s
                };
            });
            var a = i.data.medias.findIndex(function(e) {
                return e.hash === t.hash;
            }), n = i.positions[a].enlarge;
            i.startLeft = n.left, i.startTop = n.top;
            var o = "left: ".concat(n.left, "px; top: ").concat(n.top, "px;") + " width: ".concat(n.width, "px; height: ").concat(n.height, "px;"), s = {};
            s[t.hash] = 1, i.setData({
                dragging: !0,
                movingItem: t,
                movingPosition: o,
                transparencies: s,
                trashOpen: !1
            });
        });
    },
    dragMove: function(t, e) {
        var i = this, a = e.changedTouches[0].clientX, n = e.changedTouches[0].clientY, o = a - this.startX, s = n - this.startY, h = this.data.medias.findIndex(function(e) {
            return e.hash === t.hash;
        }), r = this.positions[h].enlarge, c = "left: ".concat(this.startLeft + o, "px; top: ").concat(this.startTop + s, "px;") + " width: ".concat(r.width, "px; height: ").concat(r.height, "px;"), d = this.data.medias.find(function(t, e) {
            var o = i.positions[e].bound;
            return a >= o.left && a < o.right && n >= o.top && n < o.bottom;
        });
        if (d && d.hash !== this.data.movingItem.hash) {
            var u = this.data.medias.slice(), l = u.findIndex(function(t) {
                return t.hash === i.data.movingItem.hash;
            }), g = u.findIndex(function(t) {
                return t.hash === d.hash;
            });
            u.splice(l, 1), u.splice(g, 0, this.data.movingItem), this.setData({
                movingPosition: c,
                medias: u
            });
        } else this.setData({
            movingPosition: c
        });
        wx.createSelectorQuery().select("#fixed-bottom-block").boundingClientRect().exec(function(t) {
            var e = n >= t[0].top;
            !e != !i.data.trashOpen && i.setData({
                trashOpen: e
            });
        });
    },
    dragEnd: function(t, e) {
        var i = this, a = e.changedTouches[0].clientY;
        this.setData({
            dragging: !1,
            movingItem: null,
            transparencies: {},
            trashOpen: !1
        }), wx.createSelectorQuery().select("#fixed-bottom-block").boundingClientRect().exec(function(e) {
            if (a >= e[0].top) {
                var n = i.data.medias.slice(), o = n.findIndex(function(e) {
                    return e.hash === t.hash;
                });
                n.splice(o, 1), i.setData({
                    medias: n
                });
            }
        });
    },
    data: {
        section: null,
        sectionText: "",
        item: {},
        content: "",
        medias: [],
        transparencies: {}
    },
    onLoad: function(t) {
        var n = this, o = t.source;
        this.section = t.section;
        var s = {
            id: t.id
        };
        if (t.query) {
            var h = i.unRegister(t.query);
            o = h.source, s = h.item || s, this.section = s.section || h.section, this.onChange = h.onChange;
        }
        this.setData({
            section: this.section,
            sectionText: a.sectionText(this.section),
            item: s,
            content: s.content || "",
            medias: (s.medias || []).map(function(t) {
                return n.fixMedia(t);
            }),
            confirmText: s.id ? "确认" : "发布"
        }), e.mercury.post("sectionAd/log", {
            action: s.id ? "page_edit" : "page_publish",
            section: this.section,
            id: s.id,
            result: o
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: t.shareToPath("/pages/section-ad/section-ad", {
                section: this.section,
                id: this.data.item.id,
                source: "share"
            })
        };
    }
});