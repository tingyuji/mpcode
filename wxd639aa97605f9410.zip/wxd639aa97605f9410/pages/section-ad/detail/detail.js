var e = require("../../../utils/util"), t = require("../../../utils/user"), i = require("../../../utils/ajax"), n = require("../../../utils/globalMap"), a = require("../../../utils/ad"), s = require("../common"), o = new Array(24).fill(0).map(function(e, t) {
    return ("0" + t).slice(-2);
}), r = new Array(60).fill(0).map(function(e, t) {
    return ("0" + t).slice(-2);
});

Page({
    updateItem: function(e) {
        var t = e.item.proFlag ? s.allElevateSettingsPro : s.allElevateSettings;
        e.timeLeft = s.getTimeLeft(e.item), e.mediaLines = s.getMediaLines(e.item.medias || []), 
        e.contentNodes = a.getContents(e.item.content), e.elevateTime = s.getElevateTimeDesc(e.item.elevateTime), 
        e.elevateSetting = s.getElevateSettingDesc(e.item.elevateSetting, e.item.elevateMinute), 
        e.elevateSettingIndex = t.findIndex(function(t) {
            return t.desc === e.elevateSetting;
        });
        var i = s.getElevateMinute(e.item.elevateMinute);
        e.elevateMinute = i.format("HH:mm"), e.multiIndex = [ "manual" === e.item.elevateSetting ? 1 : 0, i.hours(), i.minutes() ], 
        e.allElevateSettings = t.map(function(e) {
            return e.desc;
        }), this.setData(e);
    },
    refresh: function(e) {
        this.data.userId > 0 && this.load(e);
    },
    load: function(t) {
        var n = this;
        this.changed = !t || this.changed, e.showLoading("获取数据中"), i.mercury.get("sectionAd/loadDetail", {
            id: this.itemId
        }).finally(e.hideLoading).then(function(e) {
            return n.updateItem({
                item: e
            });
        }).catch(function(e) {
            return i.showError("获取信息详情", e);
        });
    },
    recharge: function() {
        var e = this;
        this.deadbeatBlockModal.check(this.section + "_recharge").then(function(t) {
            if (t) {
                var i = {
                    item: e.data.item,
                    source: "".concat(e.section, ".detail"),
                    onChange: function() {
                        return e.refresh(!1);
                    }
                };
                wx.navigateTo({
                    url: "../pay/pay?query=".concat(n.register(i))
                });
            }
        });
    },
    elevateSettingChanged: function(e) {
        var t = (this.data.item.proFlag ? s.allElevateSettingsPro : s.allElevateSettings)[e.detail.value];
        t && t.name !== this.data.item.elevateSetting && this.saveElevateSetting(t.name, this.data.elevateMinute);
    },
    saveElevateSetting: function(t, n) {
        var a = this;
        e.showLoading("正在修改"), i.mercury.post("sectionAd/elevateSetting", {
            id: this.itemId,
            value: t,
            minute: n
        }).finally(e.hideLoading).then(function() {
            return a.refresh(!1);
        }).catch(function(e) {
            return i.showError("修改提升设置", e);
        });
    },
    elevate: function() {
        var e = this;
        if (this.data.item.topFlag && this.data.item.daysLeft > 0) if (this.data.item.elevateLeft > 0) this.doElevate(); else {
            var t = {
                item: this.data.item,
                source: "".concat(this.section, ".detail"),
                isElevate: !0,
                onChange: function() {
                    return e.refresh(!1);
                }
            };
            wx.navigateTo({
                url: "../pay/pay?query=".concat(n.register(t))
            });
        }
    },
    doElevate: function() {
        var t = this;
        this.elevating || (this.elevating = !0, e.confirm("当前排名：".concat(this.data.item.index, "，确认手动提升一次排名吗？")).then(function() {
            e.showLoading("正在提升"), i.mercury.post("sectionAd/elevate", {
                id: t.itemId
            }).finally(function() {
                e.hideLoading(), t.elevating = !1;
            }).then(function() {
                return t.refresh(!1);
            }).catch(function(e) {
                return i.showError("提升排名", e);
            });
        }).catch(function() {
            return t.elevating = !1;
        }));
    },
    enlarge: function(t) {
        var n = t.currentTarget.dataset.image;
        if (n.url) {
            var a = this.data.item.medias.map(function(e) {
                return e.hash;
            }), s = a.findIndex(function(e) {
                return e === n.hash;
            });
            e.showLoading("获取照片中"), i.mercury.post("sectionAd/getMediaUrls", {
                hashes: a
            }).finally(e.hideLoading).then(function(e) {
                wx.previewImage({
                    current: e[s],
                    urls: e
                });
            }).catch(function(e) {
                return i.showError("获取照片信息", e);
            });
        }
    },
    editContent: function() {
        var e = this, t = {
            item: this.data.item,
            source: "".concat(this.section, ".detail"),
            onChange: function() {
                return e.refresh(!1);
            }
        };
        wx.navigateTo({
            url: "../edit/edit?query=".concat(n.register(t))
        });
    },
    remove: function() {
        var t = this, n = this.data.item.daysLeft > 0 ? "您的交易信息正在展示中，现在删除将不退还任何费用，且不可恢复，是否确定删除？" : "删除的交易信息不可恢复，是否确定删除？";
        e.confirm(n).then(function() {
            e.showLoading("正在删除"), i.mercury.post("sectionAd/remove", {
                id: t.itemId
            }).finally(e.hideLoading).then(function() {
                t.changed = !0, wx.navigateBack();
            }).catch(function(e) {
                return i.showError("删除交易信息", e);
            });
        });
    },
    elevateProPickerChange: function(e) {
        var t = e.detail.value[0] ? "manual" : "daily", i = "daily" === t, n = ("0" + e.detail.value[1]).slice(-2) + ":" + ("0" + e.detail.value[2]).slice(-2);
        this.setData({
            elevateSettingDaily: i,
            elevateMinute: n
        }), this.saveElevateSetting(t, n);
    },
    data: {
        section: null,
        sectionText: "",
        item: {},
        mediaLines: [],
        contentNodes: [],
        elevateTime: "",
        elevateSetting: "",
        allElevateSettings: [],
        multiArray: [ [ "每天自动提升排名", "手动提升排名" ], o, r ],
        multiIndex: [ 0, 0, 0 ]
    },
    onLoad: function(a) {
        var o = this;
        e.checkUserLogin(this);
        var r = a.source;
        this.section = a.section, this.itemId = a.id;
        var c = {
            id: this.itemId
        };
        if (a.query) {
            var u = n.unRegister(a.query);
            r = u.source, c = u.item, this.itemId = c.id, this.section = c.section, this.onChange = u.onChange;
        }
        this.updateItem({
            item: c,
            section: this.section,
            sectionText: s.sectionText(this.section)
        }), i.mercury.post("sectionAd/log", {
            action: "page_detail",
            section: this.section,
            id: c.id,
            result: r
        }), this.syncUserId = t.id.subscribeAndFireOnce(function(e) {
            o.setData({
                userId: e
            }), o.refresh(!0);
        });
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        e.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.changed && this.onChange && this.onChange();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: e.shareToPath("/pages/section-ad/section-ad", {
                section: this.section,
                id: this.itemId,
                source: "share"
            })
        };
    }
});