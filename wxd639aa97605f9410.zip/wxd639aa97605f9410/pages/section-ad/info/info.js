var t = require("../../../utils/util"), e = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), n = require("../../../utils/ad"), a = require("../common");

Page({
    enlarge: function(i) {
        var n = i.currentTarget.dataset.image;
        if (n.url) {
            var a = this.data.item.medias.map(function(t) {
                return t.hash;
            }), o = a.findIndex(function(t) {
                return t === n.hash;
            });
            e.mercury.post("sectionAd/log", {
                action: "enlarge_media",
                section: this.section,
                id: this.data.item.id,
                result: o,
                note: {
                    page: "info",
                    rank: this.rank
                }
            }), t.showLoading("获取照片中"), e.mercury.post("sectionAd/getMediaUrls", {
                hashes: a
            }).finally(t.hideLoading).then(function(t) {
                wx.previewImage({
                    current: t[o],
                    urls: t
                });
            }).catch(function(t) {
                return e.showError("获取照片信息", t);
            });
        }
    },
    call: function(t) {
        var i = t.currentTarget.dataset.mobile;
        e.mercury.post("sectionAd/dialPhone", {
            id: this.data.item.id,
            phone: i,
            rank: this.rank
        }), wx.makePhoneCall({
            phoneNumber: i
        });
    },
    contact: function() {
        e.mercury.post("sectionAd/contactPublisher", {
            id: this.data.item.id,
            rank: this.rank
        }).then(function(t) {
            wx.makePhoneCall({
                phoneNumber: t
            });
        }).catch(function(t) {
            return e.showError("获取发布人信息", t);
        });
    },
    publish: function() {
        var t = this, e = {
            section: this.section,
            source: "".concat(this.section, ".info"),
            onChange: function() {
                return t.changed = !0;
            }
        };
        wx.navigateTo({
            url: "../edit/edit?query=".concat(i.register(e))
        });
    },
    updateItem: function(t) {
        t.mediaLines = a.getMediaLines(t.item.medias), t.contentNodes = n.getContents(t.item.content), 
        this.setData(t), this.rank || (this.rank = t.item.index);
    },
    data: {
        section: null,
        sectionText: "",
        item: {},
        mediaLines: [],
        contentNodes: []
    },
    onLoad: function(t) {
        var n = this;
        this.changed = !1;
        var o = t.source;
        this.section = t.section;
        var s = {
            id: t.id,
            section: this.section,
            medias: []
        };
        if (t.query) {
            var c = i.unRegister(t.query);
            o = c.source, s = c.item, this.section = s.section, this.callback = c.callback;
        }
        this.updateItem({
            section: this.section,
            sectionText: a.sectionText(this.section),
            item: s
        }), e.mercury.post("sectionAd/log", {
            action: "page_info",
            section: this.section,
            id: this.data.item.id,
            result: o,
            note: {
                rank: this.rank
            }
        }).then(function() {
            e.mercury.get("sectionAd/load", {
                id: n.data.item.id
            }).then(function(t) {
                t ? n.updateItem({
                    item: t
                }) : wx.redirectTo({
                    url: "../section-ad?section=".concat(n.section, "?source=share")
                });
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.callback && this.callback(this.changed, this.data.item && this.data.item.readCount);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: t.shareToPath("/pages/section-ad/section-ad", {
                section: this.section,
                id: this.data.item.id,
                source: "share"
            })
        };
    }
});