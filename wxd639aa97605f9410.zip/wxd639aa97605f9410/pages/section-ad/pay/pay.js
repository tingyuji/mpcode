var t = require("../../../utils/util"), e = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), n = require("../common");

Page({
    dial400: function() {
        t.dial400();
    },
    updateSelected: function(t) {
        var e = t.selected;
        if (t.selectedId = e && e.id || null, t.selectedVoucher = +(e && e.voucher || 0).toFixed(2), 
        t.action = "", e) {
            var i = e.amount;
            i > 0 ? t.action = "支付".concat(+(i - e.voucher).toFixed(2), "元").concat(e.action) : "recharge" === this.type ? t.action = "发布" : t.action = e.action;
        }
        t.remainDesc = this.getRemainDesc(e), this.setData(t);
    },
    getRemainDesc: function(t) {
        var e = "", i = t && t.remainAmount > 0 ? +t.remainAmount.toFixed(2) : 0;
        if (i > 0) {
            var n = "";
            t.isPro ? n = "将增加诚信交易招牌" : t.isTop && (n = "将置顶发布");
            var a = this.topFlag ? "置顶发布" : "普通发布", o = t.days, r = t.remainDays;
            if (n && o > 0 && r > 0) {
                e = "续费后您的广告".concat(n, "，有效期").concat(o, "天。未使用的").concat(r, "天").concat(a, "费用").concat(i, "元将从续费金额中减免");
                var s = +(i - t.price).toFixed(2);
                s > 0 && (e += "，其中超额的".concat(s, "元将作废"));
            }
        }
        return e;
    },
    select: function(t) {
        this.updateSelected({
            selected: t.currentTarget.dataset.item
        });
    },
    pay: function() {
        var t = this;
        this.data.selected && !this.paying && (e.mercury.post("sectionAd/log", {
            action: "click_pay_".concat(this.type),
            section: this.section,
            id: this.itemId || null,
            result: this.data.selected.id
        }), this.paying = !0, this.data.selected.amount > 0 ? this.doPay().finally(function() {
            return t.paying = !1;
        }) : "recharge" === this.type ? this.freeUpgrade().finally(function() {
            return t.paying = !1;
        }) : this.freePublish().finally(function() {
            return t.paying = !1;
        }));
    },
    payParams: function() {
        return {
            id: this.itemId,
            section: this.section,
            content: this.data.item.content || "",
            medias: (this.data.item.medias || []).map(function(t) {
                return {
                    hash: t.hash,
                    idx: t.idx
                };
            }),
            type: this.type,
            option: this.data.selected.id
        };
    },
    freeUpgrade: function() {
        var e = this, i = this.data.selected;
        if (+(i.remainAmount - i.price).toFixed(2) > 0) {
            var n = this.getRemainDesc(i) + "，是否继续？";
            return t.confirm(n).then(function() {
                return e.freeUpgradeHelper();
            });
        }
        return this.freeUpgradeHelper();
    },
    freeUpgradeHelper: function() {
        var i = this;
        return t.showLoading("发布信息中"), e.mercury.post("sectionAd/freeUpgrade", this.payParams()).finally(t.hideLoading).then(function() {
            i.onChange && i.onChange(), wx.navigateBack();
        }).catch(function(t) {
            return e.showError("发布", t);
        });
    },
    freePublish: function() {
        var i = this;
        return t.showLoading("发布信息中"), e.mercury.post("sectionAd/freePublish", this.payParams()).finally(t.hideLoading).then(function() {
            i.onChange && i.onChange(), wx.navigateBack({
                delta: 2
            });
        }).catch(function(t) {
            return e.showError("VIP免费发布", t);
        });
    },
    doPay: function() {
        var i = this;
        return t.showLoading("准备支付中"), e.mercury.post("sectionAd/payInfo", this.payParams()).finally(t.hideLoading).then(function(e) {
            var n = e.payInfo;
            return new Promise(function(t, e) {
                wx.requestPayment({
                    timeStamp: n.timeStamp.toString(),
                    nonceStr: n.nonceStr,
                    package: n.package,
                    signType: n.signType,
                    paySign: n.paySign,
                    success: t,
                    fail: e
                });
            }).then(function() {
                return i.onPayDone(e.orderId);
            }).catch(function(e) {
                var i = e.errMsg.indexOf("fail"), n = e.errMsg.slice(i + 4).trim();
                "cancel" !== n && t.alert("付款失败，" + n);
            });
        }).catch(function(t) {
            return e.showError("获取支付信息", t);
        });
    },
    onPayDone: function(i) {
        var n = this;
        return t.showLoading("获取结果中"), e.mercury.get("sectionAd/payStatus", {
            orderId: i
        }).finally(t.hideLoading).then(function(t) {
            if ("USED" === t || "BOUGHT" === t) switch (e.mercury.post("sectionAd/log", {
                action: "pay_".concat(n.type, "_done"),
                section: n.section,
                id: n.data.item.id,
                result: n.data.selected.id,
                note: {
                    orderId: i
                }
            }), n.onChange && n.onChange(), n.type) {
              case "elevate":
                wx.navigateBack();
                break;

              case "publish":
                wx.navigateBack({
                    delta: 2
                });
                break;

              case "recharge":
                wx.navigateBack();
            }
        }).catch(function(t) {
            return e.showError("获取支付结果", t);
        });
    },
    data: {
        isIOS: t.isIOS(),
        section: null,
        sectionText: "",
        item: {},
        options: [],
        selected: null,
        warmWarnings: [],
        selectedVoucher: 0,
        action: "",
        remainDesc: ""
    },
    onLoad: function(a) {
        var o = this, r = a.source;
        this.section = a.section, this.itemId = a.id;
        var s = {
            id: this.itemId
        };
        if (this.isElevate = !1, a.query) {
            var c = i.unRegister(a.query);
            r = c.source, s = c.item, this.itemId = s.id, this.section = s.section, this.topFlag = !!s.topFlag, 
            this.proFlag = !!s.proFlag, this.onChange = c.onChange, this.isElevate = !!c.isElevate;
        }
        this.type = this.isElevate ? "elevate" : this.itemId ? "recharge" : "publish", this.setData({
            item: s,
            section: this.section,
            sectionText: n.sectionText(this.section)
        }), e.mercury.post("sectionAd/log", {
            action: "page_pay_".concat(this.type),
            section: this.section,
            id: this.itemId || null,
            result: r
        }), t.showLoading("获取信息中"), e.mercury.get("sectionAd/rules", {
            type: "pay",
            subType: this.type,
            section: this.section
        }).then(function(t) {
            return o.setData({
                warmWarnings: t
            });
        }), e.mercury.get("sectionAd/payOptions", {
            id: this.itemId,
            section: this.section,
            type: this.type
        }).finally(t.hideLoading).then(function(e) {
            if (e.length <= 0) t.alert("获取付费信息失败：参数错误").then(wx.navigateBack); else {
                o.data.isIOS && (e = e.filter(function(t) {
                    return !t.price;
                })), e.forEach(function(t) {
                    t.isPro = !!t.isPro, t.proIntroImage = n.proIntroImage;
                    var e = t.desc || "";
                    for (t.descParts = []; e.length > 0; ) {
                        var i = e.match(/\((.*?)\)/);
                        if (!i) {
                            t.descParts.push({
                                type: "normal",
                                content: e
                            });
                            break;
                        }
                        i.index > 0 ? (t.descParts.push({
                            type: "normal",
                            content: e.slice(0, i.index)
                        }), e = e.slice(i.index)) : (t.descParts.push({
                            type: "strong",
                            content: i[1]
                        }), e = e.slice(i[0].length));
                    }
                });
                var i = e[0];
                "recharge" === o.type && (o.data.item.topFlag ? o.data.item.proFlag || (i = e.filter(function(t) {
                    return !t.isPro;
                })[0] || i) : i = e.filter(function(t) {
                    return !t.isTop;
                })[0] || i), o.updateSelected({
                    options: e,
                    selected: i
                });
            }
        }).catch(function(t) {
            return e.showError("获取付费信息", t).then(wx.navigateBack);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: t.shareToPath("/pages/section-ad/section-ad", {
                section: this.section,
                id: this.itemId,
                source: "share"
            })
        };
    }
});