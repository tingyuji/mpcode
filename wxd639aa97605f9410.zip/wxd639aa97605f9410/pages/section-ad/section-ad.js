require("../../utils/env");

var t = require("../../utils/user"), e = require("../../utils/util"), i = require("../../utils/ajax"), n = require("../../utils/globalMap"), o = require("./common");

Page({
    refresh: function() {
        wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        }), this.load(0);
    },
    load: function(t) {
        var n = this;
        return this.loading = !0, e.showLoading("获取数据中"), t || i.mercury.get("sectionAd/freeCount", {
            section: this.section
        }).then(function(t) {
            return n.setData({
                freeCount: t
            });
        }), i.mercury.get("sectionAd/list", {
            section: this.section,
            page: t
        }).finally(function() {
            e.hideLoading(), n.loading = !1;
        }).then(function(e) {
            var i = e.length < 8;
            if (t > 0) {
                var o = new Set();
                e.forEach(function(t) {
                    var i = n.data.items.findIndex(function(e) {
                        return e.id === t.id;
                    });
                    i >= 0 && (e.splice(i, 1, t), o.add(t.id));
                }), e = n.data.items.concat(e.filter(function(t) {
                    return !o.has(t.id);
                }));
            }
            n.fixItems(e), n.setData({
                searchEnd: i,
                items: e,
                loaded: !0
            }), n.itemsPage = t + 1;
        }).catch(function(t) {
            return i.showError("获取交易版块数据", t);
        });
    },
    fixItems: function(t) {
        t.forEach(function(t) {
            for (t.proStyle = t.proFlag ? "background-image: url(".concat(o.proBackUrl, ")") : "", 
            t.proHeaderImage = o.proHeaderImage, t.images = t.medias.slice(0, 3), t.images.forEach(function(t) {
                t.thumbUrl = o.getThumbUrl(t.hash, 2, 3), t.url = o.getMediaUrl(t.hash);
            }); t.images.length > 0 && t.images.length < 3; ) t.images.push({
                hash: t.images.length.toString(),
                thumbUrl: "/images/empty-white.png"
            });
        });
    },
    viewDetail: function(t) {
        var e = t.currentTarget.dataset.item;
        this.toInfo(e);
    },
    toInfo: function(t) {
        var e = this, i = {
            item: t,
            source: "".concat(this.section, ".list"),
            callback: function(i, n) {
                if (i) e.refresh(); else if (null != n) {
                    var o = e.data.items.slice(), a = o.find(function(e) {
                        return e.id === t.id;
                    });
                    a && (a.readCount = n, e.setData({
                        items: o
                    }));
                }
            }
        };
        wx.navigateTo({
            url: "./info/info?query=".concat(n.register(i))
        });
    },
    enlarge: function(t) {
        var n = t.currentTarget.dataset.item, o = t.currentTarget.dataset.image;
        if (o.url) {
            var a = n.medias.map(function(t) {
                return t.hash;
            }), s = a.findIndex(function(t) {
                return t === o.hash;
            });
            i.mercury.post("sectionAd/log", {
                action: "enlarge_media",
                section: this.section,
                id: n.id,
                result: s,
                note: {
                    page: "list",
                    rank: n.index
                }
            }), e.showLoading("获取照片中"), i.mercury.post("sectionAd/getMediaUrls", {
                hashes: a
            }).finally(e.hideLoading).then(function(t) {
                wx.previewImage({
                    current: t[s],
                    urls: t
                });
            }).catch(function(t) {
                return i.showError("获取照片信息", t);
            });
        }
    },
    manage: function() {
        var e = this;
        if (t.id.get() > 0) {
            var i = {
                section: this.section,
                source: "".concat(this.section, ".list"),
                onChange: function() {
                    return e.refresh();
                }
            };
            wx.navigateTo({
                url: "./manage/manage?query=".concat(n.register(i))
            });
        } else this.login();
    },
    publish: function() {
        var e = this;
        t.id.get() > 0 ? this.deadbeatBlockModal.check(this.section + "_publish").then(function(t) {
            if (t) {
                var i = {
                    section: e.section,
                    source: "".concat(e.section, ".list"),
                    onChange: function() {
                        return e.refresh();
                    }
                };
                wx.navigateTo({
                    url: "./edit/edit?query=".concat(n.register(i))
                });
            }
        }) : this.login();
    },
    login: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    data: {
        section: null,
        sectionText: "",
        freeCount: 0,
        items: [],
        pullDown: !1,
        loaded: !1
    },
    onLoad: function(t) {
        var e = this;
        this.itemsPage = 0, this.section = t.section, this.setData({
            section: this.section,
            sectionText: o.sectionText(this.section)
        }), i.mercury.post("sectionAd/log", {
            action: "page_list",
            section: this.section,
            result: t.source
        }), this.refresh(), t.id && i.mercury.get("sectionAd/load", {
            id: t.id
        }).then(function(t) {
            t && e.toInfo(t);
        });
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var t = this;
        this.setData({
            pullDown: !0
        }), this.load(0).finally(function() {
            wx.stopPullDownRefresh(), t.setData({
                pullDown: !1
            });
        });
    },
    onReachBottom: function() {
        this.data.searchEnd || this.loading || this.load(this.itemsPage);
    },
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: e.sharePath({
                section: this.section,
                source: "share"
            })
        };
    }
});