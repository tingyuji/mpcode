require("../../../utils/env");

var e = require("../../../utils/util"), t = require("../../../utils/user"), n = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), s = require("../common");

Page({
    refresh: function(e) {
        this.data.userId > 0 ? this.load(e) : this.setData({
            loaded: !1,
            freeCount: 0,
            items: []
        });
    },
    load: function(t) {
        var i = this;
        this.changed = !t || this.changed, e.showLoading("获取数据中"), n.mercury.get("sectionAd/freeCount", {
            section: this.section
        }).then(function(e) {
            return i.setData({
                freeCount: e
            });
        }), n.mercury.get("sectionAd/rules", {
            type: "publish",
            section: this.section
        }).then(function(e) {
            return i.setData({
                rules: e
            });
        }), n.mercury.get("sectionAd/mine", {
            section: this.section
        }).finally(e.hideLoading).then(function(e) {
            e.forEach(function(e) {
                for (e.index = e.index || "", e.proStyle = e.proFlag ? "background-image: url(".concat(s.proBackUrl, ")") : "", 
                e.proHeaderImage = s.proHeaderImage, e.timeLeft = s.getTimeLeft(e), e.images = e.medias.slice(0, 3), 
                e.images.forEach(function(e) {
                    e.thumbUrl = s.getThumbUrl(e.hash, 2, 3), e.url = s.getMediaUrl(e.hash);
                }); e.images.length > 0 && e.images.length < 3; ) e.images.push({
                    hash: e.images.length.toString(),
                    thumbUrl: "/images/empty-white.png"
                });
            }), i.setData({
                items: e,
                loaded: !0
            });
        }).catch(function(e) {
            return n.showError("获取我的交易信息", e);
        });
    },
    viewDetail: function(e) {
        var t = this, n = {
            item: e.currentTarget.dataset.item,
            source: "".concat(this.section, ".manage"),
            onChange: function() {
                return t.refresh(!1);
            }
        };
        wx.navigateTo({
            url: "../detail/detail?query=".concat(i.register(n))
        });
    },
    enlarge: function(t) {
        var i = t.currentTarget.dataset.item, s = t.currentTarget.dataset.image;
        if (s.url) {
            var r = i.medias.map(function(e) {
                return e.hash;
            }), a = r.findIndex(function(e) {
                return e === s.hash;
            });
            e.showLoading("获取照片中"), n.mercury.post("sectionAd/getMediaUrls", {
                hashes: r
            }).finally(e.hideLoading).then(function(e) {
                wx.previewImage({
                    current: e[a],
                    urls: e
                });
            }).catch(function(e) {
                return n.showError("获取照片信息", e);
            });
        }
    },
    publish: function() {
        var e = this;
        this.deadbeatBlockModal.check(this.section + "_manage_publish").then(function(t) {
            if (t) {
                var n = {
                    section: e.section,
                    source: "".concat(e.section, ".manage"),
                    onChange: function() {
                        return e.refresh(!1);
                    }
                };
                wx.navigateTo({
                    url: "../edit/edit?query=".concat(i.register(n))
                });
            }
        });
    },
    data: {
        loaded: !1,
        freeCount: 0,
        items: [],
        rules: []
    },
    onLoad: function(r) {
        var a = this;
        e.checkUserLogin(this);
        var o = r.source;
        if (this.section = r.section, r.query) {
            var c = i.unRegister(r.query);
            o = c.source, this.section = c.section, this.onChange = c.onChange;
        }
        this.setData({
            section: this.section,
            sectionText: s.sectionText(this.section)
        }), n.mercury.post("sectionAd/log", {
            action: "page_manage",
            section: this.section,
            result: o
        }), this.syncUserId = t.id.subscribeAndFireOnce(function(e) {
            a.setData({
                userId: e
            }), a.refresh();
        });
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        e.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.changed && this.onChange && this.onChange();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.sectionText + "中心",
            path: e.sharePath({
                section: this.section,
                source: "share"
            })
        };
    }
});