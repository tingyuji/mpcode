var t = require("../../utils/util"), a = require("../../utils/globalMap"), e = require("../../utils/ajax");

Page({
    data: {
        url: ""
    },
    onLoad: function(t) {
        this.url = t.url, this.callback = a.unRegister(t.callback), this.setData({
            url: decodeURIComponent(this.url)
        }), e.mercury.post("ad/browseUrl", {
            url: this.data.url
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: this.callback ? "/pages/index/index?".concat(t.shareParam()) : t.sharePath({
                url: this.url
            })
        };
    }
});