var t = require("../../utils/util"), e = require("../../utils/ajax"), n = require("../../modules/moment");

Page({
    dial: function() {
        e.mercury.post("mapps/log", {
            action: "fuel_dial_phone",
            target: this.data.phoneNumber
        }), wx.makePhoneCall({
            phoneNumber: this.data.phoneNumber
        });
    },
    getTimeDesc: function(t) {
        return n(t).startOf("day") === n().startOf("day") ? "今天 " + n(t).format("HH:mm") : n(t).format("MM-DD HH:mm");
    },
    data: {
        phoneNumber: "18505116067",
        contactName: "吴",
        content: "",
        contentTime: ""
    },
    onLoad: function(t) {
        var n = this;
        e.mercury.get("utils/fuelPrice").then(function(t) {
            n.setData({
                content: t && t.content ? t.content.replace(/ /g, "&nbsp;") : "",
                contentTime: n.getTimeDesc(t && t.time)
            });
        }).catch(function(t) {
            return e.showError("获取报价信息", t);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});