var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../utils/ad"), a = require("../../utils/ajax"), i = require("../../utils/env"), r = require("../../modules/moment"), s = require("../../utils/user"), n = require("../../utils/util"), o = require("../../utils/globalMap"), h = require("../../dao/ship"), c = require("../../dao/shipAjax"), d = require("../../dao/vessel"), l = require("../../dao/searchShortcuts"), u = require("../../modules/spark-md5"), g = require("../used-vessel/common"), m = require("../../dao/sailorExamCompanies"), p = getApp(), f = function() {};

Page({
    data: {
        userId: 0,
        userAvatar: null,
        palletItems: [],
        originItems: [],
        guessItems: [],
        orderedItems: [],
        orderedItemsExpand: !1,
        start: "",
        target: "",
        startPorts: [],
        targetPorts: [],
        minWeight: null,
        maxWeight: null,
        weightsLine1: "",
        weightsLine2: "",
        noCondition: !0,
        editingCondition: !1,
        startPage: 0,
        startGuess: 0,
        loading: !1,
        tabs: [ "搜索货源", "免费发布空船" ],
        activeIndex: 0,
        sliderOffset: 0,
        myShip: null,
        maskShipCount: 0,
        myPallets: [],
        searchNone: !1,
        searchEnd: !1,
        guessEnd: !1,
        loadNone: !1,
        lastSearchTime: null,
        pullDown: !1,
        top: !1,
        scrollTops: [],
        windowHeight: p.globalData.systemInfo.windowHeight,
        help: "/pages/web-view/webView?url=".concat(encodeURIComponent(i.resource("app-help/how-to-search-pallet.html"))),
        shortBargeAlert: !1,
        recommendTargets: [],
        shortBargeAlertHeight: 50,
        changeWeightAlert: 0,
        changeWeightAlertHeight: 50,
        changeWeightText: "",
        isVipSearch: !1,
        haveMore: !1
    },
    scrollTop: function() {
        this.setData({
            top: !0
        });
    },
    confirmSearch: function(t) {
        this.conditionChange({
            startPorts: t.detail.startPorts || [],
            targetPorts: t.detail.targetPorts || [],
            minWeight: t.detail.minWeight || null,
            maxWeight: t.detail.maxWeight || null
        });
    },
    closeShortBargeAlert: function() {
        this.setData({
            shortBargeAlert: !1
        });
    },
    editTarget: function(t) {
        var e = this, i = {
            callback: function(i) {
                t && a.mercury.post("search/recommendTargetLog", {
                    action: "recommend_target.edit",
                    target: i.map(function(t) {
                        return t.id;
                    }).join()
                }), e.targetPortsChange(i);
            },
            ports: JSON.parse(JSON.stringify(this.data.targetPorts)),
            type: "palletTarget",
            title: "请选择您要找的货源的",
            titleHighlight: "卸货港",
            placeholder: "建议您将沿线愿意去的目的港都选上"
        };
        wx.navigateTo({
            url: "/pages/multi-ports-selector/multiPortsSelector?query=".concat(o.register(i))
        });
    },
    targetPortsChange: function(t) {
        this.conditionChange({
            startPorts: this.data.startPorts,
            targetPorts: t || [],
            minWeight: this.data.minWeight,
            maxWeight: this.data.maxWeight
        });
    },
    chooseTarget: function(t) {
        var e = t.detail;
        e ? (a.mercury.post("search/recommendTargetLog", {
            action: "recommend_target.add",
            target: e.id
        }), this.targetPortsChange(this.data.targetPorts.concat(e))) : this.editTarget(!0);
    },
    refreshItem: function(t, e, a) {
        if (0 == this.data.activeIndex) {
            for (var r = this.data.originItems, s = 0; s < r.length; s++) {
                var n = r[s];
                if (n.objectType === t && n.id === e) {
                    n.user.name = a.username, n.enterprise.store || n.tag.official || a.avatar && (n.user.avatar = a.avatar, 
                    n.user.avatarUrl = i.mercury("files/avatar/".concat(a.avatar)));
                    break;
                }
            }
            this.setData({
                originItems: this.data.originItems,
                palletItems: this.data.palletItems
            });
        } else if (1 == this.data.activeIndex) {
            for (var o = this.data.myPallets, h = 0; h < o.length; h++) {
                var c = o[h];
                if (c.objectType === t && c.id === e) {
                    c.user.name = a.username, c.enterprise.store || c.tag.official || a.avatar && (c.user.avatar = a.avatar, 
                    c.user.avatarUrl = i.mercury("files/avatar/".concat(a.avatar)));
                    break;
                }
            }
            this.setData({
                myPallets: o
            });
        }
    },
    remove: function() {
        var t = h.get();
        t.id ? n.confirm("是否删除空船？").then(function() {
            n.showLoading("删除空船中"), a.mercury.post("ships/remove", {
                id: t.id
            }).finally(n.hideLoading).then(h.refresh).catch(function(t) {
                return a.showError("删除空船", t);
            });
        }).catch(f) : (n.alert("空船不存在"), h.refresh());
    },
    tabClick: function(t) {
        var e = t.currentTarget.id || 0, a = this.data.scrollTops[e] || 0;
        this.setData({
            sliderOffset: t.currentTarget.offsetLeft,
            activeIndex: t.currentTarget.id
        }), wx.pageScrollTo({
            scrollTop: a,
            duration: 0
        });
    },
    switchTab: function(t) {
        "1" == t ? this.setData({
            sliderOffset: 188,
            activeIndex: "1"
        }) : "0" == t && this.setData({
            sliderOffset: 0,
            activeIndex: "0"
        });
    },
    setCondition: function(t) {
        var e = {};
        e[t.currentTarget.dataset.condition] = t.detail.value, this.setData(e);
    },
    fixedItems: function(t, e) {
        var a = this, i = {};
        return e.forEach(function(t) {
            return i[t.objectType] = Math.max(i[t.objectType] || 0, Number.isFinite(t.adIndex) ? t.adIndex + 1 : 0);
        }), t.map(function(t) {
            return a._formatPalletItem(t, i);
        });
    },
    _formatPalletItem: function(t, a) {
        if (a = a || {}, t.adType = "ship" === t.objectType || "pallet" === t.objectType ? "" : t.objectType, 
        t.adIndex = a[t.objectType] || 0, a[t.objectType] = (a[t.objectType] || 0) + 1, 
        t.hash = t.objectType + t.id + t.adIndex, t.adType) if ("ad" === t.adType) {
            t.contents = e.getContents(t.content);
            var r = t.photo;
            r && r.name ? t.avatarUrl = i.mercury("files/load-ad-image?name=".concat(encodeURIComponent(r.name), "&width=60&height=60")) : t.avatarUrl = i.resource("mp/ad-avatar.png");
        } else "section_ad" === t.adType ? t.index = t.adIndex : "used_vessel" === t.adType ? g.fixItem(t) : "sailor_exam" === t.adType && (t.company = m.get()[Math.max(0, (t.id || 0) - 1)]); else t.pallet = t.id = Number.isFinite(t.pallet) ? t.pallet : t.id, 
        t.isGreat = t.great && !t.great.pause, t.isGreat ? t.user.avatarUrl = "/images/great-pallet-avatar.jpg" : t.tag.official ? t.tag.media.length > 0 && (t.user.avatarUrl = i.mercury("files/media/".concat(t.tag.media[0].hash, "?thumbnail=1"))) : t.enterprise.store && (t.tag.media.length > 0 && (t.user.avatarUrl = i.mercury("store/media/".concat(t.tag.media[0].file, "?thumbnail=1"))), 
        t.tag.authCompany = !0, t.user.organization = t.enterprise.fullName), t.user.avatarUrl || (t.user.newAvatar ? t.user.avatarUrl = t.user.newAvatar : t.user.avatarUrl = "/images/avatar-none.png");
        return t;
    },
    _refactorPalletItems: function(t) {
        var e = t.filter(function(t) {
            return !t.adType && t.tag && t.tag.official;
        }), a = t.filter(function(t) {
            return t.adType || !(t.tag && t.tag.official);
        });
        return (e.length > 0 ? [ {
            hash: u.hash(e.map(function(t) {
                return t.hash;
            }).join()),
            objectType: "official",
            items: e
        } ] : []).concat(a);
    },
    showLoading: function() {
        wx.showLoading({
            title: "正在加载..."
        }), this.setData({
            loading: !0
        });
    },
    hideLoading: function() {
        this.setData({
            loading: !1
        }), wx.hideLoading();
    },
    search: function(t) {
        var e = this;
        t = t || f;
        var a = this.data;
        wx.setStorage({
            key: "zhaohuo.lastTime",
            data: new Date().getTime()
        }), wx.setStorage({
            key: "zhaohuo.startPorts",
            data: a.startPorts
        }), wx.setStorage({
            key: "zhaohuo.targetPorts",
            data: a.targetPorts
        }), wx.setStorage({
            key: "zhaohuo.minWeight",
            data: a.minWeight || null
        }), wx.setStorage({
            key: "zhaohuo.maxWeight",
            data: a.maxWeight || null
        }), a.startPorts.length || a.targetPorts.length || a.minWeight || a.maxWeight ? (this.showLoading(), 
        (a.searchEnd ? this.guessLike(a, 0) : this.doSearch(a)).finally(function() {
            e.hideLoading(), t();
        })) : t();
    },
    doSearch: function(t) {
        var e = this, i = !t.startPage;
        i && this.setData({
            changeWeightAlert: 0
        });
        var r = {
            startPorts: t.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: t.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: t.minWeight,
            maxWeight: t.maxWeight
        };
        this.searchParamsJson = JSON.stringify(r);
        var s = Object.assign({}, r, {
            start: t.startPage,
            limit: 15,
            vesselWeight: d.get() && d.get().deadweightTonnage || 0
        });
        return a.mercury.post("search/palletsWithAdV4", s).then(function(a) {
            if (void 0 !== a.minWeight && a.minWeight !== e.data.minWeight || void 0 !== a.maxWeight && a.maxWeight !== e.data.maxWeight) {
                var r = e.data.minWeight || e.data.maxWeight ? 2 : 3, s = "";
                a.minWeight && a.maxWeight ? s = a.minWeight + "~" + a.maxWeight + "吨" : a.minWeight ? s = a.minWeight + "吨以上" : a.maxWeight ? s = a.maxWeight + "吨以下" : r = 1, 
                e.setData({
                    changeWeightAlert: r,
                    changeWeightText: s
                });
                var n = setInterval(function() {
                    wx.createSelectorQuery().in(e).select("#change-weight-alert").boundingClientRect().exec(function(t) {
                        e.data.changeWeightAlert ? t && t[0] && Number.isFinite(t[0].height) && t[0].height > 0 && (e.setData({
                            changeWeightAlertHeight: Math.max(25, t[0].height)
                        }), clearInterval(n)) : clearInterval(n);
                    });
                }, 100);
            } else e.setData({
                changeWeightAlert: 0
            });
            var o = e.fixedItems(a.items, t.originItems), h = o.filter(function(t) {
                return !t.adType;
            }).length, c = t.startPage + h, d = t.originItems.concat(o), l = !d.find(function(t) {
                return !t.adType;
            }), u = c >= a.exist, g = e._refactorPalletItems(d);
            if (e.patchShowIndices(g), e.setData({
                startPage: c,
                palletItems: g,
                originItems: d,
                searchNone: l,
                searchEnd: u,
                lastSearchTime: new Date(),
                isVipSearch: a.vip,
                haveMore: a.more
            }), u) return e.loadOrdered().then(function() {
                return e.guessLike(e.data, h, i);
            });
            e.checkVipAlert(u);
        });
    },
    checkVipAlert: function(t) {
        var e = this;
        if (!t && this.lastSearchParamsJson !== this.searchParamsJson && !this.data.isVipSearch) if (s.id.get() > 0) {
            n.confirm("您当前不是VIP用户，每次搜索最多只能查看150个货源，升级为VIP用户可查看更多", {
                cancelText: "暂不升级",
                confirmText: "升级VIP"
            }).then(function() {
                return e.toVip("alert-dialog");
            }).catch(function() {});
        } else {
            n.confirm("未登录用户每次搜索最多只能查看150个货源", {
                cancelText: "暂不登录",
                confirmText: "去登录"
            }).then(function() {
                return e.toLogin("alert-dialog");
            }).catch(function() {});
        }
        this.lastSearchParamsJson = this.searchParamsJson;
    },
    patchShowIndices: function(e, a) {
        var i, r = 0, s = t(e);
        try {
            for (s.s(); !(i = s.n()).done; ) {
                var n = i.value;
                switch (n.objectType) {
                  case "pallet":
                    n.showIndex = r++;
                    break;

                  case "official":
                  case "enterprise":
                    var o, h = t(n.items);
                    try {
                        for (h.s(); !(o = h.n()).done; ) {
                            var c = o.value;
                            c.adType || (c.showIndex = r++);
                        }
                    } catch (t) {
                        h.e(t);
                    } finally {
                        h.f();
                    }
                }
            }
        } catch (t) {
            s.e(t);
        } finally {
            s.f();
        }
        if (Array.isArray(a)) {
            var d, l = t(a);
            try {
                for (l.s(); !(d = l.n()).done; ) {
                    var u = d.value;
                    u.adType || (u.showIndex = r++);
                }
            } catch (t) {
                l.e(t);
            } finally {
                l.f();
            }
        }
    },
    loadOrdered: function() {
        var t = this;
        return a.mercury.post("search/orderedPallets", {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: this.data.minWeight,
            maxWeight: this.data.maxWeight
        }).then(function(e) {
            e.forEach(function(t) {
                return t.objectType = "pallet";
            }), e = e.map(function(e) {
                return t._formatPalletItem(e);
            }), t.setData({
                orderedItems: e
            });
        });
    },
    shrinkOrderedItems: function() {
        this.setData({
            orderedItemsExpand: !1
        });
    },
    expandOrderedItems: function() {
        this.setData({
            orderedItemsExpand: !0
        });
    },
    guessLike: function(t, e, i) {
        var r = this, s = 15 - e, n = 0, o = 0;
        return t.originItems.forEach(function(t) {
            t.adType ? n = 0 : (n++, o++);
        }), a.mercury.post("search/guessLikePallets", {
            startPorts: t.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: t.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: t.minWeight,
            maxWeight: t.maxWeight,
            start: t.startGuess,
            limit: s,
            vesselWeight: d.get() && d.get().deadweightTonnage || 0,
            version: "v4",
            startCursor: n,
            itemCount: o
        }).then(function(e) {
            var a = r.fixedItems(e.items, t.originItems.concat(t.guessItems)), s = t.startGuess + a.filter(function(t) {
                return !t.adType;
            }).length, n = t.guessItems.concat(a);
            n.filter(function(t) {
                return !t.adType;
            }).forEach(function(t, e) {
                return t.guessIndex = e;
            }), r.patchShowIndices(t.palletItems, n), r.setData({
                startGuess: s,
                guessItems: n,
                guessEnd: s >= e.exist,
                isVipSearch: e.vip,
                haveMore: e.more
            }), i && r.checkVipAlert(r.data.guessEnd);
        });
    },
    conditionChange: function(t) {
        this.updateSearchBar(Object.assign({}, t, {
            startPage: 0,
            startGuess: 0,
            palletItems: [],
            originItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchEnd: !1,
            guessEnd: !1,
            searchNone: !1,
            startPorts: t.startPorts,
            targetPorts: t.targetPorts,
            minWeight: t.minWeight,
            maxWeight: t.maxWeight,
            isVipSearch: !1,
            haveMore: !1
        })), this.search();
    },
    toEditCondition: function(t) {
        var e = "zhaohuo." + ("string" == typeof t ? t : "search-bottom");
        a.mercury.post("mapps/log", {
            action: "user-click",
            target: "edit-condition",
            result: e
        }), this.editCondition();
    },
    toVip: function(t) {
        var e = "zhaohuo." + ("string" == typeof t ? t : "search-bottom");
        a.mercury.post("mapps/log", {
            action: "user-click",
            target: "to-vip",
            result: e
        }), wx.navigateTo({
            url: "/pages/settings/vip-ship/vip-ship?source=search"
        });
    },
    toLogin: function(t) {
        var e = "zhaohuo." + ("string" == typeof t ? t : "search-bottom");
        a.mercury.post("mapps/log", {
            action: "user-click",
            target: "to-login",
            result: e
        }), wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile?source=search"
        });
    },
    editCondition: function() {
        this.setData({
            editingCondition: !0
        }), this.updateEditingCondition();
    },
    updateAvatar: function(t) {
        var e = "/images/avatar-none.png", a = s.avatar.get();
        a && (e = i.mercury("files/avatar/".concat(a)));
        var r = d.get();
        r && r.photo && !r.photo.expired && (e = i.mercury("vessels/photo?file=".concat(r.photo.file, "&thumbnail=1"))), 
        this.setData(Object.assign({}, t, {
            avatarUrl: e
        }));
    },
    onLoad: function(t) {
        var e = this;
        "promotion" === t.source && a.mercury.post("utils/promotionToMp", {
            action: "zhao_huo",
            openid: p.globalData.userData.openid
        });
        var i = p.globalData.systemInfo;
        this.setData({
            sliderOffset: i.windowWidth / this.data.tabs.length * this.data.activeIndex,
            windowHeight: i.windowHeight
        }), this.syncUserId = s.id.subscribeAndFireOnce(function(t) {
            return e.setData({
                userId: t
            });
        }), this.syncVessel = d.subscribeAndFireOnce(function(t) {
            return e.updateAvatar({
                vesselName: t && t.name
            });
        }), this.syncShip = h.subscribeAndFireOnce(function(t) {
            e.setData({
                myShip: t
            }), e._loadLinkPallets();
        }), this.syncMaskShipCount = h.maskShipCount.subscribeAndFireOnce(function(t) {
            return e.setData({
                maskShipCount: t
            });
        });
        var r = +wx.getStorageSync("zhaohuo.lastTime") || 0, n = [], o = [], c = null, l = null;
        if ((!r || new Date().getTime() - r < 2592e5) && (n = wx.getStorageSync("zhaohuo.startPorts"), 
        Array.isArray(n) && "string" == typeof n[0] && (n = n.map(function(t) {
            return {
                id: t,
                title: t
            };
        })), o = wx.getStorageSync("zhaohuo.targetPorts"), Array.isArray(o) && "string" == typeof o[0] && (o = o.map(function(t) {
            return {
                id: t,
                title: t
            };
        })), c = parseInt(wx.getStorageSync("zhaohuo.minWeight")), l = parseInt(wx.getStorageSync("zhaohuo.maxWeight"))), 
        t.cacheQuery) {
            if (n = [], t.startPorts) {
                var u = (t.startPorts || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                }), g = (t.startPortTitles || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                });
                n = u.map(function(t, e) {
                    return {
                        id: t,
                        title: g[e] || t
                    };
                });
            }
            if (o = [], t.targetPorts) {
                var m = (t.targetPorts || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                }), f = (t.targetPortTitles || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                });
                o = m.map(function(t, e) {
                    return {
                        id: t,
                        title: f[e] || t
                    };
                });
            }
            c = parseInt(t.minWeight), l = parseInt(t.maxWeight);
        }
        var v = {
            startPorts: n || [],
            targetPorts: o || []
        };
        Number.isFinite(c) && (v = Object.assign(v, {
            minWeight: c
        })), Number.isFinite(l) && (v = Object.assign(v, {
            maxWeight: l
        })), t.searchPort && (v.startPorts = [ {
            id: t.searchPort,
            title: t.searchPortTitle || t.searchPort
        } ], v.targetPorts = [], v.minWeight = null, v.maxWeight = null), this.updateSearchBar(v), 
        this.search(), t.tab && this.switchTab(+t.tab || 0);
    },
    updateSearchBar: function(t) {
        var e = this;
        t.start = t.startPorts.length > 0 ? t.startPorts[0].title + (t.startPorts.length > 1 ? "等" : "") : "不限", 
        t.target = t.targetPorts.length > 0 ? t.targetPorts[0].title + (t.targetPorts.length > 1 ? "等" : "") : "不限", 
        t.weightsLine1 = t.minWeight && t.maxWeight ? "".concat(t.minWeight, " ~") : t.minWeight ? "".concat(t.minWeight, "吨") : t.maxWeight ? "".concat(t.maxWeight, "吨") : "", 
        t.weightsLine2 = t.minWeight && t.maxWeight ? "".concat(t.maxWeight, "吨") : t.minWeight ? "以上" : t.maxWeight ? "以下" : "", 
        t.noCondition = !t.startPorts.length && !t.targetPorts.length, t.editingCondition = t.noCondition, 
        this.setData(t), this.updateEditingCondition(), a.mercury.post("search/shortBarge", {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            })
        }).then(function(t) {
            e.setData({
                shortBargeAlert: t
            });
            var a = setInterval(function() {
                wx.createSelectorQuery().in(e).select("#short-barge-alert").boundingClientRect().exec(function(t) {
                    e.data.shortBargeAlert ? t && t[0] && Number.isFinite(t[0].height) && t[0].height > 0 && (e.setData({
                        shortBargeAlertHeight: Math.max(50, t[0].height)
                    }), clearInterval(a)) : clearInterval(a);
                });
            }, 100);
        }).catch(function(t) {
            return console.error(t);
        }), d.get() && a.mercury.post("search/recommendTargetPorts", {
            vessel: d.get().id,
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            })
        }).then(function(t) {
            e.setData({
                recommendTargets: (t || []).slice(0, 5).map(function(t) {
                    return {
                        id: t,
                        title: t
                    };
                })
            });
        }).catch(function(t) {
            return console.error(t);
        });
    },
    updateEditingCondition: function() {
        if (this.data.editingCondition || this.data.noCondition) {
            var t = this.selectComponent("#chuan-search-condition");
            t && t.init(this.data.startPorts, this.data.targetPorts, this.data.minWeight, this.data.maxWeight);
        }
    },
    _loadLinkPallets: function() {
        var t = this, e = this.data.myShip;
        return e ? a.mercury.get("ships/load-links-with-ad?ship=".concat(e.id, "&shipVersion=0&update=true&version=v4")).then(function(i) {
            var r = t.fixedItems(i.items, []), s = !r.find(function(t) {
                return !t.adType;
            }), n = t._refactorPalletItems(r);
            t.setData({
                myPallets: n,
                loadNone: s
            });
            var o = i.items.filter(function(t) {
                return "ad" === t.objectType;
            }).map(function(t) {
                return t.id;
            });
            return o.length > 0 && a.mercury.post("pallets/shown-ad", {
                ads: o,
                start: e.startPortId,
                target: e.aimPortId
            }), n;
        }) : (this.setData({
            myPallets: [],
            loadNone: !1
        }), Promise.resolve([]));
    },
    onReady: function() {
        this.updateEditingCondition(), this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        (this.data.top && (this.setData({
            top: !1
        }), wx.pageScrollTo({
            scrollTop: 0
        })), this.data.loading && this.showLoading(), this.data.lastSearchTime) && (r().diff(r(this.data.lastSearchTime), "minutes") >= 15 && (this.setData({
            startPage: 0,
            startGuess: 0,
            palletItems: [],
            originItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchEnd: !1,
            guessEnd: !1,
            searchNone: !1,
            isVipSearch: !1,
            haveMore: !1
        }), this.search()));
        h.refresh().catch(function(t) {
            return a.showError("获取空船信息", t);
        }), this.refreshMaskInterval = setInterval(h.refreshMask, 6e4);
    },
    onHide: function() {
        this.refreshMaskInterval && (clearInterval(this.refreshMaskInterval), this.refreshMaskInterval = null);
    },
    onUnload: function() {
        this.syncUserId.dispose(), this.syncShip.dispose(), this.syncVessel.dispose(), this.syncMaskShipCount.dispose(), 
        this.targetPortsCallbackId && (o.unRegister(this.targetPortsCallbackId), this.targetPortsCallbackId = null);
    },
    refresh: function() {
        var t = this;
        return this.showLoading(), this._loadLinkPallets.then(function() {
            return t.hideLoading();
        });
    },
    activateShip: function(t) {
        var e = this;
        this.deadbeatBlockModal.check("ship_activate").then(function(i) {
            i && (n.showLoading("获取数据中"), c.canPublish(function(e, i) {
                if (i) {
                    var r = t.currentTarget.dataset.ship;
                    a.mercury.post("ships/activate", {
                        id: r
                    }).finally(n.hideLoading).then(function() {
                        return wx.navigateTo({
                            url: "/pages/edit-ship/edit-ship?id=" + r
                        });
                    });
                } else n.authShipCreateModal(), n.hideLoading();
            }.bind(e)));
        });
    },
    _login: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    editShip: function(t) {
        var e = this;
        s.id.get() ? this.deadbeatBlockModal.check("ship_publish").then(function(a) {
            a && (n.showLoading("加载页面中"), c.canPublish(function(a, i) {
                if (n.hideLoading(), i) {
                    var r = t.currentTarget.dataset.ship;
                    0 == e.data.activeIndex && e.switchTab(1), wx.navigateTo({
                        url: "/pages/edit-ship/edit-ship?id=" + r
                    });
                } else n.authShipCreateModal();
            }));
        }) : this._login();
    },
    onPullDownRefresh: function() {
        var t = this;
        0 == this.data.activeIndex ? this.data.editingCondition || this.data.noCondition ? l.ship.refresh().then(function() {
            return wx.stopPullDownRefresh();
        }) : (this.setData({
            startPage: 0,
            startGuess: 0,
            palletItems: [],
            originItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchEnd: !1,
            guessEnd: !1,
            searchNone: !1,
            pullDown: !0,
            isVipSearch: !1,
            haveMore: !1
        }), this.search(function() {
            wx.stopPullDownRefresh(), t.setData({
                pullDown: !1
            });
        })) : 1 == this.data.activeIndex && (this.shipDao.refreshMask(), this._loadLinkPallets.then(function() {
            return wx.stopPullDownRefresh();
        }));
    },
    onReachBottom: function() {
        0 != this.data.activeIndex || this.data.guessEnd || this.data.editingCondition || this.data.noCondition || this.search();
    },
    onPageScroll: function(t) {
        var e = this.data.activeIndex || 0;
        this.data.scrollTops[e] = t.scrollTop;
    },
    onShareAppMessage: function() {
        var t = {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }).join(),
            startPortTitles: this.data.startPorts.map(function(t) {
                return t.title;
            }).join(),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            }).join(),
            targetPortTitles: this.data.targetPorts.map(function(t) {
                return t.title;
            }).join(),
            cacheQuery: !0
        };
        return this.data.minWeight && (t = Object.assign(t, {
            minWeight: this.data.minWeight
        })), this.data.maxWeight && (t = Object.assign(t, {
            maxWeight: this.data.maxWeight
        })), {
            title: n.shareTitle,
            path: n.shareTabPath("zhaohuo", t)
        };
    },
    toHelp: function() {
        a.mercury.post("mapps/log", {
            action: "help-search-ship"
        });
    }
});