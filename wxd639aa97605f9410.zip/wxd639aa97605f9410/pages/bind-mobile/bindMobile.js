var e = require("../../utils/user"), t = require("../../utils/util"), a = require("../../utils/ajax"), n = require("../../modules/spark-md5"), o = getApp();

Page({
    data: {
        mobile: "",
        validMobile: !1,
        resend: !1,
        code: "",
        validCode: !1,
        countDown: 0,
        captchaImage: "",
        vsig: "",
        md5: "",
        captcha: "",
        token: "",
        genders: [ "", "男", "女" ],
        genderValues: [ "", "male", "female" ],
        genderIndex: 0,
        name: ""
    },
    onLoad: function(e) {
        this.setData({
            otherMobile: this.otherMobile = !!e.other
        }), this.otherMobile && this.refreshCaptcha();
    },
    onReady: function() {
        this.newUserModal = this.selectComponent("#newUserModal"), this.securityWarningModal = this.selectComponent("#securityWarning");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    mobileChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), a = /^1\d{10}$/.test(t);
        this.setData({
            mobile: t,
            validMobile: a
        });
    },
    codeChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), a = /^\d{6}$/.test(t);
        this.setData({
            code: t,
            validCode: a
        });
    },
    sendCode: function() {
        var e = this;
        this.data.validMobile && !this.data.countDown && a.mercury.post("miniProgram/sendCode", {
            mobile: this.data.mobile,
            vsig: this.data.vsig,
            captcha: this.data.captcha
        }).then(function() {
            e.setData({
                countDown: 60,
                resend: !0
            });
            var t = setInterval(function() {
                e.data.countDown > 0 ? e.setData({
                    countDown: --e.data.countDown
                }) : clearInterval(t);
            }, 1e3);
        }).catch(function(t) {
            412 === t.statusCode && (e.refreshCaptcha(), e.setData({
                captchaVerified: !1
            })), a.showError("发送短信验证码", t);
        });
    },
    getPhoneNumber: function(e) {
        var t = this;
        e.detail.code && a.mercury.post("miniProgram/bindWeixinMobile", {
            code: e.detail.code,
            openid: o.globalData.userData.openid
        }).then(function(e) {
            return t.bindDone(e);
        }).catch(function(e) {
            return t.onBindError(e);
        });
    },
    doBind: function() {
        var e = this;
        a.mercury.post("miniProgram/bindMobile", {
            mobile: this.data.mobile,
            openid: o.globalData.userData.openid,
            code: this.data.code
        }).then(function(t) {
            return e.bindDone(t);
        }).catch(function(t) {
            return e.onBindError(t);
        });
    },
    onBindError: function(e) {
        return e && (404 === e.statusCode || 401 === e.statusCode || 403 === e.statusCode) && e.data && e.data.code ? this.doSecurityWarning(e.data.code, e.data.mobile) : a.showError("绑定微信手机号", e);
    },
    bindDone: function(t) {
        this.setData({
            token: t.token
        }), t.isNew ? (this.newUserModal.show(), a.setToken(t.token), e.refresh().catch(function() {})) : this.refreshUser(t.token);
    },
    refreshUser: function(t) {
        var n = this;
        a.setToken(t), e.refresh().then(function() {
            return n.done();
        }).catch(function(e) {
            return a.showError("获取用户数据", e);
        });
    },
    refreshCaptcha: function() {
        var e = this;
        a.mercury.get("miniProgram/captchaImageData?ts=".concat(new Date().getTime())).then(function(t) {
            e.setData({
                captchaImage: "data:" + t.mime + ";base64," + t.data,
                vsig: t.vsig,
                md5: t.md5
            });
        });
    },
    captchaChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, "");
        n.hash(t) === this.data.md5 && (this.setData({
            captcha: t,
            captchaVerified: !0
        }), wx.showToast({
            title: "图形码验证成功",
            icon: "success",
            duration: 1e3
        }), this.data.mobile && this.data.validMobile && this.sendCode());
    },
    done: function() {
        wx.navigateBack({
            delta: this.otherMobile ? 2 : 1
        });
    },
    genderChange: function(e) {
        this.setData({
            genderIndex: e.detail.value
        });
    },
    nameChange: function(e) {
        this.setData({
            name: e.detail.value
        });
    },
    confirmUserProfile: function() {
        var e = this;
        this.data.name ? this.data.genderIndex <= 0 ? t.alert("请选择您的性别") : a.mercury.post("miniProgram/completeProfile", {
            openid: o.globalData.userData.openid,
            name: this.data.name,
            gender: this.data.genderValues[this.data.genderIndex]
        }).then(function() {
            e.newUserModal.hide(), e.refreshUser(e.data.token);
        }).catch(function(e) {
            return a.showError("完善用户资料", e);
        }) : t.alert("请输入您的姓名");
    },
    backToHome: function() {
        var e = (getCurrentPages() || []).map(function(e) {
            return e.route || "";
        }).reverse().findIndex(function(e) {
            return e.startsWith("pages/home/home");
        });
        e >= 0 ? wx.navigateBack({
            delta: e
        }) : wx.reLaunch({
            url: "/pages/home/home"
        });
    },
    doSecurityWarning: function(e, a) {
        var n = this;
        if ("MULTI_LOGIN" === e) o.globalData.backingHome = !0, o.globalData.cheatMobile = a, 
        o.globalData.cheatMobileEvent.set(o.globalData.cheatMobileEvent.get() + 1), this.backToHome(); else {
            var i, r, s;
            switch (e) {
              case "CHEAT_DANGER":
                i = "系统监测到您的账号可能被其他人盗用，为了您的信息安全，请重新绑定手机号。如果是您将账号借给其他人使用，请通知对方停止使用您的账号，否则您的账号可能被封号", 
                r = "重新绑定手机号", s = function() {};
                break;

              case "CHEAT_FREEZE":
              default:
                i = "系统监测到您的账号多次被其他人盗用，为保护账号安全，已将当前账号封号，请向管理员申诉找回账号", r = "联系客服", s = function() {
                    t.dial400(), n.backToHome();
                };
            }
            this.securityWarningModal.doModal(i, r).then(s);
        }
    }
});