var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../utils/util"), a = require("../../utils/env"), r = require("../../utils/ajax"), n = require("../../modules/moment"), i = require("../../modules/spark-md5"), o = require("../../utils/globalMap"), c = require("../../utils/user");

Page({
    tabClick: function(t) {
        var e = t.currentTarget.id;
        r.mercury.post("search/logRecentContact", {
            action: "recent_contact.switch_tab",
            target: e
        }), this.setData({
            passiveTab: "passive" === e,
            sliderOffset: t.currentTarget.offsetLeft
        }), this.updateTabItems();
    },
    updateTabItems: function() {
        this.setData({
            tabItems: this.data.passiveTab ? this.data.passiveItems : this.data.initiativeItems
        });
    },
    formatDate: function(t) {
        var e = n(t);
        return e.startOf("day").valueOf() === n().startOf("day").valueOf() ? "今天" : e.format("M月D日");
    },
    formatViewTime: function(t) {
        var e = n().startOf("day").diff(n(new Date(t)).startOf("day"), "days");
        if (e > 0) return 1 === e ? "昨天" : "".concat(e, "天前");
        var a = (new Date().getTime() - new Date(t).getTime()) / 1e3;
        if (a < 60) return "刚刚";
        var r = Math.floor(a / 60);
        if (r < 60) return "".concat(r, "分钟前");
        var i = Math.floor(r / 60);
        return "".concat(i, "小时前");
    },
    dial: function(t) {
        var a = this, n = t.currentTarget.dataset.item;
        if (r.mercury.post("search/logRecentContact", {
            action: "recent_contact.dial",
            target: n.mobile,
            result: n.targetUser.name
        }), n.needVip) {
            var i = "pallet" === n.viewType ? "货主" : "船主";
            e.confirm("此功能仅对".concat(i, "VIP用户开放，请开通").concat(i, "VIP"), {
                cancelText: "暂不开通",
                confirmText: "立即开通"
            }).then(function() {
                return a.toVip(n.viewType);
            }).catch(function() {});
        } else wx.makePhoneCall({
            phoneNumber: n.mobile
        });
    },
    toVip: function(t) {
        r.mercury.post("search/logRecentContact", {
            action: "recent_contact.to_vip",
            target: t
        }), r.mercury.post("vip/log", {
            action: "vip_user_click",
            target: "recent_contact_to_vip_".concat(t)
        }), wx.navigateTo({
            url: "/pages/settings/vip-".concat(t, "/vip-").concat(t)
        });
    },
    load: function() {
        var t = this;
        e.showLoading("获取数据中"), r.mercury.get("search/recentContacts").finally(e.hideLoading).then(function(e) {
            (e = e.filter(function(t) {
                return !(t.passive && !t.vesselName);
            })).forEach(function(e) {
                var a = "".concat(e.viewType, "_").concat(e.id), r = t.itemMap[a], n = function(t) {
                    return void 0 === t ? null : t;
                };
                e.targetUser.name = e.targetUser.name || "", e.vesselCertified = e.vesselCertified || !1, 
                e.originDate = e.date, e.date = e.date ? t.formatDate(e.date) : null, e.viewTime = t.formatViewTime(e.viewTime), 
                e.needVip = e.mobile.indexOf("*") >= 0, e.jianghuPositionCount = n(r && r.jianghuPositionCount), 
                e.familiarRelationCount = n(r && r.familiarRelationCount), e.historyPalletCount = n(r && r.historyPalletCount), 
                e.hash = i.hash(JSON.stringify(e)), t.itemMap[a] = e;
            }), t.setData({
                initiativeItems: e.filter(function(t) {
                    return !t.passive;
                }),
                passiveItems: e.filter(function(t) {
                    return t.passive;
                })
            }), t.updateTabItems(), t.updateSharpEyes(e.filter(function(t) {
                return (t.passive ? 1 : 0) ^ ("pallet" === t.viewType ? 1 : 0);
            }));
        }).catch(function(t) {
            return r.showError("获取数据");
        });
    },
    updateItem: function(t, e) {
        var a = {}, r = this.data.initiativeItems.findIndex(function(e) {
            return e.viewType === t.viewType && e.id === t.id;
        });
        r >= 0 && (a["initiativeItems[".concat(r, "].").concat(e)] = t[e], this.data.passiveTab || (a["tabItems[".concat(r, "].").concat(e)] = t[e])), 
        (r = this.data.passiveItems.findIndex(function(e) {
            return e.viewType === t.viewType && e.id === t.id;
        })) >= 0 && (a["passiveItems[".concat(r, "].").concat(e)] = t[e], this.data.passiveTab && (a["tabItems[".concat(r, "].").concat(e)] = t[e])), 
        this.setData(a);
    },
    updateSharpEyes: function(e) {
        var a, n = this, i = t(e);
        try {
            var o = function() {
                var t = a.value, e = ("".concat(t.viewType, ":").concat(t.id), {
                    pallet: "pallet" === t.viewType ? t.id : null,
                    target: "pallet" !== t.viewType ? t.targetUser.id : null,
                    pageInit: !1
                });
                r.mercury.get("markings/summary", e).then(function(e) {
                    t.jianghuPositionCount = (e || {}).total || 0, n.updateItem(t, "jianghuPositionCount");
                }).catch(function(t) {
                    return console.error(t);
                }), r.mercury.get("pallets/familiar", e).then(function(e) {
                    t.familiarRelationCount = ((e || {}).relations || []).length, n.updateItem(t, "familiarRelationCount");
                }).catch(function(t) {
                    return console.error(t);
                }), r.mercury.get("pallets/history", e).then(function(e) {
                    t.historyPalletCount = (e || []).length, n.updateItem(t, "historyPalletCount");
                }).catch(function(t) {
                    return console.error(t);
                });
            };
            for (i.s(); !(a = i.n()).done; ) o();
        } catch (t) {
            i.e(t);
        } finally {
            i.f();
        }
    },
    addFriend: function(t) {
        var e = t.currentTarget.dataset.item, a = e.mobile, n = e.targetUser.name, i = o.register(function() {
            r.mercury.post("search/logRecentContact", {
                action: "recent_contact.add_friend",
                target: a,
                result: n
            });
        });
        r.mercury.post("search/logRecentContact", {
            action: "recent_contact.to_add_friend",
            target: a,
            result: n
        }), wx.navigateTo({
            url: "/pages/friend-circle/add-friend/add-friend?mobile=".concat(a, "&name=").concat(n, "&callback=").concat(i)
        });
    },
    addBaddie: function(t) {
        var e = t.currentTarget.dataset.item, a = e.mobile, n = e.targetUser.name, i = o.register(function() {
            r.mercury.post("search/logRecentContact", {
                action: "recent_contact.add_baddie",
                target: a,
                result: n
            });
        });
        r.mercury.post("search/logRecentContact", {
            action: "recent_contact.to_add_baddie",
            target: a,
            result: n
        }), wx.navigateTo({
            url: "/pages/friend-circle/add-baddie/add-baddie?mobile=".concat(a, "&name=").concat(n, "&callback=").concat(i)
        });
    },
    createContract: function(t) {
        var e = t.currentTarget.dataset.item, a = null;
        if (!e.longTerm && !e.loadOnArrived) {
            var i = n(e.originDate);
            i.isValid() && (a = i.format("M月D日"));
        }
        var c = {
            userType: "carrier",
            senderName: e.targetUser && e.targetUser.name || null,
            senderMobile: e.mobile,
            cargoName: e.name,
            cargoWeight: e.cargo,
            startPort: e.start,
            targetPort: e.target,
            freight: e.price || null,
            startFee: e.startPrice || null,
            settlement: e.settlement || null,
            loadDate: a,
            handlingTime: e.handlingTime || null,
            demurrage: e.demurrage || null
        };
        /^\d+$/.test(c.cargoWeight) && (c.cargoWeight += "吨"), r.mercury.post("contractHelper/log", {
            action: "contract_helper.create_by_pallet",
            target: e.id,
            result: e.version
        }), wx.redirectTo({
            url: "/pages/contract-helper/edit/edit?item=" + o.register(c)
        });
    },
    getPalletQuery: function(t) {
        var e = function(t, e) {
            return t.enterprise.store && (t.tag.authCompany = !0), t.user.avatarUrl = "/images/avatar-none.png", 
            t.user.avatar && (t.user.avatarUrl = a.mercury("files/avatar/".concat(t.user.avatar))), 
            t.user.newAvatar && (t.user.avatarUrl = t.user.newAvatar), t.isGreat = t.great && !t.great.pause, 
            t.isGreat && (t.user.avatarUrl = "/images/great-pallet-avatar.jpg"), o.register(Object.assign({
                state: {}
            }, t, e));
        };
        return "pallet" === t.viewType ? r.mercury.get("pallets/detail", {
            pallet: t.id,
            origin: 0,
            mark: 0
        }).then(function(a) {
            return e(a, {
                id: t.id
            });
        }) : r.mercury.get("markings/targetProfile", {
            target: t.targetUser.id
        }).then(function(a) {
            return e(a, {
                id: null,
                targetUser: t.targetUser.id
            });
        });
    },
    jianghuPosition: function(t) {
        var e = t.currentTarget.dataset.item;
        this.getPalletQuery(e).then(function(t) {
            return wx.navigateTo({
                url: "../pallet-detail/jianghu-position/jianghu-position?query=".concat(t)
            });
        }).catch(function(t) {
            return console.error(t);
        });
    },
    familiarRelations: function(t) {
        var e = t.currentTarget.dataset.item;
        this.getPalletQuery(e).then(function(t) {
            return wx.navigateTo({
                url: "../pallet-detail/familiar-relations/familiar-relations?query=".concat(t)
            });
        }).catch(function(t) {
            return console.error(t);
        });
    },
    historyPallets: function(t) {
        var e = t.currentTarget.dataset.item;
        this.getPalletQuery(e).then(function(t) {
            return wx.navigateTo({
                url: "../pallet-detail/history-pallets/history-pallets?query=".concat(t)
            });
        }).catch(function(t) {
            return console.error(t);
        });
    },
    data: {
        passiveTab: !1,
        sliderOffset: 0,
        initiativeItems: [],
        passiveItems: []
    },
    onLoad: function(t) {
        var a = this;
        this.itemMap = {}, e.checkUserLogin(this), this.syncUserId = c.id.subscribeAndFireOnce(function(t) {
            return a.setData({
                userId: t
            });
        }), c.id.get() && (t && "contract" === t.mode && r.mercury.post("contractHelper/log", {
            action: "contract_helper.fast_create"
        }), r.mercury.post("search/logRecentContact", {
            action: "recent_contact.enter_page"
        }), this.load());
    },
    onReady: function() {},
    onShow: function() {
        var t = this.notFirstShow;
        e.checkUserShow(this), t && c.id.get() && this.load();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    }
});