var e = require("../../utils/user"), n = require("../../utils/util"), t = (require("../../utils/ajax"), 
require("../../dao/relation")), i = require("../../dao/recentContact"), s = require("../../dao/unseenServices");

Page({
    data: {
        userId: 0,
        newFriends: 0,
        newContacts: 0
    },
    onLoad: function(n) {
        var o = this;
        this.syncUserId = e.id.subscribeAndFireOnce(function(e) {
            return o.setData({
                userId: e
            });
        }), this.syncRecentContact = i.pendingCount.subscribeAndFireOnce(function(e) {
            return o.setData({
                newContacts: e
            });
        }), this.syncRelation = t.subscribeAndFireOnce(function(e) {
            e && this.setData({
                newFriends: e.friendReceived.length
            });
        }.bind(this)), this.syncUnseen = s.subscribeAndFireOnce(function(e) {
            var n = {};
            Object.getOwnPropertyNames(o.data).filter(function(e) {
                return e.startsWith("unseen_");
            }).forEach(function(e) {
                return n[e] = !1;
            }), e.forEach(function(e) {
                return n["unseen_".concat(e)] = !0;
            }), o.setData(n);
        });
    },
    onReady: function() {},
    onShow: function() {
        t.refresh(), i.pendingCount.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncRecentContact.dispose(), this.syncRelation.dispose(), 
        this.syncUnseen.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareTabPath("services")
        };
    },
    bindMobile: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    toContractHelper: function() {
        e.id().get() > 0 ? (s.see("contractHelper"), wx.navigateTo({
            url: "/pages/contract-helper/contract-helper"
        })) : this.bindMobile();
    },
    toFuel: function() {
        s.see("fuel"), wx.navigateTo({
            url: "/pages/fuel/fuel"
        });
    },
    toRecentContact: function() {
        e.id().get() > 0 ? (s.see("recentContact"), wx.navigateTo({
            url: "/pages/recent-contact/recent-contact"
        })) : this.bindMobile();
    },
    toPublishAd: function() {
        e.id().get() > 0 ? (s.see("publishAd"), wx.navigateTo({
            url: "/pages/publish-ad/publishAd?source=services"
        })) : this.bindMobile();
    },
    toFriendCircle: function() {
        e.id().get() > 0 ? (s.see("friendCircle"), wx.navigateTo({
            url: "/pages/friend-circle/friend-circle"
        })) : this.bindMobile();
    },
    toAntiFakePhoto: function() {
        s.see("antiFakePhoto"), wx.navigateTo({
            url: "/pages/anti-fake-photo/anti-fake-photo"
        });
    }
});