var e = require("../../utils/env"), t = require("../../dao/pallet"), n = require("../../utils/ajax");

Page({
    toMyPallet: function() {},
    data: {
        greatPalletDemoImgUrl: e.resource("mp/great-pallet-demo.jpg"),
        toUpgradeCount: 1
    },
    onLoad: function(e) {
        var o = this;
        this.syncPallets = t.pallets.subscribeAndFireOnce(function(e) {
            return o.setData({
                toUpgradeCount: e.filter(function(e) {
                    return !e.great;
                }).length
            });
        }), t.pallets.refresh(), n.mercury.post("greatPallet/log", {
            action: "page.intro",
            result: e.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncPallets.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});