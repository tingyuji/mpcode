var e = require("../../../dao/cash"), t = require("../../../utils/ajax"), a = require("../../../utils/util"), n = require("../../../utils/globalMap"), r = require("../../../utils/greatPallet");

Page({
    charge: function(e) {
        var a = this, n = +e.currentTarget.dataset.amount;
        this.data.busy || (t.mercury.post("cash/log", {
            action: "charge-click",
            target: "great-pallet",
            result: n
        }), this.setData({
            busy: !0
        }), this.doPay(n).finally(function() {
            return a.setData({
                busy: !1
            });
        }));
    },
    doPay: function(e) {
        var n = this;
        return a.showLoading("获取数据中"), t.mercury.post("cash/charge", {
            amount: e,
            source: "great-pallet"
        }).finally(a.hideLoading).then(function(t) {
            var a = t && t.payInfo;
            if (a) return n.wxPay(a, t.orderId, e);
        }).catch(function(e) {
            return t.showError("获取支付信息", e);
        });
    },
    wxPay: function(e, t, n) {
        var r = this;
        return new Promise(function(s) {
            wx.requestPayment({
                timeStamp: e.timeStamp.toString(),
                nonceStr: e.nonceStr,
                package: e.package,
                signType: e.signType,
                paySign: e.paySign,
                success: function(e) {
                    r.onPayDone(t, n).then(s);
                },
                fail: function(e) {
                    var t = e.errMsg.indexOf("fail"), n = e.errMsg.slice(t + 4).trim();
                    "cancel" !== n && a.alert("付款失败，" + n), s();
                }
            });
        });
    },
    onPayDone: function(n, s) {
        var i = this;
        return a.showLoading("获取结果中"), t.mercury.get("cash/chargeStatus", {
            orderId: n
        }).finally(a.hideLoading).then(function(a) {
            "USED" !== a && "BOUGHT" !== a || (t.mercury.post("cash/log", {
                action: "charge-done",
                target: "great-pallet",
                result: s
            }), i.pallet ? r.upgradePallet(i.pallet, !0, i.selectComponent("#upgrade-done")) : e.refresh());
        }).catch(function(e) {
            return t.showError("获取支付结果", e);
        });
    },
    data: {
        isNewUser: !0,
        busy: !1,
        cash: 0,
        cashText: "0.00"
    },
    onLoad: function(a) {
        var r = this;
        this.syncCash = e.subscribeAndFireOnce(function(e) {
            return r.setData({
                cash: e,
                cashText: e.toFixed(2)
            });
        }), this.setData({
            isNewUser: !0 === a.isNewUser || "true" === a.isNewUser || !!parseInt(a.isNewUser)
        }), this.pallet = n.unRegister(a.pallet), this.callback = n.unRegister(a.callback), 
        t.mercury.post("greatPallet/log", {
            action: "page.upgrade",
            target: this.pallet && this.pallet.id || null,
            result: a.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncCash.dispose(), this.callback && this.callback();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});