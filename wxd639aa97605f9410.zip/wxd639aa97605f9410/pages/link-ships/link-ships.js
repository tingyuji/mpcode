var e = require("../../utils/ad"), t = require("../../utils/ajax.js"), a = require("../../utils/env"), i = require("../../utils/globalMap"), n = require("../../dao/pallet.js"), o = require("../../utils/util"), s = require("../used-vessel/common"), r = require("../../dao/sailorExamCompanies"), l = function() {};

Page({
    data: {
        id: null,
        version: null,
        start: null,
        target: null,
        loading: !1,
        loadNone: !1,
        shipItems: []
    },
    refreshItem: function(e, t, a) {
        for (var i = this.data.shipItems, n = 0; n < i.length; n++) {
            var o = i[n];
            if (o.objectType === e && o.id === t) {
                o.user.name = a.username;
                break;
            }
        }
        this.setData({
            shipItems: this.data.shipItems
        });
    },
    fixedItems: function(e, t) {
        var a = this, i = {};
        return t.forEach(function(e) {
            return i[e.objectType] = Math.max(i[e.objectType] || 0, Number.isFinite(e.adIndex) ? e.adIndex + 1 : 0);
        }), e.map(function(e) {
            return a._formatShipItem(e, i);
        });
    },
    _formatShipItem: function(t, i) {
        if (i = i || {}, t.adType = "ship" === t.objectType || "pallet" === t.objectType ? "" : t.objectType, 
        t.adIndex = i[t.objectType] || 0, i[t.objectType] = (i[t.objectType] || 0) + 1, 
        t.hash = t.objectType + t.id + t.adIndex, t.adType) if ("ad" === t.adType) {
            t.contents = e.getContents(t.content);
            var n = t.photo;
            n && n.name ? t.avatarUrl = a.mercury("files/load-ad-image?name=".concat(encodeURIComponent(n.name), "&width=60&height=60")) : t.avatarUrl = a.resource("mp/ad-avatar.png");
        } else "section_ad" === t.adType ? t.index = t.adIndex : "used_vessel" === t.adType ? s.fixItem(t) : "sailor_exam" === t.adType && (t.company = r.get()[Math.max(0, (t.id || 0) - 1)]); else {
            t.ship = t.id = Number.isFinite(t.ship) ? t.ship : t.id;
            var l = t.tag.photo;
            l && l.file ? (l.timeText = o.getTimeText(l.time), t.user.avatarUrl = a.mercury("vessels/photo?file=".concat(l.file, "&thumbnail=1"))) : t.user.avatarUrl = "/images/photo-empty.png";
        }
        return t;
    },
    editPallet: function(e) {
        o.showLoading("加载页面中"), n.canPublish(function(t, a) {
            var n = this;
            if (o.hideLoading(), a) {
                var s = e.currentTarget.dataset.pallet;
                wx.navigateTo({
                    url: "/pages/edit-pallet/edit-pallet?id=".concat(s, "&callback=").concat(i.register(function() {
                        return n.load();
                    }))
                });
            } else o.authPalletCreateModal();
        }.bind(this));
    },
    load: function() {
        this._load();
    },
    _load: function(e) {
        e = e || l, wx.showLoading({
            title: "正在加载..."
        }), this.setData({
            loading: !0
        }), t.mercury.get("pallets/load-links-with-ad?pallet=".concat(this.data.id, "&palletVersion=0&update=true&version=v4")).then(function(a) {
            var i = this.fixedItems(a.items, []), n = !i.find(function(e) {
                return !e.adType;
            });
            this.setData({
                shipItems: i,
                loadNone: n
            });
            var o = a.items.filter(function(e) {
                return "ad" === e.objectType;
            }).map(function(e) {
                return e.id;
            });
            o.length > 0 && t.mercury.post("pallets/shown-ad", {
                ads: o,
                start: this.data.start,
                target: this.data.target
            }), e();
        }.bind(this)).finally(function() {
            wx.hideLoading(), this.setData({
                loading: !1
            });
        }.bind(this));
    },
    onLoad: function(e) {
        this.setData({
            id: e.id,
            version: e.version,
            start: e.start,
            target: e.target
        }), this._load();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this._load(function() {
            wx.stopPullDownRefresh();
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: o.shareTitle,
            path: o.shareTabPath("zhaochuan")
        };
    }
});