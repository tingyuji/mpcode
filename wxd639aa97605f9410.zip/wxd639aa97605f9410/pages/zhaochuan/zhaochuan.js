var t = require("../../utils/ad"), e = require("../../utils/ajax"), a = require("../../utils/env"), i = require("../../modules/moment"), r = require("../../dao/pallet"), n = require("../../dao/cash"), s = require("../../dao/enterprise"), o = require("../../utils/user"), h = require("../../utils/util"), c = require("../../dao/searchShortcuts"), l = require("../../utils/globalMap"), u = require("../used-vessel/common"), d = require("../../utils/greatPallet"), g = require("../../dao/sailorExamCompanies"), m = getApp(), p = function() {};

Page({
    data: {
        userId: 0,
        shipItems: [],
        guessItems: [],
        orderedItems: [],
        orderedItemsExpand: !1,
        hotPorts: [],
        start: "",
        target: "",
        startPorts: [],
        targetPorts: [],
        minWeight: null,
        maxWeight: null,
        weightsLine1: "",
        weightsLine2: "",
        noCondition: !0,
        editingCondition: !1,
        startPage: 0,
        startGuess: 0,
        loading: !1,
        tabs: [ "搜索空船", "免费发布货源" ],
        activeIndex: 0,
        sliderOffset: 0,
        myPallets: [],
        maskPalletCount: 0,
        searchNone: !1,
        searchEnd: !1,
        guessEnd: !1,
        banner: "",
        lastSearchTime: null,
        pullDown: !1,
        top: !1,
        scrollTops: [],
        windowHeight: m.globalData.systemInfo.windowHeight,
        help: "/pages/web-view/webView?url=".concat(encodeURIComponent(a.resource("app-help/how-to-search-ship.html"))),
        shortBargeAlert: !1,
        shortBargeAlertHeight: 50,
        changeWeightAlert: !1,
        changeWeightAlertHeight: 50,
        changeWeightText: "",
        myPalletsAlert: "",
        greatPalletLeftDesc: "",
        isVipSearch: !1,
        haveMore: !1
    },
    scrollTop: function() {
        this.setData({
            top: !0
        });
    },
    confirmSearch: function(t) {
        this.conditionChange({
            startPorts: t.detail.startPorts || [],
            targetPorts: t.detail.targetPorts || [],
            minWeight: t.detail.minWeight || null,
            maxWeight: t.detail.maxWeight || null
        });
    },
    closeShortBargeAlert: function() {
        this.setData({
            shortBargeAlert: !1
        });
    },
    editTarget: function() {
        var t = {
            callback: this.targetPortsChange.bind(this),
            ports: JSON.parse(JSON.stringify(this.data.targetPorts)),
            type: "shipTarget",
            title: "请选择",
            titleHighlight: "卸货港",
            placeholder: "建议您多选几个卸货港附近的港口和地区"
        };
        wx.navigateTo({
            url: "/pages/multi-ports-selector/multiPortsSelector?query=".concat(l.register(t))
        });
    },
    targetPortsChange: function(t) {
        this.conditionChange({
            startPorts: this.data.startPorts,
            targetPorts: t || [],
            minWeight: this.data.minWeight,
            maxWeight: this.data.maxWeight
        });
    },
    refreshItem: function(t, e, a) {
        for (var i = this.data.shipItems, r = 0; r < i.length; r++) {
            var n = i[r];
            if (n.objectType === t && n.id === e) {
                n.user.name = a.username;
                break;
            }
        }
        this.setData({
            shipItems: this.data.shipItems
        });
    },
    showLoading: function() {
        wx.showLoading({
            title: "正在加载..."
        }), this.setData({
            loading: !0
        });
    },
    hideLoading: function() {
        this.setData({
            loading: !1
        }), wx.hideLoading();
    },
    refresh: function() {
        return e.mercury.post("greatPallet/update").then(function() {
            return Promise.all([ r.pallets.refresh(), n.refresh() ]);
        });
    },
    updatePallets: function() {
        var t = r.pallets.get(), e = n.get(), a = new Date().getHours(), i = a >= 6 && a < 22, h = i && !!t.find(function(t) {
            return t.great && (!t.great.pause || 0 === t.status);
        }), c = "";
        if (e >= .1) {
            var l = t.filter(function(t) {
                return t.great && !t.great.pause;
            }).length, u = 6 * Math.floor(10 * e / l), d = Math.floor(u / 60), g = Math.floor(d / 16);
            c = g > 0 ? g + "天" : d > 0 ? d + "小时" : u + "分钟";
        }
        var m = "", p = s.get();
        h && !c ? m = "notEnoughMoney" : o.certified.get() || o.certifying.get() || p && ("approved" === p.status || p.store) ? h && c && (m = "timeLeft") : m = "notCertified", 
        this.setData({
            myPallets: t,
            inGreatPalletTime: i,
            greatPalletLeftDesc: c,
            myPalletsAlert: m
        });
    },
    confirmUpgradeGreat: function(t, a) {
        var i = this, n = new Date().getHours();
        if (n < 6 || n >= 22) return Promise.resolve();
        var s = function(t) {
            return r.pallets.get().find(function(e) {
                return e.id === t;
            });
        };
        return this.refresh().then(function() {
            var n = s(t);
            (n ? Promise.resolve() : e.mercury.post("greatPallet/linkId", {
                id: t,
                ids: r.pallets.get().map(function(t) {
                    return t.id;
                })
            }).then(function(t) {
                return n = s(t);
            })).then(function() {
                !n || n.mask || n.great || 0 !== n.status || (i.setData({
                    demoPallet: d.getPalletDemo(n),
                    isNewPallet: a
                }), i.confirmUpgradeModal.show());
            });
        });
    },
    confirmUpgrade: function() {
        this.confirmUpgradeModal.hide(), this.toUpgradePallet(this.data.demoPallet.id);
    },
    toUpgrade: function(t) {
        var e = t.currentTarget.dataset.item;
        this.toUpgradePallet(e.id);
    },
    toUpgradePallet: function(t) {
        var e = this;
        d.upgrade(t, "myPallet", function() {
            return e.refresh();
        }, this.selectComponent("#upgrade-done"));
    },
    toCharge: function() {
        d.upgrade(null, "myPallet", null);
    },
    remove: function(t) {
        var a = this;
        wx.showModal({
            title: "删除货源",
            content: "是否删除货源？",
            success: function(i) {
                var r = t.currentTarget.dataset.pallet;
                i.confirm && e.mercury.post("pallets/remove", {
                    id: r
                }).then(function() {
                    return a.refresh();
                }).catch(function(t) {
                    return e.showError("删除货源", t);
                });
            }
        });
    },
    pause: function(t) {
        var a = this, i = t.currentTarget.dataset.pallet;
        e.mercury.post("pallets/pause", {
            id: i
        }).then(function() {
            return a.refresh();
        }).catch(function(t) {
            return e.showError("暂停货源", t);
        });
    },
    resume: function(t) {
        var a = this;
        this.deadbeatBlockModal.check("pallet_resume").then(function(i) {
            i && (h.showLoading("刷新数据中"), r.canPublish(function(i, n) {
                if (n) {
                    var s = t.currentTarget.dataset.pallet;
                    r.morePallets(s, function() {
                        var t = !1;
                        e.mercury.post("pallets/resume", {
                            id: s
                        }).finally(h.hideLoading).catch(function(a) {
                            t = !0, e.showError("恢复货源", a);
                        }).then(function() {
                            return !t && a.confirmUpgradeGreat(s, !1);
                        });
                    });
                } else h.hideLoading(), h.authPalletCreateModal();
            }));
        });
    },
    activate: function(t) {
        var a = this;
        this.deadbeatBlockModal.check("pallet_activate").then(function(i) {
            i && (h.showLoading("刷新数据中"), r.canPublish(function(i, n) {
                if (n) {
                    var s = t.currentTarget.dataset.pallet;
                    r.morePallets(s, function() {
                        var t = !1;
                        e.mercury.post("pallets/activate", {
                            id: s
                        }).finally(h.hideLoading).catch(function(a) {
                            t = !0, e.showError("激活货源", a);
                        }).then(function() {
                            return !t && a.confirmUpgradeGreat(s, !1);
                        });
                    });
                } else h.hideLoading(), h.authPalletCreateModal();
            }));
        });
    },
    _login: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    editPallet: function(t) {
        var e = this;
        o.id.get() ? this.deadbeatBlockModal.check("pallet_publish").then(function(a) {
            a && (h.showLoading("刷新数据中"), r.canPublish(function(a, i) {
                if (i) {
                    var n = +t.currentTarget.dataset.pallet || 0;
                    r.morePallets(n, function() {
                        h.hideLoading(), 0 == e.data.activeIndex && e.switchTab(1);
                        var t = l.register(function(t) {
                            !n && t && r.pallets.refresh().then(function() {
                                return e.confirmUpgradeGreat(t, !0);
                            });
                        });
                        wx.navigateTo({
                            url: "/pages/edit-pallet/edit-pallet?id=".concat(n, "&callback=").concat(t)
                        });
                    });
                } else h.hideLoading(), h.authPalletCreateModal();
            }));
        }) : this._login();
    },
    tabClick: function(t) {
        var e = t.currentTarget.id || 0, a = this.data.scrollTops[e] || 0;
        this.setData({
            sliderOffset: t.currentTarget.offsetLeft,
            activeIndex: t.currentTarget.id
        }), wx.pageScrollTo({
            scrollTop: a,
            duration: 0
        });
    },
    switchTab: function(t) {
        "1" == t ? this.setData({
            sliderOffset: 188,
            activeIndex: "1"
        }) : "0" == t && this.setData({
            sliderOffset: 0,
            activeIndex: "0"
        });
    },
    setCondition: function(t) {
        var e = {};
        e[t.currentTarget.dataset.condition] = t.detail.value, this.setData(e);
    },
    fixedItems: function(t, e) {
        var a = this, i = {};
        return e.forEach(function(t) {
            return i[t.objectType] = Math.max(i[t.objectType] || 0, Number.isFinite(t.adIndex) ? t.adIndex + 1 : 0);
        }), t.map(function(t) {
            return a._formatShipItem(t, i);
        });
    },
    _formatShipItem: function(e, i) {
        if (i = i || {}, e.adType = "ship" === e.objectType || "pallet" === e.objectType ? "" : e.objectType, 
        e.adIndex = i[e.objectType] || 0, i[e.objectType] = (i[e.objectType] || 0) + 1, 
        e.hash = e.objectType + e.id + e.adIndex, e.adType) if ("ad" === e.adType) {
            e.contents = t.getContents(e.content);
            var r = e.photo;
            r && r.name ? e.avatarUrl = a.mercury("files/load-ad-image?name=".concat(encodeURIComponent(r.name), "&width=60&height=60")) : e.avatarUrl = a.resource("mp/ad-avatar.png");
        } else "section_ad" === e.adType ? e.index = e.adIndex : "used_vessel" === e.adType ? u.fixItem(e) : "sailor_exam" === e.adType && (e.company = g.get()[Math.max(0, (e.id || 0) - 1)]); else {
            e.ship = e.id = Number.isFinite(e.ship) ? e.ship : e.id;
            var n = e.tag.photo;
            n && n.file ? (n.timeText = h.getTimeText(n.time), e.user.avatarUrl = a.mercury("vessels/photo?file=".concat(n.file, "&thumbnail=1"))) : e.user.avatarUrl = "/images/photo-empty.png";
        }
        return e;
    },
    search: function(t, e) {
        var a = this;
        "function" == typeof t ? (e = t, t = {}) : (t = t || {}, e = e || p);
        var i = this.data;
        wx.setStorage({
            key: "zhaochuan.lastTime",
            data: new Date().getTime()
        }), wx.setStorage({
            key: "zhaochuan.startPorts",
            data: i.startPorts
        }), wx.setStorage({
            key: "zhaochuan.targetPorts",
            data: i.targetPorts
        }), wx.setStorage({
            key: "zhaochuan.minWeight",
            data: i.minWeight || null
        }), wx.setStorage({
            key: "zhaochuan.maxWeight",
            data: i.maxWeight || null
        }), i.startPorts.length || i.targetPorts.length || i.minWeight || i.maxWeight ? (t.hideLoading || this.showLoading(), 
        (i.searchEnd ? this.guessLike(i, 0) : this.doSearch(i)).finally(function() {
            t.hideLoading || a.hideLoading(), e();
        })) : e();
    },
    doSearch: function(t) {
        var a = this, i = !t.startPage;
        i && this.setData({
            changeWeightAlert: !1
        });
        var r = {
            startPorts: t.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: t.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: t.minWeight,
            maxWeight: t.maxWeight
        };
        this.searchParamsJson = JSON.stringify(r);
        var n = Object.assign({}, r, {
            start: t.startPage,
            limit: 15
        });
        return e.mercury.post("search/shipsWithAdV4", n).then(function(e) {
            if (void 0 !== e.minWeight && e.minWeight !== a.data.minWeight || void 0 !== e.maxWeight && e.maxWeight !== a.data.maxWeight) {
                var r = "";
                e.minWeight && e.maxWeight ? r = e.minWeight + "~" + e.maxWeight + "吨" : e.minWeight ? r = e.minWeight + "吨以上" : e.maxWeight && (r = e.maxWeight + "吨以下"), 
                a.setData({
                    changeWeightAlert: !0,
                    changeWeightText: r
                });
                var n = setInterval(function() {
                    wx.createSelectorQuery().in(a).select("#change-weight-alert").boundingClientRect().exec(function(t) {
                        a.data.changeWeightAlert ? t && t[0] && Number.isFinite(t[0].height) && t[0].height > 0 && (a.setData({
                            changeWeightAlertHeight: Math.max(25, t[0].height)
                        }), clearInterval(n)) : clearInterval(n);
                    });
                }, 100);
            } else a.setData({
                changeWeightAlert: !1
            });
            var s = a.fixedItems(e.items, t.shipItems), o = s.filter(function(t) {
                return !t.adType;
            }).length, h = t.startPage + o, c = t.shipItems.concat(s), l = !c.find(function(t) {
                return !t.adType;
            }), u = h >= e.exist;
            if (a.setData({
                startPage: h,
                shipItems: c,
                searchNone: l,
                searchEnd: u,
                lastSearchTime: new Date(),
                isVipSearch: e.vip,
                haveMore: e.more
            }), u) return a.loadOrdered().then(function() {
                return a.guessLike(a.data, o, i);
            });
            a.checkVipAlert(u);
        });
    },
    checkVipAlert: function(t) {
        var e = this;
        if (!t && this.lastSearchParamsJson !== this.searchParamsJson && !this.data.isVipSearch) if (o.id.get() > 0) {
            h.confirm("您当前不是VIP用户，每次搜索最多只能查看100条空船信息，升级为VIP用户可查看更多", {
                cancelText: "暂不升级",
                confirmText: "升级VIP"
            }).then(function() {
                return e.toVip("alert-dialog");
            }).catch(function() {});
        } else {
            h.confirm("未登录用户每次搜索最多只能查看100条空船信息", {
                cancelText: "暂不登录",
                confirmText: "去登录"
            }).then(function() {
                return e.toLogin("alert-dialog");
            }).catch(function() {});
        }
        this.lastSearchParamsJson = this.searchParamsJson;
    },
    loadOrdered: function() {
        var t = this;
        return e.mercury.post("search/orderedShips", {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: this.data.minWeight,
            maxWeight: this.data.maxWeight
        }).then(function(e) {
            t.setData({
                orderedItems: e.map(function(e) {
                    return t._formatShipItem(e);
                })
            });
        });
    },
    shrinkOrderedItems: function() {
        this.setData({
            orderedItemsExpand: !1
        });
    },
    expandOrderedItems: function() {
        this.setData({
            orderedItemsExpand: !0
        });
    },
    guessLike: function(t, a, i) {
        var r = this, n = 15 - a, s = 0, o = 0;
        return t.shipItems.forEach(function(t) {
            t.adType ? s = 0 : (s++, o++);
        }), e.mercury.post("search/guessLikeShips", {
            startPorts: t.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: t.targetPorts.map(function(t) {
                return t.id;
            }),
            minWeight: t.minWeight,
            maxWeight: t.maxWeight,
            start: t.startGuess,
            limit: n,
            version: "v4",
            startCursor: s,
            itemCount: o
        }).then(function(e) {
            var a = r.fixedItems(e.items, t.shipItems.concat(t.guessItems)), n = t.startGuess + a.filter(function(t) {
                return !t.adType;
            }).length, s = t.guessItems.concat(a);
            s.filter(function(t) {
                return !t.adType;
            }).forEach(function(t, e) {
                return t.guessIndex = e;
            }), r.setData({
                startGuess: n,
                guessItems: s,
                guessEnd: n >= e.exist,
                isVipSearch: e.vip,
                haveMore: e.more
            }), i && r.checkVipAlert(r.data.guessEnd);
        });
    },
    conditionChange: function(t) {
        this.updateSearchBar(Object.assign({}, t, {
            startPage: 0,
            startGuess: 0,
            shipItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchNone: !1,
            searchEnd: !1,
            guessEnd: !1,
            startPorts: t.startPorts,
            targetPorts: t.targetPorts,
            minWeight: t.minWeight,
            maxWeight: t.maxWeight,
            isVipSearch: !1,
            haveMore: !1
        })), this.search();
    },
    toEditCondition: function(t) {
        var a = "xunchuan." + ("string" == typeof t ? t : "search-bottom");
        e.mercury.post("mapps/log", {
            action: "user-click",
            target: "edit-condition",
            result: a
        }), this.editCondition();
    },
    toVip: function(t) {
        var a = "xunchuan." + ("string" == typeof t ? t : "search-bottom");
        e.mercury.post("mapps/log", {
            action: "user-click",
            target: "to-vip",
            result: a
        }), wx.navigateTo({
            url: "/pages/settings/vip-pallet/vip-pallet?source=search"
        });
    },
    toLogin: function(t) {
        var a = "xunchuan." + ("string" == typeof t ? t : "search-bottom");
        e.mercury.post("mapps/log", {
            action: "user-click",
            target: "to-login",
            result: a
        }), wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile?source=search"
        });
    },
    editCondition: function() {
        this.setData({
            editingCondition: !0
        }), this.updateEditingCondition();
    },
    onLoad: function(t) {
        var i = this;
        "promotion" === t.source && e.mercury.post("utils/promotionToMp", {
            action: "xun_chuan",
            openid: m.globalData.userData.openid
        });
        var c = m.globalData.systemInfo;
        this.setData({
            sliderOffset: c.windowWidth / this.data.tabs.length * this.data.activeIndex,
            banner: a.resource("mp/delegate.jpg"),
            windowHeight: c.windowHeight
        }), e.mercury.get("search/shipsTopPorts", {
            count: 15
        }).then(function(t) {
            this.setData({
                hotPorts: t
            });
        }.bind(this)), this.syncUserId = o.id.subscribeAndFireOnce(function(t) {
            return i.setData({
                userId: t
            });
        }), this.syncPallets = r.pallets.subscribeAndFireOnce(function() {
            return i.updatePallets();
        }), this.syncCash = n.subscribeAndFireOnce(function() {
            return i.updatePallets();
        }), this.syncUserCertifying = o.certifying.subscribeAndFireOnce(function() {
            return i.updatePallets();
        }), this.syncUserCertified = o.certified.subscribeAndFireOnce(function() {
            return i.updatePallets();
        }), this.syncEnterprise = s.subscribeAndFireOnce(function() {
            return i.updatePallets();
        }), this.syncMaskPalletCount = r.maskPalletCount.subscribeAndFireOnce(function(t) {
            return i.setData({
                maskPalletCount: t
            });
        });
        var l = +wx.getStorageSync("zhaochuan.lastTime") || 0, u = [], d = [], g = null, p = null;
        if ((!l || new Date().getTime() - l < 2592e5) && (u = wx.getStorageSync("zhaochuan.startPorts"), 
        Array.isArray(u) && "string" == typeof u[0] && (u = u.map(function(t) {
            return {
                id: t,
                title: t
            };
        })), d = wx.getStorageSync("zhaochuan.targetPorts"), Array.isArray(d) && "string" == typeof d[0] && (d = d.map(function(t) {
            return {
                id: t,
                title: t
            };
        })), g = parseInt(wx.getStorageSync("zhaochuan.minWeight")), p = parseInt(wx.getStorageSync("zhaochuan.maxWeight"))), 
        t.cacheQuery) {
            if (u = [], t.startPorts) {
                var f = (t.startPorts || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                }), P = (t.startPortTitles || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                });
                u = f.map(function(t, e) {
                    return {
                        id: t,
                        title: P[e] || t
                    };
                });
            }
            if (d = [], t.targetPorts) {
                var v = (t.targetPorts || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                }), x = (t.targetPortTitles || "").split(",").map(function(t) {
                    return t.trim();
                }).filter(function(t) {
                    return t;
                });
                d = v.map(function(t, e) {
                    return {
                        id: t,
                        title: x[e] || t
                    };
                });
            }
            g = parseInt(t.minWeight), p = parseInt(t.maxWeight);
        }
        var y = {
            startPorts: u || [],
            targetPorts: d || []
        };
        if (Number.isFinite(g) && (y = Object.assign(y, {
            minWeight: g
        })), Number.isFinite(p) && (y = Object.assign(y, {
            maxWeight: p
        })), t.searchPort && (y.startPorts = [ {
            id: t.searchPort,
            title: t.searchPortTitle || t.searchPort
        } ], y.targetPorts = [], y.minWeight = null, y.maxWeight = null), this.updateSearchBar(y), 
        t.tab && this.switchTab(+t.tab || 0), t.cacheQuery || 0 != this.data.activeIndex || r.normalPalletCount.get()) this.search(); else {
            h.confirm("90%的船主只搜索货源，不发布空船信息。强烈建议您发布货源信息等待船主呼入。", {
                cancelText: "搜索空船",
                confirmText: "发布货源"
            }).then(function() {
                return i.switchTab(1);
            }).finally(function() {
                var t = 0 != i.data.activeIndex;
                i.search({
                    hideLoading: t
                }), e.mercury.post("mapps/log", {
                    action: "ui_options",
                    target: "search_or_publish_pallet",
                    result: t ? "to_my_pallet" : "to_search"
                });
            });
        }
    },
    updateSearchBar: function(t) {
        var a = this;
        t.start = t.startPorts.length > 0 ? t.startPorts[0].title + (t.startPorts.length > 1 ? "等" : "") : "不限", 
        t.target = t.targetPorts.length > 0 ? t.targetPorts[0].title + (t.targetPorts.length > 1 ? "等" : "") : "不限", 
        t.weightsLine1 = t.minWeight && t.maxWeight ? "".concat(t.minWeight, " ~") : t.minWeight ? "".concat(t.minWeight, "吨") : t.maxWeight ? "".concat(t.maxWeight, "吨") : "", 
        t.weightsLine2 = t.minWeight && t.maxWeight ? "".concat(t.maxWeight, "吨") : t.minWeight ? "以上" : t.maxWeight ? "以下" : "", 
        t.noCondition = !t.startPorts.length && !t.targetPorts.length, t.editingCondition = t.noCondition, 
        this.setData(t), this.updateEditingCondition(), e.mercury.post("search/shortBarge", {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            })
        }).then(function(t) {
            a.setData({
                shortBargeAlert: t
            });
            var e = setInterval(function() {
                wx.createSelectorQuery().in(a).select("#short-barge-alert").boundingClientRect().exec(function(t) {
                    a.data.shortBargeAlert ? t && t[0] && Number.isFinite(t[0].height) && t[0].height > 0 && (a.setData({
                        shortBargeAlertHeight: Math.max(50, t[0].height)
                    }), clearInterval(e)) : clearInterval(e);
                });
            }, 100);
        }).catch(function(t) {
            return console.error(t);
        });
    },
    updateEditingCondition: function() {
        if (this.data.editingCondition || this.data.noCondition) {
            var t = this.selectComponent("#chuan-search-condition");
            t && t.init(this.data.startPorts, this.data.targetPorts, this.data.minWeight, this.data.maxWeight);
        }
    },
    onReady: function() {
        this.updateEditingCondition(), this.confirmUpgradeModal = this.selectComponent("#confirmUpgradeModal"), 
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        (this.data.top && (this.setData({
            top: !1
        }), wx.pageScrollTo({
            scrollTop: 0
        })), this.data.loading && this.showLoading(), this.data.lastSearchTime) && (i().diff(i(this.data.lastSearchTime), "minutes") >= 15 && (this.setData({
            startPage: 0,
            startGuess: 0,
            shipItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchEnd: !1,
            guessEnd: !1,
            searchNone: !1,
            isVipSearch: !1,
            haveMore: !1
        }), this.search()));
        r.pallets.refresh().catch(function(t) {
            return e.showError("获取货源信息", t);
        }), this.refreshMaskInterval = setInterval(r.pallets.refreshMask, 6e4);
    },
    onHide: function() {
        this.refreshMaskInterval && (clearInterval(this.refreshMaskInterval), this.refreshMaskInterval = null);
    },
    onUnload: function() {
        this.syncUserId.dispose(), this.syncPallets.dispose(), this.syncCash.dispose(), 
        this.syncMaskPalletCount.dispose(), this.syncUserCertifying.dispose(), this.syncUserCertified.dispose(), 
        this.syncEnterprise.dispose();
    },
    onPullDownRefresh: function() {
        0 == this.data.activeIndex ? this.data.editingCondition || this.data.noCondition ? c.ship.refresh().then(function() {
            return wx.stopPullDownRefresh();
        }) : (this.setData({
            startPage: 0,
            startGuess: 0,
            shipItems: [],
            guessItems: [],
            orderedItems: [],
            orderedItemsExpand: !1,
            searchEnd: !1,
            guessEnd: !1,
            searchNone: !1,
            pullDown: !0,
            isVipSearch: !1,
            haveMore: !1
        }), this.search(function() {
            wx.stopPullDownRefresh(), this.setData({
                pullDown: !1
            });
        }.bind(this))) : 1 == this.data.activeIndex && r.pallets.refresh().then(wx.stopPullDownRefresh).catch(function(t) {
            return e.showError("获取货源信息", t);
        });
    },
    onReachBottom: function() {
        0 != this.data.activeIndex || this.data.guessEnd || this.data.editingCondition || this.data.noCondition || this.search();
    },
    onPageScroll: function(t) {
        var e = this.data.activeIndex || 0;
        this.data.scrollTops[e] = t.scrollTop;
    },
    onShareAppMessage: function() {
        var t = {
            startPorts: this.data.startPorts.map(function(t) {
                return t.id;
            }).join(),
            startPortTitles: this.data.startPorts.map(function(t) {
                return t.title;
            }).join(),
            targetPorts: this.data.targetPorts.map(function(t) {
                return t.id;
            }).join(),
            targetPortTitles: this.data.targetPorts.map(function(t) {
                return t.title;
            }).join(),
            cacheQuery: !0
        };
        return this.data.minWeight && (t = Object.assign(t, {
            minWeight: this.data.minWeight
        })), this.data.maxWeight && (t = Object.assign(t, {
            maxWeight: this.data.maxWeight
        })), {
            title: h.shareTitle,
            path: h.shareTabPath("zhaochuan", t)
        };
    },
    toHelp: function() {
        e.mercury.post("mapps/log", {
            action: "help-search-ship"
        });
    }
});