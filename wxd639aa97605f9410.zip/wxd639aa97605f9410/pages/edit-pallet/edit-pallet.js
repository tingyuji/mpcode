var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), a = require("../../utils/ajax.js"), i = require("../../utils/env.js"), e = require("../../dao/enterprise.js"), n = require("../../utils/globalMap"), h = require("../../modules/moment.js"), s = require("../../dao/pallet.js"), r = require("../../utils/user.js"), o = require("../../utils/util.js");

Page({
    data: {
        id: null,
        startPort: {
            id: "",
            title: ""
        },
        startTerminal: "",
        targetPort: {
            id: "",
            title: ""
        },
        targetTerminal: "",
        cargo: "",
        note: "",
        longTerm: !1,
        loadOnArrived: !1,
        blankPorts: [],
        anyWeight: null,
        minWeight: null,
        maxWeight: null,
        fleet: !1,
        shipSingle: !1,
        shipCount: null,
        fengcang: null,
        shuichi: null,
        bridgePosition: null,
        hatch: null,
        dakong: null,
        sink: null,
        draught: null,
        shipLength: null,
        shipWidth: null,
        shipHeight: null,
        hatchLength: null,
        hatchWidth: null,
        hatchDepth: null,
        price: null,
        startPrice: null,
        demurrage: null,
        handlingTime: null,
        settlement: null,
        payment: null,
        isStarEnterprise: !1,
        startLoc: null,
        targetLoc: null,
        media: []
    },
    modifyAlert: function() {
        this.data.id && o.alert("已发布的货源不能修改装货港、卸货港和货物名称");
    },
    removeMedia: function(t) {
        o.confirm("是否确定删除？").then(function() {
            var a = t.currentTarget.dataset.index, i = this.data.media;
            i.splice(a, 1), this.setData({
                media: i
            });
        }.bind(this)).catch(function() {});
    },
    uploadMedia: function(t) {
        wx.showModal({
            title: "上传提示",
            content: "为货源上传图片或视频？",
            success: function(t) {
                t.confirm ? wx.chooseImage({
                    count: 1,
                    sizeType: [ "compressed" ],
                    success: function(t) {
                        wx.showLoading({
                            title: "正在上传..."
                        });
                        for (var e = t.tempFilePaths[0], n = "jpg", h = e.length - 1; h >= 0; h--) if ("." === e[h]) {
                            n = e.slice(h);
                            break;
                        }
                        a.mercury.upload("store/uploadMedia", e, null, {
                            pallet: this.data.id,
                            suffix: n
                        }, null, {}).finally(function() {
                            wx.hideLoading();
                        }).then(function(t) {
                            var e = this.data.media;
                            e.push({
                                file: t,
                                url: i.mercury("store/media/".concat(t, "?authentication=").concat(a.getToken(), "&thumbnail=1"))
                            }), this.setData({
                                media: e
                            });
                        }.bind(this)).catch(function(t) {
                            return a.showError("为货源上传图片", t);
                        });
                    }.bind(this)
                }) : t.cancel && wx.chooseVideo({
                    success: function(t) {
                        wx.showLoading({
                            title: "正在上传..."
                        });
                        for (var e = t.tempFilePath, n = "jpg", h = e.length - 1; h >= 0; h--) if ("." === e[h]) {
                            n = e.slice(h);
                            break;
                        }
                        a.mercury.upload("store/uploadMedia", e, null, {
                            pallet: this.data.id,
                            suffix: n
                        }, null, {}).finally(function() {
                            wx.hideLoading();
                        }).then(function(t) {
                            var e = this.data.media;
                            e.push({
                                file: t,
                                url: i.mercury("store/media/".concat(t, "?authentication=").concat(a.getToken(), "&thumbnail=1"))
                            }), this.setData({
                                media: e
                            });
                        }.bind(this)).catch(function(t) {
                            return a.showError("为货源上传视频", t);
                        });
                    }.bind(this)
                });
            }.bind(this),
            confirmText: "选择图片",
            cancelText: "选择视频",
            cancelColor: "#3CC51F"
        });
    },
    onLoad: function(s) {
        e.refresh();
        var o = e.get(), l = parseInt(s && s.id) || 0;
        this.callback = s.callback ? n.unRegister(s.callback) : null;
        var d = h().format("YYYY-MM-DD");
        this.setData({
            id: l,
            today: d,
            days30: h().add(30, "days").format("YYYY-MM-DD"),
            date: d,
            isStarEnterprise: o && o.store
        }), r.id.get() ? l && a.mercury.get("pallets/load", {
            id: l
        }).then(function(e) {
            var n, s = (e.blankStartId || "").split(",").map(function(t) {
                return t.trim();
            }).filter(function(t) {
                return t;
            }), r = (e.blankStart || "").split(",").map(function(t) {
                return t.trim();
            }).filter(function(t) {
                return t;
            }), o = s.map(function(t, a) {
                return {
                    id: t,
                    title: r[a] || t
                };
            }), l = e.media || [], d = t(l);
            try {
                for (d.s(); !(n = d.n()).done; ) {
                    var c = n.value;
                    c.url = i.mercury("store/media/".concat(c.file, "?authentication=").concat(a.getToken(), "&thumbnail=1"));
                }
            } catch (t) {
                d.e(t);
            } finally {
                d.f();
            }
            this.setData({
                startPort: {
                    id: e.startPortId,
                    title: e.startPort
                },
                startTerminal: e.startTerminal,
                targetPort: {
                    id: e.aimPortId,
                    title: e.aimPort
                },
                targetTerminal: e.targetTerminal,
                name: e.name,
                cargo: e.cargo,
                longTerm: e.longTerm,
                loadOnArrived: e.loadOnArrived,
                date: h(e.date).format("YYYY-MM-DD"),
                note: e.note,
                anyWeight: e.anyWeight,
                minWeight: e.minWeight,
                maxWeight: e.maxWeight,
                blankPorts: o,
                fleet: e.fleet,
                shipSingle: e.shipSingle,
                shipCount: e.shipCount,
                fengcang: e.fengcang,
                shuichi: e.shuichi,
                bridgePosition: e.bridgePosition,
                hatch: e.hatch,
                dakong: e.dakong,
                sink: e.sink,
                draught: e.draught,
                shipLength: e.shipLength,
                shipWidth: e.shipWidth,
                shipHeight: e.shipHeight,
                hatchLength: e.hatchLength,
                hatchWidth: e.hatchWidth,
                hatchDepth: e.hatchDepth,
                price: e.price,
                startPrice: e.startPrice,
                demurrage: e.demurrage,
                handlingTime: e.handlingTime,
                settlement: e.settlement,
                payment: e.payment,
                startLoc: e.startLoc || null,
                targetLoc: e.targetLoc || null,
                media: l
            }), this.selectComponent("#startPort").setPort(this.data.startPort), this.selectComponent("#targetPort").setPort(this.data.targetPort), 
            this.selectComponent("#name").setCargo(this.data.name);
        }.bind(this)).catch(function(t) {
            return a.showError("加载货源", t);
        }) : wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    nameChange: function(t) {
        this.setData({
            name: t.detail
        });
    },
    startPortChange: function(t) {
        this.setData({
            startPort: t.detail
        });
    },
    targetPortChange: function(t) {
        this.setData({
            targetPort: t.detail
        });
    },
    noteChange: function(t) {
        this.data.note = t.detail;
    },
    longTermChange: function(t) {
        this.setData({
            longTerm: "longTerm" === t.detail.value,
            loadOnArrived: "loadOnArrived" === t.detail.value
        });
    },
    _getCity: function(t) {
        var a = (t = t || "").indexOf("市");
        return a >= 0 ? t.slice(0, a + 1) : t;
    },
    locateStart: function() {
        this.data.startLoc;
        wx.chooseLocation({
            success: function(t) {
                this.setData({
                    startLoc: {
                        cityname: this._getCity(t.address),
                        lat: t.latitude,
                        lng: t.longitude,
                        poiname: t.name,
                        poiaddress: t.address
                    }
                });
            }.bind(this)
        });
    },
    locateTarget: function() {
        wx.chooseLocation({
            success: function(t) {
                this.setData({
                    targetLoc: {
                        cityname: this._getCity(t.address),
                        lat: t.latitude,
                        lng: t.longitude,
                        poiname: t.name,
                        poiaddress: t.address
                    }
                });
            }.bind(this)
        });
    },
    removeStartLocation: function() {
        this.setData({
            startLoc: null
        });
    },
    removeTargetLocation: function() {
        this.setData({
            targetLoc: null
        });
    },
    openStartLocation: function() {
        var t = this.data.startLoc;
        wx.openLocation({
            latitude: t && t.lat,
            longitude: t && t.lng,
            name: t && t.poiname,
            address: t && t.poiaddress
        });
    },
    openTargetLocation: function() {
        var t = this.data.targetLoc;
        wx.openLocation({
            latitude: t && t.lat,
            longitude: t && t.lng,
            name: t && t.poiname,
            address: t && t.poiaddress
        });
    },
    setDate: function(t) {
        var a = t.detail.value;
        this.setData({
            date: a
        });
    },
    setStartTerminal: function(t) {
        this.data.startTerminal = t.detail.value;
    },
    setTargetTerminal: function(t) {
        this.data.targetTerminal = t.detail.value;
    },
    setCargo: function(t) {
        this.data.cargo = t.detail.value;
    },
    freightChange: function(t) {
        this.setData({
            price: t.price || "",
            startPrice: t.startPrice || "",
            demurrage: t.demurrage || "",
            handlingTime: t.handlingTime || "",
            settlement: t.settlement || "",
            payment: t.payment || ""
        });
    },
    shipDescriptionChange: function(t) {
        var a = t.anyWeight, i = t.minWeight, e = t.maxWeight;
        a && (i = null, e = null), this.setData({
            anyWeight: a,
            minWeight: i,
            maxWeight: e,
            blankPorts: t.blankPorts,
            fleet: t.fleet,
            shipSingle: t.shipSingle,
            shipCount: parseInt(t.shipCount) || null,
            fengcang: t.fengcang,
            shuichi: t.shuichi,
            bridgePosition: t.bridgePosition,
            hatch: t.hatch,
            dakong: t.dakong,
            sink: t.sink,
            draught: parseFloat(t.draught) || null,
            shipLength: parseFloat(t.shipLength) || null,
            shipWidth: parseFloat(t.shipWidth) || null,
            shipHeight: parseFloat(t.shipHeight) || null,
            hatchLength: parseFloat(t.hatchLength) || null,
            hatchWidth: parseFloat(t.hatchWidth) || null,
            hatchDepth: parseFloat(t.hatchDepth) || null
        });
    },
    editFreight: function() {
        this.callbackId = n.register(this.freightChange.bind(this));
        var t = "/pages/edit-freight/edit-freight?callback=".concat(this.callbackId);
        this.data.price && (t += "&price=".concat(this.data.price)), this.data.startPrice && (t += "&startPrice=".concat(this.data.startPrice)), 
        this.data.demurrage && (t += "&demurrage=".concat(this.data.demurrage)), this.data.handlingTime && (t += "&handlingTime=".concat(this.data.handlingTime)), 
        this.data.settlement && (t += "&settlement=".concat(this.data.settlement)), this.data.payment && (t += "&payment=".concat(this.data.payment)), 
        wx.navigateTo({
            url: t
        });
    },
    editShipDescription: function() {
        this.callbackId = n.register(this.shipDescriptionChange.bind(this));
        var t = "/pages/edit-ship-description/edit-ship-description?callback=".concat(this.callbackId);
        o.isNil(this.data.draught) || (t += "&draught=".concat(this.data.draught)), o.isNil(this.data.shipLength) || (t += "&shipLength=".concat(this.data.shipLength)), 
        o.isNil(this.data.shipWidth) || (t += "&shipWidth=".concat(this.data.shipWidth)), 
        o.isNil(this.data.shipHeight) || (t += "&shipHeight=".concat(this.data.shipHeight)), 
        o.isNil(this.data.hatchLength) || (t += "&hatchLength=".concat(this.data.hatchLength)), 
        o.isNil(this.data.hatchWidth) || (t += "&hatchWidth=".concat(this.data.hatchWidth)), 
        o.isNil(this.data.hatchDepth) || (t += "&hatchDepth=".concat(this.data.hatchDepth)), 
        this.data.blankPorts.length > 0 && (t += "&blankPorts=".concat(this.data.blankPorts.map(function(t) {
            return t.id;
        }).join(",")), t += "&blankPortTitles=".concat(this.data.blankPorts.map(function(t) {
            return t.title;
        }).join(",")));
        var a = "unknown";
        "yes" === this.data.fengcang && (a = "yes"), t += "&fengcang=".concat(a);
        var i = "unknown";
        "biaozhun" === this.data.shuichi ? i = "biaozhun" : "magang" === this.data.shuichi ? i = "magang" : "wugang" === this.data.shuichi ? i = "wugang" : "zhonggang" === this.data.shuichi && (i = "zhonggang"), 
        t += "&shuichi=".concat(i);
        var e = "unknown";
        "fore" === this.data.bridgePosition ? e = "fore" : "aft" === this.data.bridgePosition && (e = "aft"), 
        t += "&bridgePosition=".concat(e);
        var h = "unknown";
        "whole" === this.data.hatch ? h = "whole" : "division" === this.data.hatch && (h = "division"), 
        t += "&hatch=".concat(h);
        var s = "unknown";
        "yes" === this.data.dakong && (s = "yes"), t += "&dakong=".concat(s);
        var r = "unknown";
        "yes" === this.data.sink && (r = "yes"), t += "&sink=".concat(r), this.data.fleet && (t += "&fleet=fleet"), 
        this.data.shipSingle && (t += "&shipSingle=shipSingle"), o.isNil(this.data.shipCount) || (t += "&shipCount=".concat(this.data.shipCount)), 
        this.data.anyWeight ? t += "&anyWeight=anyWeight" : (o.isNil(this.data.minWeight) || (t += "&minWeight=".concat(this.data.minWeight)), 
        o.isNil(this.data.maxWeight) || (t += "&maxWeight=".concat(this.data.maxWeight))), 
        wx.navigateTo({
            url: t
        });
    },
    _getPrevPage: function() {
        var t = getCurrentPages();
        return t[t.length - 2];
    },
    _publishBack: function(t) {
        this.callback && this.callback(t);
        var a = this._getPrevPage();
        a && a.route && (a.route.startsWith("pages/zhaochuan/zhaochuan") || a.route.startsWith("pages/link-ships/link-ships")) ? this._back() : wx.redirectTo({
            url: "/pages/zhaochuan/zhaochuan?tab=1"
        });
    },
    _back: function() {
        var t = this._getPrevPage();
        t && "function" == typeof t.scrollTop && t.scrollTop(), wx.navigateBack();
    },
    cancel: function() {
        this._back();
    },
    publish: function() {
        if (this.data.startPort.id) if (this.data.targetPort.id) if (this.data.name) if (this.data.cargo) if (o.isNil(this.data.anyWeight)) o.alert("没有填写船舶要求"); else {
            var t = {
                aimPort: this.data.targetPort.id,
                anyWeight: this.data.anyWeight,
                blankStart: this.data.blankPorts.map(function(t) {
                    return t.id;
                }).join(","),
                cargo: this.data.cargo,
                date: this.data.date,
                demurrage: this.data.demurrage,
                draught: this.data.draught,
                duration: 1,
                fengcang: this.data.fengcang,
                shuichi: this.data.shuichi,
                bridgePosition: this.data.bridgePosition,
                hatch: this.data.hatch,
                dakong: this.data.dakong,
                sink: this.data.sink,
                fleet: this.data.fleet,
                handlingTime: this.data.handlingTime,
                hatchDepth: this.data.hatchDepth,
                hatchLength: this.data.hatchLength,
                hatchWidth: this.data.hatchWidth,
                id: this.data.id,
                longTerm: this.data.longTerm,
                loadOnArrived: this.data.loadOnArrived,
                maxWeight: this.data.maxWeight,
                minWeight: this.data.minWeight,
                mobiles: r.mobile.get(),
                name: this.data.name,
                note: this.data.note,
                payment: this.data.payment,
                price: this.data.price,
                settlement: this.data.settlement,
                shipCount: this.data.shipCount,
                shipHeight: this.data.shipHeight,
                shipLength: this.data.shipLength,
                shipSingle: this.data.shipSingle,
                shipWidth: this.data.shipWidth,
                startPort: this.data.startPort.id,
                startPrice: this.data.startPrice,
                startTerminal: this.data.startTerminal,
                targetTerminal: this.data.targetTerminal,
                startLoc: this.data.startLoc,
                targetLoc: this.data.targetLoc,
                media: this.data.media
            };
            o.showLoading("发布货源中"), s.canPublish(function(i, e) {
                var n = this;
                e ? a.mercury.post("pallets/save", t).finally(o.hideLoading).then(function(t) {
                    return n._publishBack(t);
                }).catch(function(t) {
                    return a.showError("发布货源", t);
                }) : (o.hideLoading(), o.authPalletCreateModal());
            }.bind(this));
        } else o.alert("货量不能为空"); else o.alert("货物名称不能为空"); else o.alert("卸货港不能为空"); else o.alert("装货港不能为空");
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});