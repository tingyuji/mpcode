var t = require("../../utils/ajax.js"), e = require("../../utils/env.js"), i = require("../../dao/shipAjax.js"), o = require("../../dao/ship.js"), n = require("../../utils/util.js"), a = require("../../dao/vessel.js");

Page({
    data: {
        id: null
    },
    edit: function(t) {
        n.showLoading("加载页面中"), i.canPublish(function(t, e) {
            n.hideLoading(), e ? wx.redirectTo({
                url: "/pages/edit-ship/edit-ship?id=" + this.data.id
            }) : n.authShipCreateModal();
        }.bind(this));
    },
    remove: function(e) {
        wx.showModal({
            title: "删除空船",
            content: "是否删除空船？",
            success: function(e) {
                e.confirm && t.mercury.post("ships/remove", {
                    id: this.data.id
                }).then(function() {
                    o.refresh(), wx.navigateBack();
                }.bind(this));
            }.bind(this)
        });
    },
    preview: function() {
        wx.previewImage({
            urls: [ this.data.vessel.photo.originUrl ]
        });
    },
    onLoad: function(t) {
        var i = o.get(), s = a.get();
        i.showTimeText = n.getTimeText(i.showTime), i.dateText = n.getDateText(i.date);
        var r = [];
        i.aimPort && (r = i.aimPort.split(",")), i.aimPorts = r.join(" ");
        var h = [];
        i.blankStart && (h = i.blankStart.split(",")), i.blankStarts = h.join(" "), s.photo && (s.photo.time && (s.photo.timeText = n.getTimeText(s.photo.time)), 
        s.photo.file ? (s.photo.originUrl = e.mercury("vessels/photo?file=".concat(s.photo.file)), 
        s.photo.url = e.mercury("vessels/photo?file=".concat(s.photo.file, "&thumbnail=1"))) : (s.photo.originUrl = "/images/photo-empty.png", 
        s.photo.url = "/images/photo-empty.png")), this.setData({
            id: t.id,
            ship: i,
            vessel: s
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this.data.ship, e = "".concat(t.weight, "吨").concat(t.dateText, "空").concat(t.startPort), i = "/pages/ship-detail/ship-detail?id=".concat(t.id, "&origin=0&mark=0");
        return {
            title: e,
            path: "/pages/index/index?navigate=" + encodeURIComponent(i)
        };
    }
});