var e = require("../../modules/moment"), t = require("../../modules/spark-md5"), i = require("../../utils/ajax"), n = require("../../utils/util");

Page({
    updateItem: function(e) {
        var t;
        switch (e.type) {
          case "现货":
            t = "xianhuo";
            break;

          case "长期":
            t = "changqi";
            break;

          case "求购":
            t = "qiugou";
        }
        var i = e && e.user || {};
        i.nick = i.nick || "——";
        var n = e && e.avatarUrl || "/images/sandstone_mp_default_avatar.png", a = e && e.medias || [];
        (a = a.filter(function(e) {
            return e.mimeType && (e.mimeType.startsWith("image/") || e.mimeType.startsWith("video/"));
        })).forEach(function(e, t) {
            e.index = t, e.type = e.mimeType.split("/")[0], e.posterUrl = e.posterUrl || e.url, 
            e.imageMode = "vertical" === e.direction ? "heightFix" : "widthFix";
        }), this.medias = a.slice(), 4 === a.length && a.splice(2, 0, {
            id: 0
        });
        var o = e && e.position || null;
        o && (o.name = o.poiName || o.city, o.address = o.poiAddress || null);
        var r = this.getShowTime(e && e.showTime), s = this.getContentItems(e);
        this.setData({
            typeClass: t,
            user: i,
            avatarUrl: n,
            medias: a,
            position: o,
            showTime: r,
            item: e,
            contentItems: s
        });
    },
    getShowTime: function(t) {
        t = (t ? new Date(t).getTime() : 0) || 0;
        var i = new Date().getTime(), n = (i - t) / 1e3 / 60;
        if (n < 60) return Math.max(1, Math.floor(n)) + "分钟前";
        if ((n /= 60) < 24) return Math.floor(n) + "小时前";
        var a = e(t).startOf("day"), o = e(i).startOf("day").diff(a, "day");
        return 1 === o ? "昨天" : o + "天前";
    },
    getContentItems: function(e) {
        var i = (e.content || "").replace(/\r\n/g, "\n").replace(/[\r\n]/g, "\r\n").replace(/(\D|\b)(1[3-9]\d{9}|4008030092|400-803-0092)(\D|\b)/g, function(e, t, i, n) {
            return "".concat(t || "", "@chb2@").concat(i, "#chb2#").concat(n || "");
        }), n = [], a = function(e) {
            n.push({
                type: "string",
                content: e
            });
        }, o = i.match(/@chb2@([\d\-]+)#chb2#/g);
        if (o) {
            for (var r = i.replace(/@chb2@([\d\-]+)#chb2#/g, "@chb2@").split("@chb2@"), s = 0; s < o.length; s++) a(r[s]), 
            n.push({
                type: "phone",
                content: o[s].match(/@chb2@([\d\-]+)#chb2#/)[1]
            });
            a(r[r.length - 1]);
        } else a(i);
        return n.forEach(function(e) {
            return e.hash = t.hash(JSON.stringify(e));
        }), n;
    },
    dial: function(e) {
        var t = e.currentTarget.dataset.item.content;
        i.service.post("ad/sandstoneDial", {
            id: this.data.item.id,
            phone: t,
            place: "content"
        }), wx.makePhoneCall({
            phoneNumber: t
        });
    },
    dialMobile: function() {
        var e = this.data.item.mobile;
        i.service.post("ad/sandstoneDial", {
            id: this.data.item.id,
            phone: e,
            place: "menu"
        }), wx.makePhoneCall({
            phoneNumber: e
        }), this.tapMask();
    },
    preview: function(e) {
        console.log(e);
        var t = e.currentTarget.dataset.media, i = this.medias.map(function(e) {
            return {
                url: e.url,
                type: e.mimeType.startsWith("video/") ? "video" : "image",
                poster: e.posterUrl
            };
        }), n = i[t.index];
        "video" === n.type ? wx.navigateTo({
            url: "/pages/video-detail/video-detail?url=" + encodeURIComponent(n.url)
        }) : wx.previewMedia({
            sources: i,
            current: t.index
        });
    },
    previewLocation: function() {
        var e = this.data.position;
        wx.openLocation({
            longitude: e.lon,
            latitude: e.lat,
            name: e.name,
            address: e.address
        });
    },
    more: function() {
        this.setData({
            showTooltip: !this.data.showTooltip
        });
    },
    tapMask: function() {
        this.setData({
            showTooltip: !1
        });
    },
    open: function() {
        this.jumpToSandstoneMiniProgram("open");
    },
    view: function() {
        this.jumpToSandstoneMiniProgram("more");
    },
    publish: function() {
        this.jumpToSandstoneMiniProgram("publish");
    },
    jumpToSandstoneMiniProgram: function(e) {
        i.mercury.post("ad/sandstoneJump", {
            id: this.data.item.id,
            place: e
        }), n.jumpToSandstoneMiniProgram("sandstoneDetail");
    },
    data: {
        id: 0,
        item: null,
        contentItems: [],
        typeClass: "",
        user: {},
        medias: [],
        position: null,
        showTime: "",
        showTooltip: !1,
        avatarUrl: ""
    },
    onLoad: function(e) {
        var t = this;
        n.showLoading("正在载入..."), i.mercury.get("ad/sandstoneDetail?id=" + e.id).finally(n.hideLoading).then(function(e) {
            t.updateItem(e);
        }).catch(function(e) {
            return i.showError("获取砂石消息详情", e).then(wx.navigateBack);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});