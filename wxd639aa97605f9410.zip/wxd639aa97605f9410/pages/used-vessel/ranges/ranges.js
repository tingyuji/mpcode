var n = require("../../../utils/globalMap"), t = require("../../../utils/ajax"), e = require("../common");

Page({
    init: function() {
        var n = this, e = this.data.rangeOptions.map(function(n) {
            return [ n.min, n.max ];
        });
        t.mercury.post("usedVessel/countByRanges", {
            ranges: e
        }).then(function(t) {
            for (var e = 0; e < n.data.rangeOptions.length; e++) n.data.rangeOptions[e].count = t[e] || 0;
            n.setData({
                rangeOptions: n.data.rangeOptions
            });
        });
    },
    remove: function(n) {
        var t = n.currentTarget.dataset.item, e = this.data.rangeOptions.find(function(n) {
            return n.title === t;
        });
        e && (e.selected = !1, this.rangesChanged(this.data.rangeOptions));
    },
    select: function(n) {
        var t = n.currentTarget.dataset.item, e = this.data.rangeOptions.find(function(n) {
            return n.title === t.title;
        });
        e && (e.selected = !0, this.rangesChanged(this.data.rangeOptions));
    },
    rangesChanged: function(n) {
        var t = n.filter(function(n) {
            return n.selected;
        }).map(function(n) {
            return n.title;
        });
        this.setData({
            ranges: t,
            rangeOptions: n
        });
    },
    confirm: function() {
        this.data.ranges.length > 0 && (this.callback && this.callback(this.data.rangeOptions.filter(function(n) {
            return n.selected;
        }).map(function(n) {
            return [ n.min, n.max ];
        })), wx.navigateBack());
    },
    clearSelection: function() {
        var n = this.data.rangeOptions.map(function(n) {
            return Object.assign({}, n, {
                selected: !1
            });
        });
        this.setData({
            ranges: [],
            rangeOptions: n
        });
    },
    data: {
        ranges: [],
        rangeOptions: e.range_options.map(function(n) {
            return Object.assign({}, n, {
                count: 0,
                selected: !1
            });
        })
    },
    onLoad: function(e) {
        this.callback = e.callback ? n.unRegister(e.callback) : null;
        var a = e.ranges ? n.unRegister(e.ranges) : [], i = this.data.rangeOptions.map(function(n) {
            return Object.assign({}, n, {
                selected: a.find(function(t) {
                    return t[0] === n.min && t[1] === n.max;
                })
            });
        });
        this.rangesChanged(i), t.mercury.post("usedVessel/log", {
            action: "page_range_selector",
            result: e.source
        }), this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});