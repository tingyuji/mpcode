var e = require("../../../utils/env"), t = require("../../../utils/globalMap"), i = require("../../../utils/ajax");

Page({
    next: function() {
        var e = t.register(this.item), i = this.recharge ? "pay/pay" : "edit/edit";
        this.navigateNext = !0, wx.navigateTo({
            url: "../".concat(i, "?source=usedVesselFeeIntro&item=").concat(e, "&backStep=").concat(this.backStep, "&recharge=1")
        });
    },
    data: {
        topImageUrl: e.resource("mp/used_vessel_fee_top.jpg"),
        introImageUrl: e.resource("mp/used_vessel_fee_intro.jpg")
    },
    onLoad: function(e) {
        this.item = t.unRegister(e.item), this.backStep = (+e.backStep || 0) + 1;
        var a = this.item && this.item.id || 0;
        if (this.recharge = a > 0 && [ "publishing", "expired" ].indexOf(this.item.state) >= 0, 
        this.recharge) {
            var n = +this.item.length * +this.item.width * +this.item.depth, s = +this.item.price || 0, r = this.item.buildTime && new Date(this.item.buildTime).getFullYear() || 0, o = Math.max(0, Math.min(19, new Date().getFullYear() - r)), h = Math.round(.6 * n * .14 * (1 - .05 * o));
            (!s || s > 999999999 || s < h) && (this.recharge = !1);
        }
        i.mercury.post("usedVessel/log", {
            action: "page_fee_intro",
            id: a,
            result: e.source
        });
    },
    onReady: function() {},
    onShow: function() {
        this.navigateNext && wx.navigateBack();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});