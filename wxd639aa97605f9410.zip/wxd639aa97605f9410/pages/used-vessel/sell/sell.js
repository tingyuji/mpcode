var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../utils/util"), i = require("../../../utils/user"), n = require("../../../utils/ajax"), r = require("../../../utils/globalMap"), s = require("../../../dao/usedVesselSell"), o = require("../../../modules/spark-md5");

Page({
    bindMobile: function() {
        this.isLoginBack = !0, wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    goBack: function() {
        this.isShare ? wx.redirectTo({
            url: "/pages/home/home"
        }) : wx.navigateBack();
    },
    load: function(i, r) {
        var a = this;
        return !r && t.showLoading("获取数据中"), s.refresh().finally(function() {
            return r ? void 0 : t.hideLoading();
        }).then(function() {
            var t, n = s.get(), r = n.items.map(function(e) {
                return Object.assign({}, e);
            }), u = e(r);
            try {
                for (u.s(); !(t = u.n()).done; ) {
                    var c = t.value;
                    c.suggestions = [], c.isVisitValid && !c.isVisitExpired && c.visitable || c.suggestions.push("填写准确的看船地点和看船时间"), 
                    c.price ? c.highPrice && c.suggestions.push("填写合理的船舶报价(例如调低总价)") : c.suggestions.push("填写合理的船舶报价"), 
                    c.fewIntro && c.suggestions.push("在备注中详细介绍船舶信息(可参考样例)"), c.fewImage && c.suggestions.push("请上传多张清晰的船舶照片"), 
                    c.hash = o.hash(JSON.stringify(c));
                }
            } catch (e) {
                u.e(e);
            } finally {
                u.f();
            }
            a.autoCreate ? (a.autoCreate = !1, r.length || a.goBack()) : i && !r.length && (a.autoCreate = !0, 
            a.toPublish());
            var l = a.data.firstLoaded || r.length > 0;
            a.setData({
                sellInfo: n,
                items: r,
                firstLoaded: l
            });
        }).catch(function(e) {
            return n.showError("获取卖船信息", e).finally(function() {
                return a.goBack();
            });
        });
    },
    toPublish: function(e) {
        var t = this;
        this.deadbeatBlockModal.check("used_vessel_publish").then(function(i) {
            if (i) {
                var n = r.register(e || null);
                wx.navigateTo({
                    url: "../fee-intro/fee-intro?source=usedVesselSell&item=".concat(n)
                });
            } else t.data.items.length || t.goBack();
        });
    },
    toEdit: function(e) {
        var t = r.register(e || null);
        wx.navigateTo({
            url: "../edit/edit?source=usedVesselSell&item=".concat(t)
        });
    },
    editVisit: function(e) {
        var t = e.currentTarget.dataset.item;
        if (t && "draft" !== t.state) {
            var i = r.register(t || null);
            wx.navigateTo({
                url: "../edit-visit/edit-visit?source=usedVesselSell&item=".concat(i, "&action=edit")
            });
        }
    },
    remove: function(e) {
        var i = this, n = e.currentTarget.dataset.item;
        if ("publishing" === n.state) {
            t.confirm("删除后广告将不能被买家看到，如果您的船还没卖掉，不建议删除；\n调整广告内容请点击“修改广告”", {
                cancelText: "确认删除",
                confirmText: "修改广告"
            }).then(function() {
                return i.toEdit(n);
            }).catch(function() {
                return i.removeItem(n);
            });
        } else t.confirm("是否删除此卖船信息？").then(function() {
            return i.removeItem(n);
        });
    },
    removeItem: function(e) {
        var t = this, i = e && e.id || 0;
        return n.mercury.post("usedVessel/remove", {
            id: i
        }).then(function() {
            return t.load();
        }).catch(function(e) {
            return n.showError("删除卖船信息", e);
        });
    },
    edit: function(e) {
        var t = e.currentTarget.dataset.item;
        this.toEdit(t);
    },
    publish: function() {
        var e = this;
        this.getPreCreateInfo().then(function(i) {
            if (i) if (i.draft) {
                t.confirm("您当前有一条卖船信息草稿，是否继续编辑草稿？", {
                    cancelText: "删除草稿",
                    confirmText: "继续编辑"
                }).then(function() {
                    return e.toEdit(i.draft);
                }).catch(function() {
                    return e.removeItem(i.draft).then(function() {
                        return e.toPublish();
                    });
                });
            } else if (i.result) e.toPublish(); else {
                var r = "为了保障卖船信息的真实有效性，每个用户只能发布1条卖船信息。\n如果您有多条船需要出售，请联系客服4008030092";
                i.count > 1 && (r = "您当前只能创建" + i.count + "条卖船信息。\n如有更多船舶需要出售，请联系客服4008030092"), 
                t.confirm(r, {
                    cancelText: "暂不联系",
                    confirmText: "联系客服"
                }).then(function() {
                    n.mercury.post("usedVessel/log", {
                        action: "dail400",
                        target: "sell.create"
                    }), wx.makePhoneCall({
                        phoneNumber: "4008030092"
                    });
                });
            } else ;
        });
    },
    rechargeItem: function(e) {
        var t = e.currentTarget.dataset.item;
        this.toPublish(t);
    },
    publishItem: function(e) {
        var t = e.currentTarget.dataset.item;
        this.toPublish(t);
    },
    getPreCreateInfo: function() {
        return n.mercury.get("usedVessel/canCreate").catch(function(e) {
            return n.showError("获取卖船信息", e), null;
        });
    },
    data: {
        userId: 0,
        firstLoaded: !1,
        sellInfo: {
            items: [],
            toExtend: 0,
            toPublish: 0,
            showing: 0
        },
        items: []
    },
    onLoad: function(e) {
        var t = this;
        this.isShare = "share" === e.source, this.syncUserId = i.id.subscribeAndFireOnce(function(e) {
            return t.setData({
                userId: e
            });
        }), n.mercury.post("usedVessel/log", {
            action: "page_sell",
            result: e.source
        });
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        var e = this, t = !this.notFirstShow;
        this.notFirstShow = !0, i.id.get() ? (this.load(t), t || setTimeout(function() {
            return e.load(t, !0);
        }, 500)) : this.isLoginBack ? this.goBack() : this.bindMobile();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "吉船出售",
            path: t.sharePath({
                source: "share"
            })
        };
    }
});