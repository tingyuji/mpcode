var t = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), e = require("../common");

Page({
    introChange: function(t) {
        var i = t.detail.value || null;
        i !== this.data.intro && (this.data.intro = i, this.item.intro = i, e.saveItem(this.item));
    },
    prev: function() {
        wx.navigateBack();
    },
    next: function() {
        var t = i.register(this.item);
        wx.navigateTo({
            url: "../edit-image/edit-image?source=usedVesselEditIntro&item=".concat(t, "&action=").concat(this.action, "&backStep=").concat(this.backStep, "&recharge=").concat(this.recharge)
        });
    },
    data: {
        intro: null
    },
    onLoad: function(e) {
        this.item = i.unRegister(e.item), this.item.intro = this.item.intro || null, this.backStep = (+e.backStep || 0) + 1, 
        this.recharge = +e.recharge || 0, this.action = e.action;
        var n = "page_".concat(this.action, "_intro");
        t.mercury.post("usedVessel/log", {
            action: n,
            id: this.item.id,
            result: e.source
        }), this.setData({
            intro: this.item.intro
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});