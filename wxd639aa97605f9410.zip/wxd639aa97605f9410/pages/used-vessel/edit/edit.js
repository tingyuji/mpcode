var t = require("../../../modules/moment"), e = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), a = require("../../../utils/util"), n = require("../common"), r = require("../../../dao/usedVesselSell");

Page({
    lengthChange: function(t) {
        var e = +t.detail.value || null;
        e !== this.data.length && (this.data.length = e, this.valueChanged());
    },
    widthChange: function(t) {
        var e = +t.detail.value || null;
        e !== this.data.width && (this.data.width = e, this.valueChanged());
    },
    depthChange: function(t) {
        var e = +t.detail.value || null;
        e !== this.data.depth && (this.data.depth = e, this.valueChanged());
    },
    weightChange: function(t) {
        var e = +t.detail.value || null;
        e !== this.data.weight && (this.data.weight = e, this.valueChanged());
    },
    buildYearChange: function(t) {
        var e = +t.detail.value || null;
        e = e < this.data.yearRange.length ? Math.max(0, e) : 0;
        var i = +this.data.yearRange[e];
        i !== this.data.buildYear && (this.setData({
            buildYear: i,
            buildYearIndex: e
        }), this.valueChanged());
    },
    buildPlaceChange: function(t) {
        var e = t.detail.value || null;
        e !== this.data.buildPlace && (this.data.buildPlace = e, this.valueChanged());
    },
    priceChange: function(t) {
        var e = t.detail.value;
        e !== this.data.price && (this.data.price = e, this.valueChanged());
    },
    getPrice: function() {
        var t = +this.data.price || 0;
        return t >= 1e5 && t < 999999999 && (t /= 1e4), t;
    },
    valueChanged: function() {
        if ("draft" !== this.item.state) {
            if (!+this.data.length) return this.setData({
                length: this.item.length
            }), this.clearAlert("不能删除船舶长度");
            if (!+this.data.width) return this.setData({
                width: this.item.width
            }), this.clearAlert("不能删除船舶宽度");
            if (!+this.data.depth) return this.setData({
                depth: this.item.depth
            }), this.clearAlert("不能删除船舶型深");
            if (!+this.data.weight) return this.setData({
                weight: this.item.weight
            }), this.clearAlert("不能删除船舶实装吨位");
            if (!this.data.buildYear) {
                var e = this.item.buildTime ? t(this.item.buildTime) : null, i = e && e.isValid() ? e.year() : null, a = Math.max(0, this.data.yearRange.findIndex(function(t) {
                    return t === i;
                }));
                return this.setData({
                    buildYear: i,
                    buildYearIndex: a
                }), this.clearAlert("不能删除船舶建造时间");
            }
            if (null === this.data.price || void 0 === this.data.price || "" === this.data.price.toString().trim() || !Number.isFinite(+this.data.price)) return this.setData({
                price: this.item.price
            }), this.clearAlert("不能删除船舶总价");
            var n = this.checkPriceMsg();
            if (n) return this.setData({
                price: this.item.price
            }), this.clearAlert(n);
        }
        var r = (this.data.buildPlace || "").trim();
        r.length > 7 && (this.setData({
            buildPlace: r.slice(0, 7)
        }), this.clearAlert("船舶建造地点最多只能输入7个字")), this.item.length = +this.data.length || null, 
        this.item.width = +this.data.width || null, this.item.depth = +this.data.depth || null, 
        this.item.weight = +this.data.weight || null;
        var l = +this.data.buildYear || null;
        this.item.buildTime = l > 0 ? new Date("".concat(l, "-01-01")) : null, this.item.buildPlace = r || null, 
        this.item.price = this.getPrice() || null, this.trySaveItem();
    },
    trySaveItem: function() {
        var t = this;
        return n.saveItem(this.item).catch(function(e) {
            return r.refresh().then(function(i) {
                var a = i.find(function(t) {
                    return "draft" === t.state;
                });
                throw a && (t.item.id = a.id), e;
            });
        });
    },
    load: function(t) {
        var i = this;
        if (t) return a.showLoading("获取数据中"), r.refresh().finally(a.hideLoading).then(function() {
            i.item = r.get().items.find(function(e) {
                return e.id === t;
            }), i.item ? i.updateItem() : a.alert("未找到该条卖船信息").then(wx.navigateBack);
        }).catch(function(t) {
            return e.showError("获取卖船信息", t).finally(function() {
                return i.back();
            });
        });
        this.item = {
            state: "draft",
            medias: []
        }, this.updateItem();
    },
    updateItem: function() {
        if (this.item) {
            var e = this.item.buildTime ? t(this.item.buildTime) : null, i = e && e.isValid() ? e.year() : null, a = Math.max(0, this.data.yearRange.findIndex(function(t) {
                return t === i;
            }));
            this.setData({
                length: this.item.length || null,
                width: this.item.width || null,
                depth: this.item.depth || null,
                weight: this.item.weight || null,
                buildYear: i,
                buildYearIndex: a,
                buildPlace: this.item.buildPlace || null,
                price: this.item.price || null
            });
        }
    },
    clearAlert: function(t) {
        var e = this;
        this.backClicked || (this.clearAlerting = !0, "string" == typeof t ? a.alert(t).finally(function() {
            return e.clearAlerting = !1;
        }) : "function" == typeof t && t().finally(function() {
            return e.clearAlerting = !1;
        }));
    },
    checkPriceMsg: function() {
        var t = +this.data.length, i = +this.data.width, n = +this.data.depth, r = t * i * n, l = this.getPrice(), h = new Date().getFullYear() - (+this.data.buildYear || 0);
        h = Math.max(0, Math.min(19, h));
        var u = Math.round(.6 * r * .14 * (1 - .05 * h));
        if (null === this.data.price || void 0 === this.data.price || "" === this.data.price.toString().trim() || !Number.isFinite(l)) return function() {
            return a.alert("请填写船舶总价");
        };
        if (l > 999999999) return function() {
            return a.alert("您填写的船舶总价过高");
        };
        if (l < u) {
            var c = this.item && this.item.id || 0;
            return e.mercury.post("usedVessel/log", {
                action: "alert-price-low",
                id: c,
                note: {
                    length: t,
                    width: i,
                    depth: n,
                    price: l,
                    buildYear: this.data.buildYear
                }
            }), function() {
                return a.confirm("您填写的船舶总价过低，请咨询客服400-803-0092", {
                    cancelText: "取消",
                    confirmText: "拨打400"
                }).then(function() {
                    return a.dial400();
                }).catch(function() {});
            };
        }
    },
    back: function() {
        var t = this;
        this.backClicked = !0, this.clearAlerting ? setTimeout(function() {
            return t.back();
        }, 100) : wx.navigateBack({
            delta: this.backStep
        });
    },
    next: function() {
        var t = this;
        setTimeout(function() {
            if (!t.clearAlerting) {
                var n = +t.data.length, r = +t.data.width, l = +t.data.depth, h = +t.data.weight;
                if (!n) return a.alert("请填写船舶长度");
                if (!r) return a.alert("请填写船舶宽度");
                if (!l) return a.alert("请填写船舶型深");
                if (!h) return a.alert("请填写船舶实装吨位");
                if (!t.data.buildYear) return a.alert("请填写船舶建造时间");
                (function() {
                    var t = +(h / (n * r * l)).toFixed(2);
                    if (t > .85 || t < .6) {
                        var e = "您填写的船舶尺度为长".concat(n, "×宽").concat(r, "×深").concat(l, "，实装").concat(h, "吨，") + "通常情况下实装吨位 = 长×宽×深×0.7，您的系数为".concat(t, "，请确认信息是否填写正确");
                        return a.confirm(e, {
                            cancelText: "去修改",
                            confirmText: "确认无误"
                        }).then(function() {
                            return !0;
                        }).catch(function() {
                            return !1;
                        });
                    }
                    return Promise.resolve(!0);
                })().then(function(e) {
                    return !!e && function() {
                        var e = t.getPrice(), i = t.checkPriceMsg();
                        if (i) i(); else {
                            var n = Math.round(1e4 * e / h);
                            if (!(n > 3e3 || n < 300)) return !0;
                            var r = "您填写的价格信息".concat(e, "万元可能有误，请注意船舶总价的单位为万元");
                            a.confirm(r, {
                                cancelText: "去修改",
                                confirmText: "确认无误"
                            });
                        }
                    }();
                }).then(function(a) {
                    a && t.trySaveItem().then(function() {
                        var e = i.register(t.item);
                        wx.navigateTo({
                            url: "../edit-intro/edit-intro?source=usedVesselEdit&item=".concat(e, "&action=").concat(t.action, "&backStep=").concat(t.backStep, "&recharge=").concat(t.recharge)
                        });
                    }).catch(function(t) {
                        return e.showError("保存卖船信息", t);
                    });
                });
            }
        });
    },
    data: {
        length: null,
        width: null,
        depth: null,
        weight: null,
        buildYear: null,
        buildYearIndex: 0,
        buildPlace: null,
        price: null,
        yearRange: new Array(30).fill(0).map(function(e, i) {
            return t().year() - i;
        })
    },
    onLoad: function(t) {
        var a = t.item ? i.unRegister(t.item) : null, n = a && a.id || 0;
        this.backStep = (+t.backStep || 0) + 1, this.recharge = +t.recharge || 0, this.action = a && "draft" !== a.state ? "edit" : "publish";
        var r = "page_".concat(this.action);
        e.mercury.post("usedVessel/log", {
            action: r,
            id: n,
            result: t.source
        }), this.load(n);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.backClicked = !0;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});