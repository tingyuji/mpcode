var e = require("../../../utils/util"), t = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), a = (require("../../../dao/usedVesselSell"), 
"used_vessel_publish_resize_canvas");

Page({
    upload: function() {
        var e = this;
        wx.showActionSheet({
            itemList: [ "拍照", "从手机相册选择" ],
            success: function(t) {
                t.cancel || e.chooseImage(t.tapIndex);
            }
        });
    },
    chooseImage: function(e) {
        var t = this;
        wx.chooseImage({
            sizeType: [ "original" ],
            sourceType: [ 0 === e ? "camera" : "album" ],
            count: 1,
            success: function(e) {
                return t.uploadImage(e.tempFilePaths[0], t.data.width, t.data.height);
            }
        });
    },
    uploadImage: function(i, a, n) {
        var s = this;
        this.resizeImage(i, a, n).then(function(i) {
            s.setData({
                uploading: !0,
                uploadProgress: 0
            }), e.showLoading("上传照片中"), t.mercury.upload("usedVessel/uploadMedia", i, "image/jpeg", {
                id: s.data.item.id,
                suffix: "jpg"
            }, null, {
                onProgress: function(e) {
                    return s.setData({
                        uploadProgress: e.progress
                    });
                }
            }).finally(function() {
                s.setData({
                    uploading: !1
                }), e.hideLoading();
            }).then(function(e) {
                s.setData({
                    imageUrl: e.url
                }), s.recognize(e);
            }).catch(function(e) {
                return t.showError("上传照片", e);
            });
        }).catch(function(t) {
            return e.alert("修改照片尺寸失败");
        });
    },
    resizeImage: function(t, i, n, s, o, r) {
        var h = this;
        return new Promise(function(u, c) {
            e.showLoading("处理照片中"), h.setData({
                hideResizing: !1
            }), setTimeout(function() {
                wx.getImageInfo({
                    src: t,
                    success: function(e) {
                        if (e.width <= i && e.height <= n) u(e.path); else {
                            var t = wx.createCanvasContext(a), d = 0, l = 0, g = i, f = n, p = i / e.width, m = n / e.height;
                            switch (s) {
                              case "pad":
                                var w = Math.min(p, m);
                                g = Math.round(e.width * w), f = Math.round(e.height * w), h.setData({
                                    width: g,
                                    height: f
                                }), t.drawImage(e.path, 0, 0, g, f);
                                break;

                              case "fit":
                                var v = Math.max(p, m), x = Math.round(e.width * v), y = Math.round(e.height * v);
                                h.setData({
                                    width: x,
                                    height: y
                                }), t.drawImage(e.path, 0, 0, x, y), d = Math.floor((x - g) / 2), l = Math.floor((y - f) / 2);
                                break;

                              case "fill":
                              default:
                                h.setData({
                                    width: i,
                                    height: n
                                }), t.drawImage(e.path, 0, 0, i, n);
                            }
                            t.draw(!1, function() {
                                wx.canvasToTempFilePath({
                                    canvasId: a,
                                    x: d,
                                    y: l,
                                    width: g,
                                    height: f,
                                    destWidth: g,
                                    destHeight: f,
                                    fileType: o || "jpg",
                                    quality: r || .9,
                                    success: function(e) {
                                        return u(e.tempFilePath);
                                    },
                                    fail: c
                                });
                            });
                        }
                    },
                    fail: c
                });
            }, 100);
        }).finally(function() {
            e.hideLoading(), h.setData({
                hideResizing: !0
            });
        });
    },
    recognize: function(i) {
        var a = this;
        e.showLoading("识别照片中");
        var n = {
            id: this.data.item.id,
            hash: i.hash,
            suffix: i.suffix
        };
        t.mercury.post("usedVessel/recognizeCert", n).finally(e.hideLoading).then(function(i) {
            if (i) a.refresh(); else {
                e.confirm("您的船舶大簿子未通过检测，无法为您发布卖船信息，请联系客服4008030092", {
                    cancelText: "联系客服",
                    confirmText: "重新上传"
                }).then(function() {
                    return a.upload();
                }).catch(function() {
                    t.mercury.post("usedVessel/log", {
                        action: "dail400",
                        target: "publish.cert_fail"
                    }), e.dial400();
                });
            }
        }).catch(function(e) {
            return t.showError("识别大簿子照片", e);
        });
    },
    refresh: function() {
        var i = this;
        return e.showLoading("查询中"), t.mercury.get("usedVessel/canPublish").then(function() {
            return i.next();
        }).finally(e.hideLoading).catch(function(e) {
            return t.showError("查询发布条件", e);
        });
    },
    next: function() {
        var e = i.register(this.item), t = "publishing" === this.item.state ? "edit-publish/edit-publish" : "pay/pay";
        this.navigteNext = !0, wx.navigateTo({
            url: "../".concat(t, "?source=usedVesselCertify&item=").concat(e, "&backStep=").concat(this.backStep)
        });
    },
    data: {
        imageUrl: "",
        uploading: !1,
        uploadProgress: 0,
        resizeCanvasId: a,
        width: 1280,
        height: 1280,
        hideResizing: !0
    },
    onLoad: function(e) {
        this.item = i.unRegister(e.item), this.backStep = (+e.backStep || 0) + 1, t.mercury.post("usedVessel/log", {
            action: "page_certify_vessel",
            id: this.item.id,
            result: e.source
        }), this.refresh();
    },
    onReady: function() {},
    onShow: function() {
        this.navigteNext && wx.navigateBack();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});