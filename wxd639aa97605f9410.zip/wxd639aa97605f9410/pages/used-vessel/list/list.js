var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), s = require("../../../utils/util"), r = require("../../../utils/ajax"), n = require("../../../utils/env"), a = require("../../../utils/globalMap"), i = require("../common"), o = require("../../../dao/usedVesselSell"), l = {
    comprehensive: "综合排序",
    publishTimeDesc: "最新发布",
    priceAsc: "总价最低",
    priceDesc: "总价最高",
    unitPriceAsc: "单价最低",
    unitPriceDesc: "单价最高",
    ageAsc: "船龄最短",
    ageDesc: "船龄最长"
};

Page({
    updateTopFloatBarHeight: function(e) {
        var t = this;
        e > 0 && wx.createSelectorQuery().in(this).select(".top-float-bar").boundingClientRect(function(s) {
            t.setData({
                topFloatBarHeight: s.height
            }), setTimeout(function() {
                return t.updateTopFloatBarHeight(e - 1);
            }, 500);
        }).exec();
    },
    loadRanges: function() {
        this.ranges = wx.getStorageSync("used_vessel.ranges") || [], this.ranges.length || (this.ranges = i.range_options.map(function(e) {
            return [ e.min, e.max ];
        })), this.updateRanges();
    },
    saveRanges: function(e) {
        this.ranges = e || [], this.ranges.length || (this.ranges = i.range_options.map(function(e) {
            return [ e.min, e.max ];
        })), wx.setStorage({
            key: "used_vessel.ranges",
            data: this.ranges
        }), this.updateRanges();
    },
    updateRanges: function() {
        var e, s = [], r = t(this.ranges);
        try {
            for (r.s(); !(e = r.n()).done; ) {
                var n = e.value, a = s[s.length - 1];
                a && a[1] === n[0] ? a[1] = n[1] : s.push(n.slice());
            }
        } catch (e) {
            r.e(e);
        } finally {
            r.f();
        }
        var i = s.map(function(e) {
            return e[0] ? e[1] ? "".concat(e[0], "~").concat(e[1]) : "".concat(e[0], "以上") : "".concat(e[1], "以下");
        });
        1 !== s.length || s[0][0] || s[0][1] || (i = [ "全部吨位" ]), this.setData({
            rangesTitle: i
        }), this.updateTopFloatBarHeight(20);
    },
    editRanges: function() {
        var e = this, t = a.register(this.ranges), s = a.register(function(t) {
            e.saveRanges(t), r.mercury.post("usedVessel/log", {
                action: "select_ranges",
                result: e.data.rangesTitle.join()
            }), e.refresh();
        });
        wx.navigateTo({
            url: "../ranges/ranges?source=usedVesselList&ranges=".concat(t, "&callback=").concat(s)
        });
    },
    orderTypeChange: function(e) {
        var t = +e.detail.value || 0, s = Object.getOwnPropertyNames(l);
        t = t < s.length ? Math.max(0, t) : 0, this.orderType = s[t], this.setData({
            orderTypeIndex: t,
            orderTypeDesc: l[this.orderType]
        }), r.mercury.post("usedVessel/log", {
            action: "select_order_type",
            id: this.orderType,
            result: this.data.orderTypeDesc
        }), this.refresh();
    },
    refresh: function() {
        return wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        }), this.itemTotal = 0, this.items = [], o.refresh(), this.load(0);
    },
    load: function(t) {
        var n = this;
        return this.data.loading ? Promise.resolve() : (s.showLoading("获取数据中"), this.setData({
            loading: !0
        }), r.mercury.post("usedVessel/search", {
            ranges: this.ranges,
            orderType: this.orderType,
            start: t || 0,
            limit: 15
        }).finally(function() {
            n.setData({
                loading: !1
            }), s.hideLoading();
        }).then(function(t) {
            var s, r = t.items;
            r.forEach(function(e) {
                i.fixItem(e), e.seen > 3 ? e.seenText = "以前看过" : 3 === e.seen ? e.seenText = "前天看过" : 2 === e.seen ? e.seenText = "昨天看过" : 1 === e.seen ? e.seenText = "今天看过" : e.seenText = "";
            }), n.items.length > t.start && n.items.splice(t.start), (s = n.items).push.apply(s, e(r)), 
            n.itemTotal = t.total;
            var a = n.items.length >= n.itemTotal, o = n.getItemsWithAd();
            n.setData({
                searchEnd: a,
                itemsWithAd: o
            });
        }).catch(function(e) {
            return r.showError("获取吉船出售信息", e);
        }));
    },
    getItemsWithAd: function() {
        var e, s = [], r = 0, n = !0, a = t(this.items);
        try {
            for (a.s(); !(e = a.n()).done; ) {
                var i = e.value;
                s.push(Object.assign({}, i, {
                    type: "content"
                })), i.guess && n && s.push({
                    type: "first_guess"
                }), n = n && !i.guess, ++r % 5 == 0 && (r % 10 == 0 ? s.push({
                    type: "ad_intro"
                }) : s.push({
                    type: "ad_sell"
                }));
            }
        } catch (e) {
            a.e(e);
        } finally {
            a.f();
        }
        return s.forEach(function(e, t) {
            return e.key = "".concat(e.type, ":").concat(e.id || t + 1);
        }), s;
    },
    toSell: function(e) {
        var t = e.currentTarget.dataset.source;
        wx.navigateTo({
            url: "../sell/sell?source=usedVesselList" + (t ? "_" + t : "")
        });
    },
    toEditVisit: function() {
        var e = a.register(this.data.sellInfo.visitAlertItem || null);
        wx.navigateTo({
            url: "./edit-visit/edit-visit?source=usedVesselList&item=".concat(e, "&action=edit")
        });
    },
    data: {
        topFloatBarHeight: 39,
        introImage: n.resource("mp/used-vessel-list-advert.jpg"),
        rangesTitle: [],
        orderTypeIndex: 0,
        orderTypeDesc: "综合排序",
        orderTypeOptions: Object.getOwnPropertyNames(l).map(function(e) {
            return l[e];
        }),
        loading: !1,
        searchEnd: !1,
        pullDown: !1,
        itemsWithAd: [],
        sellInfo: {
            items: []
        }
    },
    onLoad: function(e) {
        var t = this;
        this.syncSellInfo = o.subscribeAndFireOnce(function(e) {
            return t.setData({
                sellInfo: e
            });
        }), this.source = e.source, this.orderType = "comprehensive", this.ranges = [], 
        r.mercury.post("usedVessel/log", {
            action: "page_list",
            result: this.source
        }), this.loadRanges(), this.refresh();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncSellInfo.dispose();
    },
    onPullDownRefresh: function() {
        var e = this;
        this.setData({
            pullDown: !0
        }), this.refresh().finally(function() {
            wx.stopPullDownRefresh(), e.setData({
                pullDown: !1
            });
        });
    },
    onReachBottom: function() {
        this.data.searchEnd || this.load(this.items.length);
    },
    onShareAppMessage: function() {
        return {
            title: "吉船出售",
            path: s.sharePath({
                source: "share"
            })
        };
    }
});