var e = require("../../../utils/env"), t = require("../../../utils/ajax"), i = require("../../../utils/util"), s = require("../common");

Page({
    load: function(e) {
        var a = this;
        return i.showLoading("获取数据中"), t.mercury.get("usedVessel/detail", {
            id: e
        }).finally(i.hideLoading).then(function(e) {
            var t = s.fixItem(e), i = t.contactMobile || "";
            i = i.slice(0, 3) + "****" + i.slice(6), a.setData({
                vessel: t,
                contactMobile: i
            });
        }).catch(function(e) {
            return t.showError("获取卖船信息详情", e).finally(wx.navigateBack);
        });
    },
    contact: function() {
        var e = this, i = this.data.vessel.contactMobile;
        this.setData({
            contactMobile: i
        }), t.mercury.post("usedVessel/dial", {
            id: this.itemId,
            mobile: i
        }), wx.makePhoneCall({
            phoneNumber: i
        }), setTimeout(function() {
            return e.feedback.showModal();
        }, 500);
    },
    onFeedback: function(e) {
        var i = e.currentTarget.dataset.feedback;
        t.mercury.post("usedVessel/feedback", {
            id: this.itemId,
            feedback: i
        }), this.feedback.hideModal();
    },
    enlarge: function(e) {
        var t = e.currentTarget.dataset.item, i = this.data.vessel.medias.map(function(e) {
            return e.url;
        }), s = Math.max(0, i.findIndex(function(e) {
            return e === t.url;
        }));
        wx.previewImage({
            current: i[s],
            urls: i
        });
    },
    toUsedVesselMain: function() {
        wx.navigateTo({
            url: "../sell/sell?source=usedVesselDetail"
        });
    },
    data: {
        topAdvertLink: null,
        vessel: null,
        contactMobile: ""
    },
    onLoad: function(i) {
        this.itemId = +i.id || 0, t.mercury.post("usedVessel/log", {
            action: "page_detail",
            id: this.itemId,
            result: i.source
        });
        var s = i.source && i.source.startsWith("usedVessel") ? "" : e.resource("mp/used_vessel_detail_top.jpg");
        this.setData({
            topAdvertLink: s
        }), this.load(this.itemId);
    },
    onReady: function() {
        this.feedback = this.selectComponent("#feedback-modal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "吉船出售",
            path: i.sharePath({
                id: this.itemId,
                source: "share"
            })
        };
    }
});