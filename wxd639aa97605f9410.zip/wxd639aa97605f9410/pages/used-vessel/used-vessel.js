var e = require("../../utils/env"), t = require("../../utils/util"), o = require("../../utils/globalMap"), s = require("../../utils/ajax"), i = require("../../dao/usedVesselSell"), n = require("./common");

Page({
    updateTopFloatBarHeight: function(e) {
        var t = this;
        e > 0 && wx.createSelectorQuery().in(this).select(".top-float-bar").boundingClientRect(function(o) {
            t.setData({
                topFloatBarHeight: o.height
            }), setTimeout(function() {
                return t.updateTopFloatBarHeight(e - 1);
            }, 500);
        }).exec();
    },
    refresh: function() {
        return wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        }), this.load();
    },
    load: function() {
        var e = this;
        return this.data.loading ? Promise.resolve() : (t.showLoading("获取数据中"), this.setData({
            loading: !0
        }), i.refresh().then(function() {
            return s.mercury.get("usedVessel/recommendations");
        }).finally(function() {
            e.setData({
                loading: !1
            }), t.hideLoading();
        }).then(function(t) {
            t.forEach(function(e) {
                return n.fixItem(e);
            }), e.setData({
                items: t
            });
        }).catch(function(e) {
            return s.showError("获取今日吉船推荐", e);
        }));
    },
    toSell: function() {
        wx.navigateTo({
            url: "./sell/sell?source=usedVessel_toSell"
        });
    },
    toSell_expired: function() {
        wx.navigateTo({
            url: "./sell/sell?source=usedVessel_expired"
        });
    },
    toSell_toExtend: function() {
        wx.navigateTo({
            url: "./sell/sell?source=usedVessel_toExtend"
        });
    },
    toSell_toPublish: function() {
        wx.navigateTo({
            url: "./sell/sell?source=usedVessel_toPublish"
        });
    },
    toSell_toDetail: function() {
        wx.navigateTo({
            url: "./sell/sell?source=usedVessel_toDetail"
        });
    },
    toBuy: function() {
        wx.navigateTo({
            url: "./list/list?source=usedVessel_toBuy"
        });
    },
    more: function() {
        wx.navigateTo({
            url: "./list/list?source=usedVessel_more"
        });
    },
    toEditVisit: function() {
        var e = o.register(this.data.sellInfo.visitAlertItem || null);
        wx.navigateTo({
            url: "./edit-visit/edit-visit?source=usedVessel&item=".concat(e, "&action=edit")
        });
    },
    data: {
        advertImage: e.resource("mp/used_vessel_advert.jpg"),
        topFloatBarHeight: 156,
        items: [],
        sellInfo: {
            items: []
        },
        loading: !1
    },
    onLoad: function(e) {
        var t = this;
        this.syncSellInfo = i.subscribeAndFireOnce(function(e) {
            return t.setData({
                sellInfo: e
            });
        }), s.mercury.post("usedVessel/log", {
            action: "page_main",
            result: e.source
        }), this.load();
    },
    onReady: function() {
        this.updateTopFloatBarHeight(20);
    },
    onShow: function() {
        var e = !this.notFirstShow;
        this.notFirstShow = !0, e || this.load();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncSellInfo.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh().finally(function() {
            return wx.stopPullDownRefresh();
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "吉船出售",
            path: t.sharePath({
                source: "share"
            })
        };
    }
});