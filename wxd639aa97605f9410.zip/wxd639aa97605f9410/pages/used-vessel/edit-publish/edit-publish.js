var t = require("../../../utils/globalMap"), e = require("../../../utils/ajax"), n = require("../../../utils/util"), i = require("../../../dao/usedVesselSell");

Page({
    refresh: function(t) {
        var a = this;
        return t && (n.showLoading("发布中"), this.setData({
            loading: !0
        })), i.refresh().then(function() {
            var t = i.get().items.find(function(t) {
                return t.id === a.data.item.id;
            });
            t && a.setData({
                item: t
            }), "publishing" !== (t && t.state) && setTimeout(function() {
                return a.refresh(!1);
            }, 500);
        }).finally(function() {
            t && (a.setData({
                loading: !1
            }), n.hideLoading());
        }).catch(function(t) {
            return e.showError("刷新卖船信息", t).then(function() {
                return wx.navigateBack();
            });
        });
    },
    done: function() {
        wx.navigateBack({
            delta: this.backStep
        });
    },
    data: {
        loading: !1,
        item: 0,
        actionText: "发布"
    },
    onLoad: function(n) {
        var i = t.unRegister(n.item);
        this.backStep = (+n.backStep || 0) + 1;
        var a = "publishing" === i.state ? "edit" : "publish";
        this.setData({
            actionText: "publishing" === i.state ? "修改" : "发布"
        }), e.mercury.post("usedVessel/log", {
            action: "page_".concat(a, "_result"),
            id: i.id,
            result: n.source
        }), this.setData({
            item: i
        }), this.refresh(!0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});