var t = require("../../../utils/globalMap"), e = require("../../../utils/ajax"), i = require("../../../utils/util");

Page({
    init: function() {
        var t = this;
        i.showLoading("获取信息中"), e.mercury.get("usedVessel/payOption", {
            id: this.itemId
        }).finally(i.hideLoading).then(function(e) {
            t.setData({
                price: e.price,
                voucher: e.voucher,
                payAmount: e.price - e.voucher
            });
        }).catch(function(t) {
            return e.showError("获取付费信息", t).then(wx.navigateBack);
        });
    },
    pay: function() {
        var t = this;
        this.paying || (e.mercury.post("usedVessel/log", {
            action: "click_pay",
            id: this.itemId || null,
            result: this.data.payAmount,
            note: {
                id: this.itemId,
                price: this.data.price,
                voucher: this.data.voucher
            }
        }), this.paying = !0, this.doPay().finally(function() {
            return t.paying = !1;
        }));
    },
    doPay: function() {
        var t = this;
        return i.showLoading("准备支付中"), e.mercury.post("usedVessel/payInfo", {
            id: this.itemId
        }).finally(i.hideLoading).then(function(e) {
            var n = e.payInfo;
            return new Promise(function(t, e) {
                wx.requestPayment({
                    timeStamp: n.timeStamp.toString(),
                    nonceStr: n.nonceStr,
                    package: n.package,
                    signType: n.signType,
                    paySign: n.paySign,
                    success: t,
                    fail: e
                });
            }).then(function() {
                return t.onPayDone(e.orderId);
            }).catch(function(t) {
                var e = t.errMsg.indexOf("fail"), n = t.errMsg.slice(e + 4).trim();
                "cancel" !== n && i.alert("付款失败，" + n);
            });
        }).catch(function(t) {
            return e.showError("获取支付信息", t);
        });
    },
    onPayDone: function(t) {
        var n = this;
        return i.showLoading("获取结果中"), e.mercury.get("usedVessel/payStatus", {
            orderId: t
        }).finally(i.hideLoading).then(function(i) {
            "USED" !== i && "BOUGHT" !== i || (e.mercury.post("usedVessel/log", {
                action: "pay_done",
                id: n.itemId || null,
                result: t,
                note: {
                    id: n.itemId,
                    price: n.data.price,
                    voucher: n.data.voucher
                }
            }), n.next());
        }).catch(function(t) {
            return e.showError("获取支付结果", t);
        });
    },
    next: function() {
        var e = t.register(this.item);
        this.navigateNext = !0, wx.navigateTo({
            url: "../edit-publish/edit-publish?source=usedVesselPay&item=".concat(e, "&backStep=").concat(this.backStep)
        });
    },
    data: {
        isIOS: i.isIOS(),
        vesselPrice: 0,
        price: 0,
        payAmount: 0,
        voucher: 0,
        paying: !1
    },
    onLoad: function(i) {
        this.item = t.unRegister(i.item), this.backStep = (+i.backStep || 0) + 1, this.source = i.source, 
        this.itemId = this.item && this.item.id || 0, e.mercury.post("usedVessel/log", {
            action: "page_pay",
            id: this.itemId,
            result: this.source
        });
        var n = this.item && this.item.price || 0, a = Math.min(400, Math.max(50, Math.floor(n || 0)));
        this.setData({
            vesselPrice: n,
            price: a,
            voucher: 0
        }), this.init();
    },
    onReady: function() {},
    onShow: function() {
        this.navigateNext && wx.navigateBack({
            delta: this.backStep
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});