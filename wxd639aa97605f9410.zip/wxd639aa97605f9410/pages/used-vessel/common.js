var e = require("../../utils/ajax"), i = require("../../modules/moment");

var t = !1;

function a(i) {
    return e.mercury.post("usedVessel/update", i);
}

module.exports.fixItem = function(e) {
    if (e) {
        if (e.publishTime = e.publishTime ? new Date(e.publishTime) : null, e.buildTime = e.buildTime ? new Date(e.buildTime) : null, 
        e.buildYear = e.buildTime ? e.buildTime.getFullYear() : null, e.price = Number.isFinite(e.price) ? e.price : null, 
        e.pricePerTon = e.weight && e.price ? Math.round(1e4 * e.price / e.weight) : null, 
        e.remainDuration = e.expireDays + "天", 0 === e.expireDays && "publishing" === e.state) {
            var t = Math.max(1, i(e.expireTime).diff(i(), "minute"));
            e.remainDuration = t >= 60 ? Math.floor(t / 60) + "小时" : t + "分钟";
        }
        e.medias = e.medias || [];
        for (var a = -1, r = function() {
            var i = u[n];
            if ((a = e.medias.findIndex(function(e) {
                return e.title === i;
            })) >= 0) return "break";
        }, n = 0, u = [ "船舶侧面照", "船头照片", "船尾照片", "驾驶室照片" ]; n < u.length; n++) {
            if ("break" === r()) break;
        }
        a <= 0 && e.medias.length > 0 && (a = Math.floor(Math.random() * e.medias.length) % e.medias.length), 
        e.avatarImageUrl = a >= 0 ? e.medias[a].thumbnailUrl : "/images/no-upload-photo.png";
        var l = e.isVisitValid && e.visitable;
        e.visitDateDesc = l ? function(e) {
            var t = i(e.visitBeginDate).startOf("day"), a = i(e.visitEndDate).startOf("day"), r = t.format("YYYY-MM") === a.format("YYYY-MM"), n = t.format("M月D日");
            if (t.valueOf() === a.valueOf()) return n;
            var u = a.format(r ? "D日" : "M月D日");
            return "".concat(n, "~").concat(u);
        }(e) : "", e.visitPlaceDesc = l ? "".concat(e.visitPlace, "可看船") : "", e.visitDateShortDesc = l && !e.isVisitExpired ? function(e) {
            var t = i(e.visitBeginDate).startOf("day").valueOf(), a = i(e.visitEndDate).startOf("day").valueOf(), r = i().startOf("day").valueOf();
            if (r > t) {
                if (!(a >= r)) return "不可";
                t = r;
            }
            return t === r ? "今天" : t === i(r).add(1, "day").valueOf() ? "明天" : t === i(r).add(2, "day").valueOf() ? "后天" : i(t).format("D号");
        }(e) + "看船" : "", e.visitDesc = l ? "".concat(e.visitDateDesc).concat(e.visitPlaceDesc, "，") : "";
    }
    return e;
}, module.exports.saveItem = function i(r) {
    return t ? new Promise(function(e) {
        return setTimeout(function() {
            return e(i(r));
        }, 500);
    }) : (t = !0, r.id ? a(r).finally(function() {
        return t = !1;
    }) : e.mercury.post("usedVessel/newDraft").then(function(e) {
        return r.id = e, a(r);
    }).finally(function() {
        return t = !1;
    }));
}, module.exports.range_options = [ {
    min: 0,
    max: 500,
    title: "500吨以下"
}, {
    min: 500,
    max: 1e3,
    title: "500~1000吨"
}, {
    min: 1e3,
    max: 2e3,
    title: "1000~2000吨"
}, {
    min: 2e3,
    max: 3e3,
    title: "2000~3000吨"
}, {
    min: 3e3,
    max: 4e3,
    title: "3000~4000吨"
}, {
    min: 4e3,
    max: 5e3,
    title: "4000~5000吨"
}, {
    min: 5e3,
    max: 6e3,
    title: "5000~6000吨"
}, {
    min: 6e3,
    max: 1e4,
    title: "6000~10000吨"
}, {
    min: 1e4,
    max: 0,
    title: "10000吨以上"
} ];