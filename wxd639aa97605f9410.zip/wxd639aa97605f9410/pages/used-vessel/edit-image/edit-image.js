var t = require("../../../utils/globalMap"), e = require("../../../utils/ajax"), a = require("../../../utils/util"), i = require("../common"), n = [ "驾驶室照片", "船舱照片", "轮机室照片", "船头照片", "船舶侧面照", "船尾照片", "室内装修", "自选照片-1", "自选照片-2" ], s = function(t) {
    return {
        index: t,
        title: n[t],
        hash: null,
        url: "/images/upload-photo.png",
        thumbnailUrl: "/images/upload-photo.png"
    };
};

Page({
    save: function() {
        this.item.medias = this.data.medias.map(function(t) {
            return {
                title: t.title,
                hash: t.hash,
                url: t.url,
                thumbnailUrl: t.thumbnailUrl
            };
        }).filter(function(t) {
            return t.hash;
        }), i.saveItem(this.item);
    },
    prev: function() {
        wx.navigateBack();
    },
    remove: function(t) {
        var e = this, i = t.currentTarget.dataset.item;
        i && i.hash && a.confirm("确定要删除这个图片吗？").then(function() {
            var t = i.index;
            e.data.medias[t] = s(t), e.setData({
                medias: e.data.medias
            }), e.save();
        });
    },
    next: function() {
        var e = t.register(this.item);
        wx.navigateTo({
            url: "../edit-visit/edit-visit?source=usedVesselEditImage&item=".concat(e, "&action=").concat(this.action, "&backStep=").concat(this.backStep, "&recharge=").concat(this.recharge)
        });
    },
    upload: function(t) {
        var e = this, a = t.currentTarget.dataset.item;
        a && a.index >= 0 && wx.showActionSheet({
            itemList: [ "拍照", "从手机相册选择" ],
            success: function(t) {
                t.cancel || e.chooseImage(a.index, t.tapIndex);
            }
        });
    },
    chooseImage: function(t, e) {
        var a = this;
        wx.chooseImage({
            sizeType: [ "original" ],
            sourceType: [ 0 === e ? "camera" : "album" ],
            count: 1,
            success: function(e) {
                return a.uploadImage(t, e.tempFilePaths[0], a.data.width, a.data.height);
            }
        });
    },
    uploadImage: function(t, i, n, s) {
        var o = this;
        this.resizeImage(i, n, s).then(function(i) {
            o.setData({
                uploading: !0,
                uploadProgress: 0
            }), a.showLoading("上传照片中"), e.mercury.upload("usedVessel/uploadMedia", i, "image/jpeg", {
                id: o.item.id,
                suffix: "jpg"
            }, null, {
                onProgress: function(t) {
                    return o.setData({
                        uploadProgress: t.progress
                    });
                }
            }).finally(function() {
                o.setData({
                    uploading: !1
                }), a.hideLoading();
            }).then(function(e) {
                Object.assign(o.data.medias[t], e), o.setData({
                    medias: o.data.medias
                }), o.save();
            }).catch(function(t) {
                return e.showError("上传照片", t);
            });
        }).catch(function(t) {
            return a.alert("修改照片尺寸失败");
        });
    },
    resizeImage: function(t, e, i, n, s, o) {
        var r = this;
        return new Promise(function(h, u) {
            a.showLoading("处理照片中"), r.setData({
                hideResizing: !1
            }), setTimeout(function() {
                wx.getImageInfo({
                    src: t,
                    success: function(t) {
                        if (t.width <= e && t.height <= i) h(t.path); else {
                            var a = wx.createCanvasContext("used_vessel_resize_canvas"), c = 0, d = 0, l = e, g = i, m = e / t.width, f = i / t.height;
                            switch (n) {
                              case "pad":
                                var p = Math.min(m, f);
                                l = Math.round(t.width * p), g = Math.round(t.height * p), r.setData({
                                    width: l,
                                    height: g
                                }), a.drawImage(t.path, 0, 0, l, g);
                                break;

                              case "fit":
                                var v = Math.max(m, f), w = Math.round(t.width * v), x = Math.round(t.height * v);
                                r.setData({
                                    width: w,
                                    height: x
                                }), a.drawImage(t.path, 0, 0, w, x), c = Math.floor((w - l) / 2), d = Math.floor((x - g) / 2);
                                break;

                              case "fill":
                              default:
                                r.setData({
                                    width: e,
                                    height: i
                                }), a.drawImage(t.path, 0, 0, e, i);
                            }
                            a.draw(!1, function() {
                                wx.canvasToTempFilePath({
                                    canvasId: "used_vessel_resize_canvas",
                                    x: c,
                                    y: d,
                                    width: l,
                                    height: g,
                                    destWidth: l,
                                    destHeight: g,
                                    fileType: s || "jpg",
                                    quality: o || .9,
                                    success: function(t) {
                                        return h(t.tempFilePath);
                                    },
                                    fail: u
                                });
                            });
                        }
                    },
                    fail: u
                });
            }, 100);
        }).finally(function() {
            a.hideLoading(), r.setData({
                hideResizing: !0
            });
        });
    },
    data: {
        medias: [],
        uploading: !1,
        uploadProgress: 0,
        resizeCanvasId: "used_vessel_resize_canvas",
        width: 1280,
        height: 1280,
        hideResizing: !0
    },
    onLoad: function(a) {
        var i = this;
        this.item = t.unRegister(a.item), this.backStep = (+a.backStep || 0) + 1, this.recharge = +a.recharge || 0, 
        this.action = a.action;
        var o = "page_".concat(this.action, "_image");
        e.mercury.post("usedVessel/log", {
            action: o,
            id: this.item.id,
            result: a.source
        });
        var r = "发布";
        "expired" === this.item.state ? r = "重新发布" : "publishing" === this.item.state && (r = "完成");
        var h = new Array(9).fill(0).map(function(t, e) {
            return Object.assign(s(e), i.item.medias.find(function(t) {
                return t.title === n[e];
            }));
        });
        this.setData({
            publishAction: r,
            medias: h
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});