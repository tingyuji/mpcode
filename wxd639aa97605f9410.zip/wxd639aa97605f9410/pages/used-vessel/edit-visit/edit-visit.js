var t = require("../../../utils/globalMap"), i = require("../../../utils/ajax"), e = require("../../../modules/moment"), a = require("../../../dao/usedVesselSell"), s = require("../common"), n = require("../../../utils/util"), r = require("../../../utils/user");

Page({
    mayVisit: function() {
        this.setData({
            visitable: !0
        }), this.valueChanged();
    },
    mayNotVisit: function() {
        this.setData({
            visitable: !1
        }), this.valueChanged();
    },
    prev: function() {
        wx.navigateBack();
    },
    validatePlace: function() {
        return this.setData({
            visitPlace: this.data.visitPlace && this.data.visitPlace.trim() || ""
        }), this.data.visitPlace ? this.data.visitPlace.length > 3 ? (n.alert("看船地点最多只能输入三个字"), 
        Promise.resolve(!1)) : i.mercury.get("usedVessel/isPortName?name=" + this.data.visitPlace).then(function(t) {
            return t || n.alert("看船地点请输入港口名"), !!t;
        }).catch(function(t) {
            return i.showError("获取卖船信息", t), !1;
        }) : (n.alert("请填写看船地点"), Promise.resolve(!1));
    },
    validate: function() {
        var t = this;
        return this.data.visitable ? this.validatePlace().then(function(i) {
            return i && (t.data.visitBeginDate ? t.data.visitEndDate ? e(t.data.visitBeginDate).valueOf() > e(t.data.visitEndDate).valueOf() && (n.alert("开始日期不能大于结束日期"), 
            i = !1) : (n.alert("请选择结束日期"), i = !1) : (n.alert("请选择开始日期"), i = !1)), i;
        }) : Promise.resolve(!0);
    },
    publish: function() {
        var e = this;
        this.validate().then(function(a) {
            if (a) if ("publishing" !== e.item.state || e.recharge || "usedVesselEditImage" !== e.source) "publishing" === e.item.state && !e.recharge || "usedVesselEditImage" !== e.source ? wx.navigateBack() : e.deadbeatBlockModal.check("used_vessel_recharge").then(function(a) {
                if (a) return n.showLoading("获取数据中"), i.mercury.get("usedVessel/canPublish").finally(n.hideLoading).then(function(i) {
                    var a = t.register(e.item), s = i ? "pay/pay" : "certify/certify";
                    wx.navigateTo({
                        url: "../".concat(s, "?source=usedVesselEditVisit&item=").concat(a, "&backStep=").concat(e.backStep)
                    });
                }).catch(function(t) {
                    return i.showError("查询发布条件", t);
                });
            }); else {
                var s = t.register(e.item);
                wx.navigateTo({
                    url: "../edit-publish/edit-publish?source=usedVesselEditVisit&item=".concat(s, "&backStep=").concat(e.backStep)
                });
            }
        });
    },
    visitPlaceChange: function(t) {
        this.setData({
            visitPlace: t.detail.value || ""
        }), this.valueChanged();
    },
    formatDate: function(t) {
        return t ? e(t).format("YYYY-MM-DD") : "";
    },
    formatDateString: function(t) {
        return t ? e(t).format("YYYY年M月D日") : "";
    },
    visitBeginDateChange: function(t) {
        var i = this.formatDate(t.detail.value);
        this.setData({
            visitBeginDate: i,
            visitBeginDateString: this.formatDateString(i)
        }), this.valueChanged();
    },
    visitEndDateChange: function(t) {
        var i = this.formatDate(t.detail.value);
        this.setData({
            visitEndDate: i,
            visitEndDateString: this.formatDateString(i)
        }), this.valueChanged();
    },
    init: function() {
        var t = "expired" === this.item.state ? "重新发布" : "发布";
        "publishing" !== this.item.state && "usedVesselEditImage" === this.source || (t = "完成");
        var i = !(null !== this.item.visitable && void 0 !== this.item.visitable && !this.item.visitable), a = this.item.visitPlace || "", s = i && this.formatDate(this.item.visitBeginDate) || null, n = i && this.formatDate(this.item.visitEndDate) || null, r = this.formatDateString(s), h = this.formatDateString(n), o = this.formatDate(e());
        this.setData({
            publishAction: t,
            today: o,
            visitable: i,
            visitPlace: a,
            visitBeginDate: s,
            visitEndDate: n,
            visitBeginDateString: r,
            visitEndDateString: h
        });
    },
    initById: function() {
        var t = this;
        if (!this.item && this.itemId && this.data.userId) {
            if (!this.initing) return this.initing = !0, n.showLoading("获取数据中"), a.refresh().finally(n.hideLoading).then(function() {
                t.initing = !1, t.item = a.get().items.find(function(i) {
                    return i.id === t.itemId;
                }), t.item ? t.init() : n.alert("未找到该条卖船信息").then(wx.navigateBack);
            }).catch(function(t) {
                return i.showError("获取卖船信息", t).finally(wx.navigateBack);
            });
            setTimeout(function() {
                return t.initById();
            }, 100);
        }
    },
    data: {
        publishAction: "发布",
        visitable: !0,
        visitPlace: "",
        visitBeginDate: "",
        visitBeginDateString: "",
        visitEndDate: "",
        visitEndDateString: ""
    },
    onLoad: function(e) {
        var a = this;
        this.syncUserId = r.id.subscribeAndFireOnce(function(t) {
            a.setData({
                userId: t
            }), t && a.initById();
        }), this.item = t.unRegister(e.item), this.itemId = +e.id || 0, this.backStep = (+e.backStep || 0) + 1, 
        this.recharge = +e.recharge || 0, this.source = e.source, this.action = e.action || "edit";
        var s = "page_".concat(this.action, "_visit");
        i.mercury.post("usedVessel/log", {
            action: s,
            id: this.itemId || this.item.id,
            result: this.source
        }), this.item ? this.init() : this.initById();
    },
    valueChanged: function() {
        this.item.visitable = this.data.visitable, this.item.visitPlace = this.data.visitPlace ? this.data.visitPlace.trim().slice(0, 3) : "", 
        this.item.visitBeginDate = this.formatDate(this.data.visitBeginDate), this.item.visitEndDate = this.formatDate(this.data.visitEndDate), 
        s.saveItem(this.item);
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        n.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        a.refresh(), this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});