var t = require("../../../utils/globalMap"), i = require("../../../utils/ajax"), e = require("../../../utils/util"), a = require("../../../utils/user"), o = require("../../../utils/env"), n = require("../../../utils/contactAlert"), r = require("../../../dao/vipStatus"), s = function() {
    i.mercury.post("vip/log", {
        action: "vip_user_click",
        target: "contact_to_vip_ship"
    }), wx.navigateTo({
        url: "/pages/settings/vip-ship/vip-ship"
    });
};

Page({
    jianghuPosition: function() {
        wx.redirectTo({
            url: "../jianghu-position/jianghu-position?query=".concat(t.register(this.query))
        });
    },
    familiarRelations: function() {
        wx.redirectTo({
            url: "../familiar-relations/familiar-relations?query=".concat(t.register(this.query))
        });
    },
    historyPallets: function() {
        wx.redirectTo({
            url: "../history-pallets/history-pallets?query=".concat(t.register(this.query))
        });
    },
    toVip: function() {
        this.data.shipVip || this.data.tag.official || e.confirm("只有船主VIP用户才能查看***内容，是否开通船主VIP？", {
            cancelText: "暂不开通",
            confirmText: "立即开通"
        }).then(s).catch(function() {});
    },
    toVipHelper: function() {
        this.data.shipVip || this.data.tag.official || s();
    },
    makeContact: function() {
        this.data.shipVip || this.data.tag.official ? this.data.tag.official || a.certifiedShip.get() ? this._makeContact() : e.authShipCreateModal("查看货主信息") : this.toVip();
    },
    vipBlock: function(t, e) {
        return this.vipBlockModal.modal(t, e, "免费发布空船").then(function(t) {
            switch (t) {
              case "to_vip":
                return s();

              case "to_publish":
                return i.mercury.post("vip/log", {
                    action: "vip_user_click",
                    target: "contact_to_publish_ship"
                }), void wx.navigateTo({
                    url: "/pages/edit-ship/edit-ship?id=0"
                });
            }
        });
    },
    _makeContact: function() {
        var t = this;
        this.data.tag.official ? this._doMakeContact() : (e.hideLoading(), this.contactAlert.alert().then(function() {
            i.mercury.get("account/vipStatus").then(function(a) {
                var o = a.vips, n = new Date(a.vipBeginDate);
                if (o.indexOf("ship") >= 0 || new Date() < n) t._doMakeContact(); else {
                    var r = a.leftMobiles;
                    if (a.shipVipBought) i.mercury.post("vip/log", {
                        action: "vip_bought_block_contact_pallet",
                        target: t.data.id
                    }), t.vipBlock("您的船主VIP已过期，暂时无法查看电话，续费后即可查看货主电话。", "立即续费"); else if (r > 0) {
                        var s = a.alreadyMobiles;
                        e.alert("普通用户最多可查看10个电话，您已查看".concat(s, "个，还可免费查看").concat(r, "个电话。"), {
                            confirmText: "知道了"
                        }).then(function() {
                            e.showLoading("获取数据中"), t._doMakeContact();
                        });
                    } else i.mercury.post("vip/log", {
                        action: "vip_block_contact_pallet",
                        target: t.data.id
                    }), t.vipBlock("普通用户可免费查看10个电话，您的查看次数已达上限，请开通船主VIP查看更多货源电话。", "立即开通");
                }
            }).catch(function(t) {
                return i.showError("获取VIP信息", t);
            });
        }));
    },
    _doMakeContact: function() {
        var t = this;
        i.mercury.post("ships/make-link-contact", {
            id: this.query.id,
            ship: this.query.origin,
            page: "history-pallets",
            originType: "history-pallets"
        }).finally(e.hideLoading).then(function(i) {
            var e = t.query.user;
            e.mobiles = i.mobiles[0], e.name = i.username, t.query.enterprise.store ? e.organization = t.query.enterprise.fullName : e.organization = i.organization, 
            e.avatar = i.avatar, i.avatar && (e.avatarUrl = o.mercury("files/avatar/".concat(i.avatar))), 
            t.setData({
                user: e,
                contacted: e.mobiles.indexOf("*") < 0
            }), t.refresh();
        }).catch(function(a) {
            a.data._withMessage_ ? "NEED_SHIP_VIP" === a.data.chb2Code ? t.vipBlock(a.data.message, "立即开通") : e.alert(a.data.message) : 403 === a.statusCode ? t.contactLimit.show() : i.showError("查看货主信息", a);
        });
    },
    refresh: function(t) {
        var a = this;
        t || e.showLoading("刷新数据中"), i.mercury.get("pallets/history", {
            pallet: this.query.id,
            target: this.query.id ? null : this.query.targetUser,
            pageInit: !!t
        }).finally(function() {
            return t ? void 0 : e.hideLoading();
        }).then(function(t) {
            return a.setData({
                pallets: t.map(function(t) {
                    return t.startPort = t.startPort || "", t.aimPort = t.aimPort || "", t.cargo = t.cargo || "", 
                    t.name = t.name || "", t.dateText = t.longTerm ? "长期货" : t.loadOnArrived ? "船到就装" : t.date + "装", 
                    t;
                })
            });
        }).catch(function(t) {
            return i.showError("获取历史货源数据", t);
        });
    },
    data: {
        shipVip: !1,
        pallets: [],
        contactAlertLines: n.zhaohuo
    },
    onLoad: function(e) {
        var a = this, o = this.query = t.unRegister(e.query);
        this.setData({
            tag: o.tag,
            user: o.user,
            contacted: o.user.mobiles.indexOf("*") < 0,
            state: o.state
        }), this.syncVipStatus = r.subscribeAndFireOnce(function(t) {
            return a.setData({
                shipVip: t && t.vips.indexOf("ship") >= 0 && t.shipLeftDays > 0
            });
        }), i.mercury.get("vip/beginDate").then(function(t) {
            return a.setData({
                showPromote: new Date() < new Date(t)
            });
        }), this.refresh(!0);
    },
    onReady: function() {
        this.contactLimit = this.selectComponent("#contact-limit"), this.contactAlert = this.selectComponent("#contact-alert-modal"), 
        this.vipBlockModal = this.selectComponent("#vip-block-modal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncVipStatus.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});