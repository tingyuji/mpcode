var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), a = require("../../utils/ajax"), e = require("../../utils/env"), i = require("../../utils/user"), n = require("../../utils/util"), r = require("../../utils/globalMap"), o = require("../../utils/contactAlert"), s = require("../../dao/vessel"), l = require("../../utils/ad"), c = require("../used-vessel/common"), h = require("../../dao/sailorExamCompanies"), d = function(t) {
    a.mercury.post("vip/log", {
        action: "vip_user_click",
        target: (t || "contact") + "_to_vip_ship"
    }), wx.navigateTo({
        url: "/pages/settings/vip-ship/vip-ship"
    });
};

Page({
    data: {
        userId: 0,
        id: 0,
        item: {},
        state: {},
        tag: {},
        user: {},
        enterprise: {},
        options: {},
        dialed: !1,
        contactAlertLines: o.zhaohuo,
        jianghuPositionCount: null,
        familiarRelationCount: null,
        historyPalletCount: null,
        uvAdvert: null,
        ad: null
    },
    login: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    addAttitude: function(t) {
        var e = this, i = t.currentTarget.dataset.attitude;
        a.mercury.post("pallets/addAttitude", {
            id: this.data.id,
            attitude: i
        }).then(function() {
            return e.data.feedback.hideModal();
        });
    },
    thumbs: function(t) {
        var e = this;
        if (i.id.get()) {
            var n = t.currentTarget.dataset.type;
            a.mercury.post("store/thumbs", {
                pallet: this.data.id,
                type: n
            }).then(function() {
                return a.mercury.get("starEnterprises/store", {
                    pallet: e.data.id
                }).then(function(t) {
                    var a = e.data.enterprise;
                    a.thumbsUp = t.thumbsUp, a.thumbsDown = t.thumbsDown, a.myThumbs = t.myThumbs, e.setData({
                        enterprise: a
                    });
                });
            }).catch(function(t) {
                return a.showError("赞或踩", t);
            });
        } else this.login();
    },
    refreshParentItem: function(t) {
        var a = getCurrentPages();
        if (a.length > 1) {
            var e = a[a.length - 2];
            e.refreshItem && e.refreshItem("pallet", this.data.id, t);
        }
    },
    vipBlock: function(t, e, i, n) {
        return this.vipBlockModal.modal(t, e, "免费发布空船").then(function(t) {
            switch (t) {
              case "to_vip":
                return d(i);

              case "to_publish":
                return function(t) {
                    a.mercury.post("vip/log", {
                        action: "vip_user_click",
                        target: (t || "contact") + "_to_publish_ship"
                    }), wx.navigateTo({
                        url: "/pages/edit-ship/edit-ship?id=0"
                    });
                }();

              default:
                return n && n();
            }
        });
    },
    _makeContact: function(t, r) {
        var o = this, s = function() {
            a.mercury.post("ships/make-link-contact", {
                id: o.data.id,
                ship: o.data.options.origin,
                page: "pallet-detail",
                showIndex: o.data.options.showIndex,
                originType: o.data.options.originType
            }).then(function(a) {
                var n = o.data.user;
                n.mobiles = a.mobiles[0], n.name = a.username, o.data.enterprise.store ? n.organization = o.data.enterprise.fullName : n.organization = a.organization, 
                n.avatar = a.avatar, a.avatar && (n.avatarUrl = e.mercury("files/avatar/".concat(a.avatar))), 
                r = r || n.mobiles, o.setData({
                    user: n,
                    contacted: !/\*+/.test(r)
                }), i.refresh(), o.refreshParentItem({
                    username: a.username,
                    avatar: a.avatar
                }), o.data.tag.official || o.setData({
                    dialed: !0
                }), t && o.dial(r);
            }).catch(function(t) {
                t.data && t.data._withMessage_ ? "NEED_SHIP_VIP" === t.data.chb2Code ? o.vipBlock(t.data.message, "立即开通") : n.alert(t.data.message) : 403 === t.statusCode && t.data && "CONTACT_LIMIT" === t.data.message ? o.contactLimit.show() : a.showError("查看电话", t);
            });
        };
        this.data.tag.official ? s() : this.contactAlert.alert().then(function() {
            a.mercury.get("account/vipStatus").then(function(t) {
                var e = t.vips, i = new Date(t.vipBeginDate);
                if (e.indexOf("ship") >= 0 || new Date() < i) s(); else {
                    var r = t.leftMobiles;
                    if (t.shipVipBought) a.mercury.post("vip/log", {
                        action: "vip_bought_block_contact_pallet",
                        target: o.data.id
                    }), o.vipBlock("您的船主VIP已过期，暂时无法查看电话，续费后即可查看货主电话。", "立即续费"); else if (r > 0) {
                        var l = t.alreadyMobiles;
                        n.alert("普通用户最多可查看10个电话，您已查看".concat(l, "个，还可免费查看").concat(r, "个电话。"), {
                            confirmText: "知道了"
                        }).then(s);
                    } else a.mercury.post("vip/log", {
                        action: "vip_block_contact_pallet",
                        target: o.data.id
                    }), o.vipBlock("普通用户可免费查看10个电话，您的查看次数已达上限，请开通船主VIP查看更多货源电话。", "立即开通");
                }
            }).catch(function(t) {
                return a.showError("获取VIP信息", t);
            });
        });
    },
    viewContact: function() {
        this.doMakeContact(!1);
    },
    makeContact: function() {
        this.data.tag.official ? this.data.tag.officialSecondaryMobile ? this.makeContactSecondary() : this.makeContactPrimary() : this.doMakeContact(!0);
    },
    makeContactPrimary: function() {
        this.doMakeContact(!0, this.data.tag.officialMobile);
    },
    makeContactSecondary: function() {
        this.doMakeContact(!0, this.data.tag.officialSecondaryMobile);
    },
    doMakeContact: function(t, a) {
        this.data.tag.official || i.id.get() ? this.data.user.mobiles.indexOf("*") >= 0 ? this.data.tag.official || i.certifiedShip.get() ? this._makeContact(t, a) : n.authShipCreateModal("查看货主信息") : this.dial(a) : this.login();
    },
    dial: function(t) {
        var e = this;
        a.mercury.post("ships/dial", {
            id: this.data.id,
            mark: this.data.options.mark,
            page: "pallet-detail",
            ship: this.data.options.origin,
            showIndex: this.data.options.showIndex
        }).then(function() {
            wx.makePhoneCall({
                phoneNumber: t || e.data.user.mobiles,
                success: function() {
                    e.data.dialed && (e.setData({
                        dialed: !1
                    }), e.data.feedback.showModal());
                }
            });
        });
    },
    preview: function(t) {
        var a = t.currentTarget.dataset.media, e = this.data.tag.media.findIndex(function(t) {
            return t.id === a.id;
        });
        e = Math.max(0, e), wx.previewMedia({
            sources: this.data.tag.media.map(function(t) {
                return {
                    url: t.url,
                    type: t.type.startsWith("video") ? "video" : "image",
                    poster: t.thumbnail
                };
            }),
            current: e
        });
    },
    previewLocation: function(t) {
        var a = t.currentTarget.dataset.location, e = t.currentTarget.dataset.title || "", i = a.name || a.poiname;
        wx.openLocation({
            latitude: a.lat,
            longitude: a.lng,
            name: e + (i ? "(".concat(i, ")") : ""),
            address: "此位置仅供参考，勿用于导航等其他用途",
            scale: 11
        });
    },
    officialHelp: function() {
        n.browse(e.resource("app-help/why-chb2-official-pallet.html?ts=".concat(new Date().getTime())), "official-help");
    },
    _loadData: function(t) {
        var e = this;
        return "wl" === t.source && t.hash ? a.mercury.get("wl/palletId?hash=" + t.hash).then(function(t) {
            return e.historyPalletIds.splice(-1, 1, t), e.data.options.id = t, e.setData({
                options: e.data.options
            }), e._loadDataHelper({
                id: t,
                origin: 0,
                mark: 0
            });
        }).catch(function(t) {
            404 === t.statusCode ? n.alert("货源不存在或已过期") : a.showError("获取货源信息", t);
        }) : this._loadDataHelper(t);
    },
    _loadDataHelper: function(r) {
        var o = this;
        a.mercury.get("pallets/detail", {
            pallet: r.id,
            origin: r.origin || 0,
            mark: r.mark || 0,
            showIndex: r.showIndex,
            vessel: s.get() && s.get().id || 0,
            version: "v4"
        }).then(function(a) {
            var i = a.user;
            a.isGreat = a.great && !a.great.pause, i.newAvatar ? i.avatarUrl = i.newAvatar : i.avatarUrl = "/images/avatar-none.png";
            var n = a.tag.media;
            if (n && n.length > 0) {
                var s, l = Math.ceil(Math.sqrt(n.length)), c = 6 / l, h = t(n);
                try {
                    for (h.s(); !(s = h.n()).done; ) {
                        var d = s.value;
                        d.url = a.enterprise.store ? e.mercury("store/media/".concat(encodeURIComponent(d.file))) : e.mercury("files/media/".concat(encodeURIComponent(d.hash))), 
                        d.thumbnail = "".concat(d.url, "?thumbnail=").concat(c, "&level=").concat(l);
                    }
                } catch (t) {
                    h.e(t);
                } finally {
                    h.f();
                }
            }
            var u = parseInt(r.showIndex);
            a.showIndex = Number.isFinite(u) ? u : null, a.item.startTerminal = a.item.startTerminal || "", 
            a.item.targetTerminal = a.item.targetTerminal || "", a.item.cargo && a.item.cargo.length > 0 && a.item.cargo.indexOf("吨") < 0 && a.item.cargo.indexOf("随船") < 0 && (a.item.cargo += "吨"), 
            a.item.weight && a.item.weight.length > 0 && a.item.weight.indexOf("船") < 0 && (a.item.weight += "船");
            var m = [ a.item.shipStatus, a.item.fengcang, a.item.shuichi, a.item.dakong, a.item.sink, a.item.bridgePosition ? "驾驶舱" + a.item.bridgePosition : "", a.item.hatch, a.item.draught ? "吃水" + a.item.draught : "", a.item.shipLength ? "船长" + a.item.shipLength : "", a.item.shipWidth ? "船宽" + a.item.shipWidth : "", a.item.shipHeight ? "船高" + a.item.shipHeight : "", a.item.hatchLength ? "舱口长" + a.item.hatchLength : "", a.item.hatchWidth ? "舱口宽" + a.item.hatchWidth : "", a.item.hatchDepth ? "舱口深" + a.item.hatchDepth : "", a.item.weight, a.item.dateText, a.item.deposit ? "有定金" : "", a.item.settlement, a.item.handlingTime ? "两港" + a.item.handlingTime : "", a.item.demurrage ? "滞期费" + a.item.demurrage : "" ];
            a.tag.officialDetail = m.filter(function(t) {
                return t;
            }).join("，");
            var g = new Set(o.historyPalletIds);
            a.tag.similarPallets = (a.tag.similarPallets || []).filter(function(t) {
                return !g.has(t.id);
            }).map(function(t, a) {
                return t.pallet = t.id = Number.isFinite(t.pallet) ? t.pallet : t.id, t.isGreat = t.great && !t.great.pause, 
                t.tag.official ? t.tag.media.length > 0 && (t.user.avatarUrl = e.mercury("files/media/".concat(t.tag.media[0].hash, "?thumbnail=1"))) : t.enterprise.store && (t.tag.media.length > 0 && (t.user.avatarUrl = e.mercury("store/media/".concat(t.tag.media[0].file, "?thumbnail=1"))), 
                t.tag.authCompany = !0, t.user.organization = t.enterprise.fullName), t.user.avatarUrl || (t.user.newAvatar ? t.user.avatarUrl = t.user.newAvatar : t.user.avatarUrl = "/images/avatar-none.png"), 
                t.similar = {
                    index: a,
                    historyPalletIds: o.historyPalletIds
                }, t;
            }), a.enterprise.store && (a.tag.authCompany = !0, a.user.organization = a.enterprise.fullName, 
            a.enterprise.logo && (a.enterprise.logoUrl = e.mercury("store/logo/".concat(a.enterprise.logo, "?size=100&mode=pad")))), 
            o.setData({
                id: a.id,
                isGreat: a.isGreat,
                item: a.item,
                state: a.state,
                tag: a.tag,
                ad: o.fixAdItem(a.ad || null),
                user: i,
                contacted: !/\*+/.test(i.mobiles),
                enterprise: a.enterprise,
                showAuthCompany: a.tag.authCompany && !(a.state.showTimeToday && a.enterprise.store)
            }), o.loadSharpEyes();
        }).catch(function(t) {
            if (403 === t.statusCode) if (i.id.get()) {
                var a = "您已达到今日最大查看货源详情次数，请明天再来看吧！";
                t.data._withMessage_ && (a = t.data.message), "NEED_SHIP_VIP" === t.data.chb2Code ? o.vipBlock(a, "立即开通", "detail", wx.navigateBack) : "NEED_SHIP_VIP2" === t.data.chb2Code ? n.confirm(a, {
                    cancelText: "暂不升级",
                    confirmText: "升级VIP"
                }).then(function() {
                    return d("detail");
                }).catch(function() {
                    return wx.navigateBack();
                }) : n.alert(a).then(wx.navigateBack);
            } else wx.showModal({
                title: "温馨提示",
                content: "您已达到今日最大查看货源详情次数，绑定手机号后可查看更多货源",
                showCancel: !1,
                success: function() {
                    return o.login();
                }
            }); else 429 === t.statusCode ? wx.showModal({
                title: "访问过于频繁",
                content: "访问过于频繁",
                showCancel: !1
            }) : 404 === t.statusCode ? wx.showModal({
                title: "货源不存在或已过期",
                content: "货源不存在或已过期",
                showCancel: !1
            }) : wx.showModal({
                title: "查看详情失败",
                content: "查看详情失败",
                showCancel: !1
            });
        });
    },
    fixAdItem: function(t) {
        if (t) if ("ad" === t.adType) {
            t.contents = l.getContents(t.content);
            var a = t.photo;
            a && a.name ? t.avatarUrl = e.mercury("files/load-ad-image?name=".concat(encodeURIComponent(a.name), "&width=60&height=60")) : t.avatarUrl = e.resource("mp/ad-avatar.png");
        } else "section_ad" === t.adType ? t.index = t.adIndex : "used_vessel" === t.adType ? c.fixItem(t) : "sailor_exam" === t.adType && (t.company = h.get()[Math.max(0, (t.id || 0) - 1)]);
        return t;
    },
    loadSharpEyes: function() {
        var t = this;
        this.data.userId > 0 && this.data.id && !this.data.state.ordered && !this.data.state.pause ? (a.mercury.get("markings/summary", {
            pallet: this.data.id,
            pageInit: !1
        }).then(function(a) {
            t.setData({
                jianghuPositionCount: (a || {}).total || 0
            });
        }).catch(function(t) {
            return console.error(t);
        }), a.mercury.get("pallets/familiar", {
            pallet: this.data.id,
            pageInit: !1
        }).then(function(a) {
            t.setData({
                familiarRelationCount: ((a || {}).relations || []).length
            });
        }).catch(function(t) {
            return console.error(t);
        }), this.data.tag.official ? this.setData({
            historyPalletCount: null
        }) : a.mercury.get("pallets/history", {
            pallet: this.data.id,
            pageInit: !1
        }).then(function(a) {
            t.setData({
                historyPalletCount: (a || []).length
            });
        }).catch(function(t) {
            return console.error(t);
        })) : this.setData({
            jianghuPositionCount: null,
            familiarRelationCount: null,
            historyPalletCount: null
        });
    },
    getPalletQuery: function() {
        return r.register({
            id: this.data.id,
            mark: this.data.options.mark,
            origin: this.data.options.origin,
            item: this.data.item,
            state: this.data.state,
            tag: this.data.tag,
            user: this.data.user,
            enterprise: this.data.enterprise
        });
    },
    jianghuPosition: function() {
        i.id.get() ? wx.navigateTo({
            url: "./jianghu-position/jianghu-position?query=".concat(this.getPalletQuery())
        }) : this.login();
    },
    familiarRelations: function() {
        i.id.get() ? wx.navigateTo({
            url: "./familiar-relations/familiar-relations?query=".concat(this.getPalletQuery())
        }) : this.login();
    },
    historyPallets: function() {
        i.id.get() ? wx.navigateTo({
            url: "./history-pallets/history-pallets?query=".concat(this.getPalletQuery())
        }) : this.login();
    },
    onLoad: function(t) {
        var a = this, e = this.selectComponent("#feedback");
        this.similar = r.unRegister(t.similar) || {};
        var n = +t.backCount || r.register({
            value: 0
        });
        this.historyPalletIds = (this.similar.historyPalletIds || []).concat(+t.id), this.setData({
            feedback: e,
            userId: i.id.get(),
            options: t,
            backCount: n
        }), this._loadData(t), this.syncUserId = i.id.subscribe(function(e) {
            a.setData({
                userId: e
            }), a._loadData(t);
        });
    },
    onReady: function() {
        this.contactLimit = this.selectComponent("#contact-limit"), this.contactAlert = this.selectComponent("#contact-alert-modal"), 
        this.vipBlockModal = this.selectComponent("#vip-block-modal");
    },
    onShow: function() {
        this.data.user && !/\*+/.test(this.data.user.mobiles) && this.setData({
            user: this.data.user,
            contacted: !/\*+/.test(this.data.user.mobiles)
        });
        var t = this.selectComponent("#advert");
        t && t.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
        var t = r.get(this.data.backCount);
        t.value >= 0 && (t.value++, t.value >= 3 && this.historyPalletIds.length > 1 && (t.value = -1, 
        wx.navigateBack({
            delta: this.historyPalletIds.length - 1
        }))), this.historyPalletIds.length <= 1 && r.unRegister(this.data.backCount);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this, e = this.data.item, i = "".concat(e.startPort, " → ").concat(e.aimPort, " ").concat(e.cargo, " ").concat(e.name);
        return this.data.tag.official && (i += " ".concat(this.data.tag.officialMobile, " ").concat(this.data.user.name.slice(0, 1))), 
        {
            title: i,
            path: n.sharePath({
                id: this.data.options.id,
                mark: this.data.options.mark,
                origin: this.data.options.origin,
                originType: "share"
            }),
            success: function(e) {
                "shareAppMessage:ok" === e.errMsg && a.mercury.post("miniProgram/sharePage", {
                    page: n.getCurrentPageName(),
                    target: t.data.id
                });
            }
        };
    }
});