var t = require("../../../utils/globalMap"), i = require("../../../utils/ajax"), a = require("../../../utils/util"), e = require("../../../utils/user"), n = require("../../../utils/env"), r = require("../../../utils/contactAlert"), o = require("../../../dao/vipStatus"), s = function() {
    i.mercury.post("vip/log", {
        action: "vip_user_click",
        target: "contact_to_vip_ship"
    }), wx.navigateTo({
        url: "/pages/settings/vip-ship/vip-ship"
    });
};

Page({
    refresh: function(t) {
        var e = this;
        t || a.showLoading("刷新数据中"), i.mercury.get("markings/summary", {
            pallet: this.query.id,
            target: this.query.id ? null : this.query.targetUser,
            pageInit: !!t
        }).finally(function() {
            return t ? void 0 : a.hideLoading();
        }).then(function(t) {
            var i = (t = t || {}).fraud, a = !/\*+/.test(i);
            a && (i = (i = +t.fraud || 0) <= 5 ? 0 : i), e.setData({
                markings: t,
                fraud: i,
                fraudIsShown: a
            });
        }).catch(function(t) {
            return i.showError("获取江湖评价数据", t);
        });
    },
    jianghuPosition: function() {
        wx.redirectTo({
            url: "../jianghu-position/jianghu-position?query=".concat(t.register(this.query))
        });
    },
    familiarRelations: function() {
        wx.redirectTo({
            url: "../familiar-relations/familiar-relations?query=".concat(t.register(this.query))
        });
    },
    historyPallets: function() {
        wx.redirectTo({
            url: "../history-pallets/history-pallets?query=".concat(t.register(this.query))
        });
    },
    toVip: function() {
        this.data.shipVip || this.data.tag.official || a.confirm("只有船主VIP用户才能查看***内容，是否开通船主VIP？", {
            cancelText: "暂不开通",
            confirmText: "立即开通"
        }).then(s).catch(function() {});
    },
    toVipHelper: function() {
        this.data.shipVip || this.data.tag.official || s();
    },
    makeContact: function() {
        this.data.shipVip || this.data.tag.official ? this.data.tag.official || e.certifiedShip.get() ? this._makeContact() : a.authShipCreateModal("查看货主信息") : this.toVip();
    },
    vipBlock: function(t, a) {
        return this.vipBlockModal.modal(t, a, "免费发布空船").then(function(t) {
            switch (t) {
              case "to_vip":
                return s();

              case "to_publish":
                return i.mercury.post("vip/log", {
                    action: "vip_user_click",
                    target: "contact_to_publish_ship"
                }), void wx.navigateTo({
                    url: "/pages/edit-ship/edit-ship?id=0"
                });
            }
        });
    },
    _makeContact: function() {
        var t = this;
        this.data.tag.official ? this._doMakeContact() : (a.hideLoading(), this.contactAlert.alert().then(function() {
            i.mercury.get("account/vipStatus").then(function(e) {
                var n = e.vips, r = new Date(e.vipBeginDate);
                if (n.indexOf("ship") >= 0 || new Date() < r) t._doMakeContact(); else {
                    var o = e.leftMobiles;
                    if (e.shipVipBought) i.mercury.post("vip/log", {
                        action: "vip_bought_block_contact_pallet",
                        target: t.data.id
                    }), t.vipBlock("您的船主VIP已过期，暂时无法查看电话，续费后即可查看货主电话。", "立即续费"); else if (o > 0) {
                        var s = e.alreadyMobiles;
                        a.alert("普通用户最多可查看10个电话，您已查看".concat(s, "个，还可免费查看").concat(o, "个电话。"), {
                            confirmText: "知道了"
                        }).then(function() {
                            a.showLoading("获取数据中"), t._doMakeContact();
                        });
                    } else i.mercury.post("vip/log", {
                        action: "vip_block_contact_pallet",
                        target: t.data.id
                    }), t.vipBlock("普通用户可免费查看10个电话，您的查看次数已达上限，请开通船主VIP查看更多货源电话。", "立即开通");
                }
            }).catch(function(t) {
                return i.showError("获取VIP信息", t);
            });
        }));
    },
    _doMakeContact: function() {
        var t = this;
        i.mercury.post("ships/make-link-contact", {
            id: this.query.id,
            ship: this.query.origin,
            page: "jianghu-position",
            originType: "jianghu-position"
        }).finally(a.hideLoading).then(function(i) {
            var a = t.query.user;
            a.mobiles = i.mobiles[0], a.name = i.username, t.query.enterprise.store ? a.organization = t.query.enterprise.fullName : a.organization = i.organization, 
            a.avatar = i.avatar, i.avatar && (a.avatarUrl = n.mercury("files/avatar/".concat(i.avatar))), 
            t.setData({
                user: a,
                contacted: a.mobiles.indexOf("*") < 0
            }), t.refresh();
        }).catch(function(e) {
            e.data._withMessage_ ? "NEED_SHIP_VIP" === e.data.chb2Code ? t.vipBlock(e.data.message, "立即开通") : a.alert(e.data.message) : 403 === e.statusCode ? t.contactLimit.show() : i.showError("查看货主信息", e);
        });
    },
    remove: function() {
        var t = this;
        a.confirm("您确定要删除对他的标记吗？").then(function() {
            a.showLoading("删除标记中"), i.mercury.post("markings/remove", {
                pallet: t.query.id
            }).finally(a.hideLoading).then(t.refresh()).catch(function(t) {
                return i.showError("删除标记", t);
            });
        });
    },
    mark: function() {
        this.setMarking(this.data.markings.self || ""), this.markingModal.show();
    },
    markingChange: function(t) {
        this.setMarking(t.detail.value);
    },
    setMarking: function(t) {
        this.data.markingItems.forEach(function(i) {
            return i.checked = i.value === t;
        }), this.setData({
            markingItems: this.data.markingItems
        }), this.selectedMarking = t;
    },
    confirmMarking: function(t) {
        this.selectedMarking && (this.markingModal.hide(), a.showLoading("提交标记中"), i.mercury.post("markings/save", {
            pallet: this.query.id,
            marking: this.selectedMarking
        }).finally(a.hideLoading).then(this.refresh()).catch(function(t) {
            return i.showError("修改标记", t);
        }));
    },
    data: {
        shipVip: !1,
        markings: {},
        markingItems: [ {
            name: "货主",
            value: "owner"
        }, {
            name: "货代",
            value: "proxy"
        }, {
            name: "中介",
            value: "agent"
        }, {
            name: "骗子",
            value: "fraud"
        } ],
        contactAlertLines: r.zhaohuo
    },
    onLoad: function(i) {
        var a = this, e = this.query = t.unRegister(i.query);
        this.setData({
            tag: e.tag,
            user: e.user,
            contacted: e.user.mobiles.indexOf("*") < 0,
            state: e.state
        }), this.syncVipStatus = o.subscribeAndFireOnce(function(t) {
            return a.setData({
                shipVip: t && t.vips.indexOf("ship") >= 0 && t.shipLeftDays > 0
            });
        }), this.refresh(!0);
    },
    onReady: function() {
        this.markingModal = this.selectComponent("#markingModal"), this.contactLimit = this.selectComponent("#contact-limit"), 
        this.contactAlert = this.selectComponent("#contact-alert-modal"), this.vipBlockModal = this.selectComponent("#vip-block-modal");
    },
    onShow: function() {
        e.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncVipStatus.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});