var t = require("../../utils/ajax.js"), a = require("../../utils/env.js"), e = require("../../utils/user.js"), i = require("../../utils/util"), o = require("../../utils/contactAlert"), n = require("../../utils/ad"), s = require("../used-vessel/common"), r = require("../../dao/sailorExamCompanies");

Page({
    data: {
        userId: 0,
        id: null,
        item: null,
        state: null,
        tag: null,
        user: null,
        origin: null,
        ad: null,
        contactAlertLines: o.zhaochuan,
        banner: a.resource("mp/delegate.jpg")
    },
    login: function() {
        wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    refreshParentItem: function(t) {
        var a = getCurrentPages();
        if (a.length > 1) {
            var e = a[a.length - 2];
            e.refreshItem && e.refreshItem("ship", this.data.id, t);
        }
    },
    _contact: function(o) {
        var n = this;
        t.mercury.post("pallets/make-link-contact", {
            id: this.data.id,
            pallet: this.data.origin,
            page: "ship-detail"
        }).then(function(t) {
            var i = n.data.user;
            i.mobiles = t.mobiles[0], i.name = t.username, i.vessel = t.vesselName || i.vessel, 
            i.avatar = t.avatar, t.avatar ? i.avatarUrl = a.mercury("files/avatar/".concat(t.avatar)) : i.avatarUrl = "/images/avatar-none.png", 
            n.setData({
                user: i,
                contacted: !/\*+/.test(i.mobiles)
            }), e.refresh(), n.refreshParentItem({
                username: t.username
            }), o && n.dial();
        }).catch(function(a) {
            a.data && "NEED_PALLET_VIP" === a.data.chb2Code ? n.vipBlock(a.data.message, "立即开通") : 403 === a.statusCode && a.data && "CONTACT_LIMIT" === a.data.message ? n.contactLimit.show() : a.data && a.data._withMessage_ ? i.alert(a.data.message) : t.showError("查看电话", a);
        });
    },
    vipBlock: function(a, e, i, o) {
        return this.vipBlockModal.modal(a, e, "免费发布货源").then(function(a) {
            switch (a) {
              case "to_vip":
                return function(a) {
                    t.mercury.post("vip/log", {
                        action: "vip_user_click",
                        target: (a || "contact") + "_to_vip_pallet"
                    }), wx.navigateTo({
                        url: "/pages/settings/vip-pallet/vip-pallet"
                    });
                }(i);

              case "to_publish":
                return function(a) {
                    t.mercury.post("vip/log", {
                        action: "vip_user_click",
                        target: (a || "contact") + "_to_publish_pallet"
                    }), wx.navigateTo({
                        url: "/pages/edit-pallet/edit-pallet?id=0"
                    });
                }();

              default:
                return o && o();
            }
        });
    },
    _makeContact: function(a) {
        var e = this;
        this.contactAlert.alert().then(function() {
            t.mercury.get("account/vipStatus").then(function(o) {
                var n = o.vips, s = o.isStarUser, r = new Date(o.vipBeginDate);
                if (n.indexOf("pallet") >= 0 || s || new Date() < r) e._contact(a); else {
                    var c = o.leftMobiles;
                    if (o.palletVipBought) t.mercury.post("vip/log", {
                        action: "vip_bought_block_contact_ship",
                        target: e.data.id
                    }), e.vipBlock("您的货主VIP已过期，暂时无法查看电话，续费后即可查看船主电话。", "立即续费"); else if (c > 0) {
                        var l = o.alreadyMobiles;
                        i.alert("普通用户最多可查看10个电话，您已查看".concat(l, "个，还可免费查看").concat(c, "个电话。"), {
                            confirmText: "知道了"
                        }).then(function() {
                            return e._contact(a);
                        });
                    } else t.mercury.post("vip/log", {
                        action: "vip_block_contact_ship",
                        target: e.data.id
                    }), e.vipBlock("普通用户可免费查看10个电话，您的查看次数已达上限，请开通货主VIP查看更多空船电话。", "立即开通");
                }
            }).catch(function(a) {
                return t.showError("获取VIP信息", a);
            });
        });
    },
    viewContact: function() {
        this.doMakeContact(!1);
    },
    makeContact: function() {
        this.doMakeContact(!0);
    },
    doMakeContact: function(a) {
        var i = this;
        e.id.get() ? (this.data.tag.official ? this.data.tag.officialContacted : this.data.user.mobiles.indexOf("*") < 0) ? this.dial() : this.data.tag.official ? this._contact(a) : t.mercury.get("pallets/canPublish").then(function(t) {
            t ? i._makeContact(a) : wx.showModal({
                title: "温馨提示",
                content: "您的电话号码未被列入互联网诚信名单，根据工信部对网络安全建设的要求，您不能查看船主的个人信息。为保障您的正常使用，请进行实名认证或取得公司授权",
                success: function(t) {
                    t.confirm ? wx.navigateTo({
                        url: "/pages/settings/certify-mobile/certifyMobile"
                    }) : t.cancel && wx.navigateTo({
                        url: "/pages/settings/company-auth/companyAuth"
                    });
                },
                confirmText: "实名认证",
                cancelText: "公司授权",
                cancelColor: "#3CC51F"
            });
        }) : this.login();
    },
    dial: function() {
        var a = this;
        t.mercury.post("pallets/dial", {
            id: this.data.id,
            page: "ship-detail",
            pallet: this.data.origin
        }).then(function() {
            wx.makePhoneCall({
                phoneNumber: a.data.user.mobiles
            });
        });
    },
    dialService: function() {
        i.dial400();
    },
    contactLimitConfirm: function() {
        wx.navigateBack();
    },
    _loadData: function(a) {
        var e = this;
        return "wl" === a.source && a.hash ? t.mercury.get("wl/shipId?hash=" + a.hash).then(function(t) {
            return e._loadDataHelper({
                id: t,
                origin: 0,
                mark: 0
            });
        }).catch(function(a) {
            404 === a.statusCode ? i.alert("空船不存在或已过期") : t.showError("获取空船信息", a);
        }) : this._loadDataHelper(a);
    },
    _loadDataHelper: function(o) {
        var n = this;
        return t.mercury.get("ships/detail", {
            ship: o.id,
            origin: o.origin,
            mark: o.mark,
            version: "v4"
        }).then(function(t) {
            var e = t.user;
            e.newAvatar ? e.avatarUrl = e.newAvatar : e.avatarUrl = "/images/avatar-none.png";
            var s = t.tag;
            s.photo ? (s.photo.timeText = i.getTimeText(s.photo.time), s.photoUrl = a.mercury("vessels/photo?file=".concat(s.photo.file, "&thumbnail=1")), 
            s.originPhotoUrl = a.mercury("vessels/photo?file=".concat(s.photo.file))) : (s.photoUrl = "/images/photo-empty.png", 
            s.originPhotoUrl = "/images/photo-empty.png");
            var r = [];
            t.item.aimPort && (r = t.item.aimPort.split(",")), t.item.aimPorts = r.join(" ");
            var c = [];
            t.item.blankStart && (c = t.item.blankStart.split(",")), t.item.blankStarts = c.join(" ");
            var l = !/\*+/.test(e.mobiles);
            s.official && (e.vessel = "官方实船" + s.official, l = !!s.officialContacted), n.setData({
                id: t.id,
                item: t.item,
                state: t.state,
                tag: t.tag,
                ad: n.fixAdItem(t.ad || null),
                user: e,
                contacted: l,
                origin: o.origin
            });
        }).catch(function(t) {
            if (403 === t.statusCode) if (e.id.get()) {
                var a = "您已达到今日最大查看空船详情次数，请明天再来看吧！";
                t.data._withMessage_ && (a = t.data.message), "NEED_PALLET_VIP" === t.data.chb2Code ? n.vipBlock(a, "立即开通", "detail", wx.navigateBack) : i.alert(a).then(wx.navigateBack);
            } else wx.showModal({
                title: "温馨提示",
                content: "您已达到今日最大查看空船详情次数，绑定手机号后可查看更多货源",
                showCancel: !1,
                success: function() {
                    return n.login();
                }
            }); else 429 === t.statusCode ? wx.showModal({
                title: "访问过于频繁",
                content: "访问过于频繁",
                showCancel: !1
            }) : 404 === t.statusCode ? wx.showModal({
                title: "空船不存在或已过期",
                content: "空船不存在或已过期",
                showCancel: !1
            }) : wx.showModal({
                title: "查看详情失败",
                content: "查看详情失败",
                showCancel: !1
            });
        });
    },
    fixAdItem: function(t) {
        if (t) if ("ad" === t.adType) {
            t.contents = n.getContents(t.content);
            var e = t.photo;
            e && e.name ? t.avatarUrl = a.mercury("files/load-ad-image?name=".concat(encodeURIComponent(e.name), "&width=60&height=60")) : t.avatarUrl = a.resource("mp/ad-avatar.png");
        } else "section_ad" === t.adType ? t.index = t.adIndex : "used_vessel" === t.adType ? s.fixItem(t) : "sailor_exam" === t.adType && (t.company = r.get()[Math.max(0, (t.id || 0) - 1)]);
        return t;
    },
    preview: function() {
        wx.previewImage({
            urls: [ this.data.tag.originPhotoUrl ]
        });
    },
    onLoad: function(t) {
        var a = this;
        this.setData({
            userId: e.id.get(),
            options: t
        }), this._loadData(t), this.syncUserId = e.id.subscribe(function(e) {
            a.setData({
                userId: e
            }), a._loadData(t);
        });
    },
    onReady: function() {
        this.contactLimit = this.selectComponent("#contact-limit"), this.contactAlert = this.selectComponent("#contact-alert-modal"), 
        this.vipBlockModal = this.selectComponent("#vip-block-modal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this.data.item;
        return {
            title: "".concat(t.weightText, "吨").concat(t.dateText, "空").concat(t.startPort),
            path: i.sharePath({
                id: this.data.options.id,
                mark: this.data.options.mark,
                origin: this.data.options.origin
            })
        };
    }
});