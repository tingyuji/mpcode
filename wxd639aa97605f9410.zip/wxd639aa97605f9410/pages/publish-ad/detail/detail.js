var e = require("../../../utils/util"), t = require("../../../utils/ajax"), a = (require("../../../utils/env"), 
require("../../../utils/globalMap")), n = require("../../../modules/moment"), d = require("../common");

Page({
    initItem: function(e) {
        var t = n().startOf("hour");
        this.adItem.beginTime = this.startTime, this.adItem.endTime = new Date(n(t).add(25, "hours")), 
        this.adItem.leftDays = 0, e.addDays = 0, e.addZones = this.adItem.ports || [], this.fromTime = new Date(n(t).add(1, "hour")), 
        this.setAdItem(e);
    },
    refresh: function() {
        var a = this, d = {
            addDays: 0,
            addZones: []
        }, i = n().startOf("hour");
        this.startTime = new Date(i), this.adItem.id ? (e.showLoading("获取数据中"), t.mercury.get("publishAd/detail", {
            id: this.adItem.id
        }).finally(e.hideLoading).then(function(e) {
            a.adItem = e, a.adItem.isDraft ? a.initItem(d) : (a.adItem.beginTime = new Date(a.adItem.beginTime), 
            a.adItem.endTime = new Date(a.adItem.endTime), d.oldZones = a.adItem.ports || [], 
            a.fromTime = a.adItem.outOfDate ? new Date(n(i).add(1, "hour")) : a.adItem.endTime, 
            a.setAdItem(d));
        }).catch(function(e) {
            return t.showError("读取广告详情", e);
        })) : this.initItem(d);
    },
    warn400: function() {
        e.confirm("由于相关规范，iOS功能暂不可用", {
            cancelText: "以后再说",
            confirmText: "联系客服"
        }).then(function() {
            return e.dial400();
        }).catch(function() {});
    },
    setAdItem: function(e, a) {
        var i = this;
        a && (this.adItem = a), (e = e || {}).adItem = this.adItem, e.beginTime = n(this.adItem.beginTime).format("MM-DD HH:mm"), 
        e.endTime = n(this.adItem.endTime).format("MM-DD HH:mm"), e.target = d.channelTargets[this.adItem.channel] || "", 
        t.mercury.get("publishAd/settle", {
            ad: this.adItem.id,
            countAddDays: void 0 === e.addDays ? this.data.addDays : e.addDays,
            countAddPorts: (void 0 === e.addZones ? this.data.addZones : e.addZones).length
        }).then(function(t) {
            e.shouldPay = t.settle.total || 0, e.needPay = t.settle.real || 0, e.discountReason = t.settle.sale || "", 
            e.renewAmount = t.renew && t.renew.money || 0, e.newAmount = t.new && t.new.money || 0, 
            e.settleNewDays = t.new && +t.new.days || 0, e.settleNewPorts = t.new && +t.new.ports || 0, 
            e.settleRenewDays = t.renew && +t.renew.days || 0, e.settleRenewPorts = t.renew && +t.renew.ports || 0, 
            e.outOfDate = !!i.adItem.outOfDate && !(void 0 === e.addDays ? i.data.addDays : e.addDays), 
            e.leftDays = i.adItem.leftDays || 0, void 0 !== e.addDays && (e.timeIndex = i.data.timeValues.indexOf(e.addDays)), 
            e.oldZones && (e.oldZonesText = e.oldZones.join(" ")), e.addZones && (e.addZonesText = e.addZones.join(" ")), 
            i.setData(e);
        }).catch(function(e) {
            return t.showError("计算广告价格", e);
        });
    },
    editZones: function() {
        var e = this;
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_zones"
        });
        var n = a.register({
            adItem: this.adItem,
            oldZones: this.data.oldZones.slice(),
            addZones: this.data.addZones.slice(),
            allZones: this.data.allZones,
            callback: function(t) {
                e.adItem.ports = e.data.oldZones.concat(t), e.setAdItem({
                    addZones: t
                });
            }
        });
        wx.navigateTo({
            url: "../zones/zones?query=".concat(n, "&source=publishAdDetail")
        });
    },
    timeChange: function(e) {
        var a = e.detail.value, d = this.data.timeValues[a] || 0;
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_time",
            note: {
                days: d
            }
        }), this.adItem.endTime = new Date(n(this.fromTime).add(d, "days")), this.setAdItem({
            timeIndex: a,
            addDays: d
        });
    },
    editContent: function() {
        var e = this;
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_content"
        });
        var n = a.register(this.adItem), d = a.register(function(t) {
            return e.setAdItem(null, t);
        });
        wx.navigateTo({
            url: "../content/content?adItem=".concat(n, "&callback=").concat(d, "&source=publishAdDetail")
        });
    },
    confirmBuy: function() {
        var a = this;
        if (this.data.oldZones.length || this.data.addZones.length) {
            var n = this.adItem.id && !this.adItem.isDraft;
            this.data.addDays || (n ? this.data.addZones.length : this.adItem.leftDays) ? (t.mercury.post("publishAd/log", {
                id: this.adItem.id,
                action: "ad_user_click",
                result: "pay",
                note: {
                    money: this.data.needPay
                }
            }), e.showLoading("提交订单中"), t.mercury.post("publishAd/" + (n ? "charge" : "buy"), {
                ad: {
                    id: this.adItem.id,
                    ports: this.data.addZones,
                    beginTime: this.startTime,
                    days: this.data.addDays,
                    needPay: this.data.shouldPay,
                    sale: this.data.discountReason,
                    realPay: this.data.needPay
                },
                wxpay: !0
            }).finally(e.hideLoading).then(function(e) {
                return a.onPayInfo(e);
            }).catch(function(e) {
                return t.showError("获取支付信息", e);
            })) : e.alert("请选择广告时长");
        } else e.alert("请选择在哪些地区展示您的广告");
    },
    onPayInfo: function(t) {
        var a = this, n = t && t.payInfo && t.payInfo.payInfo;
        n && wx.requestPayment({
            timeStamp: n.timeStamp.toString(),
            nonceStr: n.nonceStr,
            package: n.package,
            signType: n.signType,
            paySign: n.paySign,
            success: function(e) {
                return a.onPayDone(t.ad, t.payInfo.orderId);
            },
            fail: function(t) {
                var a = t.errMsg.indexOf("fail"), n = t.errMsg.slice(a + 4).trim();
                "cancel" !== n && e.alert("付款失败，" + n);
            }
        });
    },
    onPayDone: function(n, d) {
        var i = this;
        e.showLoading("获取结果中"), t.mercury.get("publishAd/payResult", {
            ad: n,
            order: d
        }).finally(e.hideLoading).then(function(e) {
            e && (i.adItem.id || (i.adItem.id = n), t.mercury.post("publishAd/log", {
                id: i.adItem.id,
                action: "ad_pay_done",
                result: i.data.needPay,
                note: {
                    orderId: d
                }
            }), i.refresh(), wx.navigateTo({
                url: "../success/success?adItem=".concat(a.register(i.adItem), "&source=publishAdDetail")
            }));
        }).catch(function(e) {
            return t.showError("获取支付结果", e);
        });
    },
    data: {
        oldZones: [],
        addZones: [],
        oldZonesText: "",
        addZonesText: "",
        addDays: 0,
        outOfDate: !1,
        timeOptions: [ "1天", "3天", "7天", "30天" ],
        timeValues: [ 1, 3, 7, 30 ],
        timeIndex: -1,
        isIOS: e.isIOS()
    },
    onLoad: function(e) {
        var n = this;
        this.adItem = a.unRegister(e.adItem), this.setData({
            adItem: this.adItem,
            target: d.channelTargets[this.adItem.channel]
        }), this.syncAllZones = d.allZones.subscribeAndFireOnce(function(e) {
            return n.setData({
                allZones: e,
                allZoneCount: d.allZones.count
            });
        }), this.refresh(), t.mercury.post("publishAd/log", {
            action: "ad.page_detail",
            id: this.adItem.id,
            result: e.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncAllZones.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/publish-ad/publishAd")
        };
    }
});