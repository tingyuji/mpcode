var t = require("../../../utils/globalMap"), e = require("../../../utils/util"), a = require("../../../utils/ajax"), n = require("../../../utils/env"), o = require("../common");

Page({
    data: {
        isIOS: e.isIOS(),
        title: "",
        content: "",
        photos: []
    },
    onLoad: function(e) {
        var n = this;
        this.callback = t.unRegister(e.callback), this.adItem = t.unRegister(e.adItem) || o.emptyAdItem(e.channel), 
        this.adItem.photos = Array.isArray(this.adItem.photos) ? this.adItem.photos : [], 
        this.setData({
            title: this.adItem.title,
            content: this.adItem.content,
            photos: this.adItem.photos.map(function(t) {
                return Object.assign({}, t, {
                    url: n.getPhotoUrl(t.name, !0),
                    fullUrl: n.getPhotoUrl(t.name, !1)
                });
            }),
            target: o.channelTargets[this.adItem.channel]
        }), a.mercury.post("publishAd/log", {
            action: "ad.page_content",
            id: this.adItem.id,
            result: e.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        var t = this;
        this.saved || this.adItem.id || !(this.data.title && this.data.title.trim() || this.data.content && this.data.content.trim()) || a.mercury.post("publishAd/draft", {
            ad: {
                channel: this.adItem.channel,
                title: this.data.title,
                content: this.data.content,
                photos: this.data.photos
            }
        }).finally(function() {
            t.callback && t.callback();
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/publish-ad/publishAd")
        };
    },
    save: function() {
        var t = this;
        this.saving || (this.saving = !0, this.doSave().finally(function() {
            return t.saving = !1;
        }));
    },
    doSave: function() {
        var t = this;
        return this.data.content ? a.mercury.get("publishAd/scanText", {
            title: this.data.title,
            content: this.data.content
        }).then(function() {
            return t.adItem.title = t.data.title, t.adItem.content = t.data.content, t.adItem.photos = t.data.photos.map(function(t) {
                var e = Object.assign({}, t);
                return delete e.url, delete e.fullUrl, e;
            }), t.adItem.id ? a.mercury.post("publishAd/edit", {
                id: t.adItem.id,
                title: t.data.title,
                content: t.data.content,
                photos: t.data.photos
            }).then(function() {
                return t.saveDone();
            }).catch(function(t) {
                return a.showError("保存广告内容", t);
            }) : a.mercury.post("publishAd/draft", {
                ad: {
                    channel: t.adItem.channel,
                    title: t.data.title,
                    content: t.data.content,
                    photos: t.data.photos
                }
            }).then(function(e) {
                t.adItem.id = e, t.saveDone();
            }).catch(function(t) {
                return a.showError("保存广告内容", t);
            });
        }).catch(function(t) {
            if (403 === t.statusCode) switch (t.data.code) {
              case "ILLEGAL_TITLE":
                return e.alert("您发布的广告标题内容中含有不当言论，请修改后再保存发布");

              case "ILLEGAL_CONTENT":
                return e.alert("您发布的广告正文内容中含有不当言论，请修改后再保存发布");
            }
            return a.showError("内容审核", t);
        }) : e.alert("请输入广告正文");
    },
    saveDone: function() {
        this.saved = !0, wx.navigateTo({
            url: "../detail/detail?adItem=".concat(t.register(this.adItem), "&source=publishAdContent")
        });
    },
    titleChange: function(t) {
        this.data.title = t.detail.value;
    },
    contentChange: function(t) {
        this.data.content = t.detail.value;
    },
    upload: function() {
        var t = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(n) {
                var o = n.tempFilePaths[0];
                o && (t.setData({
                    showUploadProgress: !0,
                    uploadProgress: 0
                }), e.showLoading("图片上传中"), a.mercury.upload("files/upload-ad-image", o, "image/jpeg", {
                    ad: t.adItem.id,
                    suffix: "jpg"
                }, null, {
                    onProgress: function(e) {
                        return t.setData({
                            uploadProgress: e.progress
                        });
                    }
                }).finally(function() {
                    e.hideLoading(), t.setData({
                        showUploadProgress: !1
                    });
                }).then(function(e) {
                    return t.addPhoto(e);
                }).catch(function(t) {
                    403 === t.statusCode && "ILLEGAL_IMAGE" === t.data.code ? e.alert("您上传的图片涉及内容违规，请更换图片重新上传") : a.showError("上传图片", t);
                }));
            }
        });
    },
    addPhoto: function(t) {
        var e = this.data.photos.concat({
            name: t,
            url: this.getPhotoUrl(t, !0),
            fullUrl: this.getPhotoUrl(t, !1)
        });
        this.setData({
            photos: e
        });
    },
    getPhotoUrl: function(t, e) {
        var a = e ? "&size=100&mode=fill" : "&size=1280";
        return n.mercury("files/load-ad-image?name=".concat(encodeURIComponent(t)).concat(a));
    },
    preview: function(t) {
        var e = t.currentTarget.dataset.photo;
        wx.previewImage({
            urls: this.data.photos.map(function(t) {
                return t.fullUrl;
            }),
            current: e.fullUrl
        });
    },
    remove: function(t) {
        var a = this, n = t.currentTarget.dataset.photo;
        e.confirm("确认删除此照片吗？").then(function() {
            var t = a.data.photos.slice(), e = t.findIndex(function(t) {
                return t.name === n.name;
            });
            e >= 0 && (t.splice(e, 1), a.setData({
                photos: t
            }));
        });
    }
});