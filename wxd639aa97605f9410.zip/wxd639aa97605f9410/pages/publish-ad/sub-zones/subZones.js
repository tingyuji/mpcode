var e = require("../../../utils/globalMap"), a = require("../../../utils/ajax"), t = require("../../../utils/util");

Page({
    confirm: function() {
        a.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_zones_".concat(this.data.name, "_done"),
            note: {
                addZones: this.data.addZones
            }
        }), this.callback && this.callback(this.data.addZones), wx.navigateBack();
    },
    allCheckedChange: function(e) {
        var a = !!e.detail.value, t = {};
        this.data.options.forEach(function(e) {
            return t[e] = a;
        }), this.setData({
            allChecked: a,
            checked: t,
            addZones: a ? this.data.options : []
        });
    },
    checkedChange: function(e) {
        var a = !!e.detail.value, t = e.currentTarget.dataset.option, n = Object.assign({}, this.data.checked), o = new Set(this.data.addZones);
        n[t] = a, a ? o.add(t) : o.delete(t), this.setData({
            allChecked: !this.data.options.find(function(e) {
                return !n[e];
            }),
            checked: n,
            addZones: Array.from(o)
        });
    },
    data: {
        name: "",
        oldZonesText: "",
        oldZones: [],
        addZones: [],
        options: [],
        allChecked: !1,
        checked: {}
    },
    onLoad: function(t) {
        var n = e.unRegister(t.query);
        this.callback = n.callback, this.adItem = n.adItem;
        var o = new Set(n.options);
        n.oldZones.forEach(function(e) {
            return o.delete(e);
        });
        var d = Array.from(o), s = new Set(n.addZones), i = {};
        d.forEach(function(e) {
            return i[e] = s.has(e);
        }), this.setData({
            name: n.name,
            options: d,
            checked: i,
            allChecked: n.addZones.length >= d.length,
            oldZones: n.oldZones,
            addZones: n.addZones,
            oldZonesText: n.oldZones.join()
        }), a.mercury.post("publishAd/log", {
            action: "ad.page_subZone",
            id: this.adItem.id,
            result: t.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/publish-ad/publishAd")
        };
    }
});