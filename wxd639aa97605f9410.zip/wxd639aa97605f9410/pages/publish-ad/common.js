var e = require("../../utils/observable"), t = require("../../utils/ajax"), n = require("../../utils/user"), r = new e(null);

function s() {
    n.id.get() && t.mercury.get("publishAd/choosePorts").then(function(e) {
        e && (r.count = Object.getOwnPropertyNames(e).reduce(function(t, n) {
            return t + e[n].length;
        }, 0), r.set(e));
    });
}

r.count = 0, r.refresh = s, n.id.subscribeAndFireOnce(s), module.exports = {
    emptyAdItem: function(e) {
        return Object.assign({}, {
            id: 0,
            title: "",
            content: "",
            photos: [],
            channel: e,
            isDraft: !0
        });
    },
    channelTargets: {
        pallet: "货主",
        ship: "船主"
    },
    searchTargets: {
        pallet: "空船",
        ship: "货源"
    },
    channelToPage: {
        pallet: "zhaochuan",
        ship: "zhaohuo"
    },
    allZones: r,
    zoneToPorts: {
        "苏北内河": "淮安",
        "苏南内河": "苏州",
        "安徽内河": "蚌埠",
        "山东内河": "济宁",
        "浙江内河": "杭州",
        "江西内河": "南昌",
        "湖南内河": "长沙",
        "湖北内河": "襄阳",
        "四川内河": "乐山",
        "河南内河": "周口"
    },
    zonesJson: function(e) {
        return JSON.stringify(Array.from(new Set(e)).sort());
    }
};