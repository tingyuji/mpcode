var e = require("../../../utils/globalMap"), n = require("../../../utils/util"), t = require("../../../utils/ajax"), o = require("../common");

Page({
    updateData: function(e) {
        e.oldZonesCj && (e.oldZonesCjText = e.oldZonesCj.join()), e.oldZonesNh && (e.oldZonesNhText = e.oldZonesNh.join()), 
        e.addZonesCj && (e.addZonesCjText = e.addZonesCj.join()), e.addZonesNh && (e.addZonesNhText = e.addZonesNh.join()), 
        this.setData(e);
    },
    editZonesCj: function() {
        var n = this;
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_zones_长江"
        });
        var o = e.register({
            adItem: this.adItem,
            name: "长江",
            options: Array.from(this.cjZoneOptionSet),
            oldZones: this.data.oldZonesCj.slice(),
            addZones: this.data.addZonesCj.slice(),
            callback: function(e) {
                return n.updateData({
                    addZonesCj: e
                });
            }
        });
        wx.navigateTo({
            url: "../sub-zones/subZones?query=".concat(o, "&source=publishAdZone")
        });
    },
    editZonesNh: function() {
        var n = this;
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "edit_zones_内河"
        });
        var o = e.register({
            adItem: this.adItem,
            name: "内河",
            options: Array.from(this.nhZoneOptionSet),
            oldZones: this.data.oldZonesNh.slice(),
            addZones: this.data.addZonesNh.slice(),
            callback: function(e) {
                return n.updateData({
                    addZonesNh: e
                });
            }
        });
        wx.navigateTo({
            url: "../sub-zones/subZones?query=".concat(o, "&source=publishAdZone")
        });
    },
    confirm: function() {
        if (this.data.oldZonesCj.length + this.data.oldZonesNh.length + this.data.addZonesCj.length + this.data.addZonesNh.length > 0) {
            var e = this.data.addZonesCj.concat(this.data.addZonesNh);
            t.mercury.post("publishAd/log", {
                id: this.adItem.id,
                action: "ad_user_click",
                result: "edit_zones_done",
                note: {
                    addZones: e
                }
            }), this.callback && this.callback(e), wx.navigateBack();
        } else n.alert("至少要选择一个地区");
    },
    data: {
        oldZonesCj: [],
        oldZonesNh: [],
        addZonesCj: [],
        addZonesNh: [],
        oldZonesCjText: "",
        oldZonesNhText: "",
        addZonesCjText: "",
        addZonesNhText: ""
    },
    onLoad: function(n) {
        var a = this, s = e.unRegister(n.query);
        this.adItem = s.adItem, this.allZoneOptions = s.allZones, this.callback = s.callback;
        var i = s.oldZones, d = s.addZones;
        this.cjZoneOptionSet = new Set(this.allZoneOptions.changjiang.map(function(e) {
            return e.name;
        })), this.nhZoneOptionSet = new Set(this.allZoneOptions.neihe.map(function(e) {
            return e.name;
        }));
        var l = {
            searchTarget: o.searchTargets[this.adItem.channel],
            oldZonesCj: i.filter(function(e) {
                return a.cjZoneOptionSet.has(e);
            }),
            oldZonesNh: i.filter(function(e) {
                return a.nhZoneOptionSet.has(e);
            }),
            addZonesCj: d.filter(function(e) {
                return a.cjZoneOptionSet.has(e);
            }),
            addZonesNh: d.filter(function(e) {
                return a.nhZoneOptionSet.has(e);
            })
        };
        this.updateData(l), t.mercury.post("publishAd/log", {
            action: "ad.page_zone",
            id: this.adItem.id,
            result: n.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/publish-ad/publishAd")
        };
    }
});