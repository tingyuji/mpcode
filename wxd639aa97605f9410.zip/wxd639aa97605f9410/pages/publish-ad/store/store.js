var t = require("../../../modules/moment"), e = require("../../../utils/globalMap"), o = require("../../../utils/ajax"), i = require("../../../utils/util"), n = require("../common");

Page({
    load: function() {
        var e = this;
        i.showLoading("获取数据中"), o.mercury.get("publishAd/storeList", {
            id: this.adItem.id
        }).finally(i.hideLoading).then(function(o) {
            o.forEach(function(e) {
                return e.time = t(e.updateTime).format("YYYY-MM-DD HH:mm");
            }), e.setData({
                items: o,
                storeCount: o.length
            });
        }).catch(function(t) {
            return o.showError("获取广告收藏数据", t);
        });
    },
    dial: function(t) {
        var e = t.currentTarget.dataset.item;
        o.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_store_dial",
            result: e.user,
            note: {
                mobile: e.mobile
            }
        }), wx.makePhoneCall({
            phoneNumber: e.mobile
        });
    },
    data: {},
    onLoad: function(t) {
        this.adItem = e.unRegister(t.adItem), this.setData({
            storeCount: this.adItem.storeCount,
            target: n.channelTargets[this.adItem.channel]
        }), this.load(), o.mercury.post("publishAd/log", {
            action: "ad.page_store",
            id: this.adItem.id,
            result: t.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: i.shareTitle,
            path: i.shareToPath("/pages/publish-ad/publishAd")
        };
    }
});