var e = require("../../utils/env"), t = require("../../utils/util"), r = require("../../utils/ajax"), i = require("../../utils/user"), a = require("./common"), n = require("../../utils/globalMap");

Page({
    data: {
        isIOS: t.isIOS(),
        advertisePic: e.resource("images/publish-ad-advertise.jpg?ts=1651893779812"),
        advertisePic2_1: e.resource("images/publish-ad-ad2-1.jpg?ts=1651893779812"),
        advertisePic2_2: e.resource("images/publish-ad-ad2-2.jpg?ts=1651893779812"),
        advertisePic2_3: e.resource("images/publish-ad-ad2-3.jpg?ts=1651893779812"),
        advertisePic2_4: e.resource("images/publish-ad-ad2-4.jpg?ts=1651893779812"),
        advertisePic2_5: e.resource("images/publish-ad-ad2-5.jpg?ts=1651893779812")
    },
    onLoad: function(e) {
        var n = this;
        this.portCounts = 0, t.checkUserLogin(this), this.syncUserId = i.id.subscribeAndFireOnce(function(e) {
            return n.setData({
                userId: e
            });
        }), this.syncZones = a.allZones.subscribeAndFireOnce(function() {
            return n.refresh();
        }), r.mercury.post("publishAd/log", {
            action: "ad.page_main",
            result: e.source
        });
    },
    onReady: function() {
        this.privacyAlertModal = this.selectComponent("#privacyAlertModal"), this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        t.checkUserShow(this), i.id.get() && this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncZones.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    },
    refresh: function() {
        var e = this;
        i.id.get() ? (t.showLoading("获取数据中"), r.mercury.get("publishAd/myList", {
            version: 2
        }).finally(function() {
            t.hideLoading(), wx.stopPullDownRefresh();
        }).then(function(t) {
            t.forEach(function(e) {
                e.allPorts = e.ports && e.ports.length >= a.allZones.count;
            }), e.setData({
                items: t
            });
        }).catch(function(e) {
            return r.showError("获取广告数据", e);
        })) : this.setData({
            items: []
        });
    },
    goToHelp: function() {
        t.browse(e.resource("app-help/how-to-publish-ad.html?ts=".concat(new Date().getTime())), "publish-ad-help");
    },
    toSender: function() {
        var e = this;
        r.mercury.post("publishAd/log", {
            action: "ad_user_click",
            result: "to_xunchuan"
        }), this.data.isIOS ? t.confirm("由于相关规范，iOS功能暂不可用", {
            cancelText: "以后再说",
            confirmText: "联系客服"
        }).then(function() {
            return t.dial400();
        }).catch(function() {}) : this.deadbeatBlockModal.check("ad_publish").then(function(t) {
            t && e.privacyAlert().then(function() {
                var t = n.register(e.refresh.bind(e));
                wx.navigateTo({
                    url: "./content/content?callback=".concat(t, "&channel=pallet&source=publishAd")
                });
            });
        });
    },
    toCarrier: function() {
        var e = this;
        r.mercury.post("publishAd/log", {
            action: "ad_user_click",
            result: "to_zhaohuo"
        }), this.data.isIOS ? t.confirm("由于相关规范，iOS功能暂不可用", {
            cancelText: "以后再说",
            confirmText: "联系客服"
        }).then(function() {
            return t.dial400();
        }).catch(function() {}) : this.deadbeatBlockModal.check("ad_publish").then(function(t) {
            t && e.privacyAlert().then(function() {
                var t = n.register(e.refresh.bind(e));
                wx.navigateTo({
                    url: "./content/content?callback=".concat(t, "&channel=ship&source=publishAd")
                });
            });
        });
    },
    privacyAlert: function() {
        var e = this;
        return new Promise(function(t) {
            e.setData({
                privacyAlertCountDown: 3
            });
            var r = setInterval(function() {
                e.data.privacyAlertCountDown > 0 ? e.setData({
                    privacyAlertCountDown: e.data.privacyAlertCountDown - 1
                }) : clearInterval(r);
            }, 1e3);
            e.privacyAlertCallback = t, e.privacyAlertModal.showModal();
        });
    },
    privacyAlertConfirm: function() {
        this.data.privacyAlertCountDown > 0 || (this.privacyAlertModal.hideModal(), this.privacyAlertCallback && (this.privacyAlertCallback(), 
        this.privacyAlertCallback = null));
    },
    remove: function(e) {
        var i = this, a = e.currentTarget.dataset.item;
        r.mercury.post("publishAd/log", {
            id: a.id,
            action: "ad_user_click",
            result: "remove_ad"
        });
        var n = a.outOfDate ? "" : "已删除的广告将不再展示给用户，剩余费用将不会退还，";
        t.confirm(n + "确定删除此广告？").then(function() {
            r.mercury.post("publishAd/remove", {
                id: a.id
            }).finally(function() {
                return i.refresh();
            }).catch(function(e) {
                return r.showError("删除广告", e);
            });
        });
    },
    edit: function(e) {
        var t = e.currentTarget.dataset.item;
        r.mercury.post("publishAd/log", {
            id: t.id,
            action: "ad_user_click",
            result: "edit_renew"
        }), wx.navigateTo({
            url: "./content/content?adItem=".concat(n.register(t), "&source=publishAd")
        });
    },
    viewStore: function(e) {
        var t = e.currentTarget.dataset.item;
        r.mercury.post("publishAd/log", {
            id: t.id,
            action: "ad_user_click",
            result: "view_store"
        }), wx.navigateTo({
            url: "./store/store?adItem=".concat(n.register(t), "&source=publishAd")
        });
    }
});