var e = require("../../../utils/globalMap"), t = require("../../../utils/ajax"), n = require("../../../utils/util"), o = require("../common");

Page({
    viewResult: function() {
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_user_click",
            result: "view_result"
        });
        var e = this.adItem.ports[0], n = o.zoneToPorts[e] || e, a = o.channelToPage[this.adItem.channel], i = encodeURIComponent("/pages/".concat(a, "/").concat(a, "?searchPort=").concat(n));
        wx.reLaunch({
            url: "/pages/index/index?navigate=".concat(i)
        });
    },
    data: {},
    onLoad: function(n) {
        this.adItem = e.unRegister(n.adItem), t.mercury.post("publishAd/log", {
            action: "ad.page_success",
            id: this.adItem.id,
            result: n.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/publish-ad/publishAd")
        };
    }
});