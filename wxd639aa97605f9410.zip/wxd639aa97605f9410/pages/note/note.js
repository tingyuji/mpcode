var a = require("../../utils/globalMap");

Page({
    data: {
        value: ""
    },
    onLoad: function(a) {
        var n = a.value, t = a.callback;
        this.setData({
            value: n,
            callback: t
        });
    },
    ensure: function() {
        var n = a.get(this.data.callback);
        n && n(this.data.value), wx.navigateBack();
    },
    valueChange: function(a) {
        this.data.value = a.detail.value;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});