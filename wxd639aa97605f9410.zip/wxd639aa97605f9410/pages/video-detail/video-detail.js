Page({
    data: {
        url: null,
        width: getApp().globalData.systemInfo.windowWidth,
        height: getApp().globalData.systemInfo.windowHeight
    },
    onLoad: function(n) {
        this.url = n.url, this.setData({
            url: decodeURIComponent(this.url)
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});