require("../../../modules/moment");

var e = require("../../../dao/vessel"), t = require("../../../utils/ajax"), n = require("../../../utils/util"), i = require("../../../utils/user");

Page({
    data: {
        vessel: null,
        inCertify: !1,
        bridgePositions: [ "前置", "后置" ],
        bridgePositionValues: [ "fore", "aft" ],
        fengcangs: [ "无封舱", "自动封舱", "棚架", "雨布" ],
        fengcangValues: [ "none", "auto", "manual", "waterproof" ],
        sinks: [ "无", "有" ],
        sinkValues: [ "no", "yes" ],
        certified: !1
    },
    modifyAlert: function() {
        n.alert("已认证的船舶不能更改船名");
    },
    onLoad: function(a) {
        var s = this;
        n.checkUserLogin(this), this.syncUserId = i.id.subscribeAndFireOnce(function(e) {
            return s.setData({
                userId: e
            });
        }), this.syncVessel = e.subscribeAndFireOnce(function(e) {
            return s.setData({
                vessel: e || null,
                inCertify: e && (e.certified || e.certifying),
                name: e && e.name || null,
                mmsi: e && e.mmsi || null,
                mmsiCertifyState: e && e.mmsiCertifyState || "",
                deadweightTonnage: e && e.deadweightTonnage || null,
                bridgePosition: e ? s.data.bridgePositionValues.indexOf(e.bridgePosition) : -1,
                fengcang: e ? s.data.fengcangValues.indexOf(e.fengcang) : -1,
                sink: e ? s.data.sinkValues.indexOf(e.sink) : -1,
                note: e && e.note || null,
                certified: e && e.certified || 0
            });
        }), i.id.get() && (n.showLoading("数据加载中"), e.refresh().finally(n.hideLoading).then(function() {
            "mmsi-cert" === a.action && setTimeout(function() {
                return s.mmsiPhoto();
            });
        }).catch(function(e) {
            return t.showError("获取船舶信息", e);
        }));
    },
    onReady: function() {},
    onShow: function() {
        n.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncVessel.dispose();
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.sharePath()
        };
    },
    nameChange: function(e) {
        this.data.name = e.detail.value;
    },
    mmsiChange: function(e) {
        this.data.mmsi = e.detail.value;
    },
    deadweightTonnageChange: function(e) {
        this.data.deadweightTonnage = e.detail.value;
    },
    bridgePositionChange: function(e) {
        this.setData({
            bridgePosition: e.detail.value
        });
    },
    fengcangChange: function(e) {
        this.setData({
            fengcang: e.detail.value
        });
    },
    sinkChange: function(e) {
        this.setData({
            sink: e.detail.value
        });
    },
    noteChange: function(e) {
        this.data.note = e.detail;
    },
    publish: function(i) {
        if ((this.data.name || "").trim()) if (this.data.deadweightTonnage) if (this.data.mmsi && (+this.data.mmsi < 1e8 || +this.data.mmsi > 999999999)) n.alert("请输入9位数字的AIS标识码"); else {
            var a = {
                id: this.data.vessel && this.data.vessel.id,
                name: this.data.name,
                mmsi: +this.data.mmsi || null,
                deadweightTonnage: this.data.deadweightTonnage,
                bridgePosition: this.data.bridgePositionValues[this.data.bridgePosition] || "unknown",
                fengcang: this.data.fengcangValues[this.data.fengcang] || "unknown",
                sink: this.data.sinkValues[this.data.sink] || "unknown",
                note: this.data.note
            };
            n.showLoading("保存数据中"), t.mercury.post("vessels/save", a).finally(n.hideLoading).then(function(t) {
                e.refresh(), wx.navigateBack();
            }).catch(function(i) {
                var a = null;
                409 === i.statusCode ? a = "与您名下的其它船舶重名，点击确认重新同步数据。" : 403 !== i.statusCode || "VESSEL_CERTIFYING" !== i.data.code && "VESSEL_CERTIFIED" !== i.data.code || (a = ("VESSEL_CERTIFYING" === i.data.code ? "船舶档案正在认证中" : "船舶档案已通过认证") + "，不能修改船名。"), 
                a ? n.alert("保存船舶档案信息失败，" + a).then(e.refresh) : t.showError("保存船舶档案信息", i);
            });
        } else n.alert("请输入船皮"); else n.alert("请输入船名");
    },
    remove: function(e) {
        var t = this;
        this.data.vessel && (this.data.vessel.certified ? n.confirm("删除船舶后无法查看货主电话，如有新船，请删除后重新认证。", {
            confirmText: "删除"
        }).then(function() {
            return t.doRemove();
        }) : n.confirm("是否确定删除该船舶？").then(function() {
            return t.doRemove();
        }));
    },
    doRemove: function() {
        return n.showLoading("删除船舶中"), t.mercury.post("vessels/remove", {
            id: this.data.vessel.id
        }).finally(n.hideLoading).then(function() {
            e.refresh(), wx.navigateBack();
        }).catch(function(e) {
            return t.showError("删除船舶", e);
        });
    },
    mmsiPhoto: function() {
        var i = this;
        this.takingPhoto || (this.takingPhoto = !0, this.doTakePhoto().finally(function() {
            return i.takingPhoto = !1;
        }).then(function(a) {
            return n.showLoading("上传照片"), t.mercury.upload("vessels/mmsiPhoto", a, "image/jpeg", {
                vessel: i.data.vessel && i.data.vessel.id || 0,
                suffix: "jpg"
            }).finally(n.hideLoading).then(function(t) {
                (t = +t || 0) > 0 && (i.setData({
                    mmsiCertifyState: "certifying"
                }), e.get() && e.refresh());
            }).catch(function(e) {
                return t.showError("上传照片", e);
            });
        }));
    },
    doTakePhoto: function() {
        return new Promise(function(e, t) {
            wx.chooseImage({
                count: 1,
                sizeType: [ "original" ],
                sourceType: [ "camera" ],
                success: function(t) {
                    return e(t.tempFilePaths[0]);
                },
                fail: t
            });
        });
    }
});