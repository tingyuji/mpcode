var e = require("../../../../utils/ajax"), t = require("../../../../utils/util"), a = (require("../../../../utils/env"), 
require("../../../../dao/pallet"));

Page({
    load: function(n) {
        var i = this;
        t.showLoading("获取数据中"), e.moon.get("saturn/pallet/".concat(n)).finally(t.hideLoading).then(function(e) {
            return i.setData({
                pallet: a.fixInView(e)
            });
        }).catch(function(t) {
            return e.showError("获取货源详情", t);
        });
    },
    preview: function(e) {
        var t = e.currentTarget.dataset.media, a = this.data.pallet.media.findIndex(function(e) {
            return e.id === t.id;
        });
        a = Math.max(0, a), wx.previewMedia({
            sources: this.data.pallet.media.map(function(e) {
                return {
                    url: e.url,
                    type: e.isVideo ? "video" : "image",
                    poster: e.thumbnail
                };
            }),
            current: a
        });
    },
    previewLocation: function(e) {
        var t = e.currentTarget.dataset.location;
        wx.openLocation({
            latitude: t.lat,
            longitude: t.lng,
            name: t.poiname,
            address: t.poiaddress
        });
    },
    data: {
        pallet: null
    },
    onLoad: function(e) {
        this.load(e.id);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var a = this.data.pallet, n = "".concat(a.startPort, " → ").concat(a.aimPort, " ").concat(a.cargo, " ").concat(a.name), i = "/pages/pallet-detail/pallet-detail?id=".concat(a.id, "&origin=0&mark=0&showIndex=").concat(a.showIndex, "&originType=flag-ship-store");
        return {
            title: n,
            path: "/pages/index/index?navigate=" + encodeURIComponent(i),
            success: function(n) {
                "shareAppMessage:ok" === n.errMsg && e.mercury.post("miniProgram/sharePage", {
                    page: t.getCurrentPageName(),
                    target: a.id
                });
            }
        };
    }
});