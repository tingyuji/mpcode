var e = require("../../../utils/util"), t = require("../../../utils/ajax"), a = require("../../../utils/env"), o = require("../../../utils/user"), r = require("../../../dao/enterprise"), n = require("../../../dao/pallet");

Page({
    refresh: function() {
        var a = this;
        e.showLoading("获取数据中"), r.refresh().then(function() {
            return a.data.store ? t.moon.get("saturn/pallet") : [];
        }).finally(function() {
            e.hideLoading(), wx.stopPullDownRefresh();
        }).then(function(e) {
            return a.setData({
                pallets: e.map(n.fixPallet)
            });
        }).catch(function(e) {
            return t.showError("获取官方旗舰店信息");
        });
    },
    onFoldThumbs: function() {
        this.setData({
            foldThumbs: !this.data.foldThumbs
        });
    },
    toIntro: function() {
        t.mercury.post("store/viewPage", {
            page: "flagShipStoreIntroduce",
            source: "flagShipStore"
        });
    },
    viewDetail: function(e) {
        var t = e.currentTarget.dataset.pallet;
        o.id.get() === t.user ? wx.navigateTo({
            url: "/pages/edit-pallet-detail/edit-pallet-detail?id=".concat(t.id)
        }) : wx.navigateTo({
            url: "./view-pallet/viewPallet?id=".concat(t.id)
        });
    },
    data: {
        foldThumbs: !0,
        introPage: "/pages/web-view/webView?url=".concat(encodeURIComponent(a.resource("app-help/flag-ship-store.html?ts=".concat(new Date().getTime())))),
        pallets: []
    },
    onLoad: function(e) {
        var a = this;
        this.syncStore = r.subscribeAndFireOnce(function(e) {
            a.setData({
                store: e && e.store || null
            }), a.data.store || wx.redirectTo({
                url: a.data.introPage
            });
        });
        var o = this.data.store ? "flagShipStore" : "flagShipStoreIntroduce";
        t.mercury.post("store/viewPage", {
            page: o,
            source: e.source || "share"
        });
    },
    onReady: function() {},
    onShow: function() {
        this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncStore.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/settings/my-company/myCompany")
        };
    }
});