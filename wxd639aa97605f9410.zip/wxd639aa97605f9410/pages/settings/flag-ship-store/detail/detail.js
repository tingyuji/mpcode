var e = require("../../../../dao/enterprise"), t = require("../../../../utils/util"), o = require("../../../../utils/ajax");

Page({
    changeName: function() {
        this.setData({
            newName: this.data.store.name
        }), this.nameModal.show();
    },
    newNameChange: function(e) {
        this.data.newName = (e.detail.value || "").trim();
    },
    confirmName: function() {
        var n = this.data.newName;
        n && n.length >= 4 && n.length <= 7 ? (this.nameModal.hide(), o.mercury.post("store/update", {
            name: n
        }).then(e.refresh).catch(function(e) {
            return o.showError("修改公司简称", e);
        })) : t.alert("公司简称应在4到7个字之间");
    },
    editBrief: function() {
        this.briefNote.input();
    },
    briefChange: function(t) {
        o.mercury.post("store/update", {
            brief: t.detail
        }).then(e.refresh).catch(function(e) {
            return o.showError("修改公司简介", e);
        });
    },
    changeLogo: function() {
        var n = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(r) {
                var a = r.tempFilePaths[0];
                a && (n.setData({
                    showUploadProgress: !0,
                    uploadProgress: 0
                }), t.showLoading("图片上传中"), o.mercury.upload("store/uploadLogo", a, "image/jpeg", null, null, {
                    onProgress: function(e) {
                        return n.setData({
                            uploadProgress: e.progress
                        });
                    }
                }).finally(function() {
                    t.hideLoading(), n.setData({
                        showUploadProgress: !1
                    });
                }).then(function(t) {
                    o.mercury.post("store/update", {
                        logo: t
                    }).then(e.refresh).catch(function(e) {
                        return o.showError("修改品牌形象", e);
                    });
                }).catch(function(e) {
                    403 === e.statusCode && "ILLEGAL_IMAGE" === e.data.code ? t.alert("您上传的图片涉及内容违规，请更换图片重新上传") : o.showError("上传品牌形象文件", e);
                }));
            }
        });
    },
    data: {},
    onLoad: function(t) {
        var o = this;
        this.syncStore = e.subscribeAndFireOnce(function(e) {
            return o.setData({
                store: e && e.store || null
            });
        });
    },
    onReady: function() {
        this.nameModal = this.selectComponent("#nameModal"), this.briefNote = this.selectComponent("#briefNote");
    },
    onShow: function() {
        this.briefNote && this.briefNote.setData({
            readonly: !1
        });
    },
    onHide: function() {
        this.briefNote.setData({
            readonly: !0
        });
    },
    onUnload: function() {
        this.syncStore.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/settings/my-company/myCompany")
        };
    }
});