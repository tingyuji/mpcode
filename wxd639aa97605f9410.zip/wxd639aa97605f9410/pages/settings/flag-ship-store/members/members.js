var e = require("../../../../dao/enterprise"), t = require("../../../../utils/util"), o = require("../../../../utils/user"), n = require("../../../../utils/ajax"), a = require("../../../../utils/ad");

Page({
    membersLeft: function(e) {
        return Math.max(0, e && e.maxMembers - e.members.length || 0);
    },
    add: function() {
        this.membersLeft(this.data.store) > 0 ? (this.setData({
            mobile: "",
            validMobile: !1,
            resend: !1,
            code: "",
            validCode: !1,
            countDown: 0
        }), this.newMemberModal.show()) : t.alert("您的公司已不能添加新成员，如需添加更多成员请联系船货不二客服");
    },
    mobileChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), o = /^1\d{10}$/.test(t);
        this.setData({
            mobile: t,
            validMobile: o
        });
    },
    codeChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), o = /^\d{6}$/.test(t);
        this.setData({
            code: t,
            validCode: o
        });
    },
    sendCode: function(o) {
        var a = this;
        this.data.validMobile && !this.data.countDown && (t.showLoading("发送验证码"), n.moon.post("enterprises/".concat(e.get().id, "/codes"), {
            mobile: this.data.mobile
        }).finally(t.hideLoading).then(function() {
            t.alert("短信验证码已发送给".concat(a.data.mobile, "，有效时间30分钟")), a.startCountDown(60);
        }).catch(function(e) {
            return a.showCodeError(e);
        }));
    },
    startCountDown: function(e) {
        var t = this;
        this.setData({
            countDown: e,
            resend: !0
        });
        var o = setInterval(function() {
            t.data.countDown > 0 ? t.setData({
                countDown: --t.data.countDown
            }) : clearInterval(o);
        }, 1e3);
    },
    showCodeError: function(e) {
        var o = null;
        switch (e.statusCode) {
          case 404:
            o = "电话号码不是船货不二注册用户";
            break;

          case 409:
            o = "该成员已经被添加";
            break;

          case 403:
            o = a.getContents(e.data);
        }
        Array.isArray(o) ? (this.setData({
            messageNodes: o
        }), this.alertModal.show()) : o ? t.alert(o) : n.showError("发送短信验证码", e);
    },
    confirmNewMember: function() {
        var o = this;
        this.data.validMobile ? this.data.validCode ? (t.showLoading("校验验证码"), n.moon.post("enterprises/".concat(e.get().id, "/users"), {
            mobile: this.data.mobile,
            code: this.data.code
        }).finally(t.hideLoading).then(function() {
            o.newMemberModal.hide(), e.refresh();
        }).catch(function(e) {
            return o.showVerifyError(e);
        })) : t.alert("无效的短信验证码") : t.alert("无效的手机号");
    },
    showVerifyError: function(e) {
        403 === e.statusCode && e.data && "string" == typeof e.data ? (this.setData({
            messageNodes: a.getContents(e.data)
        }), this.alertModal.show()) : n.showError("校验短信验证码", e);
    },
    confirmAlert: function() {
        this.alertModal.hide();
    },
    call: function(e) {
        var t = (e.currentTarget.dataset.mobile || "").replace(/-/g, "");
        wx.makePhoneCall({
            phoneNumber: t
        });
    },
    actions: function(n) {
        var a = this, r = n.currentTarget.dataset.member, s = [ {
            text: "设为管理员",
            value: "promote"
        }, {
            text: "移除",
            value: "remove"
        } ];
        if (r.user === o.id.get()) {
            if (1 === this.data.store.members.length) return t.alert("官方旗舰店中至少要保留一个人");
            s = [ {
                text: "离开公司",
                value: "leave"
            } ];
        } else r.isAdmin && (s = [ {
            text: "解除管理员",
            value: "demote"
        }, {
            text: "移除",
            value: "remove"
        } ]);
        this.chooseAction(r, s).then(function(t) {
            t && a.doAction(r, t).then(function(o) {
                o && ("leave" === t ? wx.reLaunch({
                    url: "/pages/index/index?tab=settings"
                }) : e.refresh());
            });
        });
    },
    chooseAction: function(e, t) {
        return new Promise(function(e) {
            wx.showActionSheet({
                itemList: t.map(function(e) {
                    return e.text;
                }),
                success: function(o) {
                    o.cancel || e(t[o.tapIndex].value);
                }
            });
        });
    },
    doAction: function(e, o) {
        var n = this;
        return new Promise(function(a, r) {
            var s = "";
            switch (o) {
              case "leave":
                s = n.data.store.members.filter(function(e) {
                    return e.isAdmin;
                }).length <= 1 ? "您如果离开，公司将自动解散，所有信息将被删除，确定离开并解散公司“".concat(n.data.store.name, "”？") : "确定离开公司“".concat(n.data.store.name, "”？");
                break;

              case "remove":
                s = "确定移除人员“".concat(e.name, "”？");
                break;

              case "promote":
                s = "确定提升“".concat(e.name, "”为管理员？");
                break;

              case "demote":
                s = "确定解除“".concat(e.name, "”的管理员身份？");
                break;

              default:
                return void r("unknown action: " + o);
            }
            t.confirm(s).then(function() {
                n.doActionHelper(e, o).then(function() {
                    return a(!0);
                }).catch(function(e) {
                    n.showActionError(e), a(!1);
                });
            }).catch(function(e) {
                return a(!1);
            });
        });
    },
    doActionHelper: function(t, o) {
        var a = e.get().id;
        switch (o) {
          case "leave":
            return n.moon.del("enterprises/".concat(a, "/users/current"));

          case "remove":
            return n.moon.del("enterprises/".concat(a, "/users/").concat(t.user));

          case "promote":
            return n.moon.put("enterprises/".concat(a, "/users/").concat(t.user, "/role"), {
                role: "admin"
            });

          case "demote":
            return n.moon.put("enterprises/".concat(a, "/users/").concat(t.user, "/role"), {
                role: "employee"
            });

          default:
            return Promise.reject("unknown action: " + o);
        }
    },
    showActionError: function(e) {
        403 === e.statusCode && e.data && "string" == typeof e.data ? (this.setData({
            messageNodes: a.getContents(e.data)
        }), this.alertModal.show()) : n.showError("人员管理操作", e);
    },
    data: {
        mobile: "",
        validMobile: !1,
        resend: !1,
        code: "",
        validCode: !1,
        countDown: 0
    },
    onLoad: function(t) {
        var o = this;
        this.syncStore = e.subscribeAndFireOnce(function(e) {
            return o.setData({
                store: e && e.store || null,
                membersLeft: o.membersLeft(e && e.store)
            });
        });
    },
    onReady: function() {
        this.newMemberModal = this.selectComponent("#newMemberModal"), this.alertModal = this.selectComponent("#alertModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncStore.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/settings/my-company/myCompany")
        };
    }
});