var n = require("../../../../dao/enterprise"), t = require("../../../../utils/util"), e = require("../../../../utils/ajax");

Page({
    leave: function() {
        t.confirm("确定离开公司“".concat(this.data.store.name, "”？")).then(function() {
            t.showLoading("提交申请中"), e.moon.del("enterprises/".concat(n.get().id, "/users/current")).finally(t.hideLoading).then(function() {
                return wx.reLaunch({
                    url: "/pages/index/index?tab=settings"
                });
            }).catch(function(n) {
                403 === n.statusCode && "string" == typeof n.data ? t.alert(n.data) : e.showError("离开公司", n);
            });
        });
    },
    data: {},
    onLoad: function(n) {},
    onReady: function() {
        var t = this;
        this.syncStore = n.subscribeAndFireOnce(function(n) {
            return t.setData({
                store: n && n.store || null
            });
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncStore.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.shareToPath("/pages/settings/my-company/myCompany")
        };
    }
});