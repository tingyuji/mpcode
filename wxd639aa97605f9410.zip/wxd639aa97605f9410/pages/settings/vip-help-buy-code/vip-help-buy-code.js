var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/regenerator")), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../../utils/globalMap"), n = require("../../../modules/moment"), a = require("../../../utils/env"), o = require("../../../utils/ajax"), i = require("../../../utils/util");

Page({
    data: {},
    onLoad: function(u) {
        var l = this, c = t.unRegister(u.info) || {}, s = n(c.expire), d = n().isSame(s, "day") ? "今天" : "明天";
        c.expireTime = "".concat(d).concat(s.format("HH时mm分")), c.codeImageUrl = a.mercury("utils/qrImage?code=" + encodeURIComponent(c.codeUrl)), 
        this.setData(c);
        var f = c.orderId, m = setInterval(r(e.default.mark(function r() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    !l.closed && s.isValid() && s.valueOf() > n().valueOf() ? o.mercury.get("vip/helpBuyStatus", {
                        orderId: f
                    }).then(function(e) {
                        "USED" === (e || "").toUpperCase() && (clearInterval(m), i.alert("扫码代付成功！").finally(function() {
                            return wx.navigateBack({
                                delta: 2
                            });
                        }));
                    }) : clearInterval(m);

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, r);
        })), 3e3);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.closed = !0;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});