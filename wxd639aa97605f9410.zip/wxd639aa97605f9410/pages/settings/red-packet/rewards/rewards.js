var e = require("../../../../utils/util"), t = require("../../../../utils/globalMap");

Page({
    data: {
        items: [],
        mode: ""
    },
    onLoad: function(e) {
        this.setData({
            items: t.unRegister(e.items) || [],
            mode: e.mode
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.shareToPath("/pages/settings/red-packet/red-packet")
        };
    }
});