var t = require("../../../@babel/runtime/helpers/toConsumableArray"), r = require("../../../utils/util"), a = require("../../../utils/user"), i = require("../../../utils/ajax"), n = require("../../../utils/globalMap"), o = require("../../../modules/moment"), s = new Set([ "INIT", "REFUND", "FAILED" ]);

function c(e) {
    var t = o(), r = o(e);
    if (r.valueOf() > t.valueOf()) {
        var a = r.diff(t, "day"), i = r.diff(t.add(a, "day"), "hour");
        return a > 0 ? "".concat(a, "天").concat(i, "小时后") : i > 0 ? i + "小时后" : "1小时内";
    }
    return "已";
}

Page({
    tabClick: function(e) {
        var t = e.currentTarget.id;
        i.mercury.post("redPacket/log", {
            action: "red_packet.tab_" + t
        }), this.setData({
            tab: t,
            sliderOffset: e.currentTarget.offsetLeft
        });
    },
    refresh: function() {
        var e = this;
        if (a.id.get()) return r.showLoading("刷新信息中"), i.mercury.get("redPacket/list").finally(r.hideLoading).then(function(r) {
            r.withdraws.forEach(function(e) {
                e.packets = [], e.date = o(e.createTime).format("YYYY-MM-DD"), e.amount = +(e.amount || 0).toFixed(2);
            });
            var a = new Map(r.withdraws.map(function(e) {
                return [ e.id, e ];
            }));
            r.packets.forEach(function(e) {
                var t = a.get(e.withdraw);
                e.isWithdrew = t && !s.has(t.status), t && (t.packets.push(e), t.isReward = "reward" === e.type), 
                e.time = o(e.createTime).format("YYYY-MM-DD HH:mm:ss"), e.expire = c(e.expireTime), 
                e.amount = +(e.amount || 0).toFixed(2);
            });
            var i = r.packets.filter(function(e) {
                return !e.isWithdrew;
            }), n = r.withdraws.filter(function(e) {
                return !s.has(e.status);
            }), d = {
                remainItems: i.filter(function(e) {
                    return "reward" !== e.type;
                }),
                remainRewardItems: i.filter(function(e) {
                    return "reward" === e.type;
                }),
                withdrewItems: n,
                loaded: !0
            };
            d.remainRewardTotal = +d.remainRewardItems.reduce(function(e, t) {
                return e + t.amount;
            }, 0).toFixed(2), d.remainRewardUnseen = !!d.remainRewardItems.find(function(e) {
                return !e.seen;
            }), d.remainRewardExpire = c(Math.min.apply(Math, t(d.remainRewardItems.map(function(e) {
                return new Date(e.expireTime).getTime();
            })))), d.remainCount = d.remainItems.length + (d.remainRewardItems.length > 0 ? 1 : 0), 
            e.setData(d);
        }).catch(function(e) {
            return i.showError("获取奖励信息", e);
        });
    },
    remainRewardsDetail: function() {
        wx.navigateTo({
            url: "rewards/rewards?items=".concat(n.register(this.data.remainRewardItems), "&mode=remain")
        });
    },
    withdrewRewardsDetail: function() {
        var t = e.currentTarget.dataset.item;
        wx.navigateTo({
            url: "rewards/rewards?items=".concat(n.register(t.packets), "&mode=withdrew")
        });
    },
    withdrawRewards: function() {
        this.data.remainRewardTotal < 50 ? (i.mercury.post("redPacket/log", {
            action: "red_packet.withdraw_rewards_block_total",
            target: this.data.remainRewardTotal
        }), r.alert("奖励金满50元才能提现，赶紧多帮助些朋友，多获取些奖励金吧")) : this.doWithdraw(this.data.remainRewardItems);
    },
    withdraw: function(e) {
        var t = this, r = e.currentTarget.dataset.item;
        "activity" === r.type ? this.chooseHelper(r.id).then(function(e) {
            e ? t.doWithdraw([ r ]) : i.mercury.post("redPacket/log", {
                action: "red_packet.withdraw_block_helper"
            });
        }) : this.doWithdraw([ r ]);
    },
    doWithdraw: function(e) {
        var t = this;
        r.showLoading("奖励领取中"), this.doWithdrawHelper(e).finally(r.hideLoading).then(function() {
            return t.refresh();
        });
    },
    doWithdrawHelper: function(e) {
        return i.mercury.get("account/wxUser").then(function(t) {
            return t ? t.subscribe ? i.mercury.post("redPacket/withdraw", {
                ids: e.map(function(e) {
                    return e.id;
                })
            }).then(function(e) {
                r.hideLoading();
                var t = "返现奖励已发放，请在微信的“船货不二”公众号领取";
                return "PROCESSING" === e && (t = "返现奖励发放中，请稍后在微信的“船货不二”公众号领取"), r.alert(t, {
                    confirmText: "知道了"
                });
            }) : (i.mercury.post("redPacket/log", {
                action: "red_packet.withdraw_block_chb2_subscribe"
            }), r.hideLoading(), r.alert("领取奖励需要关注船货不二公众号，请在微信“添加朋友”处搜索“船货不二”关注公众号", {
                confirmText: "知道了"
            })) : Promise.resolve();
        });
    },
    chooseHelper: function(e) {
        var t = this;
        return new Promise(function(r) {
            t.chooseHelperId = e, t.chooseHelperResolve = r, t.chooseHelperModal.show();
        });
    },
    confirmHelper: function() {
        var e = this, t = (this.data.helperMobile || "").trim();
        /^1\d{10}$/.test(t) ? t === a.mobile.get() ? r.alert("您不能填写自己的电话号码", {
            conformText: "重新填写"
        }) : i.mercury.get("redPacket/validHelper", {
            mobile: t
        }).then(function(t) {
            t ? (r.showLoading("数据提交中"), i.mercury.post("redPacket/chooseHelper", {
                id: e.chooseHelperId,
                helper: t
            }).finally(r.hideLoading).then(function() {
                e.chooseHelperModal.hide(), e.chooseHelperResolve(!0);
            }).catch(function(e) {
                return i.showError("提交推荐人", e);
            })) : r.alert("您填写的电话号码不具备推荐人资格，请填写船货不二VIP用户的电话号码", {
                conformText: "重新填写"
            });
        }).catch(function(e) {
            return i.showError("推荐人资格确认", e);
        }) : r.alert("请输入11位手机号码");
    },
    cancelHelper: function() {
        this.chooseHelperResolve(!1);
    },
    helperMobileChange: function(e) {
        this.data.helperMobile = e.detail.value;
    },
    dial400: function() {
        r.dial400();
    },
    data: {
        remainItems: [],
        remainRewardItems: [],
        withdrewItems: [],
        loaded: !1,
        tab: "remain",
        sliderOffset: 0,
        helperMobile: "",
        helpActivity: !1,
        endDate: "2018年08月31日"
    },
    onLoad: function(e) {
        var t = this;
        r.checkUserLogin(this), this.syncUserId = a.id.subscribeAndFireOnce(function(e) {
            return t.setData({
                userId: e
            });
        }), i.mercury.post("redPacket/log", {
            action: "red_packet.page_list",
            target: e.source ? "from_" + e.source : null
        }), this.refresh();
    },
    onReady: function() {
        this.chooseHelperModal = this.selectComponent("#chooseHelperModal");
    },
    onShow: function() {
        r.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh().then(function() {
            return wx.stopPullDownRefresh();
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: r.shareTitle,
            path: r.sharePath()
        };
    }
});