var t = require("../../../dao/location"), e = require("../../../utils/ajax"), s = require("../../../utils/util"), n = require("../../../utils/user");

Page({
    data: {
        enabled: !1,
        status: null,
        location: null,
        busy: !1
    },
    onLoad: function(e) {
        var a = this;
        s.checkUserLogin(this), this.syncUserId = n.id.subscribeAndFireOnce(function(t) {
            a.setData({
                userId: t
            }), a.refresh();
        }), this.syncLocation = t.subscribeAndFireOnce(function(t) {
            a.setData({
                location: t
            }), a.updateEnabled(a.lastEnabled);
        }), this.syncStatus = t.status.subscribeAndFireOnce(function(t) {
            a.setData({
                status: t
            }), a.updateEnabled(a.lastEnabled);
        }), this.syncAuth = t.auth.subscribeAndFireOnce(function(t) {
            a.setData({
                auth: t
            }), a.updateEnabled(a.lastEnabled);
        }), this.refresh();
    },
    onReady: function() {},
    onShow: function() {
        s.checkUserShow(this), t.auth.refresh().then(function(e) {
            e || "deny" === t.status.get() ? e && "deny" === t.status.get() && t.refresh() : t.status.set("deny");
        }).catch(function(t) {
            return console.error(t);
        });
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncLocation.dispose(), this.syncStatus.dispose(), 
        this.syncAuth.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: s.shareTitle,
            path: s.sharePath()
        };
    },
    refresh: function() {
        var t = this;
        if (n.id.get()) return this.startBusy(), e.mercury.get("mapps/VesselLocationSettings").finally(function() {
            return t.endBusy();
        }).then(function(e) {
            return t.updateEnabled(t.lastEnabled = e.enabled);
        }).catch(function(t) {
            return e.showError("获取船位设置数据", t);
        });
    },
    startBusy: function() {
        s.showLoading("获取位置中"), this.setData({
            busy: this.busy = !0
        });
    },
    endBusy: function() {
        this.setData({
            busy: this.busy = !1
        }), s.hideLoading();
    },
    enabledChange: function(e) {
        var s = this;
        this.busy || (e.detail.value ? (this.data.auth || wx.openSetting(), this.startBusy(), 
        this.updateEnabled(!0), t.refresh().finally(function() {
            return s.endBusy();
        })) : this.updateEnabled(!1));
    },
    updateEnabled: function(t) {
        var s = this;
        this.setData({
            enabled: t && !!this.data.location && "deny" !== this.data.status && this.data.auth
        }), !this.lastEnabled != !t && (this.lastEnabled = t, e.mercury.put("mapps/VesselLocationSettings", {
            enabled: t
        }).catch(function() {
            return s.lastEnabled = !t;
        }));
    }
});