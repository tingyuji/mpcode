var e = require("../../../utils/env"), t = require("../../../utils/ajax"), n = require("../../../utils/user"), a = require("../../../utils/util");

Page({
    data: {
        status: "init",
        name: n.companyAuthName.get(),
        showLicenseUploadProgress: !1,
        licenseUploadProgress: 0,
        showLetterUploadProgress: !1,
        letterUploadProgress: 0,
        samplePicSrc: e.resource("mp/certificate-sample.jpg"),
        eula: !0,
        reapply: !1
    },
    onLoad: function(e) {
        var a = this;
        this.syncCompanyAuth = n.companyAuth.subscribeAndFireOnce(function(e) {
            return a.setData({
                status: e
            });
        }), t.mercury.get("files/authCompanyDemoUrl").then(function(e) {
            return a.setData({
                demoUrl: e
            });
        }), this.refresh();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.shareToPath("/pages/settings/my-company/myCompany")
        };
    },
    imageSrc: function(n) {
        var a = encodeURIComponent(t.getToken());
        return n ? e.mercury("files/file?size=200&name=".concat(n, "&authentication=").concat(a)) : e.mercury("certifications/file?size=200&id=0&authentication=".concat(a));
    },
    refresh: function() {
        var e = this;
        a.showLoading("数据加载中"), n.refreshCompanyAuth().finally(a.hideLoading).then(function(n) {
            e.setData({
                name: n.name || null,
                licenseImage: n.license || null,
                licenseImageSrc: e.imageSrc(n.license),
                letterImage: n.letter || null,
                letterImageSrc: e.imageSrc(n.letter)
            }), n.name && n.license || (a.showLoading("数据加载中"), t.mercury.get("certifications/shipper").finally(a.hideLoading).then(function(t) {
                t && e.setData({
                    name: n.name || t.organization || null,
                    licenseImage: n.license || t.licenseFile || null,
                    licenseImageSrc: e.imageSrc(n.license || t.licenseFile)
                });
            }).catch(function(e) {
                return t.showError("获取公司授权信息", e);
            }));
        }).catch(function(e) {
            return t.showError("获取公司授权信息", e);
        });
    },
    nameChange: function(e) {
        this.data.name = e.detail.value;
    },
    eulaChange: function(e) {
        this.setData({
            eula: e.detail.value
        });
    },
    copyDemoUrl: function(e) {
        wx.setClipboardData({
            data: this.data.demoUrl,
            success: function() {
                return a.alert("", {
                    title: "链接复制成功"
                });
            },
            fail: function() {
                return a.alert("链接复制失败，请点击“授权书样例下载”直接下载");
            }
        });
    },
    downloadDemo: function(r) {
        var i = encodeURIComponent(t.getToken());
        wx.downloadFile({
            url: e.mercury("files/authCompanyDemo?uid=".concat(n.id.get(), "&authentication=").concat(i)),
            success: function(e) {
                wx.openDocument({
                    filePath: e.tempFilePath,
                    fail: function(e) {
                        return a.alert("无法打开文档");
                    }
                });
            },
            fail: function(e) {
                return t.showError("下载文档", e);
            }
        });
    },
    doReapply: function(e) {
        this.setData({
            reapply: !0
        });
    },
    openLinkEula: function(t) {
        a.browse(e.resource("app-help/eula.html?ts=".concat(new Date().getTime())), "eula");
    },
    submit: function(e) {
        var n = this;
        /^\s*$/.test(this.data.name) ? a.alert("请输入公司名称") : this.data.licenseImage ? this.data.letterImage ? (a.showLoading("数据提交中"), 
        t.mercury.post("certifications/company-apply", {
            name: this.data.name,
            license: this.data.licenseImage,
            letter: this.data.letterImage,
            description: ""
        }).finally(a.hideLoading).then(function() {
            a.alert("已成功提交, 请等待审核").then(function() {
                n.setData({
                    name: n.data.name,
                    reapply: !1
                }), n.refresh();
            });
        }).catch(function(e) {
            return t.showError("提交材料", e);
        })) : a.alert("请上传公司授权书") : a.alert("请上传营业执照");
    },
    changeImage: function(e, n, r, i, o) {
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(s) {
                var c = s.tempFilePaths[0];
                c && (n(), a.showLoading("图片上传中"), t.mercury.upload("files/upload", c, "image/jpeg", null, null, {
                    onProgress: function(e) {
                        return r(e.progress);
                    }
                }).finally(function() {
                    a.hideLoading(), i();
                }).then(function(e) {
                    return o(e);
                }).catch(function(n) {
                    return t.showError(e, n);
                }));
            }
        });
    },
    changeLicense: function() {
        var e = this;
        this.changeImage("上传公司营业执照", function() {
            return e.setData({
                showLicenseUploadProgress: !0,
                licenseUploadProgress: 0
            });
        }, function(t) {
            return e.setData({
                licenseUploadProgress: t
            });
        }, function() {
            return e.setData({
                showLicenseUploadProgress: !1
            });
        }, function(t) {
            return e.setData({
                licenseImage: t,
                licenseImageSrc: e.imageSrc(t)
            });
        });
    },
    changeLetter: function() {
        var e = this;
        this.changeImage("上传公司授权书", function() {
            return e.setData({
                showLetterUploadProgress: !0,
                letterUploadProgress: 0
            });
        }, function(t) {
            return e.setData({
                letterUploadProgress: t
            });
        }, function() {
            return e.setData({
                showLetterUploadProgress: !1
            });
        }, function(t) {
            return e.setData({
                letterImage: t,
                letterImageSrc: e.imageSrc(t)
            });
        });
    }
});