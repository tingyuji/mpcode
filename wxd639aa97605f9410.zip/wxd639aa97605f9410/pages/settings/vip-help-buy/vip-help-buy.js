var e = require("../../../utils/user"), t = require("../../../utils/ajax"), a = require("../../../utils/util"), r = require("../../../utils/env"), i = require("../../../utils/globalMap");

Page({
    scanCode: function() {
        var e = this;
        t.mercury.post("vip/log", {
            action: "help_buy_code",
            target: this.data.type + "_" + this.data.cardType,
            result: this.data.amount
        }), a.showLoading("生成订单中"), t.mercury.post("vip/buyCard", {
            type: this.data.type,
            cardType: this.data.cardType,
            helpBuy: !0
        }).finally(a.hideLoading).then(function(t) {
            var a = i.register(Object.assign({}, e.data, t.payInfo, {
                orderId: t.orderId
            }));
            wx.navigateTo({
                url: "/pages/settings/vip-help-buy-code/vip-help-buy-code?info=".concat(a)
            });
        }).catch(function(e) {
            return t.showError("生成二维码订单", e);
        });
    },
    initShare: function() {
        var e = this;
        a.showLoading("生成订单中"), t.mercury.post("vip/createShareBuy", {
            type: this.data.type,
            cardType: this.data.cardType,
            preCreate: !0
        }).finally(a.hideLoading).then(function(t) {
            e.shareId = t.id;
        }).catch(function(e) {
            return t.showError("生成分享订单", e);
        });
    },
    data: {},
    onLoad: function(t) {
        var a = this, r = "";
        switch (t.cardType) {
          case "year":
            r = "1年";
            break;

          case "season":
            r = "3个月";
            break;

          case "month":
            r = "1个月";
        }
        var i = "pallet" === t.type ? "货主VIP" : "船主VIP";
        this.setData({
            type: t.type,
            cardType: t.cardType,
            amount: t.amount,
            voucher: t.voucher,
            voucherValue: +t.voucher || 0,
            cardTypeDesc: r,
            typeDesc: i
        }), this.syncMobile = e.mobile.subscribeAndFireOnce(function(e) {
            return a.setData({
                mobile: e || ""
            });
        }), this.initShare();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncMobile.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this;
        return t.mercury.post("vip/shareBuyShare", {
            id: this.shareId
        }), {
            title: "您的好友".concat(this.data.mobile, "请您代付开通船货不二").concat(this.data.typeDesc),
            imageUrl: r.resource("mp/logo-share.png"),
            path: "/pages/index/index?shareBuy=" + this.shareId,
            success: function() {
                return e.shareComplete(!0);
            },
            fail: function() {
                return e.shareComplete(!1);
            }
        };
    },
    shareComplete: function(e) {
        t.mercury.post("vip/shareBuyResult", {
            id: this.shareId,
            result: e
        });
    }
});