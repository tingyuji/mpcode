var e = require("../../../dao/vessel"), s = require("../../../utils/user"), t = require("../../../utils/util");

Page({
    data: {
        vesselBadge: !1
    },
    onLoad: function(n) {
        var i = this;
        t.checkUserLogin(this), this.syncUserId = s.id.subscribeAndFireOnce(function(e) {
            return i.setData({
                userId: e
            });
        }), this.syncVessel = e.subscribeAndFireOnce(function(e) {
            var s = "";
            e && e.state && (s = "pending" === e.candidateState ? "pending" : e.certificationExpired ? "expired" : e.state);
            var t = "expired" === s || "rejected" === s;
            i.setData({
                vessel: e,
                vesselState: s,
                vesselBadge: t
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        t.checkUserShow(this), s.id.get() && e.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncVessel.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});