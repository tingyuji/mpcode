var e = require("../../utils/ajax.js"), s = require("../../utils/env"), t = require("../../utils/user"), i = require("../../utils/util"), n = require("../../dao/enterprise"), r = require("../../dao/vessel"), a = require("../../dao/vipStatus"), c = require("../../dao/redPacket"), o = require("../../dao/unseenServices"), u = require("../../dao/cash");

Page({
    data: {
        userId: 0,
        avatar: "",
        companyText: "",
        shipVip: !1,
        palletVip: !1,
        leftMobiles: 0,
        alreadyMobiles: 0,
        vipBadge: !1,
        vesselBadge: !1,
        redPacket: 0,
        helpActivity: !1,
        wxUserIconUrl: "",
        wxServiceIconUrl: "",
        vipActivity: {}
    },
    onLoad: function(e) {
        var i = this;
        this.syncVipBadge = t.vipBadge.subscribeAndFireOnce(function(e) {
            return i.setData({
                vipBadge: e
            });
        }), this.syncUserId = t.id.subscribeAndFireOnce(function(e) {
            return i.setData({
                userId: e
            });
        }), this.syncAvatar = t.avatar.subscribeAndFireOnce(function(e) {
            return i.setData({
                avatar: e ? s.mercury("files/avatar/" + e) : "/images/avatar-none.png"
            });
        }), this.syncName = t.name.subscribeAndFireOnce(function(e) {
            return i.setData({
                name: e || ""
            });
        }), this.syncMobile = t.mobile.subscribeAndFireOnce(function(e) {
            return i.setData({
                mobile: e || ""
            });
        }), this.syncIdCardCertified = t.idCardCertified.subscribeAndFireOnce(function(e) {
            return i.setData({
                idCardCertified: e
            });
        }), this.syncWxUser = t.wxUser.subscribeAndFireOnce(function(e) {
            return i.setData({
                wxUser: e || null,
                wxUserIconUrl: "/images/wechat".concat(e ? "" : "-disable", ".png"),
                wxServiceIconUrl: "/images/wx-service".concat(e && e.subscribe ? "-normal" : "-disable", ".png")
            });
        }), this.syncRedPacket = c.subscribeAndFireOnce(function(e) {
            return i.setData({
                redPacket: +(e && e.remain || 0).toFixed(2),
                redPacketUnseen: e && e.unseen || 0
            });
        }), this.syncReputation = t.reputation.subscribeAndFireOnce(function(e) {
            return i.setData({
                reputationLevel: e.level || 0,
                reputationPercent: e.levelReputation ? e.reputation / e.levelReputation * 100 : 0
            });
        });
        var d = function() {
            var e = n.get();
            i.setData({
                companyText: (e ? e.store && e.store.name || e.name : "approved" === t.companyAuth.get() ? t.companyAuthName.get() : "未开通") || ""
            });
        };
        this.syncEnterprise = n.subscribeAndFireOnce(d), this.syncCompanyAuth = t.companyAuth.subscribeAndFireOnce(d), 
        this.syncVessel = r.subscribeAndFireOnce(function(e) {
            var s = e && "pending" !== e.candidateState && ("rejected" === e.state || e.certificationExpired);
            i.setData({
                vessel: e,
                vesselBadge: s
            });
        }), this.syncVipStatus = a.subscribeAndFireOnce(function(e) {
            e ? this.setData({
                palletVip: e.palletLeftDays,
                shipVip: e.shipLeftDays,
                leftMobiles: e.leftMobiles,
                alreadyMobiles: e.alreadyMobiles,
                isStarUser: e.isStarUser,
                vipActivity: e.activity || {}
            }) : this.setData({
                palletVip: 0,
                shipVip: 0,
                leftMobiles: 0,
                alreadyMobiles: 0,
                isStarUser: !1,
                vipActivity: {}
            });
        }.bind(this)), this.syncUnseen = o.subscribeAndFireOnce(function(e) {
            var s = {};
            Object.getOwnPropertyNames(i.data).filter(function(e) {
                return e.startsWith("unseen_");
            }).forEach(function(e) {
                return s[e] = !1;
            }), e.forEach(function(e) {
                return s["unseen_".concat(e)] = !0;
            }), i.setData(s);
        }), this.syncCash = u.subscribeAndFireOnce(function(e) {
            return i.setData({
                cashBalance: e
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        t.id.get() ? this.refresh() : this.isBack ? wx.redirectTo({
            url: "/pages/home/home"
        }) : this.bindMobile();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncVipBadge.dispose(), this.syncUserId.dispose(), this.syncAvatar.dispose(), 
        this.syncName.dispose(), this.syncMobile.dispose(), this.syncIdCardCertified.dispose(), 
        this.syncWxUser.dispose(), this.syncRedPacket.dispose(), this.syncReputation.dispose(), 
        this.syncEnterprise.dispose(), this.syncCompanyAuth.dispose(), this.syncVessel.dispose(), 
        this.syncVipStatus.dispose(), this.syncUnseen.dispose(), this.syncCash.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: i.shareTitle,
            path: i.shareTabPath("settings")
        };
    },
    refresh: function() {
        t.refresh().then(function() {
            Promise.all([ n.refresh(), r.refresh(), a.refresh() ]).finally(function() {
                return wx.stopPullDownRefresh();
            });
        }).catch(function(e) {
            return wx.stopPullDownRefresh();
        });
    },
    bindMobile: function() {
        this.isBack = !0, wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    toVipShip: function() {
        e.mercury.post("vip/log", {
            action: "vip_user_click",
            target: "settings_to_vip_ship"
        });
    },
    toVipPallet: function() {
        e.mercury.post("vip/log", {
            action: "vip_user_click",
            target: "settings_to_vip_pallet"
        });
    },
    toMyCompany: function() {
        o.see("myCompany");
    }
});