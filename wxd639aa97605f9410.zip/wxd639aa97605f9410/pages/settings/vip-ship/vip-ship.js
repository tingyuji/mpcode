var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../utils/ajax.js"), i = require("../../../utils/env.js"), a = require("../../../dao/vipStatus"), r = require("../../../utils/util.js"), s = require("../../../utils/user"), n = require("../../../dao/vessel");

Page({
    data: {
        type: "",
        vipAgreement: "/pages/web-view/webView?url=".concat(encodeURIComponent(i.resource("app-help/vip-agreement.html?ts=".concat(new Date().getTime())))),
        shipVip: !1,
        initVip: !1,
        shipLeftDays: 0,
        shipMonthUsed: !1,
        shipSeasonUsed: !1,
        realPrice: "",
        voucher: "",
        beginDate: "2018年3月14日",
        isIOS: r.isIOS(),
        cards: [],
        vipBought: !1,
        paying: !1
    },
    toVipAgreement: function() {
        t.mercury.post("mapps/log", {
            action: "vip-agreement",
            target: "vip-ship"
        });
    },
    getDistance: function(e) {
        var t = new Date(e).getTime() - new Date().getTime(), i = Math.floor(t / 6e4), a = Math.floor(i / 60), r = Math.floor(a / 24);
        return a > 0 ? r > 0 ? "".concat(r, "天").concat(a % 24, "小时") : "".concat(a % 24, "小时") : "".concat(i + 1, "分钟");
    },
    refreshActivity: function() {
        var e = this;
        return t.mercury.get("vip/activity").then(function(t) {
            e.setData({
                activity: t
            });
        });
    },
    _refreshCards: function() {
        var i = this;
        return this.data.userId > 0 ? (r.showLoading("获取数据中"), t.mercury.get("vip/availableCards", {
            type: "ship"
        }).finally(r.hideLoading).then(function(t) {
            var a, r = e(t);
            try {
                for (r.s(); !(a = r.n()).done; ) {
                    var s = a.value;
                    s.daysString = s.days + "天", 730 === s.days && (s.daysString += "(2年)"), s.first = s.cardType.indexOf("_first") >= 0, 
                    s.experience = s.cardType.indexOf("_experience") >= 0, s.recommend = !1, s.originalPrice = s.originalPrice || 0, 
                    s.cheapDesc = s.cheapDesc || "";
                }
            } catch (e) {
                r.e(e);
            } finally {
                r.f();
            }
            return t.length > 1 && (t[0].recommend = !0), i.setData({
                cards: t
            }), t[0] && i.setData({
                type: t[0].cardType
            }), i._refreshCardInfo();
        }).catch(function(e) {
            return t.showError("获取价格信息", e);
        })) : (this.setData({
            cards: []
        }), Promise.resolve());
    },
    _refreshCardInfo: function() {
        var e = this;
        if (this.data.type && this.data.userId > 0) {
            r.showLoading("获取数据中");
            var i = this.data.type;
            t.mercury.get("vip/cardInfo", {
                type: "ship",
                cardType: this.data.type
            }).finally(r.hideLoading).then(function(t) {
                i === e.data.type && e.setData({
                    realPrice: (t.price - t.voucher).toFixed(2),
                    voucher: t.voucher.toFixed(2)
                });
            }).catch(function(e) {
                return t.showError("获取折扣信息", e);
            });
        }
    },
    switchType: function(e) {
        this._switchType(e.currentTarget.dataset.type);
    },
    _switchType: function(e) {
        e !== this.data.type && (this.setData({
            type: e
        }), this._refreshCardInfo());
    },
    charge: function() {
        this.setData({
            shipVip: !1
        });
    },
    checkVesselCertified: function() {
        return !(!this.data.vessel || !this.data.vessel.certified) || (r.alert("只有认证船主才能开通船主VIP", {
            confirmText: "去认证"
        }).then(function() {
            t.mercury.post("vip/log", {
                action: "vip_user_click",
                target: "vip_to_certify_vessel"
            }), wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel"
            });
        }), !1);
    },
    setPaying: function() {
        var e = this;
        this.clearPaying(), this.setData({
            paying: !0
        }), this.payTimer = setTimeout(function() {
            return e.clearPaying();
        }, 3e3);
    },
    clearPaying: function() {
        this.payTimer && (clearTimeout(this.payTimer), this.payTimer = null, this.setData({
            paying: !1
        }));
    },
    pay: function() {
        var e = this;
        if (this.data.realPrice && !this.data.paying) {
            this.setPaying();
            var i = this.data.realPrice;
            t.mercury.post("vip/log", {
                action: "vip_user_click",
                target: "pay_ship_".concat(this.data.type),
                result: i
            }), this.deadbeatBlockModal.check("vip_ship").then(function(a) {
                a && e.checkVesselCertified() ? t.mercury.post("vip/buyCard", {
                    type: "ship",
                    cardType: e.data.type
                }).then(function(t) {
                    var a = t && t.payInfo;
                    a ? wx.requestPayment({
                        timeStamp: a.timeStamp.toString(),
                        nonceStr: a.nonceStr,
                        package: a.package,
                        signType: a.signType,
                        paySign: a.paySign,
                        success: function(a) {
                            return e.onPayDone(t.orderId, i);
                        },
                        fail: function(t) {
                            e.clearPaying();
                            var i = t.errMsg.indexOf("fail"), a = t.errMsg.slice(i + 4).trim();
                            "cancel" !== a && r.alert("付款失败，" + a);
                        }
                    }) : e.clearPaying();
                }).catch(function(i) {
                    e.clearPaying(), t.showError("开通船主VIP", i);
                }) : e.clearPaying();
            }).catch(function() {
                return e.clearPaying();
            });
        }
    },
    onPayDone: function(e, i) {
        var s = this;
        r.showLoading("获取结果中"), t.mercury.get("vip/payStatus", {
            orderId: e
        }).finally(function() {
            s.setData({
                paying: !1
            }), r.hideLoading();
        }).then(function(r) {
            "USED" !== r && "BOUGHT" !== r || (t.mercury.post("vip/log", {
                action: "vip_pay_done_ship",
                target: e,
                result: i
            }), a.refresh());
        }).catch(function(e) {
            return t.showError("获取支付结果", e);
        });
    },
    dial400: function() {
        r.dial400();
    },
    helpBuy: function() {
        var e = this;
        this.data.realPrice && (t.mercury.post("vip/log", {
            action: "help_buy_page",
            target: "ship_".concat(this.data.type),
            result: this.data.realPrice
        }), this.deadbeatBlockModal.check("vip_ship").then(function(t) {
            t && e.checkVesselCertified() && wx.navigateTo({
                url: "/pages/settings/vip-help-buy/vip-help-buy?type=ship&cardType=".concat(e.data.type, "&amount=").concat(e.data.realPrice, "&voucher=").concat(e.data.voucher)
            });
        }));
    },
    refresh: function() {
        this._refreshCards(), a.refresh();
    },
    onLoad: function(e) {
        var t = this;
        r.checkUserLogin(this), this.syncUserId = s.id.subscribeAndFireOnce(function(e) {
            t.setData({
                userId: e
            }), t.refresh();
        }), this.syncUserMobile = s.mobile.subscribeAndFireOnce(function(e) {
            return t.setData({
                userMobile: e || ""
            });
        }), this.syncVessel = n.subscribeAndFireOnce(function(e) {
            return t.setData({
                vessel: e
            });
        }), this.syncVipStatus = a.subscribeAndFireOnce(function(i) {
            i ? t.setData({
                shipVip: !e.recharge && i.vips.indexOf("ship") >= 0,
                initVip: i.vips.indexOf("ship") >= 0,
                shipLeftDays: i.shipLeftDays,
                vipBought: i.palletVipBought
            }) : t.setData({
                shipVip: !1,
                initVip: !1,
                shipLeftDays: 0,
                vipBought: !1
            });
        }), this.refresh();
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        var e = this.notFirstShow;
        r.checkUserShow(this), e && this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncUserMobile.dispose(), this.syncVipStatus.dispose(), 
        this.syncVessel.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: r.shareTitle,
            path: r.sharePath()
        };
    }
});