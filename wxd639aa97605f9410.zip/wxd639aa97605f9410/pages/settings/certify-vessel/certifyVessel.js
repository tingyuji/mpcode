var e = require("../../../dao/vessel"), t = require("../../../utils/env"), s = require("../../../utils/ajax"), i = require("../../../utils/util");

Page({
    data: {
        samplePicBigSrc: t.resource("mp/vessel-certificate-sample-big.jpg"),
        samplePicBigSrc2021: t.resource("mp/vessel-certificate-sample-big-2021.jpg"),
        samplePicBigSizeSrc: t.resource("mp/vessel-certificate-big-size.jpg"),
        vessel: null,
        candidate: {},
        state: "",
        eula: !0,
        showLicenseUploadProgress: !1,
        licenseUploadProgress: 0,
        showSizeUploadProgress: !1,
        sizeUploadProgress: 0,
        licenseImage: null,
        licenseImageSrc: null,
        sizeImage: null,
        sizeImageSrc: null
    },
    onLoad: function(t) {
        var i = this;
        this.syncVessel = e.subscribeAndFireOnce(function(e) {
            return i.setData({
                vessel: e,
                state: i.getState(e, i.data.candidate)
            });
        }), s.mercury.post("certifications/log", {
            action: "page_certify",
            result: t.source
        });
    },
    onReady: function() {
        this.conflictModal = this.selectComponent("#conflictModal");
    },
    onShow: function() {
        var t = this, i = !this.notFirst;
        this.notFirst = !0, e.refresh().then(function() {
            e.get() ? t.refreshVessel() : i ? wx.navigateTo({
                url: "../edit-vessel/editVessel"
            }) : wx.navigateBack();
        }).catch(function(e) {
            return s.showError("获取船舶信息", e);
        });
    },
    onHide: function() {},
    onUnload: function() {
        this.syncVessel.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: i.shareTitle,
            path: i.shareToPath("/pages/settings/my-vessel/myVessel")
        };
    },
    getState: function(e, t) {
        return e ? e.certificationExpired && "pending" !== t.state && "rejected" !== t.state ? "expired" : e.state ? e.state : "none" : null;
    },
    imageId: function(e) {
        return e && (e.certifying || e.certified) || 0;
    },
    imageSrc: function(e, i) {
        var a = encodeURIComponent(s.getToken()), n = "";
        return "size" === i && (n = "type=size&"), t.mercury("certifications/file?".concat(n, "size=60&id=").concat(e || 0, "&authentication=").concat(a));
    },
    eulaChange: function(e) {
        this.setData({
            eula: e.detail.value
        });
    },
    openLinkEula: function(e) {
        i.browse(t.resource("app-help/eula.html?ts=".concat(new Date().getTime())), "eula");
    },
    changeLicense: function() {
        var e = this;
        this.changeImage("certification", "上传船舶适航证书", function() {
            return e.setData({
                showLicenseUploadProgress: !0,
                licenseUploadProgress: 0
            });
        }, function(t) {
            return e.setData({
                licenseUploadProgress: t
            });
        }, function() {
            return e.setData({
                showLicenseUploadProgress: !1
            });
        }, function(t) {
            return e.setData({
                licenseImage: t,
                licenseImageSrc: e.imageSrc(t)
            });
        });
    },
    changeSize: function() {
        var e = this;
        this.changeImage("size", "上传船舶尺寸页", function() {
            return e.setData({
                showSizeUploadProgress: !0,
                licenseUploadProgress: 0
            });
        }, function(t) {
            return e.setData({
                sizeUploadProgress: t
            });
        }, function() {
            return e.setData({
                showSizeUploadProgress: !1
            });
        }, function(t) {
            return e.setData({
                sizeImage: t,
                sizeImageSrc: e.imageSrc(t, "size")
            });
        });
    },
    changeImage: function(e, t, a, n, r, c) {
        var o = this.data.vessel.id;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(l) {
                var u = l.tempFilePaths[0];
                u && (a(), i.showLoading("图片上传中"), s.mercury.upload("certifications/upload", u, "image/jpeg", {
                    vessel: o,
                    type: e
                }, null, {
                    onProgress: function(e) {
                        return n(e.progress);
                    }
                }).finally(function() {
                    i.hideLoading(), r();
                }).then(function(e) {
                    return c(e);
                }).catch(function(e) {
                    return s.showError(t, e);
                }));
            }
        });
    },
    confirmConflict: function() {
        this.conflictModal.hide();
    },
    complain: function() {
        i.dial400();
    },
    submit: function() {
        var e = this;
        this.data.eula ? this.data.licenseImage ? this.data.sizeImage ? (i.showLoading("数据提交中"), 
        s.mercury.post("certifications/apply", {
            vessel: this.data.vessel.id,
            file: this.data.licenseImage,
            sizeFile: this.data.sizeImage
        }).finally(i.hideLoading).then(function() {
            i.alert("已成功提交, 请等待审核").then(function() {
                e.setData({
                    reapply: !1
                }), e.refreshVessel();
            });
        }).catch(function(t) {
            403 === t.statusCode && "VESSEL_EXIST" === t.data.code ? e.conflictModal.show() : 400 === t.statusCode && "CERT_FRONT_1" === t.data.code ? i.alert("认证请上传《内河船舶适航证书》，不是大簿子首页", {
                title: "提交失败"
            }) : 400 === t.statusCode && "CERT_FRONT_2" === t.data.code ? i.alert("认证请上传《安全与环保证书》第二页，不是首页", {
                title: "提交失败"
            }) : s.showError("提交认证材料", t);
        })) : i.alert("请上传船舶尺寸页") : i.alert("请上传《内河船舶安全与环保证书》第二页或《内河船舶适航证书》") : i.alert("你需要同意船货不二用户协议");
    },
    revokeCandidate: function() {
        var e = this;
        i.confirm("确定要撤销认证吗？").then(function() {
            e.cancelCandidate(!0);
        });
    },
    cancelCandidate: function(e) {
        var t = this;
        i.showLoading("数据提交中"), s.mercury.post("certifications/revokeCandidate", {
            vessel: this.data.vessel.id,
            reset: !!e
        }).finally(i.hideLoading).then(function() {
            return t.refreshVessel();
        }).catch(function(e) {
            return s.showError("撤销再认证", e);
        });
    },
    withdraw: function() {
        var e = this;
        i.confirm("确定要撤销认证吗？").then(function() {
            i.showLoading("数据提交中"), s.mercury.put("vessels/undo", {
                id: e.data.vessel.id
            }).finally(i.hideLoading).then(function() {
                return e.refreshVessel();
            }).catch(function(e) {
                return s.showError("撤销认证", e);
            });
        });
    },
    reapply: function() {
        var e = this;
        i.showLoading("数据提交中"), s.mercury.put("vessels/confirm", {
            id: this.data.vessel.id
        }).finally(i.hideLoading).then(function() {
            return e.refreshVessel();
        }).catch(function(e) {
            return s.showError("提交重新认证", e);
        });
    },
    refreshVessel: function() {
        var t = this;
        e.refresh().then(function() {
            t.data.vessel ? s.mercury.get("certifications/loadCandidate", {
                vessel: t.data.vessel.id
            }).then(function(e) {
                e = e || {}, t.setData({
                    candidate: e,
                    state: t.getState(t.data.vessel, e)
                });
            }).catch(function(e) {
                return s.showError("获取船舶再认证信息", e);
            }) : t.setData({
                candidate: {}
            });
        }).catch(function(e) {
            return s.showError("获取船舶信息", e);
        });
    },
    enlargeSamplePics: function() {
        wx.previewImage({
            urls: [ this.data.samplePicBigSrc2021, this.data.samplePicBigSrc ]
        });
    },
    enlargeSamplePicSize: function() {
        wx.previewImage({
            urls: [ this.data.samplePicBigSizeSrc ]
        });
    },
    changeVesselName: function() {
        wx.navigateTo({
            url: "../re-certify-vessel/re-certify-vessel?source=certifyVessel"
        });
    },
    sameVesselName: function() {
        wx.navigateTo({
            url: "../re-certify-vessel/re-certify-vessel?source=certifyVessel&sameName=1"
        });
    }
});