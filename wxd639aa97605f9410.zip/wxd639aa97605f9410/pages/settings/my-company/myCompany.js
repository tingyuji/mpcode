var e = require("../../../dao/enterprise"), n = require("../../../utils/user"), t = require("../../../utils/util"), r = require("../../../utils/ajax"), s = require("../../../dao/unseenServices");

Page({
    data: {},
    onLoad: function(i) {
        var o = this;
        t.checkUserLogin(this), e.get() && e.get().store ? wx.redirectTo({
            url: "../flag-ship-store/flagShipStore?source=".concat(i.source || "share")
        }) : r.mercury.post("store/viewPage", {
            page: "myCompany",
            source: i.source || "share"
        }), this.syncUserId = n.id.subscribeAndFireOnce(function(e) {
            return o.setData({
                userId: e
            });
        }), this.syncEnterprise = e.subscribeAndFireOnce(function(e) {
            return o.setData({
                store: e && e.store
            });
        }), this.syncCompanyAuth = n.companyAuth.subscribeAndFireOnce(function(e) {
            return o.setData({
                companyAuth: e
            });
        }), this.syncUnseen = s.subscribeAndFireOnce(function(e) {
            var n = {};
            Object.getOwnPropertyNames(o.data).filter(function(e) {
                return e.startsWith("unseen_");
            }).forEach(function(e) {
                return n[e] = !1;
            }), e.forEach(function(e) {
                return n["unseen_".concat(e)] = !0;
            }), o.setData(n);
        });
    },
    onReady: function() {},
    onShow: function() {
        t.checkUserShow(this), this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncEnterprise.dispose(), this.syncCompanyAuth.dispose(), 
        this.syncUnseen.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    },
    refresh: function() {
        n.id.get() && (t.showLoading("获取数据中"), Promise.all([ n.refreshCompanyAuth(), e.refresh() ]).finally(t.hideLoading).catch(function(e) {
            return r.showError("获取公司信息", e);
        }));
    },
    toCompanyAuth: function() {
        s.see("companyAuth");
    }
});