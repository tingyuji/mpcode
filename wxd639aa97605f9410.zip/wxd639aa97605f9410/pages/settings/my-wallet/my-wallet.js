var e = require("../../../utils/util"), n = require("../../../utils/user"), s = require("../../../dao/redPacket"), t = require("../../../dao/voucher"), r = require("../../../dao/unseenServices"), c = require("../../../dao/cash");

Page({
    toRedPacket: function() {
        r.see("redPacket");
    },
    toCash: function() {
        r.see("cash");
    },
    data: {
        redPacket: 0,
        cashBalance: 0
    },
    onLoad: function(i) {
        var a = this;
        e.checkUserLogin(this), this.syncUserId = n.id.subscribeAndFireOnce(function(e) {
            return a.setData({
                userId: e
            });
        }), this.syncVoucher = t.subscribeAndFireOnce(function(e) {
            return a.setData({
                voucher: +(e && e.available || 0).toFixed(2)
            });
        }), this.syncRedPacket = s.subscribeAndFireOnce(function(e) {
            return a.setData({
                redPacket: +(e && e.remain || 0).toFixed(2),
                redPacketUnseen: e && e.unseen || 0
            });
        }), this.syncUnseen = r.subscribeAndFireOnce(function(e) {
            var n = {};
            Object.getOwnPropertyNames(a.data).filter(function(e) {
                return e.startsWith("unseen_");
            }).forEach(function(e) {
                return n[e] = !1;
            }), e.forEach(function(e) {
                return n["unseen_".concat(e)] = !0;
            }), a.setData(n);
        }), this.syncCash = c.subscribeAndFireOnce(function(e) {
            return a.setData({
                cashBalance: e
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        e.checkUserShow(this), t.refresh(), s.refresh(), c.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncVoucher.dispose(), this.syncRedPacket.dispose(), 
        this.syncUnseen.dispose(), this.syncCash.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    }
});