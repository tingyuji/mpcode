var t = require("../../../utils/user"), e = require("../../../utils/ajax"), a = require("../../../utils/env"), i = require("../../../utils/util");

Page({
    data: {
        mobile: "",
        status: "loading",
        chances: 3,
        name: t.name.get(),
        idCardNumber: t.idCard.get(),
        busy: !1
    },
    onLoad: function(e) {
        var a = this;
        i.checkUserLogin(this), this.syncUserId = t.id.subscribeAndFireOnce(function(t) {
            a.setData({
                userId: t
            }), a.refresh();
        }), this.syncMobile = t.mobile.subscribeAndFireOnce(function(t) {
            return a.setData({
                mobile: t || ""
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        i.checkUserShow(this), this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncMobile.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: i.shareTitle,
            path: i.sharePath()
        };
    },
    refresh: function() {
        var a = this;
        t.id.get() && (this.setData({
            status: "loading"
        }), t.refresh().then(function() {
            a.loadChances().then(function(e) {
                var i = {
                    name: t.name.get(),
                    idCardNumber: t.idCard.get()
                };
                t.idCardCertified.get() ? i.status = "success" : e ? (i.name = "", i.status = "input") : i.status = "no-more-chance", 
                a.setData(i);
            }).catch(function(t) {
                return e.showError("获取认证信息", t);
            });
        }).catch(function(t) {
            return e.showError("刷新用户信息", t);
        }));
    },
    loadChances: function() {
        var t = this;
        return e.mercury.get("account/count-certify-left").then(function(e) {
            return t.setData({
                chances: e
            }), e;
        });
    },
    submit: function() {
        var t = this;
        this.validateMobile(this.data.mobile) ? this.validateRealName(this.data.name) ? this.validateIdCardNumber(this.data.idCardNumber) ? (i.showLoading("提交认证中"), 
        e.mercury.post("account/certify", {
            mobile: this.data.mobile,
            realname: this.data.name,
            idcard: this.data.idCardNumber
        }).then(function() {
            t.setData({
                status: "success"
            }), i.hideLoading(), t.refresh();
        }).catch(function(a) {
            t.loadChances(), i.hideLoading(), 404 === a.statusCode || 403 === a.statusCode ? t.setData({
                status: "failed"
            }) : e.showError("提交认证", a);
        })) : i.alert("无效的身份证号码", {
            title: "身份证错误"
        }) : i.alert("输入您的真实姓名才能通过认证", {
            title: "姓名错误"
        }) : i.alert("无效的手机号码", {
            title: "手机号错误"
        });
    },
    validateIdCardNumber: function(t) {
        return /^\d{17}[\dXx]$/.test(t);
    },
    validateRealName: function(t) {
        return (t = t || "").length >= 2 && t.length <= 5 && !/\w+/.test(t);
    },
    validateMobile: function(t) {
        return /^\d{11}$/.test(t);
    },
    goToHelp: function() {
        i.browse(a.resource("app-help/what-is-mobile-certification.html?ts=".concat(new Date().getTime())), "mobile-certification-help");
    },
    nameChange: function(t) {
        this.data.name = (t.detail.value || "").replace(/\s/g, "");
    },
    idCardChange: function(t) {
        this.data.idCardNumber = (t.detail.value || "").replace(/\s/g, "");
    },
    redo: function() {
        var t = this;
        this.loadChances().then(function(e) {
            t.setData({
                status: e ? "input" : "no-more-chance"
            });
        }).catch(function(t) {
            return e.showError("获取认证信息", t);
        });
    }
});