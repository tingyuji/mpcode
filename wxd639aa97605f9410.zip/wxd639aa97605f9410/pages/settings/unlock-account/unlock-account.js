var n = require("../../../utils/util"), t = require("../../../utils/ajax"), e = require("../../../utils/user");

Page({
    codeChange: function(n) {
        this.data.code = n.detail.value;
    },
    unlock: function() {
        var o = this, i = (this.data.code || "").trim();
        /^[0-9]{6}$/.test(i) ? this.data.unlocking || (this.setData({
            unlocking: !0
        }), t.mercury.post("account/unlock", {
            mobile: this.data.mobile,
            code: i
        }).then(function(o) {
            t.setToken(o), n.alert("账号解锁成功！").then(function() {
                e.refresh().then(function() {
                    return wx.navigateBack();
                });
            });
        }).catch(function(n) {
            return t.showError("解锁账号", n).then(function() {
                return o.setData({
                    unlocking: !1
                });
            });
        })) : n.alert("请输入6位数字的短信验证码");
    },
    login: function() {
        wx.redirectTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    data: {
        mobile: "",
        code: "",
        unlocking: !1
    },
    onLoad: function(n) {
        this.setData({
            mobile: n.mobile || this.data.mobile
        }), e.unlockingAccount = !0;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.setData({
            unlocking: !1
        }), e.unlockingAccount = !1;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.sharePath()
        };
    }
});