var n = require("../../../utils/env"), t = require("../../../utils/util");

Page({
    data: {
        title: n.title(),
        version: n.version()
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});