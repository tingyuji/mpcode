var e = require("../../../../utils/ajax"), t = require("../../../../utils/user"), a = require("../../../../utils/util"), n = require("../../../../modules/moment");

Page({
    refresh: function() {
        this.maxId = null;
        return this.load({
            items: [],
            loaded: !1,
            searchEnd: !1
        });
    },
    load: function(n) {
        var i = this;
        return this.data.loading ? Promise.resolve() : (n || (n = this.data), t.id.get() > 0 ? (a.showLoading("获取数据中"), 
        this.setData({
            loading: !0
        }), e.mercury.get("cash/details", {
            maxId: this.maxId
        }).finally(function() {
            i.setData({
                loading: !1
            }), a.hideLoading();
        }).then(function(e) {
            var t = null;
            e.items.forEach(function(e) {
                i.maxId = e.id, e.date = i.formatDate(e.createTime), e.amountText = e.amount.toFixed(2), 
                e.amount = +e.amountText, e.balanceText = e.balance.toFixed(2), e.balance = +e.balanceText, 
                e.createTime === e.updateTime ? e.time = i.formatTime(e.createTime) : e.time = "".concat(i.formatTime(e.createTime), "~").concat(i.formatTime(e.updateTime)), 
                t !== e.date && (t = e.date, n.items.push({
                    date: t,
                    subItems: []
                })), n.items[n.items.length - 1].subItems.push(e);
            }), n.searchEnd = e.end, n.loaded = !0, i.setData(n);
        }).catch(function(t) {
            return e.showError("获取余额详情", t);
        })) : (n.searchEnd = !0, n.loaded = !0, this.setData(n), Promise.resolve()));
    },
    formatDate: function(e) {
        var t = n(e).startOf("day"), a = n().startOf("day").valueOf();
        return t.valueOf() === a ? "今天" : n(t).add(1, "day").valueOf() === a ? "昨天" : n(t).add(2, "day").valueOf() === a ? "前天" : t.format("YYYY年M月D日");
    },
    formatTime: function(e) {
        return n(e).format("HH:mm:ss");
    },
    data: {
        items: [],
        loading: !1,
        loaded: !1,
        searchEnd: !1
    },
    onLoad: function(t) {
        e.mercury.post("cash/log", {
            action: "page.cash-details",
            result: t.source
        }), this.refresh();
    },
    onReady: function() {},
    onShow: function() {
        var e = this.notFirstShow;
        this.notFirstShow = !0, e && this.refresh();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.refresh().finally(wx.stopPullDownRefresh);
    },
    onReachBottom: function() {
        this.data.searchEnd || this.load();
    },
    onShareAppMessage: function() {}
});