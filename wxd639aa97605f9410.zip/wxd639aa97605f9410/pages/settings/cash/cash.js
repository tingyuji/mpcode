var t = require("../../../utils/util"), e = require("../../../utils/user"), n = require("../../../dao/cash"), r = require("../../../utils/ajax"), s = require("../../../utils/greatPallet"), i = "\n请联系客服4008030092咨询详情";

Page({
    refresh: function() {
        var s = this, i = null;
        return e.id.get() ? (this.setData({
            busy: !0
        }), t.showLoading("获取信息中"), n.refresh().finally(function() {
            t.hideLoading(), s.setData({
                busy: !1
            });
        }).catch(function(t) {
            i = t, r.showError("获取余额信息", t);
        }).then(function() {
            return i;
        })) : Promise.resolve(!1);
    },
    withdraw: function() {
        var e = this;
        if (this.data.busy) return !1;
        this.refresh().then(function(r) {
            if (null === r) {
                var s = n.get() || 0;
                if (s < .3) return t.alert("您的余额不足0.3元，无法提现。");
                if (s > 200) return t.alert("您的余额大于200元，无法自助提现。" + i);
                var a = "您确定要将￥".concat(+s.toFixed(2), "元余额转入您的微信零钱中吗？");
                return t.confirm(a).then(function() {
                    return e.doWithdraw();
                });
            }
        });
    },
    doWithdraw: function() {
        var e = this;
        return this.setData({
            busy: !0
        }), t.showLoading("提现中"), r.mercury.post("cash/withdrawAll").finally(function() {
            t.hideLoading(), e.setData({
                busy: !1
            });
        }).then(function(n) {
            return e.refresh(), "SUCCESS" === n.status ? t.alert("提现成功。￥".concat(+n.amount.toFixed(2), "元将转入您绑定微信号的零钱中，请过几分钟后到微信查收。")) : t.alert("提现失败。" + i);
        }).catch(function(e) {
            return t.alert(r.getAjaxErrorMessage("余额提现", e) + i);
        });
    },
    charge: function() {
        s.upgrade(null, "cash", null, null);
    },
    data: {
        cash: 0,
        busy: !1
    },
    onLoad: function(s) {
        var i = this;
        t.checkUserLogin(this), this.syncUserId = e.id.subscribeAndFireOnce(function(t) {
            return i.setData({
                userId: t
            });
        }), this.syncCash = n.subscribeAndFireOnce(function(t) {
            return i.setData({
                cash: (t || 0).toFixed(2)
            });
        }), r.mercury.post("cash/log", {
            action: "page.cash",
            result: s.source
        });
    },
    onReady: function() {},
    onShow: function() {
        t.checkUserShow(this), this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncCash.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh().finally(wx.stopPullDownRefresh);
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});