var e = require("../../../dao/voucher"), t = require("../../../utils/ajax"), n = require("../../../utils/util"), i = require("../../../modules/moment");

Page({
    data: {
        items: null
    },
    onLoad: function(n) {
        var a = this;
        this.syncDetails = e.details.subscribeAndFireOnce(function(e) {
            var t = null;
            Array.isArray(e) && (t = e.filter(function(e) {
                return "PAY" !== e.action;
            }).map(function(e) {
                return Object.assign({}, e);
            })).forEach(function(e) {
                e.createTime = new Date(e.createTime), e.time = i(e.createTime).format("YYYY/MM/DD HH:mm:ss"), 
                e.balance = e.available + e.paying, e.direction = "CONFIRM" !== e.action, e.amount = e.amount.toFixed(2);
            }), a.setData({
                items: t
            });
        }), e.details.refresh().catch(function(e) {
            return t.showError("获取代金券详情", e);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/settings/my-voucher/myVoucher")
        };
    }
});