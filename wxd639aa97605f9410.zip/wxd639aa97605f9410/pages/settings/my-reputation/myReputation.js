var e = require("../../../utils/user"), t = require("../../../utils/ajax"), n = require("../../../utils/util");

Page({
    data: {
        reputation: {}
    },
    onLoad: function(i) {
        var r = this;
        n.checkUserLogin(this), this.syncUserId = e.id.subscribeAndFireOnce(function(e) {
            return r.setData({
                userId: e
            });
        }), this.syncReputation = e.reputation.subscribeAndFireOnce(function(e) {
            return r.setData({
                reputation: e,
                progress: e.levelReputation ? e.reputation / e.levelReputation * 100 : 0
            });
        }), e.id.get() && e.refresh().catch(function(e) {
            return t.showError("刷新用户信息", e);
        });
    },
    onReady: function() {},
    onShow: function() {
        n.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncReputation.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.sharePath()
        };
    }
});