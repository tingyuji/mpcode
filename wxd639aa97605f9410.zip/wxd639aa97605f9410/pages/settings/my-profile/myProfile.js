var e = require("../../../utils/user"), t = require("../../../utils/ajax"), n = require("../../../utils/env"), a = require("../../../utils/util");

Page({
    data: {
        avatar: "",
        name: "",
        mobile: "",
        genders: [ "", "男", "女" ],
        genderValues: [ "", "male", "female" ],
        genderIndex: 0,
        resizeCanvasId: "resizeCanvasId",
        width: 200,
        height: 200,
        hideResizing: !0,
        wxUser: null
    },
    onLoad: function(t) {
        var r = this;
        a.checkUserLogin(this), this.syncUserId = e.id.subscribeAndFireOnce(function(e) {
            return r.setData({
                userId: e
            });
        }), this.syncAvatar = e.avatar.subscribeAndFireOnce(function(e) {
            return r.setData({
                avatar: e ? n.mercury("files/avatar/" + e) : "/images/avatar-none.png"
            });
        }), this.syncName = e.name.subscribeAndFireOnce(function(e) {
            return r.setData({
                name: e || ""
            });
        }), this.syncMobile = e.mobile.subscribeAndFireOnce(function(e) {
            return r.setData({
                mobile: e || ""
            });
        }), this.syncGender = e.gender.subscribeAndFireOnce(function(e) {
            return r.setData({
                genderIndex: r.data.genderValues.indexOf(e)
            });
        }), this.syncWxUser = e.wxUser.subscribeAndFireOnce(function(e) {
            return r.setData({
                wxUser: e || null
            });
        }), this.refresh();
    },
    onReady: function() {
        this.nameModal = this.selectComponent("#nameModal");
    },
    onShow: function() {
        a.checkUserShow(this);
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncAvatar.dispose(), this.syncName.dispose(), this.syncMobile.dispose(), 
        this.syncGender.dispose(), this.syncWxUser.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh().then(function() {
            return wx.stopPullDownRefresh();
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: a.shareTitle,
            path: a.sharePath()
        };
    },
    genderChange: function(n) {
        this.setData({
            genderIndex: n.detail.value
        }), t.mercury.post("account/save-my-profile", {
            name: e.name.get(),
            gender: this.data.genderValues[this.data.genderIndex]
        }).then(e.refresh).catch(function(e) {
            return t.showError("保存用户资料", e);
        });
    },
    changeName: function() {
        e.idCardCertified.get() ? a.alert("您已通过实名认证，无法修改姓名") : (this.setData({
            newName: this.data.name
        }), this.nameModal.show());
    },
    newNameChange: function(e) {
        this.data.newName = e.detail.value;
    },
    confirmName: function(n) {
        var a = this;
        this.nameModal.hide(), t.mercury.post("account/save-my-profile", {
            name: this.data.newName,
            gender: e.gender.get()
        }).then(function() {
            return a.setData({
                name: a.data.newName
            }), e.refresh();
        }).catch(function(e) {
            return t.showError("保存用户资料", e);
        });
    },
    updateAvatar: function(n, r, i) {
        this.resizeImage(n, r, i).then(function(n) {
            t.mercury.upload("files/upload-avatar", n, "image/jpeg").then(function(n) {
                t.mercury.post("account/save-my-profile", {
                    avatar: n,
                    name: e.name.get(),
                    gender: e.gender.get()
                }).then(e.refresh).catch(function(e) {
                    return t.showError("保存用户资料", e);
                });
            }).catch(function(e) {
                return t.showError("上传头像文件", e);
            });
        }).catch(function(e) {
            return a.alert("修改头像尺寸失败");
        });
    },
    onChooseAvatar: function(e) {
        var t = e.detail.avatarUrl;
        this.updateAvatar(t, this.data.width, this.data.height);
    },
    resizeImage: function(e, t, n, a, r, i) {
        var s = this;
        return new Promise(function(h, o) {
            s.setData({
                hideResizing: !1
            }), setTimeout(function() {
                wx.getImageInfo({
                    src: e,
                    success: function(e) {
                        if (e.width <= t && e.height <= n) h(e.path); else {
                            var c = wx.createCanvasContext("resizeCanvasId"), u = 0, d = 0, f = t, l = n, g = t / e.width, m = n / e.height;
                            switch (a) {
                              case "pad":
                                var w = Math.min(g, m);
                                f = Math.round(e.width * w), l = Math.round(e.height * w), s.setData({
                                    width: f,
                                    height: l
                                }), c.drawImage(e.path, 0, 0, f, l);
                                break;

                              case "fit":
                                var v = Math.max(g, m), p = Math.round(e.width * v), y = Math.round(e.height * v);
                                s.setData({
                                    width: p,
                                    height: y
                                }), c.drawImage(e.path, 0, 0, p, y), u = Math.floor((p - f) / 2), d = Math.floor((y - l) / 2);
                                break;

                              case "fill":
                              default:
                                s.setData({
                                    width: t,
                                    height: n
                                }), c.drawImage(e.path, 0, 0, t, n);
                            }
                            c.draw(!1, function() {
                                wx.canvasToTempFilePath({
                                    canvasId: "resizeCanvasId",
                                    x: u,
                                    y: d,
                                    width: f,
                                    height: l,
                                    destWidth: f,
                                    destHeight: l,
                                    fileType: r || "jpg",
                                    quality: i || .9,
                                    success: function(e) {
                                        return h(e.tempFilePath);
                                    },
                                    fail: o
                                });
                            });
                        }
                    },
                    fail: o
                });
            }, 100);
        }).finally(function() {
            return s.setData({
                hideResizing: !0
            });
        });
    },
    changeMobile: function() {
        t.mercury.get("account/canModifyMobile").then(function(e) {
            e ? wx.navigateTo({
                url: "../change-mobile/changeMobile"
            }) : a.alert("请完成您当前的所有运单后再更换绑定的手机号");
        });
    },
    bindWxUser: function(e) {
        var n = this;
        t.mercury.post("account/wxBind").then(function() {
            return n.refresh();
        }).catch(function(e) {
            e && e.errMsg && e.errMsg.indexOf("auth deny") >= 0 || t.showError("绑定微信号", e);
        });
    },
    refresh: function() {
        return a.showLoading("获取信息中"), e.refresh().then(function() {
            return e.refreshWxUser();
        }).finally(a.hideLoading).catch(function(e) {
            return t.showError("获取用户信息", e);
        });
    },
    subscribeWxService: function() {
        this.data.wxUser ? this.data.wxUser.subscribe || a.alert("请在微信“添加朋友”处搜索“船货不二”关注公众号", {
            confirmText: "知道了"
        }) : a.alert("请先绑定微信号", {
            confirmText: "知道了"
        });
    }
});