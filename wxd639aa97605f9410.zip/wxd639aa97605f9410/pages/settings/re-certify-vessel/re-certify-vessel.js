var e = require("../../../dao/vessel"), a = require("../../../utils/ajax"), t = require("../../../utils/util"), n = require("../../../utils/env");

Page({
    nameChange: function(e) {
        this.data.name = e.detail.value;
    },
    deadweightTonnageChange: function(e) {
        this.data.deadweightTonnage = e.detail.value;
    },
    bridgePositionChange: function(e) {
        this.setData({
            bridgePosition: e.detail.value
        });
    },
    fengcangChange: function(e) {
        this.setData({
            fengcang: e.detail.value
        });
    },
    sinkChange: function(e) {
        this.setData({
            sink: e.detail.value
        });
    },
    noteChange: function(e) {
        this.data.note = e.detail;
    },
    imageSrc: function(e, t) {
        var i = encodeURIComponent(a.getToken()), s = "";
        return "size" === t && (s = "type=size&"), n.mercury("certifications/file?".concat(s, "size=60&id=").concat(e || 0, "&authentication=").concat(i));
    },
    eulaChange: function(e) {
        this.setData({
            eula: e.detail.value
        });
    },
    openLinkEula: function(e) {
        t.browse(n.resource("app-help/eula.html?ts=".concat(new Date().getTime())), "eula");
    },
    changeLicense: function() {
        var e = this;
        this.changeImage("certification", "上传船舶适航证书", function() {
            return e.setData({
                showLicenseUploadProgress: !0,
                licenseUploadProgress: 0
            });
        }, function(a) {
            return e.setData({
                licenseUploadProgress: a
            });
        }, function() {
            return e.setData({
                showLicenseUploadProgress: !1
            });
        }, function(a) {
            return e.setData({
                licenseImage: a,
                licenseImageSrc: e.imageSrc(a)
            });
        });
    },
    changeSize: function() {
        var e = this;
        this.changeImage("size", "上传船舶尺寸页", function() {
            return e.setData({
                showSizeUploadProgress: !0,
                licenseUploadProgress: 0
            });
        }, function(a) {
            return e.setData({
                sizeUploadProgress: a
            });
        }, function() {
            return e.setData({
                showSizeUploadProgress: !1
            });
        }, function(a) {
            return e.setData({
                sizeImage: a,
                sizeImageSrc: e.imageSrc(a, "size")
            });
        });
    },
    changeImage: function(n, i, s, o, r, c) {
        var g = e.get().id;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var l = e.tempFilePaths[0];
                l && (s(), t.showLoading("图片上传中"), a.mercury.upload("certifications/upload", l, "image/jpeg", {
                    vessel: g,
                    type: n
                }, null, {
                    onProgress: function(e) {
                        return o(e.progress);
                    }
                }).finally(function() {
                    t.hideLoading(), r();
                }).then(function(e) {
                    return c(e);
                }).catch(function(e) {
                    return a.showError(i, e);
                }));
            }
        });
    },
    enlargeSamplePics: function() {
        wx.previewImage({
            urls: [ this.data.samplePicBigSrc2021, this.data.samplePicBigSrc ]
        });
    },
    enlargeSamplePicSize: function() {
        wx.previewImage({
            urls: [ this.data.samplePicBigSizeSrc ]
        });
    },
    submit: function() {
        var n = this;
        this.data.name && this.data.name.trim() ? this.data.deadweightTonnage && this.data.deadweightTonnage.toString().trim() ? !Number.isFinite(+this.data.deadweightTonnage) || +this.data.deadweightTonnage <= 0 ? t.alert("请输入正确的船皮") : this.data.eula ? this.data.licenseImage ? this.data.sizeImage ? (t.showLoading("数据提交中"), 
        a.mercury.post("certifications/reapply", {
            vessel: e.get().id,
            file: this.data.licenseImage,
            sizeFile: this.data.sizeImage,
            name: this.data.name,
            deadweightTonnage: this.data.deadweightTonnage,
            bridgePosition: this.data.bridgePosition,
            fengcang: this.data.fengcang,
            sink: this.data.sink,
            note: this.data.note
        }).finally(t.hideLoading).then(wx.navigateBack).catch(function(e) {
            403 === e.statusCode && "VESSEL_EXIST" === e.data.code ? n.conflictModal.show() : 400 === e.statusCode && "CERT_FRONT_1" === e.data.code ? t.alert("认证请上传《内河船舶适航证书》，不是大簿子首页", {
                title: "提交失败"
            }) : 400 === e.statusCode && "CERT_FRONT_2" === e.data.code ? t.alert("认证请上传《安全与环保证书》第二页，不是首页", {
                title: "提交失败"
            }) : a.showError("提交认证材料", e);
        })) : t.alert("请上传船舶尺寸页") : t.alert("请上传《内河船舶安全与环保证书》第二页或《内河船舶适航证书》") : t.alert("你需要同意船货不二用户协议") : t.alert("请输入船皮") : t.alert("请输入新船名");
    },
    confirmConflict: function() {
        this.conflictModal.hide();
    },
    complain: function() {
        t.dial400();
    },
    data: {
        samplePicBigSrc: n.resource("mp/vessel-certificate-sample-big.jpg"),
        samplePicBigSrc2021: n.resource("mp/vessel-certificate-sample-big-2021.jpg"),
        samplePicBigSizeSrc: n.resource("mp/vessel-certificate-big-size.jpg"),
        name: "",
        deadweightTonnage: null,
        bridgePosition: "unknown",
        fengcang: "unknown",
        sink: "unknown",
        note: "",
        bridgePositions: [ "前置", "后置" ],
        bridgePositionValues: [ "fore", "aft" ],
        fengcangs: [ "无封舱", "自动封舱", "棚架", "雨布" ],
        fengcangValues: [ "none", "auto", "manual", "waterproof" ],
        sinks: [ "无", "有" ],
        sinkValues: [ "no", "yes" ],
        eula: !0,
        showLicenseUploadProgress: !1,
        licenseUploadProgress: 0,
        showSizeUploadProgress: !1,
        sizeUploadProgress: 0,
        licenseImage: null,
        licenseImageSrc: null,
        sizeImage: null,
        sizeImageSrc: null
    },
    onLoad: function(t) {
        if (t.sameName) {
            var n = e.get();
            this.setData({
                name: n.name,
                deadweightTonnage: n.deadweightTonnage,
                bridgePosition: n.bridgePositions,
                fengcang: n.fengcang,
                sink: n.sink,
                note: n.note
            }), a.mercury.post("certifications/log", {
                action: "page_re_certify",
                result: t.source,
                target: this.data.name || null
            });
        }
    },
    onReady: function() {
        this.conflictModal = this.selectComponent("#conflictModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});