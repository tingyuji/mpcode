var e = require("../../../dao/voucher"), n = require("../../../utils/ajax"), t = require("../../../utils/util"), i = require("../../../utils/user");

Page({
    refresh: function() {
        i.id.get() && (e.refresh().catch(function(e) {
            return n.showError("获取代金券信息", e);
        }), e.details.refresh().catch(function(e) {
            return n.showError("获取代金券详情", e);
        }));
    },
    data: {
        voucher: null,
        available: 0,
        details: [],
        blocked: []
    },
    onLoad: function(n) {
        var r = this;
        t.checkUserLogin(this), this.syncUserId = i.id.subscribeAndFireOnce(function(e) {
            return r.setData({
                userId: e
            });
        }), this.syncVoucher = e.subscribeAndFireOnce(function(e) {
            return r.setData({
                voucher: e,
                available: (e && e.available || 0).toFixed(2)
            });
        }), this.syncDetails = e.details.subscribeAndFireOnce(function(e) {
            var n = (e = e || []).filter(function(e) {
                return "PAY" === e.action;
            });
            n.forEach(function(e) {
                var n = e.remainSecs || 0;
                e.remainMins = Math.floor(n / 60) + 1, e.amount = e.amount.toFixed(2);
            }), r.setData({
                details: e,
                blocked: n
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        t.checkUserShow(this), this.syncUserId = i.id.subscribeAndFireOnce(function(n) {
            e.setData({
                userId: n
            }), e.refresh();
        }), this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncVoucher.dispose(), this.syncDetails.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: t.shareTitle,
            path: t.sharePath()
        };
    }
});