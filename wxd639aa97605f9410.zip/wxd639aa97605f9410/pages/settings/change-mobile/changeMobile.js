var e = require("../../../utils/ajax"), t = require("../../../utils/user"), n = require("../../../utils/util");

getApp();

Page({
    data: {
        mobile: "",
        validMobile: !1,
        resend: !1,
        code: "",
        validCode: !1,
        countDown: 0
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: n.shareToPath("/pages/settings/my-profile/myProfile")
        };
    },
    mobileChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), n = /^1\d{10}$/.test(t);
        this.setData({
            mobile: t,
            validMobile: n
        });
    },
    codeChange: function(e) {
        var t = (e.detail.value || "").replace(/\s/g, ""), n = /^\d{6}$/.test(t);
        this.setData({
            code: t,
            validCode: n
        });
    },
    sendCode: function(t) {
        var n = this;
        this.data.validMobile && !this.data.countDown && e.mercury.post("account/changeMobileCode", {
            mobile: this.data.mobile
        }).then(function() {
            n.setData({
                countDown: 60,
                resend: !0
            });
            var e = setInterval(function() {
                n.data.countDown > 0 ? n.setData({
                    countDown: --n.data.countDown
                }) : clearInterval(e);
            }, 1e3);
        }).catch(function(e) {
            return n.showError("获取短信验证码", e);
        });
    },
    confirmChange: function() {
        var t = this;
        this.data.validMobile && this.data.validCode && e.mercury.post("account/changeMobile", {
            mobile: this.data.mobile,
            code: this.data.code
        }).then(function() {
            return t.changeDone();
        }).catch(function(e) {
            return t.showError("更换绑定手机号", e);
        });
    },
    getPhoneNumber: function(t) {
        var n = this;
        t.detail.encryptedData && t.detail.iv && e.mercury.post("account/changeWeixinMobile", {
            encrypted: t.detail.encryptedData,
            iv: t.detail.iv
        }).then(function() {
            return n.changeDone();
        }).catch(function(e) {
            return n.showError("绑定微信手机号", e);
        });
    },
    changeDone: function() {
        n.alert("您已成功更换绑定手机号").then(function() {
            t.refresh().then(function() {
                t.id.valueHasMutated(), wx.navigateBack();
            }).catch(function(t) {
                return e.showError("刷新用户信息", t);
            });
        });
    },
    showError: function(t, a) {
        var o = null;
        if (403 === a.statusCode) switch (a.data.code) {
          case "MOBILE_EXIST":
            o = "此手机号码已存在";
            break;

          case "WAYBILL_EXIST":
            o = "您还有未完成的运单";
            break;

          case "ERROR_CODE":
            o = "错误的验证码";
        }
        o ? n.alert(t + "失败，" + o) : e.showError(t, a);
    }
});