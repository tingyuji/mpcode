var e = require("../../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../../utils/ajax"), a = require("../../../utils/env"), i = require("../../../dao/vipStatus"), r = require("../../../utils/util"), n = require("../../../utils/user");

require("../../../modules/moment");

Page({
    data: {
        type: "",
        vipAgreement: "/pages/web-view/webView?url=".concat(encodeURIComponent(a.resource("app-help/vip-agreement.html?ts=".concat(new Date().getTime())))),
        palletVip: !1,
        initVip: !1,
        palletLeftDays: null,
        palletMonthUsed: !1,
        palletSeasonUsed: !1,
        realPrice: null,
        voucher: null,
        beginDate: "2018年3月14日",
        isIOS: r.isIOS(),
        cards: [],
        vipBought: !1,
        paying: !1
    },
    toVipAgreement: function() {
        t.mercury.post("mapps/log", {
            action: "vip-agreement",
            target: "vip-pallet"
        });
    },
    getDistance: function(e) {
        var t = new Date(e).getTime() - new Date().getTime(), a = Math.floor(t / 6e4), i = Math.floor(a / 60), r = Math.floor(i / 24);
        return i > 0 ? r > 0 ? "".concat(r, "天").concat(i % 24, "小时") : "".concat(i % 24, "小时") : "".concat(a + 1, "分钟");
    },
    refreshActivity: function() {
        var e = this;
        return t.mercury.get("vip/activity").then(function(t) {
            e.setData({
                activity: t
            });
        });
    },
    _refreshCards: function() {
        var a = this;
        return this.data.userId > 0 ? (r.showLoading("获取数据中"), t.mercury.get("vip/availableCards", {
            type: "pallet"
        }).finally(r.hideLoading).then(function(t) {
            var i, r = e(t);
            try {
                for (r.s(); !(i = r.n()).done; ) {
                    var n = i.value;
                    n.daysString = n.days + "天", 730 === n.days && (n.daysString += "(2年)"), n.first = n.cardType.indexOf("_first") >= 0, 
                    n.experience = n.cardType.indexOf("_experience") >= 0, n.recommend = !1, n.originalPrice = n.originalPrice || 0, 
                    n.cheapDesc = n.cheapDesc || "";
                }
            } catch (e) {
                r.e(e);
            } finally {
                r.f();
            }
            return t.length > 1 && (t[0].recommend = !0), a.setData({
                cards: t
            }), t[0] && a.setData({
                type: t[0].cardType
            }), a._refreshCardInfo();
        }).catch(function(e) {
            return t.showError("获取价格信息", e);
        })) : (this.setData({
            cards: []
        }), Promise.resolve());
    },
    _refreshCardInfo: function() {
        var e = this;
        if (this.data.type && this.data.userId > 0) {
            var a = this.data.type;
            return t.mercury.get("vip/cardInfo", {
                type: "pallet",
                cardType: this.data.type
            }).then(function(t) {
                a === e.data.type && e.setData({
                    realPrice: (t.price - t.voucher).toFixed(2),
                    voucher: t.voucher.toFixed(2)
                });
            });
        }
        return Promise.resolve();
    },
    switchType: function(e) {
        this._switchType(e.currentTarget.dataset.type);
    },
    _switchType: function(e) {
        e !== this.data.type && (this.setData({
            type: e
        }), r.showLoading("获取数据中"), this._refreshCardInfo().then(r.hideLoading).catch(function(e) {
            return t.showError("获取折扣信息", e);
        }));
    },
    charge: function() {
        this.setData({
            palletVip: !1
        });
    },
    canPublishBlock: function() {
        r.confirm("只有通过实名认证或完成公司授权的货主才能开通货主VIP", {
            cancelText: "实名认证",
            confirmText: "公司授权"
        }).then(function() {
            t.mercury.post("vip/log", {
                action: "vip_user_click",
                target: "vip_to_auth_company"
            }), wx.navigateTo({
                url: "/pages/settings/company-auth/companyAuth"
            });
        }).catch(function() {
            t.mercury.post("vip/log", {
                action: "vip_user_click",
                target: "vip_to_certify_mobile"
            }), wx.navigateTo({
                url: "/pages/settings/certify-mobile/certifyMobile"
            });
        });
    },
    setPaying: function() {
        var e = this;
        this.clearPaying(), this.setData({
            paying: !0
        }), this.payTimer = setTimeout(function() {
            return e.clearPaying();
        }, 3e3);
    },
    clearPaying: function() {
        this.payTimer && (clearTimeout(this.payTimer), this.payTimer = null, this.setData({
            paying: !1
        }));
    },
    pay: function() {
        var e = this;
        if (this.data.realPrice && !this.data.paying) {
            this.setPaying();
            var a = this.data.realPrice;
            t.mercury.post("vip/log", {
                action: "vip_user_click",
                target: "pay_pallet_".concat(this.data.type),
                result: a
            }), this.deadbeatBlockModal.check("vip_pallet").then(function(i) {
                i ? t.mercury.get("pallets/canPublish").then(function(i) {
                    i ? t.mercury.post("vip/buyCard", {
                        type: "pallet",
                        cardType: e.data.type
                    }).then(function(t) {
                        var i = t && t.payInfo;
                        i ? wx.requestPayment({
                            timeStamp: i.timeStamp.toString(),
                            nonceStr: i.nonceStr,
                            package: i.package,
                            signType: i.signType,
                            paySign: i.paySign,
                            success: function(i) {
                                return e.onPayDone(t.orderId, a);
                            },
                            fail: function(t) {
                                e.clearPaying();
                                var a = t.errMsg.indexOf("fail"), i = t.errMsg.slice(a + 4).trim();
                                "cancel" !== i && r.alert("付款失败，" + i);
                            }
                        }) : e.clearPaying();
                    }).catch(function(a) {
                        e.clearPaying(), t.showError("开通货主VIP", a);
                    }) : (e.clearPaying(), e.canPublishBlock());
                }).catch(function(a) {
                    e.clearPaying(), t.showError("查验货主VIP", a);
                }) : e.clearPaying();
            }).catch(function() {
                return e.clearPaying();
            });
        }
    },
    onPayDone: function(e, a) {
        var n = this;
        r.showLoading("获取结果中"), t.mercury.get("vip/payStatus", {
            orderId: e
        }).finally(function() {
            n.clearPaying(), r.hideLoading();
        }).then(function(r) {
            "USED" !== r && "BOUGHT" !== r || (t.mercury.post("vip/log", {
                action: "vip_pay_done_pallet",
                target: e,
                result: a
            }), i.refresh());
        }).catch(function(e) {
            return t.showError("获取支付结果", e);
        });
    },
    dial400: function() {
        r.dial400();
    },
    helpBuy: function() {
        var e = this;
        this.data.realPrice && (t.mercury.post("vip/log", {
            action: "help_buy_page",
            target: "pallet_".concat(this.data.type),
            result: this.data.realPrice
        }), this.deadbeatBlockModal.check("vip_pallet").then(function(a) {
            a && t.mercury.get("pallets/canPublish").then(function(t) {
                t ? wx.navigateTo({
                    url: "/pages/settings/vip-help-buy/vip-help-buy?type=pallet&cardType=".concat(e.data.type, "&amount=").concat(e.data.realPrice, "&voucher=").concat(e.data.voucher)
                }) : e.canPublishBlock();
            }).catch(function(e) {
                return t.showError("查验货主VIP", e);
            });
        }));
    },
    refresh: function() {
        this._refreshCards(), i.refresh();
    },
    onLoad: function(e) {
        var t = this;
        r.checkUserLogin(this), this.syncUserId = n.id.subscribeAndFireOnce(function(e) {
            t.setData({
                userId: e
            }), t.refresh();
        }), this.syncUserMobile = n.mobile.subscribeAndFireOnce(function(e) {
            return t.setData({
                userMobile: e || ""
            });
        }), this.syncVipStatus = i.subscribeAndFireOnce(function(a) {
            a ? t.setData({
                palletVip: !e.recharge && a.vips.indexOf("pallet") >= 0,
                initVip: a.vips.indexOf("pallet") >= 0,
                palletLeftDays: a.palletLeftDays,
                vipBought: a.palletVipBought
            }) : t.setData({
                palletVip: !1,
                initVip: !1,
                palletLeftDays: 0,
                vipBought: !1
            });
        }), this.refresh();
    },
    onReady: function() {
        this.deadbeatBlockModal = this.selectComponent("#deadbeat-block-modal");
    },
    onShow: function() {
        var e = this.notFirstShow;
        r.checkUserShow(this), e && this.refresh();
    },
    onHide: function() {},
    onUnload: function() {
        this.syncUserId.dispose(), this.syncUserMobile.dispose(), this.syncVipStatus.dispose();
    },
    onPullDownRefresh: function() {
        this.refresh(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: r.shareTitle,
            path: r.sharePath()
        };
    }
});