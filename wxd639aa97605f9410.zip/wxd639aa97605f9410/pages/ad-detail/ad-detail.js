var t = require("../../utils/ajax"), e = require("../../utils/util"), i = require("../../utils/env"), o = require("../../utils/user"), n = require("../../utils/ad");

Page({
    load: function(o) {
        var a = this;
        e.showLoading("获取数据中"), t.mercury.get("publishAd/abstract", {
            id: o
        }).finally(e.hideLoading).then(function(t) {
            a.adItem = t;
            for (var e = 0; e * e < t.photos.length; ) e++;
            var o = Math.round(320 / e);
            t.photos.forEach(function(t) {
                var e = encodeURIComponent(t.name);
                t.thumbnail = i.mercury("files/load-ad-image?name=".concat(e, "&size=").concat(o, "&mode=fill")), 
                t.url = i.mercury("files/load-ad-image?name=".concat(e, "&size=1280"));
            }), a.setData({
                title: t.title,
                contentNodes: n.getContents(t.content, !0),
                readCount: t.readCount,
                photos: t.photos,
                photoPercent: Math.round(100 / e)
            });
        }).catch(function(e) {
            return t.showError("读取广告", e);
        });
    },
    call: function(t) {
        this.makePhoneCall(t.currentTarget.dataset.mobile, "detail_content");
    },
    makePhoneCall: function(e, i) {
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "dial_ad_phone",
            result: this.source + "_" + i,
            note: {
                phone: e
            }
        }), wx.makePhoneCall({
            phoneNumber: e
        });
    },
    preview: function(t) {
        var e = t.currentTarget.dataset.photo;
        wx.previewImage({
            urls: this.data.photos.map(function(t) {
                return t.url;
            }),
            current: e.url
        });
    },
    contactPublisher: function() {
        var e = this;
        t.mercury.post("publishAd/contactPublisher", {
            id: this.adItem.id
        }).then(function(t) {
            var i = Array.isArray(t) ? t[0] : t;
            e.makePhoneCall(i, "detail_contact");
        }).catch(function(e) {
            return t.showError("获取广告主信息", e);
        });
    },
    publishAd: function() {
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_view_click",
            result: "publish_ad"
        }), o.id.get() > 0 ? wx.navigateTo({
            url: "/pages/publish-ad/publishAd?source=publishAdViewDetail"
        }) : wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        });
    },
    complain: function() {
        t.mercury.post("publishAd/log", {
            id: this.adItem.id,
            action: "ad_view_click",
            result: "complain"
        }), e.dial400();
    },
    data: {},
    onLoad: function(t) {
        this.source = t.source, this.adId = t.id, this.load(this.adId);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath({
                id: this.adId
            })
        };
    }
});