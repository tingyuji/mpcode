var t = getApp(), a = require("../../../utils/env"), e = require("../../../utils/util"), o = require("../../../utils/ajax"), i = require("../../../utils/globalMap"), s = require("../../../dao/sailorExamCompanies");

Page({
    onTab: function(t) {
        var a = t.currentTarget.dataset.tab, e = this.data.company && this.data.company.title;
        o.mercury.post("mapps/sailorExamLog", {
            action: "click.tab_" + a,
            target: e
        }), this.setTab(a);
    },
    setTab: function(t) {
        this.setData({
            tab: t
        });
    },
    tapIntro: function(t) {
        "intro" === t.currentTarget.dataset.tab && this.data.company.subPageScroll && t.detail.y - this.data.headHeight + this.data.scrollTops[0] < 35 && (this.data.scrollTops[0] = this.data.company.subPageScroll, 
        this.setData({
            scrollTops: this.data.scrollTops
        }));
    },
    scrollIntro: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.scrollTops[a] = t.detail.scrollTop;
    },
    updateItem: function() {
        var a = this;
        setTimeout(function() {
            Promise.all([ new Promise(function(t) {
                return wx.createSelectorQuery().select("#sailor-exam-top-block").boundingClientRect().exec(t);
            }), new Promise(function(t) {
                return wx.createSelectorQuery().select("#sailor-exam-bottom-block").boundingClientRect().exec(t);
            }) ]).then(function(e) {
                var o = e[0][0].height, i = e[1][0].height, s = t.globalData.systemInfo.windowHeight - o - i;
                a.setData({
                    headHeight: o,
                    frameHeight: s + "px"
                });
            });
        }, 100), this.data.tabs.concat([ "price" ]).forEach(function(t, e) {
            return a.loadHtml(t, e);
        });
    },
    loadHtml: function(t, e) {
        var i = this, s = this.data.company[t + "Url"];
        o.raw.get(s).then(function(t) {
            var o = t.match(/<body.*?>([\s\S]*)<\/body>/)[1];
            o = o.replace(/<img\s+src="/g, '<img src="'.concat(a.resource(i.data.company.baseUrl), "/"));
            var s = i.data.htmls;
            s[e] = o, i.setData({
                htmls: s
            });
        });
    },
    detailPrice: function() {
        var t = this.data.company && this.data.company.title;
        o.mercury.post("mapps/sailorExamLog", {
            action: "click.price_detail",
            target: t
        }), this.setData({
            showPrice: !0
        });
    },
    getCode: function() {
        var t = this.data.company && this.data.company.title, a = this.data.company && this.data.company.code;
        o.mercury.post("mapps/sailorExamLog", {
            action: "click.get_code",
            target: t,
            result: a
        }), this.getCodeModal.showModal();
    },
    closeGetCode: function() {
        this.getCodeModal.hideModal();
    },
    copyCode: function() {
        var t = this, a = this.data.company && this.data.company.title, e = this.data.company && this.data.company.code;
        o.mercury.post("mapps/sailorExamLog", {
            action: "click.copy_code",
            target: a,
            result: e
        }), wx.setClipboardData({
            data: this.data.company.code.toString(),
            success: function() {
                return t.closeGetCode();
            }
        });
    },
    data: {
        company: null,
        tabs: [ "intro", "feature", "trial" ],
        tab: "intro",
        htmls: [ "", "", "" ],
        scrollTops: [ 0, 0, 0 ],
        headHeight: 191,
        frameHeight: "100vh",
        intro: null,
        showPrice: !1,
        price: null
    },
    onLoad: function(t) {
        var a = this;
        t.item ? (this.setData({
            company: i.unRegister(t.item)
        }), this.updateItem(), this.setTab(this.data.tab)) : this.itemIndex = Math.max(0, t.index || 0), 
        this.syncCompanies = s.subscribeAndFireOnce(function(t) {
            Number.isFinite(a.itemIndex) && (a.setData({
                company: t[a.itemIndex]
            }), a.updateItem(), a.setTab(a.data.tab));
        });
        var e = this.data.company && this.data.company.title;
        o.mercury.post("mapps/sailorExamLog", {
            action: "page.company",
            target: e,
            result: t.source
        });
    },
    onReady: function() {
        this.getCodeModal = this.selectComponent("#getCodeModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: e.sharePath()
        };
    }
});