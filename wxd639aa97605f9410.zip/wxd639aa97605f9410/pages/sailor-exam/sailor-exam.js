var t = require("../../utils/env"), e = require("../../utils/ajax"), i = require("../../dao/sailorExamCompanies"), o = require("../../utils/util");

Page({
    enter: function() {
        this.browseUrl = this.data.item.enterUrl, this.getCode("enter");
    },
    toTrail: function() {
        this.browseUrl = this.data.item.trialUrl, this.getCode("to_trail");
    },
    viewScore: function() {
        var t = this.data.item.title, i = this.data.item.code;
        e.mercury.post("mapps/sailorExamLog", {
            action: "click.view_score",
            target: t,
            result: i
        }), o.browse(this.data.item.scoreUrl);
    },
    useCode: function() {
        var t = this.data.item.title, i = this.data.item.code;
        e.mercury.post("mapps/sailorExamLog", {
            action: "click.use_code",
            target: t,
            result: i
        }), o.browse(this.data.item.introUrl);
    },
    getCode: function(t) {
        var i = this.data.item.title, o = this.data.item.code;
        e.mercury.post("mapps/sailorExamLog", {
            action: "click." + t,
            target: i,
            result: o
        }), this.getCodeModal.show();
    },
    confirmCode: function() {
        this.getCodeModal.hide(), o.browse(this.browseUrl);
    },
    data: {
        titleImage: t.resource("mp/sailor-exam-title.jpg?v=3"),
        item: null
    },
    onLoad: function(t) {
        var o = this;
        this.syncCompanies = i.subscribeAndFireOnce(function(t) {
            return o.setData({
                item: t[0]
            });
        }), e.mercury.post("mapps/sailorExamLog", {
            action: "page.main",
            result: t.source
        });
    },
    onReady: function() {
        this.getCodeModal = this.selectComponent("#getCodeModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncCompanies.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: o.shareTitle,
            path: o.sharePath()
        };
    }
});