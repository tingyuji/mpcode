var t = require("../../utils/globalMap"), e = require("../../utils/ajax");

Page({
    data: {
        required: !1,
        keyword: "",
        searching: "",
        searched: "",
        options: [],
        hot: [],
        history: [],
        noLimit: "不限"
    },
    onLoad: function(t) {
        this.callback = t.callback, this.cargo = t.cargo, this.setData({
            required: !!t.required
        }), this.loadHotAndHistory();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    keywordChange: function(t) {
        this.setKeyword(t.detail.value);
    },
    clearKeyword: function() {
        this.setKeyword("");
    },
    setKeyword: function(t) {
        this.setData({
            keyword: t
        }), this.search(t);
    },
    search: function(t) {
        var e = this;
        setTimeout(function() {
            return e.doSearch(t || "");
        }, 100);
    },
    doSearch: function(t) {
        var n = this;
        t !== this.data.searched && t !== this.data.searching && (this.setData({
            searching: t
        }), t ? e.mercury.get("pallets/names", {
            q: t
        }).then(function(e) {
            if (t === n.data.searching) {
                e.indexOf(t) < 0 && e.unshift(t);
                var a = e.map(function(e) {
                    return n.parseOption(e, t);
                });
                n.setData({
                    options: a,
                    searched: t
                });
            }
        }) : this.setData({
            options: [],
            searched: ""
        }));
    },
    selectItem: function(e) {
        var n = t.get(this.callback);
        n && n(e ? e.text : null), wx.navigateBack();
    },
    parseOption: function(t, e) {
        var n = [];
        return t.split(e).forEach(function(t) {
            return n.push(e, t);
        }), n = n.slice(1).filter(function(t) {
            return t;
        }), {
            text: t,
            remark: "",
            keyword: e,
            nodes: n
        };
    },
    selectOption: function(t) {
        var e = t.currentTarget.dataset.option;
        this.selectItem(e);
    },
    selectNoLimit: function() {
        this.selectItem(null);
    },
    loadHotAndHistory: function() {
        var t = this, n = [ e.mercury.get("pallets/names", {
            count: 15
        }).catch(function(t) {
            return [];
        }), e.mercury.get("pallets/historyNames").catch(function(t) {
            return [];
        }) ];
        Promise.all(n).then(function(e) {
            e = e.map(function(e) {
                return e.map(function(e) {
                    return {
                        text: e,
                        selected: e === t.cargo
                    };
                });
            }), t.setData({
                hot: e[0],
                history: e[1]
            });
        });
    }
});