var e = require("../../utils/ajax"), n = require("../../utils/env"), t = require("../../dao/unseenServices"), i = [ {
    service: "safeTradeMemo",
    image: n.resource("images/safe-trade/trade-memo.jpg"),
    url: "https://mp.weixin.qq.com/s/kvVnO2knxskeSAzMGbaFxg",
    action: "safe-trade.view_trade_memo",
    title: "必看 | 手机掉江里了，手机里存的录音、图片却安然无恙？",
    description: "经常有船老大跟小编讲，我手机掉水里啦，之前的录音、图片全都找不到了……"
}, {
    service: "safeTrade190304",
    image: n.resource("images/safe-trade/contract-helper.jpg"),
    url: "https://mp.weixin.qq.com/s/mxzE2ky05852afAE3nGfjg",
    action: "safe-trade.view_contract_helper",
    title: "水运合同中的陷阱，你知道几个？",
    description: "你知道你签的水运合同中，存在多少陷阱吗……"
}, {
    service: "safeTrade",
    image: n.resource("images/safe-trade/sharp-eyes.jpg"),
    url: "https://mp.weixin.qq.com/s/mdjqZLQd6OTi5wWHRSCXZg",
    action: "safe-trade.view_sharp_eyes",
    title: "寻船找货识别骗子的准确率居然可达100%",
    description: "网上寻船找货靠谱吗？当然不靠谱。微信群里有陌生人发信息，啥都不了解您就敢跟他做生意？"
} ];

Page({
    onClick: function(n) {
        var i = n.currentTarget.dataset.item;
        t.see(i.service), e.mercury.post("mapps/log", {
            action: i.action
        }), wx.navigateTo({
            url: "/pages/web-view/webView?url=".concat(encodeURIComponent(i.url))
        });
    },
    data: {
        seen: [],
        unseen: []
    },
    onLoad: function(e) {
        var n = this;
        this.syncUnseen = t.subscribeAndFireOnce(function(e) {
            return n.setData({
                seen: i.filter(function(n) {
                    return e.indexOf(n.service) < 0;
                }),
                unseen: i.filter(function(n) {
                    return e.indexOf(n.service) >= 0;
                })
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncUnseen.dispose();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: util.shareTitle,
            path: util.sharePath()
        };
    }
});