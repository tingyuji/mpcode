var t = require("../../utils/globalMap"), i = require("../../utils/util.js");

Page({
    data: {
        blankPorts: [],
        fleet: null,
        shipSingle: null,
        shipCount: null,
        draught: null,
        shipLength: null,
        shipWidth: null,
        shipHeight: null,
        hatchLength: null,
        hatchWidth: null,
        hatchDepth: null,
        fengcangRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "yes",
            text: "需封舱"
        } ],
        fengcang: null,
        fengcangCursor: null,
        fengcangText: null,
        shuichiRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "biaozhun",
            text: "标准水尺"
        }, {
            id: "magang",
            text: "马钢水尺"
        }, {
            id: "wugang",
            text: "武钢水尺"
        }, {
            id: "zhonggang",
            text: "重钢水尺"
        } ],
        shuichi: null,
        shuichiCursor: null,
        shuichiText: null,
        bridgePositionRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "fore",
            text: "前置"
        }, {
            id: "aft",
            text: "后置"
        } ],
        bridgePosition: null,
        bridgePositionCursor: null,
        bridgePositionText: null,
        hatchRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "whole",
            text: "通舱"
        }, {
            id: "division",
            text: "分舱"
        } ],
        hatch: null,
        hatchCursor: null,
        hatchText: null,
        dakongRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "yes",
            text: "需打孔"
        } ],
        dakong: null,
        dakongCursor: null,
        dakongText: null,
        sinkRange: [ {
            id: "unknown",
            text: "无要求"
        }, {
            id: "yes",
            text: "需排水槽"
        } ],
        sink: null,
        sinkCursor: null,
        sinkText: null,
        anyWeight: !1,
        minWeight: null,
        maxWeight: null
    },
    onLoad: function(t) {
        var i = {
            callback: t.callback,
            fengcang: t.fengcang,
            shuichi: t.shuichi,
            bridgePosition: t.bridgePosition,
            hatch: t.hatch,
            dakong: t.dakong,
            sink: t.sink
        };
        "yes" === i.fengcang ? (i.fengcangText = "需封舱", i.fengcangCursor = 1) : (i.fengcang = "unknown", 
        i.fengcangText = "无要求", i.fengcangCursor = 0), "biaozhun" === i.shuichi ? (i.shuichiText = "标准水尺", 
        i.shuichiCursor = 1) : "magang" === i.shuichi ? (i.shuichiText = "马钢水尺", i.shuichiCursor = 2) : "wugang" === i.shuichi ? (i.shuichiText = "武钢水尺", 
        i.shuichiCursor = 3) : "zhonggang" === i.shuichi ? (i.shuichiText = "重钢水尺", i.shuichiCursor = 4) : (i.shuichi = "unknown", 
        i.shuichiText = "无要求", i.shuichiCursor = 0), "fore" === i.bridgePosition ? (i.bridgePositionText = "前置", 
        i.bridgePositionCursor = 1) : "aft" === i.bridgePosition ? (i.bridgePositionText = "后置", 
        i.bridgePositionCursor = 2) : (i.bridgePosition = "unknown", i.bridgePositionText = "无要求", 
        i.bridgePositionCursor = 0), "whole" === i.hatch ? (i.hatchText = "通舱", i.hatchCursor = 1) : "division" === i.hatch ? (i.hatchText = "分舱", 
        i.hatchCursor = 2) : (i.hatch = "unknown", i.hatchText = "无要求", i.hatchCursor = 0), 
        "yes" === i.dakong ? (i.dakongText = "需打孔", i.dakongCursor = 1) : (i.dakong = "unknown", 
        i.dakongText = "无要求", i.dakongCursor = 0), "yes" === i.sink ? (i.sinkText = "需排水槽", 
        i.sinkCursor = 1) : (i.sink = "unknown", i.sinkText = "无要求", i.sinkCursor = 0), 
        t.draught && (i.draught = t.draught), t.shipLength && (i.shipLength = t.shipLength), 
        t.shipWidth && (i.shipWidth = t.shipWidth), t.shipHeight && (i.shipHeight = t.shipHeight), 
        t.hatchLength && (i.hatchLength = t.hatchLength), t.hatchWidth && (i.hatchWidth = t.hatchWidth), 
        t.hatchDepth && (i.hatchDepth = t.hatchDepth);
        var n = (t.blankPorts || "").split(",").map(function(t) {
            return t.trim();
        }).filter(function(t) {
            return t;
        }), h = (t.blankPortTitles || "").split(",").map(function(t) {
            return t.trim();
        }).filter(function(t) {
            return t;
        });
        i.blankPorts = n.map(function(t, i) {
            return {
                id: t,
                title: h[i] || t
            };
        }), t.fleet && (i.fleet = !0), t.shipSingle && (i.shipSingle = !0), t.shipCount && (i.shipCount = t.shipCount), 
        t.anyWeight && (i.anyWeight = !0), t.minWeight && (i.anyWeight = !1, i.minWeight = t.minWeight), 
        t.maxWeight && (i.anyWeight = !1, i.maxWeight = t.maxWeight), this.setData(i);
    },
    setDraught: function(t) {
        this.data.draught = t.detail.value;
    },
    setShipLength: function(t) {
        this.data.shipLength = t.detail.value;
    },
    setShipWidth: function(t) {
        this.data.shipWidth = t.detail.value;
    },
    setShipHeight: function(t) {
        this.data.shipHeight = t.detail.value;
    },
    setHatchLength: function(t) {
        this.data.hatchLength = t.detail.value;
    },
    setHatchWidth: function(t) {
        this.data.hatchWidth = t.detail.value;
    },
    setHatchDepth: function(t) {
        this.data.hatchDepth = t.detail.value;
    },
    setShipCount: function(t) {
        this.data.shipCount = t.detail.value;
    },
    setMinWeight: function(t) {
        this.data.minWeight = t.detail.value;
    },
    setMaxWeight: function(t) {
        this.data.maxWeight = t.detail.value;
    },
    blankPortsChange: function(t) {
        this.setData({
            blankPorts: t.detail
        });
    },
    fengcangChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.fengcangRange[i];
        this.setData({
            fengcang: n.id,
            fengcangText: n.text,
            fengcangCursor: i
        });
    },
    shuichiChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.shuichiRange[i];
        this.setData({
            shuichi: n.id,
            shuichiText: n.text,
            shuichiCursor: i
        });
    },
    bridgePositionChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.bridgePositionRange[i];
        this.setData({
            bridgePosition: n.id,
            bridgePositionText: n.text,
            bridgePositionCursor: i
        });
    },
    hatchChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.hatchRange[i];
        this.setData({
            hatch: n.id,
            hatchText: n.text,
            hatchCursor: i
        });
    },
    dakongChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.dakongRange[i];
        this.setData({
            dakong: n.id,
            dakongText: n.text,
            dakongCursor: i
        });
    },
    sinkChange: function(t) {
        var i = parseInt(t.detail.value) || 0, n = this.data.sinkRange[i];
        this.setData({
            sink: n.id,
            sinkText: n.text,
            sinkCursor: i
        });
    },
    fleetChange: function(t) {
        this.setData({
            fleet: t.detail.value.indexOf("fleet") >= 0
        });
    },
    shipSingleChange: function(t) {
        this.setData({
            shipSingle: t.detail.value.indexOf("shipSingle") >= 0
        });
    },
    anyWeightChange: function(t) {
        this.setData({
            anyWeight: t.detail.value.indexOf("anyWeight") >= 0
        });
    },
    ensure: function() {
        var n = this.data.anyWeight, h = this.data.minWeight, a = this.data.maxWeight;
        if (i.isNil(n)) i.alert("必须填写船皮"); else if (!n && i.isNil(h) && i.isNil(a)) i.alert("必须填写船皮"); else {
            var e = t.get(this.data.callback);
            e && e({
                anyWeight: this.data.anyWeight,
                minWeight: this.data.minWeight,
                maxWeight: this.data.maxWeight,
                blankPorts: this.data.blankPorts,
                fleet: !!this.data.fleet,
                shipSingle: !!this.data.shipSingle,
                shipCount: this.data.shipCount,
                fengcang: this.data.fengcang,
                shuichi: this.data.shuichi,
                bridgePosition: this.data.bridgePosition,
                hatch: this.data.hatch,
                dakong: this.data.dakong,
                sink: this.data.sink,
                draught: this.data.draught,
                shipLength: this.data.shipLength,
                shipWidth: this.data.shipWidth,
                shipHeight: this.data.shipHeight,
                hatchLength: this.data.hatchLength,
                hatchWidth: this.data.hatchWidth,
                hatchDepth: this.data.hatchDepth
            }), wx.navigateBack();
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});