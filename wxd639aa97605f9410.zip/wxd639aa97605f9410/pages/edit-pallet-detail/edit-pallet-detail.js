var e = require("../../utils/ajax"), t = require("../../utils/env"), a = require("../../dao/enterprise"), n = require("../../modules/moment"), i = require("../../dao/pallet"), r = require("../../dao/cash"), o = require("../../utils/util"), l = require("../../utils/user"), s = require("../../utils/greatPallet");

Page({
    updateGreatPallets: function() {
        var e = "";
        if (r.get() >= .1) {
            var t = i.pallets.get().filter(function(e) {
                return e.great && !e.great.pause;
            }).length, a = 6 * Math.floor(10 * r.get() / t), n = Math.floor(a / 60), o = Math.floor(n / 16);
            e = o > 0 ? o + "天" : n > 0 ? n + "小时" : a + "分钟";
        }
        this.setData({
            greatPalletLeftDesc: e
        });
    },
    toUpgrade: function() {
        var e = this;
        s.upgrade(this.data.pallet.id, "myPalletDetail", function() {
            return e.load();
        }, this.selectComponent("#upgrade-done"));
    },
    toCharge: function() {
        s.upgrade(null, "myPalletDetail", null, null);
    },
    load: function() {
        var t = this;
        o.showLoading("获取数据中"), Promise.all([ e.mercury.post("greatPallet/update"), r.refresh() ]).then(function() {
            return i.pallets.refresh();
        }).then(function() {
            return e.mercury.get("pallets/load", {
                id: t.data.id
            });
        }).finally(o.hideLoading).then(function(e) {
            return t.setData({
                pallet: i.fixInView(e)
            });
        }).catch(function(t) {
            return e.showError("加载货源", t);
        });
    },
    data: {
        id: 0,
        pallet: null,
        banner: t.resource("mp/delegate.jpg")
    },
    edit: function(e) {
        o.showLoading("加载页面中"), i.canPublish(function(e, t) {
            o.hideLoading(), t ? wx.redirectTo({
                url: "/pages/edit-pallet/edit-pallet?id=" + this.data.id
            }) : o.authPalletCreateModal();
        }.bind(this));
    },
    remove: function(t) {
        wx.showModal({
            title: "删除货源",
            content: "是否删除货源？",
            success: function(t) {
                t.confirm && e.mercury.post("pallets/remove", {
                    id: this.data.id
                }).then(function() {
                    wx.navigateBack();
                }.bind(this));
            }.bind(this)
        });
    },
    onLoad: function(e) {
        var t = this, o = a.get(), l = parseInt(e && e.id) || 0, s = n().format("YYYY-MM-DD");
        this.setData({
            id: l,
            today: s,
            date: s,
            isStarEnterprise: o && o.store
        }), this.syncPallets = i.pallets.subscribeAndFireOnce(function(e) {
            return t.updateGreatPallets();
        }), this.syncCash = r.subscribeAndFireOnce(function(e) {
            return t.updateGreatPallets();
        }), this.load();
    },
    previewLocation: function(e) {
        var t = e.currentTarget.dataset.location;
        wx.openLocation({
            latitude: t.lat,
            longitude: t.lng,
            name: t.poiname,
            address: t.poiaddress
        });
    },
    preview: function(e) {
        var t = e.currentTarget.dataset.media, a = this.data.pallet.media.findIndex(function(e) {
            return e.id === t.id;
        });
        a = Math.max(0, a), wx.previewMedia({
            sources: this.data.pallet.media.map(function(e) {
                return {
                    url: e.url,
                    type: e.isVideo ? "video" : "image",
                    poster: e.thumbnail
                };
            }),
            current: a
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this.notFirstShow;
        this.notFirstShow = !0, e && this.load();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = this.data.pallet, a = "".concat(t.startPort, " → ").concat(t.aimPort, " ").concat(t.cargo, " ").concat(t.name);
        t.official && (a += " ".concat(l.mobile.get(), " ").concat(l.name.get().slice(0, 1)));
        var n = "/pages/pallet-detail/pallet-detail?id=".concat(t.id, "&origin=0&mark=0&showIndex=").concat(t.showIndex, "&originType=share-edit");
        return {
            title: a,
            path: "/pages/index/index?navigate=" + encodeURIComponent(n),
            success: function(a) {
                "shareAppMessage:ok" === a.errMsg && e.mercury.post("miniProgram/sharePage", {
                    page: o.getCurrentPageName(),
                    target: t.id
                });
            }
        };
    }
});