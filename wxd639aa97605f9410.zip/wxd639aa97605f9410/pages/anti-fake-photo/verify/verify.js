var e = require("../../../utils/util"), o = require("../../../utils/env"), t = require("../../../utils/ajax"), a = require("../../../utils/globalMap"), r = require("../common");

Page({
    verifyPhoto: function() {
        var o = this;
        t.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.verify_upload_try"
        }), wx.chooseImage({
            sizeType: [ "original" ],
            sourceType: [ "album" ],
            count: 1,
            success: function(a) {
                t.mercury.post("antiFakePhoto/log", {
                    action: "anti_fake_photo.verify_photo_selected"
                }), e.showLoading("上传照片中"), o.setData({
                    uploading: !0,
                    uploadProgress: 0
                }), t.mercury.upload("antiFakePhoto/verifyPhoto", a.tempFilePaths[0], "image/jpeg", null, null, {
                    onProgress: function(e) {
                        return o.setData({
                            uploadProgress: e.progress
                        });
                    }
                }).finally(function() {
                    o.setData({
                        uploading: !1
                    }), e.hideLoading();
                }).then(function(e) {
                    return o.showResult(e);
                }).catch(function(e) {
                    return t.showError("上传验证照片", e);
                });
            }
        });
    },
    showResult: function(e) {
        wx.navigateTo({
            url: "../compare/compare?result=".concat(a.register(e))
        });
    },
    data: {
        watermarkDate: o.resource("app-help/images/anti-fake-photo/weixin-help-watermark-date.jpg"),
        watermarkGrid: o.resource("app-help/images/anti-fake-photo/weixin-help-watermark-grid.jpg"),
        uploading: !1,
        uploadProgress: 0
    },
    onLoad: function(e) {
        t.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.page_verify",
            target: e.source
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: r.shareTitle,
            path: e.sharePath()
        };
    }
});