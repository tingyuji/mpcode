var t = require("../../../utils/util"), o = require("../../../utils/ajax"), n = require("../common"), e = getApp();

Page({
    cancel: function() {
        wx.navigateBack();
    },
    takePhoto: function() {
        var t = this;
        this.takingPhoto || (this.takingPhoto = !0, this.doTakePhoto().finally(function() {
            return t.takingPhoto = !1;
        }).then(function(n) {
            o.mercury.post("antiFakePhoto/log", {
                action: "anti_fake_photo.".concat(t.action, "_done")
            }), wx.redirectTo({
                url: "../upload/upload?photo=".concat(n)
            });
        }));
    },
    doTakePhoto: function() {
        return new Promise(function(t, o) {
            wx.createCameraContext().takePhoto({
                quality: "high",
                success: function(o) {
                    return t(o.tempImagePath);
                },
                fail: o
            });
        });
    },
    switchCamera: function() {
        this.setData({
            cameraPosition: "back" === this.data.cameraPosition ? "front" : "back"
        });
    },
    getAuthSetting: function() {
        return new Promise(function(t, o) {
            wx.getSetting({
                success: function(o) {
                    return t(o.authSetting["scope.camera"]);
                },
                fail: o
            });
        });
    },
    checkAuth: function() {
        var o = this;
        this.unloaded || this.getAuthSetting().then(function(n) {
            if (n) ; else {
                if (!1 !== n) throw "not_set";
                t.confirm("无法使用摄像头，请打开“摄像头”权限").then(function() {
                    o.authConfigured = !0, wx.openSetting();
                }).catch(wx.navigateBack);
            }
        }).catch(function() {
            return setTimeout(function() {
                return o.checkAuth();
            }, 500);
        });
    },
    data: {
        cameraHeight: e.globalData.systemInfo.windowHeight - 80 + "px",
        cameraPosition: "back"
    },
    onLoad: function(t) {
        this.retake = t.retake, this.action = t.retake ? "retake_photo" : "take_photo", 
        o.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.".concat(this.action, "_try")
        }), this.checkAuth();
    },
    onReady: function() {},
    onShow: function() {
        this.authConfigured && wx.redirectTo({
            url: "./take" + (this.retake ? "?retake=1" : "")
        });
    },
    onHide: function() {},
    onUnload: function() {
        this.unloaded = !0;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: t.shareToPath("/pages/anti-fake-photo/anti-fake-photo")
        };
    }
});