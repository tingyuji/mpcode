var t = require("../../../utils/util"), o = require("../../../utils/ajax"), a = require("../../../utils/env"), e = require("../common");

Page({
    preview: function() {
        wx.previewImage({
            urls: [ this.data.imgSrc ]
        });
    },
    savePhoto: function() {
        o.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.view_photo_save",
            target: this.hash
        }), wx.saveImageToPhotosAlbum({
            filePath: this.data.imgSrc,
            success: function() {
                return t.alert("照片保存成功");
            },
            fail: function(o) {
                /fail[:\s]?cancel$/.test(o.errMsg) || t.alert("照片保存失败， 请打开“保存到相册”的权限后再试一次").then(wx.openSetting);
            }
        });
    },
    downloadPhoto: function(t) {
        return new Promise(function(o, a) {
            wx.downloadFile({
                url: t,
                success: function(t) {
                    return o(t.tempFilePath);
                },
                fail: a
            });
        });
    },
    data: {
        imgSrc: ""
    },
    onLoad: function(e) {
        var n = this;
        this.hash = e.hash, o.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.view_photo",
            target: this.hash
        }), t.showLoading("获取照片中"), this.downloadPhoto(a.mercury("antiFakePhoto/photo?hash=" + this.hash)).then(function(t) {
            return n.setData({
                imgSrc: t
            });
        }).finally(t.hideLoading).catch(function(t) {
            return o.showError("获取防伪证件照", t);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: e.shareTitle,
            path: this.hash ? t.sharePath({
                hash: this.hash
            }) : t.shareToPath("/pages/anti-fake-photo/anti-fake-photo")
        };
    }
});