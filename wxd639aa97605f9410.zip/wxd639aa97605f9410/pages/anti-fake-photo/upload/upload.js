var t = require("../../../utils/util"), a = require("../../../utils/env"), e = require("../../../utils/ajax"), o = require("../../../utils/globalMap"), n = require("../../../modules/moment"), i = require("../common"), r = getApp(), s = a.resource("app-help/images/anti-fake-photo/watermark.png");

Page({
    initPhoto: function() {
        var a = this;
        t.showLoading("处理照片中"), this.processPhoto(this.photo).finally(t.hideLoading).then(function(t) {
            a.setData({
                imgSrc: t
            });
        }).catch(function(e) {
            return t.alert("照片处理失败").then(function() {
                return a.retakePhoto();
            });
        });
    },
    processPhoto: function(t) {
        var a = this;
        return new Promise(function(e, o) {
            wx.downloadFile({
                url: s,
                success: function(n) {
                    var i = n.tempFilePath;
                    wx.getImageInfo({
                        src: t,
                        success: function(t) {
                            var n = t.width, s = t.height;
                            s > 1920 && (n = Math.round(1920 * n / s), s = 1920), n > 1920 && (s = Math.round(1920 * s / n), 
                            n = 1920);
                            var h = r.globalData.systemInfo.pixelRatio;
                            n = Math.round(n / h), s = Math.round(s / h), a.setData({
                                width: n,
                                height: s
                            });
                            var u = wx.createCanvasContext("photoCanvasId");
                            u.drawImage(t.path, 0, 0, n, s);
                            for (var c = Math.min(n, s) / 3, l = 512; l > c; ) l /= 2;
                            for (var d = 0; d < n; d += l) for (var f = 0; f < s; f += l) u.drawImage(i, d, f, l, l);
                            a.drawWatermarkText(u, n / 2, s / 2, n / 10), u.draw(!1, function() {
                                return a.canvasToImage(n, s, 20, 1e3).then(e).catch(o);
                            });
                        },
                        fail: o
                    });
                },
                fail: o
            });
        });
    },
    canvasToImage: function(t, a, e, o) {
        var n = this;
        return new Promise(function(i, r) {
            wx.canvasToTempFilePath({
                canvasId: "photoCanvasId",
                fileType: "jpg",
                quality: .8,
                success: function(t) {
                    return i(t.tempFilePath);
                },
                fail: function(s) {
                    e > 0 && /fail[:\s]?create bitmap fail/.test(s.errMsg) ? setTimeout(function() {
                        return n.canvasToImage(t, a, e - 1, o).then(i).catch(r);
                    }, o) : r(s);
                }
            });
        });
    },
    drawWatermarkText: function(t, a, e, o) {
        t.font = 'normal bold 10px "黑体"', t.setFontSize(o), t.fillStyle = "rgba(255,192,203,0.3)", 
        t.strokeStyle = "rgba(64,64,64,0.3)", t.lineWidth = 1, t.textBaseline = "middle", 
        t.textAlign = "center";
        var i = n().format("Y年M月D日"), r = [ "船货不二防伪证件照", "拍摄于".concat(i), "仅限拍照当天使用" ];
        if (t.measureText) {
            var s = t.measureText(r[0]);
            s.width > 9.2 * o && (o *= 9 * o / s.width, t.setFontSize(o));
        }
        t.translate(a, e), t.rotate(-20 * Math.PI / 180), r.forEach(function(a, e) {
            t.fillText(a, 0, o * (e - 1) * 1.4), t.strokeText && t.strokeText(a, 0, o * (e - 1) * 1.4);
        });
    },
    preview: function() {
        wx.previewImage({
            urls: [ this.data.imgSrc ]
        });
    },
    retakePhoto: function() {
        this.retakeFunc && this.retakeFunc(), wx.navigateBack();
    },
    savePhoto: function() {
        var a = this;
        this.uploadPhoto("save").then(function(o) {
            e.mercury.post("antiFakePhoto/log", {
                action: "anti_fake_photo.save_photo",
                target: o.id
            }), wx.saveImageToPhotosAlbum({
                filePath: a.data.imgSrc,
                success: function() {
                    return t.alert("照片保存成功");
                },
                fail: function(a) {
                    /fail[:\s]?cancel$/.test(a.errMsg) || t.alert("照片保存失败， 请打开“保存到相册”的权限后再试一次").then(wx.openSetting);
                }
            });
        });
    },
    uploadPhoto: function(a) {
        var o = this;
        return this.data.uploadResult ? Promise.resolve(this.data.uploadResult) : (t.showLoading("上传照片备案"), 
        this.setData({
            uploading: !0,
            uploadProgress: 0
        }), this.doUploadPhoto(a).finally(function() {
            o.setData({
                uploading: !1
            }), t.hideLoading();
        }).catch(function(t) {
            throw e.showError("上传照片备案", t), t;
        }));
    },
    doUploadPhoto: function(t) {
        var a = this;
        return new Promise(function(o, n) {
            wx.getFileInfo({
                filePath: a.data.imgSrc,
                digestAlgorithm: "md5",
                success: function(i) {
                    e.mercury.upload("antiFakePhoto/uploadPhoto", a.data.imgSrc, "image/jpeg", {
                        action: t,
                        code: i.digest,
                        exif: ""
                    }, null, {
                        onProgress: function(t) {
                            return a.setData({
                                uploadProgress: t.progress
                            });
                        }
                    }).then(function(t) {
                        a.enableShare(t), o(t);
                    }).catch(n);
                },
                fail: n
            });
        });
    },
    enableShare: function(t) {
        this.setData({
            uploadResult: t
        }), this.hash = t.hash, wx.showShareMenu();
    },
    sharePhoto: function() {
        var t = this;
        this.uploadPhoto("share").then(function(a) {
            t.shareModal.show();
        });
    },
    shareModalShare: function() {
        this.shareModal.hide();
    },
    data: {
        imgSrc: "",
        photoCanvasId: "photoCanvasId",
        width: 0,
        height: 0,
        uploadResult: null,
        uploading: !1,
        uploadProgress: 0
    },
    onLoad: function(t) {
        wx.hideShareMenu();
        var a = o.unRegister(t.params);
        this.retakeFunc = a && a.retake, this.photo = t.photo || a && a.photo, this.initPhoto();
    },
    onReady: function() {
        this.shareModal = this.selectComponent("#shareModal");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        encodeURIComponent("/pages/anti-fake-photo/photo/photo?hash=".concat(this.hash));
        return {
            title: i.shareTitle,
            path: t.shareToPath("/pages/anti-fake-photo/photo/photo", {
                hash: this.hash
            }),
            imageUrl: this.data.imgSrc
        };
    }
});