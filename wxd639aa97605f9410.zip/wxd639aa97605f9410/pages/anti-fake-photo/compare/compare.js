var e = require("../../../@babel/runtime/helpers/typeof"), t = require("../../../utils/util"), o = require("../../../utils/ajax"), a = require("../../../utils/globalMap"), i = require("../../../modules/moment"), r = require("../common");

Page({
    preview: function() {
        o.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.compare_enlarge"
        }), wx.previewImage({
            urls: [ this.data.imgSrc ]
        });
    },
    data: {},
    onLoad: function(t) {
        var o = a.unRegister(t.result);
        if ("object" === e(o) && o.url) this.setData({
            result: "similar",
            imgSrc: o.url,
            time: i(o.time).format("Y年M月D日 HH:mm:ss")
        }); else {
            var r = !("fail" === o || "not_today" === o);
            this.setData({
                result: r ? "match" : o,
                time: r ? i(o).format("Y年M月D日 HH:mm:ss") : ""
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: r.shareTitle,
            path: t.shareToPath("/pages/anti-fake-photo/anti-fake-photo")
        };
    }
});