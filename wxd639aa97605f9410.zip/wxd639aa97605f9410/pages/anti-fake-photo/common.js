module.exports = {
    shareTitle: "防伪证件照"
};