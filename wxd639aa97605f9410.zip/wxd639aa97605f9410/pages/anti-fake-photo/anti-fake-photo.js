var o = require("../../utils/util"), t = require("../../utils/env"), e = require("../../utils/ajax"), a = require("../../utils/globalMap"), n = require("./common");

Page({
    enlargeDemo: function() {
        e.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.enlarge_demo"
        }), wx.previewImage({
            urls: [ this.data.demoUrl ]
        });
    },
    verifyPhoto: function() {
        wx.navigateTo({
            url: "verify/verify"
        });
    },
    takePhoto: function(o) {
        var t = this;
        if (!this.takingPhoto) {
            this.takingPhoto = !0;
            var n = o ? "retake_photo" : "take_photo";
            e.mercury.post("antiFakePhoto/log", {
                action: "anti_fake_photo.".concat(n, "_try")
            }), this.doTakePhoto().finally(function() {
                return t.takingPhoto = !1;
            }).then(function(o) {
                e.mercury.post("antiFakePhoto/log", {
                    action: "anti_fake_photo.".concat(n, "_done")
                });
                var i = {
                    photo: o,
                    retake: function() {
                        return t.retakeFlag = !0;
                    }
                };
                wx.navigateTo({
                    url: "upload/upload?params=".concat(a.register(i))
                });
            });
        }
    },
    doTakePhoto: function() {
        return new Promise(function(o, t) {
            wx.chooseImage({
                count: 1,
                sizeType: [ "original" ],
                sourceType: [ "camera" ],
                success: function(t) {
                    return o(t.tempFilePaths[0]);
                },
                fail: t
            });
        });
    },
    data: {
        demoUrl: t.resource("app-help/images/anti-fake-photo/demo.jpg")
    },
    onLoad: function(o) {
        e.mercury.post("antiFakePhoto/log", {
            action: "anti_fake_photo.page_main",
            target: o.source
        });
    },
    onReady: function() {},
    onShow: function() {
        this.retakeFlag && (this.retakeFlag = !1, this.takePhoto(!0));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: n.shareTitle,
            path: o.sharePath()
        };
    }
});