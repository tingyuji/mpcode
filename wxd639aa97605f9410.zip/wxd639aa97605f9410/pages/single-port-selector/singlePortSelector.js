var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("../../utils/globalMap"), i = require("../../utils/ajax"), r = require("../../utils/user");

Page({
    data: {
        required: !1,
        type: "",
        keyword: "",
        searching: "",
        searched: "",
        options: [],
        hot: [],
        history: [],
        noLimit: "不限",
        singleHistory: !0
    },
    onLoad: function(t) {
        this.callback = t.callback, this.type = (t.type || "").toLowerCase().startsWith("ship") ? "ship" : "pallet", 
        this.keywordType = t.type ? t.type + "Keyword" : "keyword", this.port = t.port, 
        this.singleHistory = !t.allowArea, this.setData({
            required: !!t.required
        }), this.loadHotAndHistory();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    keywordChange: function(t) {
        this.setKeyword(t.detail.value);
    },
    clearKeyword: function() {
        this.setKeyword("");
    },
    setKeyword: function(t) {
        this.setData({
            keyword: t
        }), this.search(t);
    },
    search: function(t) {
        var e = this;
        setTimeout(function() {
            return e.doSearch(t || "");
        }, 100);
    },
    doSearch: function(t) {
        var e = this;
        t !== this.data.searched && t !== this.data.searching && (this.setData({
            searching: t
        }), t ? i.mercury.get("search/" + this.keywordType, {
            q: t
        }).then(function(i) {
            if (t === e.data.searching) {
                var r = i.map(function(i) {
                    return e.parseOption(i, t);
                });
                e.setData({
                    options: r,
                    searched: t
                });
            }
        }) : this.setData({
            options: [],
            searched: ""
        }));
    },
    loadHotAndHistory: function() {
        var e = this, n = [ i.mercury.get("search/".concat(this.type, "sTopPorts"), {
            count: 15
        }).then(function(t) {
            return t.map(function(t) {
                return {
                    id: t.id,
                    title: t.name
                };
            });
        }).catch(function(t) {
            return [];
        }), r.id.get() ? i.mercury.get("ports/history", {
            single: this.singleHistory
        }).then(function(t) {
            return t.map(function(t) {
                return {
                    id: t.id,
                    title: t.text
                };
            });
        }).catch(function(t) {
            return [];
        }) : Promise.resolve([]) ];
        Promise.all(n).then(function(i) {
            var r = t(i, 2), n = r[0], o = r[1];
            n.concat(o).forEach(function(t) {
                return t.selected = t.id === e.port;
            }), e.setData({
                hot: n,
                history: o
            });
        });
    },
    selectItem: function(t) {
        var i = e.get(this.callback);
        i && i(t ? {
            id: t.id,
            title: t.title
        } : null), wx.navigateBack();
    },
    parseOption: function(t, e) {
        var i = [];
        return t.text.split(e).forEach(function(t) {
            return i.push(e, t);
        }), i = i.slice(1).filter(function(t) {
            return t;
        }), {
            id: t.Id,
            title: t.text,
            remark: t.remark,
            keyword: e,
            nodes: i
        };
    },
    selectOption: function(t) {
        var e = t.currentTarget.dataset.option;
        this.selectItem(e);
    },
    selectNoLimit: function() {
        this.selectItem(null);
    }
});