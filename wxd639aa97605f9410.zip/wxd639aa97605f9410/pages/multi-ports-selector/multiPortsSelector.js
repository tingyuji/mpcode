var t = require("../../@babel/runtime/helpers/typeof"), e = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../utils/globalMap"), a = require("../../utils/util"), n = require("../../utils/ajax"), o = require("../../dao/port_hierarchy"), s = require("../../modules/spark-md5"), h = {
    root: "国",
    "国": {}
};

Page({
    data: {
        ports: [],
        options: [],
        root: "",
        level: "",
        maxCount: 0,
        required: !1,
        manual: null,
        nearPorts: []
    },
    onLoad: function(t) {
        var e = this, r = i.unRegister(t.query), n = r.type || "palletStart", s = o.get()[n];
        this.hierarchy = s || h, this.callback = r.callback;
        var c = r.ports, l = this.hierarchy.root;
        this.setData({
            root: l
        }), this.setData({
            maxCount: +r.maxCount || 0,
            level: l,
            ports: c,
            options: this.getOptions(l, c),
            required: !!r.required,
            manual: r.manual || null,
            type: n,
            title: r.title || "当前所选地区和港口",
            titleHighlight: r.titleHighlight || "",
            placeholder: r.placeholder || "您选择的地区和港口将显示在这里"
        }), this.syncHierachy = o.subscribe(function(t) {
            e.hierarchy = t[n], e.setData({
                root: e.hierarchy.root,
                options: e.getOptions(e.data.level, e.data.ports)
            });
        }), s ? o.refresh(n) : (a.showLoading("加载数据中"), o.refresh(n).finally(a.hideLoading)), 
        this.updateNearPorts(c).then(function(t) {
            return e.log("init", e.data.type, e.data.ports.map(function(t) {
                return t.id;
            }).join());
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.syncHierachy.dispose(), this.log(this.confirmed ? "confirm" : "cancel", this.data.type, this.data.ports.map(function(t) {
            return t.id;
        }).join());
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    remove: function(t) {
        this.removePort(t.currentTarget.dataset.port.id);
    },
    removePort: function(t, e) {
        var r = this, i = this.data.ports.findIndex(function(e) {
            return e.id === t;
        });
        if (i >= 0) {
            var a = this.data.ports.slice();
            a.splice(i, 1), this.setData({
                ports: a,
                options: this.getOptions(this.data.level, a)
            }), this.updateNearPorts(a).then(function(a) {
                return r.log(e || "remove", t, i);
            });
        }
    },
    confirm: function() {
        this.callback && this.callback(this.data.ports), this.confirmed = !0, wx.navigateBack();
    },
    getOptions: function(t, e) {
        var r, i = this, a = [], n = !1, o = this.data.maxCount && e.length >= this.data.maxCount;
        t && (t === this.data.root || (a.push([ {
            id: t,
            text: "全" + this.hierarchy[t].title,
            count: this.hierarchy[t].count,
            allArea: !0,
            disabled: o,
            reachMax: o
        } ]), n = !!e.find(function(e) {
            return e.id === t;
        })), (this.hierarchy[t].children || []).forEach(function(t) {
            return a.push(t.map(function(t) {
                return {
                    id: t,
                    text: i.hierarchy[t].title,
                    count: i.hierarchy[t].count,
                    isSubArea: !!i.hierarchy[t].children,
                    disabled: n || o,
                    isWholeAreaSelected: n,
                    reachMax: o
                };
            }));
        }));
        var h = 0, c = (r = []).concat.apply(r, a);
        return c.forEach(function(t) {
            t.selected = !!e.find(function(e) {
                return e.id === t.id;
            }), t.selected && h++, t.disabled = t.disabled && !t.selected;
        }), c.forEach(function(t) {
            (t.allArea && h > 0 || t.isSubArea && i.areaContainPorts(t.id, e)) && (t.disabled = !1);
        }), a.forEach(function(t) {
            return t.hash = s.hash(JSON.stringify(t));
        }), a;
    },
    areaContainPorts: function(i, a) {
        var n, o, s = (n = []).concat.apply(n, r(this.hierarchy[i].children || [])), h = e(s);
        try {
            var c = function() {
                var t = o.value;
                if (a.find(function(e) {
                    return e.id === t.id;
                })) return {
                    v: !0
                };
            };
            for (h.s(); !(o = h.n()).done; ) {
                var l = c();
                if ("object" === t(l)) return l.v;
            }
        } catch (t) {
            h.e(t);
        } finally {
            h.f();
        }
        return !1;
    },
    backToRoot: function() {
        this.setData({
            level: this.data.root,
            options: this.getOptions(this.data.root, this.data.ports)
        });
    },
    select: function(t) {
        var e = t.currentTarget.dataset.option;
        e.disabled ? a.alert(e.isWholeAreaSelected ? "您已经选择了全省所有城市，请先取消选择全省，再选择城市" : "您最多可以选择".concat(this.data.maxCount, "个港口")) : (e.allArea ? null : this.hierarchy[e.id].children) ? this.setData({
            level: e.id,
            options: this.getOptions(e.id, this.data.ports)
        }) : this.selectOption(e);
    },
    clearSelection: function() {
        var t = this;
        this.setData({
            ports: [],
            options: this.getOptions(this.data.level, [])
        }), this.updateNearPorts([]).then(function(e) {
            return t.log("clear");
        });
    },
    selectOption: function(t) {
        var e = this;
        if (this.data.ports.find(function(e) {
            return e.id === t.id;
        })) this.removePort(t.id, "sel_remove"); else {
            var r = this.data.ports.slice(), i = this.data.level;
            t.allArea && (r.map(function(t) {
                return t.id;
            }).forEach(function(i) {
                if (e.isChild(t.id, i)) {
                    var a = r.findIndex(function(t) {
                        return t.id === i;
                    });
                    a >= 0 && r.splice(a, 1);
                }
            }), i = this.data.root), r.push({
                id: t.id,
                title: this.hierarchy[t.id].title
            }), this.setData({
                ports: r,
                level: i,
                options: this.getOptions(i, r)
            }), this.updateNearPorts(r).then(function(r) {
                return e.log("sel_add", t.id);
            });
        }
    },
    isChild: function(t, i) {
        var a = this.hierarchy[t].children;
        if (a) {
            var n, o, s = e((n = []).concat.apply(n, r(a)));
            try {
                for (s.s(); !(o = s.n()).done; ) {
                    var h = o.value;
                    if (h === i || this.isChild(h, i)) return !0;
                }
            } catch (t) {
                s.e(t);
            } finally {
                s.f();
            }
        }
        return !1;
    },
    manualInput: function() {
        var t = i.register(this.manualPortChange.bind(this)), e = "?callback=".concat(t, "&type=").concat(this.data.manual, "&required=1&allowArea=1");
        wx.navigateTo({
            url: "/pages/single-port-selector/singlePortSelector".concat(e)
        });
    },
    manualPortChange: function(t, e, r) {
        var i = this;
        if (t && !this.data.ports.find(function(e) {
            return e.id === t.id;
        })) {
            var a = this.data.ports.concat(t);
            this.setData({
                ports: a,
                options: this.getOptions(this.data.level, a)
            }), this.updateNearPorts(a).then(function(a) {
                return i.log(e || "manual_add", t.id, r);
            });
        }
    },
    addNearPort: function(t) {
        var e = t.currentTarget.dataset.port, r = this.data.nearPorts.findIndex(function(t) {
            return t.id === e.id;
        });
        this.manualPortChange(e, "near_add", r);
    },
    updateNearPorts: function(t) {
        var e = this;
        t || (t = this.data.ports);
        var r = t.map(function(t) {
            return t.id;
        }), i = JSON.stringify(r);
        return this.savePorts = i, r.length > 0 ? n.mercury.post("search/nearPorts", {
            ports: r
        }).then(function(t) {
            return i === e.savePorts && e.setData({
                nearPorts: t.map(function(t) {
                    return {
                        id: t,
                        title: t
                    };
                })
            }), e.data.nearPorts;
        }).catch(function(t) {}) : (this.setData({
            nearPorts: []
        }), Promise.resolve([]));
    },
    log: function(t, e, r) {
        t = "ports_sel." + t;
        var i = {
            type: this.data.type,
            ports: this.data.ports.map(function(t) {
                return t.id;
            }),
            nearPorts: this.data.nearPorts.map(function(t) {
                return t.id;
            })
        };
        n.mercury.post("search/portsSelLog", {
            action: t,
            target: e,
            result: r,
            note: i
        });
    }
});