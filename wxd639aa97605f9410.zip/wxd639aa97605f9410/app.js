Promise.prototype.finally = function(t) {
    var n = this.constructor;
    return this.then(function(e) {
        return n.resolve(t()).then(function() {
            return e;
        });
    }, function(e) {
        return n.resolve(t()).then(function() {
            throw e;
        });
    });
};

var t = require("./utils/env"), n = require("./utils/ajax"), e = require("./utils/user"), i = require("./utils/util"), o = require("./utils/observable"), a = require("./dao/location"), r = Page;

Page = function(e) {
    var o = e.onLoad;
    e.onLoad = function() {
        if ("production" !== t.name() && wx.setNavigationBarTitle({
            title: t.title()
        }), n.getToken()) {
            var e = i.getCurrentPageName(), a = arguments[0] && JSON.stringify(arguments[0]);
            n.mercury.post("mapps/page", {
                url: "/" + e,
                logParam: a
            });
        }
        o.apply(this, arguments);
    }, r(e);
}, App({
    onLaunch: function() {
        this.lastResumeTime = 0, this.globalData.systemInfo = wx.getSystemInfoSync(), n.setSystemInfo(this.globalData.systemInfo), 
        this.login();
    },
    onShow: function(t) {
        a.upload(), this.globalData.loginEvent.get() && this.globalData.resumeEvent.get() && e.refresh();
        var i = new Date().getTime();
        i - this.lastResumeTime > 3e3 && (this.lastResumeTime = i, this.globalData.resumeEvent.set(this.globalData.resumeEvent.get() + 1), 
        n.mercury.post("miniProgram/onShow", {
            options: t
        }));
    },
    onHide: function() {
        this.globalData.pauseEvent.set(this.globalData.pauseEvent.get() + 1);
    },
    login: function() {
        var t = this;
        wx.login({
            success: function(n) {
                t.globalData.loginCode = n.code, t.chb2Login();
            },
            fail: function() {
                return t.onLoginFail();
            }
        });
    },
    onLoginFail: function() {
        var t = this;
        return i.alert("请检查网络状态，稍后再试", {
            title: "微信小程序登录失败"
        }).then(function() {
            return t.login();
        });
    },
    chb2Login: function() {
        var e = this;
        return this.globalData.loginCode ? n.mercury.get("miniProgram/login", {
            code: this.globalData.loginCode,
            env: t.name()
        }).then(function(t) {
            return e.onChb2LoginSucc(t);
        }).catch(function(t) {
            403 === t.statusCode && t.data && t.data.message ? i.alert(t.data.message).then(function() {
                return e.chb2Login();
            }) : e.onChb2LoginFail();
        }) : (this.onLoginFail(), Promise.resolve());
    },
    onChb2LoginSucc: function(i) {
        var o = this;
        if (i.env) return t.setEnv(i.env), this.chb2Login();
        i.userData && i.userData.openid ? (this.globalData.userData = i.userData, n.setToken(i.token), 
        n.setAid(i.userData.openid), i.token ? e.refresh().then(function() {
            return o.onAllLogin();
        }).catch(function() {
            return o.onChb2LoginFail();
        }) : this.onAllLogin()) : this.onChb2LoginFail();
    },
    onChb2LoginFail: function() {
        var t = this;
        i.alert("请检查网络状态，稍后再试", {
            title: "获取用户信息失败"
        }).then(function() {
            return t.login();
        });
    },
    onAllLogin: function() {
        this.globalData.loginEvent.set(this.globalData.loginEvent.get() + 1);
    },
    globalData: {
        loginEvent: new o(0),
        resumeEvent: new o(0),
        pauseEvent: new o(0),
        userData: null,
        backingHome: !0,
        cheatMobile: null,
        cheatMobileEvent: new o(0)
    }
});