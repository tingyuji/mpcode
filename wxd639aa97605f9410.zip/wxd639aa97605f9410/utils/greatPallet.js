var e = require("./ajax"), t = require("./user"), r = require("./util"), a = require("./globalMap"), i = require("../dao/enterprise"), n = require("../modules/moment"), o = require("../dao/pallet"), u = require("../dao/cash");

function c(e, t, r, i) {
    var n = a.register(r), o = a.register(i);
    wx.navigateTo({
        url: "/pages/great-pallet/upgrade/upgrade?source=".concat(e, "&isNewUser=").concat(!!t, "&pallet=").concat(n, "&callback=").concat(o)
    });
}

function l(t, r, a, i) {
    t && e.mercury.post("greatPallet/upgrade", {
        id: t.id
    }).then(function() {
        a && a.showResult(g(t), function() {
            r && wx.navigateBack(), i && i();
        });
    }).catch(function(t) {
        return e.showError("升级优质实货", t);
    });
}

function g(e) {
    var r = e.cargo || "";
    /^\d+[\-~]?\d*$/.test(r) && (r += "吨");
    var a = "";
    e.anyWeight || (a = 0 === e.minWeight ? "需" + e.maxWeight + "吨以下的船" : 2147483647 === e.maxWeight || null === e.maxWeight ? "需" + e.minWeight + "吨以上的船" : e.minWeight === e.maxWeight ? "需" + e.minWeight + "吨船" : "需" + e.minWeight + "~" + e.maxWeight + "吨船");
    var o = {
        company: !!("approved" === t.companyAuth.get() || i.get() && i.get().store),
        certified: !!t.idCardCertified.get()
    }, u = "";
    u = e.longTerm ? "长期货" : e.loadOnArrived ? "船到就装" : "".concat(n(e.date).format("M月D日"), "装");
    var c = "", l = n(), g = n(e.updateTime);
    if (g.format("YYYY-MM-DD") >= l.format("YYYY-MM-DD")) {
        var s = l.diff(g, "seconds");
        c = s < 60 ? "刚刚" : s < 3600 ? Math.floor(s / 60).toFixed(0) + "分钟前" : Math.floor(s / 3600).toFixed(0) + "小时前";
    } else l.subtract(1, "days"), c = g.format("YYYY-MM-DD") >= l.format("YYYY-MM-DD") ? "昨天" + g.format("HH:mm") : g.format("M月D日");
    return c = c ? c + "发布" : "", Object.assign({}, e, {
        cargo: r,
        weightDesc: a,
        tags: o,
        load: u,
        show: c
    });
}

module.exports = {
    upgrade: function(t, a, i, n) {
        return e.mercury.post("greatPallet/log", {
            action: "upgrade-click",
            target: t,
            result: a
        }), r.showLoading("获取数据中"), Promise.all([ o.pallets.refresh(), u.refresh() ]).then(function() {
            return e.mercury.get("greatPallet/isNewUser");
        }).finally(r.hideLoading).then(function(g) {
            if (t) {
                var s = function(e) {
                    return o.pallets.get().find(function(t) {
                        return t.id === e;
                    });
                }, d = s(t);
                (d ? Promise.resolve() : e.mercury.post("greatPallet/linkId", {
                    id: t,
                    ids: o.pallets.get().map(function(e) {
                        return e.id;
                    })
                }).then(function(e) {
                    return d = s(e);
                })).then(function() {
                    d && !d.great && 0 === d.status ? u.get() >= 2 ? r.confirm("优质实货需承诺与船主签合同打定金，卸货前付清运费。是否承诺并升级？", {
                        confirmText: "是",
                        cancelText: "否"
                    }).then(function() {
                        l(d, !1, n, i);
                    }) : c(a, g, d, i) : r.alert("没有找到可以升级的货源数据");
                });
            } else c(a, g, null, i);
        }).catch(function(t) {
            return e.showError("获取数据", t);
        });
    },
    upgradePallet: l,
    getPalletDemo: g
};