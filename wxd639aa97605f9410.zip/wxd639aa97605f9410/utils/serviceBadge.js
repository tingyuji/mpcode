var e = new (require("./observable"))(0), n = [], t = 0, i = 0;

function r() {
    var r = new Set(n);
    t > 0 && r.add("friendCircle"), i > 0 && r.add("recentContact");
    var c = r.size;
    t > 0 && (c += t - 1), i > 0 && (c += i - 1), function(n) {
        e.set(n);
    }(c);
}

module.exports = {
    setFriend: function(e) {
        t = e, r();
    },
    setServices: function(e) {
        n = (e || []).slice(), r();
    },
    setRecentCount: function(e) {
        i = e, r();
    }
};