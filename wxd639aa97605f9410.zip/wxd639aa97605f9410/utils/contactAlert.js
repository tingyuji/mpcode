module.exports = {
    zhaohuo: [ {
        classes: "text-left color-dimgray",
        text: "该货源信息的真实有效性由发布人负责，建议您向货主核对货源信息及对方身份，交易前签订正规合同。船货不二不为发布人承担任何法律责任。"
    }, {
        classes: "text-left color-orange",
        text: "注意："
    }, {
        classes: "text-left color-orange",
        text: "1. 如需空放请要求对方支付订金，收到订金前请不要开船！"
    }, {
        classes: "text-left color-orange",
        text: "2. 请与货主签合同明确卸前付清运费！"
    } ],
    zhaochuan: [ {
        classes: "text-left color-dimgray",
        text: "该空船信息的真实有效性由发布人负责，建议您向船主核对空船信息及对方身份，交易前签订正规合同。船货不二不为发布人承担任何法律责任。"
    }, {
        classes: "text-left color-orange",
        text: "注意："
    }, {
        classes: "text-left color-orange",
        text: "如需向船主支付订金，请务必事先核实船主身份和船舶概况，避免财产损失"
    }, {
        classes: "text-left color-orange",
        text: "*建议可通过微信视频核实"
    } ]
};