var e = 1, r = {};

function t(e) {
    return r[e];
}

module.exports = {
    register: function(t) {
        var n = e++;
        return r[n] = t, n;
    },
    unRegister: function(e) {
        var n = t(e);
        return delete r[e], n;
    },
    get: t
};