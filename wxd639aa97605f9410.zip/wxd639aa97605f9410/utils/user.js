var e = require("../@babel/runtime/helpers/typeof"), n = require("./observable"), r = require("./ajax"), t = {
    id: new n(0),
    name: new n(null),
    avatar: new n(null),
    score: new n(0),
    voucher: new n(0),
    showVoucher: new n(!1),
    reputation: new n({}),
    mobile: new n(null),
    organization: new n(null),
    gender: new n(null),
    certified: new n(!1),
    certifiedShip: new n(!1),
    certifying: new n(!1),
    idCard: new n(null),
    idCardCertified: new n(!1),
    companyAuth: new n("init"),
    companyAuthName: new n(null),
    vipBadge: new n(!1),
    wxUser: new n(null),
    isStarUser: new n(!1),
    refreshCompanyAuth: function() {
        return r.mercury.get("certifications/company").then(function(e) {
            return t.companyAuthName.set("approved" === e.status ? e.name : null), t.companyAuth.set(e && e.status || "init"), 
            e;
        });
    },
    refreshWxUser: function() {
        return r.getToken() ? r.mercury.get("account/wxUser").then(function(e) {
            return t.wxUser.set(e || null);
        }) : Promise.resolve(null);
    },
    refresh: function() {
        return r.getToken() ? r.mercury.get("account/my-profile?errorInResult=1").then(function(n) {
            if ("object" === e(n) && n && !n.errorCode) return i(n), n;
            if (!n || 404 !== n.errorCode && 401 !== n.errorCode && 403 !== n.errorCode) throw new Error();
            return u(), wx.reLaunch({
                url: "/pages/index/index?tab=settings"
            }), null;
        }).catch(function(e) {
            if (404 === e.statusCode || 401 === e.statusCode || 403 === e.statusCode) return i(null), 
            wx.reLaunch({
                url: "/pages/index/index?tab=settings"
            }), null;
            throw e;
        }) : (i(null), Promise.resolve(null));
    },
    reset: u,
    unlockingAccount: !1
};

function i(e) {
    var n = e && e.id || 0, r = t.id.get() !== n;
    t.id.setSilence(n), t.name.set(e && e.name || null), t.avatar.set(e && e.avatar || null), 
    t.score.set(e && e.score || 0), t.voucher.set(e && e.voucher || 0), t.showVoucher.set(e && e.showVoucher || !1), 
    t.gender.set(e && e.gender || null), t.organization.set(e && e.organization || null), 
    t.mobile.set(e && e.mobiles[0] || null), t.certifying.set(e && e.certifying || 0), 
    t.certified.set(e && e.certified || 0), t.certifiedShip.set(e && e.certifiedShip || 0), 
    t.reputation.set(e && e.reputation || {}), t.idCard.set(e && e.idcard || null), 
    t.idCardCertified.set(e && e.idcardCertified || !1), t.companyAuthName.set(e && e.companyAuthName || null), 
    t.companyAuth.set(e && e.companyAuth || "init"), t.isStarUser.set(e && e.isStarUser || !1), 
    t.wxUser.set(e && e.wxUser || null), t.vipBadge.set(e && e.id > 0 && !e.isPalletVip && !e.isShipVip && !e.isStarUser), 
    r && t.id.valueHasMutated();
}

function u() {
    r.setToken(null), i(null);
}

module.exports = t, r.setMercuryErrorHandler(function(e) {
    e && 401 === e.statusCode && t.id.get() > 0 && (u(), t.unlockingAccount || wx.reLaunch({
        url: "/pages/index/index?tab=settings"
    }));
});