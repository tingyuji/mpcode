var t = require("../@babel/runtime/helpers/typeof"), n = require("./env"), e = require("./wxHelper"), r = {
    name: "miniprogram"
}, o = {};

function u(t) {
    wx.request(Object.assign({}, t, {
        header: Object.assign({}, o, t.header)
    }, l(t)));
}

function a(t, n, e) {
    u(Object.assign({}, e, d("GET", t, n, !1)));
}

function c(t, n, e) {
    u(Object.assign({}, e, d("POST", t, n, !0)));
}

function s(t, n, e) {
    u(Object.assign({}, e, d("PUT", t, n, !0)));
}

function i(t, n, e) {
    u(Object.assign({}, e, d("DELETE", t, n, !1)));
}

function f(t, n, e, r, u, a) {
    var c = Object.assign({
        url: t,
        filePath: n,
        name: "file",
        formData: r || null
    }, u, l(u, !0));
    c.header = Object.assign({}, o, u.header, e ? {
        "content-type": e
    } : {});
    var s = wx.uploadFile(c);
    a && (a.onProgress && s.onProgressUpdate(a.onProgress), a.abort = s.abort);
}

function d(t, n, e, r) {
    var o = {
        method: t,
        url: n,
        data: e,
        header: {}
    };
    return e && r && (o.header["content-type"] = "application/json"), o;
}

function l(t, n) {
    return {
        success: function(e) {
            200 === e.statusCode || 204 === e.statusCode ? t && t.success && t.success(204 === e.statusCode ? void 0 : n ? function(t) {
                try {
                    return JSON.parse(t);
                } catch (n) {
                    return t;
                }
            }(e.data) : e.data) : t && t.fail && t.fail(e);
        }
    };
}

function g(t) {
    t ? (o.Authentication = t, wx.setStorageSync("sc.auth", t)) : (delete o.Authentication, 
    wx.removeStorageSync("sc.auth"));
}

function m(n, e) {
    if (t(e.statusCode) !== t(void 0)) {
        if (e.data && "string" == typeof e.data) try {
            e.data = JSON.parse(e.data);
        } catch (t) {}
        return e.data && e.data._withMessage_ ? "".concat(n, "失败。").concat(e.data.message) : 429 === e.statusCode ? "".concat(n, "失败，请求过于频繁，请稍后重试。") : 413 === e.statusCode ? "".concat(n, "失败，文件大小超过限制，请上传5M以内的文件（如果是视频，长度约为10秒）。") : "".concat(n, "失败，服务器返回错误 (代码:").concat(e.statusCode, ")。");
    }
    return "".concat(n, "失败，请检查您的网络连接是否正常。");
}

function p(t, n, e) {
    t = t || function(t) {
        return t;
    };
    var r = {
        request: function(n) {
            return u(Object.assign({}, n, {
                url: t(n.url)
            }));
        },
        get: function(n, e, r) {
            return a(t(n), e, r);
        },
        post: function(n, e, r) {
            return c(t(n), e, r);
        },
        put: function(n, e, r) {
            return s(t(n), e, r);
        },
        del: function(n, e, r) {
            return i(t(n), e, r);
        },
        upload: function(n, e, r, o, u, a) {
            return f(t(n), e, r, o, u, a);
        }
    }, o = function(t, n, r) {
        var o = n, u = r;
        return e && (u = function(t) {
            e(t), r(t);
        }), Object.assign({}, t, {
            success: o,
            fail: u
        });
    };
    return n ? {
        request: function(t) {
            return new Promise(function(n, e) {
                return r.request(o(t, n, e));
            });
        },
        get: function(t, n, e) {
            return new Promise(function(u, a) {
                return r.get(t, n, o(e, u, a));
            });
        },
        post: function(t, n, e) {
            return new Promise(function(u, a) {
                return r.post(t, n, o(e, u, a));
            });
        },
        put: function(t, n, e) {
            return new Promise(function(u, a) {
                return r.put(t, n, o(e, u, a));
            });
        },
        del: function(t, n, e) {
            return new Promise(function(u, a) {
                return r.del(t, n, o(e, u, a));
            });
        },
        upload: function(t, n, e, u, a, c) {
            return new Promise(function(s, i) {
                return r.upload(t, n, e, u, o(a, s, i), c);
            });
        }
    } : r;
}

!function() {
    var t = wx.getStorageSync("sc.auth") || null;
    t && g(t);
    var n = wx.getStorageSync("anonid") || null;
    n && (o["chb2-anonid"] = n);
}();

var h = null;

module.exports = {
    request: u,
    get: a,
    post: c,
    put: s,
    del: i,
    upload: f,
    setToken: g,
    setAid: function(t) {
        t ? o["chb2-anonid"] = t : delete o["chb2-anonid"], wx.setStorage({
            key: "anonid",
            value: t || ""
        });
    },
    setSystemInfo: function(t) {
        Object.assign(r, {
            version: n.version(),
            mode: n.name(),
            platform: t.platform,
            "platform-version": t.system,
            "platform-model": t.model,
            "platform-manufacturer": t.brand,
            "sdk-version": t.SDKVersion,
            "wechat-version": t.version
        }), o["chb2-agent"] = Object.getOwnPropertyNames(r).map(function(t) {
            return "".concat(t, ":").concat(r[t]);
        }).join(";");
    },
    setEnterprise: function(t) {
        t ? o["chb2-enterprise"] = t.toString() : delete o["chb2-enterprise"];
    },
    getToken: function() {
        return o.Authentication;
    },
    getAgent: function() {
        return r;
    },
    showError: function(t, n) {
        return console.error(n), e.alert(m(t, n));
    },
    getAjaxErrorMessage: m,
    getCommands: p,
    mercury: p(n.mercury, !0, function(t) {
        h && h(t);
    }),
    moon: p(n.moon, !0),
    raw: p(null, !0),
    setMercuryErrorHandler: function(t) {
        h = t;
    }
};