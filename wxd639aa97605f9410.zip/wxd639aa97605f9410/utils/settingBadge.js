var e = require("./user"), r = require("./observable"), i = require("../dao/redPacket"), t = require("../dao/vessel"), a = new r(0);

var s = [];

function d() {
    var r = new Set(s);
    e.vipBadge.get() && r.add("vip");
    var d = i.get() && i.get().unseen || 0;
    d > 0 && r.add("redPacket");
    var c = r.size;
    d > 0 && (c += d - 1);
    var n = t.get();
    n && "pending" !== n.candidateState && ("rejected" === n.state || n.certificationExpired) && c++, 
    function(e) {
        a.set(e);
    }(c);
}

e.vipBadge.subscribe(d), i.subscribe(d), t.subscribe(d), module.exports = {
    setServices: function(e) {
        s = (e || []).slice(), d();
    },
    badge: a
};