var e = require("../@babel/runtime/helpers/toConsumableArray"), t = require("../@babel/runtime/helpers/createForOfIteratorHelper"), a = require("./ajax"), n = require("./user"), r = require("./wxHelper"), o = require("./globalMap"), i = require("../modules/moment.js");

function c() {
    var e = getCurrentPages();
    return e[e.length - 1].route;
}

function u() {
    var e = c().replace(/^pages\//, "").split(/[\/\\]/), t = e.slice(0, e.length - 1).join("/"), a = n.id.get() ? "&user=".concat(n.id.get()) : "", r = "&ts=".concat(new Date().getTime());
    return "share=".concat(encodeURIComponent(t)).concat(a).concat(r);
}

function s(e, t) {
    return f("navigate", e, t);
}

function l(e) {
    return [ "zhaochuan", "zhaohuo", "contact", "services", "settings" ].indexOf(e) >= 0 ? "/pages/".concat(e, "/").concat(e) : null;
}

function f(e, t, a) {
    var n = t;
    if (a) {
        var r = Object.getOwnPropertyNames(a).map(function(e) {
            return "".concat(e, "=").concat(a[e]);
        });
        r.length > 0 && (n += "?".concat(r.join("&")));
    }
    return "/pages/index/index?".concat(e, "=").concat(encodeURIComponent(n), "&").concat(u());
}

module.exports = {
    browse: function(e, t, n) {
        t && a.mercury.post("mapps/log", {
            action: t,
            memo: {
                url: e
            }
        });
        var r = n ? "&callback=".concat(o.register(n)) : "";
        wx.navigateTo({
            url: "/pages/web-view/webView?url=".concat(encodeURIComponent(e)).concat(r)
        });
    },
    getDateText: function(e) {
        var t = i(), a = t.format("YYYYMMDD");
        t.add(1, "days");
        var n = t.format("YYYYMMDD"), r = i(e).format("YYYYMMDD");
        return r === a ? "今天" : r === n ? "明天" : r.slice(-2) + "日";
    },
    getDateFullText: function(e) {
        var t = i(), a = t.format("YYYYMMDD");
        t.add(1, "days");
        var n = t.format("YYYYMMDD"), r = i(e).format("YYYYMMDD");
        return r === a ? "今天" : r === n ? "明天" : i(e).format("M月D日");
    },
    getTimeText: function(e) {
        var t = e ? i().diff(i(e), "minute") : 0;
        if (t < 1) return "刚刚";
        var a = i().startOf("day").diff(i(e).startOf("day"), "day");
        if (a > 0) return 1 === a ? "昨天" : 2 === a ? "前天" : "".concat(a, "天前");
        var n = Math.floor(t / 60);
        return n < 1 ? "".concat(t, "分钟前") : "".concat(n, "小时前");
    },
    authPalletCreateModal: function() {
        wx.showModal({
            title: "温馨提示",
            content: "您的电话号码未被列入互联网诚信名单，根据工信部对网络安全建设的要求，您不能在公共平台发布信息。为保障您的正常使用，请进行实名认证或取得公司授权",
            success: function(e) {
                e.confirm ? wx.navigateTo({
                    url: "/pages/settings/certify-mobile/certifyMobile"
                }) : e.cancel && wx.navigateTo({
                    url: "/pages/settings/company-auth/companyAuth"
                });
            },
            confirmText: "实名认证",
            cancelText: "公司授权",
            cancelColor: "#3CC51F"
        });
    },
    authShipCreateModal: function(e) {
        e = e || "发布空船", r.alert("为了维护真实诚信的交易环境，只有认证船主才能".concat(e, "。请上传船舶适航证书进行认证。"), {
            confirmText: "去认证"
        }).then(function() {
            return wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel"
            });
        });
    },
    isNil: function(e) {
        return null == e;
    },
    getCurrentPageName: c,
    shareTitle: "寻船找货的不二选择",
    shareParam: u,
    sharePath: function(e) {
        return s("/" + c(), e);
    },
    shareToPath: s,
    shareTabPath: function(e, t) {
        return f("launch", l(e), t);
    },
    getTabPage: l,
    checkUserLogin: function(e) {
        n.id.get() || (e.isBindMobileBack = !0, wx.navigateTo({
            url: "/pages/bind-mobile/bindMobile"
        }));
    },
    checkUserShow: function(e) {
        var t = !e.notFirstShow;
        e.notFirstShow = !0, !e.isBindMobileBack || n.id.get() || t || (this.isBindMobileBack = !1, 
        wx.reLaunch({
            url: "/pages/index/index"
        }));
    },
    alert: r.alert,
    confirm: r.confirm,
    showLoading: r.showLoading,
    hideLoading: r.hideLoading,
    refactorRelation: function(a) {
        var n, r = new Map(), o = t(a);
        try {
            for (o.s(); !(n = o.n()).done; ) {
                var i = n.value, c = i.pinyin.charAt(0).toUpperCase(), u = r.get(c);
                u || (u = {
                    letter: c,
                    relations: []
                }, r.set(c, u)), u.relations.push(i);
            }
        } catch (e) {
            o.e(e);
        } finally {
            o.f();
        }
        var s = e(r.values());
        return s.sort(function(e, t) {
            return e.letter.localeCompare(t.letter);
        }), s;
    },
    isIOS: function() {
        return getApp().globalData.systemInfo.system.indexOf("iOS") >= 0;
    },
    dial400: function() {
        return wx.makePhoneCall({
            phoneNumber: "4008030092"
        }).catch(function() {});
    },
    formatRelativeDate: function(e) {
        if (!e) return "";
        var t = i(e).startOf("day").diff(i().startOf("day"), "day");
        return 0 === t ? "今天" : 1 === t ? "明天" : 2 === t ? "后天" : -1 === t ? "昨天" : t > 0 ? t + "天后" : -t + "天前";
    },
    jumpToSandstoneMiniProgram: function(e) {
        a.mercury.post("mapps/log", {
            action: "jump_to_sandstone_miniprogram",
            target: e
        }), wx.navigateToMiniProgram({
            appId: "wxe9bc3b94418de83a",
            extraData: {
                from: "chb2-miniprogram"
            }
        });
    }
}, Object.assign(module.exports, r);