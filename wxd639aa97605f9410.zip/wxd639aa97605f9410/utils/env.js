var t = require("../@babel/runtime/helpers/typeof"), e = "production", n = {
    testing: {
        name: "testing",
        title: "船货不二(测试版)",
        server: "https://test.chb2.cn"
    },
    production: {
        name: "production",
        title: "船货不二",
        server: "https://www.chb2.com"
    }
}, r = n[t(e) === t(void 0) ? "testing" : e];

module.exports = {
    setEnv: function(t) {
        return r = n[t || "testing"];
    },
    title: function() {
        return r.title;
    },
    name: function() {
        return r.name;
    },
    version: function() {
        return "1.90.36";
    },
    mercury: function(t) {
        return "".concat(r.server, "/mercury/api/").concat(t);
    },
    moon: function(t) {
        return "".concat(r.server, "/moon/api/").concat(t);
    },
    resource: function(t) {
        return "".concat(r.server, "/m/files/").concat(t);
    }
};