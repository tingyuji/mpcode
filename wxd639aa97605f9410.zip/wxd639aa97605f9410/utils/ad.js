module.exports.getContents = function(t, c) {
    var n = [], e = (t = (t || "").replace(/(\D|\b)(1[3-9]\d{9}|4008030092|400-803-0092)(\D|\b)/g, function(t, c, n, e) {
        return "".concat(c || "", "@chb2@").concat(n, "#chb2#").concat(e || "");
    })).match(/@chb2@([\d\-]+)#chb2#/g);
    if (e) {
        for (var r = t.replace(/@chb2@([\d\-]+)#chb2#/g, "@chb2@").split("@chb2@"), o = 0, h = 0; h < e.length; h++) n.push({
            cursor: o,
            type: "string",
            content: r[h]
        }), o++, n.push({
            cursor: o,
            type: "mobile",
            content: e[h].match(/@chb2@([\d\-]+)#chb2#/)[1]
        }), o++;
        n.push({
            cursor: o,
            type: "string",
            content: r[r.length - 1]
        });
    } else n.push({
        cursor: 0,
        type: "string",
        content: t
    });
    return c && n.forEach(function(t) {
        return t.content = (t.content || "").replace(/ /g, "&nbsp;");
    }), n;
};