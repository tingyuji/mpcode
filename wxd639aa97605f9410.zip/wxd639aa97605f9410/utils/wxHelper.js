module.exports = {
    alert: function(n, i) {
        return new Promise(function(o, t) {
            wx.showModal(Object.assign({
                title: "温馨提示",
                content: n
            }, i, {
                showCancel: !1,
                success: o,
                fail: t
            }));
        });
    },
    confirm: function(n, i) {
        return new Promise(function(o, t) {
            wx.showModal(Object.assign({
                title: "温馨提示",
                content: n
            }, i, {
                success: function(n) {
                    n.confirm ? o() : t();
                },
                fail: t
            }));
        });
    },
    showLoading: function(n, i) {
        wx.showLoading(Object.assign({
            title: n,
            mask: !0
        }, i));
    },
    hideLoading: function(n) {
        wx.hideLoading(n);
    }
};