var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), s = function() {
    function s(t, i) {
        e(this, s), this.observer = t, this.callback = i;
    }
    return t(s, [ {
        key: "get",
        value: function() {
            return this.callback;
        }
    }, {
        key: "dispose",
        value: function() {
            this.observer.unsubscribe(this.callback);
        }
    } ]), s;
}(), i = function() {
    function i(t) {
        e(this, i), this.subscriptions = new Set(), this.value = t;
    }
    return t(i, [ {
        key: "get",
        value: function() {
            return this.value;
        }
    }, {
        key: "set",
        value: function(e) {
            var t = JSON.stringify(e) !== JSON.stringify(this.value);
            return this.value = e, t && this.valueHasMutated(), this.value;
        }
    }, {
        key: "setSilence",
        value: function(e) {
            return this.value = e, this.value;
        }
    }, {
        key: "valueHasMutated",
        value: function() {
            var e = this;
            this.subscriptions.forEach(function(t) {
                return t && t(e.value);
            });
        }
    }, {
        key: "subscribeAndFireOnce",
        value: function(e) {
            var t = this.subscribe(e);
            return e && e(this.get()), t;
        }
    }, {
        key: "subscribe",
        value: function(e) {
            return this.subscriptions.add(e), new s(this, e);
        }
    }, {
        key: "unsubscribe",
        value: function(e) {
            this.subscriptions.delete(e);
        }
    } ]), i;
}();

module.exports = i;