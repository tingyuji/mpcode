var e = require("../../utils/ajax"), t = require("../../utils/globalMap");

Component({
    properties: {
        pallet: {
            type: Object,
            value: null
        },
        guess: {
            type: Boolean,
            value: !1
        },
        similar: {
            type: Object,
            value: null
        },
        backCount: {
            type: Number,
            value: 0
        },
        source: {
            type: String,
            value: ""
        }
    },
    data: {
        seen: !1
    },
    methods: {
        seen: function() {
            var a = this.properties.pallet;
            if (!a.state.ordered && !a.state.pause) {
                a.tag.seen || this.data.seen || this.setData({
                    seen: !0
                }), this.data.guess ? e.mercury.post("search/guessLikeLog", {
                    action: "view_pallet_detail",
                    target: a.id,
                    distance: a.distance,
                    index: a.guessIndex
                }) : this.data.similar ? (this.data.backCount > 0 && (t.get(this.data.backCount).value = 0), 
                e.mercury.post("search/detailRecommendLog", {
                    action: "view_pallet_detail",
                    target: a.id,
                    index: this.data.similar.index || 0
                })) : e.mercury.post("search/searchLog", {
                    action: "view_pallet_detail",
                    target: a.id,
                    v1Compatible: !!a.oldSearch
                });
                var i = "/pages/pallet-detail/pallet-detail?id=".concat(a.id, "&origin=0&mark=").concat(a.tag.mark, "&showIndex=").concat(a.showIndex, "&originType=").concat(this.data.source);
                this.data.similar && (i += "&similar=".concat(t.register(this.data.similar))), this.data.backCount > 0 && (i += "&backCount=".concat(this.data.backCount)), 
                getCurrentPages().length < 9 ? wx.navigateTo({
                    url: i
                }) : wx.redirectTo({
                    url: i
                });
            }
        }
    }
});