var e = require("../../utils/ajax");

Component({
    properties: {
        ad: {
            type: Object,
            value: null
        },
        source: {
            type: String,
            value: "search"
        }
    },
    data: {},
    methods: {
        viewDetail: function() {
            e.mercury.post("ad/embeddedClick", {
                showId: this.data.ad.showId,
                type: this.data.ad.type,
                id: this.data.ad.id
            });
        }
    }
});