Component({
    properties: {
        title: {
            type: String,
            value: "安全警示"
        },
        text: {
            type: String,
            value: ""
        },
        cancelText: {
            type: String,
            value: ""
        },
        confirmText: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        doModal: function(t, a) {
            var e = this;
            return new Promise(function(n, o) {
                e.setData({
                    text: t,
                    confirmText: a,
                    confirmCallback: n,
                    cancelCallback: o,
                    countDown: 10,
                    countDownText: "(10秒)"
                }), e.show();
                var c = setInterval(function() {
                    var t = e.data.countDown - 1;
                    e.setData({
                        countDown: t,
                        countDownText: t > 0 ? "(".concat(t, "秒)") : "",
                        enable: t <= 0
                    }), t <= 0 && clearInterval(c);
                }, 1e3);
            });
        },
        show: function() {
            this.baseModal.showModal();
        },
        hide: function() {
            this.baseModal.hideModal();
        },
        _cancelModal: function() {
            this.hide(), this.triggerEvent("cancelEvent"), this.data.cancelCallback && this.data.cancelCallback();
        },
        _confirmModal: function() {
            this.hide(), this.triggerEvent("confirmEvent"), this.data.confirmCallback && this.data.confirmCallback();
        }
    },
    ready: function() {
        this.baseModal = this.selectComponent("#baseModal");
    }
});