Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        confirmText: {
            type: String,
            value: "确定"
        },
        backdrop: {
            type: Boolean,
            value: !1
        },
        animated: {
            type: Boolean,
            value: !0
        },
        modalSize: {
            type: String,
            value: "md"
        },
        top: {
            type: String,
            value: "50%"
        }
    },
    data: {},
    methods: {
        show: function() {
            this.baseModal.showModal();
        },
        hide: function() {
            this.baseModal.hideModal();
        },
        _cancelModal: function() {
            this.hide(), this.triggerEvent("cancelEvent");
        },
        _confirmModal: function() {
            this.triggerEvent("confirmEvent");
        }
    },
    ready: function() {
        this.baseModal = this.selectComponent("#baseModal");
    }
});