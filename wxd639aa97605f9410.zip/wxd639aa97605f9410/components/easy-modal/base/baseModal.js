Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        backdrop: {
            type: Boolean,
            value: !0
        },
        animated: {
            type: Boolean,
            value: !0
        },
        modalSize: {
            type: String,
            value: "md"
        },
        animationOption: {
            type: Object,
            value: {
                duration: 300
            }
        },
        top: {
            type: String,
            value: "50%"
        }
    },
    data: {
        isShow: !1,
        animation: ""
    },
    methods: {
        hideModal: function(t) {
            if (t && ("mask" === t.currentTarget.dataset.type && !this.data.backdrop)) return;
            this.data.isShow && this._toggleModal();
        },
        showModal: function() {
            this.data.isShow || this._toggleModal();
        },
        _toggleModal: function() {
            if (this.data.animated) {
                var t = !this.data.isShow;
                this._executeAnimation(t);
            } else this.setData({
                isShow: !this.data.isShow
            });
        },
        _executeAnimation: function(t) {
            var a = this.animation;
            t ? (a.opacity(0).step(), this.setData({
                animationData: a.export(),
                isShow: !0
            }), setTimeout(function() {
                a.opacity(1).step(), this.setData({
                    animationData: a.export()
                });
            }.bind(this), 50)) : (a.opacity(0).step(), this.setData({
                animationData: a.export()
            }), setTimeout(function() {
                this.setData({
                    isShow: t
                });
            }.bind(this), this.data.animationOption.duration));
        }
    },
    ready: function() {
        this.animation = wx.createAnimation({
            duration: this.data.animationOption.duration,
            timingFunction: "linear",
            delay: 0
        });
    }
});