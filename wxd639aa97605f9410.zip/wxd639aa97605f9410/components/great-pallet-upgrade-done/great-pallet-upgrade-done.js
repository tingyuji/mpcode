Component({
    properties: {},
    data: {
        pallet: {}
    },
    methods: {
        showResult: function(t, e) {
            this.callback = e, this.setData({
                pallet: t
            }), this.selectComponent("#easyModal").show();
        },
        clickConfirm: function() {
            this.selectComponent("#easyModal").hide(), this.callback && this.callback();
        }
    }
});