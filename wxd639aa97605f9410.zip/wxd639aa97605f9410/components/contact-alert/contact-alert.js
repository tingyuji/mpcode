Component({
    properties: {
        lines: {
            type: Array,
            value: []
        }
    },
    data: {},
    methods: {
        alert: function() {
            var t = this;
            return new Promise(function(a) {
                t.callback = a, t.alertModal.show();
            });
        },
        confirm: function() {
            this.alertModal.hide(), this.callback && this.callback();
        }
    },
    ready: function() {
        this.alertModal = this.selectComponent("#alertModal");
    }
});