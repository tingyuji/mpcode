var t = require("../../utils/globalMap");

Component({
    properties: {
        pattern: {
            type: String,
            value: "drop-down"
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        text: {
            type: String,
            value: "港口"
        },
        port: {
            type: Object,
            value: null
        },
        required: {
            type: Boolean,
            value: !1
        },
        type: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        select: function() {
            var t = this.data.type ? "&type=".concat(this.data.type) : "", e = this.data.required ? "&required=1" : "", a = "&port=" + (this.data.port ? this.data.port.id : "");
            wx.navigateTo({
                url: "/pages/single-port-selector/singlePortSelector?callback=".concat(this.callbackId).concat(t).concat(a).concat(e)
            });
        },
        setPort: function(t) {
            this.setData({
                text: t ? t.title : this.data.initText,
                port: t
            });
        },
        portChange: function(t) {
            this.setPort(t), this.triggerEvent("changeEvent", t);
        }
    },
    ready: function() {
        this.setData({
            initText: this.data.text,
            text: this.data.port ? this.data.port.title : this.data.text
        }), this.callbackId = t.register(this.portChange.bind(this));
    },
    detached: function() {
        this.callbackId && (t.unRegister(this.callbackId), this.callbackId = null);
    }
});