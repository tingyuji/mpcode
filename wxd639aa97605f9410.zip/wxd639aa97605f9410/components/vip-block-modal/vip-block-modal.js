Component({
    properties: {},
    data: {},
    methods: {
        modal: function(e, t, s) {
            var o = this;
            return this.setData({
                text: e,
                vipText: t,
                pubText: s
            }), this.baseModal.showModal(), new Promise(function(e) {
                return o.resolve = e;
            });
        },
        confirm: function(e) {
            this.baseModal.hideModal();
            var t = e.currentTarget.dataset.result;
            this.resolve && this.resolve(t);
        },
        cancel: function() {
            this.baseModal.hideModal(), this.resolve && this.resolve("cancel");
        }
    },
    ready: function() {
        this.baseModal = this.selectComponent("#baseModal");
    }
});