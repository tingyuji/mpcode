var t = require("../../utils/globalMap");

Component({
    properties: {
        pattern: {
            type: String,
            value: "drop-down"
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        text: {
            type: String,
            value: "货品"
        },
        cargo: {
            type: String,
            value: null
        },
        required: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        select: function() {
            var t = this.data.required ? "&required=1" : "", a = this.data.cargo ? "&cargo=".concat(this.data.cargo) : "";
            wx.navigateTo({
                url: "/pages/cargo-name-selector/cargoNameSelector?callback=".concat(this.callbackId).concat(a).concat(t)
            });
        },
        setCargo: function(t) {
            this.setData({
                text: t || this.data.initText,
                cargo: t
            });
        },
        cargoChange: function(t) {
            this.setCargo(t), this.triggerEvent("changeEvent", t);
        }
    },
    ready: function() {
        this.setData({
            initText: this.data.text,
            text: this.data.cargo || this.data.text
        }), this.callbackId = t.register(this.cargoChange.bind(this));
    },
    detached: function() {
        this.callbackId && (t.unRegister(this.callbackId), this.callbackId = null);
    }
});