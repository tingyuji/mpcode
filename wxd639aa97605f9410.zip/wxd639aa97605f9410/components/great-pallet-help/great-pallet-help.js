Component({
    properties: {
        source: {
            type: String,
            value: ""
        }
    },
    data: {
        index: 0
    },
    methods: {
        toggleExplain: function(t) {
            var a = +t.currentTarget.dataset.id || 0;
            this.data.index === a && (a = 0), this.setData({
                index: a
            });
        },
        toCash: function() {
            "cash" === this.data.source ? this.triggerEvent("cashEvent") : wx.navigateTo({
                url: "/pages/settings/cash/cash?source=".concat(this.data.source)
            });
        }
    }
});