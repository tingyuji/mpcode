require("../../modules/moment");

var e = require("../../utils/ajax");

Component({
    properties: {
        type: {
            type: String,
            value: ""
        },
        source: {
            type: String,
            value: ""
        },
        vessel: {
            type: Object,
            value: null
        }
    },
    data: {},
    methods: {
        seen: function() {
            "advert" === this.data.type ? e.mercury.post("ad/embeddedClick", {
                showId: this.data.vessel.showId,
                type: this.data.vessel.type,
                id: this.data.vessel.id
            }) : this.updateSeen(1);
        },
        updateSeen: function(e) {
            var t;
            t = e > 3 ? "以前看过" : 3 === e ? "前天看过" : 2 === e ? "昨天看过" : 1 === e ? "今天看过" : "", 
            this.setData({
                seenCount: e,
                seenText: t
            });
        }
    },
    attached: function() {
        var e = this.data.vessel || {}, t = "sell" === this.data.type ? "??" : "", s = e.length || t, a = e.width || t, i = e.depth || t, d = e.weight || t, l = e.buildYear || t, r = e.buildPlace || ("draft" === e.state ? t : ""), u = e.price || ("sell" === this.data.type ? "???" : ""), n = e.pricePerTon || "", h = "advert" === this.data.type ? "/pages/used-vessel/list/list?source=".concat(this.data.source) : "/pages/used-vessel/detail/detail?id=".concat(e.id, "&source=").concat(this.data.source);
        this.setData({
            length: s,
            width: a,
            depth: i,
            weight: d,
            buildYear: l,
            buildPlace: r,
            price: u,
            pricePerTon: n,
            url: h
        }), this.updateSeen(e.seen || 0);
    }
});