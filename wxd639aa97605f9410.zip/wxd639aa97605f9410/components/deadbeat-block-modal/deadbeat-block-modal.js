var e = require("../../utils/ajax"), t = require("../../utils/user"), r = require("../../utils/util");

Component({
    properties: {},
    data: {},
    methods: {
        check: function(a) {
            var i = this;
            return this.resolveCallback = null, t.id.get() ? e.mercury.get("deadbeat/check", {
                type: a
            }).then(function(e) {
                return !(e > 0) || new Promise(function(e) {
                    i.resolveCallback = function() {
                        return e(!1);
                    }, i.deadbeatModal.show();
                });
            }).catch(function(e) {
                return r.alert("网络通讯错误，请稍后再试").then(function() {
                    return !1;
                });
            }) : Promise.resolve(!0);
        },
        confirm: function() {
            this.deadbeatModal.hide(), this.resolveCallback && this.resolveCallback();
        },
        dial400: function() {
            r.dial400();
        }
    },
    ready: function() {
        this.deadbeatModal = this.selectComponent("#deadbeatModal");
    }
});