Component({
    properties: {
        relation: Object
    },
    data: {},
    methods: {
        detail: function(t) {
            var e = t.currentTarget.dataset.relation;
            getApp().globalData.currentRelation = e, wx.navigateTo({
                url: "/pages/friend-circle/relation/relation"
            });
        }
    }
});