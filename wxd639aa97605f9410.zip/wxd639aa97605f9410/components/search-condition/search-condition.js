var t = require("../../utils/user"), e = require("../../utils/util"), a = require("../../utils/ajax"), i = require("../../dao/searchShortcuts");

Component({
    properties: {
        type: {
            type: String,
            value: "ship"
        }
    },
    data: {
        userId: 0,
        inited: !1,
        startPorts: [],
        targetPorts: [],
        minWeight: null,
        maxWeight: null,
        type: "ship",
        Type: "Ship",
        targetType: "空船",
        startTitle: "请选择",
        targetTitle: "请选择",
        startPlaceholder: "",
        targetPlaceholder: "",
        shortcuts: [],
        currentIdx: 0,
        saveShortcutError: !1,
        animating: !1,
        animation: null,
        aniStartText: "",
        aniTargetText: "",
        aniWeightsText: "",
        aniLeft: 0,
        aniTop: 0,
        aniWidth: 320,
        aniHeight: 100,
        aniScaleY: 1
    },
    methods: {
        init: function(t, e, a, i) {
            this.setData({
                inited: !0,
                startPorts: t || [],
                targetPorts: e || [],
                minWeight: a || null,
                maxWeight: i || null,
                Type: "ship" === this.data.type ? "Ship" : "Pallet"
            }), this.updateCurrentIdx();
        },
        updateCurrentIdx: function() {
            var t = this, e = 0;
            this.data.shortcuts.forEach(function(a) {
                e || a.unset || a.startPorts.map(function(t) {
                    return t.id;
                }).join() !== t.data.startPorts.map(function(t) {
                    return t.id;
                }).join() || a.targetPorts.map(function(t) {
                    return t.id;
                }).join() !== t.data.targetPorts.map(function(t) {
                    return t.id;
                }).join() || a.minWeight !== t.data.minWeight || a.maxWeight !== t.data.maxWeight || (e = a.idx);
            }), this.setData({
                currentIdx: e
            });
        },
        startPortsChange: function(t) {
            this.setData({
                startPorts: t.detail || []
            });
        },
        targetPortsChange: function(t) {
            this.setData({
                targetPorts: t.detail || []
            });
        },
        weightsChange: function(t) {
            this.setData({
                minWeight: t.detail.minWeight || null,
                maxWeight: t.detail.maxWeight || null
            });
        },
        search: function() {
            this.triggerEvent("confirmEvent", {
                startPorts: this.data.startPorts,
                targetPorts: this.data.targetPorts,
                minWeight: this.data.minWeight,
                maxWeight: this.data.maxWeight
            });
        },
        confirm: function() {
            this.data.startPorts.length > 0 || this.data.targetPorts.length > 0 ? this.search() : e.alert("请输入装货港或卸货港后再点击搜索" + this.data.targetType, {
                confirmText: "知道了"
            });
        },
        save: function() {
            this.data.startPorts.length > 0 || this.data.targetPorts.length > 0 ? (this.setData({
                saveShortcutError: !1
            }), this.selectComponent("#saveShortcutModal").show()) : e.alert("请输入装货港或卸货港后再保存常用搜索条件", {
                confirmText: "知道了"
            });
        },
        clear: function() {
            this.setData({
                startPorts: [],
                targetPorts: [],
                minWeight: null,
                maxWeight: null
            }), this.selectComponent("#startPorts").setPorts([]), this.selectComponent("#targetPorts").setPorts([]), 
            this.selectComponent("#weights").setWeights(null, null);
        },
        shortcutSelChange: function(t) {
            var e = +t.detail.value || 0;
            this.setData({
                currentIdx: e,
                saveShortcutError: this.data.saveShortcutError && !e
            });
        },
        confirmSaveShortcut: function() {
            var t = this;
            this.data.currentIdx >= 1 && this.data.currentIdx <= 5 ? (this.selectComponent("#saveShortcutModal").hide(), 
            e.showLoading("保存数据中"), i[this.data.type].save({
                idx: this.data.currentIdx,
                start: this.data.startPorts,
                target: this.data.targetPorts,
                minWeight: this.data.minWeight,
                maxWeight: this.data.maxWeight
            }).finally(e.hideLoading).then(function() {
                e.confirm("是否用此条件搜索".concat(t.data.targetType, "？"), {
                    title: "保存成功",
                    confirmText: "搜索".concat(t.data.targetType),
                    cancelText: "暂不搜索"
                }).then(function() {
                    a.mercury.post("search/log".concat(t.data.Type, "Shortcut"), {
                        idx: t.data.currentIdx,
                        action: "search_shortcut"
                    }), t.search();
                });
            }).catch(function(t) {
                return a.showError("保存常用搜索条件", t);
            })) : this.setData({
                saveShortcutError: !0
            });
        },
        useShortcut: function(t) {
            var e = this, i = t.currentTarget.dataset.item;
            if (i && !i.unset) {
                var r = this.data.animating;
                r && this.setData({
                    animating: !1,
                    animation: null
                });
                var n = this.aniId = (this.aniId || 0) + 1;
                setTimeout(function() {
                    wx.createSelectorQuery().in(e).select("#searchValues").boundingClientRect().select("#shortcut".concat(i.idx)).boundingClientRect().selectViewport().scrollOffset().exec(function(t) {
                        e.setData({
                            aniLeft: t[1].left,
                            aniTop: t[1].top + t[2].scrollTop,
                            aniWidth: t[1].width,
                            aniHeight: t[0].height + 2,
                            aniStartText: i.startPorts.map(function(t) {
                                return t.title;
                            }).join(),
                            aniTargetText: i.targetPorts.map(function(t) {
                                return t.title;
                            }).join(),
                            aniWeightsText: i.minWeight && i.maxWeight ? "".concat(i.minWeight, "~").concat(i.maxWeight, "吨") : i.minWeight ? "".concat(i.minWeight, "吨以上") : i.maxWeight ? "".concat(i.maxWeight, "吨以下") : "",
                            aniScaleY: t[1].height / (t[0].height + 2),
                            animating: !0,
                            animation: null
                        }), setTimeout(function() {
                            var a = wx.createAnimation({
                                duration: 400,
                                timingFunction: "ease",
                                transformOrigin: "left top 0"
                            });
                            a.left(t[0].left).top(t[0].top + t[2].scrollTop).width(t[0].width - 2).height(t[0].height).scaleY(1).step(), 
                            e.setData({
                                animation: a.export()
                            });
                        }, r ? 50 : 100);
                    });
                }, r ? 50 : 0), setTimeout(function() {
                    n === e.aniId && (e.selectComponent("#startPorts").setPorts(i.startPorts), e.selectComponent("#targetPorts").setPorts(i.targetPorts), 
                    e.selectComponent("#weights").setWeights(i.minWeight, i.maxWeight), e.setData({
                        animating: !1,
                        animation: null
                    }));
                }, 500), this.setData({
                    startPorts: i.startPorts,
                    targetPorts: i.targetPorts,
                    minWeight: i.minWeight,
                    maxWeight: i.maxWeight,
                    currentIdx: i.idx
                }), a.mercury.post("search/log".concat(this.data.Type, "Shortcut"), {
                    idx: i.idx,
                    action: "use_shortcut"
                });
            }
        }
    },
    attached: function() {
        var e = this;
        this.syncUserId = t.id.subscribeAndFireOnce(function(t) {
            return e.setData({
                userId: t
            });
        }), this.setData({
            targetType: "ship" === this.data.type ? "空船" : "货源",
            startTitle: (this.data.type, "请选择"),
            targetTitle: "ship" === this.data.type ? "请选择" : "请选择您要找的货源的",
            startPlaceholder: "ship" === this.data.type ? "建议您多选几个装货港附近的港口和地区" : "建议您多选几个愿意去装货的港口和地区",
            targetPlaceholder: "ship" === this.data.type ? "建议您多选几个卸货港附近的港口和地区" : "建议您将沿线愿意去的目的港都选上"
        }), this.syncSearchShortcuts = i[this.data.type].subscribeAndFireOnce(function(t) {
            for (var a = [], i = 0; i < 5; i++) a[i] = {
                idx: i + 1,
                unset: !0
            };
            t.forEach(function(t) {
                t && t.idx >= 1 && t.idx <= 5 && (a[t.idx - 1] = {
                    idx: t.idx,
                    unset: !1,
                    startPorts: t.start,
                    targetPorts: t.target,
                    minWeight: t.minWeight,
                    maxWeight: t.maxWeight,
                    startText: t.start.length > 0 ? t.start[0].title + (t.start.length > 1 ? "等" : "") : "不限",
                    targetText: t.target.length > 0 ? t.target[0].title + (t.target.length > 1 ? "等" : "") : "不限",
                    weightsLine1: t.minWeight && t.maxWeight ? "".concat(t.minWeight, " ~") : t.minWeight ? "".concat(t.minWeight, "吨") : t.maxWeight ? "".concat(t.maxWeight, "吨") : "",
                    weightsLine2: t.minWeight && t.maxWeight ? "".concat(t.maxWeight, "吨") : t.minWeight ? "以上" : t.maxWeight ? "以下" : "",
                    noCondition: !t.start.length && !t.target.length
                });
            }), e.setData({
                shortcuts: a
            }), e.updateCurrentIdx();
        });
    },
    detached: function() {
        this.syncUserId.dispose(), this.syncSearchShortcuts.dispose();
    },
    ready: function() {}
});