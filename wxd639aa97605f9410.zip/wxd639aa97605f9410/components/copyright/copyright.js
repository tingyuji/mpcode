var t = require("../../utils/util");

Component({
    properties: {
        aboutUs: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        dial: function() {
            t.dial400();
        },
        toAboutUs: function() {
            this.data.aboutUs && wx.navigateTo({
                url: "/pages/settings/about-us/aboutUs"
            });
        }
    }
});