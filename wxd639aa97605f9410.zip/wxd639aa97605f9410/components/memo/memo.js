Component({
    properties: {
        placeholder: {
            type: String,
            value: ""
        },
        cursorSpacing: {
            type: Number,
            value: 0
        },
        value: {
            type: String,
            value: ""
        }
    },
    data: {
        editing: !1
    },
    methods: {
        startEditing: function() {
            this.setData({
                editing: !0
            });
        },
        stopEditing: function() {
            this.setData({
                editing: !1
            });
        },
        valueChange: function(t) {
            this.data.value = t.detail.value, this.setData({
                value: t.detail.value
            }), this.triggerEvent("changeEvent", t.detail.value);
        }
    }
});