var e = require("../../utils/ajax");

Component({
    properties: {
        ship: {
            type: Object,
            value: null
        },
        guess: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        seen: !1
    },
    methods: {
        seen: function() {
            var t = this.properties.ship;
            t.state.ordered || t.state.pause || (t.tag.seen || this.data.seen || this.setData({
                seen: !0
            }), this.data.guess ? e.mercury.post("search/guessLikeLog", {
                action: "view_ship_detail",
                target: t.id,
                distance: t.distance,
                index: t.guessIndex
            }) : e.mercury.post("search/searchLog", {
                action: "view_ship_detail",
                target: t.id,
                v1Compatible: !!t.oldSearch
            }), wx.navigateTo({
                url: "/pages/ship-detail/ship-detail?id=".concat(t.id, "&origin=0")
            }));
        }
    }
});