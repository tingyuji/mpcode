var t = require("../../utils/globalMap");

Component({
    properties: {
        pattern: {
            type: String,
            value: "drop-down"
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        text: {
            type: String,
            value: "港口"
        },
        ports: {
            type: Array,
            value: []
        },
        maxCount: {
            type: Number,
            value: 0
        },
        manual: {
            type: String,
            value: ""
        },
        highlightSelected: {
            type: Boolean,
            value: !1
        },
        type: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        titleHighlight: {
            type: String,
            value: ""
        },
        placeholder: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        select: function() {
            this.data.manual && "&manual=".concat(this.data.manual);
            var e = {
                callback: this.portsChange.bind(this),
                ports: JSON.parse(JSON.stringify(this.data.ports)),
                maxCount: this.data.maxCount,
                type: this.data.type,
                title: this.data.title,
                titleHighlight: this.data.titleHighlight,
                placeholder: this.data.placeholder,
                manual: this.data.manual
            };
            wx.navigateTo({
                url: "/pages/multi-ports-selector/multiPortsSelector?query=".concat(t.register(e))
            });
        },
        setPorts: function(t) {
            t = t || [], this.setData({
                text: t.length > 0 ? t.map(function(t) {
                    return t.title;
                }).join() : this.data.initText,
                ports: t
            });
        },
        portsChange: function(t) {
            this.setPorts(t), this.triggerEvent("changeEvent", t);
        }
    },
    ready: function() {
        this.setData({
            initText: this.data.text,
            text: this.data.ports.length > 0 ? this.data.ports.map(function(t) {
                return t.title;
            }).join() : this.data.text
        });
    },
    detached: function() {}
});