var e = require("../../utils/ajax"), t = require("../../utils/env"), i = require("../../utils/user");

Component({
    properties: {
        position: {
            type: String,
            value: null
        }
    },
    data: {
        imageUrl: ""
    },
    methods: {
        refresh: function() {
            var i = this;
            this.lastRefreshTime = this.lastRefreshTime || 0;
            var r = new Date().getTime();
            r - this.lastRefreshTime > 5e3 && (this.lastRefreshTime = r, e.mercury.get("ad/info", {
                position: this.data.position
            }).then(function(e) {
                (e = e || {}).url && !e.url.toLowerCase().startsWith("http") && (e.url = t.resource(e.url)), 
                JSON.stringify(e) !== JSON.stringify(i.ad) && (i.ad = e, i.setData({
                    imageUrl: e.image ? t.mercury("ad/image/".concat(e.image)) : null
                }));
            }).catch(function(e) {
                return console.error(e);
            }));
        },
        formatUrl: function(t) {
            if (t) {
                t = t.replace(/^https:\/\/(.+):443\//, function(e, t) {
                    return "https://".concat(t, "/");
                });
                var i = "origin=".concat(e.getAgent().name || ""), r = e.getToken();
                r && (i += "&authentication=".concat(r));
                var s = t.indexOf("?");
                s === t.length - 1 ? t += i : t += s < 0 ? "?" + i : "&" + i, t = encodeURIComponent(t);
            }
            return t || "";
        },
        click: function() {
            if (this.ad && this.ad.name) switch (e.mercury.post("ad/click", {
                position: this.data.position,
                advert: this.ad
            }), this.ad.action) {
              case "browse":
              case "inAppBrowse":
                wx.navigateTo({
                    url: "/pages/web-view/webView?url=".concat(this.formatUrl(this.ad.url))
                });
                break;

              case "page":
                var t = "advert_" + this.data.position, i = this.ad.mpPage;
                i += (i.indexOf("?") >= 0 ? "&" : "?") + "source=" + t, wx.navigateTo({
                    url: i
                });
            }
        }
    },
    attached: function() {
        var e = this;
        this.subUserId = i.id.subscribeAndFireOnce(function(t) {
            return e.refresh();
        }), this.subResume = getApp().globalData.resumeEvent.subscribe(function() {
            return e.refresh();
        });
    },
    detached: function() {
        this.subUserId.dispose(), this.subResume.dispose();
    }
});