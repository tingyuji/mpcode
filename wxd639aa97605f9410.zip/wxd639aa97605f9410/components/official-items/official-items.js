Component({
    properties: {
        official: Object,
        source: {
            type: String,
            value: ""
        }
    },
    data: {
        seenHash: {}
    },
    methods: {
        seen: function(e) {
            var t = e.currentTarget.dataset.id;
            if (!this.data.seenHash[t]) {
                var a = this.data.seenHash;
                a[t] = !0, this.setData({
                    seenHash: a
                });
            }
        }
    }
});