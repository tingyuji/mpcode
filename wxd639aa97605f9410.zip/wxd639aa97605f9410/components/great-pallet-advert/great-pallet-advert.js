var e = require("../../utils/env"), t = require("../../utils/ajax");

Component({
    properties: {
        source: {
            type: String,
            value: ""
        },
        ad: {
            type: Object,
            value: null
        }
    },
    data: {
        advertImageUrl: e.resource("mp/great-pallet-advert.jpg")
    },
    methods: {
        viewDetail: function() {
            this.data.ad && t.mercury.post("ad/embeddedClick", {
                showId: this.data.ad.showId,
                type: this.data.ad.type,
                id: this.data.ad.id
            });
        }
    }
});