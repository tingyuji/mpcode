var a = require("../../utils/ajax");

Component({
    properties: {
        ad: {
            type: Object,
            value: null
        },
        source: {
            type: String,
            value: "search"
        }
    },
    data: {},
    methods: {
        call: function(t) {
            var e = t.currentTarget.dataset.mobile;
            a.mercury.post("publishAd/log", {
                id: this.data.ad.id,
                action: "dial_ad_phone",
                result: this.data.source,
                note: {
                    phone: e
                }
            }), wx.makePhoneCall({
                phoneNumber: e
            });
        },
        viewDetail: function() {
            a.mercury.post("ad/embeddedClick", {
                showId: this.data.ad.showId,
                type: this.data.ad.type,
                id: this.data.ad.id
            }), a.mercury.post("publishAd/log", {
                id: this.data.ad.id,
                action: "ad_view_click",
                result: "view_detail_in_".concat(this.data.source)
            });
        }
    }
});