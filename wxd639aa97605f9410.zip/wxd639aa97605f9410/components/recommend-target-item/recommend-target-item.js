var t = require("../../utils/ajax");

Component({
    properties: {
        originCount: {
            type: Number,
            value: 0
        },
        ports: {
            type: Array,
            value: []
        },
        ad: {
            type: Object,
            value: null
        }
    },
    data: {},
    methods: {
        choose: function(t) {
            this.triggerEvent("chooseEvent", t.currentTarget.dataset.item);
        },
        edit: function(e) {
            this.triggerEvent("chooseEvent", null), this.data.ad && t.mercury.post("ad/embeddedClick", {
                showId: this.data.ad.showId,
                type: this.data.ad.type,
                id: this.data.ad.id
            });
        }
    }
});