Component({
    properties: {
        enterprise: Object,
        targetCount: {
            type: Number,
            value: 0
        },
        ports: {
            type: Array,
            value: []
        },
        source: {
            type: String,
            value: ""
        }
    },
    data: {
        seenHash: {}
    },
    methods: {
        seen: function(e) {
            var t = e.currentTarget.dataset.pallet;
            if (!t.state.ordered && !t.state.pause) {
                if (!this.data.seenHash[t.id]) {
                    var a = this.data.seenHash;
                    a[t.id] = !0, this.setData({
                        seenHash: a
                    });
                }
                wx.navigateTo({
                    url: "/pages/pallet-detail/pallet-detail?id=".concat(t.id, "&origin=0&mark=").concat(t.tag.mark, "&showIndex=").concat(t.showIndex, "&originType=").concat(this.data.source)
                });
            }
        },
        chooseTarget: function(e) {
            this.triggerEvent("chooseEvent", e.detail);
        }
    }
});