require("../../utils/globalMap");

Component({
    properties: {
        company: {
            type: Object,
            value: {}
        },
        mode: {
            type: String,
            value: "mode"
        },
        source: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        onTap: function() {
            [ "item", "embedded" ].indexOf(this.data.mode) >= 0 && wx.navigateTo({
                url: "/pages/sailor-exam/sailor-exam?source=" + this.data.source
            });
        }
    }
});