Component({
    properties: {},
    data: {},
    methods: {
        doModal: function(t) {
            var c = this;
            return new Promise(function(t) {
                c.callback = t, c.selectComponent("#easyModal").show();
            });
        },
        clickConfirm: function() {
            this.selectComponent("#easyModal").hide(), this.callback && this.callback(!0);
        },
        clickCancel: function() {
            this.selectComponent("#easyModal").hide(), this.callback && this.callback(!1);
        }
    }
});