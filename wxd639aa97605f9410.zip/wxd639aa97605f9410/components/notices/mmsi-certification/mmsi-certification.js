var e = require("../../../utils/env"), t = require("../../../utils/util"), i = require("../../../dao/vessel");

Component({
    properties: {},
    data: {
        demoUrl: e.resource("mp/ais_mmsi_certification.jpg"),
        closeText: "拍照上传",
        rejected: !1
    },
    methods: {
        doModal: function() {
            var e = this;
            return new Promise(function(t) {
                e.callback = t, e.show();
            });
        },
        show: function() {
            this.baseModal.showModal();
        },
        hide: function() {
            this.baseModal.hideModal();
        },
        _cancelModal: function() {
            this.hide(), this.triggerEvent("cancelEvent"), this.callback && this.callback(!1);
        },
        _confirmModal: function() {
            this.hide(), this.triggerEvent("confirmEvent"), this.callback && this.callback(!0);
        },
        dial400: function() {
            t.dial400();
        }
    },
    ready: function() {
        var e = this;
        this.baseModal = this.selectComponent("#baseModal"), i.subscribeAndFireOnce(function(t) {
            if (t) {
                var i = t && "rejected" === t.mmsiCertifyState, a = (i ? "重新" : "立即") + "拍照上传";
                e.setData({
                    rejected: i,
                    closeText: a
                });
            }
        });
    }
});