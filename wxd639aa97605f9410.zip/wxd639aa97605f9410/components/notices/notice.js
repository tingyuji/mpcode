var e = require("../../utils/ajax"), t = require("../../utils/util"), i = require("../../utils/globalMap"), s = require("../../dao/usedVesselSell");

Component({
    properties: {},
    data: {},
    methods: {
        check: function(t, i) {
            var s = this;
            return t = t || function() {}, i = i || function() {}, e.mercury.get("ad/notice", {
                version: 27
            }).then(function(n) {
                switch (n && n.notice) {
                  case "vesselCertificationExpired":
                    return t(), s.vesselCertificationExpire.doModal(n).finally(i).then(function(e) {
                        return e ? s.toVesselCertification() : void 0;
                    });

                  case "usedVesselExpireAlert":
                    return t(), s.usedVesselExpire.doModal(n).finally(i).then(function(e) {
                        return e ? s.toUsedVesselSell() : void 0;
                    });

                  case "usedVesselVisitAlert":
                    return t(), s.showUsedVesselVisitAlert().finally(i).then(function(e) {
                        return s.afterUsedVesselVisitAlert(e);
                    });

                  case "mmsiCertification":
                    return t(), s.mmsiCertificationModal.doModal().finally(i).then(function() {
                        return s.toMmsiCertification();
                    });

                  case "weather":
                    return t(), s.weatherModal.doModal().finally(i).then(function(e) {
                        return e && s.toWeather();
                    });

                  case "experienceVip":
                    return t(), s.expVipModal.doModal().finally(i).then(function(t) {
                        return t && e.mercury.post("sms/addExperienceVip");
                    });
                }
            }).catch(function(e) {
                return console.error(e);
            });
        },
        toWeather: function() {
            wx.navigateTo({
                url: "/pages/weather/weather?source=notice"
            });
        },
        toMmsiCertification: function() {
            wx.navigateTo({
                url: "/pages/settings/edit-vessel/editVessel?source=notice&action=mmsi-cert"
            });
        },
        toVesselCertification: function() {
            wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel?source=notice"
            });
        },
        showUsedVesselVisitAlert: function() {
            return s.refresh().then(function(e) {
                var i = e.visitAlertItem;
                if (i) {
                    var s, n;
                    if (i.isVisitValid ? i.isVisitExpired && (s = "您的看船信息已过期，卖船广告不会被系统推荐给买家", n = "更新看船信息") : (s = "您的卖船广告未被系统推荐给买家，填写看船信息可获得推荐", 
                    n = "填写看船信息"), s) return t.confirm(s, {
                        cancelText: "最近不方便看船",
                        confirmText: n
                    }).then(function() {
                        return {
                            item: i,
                            visitable: !0
                        };
                    }).catch(function() {
                        return {
                            item: i,
                            visitable: !1
                        };
                    });
                }
            });
        },
        afterUsedVesselVisitAlert: function(t) {
            if (t) if (t.visitable) {
                var s = i.register(t.item || null);
                wx.navigateTo({
                    url: "/pages/used-vessel/edit-visit/edit-visit?source=notice&item=".concat(s, "&action=edit")
                });
            } else e.mercury.post("usedVessel/unvisitable", {
                id: t.item.id
            });
        },
        toUsedVesselSell: function() {
            wx.navigateTo({
                url: "/pages/used-vessel/sell/sell?source=notice"
            });
        }
    },
    ready: function() {
        this.expVipModal = this.selectComponent("#expVipModal"), this.weatherModal = this.selectComponent("#weatherModal"), 
        this.mmsiCertificationModal = this.selectComponent("#mmsiCertificationModal"), this.usedVesselExpire = this.selectComponent("#usedVesselExpireModal"), 
        this.vesselCertificationExpire = this.selectComponent("#vesselCertificationExpireModal");
    }
});