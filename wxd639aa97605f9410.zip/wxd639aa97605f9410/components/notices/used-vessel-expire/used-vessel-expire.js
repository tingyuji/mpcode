var e = require("../../../utils/util");

Component({
    properties: {},
    data: {
        days: 0,
        expireText: ""
    },
    methods: {
        doModal: function(e) {
            var t = this;
            return this.setData({
                days: e.target,
                expireText: e.expireText || null
            }), new Promise(function(e) {
                t.callback = e, t.selectComponent("#easyModal").show();
            });
        },
        clickConfirm: function() {
            this.selectComponent("#easyModal").hide(), this.callback && this.callback(!0);
        },
        clickCancel: function() {
            this.selectComponent("#easyModal").hide(), this.callback && this.callback(!1);
        },
        dial400: function() {
            e.dial400();
        }
    }
});