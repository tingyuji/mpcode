var t = require("../../../utils/env");

Component({
    properties: {},
    data: {
        bkImage: t.resource("mp/weather-notice.jpg")
    },
    methods: {
        doModal: function() {
            var t = this;
            return new Promise(function(e) {
                t.callback = e, t.show();
            });
        },
        show: function() {
            this.baseModal.showModal();
        },
        hide: function() {
            this.baseModal.hideModal();
        },
        _cancelModal: function() {
            this.hide(), this.triggerEvent("cancelEvent"), this.callback && this.callback(!1);
        },
        _confirmModal: function() {
            this.hide(), this.triggerEvent("confirmEvent"), this.callback && this.callback(!0);
        }
    },
    ready: function() {
        this.baseModal = this.selectComponent("#baseModal");
    }
});