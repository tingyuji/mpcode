var t = require("../../utils/util"), e = require("../../dao/vessel"), i = require("../../utils/ajax");

Component({
    properties: {},
    data: {
        title: "温馨提示",
        cancelText: "暂不申请",
        confirmText: "申请增加次数",
        vesselCertExpired: !1
    },
    methods: {
        show: function() {
            var t = this;
            e.refresh().then(function() {
                var i = e.get(), n = i && i.certificationExpired && "pending" !== i.candidateState;
                n && t.setData({
                    vesselCertExpired: n,
                    confirmText: "重新认证",
                    cancelText: "申请增加次数"
                });
            }), this.contactLimitModal.show();
        },
        confirm: function() {
            this.contactLimitModal.hide(), this.data.vesselCertExpired ? wx.navigateTo({
                url: "/pages/settings/certify-vessel/certifyVessel?source=viewContactLimit"
            }) : this.extendLimit();
        },
        cancel: function() {
            this.data.vesselCertExpired && this.extendLimit();
        },
        dialService: function() {
            t.dial400();
        },
        extendLimit: function() {
            var t = this;
            i.mercury.post("ships/extendContactLimit").then(function(e) {
                e ? t.extendSuccModal.show() : t.extendFailModal.show();
            }).catch(function(t) {
                return i.showError("申请增加次数", t);
            });
        },
        confirmSucc: function() {
            this.extendSuccModal.hide();
        },
        confirmFail: function() {
            this.extendFailModal.hide(), this.dialService();
        }
    },
    ready: function() {
        this.contactLimitModal = this.selectComponent("#contactLimitModal"), this.extendSuccModal = this.selectComponent("#extendSuccModal"), 
        this.extendFailModal = this.selectComponent("#extendFailModal");
    }
});