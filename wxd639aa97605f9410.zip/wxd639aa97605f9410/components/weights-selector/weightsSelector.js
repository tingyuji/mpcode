Component({
    properties: {
        pattern: {
            type: String,
            value: "drop-down"
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        text: {
            type: String,
            value: "船皮"
        },
        minWeight: {
            type: String,
            value: null
        },
        maxWeight: {
            type: String,
            value: null
        },
        highlightSelected: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: "选择船皮"
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        confirmText: {
            type: String,
            value: "确定"
        },
        backdrop: {
            type: Boolean,
            value: !1
        },
        animated: {
            type: Boolean,
            value: !0
        },
        modalSize: {
            type: String,
            value: "md"
        },
        selectFilter: {
            type: Function,
            value: null
        }
    },
    data: {},
    methods: {
        select: function() {
            this.data.selectFilter && !this.data.selectFilter() || this.easyModal.show();
        },
        setWeights: function(t, e) {
            this.setData({
                minWeight: t,
                maxWeight: e,
                text: this.getText(t, e)
            });
        },
        confirm: function() {
            this.easyModal.hide(), this.setData({
                text: this.getText(this.data.minWeight, this.data.maxWeight)
            }), this.triggerEvent("changeEvent", this.getWeights(this.data.minWeight, this.data.maxWeight));
        },
        cancel: function() {
            this.setData({
                minWeight: null,
                maxWeight: null,
                text: this.getText(null, null)
            }), this.triggerEvent("changeEvent", this.getWeights(null, null));
        },
        minWeightChange: function(t) {
            this.data.minWeight = t.detail.value;
        },
        maxWeightChange: function(t) {
            this.data.maxWeight = t.detail.value;
        },
        getWeights: function(t, e) {
            function i(t) {
                return parseInt(t) || null;
            }
            return t = i(t), e = i(e), {
                minWeight: t && e ? Math.min(t, e) : t,
                maxWeight: t && e ? Math.max(t, e) : e
            };
        },
        getText: function(t, e, i) {
            var a = this.getWeights(t, e);
            return a.minWeight && a.maxWeight ? "".concat(a.minWeight, "~").concat(a.maxWeight, "吨") : a.minWeight ? "".concat(a.minWeight, "吨以上") : a.maxWeight ? "".concat(a.maxWeight, "吨以下") : i || this.data.initText;
        }
    },
    ready: function() {
        this.setData({
            initText: this.data.text,
            text: this.getText(this.data.minWeight, this.data.maxWeight, this.data.text)
        }), this.easyModal = this.selectComponent("#weightsSelectorModal");
    }
});