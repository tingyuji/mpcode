var t = require("../../utils/env"), a = require("../../utils/ajax"), e = {
    sandstone: "/images/sandstone-trade.png",
    vessel: "/images/vessel-trade.png",
    recruit: "/images/sailor-recruit.png"
};

Component({
    properties: {
        type: {
            type: String,
            value: "huo"
        },
        ad: {
            type: Object,
            value: null
        },
        source: {
            type: String,
            value: null
        }
    },
    data: {
        section: "",
        content: "",
        media: ""
    },
    methods: {
        viewDetail: function() {
            this.data.ad && a.mercury.post("ad/embeddedClick", {
                showId: this.data.ad.showId,
                type: this.data.ad.type,
                id: this.data.ad.id
            });
        }
    },
    attached: function() {
        var a, i = this.data.ad && this.data.ad.section || "", d = this.data.ad && this.data.ad.content || "", s = this.data.ad && this.data.ad.media || "";
        s = s ? (a = s.hash, t.mercury("sectionAd/mediaThumbnail?hash=".concat(a, "&thumbnail=2&level=3"))) : e[i], 
        this.setData({
            section: i,
            content: d,
            media: s
        });
    }
});