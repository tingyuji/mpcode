var a = require("../../utils/globalMap");

Component({
    properties: {
        placeholder: {
            type: String,
            value: ""
        },
        value: {
            type: String,
            value: ""
        },
        readonly: {
            type: Boolean,
            value: !1
        },
        access: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        input: function() {
            this.data.readonly || wx.navigateTo({
                url: "/pages/note/note?value=".concat(this.data.value, "&callback=").concat(this.callbackId)
            });
        },
        valueChange: function(a) {
            this.setData({
                value: a
            }), this.triggerEvent("changeEvent", a);
        }
    },
    ready: function() {
        this.callbackId = a.register(this.valueChange.bind(this));
    },
    detached: function() {
        this.callbackId && (a.unRegister(this.callbackId), this.callbackId = null);
    }
});