var e = require("../utils/ajax"), r = require("../utils/env.js"), t = require("../utils/observable"), n = require("../utils/user"), i = require("../utils/serviceBadge"), u = new t(null);

function a() {
    return n.id.get() ? e.mercury.get("relations/list").then(function(e) {
        e.forEach(function(e) {
            return e.avatarUrl = e.avatar ? r.mercury("files/avatar/".concat(e.avatar)) : "/images/avatar-none.png";
        });
        var t = e.filter(function(e) {
            return "friendReceived" === e.state;
        });
        return i.setFriend(t.length), {
            friendReceived: t,
            friend: e.filter(function(e) {
                return "friend" === e.state;
            }),
            baddie: e.filter(function(e) {
                return "baddie" === e.state;
            }),
            relation: e.filter(function(e) {
                return "friend" === e.state || "baddie" === e.state;
            })
        };
    }).then(function(e) {
        return u.set(e);
    }) : Promise.resolve(u.set(null));
}

u.refresh = a, n.id.subscribeAndFireOnce(function() {
    return a();
}), module.exports = u;