var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), s = require("../utils/serviceBadge"), n = require("../utils/settingBadge"), i = new e([]);

i.refresh = c, i.see = function(e) {
    return t.mercury.post("mapps/seeService", {
        service: e
    }).then(function() {
        i.get().indexOf(e) >= 0 && c();
    });
}, r.id.subscribeAndFireOnce(function() {
    return c();
});

var u = [ "publishAd", "friendCircle", "fuel", "recentContact", "contractHelper", "antiFakePhoto", "sandstone", "sailorRecruit", "usedVessel", "fastFindVessel", "safeTrade", "safeTrade190304", "safeTradeMemo" ], a = [ "myCompany", "companyAuth" ];

function c() {
    return r.id.get() > 0 ? t.mercury.get("mapps/unseenServices").then(function(e) {
        var t = new Set(e);
        r.isStarUser.get() && t.has("companyAuth") && t.delete("companyAuth");
        var c = u.filter(function(e) {
            return t.has(e);
        }), o = a.filter(function(e) {
            return t.has(e);
        });
        return i.set(e), s.setServices(c), n.setServices(o), i.get();
    }) : (i.set([]), Promise.resolve([]));
}

module.exports = i;