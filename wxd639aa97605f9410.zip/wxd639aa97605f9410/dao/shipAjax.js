require("../utils/ajax.js"), require("../utils/user.js");

var e = require("./vessel.js");

module.exports.canPublish = function(r) {
    var s = e.get();
    r(null, s && s.certified);
};