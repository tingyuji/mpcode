var t = require("../utils/observable"), e = require("../utils/user"), u = require("../utils/ajax"), a = new t(null);

function n() {
    return new Promise(function(t, e) {
        wx.getSetting({
            success: function(t) {
                var e = !!t.authSetting["scope.userLocation"];
                return a.auth.set(e), e;
            },
            fail: e
        });
    });
}

function i() {
    return n(), new Promise(function(t, e) {
        wx.getLocation({
            type: "wgs84",
            altitude: !0,
            success: t,
            fail: e
        });
    }).then(function(t) {
        return t.time = new Date(), a.set(t), a.status.set("success"), a.auth.set(!0), t;
    }).catch(function(t) {
        (t.errMsg || "").indexOf("auth deny") >= 0 ? a.status.set("deny") : a.status.set("error");
    });
}

a.status = new t("init"), a.auth = new t(!1), a.auth.refresh = n, a.refresh = i, 
a.upload = o;

var r = 0, s = !1, c = wx.getStorageSync("last_upload_location_time") || 0;

function o() {
    var t = new Date().getTime();
    !s && t - r > 3e3 && (r = t, s = !0, i().finally(function() {
        return s = !1;
    }).then(function(a) {
        a && e.id.get() > 0 && t - c > 3e5 && (c = t, wx.setStorage({
            key: "last_upload_location_time",
            data: c
        }), u.mercury.post("geolocation/upload", {
            position: {
                coords: {
                    latitude: a.latitude,
                    longitude: a.longitude,
                    accuracy: a.accuracy,
                    altitude: a.altitude,
                    speed: a.speed,
                    altitudeAccuracy: a.verticalAccuracy,
                    horizontalAccuracy: a.horizontalAccuracy
                },
                timestamp: t
            }
        }));
    }));
}

e.id.subscribe(function() {
    return o();
}), module.exports = a;