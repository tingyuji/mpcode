var e = require("../utils/observable"), r = require("../utils/ajax"), s = require("../utils/user"), t = new e(!1);

t.refresh = function() {
    return s.id.get() > 0 ? r.mercury.get("usedVessel/sellAlert").then(function(e) {
        return t.set(e);
    }) : Promise.resolve(t.set(!1));
}, s.id.subscribeAndFireOnce(t.refresh), module.exports = t;