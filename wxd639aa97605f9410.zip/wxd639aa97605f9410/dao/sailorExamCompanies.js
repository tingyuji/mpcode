var e = require("../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../utils/observable"), a = require("../utils/ajax"), t = require("../utils/env"), o = new r([]);

function n() {
    return a.mercury.get("mapps/sailorExamCompanies").then(function(r) {
        var a, n = e(r);
        try {
            for (n.s(); !(a = n.n()).done; ) {
                var s = a.value;
                s.baseUrl = "app-help/sailor-exam/".concat(s.short), s.avatar = t.resource("".concat(s.baseUrl, "/avatar.png"));
                for (var c = 0, l = [ "intro", "score", "trial", "enter" ]; c < l.length; c++) {
                    var i = l[c];
                    s[i + "Url"] = t.resource("".concat(s.baseUrl, "/").concat(i, ".html?v=3"));
                }
            }
        } catch (e) {
            n.e(e);
        } finally {
            n.f();
        }
        o.set(r);
    });
}

o.refresh = n, n().catch(function(e) {
    console.error(e), setTimeout(n, 5e3);
}), module.exports = o;