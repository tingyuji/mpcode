var e = require("../utils/observable"), t = require("../utils/ajax"), r = require("./vessel"), n = new e(null);

function s(e) {
    return (e = e || n.get()) ? t.mercury.get("check/activation", {
        objectId: e.id,
        objectType: "ship"
    }).then(function(t) {
        return e === n.get() && (e = JSON.parse(JSON.stringify(e))), e.mask = !!t, n.set(e);
    }) : n.set(null);
}

n.refresh = function() {
    return r.get() ? t.mercury.get("ships/list").then(function(e) {
        var i = 0, u = null, a = r.get().id;
        return e.forEach(function(e) {
            if (e.vessel === a) {
                e.date = new Date(e.date);
                var t = new Date(e.date.getTime());
                t.setDate(t.getDate() + (e.duration || 0)), t.getTime() > i && (i = t.getTime(), 
                u = e);
            }
        }), u ? t.mercury.get("ships/load", {
            id: u.id
        }).then(function(e) {
            return s(e);
        }) : n.set(null);
    }) : Promise.resolve(n.set(null));
}, n.refreshMask = s, n.maskShipCount = new e(0), n.subscribe(function(e) {
    return n.maskShipCount.set(e && e.mask ? 1 : 0);
}), r.subscribeAndFireOnce(n.refresh), module.exports = n;