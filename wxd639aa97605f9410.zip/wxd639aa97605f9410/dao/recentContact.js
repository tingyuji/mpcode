var e = require("../utils/ajax"), t = require("../utils/observable"), r = require("../utils/user"), n = require("../utils/serviceBadge"), i = require("../modules/moment"), a = new t([]), u = new t(0);

function s() {
    return r.id.get() > 0 ? e.mercury.get("search/pendingContactCount").then(function(e) {
        return n.setRecentCount(e), u.set(e);
    }) : (n.setRecentCount(0), u.set(0), Promise.resolve(0));
}

u.refresh = s, a.load = function() {
    return r.id.get() ? e.mercury.get("search/recentContacts").then(function(e) {
        return e.forEach(function(e) {
            var t, r;
            e.vesselCertified = e.vesselCertified || !1, e.date = e.date ? (t = e.date, (r = i(t)).startOf("day").valueOf() === i().startOf("day").valueOf() ? "今天" : r.format("M月D日")) : null, 
            e.viewTime = function(e) {
                var t = i().startOf("day").diff(i(new Date(e)).startOf("day"), "days");
                if (t > 0) return 1 === t ? "昨天" : "".concat(t, "天前");
                var r = (new Date().getTime() - new Date(e).getTime()) / 1e3;
                if (r < 60) return "刚刚";
                var n = Math.floor(r / 60);
                if (n < 60) return "".concat(n, "分钟前");
                var a = Math.floor(n / 60);
                return "".concat(a, "小时前");
            }(e.viewTime), e.needVip = e.mobile.indexOf("*") >= 0;
        }), a.set(e);
    }) : (a.set([]), Promise.resolve([]));
}, a.pendingCount = u, r.id.subscribeAndFireOnce(function(e) {
    if (s(), e > 0) var t = setInterval(function() {
        e === r.id.get() ? s() : clearInterval(t);
    }, 15e3);
}), module.exports = a;