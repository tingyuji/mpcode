var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), i = new e(0);

function u() {
    return r.id.get() ? t.mercury.get("cash/brief").then(function(e) {
        return i.set(+(e && e.balance || 0).toFixed(2));
    }) : (i.set(0), Promise.resolve(0));
}

i.refresh = u, r.id.subscribeAndFireOnce(function() {
    return u();
}), module.exports = i;