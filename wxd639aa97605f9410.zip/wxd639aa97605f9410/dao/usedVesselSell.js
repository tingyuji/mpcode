var e = require("../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../utils/observable"), t = require("../utils/ajax"), i = require("../utils/user"), n = require("../pages/used-vessel/common"), s = require("./usedVesselSellAlert"), u = {
    items: [],
    expired: 0,
    toExtend: 0,
    toPublish: 0,
    showing: 0,
    alertCount: 0,
    visitAlertItem: null
}, l = new r(u);

l.refresh = function() {
    o || (o = i.id.subscribe(l.refresh));
    return s.refresh(), i.id.get() > 0 ? t.mercury.get("usedVessel/sellItems").then(function(r) {
        var t, i = e(r);
        try {
            for (i.s(); !(t = i.n()).done; ) {
                var s = t.value;
                n.fixItem(s), "expired" === s.state ? s.order = 400 : s.toExtend ? s.order = 300 : "draft" === s.state ? s.order = 200 : "publishing" === s.state ? s.order = 100 : s.order = 0;
            }
        } catch (e) {
            i.e(e);
        } finally {
            i.f();
        }
        r = r.sort(function(e, r) {
            return r.order - e.order;
        });
        var u = function(e) {
            return "publishing" === e.state;
        }, o = r.filter(function(e) {
            return "expired" === e.state;
        }).length, d = r.filter(function(e) {
            return e.toExtend;
        }).length, a = r.filter(function(e) {
            return "draft" === e.state;
        }).length, f = r.filter(function(e) {
            return u(e) && !e.toExtend;
        }).length, h = r.filter(function(e) {
            return u(e) && (!e.isVisitValid || e.isVisitExpired);
        }), c = h.length, x = h[0] || null;
        return x && (f = 0, x.toExtend && (d = 0)), l.set({
            items: r,
            expired: o,
            toExtend: d,
            toPublish: a,
            showing: f,
            alertCount: c,
            visitAlertItem: x
        });
    }) : Promise.resolve(l.set(u));
};

var o = null;

module.exports = l;