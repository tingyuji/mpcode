var r = require("../utils/observable"), e = require("../utils/ajax"), n = require("../utils/user"), t = new Set(), u = new r([]);

function i() {
    return e.mercury.get("miniProgram/functions").then(function(r) {
        return t = new Set(Array.from(t).concat(r)), u.set(Array.from(new Set(r))), u.get();
    });
}

u.refresh = i, u.obj = function() {
    var r = {}, e = new Set(u.get());
    return Array.from(t).forEach(function(n) {
        return r["function_" + n] = e.has(n);
    }), r;
}, n.id.subscribeAndFireOnce(function() {
    return i();
}), module.exports = u;