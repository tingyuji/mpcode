var e = require("../utils/observable"), r = require("../utils/ajax"), t = require("../utils/user"), n = [ "Ship", "Pallet" ], u = [ new e([]), new e([]) ], s = u[0];

s.refresh = function() {
    return c(0);
}, s.save = function(e) {
    return o(0, e);
};

var i = u[1];

function c(e) {
    return t.id.get() > 0 ? r.mercury.get("search/list".concat(n[e], "Shortcuts")).then(function(r) {
        return u[e].set(r);
    }).catch(function(r) {
        return console.error(r), setTimeout(function() {
            return c(e);
        }, 1e4), u[e].get();
    }) : Promise.resolve(u[e].set([]));
}

function o(e, t) {
    return r.mercury.post("search/save".concat(n[e], "Shortcut"), t).then(function() {
        var r = u[e];
        r.get()[t.idx - 1] = t, r.valueHasMutated();
    });
}

i.refresh = function() {
    return c(1);
}, i.save = function(e) {
    return o(1, e);
}, t.id.subscribeAndFireOnce(function() {
    s.refresh(), i.refresh();
}), module.exports = {
    ship: s,
    pallet: i
};