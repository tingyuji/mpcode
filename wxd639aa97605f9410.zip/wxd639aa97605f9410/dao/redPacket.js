var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), u = new e(null);

function i() {
    return r.id.get() > 0 ? t.mercury.get("redPacket/brief").then(function(e) {
        return u.set(e);
    }) : (u.set(null), Promise.resolve(null));
}

u.refresh = i, r.id.subscribeAndFireOnce(function(e) {
    if (i(), e > 0) var t = setInterval(function() {
        e === r.id.get() ? i() : clearInterval(t);
    }, 15e3);
}), module.exports = u;