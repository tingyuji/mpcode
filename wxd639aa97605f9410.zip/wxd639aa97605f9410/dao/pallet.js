var e = require("../utils/ajax"), t = require("../utils/util"), a = require("../utils/env"), i = require("../utils/user"), r = require("../modules/moment"), n = require("../utils/observable");

function s(e) {
    return e.createTime = new Date(e.createTime), e.updateTime = e.updateTime ? new Date(e.updateTime) : null, 
    e.date = new Date(e.date), e.status = e.pause || e.ordered ? -1 : 0, e.longTerm = !!e.longTerm, 
    e.loadOnArrived = !!e.loadOnArrived, e.detailAvatarImage = e.media && e.media.length > 0 ? a.mercury("store/media/".concat(e.media[0].file, "?thumbnail=1")) : e.avatar ? a.mercury("files/avatar/".concat(e.avatar)) : "/images/avatar-none.png", 
    e.isGreat = e.great && !e.great.pause, e.avatarImage = e.isGreat ? "/images/great-pallet-avatar.jpg" : e.detailAvatarImage, 
    e.dateText = e.longTerm ? "长期货" : e.loadOnArrived ? "船到就装" : r(e.date).format("MM月DD日装"), 
    e;
}

function o(e) {
    return (e = s(e)).date = r(e.date).format("YYYY-MM-DD"), e.dateDesc = t.formatRelativeDate(e.date), 
    e;
}

var u = new n([]);

u.refreshMask = function(t) {
    return (t = t || u.get()).length > 0 ? e.mercury.get("check/activations", {
        objectIds: t.map(function(e) {
            return e.id;
        }).join(","),
        objectType: "pallet"
    }).then(function(e) {
        var a = new Set(e);
        return t === u.get() && (t = JSON.parse(JSON.stringify(t))), t.forEach(function(e) {
            return e.mask = a.has(e.id);
        }), u.set(t);
    }) : Promise.resolve(u.set([]));
}, u.refresh = function() {
    return i.id.get() > 0 ? e.mercury.get("pallets/list").then(function(e) {
        return e.length > 0 ? (e = (e = e.map(o)).sort(function(e, t) {
            return t.id - e.id;
        }), u.refreshMask(e)) : u.set([]);
    }) : Promise.resolve(u.set([]));
};

var l = new n(0);

u.subscribe(function(e) {
    return l.set(e.filter(function(e) {
        return e.mask;
    }).length);
});

var c = new n(0);

u.subscribe(function(e) {
    return c.set(e.filter(function(e) {
        return !e.mask && !e.pause && !e.ordered;
    }).length);
}), i.id.subscribeAndFireOnce(u.refresh), module.exports = {
    canPublish: function(t) {
        e.mercury.get("pallets/canPublish").then(function(e) {
            t(null, e);
        });
    },
    morePallets: function(a, i) {
        e.mercury.get("pallets/morePallets", {
            pallet: a
        }).then(function(e) {
            e.alert ? (t.hideLoading(), "PAY_LIMIT" === e.code ? t.alert(e.message) : t.confirm(e.message, {
                cancelText: "暂不开通",
                confirmText: "立即开通"
            }).then(function() {
                return wx.navigateTo({
                    url: "/pages/settings/flag-ship-store?source=publishPallet"
                });
            })) : i();
        }).catch(t.hideLoading);
    },
    fixPallet: s,
    fixInView: function(e) {
        Array.isArray(e.blankStart) && (e.blankStart = e.blankStart.join()), e.startLoc = e.startLoc || e.locations && e.locations.start || null, 
        e.targetLoc = e.targetLoc || e.locations && e.locations.target || null, e.showTimeText = t.getTimeText(e.showTime), 
        e.dateText = e.longTerm ? "长期货" : e.loadOnArrived ? "船到就装" : t.getDateFullText(e.date) + "装";
        var i = "随船装";
        e.anyWeight || (i = 0 === e.minWeight ? e.maxWeight + "吨以下" : 2147483647 === e.maxWeight || null === e.maxWeight ? e.minWeight + "吨以上" : e.minWeight === e.maxWeight ? "".concat(e.minWeight, "吨") : "".concat(e.minWeight, "-").concat(e.maxWeight, "吨")), 
        e.weight = i, e.fengcangText = "yes" === e.fengcang ? "需封舱" : "", "biaozhun" === e.shuichi ? e.shuichiText = "标准水尺" : "magang" === e.shuichi ? e.shuichiText = "马钢水尺" : "wugang" === e.shuichi ? e.shuichiText = "武钢水尺" : "zhonggang" === e.shuichi && (e.shuichiText = "重钢水尺");
        var r = "";
        if (e.shipSingle && (r += "单机"), e.shipCount > 0 && (r += "".concat(e.shipCount, "条")), 
        e.fleet && (r.length > 0 ? r += ",船队" : r += "船队"), e.shipStatus = r, e.dakongText = "yes" === e.dakong ? "需打孔" : "", 
        e.sinkText = "yes" === e.sink ? "需排水槽" : "", "fore" === e.bridgePosition ? e.bridgePositionText = "前置" : "aft" === e.bridgePosition && (e.bridgePositionText = "后置"), 
        "whole" === e.hatch ? e.hatchText = "通舱" : "division" === e.hatch && (e.hatchText = "分舱"), 
        e.media = (Array.isArray(e.media) ? e.media : []).map(function(e) {
            return e.isVideo = (e.type || "").toLowerCase().startsWith("video"), e.thumbnail = a.mercury("store/media/".concat(e.file || "none.png", "?thumbnail=1")), 
            e.url = a.mercury("store/media/".concat(e.file || "none.png").concat(e.isVideo ? "" : "?size=1280")), 
            e;
        }), e.great) {
            var n = new Date().getHours();
            e.great.notEnoughMoney = e.great.pause && !e.pause && !e.ordered && n >= 6 && n < 22;
        }
        return e;
    },
    pallets: u,
    maskPalletCount: l,
    normalPalletCount: c
};