var e = require("../utils/observable"), r = require("../utils/user"), u = require("../utils/ajax"), t = new e(null);

function n() {
    return r.id.get() ? u.mercury.get("account/vipStatus").then(function(e) {
        return t.set(e);
    }) : (t.set(null), Promise.resolve(null));
}

t.refresh = n, r.id.subscribeAndFireOnce(function() {
    return n();
}), module.exports = t;