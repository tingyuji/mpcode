var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), u = new e(null);

function l() {
    return r.id.get() ? t.mercury.get("vessels/list").then(function(e) {
        var r = function(e) {
            var r = e.filter(function(e) {
                return e.certified > 0;
            });
            return r.length > 0 ? r[r.length - 1] : e.length > 0 ? e[e.length - 1] : null;
        }(e);
        return r && (r.buildDate = r.buildDate ? new Date(r.buildDate) : null), u.set(r || null), 
        r || null;
    }) : (u.set(null), Promise.resolve(null));
}

u.refresh = l, r.id.subscribeAndFireOnce(function() {
    return l();
}), u.subscribe(function(e) {
    e && e.id > 0 && t.mercury.post("vessels/select", {
        vessel: e && e.id
    });
}), module.exports = u;