var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), u = new e(null);

function n() {
    return r.id.get() ? t.mercury.get("account/voucher").then(function(e) {
        return u.set(e);
    }) : (u.set(null), Promise.resolve(null));
}

u.refresh = n, u.details = new e(null), u.details.refresh = function() {
    return r.id.get() ? t.mercury.get("account/voucherDetails").then(function(e) {
        return u.details.set(e);
    }) : (u.details.set(null), Promise.resolve(null));
}, r.id.subscribeAndFireOnce(function() {
    return n();
}), module.exports = u;