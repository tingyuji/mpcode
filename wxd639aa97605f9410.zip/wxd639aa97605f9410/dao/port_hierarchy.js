var r = require("../@babel/runtime/helpers/typeof"), e = require("../utils/observable"), t = require("../utils/ajax"), n = new e({});

n.refresh = function(e) {
    return t.mercury.get("ports/hierarchyInfo", {
        type: e,
        version: "v2"
    }).then(function(t) {
        JSON.parse(JSON.stringify(t));
        Object.getOwnPropertyNames(t).forEach(function(n) {
            var c = t[n];
            c && "object" === r(c) && (c.title = c.t || n, c.children = Array.isArray(c.c) && c.c.length > 0 ? c.c.map(function(r) {
                return r.m;
            }) : null, c.count = c[e[0]] || 0);
        });
        var c = function(r) {
            t[r] || (t[r] = {
                title: r,
                children: null,
                count: 0
            });
        };
        Object.getOwnPropertyNames(t).forEach(function(e) {
            var n = t[e];
            n && "object" === r(n) && Array.isArray(n.children) && n.children.forEach(function(r) {
                Array.isArray(r) ? r.forEach(function(r) {
                    return c(r);
                }) : c(r);
            });
        });
        var i = Object.assign({}, n.get());
        i[e] = t, n.set(i);
    });
}, module.exports = n;