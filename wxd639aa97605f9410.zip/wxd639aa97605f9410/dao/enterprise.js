var e = require("../utils/observable"), r = require("../utils/user"), t = require("../utils/ajax"), i = require("../utils/env"), o = new e(null);

function s() {
    return r.id.get() ? new Promise(function(e, r) {
        t.mercury.get("enterprise/listUserEnterprises").then(function(o) {
            var s = o.find(function(e) {
                return e.hasStore;
            });
            s ? t.mercury.get("enterprise/loadUserEnterprise", {
                enterprise: s.id
            }).then(function(r) {
                r.createTime = r.createTime ? new Date(r.createTime) : null, r.certifyingTime = r.certifyingTime ? new Date(r.certifyingTime) : null, 
                r.approvedTime = r.approvedTime ? new Date(r.approvedTime) : null, r.store && ("string" == typeof r.store.selfRole && (r.store.selfRole = r.store.selfRole.toLowerCase()), 
                r.store.logoImage = r.store.logo ? i.mercury("store/logo/".concat(r.store.logo, "?size=100&mode=pad")) : "/images/star_logo_none.png", 
                r.store.members = Array.isArray(r.store.members) ? r.store.members : [], r.store.members.forEach(function(e) {
                    e && (e.role = (e.role || "").toLowerCase(), e.isAdmin = "admin" === e.role, e.roleName = e.isAdmin ? "管理员" : "普通成员");
                })), e(r);
            }).catch(r) : e(null);
        }).catch(r);
    }).then(function(e) {
        return t.setEnterprise(e && e.id), o.set(e), e;
    }) : (o.set(null), Promise.resolve(null));
}

o.refresh = s, r.id.subscribeAndFireOnce(function() {
    return s();
}), module.exports = o;