var n = require("../plugins/es6-promise.js");

function t(t) {
    return function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new n(function(n, o) {
            e.success = function(t) {
                n(t);
            }, e.fail = function(n) {
                o(n);
            }, t(e);
        });
    };
}

n.prototype.finally = function(n) {
    var t = this.constructor;
    return this.then(function(e) {
        return t.resolve(n()).then(function() {
            return e;
        });
    }, function(e) {
        return t.resolve(n()).then(function() {
            throw e;
        });
    });
}, module.exports = {
    wxPromisify: t,
    wxGetStorage: function() {
        return t(wx.getStorage);
    },
    wxLogin: function() {
        return t(wx.login);
    },
    wxCheckSession: function() {
        return t(wx.checkSession);
    },
    wxGetUserInfo: function() {
        return t(wx.getUserInfo);
    },
    wxGetSetting: function() {
        return t(wx.getSetting);
    },
    wxGetSystemInfo: function() {
        return t(wx.getSystemInfo);
    },
    wxRequestPayment: function() {
        return t(wx.requestPayment);
    },
    wxGetSavedFileList: function() {
        return t(wx.getSavedFileList);
    },
    wxGetSavedFileInfo: function() {
        return t(wx.getSavedFileInfo);
    },
    wxDownloadFile: function() {
        return t(wx.downloadFile);
    },
    wxSaveFile: function() {
        return t(wx.saveFile);
    },
    wxSaveImageToPhotosAlbum: function() {
        return t(wx.saveImageToPhotosAlbum);
    },
    wxPreviewImage: function() {
        return t(wx.previewImage);
    },
    wxOpenSetting: function() {
        return t(wx.openSetting);
    },
    wxShowModal: function() {
        return t(wx.showModal);
    },
    wxPlayBackgroundAudio: function() {
        return t(wx.playBackgroundAudio);
    },
    wxPauseBackgroundAudio: function() {
        return t(wx.pauseBackgroundAudio);
    },
    wxStopBackgroundAudio: function() {
        return t(wx.stopBackgroundAudio);
    },
    wxGetBackgroundAudioPlayerState: function() {
        return t(wx.getBackgroundAudioPlayerState);
    },
    wxGetShareInfo: function() {
        return t(wx.getShareInfo);
    },
    wxReportAnalytics: function() {
        return t(wx.reportAnalytics);
    }
};