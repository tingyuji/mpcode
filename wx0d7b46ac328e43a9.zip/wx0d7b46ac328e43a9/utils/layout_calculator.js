var e = require("../@babel/runtime/helpers/createForOfIteratorHelper"), t = wx.getSystemInfoSync(), a = parseInt(t.windowWidth / t.screenHeight * 100) < parseInt(9 / 17 * 100) ? 34 : 0, r = t.screenHeight, o = (t.screenWidth, 
t.statusBarHeight);

module.exports = function() {
    var t, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = i.hasTabbar, s = void 0 !== n && n, d = i.hasNavbar, l = void 0 === d || d, h = i.tabBarHeight, v = void 0 === h ? 49 : h, c = i.navBarHeight, f = void 0 === c ? 44 : c, g = i.blockList, u = void 0 === g ? [] : g, b = o + (l ? f : 0), H = (s ? v : 0) + a, p = r - b - H, w = 667 - (20 + f + (s ? v : 0)), y = [], B = e(u);
    try {
        for (B.s(); !(t = B.n()).done; ) {
            var m = t.value;
            p -= m.size, w -= m.size, console.log(p), console.log(w);
        }
    } catch (e) {
        B.e(e);
    } finally {
        B.f();
    }
    var z, I = e(u);
    try {
        for (I.s(); !(z = I.n()).done; ) {
            var k = z.value, x = k.offset / (w / p);
            y.push({
                size: k.size,
                offset: x
            });
        }
    } catch (e) {
        I.e(e);
    } finally {
        I.f();
    }
    return {
        navBarHeight: f,
        tabBarHeight: v,
        windowPaddingTop: b,
        windowPaddingBottom: H,
        blocks: y
    };
};