App({
    onShow: function(a) {
        var e = this;
        wx.getSystemInfo({
            success: function(a) {
                var t = a.screenHeight, l = a.screenWidth, n = a.statusBarHeight;
                e.globalData.isFullScreen = parseInt(l / t * 100) < parseInt(9 / 17 * 100), e.globalData.isBiggerScreen = t > 667, 
                e.globalData.statusBarHeight = n, e.globalData.navBarHeight = 44, e.globalData.navBarFontSize = 18.5, 
                e.globalData.btnScopeSize = 40, e.globalData.btnSize = 32, e.globalData.screenHeight = t, 
                e.globalData.screenWidth = l;
            }
        });
    },
    globalData: {
        isBiggerScreen: !1,
        isFullScreen: !1,
        userInfo: null
    }
});