var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/wxApi");

Component({
    properties: {
        drawData: {
            type: Array,
            observer: function() {
                this.refreshPainter();
            }
        }
    },
    data: {},
    ready: function() {
        this.refreshPainter();
    },
    methods: {
        refreshPainter: function() {
            var a = this;
            return r(e.default.mark(function r() {
                var n, i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!a.data.drawData.length) {
                            e.next = 21;
                            break;
                        }
                        a.ctx = wx.createCanvasContext("painter", a), n = t(a.data.drawData), e.prev = 3, 
                        n.s();

                      case 5:
                        if ((i = n.n()).done) {
                            e.next = 11;
                            break;
                        }
                        return data = i.value, e.next = 9, a.assignPainter(data);

                      case 9:
                        e.next = 5;
                        break;

                      case 11:
                        e.next = 16;
                        break;

                      case 13:
                        e.prev = 13, e.t0 = e.catch(3), n.e(e.t0);

                      case 16:
                        return e.prev = 16, n.f(), e.finish(16);

                      case 19:
                        a.ctx.draw(), wx.canvasToTempFilePath({
                            x: 0,
                            y: 0,
                            width: 1080,
                            height: 1920,
                            destWidth: 1080,
                            destHeight: 1920,
                            canvasId: "painter",
                            success: function(e) {
                                console.log(e), a.triggerEvent("draw", {
                                    tempFilePath: e.tempFilePath
                                });
                            }
                        }, a);

                      case 21:
                      case "end":
                        return e.stop();
                    }
                }, r, null, [ [ 3, 13, 16, 19 ] ]);
            }))();
        },
        assignPainter: function(t) {
            var a = this;
            return r(e.default.mark(function r() {
                var n;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        n = t.type, e.t0 = n, e.next = "image" === e.t0 ? 4 : "text" === e.t0 ? 7 : 10;
                        break;

                      case 4:
                        return e.next = 6, a.drawImage(t);

                      case 6:
                        return e.abrupt("break", 10);

                      case 7:
                        return e.next = 9, a.drawText(t);

                      case 9:
                        return e.abrupt("break", 10);

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        },
        drawImage: function(t) {
            var n = this;
            return r(e.default.mark(function r() {
                var i, s, c, o, u, d, l, f;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return i = t.dx, s = t.dy, c = t.width, o = t.height, u = t.url, d = a.wxDownloadFile(), 
                        e.next = 4, d({
                            url: u
                        });

                      case 4:
                        l = e.sent, f = l.tempFilePath, n.ctx.drawImage(f, i, s, c, o);

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        },
        drawText: function(e) {
            var t = e.color, r = void 0 === t ? "#ffffff" : t, a = e.font, n = void 0 === a ? "arial" : a, i = e.size, s = void 0 === i ? "64px" : i, c = e.weight, o = void 0 === c ? "bold" : c, u = e.style, d = void 0 === u ? "normal" : u, l = e.align, f = void 0 === l ? "left" : l, h = e.baseline, x = void 0 === h ? "top" : h, p = e.dx, v = void 0 === p ? 0 : p, w = e.dy, b = void 0 === w ? 0 : w, g = e.content, m = void 0 === g ? "" : g;
            console.log(v, b, m), this.ctx.font = "".concat(d, " ").concat(o, " ").concat(s, " ").concat(n), 
            this.ctx.setFillStyle(r), this.ctx.setTextAlign(f), this.ctx.setTextBaseline(x), 
            this.ctx.fillText(m, v, b);
        }
    }
});