var e = require("../../@babel/runtime/helpers/defineProperty"), a = getApp();

Component(e({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        default: {
            type: Number,
            value: 0
        }
    },
    data: {
        isFullScreen: a.globalData.isFullScreen,
        options: [ {
            value: 0,
            name: "无限"
        }, {
            value: 5,
            name: "05"
        }, {
            value: 10,
            name: "10"
        }, {
            value: 15,
            name: "15"
        }, {
            value: 20,
            name: "20"
        }, {
            value: 25,
            name: "25"
        }, {
            value: 30,
            name: "30"
        }, {
            value: 35,
            name: "35"
        }, {
            value: 40,
            name: "40"
        }, {
            value: 45,
            name: "45"
        }, {
            value: 50,
            name: "50"
        }, {
            value: 55,
            name: "55"
        }, {
            value: 60,
            name: "60"
        }, {
            value: 90,
            name: "90"
        }, {
            value: 120,
            name: "120"
        }, {
            value: 0,
            name: "无限"
        } ],
        value: [ 0 ]
    },
    ready: function() {},
    methods: {
        change: function(e) {
            var a = e.detail.value;
            this.setData({
                value: a
            }), this.selectBuffer && this.select();
        },
        select: function() {
            var e = this, a = this.data, t = a.value, n = a.options[t].value;
            this.triggerEvent("selectd", {
                duration: 60 * n
            }), this.selectBuffer = setTimeout(function() {
                clearTimeout(e.selectBuffer), e.selectBuffer = null;
            }, 2e3);
        },
        cancel: function() {
            this.triggerEvent("hide");
        }
    }
}, "ready", function() {
    var e = this.data.default / 60, a = this.data.options.findIndex(function(a) {
        return a.value === e;
    });
    this.setData({
        value: [ a ]
    });
}));