var t = require("../../utils/layout_calculator"), e = require("../../utils/event");

Component({
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        }
    },
    data: {
        layout: t(),
        show: !1
    },
    methods: {
        close: function() {
            this.setData({
                show: !1
            }), wx.setStorage({
                key: "guide-collection",
                data: !0
            });
        },
        show: function() {
            var t = wx.getStorageSync("guide-collection");
            this.setData({
                show: !t
            });
        }
    },
    ready: function() {
        var t = this;
        e.on("showCollectionGuide", this, function() {
            t.show();
        });
    }
});