var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/event.js"), a = require("../../utils/wxRequest"), n = getApp();

Component({
    externalClasses: [ "ex-class" ],
    properties: {
        theme: {
            type: String
        },
        exStyle: {
            type: String
        }
    },
    data: {
        enable: !1
    },
    ready: function() {
        this.setData({
            enable: "1" === wx.getStorageSync("subscribeStatus")
        }), r.on("subscribeStatusChange", this, function(e) {
            var t = "enable" === e.status;
            this.setData({
                enable: t
            }), wx.setStorageSync("subscribeStatus", t ? "1" : "0");
        });
    },
    detached: function() {
        r.remove("subscribeStatusChange", this);
    },
    methods: {
        onSubmit: function(r) {
            var s = this;
            return t(e.default.mark(function t() {
                var i, u, c;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (i = r.detail, u = i.formId, !s.data.enable || !u) {
                            e.next = 13;
                            break;
                        }
                        return e.next = 5, n.getOpenId();

                      case 5:
                        return c = e.sent, e.prev = 6, e.next = 9, a({
                            url: "/v1/tidesleep/wechatmp_activity",
                            method: "POST",
                            data: {
                                openid: c,
                                form_id: u
                            }
                        });

                      case 9:
                        e.next = 13;
                        break;

                      case 11:
                        e.prev = 11, e.t0 = e.catch(6);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 6, 11 ] ]);
            }))();
        }
    }
});