getApp();

Component({
    externalClasses: [ "icon-close" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.setData({
                    visible: !0
                });
            }
        },
        type: {
            type: String,
            value: "alert"
        },
        title: {
            type: String
        },
        content: {
            type: String
        },
        confirmText: {
            type: String,
            value: "确定"
        },
        confirmColor: {
            type: String,
            value: "rgb(18, 206, 102)"
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        cancelColor: {
            type: String,
            value: "rgba(0, 0, 0, 0.32)"
        }
    },
    data: {
        visible: !1
    },
    ready: function() {},
    methods: {
        onClose: function() {
            console.log("close"), this.setData({
                visible: !1
            }), this.triggerEvent("cancel");
        },
        onConfirm: function() {
            console.log("confirm"), this.setData({
                visible: !1
            }), this.triggerEvent("confirm");
        }
    }
});