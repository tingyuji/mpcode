var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), t = getApp();

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        sceneid: {
            type: String
        }
    },
    data: {
        isFullScreen: t.globalData.isFullScreen
    },
    ready: function() {},
    methods: {
        goPoster: function() {
            this.triggerEvent("hide"), wx.navigateTo({
                url: "/pages/poster/poster"
            });
        },
        cancel: function() {
            this.triggerEvent("hide");
        },
        onGotUserInfoForShare: function(t) {
            var n = this;
            return r(e.default.mark(function r() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        "getUserInfo:ok" === t.detail.errMsg ? n.goPoster() : wx.showModal({
                            title: "用户授权失败",
                            showCancel: !1,
                            content: "需要用户授权才能进行分享"
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        }
    }
});