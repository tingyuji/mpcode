var a = getApp();

Component({
    externalClasses: [ "ex-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        theme: {
            type: String
        },
        darken: {
            type: Boolean,
            value: !1
        },
        hideBtns: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        screenHeight: a.globalData.screenHeight,
        screenWidth: a.globalData.screenWidth,
        statusBarHeight: a.globalData.statusBarHeight,
        navBarHeight: a.globalData.navBarHeight,
        navBarFontSize: a.globalData.navBarFontSize,
        btnScopeSize: a.globalData.btnScopeSize,
        btnSize: a.globalData.btnSize
    },
    ready: function() {},
    methods: {}
});