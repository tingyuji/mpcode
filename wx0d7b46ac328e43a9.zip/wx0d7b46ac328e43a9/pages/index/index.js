var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/slicedToArray"), a = e(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/asyncToGenerator"), s = getApp(), n = require("../../utils/event"), r = require("../../utils/wxApi");

Page({
    data: {
        screenHeight: s.globalData.screenHeight,
        screenWidth: s.globalData.screenWidth,
        statusBarHeight: s.globalData.statusBarHeight,
        navBarHeight: s.globalData.navBarHeight,
        navBarFontSize: s.globalData.navBarFontSize,
        btnScopeSize: s.globalData.btnScopeSize,
        btnSize: s.globalData.btnSize,
        isFullScreen: s.globalData.isFullScreen,
        swing: !1,
        slidedown: !1,
        guide_0_showed: !1,
        guide_1_showed: !1,
        guide_2_showed: !1,
        shareActionsheetVisibility: !1,
        gear: 0,
        deg: 0,
        rpm: 0,
        level: 0,
        tap_count: 0
    },
    sound_1: "https://pics.tide.moreless.io/fan/fan-level-1.mp3",
    sound_2: "https://pics.tide.moreless.io/fan/fan-level-2.mp3",
    sound_3: "https://pics.tide.moreless.io/fan/fan-level-3.mp3",
    onShareAppMessage: function() {
        return {
            title: "送你一只国王的风扇，吹吹看～",
            path: "/pages/index/index",
            imageUrl: "https://pics.tide.moreless.io/fan/forward.png"
        };
    },
    onHide: function() {
        this.setData({
            disableAnimated: !0
        });
    },
    onShow: function() {
        this.setData({
            disableAnimated: !1
        });
    },
    onReady: function() {
        var e = this;
        this.initGuide(), this.tick_0 = wx.createInnerAudioContext(), this.tick_0.src = "/sounds/tick.mp3", 
        this.tick_1 = wx.createInnerAudioContext(), this.tick_1.src = "/sounds/tick.mp3", 
        this.sound = wx.getBackgroundAudioManager(), this.sound.title = "一只风扇", this.sound.onTimeUpdate(function() {
            if (e.duration_at) {
                var t = new Date(), a = t - e.duration_at;
                if (a > 1e3) {
                    e.duration_at = t;
                    var i = wx.getStorageSync("total_duration") || 0;
                    i += a, wx.setStorageSync("total_duration", i);
                }
            }
        }), this.sound.onEnded(function() {
            e.data.level && e.sound.play();
        }), this.sound.coverImgUrl = "https://pics.tide.moreless.io/fan/fan-logo.png", setInterval(function() {
            e.draw();
        }, 6e4);
    },
    onShare: function() {
        this.setData({
            shareActionsheetVisibility: !0
        });
    },
    hideShareActionSheet: function() {
        this.setData({
            shareActionsheetVisibility: !1
        });
    },
    initGuide: function() {
        var e = this;
        return i(a.default.mark(function t() {
            var i;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = r.wxGetStorage(), t.prev = 1, t.next = 4, i({
                        key: "guide_0_showed"
                    });

                  case 4:
                    e.setData({
                        guide_0_showed: !0
                    }), t.next = 9;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(1);

                  case 9:
                    return t.prev = 9, t.next = 12, i({
                        key: "guide_1_showed"
                    });

                  case 12:
                    e.setData({
                        guide_1_showed: !0
                    }), t.next = 17;
                    break;

                  case 15:
                    t.prev = 15, t.t1 = t.catch(9);

                  case 17:
                    return t.prev = 17, t.next = 20, i({
                        key: "guide_2_showed"
                    });

                  case 20:
                    e.setData({
                        guide_2_showed: !0
                    }), t.next = 25;
                    break;

                  case 23:
                    t.prev = 23, t.t2 = t.catch(17);

                  case 25:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 7 ], [ 9, 15 ], [ 17, 23 ] ]);
        }))();
    },
    onSpeedUp: function(e, a) {
        var i = this;
        n.emit("showCollectionGuide"), clearTimeout(this.transitionHandle);
        var s = this.data.speedDirection, r = 6e4;
        if (s) {
            var o = s.split("-"), d = t(o, 2), u = d[0], c = d[1];
            r = "up" === u ? 2e3 : 1e3 * c - 100;
        }
        var l, h = this.data.rpm / 60, p = this.start_at, g = +new Date();
        this.start_at = g, 0 === this.data.rpm ? (0, l = 0) : l = r - (g - p);
        var _ = l / 1e3 * 360 * h;
        this.setData({
            deg: this.data.deg - _ + e / 60 * 360,
            rpm: e,
            speedDirection: "up-".concat(a)
        }), this.transitionHandle = setTimeout(function() {
            i.start_at = +new Date(), i.setData({
                speedDirection: ""
            }), i.draw();
        }, 900);
    },
    onSpeedDown: function(e, a) {
        var i = this;
        clearTimeout(this.transitionHandle);
        var s = this.data.speedDirection, n = 6e4;
        if (s) {
            var r = s.split("-"), o = t(r, 2), d = o[0], u = o[1];
            n = "up" === d ? 2e3 : 1e3 * u - 100;
        }
        var c, l = this.data.rpm / 60, h = this.start_at, p = +new Date();
        this.start_at = p, 0 === this.data.rpm ? (0, c = 0) : c = n - (p - h);
        var g = c / 1e3 * 360 * l;
        this.setData({
            deg: this.data.deg - g + 360 * l,
            rpm: e,
            speedDirection: "down-".concat(a)
        }), this.transitionHandle = setTimeout(function() {
            i.start_at = +new Date(), i.setData({
                speedDirection: ""
            }), i.draw();
        }, 1e3 * a - 100);
    },
    onTapDoll: function(e) {
        var t = this;
        this.setData({
            swing: !0,
            slidedown: !this.data.slidedown,
            guide_0_showed: !0
        }), wx.setStorage({
            key: "guide_0_showed",
            data: "true"
        }), setTimeout(function() {
            t.setData({
                swing: !t.data.swing
            });
        }, 300);
    },
    closeChutters: function() {
        this.setData({
            swing: !0,
            slidedown: !this.data.slidedown,
            guide_0_showed: !0
        });
    },
    changeLevel: function(e) {
        var t = this;
        return i(a.default.mark(function i() {
            var s, n;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (0 === (s = parseInt(e.currentTarget.dataset.level)) || s !== t.data.level) {
                        a.next = 3;
                        break;
                    }
                    return a.abrupt("return");

                  case 3:
                    s !== t.data.level && (wx.vibrateShort(), t.tick ? (t.tick = 0, t.tick_0.seek = 0, 
                    t.tick_0.play()) : (t.tick = 1, t.tick_1.seek = 0)), n = 0, a.t0 = s, a.next = 1 === a.t0 ? 8 : 2 === a.t0 ? 10 : 3 === a.t0 ? 12 : 14;
                    break;

                  case 8:
                    return n = 300, a.abrupt("break", 14);

                  case 10:
                    return n = 700, a.abrupt("break", 14);

                  case 12:
                    return n = 1e3, a.abrupt("break", 14);

                  case 14:
                    s ? (t.duration_at = +new Date(), t["sound_".concat(s)] && (t.sound.src = t["sound_".concat(s)], 
                    t.sound.title = "一只风扇", t.sound.play())) : (t.tick_0.play(), t.sound.stop(), t.duration_at = null), 
                    s < t.data.level ? t.onSpeedDown(n, t.data.level - s) : s > t.data.level && t.onSpeedUp(n, s - t.data.level), 
                    t.setData({
                        level: s
                    });

                  case 17:
                  case "end":
                    return a.stop();
                }
            }, i);
        }))();
    },
    setGuide: function(e) {
        var t = e.currentTarget.dataset.guideType, a = 0, i = {};
        if (a = "1" === t ? this.data.tap_count + 1 : 0, i.tap_count = a, a >= 3) i.guide_1_showed = !1, 
        i.guide_2_showed = !1; else {
            var s = "guide_".concat(t, "_showed");
            wx.setStorage({
                key: s,
                data: "true"
            }), i.guide_1_showed = !0, i.guide_2_showed = !0;
        }
        this.setData(i);
    },
    draw: function() {
        if (this.start_at = +new Date(), this.data.rpm) {
            var e = 360 * this.data.rpm;
            this.setData({
                deg: this.data.deg + e
            });
        }
    }
});