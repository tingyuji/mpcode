var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), e = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), i = require("../../utils/wxApi"), n = require("../../utils/base64.min.js").Base64;

Page({
    onShareAppMessage: function() {
        return {
            title: "送你一只国王的风扇，吹吹看～",
            path: "/pages/index/index",
            imageUrl: "https://pics.tide.moreless.io/fan/forward.png"
        };
    },
    data: {
        authed: !1,
        loadFail: !1,
        picPath: "",
        drawData: [],
        screenHeight: a.globalData.screenHeight,
        screenWidth: a.globalData.screenWidth,
        statusBarHeight: a.globalData.statusBarHeight,
        navBarHeight: a.globalData.navBarHeight,
        isFullScreen: a.globalData.isFullScreen
    },
    init: function() {
        var a = this;
        return e(t.default.mark(function e() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    a.checkAuth(function(t) {
                        a.setData({
                            authed: t
                        });
                    }), a.initPoster();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    },
    initPoster: function() {
        var a = this;
        return e(t.default.mark(function e() {
            var o, r, s, c, l, h, u, d, g;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = i.wxGetUserInfo(), r = i.wxGetStorage(), s = 0, c = 0, l = 0, t.next = 7, 
                    o();

                  case 7:
                    return h = t.sent, u = h.userInfo, t.prev = 9, t.next = 12, r({
                        key: "total_duration"
                    });

                  case 12:
                    d = t.sent, s = d.data, t.next = 18;
                    break;

                  case 16:
                    t.prev = 16, t.t0 = t.catch(9);

                  case 18:
                    s && (c = parseInt(1.08 * (s / 36e5) * 785), x = void 0, x = 4 - (w = 1) + 1, l = Math.floor(Math.random() * x + w)), 
                    g = {
                        base_image_url: "https://pics.tide.moreless.io/fan/share_base_pic.png",
                        carbon: c,
                        duration: s,
                        cool: l,
                        nickname: u.nickName,
                        avatar: (e = {
                            url: u.avatarUrl
                        }, p = void 0, f = void 0, p = e.url, f = n.encodeURI(p), "".concat("https://pics.tide.moreless.io/fan/share_base_avatar.png", "?watermark/3/image/").concat(f, "/gravity/Center/dx/0/dy/0/ws/0"))
                    }, a.draw(g);

                  case 21:
                  case "end":
                    return t.stop();
                }
                var e, p, f, w, x;
            }, e, null, [ [ 9, 16 ] ]);
        }))();
    },
    draw: function(t) {
        var e = t.base_image_url, a = t.carbon, i = t.duration, n = t.cool, o = t.nickname, r = t.avatar, s = [], c = "".concat(a, " 克");
        a >= 1e3 && (c = "".concat((a /= 1e3).toFixed(1), " 千克"));
        var l = parseInt(i / 1e3), h = "".concat(l, " 秒");
        h = l >= 5400 ? "".concat(Math.ceil(l / 360) / 10, " 小时") : "".concat(Math.ceil(l / 60), " 分钟"), 
        s.push({
            type: "image",
            url: e,
            width: 1080,
            height: 1920,
            dx: 0,
            dy: 0
        }), s.push({
            type: "text",
            font: "arial",
            color: "#7E7E7D",
            size: "48px",
            weight: "bold",
            align: "center",
            italic: !1,
            dx: 290,
            dy: 305,
            maxWidth: 0,
            content: c
        }), s.push({
            type: "text",
            font: "arial",
            color: "#2F3030",
            size: "72px",
            weight: "bold",
            align: "center",
            italic: !1,
            dx: 832.5,
            dy: 348,
            maxWidth: 0,
            content: h
        }), s.push({
            type: "text",
            font: "arial",
            color: "#515658",
            size: "64px",
            weight: "bold",
            align: "center",
            italic: !1,
            dx: 245,
            dy: 1312,
            maxWidth: 0,
            content: "".concat(n, " 度")
        }), s.push({
            type: "image",
            url: r,
            width: 120,
            height: 120,
            dx: 80,
            dy: 1670
        }), s.push({
            type: "text",
            font: "arial",
            color: "#000000",
            size: "40px",
            weight: "bold",
            align: "left",
            italic: !1,
            dx: 232,
            dy: 1674,
            maxWidth: 0,
            content: o
        }), this.setData({
            drawData: s
        });
    },
    onDraw: function(t) {
        var e = t.detail;
        console.log(e.tempFilePath), wx.hideLoading(), this.setData({
            picPath: e.tempFilePath
        });
    },
    askRetry: function() {
        var t = this;
        wx.hideLoading(), wx.showModal({
            title: "海报生成失败",
            content: "是否重试？",
            confirmText: "确定",
            showCancel: !0,
            success: function(e) {
                e.confirm ? t.init() : e.cancel && t.gohome();
            }
        });
    },
    gohome: function() {
        wx.navigateBack();
    },
    onImageLoad: function() {
        wx.hideLoading();
    },
    onImageLoadFail: function() {
        this.askRetry();
    },
    onOpensetting: function(t) {
        var e = t.detail;
        e.authSetting["scope.writePhotosAlbum"] || void 0 === e.authSetting["scope.writePhotosAlbum"] ? (this.setData({
            authed: !0
        }), this.save()) : wx.showModal({
            title: "需要打开保存到相册的权限",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#000"
        });
    },
    checkAuth: function(t) {
        wx.getSetting({
            fail: function(e) {
                t(!1);
            },
            success: function(e) {
                e.authSetting["scope.writePhotosAlbum"] || void 0 === e.authSetting["scope.writePhotosAlbum"] ? t(!0) : t(!1);
            }
        });
    },
    save: function() {
        var t = this;
        this.checkAuth(function(e) {
            e && (wx.showLoading({
                mask: !0,
                title: "正在生成海报"
            }), wx.saveImageToPhotosAlbum({
                filePath: t.data.picPath,
                fail: function(e) {
                    wx.hideLoading(), "saveImageToPhotosAlbum:fail auth deny" === e.errMsg ? (t.setData({
                        authed: !1
                    }), wx.showModal({
                        title: "未能保存",
                        content: "需要打开保存到相册的权限",
                        confirmText: "确定",
                        showCancel: !1
                    })) : wx.showModal({
                        title: "未能保存",
                        content: "保存到系统相册时失败",
                        confirmText: "确定",
                        showCancel: !1
                    });
                },
                success: function() {
                    wx.hideLoading(), wx.showModal({
                        title: "你的风扇已存放到系统相册",
                        content: "快去分享给朋友们，让他们也凉快一下吧～",
                        confirmText: "我知道了",
                        showCancel: !1
                    });
                }
            }));
        });
    },
    preview: function() {
        i.wxPreviewImage()({
            urls: [ this.data.picPath ]
        });
    },
    onLoad: function(t) {
        wx.showLoading({
            mask: !0
        }), this.init();
    }
});