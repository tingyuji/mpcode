(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "21e9": function(e, t, n) {},
    "23be": function(e, t, n) {
        n.r(t);
        var o = n("e4a4"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    "3dfd": function(e, t, n) {
        n.r(t);
        var o = n("23be");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("5c0b");
        var r = n("f0c5"), u = Object(r.a)(o.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = u.exports;
    },
    "56d7": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0, n("6cdc");
            var o = c(n("66fd")), a = c(n("3dfd")), r = c(n("4360")), u = c(n("813e"));
            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function i(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function f(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            o.default.use(u.default), o.default.prototype.$store = r.default, o.default.config.productionTip = !1, 
            a.default.mpType = "app";
            var l = new o.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach(function(t) {
                        f(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({
                store: r.default
            }, a.default));
            e(l).$mount();
            var d = l;
            t.default = d;
        }).call(this, n("543d").createApp);
    },
    "5c0b": function(e, t, n) {
        var o = n("21e9");
        n.n(o).a;
    },
    e4a4: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("c24f"));
            var a = {
                onLaunch: function() {
                    var t = this, n = e.getStorageSync("token");
                    n && (e.showLoading({
                        mask: !0,
                        title: "加载中..."
                    }), console.log(n), o.default.get().then(function(n) {
                        var o = n.data.data.userinfo;
                        o.login = !0, t.$store.commit("login", o), e.switchTab({
                            url: "../home/index"
                        });
                    }).catch(function(t) {
                        e.showToast({
                            title: t.message || "系统错误",
                            icon: "none"
                        });
                    }).finally(function() {
                        e.hideLoading();
                    }));
                    var a = wx.getUpdateManager();
                    a.onCheckForUpdate(function(e) {
                        e.hasUpdate;
                    }), a.onUpdateReady(function() {
                        wx.showModal({
                            title: "更新检测",
                            content: "检测到新版本，是否重启小程序？",
                            success: function(e) {
                                e.confirm && a.applyUpdate();
                            }
                        });
                    }), a.onUpdateFailed(function() {
                        wx.showModal({
                            title: "更新提示",
                            content: "新版本下载失败",
                            showCancel: !1
                        });
                    });
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    }
}, [ [ "56d7", "common/runtime", "common/vendor" ] ] ]);