(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coures/lostarticle/lostarticle" ], {
    "11c5": function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(e("caa4"));
            var o = {
                components: {
                    jwHeader: function() {
                        e.e("components/jw-header/jw-header").then(function() {
                            return resolve(e("ef83"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        list: [],
                        isMaxBottom: !1,
                        refreshType: "custom",
                        refreshTip: "正在下拉",
                        loadTip: "获取更多数据",
                        loadingTip: "正在加载中...",
                        emptyTip: "-没有更多数据了-",
                        touchHeight: 50,
                        height: 0,
                        bottom: 50,
                        autoPullUp: !0,
                        stopPullDown: !0,
                        page: 1,
                        count: 1,
                        limit: 10
                    };
                },
                onLoad: function() {
                    this.fetchList(!0);
                },
                methods: {
                    fetchList: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
                        n && (this.list = [], this.page = 1, this.count = 0, this.isMaxBottom = !1), i.default.lostarticleList(this.page, this.limit).then(function(t) {
                            var n = t.data;
                            n.code > 0 && (n.data.list.forEach(function(t) {
                                t.content = t.content.replace(/<img/gi, '<img mode="widthFix"'), e.list.push(t);
                            }), e.page++, e.count = n.data.count, e.count > (e.page - 1) * e.limit && (e.isMaxBottom = !0));
                        }).catch(function(n) {
                            return t.showToast({
                                title: "发生了一点问题",
                                icon: "none"
                            });
                        });
                    },
                    toDetail: function(n) {
                        t.setStorage({
                            key: "lost-detail",
                            data: n,
                            success: function() {
                                t.navigateTo({
                                    url: "./detail",
                                    animationType: "slide-in-bottom"
                                });
                            }
                        });
                    },
                    handlePullDown: function(t) {
                        this.fetchList(!0), t && t();
                    },
                    handleLoadMore: function(t) {
                        this.list.length < this.count ? (this.fetchList(), t && t()) : t && t({
                            isEnd: !0
                        });
                    }
                }
            };
            n.default = o;
        }).call(this, e("543d").default);
    },
    "3a80": function(t, n, e) {
        e.r(n);
        var i = e("5da9"), o = e("a2e1");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("9e12");
        var u = e("f0c5"), c = Object(u.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        n.default = c.exports;
    },
    "5da9": function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            uEmpty: function() {
                return e.e("uview-ui/components/u-empty/u-empty").then(e.bind(null, "65ec"));
            }
        }, o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    7427: function(t, n, e) {},
    "9e12": function(t, n, e) {
        var i = e("7427");
        e.n(i).a;
    },
    a2e1: function(t, n, e) {
        e.r(n);
        var i = e("11c5"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        n.default = o.a;
    },
    fca7: function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), n(e("66fd")), t(n(e("3a80")).default);
        }).call(this, e("543d").createPage);
    }
}, [ [ "fca7", "common/runtime", "common/vendor" ] ] ]);