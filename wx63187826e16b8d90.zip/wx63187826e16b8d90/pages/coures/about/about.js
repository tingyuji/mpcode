(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coures/about/about" ], {
    "2acb": function(e, t, n) {},
    "2e64": function(e, t, n) {
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var c = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    "32cb": function(e, t, n) {
        var c = n("2acb");
        n.n(c).a;
    },
    "423d": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = {
            components: {
                jwHeader: function() {
                    n.e("components/jw-header/jw-header").then(function() {
                        return resolve(n("ef83"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    about: "",
                    rule: [ {
                        title: "致学员",
                        selected: !1,
                        content: ""
                    }, {
                        title: "管理规定",
                        selected: !1,
                        content: ""
                    }, {
                        title: "管理规定",
                        selected: !1,
                        content: ""
                    }, {
                        title: "管理规定",
                        selected: !1,
                        content: ""
                    } ]
                };
            },
            onLoad: function() {
                this.rule = this.$store.state.base.rule;
                var e = this.rule.find(function(e) {
                    return "致学员" == e.title;
                });
                this.changeTab(e);
            },
            methods: {
                changeTab: function(e) {
                    this.rule.forEach(function(e) {
                        e.selected = !1;
                    }), e.selected = !0, this.about = e.content;
                }
            }
        };
        t.default = c;
    },
    4955: function(e, t, n) {
        n.r(t);
        var c = n("423d"), o = n.n(c);
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(u);
        t.default = o.a;
    },
    "640a": function(e, t, n) {
        n.r(t);
        var c = n("2e64"), o = n("4955");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(u);
        n("32cb");
        var a = n("f0c5"), i = Object(a.a)(o.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        t.default = i.exports;
    },
    "68bd": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("6cdc"), t(n("66fd")), e(t(n("640a")).default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "68bd", "common/runtime", "common/vendor" ] ] ]);