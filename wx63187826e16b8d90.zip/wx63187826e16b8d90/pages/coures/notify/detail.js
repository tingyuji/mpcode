(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coures/notify/detail" ], {
    "367f": function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("6cdc"), e(t("66fd")), n(e(t("576b")).default);
        }).call(this, t("543d").createPage);
    },
    "576b": function(n, e, t) {
        t.r(e);
        var o = t("9f5d"), a = t("7b45");
        for (var f in a) [ "default" ].indexOf(f) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(f);
        t("90e7");
        var u = t("f0c5"), i = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = i.exports;
    },
    "7b45": function(n, e, t) {
        t.r(e);
        var o = t("eb30"), a = t.n(o);
        for (var f in o) [ "default" ].indexOf(f) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(f);
        e.default = a.a;
    },
    "90e7": function(n, e, t) {
        var o = t("a963");
        t.n(o).a;
    },
    "9f5d": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    a963: function(n, e, t) {},
    eb30: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = {
                components: {
                    jwHeader: function() {
                        t.e("components/jw-header/jw-header").then(function() {
                            return resolve(t("ef83"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        notifyDetail: {
                            title: "",
                            createtime: "",
                            content: ""
                        }
                    };
                },
                onLoad: function() {
                    this.notifyDetail = n.getStorageSync("notify-detail"), n.removeStorageSync("notify-detail");
                }
            };
            e.default = o;
        }).call(this, t("543d").default);
    }
}, [ [ "367f", "common/runtime", "common/vendor" ] ] ]);