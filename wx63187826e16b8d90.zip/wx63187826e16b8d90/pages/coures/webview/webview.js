(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coures/webview/webview" ], {
    "343f": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        url: ""
                    };
                },
                onLoad: function(t) {
                    var e = this;
                    n.getStorage({
                        key: "webview_params",
                        success: function(n) {
                            e.url = n.data.url, e.title = n.data.title || "", console.log(n);
                        }
                    });
                }
            };
            t.default = e;
        }).call(this, e("543d").default);
    },
    a132: function(n, t, e) {
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    a225: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("6cdc"), t(e("66fd")), n(t(e("f6f2")).default);
        }).call(this, e("543d").createPage);
    },
    bb65: function(n, t, e) {
        e.r(t);
        var u = e("343f"), a = e.n(u);
        for (var f in u) [ "default" ].indexOf(f) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(f);
        t.default = a.a;
    },
    f6f2: function(n, t, e) {
        e.r(t);
        var u = e("a132"), a = e("bb65");
        for (var f in a) [ "default" ].indexOf(f) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(f);
        var o = e("f0c5"), c = Object(o.a)(a.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        t.default = c.exports;
    }
}, [ [ "a225", "common/runtime", "common/vendor" ] ] ]);