(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/map/map" ], {
    "0b7d": function(t, n, e) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0, function(t) {
            t && t.__esModule;
        }(e("caa4"));
        var a = {
            data: function() {
                return {
                    id: 1,
                    type: 1,
                    info: {
                        menulist: []
                    },
                    scale: 1,
                    url: ""
                };
            },
            onLoad: function(t) {
                t.parent_id && (this.parent_id = t.parent_id), t.type && (this.type = t.type), this.url = this.$store.state.staticUrl + "/index/school/map_preview?id=" + this.id + "&type=" + this.type, 
                console.log(this.url);
            },
            methods: {}
        };
        n.default = a;
    },
    1265: function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "6fdf": function(t, n, e) {
        e.r(n);
        var a = e("0b7d"), i = e.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(u);
        n.default = i.a;
    },
    "85c6": function(t, n, e) {},
    "89ee": function(t, n, e) {
        var a = e("85c6");
        e.n(a).a;
    },
    aa71: function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), n(e("66fd")), t(n(e("cf4e")).default);
        }).call(this, e("543d").createPage);
    },
    cf4e: function(t, n, e) {
        e.r(n);
        var a = e("1265"), i = e("6fdf");
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(u);
        e("89ee");
        var o = e("f0c5"), c = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = c.exports;
    }
}, [ [ "aa71", "common/runtime", "common/vendor" ] ] ]);