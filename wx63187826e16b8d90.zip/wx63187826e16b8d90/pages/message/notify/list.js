(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message/notify/list" ], {
    "05fd": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), n(e("66fd")), t(n(e("a947")).default);
        }).call(this, e("543d").createPage);
    },
    "41b8": function(t, n, e) {
        var i = e("5d51");
        e.n(i).a;
    },
    "5d51": function(t, n, e) {},
    a947: function(t, n, e) {
        e.r(n);
        var i = e("d2c3"), o = e("c169");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(u);
        e("41b8");
        var c = e("f0c5"), a = Object(c.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        n.default = a.exports;
    },
    c169: function(t, n, e) {
        e.r(n);
        var i = e("fddb"), o = e.n(i);
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(u);
        n.default = o.a;
    },
    d2c3: function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return u;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            uEmpty: function() {
                return e.e("uview-ui/components/u-empty/u-empty").then(e.bind(null, "65ec"));
            },
            uCard: function() {
                return e.e("uview-ui/components/u-card/u-card").then(e.bind(null, "2b9b"));
            }
        }, o = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    fddb: function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(e("c443"));
            var o = {
                components: {},
                data: function() {
                    return {
                        refreshType: "custom",
                        refreshTip: "正在下拉",
                        loadTip: "获取更多数据",
                        loadingTip: "正在加载中...",
                        emptyTip: "-没有更多数据了-",
                        touchHeight: 50,
                        height: 0,
                        bottom: 50,
                        autoPullUp: !0,
                        stopPullDown: !0,
                        list: [],
                        page: 1,
                        count: 1,
                        limit: 10
                    };
                },
                onLoad: function() {
                    this.fetchList(!0);
                },
                onPullDownRefresh: function() {
                    this.fetchList(!0), setTimeout(function() {
                        t.stopPullDownRefresh();
                    }, 1200);
                },
                onReachBottom: function() {
                    this.fetchList();
                },
                methods: {
                    handlePullDown: function(t) {
                        this.fetchList(!0), t && t();
                    },
                    handleLoadMore: function(t) {
                        this.list.length < this.count ? (this.fetchList(), t && t()) : t && t({
                            isEnd: !0
                        });
                    },
                    fetchList: function(n) {
                        var e = this;
                        n && (this.list = [], this.page = 1, this.count = 1), i.default.list(this.page, this.limit).then(function(t) {
                            var n = t.data;
                            n.code > 0 && (n.data.list.forEach(function(t) {
                                e.list.push(t);
                            }), e.page++, e.count = n.data.count, e.readed());
                        }).catch(function(n) {
                            return console.log(n), t.showToast({
                                title: "发生了点问题",
                                icon: "none"
                            });
                        });
                    },
                    readed: function() {
                        var t = this;
                        this.$forceUpdate();
                        var n = this;
                        setTimeout(function() {
                            t.list.forEach(function(t) {
                                1 == t.readstatus && i.default.setreadstatus(t.id).then(function(t) {
                                    t.data, n.$state.commit("set_message_unread", 0);
                                }).catch(function(t) {});
                            });
                        }, 300);
                    },
                    toDetail: function(n) {
                        t.navigateTo({
                            url: "./detail?id=" + n
                        });
                    }
                }
            };
            n.default = o;
        }).call(this, e("543d").default);
    }
}, [ [ "05fd", "common/runtime", "common/vendor" ] ] ]);