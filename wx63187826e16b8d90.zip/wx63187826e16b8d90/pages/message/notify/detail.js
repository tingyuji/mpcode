(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message/notify/detail" ], {
    "1d95": function(n, t, e) {
        e.r(t);
        var u = e("cc47"), c = e("f054");
        for (var f in c) [ "default" ].indexOf(f) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(f);
        var a = e("f0c5"), o = Object(a.a)(c.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        t.default = o.exports;
    },
    "38ac": function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("6cdc"), t(e("66fd")), n(t(e("1d95")).default);
        }).call(this, e("543d").createPage);
    },
    3943: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            data: function() {
                return {};
            },
            methods: {}
        };
    },
    cc47: function(n, t, e) {
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    f054: function(n, t, e) {
        e.r(t);
        var u = e("3943"), c = e.n(u);
        for (var f in u) [ "default" ].indexOf(f) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(f);
        t.default = c.a;
    }
}, [ [ "38ac", "common/runtime", "common/vendor" ] ] ]);