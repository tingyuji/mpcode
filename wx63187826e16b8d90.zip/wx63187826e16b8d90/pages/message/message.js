(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/message/message" ], {
    "22af": function(n, t, e) {
        e.r(t);
        var o = e("df8e"), a = e("f508");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(u);
        e("f000");
        var i = e("f0c5"), c = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    2994: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("6cdc"), t(e("66fd")), n(t(e("22af")).default);
        }).call(this, e("543d").createPage);
    },
    7071: function(n, t, e) {},
    "8e51": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("c443"));
            var a = {
                components: {
                    Circle: function() {
                        e.e("pages/components/Circle/index").then(function() {
                            return resolve(e("f21a"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    Gap: function() {
                        e.e("components/Gap/index").then(function() {
                            return resolve(e("acfe"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        list: []
                    };
                },
                onShow: function() {
                    this.fetchGroupList(), o.default.unread_num();
                },
                methods: {
                    onMsgClick: function(t) {
                        switch (t.action) {
                          case "food_detail":
                            n.navigateTo({
                                url: "./food_detail"
                            });
                            break;

                          case "notify_list":
                            n.navigateTo({
                                url: "./notify/list"
                            });
                        }
                    },
                    fetchGroupList: function() {
                        var t = this;
                        o.default.group_list().then(function(n) {
                            var e = n.data;
                            t.list = e.data;
                        }).catch(function(t) {
                            n.showToast({
                                title: t.message || "系统错误",
                                icon: "none"
                            });
                        });
                    }
                }
            };
            t.default = a;
        }).call(this, e("543d").default);
    },
    df8e: function(n, t, e) {
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            uAvatar: function() {
                return e.e("uview-ui/components/u-avatar/u-avatar").then(e.bind(null, "771b"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    f000: function(n, t, e) {
        var o = e("7071");
        e.n(o).a;
    },
    f508: function(n, t, e) {
        e.r(t);
        var o = e("8e51"), a = e.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        t.default = a.a;
    }
}, [ [ "2994", "common/runtime", "common/vendor" ] ] ]);