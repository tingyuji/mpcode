(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/home/bookdir/booklist/bookdetail/index" ], {
    "7dcc": function(n, t, o) {},
    8765: function(n, t, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("6cdc"), t(o("66fd")), n(t(o("a755")).default);
        }).call(this, o("543d").createPage);
    },
    "9f20": function(n, t, o) {
        o.r(t);
        var e = o("fa15"), a = o.n(e);
        for (var i in e) [ "default" ].indexOf(i) < 0 && function(n) {
            o.d(t, n, function() {
                return e[n];
            });
        }(i);
        t.default = a.a;
    },
    a755: function(n, t, o) {
        o.r(t);
        var e = o("ab9f"), a = o("9f20");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            o.d(t, n, function() {
                return a[n];
            });
        }(i);
        o("adbf");
        var u = o("f0c5"), c = Object(u.a)(a.default, e.b, e.c, !1, null, "5bf9bebe", null, !1, e.a, void 0);
        t.default = c.exports;
    },
    ab9f: function(n, t, o) {
        o.d(t, "b", function() {
            return a;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {
            return e;
        });
        var e = {
            Empty: function() {
                return o.e("components/Empty/Empty").then(o.bind(null, "a076"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    adbf: function(n, t, o) {
        var e = o("7dcc");
        o.n(e).a;
    },
    fa15: function(n, t, o) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(o("b067"));
            var a = {
                components: {
                    Empty: function() {
                        o.e("components/Empty/Empty").then(function() {
                            return resolve(o("a076"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        book: null
                    };
                },
                onLoad: function(n) {
                    var t = n.bookid;
                    this.getDetail(t);
                },
                methods: {
                    getDetail: function(t) {
                        var o = this;
                        e.default.getBookInfo(t).then(function(t) {
                            var e = t.data;
                            o.book = e.data, n.setNavigationBarTitle({
                                title: o.book.bookname
                            });
                        }).catch(function(t) {
                            n.showToast(t.message || "查询失败,请稍后再试~");
                        });
                    },
                    onPreview: function() {
                        n.downloadFile({
                            url: this.book.url,
                            success: function(t) {
                                200 == t.statusCode ? n.openDocument({
                                    filePath: t.tempFilePath,
                                    showMenu: !0,
                                    fail: function(t) {
                                        n.showToast({
                                            title: t.message || "打开文件失败, 请稍后再试~",
                                            icon: "none"
                                        });
                                    }
                                }) : n.showToast({
                                    title: "打开文件失败, 网络遇到了问题~",
                                    icon: "none"
                                });
                            },
                            fail: function(t) {
                                n.showToast({
                                    title: t.message || "预览文件失败, 请稍后再试~",
                                    icon: "none"
                                });
                            }
                        });
                    },
                    onDownload: function() {
                        var t = this;
                        n.downloadFile({
                            url: this.book.url,
                            success: function(o) {
                                200 == o.statusCode ? n.getFileSystemManager().saveFile({
                                    tempFilePath: o.tempFilePath,
                                    filePath: wx.env.USER_DATA_PATH + "/" + t.book.bookname + new Date().getTime() + "." + t.book.type,
                                    success: function(t) {
                                        n.showToast({
                                            title: "文档已保存至 " + t.savedFilePath,
                                            icon: "none"
                                        });
                                    },
                                    fail: function(t) {
                                        n.showToast({
                                            title: "下载文档失败, 请稍后再试",
                                            icon: "none"
                                        });
                                    }
                                }) : n.showToast({
                                    title: "下载失败, 网络遇到了问题~",
                                    icon: "none"
                                });
                            },
                            fail: function(t) {
                                n.showToast({
                                    title: t.message || "下载文件失败, 请稍后再试~",
                                    icon: "none"
                                });
                            }
                        });
                    }
                }
            };
            t.default = a;
        }).call(this, o("543d").default);
    }
}, [ [ "8765", "common/runtime", "common/vendor" ] ] ]);