(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/home/bookdir/booklist/index" ], {
    "1cd8": function(t, n, e) {
        var i = e("dc4c");
        e.n(i).a;
    },
    8127: function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), n(e("66fd")), t(n(e("a96d")).default);
        }).call(this, e("543d").createPage);
    },
    "8c68": function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            Empty: function() {
                return e.e("components/Empty/Empty").then(e.bind(null, "a076"));
            }
        }, o = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    "8e82": function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(e("b067"));
            var o = {
                components: {
                    Empty: function() {
                        e.e("components/Empty/Empty").then(function() {
                            return resolve(e("a076"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        page: 1,
                        limit: 20,
                        list: [],
                        more: !0,
                        dirid: 0
                    };
                },
                onLoad: function(n) {
                    this.dirid = n.dirid, n.dirname && t.setNavigationBarTitle({
                        title: n.dirname
                    }), this.fetchList();
                },
                onPullDownRefresh: function() {
                    this.clearList(), this.fetchList().finally(function() {
                        t.stopPullDownRefresh();
                    });
                },
                onReachBottom: function() {
                    this.more && this.fetchList();
                },
                methods: {
                    fetchList: function() {
                        var n = this;
                        return new Promise(function(e, o) {
                            i.default.getBookList(n.dirid, n.page, n.limit).then(function(t) {
                                var i = t.data;
                                n.list = n.list.concat(i.list), n.more = i.more, n.page++, e();
                            }).catch(function(n) {
                                o(n), t.showToast(n.message || "查询失败,请稍后再试~");
                            });
                        });
                    },
                    clearList: function() {
                        this.page = 1, this.list = [], this.more = !0;
                    },
                    onBookClick: function(n) {
                        t.navigateTo({
                            url: "./bookdetail/index?bookid=" + n.id
                        });
                    }
                }
            };
            n.default = o;
        }).call(this, e("543d").default);
    },
    9864: function(t, n, e) {
        e.r(n);
        var i = e("8e82"), o = e.n(i);
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(c);
        n.default = o.a;
    },
    a96d: function(t, n, e) {
        e.r(n);
        var i = e("8c68"), o = e("9864");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        e("1cd8");
        var u = e("f0c5"), a = Object(u.a)(o.default, i.b, i.c, !1, null, "f83876b6", null, !1, i.a, void 0);
        n.default = a.exports;
    },
    dc4c: function(t, n, e) {}
}, [ [ "8127", "common/runtime", "common/vendor" ] ] ]);