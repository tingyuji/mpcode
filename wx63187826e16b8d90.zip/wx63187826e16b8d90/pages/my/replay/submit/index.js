(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/replay/submit/index" ], {
    "0751": function(n, t, o) {
        o.d(t, "b", function() {
            return e;
        }), o.d(t, "c", function() {
            return a;
        }), o.d(t, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "35e2": function(n, t, o) {
        var e = o("5737");
        o.n(e).a;
    },
    5737: function(n, t, o) {},
    "674c": function(n, t, o) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = o("c24f"), a = {
                data: function() {
                    return {
                        formData: {
                            content: "",
                            count: "",
                            trainid: 0
                        }
                    };
                },
                onLoad: function(t) {
                    var o = t.trainid;
                    o ? this.formData.trainid = o : n.showToast({
                        title: "数据异常",
                        icon: "none"
                    });
                },
                methods: {
                    onSubmit: function() {
                        (0, e.doTrainReplay)(this.formData.trainid, this.formData.content, this.formData.count).then(function(t) {
                            var o = t.data;
                            if (1 != o.code) throw new Error(o.msg);
                            n.showToast({
                                title: "提交成功",
                                icon: "success"
                            }), setTimeout(function() {
                                n.navigateBack();
                            }, 1200);
                        }).catch(function(t) {
                            n.showToast({
                                title: t.message || "提交失败, 请稍后再试",
                                icon: "none"
                            });
                        });
                    }
                }
            };
            t.default = a;
        }).call(this, o("543d").default);
    },
    7851: function(n, t, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("6cdc"), t(o("66fd")), n(t(o("b61c")).default);
        }).call(this, o("543d").createPage);
    },
    "99e1": function(n, t, o) {},
    b61c: function(n, t, o) {
        o.r(t);
        var e = o("0751"), a = o("d35c");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            o.d(t, n, function() {
                return a[n];
            });
        }(i);
        o("35e2"), o("fe41");
        var c = o("f0c5"), u = Object(c.a)(a.default, e.b, e.c, !1, null, "7e8080be", null, !1, e.a, void 0);
        t.default = u.exports;
    },
    d35c: function(n, t, o) {
        o.r(t);
        var e = o("674c"), a = o.n(e);
        for (var i in e) [ "default" ].indexOf(i) < 0 && function(n) {
            o.d(t, n, function() {
                return e[n];
            });
        }(i);
        t.default = a.a;
    },
    fe41: function(n, t, o) {
        var e = o("99e1");
        o.n(e).a;
    }
}, [ [ "7851", "common/runtime", "common/vendor" ] ] ]);