var n = require("../../@babel/runtime/helpers/typeof");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/index" ], {
    "03ef": function(n, e, t) {
        t.r(e);
        var o = t("b72f"), c = t("6882");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(r);
        t("6285");
        var i = t("f0c5"), a = Object(i.a)(c.default, o.b, o.c, !1, null, "2d4c4d5a", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    "59df": function(e, t, o) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = u(o("554c")), r = u(o("caa4")), i = u(o("c24f")), a = u(o("c443"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function s(e) {
                return (s = "function" == typeof Symbol && "symbol" === n(Symbol.iterator) ? function(e) {
                    return n(e);
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : n(e);
                })(e);
            }
            function l(n, e) {
                var t = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function f(n, e, t) {
                return e in n ? Object.defineProperty(n, e, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[e] = t, n;
            }
            var d = {
                components: {
                    MainContent: function() {
                        o.e("pages/my/components/MainContent/index").then(function() {
                            return resolve(o("4c82"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Circle: function() {
                        o.e("pages/components/Circle/index").then(function() {
                            return resolve(o("f21a"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    LinkContainer: function() {
                        o.e("pages/components/LinkContainer/index").then(function() {
                            return resolve(o("9174"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    LinkItem: function() {
                        o.e("pages/components/LinkContainer/LinkItem/index").then(function() {
                            return resolve(o("411d"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    UserProfile: function() {
                        o.e("pages/my/components/UserProfile/index").then(function() {
                            return resolve(o("b6a7"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Gap: function() {
                        o.e("components/Gap/index").then(function() {
                            return resolve(o("acfe"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                computed: function(n) {
                    for (var e = 1; e < arguments.length; e++) {
                        var t = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? l(Object(t), !0).forEach(function(e) {
                            f(n, e, t[e]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach(function(e) {
                            Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(t, e));
                        });
                    }
                    return n;
                }({}, (0, o("2f62").mapState)([ "base" ])),
                data: function() {
                    return {};
                },
                onShow: function() {
                    this.loadUserinfo(), a.default.unread_num();
                },
                methods: {
                    loadUserinfo: function() {
                        var n = this;
                        i.default.get().then(function(e) {
                            var t = e.data.data.userinfo;
                            t.login = !0, n.$store.commit("login", t);
                        }).catch(function(n) {
                            e.showToast({
                                title: n.message || "加载失败",
                                icon: "none"
                            });
                        });
                    },
                    scanActionSign: function(n) {
                        e.getLocation({
                            type: "gcj02",
                            geocode: !0,
                            success: function(t) {
                                t.address, n = Object.assign(n, {
                                    submit: {
                                        lat: t.latitude,
                                        lng: t.longitude,
                                        address: t.address
                                    }
                                }), r.default.scanCode(n).then(function(n) {
                                    var t = n.data;
                                    if (!(t.code > 0)) throw new Error(t.msg);
                                    e.showToast({
                                        title: "签到成功",
                                        icon: "success"
                                    });
                                }).catch(function(n) {
                                    e.showModal({
                                        title: "签到失败",
                                        content: n.message,
                                        showCancel: !1
                                    });
                                });
                            },
                            fail: function(n) {
                                e.showModal({
                                    content: "获取位置失败，请打开定位",
                                    showCancel: !1
                                });
                            }
                        });
                    },
                    actionClear: function() {
                        if (null == this.$store.state.userInfo.room_nu) return e.showModal({
                            content: "您暂时还没有预定到房间",
                            showCancel: !1
                        });
                        c.default.actionClear(this.$store.state.userInfo.room_nu);
                    },
                    actionXuzhuBoxShow: function() {
                        if (null == this.$store.state.userInfo.room_nu) return e.showModal({
                            content: "您暂时还没有预定到房间",
                            showCancel: !1
                        });
                        e.navigateTo({
                            url: "../hotel/xuzhu/xuzhu",
                            animationType: "slide-in-bottom"
                        });
                    },
                    onScanCode: function() {
                        var n = this;
                        e.scanCode({
                            onlyFromCamera: !0,
                            scanType: [ "qrCode" ],
                            success: function(t) {
                                t.scanType;
                                var o = t.result;
                                if ("object" != s(JSON.parse(o))) return e.showModal({
                                    content: "不支持的二维码",
                                    showCancel: !1
                                });
                                var c = JSON.parse(o);
                                if ("course_sign" != c.call) return e.showModal({
                                    content: "不支持的二维码",
                                    showCancel: !1
                                });
                                n.scanActionSign(c);
                            }
                        });
                    },
                    toFoodList: function() {
                        e.navigateTo({
                            url: "../message/food_detail"
                        });
                    },
                    toSwzl: function() {
                        e.navigateTo({
                            url: "../coures/lostarticle/lostarticle"
                        });
                    },
                    toReplay: function() {
                        e.navigateTo({
                            url: "./replay/index"
                        });
                    },
                    toCert: function() {
                        e.navigateTo({
                            url: "./certificate/index"
                        });
                    },
                    logout: function() {
                        var n = this;
                        e.showModal({
                            content: "确认要注销吗？",
                            success: function(e) {
                                e.confirm && n.$store.commit("logout");
                            }
                        });
                    }
                }
            };
            t.default = d;
        }).call(this, o("543d").default);
    },
    6285: function(n, e, t) {
        var o = t("c0ec");
        t.n(o).a;
    },
    6882: function(n, e, t) {
        t.r(e);
        var o = t("59df"), c = t.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(r);
        e.default = c.a;
    },
    a46a: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("6cdc"), e(t("66fd")), n(e(t("03ef")).default);
        }).call(this, t("543d").createPage);
    },
    b72f: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    c0ec: function(n, e, t) {}
}, [ [ "a46a", "common/runtime", "common/vendor" ] ] ]);