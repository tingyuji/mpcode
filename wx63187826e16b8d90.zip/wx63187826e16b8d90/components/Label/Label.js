(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Label/Label" ], {
    "146f": function(n, e, t) {
        t.r(e);
        var a = t("b1bb"), o = t("ad27");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        t("8a87");
        var u = t("f0c5"), f = Object(u.a)(o.default, a.b, a.c, !1, null, "5530edea", null, !1, a.a, void 0);
        e.default = f.exports;
    },
    5554: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            data: function() {
                return {};
            },
            props: {
                value: String,
                type: {
                    type: String,
                    default: "default"
                }
            }
        };
        e.default = a;
    },
    "7b0b": function(n, e, t) {},
    "8a87": function(n, e, t) {
        var a = t("7b0b");
        t.n(a).a;
    },
    ad27: function(n, e, t) {
        t.r(e);
        var a = t("5554"), o = t.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        e.default = o.a;
    },
    b1bb: function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Label/Label-create-component", {
    "components/Label/Label-create-component": function(n, e, t) {
        t("543d").createComponent(t("146f"));
    }
}, [ [ "components/Label/Label-create-component" ] ] ]);