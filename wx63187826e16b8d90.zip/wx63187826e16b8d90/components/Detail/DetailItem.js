(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Detail/DetailItem" ], {
    "0ec6": function(e, n, t) {
        t.r(n);
        var o = t("55b6"), a = t("5253");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(c);
        t("38cd");
        var i = t("f0c5"), l = Object(i.a)(a.default, o.b, o.c, !1, null, "3094435d", null, !1, o.a, void 0);
        n.default = l.exports;
    },
    "38cd": function(e, n, t) {
        var o = t("5b14");
        t.n(o).a;
    },
    5253: function(e, n, t) {
        t.r(n);
        var o = t("c774"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = a.a;
    },
    "55b6": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "5b14": function(e, n, t) {},
    c774: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = {
            name: "detail-item",
            props: {
                label: String
            }
        };
        n.default = o;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Detail/DetailItem-create-component", {
    "components/Detail/DetailItem-create-component": function(e, n, t) {
        t("543d").createComponent(t("0ec6"));
    }
}, [ [ "components/Detail/DetailItem-create-component" ] ] ]);