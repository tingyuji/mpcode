(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Detail/Detail" ], {
    "0c87": function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    2986: function(n, e, t) {
        t.r(e);
        var a = t("0c87"), o = t("c660");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        t("d537");
        var u = t("f0c5"), i = Object(u.a)(o.default, a.b, a.c, !1, null, "6179484c", null, !1, a.a, void 0);
        e.default = i.exports;
    },
    5439: function(n, e, t) {},
    ac3f: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            name: "detail",
            props: {
                labelWidth: {
                    type: Number,
                    default: 120
                }
            },
            data: function() {
                return {};
            }
        };
        e.default = a;
    },
    c660: function(n, e, t) {
        t.r(e);
        var a = t("ac3f"), o = t.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        e.default = o.a;
    },
    d537: function(n, e, t) {
        var a = t("5439");
        t.n(a).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Detail/Detail-create-component", {
    "components/Detail/Detail-create-component": function(n, e, t) {
        t("543d").createComponent(t("2986"));
    }
}, [ [ "components/Detail/Detail-create-component" ] ] ]);