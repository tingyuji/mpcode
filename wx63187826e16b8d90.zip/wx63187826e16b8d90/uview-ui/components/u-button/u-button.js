(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uview-ui/components/u-button/u-button" ], {
    "2c1b": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                name: "u-button",
                props: {
                    hairLine: {
                        type: Boolean,
                        default: !0
                    },
                    type: {
                        type: String,
                        default: "default"
                    },
                    size: {
                        type: String,
                        default: "default"
                    },
                    shape: {
                        type: String,
                        default: "square"
                    },
                    plain: {
                        type: Boolean,
                        default: !1
                    },
                    disabled: {
                        type: Boolean,
                        default: !1
                    },
                    loading: {
                        type: Boolean,
                        default: !1
                    },
                    openType: {
                        type: String,
                        default: ""
                    },
                    formType: {
                        type: String,
                        default: ""
                    },
                    appParameter: {
                        type: String,
                        default: ""
                    },
                    hoverStopPropagation: {
                        type: Boolean,
                        default: !1
                    },
                    lang: {
                        type: String,
                        default: "en"
                    },
                    sessionFrom: {
                        type: String,
                        default: ""
                    },
                    sendMessageTitle: {
                        type: String,
                        default: ""
                    },
                    sendMessagePath: {
                        type: String,
                        default: ""
                    },
                    sendMessageImg: {
                        type: String,
                        default: ""
                    },
                    showMessageCard: {
                        type: Boolean,
                        default: !1
                    },
                    hoverBgColor: {
                        type: String,
                        default: ""
                    },
                    rippleBgColor: {
                        type: String,
                        default: ""
                    },
                    ripple: {
                        type: Boolean,
                        default: !1
                    },
                    hoverClass: {
                        type: String,
                        default: ""
                    },
                    customStyle: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    dataName: {
                        type: String,
                        default: ""
                    },
                    throttleTime: {
                        type: [ String, Number ],
                        default: 1e3
                    },
                    hoverStartTime: {
                        type: [ String, Number ],
                        default: 20
                    },
                    hoverStayTime: {
                        type: [ String, Number ],
                        default: 150
                    }
                },
                computed: {
                    getHoverClass: function() {
                        if (this.loading || this.disabled || this.ripple || this.hoverClass) return "";
                        return this.plain ? "u-" + this.type + "-plain-hover" : "u-" + this.type + "-hover";
                    },
                    showHairLineBorder: function() {
                        return [ "primary", "success", "error", "warning" ].indexOf(this.type) >= 0 && !this.plain ? "" : "u-hairline-border";
                    }
                },
                data: function() {
                    return {
                        rippleTop: 0,
                        rippleLeft: 0,
                        fields: {},
                        waveActive: !1
                    };
                },
                methods: {
                    click: function(e) {
                        var t = this;
                        this.$u.throttle(function() {
                            !0 !== t.loading && !0 !== t.disabled && (t.ripple && (t.waveActive = !1, t.$nextTick(function() {
                                this.getWaveQuery(e);
                            })), t.$emit("click", e));
                        }, this.throttleTime);
                    },
                    getWaveQuery: function(e) {
                        var t = this;
                        this.getElQuery().then(function(n) {
                            var i = n[0];
                            if (i.width && i.width && (i.targetWidth = i.height > i.width ? i.height : i.width, 
                            i.targetWidth)) {
                                t.fields = i;
                                var o, a;
                                o = e.touches[0].clientX, a = e.touches[0].clientY, t.rippleTop = a - i.top - i.targetWidth / 2, 
                                t.rippleLeft = o - i.left - i.targetWidth / 2, t.$nextTick(function() {
                                    t.waveActive = !0;
                                });
                            }
                        });
                    },
                    getElQuery: function() {
                        var t = this;
                        return new Promise(function(n) {
                            var i = "";
                            (i = e.createSelectorQuery().in(t)).select(".u-btn").boundingClientRect(), i.exec(function(e) {
                                n(e);
                            });
                        });
                    },
                    getphonenumber: function(e) {
                        this.$emit("getphonenumber", e);
                    },
                    getuserinfo: function(e) {
                        this.$emit("getuserinfo", e);
                    },
                    error: function(e) {
                        this.$emit("error", e);
                    },
                    opensetting: function(e) {
                        this.$emit("opensetting", e);
                    },
                    launchapp: function(e) {
                        this.$emit("launchapp", e);
                    }
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    "6ea6": function(e, t, n) {
        var i = n("fa26");
        n.n(i).a;
    },
    "7e94": function(e, t, n) {
        n.r(t);
        var i = n("ff06"), o = n("a943");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("6ea6");
        var r = n("f0c5"), u = Object(r.a)(o.default, i.b, i.c, !1, null, "65533ede", null, !1, i.a, void 0);
        t.default = u.exports;
    },
    a943: function(e, t, n) {
        n.r(t);
        var i = n("2c1b"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        t.default = o.a;
    },
    fa26: function(e, t, n) {},
    ff06: function(e, t, n) {
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__get_style([ e.customStyle, {
                overflow: e.ripple ? "hidden" : "visible"
            } ])), n = Number(e.hoverStartTime), i = Number(e.hoverStayTime);
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: t,
                    m0: n,
                    m1: i
                }
            });
        }, o = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uview-ui/components/u-button/u-button-create-component", {
    "uview-ui/components/u-button/u-button-create-component": function(e, t, n) {
        n("543d").createComponent(n("7e94"));
    }
}, [ [ "uview-ui/components/u-button/u-button-create-component" ] ] ]);