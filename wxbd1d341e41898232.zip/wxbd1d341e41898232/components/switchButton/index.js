Component({
    properties: {
        tabs: {
            type: Array,
            value: []
        },
        active: {
            type: Number,
            value: 0
        }
    },
    data: {},
    methods: {
        doChange: function(t) {
            var e = t.currentTarget.dataset.index;
            this.setData({
                active: e
            }), this.triggerEvent("change", e);
        }
    },
    ready: function() {}
});