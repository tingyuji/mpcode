var t = require("../../libs/wxapi");

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        showBg: {
            type: String,
            value: !1
        },
        showBack: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: ""
        },
        hdColor: {
            type: String,
            value: ""
        },
        nativeScroll: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        scrollHeight: ""
    },
    methods: {
        goBack: function() {
            (0, t.navigateBack)();
        },
        computeScrollViewHeight: function() {
            var t = this;
            wx.createSelectorQuery().in(this).select(".header").boundingClientRect(function(e) {
                var o = e.height, i = wx.getSystemInfoSync().windowHeight - o;
                t.setData({
                    scrollHeight: "".concat(i, "px")
                });
            }).exec();
        },
        scrollToBottom: function() {
            this.triggerEvent("reachbottom");
        },
        scrollToTop: function() {
            this.triggerEvent("reachtop");
        }
    },
    ready: function() {
        var t = getApp().globalData, e = t.statusBarHeight, o = t.titleBarHeight;
        this.setData({
            statusBarHeight: e,
            titleBarHeight: o
        }), this.computeScrollViewHeight();
    },
    externalClasses: [ "flex-row", "cross-center" ]
});