Component({
    properties: {
        sharekey: {
            type: String,
            value: ""
        }
    },
    data: {
        isShow: !0
    },
    methods: {
        shareCourse: function() {},
        shareConfirm: function() {
            var t = this;
            console.log(3333), this.setData({
                isShow: !1
            }), setTimeout(function() {
                t.triggerEvent("confirm");
            });
        }
    }
});