var t = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../request/index"), o = require("../../utils/index"), i = require("../../libs/wxapi");

Component({
    properties: {},
    data: {
        countryCode: {
            name: "China",
            code: 86,
            desc: "中国"
        },
        code: "",
        mobile: "",
        isCounting: !1,
        timeHandle: null,
        timeCount: 60,
        isBusy: !1,
        toast: {
            show: !1,
            message: ""
        }
    },
    methods: {
        toast: function(t, e, i) {
            var n = this;
            "" !== (0, o.trim)(e) && (this.setData({
                toast: {
                    show: !0,
                    message: e
                }
            }), setTimeout(function() {
                n.setData({
                    toast: {
                        show: !1,
                        message: ""
                    }
                });
            }, i || 2e3));
        },
        doConfirm: function(t) {
            this.triggerEvent("confirm", {
                mobile: t
            });
        },
        doCancel: function() {
            this.triggerEvent("cancel");
        },
        bindKeyInputMB: function(e) {
            var o = e.target.id, i = e.detail.value;
            this.setData(t({}, o, i));
        },
        sendCodeMB: function() {
            var t = this, i = this.data, n = i.isCounting, s = (i.timeHandle, i.countryCode), a = i.mobile;
            n || ("" == (a = (0, o.trim)(a)) ? this.toast(null, "请输入手机号~") : (0, o.isMobile)(a, s.code) ? e.userRequest.userCode(a, s.code).then(function(e) {
                "success" == e.status ? (t.setData({
                    isCounting: !0,
                    timeCount: 60
                }), t.countingMB()) : t.toast(null, e.result.error_msg);
            }) : this.toast(null, "请输入正确的手机号~"));
        },
        countingMB: function() {
            var t = this, e = this.data, o = e.timeHandle, i = e.timeCount, n = e.isCounting;
            i > 0 ? (i--, o = setTimeout(function() {
                t.countingMB();
            }, 1e3)) : (clearTimeout(o), o = null, n = !1), this.setData({
                timeHandle: o,
                timeCount: i,
                isCounting: n
            });
        },
        confirmMB: function() {
            var t = this, i = this.data, n = i.mobile, s = i.code, a = i.countryCode;
            i.isBusy || (n = (0, o.trim)(n), s = (0, o.trim)(s), "" == n ? this.toast(null, "请输入手机号~") : (0, 
            o.isMobile)(n, a.code) ? "" == s ? this.toast(null, "请输入短信验证码~") : (this.setData({
                isBusy: !0
            }), e.userRequest.userBind({
                mobile: n,
                code: s,
                country_code: a.code
            }).then(function(e) {
                "success" == e.status ? (getApp().globalData.userInfoData.mobile = n, t.doConfirm(n)) : t.toast(null, e.result.error_msg);
                t.setData({
                    isBusy: !1,
                    code: ""
                });
            })) : this.toast(null, "请输入正确的手机号~"));
        },
        onCountryCodeTap: function() {
            (0, i.navigate)("/pages/countryCode/countryCode");
        },
        setupMB: function() {
            var t = this, e = getApp().globalData;
            e.countryCode ? this.setData({
                countryCode: e.countryCode
            }) : (0, i.getStorage)("countryCode").then(function(e) {
                e.data && t.setData({
                    countryCode: e.data
                });
            });
        }
    }
});