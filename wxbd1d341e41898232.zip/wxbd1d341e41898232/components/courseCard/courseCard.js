var e = require("../../@babel/runtime/helpers/objectSpread2"), t = (require("../../libs/wxapi"), 
require("../../utils/index"));

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        title: {
            type: String,
            value: ""
        },
        corner: {
            type: Object,
            value: null
        },
        partner: {
            type: Number,
            value: 0
        },
        duration: {
            type: Number,
            value: 0
        }
    },
    data: {
        duration_show: "",
        commend_img_show: ""
    },
    ready: function() {
        var r = this.data, i = r.corner, a = r.duration, o = r.item, n = (i || {}).title;
        this.setData({
            duration_show: (0, t.secondFormat)(a),
            commend_img_show: (0, t.imgResize)(o.commend_img_show, {
                w: 320,
                h: 350,
                format: "jpg",
                Q: 60
            }),
            corner: e(e({}, i), {}, {
                title: n ? n.substr(0, 4) : ""
            })
        });
    },
    methods: {
        onCardTap: function(e) {
            var r = e.currentTarget.dataset.item;
            this.triggerEvent("courseCardClick", r), (0, t.link2Course)(r);
        }
    }
});