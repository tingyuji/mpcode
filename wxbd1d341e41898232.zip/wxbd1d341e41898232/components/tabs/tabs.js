var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../../@babel/runtime/helpers/objectSpread2");

Component({
    properties: {
        tabslist: {
            type: Array,
            value: [],
            observer: function(t, e, a) {
                t !== e && this.refreshData(t);
            }
        },
        tabWidth: {
            type: Number,
            value: 0
        },
        defaultId: {
            type: Number,
            value: 0
        }
    },
    data: {
        tabActive: 0,
        tabLen: 0,
        tabPanes: []
    },
    attached: function() {
        this.refreshData(this.data.tabslist);
    },
    methods: {
        refreshData: function(t) {
            console.log(t);
            var e = t && t.length ? t[0].id : 0;
            this.setData({
                tabActive: this.data.defaultId || e,
                tabLen: this.contTabLen()
            });
        },
        tabClick: function(t) {
            var a = t.currentTarget.dataset.item, r = e({}, a);
            this.triggerEvent("tabClick", r, {
                bubbles: !1,
                composed: !1,
                capturePhase: !1
            }), this.setData({
                tabActive: a.id
            });
        },
        contTabLen: function() {
            var e, a = 0, r = this.data.tabslist, i = t(r);
            try {
                for (i.s(); !(e = i.n()).done; ) {
                    a += e.value.width || 135;
                }
            } catch (t) {
                i.e(t);
            } finally {
                i.f();
            }
            return a;
        },
        isActived: function(t) {
            return t === this.tabClickIndex;
        }
    }
});