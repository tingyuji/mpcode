var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../libs/wxapi"), i = require("../../request/index"), n = require("../../utils/index");

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        completeTime: String,
        isEnd: {
            type: Boolean,
            value: !1
        },
        bgImg: String,
        width: {
            type: Number,
            value: 670
        },
        height: {
            type: Number,
            value: 752
        },
        imgHeight: {
            type: Number,
            value: 340
        },
        learnSeconds: {
            type: Number,
            value: 0
        },
        currLearnSeconds: {
            type: Number,
            value: 0
        },
        courseName: {
            type: String,
            value: ""
        }
    },
    data: {
        showSetting: !1,
        uiSize: 375,
        shareData: {
            url: "",
            word: "",
            user: {
                id: 0,
                realname: "",
                nickname: "",
                learn_seconds: 0,
                avatar: ""
            }
        },
        card: {
            url: "",
            local: ""
        },
        avatar: {
            url: "",
            local: ""
        },
        qrCode: {
            url: "https://cdn-static.knowyourself.cc/meditation_wxapp/images/qr_play.png",
            local: ""
        },
        logoSrc: {
            url: (0, n.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/image_logo.png", {
                w: 190,
                h: 62,
                Q: 80
            }),
            local: ""
        },
        logoBottom: {
            url: (0, n.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/card_img/logo_bottom.png", {
                Q: 80
            }),
            local: ""
        },
        slogan: {
            url: (0, n.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/slogan.png", {
                w: 142,
                h: 36,
                Q: 80
            }),
            local: ""
        }
    },
    ready: function() {
        var e = this;
        this.getShareCardInfo(function(a) {
            e.setData({
                shareData: t(t({}, e.data.shareData), a)
            });
            var i = e.data.shareData;
            e.drawCanvas(i);
        });
    },
    methods: {
        showSettingTip: function() {
            this.setData({
                showSetting: !0
            });
        },
        onSettingCancel: function() {
            this.setData({
                showSetting: !1
            });
        },
        onMaskClick: function() {
            this.hide();
        },
        onCanvasClick: function() {},
        onShare: function() {
            this.triggerEvent("share");
        },
        onSure: function() {
            this.triggerEvent("confirm");
        },
        hide: function() {
            this.triggerEvent("hide");
        },
        drawCanvas: function(e) {
            var t = this;
            this.data.isEnd ? (this.setData({
                height: 954
            }), this.drawPlayed(wx.createCanvasContext("shareCanvas", this), 1, "", e.url || this.data.bgImg, e, function() {
                t.drawPlayed(wx.createCanvasContext("shareCanvas_2x", t), 2, "", e.url || t.data.bgImg, e);
            })) : this.drawImg(wx.createCanvasContext("shareCanvas", this), 1, e.url || this.data.bgImg, e, function() {
                t.drawImg(wx.createCanvasContext("shareCanvas_2x", t), 2, e.url || t.data.bgImg, e);
            });
        },
        drawImg: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, o = arguments.length > 2 ? arguments[2] : void 0, r = arguments.length > 3 ? arguments[3] : void 0, l = arguments.length > 4 ? arguments[4] : void 0, s = getApp().globalData, c = s.systemInfo, h = s.ky_platform, g = this.data.uiSize, d = c.windowWidth * i / (2 * g);
            console.log("ratio", d), o || reutrn;
            var f = function(e) {
                return Math.round(e * d);
            }, u = this.data, m = u.width, v = u.height, w = u.imgHeight, p = u.courseName, x = getApp(), S = x.globalData.userInfoData;
            (0, a.promisify)(wx.getImageInfo);
            (0, a.showLoading)({
                title: "正在生成图片.."
            }), this.downImage("card", (0, n.imgResize)(o, {
                w: m,
                h: v,
                format: "jpg"
            })).then(function(a) {
                if (1 !== h && t.roundRect(e, 0, 0, f(m), f(v), f(12)), e.drawImage(a.path, 0, v - w - 2, m, w, 0, 0, f(m), f(w)), 
                e.save(), e.fillStyle = "rgba(0, 0, 0, .2)", e.fillRect(0, 0, f(m), f(w)), e.restore(), 
                e.save(), S && S.avatar) return t.downImage("avatar", S.avatar);
                t.drawImageFail("未获取到头像");
            }).then(function(a) {
                var i = f(82), o = i / 2;
                e.beginPath(), e.arc(f(40) + o, f(40) + o, o, 0, 2 * Math.PI, !1), e.clip(), e.drawImage(a.path, f(40), f(40), i, i), 
                e.restore(), S.nickname && (e.setFontSize(f(30)), e.setFillStyle("#fff"), e.fillText(S.nickname, f(142), f(89), f(466)), 
                e.save()), e.save(), e.beginPath(), e.rect(f(0), f(340), f(670), f(412)), e.setFillStyle("#fff"), 
                e.fill(), e.restore();
                var l = r.user.learn_seconds;
                l = t.data.learn_seconds || l, e.setTextAlign("center"), e.setFontSize(f(28)), e.setFillStyle("#314259"), 
                e.fillText("我在“呼吸冥想”练习《".concat(p, "》"), f(m / 2), f(510), f(545)), e.setLineDash([ 3, 3 ], 0), 
                e.strokeStyle = "#90A4B7", e.beginPath(), e.moveTo(f(45), f(550)), e.lineTo(f(625), f(550)), 
                e.stroke();
                var s = (0, n.currentDate)(), c = s.year, h = s.month, g = s.date, d = s.day;
                return e.setTextAlign("center"), e.setFontSize(f(64)), e.fillText(g, f(80), f(669), f(70)), 
                e.setFontSize(f(18)), e.fillText(c + "." + (h + 1), f(80), f(695), f(70)), e.setFontSize(f(18)), 
                e.fillText("/", f(140), f(665), f(70)), e.setFontSize(f(20)), (0, n.drawTextVertical)(e, "星期" + (0, 
                n.getChineseWeekDay)(d), f(180), f(634), f(28)), t.downImage("slogan");
            }).then(function(a) {
                return e.save(), e.drawImage(a.path, f(315), f(631), f(142), f(36)), e.restore(), 
                e.setFontSize(f(20)), e.setTextAlign("left"), e.setFillStyle("rgba(49,66,89,0.4)"), 
                e.fillText("长按识别，一起冥想", f(315), f(695)), e.setFillStyle("#314259"), e.save(), t.downImage("qrCode");
            }).then(function(a) {
                return e.save(), t.setData({
                    qrCodeLocal: a.path
                }), e.drawImage(a.path, f(528), f(604), f(95), f(95)), e.restore(), t.downImage("logoSrc");
            }).then(function(t) {
                e.save(), e.drawImage(t.path, f(228), f(370), f(208), f(68)), e.restore(), (0, a.hideLoading)(), 
                e.draw(), l && l();
            }).catch(function(e) {
                console.error(e), t.drawImageFail(e.errMsg || JSON.stringify(e));
            });
        },
        drawPlayed: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                word: "",
                author: ""
            }, r = (o.word, o.author, arguments.length > 3 ? arguments[3] : void 0), l = arguments.length > 4 ? arguments[4] : void 0, s = arguments.length > 5 ? arguments[5] : void 0, c = getApp().globalData, h = c.systemInfo, g = c.ky_platform, d = c.userInfoData, f = this.data, u = f.width, m = f.height, v = f.imgHeight, w = f.uiSize, p = f.courseName, x = f.currLearnSeconds, S = h.windowWidth * i / (2 * w), T = function(e) {
                return Math.round(e * S);
            };
            (0, a.promisify)(wx.getImageInfo);
            (0, a.showLoading)({
                title: "正在生成图片..."
            }), this.downImage("card", (0, n.imgResize)(r, {
                w: u,
                h: m,
                format: "jpg",
                Q: 60
            })).then(function(a) {
                1 !== g && t.roundRect(e, 0, 0, T(u), T(m), T(12)), e.drawImage(a.path, 0, m - v - 2, u, v, 0, 0, T(u), T(v)), 
                e.save(), e.fillStyle = "rgba(0, 0, 0, .2)", e.fillRect(0, 0, T(u), T(v)), e.restore();
                var i = (0, n.currentDate)(), o = i.year, r = i.month, l = i.date, s = i.day;
                if (e.setTextAlign("center"), e.setTextBaseline("middle"), e.setFillStyle("#fff"), 
                e.setFontSize(T(64)), e.fillText(l, T(522), T(85), T(70)), e.setFontSize(T(18)), 
                e.fillText(o + "." + (r + 1), T(522), T(128.5), T(70)), e.setFontSize(T(18)), e.fillText("/", T(573), T(98), T(70)), 
                e.setFontSize(T(20)), e.fillText("星", T(609), T(71), T(22)), e.fillText("期", T(609), T(96), T(22)), 
                e.fillText((0, n.getChineseWeekDay)(s), T(609), T(121), T(22)), e.fillStyle = "#fff", 
                e.fillRect(0, T(340), T(u), T(m - v)), d && d.avatar) return t.downImage("avatar", d.avatar);
                t.drawImageFail("未获取到头像");
            }).then(function(a) {
                var i = T(82), n = i / 2;
                e.save(), e.beginPath(), e.arc(T(294) + n, T(370) + n, n, 0, 2 * Math.PI, !1), e.clip(), 
                e.drawImage(a.path, T(294), T(370), i, i), e.restore(), d.nickname && (e.setFontSize(T(30)), 
                e.setFillStyle("#fff"), t.fillBoldText(e, d.nickname, T(335), T(487), T(570), T(30), "#314259", "center"), 
                e.save()), t.drawRoundedRect(e, T(123), T(544), T(90), T(42), T(21), !0, "#E4E6E8"), 
                t.drawRoundedRect(e, T(456), T(544), T(90), T(42), T(21), !0, "#E4E6E8"), e.setFontSize(T(22)), 
                e.setTextAlign("center"), e.setFillStyle("#ADB4BD"), e.fillText("本次", T(167.5), T(565), T(275)), 
                e.fillText("累计", T(502.5), T(565), T(275)), e.setFontSize(T(24)), e.setTextAlign("center"), 
                e.setFillStyle("rgba(49,66,89, .67)"), e.fillText("完成《".concat(p, "》"), T(167.5), T(632), T(275)), 
                e.fillText("我在“呼吸冥想”", T(502.5), T(632), T(275));
                var o = l.user.learn_seconds, r = Math.ceil((t.data.learnSeconds || o) / 60) + "", s = "" + Math.ceil(x / 60);
                console.log(t.data.learnSeconds, o, x);
                var c = {
                    text: s,
                    len: 28 * s.length + 36 + 44
                }, h = {
                    text: r,
                    len: 28 * r.length + 36 + 44
                };
                return t.fillBoldText(e, c.text, T(167.5 - c.len / 2 + 18), T(709), T(570), T(52), "#314259", "left"), 
                e.setTextAlign("right"), e.setFontSize(T(22)), e.fillText("分钟", T(167.5 + c.len / 2), T(717)), 
                t.fillBoldText(e, h.text, T(502.5 - h.len / 2 + 18), T(709), T(570), T(52), "#314259", "left"), 
                e.setTextAlign("right"), e.setFontSize(T(22)), e.fillText("分钟", T(502.5 + h.len / 2), T(717)), 
                e.strokeStyle = "#EFF0F1", e.lineWidth = T(2), e.beginPath(), e.moveTo(T(334), T(595)), 
                e.lineTo(T(334), T(735)), e.stroke(), e.strokeStyle = "#EFF0F1", e.lineWidth = T(2), 
                e.beginPath(), e.moveTo(T(45), T(789)), e.lineTo(T(625), T(789)), e.stroke(), e.setFontSize(T(20)), 
                e.setTextAlign("right"), e.setFillStyle("rgba(49, 66, 89, .4)"), e.fillText("长按识别，一起冥想", T(501), T(903)), 
                t.downImage("logoBottom");
            }).then(function(a) {
                return e.setFillStyle("#fff"), e.drawImage(a.path, T(45), T(838), T(213), T(68)), 
                e.save(), t.downImage("qrCode");
            }).then(function(i) {
                e.setFillStyle("#fff"), e.drawImage(i.path, T(523.6), T(822.6), T(98.8), T(98.8)), 
                e.restore(), (0, a.hideLoading)(), e.draw(), s && s(), t.setData({
                    finished: !0
                });
            }).catch(function(e) {
                console.error(e), t.drawImageFail(e.errMsg || JSON.stringify(e));
            });
        },
        downImage: function(t, i) {
            var n = this, o = this.data["" + t] || {}, r = (0, a.promisify)(wx.getImageInfo);
            return !o.local || i && i !== o.url ? new Promise(function(a, l) {
                r({
                    src: o.url || i
                }).then(function(r) {
                    n.setData(e({}, "" + t, {
                        local: r.path,
                        url: o.url || i
                    })), a(r);
                }).catch(function(e) {
                    l(e);
                });
            }) : new Promise(function(e, t) {
                e({
                    path: o.local
                });
            });
        },
        drawImageFail: function(e) {
            var t = this;
            (0, a.hideLoading)(), (0, a.showToast)("生成图片失败，原因:".concat(e)), clearTimeout(this.failTimer), 
            this.failTimer = setTimeout(function() {
                t.hide();
            }, 2e3);
        },
        onSaveImage: function(e) {
            var t = this;
            (0, n.checkQuikAuth)({
                scope: "scope.writePhotosAlbum"
            }).then(function(e) {
                t.saveShareImage();
            }).catch(function(e) {
                var i = e.err, n = e.isQuikFail;
                /authorize:fail/.test(i.errMsg) ? n ? t.showSettingTip() : (0, a.showToast)("由于您拒绝授权，图片保存失败") : (0, 
                a.showToast)(JSON.stringify(i));
            });
        },
        fillBoldText: function(e, t, a, i, n, o, r, l) {
            var s = getApp().globalData.ky_platform;
            e.save(), e.font = "normal bold ".concat(o, 1 == s ? 'px/20px "PingFang SC",sans-serif' : 'px/20px "Helvetica Neue",Helvetica,Arial,"PingFang SC","Hiragino Sans GB","Heiti SC","Microsoft YaHei","WenQuanYi Micro Hei",sans-serif'), 
            r && e.setFillStyle(r), l && e.setTextAlign(l), e.fillText("".concat(t), a, i, n), 
            e.restore();
        },
        saveShareImage: function() {
            var e = this, t = getApp().globalData.ky_platform;
            (0, n.mtaReport)("play_save_image"), (0, a.showLoading)({
                title: "正在保存图片.."
            });
            wx.canvasToTempFilePath({
                x: 0,
                y: 0,
                width: this.data.width,
                height: this.data.height,
                canvasId: 1 === t ? "shareCanvas" : "shareCanvas_2x",
                success: function(t) {
                    wx.saveImageToPhotosAlbum({
                        filePath: t.tempFilePath,
                        success: function(e) {
                            console.log(e), wx.showToast({
                                title: "保存到相册成功",
                                duration: 1500
                            });
                        },
                        fail: function(e) {
                            console.log(e), wx.showToast({
                                title: "保存到相册失败",
                                icon: "fail"
                            });
                        },
                        complete: function(t) {
                            (0, a.hideLoading)(), e.hide(), console.log(t);
                        }
                    });
                },
                fail: function(e) {
                    console.log(e), wx.showToast({
                        title: "转换图片失败",
                        icon: "fail"
                    });
                },
                complete: function(e) {
                    console.log(e);
                }
            }, this);
        },
        fillMultiLineText: function(e, t, a, i, o, r) {
            for (var l = [], s = 0; (0, n.getStrLen)(t) > 21 * s; ) l.push(t.substr(21 * s, 21)), 
            ++s;
            l.forEach(function(t, n) {
                e.fillText(t, a, i + r(41 * n), o);
            });
        },
        getShareCardInfo: function(e) {
            i.mediRequest.getShareCardInfo().then(function(t) {
                "success" === t.status ? e && e(t.result) : (0, a.showToast)("获取打卡信息失败");
            });
        },
        drawRoundedRect: function(e, t, a, i, n, o, r) {
            var l = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "transparent";
            e.save();
            var s = function(e, t) {
                return {
                    x: e,
                    y: t
                };
            }, c = s(t + o, a), h = s(t + i, a), g = s(t + i, a + n), d = s(t, a + n), f = s(t, a);
            e.beginPath(), e.setStrokeStyle(l), e.moveTo(c.x, c.y), e.arcTo(h.x, h.y, g.x, g.y, o), 
            e.arcTo(g.x, g.y, d.x, d.y, o), e.arcTo(d.x, d.y, f.x, f.y, o), e.arcTo(f.x, f.y, c.x, c.y, o), 
            e.stroke(), e.closePath(), r || e.clip(), e.restore();
        },
        roundRect: function(e, t, a, i, n, o, r) {
            var l = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "transparent";
            e.beginPath(), e.setStrokeStyle(l), e.arc(t + o, a + o, o, Math.PI, 1.5 * Math.PI), 
            e.moveTo(t + o, a), e.lineTo(t + i - o, a), e.lineTo(t + i, a + o), e.arc(t + i - o, a + o, o, 1.5 * Math.PI, 2 * Math.PI), 
            e.lineTo(t + i, a + n - o), e.lineTo(t + i - o, a + n), e.arc(t + i - o, a + n - o, o, 0, .5 * Math.PI), 
            e.lineTo(t + o, a + n), e.lineTo(t, a + n - o), e.arc(t + o, a + n - o, o, .5 * Math.PI, Math.PI), 
            e.lineTo(t, a + o), e.lineTo(t + o, a), e.stroke(), e.closePath(), r || e.clip(), 
            e.save();
        }
    }
});