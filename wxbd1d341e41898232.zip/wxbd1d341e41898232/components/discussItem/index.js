Component({
    properties: {
        item: {
            type: Object,
            value: {}
        }
    },
    data: {},
    methods: {}
});