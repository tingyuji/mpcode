module.exports = {
    name: "loadingView",
    data: {
        show: !0
    },
    methods: {
        startLoading: function() {
            this.setData({
                show: !0
            });
        },
        stopLoading: function() {
            this.setData({
                show: !1
            });
        }
    }
};