Component({
    properties: {
        shareApp: {
            type: Function,
            value: function() {},
            observer: function() {}
        },
        shareTimeline: {
            type: Function,
            value: function() {},
            observer: function() {}
        }
    },
    data: {
        isShow: !0
    },
    methods: {
        onCancel: function() {
            this.triggerEvent("hide");
        },
        onShareApp: function() {
            this.triggerEvent("shareApp"), this.onCancel();
        },
        onShareTimeline: function() {
            this.triggerEvent("shareTimeline"), this.onCancel();
        }
    }
});