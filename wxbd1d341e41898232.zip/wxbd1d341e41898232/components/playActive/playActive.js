Component({
    properties: {},
    data: {
        text: "breathe in",
        animationData: {},
        pointAnimation: {}
    },
    ready: function() {
        var t = this;
        setTimeout(function() {
            t.aniSetting = {
                duration: 5e3,
                timingFunction: "linear",
                delay: 0
            }, t.rotateDeg = 0, t.animation = wx.createAnimation(t.aniSetting), t.animationPoint = wx.createAnimation(t.aniSetting), 
            t.setData({
                text: "breathe in",
                pointAnimation: t.animationPoint.export(),
                animationData: t.animation.export()
            }), t.rotateDeg += 90, t.heartBeat();
        }, 100);
    },
    methods: {
        heartBeat: function() {
            var t = this;
            this.firstPart().then(function(i) {
                return t.secondPart();
            }).then(function(i) {
                return t.thirdPart();
            }).then(function(i) {
                return t.fourthPart();
            }).then(function(i) {
                t.heartBeat();
            });
        },
        setTimer: function(t) {
            var i = this;
            return new Promise(function(n, a) {
                setTimeout(function() {
                    i.rotateDeg += 90, n(i.rotateDeg);
                }, t);
            });
        },
        firstPart: function() {
            return this.animationPoint.rotate(this.rotateDeg).step(this.aniSetting), this.animation.scale(1.2, 1.2).step(this.aniSetting), 
            this.setData({
                text: "breathe in",
                pointAnimation: this.animationPoint.export(),
                animationData: this.animation.export()
            }), this.setTimer(5500);
        },
        secondPart: function() {
            return this.animationPoint.rotate(this.rotateDeg).step(this.aniSetting), this.animation.scale(1, 1).step(this.aniSetting), 
            this.setData({
                text: "breathe out",
                pointAnimation: this.animationPoint.export(),
                animationData: this.animation.export()
            }), this.setTimer(5500);
        },
        thirdPart: function() {
            return this.animationPoint.rotate(this.rotateDeg).step(this.aniSetting), this.animation.scale(1.2, 1.2).step(this.aniSetting), 
            this.setData({
                text: "breathe in",
                pointAnimation: this.animationPoint.export(),
                animationData: this.animation.export()
            }), this.setTimer(5500);
        },
        fourthPart: function() {
            return this.animationPoint.rotate(this.rotateDeg).step(this.aniSetting), this.animation.scale(1, 1).step(this.aniSetting), 
            this.setData({
                text: "breathe out",
                pointAnimation: this.animationPoint.export(),
                animationData: this.animation.export()
            }), this.setTimer(5500);
        }
    }
});