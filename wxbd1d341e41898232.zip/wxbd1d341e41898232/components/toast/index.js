var s = require("../../utils/index");

module.exports = {
    name: "toast",
    data: {
        show: !1,
        message: ""
    },
    methods: {
        toast: function(t, e, a) {
            var o = this;
            "" !== (0, s.trim)(e) && (this.setData({
                show: !0,
                message: e
            }), setTimeout(function() {
                o.setData({
                    show: !1,
                    message: ""
                });
            }, a || 2e3));
        }
    }
};