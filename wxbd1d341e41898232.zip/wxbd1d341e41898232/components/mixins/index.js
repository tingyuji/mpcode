var e = require("../../libs/wxapi"), r = require("../../request/index");

module.exports = {
    name: "mixins",
    data: {},
    methods: {
        onAnchorTap: function(r) {
            var t = r.currentTarget.dataset.url;
            (0, e.backOrNavigate)(t);
        },
        submitFormId: function(e) {
            var t = e.detail.formId;
            t && r.systemRecordRequest.reportFormId(t).then(function(e) {
                console.log(e);
            });
        },
        previewImage: function(e) {
            var r = e.currentTarget.dataset, t = r.current, a = void 0 === t ? "" : t, i = r.urls, n = void 0 === i ? [] : i;
            wx.previewImage({
                current: a,
                urls: n
            });
        }
    }
};