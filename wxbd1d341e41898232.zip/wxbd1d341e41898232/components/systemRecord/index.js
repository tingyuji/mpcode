var e = require("../../utils/index"), t = require("../../request/index");

module.exports = {
    name: "systemRecord",
    data: {
        visit_start_time: 0,
        from_page: ""
    },
    methods: {
        systemRecordStart: function() {
            this.setData({
                visit_start_time: (0, e.now)()
            });
        },
        systemRecordReport: function(e, s) {
            var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "", o = this.data.from_page;
            t.systemRecordRequest.report({
                user_id: e,
                visit_page: s,
                page_id: i,
                visit_type: r,
                from_page: o
            }).then(function(e) {}), this.setData({
                from_page: s
            });
        },
        systemRecordReportShare: function(e, s) {
            var r = this.data.from_page;
            t.systemRecordRequest.report({
                user_id: e,
                visit_page: s,
                visit_type: 2,
                from_page: r,
                event: "share"
            }).then(function(e) {
                console.log(e);
            });
        }
    }
};