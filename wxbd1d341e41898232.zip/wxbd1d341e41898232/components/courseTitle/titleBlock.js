Component({
    properties: {
        title: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {}
});