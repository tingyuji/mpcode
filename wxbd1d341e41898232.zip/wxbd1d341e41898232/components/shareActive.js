Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getShareText = a, exports.default = void 0;

var e = require("../utils/index");

function a() {
    var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = a.id, s = void 0 === t ? "" : t, i = a.sharekey, c = void 0 === i ? "" : i, r = a.courseId, o = void 0 === r ? "" : r, n = a.success, p = void 0 === n ? function() {} : n, h = a.fail, m = void 0 === h ? function() {} : h, g = a.compelete, l = void 0 === g ? function() {} : g, d = {
        66: {
            title: "10万个睡不着的人都打开了这个小程序…",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_01.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        67: {
            title: "你还记不记得一夜无梦是什么感觉？",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_02.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        70: {
            title: "保持专注不是一件容易事，听说练这个有用…",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_03.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        44: {
            title: "上一个点进来的人说：和朋友的关系更亲密了！",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_04.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        48: {
            title: "分享给你，就是想要拉着你一起开心呀！",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_05.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        74: {
            title: "送你一台身体扫描仪，了解一下？",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_06.jpg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        },
        75: {
            title: "更平和、更专注！人人都能学会的头脑训练！",
            imageUrl: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share/shareActive_07.jpeg", {
                format: "jpg",
                Q: 60
            }),
            path: (0, e.shareLink)("/pages/getOne/index?sharekey=".concat(c, "&id=").concat(s, "&from=share")),
            success: p,
            fail: m,
            compelete: l
        }
    };
    return d["".concat(o)] || {
        title: "这里有一门超实用的冥想课程，快来看看吧！",
        imageUrl: e.com_share_card_img,
        path: (0, e.shareLink)("/pages/course/course?id=".concat(o, "'&from=share")),
        success: p,
        fail: m,
        compelete: l
    };
}

var t = a;

exports.default = t;