var e = require("../../request/index");

Component({
    properties: {},
    data: {},
    methods: {
        reportFormId: function(r) {
            var o = r.detail.formId;
            e.systemRecordRequest.reportFormId({
                type: 2,
                form_id: o
            }).then(function(e) {
                console.log(e);
            });
        }
    }
});