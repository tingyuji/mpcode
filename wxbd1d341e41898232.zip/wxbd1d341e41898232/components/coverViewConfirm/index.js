Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        content: String,
        title: String,
        confirmOpenType: {
            type: String,
            value: ""
        },
        cancelOpenType: {
            type: String,
            value: ""
        },
        confirmText: {
            type: String,
            value: ""
        },
        cancelText: {
            type: String,
            value: ""
        },
        boxWidth: {
            type: Number,
            value: 496
        },
        buttonReverse: {
            type: Boolean,
            value: !1
        },
        closeable: {
            type: Boolean,
            value: !0
        },
        maskClosable: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        onSure: function() {
            this.triggerEvent("confirm");
        },
        onCancel: function() {
            this.triggerEvent("cancel");
        },
        onContainerClick: function() {
            this.data.maskClosable && this.onCancel();
        },
        noop: function() {}
    }
});