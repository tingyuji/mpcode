var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.mtaReport = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "init", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", r = getApp(), n = r.globalData.mta;
    if ("init" === e) return void n.Page.init();
    n.Event.stat(e, o({}, t));
}, exports.imgResize = p, exports.checkQuikAuth = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.scope, r = (0, 
    c.promisify)(wx.authorize), n = !0;
    return setTimeout(function() {
        n = !1;
    }, 300), new Promise(function(e, a) {
        r({
            scope: t
        }).then(function(t) {
            e(t);
        }).catch(function(e) {
            console.log("isQuikFail", n), a({
                err: e,
                isQuikFail: n
            });
        });
    });
}, exports.link2Course = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (!e.id) return void (0, c.showToast)("没有对应跳转id");
    if (1 === e.type) return void (0, c.backOrNavigate)("/pages/play/play?courseId=".concat(e.id, "&type=").concat(e.type));
    (0, c.backOrNavigate)("/pages/course/course?id=".concat(e.id));
}, exports.link2Lesson = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (!e.id) return void (0, c.showToast)("没有对应跳转id");
    (0, c.backOrNavigate)("/pages/play/play?lessonId=".concat(e.id, "&type=").concat(e.type || ""));
}, exports.parseQuery = g, exports.isNumber = function(e, t) {
    var r;
    r = t ? new RegExp("^\\d{" + t + "}$") : /^\d+$/;
    return !!r.test(e);
}, exports.isEmail = function(e) {
    if (e && /^(?:[-\w])+(?:\.[-\w]+)*@(?:[-\w])+(?:(?:\.[-\w]+)+)$/.test(e)) return !0;
    return !1;
}, exports.isMobile = function(e) {
    var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 86;
    t = 86 == r ? /^1[34587]\d{9}$/ : /^\d{5,13}$/;
    return !!t.test(e);
}, exports.isArray = function(e) {
    return "[object Array]" == Object.prototype.toString.call(e);
}, exports.trim = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return (e += "").replace(/^\s+|\s+$/, "");
}, exports.getStrLen = function(e, t) {
    return e.replace(/[\u4e00-\u9fa5]/g, "--").length;
}, exports.padZero = f, exports.second2minute = function(e) {
    var t = Math.floor(e / 60);
    return {
        time: e = Math.floor(e % 60),
        minute: t,
        second: e,
        str: t || e ? "".concat(t, ":").concat(f(e)) : "0:00"
    };
}, exports.currentDate = function() {
    var e, t, r, n, a = new Date();
    return e = a.getFullYear(), t = a.getMonth(), r = a.getDate(), n = a.getDay(), {
        time: a.getTime(),
        year: e,
        month: t,
        date: r,
        day: n,
        str: "".concat(e, "-").concat(f(t + 1), "-").concat(f(r))
    };
}, exports.currentWeek = d, exports.nextWeek = h, exports.getTwoWeek = function() {
    var e = d(), t = h(e[e.length - 1].time);
    return [].concat(a(e), a(t));
}, exports.isLater = function(e, t) {
    return e = e.replace(/-/g, "") - 0, t = t.replace(/-/g, "") - 0, e - t > 0;
}, exports.getChineseWeekDay = x, exports.drawTextVertical = function(e, t, r, n, a) {
    var o = t.split(""), i = o.map(function(e) {
        return a || 12;
    }), s = e.textAlign, c = e.textBaseline;
    "left" == s ? r += Math.max.apply(null, i) / 2 : "right" == s && (r -= Math.max.apply(null, i) / 2);
    "bottom" == c || "alphabetic" == c || "ideographic" == c ? n -= i[0] / 2 : "top" != c && "hanging" != c || (n += i[0] / 2);
    e.textAlign = "center", e.textBaseline = "middle", o.forEach(function(a, o) {
        var s = i[o];
        a.charCodeAt(0) <= 256 ? (e.translate(r, n), e.rotate(90 * Math.PI / 180), e.translate(-r, -n)) : o > 0 && t.charCodeAt(o - 1) < 256 && (n += i[o - 1] / 2), 
        e.fillText(a, r, n), e.setTransform(1, 0, 0, 1, 0, 0);
        s = i[o];
        n += s;
    }), e.textAlign = s, e.textBaseline = c;
}, exports.nextDays = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Date(), r = t, n = 864e5, a = new Array(e), o = 0; o < e; o++) {
        var i = void 0, s = void 0, c = void 0, u = void 0;
        i = r.getFullYear(), s = r.getMonth(), c = r.getDate(), u = r.getDay(), a[o] = {
            year: i,
            month: s,
            date: c,
            day: u,
            str: "".concat(i, "-").concat(f(s + 1), "-").concat(f(c))
        }, r.setTime(r.getTime() + n);
    }
    return {
        days: a,
        from: t
    };
}, exports.getUID = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10, t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", r = "", n = 0;
    for (;n < e; ) r += t[Math.floor(Math.random() * (t.length - 1) + 1)], n++;
    return r;
}, exports.timeFormat = function(e) {
    "number" == typeof e ? e *= 1e3 : e = isNaN(e) ? +new Date(e.replace(/-/g, "/")) : +e;
    var t = +new Date(), r = t - e, n = r > 0 ? "前" : "后";
    if ((r = Math.abs(r)) < 1e3) return "刚刚";
    if (r < 6e4) return Math.max(1, Math.floor(r / 60)) + "秒" + n;
    if (r < 36e5) return Math.max(1, Math.floor(r / 6e4)) + "分钟" + n;
    if (r < 864e5) return Math.max(1, Math.floor(r / 36e5)) + "小时" + n;
    var a = new Date(t), o = new Date(e), i = (a.getFullYear(), o.getFullYear()), s = o.getMonth() + 1, c = o.getDate(), u = [];
    return u.push(i), u.push(s > 9 ? s : "0" + s), u.push(c > 9 ? c : "0" + c), u.join("-");
}, exports.anaUrlInfo = function(e) {
    var t = M(e), r = t.indexOf("?");
    if (-1 === r) return {};
    var n = (t = t.substring(r + 1)).split("&"), a = {};
    return n.forEach(function(e, t, r) {
        var n = e.split("=");
        n.length > 1 && (a[n[0]] = n[1]);
    }), a;
}, exports.transNickName = w, exports.refreshPage = function() {
    var e = getCurrentPages(), t = e.length > 1 ? e[e.length - 1] : {
        route: "pages/index/index"
    };
    u.default.contains(s.default.tabBar_url, "/".concat(t.route)) || "pages/index/index" === t.route ? reLaunch({
        url: "".concat(t.route).concat(v(t.options))
    }) : (0, c.backOrRedirect)("/".concat(t.route).concat(v(t.options)));
}, exports.checkVersion = function() {
    return new Promise(function(e, t) {
        var r = getApp().globalData.isCheckingVerion;
        "" === r ? i.userRequest.getVersionSign().then(function(t) {
            "success" === t.status && t.result ? (getApp().globalData.isCheckingVerion = t.result.status, 
            e(t.result.status)) : e(0);
        }).catch(function(t) {
            return e(0);
        }) : e(r);
    });
}, exports.checkLogin = function(e, t) {
    return k.apply(this, arguments);
}, exports.go2Login = _, exports.isTabBar = function(e) {
    return u.default.contains(s.default.tabBar_url, e);
}, exports.shareLink = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = t.notPassIndex, n = void 0 !== r && r, a = t.link_type, o = void 0 === a ? "" : a, i = t.app_id, s = void 0 === i ? "" : i;
    if (n) return e;
    return "/pages/index/index?path=".concat(encodeURIComponent(e), "&link_type=").concat(o, "&app_id=").concat(s);
}, exports.gotoPath = function(e, t) {
    wx.showLoading({
        title: "正在跳转"
    }), setTimeout(function() {
        wx.hideLoading();
        var r = e.app_id, n = e.path, a = e.link_type;
        if (n = M(n), 3 == a) {
            if (t) return void (0, c.backOrRedirect)("/pages/webview/webview?url=".concat(n));
            (0, c.backOrNavigate)("/pages/webview/webview?url=".concat(n));
        } else if (2 == a) r && wx.navigateToMiniProgram({
            appId: r,
            path: n,
            extraData: {
                from: "meditation"
            },
            success: function(e) {}
        }); else {
            if (t) return void (0, c.backOrRedirect)(n);
            (0, c.backOrNavigate)(n);
        }
    }, 300);
}, exports.checkDecode = M, exports.checkEncode = function(e) {
    return !e.indexOf("/") > -1 ? e : encodeURIComponent(e);
}, exports.measureText = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10;
    return function(e) {
        e = (e = String(e)).split("");
        var r = 0;
        return e.forEach(function(e) {
            /[a-zA-Z]/.test(e) ? r += 7 : /[0-9]/.test(e) ? r += 5.5 : /\./.test(e) ? r += 2.7 : /-/.test(e) ? r += 3.25 : /[\u4e00-\u9fa5]/.test(e) ? r += 10 : /\(|\)/.test(e) ? r += 3.73 : /\s/.test(e) ? r += 2.5 : /%/.test(e) ? r += 8 : r += 10;
        }), {
            width: r * t / 10
        };
    }(e);
}, exports.canUseWebView = exports.addGlobalParams = exports.obj2qs = exports.learnTimeFormat = exports.numFixed = exports.parseDateToLocalString = exports.jsonDecode = exports.customDateString = exports.countLetter = exports.secondFormat = exports.defaultShareObj = exports.thisDate = exports.unixNow = exports.now = exports.com_share_card_img = void 0;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/typeof"), a = require("../@babel/runtime/helpers/toConsumableArray"), o = require("../@babel/runtime/helpers/objectSpread2"), i = require("../request/index"), s = e(require("../config/config")), c = require("../libs/wxapi"), u = e(require("../libs/underscore")), l = p("https://cdn-static.knowyourself.cc/meditation_wxapp/images/share_card.png", {
    w: 750,
    h: 600,
    format: "jpg",
    Q: 60
});

exports.com_share_card_img = l;

exports.now = function() {
    return +new Date();
};

exports.unixNow = function() {
    return Math.round(+new Date() / 1e3);
};

exports.thisDate = function() {
    var e = new Date();
    return [ e.getFullYear(), f(e.getMonth() + 1, 2), f(e.getDay()) ].join(".");
};

exports.defaultShareObj = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.title, r = e.imageUrl, n = e.path;
    return {
        title: t || "这里有一门超实用的冥想课程，快来看看吧！",
        imageUrl: r || l,
        path: n || "/pages/index/index"
    };
};

function p(e, t) {
    var r = t.w, n = t.h, a = t.format, o = t.q, i = t.Q, s = t.autoOrient;
    if (e.indexOf("x-oss-process") > -1) return e;
    var c = e.replace(/\?.*/, ""), u = "?x-oss-process=image";
    return r && n ? u += "/resize,m_mfit,h_".concat(n, ",w_").concat(r, ",") : (r && (u += "/resize,w_".concat(r)), 
    n && (u += "/resize,h_".concat(n))), a && (u += "/format,".concat(a)), (o || i) && (u += "/quality,", 
    o && (u += "q_".concat(o)), i && (u += "Q_".concat(i))), s && (u += "/auto-orient,".concat(s)), 
    "".concat(c).concat(u);
}

function g() {
    var e, t, r, n, a, o, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", s = {};
    if (e = i.indexOf("?"), i = e > -1 ? i.slice(e + 1) : "") for (t = 0, r = (i = i.split("&")).length; t < r; t++) n = (n = i[t]).split("="), 
    a = decodeURIComponent(n[0]), o = decodeURIComponent(n[1]), s[a] = o;
    return s;
}

function f() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2, r = (e += "").length, n = t - r;
    if (0 == r || 0 == t || n <= 0) return e;
    for (var a = 0; a < n; a++) e = "0" + e;
    return e;
}

function d() {
    var e = new Date(), t = new Array(7), r = e.getDay();
    e.setTime(e.getTime() - 864e5 * r);
    for (var n = 0; n < 7; n++) {
        var a, o, i, s;
        a = e.getFullYear(), o = e.getMonth(), i = e.getDate(), s = e.getDay(), t[n] = {
            time: e.getTime(),
            year: a,
            month: o,
            date: i,
            day: s,
            day_show: "星期".concat(x(s)),
            str: "".concat(a, "-").concat(f(o + 1), "-").concat(f(i))
        }, e.setTime(e.getTime() + 864e5);
    }
    return t;
}

function h(e) {
    var t = new Date(), r = new Array(7);
    t.setTime(e + 864e5);
    for (var n = 0; n < 7; n++) {
        var a, o, i, s;
        a = t.getFullYear(), o = t.getMonth(), i = t.getDate(), s = t.getDay(), r[n] = {
            time: t.getTime(),
            year: a,
            month: o,
            date: i,
            day: s,
            day_show: "星期".concat(x(s)),
            str: "".concat(a, "-").concat(f(o + 1), "-").concat(f(i))
        }, t.setTime(t.getTime() + 864e5);
    }
    return r;
}

function x(e) {
    switch (e -= 0) {
      case 0:
        return "日";

      case 1:
        return "一";

      case 2:
        return "二";

      case 3:
        return "三";

      case 4:
        return "四";

      case 5:
        return "五";

      case 6:
        return "六";
    }
}

exports.secondFormat = function(e) {
    var t = "", r = 3600;
    return e / r > 1 && (t += "".concat(f(Math.floor(e / r)), ":")), e %= r, r = 60, 
    t += "".concat(f(Math.floor(e / r)), ":"), e %= r, r = 1, t += f(Math.floor(e / r));
};

exports.countLetter = function(e) {
    var t, r, a, o, i, s = n(e);
    if ("string" !== s && "number" !== s) return 0;
    for (t = 0, o = /[^\x00-\xff]/, r = 0, a = (i = (e += "").match(/./g) || []).length; r < a; r++) o.test(i[r]) ? t += 2 : t++;
    return t;
};

exports.customDateString = function(e) {
    return e ? (10 == (e + "").length && (e *= 1e3), l = (t = new Date(e)).getTime(), 
    r = t.getFullYear(), n = t.getMonth() + 1, s = t.getDate(), a = t.getHours(), o = t.getMinutes(), 
    c = r + "年" + f(n) + "月" + f(s) + "日", i = f(a) + ":" + f(o), (t = new Date()).setHours(0), 
    t.setMinutes(0), t.setSeconds(0), u = t.getTime(), (p = Math.round((u - l) / 864e5)) <= 0 ? i : 1 == p ? "昨天 " + i : c + " " + i) : "";
    var t, r, n, a, o, i, s, c, u, l, p;
};

exports.jsonDecode = function(e) {
    try {
        return JSON.parse(e);
    } catch (t) {
        return e;
    }
};

exports.parseDateToLocalString = function(e) {
    var t, r, n, a;
    return r = (t = "number" == typeof e ? new Date(1e3 * e) : new Date(e)).getFullYear(), 
    n = t.getMonth(), a = t.getDate(), t.getDay(), "".concat(r, "年").concat(f(n + 1), "月").concat(f(a), "日");
};

var m = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
    return (e = parseFloat(e)) || (e = 0), e.toFixed(t) - 0;
};

exports.numFixed = m;

exports.learnTimeFormat = function(e) {
    var t = Math.ceil(e / 60);
    if (t <= 999) return {
        time: t,
        label: "分钟"
    };
    var r = Math.ceil(e / 3600);
    if (r <= 999) return {
        time: r,
        label: "小时"
    };
    var n = m(e / 3600 / 1e3, 1);
    return {
        time: "".concat(n, "K"),
        label: "小时"
    };
};

var v = function(e, t) {
    e = e || {};
    var r = "?";
    return Object.keys(e).forEach(function(n) {
        var a = e[n];
        n && (t || a) && (1 !== r.length && (r += "&"), r += n + "=" + a);
    }), r.length > 1 ? r : "";
};

exports.obj2qs = v;

var b;

function w(e) {
    var t = o({}, e);
    return t.unique_name = t.nickname, t.nickname = t.wx_name, t.avatar = t.avatar || p("https://cdn-static.knowyourself.cc/meditation_wxapp/images/head_default.png", {
        w: 120,
        h: 120,
        q: 80
    }), t;
}

function y() {
    return D.apply(this, arguments);
}

function D() {
    return (D = r(t.default.mark(function e() {
        var r;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, c.getStorage)("loginState").then(function() {
                    r = !0;
                }).catch(function() {
                    r = !1;
                });

              case 2:
                return e.abrupt("return", r);

              case 3:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function k() {
    return (k = r(t.default.mark(function e(r, n) {
        var a, s, u = arguments;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (a = u.length > 2 && void 0 !== u[2] ? u[2] : {}, !(s = getApp()).globalData.user_id) {
                    e.next = 6;
                    break;
                }
                setTimeout(function() {
                    r && r();
                }, 100), e.next = 13;
                break;

              case 6:
                return e.next = 8, y();

              case 8:
                if (e.sent) {
                    e.next = 12;
                    break;
                }
                return wx.reLaunch({
                    url: "/pages/logOn/logOn"
                }), e.abrupt("return");

              case 12:
                new Promise(function(e, t) {
                    Promise.all([ (0, c.getStorage)("ky_userid"), (0, c.getStorage)("ky_token") ]).then(function(n) {
                        var a = n[1].data, c = n[0].data;
                        s.globalData = o(o({}, s.globalData), {}, {
                            token: a,
                            user_id: c
                        }), i.userRequest.getUserInfo().then(function(n) {
                            var a = n.status, o = n.result;
                            if ("success" === a) return o = w(o), s.globalData.userInfoData = o, r && r(), void e();
                            t(o);
                        }).catch(t);
                    }).catch(function(e) {
                        t(e);
                    });
                }).catch(function(e) {
                    i.userRequest.login().then(function(e) {
                        if ("success" == e.status) (0, c.setStorage)("ky_userid", e.result.user_id), (0, 
                        c.setStorage)("ky_token", e.result.token), s.globalData = o(o({}, s.globalData), e.result), 
                        i.userRequest.getUserInfo().then(function(e) {
                            var t = e.status, r = e.result;
                            "success" === t && (r = w(r), s.globalData.userInfoData = r);
                        }); else if ((0, c.showToast)(e.result.error_msg), 701 === e.result.error_code) return void _("/pages/login/login".concat(v(a)));
                        s.globalData.user_id ? r && r() : _("/pages/login/login".concat(v(a)));
                    });
                });

              case 13:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function _(e) {
    b && clearTimeout(b), b = setTimeout(function() {
        console.log(e), (0, c.backOrNavigate)(e);
    }, 300);
}

function M(e) {
    return e.indexOf("/") > -1 ? e : decodeURIComponent(e);
}

exports.addGlobalParams = function(e) {
    if (!e) return "";
    var t, r, n = getApp().globalData;
    return t = g(e), r = e.replace(/\?.*/, ""), t.topsession = n.token, t.userid = n.userInfoData.user_id, 
    t.avatar = n.userInfoData.avatar, t.nickname = n.userInfoData.nickname, t.uuid = n.uuid, 
    t.channelid = n.channelid, t.version = "1.2.8", "".concat(r).concat(v(t));
};

exports.canUseWebView = function(e) {
    if (!e) {
        var t = getApp().globalData;
        e = t.systemInfo && t.systemInfo.SDKVersion || "";
    }
    return !!e && (e = e.replace(/\./g, ""), !((e = parseInt(e) || 0) - 164 < 0));
};