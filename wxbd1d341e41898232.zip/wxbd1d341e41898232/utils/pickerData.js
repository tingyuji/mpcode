Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.agePicker = exports.marriagePicker = exports.childrenPicker = exports.genderPicker = void 0;

exports.genderPicker = [ {
    value: 1,
    name: "男",
    key: "male"
}, {
    value: 2,
    name: "女",
    key: "female"
} ];

exports.childrenPicker = [ {
    value: 1,
    name: "有",
    key: "has"
}, {
    value: 2,
    name: "没有",
    key: "no"
} ];

exports.marriagePicker = [ {
    value: 1,
    name: "未婚",
    key: "unmarried"
}, {
    value: 2,
    name: "已婚",
    key: "married"
} ];

var e = [];

exports.agePicker = e;

for (var r = 10; r <= 100; r++) e.push({
    value: r,
    name: "".concat(r, " 周岁"),
    key: r
});