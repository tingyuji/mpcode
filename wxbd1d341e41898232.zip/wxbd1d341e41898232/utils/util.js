var t = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
};

module.exports = {
    formatTime: function(e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, o = e.getFullYear(), i = e.getMonth() + 1, r = e.getDate(), a = e.getHours(), u = e.getMinutes(), g = e.getSeconds();
        return 1 == n ? [ o, i, r ].map(t).join("/") + " " + [ a, u, g ].map(t).join(":") : 2 == n ? [ o, i, r ].map(t).join("/") + " " + [ a, u ].map(t).join(":") : 3 == n ? [ o, i, r ].map(t).join("-") : void 0;
    }
};