var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../request/index"), a = require("../../utils/index"), o = require("../../libs/wxapi"), n = e(require("../../config/config")), s = e(require("../../libs/underscore"));

Page({
    data: {
        auth: !1,
        contentTop: 0,
        options: null
    },
    onLoad: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        (0, a.mtaReport)(), this.setData({
            options: t
        }), setTimeout(function() {
            e.checkLogin();
        }, 300);
    },
    onReady: function() {
        var e = getApp().globalData.systemInfo;
        this.setData({
            contentTop: Math.round(583 * e.screenHeight / 1334)
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, a.defaultShareObj)();
    },
    showAuth: function() {
        this.setData({
            auth: !1
        });
    },
    goBack: function() {
        var e = this.data.options, t = getCurrentPages();
        this.setData({
            auth: !0
        });
        var r = t.length > 1 ? t[t.length - 2] : {
            route: "pages/index/index"
        };
        console.log("goBack", e), e && e.path ? (0, a.gotoPath)(e, !0) : s.default.contains(n.default.tabBar_url, "/".concat(r.route)) || "pages/index/index" === r.route ? (0, 
        o.reLaunch)({
            url: "".concat(r.route).concat((0, a.obj2qs)(r.options))
        }) : (0, o.backOrRedirect)("/".concat(r.route).concat((0, a.obj2qs)(r.options)));
    },
    handleGetUserInfo: function(e) {
        var s = this;
        if ((0, a.mtaReport)("auth"), e.detail.userInfo) {
            var r = e.detail.userInfo;
            getApp().globalData.user_id ? t.userRequest.updateDetail({
                icon: (0, a.imgResize)(r.avatarUrl || r.avatar, {
                    autoOrient: 1
                }),
                wx_name: r.nickName,
                city: r.city,
                country: r.country,
                gender: r.gender
            }).then(function(t) {
                (console.log(t), "success" == t.status) && (getApp().globalData.userInfoData = {
                    avatar: (0, a.imgResize)(r.avatarUrl || r.avatar, {
                        autoOrient: 1
                    }),
                    nickname: r.nickName
                }, s.goBack(), e.successFn && e.successFn());
            }) : (0, o.login)().then(function(i) {
                console.log("login", i), i.code ? t.userRequest.regist({
                    encrypted: e.detail.encryptedData,
                    iv: e.detail.iv,
                    code: i.code
                }).then(function(t) {
                    if (console.log("regist", t), "success" == t.status) {
                        var i = getApp();
                        i.globalData.userInfoData = {
                            avatar: (0, a.imgResize)(r.avatarUrl || r.avatar, {
                                autoOrient: 1
                            }),
                            nickname: r.nickName,
                            user_id: t.result.user_id
                        }, i.globalData.user_id = t.result.user_id, (0, o.setStorage)("ky_userid", t.result.user_id), 
                        1 == t.result.registration && (0, o.setStorage)(n.default.GUIDE_SHOW_KEY, 1), t.result.openid && (i.globalData.uuid = t.result.openid), 
                        t.result.token && ((0, o.setStorage)("ky_token", t.result.token), i.globalData.token = t.result.token), 
                        s.goBack(), e.successFn && e.successFn();
                    } else (0, o.showToast)("注册失败:".concat(t.result.error_msg));
                }).catch(function(e) {
                    console.error(e);
                }) : (0, o.showToast)("登录失败:".concat(i.result.error_msg));
            });
        }
    },
    getUserInfo: function(e) {
        var o = this, n = getApp();
        t.userRequest.getUserInfo().then(function(t) {
            var s = t.status, r = t.result;
            "success" === s && (r = (0, a.transNickName)(r), o.setData({
                userInfo: r
            }), n.globalData.userInfoData = r, n.globalData.updateDetail.avatar = (0, a.imgResize)(n.globalData.updateDetail.avatar, {
                autoOrient: 1
            }), e && e());
        });
    }
});