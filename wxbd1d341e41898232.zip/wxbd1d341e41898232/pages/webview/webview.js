require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../libs/underscore"));

Page({
    data: {
        url: ""
    },
    components: {
        systemRecord: {}
    },
    onShow: function() {
        getApp();
        this.systemRecordStart();
    },
    onHide: function() {
        var e = getApp();
        this.systemRecordReport(e.globalData.unionid, "webview");
    },
    onUnload: function() {
        var e = getApp();
        this.systemRecordReport(e.globalData.unionid, "webview");
    },
    onLoad: function(e) {
        console.log(e, 89), e.url && this.setData({
            url: decodeURIComponent(e.url)
        });
    }
});