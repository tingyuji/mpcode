var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../utils/index"), i = require("../../request/index"), s = require("../../libs/wxapi");

Page({
    data: {
        currTab: "",
        currShowType: "",
        tabslist: [],
        subTab: [],
        currSubTab: {},
        courseListShow: [],
        subTabLen: "",
        courseListShowWidth: ""
    },
    onLoad: function() {
        (0, e.mtaReport)();
    },
    onShow: function() {
        wx._trackEvent("v1_pv_meditation", {
            userid: getApp().globalData.user_id
        }), this.data.tabslist && this.data.tabslist.length || this.getGenre(), (0, e.mtaReport)("meditation_in");
    },
    onTabClick: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.detail;
        console.log(e), this.changeTab(e);
    },
    onSubTabClick: function(t) {
        var e = t.currentTarget.dataset.item;
        console.log(e), this.changeSubTab(e);
    },
    onSoundClick: function(t) {
        var i = t.currentTarget.dataset, s = i.item;
        i.type_show;
        (0, e.link2Course)(s);
    },
    changeTab: function(e) {
        var i = this;
        if (e && e.id) {
            var s = e.id, a = this.data.tabslist.find(function(t) {
                return t.id === s;
            });
            this.setData({
                subTab: []
            }), setTimeout(function() {
                i.setData({
                    currTab: s,
                    currShowType: e.type_show,
                    subTab: a && a.child ? t(a.child) : []
                }), i.contSubLen(a.child);
                var n = a.child && a.child.length ? a.child[0] : null;
                2 === a.type_show ? i.changeSubTab(n) : i.getCourseList({
                    genre_id: a.id
                });
            }, 0);
        }
    },
    changeSubTab: function(t) {
        var e = this;
        if (t && t.id) {
            var i = t.id;
            this.data.subTab.find(function(t) {
                return t.id === i;
            });
            setTimeout(function() {
                e.setData({
                    currSubTab: i
                }), e.getCourseList({
                    genre_id: e.data.currTab,
                    child_genre_id: i
                });
            }, 0);
        }
    },
    contSubLen: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.subTab, e = t.length, i = 0;
        return e && e > 6 && (i = 125 * e), this.setData({
            subTabLen: i ? i + "rpx" : ""
        }), i;
    },
    contSoundShowWidth: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.courseListShow, e = t.length, i = 0;
        return i = 202 * e, i += 40, this.setData({
            courseListShowWidth: i + "rpx"
        }), i;
    },
    getGenre: function() {
        var e = this;
        i.mediRequest.getGenreAll().then(function(i) {
            "success" === i.status && (e.setData({
                tabslist: t(i.result)
            }), e.changeTab(i.result[0]));
        });
    },
    getCourseList: function() {
        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.genre_id, n = void 0 === a ? "" : a, r = e.child_genre_id, u = void 0 === r ? "" : r;
        i.mediRequest.getCourseList({
            genre_id: n,
            child_genre_id: u
        }).then(function(e) {
            "success" === e.status ? (t.setData({
                courseListShow: []
            }), setTimeout(function() {
                t.setData({
                    courseListShow: t.makeCourseListShow(e.result.list, t.data.currShowType)
                }), t.contSoundShowWidth(), console.log(t.data.courseListShow);
            }, 0)) : (0, s.showToast)(e.result.error_msg);
        });
    },
    makeCourseListShow: function(t, e) {
        if (1 == e) return t || [];
        var i = [], s = t && t[0] ? t[0].course : [], a = 0, n = 0;
        return s.forEach(function(t, e, s) {
            i[a] || (i.push([]), n = 0);
            var r = i[a];
            ++n, r.push(t), a % 2 == 0 ? 3 === n && ++a : 4 === n && ++a;
        }), i;
    }
});