var e = require("../../../@babel/runtime/helpers/toConsumableArray"), a = require("../../../request/index"), t = require("../../../request/constent"), o = require("../../../libs/wxapi"), n = require("../../../utils/index");

Page({
    data: {
        showMobile: !1,
        userInfo: {},
        images: []
    },
    doChooseImg: function(e) {
        var a = this;
        wx.chooseImage({
            count: Math.max(0, 9 - this.data.images.length),
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.uploadImage(t);
            }
        });
    },
    uploadImage: function(a) {
        var s = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        (0, o.showLoading)("上传中...", {
            mask: !0
        }), wx.uploadFile({
            url: "".concat(t.commonApi, "/upload/file"),
            name: "file",
            filePath: a[i],
            success: function(a) {
                var t = (0, n.jsonDecode)(a.data);
                "success" === t.status && ((0, o.hideLoading)(), s.setData({
                    images: [].concat(e(s.data.images), [ t.result.url ]),
                    "userInfo.avatar": t.result.url
                }));
            }
        });
    },
    inputText: function(e) {
        console.log(e, 555), this.setData({
            "userInfo.nickname": e.detail.value
        });
    },
    inputPhone: function() {
        this.setData({
            showMobile: !0
        });
    },
    doMobileConfirm: function(e) {
        var a = e.detail.mobile;
        this.data.detail;
        this.setData({
            "userInfo.mobile": a
        }), this.doMobileCancel();
    },
    doMobileCancel: function() {
        this.setData({
            showMobile: !1
        });
    },
    updateInfo: function() {
        var e = this;
        a.userRequest.updateDetail({
            nickname: this.data.userInfo.nickname,
            sex: this.data.userInfo.sex,
            avatar: this.data.userInfo.avatar
        }).then(function(a) {
            var t = a.status;
            a.result;
            if ("success" === t) {
                var n = getApp().globalData;
                console.log(3243, e.data.userInfo), n.userInfoData = e.data.userInfo, (0, o.reLaunch)({
                    url: "/pages/mine/index/mine"
                });
            }
        });
    },
    onLoad: function(e) {
        var a = getApp().globalData;
        console.log(a, 8888), this.setData({
            userInfo: a.userInfoData
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, n.defaultShareObj)();
    }
});