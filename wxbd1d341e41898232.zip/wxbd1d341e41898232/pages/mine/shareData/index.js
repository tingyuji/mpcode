var t = require("../../../libs/wxapi"), e = (require("../../../request/index"), 
require("../../../utils/index"));

Page({
    data: {
        finished: !1,
        width: 670,
        height: 742,
        uiSize: 375,
        showSetting: !1,
        titleImg: "https://cdn-static.knowyourself.cc/meditation_wxapp/images/share_data_title.png",
        qrCode: "https://cdn-static.knowyourself.cc/meditation_wxapp/images/qr_data.png",
        slogan: (0, e.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/slogan.png", {
            w: 142,
            h: 36,
            Q: 80
        })
    },
    onLoad: function(t) {},
    onReady: function() {
        (0, e.checkLogin)(this.init, !0);
    },
    init: function() {
        this.drawCanvas();
    },
    drawCanvas: function() {
        var i = this, a = getApp().globalData, n = a.systemInfo, o = a.userInfoData, s = a.ky_platform, l = this.data, r = l.width, h = l.height, c = l.uiSize, f = wx.createCanvasContext("shareData", this);
        this.ratio = n.windowWidth / (2 * c);
        var d = function(t) {
            return Math.round(t * i.ratio);
        }, u = (0, t.promisify)(wx.getImageInfo);
        (0, t.showLoading)({
            title: "正在生成图片..."
        }), 1 !== s && this.roundRect(f, 0, 0, d(r), d(h), d(12)), f.setTextBaseline("middle"), 
        f.fillStyle = "#fff", f.fillRect(0, 0, d(r), d(h)), f.save(), f.setLineDash([ 3, 3 ], 0), 
        f.setLineWidth(d(2)), f.setLineJoin("round"), f.strokeStyle = "rgba(144,164,183,.8)", 
        f.beginPath(), f.moveTo(d(30), d(57)), f.lineTo(d(30), d(562)), f.lineTo(d(640), d(562)), 
        f.lineTo(d(640), d(57)), f.closePath(), f.stroke(), f.restore(), u({
            src: this.data.titleImg
        }).then(function(t) {
            return f.fillRect(d(185), d(30), d(300), d(50)), f.setTextAlign("center"), f.setFillStyle("#314259"), 
            f.setFontSize(d(36)), f.drawImage(t.path, d(217), d(38), d(230), d(35)), u({
                src: o.avatar
            });
        }).then(function(t) {
            f.save();
            var a = d(100), n = a / 2;
            f.beginPath(), f.arc(d(285) + n, d(128) + n, n, 0, 2 * Math.PI, !1), f.clip(), f.setFillStyle("#fff"), 
            f.drawImage(t.path, d(285), d(128), a, a), f.restore(), f.save(), f.setFontSize(d(28)), 
            i.fillBoldText(f, o.wx_name, d(335), d(264), d(610), d(28)), f.restore(), f.setStrokeStyle("rgba(218, 224, 233, .5)"), 
            f.setLineWidth(d(2)), f.beginPath(), f.moveTo(d(239.5), d(383)), f.lineTo(d(239.5), d(473)), 
            f.moveTo(d(443.5), d(383)), f.lineTo(d(443.5), d(473)), f.stroke(), f.save(), f.setFontSize(d(24)), 
            f.setFillStyle("rgba(49, 66, 89, .8)"), i.fillBoldText(f, "累计时长", d(133), d(380), d(200), d(24)), 
            i.fillBoldText(f, "累计天数", d(337), d(380), d(200), d(24)), i.fillBoldText(f, "完成课时", d(541), d(380), d(200), d(24)), 
            f.restore(), f.setFontSize(d(22)), f.setTextAlign("left");
            var s = (0, e.learnTimeFormat)(o.learn_seconds), l = (0, e.measureText)(s.label, d(22)).width, r = (0, 
            e.measureText)("个", d(22)).width, h = d(12);
            f.setFontSize(d(48));
            var c = (0, e.measureText)(s.time, d(48)).width, g = (0, e.measureText)(o.learn_days, d(48)).width, w = (0, 
            e.measureText)(o.lesson_count, d(48)).width, T = d(133) - (l + h + c) / 2, m = d(337) - (r + h + g) / 2, x = d(541) - (r + h + w) / 2;
            return f.setFillStyle("#5498C5"), f.fillText(s.time, T, d(458.5)), f.fillText(o.learn_days, m, d(458.5)), 
            f.fillText(o.lesson_count, x, d(458.5)), f.setFontSize(d(22)), f.setFillStyle("rgba(49, 66, 89, .8)"), 
            f.fillText(s.label, T + c + h, d(465)), f.fillText("天", m + g + h, d(465)), f.fillText("个", x + w + h, d(465)), 
            u({
                src: i.data.slogan
            });
        }).then(function(e) {
            f.save(), f.drawImage(e.path, d(49), d(618), d(142), d(36)), f.restore(), f.setTextAlign("left"), 
            f.setFillStyle("rgba(49, 66, 89, .4)"), f.fillText("长按识别，一起冥想", d(49), d(680.5)), 
            i.drawQrCode(f, function() {
                (0, t.hideLoading)(), f.draw(), i.setData({
                    finished: !0
                });
            });
        });
    },
    fillBoldText: function(t, e, i, a, n, o, s, l) {
        var r = getApp().globalData.ky_platform;
        t.save(), t.font = "normal bold ".concat(o, 1 == r ? 'px/20px "PingFang SC",sans-serif' : 'px/20px "Helvetica Neue",Helvetica,Arial,"PingFang SC","Hiragino Sans GB","Heiti SC","Microsoft YaHei","WenQuanYi Micro Hei",sans-serif'), 
        s && t.setFillStyle(s), l && t.setTextAlign(l), t.fillText("".concat(e), i, a, n), 
        t.restore();
    },
    drawQrCode: function(e, i) {
        var a = this, n = (0, t.promisify)(wx.getImageInfo), o = function(t) {
            return t * a.ratio;
        };
        n({
            src: this.data.qrCode
        }).then(function(t) {
            e.setFillStyle("#fff"), e.drawImage(t.path, o(503), o(595), o(114), o(114)), e.restore(), 
            i && i();
        });
    },
    roundRect: function(t, e, i, a, n, o) {
        t.beginPath(), t.setFillStyle("transparent"), t.arc(e + o, i + o, o, Math.PI, 1.5 * Math.PI), 
        t.moveTo(e + o, i), t.lineTo(e + a - o, i), t.lineTo(e + a, i + o), t.arc(e + a - o, i + o, o, 1.5 * Math.PI, 2 * Math.PI), 
        t.lineTo(e + a, i + n - o), t.lineTo(e + a - o, i + n), t.arc(e + a - o, i + n - o, o, 0, .5 * Math.PI), 
        t.lineTo(e + o, i + n), t.lineTo(e, i + n - o), t.arc(e + o, i + n - o, o, .5 * Math.PI, Math.PI), 
        t.lineTo(e, i + o), t.lineTo(e + o, i), t.fill(), t.closePath(), t.clip();
    },
    onSaveImage: function() {
        var i = this;
        (0, e.checkQuikAuth)({
            scope: "scope.writePhotosAlbum"
        }).then(function(t) {
            i.saveShareImage();
        }).catch(function(e) {
            var a = e.err, n = e.isQuikFail;
            /authorize:fail/.test(a.errMsg) ? n ? i.showSettingTip() : (0, t.showToast)("由于您拒绝授权，图片保存失败") : (0, 
            t.showToast)(JSON.stringify(a));
        });
    },
    showSettingTip: function() {
        this.setData({
            showSetting: !0
        });
    },
    hideSettingTip: function() {
        this.setData({
            showSetting: !1
        });
    },
    saveShareImage: function() {
        var e = this;
        if (this.data.finished) {
            var i = function(t) {
                return t * e.ratio;
            };
            (0, t.showLoading)({
                title: "正在保存图片.."
            });
            wx.canvasToTempFilePath({
                x: 0,
                y: 0,
                width: i(this.data.width),
                height: i(this.data.height),
                canvasId: "shareData",
                success: function(e) {
                    wx.saveImageToPhotosAlbum({
                        filePath: e.tempFilePath,
                        success: function(t) {
                            wx.showToast({
                                title: "保存到相册成功",
                                duration: 1500
                            });
                        },
                        fail: function(t) {
                            wx.showToast({
                                title: "保存到相册失败",
                                icon: "fail"
                            });
                        },
                        complete: function(e) {
                            (0, t.hideLoading)();
                        }
                    });
                },
                fail: function(t) {
                    wx.showToast({
                        title: "转换图片失败",
                        icon: "fail"
                    });
                },
                complete: function(t) {}
            }, this);
        }
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.defaultShareObj)();
    }
});