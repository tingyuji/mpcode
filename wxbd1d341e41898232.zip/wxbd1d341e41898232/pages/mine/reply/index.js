var t = require("../../../utils/index"), e = require("../../../request/index");

require("../../../libs/wxapi");

Page({
    data: {
        tabslist: [],
        replyList: [],
        statusConf: {
            1: "进行中",
            2: "已完成"
        }
    },
    getReplyList: function() {
        var t = this;
        e.mediRequest.getGenreAll().then(function(e) {
            "success" === e.status && t.setData({
                replyList: [ {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                } ]
            });
        });
    },
    onLoad: function(t) {
        this.getReplyList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});