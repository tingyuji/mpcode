require("../../../request/index");

var a = require("../../../libs/wxapi"), e = require("../../../utils/index");

Page({
    data: {
        userInfo: {},
        learnTime: {},
        showBanner: !1
    },
    editInfo: function() {
        wx.navigateTo({
            url: "/pages/mine/editMyInfo/index",
            success: function(a) {},
            fail: function(a) {},
            complete: function(a) {}
        });
    },
    getShare: function() {
        (0, e.mtaReport)("mine_data_share"), (0, a.backOrNavigate)("/pages/mine/shareData/index");
    },
    getMyPractice: function() {
        (0, a.backOrNavigate)("/pages/mine/practice/index");
    },
    getMyDiscuss: function() {
        (0, a.backOrNavigate)("/pages/mine/discuss/index?status=1");
    },
    getMyMessage: function() {
        (0, a.backOrNavigate)("/pages/mine/message/index");
    },
    goFeedBack: function() {
        (0, a.backOrNavigate)("/pages/mine/feedback/index?status=1");
    },
    getManual: function() {
        (0, a.backOrNavigate)("/pages/mine/manual/index");
    },
    getOne: function() {
        (0, a.backOrNavigate)("/pages/getOne/index");
    },
    onLoad: function(a) {
        (0, e.mtaReport)(), (0, e.mtaReport)("mine_in");
    },
    init: function() {
        this.getUserInfo();
    },
    getUserInfo: function() {
        var n = getApp();
        if (console.log(n.globalData), console.log(n.globalData.userInfoData), n.globalData.userInfoData) return -1 === n.globalData.userInfoData.avatar.indexOf("auto-orient") && (n.globalData.userInfoData.avatar = (0, 
        e.imgResize)(n.globalData.userInfoData.avatar, {
            autoOrient: 1
        })), console.log(n.globalData.userInfoData, 12), 1 == n.globalData.userInfoData.market.show_status ? this.setData({
            showBanner: !0
        }) : this.setData({
            showBanner: !1
        }), this.setData({
            userInfo: n.globalData.userInfoData
        }), void this.setData({
            learnTime: (0, e.learnTimeFormat)(n.globalData.userInfoData.learn_seconds || 0)
        });
        (0, a.backOrNavigate)("/pages/logOn/logOn");
    },
    onReady: function() {},
    onShow: function() {
        wx._trackEvent("v1_pv_my", {
            userid: getApp().globalData.user_id
        }), (0, e.checkLogin)(this.init, !0);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.defaultShareObj)();
    }
});