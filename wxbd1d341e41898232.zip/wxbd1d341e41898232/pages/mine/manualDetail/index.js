var n = require("../../../@babel/runtime/helpers/objectSpread2"), e = require("../../../utils/index");

Page({
    data: {
        item: ""
    },
    onLoad: function(e) {
        console.log(e, 555), this.setData(n({}, e));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.defaultShareObj)();
    }
});