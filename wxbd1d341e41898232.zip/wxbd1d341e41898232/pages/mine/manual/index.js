var n = require("../../../libs/wxapi"), e = require("../../../utils/index");

Page({
    data: {},
    getDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        (0, n.backOrNavigate)("/pages/mine/manualDetail/index?item=".concat(t));
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.defaultShareObj)();
    }
});