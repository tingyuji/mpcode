var t = require("../../../utils/index"), i = require("../../../request/index");

require("../../../libs/wxapi");

Page({
    data: {
        tabslist: [],
        activityList: [],
        statusConf: {
            1: "进行中",
            2: "已完成"
        }
    },
    getActivityList: function() {
        var t = this;
        i.mediRequest.getGenreAll().then(function(i) {
            "success" === i.status && t.setData({
                activityList: [ {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                } ]
            });
        });
    },
    onLoad: function(t) {
        this.getActivityList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});