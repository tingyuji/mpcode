var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../utils/index"), a = require("../../../request/index"), s = (require("../../../libs/wxapi"), 
t(require("../../../libs/underscore")));

Page({
    data: {
        tabslist: [ {
            title: "已获得",
            id: 2
        }, {
            title: "已收藏",
            id: 1
        } ],
        tabActive: 2,
        practiceList: [],
        count: 0,
        page_size: 10,
        statusConf: {
            1: "未开始",
            2: "进行中",
            3: "已完成"
        },
        isBusy: !1
    },
    components: {
        toast: {},
        loadingView: {}
    },
    getPracticeList: function() {
        var t = this, i = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        this.data.isBusy || (this.setData({
            isBusy: !0
        }), this.startLoading(), a.userRequest[1 == this.data.tabActive ? "getUserStars" : "getUserCourse"]({
            offset: i ? 0 : this.data.practiceList.length,
            page_size: this.data.page_size
        }).then(function(a) {
            t.stopLoading(), t.setData({
                isBusy: !1
            }), "success" === a.status ? t.setData({
                practiceList: i ? a.result.list : [].concat(e(t.data.practiceList), e(a.result.list)),
                count: a.result.count
            }) : t.toast(null, a.result.error_msg);
        }).catch(function() {
            t.stopLoading(), t.setData({
                isBusy: !1
            });
        }));
    },
    onTabClick: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.detail;
        this.changeTab(e);
    },
    changeTab: function(t) {
        if (t && t.id) {
            var e = t.id, i = this.data.tabslist.find(function(t) {
                return t.id === e;
            });
            this.setData({
                tabActive: i.id
            }), this.getPracticeList();
        }
    },
    onLoad: function(t) {},
    init: function() {
        this.getPracticeList();
    },
    doUnCollect: function(t) {
        var e = this, i = t.currentTarget.dataset.id;
        a.mediRequest.setCourseUnstars({
            id: i
        }).then(function(t) {
            var a = t.status, s = t.result;
            "success" === a ? (e.setData({
                practiceList: e.data.practiceList.filter(function(t) {
                    return t.id != i;
                }),
                count: Math.max(0, e.data.count - 1)
            }), e.toast(null, "操作成功")) : e.toast(null, s.error_msg);
        }).catch(function() {
            e.toast(null, "操作失败");
        });
    },
    authLinkTo: function(t) {
        var e = t.currentTarget.dataset, a = e.item;
        e.type_show;
        (0, i.link2Course)(a);
    },
    onReady: function() {},
    onShow: function() {
        (0, i.checkLogin)(this.init);
        var t = getApp().globalData;
        if (t.followChange) {
            var e = this.data.practiceList;
            s.default.each(e, function(e) {
                e.id == t.followChange.id && (e.user_stars = t.followChange.user_stars);
            }), this.setData({
                practiceList: e
            }), t.followChange = null;
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var t = this.data, e = t.count;
        t.practiceList.length < e && this.getPracticeList(!1);
    },
    onShareAppMessage: function() {
        return (0, i.defaultShareObj)();
    }
});