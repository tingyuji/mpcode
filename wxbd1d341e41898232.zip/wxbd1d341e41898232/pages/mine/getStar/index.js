var t = require("../../../utils/index"), e = require("../../../request/index");

require("../../../libs/wxapi");

Page({
    data: {
        tabslist: [],
        starList: [],
        statusConf: {
            1: "进行中",
            2: "已完成"
        }
    },
    getReplyList: function(t) {
        var n = this;
        e.userRequest.getStarList({
            offset: t ? 0 : this.data.starList.length,
            page_size: this.data.page_size
        }).then(function(t) {
            "success" === t.status && n.setData({
                starList: [ {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                } ]
            });
        });
    },
    onLoad: function(t) {
        this.getReplyList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});