var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../utils/index"), a = require("../../../request/index"), n = require("../../../request/constent"), o = require("../../../libs/wxapi");

Page({
    data: {
        contentMax: 200,
        maxImagesNum: 3,
        radioItems: [ {
            name: "产品建议",
            value: 0
        }, {
            name: "问题反馈",
            value: 1
        }, {
            name: "其他",
            value: 2
        } ],
        placeholder: "不论是使用问题还是吐槽建议，都可以在这里告诉我们，我们愿为你不断进步！",
        checkedValue: 0,
        images: []
    },
    components: {
        toast: {},
        loadingView: {}
    },
    doPreview: function(e) {
        var t = e.currentTarget.dataset.url;
        wx.previewImage({
            urls: this.data.images,
            current: t
        });
    },
    doClose: function(t) {
        var a = t.currentTarget.dataset.index, n = e(this.data.images);
        n.splice(a, 1), this.setData({
            images: n
        });
    },
    getRadio: function(e) {
        this.setData({
            checkedValue: e.currentTarget.dataset.item.value
        });
    },
    doSubmit: function(e) {
        var n = this, s = e.detail.value, i = s.content, c = s.contact, u = this.data, r = u.checkedValue, d = u.contentMax, l = u.images;
        u.inUploading ? (0, o.showToast)("图片上传中...") : (i = (0, t.trim)(i)) ? i.length > d ? (0, 
        o.showToast)("内容超过" + d + "字的限制") : (this.startLoading(), a.userRequest.postFeedback({
            content: i,
            contact: c,
            images: l,
            source: 1,
            type: r
        }).then(function(e) {
            var t = e.status, a = e.result;
            n.stopLoading(), "success" === t ? ((0, o.showToast)("提交成功"), setTimeout(function() {
                (0, o.backOrNavigate)("/pages/mine/index/mine");
            }, 1e3)) : (0, o.showToast)(a.error_msg);
        }).catch(function() {
            n.stopLoading(), (0, o.showToast)("提交出错");
        })) : (0, o.showToast)("内容不能为空");
    },
    doChooseImg: function() {
        var e = this, t = this.data.maxImagesNum;
        wx.chooseImage({
            count: Math.max(0, t - this.data.images.length),
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                var a = t.tempFilePaths;
                e.uploadImage(a);
            }
        });
    },
    uploadImage: function(a) {
        var s = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        (0, o.showLoading)("上传中...(".concat(i, "/").concat(a.length, ")"), {
            mask: !0
        }), this.setData({
            inUploading: !0
        }), wx.uploadFile({
            url: "".concat(n.commonApi, "/upload/file"),
            name: "file",
            filePath: a[i],
            success: function(a) {
                var n = (0, t.jsonDecode)(a.data);
                "success" === n.status && s.setData({
                    images: [].concat(e(s.data.images), [ n.result.url ])
                });
            },
            complete: function() {
                if (i >= a.length - 1) return (0, o.hideLoading)(), void s.setData({
                    inUploading: !1
                });
                s.uploadImage(a, i + 1);
            }
        });
    },
    setActivity: function(e) {},
    onLoad: function(e) {
        e.type;
        (0, t.checkLogin)();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});