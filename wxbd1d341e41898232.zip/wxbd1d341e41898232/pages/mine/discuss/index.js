var t = require("../../../utils/index"), i = require("../../../request/index");

require("../../../libs/wxapi");

Page({
    data: {
        tabslist: [ {
            title: "我的讨论",
            id: 1
        }, {
            title: "我的回复",
            id: 2
        } ],
        tabActive: 1,
        discussList: [],
        statusConf: {
            1: "进行中",
            2: "已完成"
        },
        count: 0,
        page_size: 10,
        isBusy: !1
    },
    components: {
        toast: {},
        loadingView: {}
    },
    getDiscussList: function() {
        var t = this;
        i.mediRequest.getGenreAll().then(function(i) {
            "success" === i.status && t.setData({
                discussList: [ {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 1,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                }, {
                    id: 2,
                    title: "七日睡眠课程",
                    content: "对方水电费撒打发打发飞洒发撒发放的方式都发的发发发阿斯顿发的方法未确认部分大？",
                    status: 1
                } ]
            });
        });
    },
    onTabClick: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.detail;
        console.log(i), this.changeTab(i);
    },
    changeTab: function(t) {
        if (t && t.id) {
            console.log(t, 78787);
            var i = t.id, n = this.data.tabslist.find(function(t) {
                return t.id === i;
            });
            this.setData({
                tabActive: n.id
            }), this.getDiscussList();
        }
    },
    onLoad: function(i) {
        (0, t.checkLogin)(this.init);
    },
    init: function() {
        this.getDiscussList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});