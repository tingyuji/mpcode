var e = require("../../../@babel/runtime/helpers/toConsumableArray"), t = require("../../../utils/index"), s = require("../../../request/index"), a = require("../../../libs/wxapi"), i = require("../../../utils/util");

Page({
    data: {
        messageNewList: [],
        messageOldList: [],
        count: 0,
        page_size: 10,
        statusConf: {
            1: "进行中",
            2: "已完成"
        }
    },
    components: {
        toast: {},
        loadingView: {}
    },
    getMessageList: function() {
        var t = this, a = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        this.startLoading(), s.userRequest.getMessageList({
            offset: a ? 0 : this.data.messageNewList.length + this.data.messageOldList.length,
            page_size: this.data.page_size
        }).then(function(s) {
            t.stopLoading(), console.log(s, 12121), "success" == s.status ? (console.log(a, s.result.list.new, t.data.messageOldList, 21), 
            t.setData({
                messageNewList: a ? s.result.list.new : [].concat(e(t.data.messageNewList), e(s.result.list.new)),
                messageOldList: a ? s.result.list.old : [].concat(e(t.data.messageOldList), e(s.result.list.old)),
                count: s.result.count
            }), setTimeout(function() {
                var e = [], s = [];
                t.data.messageNewList.map(function(t) {
                    Number(t.create_time) && (t.create_time = (0, i.formatTime)(new Date(1e3 * t.create_time), 3)), 
                    e.push(t);
                }), t.data.messageOldList.map(function(e) {
                    Number(e.create_time) && (e.create_time = (0, i.formatTime)(new Date(1e3 * e.create_time), 3)), 
                    s.push(e);
                }), t.setData({
                    messageNewList: e,
                    messageOldList: s
                });
            })) : t.toast(null, s.result.error_msg);
        }).catch(function() {
            t.stopLoading();
        });
    },
    getOne: function(e) {
        var t = e.currentTarget.dataset.item;
        console.log(t, 12), (0, a.backOrNavigate)("/pages/getOne/index?id=".concat(t.marketing.id));
    },
    onLoad: function(e) {},
    init: function() {
        this.getMessageList();
    },
    onReady: function() {},
    onShow: function() {
        (0, t.checkLogin)(this.init);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        console.log(1211122222);
        var e = this.data, t = e.count, s = e.messageNewList, a = e.messageOldList;
        s.length + a.length < t && this.getMessageList(!1);
    },
    onShareAppMessage: function() {
        return (0, t.defaultShareObj)();
    }
});