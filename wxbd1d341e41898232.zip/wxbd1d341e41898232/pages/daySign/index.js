var t = require("../../libs/wxapi"), e = require("../../request/index"), i = require("../../utils/index");

Page({
    data: {
        finished: !1,
        width: 670,
        height: 899,
        bannerHeight: 340,
        uiSize: 375,
        showSetting: !1,
        bannerSrc: "",
        titleText: "https://cdn-static.knowyourself.cc/meditation_wxapp/images/daySign/riqian_logo.png",
        qrCode: "https://cdn-static.knowyourself.cc/meditation_wxapp/images/qr_daily.png",
        logoSrc: (0, i.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/image_logo.png", {
            w: 190,
            h: 62,
            Q: 80
        }),
        slogan: (0, i.imgResize)("https://cdn-static.knowyourself.cc/meditation_wxapp/images/daySign/riqian_slogan.png", {
            w: 182,
            h: 47,
            Q: 80
        })
    },
    components: {
        loadingView: {}
    },
    onLoad: function(t) {
        (0, i.mtaReport)();
    },
    onReady: function() {
        (0, i.checkLogin)(this.init);
    },
    onShow: function() {},
    init: function() {
        var i = this;
        e.homeRequest.indexWord().then(function(e) {
            var n = e.status, a = e.result;
            "success" === n ? i.drawCanvas(a) : (0, t.showToast)(a.error_msg);
        }).catch(function() {
            (0, t.showToast)("获取日签信息失败");
        });
    },
    drawCanvas: function(e) {
        var n = this, a = e.word, o = a.word, s = a.author, r = e.url, h = getApp().globalData, c = h.systemInfo, l = h.ky_platform, u = this.data, d = u.width, f = u.height, g = u.bannerHeight, w = u.uiSize, p = wx.createCanvasContext("daySign", this);
        this.ratio = c.windowWidth / (2 * w);
        var m = function(t) {
            return Math.round(t * n.ratio);
        }, T = (0, t.promisify)(wx.getImageInfo);
        (0, t.showLoading)({
            title: "正在生成图片..."
        }), T({
            src: (0, i.imgResize)(r, {
                w: d,
                h: g,
                format: "jpg",
                Q: 60
            })
        }).then(function(t) {
            return 1 !== l && n.roundRect(p, 0, 0, m(d), m(f), m(12)), p.drawImage(t.path, 0, 0, m(d), m(f)), 
            p.save(), p.fillStyle = "rgba(0, 0, 0, .3)", p.fillRect(0, 0, m(d), m(f)), p.restore(), 
            T({
                src: n.data.titleText
            });
        }).then(function(t) {
            p.save(), p.drawImage(t.path, m(229), m(18), m(213), m(28)), p.restore();
            var e = (0, i.currentDate)(), a = e.year, r = e.month, h = e.date;
            p.setTextAlign("center"), p.setTextBaseline("middle"), p.setFillStyle("#fff"), p.setFontSize(m(180)), 
            p.fillText(h, m(126), m(199), m(240)), p.save(), p.translate(m(596), m(202)), p.rotate(90 * Math.PI / 180), 
            p.setFontSize(m(28));
            p.fillText("".concat([ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ][r], " . ").concat(a), m(0), m(0)), 
            p.restore(), p.setStrokeStyle("rgba(255, 255, 255, .5)"), p.lineWidth = .5, p.beginPath(), 
            p.moveTo(m(38) - .5, m(311)), p.lineTo(m(632) - .5, m(311)), p.stroke(), p.setFillStyle("#fff"), 
            p.setTextAlign("left");
            var c = n.fillMultiLineText({
                word: "".concat(o),
                x: m(38),
                y: m(406.5),
                maxWidth: m(610),
                fontSize: m(34),
                lineHeight: m(48),
                context: p
            }), l = m(463) + c.height;
            p.setTextAlign("right"), p.setFontSize(m(30));
            var u = "".concat(s);
            p.fillText(u, m(621), l);
            var d = (0, i.measureText)(u, m(30)).width;
            p.setStrokeStyle("rgba(255, 255, 255, .6)"), p.beginPath(), p.setLineWidth = .5;
            var f = m(598) - d;
            return p.moveTo(f - .5, l), p.lineTo(f - m(62) - .5, l), p.stroke(), T({
                src: n.data.slogan
            });
        }).then(function(t) {
            return p.save(), p.drawImage(t.path, m(41), m(796), m(182), m(47)), p.restore(), 
            T({
                src: n.data.qrCode
            });
        }).then(function(e) {
            p.setFillStyle("#fff"), p.drawImage(e.path, m(525), m(758), m(100), m(100)), p.restore(), 
            (0, t.hideLoading)(), p.draw(), n.setData({
                finished: !0
            });
        });
    },
    fillMultiLineText: function(t) {
        for (var e = t.word, n = t.x, a = t.y, o = t.maxWidth, s = t.fontSize, r = t.lineHeight, h = t.context, c = [], l = 0, u = Math.floor(o / s); (0, 
        i.getStrLen)(e) > 2 * u * l; ) c.push(e.substr(u * l, u)), ++l;
        return h.setFontSize(s), c.forEach(function(t, e) {
            h.fillText(t, n, a + e * r, o);
        }), {
            height: l * r,
            width: o
        };
    },
    roundRect: function(t, e, i, n, a, o) {
        t.beginPath(), t.setStrokeStyle("transparent"), t.arc(e + o, i + o, o, Math.PI, 1.5 * Math.PI), 
        t.moveTo(e + o, i), t.lineTo(e + n - o, i), t.lineTo(e + n, i + o), t.arc(e + n - o, i + o, o, 1.5 * Math.PI, 2 * Math.PI), 
        t.lineTo(e + n, i + a - o), t.lineTo(e + n - o, i + a), t.arc(e + n - o, i + a - o, o, 0, .5 * Math.PI), 
        t.lineTo(e + o, i + a), t.lineTo(e, i + a - o), t.arc(e + o, i + a - o, o, .5 * Math.PI, Math.PI), 
        t.lineTo(e, i + o), t.lineTo(e + o, i), t.stroke(), t.closePath(), t.clip(), t.save();
    },
    onSaveImage: function() {
        var e = this;
        (0, i.checkQuikAuth)({
            scope: "scope.writePhotosAlbum"
        }).then(function(t) {
            e.saveShareImage();
        }).catch(function(i) {
            var n = i.err, a = i.isQuikFail;
            console.log(n, a), /authorize:fail/.test(n.errMsg) ? a ? e.showSettingTip() : (0, 
            t.showToast)("由于您拒绝授权，图片保存失败") : (0, t.showToast)(JSON.stringify(n));
        });
    },
    showSettingTip: function() {
        this.setData({
            showSetting: !0
        });
    },
    hideSettingTip: function() {
        this.setData({
            showSetting: !1
        });
    },
    saveShareImage: function() {
        var e = this;
        if ((0, i.mtaReport)("day_timeline"), this.data.finished) {
            var n = function(t) {
                return t * e.ratio;
            };
            (0, t.showLoading)({
                title: "正在保存图片.."
            });
            wx.canvasToTempFilePath({
                x: 0,
                y: 0,
                width: n(this.data.width),
                height: n(this.data.height),
                canvasId: "daySign",
                success: function(e) {
                    wx.saveImageToPhotosAlbum({
                        filePath: e.tempFilePath,
                        success: function(t) {
                            wx.showToast({
                                title: "保存到相册成功",
                                duration: 1500
                            });
                        },
                        fail: function(t) {
                            wx.showToast({
                                title: "保存到相册失败",
                                icon: "fail"
                            });
                        },
                        complete: function(e) {
                            (0, t.hideLoading)();
                        }
                    });
                },
                fail: function(t) {
                    wx.showToast({
                        title: "转换图片失败",
                        icon: "fail"
                    });
                },
                complete: function(t) {}
            }, this);
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, i.mtaReport)("day_share"), {
            title: "呼吸冥想",
            path: "/pages/index/index"
        };
    }
});