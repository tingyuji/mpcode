var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/defineProperty"), o = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../libs/wxapi"), r = require("../../request/index"), i = require("../../utils/index"), n = e(require("../../libs/underscore"));

Page({
    data: {
        common: [],
        list: [],
        keyword: "",
        filtered: null
    },
    components: {
        toast: {},
        loadingView: {
            show: !1
        },
        systemRecord: {}
    },
    onShow: function() {
        getApp();
        this.systemRecordStart();
    },
    onHide: function() {
        var e = getApp();
        this.systemRecordReport(e.globalData.unionid, "countryCode");
    },
    onUnload: function() {
        var e = getApp();
        this.systemRecordReport(e.globalData.unionid, "countryCode");
    },
    onLoad: function(e) {
        e.id;
        this.init();
    },
    getCountryCodeData: function() {
        var e = this, t = getApp().globalData;
        t.countryCodeData ? this.setData(o({}, t.countryCodeData)) : r.homeRequest.countryCodeData().then(function(a) {
            "success" == a.status && (e.setData(o({}, a.result)), t.countryCodeData = a.result);
        });
    },
    init: function() {
        this.getCountryCodeData();
    },
    onCCTap: function(e) {
        var t = getApp().globalData, o = e.currentTarget.dataset.item;
        t.countryCode = o, (0, a.setStorage)("countryCode", o), (0, a.navigateBack)();
    },
    onSearchInputConfirm: function() {
        this.filterCC();
    },
    filterCC: function(e) {
        var t = this.data, o = t.keyword, a = t.list, r = null;
        "" != (o = (0, i.trim)(o).toLocaleLowerCase()) && (r = n.default.filter(a, function(e) {
            var t = e.name, a = e.desc, r = e.code;
            return t.toLocaleLowerCase().indexOf(o) > -1 || a.toLocaleLowerCase().indexOf(o) > -1 || (r + "").indexOf(o) > -1;
        })), this.setData({
            filtered: r
        });
    },
    bindKeyInput: function(e) {
        var o = e.target.id, a = e.detail.value;
        this.setData(t({}, o, a)), this.filterCC();
    }
});