var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../libs/wxapi"), i = require("../../utils/index"), s = require("../../request/index"), a = require("../../components/shareActive");

Page({
    data: {
        showFree: !1,
        showShare: !1,
        shareOptions: null,
        imgIsEnd: !1,
        showImg: !1,
        learn_seconds: 0,
        curr_learn_seconds: 0,
        clear_curr_learn_seconds: !1,
        courseName: "",
        canOperate: !1,
        isPlaying: !1,
        showPlayActive: !1,
        isStopped: !0,
        totalProcessNum: 100,
        currentProcessNum: 0,
        canSlider: !1,
        isSliderShow: !0,
        isMovingSlider: !1,
        playInfo: {
            currentTime: "0:00",
            duration: "0:00",
            process: 0,
            procPos: {
                x: 0,
                y: 18
            },
            procPosOrigin: {
                x: 0,
                y: 18
            }
        },
        course: {},
        marketing: null,
        id: "",
        lessonId: "",
        courseId: "",
        soundType: "",
        audioInfo: {
            can_study: 0,
            id: "",
            lesson: "",
            resource_time: 0,
            resource_url: "",
            show_type: "",
            summary: "",
            title: "",
            user_study: 2
        },
        currentCouseId: ""
    },
    onLoad: function(e) {
        var t = this;
        (0, i.mtaReport)(), (0, i.mtaReport)("play_in"), this.options = e, (0, i.checkLogin)(function() {
            return t.init(e);
        });
    },
    onReady: function() {},
    onShow: function() {
        wx._trackEvent("v1_pv_play", {
            userid: getApp().globalData.user_id
        }), this.data.isPlaying && this.setData({
            showPlayActive: !0
        }), this.recoverTimeReport();
    },
    onHide: function() {
        this.data.showPlayActive && this.setData({
            showPlayActive: !1
        });
    },
    recoverTimeReport: function() {
        this.learnedTime = this.getRecoverTime(), this.learnedTime > 0 && this.reportTime({
            learnedTime: this.learnedTime
        });
    },
    getRecoverTime: function() {
        if (!this.data.isPlaying) return 0;
        getApp().globalData;
        var e = this.data.audioInfo.show_type, t = this.originTime, i = this.lastTime, s = 2 == e ? 1 / 0 : this.resource_time - this.originTime, a = this.learnedTime;
        if (this.lastTime = new Date().getTime(), this.originTime = this.backgroundPlayer.currentTime, 
        void 0 !== t && i) {
            var r = (new Date().getTime() - i) / 1e3 + this.learnedTime;
            return a += r > s ? s : r;
        }
        return 0;
    },
    hideRecordTime: function() {},
    onUnload: function() {
        this.saveGlobalPlayerInfo({
            currentTime: this.data.isStopped ? "0" : this.currentTime
        }), this.addPlayedTime(), this.learnedTime > 0 && this.reportTime({
            learnedTime: this.learnedTime
        }), this.stopAudio();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this.data.course;
        return e ? ((0, i.mtaReport)("play_share", {
            id: this.data.audioInfo.id
        }), this.shareObj || {
            title: "这里有一门超实用的冥想课程，快来看看吧！",
            imageUrl: i.com_share_card_img,
            path: (0, i.shareLink)("/pages/course/course?id=" + e.id + "&from=share"),
            success: function(e) {
                console.log("onShareAppMessage success");
            },
            fail: function(e) {
                console.log("onShareAppMessage fail");
            },
            compelete: function(e) {
                console.log("onShareAppMessage compelete");
            }
        }) : null;
    },
    onCollectClick: function(i) {
        var s = this;
        if (this.data.canOperate) {
            var a = i.currentTarget.dataset.item;
            this.setCollect(a.user_stars, function(i, r) {
                if (i) return (0, t.showToast)(i);
                s.setData({
                    course: e(e({}, s.data.course), {}, {
                        user_stars: 1 == a.user_stars ? 2 : 1
                    })
                });
            });
        } else (0, t.showToast)("暂不可操作");
    },
    doFreeConfirm: function() {
        this.hideMarketingTip();
    },
    onFreeCancel: function() {
        this.hideMarketingTip();
    },
    showMarketingTip: function() {
        var e = this.data, t = e.course, i = (e.audioInfo.title, t.marketing), s = void 0 === i ? {} : i, r = t.id, o = s.sharekey, n = void 0 === o ? "" : o, u = s.id, d = void 0 === u ? "" : u;
        this.shareObj = (0, a.getShareText)({
            id: d,
            sharekey: n,
            courseId: r
        }), this.setData({
            showFree: !0
        }), this.hideSlider();
    },
    hideMarketingTip: function() {
        this.shareObj = null, this.setData({
            showFree: !1
        }), this.showSlider();
    },
    onShareBtnClick: function(e) {
        if (this.data.canOperate) {
            var i = e.currentTarget.dataset.course;
            i && i.marketing ? this.showMarketingTip() : this.showShareTip();
        } else (0, t.showToast)("暂不可操作");
    },
    onShareHide: function() {
        this.setData({
            showShare: !1
        });
    },
    onShareTimeline: function(e) {
        (0, i.mtaReport)("play_timeline", {
            id: this.data.audioInfo.id
        }), this.showCardImgTip();
    },
    showCardImgTip: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this.data, i = t.course, s = t.audioInfo.title;
        this.setData({
            courseName: i.title || s,
            imgIsEnd: e,
            showImg: !0
        }), this.hideSlider();
    },
    hideCardImgTip: function() {
        this.setData({
            imgIsEnd: !1,
            showImg: !1
        }), this.showSlider();
    },
    showShareTip: function(s) {
        var a = this.data, r = a.course, o = a.lessonId, n = a.soundType, u = {
            title: "这里有一门超实用的冥想课程，快来看看吧！",
            imageUrl: i.com_share_card_img,
            path: ""
        };
        r ? ("mini_course" == n ? this.shareObj = e(e({}, u), {}, {
            path: (0, i.shareLink)("/pages/play/play?lessonId=".concat(o, "&type=").concat(n, "&from=share"))
        }) : 1 == r.type ? this.shareObj = e(e({}, u), {}, {
            path: (0, i.shareLink)("/pages/play/play?courseId=".concat(r.id, "&type=").concat(n, "&from=share"))
        }) : this.shareObj = e(e({}, u), {}, {
            path: (0, i.shareLink)("/pages/course/course?id=".concat(r.id, "&from=share"))
        }), this.setData({
            showShare: !0
        })) : (0, t.showToast)("课程数据未获取到,暂无法分享");
    },
    init: function() {
        var e = this, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.options;
        (0, t.hideShareMenu)();
        var s = wx.getSystemInfoSync();
        this.ratio = s.windowWidth / 375;
        var a = getApp();
        this.backgroundPlayer = a.globalData.backgroundPlayer, this.shareObj = null, this.learnedTime = 0, 
        this.needSeekTime = 0, this.setData({
            courseId: i.courseId || "",
            lessonId: i.lessonId || "",
            soundType: i.type || ""
        });
        var r = this.getGlobalPlayerInfo(), o = r.courseId, n = r.lessonId, u = r.soundType, d = r.currentTime;
        (o && o == this.data.courseId || n && n == this.data.lessonId) && u == this.data.soundType && (this.currentTime = d), 
        this.clearGlobalPlayerInfo(), this.getPageData(function(i, s) {
            if (i) return setTimeout(function() {
                (0, t.navigateBack)();
            }, 2e3), (0, t.showToast)(i);
            e.setData({
                canOperate: !0
            });
            var a = e.data, r = a.courseId, o = a.lessonId, n = a.soundType;
            e.saveGlobalPlayerInfo({
                courseId: r,
                lessonId: o,
                soundType: n
            }), e.initPage(s);
        });
    },
    initPage: function(t) {
        var i = t.course, s = this.data.audioInfo;
        this.setData({
            audioInfo: e(e({}, s), t),
            course: i || {},
            marketing: i.marketing || null
        }), this.showDuration(t.resource_time), this.startPlayAudio(t);
    },
    startPlayAudio: function() {
        var e = this, s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.audioInfo, a = s.resource_url, r = s.title, o = s.resource_time, n = s.can_study;
        1 === n && (this.isReplay = !1, this.playAudio({
            resource_url: a,
            title: r,
            resource_time: o
        }, this.currentTime), this.backgroundPlayer.onPlay(function() {
            e.isReplay || (0, t.hideLoading)(), e.isReplay = !1, e.addPlayedTime(), e.onPlay();
        }), this.backgroundPlayer.onPause(function() {
            e.onPause();
        }), this.backgroundPlayer.onStop(function() {
            e.onStop();
        }), this.backgroundPlayer.onTimeUpdate(function(t) {
            e.onTimeUpdate();
        }), this.backgroundPlayer.onEnded(function() {
            (0, i.mtaReport)("play_end", {
                id: e.data.audioInfo.id
            }), e.onAudioPlayEnded();
        }));
    },
    onPlay: function() {
        this.setData({
            isPlaying: !0,
            showPlayActive: !0,
            isStopped: !1,
            canSlider: !0
        }), this.data.clear_curr_learn_seconds && this.setData({
            clear_curr_learn_seconds: !1,
            curr_learn_seconds: 0
        }), this.needSeekTime && (this.doSeek(this.needSeekTime), this.needSeekTime = 0);
    },
    onPause: function() {
        this.setData({
            isPlaying: !1,
            showPlayActive: !1
        }), this.addPlayedTime();
    },
    onTimeUpdate: function() {
        this.currentTime = this.backgroundPlayer.currentTime, this.data.isMovingSlider || (this.setCurrTimeShow(this.currentTime), 
        this.showProcess(this.currentTime));
    },
    addPlayedTime: function(e) {
        e = this.backgroundPlayer ? this.backgroundPlayer.currentTime : 0, this.originTime = this.originTime || 0;
        var t = e - this.originTime;
        this.learnedTime += t, (!this.originTime && this.learnedTime || this.learnedTime >= 10) && this.reportTime({
            learnedTime: this.learnedTime
        }), this.originTime = e, this.lastTime = new Date().getTime();
    },
    onStop: function() {
        this.setData({
            isPlaying: !1,
            showPlayActive: !1,
            isStopped: !0,
            canSlider: !1
        });
    },
    onAudioPlayEnded: function() {
        var e = this;
        this.learnedTime = this.getRecoverTime(), this.setData({
            isPlaying: !1,
            showPlayActive: !1,
            canSlider: !1
        }), this.stopAudio(), 2 == this.data.audioInfo.show_type ? (this.reportTime({
            learnedTime: this.learnedTime,
            is_begin: 0,
            is_end: !0
        }), setTimeout(function() {
            e.isReplay = !0, e.playAudio();
        }, 0)) : this.reportTime({
            learnedTime: this.learnedTime,
            is_begin: 0,
            is_end: !0
        }, function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            e.setData({
                learn_seconds: t
            }), e.showCardImgTimer && clearTimeout(e.showCardImgTimer), e.showCardImgTimer = setTimeout(function() {
                e.showCardImgTip(!0), e.setData({
                    clear_curr_learn_seconds: !0
                });
            }, 300);
        });
    },
    clearGlobalPlayerInfo: function() {
        getApp().globalData.playerInfo = {
            courseId: "",
            lessonId: "",
            soundType: "",
            currentTime: ""
        };
    },
    saveGlobalPlayerInfo: function(t) {
        var i = getApp(), s = i.globalData.playerInfo || {}, a = t || {}, r = a.courseId, o = a.lessonId, n = a.soundType, u = a.currentTime;
        i.globalData.playerInfo = e(e({}, s), {}, {
            courseId: r || s.courseId,
            lessonId: o || s.lessonId,
            soundType: n || s.soundType,
            currentTime: u || s.currentTime
        });
    },
    getGlobalPlayerInfo: function() {
        var e = getApp().globalData.playerInfo || {};
        return {
            courseId: e.courseId || "",
            lessonId: e.lessonId || "",
            soundType: e.soundType || "",
            currentTime: e.currentTime
        };
    },
    stopAudio: function() {
        this.backgroundPlayer && this.data.isPlaying && this.backgroundPlayer.stop(), this.setData({
            isStopped: !0
        }), this.currentTime = 0, this.setCurrTimeShow(this.currentTime), this.showProcess(this.currentTime);
    },
    playAudio: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.audioInfo, i = e.resource_url, s = e.title, a = e.resource_time, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, o = this.data.isStopped;
        r = Math.floor(r) || 0, this.playTimer && clearTimeout(this.playTimer), this.backgroundPlayer && (o ? i && (this.isReplay || (0, 
        t.showLoading)("正在加载声音…"), this.originTime = r, this.backgroundPlayer.startTime = r, 
        this.backgroundPlayer.src = i, this.backgroundPlayer.title = s, this.resource_time = a, 
        this.reportTime({
            learnedTime: 0,
            is_begin: r ? 0 : 1
        })) : this.backgroundPlayer && this.backgroundPlayer.play());
    },
    onPlayClick: function(e) {
        e.currentTarget.dataset.course;
        this.switchPlay();
    },
    switchPlay: function() {
        this.data.isPlaying ? this.backgroundPlayer.pause() : (this.isReplay = !1, this.playAudio());
    },
    onSliderChanging: function(e) {
        var t = e.detail.value / this.data.totalProcessNum * this.resource_time;
        this.setCurrTimeShow(t);
    },
    onSliderChange: function(e) {
        var t = e.detail.value / this.data.totalProcessNum * this.resource_time;
        this.doSeek(t);
    },
    doSeek: function(e) {
        return this.addPlayedTime(), (e = Number(e)) >= this.resource_time ? (this.stopAudio(), 
        void this.onAudioPlayEnded()) : this.data.isPlaying ? (this.originTime = e, void this.backgroundPlayer.seek(e)) : (this.backgroundPlayer.play(), 
        void (this.needSeekTime = e));
    },
    onSliderStart: function(e) {
        this.setData({
            isMovingSlider: !0
        });
    },
    onSliderEnd: function(e) {
        getApp().globalData.courseFinish = {
            id: this.data.currentCouseId,
            progress: 3
        }, this.setData({
            isMovingSlider: !1
        });
    },
    showSlider: function() {
        this.setData({
            isSliderShow: !0
        });
    },
    hideSlider: function() {
        this.setData({
            isSliderShow: !1
        });
    },
    setCurrTimeShow: function(t) {
        this.setData({
            playInfo: e(e({}, this.data.playInfo), {}, {
                currentTime: (0, i.second2minute)(t).str
            })
        });
    },
    showDuration: function(t) {
        this.setData({
            totalProcessNum: t,
            playInfo: e(e({}, this.data.playInfo), {}, {
                duration: (0, i.second2minute)(t).str
            })
        });
    },
    showProcess: function(e) {
        var t = this.data, i = t.playInfo, s = t.audioInfo.resource_time, a = (i.procPosOrigin, 
        e / s);
        this.setData({
            currentProcessNum: Math.floor(a * this.data.totalProcessNum)
        });
    },
    minusLearnedTime: function(e) {
        this.learnedTime -= e;
    },
    reportTime: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.learnedTime, i = e.is_begin, a = void 0 === i ? 0 : i, r = e.is_end, o = void 0 === r ? 0 : r, n = arguments.length > 1 ? arguments[1] : void 0, u = Math.round(t);
        this.minusLearnedTime(u), this.setData({
            curr_learn_seconds: this.data.curr_learn_seconds + u
        });
        var d = 2;
        o && (d = 3);
        var h = this.data.audioInfo, l = h.id, c = h.course;
        c ? u < 0 || 0 === u && 2 === d || ("mini_course" !== this.data.soundType ? s.mediRequest.setLessonStudy({
            type: d,
            id: l,
            is_begin: a,
            course_id: c.id,
            learn_seconds: u
        }).then(function(e) {
            if ("success" === e.status) {
                var t = (e.result || {}).learn_seconds;
                n && n(t);
            }
        }) : s.homeRequest.setMiniCourseStudy({
            type: d,
            id: l,
            course_id: c.id,
            learn_seconds: u
        }).then(function(e) {
            if ("success" === e.status) {
                var t = (e.result || {}).learn_seconds;
                n && n(t);
            }
        })) : console.log("课程数据未获取到,暂无法上报");
    },
    transMini2Course: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.id, s = t.audio_time, a = t.audio_url, r = (t.audio_url_show, 
        t.bg_img, t.commend_img, t.create_time, t.sort, t.status, t.title);
        t.type, t.update_time;
        return e(e({}, t), {}, {
            can_study: 1,
            id: i,
            course: {
                type: 1
            },
            resource_time: s,
            resource_url: a,
            title: r
        });
    },
    getPageData: function(e) {
        var i = this;
        (0, t.showLoading)("获取课节数据..."), "mini_course" !== this.data.soundType ? 1 != this.data.soundType ? s.mediRequest.getLessonDetail({
            id: this.data.lessonId
        }).then(function(i) {
            (0, t.hideLoading)(), "success" === i.status ? e && e(null, i.result) : e && e(i.result.error_msg, i.result);
        }) : s.mediRequest.getCourseLesson({
            id: this.data.courseId
        }).then(function(a) {
            if ((0, t.hideLoading)(), "success" === a.status) {
                var r = a.result;
                if (!r || !r.lesson || !r.lesson.length) return void (0, t.showToast)("获取音频失败");
                var o = r.lesson[0].id;
                i.setData({
                    lessonId: o,
                    currentCouseId: r.course.id
                }), s.mediRequest.getLessonDetail({
                    id: o
                }).then(function(t) {
                    "success" === t.status ? e && e(null, t.result) : e && e(t.result.error_msg, t.result);
                });
            } else e && e(a.result.error_msg, a.result);
        }) : s.homeRequest.getMiniCourseDetail({
            id: this.data.lessonId
        }).then(function(s) {
            if ((0, t.hideLoading)(), "success" === s.status) {
                var a = i.transMini2Course(s.result);
                e && e(null, a);
            } else e && e(s.result.error_msg, s.result);
        });
    },
    setCollect: function(e, i) {
        var a = this.data.course.id;
        (0, t.showLoading)("正在设置"), 1 != e ? s.mediRequest.setCourseStars({
            id: a
        }).then(function(e) {
            (0, t.hideLoading)(), "success" === e.status ? i && i(null, e.result) : i && i(e.result.error_msg, e.result);
        }) : s.mediRequest.setCourseUnstars({
            id: a
        }).then(function(e) {
            (0, t.hideLoading)(), "success" === e.status ? i && i(null, e.result) : i && i(e.result.error_msg, e.result);
        });
    }
});