var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../libs/wxapi"), s = require("../../request/index"), a = require("../../utils/index"), n = require("../../utils/util"), o = require("../../components/shareActive");

Page({
    data: {
        showFree: !1,
        showShare: !1,
        showIndexModal: !1,
        shareOptions: null,
        id: "",
        course: "",
        courses_1: [],
        courses_2: [],
        marketing: null,
        modalTextConf: {
            0: "查看活动",
            1: "查看活动",
            2: "继续赠课",
            3: "查看活动"
        },
        modalContentConf: {
            0: "恭喜你抢到唯一名额，可与好友一起学习！参与活动还可免费领取更多课程哦～",
            1: "Hi，老朋友！赠送的课程只有新用户才能领哦～赶紧参加赠一得一活动，超多实用课程免费领！",
            2: "啊哦～你赠送的暂时还没有好友领取，继续赠送试试吧！",
            3: "啊哦，这门课已经被其他小伙伴领走啦～没关系，参加赠一得一活动，超多实用课程等你免费领！"
        },
        status: "",
        sharekey: "",
        title: "",
        start_time: "",
        end_time: "",
        banner_img: "",
        modal_title: "",
        modal_content: "",
        share_id: "",
        show_footer: !1
    },
    components: {
        toast: {},
        loadingView: {}
    },
    modalContentConf: function(e, t) {
        return 0 == e ? "恭喜你抢到唯一名额，可与好友一起学习《" + t + "》！参与活动还可免费领取更多课程哦～" : 1 == e ? "Hi，老朋友！赠送的课程只有新用户才能领哦～赶紧参加赠一得一活动，超多实用课程免费领！" : 2 == e ? "啊哦～你赠送的《" + t + "》暂时还没有好友领取，继续赠送试试吧！" : 3 == e ? "啊哦，这门课已经被其他小伙伴领走啦～没关系，参加赠一得一活动，超多实用课程等你免费领！" : void 0;
    },
    getOne: function() {
        (0, t.backOrNavigate)("/pages/getOne/index");
    },
    getMarketData: function() {
        var e = this;
        this.startLoading(), s.mediRequest.getMarketIndex({
            id: this.data.id
        }).then(function(s) {
            e.stopLoading();
            var o = [], i = [];
            "success" === s.status ? (s.result.courses.map(function(e) {
                e.lesson_time_count = (0, a.secondFormat)(e.lesson_time_count), 1 == e.type ? o.push(e) : 2 == e.type && i.push(e);
            }), console.log((0, n.formatTime)(new Date(s.result.start_time)), 4444), e.setData({
                courses_1: o,
                courses_2: i,
                title: s.result.title,
                start_time: (0, n.formatTime)(new Date(1e3 * s.result.start_time), 2),
                end_time: (0, n.formatTime)(new Date(1e3 * s.result.end_time), 2),
                banner_img: s.result.image_show,
                share_id: s.result.id,
                show_footer: !0
            }), console.log(e.data, 7777)) : ((0, t.showToast)(s.result.error_msg), setTimeout(function() {
                (0, t.backOrNavigate)("/pages/index/index");
            }, 2e3));
        }).catch(function() {
            e.stopLoading();
        });
    },
    getStatus: function(e) {
        var a = this;
        s.mediRequest.getCourseByShare({
            sharekey: e
        }).then(function(e) {
            "success" === e.status ? (a.setData({
                status: e.result.status,
                modal_title: e.result.course.title,
                modal_content: a.modalContentConf(e.result.status, e.result.course.title),
                showIndexModal: !0
            }), setTimeout(function() {
                a.getMarketData();
            })) : ((0, t.showToast)(e.result.error_msg), setTimeout(function() {
                (0, t.backOrNavigate)("/pages/index/index");
            }, 2e3));
        });
    },
    getDetail: function(e) {
        var t = e.currentTarget.dataset, s = t.id, n = t.type;
        (0, a.link2Course)({
            id: s,
            type: n
        });
    },
    onLoad: function(e) {
        var s = this;
        (0, a.mtaReport)(), (0, a.mtaReport)("getone_in"), console.log(e, 67), (0, t.hideShareMenu)(), 
        this.shareObj = null, this.setData({
            id: e.id || ""
        }), e.sharekey ? (this.setData({
            sharekey: e.sharekey
        }), setTimeout(function() {
            (0, a.checkLogin)(s.init_hasKey);
        })) : setTimeout(function() {
            (0, a.checkLogin)(s.init_noKey);
        });
    },
    init_hasKey: function() {
        this.getStatus(this.data.sharekey);
    },
    init_noKey: function() {
        this.getMarketData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, a.mtaReport)("getone_share"), this.shareObj || {
            title: "我想和你一起学习这门超实用的课～名额有限，赶快领取吧！",
            imageUrl: a.com_share_card_img,
            path: (0, a.shareLink)("/pages/getOne/index?sharekey=" + this.data.course.share.sharekey + "&id=" + this.data.share_id + "&from=share")
        };
    },
    onCollectClick: function(s) {
        var a = this, n = s.currentTarget.dataset.item;
        this.setCollect(n.user_stars, function(s, o) {
            if (s) return (0, t.showToast)({
                title: s
            });
            a.setData({
                course: e(e({}, a.data.course), {}, {
                    stars_num: n.stars_num + (1 == n.user_stars ? -1 : 1),
                    user_stars: 1 == n.user_stars ? 2 : 1
                })
            });
        });
    },
    onLessonClick: function(e) {
        var t = e.currentTarget.dataset.item;
        1 != t.can_study ? t.marketing && this.setData({
            showFree: !0
        }) : (0, a.link2Lesson)(t);
    },
    doFreeConfirm: function() {
        (0, t.showShareMenu)(), this.onFreeCancel();
    },
    doFreeCon: function() {
        this.setData({
            showIndexModal: !1
        });
    },
    onIndexModalCancel: function() {
        this.setData({
            showIndexModal: !1
        });
    },
    onFreeCancel: function() {
        this.setData({
            showFree: !1
        });
    },
    shareCourse: function(e) {
        var t = this, s = e.currentTarget.dataset.item;
        console.log(s, 1222), this.setData({
            course: s
        }), setTimeout(function() {
            t.showMarketingTip();
        });
    },
    onShareHide: function() {
        this.setData({
            showShare: !1
        });
    },
    onShareApp: function() {},
    onShareTimeline: function(e) {
        (0, a.mtaReport)("getone_timeline"), s.mediRequest.getShareCardInfo().then(function(e) {});
    },
    showMarketingTip: function() {
        this.shareObj = (0, o.getShareText)({
            id: this.data.share_id,
            courseId: this.data.course.id,
            sharekey: this.data.course.share.sharekey
        }), this.setData({
            showFree: !0
        });
    },
    getPageData: function(e) {
        s.mediRequest.getCourseLesson({
            id: this.data.id
        }).then(function(t) {
            "success" === t.status ? e && e(null, t.result) : e && e(t.result.error_msg, t.result);
        });
    },
    setCollect: function(e, t) {
        1 != e ? s.mediRequest.setCourseStars({
            id: this.data.id
        }).then(function(e) {
            "success" === e.status ? t && t(null, e.result) : t && t(e.result.error_msg, e.result);
        }) : s.mediRequest.setCourseUnstars({
            id: this.data.id
        }).then(function(e) {
            "success" === e.status ? t && t(null, e.result) : t && t(e.result.error_msg, e.result);
        });
    }
});