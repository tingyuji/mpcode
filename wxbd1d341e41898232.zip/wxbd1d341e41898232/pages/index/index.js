var e, t = require("../../@babel/runtime/helpers/interopRequireDefault"), n = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), i = t(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../request/index"), s = require("../../libs/wxapi"), c = require("../../utils/index"), u = t(require("../../config/config")), d = t(require("../../libs/underscore"));

Page({
    data: {
        showGroup: !1,
        videoWidth: "100%",
        guide: {
            show: !1,
            poster: "",
            source: ""
        },
        inited: !1,
        banner: [],
        course: [],
        group: [],
        mini_course: [],
        word: {},
        date: {}
    },
    components: {
        loadingView: {}
    },
    onLoad: (e = r(i.default.mark(function e(t) {
        var n, a, r, h, p, l;
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((0, c.mtaReport)(), 0 === Object.keys(t).length) {
                    e.next = 15;
                    break;
                }
                if (!t.scene || void 0 === t.scene) {
                    e.next = 14;
                    break;
                }
                return e.next = 5, o.homeRequest.getQrcodeData({
                    scene: t.scene,
                    source: 13
                });

              case 5:
                n = e.sent, a = n.result, h = "/".concat((r = a).page, "?"), delete r.page, p = Object.keys(r).reduce(function(e, t) {
                    return e += "" === e ? "".concat(t, "=").concat(r[t]) : "&".concat(t, "=").concat(r[t]);
                }, ""), (0, s.backOrNavigate)("".concat(h).concat(p)), e.next = 15;
                break;

              case 14:
                this.options = t;

              case 15:
                if (t.q && (t = (0, c.anaUrlInfo)(t.q)), !t.path) {
                    e.next = 23;
                    break;
                }
                if (!(l = (0, c.checkDecode)(t.path)) || 2 === t.link_type || d.default.contains(u.default.need_no_login_url, l.replace(/\?.+$/, ""))) {
                    e.next = 21;
                    break;
                }
                return (0, c.checkLogin)(function() {
                    (0, c.gotoPath)(t);
                }, t.sessionexpire, t), e.abrupt("return");

              case 21:
                return (0, c.gotoPath)(t), e.abrupt("return");

              case 23:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {
        var e = this;
        wx._trackEvent("v1_pv_firstpage", {
            userid: getApp().globalData.user_id
        });
        var t = new Date(), n = t.getDate(), a = t.getMonth() + 1, i = t.getFullYear();
        this.setData({
            date: {
                year: i,
                month: a > 9 ? a : "0".concat(a),
                date: n > 9 ? n : "0".concat(n)
            }
        }), (0, c.checkLogin)(function() {
            e.init();
        }, this.options.sessionexpire, this.options);
    },
    onHide: function() {
        this.setData({
            inited: !1
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(e) {
        return (0, c.defaultShareObj)();
    },
    getData: function() {
        var e = this;
        this.startLoading(), o.homeRequest.index().then(function(t) {
            var i = t.status, r = t.result;
            if (e.stopLoading(), "success" === i) {
                var o, c = {}, d = a(r.banner);
                try {
                    for (d.s(); !(o = d.n()).done; ) {
                        var h = o.value;
                        if (4 == h.link_type) {
                            c = n({}, h);
                            break;
                        }
                    }
                } catch (e) {
                    d.e(e);
                } finally {
                    d.f();
                }
                e.setData(n(n({}, r), {}, {
                    guide: n(n({}, e.data.guide), {}, {
                        poster: c.cover || "",
                        source: c.link || ""
                    })
                })), (0, s.getStorage)(u.default.GUIDE_SHOW_KEY).then(function(t) {
                    1 == t.data && ((0, s.removeStorage)(u.default.GUIDE_SHOW_KEY), e.doShowGuide());
                }).catch(function(e) {});
            }
        }).catch(function() {
            e.stopLoading();
        });
    },
    init: function() {
        if (this.data.inited) return !1;
        this.getData(), this.getWords(), this.setData({
            inited: !0
        });
    },
    getWords: function() {
        var e = this;
        o.homeRequest.indexWord().then(function(t) {
            var a = t.status, i = t.result;
            "success" === a && e.setData({
                word: n({}, i.word)
            });
        });
    },
    authLinkTo: function(e) {
        var t = e.currentTarget.dataset, n = t.id, a = t.path, i = t.type;
        switch (i) {
          case "mini_course":
            (0, c.mtaReport)("index_mini", {
                id: n
            });
            break;

          case "daySign":
            (0, c.mtaReport)("index_daysign");
            break;

          default:
            (0, c.mtaReport)("index_course", {
                id: n
            });
        }
        "/pages/play/play" !== a && "/pages/course/course" !== a ? (n && (a += "?id=".concat(n, "&type=").concat(i)), 
        (0, s.backOrNavigate)(a)) : "mini_course" === i ? (0, c.link2Lesson)({
            id: n,
            type: i
        }) : (0, c.link2Course)({
            id: n,
            type: i
        });
    },
    bannerLinkTo: function(e) {
        var t = e.currentTarget.dataset.item, n = t.appid, a = t.link_type, i = t.link;
        (0, c.mtaReport)("index_banner", {
            link: i
        });
        4 != a ? (0, c.gotoPath)({
            app_id: n,
            link_type: a,
            path: i
        }) : this.doShowGuide();
    },
    doShowGuide: function() {
        this.setData({
            "guide.show": !0
        });
    },
    doHideGuide: function() {
        this.setData({
            "guide.show": !1
        });
    },
    onFullscreenChange: function(e) {
        var t = e.detail.fullscreen, n = getApp().globalData.systemInfo;
        if (!t) {
            var a = 670 * n.windowWidth / 750;
            this.setData({
                videoWidth: "".concat(a, "px")
            });
        }
    }
});