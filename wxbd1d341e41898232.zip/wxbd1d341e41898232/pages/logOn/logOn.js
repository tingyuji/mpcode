var n = require("../../libs/wxapi"), e = require("../../request/index");

Page({
    data: {
        checkState: !1
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    checkPolicyFun: function() {
        this.setData({
            checkState: !this.data.checkState
        });
    },
    toPolicyFun: function() {
        (0, n.navigate)("/pages/webview/webview?url=https://kyapp.knowyourself.cc/privacyPolicy");
    },
    loginFun: function() {
        var n = this;
        this.data.checkState ? wx.getUserProfile({
            desc: "用于完善资料",
            success: function(e) {
                n.logonFun();
            }
        }) : wx.showToast({
            title: "请先阅读并同意月食隐私政策",
            icon: "none"
        });
    },
    logonFun: function() {
        var t = getApp();
        e.userRequest.getUserInfo().then(function(e) {
            var o = e.result;
            t.globalData.userInfoData = o, wx.reLaunch({
                url: "/pages/index/index"
            }), (0, n.setStorage)("loginState", !0);
        });
    }
});