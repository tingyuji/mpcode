var t = require("../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../request/index"), a = require("../../../libs/wxapi"), e = require("../../../utils/index");

Page({
    data: {
        statusBarHeight: 0,
        titleBarHeight: 0,
        activeTab: "discus",
        showQuit: !1,
        showJoin: !1,
        showMobile: !1,
        detail: {},
        sort: 0,
        topic: {
            count: 0,
            list: []
        },
        userInfo: {}
    },
    components: {
        loadingView: {
            show: !1
        },
        toast: {}
    },
    onLoad: function(t) {
        this.id = t.id, (0, e.checkLogin)(this.init);
    },
    init: function() {
        this.getDetail(), this.getTopics(!0), this.getUserInfo();
    },
    getTopics: function() {
        var a = this, o = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this.inLock || (o && this.startLoading(), this.inLock = !0, i.groupRequest.getTopics({
            group_id: this.id,
            offset: o ? 0 : this.data.topic.list.length,
            sort: this.data.sort,
            limit: 10
        }).then(function(i) {
            var s = i.status, n = i.result, u = n.count, c = n.items;
            a.inLock = !1, a.stopLoading(), "success" === s && (c = c.map(function(t) {
                return t.last_update = (0, e.timeFormat)(+t.last_reply.create_time || t.create_time), 
                t;
            }), a.setData({
                topic: {
                    count: u,
                    list: o ? c : [].concat(t(a.data.topic.list), t(c))
                }
            }));
        }).catch(function() {
            a.inLock = !1, a.stopLoading();
        }));
    },
    getDetail: function() {
        var t = this;
        i.groupRequest.groupDetail(this.id).then(function(i) {
            var a = i.status, o = i.result;
            "success" === a && (o.create_time_show = (0, e.parseDateToLocalString)(o.create_time_show), 
            t.setData({
                detail: o
            }));
        });
    },
    doQuit: function() {
        this.setData({
            showQuit: !0
        });
    },
    doEnter: function() {
        var t = this;
        i.groupRequest.enterGroup(this.id).then(function(i) {
            var a = i.status, e = i.result;
            "success" === a ? (t.setData({
                "detail.follow": 1
            }), t.toast(null, "加入成功")) : t.toast(null, e.error_msg);
        }).catch(function() {
            t.toast(null, "操作失败");
        });
    },
    doQuitConfirm: function() {
        var t = this;
        i.groupRequest.quitGroup(this.id).then(function(i) {
            var a = i.status, e = i.result;
            "success" === a ? (t.setData({
                "detail.follow": 0
            }), t.toast(null, "退出成功")) : t.toast(null, e.error_msg);
        }).catch(function() {
            t.toast(null, "操作失败");
        }), this.doQuitCancel();
    },
    doQuitCancel: function() {
        this.setData({
            showQuit: !1
        });
    },
    doJoinConfirm: function() {
        this.doEnter(), this.doJoinCancel();
    },
    doJoinCancel: function() {
        this.setData({
            showJoin: !1
        });
    },
    doMobileConfirm: function(t) {
        var i = t.detail.mobile, e = this.data.detail;
        this.setData({
            "userInfo.mobile": i
        }), this.doMobileCancel(), e.follow ? (0, a.backOrNavigate)("/pages/planet/newDiscussion/index?group_id=".concat(this.id)) : this.setData({
            showJoin: !0
        });
    },
    doMobileCancel: function() {
        this.setData({
            showMobile: !1
        });
    },
    onReady: function() {
        var t = getApp().globalData, i = t.statusBarHeight, a = t.titleBarHeight;
        this.setData({
            statusBarHeight: i,
            titleBarHeight: a
        });
    },
    onShow: function() {
        var t = getApp().globalData.userInfoData;
        t && this.setData({
            userInfo: t
        });
        var i = this.selectComponent("#mobile");
        i && i.setupMB();
    },
    getUserInfo: function() {
        var t = this, a = getApp(), o = a.globalData.userInfoData;
        o ? this.setData({
            userInfo: o
        }) : i.userRequest.getUserInfo().then(function(i) {
            var o = i.status, s = i.result;
            "success" === o && (s = (0, e.transNickName)(s), t.setData({
                userInfo: s
            }), a.globalData.userInfoData = s);
        }).catch(function() {});
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var t = this.data.topic, i = t.count;
        t.list.length < i && this.getTopics();
    },
    onShareAppMessage: function() {
        var t = this.data.detail;
        return {
            title: t.title,
            path: "/pages/planet/detail/detail?id=".concat(t.id)
        };
    },
    doSortWayChange: function(t) {
        this.setData({
            sort: t.detail
        }), this.getTopics(!0);
    },
    doChangeTab: function(t) {
        var i = t.currentTarget.dataset.tab;
        this.setData({
            activeTab: i
        });
    },
    authLinkTo: function(t) {
        var i = t.currentTarget.dataset, e = i.id, o = i.path;
        (0, a.backOrNavigate)("".concat(o, "?id=").concat(e));
    },
    linkToAdd: function() {
        var t = this.data, i = t.userInfo, e = t.detail;
        i.mobile ? e.follow ? (0, a.backOrNavigate)("/pages/planet/newDiscussion/index?group_id=".concat(this.id)) : this.setData({
            showJoin: !0
        }) : this.setData({
            showMobile: !0
        });
    },
    goBack: function() {
        (0, a.backOrNavigate)("/pages/planet/index/index");
    }
});