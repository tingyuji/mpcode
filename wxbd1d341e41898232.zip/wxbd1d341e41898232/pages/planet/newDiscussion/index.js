var t = require("../../../@babel/runtime/helpers/toConsumableArray"), e = require("../../../@babel/runtime/helpers/defineProperty"), i = require("../../../request/index"), a = require("../../../request/constent"), o = require("../../../libs/wxapi"), n = require("../../../utils/index");

Page({
    data: {
        images: [],
        showConfirm: !1,
        title: "",
        content: ""
    },
    components: {
        loadingView: {},
        toast: {}
    },
    onLoad: function(t) {
        this.group_id = t.group_id, (0, n.checkLogin)();
    },
    doHideConfirm: function() {
        this.setData({
            showConfirm: !1
        });
    },
    doConfirm: function() {
        (0, o.backOrNavigate)("/pages/planet/detail/detail?id=".concat(this.group_id));
    },
    bindKeyInput: function(t) {
        var i = t.target.id;
        this.setData(e({}, i, t.detail.value));
    },
    doAdd: function(t) {
        var e = this, a = t.detail.value, s = a.title, u = a.content, r = this.data.images, c = {
            group_id: this.group_id,
            desc: u,
            images: r,
            title: s
        };
        return (0, n.trim)(s) ? (0, n.trim)(u) ? (c.title = (0, n.trim)(s), c.desc = (0, 
        n.trim)(u), this.startLoading(), void i.groupRequest.addTopic(c).then(function(t) {
            var i = t.status, a = t.result;
            if (e.stopLoading(), "success" === i) return e.toast(null, "发布成功"), void (0, o.backOrNavigate)("/pages/planet/detail/detail?id=".concat(e.group_id));
            e.toast(null, a.error_msg);
        }).catch(function() {
            e.stopLoading();
        })) : (this.toast(null, "内容不能为空~"), !1) : (this.toast(null, "标题不能为空~"), !1);
    },
    doCancel: function(t) {
        this.setData({
            showConfirm: !0
        });
    },
    doChooseImg: function(t) {
        var e = this;
        wx.chooseImage({
            count: Math.max(0, 9 - this.data.images.length),
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                var i = t.tempFilePaths;
                e.uploadImage(i);
            }
        });
    },
    uploadImage: function(e) {
        var i = this, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        (0, o.showLoading)("上传中...(".concat(s, "/").concat(e.length, ")"), {
            mask: !0
        }), wx.uploadFile({
            url: "".concat(a.commonApi, "/upload/file"),
            name: "file",
            filePath: e[s],
            success: function(e) {
                var a = (0, n.jsonDecode)(e.data);
                "success" === a.status && i.setData({
                    images: [].concat(t(i.data.images), [ a.result.url ])
                });
            },
            complete: function() {
                s >= e.length - 1 ? (0, o.hideLoading)() : i.uploadImage(e, s + 1);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, n.defaultShareObj)();
    }
});