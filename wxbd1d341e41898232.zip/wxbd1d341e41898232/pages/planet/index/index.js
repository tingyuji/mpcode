var t = require("../../../@babel/runtime/helpers/toConsumableArray"), i = require("../../../request/index"), n = require("../../../libs/wxapi"), e = require("../../../utils/index");

Page({
    data: {
        groupList: {
            count: 0,
            offset: 0,
            list: []
        },
        noticeCover: ""
    },
    onLoad: function(t) {
        (0, e.checkLogin)(this.init);
    },
    init: function() {
        this.getNotice(), this.getList();
    },
    getNotice: function() {
        var t = this;
        i.groupRequest.getNotice().then(function(i) {
            var n = i.status, e = i.result;
            "success" === n && t.setData({
                noticeCover: e.image
            });
        });
    },
    getList: function() {
        var n = this;
        this.inLock || (this.inLock = !0, i.groupRequest.groupList({
            offset: this.data.groupList.list.length
        }).then(function(i) {
            var e = i.status, o = i.result;
            if (n.inLock = !1, "success" === e) {
                var s = o.count, u = o.items;
                n.setData({
                    groupList: {
                        count: s,
                        list: [].concat(t(n.data.groupList.list), t(u))
                    }
                });
            }
        }).catch(function() {
            n.inLock = !1;
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    authLinkTo: function(t) {
        var i = t.currentTarget.dataset, e = i.id, o = i.path;
        (0, n.backOrNavigate)("".concat(o, "?id=").concat(e));
    },
    onReachBottom: function() {
        var t = this.data.groupList, i = t.list, n = t.count;
        i.length < n && this.getList();
    },
    onShareAppMessage: function() {
        return (0, e.defaultShareObj)();
    }
});