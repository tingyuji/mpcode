var t = require("../../../request/index"), n = (require("../../../libs/wxapi"), 
require("../../../utils/index"));

Page({
    data: {
        iptFocus: !1,
        hasContent: !1,
        opMap: {
            del: {
                icon: "delete",
                name: "删除此讨论"
            },
            stick: {
                icon: "stick",
                name: "置顶"
            },
            unstick: {
                icon: "stick",
                name: "取消置顶"
            },
            ban: {
                icon: "warning",
                name: "禁言3天"
            },
            unban: {
                icon: "warning",
                name: "已禁言"
            },
            share: {
                icon: "share",
                name: "分享"
            },
            edit: {
                icon: "copy",
                name: "编辑讨论"
            },
            report: {
                icon: "warning",
                name: "举报"
            },
            del2: {
                icon: "delete",
                name: "删除此评论"
            }
        },
        opModal: {
            show: !1,
            items: [ "stick", "del" ],
            data: {}
        },
        detail: {}
    },
    components: {
        loadingView: {},
        toast: {}
    },
    onLoad: function(t) {
        this.id = t.id, (0, n.checkLogin)(this.init);
    },
    init: function() {
        this.getTopic(), this.getReplyList();
    },
    getReplyList: function() {
        var n = this;
        t.groupRequest.getReplyList({
            topic_id: this.id
        }).then(function(t) {
            var i = t.status, o = t.result;
            "success" === i && n.setData({
                replyList: o
            });
        });
    },
    getTopic: function() {
        var n = this;
        this.startLoading(), t.groupRequest.getTopic(this.id).then(function(t) {
            var i = t.status, o = t.result;
            n.stopLoading(), "success" === i ? n.setData({
                detail: o
            }) : n.toast(null, o.error_msg);
        }).catch(function() {
            n.stopLoading();
        });
    },
    onReady: function() {},
    doOperation: function(t) {
        t.currentTarget.dataset.key, this.data.opModal.data;
    },
    doOpModalHide: function() {
        this.setData({
            opModal: {
                show: !1
            }
        });
    },
    onContentChange: function(t) {},
    onFocus: function() {
        this.setData({
            iptFocus: !0
        });
    },
    onBlur: function(t) {
        this.setData({
            iptFocus: !1,
            hasContent: !!t.detail.value
        });
    },
    showOp: function(t) {
        this.setData({
            opModal: {
                show: !0,
                items: [ "del", "stick" ],
                data: {}
            }
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, n.defaultShareObj)();
    },
    noop: function() {}
});