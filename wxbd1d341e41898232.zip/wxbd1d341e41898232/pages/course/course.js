var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../libs/wxapi"), s = require("../../request/index"), a = require("../../utils/index"), i = require("../../components/shareActive");

Page({
    data: {
        notFirstIn: !1,
        showFree: !1,
        showShare: !1,
        shareOptions: null,
        showImg: !1,
        canOperate: !1,
        id: "",
        titleImg: "",
        course: {},
        lesson: [],
        marketing: null
    },
    getOne: function() {
        (0, t.backOrNavigate)("/pages/getOne/index");
    },
    onLoad: function(e) {
        var t = this;
        (0, a.mtaReport)(), (0, a.mtaReport)("course_in", {
            id: this.data.id
        }), this.options = e, (0, a.checkLogin)(function() {
            return t.init(e);
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        !this.data.notFirstIn && this.data.id && (this.setData({
            notFirstIn: !0
        }), this.getPageData(function(s, i) {
            if (s) return (0, t.showToast)(s);
            var r = i.course, o = i.lesson, n = i.marketing;
            o && o.length && o.forEach(function(e) {
                e && (e.resource_time_show = (0, a.secondFormat)(e.resource_time));
            }), e.setData({
                course: r,
                lesson: o,
                marketing: n
            }), console.log(i);
        }));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this.data.course;
        if ((0, a.mtaReport)("course_share", {
            id: this.data.id
        }), !e) return null;
        var t = this.shareObj || {
            title: "这里有一门超实用的冥想课程，快来看看吧！",
            imageUrl: a.com_share_card_img,
            path: (0, a.shareLink)("/pages/course/course?id=" + e.id + "&from=share"),
            success: function(e) {
                console.log("onShareAppMessage success");
            },
            fail: function(e) {
                console.log("onShareAppMessage fail");
            },
            compelete: function(e) {
                console.log("onShareAppMessage compelete");
            }
        };
        return console.log("onShareAppMessage", t), this.shareObj;
    },
    onCollectClick: function(s) {
        var a = this;
        if (this.data.canOperate) {
            var i = s.currentTarget.dataset.item, r = getApp().globalData;
            this.setCollect(i.user_stars, function(s, o) {
                if (s) return (0, t.showToast)(s);
                a.setData({
                    course: e(e({}, a.data.course), {}, {
                        stars_num: i.stars_num + (1 == i.user_stars ? -1 : 1),
                        user_stars: 1 == i.user_stars ? 2 : 1
                    })
                }), r.followChange = {
                    id: i.id,
                    user_stars: 1 == i.user_stars ? 2 : 1
                };
            });
        } else (0, t.showToast)("暂不可操作");
    },
    onLessonClick: function(e) {
        var t = e.currentTarget.dataset.item;
        1 != t.can_study ? t.marketing && this.setData({
            showFree: !0
        }) : (0, a.link2Lesson)(t);
    },
    doFreeConfirm: function() {
        this.hideMarketingTip();
    },
    onFreeCancel: function() {
        this.hideMarketingTip();
    },
    showMarketingTip: function() {
        var e = this.data, t = e.course.id, s = e.marketing, a = s.sharekey, r = void 0 === a ? "" : a, o = s.id, n = void 0 === o ? "" : o;
        this.shareObj = (0, i.getShareText)({
            id: n,
            sharekey: r,
            courseId: t
        }), this.setData({
            showFree: !0
        });
    },
    hideMarketingTip: function() {
        this.shareObj = null, this.setData({
            showFree: !1
        });
    },
    onShareBtnClick: function(e) {
        if (this.data.canOperate) {
            var s = e.currentTarget.dataset, a = s.course, i = s.marketing;
            a && i ? this.showMarketingTip() : this.showShareTip();
        } else (0, t.showToast)("暂不可操作");
    },
    onShareHide: function() {
        this.setData({
            showShare: !1
        });
    },
    onShareTimeline: function(e) {
        (0, a.mtaReport)("course_time", {
            id: this.data.id
        }), this.setData({
            showImg: !0
        });
    },
    showCardImgTip: function() {
        this.setData({
            showImg: !0
        });
    },
    hideCardImgTip: function() {
        this.setData({
            showImg: !1
        });
    },
    showShareTip: function(e) {
        var t = this.data.course;
        this.shareObj = {
            title: "这里有一门超实用的冥想课程，快来看看吧！",
            imageUrl: a.com_share_card_img,
            path: (0, a.shareLink)("/pages/course/course?id=" + t.id + "&from=share")
        }, this.setData({
            showShare: !0
        });
    },
    init: function() {
        var e = this, s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.options;
        (0, t.hideShareMenu)(), this.shareObj = null, console.log(s), this.setData({
            id: s.id || ""
        }), this.getPageData(function(s, i) {
            if (s) return setTimeout(function() {
                (0, t.navigateBack)();
            }, 2e3), (0, t.showToast)(s);
            e.setData({
                canOperate: !0
            });
            var r = i.course, o = i.lesson, n = i.marketing;
            o && o.length && o.forEach(function(e) {
                e && (e.resource_time_show = (0, a.secondFormat)(e.resource_time));
            }), e.setData({
                course: r,
                lesson: o,
                marketing: n,
                titleImg: r ? (0, a.imgResize)(r.commend_img_show, {
                    w: 220,
                    h: 220,
                    format: "jpg",
                    Q: 60
                }) : ""
            }), 1 === r.type && o && o.length && (0, a.link2Lesson)(o[0]), console.log(i);
        });
    },
    getPageData: function(e) {
        s.mediRequest.getCourseLesson({
            id: this.data.id
        }).then(function(t) {
            "success" === t.status ? e && e(null, t.result) : e && e(t.result.error_msg, t.result);
        });
    },
    setCollect: function(e, t) {
        1 != e ? s.mediRequest.setCourseStars({
            id: this.data.id
        }).then(function(e) {
            "success" === e.status ? t && t(null, e.result) : t && t(e.result.error_msg, e.result);
        }) : s.mediRequest.setCourseUnstars({
            id: this.data.id
        }).then(function(e) {
            "success" === e.status ? t && t(null, e.result) : t && t(e.result.error_msg, e.result);
        });
    }
});