var e = require("@babel/runtime/helpers/interopRequireDefault"), a = require("./libs/wxapi"), t = e(require("umtrack-wx"));

require("/libs/wx-component/index");

var r = require("/libs/mta_analysis.js");

App({
    umengConfig: {
        appKey: "60d3f7828a102159db798f90",
        useOpenid: !0,
        autoGetOpenid: !0,
        uploadUserInfo: !0,
        debug: !1,
        enableVerify: !1
    },
    onLaunch: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.globalData.backgroundPlayer = wx.getBackgroundAudioManager(), this.checkServerTime(), 
        (0, a.getSystemInfo)().then(function(a) {
            e.globalData.systemInfo = a, /ios/i.test(a.system) ? e.globalData.ky_platform = 1 : /android/i.test(a.system) ? e.globalData.ky_platform = 2 : e.globalData.ky_platform = 3;
            var t = 44, r = a.statusBarHeight;
            t += r, e.globalData.statusBarHeight = r, e.globalData.titleBarHeight = t - r;
        }).catch(function(a) {
            e.globalData.statusBarHeight = 0, e.globalData.titleBarHeight = 0, console.log(a);
        }), t.referrerInfo && t.referrerInfo.extraData && t.referrerInfo.extraData.channelid && (this.globalData.channelid = t.referrerInfo.extraData.channelid), 
        r.App.init({
            appID: "500651736",
            eventID: "500651744",
            statPullDownFresh: !0,
            statShareApp: !0,
            statReachBottom: !0
        }), setTimeout(function() {
            e.checkUpdate();
        }, 3e3);
    },
    onShow: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.referrerInfo, r = void 0 === a ? {} : a, n = r.extraData;
        n && n.channelid && (this.globalData.channelid = n.channelid), wx._trackEvent = function(e) {
            var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            for (var r in a) if (a.hasOwnProperty(r)) {
                var n = a[r];
                a[r] = n + "";
            }
            t.default.trackEvent(e, a);
        };
    },
    checkServerTime: function() {
        var e = this, a = new Date().getTime();
        wx.request({
            url: "https://time-check.knowyourself.cc/",
            method: "GET",
            success: function(t) {
                e.globalData.serverTimeExceed = t.data - a, console.log(e.globalData.serverTimeExceed);
            }
        });
    },
    checkUpdate: function() {
        if (wx.getUpdateManager) {
            var e = wx.getUpdateManager();
            e.onCheckForUpdate(function(e) {
                console.log(e.hasUpdate);
            }), e.onUpdateReady(function() {
                wx.showModal({
                    title: "更新提示",
                    content: "新版本已经准备好，是否重启应用？",
                    success: function(a) {
                        a.confirm && e.applyUpdate();
                    }
                });
            });
        }
    },
    globalData: {
        uma: t.default,
        version: "0.1.7",
        serverTimeExceed: 0,
        systemInfo: {},
        isCheckingVerion: "",
        backgroundPlayer: null,
        uuid: "",
        channelid: "",
        mta: r,
        user_id: ""
    }
});