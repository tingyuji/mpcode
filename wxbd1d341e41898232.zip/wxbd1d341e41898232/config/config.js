Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    need_no_login_url: [ "/pages/index/index" ],
    need_tip_api: [ "/v1/user/mini-login", "/v1/user/info" ],
    tabBar_url: [ "/pages/index/index", "/pages/meditation/meditation", "/pages/planet/index/index", "/pages/mine/index/mine" ],
    HmacSHA256_sign: {
        secret: "DojHnUjJchVGfXl&",
        username: "wxmini"
    },
    GUIDE_SHOW_KEY: "ky_mt_guide_video_should_show"
};