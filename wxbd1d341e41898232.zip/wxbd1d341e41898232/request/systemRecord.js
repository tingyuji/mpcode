Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("./constent"), r = {
    report: function(r) {
        return (0, e.post)("/record/consult", r);
    },
    reportFormId: function(r) {
        return (0, e.post)("/v1/user/formid", r);
    }
};

exports.default = r;