var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), Object.defineProperty(exports, "commonApi", {
    enumerable: !0,
    get: function() {
        return i.commonApi;
    }
}), Object.defineProperty(exports, "apiHost", {
    enumerable: !0,
    get: function() {
        return i.apiHost;
    }
}), Object.defineProperty(exports, "h5Host", {
    enumerable: !0,
    get: function() {
        return i.h5Host;
    }
}), Object.defineProperty(exports, "wechatApi", {
    enumerable: !0,
    get: function() {
        return i.wechatApi;
    }
}), exports.post = exports.get = exports.source = void 0;

var t = require("../@babel/runtime/helpers/objectSpread2"), r = e(require("../libs/es6-promise")), n = e(require("../libs/crypto-js/index")), o = e(require("../config/config")), a = e(require("../libs/underscore")), i = require("./api_env");

exports.source = 10;

exports.get = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 ? arguments[2] : void 0, n = arguments.length > 3 ? arguments[3] : void 0;
    return u(e, "GET", t, r, n);
};

exports.post = function(e, t, r, n) {
    return u(e, "POST", t, r, n);
};

function c(e, t, r) {
    e = "" + e;
    var a = o.default.HmacSHA256_sign, i = a.username, c = a.secret, u = new Date(r).toUTCString(), s = function(e, t, r, o) {
        var a = "x-date: ".concat(o, "\n").concat(t, " ").concat(e, " HTTP/1.1");
        return n.default.HmacSHA256(a, r).toString(n.default.enc.Base64);
    }(e, t, c, u);
    return {
        "X-Date": u,
        Authorization: 'hmac username="'.concat(i, '", algorithm="hmac-sha256", headers="x-date request-line", signature="').concat(s, '"')
    };
}

function u() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 ? arguments[1] : void 0, o = arguments.length > 2 ? arguments[2] : void 0, a = arguments.length > 3 ? arguments[3] : void 0, u = arguments.length > 4 ? arguments[4] : void 0, d = getApp(), p = d.globalData.serverTimeExceed + Date.now();
    "GET" === n && (e = "".concat(e).concat(l(o, !0)));
    var g = c(e, n, p);
    return a = t(t({}, a), g), !/user\/mini\-login$/.test(e) && d.globalData.token && ((a = a || {})["KY-AUTH-TOKEN"] = d.globalData.token, 
    a["KY-SYSTEM"] = d.globalData.ky_platform < 3 ? d.globalData.ky_platform : "", a["KY-PLATFORM"] = 2), 
    d.globalData.version && (a["KY-WXAPP-VERSION"] = d.globalData.version), new r.default(function(t, r) {
        var c = {
            url: /^http/.test(e) ? e : i.apiHost + e,
            data: "GET" === n ? {} : o || {},
            dataType: u || "json",
            method: n || "GET"
        };
        a && (c.header = a), c.success = function(n) {
            var o = n.data || {}, a = o.result, i = o.status;
            if (n.statusCode >= 400) return s(e, n.statusCode), void r(n);
            t(n.data), "success" != i && a && 700 == a.error_code && (d.globalData.token = "", 
            d.globalData.user_id = "");
        }, c.fail = function(t) {
            s(e), r(t);
        }, wx.request(c);
    });
}

function s(e, t) {
    wx.hideLoading(), a.default.contains(o.default.need_tip_api, e) && wx.showModal({
        title: "提示",
        content: "网络异常:".concat(t || "", "，请点“刷新”按钮或稍后重试～"),
        confirmText: "刷新",
        success: function(e) {
            var t, r;
            e.confirm && (t = getCurrentPages(), r = t.length > 1 ? t[t.length - 1] : {
                route: "pages/index/index"
            }, a.default.contains(o.default.tabBar_url, "/".concat(r.route)) || "pages/index/index" === r.route ? wx.reLaunch({
                url: "/".concat(r.route).concat(l(r.options))
            }) : wx.redirectTo({
                url: "/".concat(r.route).concat(l(r.options))
            }));
        }
    });
}

function l(e, t) {
    e = e || {};
    var r = "?";
    return Object.keys(e).forEach(function(n) {
        var o = e[n];
        n && (t || o) && (1 !== r.length && (r += "&"), r += n + "=" + o);
    }), r.length > 1 ? r : "";
}