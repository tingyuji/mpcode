Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("./constent"), t = {
    login: function() {
        return new Promise(function(e, t) {
            wx.login({
                success: function(r) {
                    r.code ? e(r) : t(r);
                },
                fail: function(e) {
                    t(e || {});
                }
            });
        }).then(function(t) {
            return t.source = e.source, (0, e.post)("/v1/user/mini-login", t);
        });
    },
    updateDetail: function(t) {
        return t.source = e.source, (0, e.post)("/v1/user/update", t);
    },
    getUserInfo: function() {
        return (0, e.get)("/v1/user/info");
    },
    getUserCourse: function() {
        return (0, e.get)("/v1/user/course");
    },
    getUserStars: function() {
        return (0, e.get)("/v1/user/stars");
    },
    userBind: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.post)("/v1/user/bind-mobile", t);
    },
    userCode: function(t, r) {
        return (0, e.post)("/v1/user/send-sms", {
            mobile: t,
            country_code: r
        });
    },
    regist: function(t) {
        return t.source = e.source, (0, e.post)("/v1/user/mini-register", t);
    },
    getUserView: function() {
        return (0, e.get)("/user/view");
    },
    getHomeData: function() {
        return (0, e.get)("/home");
    },
    getVersionSign: function() {
        return (0, e.get)("/v1/system/audit");
    },
    getPaySign: function(t) {
        return (0, e.post)("/order/".concat(t, "/pay"), {
            order_id: t
        });
    },
    postFormId: function(t) {
        return (0, e.post)("/record/form", {
            form_id: t
        });
    },
    getSceneDetail: function(t) {
        return (0, e.get)("".concat(e.commonApi, "/weixin/qdetail"), {
            scene: t
        });
    },
    postStart: function(t) {
        return (0, e.post)("/exam/".concat(t, "/star"));
    },
    getStarList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.get)("/v1/message/user-stars", t);
    },
    getMessageList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.get)("/v1/message/user-activity", t);
    },
    postFeedback: function(t) {
        return (0, e.post)("/v1/user/feedback", t);
    }
};

exports.default = t;