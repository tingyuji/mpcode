Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wechatApi = exports.h5Host = exports.apiHost = exports.commonApi = void 0;

exports.commonApi = "https://common-api.knowyourself.cc";

exports.apiHost = "https://meditation-api.knowyourself.cc";

exports.h5Host = "https://meditation.knowyourself.cc";

exports.wechatApi = "https://api.knowyourself.cc/wechat-v2";