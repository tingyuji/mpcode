var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("./constent"), r = (e(require("../libs/underscore")), {
    getGenreAll: function() {
        return (0, t.get)("/v1/genre/all");
    },
    getGenreList: function() {
        return (0, t.get)("/v1/genre/list");
    },
    getGenreChild: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.get)("/v1/genre/".concat(r, "/child"));
    },
    getCourseList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, t.get)("/v1/course/list", e);
    },
    getCourseLesson: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.get)("/v1/course/".concat(r, "/lesson"));
    },
    getLessonDetail: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.get)("/v1/lesson/".concat(r));
    },
    setLessonStudy: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        };
        return (0, t.post)("/v1/lesson/".concat(e.id, "/study"), e);
    },
    setCourseStars: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.post)("/v1/course/".concat(r, "/stars"));
    },
    setCourseUnstars: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.post)("/v1/course/".concat(r, "/unstars"));
    },
    getSystemImg: function() {
        return (0, t.post)("/v1/system/img");
    },
    getShareCardInfo: function() {
        return (0, t.get)("/v1/system/share-data");
    },
    getMarketIndex: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, t.get)("/v1/marketing/index", e);
    },
    getCourseByShare: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, t.post)("/v1/marketing/receive", e);
    }
});

exports.default = r;