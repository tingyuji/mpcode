var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("./constent"), r = (e(require("../libs/underscore")), {
    countryCodeData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, t.get)("".concat(t.commonApi, "/sms/codelist"), e);
    },
    index: function() {
        return (0, t.get)("/v1/home/index");
    },
    indexWord: function() {
        return (0, t.get)("/v1/system/words");
    },
    getMiniCourseDetail: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        }, r = e.id;
        return (0, t.get)("/v1/home/mini-course/".concat(r));
    },
    setMiniCourseStudy: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            id: ""
        };
        return (0, t.post)("/v1/home/mini-course/study", e);
    },
    getQrcodeData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, t.get)("".concat(t.wechatApi, "/qrcode/scene-data"), e);
    }
});

exports.default = r;