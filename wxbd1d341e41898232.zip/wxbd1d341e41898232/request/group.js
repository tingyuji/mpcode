var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("./constent"), r = (t(require("../libs/underscore")), {
    groupList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.get)("/v1/group/list", t);
    },
    groupDetail: function(t) {
        return (0, e.get)("/v1/group/".concat(t));
    },
    getTopics: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.get)("/v1/topic/list", t);
    },
    getNotice: function() {
        return (0, e.get)("/v1/group/notice");
    },
    getTopic: function(t) {
        return (0, e.get)("/v1/topic/".concat(t));
    },
    getReplyList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.get)("/v1/reply/list", t);
    },
    publishReply: function(t) {
        return (0, e.post)("/v1/reply/publish", t);
    },
    addTopic: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return (0, e.post)("/v1/topic/publish", t);
    },
    enterGroup: function(t) {
        return (0, e.post)("/v1/group/".concat(t, "/enter"));
    },
    quitGroup: function(t) {
        return (0, e.post)("/v1/group/".concat(t, "/quit"));
    }
});

exports.default = r;