(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/canvasimage" ], {
    "12e9": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("8ac4"), r = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = r.a;
    },
    "8ac4": function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = a(n("2eee")), i = a(n("c973")), c = a(n("b3ea")), o = {
            data: function() {
                return {
                    styles: {
                        width: 550,
                        height: 760
                    },
                    name: "",
                    time: "",
                    showPoster: !1,
                    posterImage: "",
                    canvasId: "poster"
                };
            },
            methods: {
                createDraw: function() {
                    var e = this, t = new c.default({
                        canvasId: this.canvasId,
                        _this: this,
                        unit: "rpx",
                        width: this.styles.width,
                        height: this.styles.height,
                        type: "default"
                    });
                    this.draw = t, t.$on("init", (0, i.default)(r.default.mark(function t() {
                        return r.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (!(e.styles.width > 600)) {
                                    t.next = 5;
                                    break;
                                }
                                return t.next = 3, e.drawPosters();

                              case 3:
                                t.next = 7;
                                break;

                              case 5:
                                return t.next = 7, e.drawPoster();

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    })));
                },
                drawPosters: function() {
                    var e = this;
                    return (0, i.default)(r.default.mark(function t() {
                        var n, a;
                        return r.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return n = {
                                    title: "/static/image/zs/title.png",
                                    xcxm: "/static/image/zs/xcxm.jpg",
                                    cons: "/static/image/zs/zscenter.png",
                                    name: e.name,
                                    time: e.time
                                }, t.next = 3, e.draw.drawPoster(function(e) {
                                    var t = e.ctxObj, a = e.bgObj, r = t.width;
                                    return [ (t.height, {
                                        name: "background",
                                        type: "image",
                                        w: a.width,
                                        h: a.height,
                                        x: 0,
                                        y: 0,
                                        src: "/static/image/zs/bg.png"
                                    }), {
                                        name: "titlebg",
                                        type: "image",
                                        src: n.title,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e) {
                                            return {
                                                y: 100,
                                                w: 300
                                            };
                                        }
                                    }, {
                                        name: "name",
                                        type: "text",
                                        text: n.name,
                                        font: {
                                            size: 32,
                                            weight: "blod"
                                        },
                                        callback: function(e, t) {
                                            var n = t.find(function(e) {
                                                return "titlebg" === e.name;
                                            });
                                            return {
                                                w: n.w,
                                                x: 80,
                                                y: n.ey + 40
                                            };
                                        }
                                    }, {
                                        name: "content",
                                        type: "image",
                                        src: n.cons,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e, t) {
                                            return {
                                                y: t.find(function(e) {
                                                    return "name" === e.name;
                                                }).ey + 20,
                                                w: 450
                                            };
                                        }
                                    }, {
                                        name: "time",
                                        type: "text",
                                        text: n.time,
                                        font: {
                                            size: 24,
                                            weight: "blod"
                                        },
                                        textAlign: "center",
                                        callback: function(e, t) {
                                            var n = t.find(function(e) {
                                                return "content" === e.name;
                                            });
                                            return {
                                                w: r,
                                                x: 0,
                                                y: n.ey - 40
                                            };
                                        }
                                    }, {
                                        name: "qrcode",
                                        type: "image",
                                        src: n.xcxm,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e, t) {
                                            return {
                                                y: t.find(function(e) {
                                                    return "time" === e.name;
                                                }).ey + 20,
                                                w: 100
                                            };
                                        }
                                    } ];
                                });

                              case 3:
                                if ((a = t.sent).success) {
                                    t.next = 6;
                                    break;
                                }
                                return t.abrupt("return");

                              case 6:
                                e.showPoster = !0, e.posterImage = a.data, e.$emit("url", a.data);

                              case 9:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                drawPoster: function() {
                    var e = this;
                    return (0, i.default)(r.default.mark(function t() {
                        var n, a;
                        return r.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return n = {
                                    title: "/static/image/zs/title.png",
                                    xcxm: "/static/image/zs/xcxm.jpg",
                                    cons: "/static/image/zs/zscenter.png",
                                    name: e.name,
                                    time: e.time
                                }, t.next = 3, e.draw.drawPoster(function(e) {
                                    var t = e.ctxObj, a = e.bgObj;
                                    return [ (t.width, t.height, {
                                        name: "background",
                                        type: "image",
                                        w: a.width,
                                        h: a.height,
                                        x: 0,
                                        y: 0,
                                        src: "/static/image/zs/bg.png"
                                    }), {
                                        name: "titlebg",
                                        type: "image",
                                        src: n.title,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e) {
                                            return {
                                                y: 80,
                                                w: 250
                                            };
                                        }
                                    }, {
                                        name: "name",
                                        type: "text",
                                        text: n.name,
                                        font: {
                                            size: 28,
                                            weight: "blod"
                                        },
                                        callback: function(e, t) {
                                            var n = t.find(function(e) {
                                                return "titlebg" === e.name;
                                            });
                                            return {
                                                w: n.w,
                                                x: 80,
                                                y: n.ey + 40
                                            };
                                        }
                                    }, {
                                        name: "content",
                                        type: "image",
                                        src: n.cons,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e, t) {
                                            return {
                                                y: t.find(function(e) {
                                                    return "name" === e.name;
                                                }).ey + 20,
                                                w: 400
                                            };
                                        }
                                    }, {
                                        name: "time",
                                        type: "text",
                                        text: n.time,
                                        font: {
                                            size: 24,
                                            weight: "blod"
                                        },
                                        textAlign: "center",
                                        callback: function(e, t) {
                                            var n = t.find(function(e) {
                                                return "content" === e.name;
                                            });
                                            return {
                                                w: n.w,
                                                x: 0,
                                                y: n.ey - 40
                                            };
                                        }
                                    }, {
                                        name: "qrcode",
                                        type: "image",
                                        src: n.xcxm,
                                        drawType: "rect",
                                        mode: "widthFix",
                                        windowAlign: "center",
                                        callback: function(e, t) {
                                            return {
                                                y: t.find(function(e) {
                                                    return "time" === e.name;
                                                }).ey + 20,
                                                w: 80
                                            };
                                        }
                                    } ];
                                });

                              case 3:
                                if ((a = t.sent).success) {
                                    t.next = 6;
                                    break;
                                }
                                return t.abrupt("return");

                              case 6:
                                e.showPoster = !0, e.posterImage = a.data, e.$emit("url", a.data);

                              case 9:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            }
        };
        t.default = o;
    },
    bdde: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    f23c9: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("bdde"), r = n("12e9");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        var c = n("f0c5"), o = Object(c.a)(r.default, a.b, a.c, !1, null, "2a025a77", null, !1, a.a, void 0);
        t.default = o.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/canvasimage-create-component", {
    "components/canvasimage-create-component": function(e, t, n) {
        n("543d").createComponent(n("f23c9"));
    }
}, [ [ "components/canvasimage-create-component" ] ] ]);