(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/screen" ], {
    3759: function(e, t, n) {},
    5313: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            uPopup: function() {
                return n.e("uview-ui/components/u-popup/u-popup").then(n.bind(null, "267f"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    "5a10": function(e, t, n) {
        "use strict";
        var a = n("3759");
        n.n(a).a;
    },
    "5e1a": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("961e"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = i.a;
    },
    "6f8fe": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("5313"), i = n("5e1a");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("5a10");
        var o = n("f0c5"), s = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = s.exports;
    },
    7478: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("a16c"), a(n("66fd"));
            var i = a(n("6f8fe"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "961e": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n("2eee")), r = a(n("c973")), o = a(n("9523")), s = n("26cb");
            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach(function(t) {
                        (0, o.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var f = "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0", l = {
                data: function() {
                    return {
                        show: !1,
                        userInfo: {
                            avatarUrl: f,
                            nickName: ""
                        },
                        showbtn: !0,
                        phone: {}
                    };
                },
                computed: c({}, (0, s.mapState)([ "token" ])),
                onLoad: function() {
                    var e = this;
                    "" != this.token && null != this.token && this.$api.post("Users/detail").then(function(t) {
                        e.showbtn = "token无效" == t;
                    });
                },
                onShareAppMessage: function() {},
                methods: c(c({}, (0, s.mapMutations)([ "login", "logout" ])), {}, {
                    goindexs: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    onChooseAvatar: function(e) {
                        this.userInfo.avatarUrl = e.detail.avatarUrl;
                    },
                    submitchange: function(t) {
                        if ("" == t.detail.value.nickname) return this.$api.msg("请输入用户昵称");
                        var n = t.detail.value.nickname;
                        /select|update|delete|exec|count|'|"|=|;|>|<|%/i.test(n) ? this.$api.msg("不允许输入特殊字符或符号，请修改") : (this.userInfo.nickName = n, 
                        e.showLoading({
                            mask: !0
                        }), this.urshows());
                    },
                    goindex: function(t) {
                        var n = this;
                        "" != this.token && null != this.token ? this.$api.post("Users/detail").then(function(a) {
                            "token无效" == a ? (n.logout(), n.wechartlogin(t)) : e.switchTab({
                                url: "/pages/index/index"
                            });
                        }) : this.wechartlogin(t);
                    },
                    wechartlogin: function(t) {
                        var n = this;
                        e.showModal({
                            title: "温馨提示",
                            content: "授权微信登录后才能正常使用小程序功能",
                            success: function(a) {
                                a.confirm && (e.showLoading({
                                    mask: !0
                                }), e.getUserProfile({
                                    desc: "获取您的昵称、头像及性别",
                                    lang: "zh_CN",
                                    success: function(e) {
                                        e.userInfo.avatarUrl = f, n.userInfo = e.userInfo, n.phone = t.detail, n.wechartsmal();
                                    }
                                }));
                            }
                        });
                    },
                    editname: function() {
                        var e = this;
                        return (0, r.default)(i.default.mark(function t() {
                            return i.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    e.$api.post("Users/editto", {
                                        user_name: e.userInfo.nickName
                                    });

                                  case 1:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    urshows: function() {
                        var t = this, n = this.userInfo;
                        this.phone, this.editname(), n.avatarUrl == f ? e.switchTab({
                            url: "/pages/index/index"
                        }) : t.$api.upload("Users/addfile2", {}, n.avatarUrl, "file").then(function(a) {
                            if (500 == a.code) return t.$api.msg(a.data);
                            n.avatarUrl = a.data, e.switchTab({
                                url: "/pages/index/index"
                            });
                        });
                    },
                    wechartsmal: function() {
                        var t = this, n = this.userInfo;
                        this.phone, e.login({
                            provider: "weixin",
                            success: function(a) {
                                t.$api.post("Index/wxlogin", {
                                    code: a.code,
                                    user_name: n.nickName,
                                    src: n.avatarUrl
                                }).then(function(n) {
                                    t.login(n.data.token), 0 == n.data.is_new ? e.switchTab({
                                        url: "/pages/index/index"
                                    }) : (t.show = !0, e.hideLoading());
                                });
                            }
                        });
                    }
                })
            };
            t.default = l;
        }).call(this, n("543d").default);
    }
}, [ [ "7478", "common/runtime", "common/vendor" ] ] ]);