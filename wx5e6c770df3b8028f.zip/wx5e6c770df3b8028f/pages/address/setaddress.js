(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/address/setaddress" ], {
    "2ec1": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("a16c"), a(n("66fd"));
            var i = a(n("b2b7"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "3f83": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uToast: function() {
                return n.e("uview-ui/components/u-toast/u-toast").then(n.bind(null, "af4f"));
            }
        }, i = function() {
            var t = this;
            t.$createElement, t._self._c, t._isMounted || (t.e0 = function(e) {
                t.value = !0;
            });
        }, r = [];
    },
    "686e": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("a25f"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    },
    "85ff": function(t, e, n) {
        "use strict";
        var a = n("cfe9");
        n.n(a).a;
    },
    a25f: function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("2eee")), r = a(n("c973")), u = {
                data: function() {
                    return {
                        show: !1,
                        height: 30,
                        bgColor: this.$u.color.bgColor,
                        marginTop: 30,
                        marginBottom: 30,
                        value: !1,
                        input: "",
                        list: {
                            user_name: "",
                            tel: "",
                            address: "",
                            province: "",
                            city: "",
                            region: ""
                        },
                        defaultReg: [],
                        i: 1,
                        uid: ""
                    };
                },
                onLoad: function(t) {
                    this.i = t.i, 0 == t.i && this.loadData(t.item);
                },
                methods: {
                    loadData: function(t) {
                        var e = JSON.parse(t);
                        this.list = e, this.defaultReg = [ e.province, e.city, e.region ], this.input = e.province + " " + e.city + " " + e.region;
                    },
                    subMitChange: function() {
                        var t = this.list;
                        return "" == t.name ? this.$u.toast("收货人不能为空") : "" == t.phone ? this.$u.toast("手机号不可为空") : "" == t.province ? this.$u.toast("请选择地址") : "" == t.address ? this.$u.toast("详细地址不能为空") : 1 == this.i ? this.requestsubmit() : this.requestsubmits();
                    },
                    requestsubmit: function(e) {
                        var n = this;
                        return (0, r.default)(i.default.mark(function e() {
                            var a;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, n.$api.post("address/add", n.list);

                                  case 2:
                                    if (500 != (a = e.sent).code) {
                                        e.next = 5;
                                        break;
                                    }
                                    return e.abrupt("return", n.$api.msg(a.msg));

                                  case 5:
                                    n.$u.toast("添加成功"), setTimeout(function() {
                                        t.navigateBack({});
                                    }, 500);

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    requestsubmits: function(e) {
                        var n = this;
                        return (0, r.default)(i.default.mark(function e() {
                            var a, r;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return (a = n.list).id = n.uid, e.next = 4, n.$api.post("address/add", a);

                                  case 4:
                                    if (500 != (r = e.sent).code) {
                                        e.next = 7;
                                        break;
                                    }
                                    return e.abrupt("return", n.$api.msg(r.msg));

                                  case 7:
                                    n.$u.toast("修改成功"), setTimeout(function() {
                                        t.navigateBack({});
                                    }, 500);

                                  case 9:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    cityChange: function(t) {
                        this.list.province = t.province.label, this.list.city = t.city.label, this.list.region = t.area.label, 
                        this.input = t.province.label + " " + t.city.label + " " + t.area.label;
                    }
                }
            };
            e.default = u;
        }).call(this, n("543d").default);
    },
    b2b7: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("3f83"), i = n("686e");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("85ff");
        var u = n("f0c5"), s = Object(u.a)(i.default, a.b, a.c, !1, null, "5e7a4f66", null, !1, a.a, void 0);
        e.default = s.exports;
    },
    cfe9: function(t, e, n) {}
}, [ [ "2ec1", "common/runtime", "common/vendor" ] ] ]);