(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/information" ], {
    "0470": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("2eee")), r = a(n("c973")), s = {
                data: function() {
                    return {
                        ifcell: !0,
                        navlist: [],
                        user: {},
                        paths: ""
                    };
                },
                created: function() {
                    var e = this;
                    t.$on("uAvatarCropper", function(n) {
                        e.user.src = n, t.showLoading({}), e.$api.upload("Users/addfile", {}, n, "file").then(function(t) {
                            if (500 == t.code) return e.$api.msg(t.data);
                            e.paths = t.data;
                        });
                    });
                },
                onLoad: function() {
                    this.loadnonedate();
                },
                methods: {
                    clickxg: function() {
                        var e = this;
                        return (0, r.default)(i.default.mark(function n() {
                            var a, r;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (a = e, "" != e.paths && t.showModal({
                                        content: "您确定修改信息吗？",
                                        success: function() {
                                            a.$api.post("Users/edit3", {
                                                src: a.paths
                                            }).then(function(t) {
                                                if (500 == t.code) return a.$api.msg(res.data);
                                                a.loadnonedate();
                                            });
                                        }
                                    }), e.user.user_name == e.navlist[1].txt) {
                                        n.next = 9;
                                        break;
                                    }
                                    if (r = e.navlist[1].txt, !/select|update|delete|exec|count|'|"|=|;|>|<|%/i.test(r)) {
                                        n.next = 8;
                                        break;
                                    }
                                    return e.$api.msg("不允许输入特殊字符或符号，请修改"), n.abrupt("return");

                                  case 8:
                                    t.showModal({
                                        content: "您确定修改信息吗？",
                                        success: function() {
                                            a.confrims(a.navlist[1].txt);
                                        }
                                    });

                                  case 9:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getphone: function(e) {
                        if ("getPhoneNumber:ok" != e.detail.errMsg) return this.$api.msg("请先获取手机号在进行下一步");
                        var n = this;
                        this.$api.post("Users/gettel", {
                            code: e.detail.code
                        }).then(function(e) {
                            if (t.hideLoading(), 500 == e.code) return n.$api.msg("绑定失败");
                            n.$api.msg("绑定成功"), n.loadnonedate();
                        });
                    },
                    confrims: function(t) {
                        var e = this;
                        return (0, r.default)(i.default.mark(function n() {
                            var a;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, e.$api.post("Users/edit", {
                                        user_name: t
                                    });

                                  case 2:
                                    if (500 != (a = n.sent).code) {
                                        n.next = 7;
                                        break;
                                    }
                                    return n.abrupt("return", e.$api.msg(a.data));

                                  case 7:
                                    e.$api.msg("修改成功"), e.loadnonedate();

                                  case 9:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    loadnonedate: function() {
                        this.navlist = [], this.navlist = [ {
                            title: "头像",
                            isarrow: !1,
                            isava: !0,
                            url: 0
                        }, {
                            title: "昵称",
                            isarrow: !1,
                            isava: !1,
                            txt: "",
                            disbled: !1
                        }, {
                            title: "手机号",
                            isarrow: !1,
                            isava: !1,
                            phone: !1,
                            disbled: !0,
                            txt: ""
                        }, {
                            title: "单位信息",
                            isarrow: !0,
                            isava: !1,
                            disbled: !0,
                            txt: "",
                            url: "./updatedw"
                        } ], this.loadData();
                    },
                    loadData: function() {
                        var t = this;
                        return (0, r.default)(i.default.mark(function e() {
                            var n, a;
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return t.ifcell = !1, e.next = 3, t.$api.post("Users/detail");

                                  case 3:
                                    n = e.sent, a = n.data, t.user = a, "" == a.tel && (t.navlist[2].phone = !0), 1 == a.is_edit && (t.navlist[1].disbled = !0), 
                                    1 == a.is_edit_code && (t.navlist[3].disbled = !0), t.navlist[1].txt = a.user_name, 
                                    t.navlist[2].txt = a.tel, t.navlist[3].txt = "".concat(a.province).concat(a.city).concat(a.area).concat("-1" == a.title ? "" : a.title), 
                                    t.ifcell = !0;

                                  case 13:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    gonav: function(e) {
                        if (0 == e) {
                            if (2 == this.user.is_edit_src) return;
                            this.$u.route({
                                url: "/uview-ui/components/u-avatar-cropper/u-avatar-cropper",
                                params: {
                                    destWidth: 300,
                                    rectWidth: 300,
                                    fileType: "jpg"
                                }
                            });
                        } else if ("" != e && null != e) {
                            if ("1" == this.user.is_edit_code) return;
                            t.navigateTo({
                                url: e
                            });
                        }
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    },
    "293d": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("a16c"), a(n("66fd"));
            var i = a(n("a838"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "2a99": function(t, e, n) {},
    "3a27": function(t, e, n) {
        "use strict";
        var a = n("2a99");
        n.n(a).a;
    },
    a838: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("ad7a"), i = n("ffae");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("3a27");
        var s = n("f0c5"), u = Object(s.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = u.exports;
    },
    ad7a: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uCellGroup: function() {
                return n.e("uview-ui/components/u-cell-group/u-cell-group").then(n.bind(null, "3777"));
            },
            uCellItem: function() {
                return n.e("uview-ui/components/u-cell-item/u-cell-item").then(n.bind(null, "2913"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    ffae: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("0470"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    }
}, [ [ "293d", "common/runtime", "common/vendor" ] ] ]);