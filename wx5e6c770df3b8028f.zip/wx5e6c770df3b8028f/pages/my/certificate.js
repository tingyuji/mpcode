(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/certificate" ], {
    "1efe": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("23b1"), a = n("a490");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("98b7");
        var s = n("f0c5"), u = Object(s.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "23b1": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            uEmpty: function() {
                return n.e("uview-ui/components/u-empty/u-empty").then(n.bind(null, "2cd2"));
            },
            uPopup: function() {
                return n.e("uview-ui/components/u-popup/u-popup").then(n.bind(null, "267f"));
            },
            uParse: function() {
                return Promise.all([ n.e("common/vendor"), n.e("uview-ui/components/u-parse/u-parse") ]).then(n.bind(null, "1d79"));
            }
        }, a = function() {
            var e = this, t = (e.$createElement, e._self._c, e.list.length);
            e._isMounted || (e.e0 = function(t) {
                e.gzshow = !0;
            }, e.e1 = function(t) {
                e.gzshow = !1;
            }, e.e2 = function(t) {
                e.clickshow = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, i = [];
    },
    "2d24": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("a16c"), o(n("66fd"));
            var a = o(n("1efe"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "98b7": function(e, t, n) {
        "use strict";
        var o = n("d543");
        n.n(o).a;
    },
    a490: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("f09e"), a = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = a.a;
    },
    d543: function(e, t, n) {},
    f09e: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("2eee")), i = o(n("c973")), s = {
                data: function() {
                    return {
                        gzshow: !1,
                        clickshow: !1,
                        content: "",
                        list: [],
                        sedlist: {}
                    };
                },
                onLoad: function() {
                    this.loadData();
                },
                methods: {
                    clickdata: function(e) {
                        var t = this;
                        this.clickshow = !0, this.$nextTick(function() {
                            t.$refs.canvasimage.styles = {
                                width: 660,
                                height: 926
                            }, t.$refs.canvasimage.name = e.user_name + "：";
                            var n = Date.parse(e.gmt_create);
                            t.$refs.canvasimage.time = t.$u.timeFormat(n, "yyyy 年 mm 月 dd 日"), t.$refs.canvasimage.createDraw();
                        }), this.sedlist = e;
                    },
                    url: function(e) {
                        this.sedlist.url = e;
                    },
                    savexc: function() {
                        e.showLoading({
                            title: "加载中..."
                        });
                        var t = this;
                        e.saveImageToPhotosAlbum({
                            filePath: this.sedlist.url,
                            success: function(n) {
                                e.hideLoading(), e.showModal({
                                    title: "提示",
                                    content: "保存成功",
                                    modalType: !1,
                                    success: function() {
                                        t.clickshow = !1;
                                    }
                                });
                            },
                            fail: function(t) {
                                "saveImageToPhotosAlbum:fail:auth denied" !== t.errMsg && "saveImageToPhotosAlbum:fail auth deny" !== t.errMsg && "saveImageToPhotosAlbum:fail authorize no response" !== t.errMsg || e.showModal({
                                    title: "提示",
                                    content: "需要您授权保存相册",
                                    modalType: !1,
                                    success: function(t) {
                                        e.openSetting({
                                            success: function(t) {
                                                console.log("settingdata", t), t.authSetting["scope.writePhotosAlbum"] ? e.showModal({
                                                    title: "提示",
                                                    content: "获取权限成功,再次点击图片即可保存",
                                                    modalType: !1
                                                }) : e.showModal({
                                                    title: "提示",
                                                    content: "获取权限失败，将无法保存到相册哦~",
                                                    modalType: !1
                                                });
                                            },
                                            fail: function(e) {
                                                console.log("failData", e);
                                            },
                                            complete: function(e) {
                                                console.log("finishData", e);
                                            }
                                        });
                                    }
                                });
                            },
                            complete: function(t) {
                                e.hideLoading();
                            }
                        });
                    },
                    loadData: function() {
                        var e = this;
                        return (0, i.default)(a.default.mark(function t() {
                            var n, o;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 3, e.$api.post("comm/zhengshucomm");

                                  case 3:
                                    return n = t.sent, e.content = n.data, t.next = 7, e.$api.post("Users/certificate");

                                  case 7:
                                    o = t.sent, e.list = o.data;

                                  case 9:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    retu: function() {}
                }
            };
            t.default = s;
        }).call(this, n("bc2e").default);
    }
}, [ [ "2d24", "common/runtime", "common/vendor" ] ] ]);