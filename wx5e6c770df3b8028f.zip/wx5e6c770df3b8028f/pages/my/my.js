(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/my" ], {
    "0f79": function(t, e, n) {
        "use strict";
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var u = r(n("2eee")), c = r(n("c973")), a = r(n("9523"));
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function o(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        (0, a.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var l = {
                data: function() {
                    return {
                        navlist: [ {
                            src: "/static/image/my/0.png",
                            title: "我的证书",
                            url: "./certificate"
                        }, {
                            src: "/static/image/my/1.png",
                            title: "修改个人信息",
                            url: "./information"
                        }, {
                            src: "/static/image/my/3.png",
                            title: "登记收货地址",
                            url: "/pages/address/address"
                        }, {
                            src: "/static/image/my/2.png",
                            title: "意见反馈",
                            url: "./feedback"
                        } ],
                        user: {}
                    };
                },
                onShow: function() {
                    this.loadData();
                },
                methods: o(o({}, (0, n("26cb").mapMutations)([ "logout" ])), {}, {
                    logouts: function() {
                        var e = this;
                        t.showModal({
                            title: "您确认要退出登录吗？",
                            success: function(n) {
                                n.confirm && (e.logout(), t.reLaunch({
                                    url: "/pages/index/screen"
                                }));
                            }
                        });
                    },
                    loadData: function() {
                        var t = this;
                        return (0, c.default)(u.default.mark(function e() {
                            var n, r;
                            return u.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.$api.post("Users/detail");

                                  case 2:
                                    n = e.sent, r = n.data, t.user = r;

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    clickgo: function(e) {
                        t.navigateTo({
                            url: e.url
                        });
                    }
                })
            };
            e.default = l;
        }).call(this, n("543d").default);
    },
    1755: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var r = n("4ea4");
            n("a16c"), r(n("66fd"));
            var u = r(n("2673"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(u.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    2673: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("9039"), u = n("b30b");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(c);
        n("69ad");
        var a = n("f0c5"), i = Object(a.a)(u.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        e.default = i.exports;
    },
    "69ad": function(t, e, n) {
        "use strict";
        var r = n("a8e5");
        n.n(r).a;
    },
    9039: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return u;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return r;
        });
        var r = {
            uCellGroup: function() {
                return n.e("uview-ui/components/u-cell-group/u-cell-group").then(n.bind(null, "3777"));
            },
            uCellItem: function() {
                return n.e("uview-ui/components/u-cell-item/u-cell-item").then(n.bind(null, "2913"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    a8e5: function(t, e, n) {},
    b30b: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("0f79"), u = n.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        e.default = u.a;
    }
}, [ [ "1755", "common/runtime", "common/vendor" ] ] ]);