(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/answer/contact" ], {
    "0823": function(n, t, u) {},
    "08fb": function(n, t, u) {
        "use strict";
        u.r(t);
        var e = u("43c3"), o = u.n(e);
        for (var c in e) [ "default" ].indexOf(c) < 0 && function(n) {
            u.d(t, n, function() {
                return e[n];
            });
        }(c);
        t.default = o.a;
    },
    "43c3": function(n, t, u) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var u = {
                data: function() {
                    return {
                        background: {
                            backgroundColor: "rgba(0,0,0,.0)"
                        },
                        ushowgz: !1,
                        content: ""
                    };
                },
                onLoad: function() {},
                methods: {
                    look: function() {
                        n.navigateTo({
                            url: "./answer?type=0"
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, u("543d").default);
    },
    "483b": function(n, t, u) {
        "use strict";
        u.r(t);
        var e = u("990c"), o = u("08fb");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            u.d(t, n, function() {
                return o[n];
            });
        }(c);
        u("d611");
        var a = u("f0c5"), r = Object(a.a)(o.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        t.default = r.exports;
    },
    "681c": function(n, t, u) {
        "use strict";
        (function(n, t) {
            var e = u("4ea4");
            u("a16c"), e(u("66fd"));
            var o = e(u("483b"));
            n.__webpack_require_UNI_MP_PLUGIN__ = u, t(o.default);
        }).call(this, u("bc2e").default, u("543d").createPage);
    },
    "990c": function(n, t, u) {
        "use strict";
        u.d(t, "b", function() {
            return o;
        }), u.d(t, "c", function() {
            return c;
        }), u.d(t, "a", function() {
            return e;
        });
        var e = {
            uNavbar: function() {
                return u.e("uview-ui/components/u-navbar/u-navbar").then(u.bind(null, "2cf5"));
            },
            uPopup: function() {
                return u.e("uview-ui/components/u-popup/u-popup").then(u.bind(null, "267f"));
            }
        }, o = function() {
            var n = this;
            n.$createElement, n._self._c, n._isMounted || (n.e0 = function(t) {
                n.ushowgz = !0;
            });
        }, c = [];
    },
    d611: function(n, t, u) {
        "use strict";
        var e = u("0823");
        u.n(e).a;
    }
}, [ [ "681c", "common/runtime", "common/vendor" ] ] ]);