(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/answer/everyday" ], {
    "09d5": function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return r;
        }), t.d(e, "a", function() {
            return u;
        });
        var u = {
            uNavbar: function() {
                return t.e("uview-ui/components/u-navbar/u-navbar").then(t.bind(null, "2cf5"));
            },
            uPopup: function() {
                return t.e("uview-ui/components/u-popup/u-popup").then(t.bind(null, "267f"));
            }
        }, a = function() {
            var n = this;
            n.$createElement, n._self._c, n._isMounted || (n.e0 = function(e) {
                n.ushowgz = !0;
            });
        }, r = [];
    },
    "0cac": function(n, e, t) {
        "use strict";
        t.r(e);
        var u = t("09d5"), a = t("2e29");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(r);
        t("5f28");
        var o = t("f0c5"), c = Object(o.a)(a.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        e.default = c.exports;
    },
    "2e29": function(n, e, t) {
        "use strict";
        t.r(e);
        var u = t("bf74"), a = t.n(u);
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(r);
        e.default = a.a;
    },
    5794: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var u = t("4ea4");
            t("a16c"), u(t("66fd"));
            var a = u(t("0cac"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "5ae0": function(n, e, t) {},
    "5f28": function(n, e, t) {
        "use strict";
        var u = t("5ae0");
        t.n(u).a;
    },
    bf74: function(n, e, t) {
        "use strict";
        (function(n) {
            var u = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = u(t("2eee")), r = u(t("c973")), o = {
                data: function() {
                    return {
                        background: {
                            backgroundColor: "rgba(0,0,0,.0)"
                        },
                        ushowgz: !1,
                        content: "",
                        num: 0,
                        zgf: 0
                    };
                },
                onShow: function() {
                    var e = this;
                    n.showLoading({
                        mask: !0
                    }), this.$api.post("userquestion/usersums").then(function(n) {
                        e.num = n.data;
                    }), n.hideLoading();
                    var t = n.getStorageSync("zgf");
                    this.zgf = "" == t ? 0 : t;
                },
                methods: {
                    look: function() {
                        var e = this;
                        return (0, r.default)(a.default.mark(function t() {
                            var u;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, e.$api.post("Question/usersums");

                                  case 2:
                                    if (500 != (u = t.sent).code) {
                                        t.next = 5;
                                        break;
                                    }
                                    return t.abrupt("return", e.$api.msg(u.data));

                                  case 5:
                                    n.navigateTo({
                                        url: "./answer?type=1"
                                    });

                                  case 6:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            e.default = o;
        }).call(this, t("543d").default);
    }
}, [ [ "5794", "common/runtime", "common/vendor" ] ] ]);