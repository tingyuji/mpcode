(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/answer/result" ], {
    "3b6e": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("8ff4"), r = n.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(u);
        e.default = r.a;
    },
    "5f92": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uNavbar: function() {
                return n.e("uview-ui/components/u-navbar/u-navbar").then(n.bind(null, "2cf5"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    7845: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("a16c"), a(n("66fd"));
            var r = a(n("7fd0"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "7fd0": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("5f92"), r = n("3b6e");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(u);
        n("864e");
        var o = n("f0c5"), c = Object(o.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    },
    "840b": function(t, e, n) {},
    "864e": function(t, e, n) {
        "use strict";
        var a = n("840b");
        n.n(a).a;
    },
    "8ff4": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = a(n("2eee")), u = a(n("c973")), o = {
                components: {
                    everyday: function() {
                        n.e("components/everyday").then(function() {
                            return resolve(n("3bf7"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    contact: function() {
                        n.e("components/contact").then(function() {
                            return resolve(n("8011"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        background: {
                            backgroundColor: "rgba(0,0,0,.0)"
                        },
                        time: 0,
                        fs: 0,
                        type: 0,
                        userlist: "",
                        rand: ""
                    };
                },
                onLoad: function(t) {
                    this.time = t.time, this.fs = t.fs, this.type = t.type, this.userlist = t.userlist, 
                    this.rand = t.rand, 1 == t.type ? this.add() : this.$refs.contacts.loadData();
                },
                methods: {
                    add: function() {
                        var e = this;
                        return (0, u.default)(r.default.mark(function n() {
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return t.showLoading({
                                        mask: !0
                                    }), n.next = 3, e.$api.post("Question/save", {
                                        rand: e.rand,
                                        arr_json: e.userlist,
                                        set_date: e.time
                                    });

                                  case 3:
                                    n.sent, e.$refs.everydays.loadData(), t.hideLoading();

                                  case 6:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    }
                }
            };
            e.default = o;
        }).call(this, n("543d").default);
    }
}, [ [ "7845", "common/runtime", "common/vendor" ] ] ]);