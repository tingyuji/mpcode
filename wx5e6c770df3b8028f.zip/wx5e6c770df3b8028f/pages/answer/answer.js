(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/answer/answer" ], {
    "0182": function(t, s, e) {},
    "3b39": function(t, s, e) {
        "use strict";
        (function(t) {
            var n = e("4ea4");
            Object.defineProperty(s, "__esModule", {
                value: !0
            }), s.default = void 0;
            var a, r = n(e("2eee")), i = n(e("c973")), c = n(e("448a")), o = {
                data: function() {
                    return {
                        endan: !1,
                        type: 0,
                        answidth: 10,
                        tnum: 1,
                        arrs: [],
                        rand: "",
                        fstxt: 0,
                        djstxt: 120,
                        idx: 0,
                        next: !1,
                        zsctime: 0,
                        usersed: "",
                        usersedlist: [],
                        ushows: !1,
                        uclass: {
                            a: "",
                            b: "",
                            c: "",
                            d: ""
                        },
                        yandn: {
                            a: "",
                            b: "",
                            c: "",
                            d: ""
                        },
                        curr: !0,
                        customback: function(s) {
                            if (0 == this.type) t.showModal({
                                content: "确认退出答题？",
                                cancelText: "取消答题",
                                confirmText: "继续答题",
                                success: function(s) {
                                    s.cancel && t.navigateBack();
                                }
                            }); else {
                                var e = this;
                                t.showModal({
                                    content: "本次答题已消耗一次机会，请问确认退出答题？",
                                    cancelText: "取消答题",
                                    confirmText: "继续答题",
                                    success: function(s) {
                                        if (s.cancel) {
                                            var n = t.getStorageSync("zgf");
                                            "" == n ? t.setStorageSync("zgf", e.fstxt) : n > e.fstxt || t.setStorageSync("zgf", e.fstxt), 
                                            t.navigateBack();
                                        }
                                    }
                                });
                            }
                        }
                    };
                },
                onLoad: function(s) {
                    this.type = s.type, 0 == s.type ? t.setNavigationBarTitle({
                        title: "个人练习"
                    }) : t.setNavigationBarTitle({
                        title: "每日答题"
                    }), this.loadData();
                },
                onUnload: function() {
                    clearInterval(a);
                },
                methods: {
                    tjdaan: function(s) {
                        var e = this.arrs[this.idx], n = this.usersed, a = n.slice(0, n.length - 1).split(","), r = (0, 
                        c.default)(new Set(a)), i = this.usersedlist;
                        i.push({
                            id: e.id,
                            user_answer: 1 == n.length ? n : r.join("")
                        }), t.redirectTo({
                            url: "/pages/answer/result?type=" + this.type + "&&time=" + this.zsctime + "&&fs=" + this.fstxt + "&&userlist=" + JSON.stringify(i) + "&&rand=" + this.rand
                        });
                    },
                    findidx: function(t, s) {
                        if (!this.next) {
                            var e = this.arrs[this.idx].answer, n = this.uclass;
                            if (1 == e.length) n = {
                                a: "",
                                b: "",
                                c: "",
                                d: ""
                            }, this.usersed = s, n["".concat(s.toLowerCase())] = "ansconxzitemused"; else {
                                var a = this.usersed;
                                if ("ansconxzitemused" == n["".concat(s.toLowerCase())]) {
                                    n["".concat(s.toLowerCase())] = "";
                                    var r = (a = a.slice(0, a.length - 1).split(",")).filter(function(t) {
                                        return null != t;
                                    }).filter(function(t) {
                                        return t != s;
                                    }), i = (0, c.default)(new Set(r));
                                    this.usersed = i.join(",") + ",";
                                } else n["".concat(s.toLowerCase())] = "ansconxzitemused", this.usersed += s + ",";
                            }
                            this.uclass = n, this.curr = !1;
                        }
                    },
                    clicksed: function() {
                        var t = this.arrs[this.idx];
                        if (t.answer = t.answer.replace(/\s*/g, ""), 1 == t.answer.length) {
                            var s = t.answer, e = this.usersed;
                            this.userlist();
                            var n = this.uclass, r = this.yandn;
                            s == e ? (this.fstxt += 10, n["".concat(e.toLowerCase())] += " success", r["".concat(e.toLowerCase())] = "sucess") : (n["".concat(e.toLowerCase())] += " error", 
                            r["".concat(e.toLowerCase())] = "error", n["".concat(s.toLowerCase())] = "success", 
                            r["".concat(s.toLowerCase())] = "sucess"), this.uclass = n, this.yandn = r;
                        } else {
                            var i = t.answer.split(""), c = this.usersed.slice(0, this.usersed.length - 1).split(",");
                            this.userlist();
                            var o = this.uclass, u = this.yandn;
                            c.sort().join("") == i.join("") ? (this.fstxt += 10, c.forEach(function(t) {
                                o["".concat(t.toLowerCase())] += " success", u["".concat(t.toLowerCase())] = "sucess";
                            }), this.uclass = o, this.yandn = u) : i.forEach(function(t) {
                                c.forEach(function(s) {
                                    t == s ? (o["".concat(s.toLowerCase())] += " success", u["".concat(s.toLowerCase())] = "sucess") : (o["".concat(t.toLowerCase())] = "success", 
                                    u["".concat(t.toLowerCase())] = "sucess");
                                });
                            }), this.uclass = o, this.yandn = u;
                        }
                        clearInterval(a), this.zsctime += 120 - this.djstxt, 10 == this.tnum ? this.ushows = !0 : this.next = !0;
                    },
                    userlist: function() {
                        var t = this.arrs[this.idx], s = this.usersed, e = s.slice(0, s.length - 1).split(","), n = (0, 
                        c.default)(new Set(e));
                        this.usersedlist.push({
                            id: t.id,
                            user_answer: 1 == s.length ? s : n.join("")
                        });
                    },
                    rejgc: function() {
                        var t = this.uclass, s = this.yandn;
                        t = {
                            a: "",
                            b: "",
                            c: "",
                            d: ""
                        }, s = {
                            a: "",
                            b: "",
                            c: "",
                            d: ""
                        }, this.uclass = t, this.yandn = s;
                    },
                    nextsed: function() {
                        this.djstxt = 120, this.startdjs(), this.curr = !0, this.rejgc(), this.usersed = "", 
                        this.next = !1, this.idx >= 9 || (this.idx += 1, this.tnum += 1, this.answidth += 10);
                    },
                    loadData: function() {
                        var t = this;
                        return (0, i.default)(r.default.mark(function s() {
                            var e;
                            return r.default.wrap(function(s) {
                                for (;;) switch (s.prev = s.next) {
                                  case 0:
                                    return s.next = 2, t.$api.post("Question/lists");

                                  case 2:
                                    (e = s.sent).data.arr, t.arrs = e.data.arr, t.idx = 0, t.rand = e.data.rand, t.startdjs();

                                  case 8:
                                  case "end":
                                    return s.stop();
                                }
                            }, s);
                        }))();
                    },
                    startdjs: function() {
                        var s = this;
                        clearInterval(a), a = setInterval(function() {
                            s.djstxt--, s.djstxt <= 0 && (clearInterval(a), t.showModal({
                                content: "您已超时,点击进入下一题",
                                showCancel: !1,
                                confirmText: "下一题",
                                success: function() {
                                    s.nextsed();
                                }
                            }));
                        }, 1e3);
                    },
                    arrayEquals: function(t) {
                        function s(s, e) {
                            return t.apply(this, arguments);
                        }
                        return s.toString = function() {
                            return t.toString();
                        }, s;
                    }(function(t, s) {
                        if (!t && !t) return !1;
                        if (t.length != s.length) return !1;
                        for (var e = 0, n = t.length; e < n; e++) if (t[e] instanceof Array && s[e] instanceof Array) {
                            if (!arrayEquals(t[e], s[e])) return !1;
                        } else if (t[e] != s[e]) return !1;
                        return !0;
                    })
                }
            };
            s.default = o;
        }).call(this, e("543d").default);
    },
    6340: function(t, s, e) {
        "use strict";
        e.r(s);
        var n = e("ecb1"), a = e("d335");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(s, t, function() {
                return a[t];
            });
        }(r);
        e("8983");
        var i = e("f0c5"), c = Object(i.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        s.default = c.exports;
    },
    "80b4": function(t, s, e) {
        "use strict";
        (function(t, s) {
            var n = e("4ea4");
            e("a16c"), n(e("66fd"));
            var a = n(e("6340"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, s(a.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    8983: function(t, s, e) {
        "use strict";
        var n = e("0182");
        e.n(n).a;
    },
    d335: function(t, s, e) {
        "use strict";
        e.r(s);
        var n = e("3b39"), a = e.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(s, t, function() {
                return n[t];
            });
        }(r);
        s.default = a.a;
    },
    ecb1: function(t, s, e) {
        "use strict";
        e.d(s, "b", function() {
            return a;
        }), e.d(s, "c", function() {
            return r;
        }), e.d(s, "a", function() {
            return n;
        });
        var n = {
            uNavbar: function() {
                return e.e("uview-ui/components/u-navbar/u-navbar").then(e.bind(null, "2cf5"));
            }
        }, a = function() {
            this.$createElement;
            var t = (this._self._c, this.arrs.length), s = this.arrs[this.idx].answer.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: s
                }
            });
        }, r = [];
    }
}, [ [ "80b4", "common/runtime", "common/vendor" ] ] ]);