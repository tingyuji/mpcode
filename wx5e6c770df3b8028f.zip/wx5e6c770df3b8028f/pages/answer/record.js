(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/answer/record" ], {
    "00e1": function(t, e, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = a(n("2eee")), r = a(n("c973")), c = {
            data: function() {
                return {
                    list: []
                };
            },
            onLoad: function() {
                this.loadData();
            },
            methods: {
                loadData: function() {
                    var t = this;
                    return (0, r.default)(u.default.mark(function e() {
                        var n;
                        return u.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.$api.post("userquestion/lists");

                              case 2:
                                n = e.sent, t.list = n.data;

                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                }
            }
        };
        e.default = c;
    },
    "2bd8": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("5b6b"), u = n("78a5");
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(r);
        n("8c8b");
        var c = n("f0c5"), i = Object(c.a)(u.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = i.exports;
    },
    "5b6b": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return u;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            uEmpty: function() {
                return n.e("uview-ui/components/u-empty/u-empty").then(n.bind(null, "2cd2"));
            }
        }, u = function() {
            this.$createElement;
            var t = (this._self._c, this.list.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, r = [];
    },
    "78a5": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("00e1"), u = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = u.a;
    },
    "8c8b": function(t, e, n) {
        "use strict";
        var a = n("bc25");
        n.n(a).a;
    },
    "969d": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("a16c"), a(n("66fd"));
            var u = a(n("2bd8"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(u.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    bc25: function(t, e, n) {}
}, [ [ "969d", "common/runtime", "common/vendor" ] ] ]);