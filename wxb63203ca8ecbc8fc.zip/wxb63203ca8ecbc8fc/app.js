var e = require("@babel/runtime/helpers/interopRequireDefault");

require("./common/utils/myPage");

var r = require("./common/utils/logger"), o = require("./common/utils/navigate"), i = require("./common/utils/forceUpdate"), n = require("./common/utils/storage");

require("umtrack-wx");

var t = require("./common/utils/copyCode"), a = e(require("@xmly/raven-lite/index")), u = require("./common/utils/env"), s = require("./common/utils/handleVipSubsribe"), l = require("./common/utils/wxCookie");

App({
    globalData: {
        isHide: !1,
        isPlayerBarMini: !1
    },
    umengConfig: {
        appKey: "5f3f8a93b4b08b653e97d154",
        useOpenid: !0,
        autoGetOpenid: !1,
        debug: !1,
        uploadUserInfo: !0
    },
    onLaunch: function(e) {
        (0, r.init)(e.scene, e.referrerInfo), (0, n.set)("show_bubble", "true");
        a.default.config("https://734433aa684d4f999bd2d84ed1b7e8cc@websentry.ximalaya.com/2888", {
            release: "v20200914",
            environment: "production",
            allowDuplicates: !0,
            sampleRate: .1
        }).install(), u.isDevelopment || setTimeout(function() {
            (0, t.copyCodeByEvent)("qt");
        }, 300), (0, i.forceUpdateWeixinVersion)();
    },
    onShow: function(e) {
        var i = e.query || e[0].query, n = e.scene || e[0].scene, t = e.referrerInfo || e[0].referrerInfo;
        if (i.from || i.copy) {
            var a = i.from, u = i.count, c = i.plan, m = i.copy, p = i.copydt;
            this.sq = {
                from: a,
                count: u,
                plan: c,
                copy: m,
                copydt: p
            };
        }
        (0, r.set_sq)(i, n, t), this.scene = n, (0, o.paidAlbumNavigate)(e), (0, s.delayHandleVipSubsribe)(e), 
        (0, l.handleNavigatedCookie)(e), this.globalData.isHide = !1;
    },
    onHide: function() {
        this.globalData.isHide = !0;
    },
    onError: function(e) {
        console.log("xm发生错误", e), a.default.captureException(JSON.stringify(e), {
            level: "error"
        });
        try {
            wx.reportAnalytics("error", {
                message: JSON.stringify(e).slice(0, 1024)
            });
        } catch (e) {
            console.log(e);
        }
    }
});