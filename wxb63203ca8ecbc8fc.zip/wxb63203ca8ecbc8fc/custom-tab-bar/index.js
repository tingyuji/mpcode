var e = require("../common/utils/logger"), t = require("../packages/lite-player/event"), i = require("../common/apis/tabbar"), a = require("../common/utils/storage"), s = require("../common/utils/myAdapter");

Component({
    data: {
        isShow: !1,
        selected: 0,
        color: "#999999",
        selectedColor: "#f86442",
        backgroundColor: "white",
        list: [ {
            text: "首页",
            pagePath: "/pages/index/index",
            iconPath: "/images/bar_ic_home.png",
            selectedIconPath: "/images/bar_ic_home_selected.png"
        }, {
            text: "精品",
            pagePath: "/pages/paid/paid",
            iconPath: "/images/bar_ic_paid.png",
            selectedIconPath: "/images/bar_ic_paid_selected.png"
        }, {
            text: "我的",
            pagePath: "/pages/mine/mine",
            iconPath: "/images/bar_ic_me.png",
            selectedIconPath: "/images/bar_ic_me_selected.png"
        } ]
    },
    attached: function() {
        this._hideBar = this.hideBar.bind(this), this._showBar = this.showBar.bind(this), 
        this._onNightChange = this.onNightChange.bind(this), this._setHomeBack = this.setHomeBack.bind(this), 
        t.EventBus.on("openGModal", this._hideBar), t.EventBus.on("hideGModal", this._showBar), 
        t.EventBus.on("changeNightMode", this._onNightChange), t.EventBus.on("setHomeBackIcon", this._setHomeBack), 
        this.onNightChange();
    },
    methods: {
        showBar: function() {
            this.setData({
                isShow: !0
            });
        },
        hideBar: function() {
            this.setData({
                isShow: !1
            });
        },
        onNightChange: function(e) {
            var t = Number(e);
            t > 0 || (0, s.isUndefined)(e) && (0, a.get)("night_mode") > 1 ? this.setData({
                color: "#e7e7e7",
                backgroundColor: "#7d7c79"
            }) : (0 === t || (0, s.isUndefined)(e) && 0 === (0, a.get)("night_mode")) && this.setData({
                color: "#999999",
                backgroundColor: "white"
            });
        },
        setHomeBack: function(e) {
            var t = this.data.list, i = void 0 === t ? [] : t;
            if (i.length > 0) {
                var a = i.slice();
                a[0].selectedIconPath = e ? "/images/bar_ic_home_back.png" : "/images/bar_ic_home_selected.png", 
                this.setData({
                    list: a
                });
            }
        },
        setTabBar: function(e) {
            var t = this;
            if (e) {
                var a = e.route || "/index/index";
                (0, i.getTabbarInfo)().then(function(e) {
                    if (e && e.length) {
                        var i = e.findIndex(function(e) {
                            return e && e.pagePath.includes(a);
                        });
                        i > -1 && t.setData({
                            selected: i,
                            list: e,
                            isShow: !0
                        });
                    } else t.setData({
                        selected: 0,
                        list: e,
                        isShow: !0
                    });
                });
            }
        },
        switchTab: function(i) {
            var a = i.currentTarget.dataset, s = a.index, n = a.path, o = this.data.selected;
            s === o && 0 === o && t.EventBus.emit("backHomeTop"), wx.switchTab({
                url: n,
                success: function() {},
                fail: function(e) {
                    console.log(e, "switch tab error");
                },
                complete: function() {
                    wx.showLoading({
                        title: "加载中"
                    }), setTimeout(function() {
                        wx.hideLoading();
                    }, 1e3);
                }
            }), (0, e.genLogger)(28692, "click", {
                currPage: "overall"
            }), "/pages/vip/vip" === n && (0, e.genLogger)(28694, "click", {
                currPage: "vip"
            });
        }
    }
});