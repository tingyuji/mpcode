Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.RADIOS = exports.HOTNEWS = void 0;

exports.RADIOS = "radios";

exports.HOTNEWS = "hotNews";