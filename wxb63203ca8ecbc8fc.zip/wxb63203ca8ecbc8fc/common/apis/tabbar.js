Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getTabbarInfo = function() {
    return (0, t.request)({
        url: r.Apis.queryCustomTabbarList
    }).then(function(r) {
        var t = r.data, u = void 0 === t ? [] : t;
        if (0 === r.ret && u.length > 0) {
            var o = u.filter(function(e) {
                return "1" === e.os;
            }), a = u.filter(function(e) {
                return "2" === e.os;
            }), s = ((0, n.isIos)() ? a.length > 0 && a[0].list : o.length > 0 && o[0].list) || [];
            return s = s.length > 0 ? s.map(function(r) {
                return e(e({}, r), {}, {
                    iconPath: (0, i.image2Url)(r.iconPath),
                    selectedIconPath: (0, i.image2Url)(r.selectedIconPath)
                });
            }) : [];
        }
        return [];
    }).catch(function(e) {
        return console.log("getTabbarInfo err", e);
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("./request"), n = require("../../common/utils/index"), i = require("../utils/index");