Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryMigrationTips = function() {
    return (0, e.request)({
        url: e.Apis.queryMigrationTips
    }).then(function(e) {
        return e.data || {};
    });
}, exports.queryPoints = function() {
    return (0, e.request)({
        url: e.Apis.queryUserPoint
    }).then(function(e) {
        return e.data || {};
    });
};

var e = require("./index");