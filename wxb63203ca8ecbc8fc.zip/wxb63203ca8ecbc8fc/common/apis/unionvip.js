Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.bindMobile = function(t) {
    var n = t.clientId, r = t.mobile;
    return (0, e.request)({
        method: "POST",
        url: e.Apis.bindMobile,
        data: {
            clientId: n,
            mphone: r,
            remark: "+86"
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    }).catch(function(e) {
        return wx.showToast({
            icon: "none",
            title: "/bindMobile 接口异常"
        });
    });
}, exports.getUserInfo = function() {
    return (0, e.request)({
        url: e.Apis.getUserInfo
    }).then(function(e) {
        return e.data;
    });
}, exports.mobileSend = function(r) {
    var o = r.mobile;
    return n().then(function(n) {
        var r = (0, t.getSignature)({
            mobile: o,
            nonce: n,
            sendType: 1,
            templateId: "tplca9262d4c37b4f63"
        });
        return (0, e.request)({
            method: "POST",
            url: e.Apis.mobileSend,
            data: {
                mobile: o,
                nonce: n,
                sendType: 1,
                signature: r,
                templateId: "tplca9262d4c37b4f63"
            }
        }).then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return e;
        }).catch(function(e) {
            return wx.showToast({
                icon: "none",
                title: "/mobile/send 接口异常"
            });
        });
    });
}, exports.mobileVerify = function(t) {
    var n = t.code, r = t.mobile;
    return (0, e.request)({
        method: "POST",
        url: e.Apis.mobileVerify,
        data: {
            code: n,
            mobile: r,
            templateId: "tplca9262d4c37b4f63"
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    }).catch(function(e) {
        return wx.showToast({
            icon: "none",
            title: "/mobile/verify 接口异常"
        });
    });
}, exports.queryNonce = n, exports.queryUnionProductById = function(t) {
    return (0, e.request)({
        url: e.Apis.queryUnionProductById,
        data: {
            itemId: t
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data;
    }).catch(function(e) {
        return wx.showToast({
            icon: "none",
            title: "queryUnionProductById 接口异常"
        });
    });
}, exports.querybindMobile = function(t) {
    var n = t.clientId;
    return (0, e.request)({
        url: e.Apis.querybindMobile,
        data: {
            clientId: n,
            ts: Date.now()
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.ret, n = e.msg;
        return 0 !== t ? (wx.showToast({
            icon: "none",
            title: "".concat(n)
        }), "") : e.data.bind.mphone;
    }).catch(function(e) {
        return wx.showToast({
            icon: "none",
            title: "/querybindMobile 接口异常"
        });
    });
};

var e = require("./index"), t = require("../utils/security");

function n() {
    return (0, e.request)({
        url: e.Apis.queryNonce + Date.now()
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data;
    });
}