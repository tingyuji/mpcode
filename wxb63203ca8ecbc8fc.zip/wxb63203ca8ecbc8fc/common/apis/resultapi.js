Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryAllCategory = function(r) {
    return (0, e.request)({
        url: e.Apis.queryAllCategory,
        data: r
    }).then(function(e) {
        var r = (e.data || {}).categories;
        return {
            categories: void 0 === r ? [] : r
        };
    });
}, exports.querySearchResult = function(t) {
    return (0, e.request)({
        url: e.Apis.querySearchResult,
        data: t
    }).then(function(e) {
        var t = e.data || {}, u = t.albumViews, s = t.trackViews, a = t.userViews, i = (u || {}).albums, n = void 0 === i ? [] : i, o = (s || {}).tracks, c = void 0 === o ? [] : o, l = (a || {}).users, p = void 0 === l ? [] : l;
        return u.albums = n.map(function(e) {
            return (0, r._parseAlbum)(e);
        }), s.tracks = c.map(function(e) {
            return (0, r._parseTrack)(e);
        }), a.users = p.map(function(e) {
            return (0, r._parseUser)(e);
        }), {
            albumViews: u,
            trackViews: s,
            userViews: a
        };
    });
};

var e = require("./index"), r = require("./parse");