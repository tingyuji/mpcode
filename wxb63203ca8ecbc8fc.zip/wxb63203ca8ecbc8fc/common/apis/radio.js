Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getChangeRadios = function() {
    return (0, r.request)({
        url: r.Apis.changeRadios
    }).then(function(r) {
        return (r.data || []).map(function(r) {
            return (0, e.parseRadio)(r);
        });
    });
}, exports.getListFavoriteRadios = function(e) {
    return (0, r.request)({
        url: r.Apis.favorRadios,
        data: e
    }).then(function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return r.data || {};
    });
}, exports.getRadioHomepage = function() {
    return (0, r.request)({
        url: r.Apis.radioHomepage
    }).then(function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return r.data || [];
    });
}, exports.getRadioProsInfo = function(e) {
    var t = wx.getSystemInfoSync();
    return (0, r.request)({
        url: r.Apis.radioPlayProgramInfo,
        data: {
            radioId: e,
            device: t.platform
        }
    }).then(function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return r.data || {};
    });
}, exports.operateFavorite = function(e, t) {
    return (0, r.request)({
        url: t ? r.Apis.radioUnFavorite : r.Apis.radioFavorite,
        method: "POST",
        data: {
            radioId: e
        }
    }).then(function(r) {
        return {
            success: r.data,
            isFavorite: !t
        };
    });
}, exports.searchRadiosWithLoCaId = function(t) {
    return (0, r.request)({
        url: r.Apis.searchRadios,
        data: t
    }).then(function(r) {
        var t = r.data, a = void 0 === t ? {} : t, o = a.radios, n = void 0 === o ? [] : o;
        return a.radios = n.map(function(r) {
            return (0, e.parseRadio)(r);
        }), a;
    });
};

var r = require("./index"), e = require("./parse");