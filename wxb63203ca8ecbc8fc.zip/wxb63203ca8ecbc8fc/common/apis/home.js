Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getBannerAdSetting = function() {
    return (0, r.request)({
        url: r.Apis.queryHomeBannerAd
    }).then(function(e) {
        var t = (e || {}).data;
        return (void 0 === t ? [] : t) || [];
    });
}, exports.getCategoryFeed = function(u) {
    return (0, r.request)({
        url: r.Apis.queryCategoryFeed,
        data: {
            categoryId: u
        }
    }).then(function(r) {
        var u = (r || {}).data;
        return e((void 0 === u ? [] : u).map(function(e) {
            return "track" === e.type ? t(t({}, e), {}, {
                data: (0, n._parseTrack)(e.data)
            }) : "album" === e.type ? t(t({}, e), {}, {
                data: (0, n._parseAlbum)(e.data)
            }) : void 0;
        }));
    });
}, exports.getCategoryHotChannels = function() {
    return (0, r.request)({
        url: r.Apis.queryCategoryChannels
    }).then(function(e) {
        var t = (e || {}).data;
        return void 0 === t ? [] : t;
    });
}, exports.getExAdWidgetSetting = function() {
    return (0, r.request)({
        url: r.Apis.queryExAdWidget
    }).then(function(e) {
        var t = (e || {}).data;
        return (void 0 === t ? [] : t)[0] || {};
    });
}, exports.getIndexCategories = function() {
    return (0, r.request)({
        url: r.Apis.queryIndexCategory
    }).then(function(e) {
        var t, r = e || {}, n = r.ret, u = r.data;
        if (0 === n) return (void 0 === u ? [] : u).sort((t = "order", function(e, r) {
            return e[t] - r[t];
        }));
    });
}, exports.getIndexContent = function(e) {
    return (0, r.request)({
        url: r.Apis.queryIndexContent,
        data: {
            categoryPinyin: e
        }
    }).then(function(r) {
        console.log(e);
        var u = r || {}, a = u.ret, o = u.data, i = (o = void 0 === o ? {} : o).modules;
        if (0 === a) {
            var d = [];
            return (void 0 === i ? [] : i).forEach(function(e) {
                if (0 !== e.moduleInfo.length || "ugc" === e.moduleType && e.redirect) {
                    var r = {};
                    if ("ad" === e.moduleType) {
                        var u = e.moduleInfo.map(function(e) {
                            return t({}, e.adFocusPictureDetail);
                        });
                        r = t(t({}, e), {}, {
                            moduleInfo: u
                        });
                    } else r = "album" === e.moduleType ? t(t({}, e), {}, {
                        moduleInfo: e.moduleInfo.map(function(e) {
                            return (0, n._parseAlbum)(e);
                        })
                    }) : "track" === e.moduleType ? t(t({}, e), {}, {
                        moduleInfo: e.moduleInfo.map(function(e) {
                            return (0, n._parseTrack)(e);
                        })
                    }) : (e.moduleType, t({}, e));
                    d.push(t({}, r));
                }
            }), d;
        }
    });
}, exports.getIndexFeed = function() {
    return (0, r.request)({
        url: r.Apis.queryHomeFeed
    }).then(function(r) {
        var u = (r || {}).data;
        return e((void 0 === u ? [] : u).map(function(e) {
            return "track" === e.type ? t(t({}, e), {}, {
                data: (0, n._parseTrack)(e.data)
            }) : "album" === e.type ? t(t({}, e), {}, {
                data: (0, n._parseAlbum)(e.data)
            }) : void 0;
        }));
    });
}, exports.queryIndexTabModule = function(e) {
    return (0, r.request)({
        url: e
    }).then(function(e) {
        var t = e || {}, r = t.ret, n = t.list, a = void 0 === n ? [] : n, o = t.msg;
        if (console.log("error msg", o), 0 === r) return a.map(function(e) {
            return {
                id: e.specialId,
                title: e.title || "",
                subtitle: e.subtitle || "",
                count: e.count || 0,
                nickname: e.nickname || "喜马用户",
                listenType: e.tag || e.specialContentType,
                cover: (0, u.image2Url)(e.coverPath)
            };
        });
    });
}, exports.queryIndexTabRankList = function() {
    return (0, r.request)({
        url: r.Apis.getIndexTabRankList
    }).then(function(e) {
        var t = (e || {}).data;
        return void 0 === t ? [] : t;
    });
}, exports.queryRecommendBanner = function() {
    return (0, r.request)({
        url: r.Apis.queryHomeRecBanner
    }).then(function(e) {
        return e.data || {};
    });
}, exports.queryShowUpgradeModal = function() {
    return (0, r.request)({
        url: r.Apis.queryShowUpgradeModal
    }).then(function(e) {
        return e.data && e.data[0] || {};
    });
};

var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), n = require("./parse"), u = require("../utils/index");