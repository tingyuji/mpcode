Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.deleteListenedTrack = function(e) {
    return (0, t.request)({
        url: t.Apis.deleteListened,
        data: {
            delType: 1,
            trackId: e
        },
        method: "POST"
    }).then(function(e) {
        var t = e.ret, r = e.msg;
        200 !== t && wx.showToast({
            icon: "none",
            title: r
        });
    });
}, exports.queryGetListened = function() {
    return (0, t.request)({
        url: t.Apis.queryGetListened,
        data: {
            includeChannel: !1,
            includeRadio: !1
        }
    }).then(function(e) {
        var r = e.data || {}, a = r.yesterday, u = void 0 === a ? [] : a, n = r.earlier, i = void 0 === n ? [] : n, o = r.today, s = void 0 === o ? [] : o;
        return {
            yesterday: u.map(function(e) {
                return (0, t._parseTrack)(e);
            }),
            earlier: i.map(function(e) {
                return (0, t._parseTrack)(e);
            }),
            today: s.map(function(e) {
                return (0, t._parseTrack)(e);
            })
        };
    });
}, exports.queryHasBroughtAlbums = function(e) {
    return (0, t.request)({
        url: t.Apis.queryHasBroughtAlbums,
        data: e
    }).then(function(e) {
        var r = e.data || {}, a = r.pageNum, u = void 0 === a ? 1 : a, n = r.pageSie, i = void 0 === n ? 20 : n, o = r.totalCount, s = void 0 === o ? 0 : o, d = r.items, c = {
            page: u,
            pageSie: i,
            total: s,
            albumList: (void 0 === d ? [] : d).map(function(e) {
                return (0, t._parseAlbum)(e);
            })
        };
        return console.log("BroughtAlbums=====", c), c;
    });
}, exports.queryLikeTracks = function(a) {
    return (0, t.request)({
        url: t.Apis.queryGetLikeTracks,
        data: a
    }).then(function(t) {
        var a = t.data || {}, u = a.pageNum, n = void 0 === u ? 1 : u, i = a.pageSize, o = void 0 === i ? 20 : i, s = a.totalCount, d = void 0 === s ? 0 : s, c = a.tracksList;
        return {
            page: n,
            pageSize: o,
            total: d,
            tracksList: (void 0 === c ? [] : c).map(function(t) {
                return e(e({}, t), {}, {
                    trackCoverPath: (0, r.image2Url)(t.trackCoverPath || "")
                });
            })
        };
    });
}, exports.querySrcById = function(e) {
    return (0, t.request)({
        url: t.Apis.querySrcByTrackId,
        data: e
    }).then(function(e) {
        return e.data || {};
    });
}, exports.querySubscribeAlbum = function(r) {
    return (0, t.request)({
        url: t.Apis.querySubscribeAlbum,
        data: e(e({}, r), {}, {
            from: 4
        })
    }).then(function(e) {
        var r = e.data || {}, a = r.pageNum, u = void 0 === a ? 1 : a, n = r.pageSize, i = void 0 === n ? 20 : n, o = r.totalCount, s = void 0 === o ? 0 : o, d = r.albumsInfo;
        return {
            page: u,
            pageSize: i,
            total: s,
            albumList: (void 0 === d ? [] : d).map(function(e) {
                return (0, t._parseAlbum)(e);
            })
        };
    });
}, exports.queryUserInfo = function(a) {
    return (0, t.request)({
        url: t.Apis.queryAnchorBasic,
        data: e({}, a)
    }).then(function(t) {
        return e(e({}, t.data), {}, {
            cover: t.data && (0, r.image2Url)(t.data.cover || "")
        });
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("./index"), r = require("../utils/index");