Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.HOTNEWSPARAM = void 0, exports.getHotNewsTabList = function() {
    return (0, e.request)({
        url: "".concat(e.Apis.hotNewsTabList, "/ts-").concat(new Date().getTime())
    }).then(function(e) {
        return e.data;
    });
}, exports.getHotNewsTrackInfo = function(t) {
    var a = wx.getSystemInfoSync();
    return (0, e.request)({
        url: "".concat(e.Apis.hotNewsTrackInfo, "/ts-").concat(new Date().getTime()),
        data: {
            trackId: t,
            device: a.platform
        }
    });
}, exports.getHotNewsTrackList = function() {
    var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r, n = s.channelId, o = s.pageSize, i = s.pageId, c = s.channelType, u = 0 === c ? e.Apis.hotNewsTrackList0 : e.Apis.hotNewsTrackList, d = 0 === c ? {
        channelId: n,
        isFirst: !1,
        like: -1,
        trackLimit: o
    } : {
        groupId: n,
        pageSize: o,
        pageId: i
    };
    return (0, e.request)({
        url: "".concat(u, "/ts-").concat(new Date().getTime()),
        data: d
    }).then(function(e) {
        var r = e.data, s = r.list, n = r.itemInfos, o = (0, a.getLocalPlayProgress)();
        return e.data.list = (s || n).map(function(e) {
            return (0, t.parseHotNewsTrack)(e, o[e.trackId]);
        }), e.data;
    });
}, exports.saveHotNesChannels = function(t) {
    return (0, e.request)({
        url: e.Apis.hotNewsSaveChannels,
        method: "POST",
        data: {
            radioIds: t
        }
    });
};

var e = require("./index"), t = require("./parse"), a = require("../utils/hotNews"), r = {
    channelId: 80,
    pageSize: 10,
    pageId: 1
};

exports.HOTNEWSPARAM = r;