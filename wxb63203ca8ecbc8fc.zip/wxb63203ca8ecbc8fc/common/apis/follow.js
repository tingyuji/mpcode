Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryUserFans = function(a) {
    return (0, r.request)({
        url: r.Apis.queryFans,
        data: a
    }).then(function(r) {
        var a = r.data || {}, n = a.page, o = void 0 === n ? 1 : n, i = a.pageSize, u = void 0 === i ? 10 : i, s = a.totalCount;
        return {
            page: o,
            pageSize: u,
            total: void 0 === s ? 0 : s,
            fansList: a.fansPageInfo.map(function(r) {
                return e(e({}, r), {}, {
                    coverPath: (0, t.image2Url)(r.coverPath)
                });
            })
        };
    });
}, exports.queryUserFollowings = function(a) {
    return (0, r.request)({
        url: r.Apis.queryFollowings,
        data: a
    }).then(function(r) {
        var a = r.data || {}, n = a.page, o = void 0 === n ? 1 : n, i = a.pageSize, u = void 0 === i ? 20 : i, s = a.totalCount;
        return {
            page: o,
            pageSize: u,
            total: void 0 === s ? 0 : s,
            fansList: a.followingsPageInfo.map(function(r) {
                return e(e({}, r), {}, {
                    coverPath: (0, t.image2Url)(r.coverPath)
                });
            })
        };
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("../utils/index");