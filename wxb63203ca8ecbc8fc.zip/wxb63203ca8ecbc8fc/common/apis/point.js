Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAlbumPoints = function(r) {
    return (0, e.request)({
        url: e.Apis.queryAlbumPoints + r
    });
}, exports.getTrackPoints = function(r) {
    return (0, e.request)({
        url: e.Apis.queryTrackPoints + r
    });
}, exports.usePointUnlockTrack = function(r) {
    return (0, e.request)({
        url: e.Apis.usePointUnlockTrack + r,
        method: "POST"
    });
};

var e = require("./index");