Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.assistFriend = function(e) {
    return (0, r.request)({
        url: r.Apis.assisTask,
        data: e,
        method: "POST"
    }).then(function(e) {
        return e.data || {};
    });
}, exports.assistShareTask = function(e) {
    var a = n.isDevelopment ? t({}, e) : t(t({}, e), {}, {
        context: {
            id: (0, s.getWXAccessOpenId)(),
            type: 3,
            tag: "18"
        }
    });
    return (0, r.request)({
        url: r.Apis.assistShareTask,
        data: a,
        method: "POST"
    }).then(function(e) {
        return (e || {}).data;
    });
}, exports.drawAssisAward = function(e) {
    return (0, r.request)({
        url: r.Apis.drawShareAssistAward,
        data: e,
        method: "POST"
    });
}, exports.drawTaskAward = function(e) {
    return (0, r.request)({
        url: r.Apis.drawTaskAward,
        method: "POST",
        data: t({
            aid: 6
        }, e)
    }).then(function(e) {
        return e.data || {};
    });
}, exports.exchangeStar = function() {
    return (0, r.request)({
        url: r.Apis.exchangeStar2Points,
        method: "POST"
    });
}, exports.getAssistMigrateUsers = function() {
    return (0, r.request)({
        url: r.Apis.queryAssistMigrateUsers,
        method: "GET"
    }).then(function(e) {
        var t = e || {};
        return 0 === t.ret && t.data || {};
    });
}, exports.getTaskToken = u, exports.participateShareActicity = function(e) {
    return (0, r.request)({
        url: r.Apis.participateShareActivity,
        data: e,
        method: "POST"
    }).then(function(e) {
        return (e || {}).data;
    });
}, exports.queryBasicShareInfo = function(e) {
    return (0, r.request)({
        url: r.Apis.queryBasicShareInfo,
        data: e,
        method: "GET"
    }).then(function(e) {
        return (e || {}).data;
    });
}, exports.queryRules = function() {
    return (0, r.request)({
        url: r.Apis.queryActivityRules
    }).then(function(e) {
        return e.data || {};
    });
}, exports.queryShareInfos = function() {
    return (0, r.request)({
        url: r.Apis.queryShareInfos
    }).then(function(e) {
        return e.data || {};
    });
}, exports.queryShareRecords = function(e) {
    return (0, r.request)({
        url: r.Apis.queryShareRecords,
        data: e,
        method: "GET"
    }).then(function(e) {
        return (e || {}).data.map(a);
    });
}, exports.queryStarInfo = function() {
    return (0, r.request)({
        url: r.Apis.queryStarPoints
    }).then(function(e) {
        return (e || {}).data;
    });
}, exports.queryTasks = function(n) {
    return (0, r.request)({
        url: r.Apis.queryTaskRecords,
        data: t({
            aid: 6
        }, n)
    }).then(function(t) {
        var n = (t.data || {}).taskItems;
        return e(n.map(function(e) {
            return (0, r.parseTaskInfo)(e);
        }));
    });
}, exports.updateTaskProgress = function(e) {
    return u().then(function(t) {
        return (0, r.request)({
            url: r.Apis.updateTaskProgress,
            data: {
                token: t,
                aid: 6,
                taskId: e,
                progress: 1
            },
            method: "POST"
        }).then(function(e) {
            return e.data || {};
        });
    });
};

var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), n = require("../utils/index"), s = require("../../common/utils/wxCookie");

function a(e) {
    return t(t({}, e), {}, {
        assistId: e.id,
        logo: e.assistUserInfo && (0, n.image2Url)(e.assistUserInfo.headPortrait)
    });
}

function u(e) {
    return (0, r.request)({
        url: r.Apis.genTaskToken,
        data: {
            aid: 6,
            taskId: e
        },
        method: "POST"
    }).then(function(e) {
        return (e.data || {}).token;
    });
}