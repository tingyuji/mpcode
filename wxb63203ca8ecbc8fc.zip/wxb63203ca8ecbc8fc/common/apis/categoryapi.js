Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryCategories = function() {
    return (0, e.request)({
        url: e.Apis.queryCategories
    }).then(function(e) {
        return e.data;
    });
};

var e = require("./index");