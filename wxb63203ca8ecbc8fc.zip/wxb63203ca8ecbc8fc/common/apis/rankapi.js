Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryRank = function(t) {
    return (0, e.request)({
        url: e.Apis.queryRank,
        data: t
    }).then(function(t) {
        if (0 === t.ret) {
            var r = t.data || {}, n = r.rankModuleInfoList, o = void 0 === n ? [] : n, u = r.clusterCode, a = r.categoryCode;
            return {
                clusterCode: u,
                rankId: r.rankId,
                categoryCode: a,
                contentType: r.contentType,
                title: r.title,
                rankList: o.map(function(t) {
                    return (0, e._parseAlbum)(t);
                })
            };
        }
    });
};

var e = require("./index");