Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryDetail = function(a) {
    return (0, r.request)({
        url: r.Apis.queryPointsDetail,
        data: a
    }).then(function(r) {
        var a = r.data || {};
        return {
            page: a.page,
            pageSize: a.pageSize,
            hasMore: a.hasMore,
            infos: a.infos.map(function(r) {
                return e(e({}, r), {}, {
                    createAt: (0, t.dateFmt)(r.createAt)
                });
            })
        };
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("../utils/time");