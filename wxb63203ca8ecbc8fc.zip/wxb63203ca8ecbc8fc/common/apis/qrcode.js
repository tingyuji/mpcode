Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCurrentUser = function() {
    return (0, r.request)({
        url: r.Apis.getCurrentUser
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || {};
    });
}, exports.getQrCode = function(t) {
    return (0, r.request)({
        url: r.Apis.genQrCode,
        method: "POST",
        data: e({
            littleProgramCode: "pay"
        }, t)
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        return "string" == typeof e && e.includes("http") || (wx.showToast({
            title: "获取二维码失败，请稍后重试",
            icon: "none"
        }), e = ""), e;
    });
}, require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index");