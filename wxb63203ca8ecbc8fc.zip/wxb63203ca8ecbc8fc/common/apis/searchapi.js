Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryHotWordCategory = function() {
    return (0, r.request)({
        url: r.Apis.queryHotWordCategory
    }).then(function(e) {
        var r = (e || {}).category;
        return void 0 === r ? [] : r;
    });
}, exports.queryHotWords = function(e) {
    return (0, r.request)({
        url: r.Apis.queryHotWords,
        data: e
    }).then(function(e) {
        var r = (e || {}).hotWordResultList;
        return {
            hotWordResultList: void 0 === r ? [] : r
        };
    });
}, exports.querySearchSuggest = function(e) {
    return (0, r.request)({
        url: r.Apis.querySearchSuggest,
        data: {
            kw: e.trim()
        },
        method: "post"
    }).then(function(e) {
        return e.data || {};
    });
}, exports.recommendSearch = function(t) {
    var o = t.trackPlay, u = void 0 === o ? [] : o, i = t.albumExposure, n = void 0 === i ? [] : i, s = t.history, d = void 0 === s ? [] : s, a = t.userId, c = void 0 === a ? "" : a;
    return (0, r.request)(e({
        url: r.Apis.recommendSearch,
        method: "POST",
        data: {
            trackPlay: JSON.stringify(u),
            albumExposure: JSON.stringify(n),
            device: "web",
            page: 1,
            pageSize: 10,
            userId: c,
            history: JSON.stringify(d),
            version: "3.0"
        }
    }, "method", "post")).then(function(e) {
        var r = e.code, t = void 0 === r ? 0 : r, o = e.hotWordList;
        return 0 === t && (void 0 === o ? [] : o) || [];
    });
};

var e = require("../../@babel/runtime/helpers/defineProperty"), r = require("./index");