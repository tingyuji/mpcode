Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getArticleDetail = function(r) {
    return (0, e.request)({
        url: e.Apis.queryArticleDetail,
        method: "get",
        data: {
            id: r
        }
    }).then(function(e) {
        var r = e.data, i = void 0 === r ? {} : r, o = i.author, a = i.content, n = i.date, u = i.title, c = i.categoryCode;
        return {
            author: o,
            date: n,
            title: u,
            content: (0, t.mpParse)((0, t.formatQARichText)(a.replace(/\+/g, " "))),
            categoryCode: c
        };
    });
};

var e = require("./index"), t = require("../../common/utils/index");