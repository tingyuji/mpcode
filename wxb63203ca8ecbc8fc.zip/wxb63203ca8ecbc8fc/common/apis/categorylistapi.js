Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryCategoryAlbumsByPage = function(t) {
    return (0, e.request)({
        url: e.Apis.queryCategoryAlbumsByPage,
        data: t
    }).then(function(t) {
        var a = t.data || {}, r = a.totalCount, u = a.albumBriefDetailInfos;
        return {
            totalCount: r,
            albumList: (void 0 === u ? [] : u).map(function(t) {
                return (0, e._parseAlbum)(t);
            })
        };
    });
}, exports.queryCategoryPage = function(t) {
    return (0, e.request)({
        url: e.Apis.queryCategoryPage,
        data: t
    }).then(function(t) {
        var a = t.data || {}, r = a.subCategories, u = void 0 === r ? [] : r, o = a.firstPageCategoryAlbums, n = void 0 === o ? {} : o, i = a.categoryDisplayName, s = n.totalCount, l = n.albumBriefDetailInfos, y = void 0 === l ? [] : l;
        return u.unshift({
            displayValue: "全部",
            code: "quanbu"
        }), {
            categoryDisplayName: i,
            totalCount: s,
            subCategories: u,
            categoryAlbumList: y.map(function(t) {
                return (0, e._parseAlbum)(t);
            })
        };
    });
};

var e = require("./index");