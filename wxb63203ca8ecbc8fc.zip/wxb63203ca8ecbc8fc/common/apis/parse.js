Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports._parseUser = exports._parseTrack = exports._parseAlbum = void 0, exports.compose = y, 
exports.parseAlbum = p, exports.parseAnchorInfo = function(e) {
    return t(t({}, e), {}, {
        cover: "https:".concat(e.cover)
    });
}, exports.parseComment = function e(r) {
    var t = r.id, o = r.uid, n = r.nickname, s = r.smallHeader, u = r.content, l = r.likes, c = r.liked, p = r.createdAt, m = r.updatedAt, d = r.pNickname, y = r.parentId, b = r.parentUid, g = r.replyCount, f = r.replies, h = r.pictureUrl;
    f && (f = f.map(e));
    return {
        id: t,
        uid: o,
        nickname: n,
        avatar: (0, a.image2Url)(s),
        content: (0, a.mpParse)((0, a.formatCommentContent)(u)),
        likesStr: (0, a.parseNum)(l),
        likes: l,
        liked: c,
        createdAt: (0, i.parseDateTime)(p),
        updatedAt: m,
        pNickname: d,
        parentId: y,
        parentUid: b,
        replies: f,
        replyCount: g,
        pictureUrl: h
    };
}, exports.parseHotNewsTrack = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0, n = new Date().getTime(), s = void 0 !== r, u = e.trackId, l = e.albumCoverPath, c = e.createdAt, p = e.duration, m = e.playPathAacv224, d = e.albumId, y = e.albumTitle, b = e.buzzGroupId;
    return t(t({}, e), {}, {
        id: u,
        title: e.title.replace(/\+/g, " "),
        cover: (0, a.image2Url)(l),
        createdAt: (0, i.formatElapseTime)(c, n, ""),
        durationStr: (0, i.parseTime)(p),
        src: m ? encodeURI(m) : "",
        albumName: y,
        channelId: b,
        album: {
            id: d,
            url: e.albumUrl || e.url ? e.url : "",
            jumpUrl: "/pages/soundPage/soundPage?trackId=".concat(u)
        },
        type: o.HOTNEWS,
        userPermission: !0,
        canPlay: !0,
        isXimiFirst: !0,
        canPlayXimiTrack: !0,
        playPercent: r || 0,
        isSeen: s
    });
}, exports.parseRadio = function(e) {
    var r = e.playCount;
    return t(t({}, e), {}, {
        playCount: (0, a.parseNum)(r)
    });
}, exports.parseRadioProgram = function(e, r, t) {
    var n = e.id, s = e.name, u = e.coverSmall, l = r.id, c = r.programScheduleId, p = r.programScheduledId, m = r.name, d = r.announcerNames, y = r.radioPlayUrlDTO, b = r.startTime, g = r.endTime;
    b && g || (b = "00:00", g = "23:59");
    var f = (0, i.startEndDuration)(b, g), h = f.duration, T = f.durationStr;
    return {
        id: l ? p || c : n,
        title: m,
        cover: (0, a.image2Url)(u),
        src: y && y.ts64,
        albumId: n,
        albumName: s,
        album: {
            id: n,
            jumpUrl: "/pages/radio-program-play/radio-program-play?radioId=".concat(n),
            startTime: b,
            endTime: g,
            radioId: n,
            programScheduleId: c || p,
            programId: l
        },
        singer: !!d && d.join(" ") || "",
        protocol: "hls",
        duration: h,
        durationStr: T,
        userPermission: !0,
        canPlay: !0,
        isXimiFirst: !0,
        canPlayXimiTrack: !0,
        startTime: 0,
        isLive: t,
        type: o.RADIOS
    };
}, exports.parseSellingPoint = c, exports.parseTaskInfo = function(e) {
    var r, i, o = e, n = o.stepType, s = o.stepStatusMap, u = void 0 === s ? {} : s, l = o.progress, c = o.contextMap, p = void 0 === c ? {} : c, m = o.condition;
    0 !== n && (2 === (i = 0 === l ? u[l + 1] : u[l]) && l !== m && (i = u[l + 1]), 
    r = p[i], e = t(t({}, e), {}, {
        multiStepStatus: i,
        multiStepText: r
    }));
    return t(t({}, e), {}, {
        assisters: e.assisters.map(function(e) {
            return e.logo && (e.logo = (0, a.image2Url)(e.logo)), e;
        })
    });
}, exports.parseTrack = m, exports.parseUgcInfo = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.anchorInfo, t = (r = void 0 === r ? {} : r).userInfo, o = void 0 === t ? {} : t, n = r.userExtendInfo, s = void 0 === n ? {} : n;
    return {
        ugcId: e.id,
        count: e.count,
        listenType: e.listenType,
        title: e.title,
        listenIntro: e.listenIntro,
        cover: (0, a.image2Url)(e.coverSmall || "//s1.xmcdn.com/yx/ximalaya-mobile-resource/last/dist/images/tinglist_no_content_c499b83.png"),
        nickname: o.nickname,
        anchorAvatar: (0, a.image2Url)(o.logo),
        anchorId: o.id,
        createdAt: (0, i.timestampToTime)(e.createdTime),
        isFollow: s.isFollowedByCurrentUser
    };
}, exports.parseUser = d;

var e = require("../../@babel/runtime/helpers/objectWithoutProperties"), r = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../utils/index"), i = require("../utils/time"), o = require("../../common/const/trackType"), n = [ "trackInfo", "playInfo", "statCountInfo", "pageUriInfo" ], s = [ "albumInfo", "statCountInfo", "pageUriInfo", "anchorInfo" ], u = [ "userInfo", "statCountInfo" ];

function l(e) {
    var r = e;
    return e.startsWith("http") && !e.startsWith("https") && (r = e.replace("http", "https")), 
    encodeURI(r);
}

function c(e) {
    return e || (e = {}), Object.keys(e).filter(function(r) {
        return e[r];
    }).map(function(r) {
        return e[r];
    });
}

function p(e) {
    return {
        id: e.id || e.albumId,
        cover: (0, a.image2Url)(e.cover || e.cover_path || e.coverPath || e.albumCoverPath),
        title: e.title || e.albumTitle || e.subTitle,
        url: e.url || e.albumUrl,
        subTitle: e.salePoint || "",
        type: e.albumType,
        price: e.price,
        intro: e.intro || e.description,
        categoryCode: e.categoryCode,
        categoryPinyin: e.pinyin,
        categoryName: e.categoryName,
        vipPrice: e.vipPrice,
        discountedPrice: e.discountedPrice,
        playCount: (0, a.parseNum)(e.playCount) || (0, a.parseNum)(e.play) || (0, a.parseNum)(e.albumPlayCount),
        oldPlayCount: e.playCount || e.play,
        includeTrackCount: e.trackCount || e.tracks || e.albumTrackCount,
        canNotCopyIntro: e.canNotCopyIntro,
        oldSubscribeCount: e.subscribe || e.subscribeCount,
        subscribeCount: (0, a.parseNum)(e.subscribe || e.subscribeCount),
        updatedTime: e.updatedTime || 0,
        campPhraseInfo: e.campPhraseInfo,
        isFinished: e.isFinished,
        createdAt: e.createdAt,
        shortIntro: e.shortIntro,
        commentContent: e.commentContent || e.count_comment,
        subscribe: !1,
        anchorName: e.anchorName || e.nickname,
        createdTime: (0, i.timestampToTime)(e.createdAt),
        albumPreferTag: e.albumPreferTag,
        albumTag: e.albumTag,
        isSample: e.isSample,
        isPaid: e.albumPayType > 0 || e.is_paid || e.isPaid,
        albumPayType: e.albumPayType,
        albumVipPayType: e.albumVipPayType,
        albumXimiVipPayType: e.albumXimiVipPayType,
        isVipFirst: e.isVipFirst,
        vipType: e.vipType,
        anchor: e.anchorId,
        albumFinishTag: e.albumFinishTag,
        trackCountLength: (e.trackCount || e.tracks || 0).toString().length,
        pushSwitchForWechat: e.pushSwitchForWechat,
        isTimeLimitedAlbum: e.isTimeLimitedAlbum,
        limiteCountdownTime: e.timeLimitedAlbumCountdownTime,
        sellingPoints: c(e.sellingPoint)
    };
}

function m() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = new Date().getTime(), t = e.id || e.trackId || e.childId;
    return {
        id: t,
        title: (e.trackTitle || e.title || e.childTitle || "").replace(/\+/g, " "),
        url: e.url || e.trackUrl || e.detailUrl,
        cover: (0, a.image2Url)(e.cover || e.cover_path || e.trackCover || e.album_cover_path || e.itemCoverUrl),
        videoCover: (0, a.image2Url)(e.videoCover, {
            op_type: 2,
            upload_type: "cover",
            rows: 360,
            columns: 640
        }),
        createdAt: e.createdAt || e.endedAt,
        updatedTime: e.updatedTime,
        updatedAt: (0, i.formatElapseTime)(e.updatedTime || e.updated_at, r),
        isFree: e.isFree,
        isPaid: e.isPaid || e.is_paid,
        needPay: e.isPaid && !e.userPermission,
        duration: e.duration,
        isTrailer: e.isTrailer,
        userPermission: e.userPermission,
        isVipFirst: e.isVipFirst || e.is_v,
        isXimiFirst: e.isXimiFirst,
        price: e.price,
        discountedPrice: e.discountedPrice,
        durationStr: e.trackDuration || e.duration ? (0, i.parseTime)(e.duration) : (0, 
        i.parseTime)(e.length),
        playCount: (0, a.parseNum)(e.playCount) || (0, a.parseNum)(e.count_play),
        oldPlayCount: e.playCount || e.count_play,
        shareCount: (0, a.parseNum)(e.shareCount) || (0, a.parseNum)(e.count_share),
        favoriteCount: e.favoriteCount || e.count_like,
        favoriteCountStr: (0, a.parseNum)(e.favoriteCount) || (0, a.parseNum)(e.count_like),
        commentCount: (0, a.parseNum)(e.commentCount) || (0, a.parseNum)(e.count_comment),
        categoryCode: e.categoryCode,
        intro: e.intro,
        isOffline: e.isOffline,
        isAudition: e.isPaid && e.isFree,
        isLock: !e.userPermission && e.isPaid && !e.isFree,
        sampleDuration: e.sampleDuration,
        iting: e.iting,
        isCopyright: e.isHoldCopyright,
        src: 5 === e.trackType ? l(e.baiduMusicUrl) : e.is_free && e.is_paid ? "" : e.playPath || e.play_path || !e.id ? encodeURI(e.playPath) || encodeURI(e.play_path) : e.playPath || e.play_path,
        albumId: e.albumId || e.album_id,
        albumName: e.albumName || e.itemTitle || e.albumTitle,
        album: {
            id: e.albumId || e.album_id || e.itemId,
            url: e.albumUrl || e.url ? e.url : "",
            jumpUrl: "/pages/soundPage/soundPage?trackId=".concat(t)
        },
        anchor: {
            id: e.anchorId || e.uid,
            anchorName: e.anchorName || e.userName
        },
        commentContent: e.commentContent || "",
        breakSecond: e.breakSecond,
        breakPercent: (100 * e.breakSecond / e.length).toString().split(".")[0],
        auditStatus: e.auditStatus,
        opType: e.opType,
        canPlayXimiTrack: e.canPlayXimiTrack,
        isVideo: e.isVideo
    };
}

function d() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return {
        uid: e.uid,
        pTtitle: e.pTtitle,
        gender: e.gender,
        isVerified: e.isVerified,
        logoPic: e.logoPic,
        nickname: e.nickname,
        isLoginBan: e.isLoginBan,
        smallPic: e.smallPic,
        vLogoType: e.vLogoType,
        verifyType: e.verifyType,
        tracksCounts: e.tracks_counts,
        followersCounts: (0, a.parseNum)(e.followers_counts),
        followingsCounts: e.followings_counts,
        isVip: e.isVip,
        userGrade: e.userGrade,
        anchorGrade: e.anchorGrade,
        personDescribe: e.personDescribe
    };
}

function y() {
    var e, t = Array.prototype.slice, a = t.call(arguments, 0) || [], i = [], o = r(a);
    try {
        for (o.s(); !(e = o.n()).done; ) {
            var n = e.value;
            Array.isArray(n) && (i = i.concat(a)), i.push(n);
        }
    } catch (e) {
        o.e(e);
    } finally {
        o.f();
    }
    for (var s = i.length, u = s; u--; ) if ("function" != typeof i[u]) throw new Error("Expected a function");
    return function() {
        for (var e = t.call(arguments, 0) || [], r = 0, a = s ? i[r].apply(this, e) : e[0]; ++r < s; ) a = i[r].call(this, a);
        return a;
    };
}

var b = y(function(r) {
    var a = r.trackInfo, i = r.playInfo, o = r.statCountInfo, s = r.pageUriInfo, u = e(r, n);
    return t(t(t(t(t({}, a), i), o), s), u);
}, m);

exports._parseTrack = b;

var g = y(function(r) {
    var a = r.albumInfo, i = r.statCountInfo, o = r.pageUriInfo, n = r.anchorInfo, u = void 0 === n ? {} : n, l = e(r, s);
    return t(t(t(t({}, a), i), o), {}, {
        anchorName: u.nickname || ""
    }, l);
}, p);

exports._parseAlbum = g;

var f = y(function(r) {
    var a = r.userInfo, i = r.statCountInfo, o = e(r, u);
    return t(t(t({}, a), i), o);
}, d);

exports._parseUser = f;