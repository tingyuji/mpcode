Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryForceUpdateContent = function() {
    return (0, e.request)({
        url: e.Apis.queryForceUpdateContent
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || [];
    });
}, exports.queryOpenAppContent = function() {
    return (0, e.request)({
        url: e.Apis.queryOpenAppContent
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || [];
    });
};

var e = require("./index");