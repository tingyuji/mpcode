Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryActivitySettings = function() {
    var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.queryWxgroupActivitySetting,
        data: i
    }).then(function(r) {
        var i = (r || {}).data.filter(function(e) {
            return e.isShow;
        });
        return 0 === i.length ? [] : i.map(function(r) {
            return e(e({}, r), {}, {
                pageImage: (0, t.fillImageUrl)(r.pageImage),
                cardImage: (0, t.fillImageUrl)(r.cardImage)
            });
        });
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("../utils/index");