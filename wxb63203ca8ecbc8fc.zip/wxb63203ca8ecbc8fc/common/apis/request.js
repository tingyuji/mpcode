var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.request = void 0, require("../../@babel/runtime/helpers/Arrayincludes");

var r = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../utils/storage"), t = e(require("../utils/xmSign")), a = require("@xmly/lite-login_wx/lib/index"), o = e(require("@xmly/raven-lite")), n = [ "authentication-server", "business-jvip-mobile-web", "radio-first-page-app" ];

exports.request = function(e) {
    var u = e.url, s = e.data, l = e.method, d = void 0 === l ? "GET" : l, c = e.headers, p = void 0 === c ? {} : c;
    return new Promise(function(e, l) {
        var c = a.cookies.getCookieByURI(u), m = r(r({}, p), {}, {
            cookie: c,
            Origin: "https://m.ximalaya.com"
        });
        u.includes("/revision") && (m["xm-sign"] = (0, t.default)()), u.includes("/mobile") && !n.some(function(e) {
            return u.includes(e);
        }) && (m["Content-Type"] = "application/x-www-form-urlencoded"), wx.request({
            url: u,
            data: s,
            header: m,
            method: d,
            success: function(r) {
                if (401 === r.data.ret || 303 === r.data.ret || 50 === r.data.ret) return (0, i.removeUid)(), 
                wx.navigateTo({
                    url: "/pages/login/login"
                });
                if (404 === r.data.ret) return wx.redirectTo({
                    url: "/pages/404/index"
                });
                if (a.cookies.parseHeaders(r.header), e(r.data), !(0, i.getUid)()) {
                    var t = r.data.context, o = (t = void 0 === t ? {} : t).currentUser, n = (o = void 0 === o ? {} : o).id;
                    n && (0, i.getUid)(n);
                }
            },
            fail: function(e) {
                console.log("request error", u, e), o.default.captureException(JSON.stringify(e), {
                    level: "error"
                }), l(e);
            }
        });
    });
};