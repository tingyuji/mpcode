Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getUserInfo = function() {
    return (0, r.request)({
        url: r.Apis.getUserInfo
    }).then(function(e) {
        return e.data;
    });
}, exports.queryPaidCategory = function() {
    return (0, r.request)({
        url: r.Apis.queryPaidCategory
    }).then(function(e) {
        return e.data || {};
    });
}, exports.queryPaidRankList = function() {
    return (0, r.request)({
        url: r.Apis.queryPaidRank
    }).then(function(e) {
        var r = e.data.rankList;
        return ((void 0 === r ? [] : r)[0].albums || []).slice(0, 8).map(u);
    });
}, exports.queryVipCategoryPageAlbum = function(a) {
    return (0, r.request)({
        url: r.Apis.queryVipCategoryPageAlbum,
        data: e({
            subcategory: "",
            meta: "",
            isVip: !t.isDevelopment,
            sort: 0,
            perPage: 10
        }, a)
    }).then(function(r) {
        var t = r.data, a = void 0 === t ? {} : t;
        return e(e({}, a), {}, {
            albums: a.albums.map(u)
        });
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("../utils/index"), u = function(e) {
    return {
        id: e.id || e.albumId,
        title: e.albumTitle || e.title,
        playCount: (0, t.parseNum)(e.playCount),
        trackCount: e.trackCount,
        vipType: e.vipType,
        isPaid: e.isPaid,
        cover: (0, t.image2Url)(e.cover || e.coverPath),
        anchorName: e.anchorName
    };
};