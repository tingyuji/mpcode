Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getPlayInfo = function(t) {
    return (0, r.request)({
        url: e.Apis.getSleepUrl,
        data: {
            ptype: 1,
            id: t
        }
    }).then(function(e) {
        return e;
    });
}, exports.getSleepTheme = function(t) {
    var i = t.topicId, u = t.page, n = t.pageSize;
    return (0, r.request)({
        url: e.Apis.getSleepThemes,
        data: {
            topicId: i,
            page: u,
            pageSize: n
        }
    }).then(function(e) {
        return e;
    });
}, exports.getSleepTrackInfo = function(t) {
    var i = t.topicId, u = t.trackId;
    return (0, r.request)({
        url: e.Apis.getSleepTrackInfo,
        data: {
            topicId: i,
            trackId: u
        }
    }).then(function(e) {
        return e;
    });
};

require("../utils/storage");

var e = require("./index"), r = require("./request");

require("@xmly/lite-login_wx/lib/index"), require("../utils/env"), require("../utils/logger");