var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createTrackComment = function(e) {
    return (0, n.request)({
        url: n.Apis.createComment,
        method: "POST",
        data: r({}, e)
    }).then(function(e) {
        var t = e.msg, a = e.ret, n = e.extension, i = void 0 === n ? {} : n;
        return wx.showToast({
            icon: "none",
            title: t
        }), 200 === a ? Promise.resolve(r({}, i)) : Promise.reject(r({}, i));
    });
}, exports.dislikeComment = function(e, r) {
    return (0, n.request)({
        url: n.Apis.dislikeComment,
        method: "POST",
        data: {
            trackId: e,
            commentId: r
        }
    });
}, exports.dislikeTrack = function(e) {
    return (0, n.request)({
        url: n.Apis.dislikeTrack,
        method: "POST",
        data: {
            trackId: e
        }
    });
}, exports.getCommentList = function(e) {
    var r = e.trackId, t = e.page, a = e.pageSize, o = void 0 === a ? 20 : a;
    return (0, n.request)({
        url: n.Apis.queryTrackCommentsByPage,
        data: {
            trackId: r,
            page: t,
            pageSize: o,
            order: 1
        }
    }).then(function(e) {
        var r = e.data;
        return {
            totalCount: r.totalCount,
            pageSize: r.pageSize,
            commentList: r.comments.map(i.parseComment)
        };
    });
}, exports.getReplyList = function(e) {
    var r = e.trackId, t = e.commentId, a = e.page, o = e.pageSize, u = void 0 === o ? 20 : o;
    return (0, n.request)({
        url: n.Apis.queryReplies,
        data: {
            trackId: r,
            commentId: t,
            page: a,
            pageSize: u,
            order: 0
        }
    }).then(function(e) {
        var r = e.data, t = r.comments, n = r.totalCount;
        return {
            replies: t.map(i.parseComment),
            end: n < u * a
        };
    });
}, exports.getTrackInfo = function(e) {
    var i = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    return (0, n.request)({
        url: n.Apis.queryMPTrackPage + e + (a.isWx && i ? "?isIncludeMeta=true" : "")
    }).then(function(i) {
        var o = i.data, u = void 0 === o ? {} : o, s = i.ret, c = i.msg;
        if (0 === s) {
            var d = u.trackDetailInfo, m = u.trackRichInfo, l = u.albumDetailInfo, p = u.albumPayType, f = u.isSubscribe, k = u.isFavourite, v = u.albumMetaValueInfos, h = void 0 === v ? [] : v, q = u.canPlayXimiTrack, T = m.richIntro, g = void 0 === T ? "" : T;
            return g.replace(/<(?!img)[^>]+>/g, "") || (g = ""), Promise.resolve({
                canPlayXimiTrack: q,
                trackInfo: r(r({}, (0, n._parseTrack)(d)), {}, {
                    isFavourite: k
                }),
                richIntro: g ? (0, t.default)((0, a.formatRichText)("<div>".concat(g, "</div>"))) : "",
                albumInfo: (0, n._parseAlbum)(r(r({}, l), {}, {
                    albumPayType: p
                })),
                isSubscribe: f,
                isFavourite: k,
                albumMetaValueInfos: h.map(function(e) {
                    return e && e.displayName;
                })
            });
        }
        return 403 === s ? void wx.redirectTo({
            url: "/pages/404/index?ptype=2&id=".concat(e)
        }) : Promise.reject(c);
    });
}, exports.isTrackLiked = function(e) {
    return (0, n.request)({
        url: n.Apis.isTrackFavourite + e
    }).then(function(e) {
        return e.data;
    });
}, exports.likeComment = function(e, r) {
    return (0, n.request)({
        url: n.Apis.likeComment,
        method: "POST",
        data: {
            trackId: e,
            commentId: r
        }
    });
}, exports.likeTrack = function(e) {
    return new Promise(function(r, t) {
        (0, n.request)({
            url: n.Apis.likeTrack,
            method: "POST",
            data: {
                trackId: e
            }
        }).then(function(e) {
            var a = e.ret, n = e.msg;
            return 200 === a ? r() : (wx.showToast({
                title: n,
                icon: "none"
            }), t());
        });
    });
}, exports.multiQueryRank = function(e) {
    return (0, n.request)({
        url: n.Apis.multiQueryRank,
        data: {
            categoryCodes: e,
            size: 3
        }
    }).then(function(e) {
        var r = e.ret, t = e.data, a = t.categoryCodes, i = t.rankLists;
        return 0 === r ? {
            categoryCodes: a,
            rankList: i.map(function(e) {
                return e.map(function(e) {
                    return (0, n._parseAlbum)(e);
                });
            })
        } : [];
    });
}, exports.queryAnchorName = function(e) {
    return (0, n.request)({
        url: n.Apis.queryAnchorBasic,
        data: {
            uid: e
        }
    }).then(function(e) {
        var r = e.data, t = (r = void 0 === r ? {} : r).nickName, n = void 0 === t ? "" : t, i = r.cover, u = r.anchorGrade, s = r.relation, c = (s = void 0 === s ? {} : s).isFollow, d = void 0 === c || c, m = r.personalSignature, l = r.fansCount;
        return {
            anchorName: n,
            anchorAvatar: (0, a.image2Url)(i),
            anchorGrade: u,
            isFollow: d,
            anchorIntro: m,
            fansCount: (0, o.default)(l)
        };
    });
}, exports.queryFeedRank = function() {
    return (0, n.request)({
        url: n.Apis.queryFeedRank
    }).then(function(e) {
        var r = e.ret, t = e.data;
        return 0 === r ? t : [];
    });
}, exports.queryRelativeTracks = function(e, r, t, a) {
    return (0, n.request)({
        url: n.Apis.queryRelativeTracks,
        data: {
            trackId: e,
            preOffset: r || 10,
            nextOffset: t || 10,
            order: !1 === a ? 1 : 0
        }
    }).then(function(e) {
        var r = e.ret, t = e.data;
        return 0 !== r ? [] : t.map(n._parseTrack);
    });
}, exports.queryTracks = function(e) {
    return (0, n.request)({
        url: n.Apis.queryTrackByIds,
        method: "post",
        data: {
            trackIds: e
        }
    }).then(function(e) {
        var r = e.ret, t = e.data;
        if (0 !== r) throw null;
        return t.map(n._parseTrack);
    });
};

var r = require("../../@babel/runtime/helpers/objectSpread2"), t = e(require("../../packages/parse-html/index")), a = require("../utils/index"), n = require("./index"), i = require("./parse"), o = e(require("../utils/humanizeCount"));