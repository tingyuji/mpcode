Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryCategory = function(u) {
    return (0, t.request)({
        url: t.Apis.queryCateInfo,
        data: u
    }).then(function(u) {
        var n = (u || {}).data;
        return e(n.map(function(e) {
            return "track" === e.type ? r(r({}, e), {}, {
                data: (0, t._parseTrack)(e.data)
            }) : "album" === e.type ? r(r({}, e), {}, {
                data: (0, t._parseAlbum)(e.data)
            }) : void 0;
        }));
    });
}, exports.queryPageInfo = function() {
    return (0, t.request)({
        url: t.Apis.queryPaidPageInfo
    }).then(function(e) {
        var n = (e || {}).data, a = [], o = {};
        return (void 0 === n ? [] : n).forEach(function(e) {
            var n = e.moduleType, i = e.moduleInfo;
            if ("tomato" === n) {
                var s = i.map(function(e) {
                    return r(r({}, e), {}, {
                        icon: (0, u.image2Url)(e.icon)
                    });
                });
                o = r(r({}, e), {}, {
                    moduleInfo: s
                });
            }
            "rank" !== n && "guessYouLike" !== n || (o = r(r({}, e), {}, {
                moduleInfo: e.moduleInfo.map(function(e) {
                    return (0, t._parseAlbum)(e);
                })
            })), "star" !== n && "feed" !== n || (o = r({}, e)), a.push(r({}, o));
        }), a;
    });
}, exports.queryPoints = function() {
    return (0, t.request)({
        url: t.Apis.queryUserPoint
    }).then(function(e) {
        return e.data || {};
    });
};

var e = require("../../@babel/runtime/helpers/toConsumableArray"), r = require("../../@babel/runtime/helpers/objectSpread2"), t = require("./index"), u = (require("../../common/utils/index"), 
require("../utils/index"));