Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryFlushUpdate = function() {
    return (0, r.request)({
        url: r.Apis.queryFlushUpdate
    }).then(function(r) {
        var a = r.data;
        return 200 !== r.ret ? {
            albumList: []
        } : e(e({}, a), {}, {
            albumList: a.albumList.map(function(r) {
                return e(e({}, r), {}, {
                    albumCoverPath: (0, t.image2Url)(r.albumCoverPath)
                });
            })
        });
    });
}, exports.queryHotSale = function() {
    return (0, r.request)({
        url: r.Apis.queryHotSale
    }).then(function(r) {
        return r.data && r.data.length ? r.data.map(function(r) {
            return e(e({}, r), {}, {
                albums: r.albums.map(function(r) {
                    return e(e({}, r), {}, {
                        albumCoverPath: (0, t.image2Url)(r.albumCoverPath)
                    });
                })
            });
        }) : [];
    });
}, exports.queryValiditySaleList = function(a) {
    var u = a.pageNum, n = a.pageSize;
    return (0, r.request)({
        url: r.Apis.queryValiditySaleList,
        data: {
            pageNum: u,
            pageSize: n || 10
        }
    }).then(function(r) {
        var a = r.data;
        return 200 !== r.ret ? {
            albums: []
        } : e(e({}, a), {}, {
            albums: a.albums.map(function(r) {
                return e(e({}, r), {}, {
                    albumCoverPath: (0, t.image2Url)(r.albumCoverPath)
                });
            })
        });
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = require("../utils/index");