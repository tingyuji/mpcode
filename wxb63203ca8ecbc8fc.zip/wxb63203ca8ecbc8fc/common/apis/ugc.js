Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getUgcComments = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, e.request)({
        url: e.Apis.queryUgcComments,
        data: r
    }).then(function(e) {
        var r = e.ret, a = e.data, n = void 0 === a ? {} : a;
        if (0 === r) return {
            totalCount: n.totalCount,
            pageSize: n.pageSize,
            commentList: n.comments.map(t.parseComment)
        };
    });
}, exports.getUgcList = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, e.request)({
        url: "".concat(e.Apis.queryUGC, "/").concat(r.ugcId),
        data: {
            pageNo: r.pageNo,
            pageSize: r.pageSize || 20
        }
    }).then(function(e) {
        var r = e.data, a = void 0 === r ? {} : r;
        if (0 === e.ret) {
            var n = a.albumList, o = void 0 === n ? [] : n, u = a.trackList, i = void 0 === u ? [] : u, s = o.map(function(e) {
                return (0, t._parseAlbum)(e);
            }), c = i.map(function(e) {
                return (0, t._parseTrack)(e);
            });
            return {
                ugcInfo: (0, t.parseUgcInfo)(a),
                albums: s,
                tracks: c
            };
        }
    });
};

var e = require("./index"), t = require("./parse");