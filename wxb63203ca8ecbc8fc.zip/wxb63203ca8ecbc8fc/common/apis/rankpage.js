var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getRankList = function(e) {
    return (0, t.request)({
        url: t.Apis.newQueryRankList,
        data: e
    }).then(function(e) {
        return e.data || {};
    });
}, exports.getRankType = function() {
    return (0, t.request)({
        url: t.Apis.newRankType
    }).then(function(e) {
        return e.data || {};
    });
}, exports.parseRankList = void 0;

var t = require("./index"), r = require("../utils/image"), n = e(require("../utils/humanizeCount"));

exports.parseRankList = function(e) {
    return {
        id: e.id,
        title: e.albumTitle,
        subtitle: e.lastUpdateTrack,
        cover: (0, r.image2Url)(e.cover),
        anchorName: e.anchorName,
        isFollow: e.isFollow,
        grade: e.grade,
        description: e.personalDescription,
        position: e.rankingPositionChange,
        score: Math.floor(Number(e.rankingScore)),
        isPaid: e.isPaid,
        vipType: e.vipType,
        playCount: (0, n.default)(e.playCount),
        salePoint: e.salePoint,
        trackCount: (0, n.default)(e.trackCount),
        fansCount: (0, n.default)(e.fansCount)
    };
};