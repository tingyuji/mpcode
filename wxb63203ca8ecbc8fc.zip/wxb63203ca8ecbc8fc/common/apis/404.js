var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryRecommend = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.queryBdspRecommend,
        data: e
    }).then(function(e) {
        if (200 !== e.ret) return {
            list: [],
            categoryCode: ""
        };
        var r = e.data, a = r.albums, u = void 0 === a ? [] : a, n = r.categoryCode;
        return {
            list: u.slice(0, 10).map(function(e) {
                return {
                    id: e.albumId,
                    coverPath: (0, t.image2Url)(e.albumCoverPath),
                    title: e.albumTitle,
                    intro: e.intro,
                    nickname: e.albumUserNickName,
                    trackCount: e.albumTrackCount,
                    playCount: (0, i.default)(e.albumPlayCount),
                    isPaid: e.isPaid,
                    vipType: e.vipType,
                    tag: e.isPaid ? 0 != e.vipType ? 2 : 1 : -1
                };
            }),
            categoryCode: n
        };
    });
};

var r = require("./index"), t = require("../utils/index"), i = e(require("../utils/humanizeCount"));