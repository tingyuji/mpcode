Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryTracks = function(e) {
    return (0, r.request)({
        url: r.Apis.queryUnlockTracks,
        data: e
    }).then(function(r) {
        var e = r.data || {};
        return {
            hasMore: e.hasMore,
            page: e.page,
            trackInfos: e.trackInfos
        };
    });
}, exports.queryUnlock = function(e) {
    return (0, r.request)({
        url: r.Apis.queryUnlockHistory,
        data: e
    }).then(function(e) {
        return {
            unlockInfos: (e.data || {}).unlockInfos.map(function(e) {
                return {
                    albumInfo: (0, r._parseAlbum)(e.albumInfo),
                    trackInfos: e.trackInfos,
                    hasMore: e.hasMore
                };
            })
        };
    });
};

var r = require("./index");