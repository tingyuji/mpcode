Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.decryptDataAndLogin = function(e) {
    return (0, n.request)({
        url: t.Apis.decryptAndLogin,
        data: e,
        method: "POST"
    });
}, exports.getBaseAccessByCode = function(e) {
    return (0, n.request)({
        url: t.Apis.getBaseAccessByCode,
        data: e,
        method: "POST"
    }).then(function(e) {
        return e;
    });
}, exports.getNonce = function() {
    return (0, n.request)({
        url: t.Apis.getNonce
    }).then(function(e) {
        var t = e.ret, n = e.nonce;
        return 0 === t ? n : "";
    });
}, exports.getOpenId = function(e) {
    return (0, n.request)({
        url: t.Apis.getOpenId,
        data: e
    }).then(function(e) {
        var t = e.data, n = t.openid, r = t.anonymous_openid, o = n || r;
        return o && getOpenid(o);
    });
}, exports.getUserInfo = u;

var e = require("../utils/storage"), t = require("./index"), n = require("./request"), r = require("@xmly/lite-login_wx/lib/index"), o = require("../utils/env"), i = require("../utils/logger");

function u() {
    return (0, n.request)({
        url: t.Apis.getUserInfo
    }).then(function(t) {
        var n = t.data, r = "";
        n && (r = n.uid);
        r && (0, e.getUid)(r), !r && (0, e.removeUid)();
    });
}

(0, r.onSuccess)(function(e) {
    var t = getCurrentPages();
    "pages/setting/setting" === (t && t.length && t[t.length - 2] && t[t.length - 2].route) ? wx.navigateBack({
        delta: 2
    }) : wx.navigateBack(), u(), setTimeout(function() {
        var e = getCurrentPages().pop();
        !function(e) {
            if ("/pages/webview/index" === e.path) {
                var t = o.isDevelopment ? "4&_token" : "1&_token", n = r.cookies.get(t), i = e.url.includes("?") ? "&" : "?";
                e.url += "".concat(i, "token=").concat(encodeURIComponent(n.value));
            }
        }(e);
        var t = e.options, n = void 0 === t ? {} : t;
        e.initLoad ? e.initLoad(n) : e.onLoad(n);
    }, 500), (0, i.genLogger)(31512, "click", {
        currPage: "login",
        itemType: e ? e.loginType : ""
    });
});