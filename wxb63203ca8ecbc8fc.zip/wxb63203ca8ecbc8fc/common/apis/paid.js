Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.genOrderSign = function(e) {
    return (0, r.request)({
        url: r.Apis.genOrderSign,
        data: e,
        method: "POST"
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.genProductItemId = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.genProductItemId,
        data: e
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.getCurrentUser = function() {
    return (0, r.request)({
        url: r.Apis.getCurrentUser
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || {};
    });
}, exports.getVipSubscribeStatus = function(e) {
    return (0, r.request)({
        url: r.Apis.querySignStatus,
        data: {
            userId: e
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || {};
    });
}, exports.isAlbumSupportRefund = function(e) {
    return (0, r.request)({
        url: r.Apis.isAlbumSupportRefund + e
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.placeorderandmakepayment = function(e) {
    return (0, r.request)({
        url: r.Apis.placeorderandmakepayment,
        data: e,
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.prepareBatchAlbumVo = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.prepareBatchAlbumVo,
        data: e
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.prepareorderInfo = function() {
    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.prepareorderInfo,
        data: n,
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        }
    }).then(function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = r.orderContext, u = (n = void 0 === n ? {} : n).orderItems, o = void 0 === u ? [] : u, i = r.orderContext, a = o.map(function(r) {
            return e(e({}, r), {}, {
                coverUrl: (0, t.image2Url)(r.coverUrl)
            });
        }), s = e(e({}, i), {}, {
            orderItems: a
        });
        return e(e({}, r), {}, {
            orderContext: s
        });
    });
}, exports.queryProductMulti = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, r.request)({
        url: r.Apis.queryProductMulti,
        data: e
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.querySingleAlbumLastNotBuy = function(e) {
    return (0, r.request)({
        url: r.Apis.querySingleAlbumLastNotBuy + e
    }).then(function(e) {
        var r = (e || {}).data, t = (void 0 === r ? {} : r).singleBuyPriceInfo;
        return {
            singleBuyPriceInfo: void 0 === t ? {} : t
        };
    });
}, exports.queryTrackPayList = function(e) {
    return (0, r.request)({
        url: r.Apis.queryTrackPayList,
        data: {
            trackId: e
        }
    }).then(function(e) {
        var r = e.data, t = (e.ret, r.vo);
        return {
            vo: void 0 === t ? {} : t
        };
    });
}, exports.queryVipBasicInfo = function() {
    return (0, r.request)({
        url: r.Apis.queryVipBasicInfo
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.queryVipBuyList = function() {
    return (0, r.request)({
        url: r.Apis.queryVipBuyList
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.subscriptionSign = function(e) {
    return (0, r.request)({
        url: r.Apis.signVipsubscription,
        data: e,
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (0 === e.ret) return e.data;
        wx.showToast({
            title: e.msg,
            icon: "none"
        });
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), t = (require("../../common/utils/index"), 
require("../utils/index"));