var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryChannelInfo = exports.queryChannelAlbumsByMeta = void 0;

var t = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), a = require("./parse"), n = e(require("../utils/humanizeCount")), u = function(e) {
    return {
        type: "album",
        data: t({}, (0, a.parseAlbum)(e))
    };
};

exports.queryChannelInfo = function(e) {
    return (0, r.request)({
        url: r.Apis.getChannelInfo,
        data: {
            channelRelationMetadataId: e
        }
    }).then(function(e) {
        var r, a = e.data || {}, u = a.metadata, o = void 0 === u ? [] : u, i = a.topInfo;
        return {
            metadata: o,
            info: (r = void 0 === i ? {} : i, t(t({}, r), {}, {
                newCount: (0, n.default)(r.newCount),
                trackCount: (0, n.default)(r.trackCount)
            }))
        };
    });
};

exports.queryChannelAlbumsByMeta = function(e) {
    return (0, r.request)({
        url: r.Apis.getChannelAlbumsByMetas,
        data: e
    }).then(function(e) {
        var r = (e || {}).data, a = void 0 === r ? {} : r, n = a.albums, o = void 0 === n ? [] : n;
        return t(t({}, a), {}, {
            albums: o.map(u)
        });
    });
};