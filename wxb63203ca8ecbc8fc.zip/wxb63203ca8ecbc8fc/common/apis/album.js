Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addAlbumPushCount = function() {
    return (0, r.request)({
        url: r.Apis.addPushAlbum,
        data: {
            openId: (0, o.getWXAccessOpenId)()
        },
        method: "POST"
    }).then(function(e) {
        var r = e.ret, n = e.extension;
        if (200 === r) return Promise.resolve(t({}, n));
    });
}, exports.allocateCoupon = function(e) {
    return (0, r.request)({
        url: r.Apis.allocateAlbumCoupons,
        method: "POST",
        data: {
            domain: 1,
            couponId: e,
            comment: "微信小程序训练营领券"
        },
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.code, r = e.message;
        return 200 !== t && wx.showToast({
            icon: "none",
            title: r
        }), e;
    });
}, exports.getAlbumActivityInfo = function(n) {
    return (0, r.request)({
        url: "".concat(r.Apis.queryAlbumActivityInfo, "/").concat(n)
    }).then(function(r) {
        var n = (r || {}).data, o = void 0 === n ? {} : n, u = o.albumCouponInfo, a = (u = void 0 === u ? {} : u).albumId, i = u.style, l = u.shareCouponInfos, d = void 0 === l ? [] : l, m = o.albumShareActivityInfo, p = void 0 === m ? {} : m, b = e(o, s);
        return t({
            couponInfo: {
                list: d.map(c),
                style: i,
                albumId: a
            },
            shareActivityInfo: p,
            albumId: a
        }, b);
    });
}, exports.getAlbumInfo = function(e) {
    return (0, r.request)({
        url: r.Apis.queryMPAlbumPage + e + (u.isWx ? "?isIncludeMeta=true" : "")
    }).then(function(t) {
        var o = t.data, u = void 0 === o ? {} : o, a = t.ret, i = t.msg;
        if (0 === a) {
            var s = u.albumDetailInfo, c = u.isSubscribe, l = u.albumRichInfo.richIntro, d = void 0 === l ? "" : l, m = u.userPermission, p = u.albumMetaValueInfos, b = void 0 === p ? [] : p, f = u.albumXimiVipPayType, v = u.albumType, I = d;
            return 1 === (0, r._parseAlbum)(s).albumPayType && (0, n.isIos)() && (I = (0, n.filterPaidRichIntro)(I)), 
            Promise.resolve({
                albumInfo: (0, r._parseAlbum)(s),
                isSubscribe: c,
                richIntro: (0, n.mpParse)((0, n.formatRichText)(I.replace(/\+/g, " "))),
                userPermission: m,
                albumXimiVipPayType: f,
                albumMetaValueInfos: b.map(function(e) {
                    return e && e.displayName;
                }),
                albumType: v
            });
        }
        return 403 === a ? void wx.redirectTo({
            url: "/pages/404/index?ptype=1&id=".concat(e)
        }) : Promise.reject(i);
    });
}, exports.getCampExtraInfo = function(e) {
    return (0, r.request)({
        url: r.Apis.queryCampInfo + "/".concat(Date.now()),
        data: {
            albumId: e,
            v: Date.now()
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.data || {};
    });
}, exports.getGroupCode = function(e) {
    return (0, r.request)({
        url: r.Apis.queryGroupCode,
        data: {
            itemId: e
        }
    }).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.getTrackList = function(e) {
    var n = e.albumId, o = e.page, u = e.pageSize, a = void 0 === u ? 20 : u, i = e.asc, s = void 0 === i || i;
    return (0, r.request)({
        url: r.Apis.queryAlbumTrackRecordsByPage,
        data: {
            albumId: n,
            page: o,
            pageSize: a,
            asc: s,
            countKeys: "play,comment,share,favorite"
        }
    }).then(function(e) {
        var n = e.data, o = n.totalCount, u = n.page, i = n.trackDetailInfos.map(function(e, n) {
            return t(t({}, (0, r._parseTrack)(e)), {}, {
                key: s ? (u - 1) * a + n + 1 : o - (u - 1) * a - n
            });
        }), c = Math.ceil(o / a);
        return {
            trackList: i,
            totalCount: o,
            totalPage: c
        };
    });
}, exports.parseCouponInfo = c, exports.queryAlbumCommentList = function(e) {
    var o = e.albumId, u = e.pageId;
    return (0, r.request)({
        url: r.Apis.queryAlbumCommentList,
        data: {
            albumId: o,
            pageId: u,
            pageSize: 10,
            order: "content-score-desc"
        }
    }).then(function(e) {
        var r = e.data, o = void 0 === r ? {} : r;
        return {
            comments: t({
                list: o.comments.list.map(function(e) {
                    return e.createdAt = (0, a.timestampToTime)(e.createdAt), e.content = (0, n.mpParse)((0, 
                    i.commentFaceBack)(e.content)), e;
                })
            }, o.comments)
        };
    });
}, exports.queryAlbumRankTag = function(e) {
    var t = e.albumId;
    return (0, r.request)({
        url: r.Apis.queryAlbumRankTag,
        data: {
            albumId: t
        }
    }).then(function(e) {
        var t = e.data;
        return (void 0 === t ? {} : t).rankTag || {};
    });
}, exports.queryAlbumStar = function(e) {
    var n = e.albumId;
    return (0, r.request)({
        url: r.Apis.queryAlbumStar + n
    }).then(function(e) {
        var r = e.data;
        return t({}, void 0 === r ? {} : r);
    });
}, exports.queryAnchorName = function(e) {
    return (0, r.request)({
        url: r.Apis.queryAnchorBasic,
        data: {
            uid: e
        }
    }).then(function(e) {
        var t = e.data, r = (t = void 0 === t ? {} : t).nickName, n = void 0 === r ? "" : r, o = t.cover, a = void 0 === o ? "" : o, i = t.anchorGrade, s = void 0 === i ? "" : i, c = t.fansCount, l = void 0 === c ? 0 : c, d = t.relation, m = (d = void 0 === d ? {
            isFollow: !1
        } : d).isFollow, p = void 0 !== m && m;
        return {
            anchorName: n,
            anchorAvatar: (0, u.image2Url)(a),
            anchorGrade: s,
            fansCount: l,
            isFollow: p
        };
    });
}, exports.queryRelateRecommendAlbums = function(e) {
    return (0, r.request)({
        url: r.Apis.queryRelateRecommendAlbums,
        data: t(t({}, e), {}, {
            queryType: 1
        })
    }).then(function(e) {
        var n = e.data, o = void 0 === n ? {} : n, u = o.hotWordAlbums, a = void 0 === u ? [] : u;
        return t(t({}, o), {}, {
            albumInfo: a.map(r._parseAlbum)
        });
    });
}, exports.subscribeAlbum = function(e) {
    return new Promise(function(t, n) {
        (0, r.request)({
            url: r.Apis.subscribeAlbum,
            method: "POST",
            data: {
                actionId: e,
                touserOpenId: (0, o.getWXAccessOpenId)()
            }
        }).then(function(e) {
            var r = e.ret, o = e.msg;
            200 === r ? t() : (wx.showToast({
                title: o,
                icon: "none"
            }), n());
        });
    });
}, exports.switchPushAlbum = function(e) {
    return (0, r.request)({
        url: r.Apis.pushSubAlbum,
        data: t(t({}, e), {}, {
            openId: (0, o.getWXAccessOpenId)()
        }),
        method: "POST"
    }).then(function(e) {
        console.log(e);
    });
}, exports.unsubscribeAlbum = function(e) {
    return (0, r.request)({
        url: r.Apis.unsubscribeAlbum,
        method: "POST",
        data: {
            actionId: e,
            touserOpenId: (0, o.getWXAccessOpenId)()
        }
    });
};

var e = require("../../@babel/runtime/helpers/objectWithoutProperties"), t = require("../../@babel/runtime/helpers/objectSpread2"), r = require("./index"), n = require("../../common/utils/index"), o = require("../../common/utils/wxCookie"), u = require("../utils/index"), a = require("../utils/time"), i = require("../utils/face.lib"), s = [ "albumCouponInfo", "albumShareActivityInfo" ];

function c(e) {
    var t = e.couponItem || {};
    return {
        id: t.couponId,
        couponId: t.couponId,
        isReceived: e.isReceived,
        activityId: t.activityId,
        couponType: t.couponType,
        url: e.receiveCouponUrl,
        name: t.name,
        discountType: t.discountType,
        couponValue: t.couponValue,
        plusRate: t.plusRate,
        usingCouponPrice: e.usingCouponPrice,
        isCanUse: e.isCanUse,
        usingDateToastMsg: e.usingDateToastMsg,
        discountRate: t.discountRate,
        supportItemIds: e.itemIds || []
    };
}