var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.cancelFollow = function(e) {
    return (0, a.request)({
        url: a.Apis.unfollowUser,
        data: e,
        method: "POST"
    });
}, exports.queryAnchorAlbums = function(e) {
    var o = e.page, n = void 0 === o ? 1 : o, p = e.pageSize, s = void 0 === p ? 20 : p, l = t(e, i);
    return (0, a.request)({
        url: a.Apis.queryPubAlbums,
        data: r(r({
            page: n,
            pageSize: s
        }, l), {}, {
            asc: !1
        })
    }).then(function(e) {
        var t = e.data || {}, o = t.page, i = void 0 === o ? 1 : o, n = t.pageSize, p = void 0 === n ? 20 : n, s = t.totalCount, l = void 0 === s ? 0 : s, d = t.albumBriefDetailInfos;
        return {
            page: i,
            pageSize: p,
            total: l,
            albums: (void 0 === d ? [] : d).map(function(e) {
                return r(r(r({}, (0, a._parseAlbum)(e.albumInfo)), e.statCountInfo), {}, {
                    playCount: (0, u.default)(e.statCountInfo.playCount)
                });
            })
        };
    });
}, exports.queryAnchorInfo = function(e) {
    return (0, a.request)({
        url: a.Apis.queryAnchorBasic,
        data: e
    }).then(function(e) {
        var t = e.data;
        return r(r({}, t), {}, {
            fansCount: (0, u.default)(t && t.fansCount || 0),
            cover: (0, o.image2Url)(t && t.cover || "")
        });
    });
}, exports.queryAnchorListenList = function(e) {
    var u = e.page, o = void 0 === u ? 1 : u, i = e.pageSize, n = void 0 === i ? 20 : i, s = t(e, p);
    return (0, a.request)({
        url: a.Apis.queryPubListenList + s.uid,
        data: r(r({
            pageId: o,
            pageSize: n
        }, s), {}, {
            uid: s.uid
        }),
        method: "POST"
    }).then(function(e) {
        var t = e.albumList || {}, r = t.pageId, a = void 0 === r ? 1 : r, u = t.pageSize, o = void 0 === u ? 20 : u, i = t.totalCount, n = void 0 === i ? 0 : i, p = t.list;
        return {
            page: a,
            pageSize: o,
            total: n,
            list: void 0 === p ? [] : p
        };
    });
}, exports.queryAnchorTracks = function(e) {
    var o = e.page, i = void 0 === o ? 1 : o, p = e.pageSize, s = void 0 === p ? 20 : p, l = t(e, n);
    return (0, a.request)({
        url: a.Apis.queryPubTracks,
        data: r(r({
            page: i,
            pageSize: s
        }, l), {}, {
            asc: !1
        })
    }).then(function(e) {
        var t = e.data || {}, o = t.page, i = void 0 === o ? 1 : o, n = t.pageSize, p = void 0 === n ? 20 : n, s = t.totalCount, l = void 0 === s ? 0 : s, d = t.trackDetailInfos;
        return {
            page: i,
            pageSize: p,
            total: l,
            tracks: (void 0 === d ? [] : d).map(function(e) {
                return r(r({}, (0, a._parseTrack)(e.trackInfo)), {}, {
                    playCount: (0, u.default)(e.statCountInfo.playCount || 0)
                });
            })
        };
    });
}, exports.setFollow = function(e) {
    return (0, a.request)({
        url: a.Apis.followUser,
        data: e,
        method: "POST"
    });
};

var t = require("../../@babel/runtime/helpers/objectWithoutProperties"), r = require("../../@babel/runtime/helpers/objectSpread2"), a = require("./index"), u = e(require("../utils/humanizeCount")), o = require("../utils/index"), i = [ "page", "pageSize" ], n = [ "page", "pageSize" ], p = [ "page", "pageSize" ];