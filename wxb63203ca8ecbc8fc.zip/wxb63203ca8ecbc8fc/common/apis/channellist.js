var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queyrAllChannelGroups = exports.queryHotChannels = exports.queryChannelsByGroupId = void 0;

var r = require("../../@babel/runtime/helpers/objectSpread2"), n = require("./index"), t = e(require("../utils/humanizeCount")), u = function(e) {
    return r(r({}, e), {}, {
        newCount: (0, t.default)(e.newCount),
        trackCount: (0, t.default)(e.trackCount)
    });
};

exports.queyrAllChannelGroups = function() {
    return (0, n.request)({
        url: n.Apis.queryAllChannelGroup
    }).then(function(e) {
        var r = e.ret, n = e.data;
        if (200 !== r) return [];
        var t = (n || {}).groups;
        return void 0 === t ? [] : t;
    });
};

exports.queryChannelsByGroupId = function(e) {
    return (0, n.request)({
        url: n.Apis.getChannelsByGroupId,
        data: {
            groupId: e
        }
    }).then(function(e) {
        var r = e.ret, n = e.data;
        if (200 !== r) return [];
        var t = (n || {}).channels;
        return (void 0 === t ? [] : t).map(u);
    });
};

exports.queryHotChannels = function() {
    return (0, n.request)({
        url: n.Apis.getHotChannels
    }).then(function(e) {
        var r = e.data, n = (r = void 0 === r ? {} : r).hotChannels;
        return void 0 === n ? [] : n;
    });
};