Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryGuide = void 0;

var e = require("./index");

exports.queryGuide = function() {
    return (0, e.request)({
        url: e.Apis.queryErrorGuideSetting
    }).then(function(e) {
        return e.data[0] || {};
    });
};