Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = function(e) {
    var t = 1e8, r = 1e4, o = 1e3;
    try {
        e = Number(e);
    } catch (e) {
        return "0";
    }
    if (!Number.isInteger(e)) return "0";
    var a, c = e < 0 ? "-" : "", n = Math.abs(e);
    return a = n >= t ? "".concat((n / t).toFixed(2), "亿") : n >= r ? "".concat(Math.floor(n / o) / 10, "万") : n, 
    "".concat(c).concat(a);
};