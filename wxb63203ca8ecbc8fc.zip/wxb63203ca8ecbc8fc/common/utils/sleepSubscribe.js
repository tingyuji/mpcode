Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addSubCount = function() {
    e(function(t) {
        "accept" === t && addAlbumPushCount().then(function(t) {
            t && t.today_count < 10 && (console.log("订阅数+1"), wxSubscribeAlbum());
        });
    });
}, exports.getNetworkType = function() {
    return new Promise(function(t) {
        wx.canIUse("getNetworkType") ? wx.getNetworkType({
            success: function(e) {
                t(e.networkType);
            },
            fail: function(e) {
                t();
            }
        }) : t({
            networkType: "wifi"
        });
    });
}, exports.queryWxSubStatus = e, exports.wxSubscribeReminder = function(e) {
    wx.requestSubscribeMessage({
        tmplIds: [ t ],
        success: function(n) {
            var s = n.errMsg, i = n[t];
            console.log("errMsg:", s), console.log("tempIdRet:", i), "function" == typeof e && e(i);
        },
        fail: function() {},
        complete: function() {}
    });
};

var t = "AVqhVtd6xjz_9CHWUw764QYjbsulCh40EzU9QxcBhds";

function e(e) {
    var n = !0, s = !1;
    wx.getSetting({
        withSubscriptions: !0,
        success: function(i) {
            if (i && i.subscriptionsSetting && i.subscriptionsSetting.mainSwitch ? i.subscriptionsSetting.itemSettings && (n = !1, 
            "accept" === i.subscriptionsSetting.itemSettings[t] && (s = !0), i.subscriptionsSetting.itemSettings[t]) : n = !1, 
            "function" == typeof e) {
                var o = "";
                !n && s && (o = "accept"), n && !s && (o = "query"), n || s || (o = "reject"), e(o);
            }
        }
    });
}