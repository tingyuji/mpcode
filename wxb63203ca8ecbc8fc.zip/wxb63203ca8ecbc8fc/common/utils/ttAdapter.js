Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAudioDuration = function(t) {
    return t.audioAttr && t.audioAttr.duration / 1e3 || t.duration;
};