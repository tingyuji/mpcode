var t;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.changeNavBarStyle = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "day";
    "night" === t ? wx.setNavigationBarColor && wx.setNavigationBarColor({
        frontColor: "#ffffff",
        backgroundColor: "#7d7c79"
    }) : wx.setNavigationBarColor && wx.setNavigationBarColor({
        frontColor: "#000000",
        backgroundColor: "#fff"
    });
}, exports.getMenuButtonHeight = function() {
    e || (e = wx.getMenuButtonBoundingClientRect());
    return e.height || 28;
}, exports.getMenuButtonTop = function() {
    e || (e = wx.getMenuButtonBoundingClientRect());
    return e.top || 23;
}, exports.getNavStatusBarHeight = function() {
    var t = n() ? 0 : o();
    return {
        statusBarHeight: t,
        navBarHeight: t + 44
    };
}, exports.getSafeHeight = function() {
    var e = t, r = e.safeArea, n = e.screenHeight, o = n;
    r && (o = r && r.height || n);
    return o;
}, exports.getSafeTopHeight = function() {
    var e = 0;
    try {
        var r = t = wx.getSystemInfoSync(), n = r.safeArea, o = r.statusBarHeight;
        if (n && (e = n && n.top || 0), e > 0 && o > 0) return 0;
        if (0 === e && o > 0) return o;
    } catch (t) {
        e = 0;
    }
    return e;
}, exports.getScreenHeight = function() {
    return (t || {}).screenHeight;
}, exports.getStatusBarHeight = o, exports.getTabBarHeight = function() {
    var e = t || {}, r = e.screenHeight, n = e.windowHeight, o = e.statusBarHeight, i = e.pixelRatio;
    return (r - n - o) * i;
}, exports.getWindowHeight = function() {
    return (t || {}).windowHeight;
}, exports.isAndroid = function() {
    t || (t = wx.getSystemInfoSync());
    return "android" === t.platform;
}, exports.isHomePage = function() {
    var t = getCurrentPages(), e = Math.max(t.length - 1, 0);
    return t[e].route.includes("index/index");
}, exports.isIos = function() {
    t || (t = wx.getSystemInfoSync());
    return "ios" === t.platform;
}, exports.isLiuHaiScreen = function() {
    return (n() ? 0 : o()) > 20;
}, exports.isLowerDevice = function(e) {
    t || (t = wx.getSystemInfoSync());
    return i(t.version, e) <= 0;
}, exports.isLowerSDK = function(e) {
    t || (t = wx.getSystemInfoSync());
    return i(t.SDKVersion, e) <= 0;
}, exports.isOldVersion = n, exports.isTabBarPage = function(t) {
    var e = getCurrentPages(), r = Math.max(e.length - 1, 0), n = e[r].route, o = t || n;
    return [ "mine/mine", "index/index", "paid/paid", "category/category" ].some(function(t) {
        return o.includes(t);
    });
}, require("../../@babel/runtime/helpers/Arrayincludes");

var e, r = 0;

function n() {
    var e = t, r = e.platform, n = e.SDKVersion;
    return "android" === r && n < "1.4.0";
}

function o() {
    if (r) return r;
    try {
        var e = t = wx.getSystemInfoSync(), n = e.safeArea, o = e.statusBarHeight;
        if (n) r = n && n.top || o; else {
            var i = wx.getMenuButtonLayout().top;
            r = (void 0 === i ? 50 : i) - 6;
        }
    } catch (t) {
        r = 44;
    }
    return r;
}

function i(t, e) {
    var r = t.split("."), n = e.split("."), o = r[0] - n[0];
    return 0 == o && t != e ? i(r.splice(1).join("."), n.splice(1).join(".")) : o;
}