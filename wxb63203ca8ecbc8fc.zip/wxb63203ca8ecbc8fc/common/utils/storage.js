Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setListenedAlbums = exports.set = exports.removeUid = exports.removeSortAlbum = exports.isSameUser = exports.isLogin = exports.isInSortAlbum = exports.getUid = exports.getTodayFirstMineAd = exports.getTodayAdClosed = exports.getOpenid = exports.getNextTrackTip = exports.getListenedAlbums = exports.getFirstTrackOps = exports.getFavoriteTip = exports.get = exports.checkLogin = exports.addSortAlbum = void 0;

var e = function(e, t) {
    return t = "string" == typeof t ? t : JSON.stringify(t), wx.setStorageSync(e, t);
};

exports.set = e;

var t = function(e) {
    var t = wx.getStorageSync(e);
    try {
        return JSON.parse(t);
    } catch (e) {
        return t;
    }
};

exports.get = t;

var r = "uid", o = "openid", n = "FIRST_TRACK_TIP", s = "FIRST_FAVORITE_TIP", i = "FIRST_MINE_AD", u = "LISTENED_ALBUM_LIST", p = "ALBUM_SORT_LIST", x = "CLOSE_AD_WIDGET", c = "FIRST_TRACK_OPS", g = new Date().toLocaleDateString(), a = function(o) {
    return o ? (e(r, o), o) : t(r);
};

exports.getUid = a;

exports.removeUid = function() {
    e(r, "");
};

exports.getOpenid = function(r) {
    return r ? (e(o, r), r) : t(o);
};

function d(r) {
    return t(r) === g || (e(r, g), !1);
}

function T(e) {
    return t(e) === g;
}

exports.isSameUser = function(e) {
    return a() + "" == e + "";
};

exports.getNextTrackTip = function() {
    return d(n);
};

exports.getFavoriteTip = function() {
    return d(s);
};

exports.getTodayFirstMineAd = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return e ? d(i) : T(i);
};

exports.setListenedAlbums = function(t) {
    e(u, t);
};

exports.getListenedAlbums = function() {
    return t(u);
};

exports.addSortAlbum = function(r) {
    var o = t(p) || [];
    o.length >= 10 || (o.push(r), e(p, o));
};

exports.removeSortAlbum = function(r) {
    var o = t(p) || [], n = o.indexOf(r);
    n < 0 || (o.splice(n, 1), e(p, o));
};

exports.isInSortAlbum = function(e) {
    return t(p).indexOf(e) > -1;
};

var f = function() {
    return !!a();
};

exports.isLogin = f;

exports.checkLogin = function() {
    return !!f() || (wx.navigateTo({
        url: "/pages/login/login"
    }), !1);
};

exports.getTodayAdClosed = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return e ? d(x) : T(x);
};

exports.getFirstTrackOps = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return r ? e(c, !0) : t(c);
};