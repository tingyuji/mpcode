Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.defaultUserImg = exports.defaultAlbumImg = void 0, exports.fillImageUrl = function(t) {
    return s + t;
}, exports.getOriginImgUrl = m, exports.image2Url = function(e) {
    var l = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        op_type: 5,
        quality: 7,
        name: "mobile_large",
        upload_type: "album"
    }, u = l.op_type, n = void 0 === u ? 5 : u, c = l.name, d = void 0 === c ? "mobile_large" : c, g = l.upload_type, v = void 0 === g ? "album" : g, y = l.quality, h = void 0 === y ? 7 : y, f = t(l, p);
    if (!e) return i;
    var x = e;
    if (/^^\/\/s1.xmcdn.com/.test(x)) return "https:" + x;
    if (!/imagev2/.test(x) && /^http:\/\//.test(x)) return x;
    /^http:\/\//.test(x) && x.replace("http:", "https:");
    /^\/\//.test(x) && (x = "https:" + x);
    /!/.test(x) && (x = m(x));
    /^http/.test(x) || (x.startsWith("/storages/") && (x = x.replace("/storages/", "storages/")), 
    x = s + x);
    /.(png|jpe?g)$/.test(x) && (x += "!strip=1&quality=".concat(h, "&op_type=").concat(n, "&upload_type=").concat(v, "&name=").concat(d, "&device_type=ios").concat((0, 
    r.isAndroid)() ? "&magick=webp" : "").concat((0, a.isEmpty)(f) ? "" : "&" + (0, 
    o.obj2url)(f, !1)));
    return x;
}, exports.imageRoot = void 0;

var t = require("../../@babel/runtime/helpers/objectWithoutProperties"), e = require("./env"), r = require("./navBar"), o = require("./navigate"), a = require("./myAdapter"), p = [ "op_type", "name", "upload_type", "quality" ], s = e.isDevelopment ? "https://imagev2.test.ximalaya.com/" : "https://imagev2.xmcdn.com/";

exports.imageRoot = s;

var i = "https://fdfs.xmcdn.com/group65/M06/F5/16/wKgMdF1dEd6z5MACAABWzQ6NrWQ375.jpg";

exports.defaultAlbumImg = i;

function m(t) {
    return t && t.split("!").length ? t.split("!")[0] : t;
}

exports.defaultUserImg = "https://s1.xmcdn.com/css/img/common/default/user100.jpg";