Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.unescape = exports.escape = void 0;

var e = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#x27;",
    "`": "&#x60;"
}, t = function(e) {
    for (var t = {}, r = Object.keys(e), n = 0, o = r.length; n < o; n++) t[e[r[n]]] = r[n];
    return t;
}(e), r = function(e) {
    var t = function(t) {
        return e[t];
    }, r = "(?:" + Object.keys(e).join("|") + ")", n = RegExp(r), o = RegExp(r, "g");
    return function(e) {
        return e = null == e ? "" : "" + e, n.test(e) ? e.replace(o, t) : e;
    };
}, n = r(e);

exports.escape = n;

var o = r(t);

exports.unescape = o;