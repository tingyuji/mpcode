Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.drawSharePic = function(t, l, a) {
    var i = l.cover, o = l.playCount, r = l.oldPlayCount, n = l.albumMetaValueInfos, s = wx.createCanvasContext(t);
    (0, e.downloadFile)(i).then(function(e) {
        var l = e.tempFilePath;
        if (s.save(), s.drawImage(l, 40, 0, 320, 320), s.restore(), s.setFillStyle("rgb(50,53,54)"), 
        s.fillRect(0, 0, 10, 400), s.setFillStyle("black"), s.fillRect(10, 0, 5, 400), s.setFillStyle("rgb(50,53,54)"), 
        s.fillRect(15, 0, 25, 400), s.setFillStyle("rgb(50,53,54)"), s.fillRect(360, 0, 25, 400), 
        s.setFillStyle("black"), s.fillRect(385, 0, 5, 400), s.setFillStyle("rgb(50,53,54)"), 
        s.fillRect(390, 0, 10, 400), r >= 1e4) {
            var i = s.createLinearGradient(0, 0, 0, 88);
            i.addColorStop(0, "rgba(0,0,0,0.6)"), i.addColorStop(1, "rgba(0,0,0,0)"), s.setFillStyle(i), 
            s.fillRect(0, 0, 400, 88), s.setFillStyle("rgba(245, 245, 245, 1)"), s.setFontSize(27), 
            s.setTextAlign("left"), s.fillText("播放量：".concat(o), 26, 43);
        }
        var c = 0;
        n && n.forEach(function(e, t) {
            if (!(t > 2)) {
                s.setFillStyle("rgba(255,255,255,1)"), s.setFontSize(16), s.setTextAlign("left");
                var l = s.measureText(e).width;
                s.save(), function(e, t, l, a, i, o) {
                    e.beginPath();
                    var r = e.createLinearGradient(0, i, a, 0);
                    r.addColorStop(0, "rgba(250, 40, 0, 1)"), r.addColorStop(1, "rgba(255, 94, 61, 1)"), 
                    e.setFillStyle(r), e.arc(t + o, l + o, o, Math.PI, 1.5 * Math.PI), e.moveTo(t + o, l), 
                    e.lineTo(t + a - o, l), e.lineTo(t + a, l + o), e.arc(t + a - o, l + o, o, 1.5 * Math.PI, 2 * Math.PI), 
                    e.lineTo(t + a, l + i - o), e.lineTo(t + a - o, l + i), e.arc(t + a - o, l + i - o, o, 0, .5 * Math.PI), 
                    e.lineTo(t + o, l + i), e.lineTo(t, l + i - o), e.arc(t + o, l + i - o, o, .5 * Math.PI, Math.PI), 
                    e.lineTo(t, l + o), e.lineTo(t + o, l), e.fill(), e.closePath(), e.clip();
                }(s, 47 * t + c + 26, 277, l + 32, 32, 16), s.restore(), s.fillText(e, 47 * t + c + 16 + 26, 299), 
                c += l;
            }
        }), s.save(), s.drawImage("../../images/poster/share_play.png", 160, 120, 80, 80), 
        s.restore(), s.draw(!0, function() {
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    x: 0,
                    y: 0,
                    width: 400,
                    height: 320,
                    canvasId: t,
                    success: function(e) {
                        "function" == typeof a && a(e.tempFilePath);
                    },
                    fail: function(e) {}
                });
            }, 300);
        });
    });
};

var e = require("./genPoster");