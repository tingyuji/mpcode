Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.YESTERDAY = exports.TOMORROW = exports.TODAY = void 0, exports.currentTimeSecond = function(e) {
    var t = s(), r = c(e);
    return t - r;
}, exports.dateFmt = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "YYYY-MM-dd hh:mm:ss", r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], n = new Date(e), a = new Date(), o = a.getFullYear(), i = {
        "M+": n.getMonth() + 1,
        "d+": n.getDate(),
        "h+": n.getHours(),
        "m+": n.getMinutes(),
        "s+": n.getSeconds(),
        "q+": Math.floor((n.getMonth() + 3) / 3)
    };
    if (/(y+)/i.test(t)) {
        var s = RegExp.$1, c = n.getFullYear();
        t = r && o === c ? t.replace(s, "").slice(1) : t.replace(s, (c + "").substr(4 - s.length));
    }
    if (/(S)/.test(t)) {
        var u = RegExp.$1;
        t = t.replace(u, n.getMilliseconds());
    }
    for (var p = Object.keys(i), l = 0, f = p; l < f.length; l++) {
        var g = f[l];
        if (new RegExp("(" + g + ")").test(t)) {
            var m = RegExp.$1, v = i[g];
            t = t.replace(m, ("00" + v).substr(("" + v).length));
        }
    }
    return t;
}, exports.dateFmt2 = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = new Date(e), n = new Date(), a = r.getFullYear(), o = r.getMonth() + 1, i = r.getDate(), s = n.getFullYear();
    return s !== a || t ? "".concat(a, "年").concat(o, "月").concat(i, "日") : "".concat(o, "月").concat(i, "日");
}, exports.fillZero = r, exports.formatElapseTime = function(e, t, r) {
    var n = t - e, a = "";
    void 0 === r && (r = "更新");
    if (n > 31104e6) {
        var o = Math.floor(n / 31104e6);
        a = "".concat(o, "年前").concat(r);
    } else if (n > 2592e6) {
        var i = Math.floor(n / 2592e6);
        a = "".concat(i, "月前").concat(r);
    } else if (n > 864e5) {
        var s = Math.floor(n / 864e5);
        a = "".concat(s, "天前").concat(r);
    } else if (n > 36e5) {
        var c = Math.floor(n / 36e5);
        a = "".concat(c, "小时前").concat(r);
    } else if (n > 6e4) {
        var u = Math.floor(n / 6e4);
        a = "".concat(u, "分钟前").concat(r);
    } else a = "刚刚".concat(r);
    return a;
}, exports.formatTime = o, exports.isLiveStreaming = exports.isLivePreview = exports.isLivePlayback = void 0, 
exports.parseDateTime = function(e) {
    return Date.now() - e > 2592e6 ? o(e, "{y}-{m}") : o(e, "{m}-{dd}");
}, exports.parseDuration = n, exports.parseTime = a, exports.parseTimeStamp = function(e) {
    if ("number" != typeof e) return {};
    var t = parseInt(e / 864e5, 10), r = parseInt(e % 864e5 / 36e5, 10), n = parseInt(e % 36e5 / 6e4, 10), a = parseInt(e % 6e4 / 1e3, 10), o = parseInt(e % 1e3);
    return {
        d: t,
        h: r,
        m: n,
        s: a,
        ms: o
    };
}, exports.startEndDuration = function(e, t) {
    var r = u({
        startTime: e,
        endTime: t
    }), n = r.startTime, o = r.endTime - n;
    return {
        duration: o,
        durationStr: a(o)
    };
}, exports.timestampToTime = function(e) {
    if (!e) return;
    var t = e.length > 10 ? 1e3 : 1, r = new Date(e * t), n = r.getFullYear(), a = r.getMonth() + 1, o = r.getDate();
    a < 10 && (a = "0".concat(a));
    o < 10 && (o = "0".concat(o));
    return "".concat(n, "-").concat(a, "-").concat(o);
};

var e = require("../../@babel/runtime/helpers/slicedToArray"), t = require("../../@babel/runtime/helpers/typeof");

function r(e) {
    return e < 10 ? "0" + e : e;
}

function n() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
    t = parseInt(t), e = Math.round(e);
    var n = (e = isNaN(e) ? 0 : e) % 60, a = parseInt(e / 60, 10) % 60, o = parseInt(e / 3600, 10), i = "";
    switch (t) {
      case 1:
        i = "".concat(r(n));
        break;

      case 2:
        i = "".concat(r(a), ":").concat(r(n));
        break;

      case 3:
        i = "".concat(r(o), ":").concat(r(a), ":").concat(r(n));
    }
    return i;
}

function a() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
    return e >= 3600 && (t = 3), n(e, t);
}

function o(e, r) {
    if (0 === arguments.length) return null;
    var n, a = r || "{y}-{m}-{d} {h}:{i}:{s}";
    "object" === t(e) ? n = e : ("string" == typeof e && /^[0-9]+$/.test(e) && (e = parseInt(e)), 
    "number" == typeof e && 10 === e.toString().length && (e *= 1e3), n = new Date(e));
    var o = {
        y: n.getFullYear(),
        m: n.getMonth() + 1,
        d: n.getDate(),
        h: n.getHours(),
        i: n.getMinutes(),
        s: n.getSeconds(),
        a: n.getDay()
    }, i = a.replace(/{(y|m|d|h|i|s|a)+}/gi, function(e, t) {
        var r = o[t];
        return "a" === t ? [ "日", "一", "二", "三", "四", "五", "六" ][r] : (e.length > 0 && r < 10 && (r = "0" + r), 
        r || 0);
    });
    return i;
}

var i = function(e) {
    return !!(e && e.endTime && e.startTime);
};

function s() {
    var e, t, r = (e = new Date().getTimezoneOffset(), t = new Date().getTime(), new Date(t + 60 * e * 1e3 + 288e5));
    return 60 * (60 * r.getHours() + r.getMinutes()) + r.getSeconds();
}

function c(t) {
    if (!t) return 0;
    var r = t.split(":"), n = e(r, 2), a = n[0], o = n[1];
    return 60 * (60 * Number(a) + Number(o));
}

var u = function(e) {
    var t = e.startTime, r = e.endTime, n = c(t), a = c(r);
    return 0 === a && (a = 86400), {
        startTime: n,
        endTime: a,
        now: s()
    };
};

exports.YESTERDAY = "yesterday";

exports.TODAY = "today";

exports.TOMORROW = "tomorrow";

exports.isLiveStreaming = function(e) {
    if (!i(e)) return !1;
    var t = u(e), r = t.startTime, n = t.endTime, a = t.now;
    return "today" === e.type && a >= r && a <= n;
};

exports.isLivePlayback = function(e) {
    if (!i(e)) return !1;
    var t = u(e), r = t.startTime, n = t.endTime, a = t.now;
    return "yesterday" === e.type || "today" === e.type && a > r && a > n;
};

exports.isLivePreview = function(e) {
    if (!i(e)) return !1;
    var t = u(e), r = t.startTime, n = t.now;
    return "tomorrow" === e.type || "today" === e.type && n < r;
};