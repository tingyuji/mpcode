var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setWXOpenId = exports.setUUid = exports.handleNavigatedCookie = exports.getWXPayOpenId = exports.getWXAccessOpenId = exports.getUUid = exports.generatorUUid = void 0;

var o = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../apis/user"), n = require("@xmly/lite-login_wx/lib/index"), r = require("./index"), i = (require("./logger"), 
require("./navBar")), a = e(require("../../packages/uuid/index")), c = require("./storage"), s = r.isDevelopment ? "4&_device" : "1&_device", d = r.isDevelopment ? "wxopenid_wx4b1ec72b4bf82706_4" : "wxopenid_wx3a4b4454f28a932b_1", u = r.isDevelopment ? "wxopenid_wxb63203ca8ecbc8fc_4" : "wxopenid_wxb63203ca8ecbc8fc_1";

exports.getWXPayOpenId = function() {
    return (n.cookies.get("".concat(d)) || {}).value;
};

exports.getWXAccessOpenId = function() {
    return (n.cookies.get("".concat(u)) || {}).value;
};

exports.setWXOpenId = function(e) {
    wx.login({
        force: !1,
        success: function(r) {
            var i = {
                code: r.code,
                thirdpartyId: 18
            };
            (0, t.getBaseAccessByCode)(i).then(function(t) {
                t.ret;
                var r = t.openId, i = (t.key, o({}, n.cookies.get(u)));
                console.log("options", i), i.name = d, n.cookies.set("".concat(d), r, i), e && e(r);
            });
        }
    });
};

exports.getUUid = function() {
    var e = n.cookies.get("".concat(s)) || {};
    return console.log("getUUid", s, e, "--"), e.value;
};

exports.setUUid = function() {
    var e = "".concat((0, i.isIos)() ? "iPhone" : "android", "&").concat((0, a.default)(), "&1.0.0");
    console.log("setUUid", s, e), n.cookies.set("".concat(s), e, {
        expires: "3744613856000"
    });
};

exports.generatorUUid = function() {};

exports.handleNavigatedCookie = function(e) {
    var o = e.referrerInfo || e[0].referrerInfo, i = e.scene || e[0].scene, a = e.query || e[0].query;
    console.log("handleNavigatedCookie referrerInfo======", o, i, e);
    var s = o.appId, d = o.extraData;
    if ("wx5cbadb79ad885413" === s && d.bizKey && d.uid && 1037 === Number(i) && function(e) {
        var o = (0, r.getCurrPage)();
        return console.log("handleNavigatedCookie isFromXibo======", o, e, o.options, getCurrentPages().pop()), 
        !(!e.xibo || "1" !== e.xibo);
    }(a)) {
        var u = d.uid, p = d.bizKey, g = d.thirdpartyId;
        if ((0, c.getUid)() + "" == u + "") return;
        console.log("handleNavigatedCookie handleLogin====="), (0, t.getNonce)().then(function(e) {
            if (e) {
                var o = (0, n.getSignature)({
                    nonce: e,
                    bizKey: p,
                    thirdpartyId: g
                }, r.isDevelopment ? "test" : "");
                (0, t.decryptDataAndLogin)({
                    bizKey: p,
                    nonce: e,
                    thirdpartyId: g,
                    signature: o
                }).then(function(e) {
                    console.log("decryptDataAndLogin======", e), (0, t.getUserInfo)().then(function(e) {
                        setTimeout(function() {
                            var e = getCurrentPages().pop(), o = e.options, t = void 0 === o ? {} : o;
                            e.initLoad ? e.initLoad(t) : e.onLoad(t);
                        }, 500);
                    });
                });
            }
        });
    }
};