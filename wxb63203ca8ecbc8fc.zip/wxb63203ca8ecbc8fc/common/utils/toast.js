Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.showLongToast = void 0;

var e = require("../../@babel/runtime/helpers/objectSpread2");

exports.showLongToast = function(o) {
    wx.showToast(e(e({}, o), {}, {
        duration: 3e3
    }));
};