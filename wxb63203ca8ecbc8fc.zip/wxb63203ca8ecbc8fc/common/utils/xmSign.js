Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    var a = Date.now();
    return "".concat(t("ximalaya-001"), "(").concat(e(100), ")").concat(a, "(").concat(e(100), ")").concat(a);
};

var t = require("md5"), e = function(t) {
    return ~~(Math.random() * t);
};