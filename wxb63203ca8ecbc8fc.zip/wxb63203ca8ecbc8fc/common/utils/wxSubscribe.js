Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addSubCount = function(e) {
    (0, o.addAlbumPushCount)().then(function(o) {
        if (o && o.today_count < 8) {
            var u = (0, n.get)("subscribe_status"), s = "", r = new Date().toLocaleDateString();
            "object" === t(u) && u.date && u.status && (s = u.date == r ? u.status : ""), s ? (console.log("读取本地存储订阅状态:".concat(s)), 
            "accept" === s && (console.log("读取本地存储状态，订阅数+1"), c())) : i(e, function(t) {
                console.log("本地无订阅状态，调用getSetting查询"), (0, n.set)("subscribe_status", {
                    date: r,
                    status: t
                }), "accept" === t && (console.log("调用getSetting，订阅数+1"), c());
            });
        }
    });
}, exports.handleAlbumSub = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 ? arguments[1] : void 0, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "album", r = function() {
        e.EventBus.emit("showSubModal", {
            info: t,
            currentPage: s
        }), (0, u.exposureSubsribeModal)();
    }, a = function(t) {
        "accept" === t && ((0, o.addAlbumPushCount)().then(function(t) {
            (!t.today_count || t.today_count) < 10 && c();
        }), r()), "query" === t && c(function(t) {
            e.EventBus.emit("showSubTip", !1), (0, u.genLogger)(19482, "click", {
                item: "accept" === t ? "允许一次" : "取消一次"
            }), "accept" === t && (0, o.addAlbumPushCount)(), "reject" === t && (0, o.switchPushAlbum)({
                albumId: n,
                status: 0
            }), r();
        });
    };
    i("".concat(s, ",专辑订阅"), function(u) {
        switch (u) {
          case "reject":
            e.EventBus.emit("showSubModal", {
                info: t,
                currentPage: s
            }), (0, o.switchPushAlbum)({
                albumId: n,
                status: 0
            });
            break;

          case "query":
            e.EventBus.emit("showSubTip", !0), a(u);
            break;

          case "accept":
            a(u);
        }
    });
}, exports.queryWxSubStatus = i, exports.subscribeTemplateId = void 0, exports.wxSubscribeAlbum = c;

var t = require("../../@babel/runtime/helpers/typeof"), e = require("../../packages/lite-player/event"), o = require("../../common/apis/album"), u = require("../../common/utils/logger"), n = require("../utils/index"), s = "cJNYhCd8XqixDsg-2PBqqvTgq_3mMAby3i5XFVYduNY";

function c(t) {
    wx.requestSubscribeMessage({
        tmplIds: [ s ],
        success: function(e) {
            var o = e.errMsg, u = e[s];
            console.log("errMsg:", o), console.log("tempIdRet:", u), "function" == typeof t && t(u);
        },
        fail: function() {},
        complete: function() {}
    });
}

function i() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "我页打开订阅", e = arguments.length > 1 ? arguments[1] : void 0, o = !0, n = !1, c = function(t) {
        var e = t.showSubModal, o = t.canAutoAddSub, u = "";
        return !e && o && (u = "accept"), e && !o && (u = "query"), e || o || (u = "reject"), 
        u;
    };
    wx.getSetting({
        withSubscriptions: !0,
        success: function(t) {
            t && t.subscriptionsSetting && t.subscriptionsSetting.mainSwitch ? t.subscriptionsSetting.itemSettings && (o = !1, 
            "accept" === t.subscriptionsSetting.itemSettings[s] && (n = !0), t.subscriptionsSetting.itemSettings[s]) : o = !1;
            var u = c({
                showSubModal: o,
                canAutoAddSub: n
            });
            t && t.errcode && 45009 == t.errcode && (u = "error"), "function" == typeof e && e(u);
        },
        fail: function() {
            o = !1, "function" == typeof e && e("error");
        },
        complete: function() {
            (0, u.genLogger)(33016, "click", {
                type: t
            });
        }
    });
}

exports.subscribeTemplateId = s;