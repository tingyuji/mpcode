Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAlbum = function(e, t) {
    var a = e.currentTarget.dataset.index;
    if (!a && 0 !== a) return;
    return t[a];
}, exports.getBridgeAudioPage = function(e) {
    return {
        path: "pages/bridge/bridge",
        query: {
            url: encodeURIComponent(e)
        }
    };
}, exports.getBridgeUrl = function(e) {
    return "/pages/bridge/bridge?url=".concat(encodeURIComponent(e));
}, exports.getCurrentRoute = function() {
    var e = getCurrentPages(), t = Math.max(e.length - 1, 0), a = e[t];
    return a && a.route;
}, exports.getLastPage = function() {
    var e = getCurrentPages() || [], t = e[e.length - 2], a = "";
    t && (a = "/" + (0, n.getUrl)(t.options, t.route));
    return a;
}, exports.goPage = function(e) {
    if (i()) return wx.redirectTo(e);
    wx.navigateTo(e);
}, exports.isPageStackFull = i, exports.obj2url = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "true", a = "";
    return Object.keys(e).forEach(function(t, r) {
        r > 0 && (a += "&"), a += "".concat(t, "=").concat(e[t]);
    }), "true" === t ? encodeURIComponent(a) : a;
}, exports.paidAlbumNavigate = function(e) {
    var t = e.path || e[0].path, a = e.query || e[0].query, r = a.albumId, n = void 0 === r ? "" : r, o = a.scene;
    if ("pages/paidPackage/pages/albumDetailPaid/albumDetailPaid" === t) {
        if (o) {
            var i = decodeURIComponent(o).toString().split(",");
            n = i && i.length > 1 && i[0];
        }
        wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(n, "&fromOldVersion=1")
        });
    }
}, exports.safeNavigateBack = function(t) {
    wx.navigateBack(e({
        delta: 1,
        fail: function() {
            c();
        }
    }, t));
}, exports.safeNavigateTo = function(e) {
    wx.navigateTo({
        url: e.url,
        fail: function() {
            g(e);
        }
    });
}, exports.safeRedirectTo = g, exports.safeSwitchTab = u, exports.toAlbum = l, exports.toHome = c, 
exports.track2Video = function(e) {
    var t = getCurrentPages(), a = Math.max(t.length - 2, 0), r = t[a], n = r.id, o = r.path;
    if (console.log(t, "track2Video=========="), "/pages/video/index" === o && n + "" == e + "" && t.length > 1) return wx.navigateBack();
    wx[i() ? "redirectTo" : "navigateTo"]({
        url: "/pages/video/index?id=".concat(e)
    });
}, exports.track2album = function(e) {
    var t = getCurrentPages(), a = Math.max(t.length - 2, 0), r = t[a], n = r.path, o = r.albumId, u = r.url, c = void 0 === u ? "" : u;
    "/pages/webview/index" === n && (o = c.split("/").pop());
    if (Number(o) === e.id && t.length > 1) return wx.navigateBack();
    l(e, i() ? "redirectTo" : "navigateTo");
}, exports.url2obj = function(e) {
    var a = e.split(/[?&]/).splice(1), r = {};
    return a.forEach(function(e) {
        var a = e.split(/=/), n = t(a, 2), o = n[0], i = n[1];
        r[o] = i;
    }), r;
}, exports.video2Track = function(e) {
    var t = getCurrentPages(), a = Math.max(t.length - 2, 0), r = t[a], n = r.trackId, o = r.path;
    if (console.log("video2Track", r), "/pages/soundPage/soundPage" === o && n + "" == e + "" && t.length > 1) return wx.navigateBack();
    wx[i() ? "redirectTo" : "navigateTo"]({
        url: "/pages/soundPage/soundPage?trackId=".concat(e)
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("./env"), r = require("./navBar"), n = require("./index"), o = require("../../common/const/trackType");

function i() {
    return getCurrentPages().length >= 10;
}

function u(e) {
    wx.switchTab({
        url: e.url,
        fail: function() {
            wx.reLaunch({
                url: "/pages/home/home"
            });
        }
    });
}

function c() {
    wx.reLaunch({
        url: "/pages/index/index"
    });
}

function g(e) {
    wx.redirectTo({
        url: e.url,
        fail: function() {
            u(e);
        }
    });
}

function l() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.id, n = e.categoryCode, i = arguments.length > 1 ? arguments[1] : void 0, u = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "navigateTo";
    if (t) {
        var c = !1, g = !!c && "/pages/webview/index?url=https://m.".concat(a.isDevelopment ? "test." : "", "ximalaya.com/").concat(n, "/").concat(t, "/&barHeight=").concat((0, 
        r.getStatusBarHeight)());
        g || (g = i === o.RADIOS ? "/pages/radio-program-play/radio-program-play?radioId=".concat(t) : "/pages/albumDetail/albumDetail?albumId=".concat(t)), 
        wx[u]({
            url: g
        });
    }
}