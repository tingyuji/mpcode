Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.RUN_ENV = function() {
    if ("undefined" != typeof swan) return "swan";
    if ("undefined" != typeof my) return "my";
    if ("undefined" != typeof wx) return "wx";
    if ("undefined" != typeof qq) return "qq";
    if ("undefined" != typeof tt) return "tt";
    if ("undefined" != typeof wx) return "xm";
}, exports.isWx = exports.isMy = exports.isDevelopment = exports.env = void 0;

var e = "production";

exports.env = e;

exports.isMy = !1;

exports.isWx = !0;

exports.isDevelopment = !1;