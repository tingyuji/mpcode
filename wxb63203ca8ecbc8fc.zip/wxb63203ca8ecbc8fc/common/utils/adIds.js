Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.trackCenterAdId = exports.pointscenterVideoAdId = exports.pointscenterBannerId = exports.pointscenetrAdId = exports.myModalAdId = exports.hpFeedVideoAdId = exports.hpFeedAdId = exports.bannerAdId = void 0;

exports.bannerAdId = "adunit-0f4cbbbec10c7d3f";

exports.hpFeedAdId = "adunit-4e9a52b105fd6987";

exports.hpFeedVideoAdId = "adunit-d4a7f058b7a2251f";

exports.trackCenterAdId = "adunit-29fc05d99b21172d";

exports.myModalAdId = "adunit-f8ac8a9de2bf59ae";

exports.pointscenetrAdId = "adunit-6c089301771a2c12";

exports.pointscenterBannerId = "adunit-eccee0607441237e";

exports.pointscenterVideoAdId = "adunit-6439ee283468ad3b";