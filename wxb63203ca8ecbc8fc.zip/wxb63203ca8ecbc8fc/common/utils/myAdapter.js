function t() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return 0 === Object.keys(t).length;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDataset = function(e) {
    return (e.target || e.currentTarget) && (e.target.targetDataset || (t(e.target.dataset) ? e.currentTarget && e.currentTarget.dataset || {} : e.target && e.target.dataset || {})) || {};
}, exports.isEmpty = t, exports.isUndefined = function(t) {
    return void 0 === t;
};