var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.myPage = g;

var n = require("../../@babel/runtime/helpers/objectSpread2"), t = require("./logger"), o = require("../../packages/lite-player/event"), a = require("../../common/utils/index"), i = require("../../common/utils/shareFromApp"), r = e(require("../../common/utils/qm-wx-min")), s = require("../../common/utils/wxSubscribe"), u = require("../apis/mineapi"), l = Page, c = [];

function h() {
    var e = c.pop();
    "function" == typeof e && e();
}

function g(e) {
    var g = getApp(), d = null, p = null, f = function(e) {
        p = e;
    }, b = e.onLoad, m = e.onReady, P = e.onShow, y = e.onHide, S = e.onUnload, v = e.onShareAppMessage, T = e.onPullDownRefresh, C = e.onTabItemTap, q = e.onPageScroll, x = e.onScroll, w = e.onTouchStart, D = e.onTouchEnd, k = function() {
        var e = g.globalData, n = e.isPlayerBarMini, t = e.isTouching;
        n && !t && (d && (clearTimeout(d), d = null), d = setTimeout(function() {
            o.EventBus.emit("setPlayerBarMiniVisible", !1), g.globalData.isPlayerBarMini = !1;
        }, 500)), n || (o.EventBus.emit("setPlayerBarMiniVisible", !0), g.globalData.isPlayerBarMini = !0);
    };
    e.onLoad = function(e) {
        this.options = e, b && b.bind(this)(e), this.onloadTime = new Date(), o.EventBus.on("globalPlayerShare", f);
    }, e.onReady = function() {
        var e = (0, a.getCurrentRoute)(), n = new Date() - this.onloadTime;
        (0, a.canIUse)("reportPerformance") && (console.log("当前页面渲染耗时", n, e), wx.reportPerformance(2001, n, e)), 
        m && m.bind(this)(this.options);
    }, e.onShow = function(e) {
        try {
            c.length && c.forEach(function(e) {
                return e();
            }), (0, a.getUid)() && "pages/soundPage/soundPage" === (0, a.getCurrentRoute)() ? function(e) {
                var o = (0, a.get)("userInfo"), i = Object.keys(o);
                if (i.indexOf("tracksCount") > -1 && i.indexOf("anchorGrade") > -1) {
                    var r = o.tracksCount, s = o.anchorGrade;
                    e = n(n({}, e), {}, {
                        tracksCount: r,
                        anchorGrade: s
                    }), (0, t.PV)(e);
                } else (0, u.queryUserInfo)({
                    uid: (0, a.getUid)()
                }).then(function(o) {
                    var i = o.tracksCount, r = o.anchorGrade;
                    e = n(n({}, e), {}, {
                        tracksCount: i,
                        anchorGrade: r
                    }), (0, a.set)("userInfo", o), (0, t.PV)(e);
                });
            }(this.options) : (0, t.PV)(this.options), c.push((0, t.PE)(this.options)), (0, 
            a.isPageStackFull)() && (0, t.genLogger)(20394, "exposure", {}), r.default.show();
        } catch (e) {
            console.log(e);
        }
        P && P.bind(this)();
    }, e.onHide = function() {
        h(), y && y.bind(this)();
    }, e.onUnload = function() {
        h(), S && S.bind(this)(), o.EventBus.off("globalPlayerShare", f);
    }, e.onPullDownRefresh = function() {
        console.log("onPullDownRefresh"), T && T.bind(this)(), b && b.bind(this)(options);
    }, e.onPageScroll = function(e) {
        q && q.bind(this)(e), k();
    }, x && (e.onScroll = function(e) {
        x.bind(this)(e), k();
    }), e.onShareAppMessage = v ? function(e) {
        var n = v.bind(this)(e);
        return (0, t.clickShareWeChat)(), e.target && e.target.dataset.pshare ? p : n;
    } : function(e) {
        var o = getApp().sq, r = (0, a.getCurrPage)();
        this.shareCount = (0, i.returnShareCount)(o);
        var s = (0, a.getUrl)(n(n(n({}, r.options), o), {}, {
            count: this.shareCount
        }), r.route);
        return (0, t.clickShareWeChat)(), e.target && e.target.dataset.pshare ? p : {
            title: "千万优质好内容，等你来听",
            path: "/".concat(s),
            imageUrl: "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/wx_images/images/share/bg.png"
        };
    }, C && (e.onTabItemTap = function(e) {
        (0, s.addSubCount)("tab"), C && C.bind(this)(e);
    }), e.onTouchStart = function(e) {
        g.globalData.isTouching = !0, w && w.bind(this)(e);
    }, e.onTouchEnd = function(e) {
        g.globalData.isTouching = !1, g.globalData.isPlayerBarMini && k(), D && D.bind(this)(e);
    }, l(e);
}

Page = g;