Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.canOpenApp = function() {
    e || (e = getApp());
    return 1036 == e.scene || 1069 == e.scene;
}, exports.copyCode = function(e, t) {
    var o = e.schema, n = e.srcPage, c = e.type, r = e.codeLink, s = "".concat(n, "&src=m.ximalaya.com/share/").concat(c, "&iting=").concat(encodeURIComponent(o), "&android_schema=").concat(encodeURIComponent(o));
    r && (s = r);
    wx.request({
        url: "".concat(a, "/thirdparty-share/createShareCommand"),
        method: "POST",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        data: {
            shareContentType: "URL",
            link: s
        },
        success: function(e) {
            0 == e.data.ret && (t && t(e.data.command), setTimeout(function() {
                return t = e.data.command, void wx.setClipboardData({
                    data: t,
                    success: function(e) {
                        wx.hideToast(), console.log("O(∩_∩)O~~复制成功");
                    },
                    fail: function() {
                        console.log("orz...复制失败");
                    }
                });
                var t;
            }, 500));
        },
        fail: function(e) {
            console.log("\b串码接口调用失败", e);
        }
    });
}, exports.copyCodeByEvent = function(e) {
    t || (t = wx.getSystemInfoSync());
    if ("ios" === t.platform && "stjs" !== e && "jfzx" !== e) return;
    var o = {
        utm_source: "wechat_miniprogram",
        src: "wxxcx_".concat(e)
    };
    "qt" !== e && "stjs" !== e || (o.from = "zhanshi");
    n.copyHandle({
        cid: 3001,
        link: "iting://open",
        extraInfo: o
    });
};

var e, t, o = require("./env"), n = require("@xmly/arouse-lite"), a = o.isDevelopment ? "http://m.test.ximalaya.com" : "https://m.ximalaya.com";