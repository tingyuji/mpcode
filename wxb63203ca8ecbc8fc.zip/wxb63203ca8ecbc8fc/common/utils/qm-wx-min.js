var e = {};

"function" != typeof Object.assign && (Object.assign = function(e) {
    if (null == e) throw new TypeError("Cannot convert undefined or null to object");
    e = Object(e);
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        if (null != n) for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
    }
    return e;
});

var t = {
    Store: {
        set: function(e, t) {
            return wx.setStorageSync(e, t), !0;
        },
        get: function(e) {
            return wx.getStorageSync(e);
        },
        remove: function(e) {
            return wx.removeStorageSync(e), !0;
        }
    },
    random: function() {
        for (var e = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", t = e.length, n = "", i = 0; i < 12; i++) n += e.charAt(Math.floor(Math.random() * t));
        return n;
    },
    timestamp: function() {
        return new Date().getTime();
    },
    uuid: function() {
        return this.timestamp() + "-" + this.random();
    },
    request: function(t) {
        var n = {
            appkey: e.appkey
        };
        if (this.Store.get("Qt_uid")) n.deviceId = this.Store.get("Qt_uid"); else {
            var i = this.uuid();
            this.Store.set("Qt_uid", i), n.deviceId = i;
        }
        Object.assign(n, t.data), wx.request({
            url: "https://www.qchannel03.cn/wxv1",
            data: JSON.stringify(n),
            method: "POST",
            success: function(e) {
                t.success && t.success();
            },
            fail: function(e) {
                t.fail && t.fail();
            }
        });
    }
}, n = {
    appinfos: {},
    getAppInfos: function() {
        var n = {
            sdkVersion: "20170718"
        };
        if (t.Store.get("Qt_initTime_ts")) n.initTime = t.Store.get("Qt_initTime_ts"); else {
            var i = t.timestamp();
            t.Store.set("Qt_initTime_ts", i), n.initTime = i;
        }
        Object.assign(n, e.getAppInfos), this.appinfos = n;
    },
    deviceinfos: {},
    getDeviceInfos: function() {
        var e = {};
        wx.getSystemInfo({
            success: function(t) {
                e.model = t.model.indexOf("<") > -1 ? t.model.split("<")[0] : t.model, e.wechatVersion = t.version, 
                e.scr_width = t.windowWidth, e.scr_height = t.windowHeight, e.language = t.language, 
                e.timezone = -new Date().getTimezoneOffset() / 60, Object.assign(n.deviceinfos, e);
            }
        }), wx.getNetworkType({
            success: function(t) {
                var i = t.networkType.toLocaleLowerCase();
                e.connectionType = i, Object.assign(n.deviceinfos, e);
            }
        });
    },
    start_track: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {}, i = {};
        i.initTime = t.Store.get("Qt_initTime_ts"), i.duration = 0, t.Store.set("Qt_session_btime", t.timestamp()), 
        i.start = t.timestamp(), this.sessionSend(i, e, n);
    },
    stop_track: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {}, i = {}, s = t.timestamp();
        t.Store.get("Qt_session_btime") && (i.duration = parseInt((s - t.Store.get("Qt_session_btime")) / 1e3), 
        i.start = t.Store.get("Qt_session_btime"), this.sessionSend(i, e, n));
    },
    sessionSend: function(e, n, i) {
        Object.assign(this.appinfos, e), Object.assign(this.appinfos, this.deviceinfos), 
        t.request({
            data: this.appinfos,
            success: function(t) {
                n && n(e, t);
            },
            fail: function(t) {
                i && i(e, t);
            }
        });
    },
    launch: function(t) {
        "appkey" in t || (t.appkey = !1), "appname" in t || (t.appname = !1), "versionName" in t || (t.versionName = "1.0.0"), 
        "versionCode" in t || (t.versionCode = "1"), t.appkey || (t.appkey = "", console.error("请填写AppKey")), 
        t.appname || (t.appname = "appname", console.error("请填写您的小程序名称")), e = {
            appkey: t.appkey,
            getAppInfos: {
                appname: t.appname,
                versionName: t.versionName,
                versionCode: t.versionCode
            },
            params: t
        }, this.getDeviceInfos(), this.getAppInfos();
        var n = this;
        setTimeout(function() {
            var e, t = getApp();
            e = t.onShow, t.onShow = function() {
                n.show(), e.call(this, arguments);
            }, function() {
                var e = t.onHide;
                t.onHide = function() {
                    n.hide(), e.call(this, arguments);
                };
            }();
        }, 0);
    },
    show: function() {
        this.start_track();
    },
    hide: function() {
        this.stop_track();
    }
};

module.exports = n;