Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initAdVideo = function(o, n) {
    wx.createRewardedVideoAd && (o.onLoad(function() {}), o.onError(function(o) {
        console.log(o, "激励视频播放出错"), wx.showToast({
            title: "视频还在准备中，过会再来吧~",
            icon: "none"
        });
    }), o.onClose(function(o) {
        "function" == typeof n && n(o);
    }));
}, exports.watchAdVideo = function(o) {
    o && o.show().then(function() {
        console.log("激励视频 广告显示成功");
    }).catch(function() {
        o.load().then(function() {
            return o.show();
        }).catch(function(o) {
            console.log("激励视频 广告显示失败"), console.log(o);
        });
    });
};