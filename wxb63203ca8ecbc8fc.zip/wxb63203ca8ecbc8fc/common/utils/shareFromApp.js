Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.toRequestShortUrl = exports.returnShareCount = void 0;

var r = require("../apis/index");

exports.toRequestShortUrl = function(e) {
    var t = e.from, o = e.webUrl;
    "app" === t && o && (0, r.request)({
        url: o
    });
};

exports.returnShareCount = function(r) {
    if (!r) return 0;
    var e = r.from, t = r.count, o = 0;
    return e && (isNaN(Number(t)) || (o = t), o++), o;
};