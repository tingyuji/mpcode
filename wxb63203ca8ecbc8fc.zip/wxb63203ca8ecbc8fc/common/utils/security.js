var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getQueryString = u, exports.getSecurityKey = n, exports.getSignature = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = n(), o = u(e) + "&" + t;
    return (0, r.default)(o.toUpperCase());
};

var r = e(require("./sha1")), t = require("./env");

function n() {
    return t.isDevelopment ? "WEB-V1-TEST-08A5F0C2A54B4F899E3F9ECFE14DC128B6D1FB3F5FB744ABB76BEAA9534D3B2F" : "WEB-V1-PRODUCT-E7768904917C4154A925FBE1A3848BC3E84E2C7770744E56AFBC9600C267891F";
}

function u(e) {
    var r = "", t = Object.keys(e).sort(function(e, r) {
        return e.charCodeAt(0) - r.charCodeAt(0);
    }), n = t.length;
    return t.forEach(function(t, u) {
        var o = e[t];
        r += "".concat(t, "=").concat(o), u < n - 1 && (r += "&");
    }), r;
}