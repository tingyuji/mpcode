Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.showSuccessModal = exports.handleVipSubsribe = exports.delayHandleVipSubsribe = void 0;

var e = require("../apis/paid"), r = require("../utils/index"), t = require("../../packages/lite-player/event"), i = require("./logger"), o = function(e) {
    wx.disableAlertBeforeUnload && wx.disableAlertBeforeUnload({}), (0, i.genLogger)(26735, "slipPage", {
        type: "自动续费",
        id: e
    }), wx.showModal({
        title: "【购买成功】",
        content: "快去畅听VIP精品内容吧~",
        confirmText: "好的",
        confirmColor: "#F24821",
        showCancel: !1,
        success: function(e) {
            (0, r.safeRedirectTo)({
                url: (0, r.getLastPage)()
            });
        }
    });
};

exports.showSuccessModal = o;

var s = function(i) {
    var s = i.scene || i[0].scene, n = i.referrerInfo || i[0].referrerInfo;
    if (1038 === s) {
        var a = n.appId, d = n.extraData;
        if ("wxbd687630cd02ce1d" == a) {
            if (void 0 === d) return void (0, e.getVipSubscribeStatus)((0, r.getUid)()).then(function(e) {
                1 === e.statusId ? o(e.itemId) : t.EventBus.emit("showAutoRenewQueryModal");
            });
            if ("SUCCESS" == d.return_code) {
                var u = d.contract_id;
                return void (0, e.getVipSubscribeStatus)((0, r.getUid)()).then(function(e) {
                    1 === e.statusId && e.signOrderNo + "" == u + "" ? o(e.itemId) : t.EventBus.emit("showAutoRenewQueryModal");
                });
            }
            return void t.EventBus.emit("showAutoRenewQueryModal");
        }
    }
};

exports.handleVipSubsribe = s;

exports.delayHandleVipSubsribe = function(e) {
    var r = e.scene || e[0].scene, t = (e.referrerInfo || e[0].referrerInfo).appId, i = getApp(), o = (i && i.globalData || {}).isAutoRenew;
    1038 === r && "wxbd687630cd02ce1d" == t && o && (wx.showLoading({
        title: "订单处理中",
        mask: !0
    }), setTimeout(function() {
        s(e), wx.hideLoading();
    }, 2e3));
};