Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setTabBar = function(e) {
    "function" == typeof e.getTabBar && e.getTabBar() && e.getTabBar().setTabBar(e);
};