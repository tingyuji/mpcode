Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getLocalPlayProgress = function() {
    var t = (0, e.get)(r);
    if (!t) return {};
    return t.playMap;
}, exports.setLocalPlayProgress = function(a, o) {
    o > 100 && (o = 100);
    var s = a.trackId;
    if (a.type !== t.HOTNEWS) return;
    var p = {
        timeStamp: new Date().getTime(),
        playMap: {}
    }, i = (0, e.get)(r);
    (!i || i.timeStamp - new Date().getTime() > 86400) && (i = p);
    i.playMap[s] = o, console.log("听头条播放进度更新", i), (0, e.set)(r, i);
};

var e = require("./storage"), t = require("../const/trackType"), r = "hotNews-play-progress";