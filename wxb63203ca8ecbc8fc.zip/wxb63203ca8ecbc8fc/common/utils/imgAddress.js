Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.imgAddress = void 0;

exports.imgAddress = "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/images";