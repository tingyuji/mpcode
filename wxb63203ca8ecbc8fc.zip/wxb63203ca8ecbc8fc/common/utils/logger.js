var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.helpModalShow = exports.genLoggerPV = exports.genLoggerExit = exports.genLoggerClick = exports.genLogger = exports.exposureSubsribeModal = exports.exposureModule = exports.exposureLikeModal = exports.clickWatchVideo = exports.clickVipBar = exports.clickTrackRank = exports.clickTrackNextTip = exports.clickTrackList = exports.clickTomato = exports.clickSubscribeModalShare = exports.clickStar = exports.clickSigninEntrance = exports.clickSignin = exports.clickShareWeChat = exports.clickShareTimeline = exports.clickRecommandAlbum = exports.clickRankAlbum = exports.clickPointSeeMore = exports.clickPaidGuessAlbum = exports.clickModuleAlbum = exports.clickMineTab = exports.clickLikeModalShare = exports.clickInviteFriend = exports.clickIndexModuleSeeMore = exports.clickHotListenList = exports.clickHelpBtn = exports.clickHelpAlbum = exports.clickHeadline = exports.clickGzhTask = exports.clickGuessChange = exports.clickGetPoints = exports.clickFeedItem = exports.clickDrawAssistAward = exports.clickAnchorFollow = exports.PV = exports.PE = void 0, 
exports.init = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = "wx", u = wx.getSystemInfoSync(), k = u.screenHeight, d = u.screenWidth, g = u.pixelRatio, m = u.benchmarkLevel, v = u.SDKVersion, h = u.platform, b = u.system, P = u.version, w = u.model, y = u.brand, I = u.isQB;
    0;
    I && (t = "qb");
    var S = x(t), T = l.version;
    f = {
        sceneId: e,
        miniProgramType: p.wx,
        appName: S,
        screenHeight: k,
        screenWidth: d,
        pixelRatio: g,
        benchmarkLevel: m,
        SDKVersion: v,
        platform: h,
        system: b,
        version: P,
        model: w,
        brand: y,
        srcAppId: r.appId || "",
        xcxVersion: T
    }, (0, i.start)({
        b: 376,
        p: "wx",
        e: c.env
    }), (0, n.getUid)() || (0, o.getUserInfo)();
    var M = function(e) {
        wx.uma.setOpenid(e);
    };
    (0, s.setWXOpenId)(M), a.default.launch({
        appkey: "qtwx_HyuEVdM3",
        appname: "喜马拉雅lite",
        versionName: "1.0",
        versionCode: "1.0"
    });
}, exports.set_sq = function(e, r) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    f.sceneId = r, f.srcAppId = t.appId || "";
    var i = e.from, o = e.count, c = e.plan, n = e.copy, a = e.copydt;
    if (!i && !n) return;
    h = {
        from: i,
        count: o,
        plan: c,
        copy: n,
        copydt: a
    };
}, exports.trackNextTip = exports.signinSuccessToast = void 0;

var r = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../@babel/runtime/helpers/slicedToArray"), i = require("@xmly/xlog-xmlite/index.js"), o = require("../apis/user"), c = require("./env"), n = require("./storage"), a = e(require("./qm-wx-min")), s = require("./wxCookie"), u = require("./index"), l = require("../../version.config"), p = {
    tt: "bytedance",
    my: "alipay",
    qh: 360,
    quickapp: "quickapp",
    wx: "weixin"
}, x = function(e) {
    switch (e) {
      case "tt01":
        return "Toutiao";

      case "tt02":
        return "Douyin";

      case "tt06":
        return "ToutiaoMini";

      case "my":
        return "Alipay";

      case "wx":
        return "Weixin";

      case "qb":
        return "QB";

      default:
        return "Toutiao";
    }
}, k = {
    index: 47573,
    categorylist: 12061,
    search: 47584,
    searchresult: 12065,
    rank: 12067,
    pointsunlock: 17147,
    pointsdetail: 17145,
    pointscenter: 17143,
    setting: 17141,
    follow: 17139,
    fans: 17137,
    mine: 48117,
    paid: 51413,
    category: 17120,
    listenlist: 17122,
    announcer: 17048,
    soundPage: 47776,
    albumDetail: 51409,
    error: 17151,
    settlement: 17149,
    article: 51529,
    404: 26644,
    vip: 51415,
    rankpage: 27108,
    channellist: 47097,
    channel: 47097,
    wxgroup: 30048,
    login: 31510,
    video: 33751,
    radio: 30720,
    "radio-program-play": 30718
}, d = [ [ "index", "wx-newhome" ], [ "search", "wx-newsearch" ], [ "article", "wx-ask" ], [ "vip", "wx-vip" ], [ "paid", "wx-elite" ], [ "mine", "wx-mine" ], [ "albumDetail", "wx-newalbum" ], [ "soundPage", "wx-newvoicepage" ], [ "currPage", "wx-channelclassify" ] ], g = d.map(function(e) {
    var r = t(e, 2), i = r[0], o = r[1], c = [ o, i ];
    return [ i = c[0], o = c[1] ];
}), m = new Map(g), f = {}, v = "", h = {};

function b(e) {
    var r = new Map(d);
    if (!e.length) return "";
    var t = e.pop();
    if (!t) return "";
    var i = t.route, o = t.__route__, c = (i || o).match(/pages\/(.*)\//);
    return c ? r.has(c[1]) ? r.get(c[1]) : c[1] : "";
}

function P() {
    var e = getCurrentPages();
    return [ b(e), b(e) || v ];
}

function w() {
    var e = (0, u.getCurrPage)();
    return r({
        userId: (0, n.getUid)(),
        miniUrl: (0, u.getUrl)(e.options, e.route),
        wxopenid: (0, s.getWXAccessOpenId)()
    }, h);
}

function y() {
    var e = "follow", r = (0, u.getPageData)(), i = t(r, 2), o = i[0];
    i[1];
    return "fans" === o.type && (e = "fans"), e;
}

var I = function(e, o, c) {
    var n = P(), a = t(n, 2), s = a[0], u = a[1], l = r(r({
        prevPage: u
    }, f), w()), p = r(r({}, c), l);
    void 0 === p.currPage && (p.currPage = s), setTimeout(function() {
        return (0, i.event)(e, o, p);
    }, 20);
};

exports.genLogger = I;

var S = function(e, t, o) {
    e && setTimeout(function() {
        return (0, i.pageView)(e, t, r({}, o));
    }, 20);
};

exports.genLoggerPV = S;

var T = function(e, t) {
    e && !isNaN(e) && setTimeout(function() {
        return (0, i.pageExit)(e, r({}, t));
    }, 20);
};

exports.genLoggerExit = T;

var M = function(e, o, c) {
    var n = P(), a = t(n, 2), s = a[0], u = a[1], l = r(r({
        prevPage: u
    }, f), w());
    setTimeout(function() {
        return (0, i.click)(e, o, r(r(r({}, l), c), {}, {
            currPage: s
        }));
    }, 20);
};

exports.genLoggerClick = M;

exports.PV = function(e) {
    var i = P(), o = t(i, 2), c = o[0], n = o[1];
    if ("follow" === c && (c = y()), "404" === c) {
        e.ptype = {
            1: "album",
            2: "track"
        }[e.ptype];
    }
    v = c;
    var a = r(r({
        prevPage: n
    }, f), w());
    S(k[m.get(c)], c, r(r({}, a), e));
};

exports.PE = function(e) {
    var i = P(), o = t(i, 2), c = o[0], n = o[1];
    "follow" === c && (c = y());
    var a = r(r({
        prevPage: n
    }, f), w());
    return function() {
        return T(k[m.get(c)] + 1, r(r({
            currPage: c
        }, a), e));
    };
};

exports.trackNextTip = function() {
    I(13399, "exposure", {
        currModule: "tips",
        currPage: "track"
    });
};

exports.clickTrackNextTip = function(e) {
    M(13400, "tips", {
        trackId: e,
        currPage: "track"
    });
};

exports.clickTrackList = function(e) {
    M(13401, "trackList", {
        objItem: "track",
        objItemId: e,
        currPage: "track"
    });
};

exports.clickTrackRank = function(e, r) {
    M(13402, "rank", {
        clusterCode: e,
        albumId: r,
        currPage: "track"
    });
};

var A = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    M(e, "XX", r({
        currPage: "pointCenter"
    }, t));
};

exports.clickPointSeeMore = function() {
    A(17163);
};

exports.clickRecommandAlbum = function(e) {
    A(17162, {
        albumId: e
    });
};

exports.clickDrawAssistAward = function() {
    A(17161);
};

exports.clickInviteFriend = function() {
    A(17160);
};

exports.clickGzhTask = function(e) {
    A(17158, {
        item: e
    });
};

exports.clickWatchVideo = function(e) {
    A(17156, {
        item: e
    });
};

exports.clickHelpAlbum = function(e, r) {
    A(17376, {
        type: e,
        albumId: r
    });
};

exports.clickHelpBtn = function(e) {
    A(17375, {
        type: e
    });
};

exports.helpModalShow = function(e) {
    I(17374, "exposure", {
        currPage: "pointCenter",
        type: e
    });
};

exports.signinSuccessToast = function() {
    I(17155, "exposure", {
        currPage: "pointCenter"
    });
};

exports.clickSignin = function(e) {
    A(17154, {
        item: e
    });
};

exports.clickMineTab = function(e) {
    M(20393, "XX", {
        currPage: "my",
        moduleName: e
    });
};

exports.clickVipBar = function() {
    M(17135, "XX", {
        currPage: "my"
    });
};

exports.clickSigninEntrance = function() {
    M(17134, "XX", {
        currPage: "my"
    });
};

var L = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    M(e, "XX", r({
        currPage: "paid"
    }, t));
};

exports.clickFeedItem = function(e, r, t, i, o, c) {
    L(17133, {
        item: e,
        albumId: r,
        trackId: t,
        moduleName: i,
        recSrc: o,
        recTrack: c
    });
};

exports.clickPaidGuessAlbum = function(e) {
    L(17132, {
        albumId: e
    });
};

exports.clickStar = function(e) {
    L(17131, {
        albumId: e
    });
};

exports.clickRankAlbum = function(e) {
    L(17130, {
        albumId: e
    });
};

exports.clickTomato = function(e) {
    L(17129, {
        item: e
    });
};

exports.clickGetPoints = function() {
    L(17128);
};

exports.clickAnchorFollow = function(e, r) {
    M(17119, "XX", {
        currPage: "anchor",
        item: e,
        currPageId: r
    });
};

var q = function(e, t) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    M(e, t, r({
        currPage: "index"
    }, i));
};

exports.clickHotListenList = function(e) {
    q(17073, e);
};

exports.clickIndexModuleSeeMore = function(e, r) {
    q(17047, r, {
        moduleName: e
    });
};

exports.clickModuleAlbum = function(e, r, t) {
    q(17046, r, {
        moduleName: t,
        albumId: e
    });
};

exports.clickHeadline = function(e, r) {
    q(17045, r, {
        trackId: e
    });
};

exports.clickGuessChange = function(e) {
    q(17044, e);
};

exports.clickShareWeChat = function() {
    I(17113, "click", {});
};

exports.clickShareTimeline = function(e) {
    M(17832, "XX", {
        currPage: e
    });
};

exports.exposureLikeModal = function() {
    I(17848, "exposure", {
        currPage: "overall"
    });
};

exports.clickLikeModalShare = function() {
    M(17850, "XX", {
        currPage: "overall"
    });
};

exports.exposureSubsribeModal = function() {
    I(17847, "exposure", {
        currPage: "overall"
    });
};

exports.clickSubscribeModalShare = function() {
    M(17849, "XX", {
        currPage: "overall"
    });
};

exports.exposureModule = function(e, r) {
    I(e, "slipPage", r);
};