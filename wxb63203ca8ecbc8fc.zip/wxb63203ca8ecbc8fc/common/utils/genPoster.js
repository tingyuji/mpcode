Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createPoster = function(e, t, s, o) {
    var i = t.canvasW, l = t.canvasH, r = s.nickName, c = o.trackInfo, g = o.albumInfo, u = o.page, f = "pages/soundPage/soundPage" === u ? c.title : g.title, p = "pages/soundPage/soundPage" === u ? c.playCount : g.playCount, d = "pages/soundPage/soundPage" === u ? "“来自专辑：".concat(g.title, "”") : g.subTitle ? "“".concat(g.subTitle, "”") : g.subTitle, h = wx.getSystemInfoSync().platform, m = function(e) {
        return i * e / 360;
    };
    e.setFillStyle("#ECEDF1"), e.fillRect(0, 0, i, l), e.save(), e.setShadow(0, m(2), m(4), "#B8C0DF"), 
    e.drawImage(a, m(20), m(20), i - m(40), l - m(40)), e.restore(), e.setShadow(0, 0, 0, "rgba(0,0,0,0)"), 
    e.save(), e.font = "normal bold ".concat(~~m(16), "px ").concat("ios" == h || "devtools" == h ? "Helvetica" : "Noto"), 
    e.setFillStyle("#002800"), e.setFontSize(m(16)), e.setTextAlign("left"), e.fillText(r || "好友为你", m(90), m(62));
    var v = e.measureText(r || "好友为你").width / 2;
    e.setFillStyle("#F86442"), e.setTextAlign("left"), e.fillText("推荐", m(90 + v + 16), m(62)), 
    e.restore(), e.setFillStyle("#333333"), e.setFontSize(m(20)), e.setTextAlign("center");
    var x = n(f, e, i - 100);
    x.forEach(function(t, a) {
        e.fillText(t, i / 2, m(357 + 26 * a));
    }), e.setFillStyle("#4F4F4F"), e.setFontSize(m(12)), e.setTextAlign("left"), n(d, e, i - 100, 1).forEach(function(t, a) {
        e.fillText(t, m(47), m(90 + 18 * a));
    }), e.setFillStyle("#888888"), e.setFontSize(m(14)), e.setTextAlign("left"), e.fillText(p + "播放", m(150), m(394 + 20 * (x.length - 1))), 
    e.save(), e.drawImage("../../images/poster/poster_headphone.png", m(127), m(378 + 20 * (x.length - 1)), m(22), m(22)), 
    e.restore(), e.setFillStyle("#666666"), e.setFontSize(m(12)), e.setTextAlign("left"), 
    e.fillText("长按一起收听吧", m(235), m(517));
}, exports.downloadFile = void 0, exports.getImageInfoAndInitCanvas = function() {
    return new Promise(function(t, n) {
        wx.getSystemInfo({
            success: function(s) {
                console.log("shareImage", a);
                var o = s.screenWidth;
                wx.getImageInfo({
                    src: a,
                    success: function(a) {
                        t(e({
                            canvasW: .85 * o * 2,
                            canvasH: .85 * o * 2 * a.height / a.width
                        }, a));
                    },
                    fail: function() {
                        n();
                    }
                });
            }
        });
    });
}, exports.qrCodeDraw = function(e, a, n, s, o) {
    var i = a.canvasW, l = a.canvasH, r = function(e) {
        return i * e / 360;
    }, c = n[0].tempFilePath, g = n[1].tempFilePath, u = n[2].tempFilePath;
    e.save(), e.drawImage("../../images/poster/xm_logo.png", r(37), r(494), r(24), r(24)), 
    e.restore(), e.save(), e.drawImage("../../images/poster/logo_name.png", r(72), r(499), r(67), r(14)), 
    e.restore(), e.save(), e.beginPath(), e.arc(r(64), r(53), r(20), 0, 2 * Math.PI), 
    e.clip(), e.drawImage(g, r(44), r(33), r(40), r(40)), e.restore(), e.save(), e.beginPath(), 
    e.arc(i / 2, r(215), r(110 * Math.sqrt(2) - 8), 0, 2 * Math.PI), e.clip(), e.drawImage(u, r(71), r(105), r(220), r(220)), 
    e.restore(), e.save(), e.beginPath(), e.arc(r(276), r(466), r(28), 0, 2 * Math.PI), 
    e.clip(), e.drawImage(c, r(248), r(438), r(56), r(56)), e.restore(), e.draw(!1, function() {
        setTimeout(function() {
            wx.canvasToTempFilePath({
                x: 0,
                y: 0,
                width: i,
                height: l,
                canvasId: "poster",
                success: function(e) {
                    console.log(e, "canvas to temp file path"), "function" == typeof o && o(e);
                },
                fail: function(e) {
                    (0, t.showLongToast)({
                        icon: "none",
                        title: "生成失败，请稍后再试"
                    });
                }
            }, s);
        }, 300);
    });
};

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("./toast"), a = "../../images/poster/poster_bg.png";

function n(e, t, a) {
    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 2, s = 0, o = 0, i = !1;
    e.split("").forEach(function(e, l) {
        (s += t.measureText(e).width) < a * n - 50 * n ? o = Math.min(15, l) : i = !0;
    });
    var l = i ? 1 === n ? "...”" : "..." : "";
    return 1 === n ? [ e.substring(0, o - 1) + l ] : [ e.substring(0, Math.max(15, o)), e.substring(Math.max(15, o), 2 * Math.max(15, o) - 1) + l ];
}

exports.downloadFile = function(e) {
    return new Promise(function(t, a) {
        wx.downloadFile({
            url: e,
            success: function(e) {
                t(e);
            },
            fail: function(e) {
                a(e);
            }
        });
    });
};