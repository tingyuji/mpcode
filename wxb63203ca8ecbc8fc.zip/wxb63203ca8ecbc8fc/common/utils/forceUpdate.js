Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.forceUpdateWeixinVersion = function() {
    wx.canIUse("getUpdateManager") && (0, e.queryForceUpdateContent)().then(function(e) {
        if (e[0] && e[0].isForceUpdate) {
            var o = wx.getUpdateManager();
            o.onCheckForUpdate(function(e) {
                console.log("====onCheckForUpdate====", e), e.hasUpdate && (o.onUpdateReady(function() {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，请重启使用",
                        showCancel: !1,
                        success: function(e) {
                            console.log("更新成功 ====success=====", e), e.confirm && o.applyUpdate();
                        }
                    });
                }), o.onUpdateFailed(function() {
                    wx.showModal({
                        title: "已经有新版本了哟~",
                        content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
                    });
                }));
            });
        }
    });
};

var e = require("../apis/open-app");