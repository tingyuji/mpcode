Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = {
    parseNum: !0,
    throttle: !0,
    debounce: !0,
    formatRichText: !0,
    formatQARichText: !0,
    highlightKeyword: !0,
    formatCommentContent: !0,
    canIUse: !0,
    urlEncode: !0,
    copyPagePath: !0,
    getUrl: !0,
    getCurrPage: !0,
    getCompletePageUrl: !0,
    xmcdnImg: !0,
    getPageData: !0,
    setShareMenu: !0,
    hideAddToMyTip: !0,
    isIPhoneX: !0,
    getIdFromScene: !0,
    filterPaidRichIntro: !0,
    getLength: !0,
    flatArr: !0,
    insertBetween: !0,
    crossMergeArr: !0,
    imagev2: !0,
    image2Url: !0,
    getOriginImgUrl: !0,
    defaultUserImg: !0,
    fillImageUrl: !0,
    mpParse: !0
};

exports.canIUse = v, exports.copyPagePath = function(e) {
    var t = getCurrentPages(), r = t[t.length - 1], n = r.route, o = r.options, i = "?";
    for (var a in o) i += "".concat(a, "=").concat("albumId" === a || "trackId" === a ? e : o[a], "&");
    i = i.substr(0, i.length - 1);
    var u = new Date(), s = u.getFullYear(), c = (0, x.fillZero)(u.getMonth() + 1), p = (0, 
    x.fillZero)(u.getDate()), l = n + i;
    wx.setClipboardData({
        data: l + "&copy=1" + "&copydt=".concat(s + c + p),
        success: function(e) {
            wx.showToast({
                title: "页面路径复制成功",
                icon: "none"
            });
        }
    });
}, exports.crossMergeArr = function(e, t) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
    return t.forEach(function(t, n) {
        return e.splice(r * (n + 1) + n, 0, t);
    }), e;
}, exports.debounce = function(e) {
    var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 300, n = !1;
    return function() {
        var o = Array.prototype.slice.call(arguments, 0), i = this;
        if (n) return clearTimeout(t), void (t = setTimeout(function() {
            n = !1, e.apply(i, o);
        }, r));
        e.apply(i, o), n = !0, t = setTimeout(function() {
            n = !1;
        }, r);
    };
}, Object.defineProperty(exports, "defaultUserImg", {
    enumerable: !0,
    get: function() {
        return r.defaultUserImg;
    }
}), Object.defineProperty(exports, "fillImageUrl", {
    enumerable: !0,
    get: function() {
        return r.fillImageUrl;
    }
}), exports.filterPaidRichIntro = void 0, exports.flatArr = w, exports.formatCommentContent = function(e) {
    if (e.includes("<img")) return e = (e = e.replace(/\+/g, " ")).replace(/<img/g, '<img style="width:10px;"'), 
    '<span style="line-height: 18px;">'.concat(e, "</span>");
    return e;
}, exports.formatQARichText = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = b(e);
    return t = t.replace(/<p/gi, '<p style="margin-top:5px;min-height:15px;"');
}, exports.formatRichText = b, exports.getCompletePageUrl = function() {
    var e = j();
    return P(e.options, e.route);
}, exports.getCurrPage = j, exports.getLength = exports.getIdFromScene = void 0, 
Object.defineProperty(exports, "getOriginImgUrl", {
    enumerable: !0,
    get: function() {
        return r.getOriginImgUrl;
    }
}), exports.getPageData = function() {
    var e = getCurrentPages(), t = e[e.length - 1], r = e[e.length - 2], n = {}, o = {};
    t && (n = t.data);
    r && (o = r.data);
    return [ n, o ];
}, exports.getUrl = P, exports.hideAddToMyTip = function() {
    var e = getApp();
    return (0, s.isIos)() && 1089 == e.scene || (0, s.isIos)() && 1001 == e.scene || (0, 
    s.isAndroid)() && 1023 == e.scene;
}, exports.highlightKeyword = function(e) {
    return e = e.replace(/(<em+[^>]*>)/g, function() {
        return ' style="color:#fe7959; font-style:normal;"', ">", '<em style="color:#fe7959; font-style:normal;">';
    });
}, Object.defineProperty(exports, "image2Url", {
    enumerable: !0,
    get: function() {
        return r.image2Url;
    }
}), exports.imagev2 = function(e) {
    var t = e;
    if (/^^\/\/s1.xmcdn.com/.test(t)) return "https:" + t;
    if (/^http\:/.test(t)) return t.replace("http", "https");
    if (/^https\:\/\/fdfs.xmcdn.com/.test(t)) return t;
    /^\/\//.test(t) && (t = "https:" + t);
    /^http/.test(t) || (t = "https://imagev2.xmcdn.com/" + t);
    /.(png|jpe?g)$/.test(t) && (t += "!strip=1&quality=7&op_type=5&upload_type=cover&name=web_large&device_type=ios");
    return t;
}, exports.insertBetween = function(e, t, r) {
    var n = [], o = e.length;
    if (o < t) return e;
    for (var i = 0; i < o; i += t) n.push(e.slice(i, i + t));
    return n.forEach(function(e) {
        e.push(r);
    }), w(n);
}, exports.isIPhoneX = void 0, Object.defineProperty(exports, "mpParse", {
    enumerable: !0,
    get: function() {
        return o.mpParse;
    }
}), exports.parseNum = function(e) {
    if (void 0 === e) return;
    return e = Number(e), (e = isNaN(e) ? 0 : e) >= 0 ? y(e) : "-" + y(Math.abs(e));
}, exports.setShareMenu = function() {
    v("showShareMenu") && wx.showShareMenu({
        menus: [ "shareAppMessage", "shareTimeline" ]
    });
}, exports.throttle = void 0, exports.urlEncode = O, exports.xmcdnImg = function() {
    return "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/wx_images/images";
};

var t = require("../../@babel/runtime/helpers/typeof");

require("../../@babel/runtime/helpers/Arrayincludes");

var r = require("./image"), n = require("./env");

Object.keys(n).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === n[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return n[t];
        }
    }));
});

var o = require("../../packages/parse-html/index"), i = require("./underscore");

Object.keys(i).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === i[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return i[t];
        }
    }));
});

var a = require("./navigate");

Object.keys(a).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === a[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return a[t];
        }
    }));
});

var u = require("./humanizeCount");

Object.keys(u).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === u[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return u[t];
        }
    }));
});

var s = require("./navBar");

Object.keys(s).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === s[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return s[t];
        }
    }));
});

var c = require("./drawSharePic");

Object.keys(c).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === c[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return c[t];
        }
    }));
});

var p = require("./wxSubscribe");

Object.keys(p).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === p[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return p[t];
        }
    }));
});

var l = require("./imgAddress");

Object.keys(l).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === l[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return l[t];
        }
    }));
});

var f = require("./myAdapter");

Object.keys(f).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === f[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return f[t];
        }
    }));
});

var g = require("./storage");

Object.keys(g).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === g[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return g[t];
        }
    }));
});

var d = require("./adIds");

Object.keys(d).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === d[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return d[t];
        }
    }));
});

var h = require("./wxCookie");

Object.keys(h).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === h[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return h[t];
        }
    }));
});

var m = require("./setTDK");

Object.keys(m).forEach(function(t) {
    "default" !== t && "__esModule" !== t && (Object.prototype.hasOwnProperty.call(e, t) || t in exports && exports[t] === m[t] || Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return m[t];
        }
    }));
});

var x = require("./time");

function y(e) {
    var t = 1e4;
    return e < 1e4 ? e : e < 1e8 ? (e /= t).toFixed(2) + "万" : (e /= t *= 1e4).toFixed(2) + "亿";
}

function b() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = e.replace(/<img[^>]*>/gi, function(e) {
        return e = (e = (e = e.replace(/style='[^']+'/gi, "")).replace(/width='[^']+'/gi, "")).replace(/height='[^']+'/gi, "");
    });
    return t = (t = (t = t.replace(/style="[^"]+"/gi, function(e) {
        return e = e.replace(/width:[^;]+;/gi, "max-width:100%;");
    })).replace(/<br[^>]*\/>/gi, "")).replace(/<img/gi, '<img style="max-width:100%;height:auto;display:block;margin-top:0;margin-bottom:0;"');
}

function v(e) {
    return "function" == typeof wx.canIUse && wx.canIUse(e);
}

function O(e, r, n) {
    if (null == e) return "";
    var o = "", i = t(e);
    if ("string" == i || "number" == i || "boolean" == i) o += "&" + r + "=" + (null == n || n ? encodeURIComponent(e) : e); else for (var a in e) {
        var u = null == r ? a : r + (e instanceof Array ? "[" + a + "]" : "." + a);
        o += O(e[a], u, n);
    }
    return o;
}

function P(e, t) {
    var r = O(e);
    return r ? t + "?" + r.slice(1) : t;
}

function j() {
    return (getCurrentPages() || []).pop() || {};
}

exports.throttle = function(e) {
    var t, r, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 100, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 200, i = !1, a = function() {
        if (i) return !1;
        var a = Array.prototype.slice.call(arguments, 0), u = this, s = Date.now();
        r && s < r + o ? (clearTimeout(t), t = setTimeout(function() {
            r = s, e.apply(u, a);
        }, n)) : (r = s, e.apply(u, a));
    };
    return a.destroy = function() {
        clearTimeout(t), i = !0;
    }, a;
};

exports.isIPhoneX = function() {
    var e = wx.getSystemInfoSync(), t = e.screenHeight, r = e.safeArea;
    return t !== (r ? r.bottom : t);
};

exports.getIdFromScene = function(e) {
    if (!e.indexOf(",")) return e;
    var t = e.split(",");
    return t[0] && t[0].toString().length > 4 ? t[0] : void 0;
};

exports.filterPaidRichIntro = function(e) {
    return e.replace(/<p(([\s\S](?!<p))*?)购买须知[\s\S]*/g, "");
};

function w(e) {
    var t = [];
    return e.forEach(function(e) {
        Array.isArray(e) ? t = t.concat(e) : t.push(e);
    }), t;
}

exports.getLength = function(e) {
    return e.replace(/[\u0391-\uFFE5]/g, "aa").length;
};