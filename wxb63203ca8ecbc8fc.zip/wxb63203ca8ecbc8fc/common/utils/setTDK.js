Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setNavigationBarTitle = function(e) {
    wx.setNavigationBarTitle({
        title: unescape("".concat(e, "-喜马拉雅"))
    }).then(function(e) {
        console.log(e, "设置页面标题 success");
    }, function(e) {
        console.log("设置页面标题 err", e);
    });
};