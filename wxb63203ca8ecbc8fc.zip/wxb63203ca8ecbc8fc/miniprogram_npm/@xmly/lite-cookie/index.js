var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../@babel/runtime/helpers/slicedToArray"), i = require("../../../@babel/runtime/helpers/createForOfIteratorHelper");

require("../../../@babel/runtime/helpers/Arrayincludes");

var o, r, n = require("../../../@babel/runtime/helpers/classCallCheck"), a = require("../../../@babel/runtime/helpers/createClass"), s = require("../../../@babel/runtime/helpers/typeof");

module.exports = (o = {}, r = function(e, t) {
    if (!o[e]) return require(t);
    if (!o[e].status) {
        var i = o[e].m;
        i._exports = i._tempexports;
        var r = Object.getOwnPropertyDescriptor(i, "exports");
        r && r.configurable && Object.defineProperty(i, "exports", {
            set: function(e) {
                "object" === s(e) && e !== i._exports && (i._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    i._exports[t] = e[t];
                })), i._tempexports = e;
            },
            get: function() {
                return i._tempexports;
            }
        }), o[e].status = 1, o[e].func(o[e].req, i, i.exports);
    }
    return o[e].m.exports;
}, function(e, t, i) {
    o[e] = {
        status: 0,
        func: t,
        req: i,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1690770624130, function(o, r, s) {
    function u() {
        return "undefined" != typeof wx ? "undefined" != typeof window && "undefined" != typeof location ? {
            platform: "none"
        } : (wx.platform = "wx", wx) : "undefined" != typeof my ? (my.platform = "my", my) : "undefined" != typeof swan ? (swan.platform = "swan", 
        swan) : "undefined" != typeof ks ? (ks.platform = "ks", ks) : "undefined" != typeof xm ? (xm.platform = "xm", 
        xm) : "undefined" != typeof tt ? (tt.platform = "tt", tt) : "undefined" != typeof qa ? (qa.platform = "qa", 
        qa) : {
            platform: "none"
        };
    }
    Object.defineProperty(s, "__esModule", {
        value: !0
    });
    var l = u(), c = function() {
        function e(t) {
            n(this, e), this.api = t;
        }
        return a(e, [ {
            key: "getItem",
            value: function(e) {
                return "my" === this.api.platform ? this.api.getStorageSync({
                    key: e
                }).data : this.api.getStorageSync(e);
            }
        }, {
            key: "setItem",
            value: function(e, t) {
                "my" === this.api.platform ? this.api.setStorageSync({
                    key: e,
                    data: t
                }) : this.api.setStorageSync(e, t);
            }
        } ]), e;
    }(), p = {
        decodeValues: !0,
        map: !1,
        silent: !1
    };
    function h(e) {
        return "string" == typeof e && !!e.trim();
    }
    function f(e, t) {
        var i = e.split(";").filter(h), o = i.shift().split("="), r = o.shift(), n = o.join("="), a = {
            name: r,
            value: (t = t ? Object.assign({}, p, t) : p).decodeValues ? decodeURIComponent(n) : n
        };
        return i.forEach(function(e) {
            var t = e.split("="), i = t.shift().trimLeft().toLowerCase(), o = t.join("=");
            "expires" === i ? a.expires = new Date(o) : "max-age" === i ? a.maxAge = parseInt(o, 10) : "secure" === i ? a.secure = !0 : "httponly" === i ? a.httpOnly = !0 : "samesite" === i ? a.sameSite = o : a[i] = o;
        }), a;
    }
    function d(e, t) {
        if (t = t ? Object.assign({}, p, t) : p, !e) return t.map ? {} : [];
        if (e.headers && e.headers["set-cookie"]) e = e.headers["set-cookie"]; else if (e.headers) {
            var i = e.headers[Object.keys(e.headers).find(function(e) {
                return "set-cookie" === e.toLowerCase();
            })];
            i || !e.headers.cookie || t.silent || console.warn("Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."), 
            e = i;
        }
        return Array.isArray(e) || (e = [ e ]), (t = t ? Object.assign({}, p, t) : p).map ? e.filter(h).reduce(function(e, i) {
            var o = f(i, t);
            return e[o.name] = o, e;
        }, {}) : e.filter(h).map(function(e) {
            return f(e, t);
        });
    }
    var v = d, m = d, k = f, g = function(e) {
        if (Array.isArray(e)) return e;
        if ("string" != typeof e) return [];
        var t, i, o, r, n, a = [], s = 0;
        function u() {
            for (;s < e.length && /\s/.test(e.charAt(s)); ) s += 1;
            return s < e.length;
        }
        for (;s < e.length; ) {
            for (t = s, n = !1; u(); ) if ("," === (i = e.charAt(s))) {
                for (o = s, s += 1, u(), r = s; s < e.length && "=" !== (i = e.charAt(s)) && ";" !== i && "," !== i; ) s += 1;
                s < e.length && "=" === e.charAt(s) ? (n = !0, s = r, a.push(e.substring(t, o)), 
                t = s) : s = o + 1;
            } else s += 1;
            (!n || s >= e.length) && a.push(e.substring(t, e.length));
        }
        return a;
    };
    v.parse = m, v.parseString = k, v.splitCookiesString = g;
    var y = new (function() {
        function e() {
            n(this, e);
        }
        return a(e, [ {
            key: "getCookieScopeDomain",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                if (!e) return [];
                var t = (e = e.replace(/^\.+/gi, "")).split(".").map(function(t) {
                    return [ ".", e.slice(e.indexOf(t)) ].join("");
                });
                return [ e ].concat(t);
            }
        }, {
            key: "normalizeDomain",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return e.replace(/^(\.*)?(?=\S)/gi, ".");
            }
        } ]), e;
    }())(), x = function() {
        function e(t) {
            n(this, e), this.name = t.name, this.value = t.value, this.domain = t.domain || "", 
            this.path = t.path || "/", this.expires = t.expires ? new Date(t.expires) : void 0, 
            this.maxAge = t.maxAge, this.httpOnly = !!t.httpOnly, this.dateTime = t.dateTime ? new Date(t.dateTime) : new Date();
        }
        return a(e, [ {
            key: "expired",
            get: function() {
                return void 0 !== this.maxAge ? this.maxAge <= 0 || (Date.now() - this.dateTime.getTime()) / 1e3 > this.maxAge : void 0 !== this.expires && this.expires < new Date();
            }
        }, {
            key: "isPermanent",
            get: function() {
                return !(void 0 === this.maxAge && void 0 === this.expires);
            }
        }, {
            key: "isInDomain",
            value: function(e) {
                return y.getCookieScopeDomain(e).includes(this.domain);
            }
        }, {
            key: "isInPath",
            value: function(e) {
                return this.path === e || 0 === e.indexOf(this.path) && this.path.lastIndexOf("/") === this.path.length - 1 || 0 === e.indexOf("".concat(this.path, "/"));
            }
        }, {
            key: "toString",
            value: function() {
                return "" !== this.name ? [ this.name, this.value ].join("=") : this.value;
            }
        } ]), e;
    }(), w = function() {
        function e(t) {
            n(this, e), this.storageKey = "__cookie_store__", this.store = t, this.cookiesMap = this.readFromStorage();
        }
        return a(e, [ {
            key: "has",
            value: function(e, t, i) {
                return void 0 !== this.getCookie(e, t, i);
            }
        }, {
            key: "get",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, i = arguments.length > 2 ? arguments[2] : void 0, o = this.getCookie(e, t, i);
                return o ? o.value : void 0;
            }
        }, {
            key: "set",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, o = i.domain;
                if (!o || !e) throw new Error("name 和 options.domain 值不正确！");
                var r = new x(Object.assign(i, {
                    name: e,
                    value: t
                })), n = this.cookiesMap.get(o) || new Map();
                return n.set(e, r), this.cookiesMap.set(o, n), this.saveToStorage(this.cookiesMap), 
                r;
            }
        }, {
            key: "remove",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                if (t) {
                    var o = this.cookiesMap.get(t);
                    o && o.delete(e), (o = this.cookiesMap.get(y.normalizeDomain(t))) && o.delete(e);
                } else {
                    var r, n = i(this.cookiesMap.values());
                    try {
                        for (n.s(); !(r = n.n()).done; ) {
                            var a = r.value;
                            a.delete(e);
                        }
                    } catch (e) {
                        n.e(e);
                    } finally {
                        n.f();
                    }
                }
                return this.saveToStorage(this.cookiesMap);
            }
        }, {
            key: "clear",
            value: function(e) {
                if (e) {
                    var t = this.cookiesMap.get(e);
                    t && t.clear();
                } else this.cookiesMap.clear();
                return this.saveToStorage(this.cookiesMap);
            }
        }, {
            key: "dir",
            value: function() {
                var e, t = {}, o = i(this.cookiesMap.keys());
                try {
                    for (o.s(); !(e = o.n()).done; ) {
                        var r = e.value, n = this.getCookies(r);
                        t[r] = n.reduce(function(e, t) {
                            return e[t.name] = t.value, e;
                        }, {});
                    }
                } catch (e) {
                    o.e(e);
                } finally {
                    o.f();
                }
                return t;
            }
        }, {
            key: "getCookie",
            value: function() {
                var e, o, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "/", s = y.getCookieScopeDomain(n), u = i(this.cookiesMap.entries());
                try {
                    for (u.s(); !(o = u.n()).done; ) {
                        var l = t(o.value, 2), c = l[0], p = l[1];
                        if (!(n && s.indexOf(c) < 0)) {
                            if ((e = p.get(r)) && e.isInPath(a) && !e.expired) break;
                            e = void 0;
                        }
                    }
                } catch (e) {
                    u.e(e);
                } finally {
                    u.f();
                }
                return e;
            }
        }, {
            key: "getCookies",
            value: function() {
                var e, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/", n = [], a = y.getCookieScopeDomain(o), s = i(this.cookiesMap.entries());
                try {
                    for (s.s(); !(e = s.n()).done; ) {
                        var u = t(e.value, 2), l = u[0], c = u[1];
                        if (!(o && a.indexOf(l) < 0)) {
                            var p, h = i(c.values());
                            try {
                                for (h.s(); !(p = h.n()).done; ) {
                                    var f = p.value;
                                    f.isInPath(r) && !f.expired && n.push(f);
                                }
                            } catch (e) {
                                h.e(e);
                            } finally {
                                h.f();
                            }
                        }
                    }
                } catch (e) {
                    s.e(e);
                } finally {
                    s.f();
                }
                return n;
            }
        }, {
            key: "makeCookiesMap",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Map();
                return e.forEach(function(e) {
                    var i = t.get(e.domain);
                    i || (i = new Map(), t.set(e.domain, i)), i.set(e.name, e);
                }), t;
            }
        }, {
            key: "setCookies",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                return this.cookiesMap = this.makeCookiesMap(e, this.cookiesMap), this.saveToStorage(this.cookiesMap), 
                this.cookiesMap;
            }
        }, {
            key: "parse",
            value: function(e, t) {
                return v.parse(v.splitCookiesString(e), {
                    decodeValues: !1
                }).map(function(e) {
                    return e.domain = y.normalizeDomain(e.domain || t), new x(e);
                });
            }
        }, {
            key: "getRequestCookies",
            value: function(e, t) {
                var i = this.getCookies(e, t);
                return this.stringify(i);
            }
        }, {
            key: "setResponseCookies",
            value: function(e, t) {
                var i = this.parse(e, t);
                return this.setCookies(i);
            }
        }, {
            key: "stringify",
            value: function(e) {
                return e.map(function(e) {
                    return e.toString();
                }).join("; ");
            }
        }, {
            key: "saveToStorage",
            value: function(e) {
                try {
                    var t, o = [], r = i(e.values());
                    try {
                        for (r.s(); !(t = r.n()).done; ) {
                            var n, a = t.value, s = i(a.values());
                            try {
                                for (s.s(); !(n = s.n()).done; ) {
                                    var u = n.value;
                                    u.isPermanent && (u.expired ? a.delete(u.name) : o.push(u));
                                }
                            } catch (e) {
                                s.e(e);
                            } finally {
                                s.f();
                            }
                        }
                    } catch (e) {
                        r.e(e);
                    } finally {
                        r.f();
                    }
                    return this.store.setItem(this.storageKey, o), !0;
                } catch (e) {
                    return console.warn("Cookie 存储异常：", e), !1;
                }
            }
        }, {
            key: "readFromStorage",
            value: function() {
                try {
                    var e = (this.store.getItem(this.storageKey) || []).map(function(e) {
                        return new x(e);
                    });
                    return this.makeCookiesMap(e);
                } catch (e) {
                    return console.warn("Cookie 读取异常：", e), new Map();
                }
            }
        } ]), e;
    }();
    if ("none" === l.platform) throw new Error("lite-cookie 支持运行在微信、支付宝、百度、喜马、头条小程序和快应用环境下，暂不支持当前运行环境");
    var C = function() {
        var t = new w(new c(l));
        function i(i) {
            return function(o) {
                return i(function(t, i) {
                    var o = i.url, r = i.cookie, n = void 0 === r || r, a = i.dataType, s = void 0 === a ? "json" : a, u = i.header, l = void 0 === u ? {} : u, c = i.headers, p = void 0 === c ? {} : c, h = i.success, f = l, d = p;
                    f["X-Requested-With"] = "XMLHttpRequest", d["X-Requested-With"] = "XMLHttpRequest", 
                    "json" === s && (f.Accept = "application/json, text/plain, */*", d.Accept = "application/json, text/plain, */*");
                    var v = h;
                    if (n) {
                        var m = o.split("/")[2], k = o.split(m).pop(), g = t.getRequestCookies(m, k);
                        f.Cookie = g, d.Cookie = g, v = function(e) {
                            e.header = e.header || e.headers || {};
                            var i = e.header["Set-Cookie"] || e.header["set-cookie"];
                            i && t.setResponseCookies(i, m), e.cookies && t.setResponseCookies(e.cookies, m), 
                            h && h(e);
                        };
                    }
                    return e(e({}, i), {}, {
                        dataType: s,
                        header: f,
                        headers: d,
                        success: v
                    });
                }(t, o));
            };
        }
        var o = l.request, r = l.uploadFile, n = l.downloadFile, a = i(o), s = i(r), u = i(n);
        try {
            Object.defineProperties(l, {
                request: {
                    value: a
                },
                uploadFile: {
                    value: s
                },
                downloadFile: {
                    value: u
                }
            });
        } catch (e) {
            throw new Error("lite-cookie: ".concat(e.message));
        }
        return Object.defineProperties(t, {
            eject: {
                value: function() {
                    return Object.defineProperties(l, {
                        request: {
                            value: o
                        },
                        uploadFile: {
                            value: r
                        },
                        downloadFile: {
                            value: n
                        }
                    }), {
                        request: a,
                        uploadFile: s,
                        downloadFile: u
                    };
                }
            }
        }), t;
    }();
    s.default = C;
}, function(e) {
    return r({}[e], e);
}), r(1690770624130));