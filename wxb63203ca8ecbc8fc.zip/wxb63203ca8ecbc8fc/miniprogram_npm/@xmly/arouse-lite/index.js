var e = require("../../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    return (t = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
        return e;
    }).apply(this, arguments);
};

function n(e, t, n, r) {
    return new (n || (n = Promise))(function(o, a) {
        function i(e) {
            try {
                c(r.next(e));
            } catch (e) {
                a(e);
            }
        }
        function u(e) {
            try {
                c(r.throw(e));
            } catch (e) {
                a(e);
            }
        }
        function c(e) {
            var t;
            e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                e(t);
            })).then(i, u);
        }
        c((r = r.apply(e, t || [])).next());
    });
}

function r(e, t) {
    var n, r, o, a, i = {
        label: 0,
        sent: function() {
            if (1 & o[0]) throw o[1];
            return o[1];
        },
        trys: [],
        ops: []
    };
    return a = {
        next: u(0),
        throw: u(1),
        return: u(2)
    }, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
        return this;
    }), a;
    function u(a) {
        return function(u) {
            return function(a) {
                if (n) throw new TypeError("Generator is already executing.");
                for (;i; ) try {
                    if (n = 1, r && (o = 2 & a[0] ? r.return : a[0] ? r.throw || ((o = r.return) && o.call(r), 
                    0) : r.next) && !(o = o.call(r, a[1])).done) return o;
                    switch (r = 0, o && (a = [ 2 & a[0], o.value ]), a[0]) {
                      case 0:
                      case 1:
                        o = a;
                        break;

                      case 4:
                        return i.label++, {
                            value: a[1],
                            done: !1
                        };

                      case 5:
                        i.label++, r = a[1], a = [ 0 ];
                        continue;

                      case 7:
                        a = i.ops.pop(), i.trys.pop();
                        continue;

                      default:
                        if (!(o = i.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== a[0] && 2 !== a[0])) {
                            i = 0;
                            continue;
                        }
                        if (3 === a[0] && (!o || a[1] > o[0] && a[1] < o[3])) {
                            i.label = a[1];
                            break;
                        }
                        if (6 === a[0] && i.label < o[1]) {
                            i.label = o[1], o = a;
                            break;
                        }
                        if (o && i.label < o[2]) {
                            i.label = o[2], i.ops.push(a);
                            break;
                        }
                        o[2] && i.ops.pop(), i.trys.pop();
                        continue;
                    }
                    a = t.call(e, i);
                } catch (e) {
                    a = [ 6, e ], r = 0;
                } finally {
                    n = o = 0;
                }
                if (5 & a[0]) throw a[1];
                return {
                    value: a[0] ? a[1] : void 0,
                    done: !0
                };
            }([ a, u ]);
        };
    }
}

var o = {
    XM_ENV: "production"
};

var a = "object" === ("undefined" == typeof qa ? "undefined" : e(qa)), i = "object" === ("undefined" == typeof swan ? "undefined" : e(swan)), u = "object" === ("undefined" == typeof ks ? "undefined" : e(ks)), c = "object" === ("undefined" == typeof wx ? "undefined" : e(wx));

function s() {
    return a ? qa : i ? swan : u ? ks : c ? wx : xm;
}

function f(t, o) {
    return n(this, void 0, void 0, function() {
        var n, i, u, f, l, d, p, h, m, y, v, b, g, w, x, S, k;
        return r(this, function(r) {
            switch (r.label) {
              case 0:
                return a ? [ 4, s().getSystemInfoSync() ] : [ 3, 2 ];

              case 1:
                return u = r.sent().osType, n = u, i = "qa", [ 3, 3 ];

              case 2:
                f = s().getSystemInfoSync(), l = f.platform, d = f.host, n = l, i = d, c && (i = "wx"), 
                r.label = 3;

              case 3:
                3, p = +new Date();
                try {
                    a ? (g = require("@system.router"), h = o || g.getState().path) : (w = getCurrentPages(), 
                    o ? h = o : (x = w[w.length - 1], S = function(t) {
                        if ("object" !== e(t)) return "";
                        var n = "";
                        for (var r in t) t[r] && (n += r + "=" + t[r] + "&");
                        return n.slice(0, n.length - 1);
                    }(x.options), h = S ? x.route + "?" + S : x.route)), h && (k = function(e, t) {
                        try {
                            var n = decodeURIComponent(t).split(/[?&]/).slice(1);
                            if (!n.length) return "";
                            var r, o, a = {};
                            return n.forEach(function(e) {
                                var t = e.indexOf("=");
                                r = e.substring(0, t), o = e.substring(t + 1), a[r] = o;
                            }), e ? a[e] || "" : a;
                        } catch (t) {
                            return e ? "" : {};
                        }
                    }("", h), m = k.shareLevel || 0, y = k.commandShareId, v = k.utm_source, b = k.shareTime);
                } catch (e) {}
                return [ 2, {
                    os: n,
                    clickType: 3,
                    ts: p,
                    openChannel: i,
                    shareLevel: m || 0,
                    commandShareId: y,
                    ximaCid: t,
                    pageUrl: h || "/page/default/index",
                    shareContentType: "URL",
                    shareTime: b || +new Date(),
                    utmSource: v
                } ];
            }
        });
    });
}

function l(e) {
    var t = e.data, n = e.request;
    return new Promise(function(e, r) {
        var a = "https://m" + ("production" === o.XM_ENV ? "." : ".test.") + "ximalaya.com/command-service/createShareCommand";
        (n || s().request)({
            data: t,
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            dataType: "json",
            url: a,
            success: function(t) {
                0 == t.data.ret ? e(t.data.command) : r(t);
            },
            fail: function(e) {
                r(e);
            }
        });
    });
}

exports.copyHandle = function(e) {
    var o = e.cid, a = e.success, i = e.extraInfo, u = e.currentPage, c = e.link, d = void 0 === c ? "iting://open" : c, p = e.request;
    return n(this, void 0, void 0, function() {
        var e, n, c;
        return r(this, function(r) {
            switch (r.label) {
              case 0:
                return o ? [ 4, f(o, u) ] : [ 2 ];

              case 1:
                return e = r.sent(), n = e.pageUrl, /^http(|s):/.test(d) && (d = "iting://open?msg_type=14&url=" + encodeURIComponent(d)), 
                c = "https://m.ximalaya.com/lite?lite_page=" + encodeURIComponent(n) + "&iting=" + encodeURIComponent(d), 
                [ 2, l({
                    data: function(e, t) {
                        var n = e, r = {};
                        if (t) {
                            for (var o in t) t[o] && ("utm_source" === o ? n.utmSource = t[o] : r[o] = t[o]);
                            Object.keys(r).length > 0 && (n.extraInfo = JSON.stringify(r));
                        }
                        return n;
                    }(t(t({}, e), {
                        link: c
                    }), i),
                    request: p
                }).then(function(e) {
                    return a && a(e), s().setClipboardData({
                        data: e,
                        success: function() {
                            s().hideToast();
                        }
                    }), e;
                }) ];
            }
        });
    });
}, exports.getBaseParams = f, exports.setEnv = function(e) {
    o.XM_ENV = e ? "production" : "test";
};