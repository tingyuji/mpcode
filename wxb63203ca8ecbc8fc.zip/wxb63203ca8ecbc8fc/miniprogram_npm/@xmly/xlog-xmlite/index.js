require("../../../@babel/runtime/helpers/Arrayincludes");

var e, t, n, r = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, n = function(t, n) {
    if (!e[t]) return require(n);
    if (!e[t].status) {
        var i = e[t].m;
        i._exports = i._tempexports;
        var o = Object.getOwnPropertyDescriptor(i, "exports");
        o && o.configurable && Object.defineProperty(i, "exports", {
            set: function(e) {
                "object" === r(e) && e !== i._exports && (i._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    i._exports[t] = e[t];
                })), i._tempexports = e;
            },
            get: function() {
                return i._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, i, i.exports);
    }
    return e[t].m.exports;
}, (t = function(t, n, r) {
    e[t] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1690770624131, function(e, t, n) {
    var r = this && this.__createBinding || (Object.create ? function(e, t, n, r) {
        void 0 === r && (r = n), Object.defineProperty(e, r, {
            enumerable: !0,
            get: function() {
                return t[n];
            }
        });
    } : function(e, t, n, r) {
        void 0 === r && (r = n), e[r] = t[n];
    }), i = this && this.__exportStar || function(e, t) {
        for (var n in e) "default" === n || t.hasOwnProperty(n) || r(t, e, n);
    }, o = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.xmLog = n.start = void 0, e("@xmly/lite-cookie");
    var a = o(e("./xmlog"));
    n.xmLog = a.default;
    var u = e("./utils/app"), s = e("./utils/data"), c = e("./config");
    n.start = function(e) {
        var t = e.b, n = e.c, r = e.e, i = e.p, o = e.d;
        if (!t) throw new Error("config option: bussinessId is missing");
        u.info.bId = t, n && s.setCustomCommon(n), r && c.setEnv(r), o && c.setDebugMode(o), 
        i && c.setPlatform(i);
    }, i(e("./ubt/index"), n), i(e("./constants"), n);
}, function(e) {
    return n({
        "./xmlog": 1690770624132,
        "./utils/app": 1690770624138,
        "./utils/data": 1690770624145,
        "./config": 1690770624137,
        "./ubt/index": 1690770624146,
        "./constants": 1690770624140
    }[e], e);
}), t(1690770624132, function(e, t, n) {
    var r = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var i = r(e("./tracker")), o = e("../config"), a = !1, u = function() {
        function e(e) {
            this.tracker = new i.default(e);
        }
        return e.start = function(e) {
            var t = e.e, n = e.p;
            a || (t && o.setEnv(t), n && o.setPlatform(n), t && n && (a = !0));
        }, e.init = function(t, n) {
            a && e.defaultTracker.init(t, n);
        }, e.event = function(t) {
            a && e.defaultTracker.event(t);
        }, e.pageView = function(t) {
            a && e.defaultTracker.pageView(t);
        }, e.pageview = function(t) {
            a && e.defaultTracker.pageView(t);
        }, e.prototype.event = function(e) {
            a && this.tracker.event(e);
        }, e.prototype.pageview = function(e) {
            a && this.tracker.pageView(e);
        }, e.prototype.pageView = function(e) {
            a && this.tracker.pageView(e);
        }, e.defaultTracker = new i.default({}), e;
    }();
    n.default = u;
}, function(e) {
    return n({
        "./tracker": 1690770624133,
        "../config": 1690770624137
    }[e], e);
}), t(1690770624133, function(e, t, n) {
    var r = this && this.__createBinding || (Object.create ? function(e, t, n, r) {
        void 0 === r && (r = n), Object.defineProperty(e, r, {
            enumerable: !0,
            get: function() {
                return t[n];
            }
        });
    } : function(e, t, n, r) {
        void 0 === r && (r = n), e[r] = t[n];
    }), i = this && this.__setModuleDefault || (Object.create ? function(e, t) {
        Object.defineProperty(e, "default", {
            enumerable: !0,
            value: t
        });
    } : function(e, t) {
        e.default = t;
    }), o = this && this.__importStar || function(e) {
        if (e && e.__esModule) return e;
        var t = {};
        if (null != e) for (var n in e) "default" !== n && Object.hasOwnProperty.call(e, n) && r(t, e, n);
        return i(t, e), t;
    }, a = this && this.__awaiter || function(e, t, n, r) {
        return new (n || (n = Promise))(function(i, o) {
            function a(e) {
                try {
                    s(r.next(e));
                } catch (e) {
                    o(e);
                }
            }
            function u(e) {
                try {
                    s(r.throw(e));
                } catch (e) {
                    o(e);
                }
            }
            function s(e) {
                var t;
                e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                    e(t);
                })).then(a, u);
            }
            s((r = r.apply(e, t || [])).next());
        });
    }, u = this && this.__generator || function(e, t) {
        var n, r, i, o, a = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1];
            },
            trys: [],
            ops: []
        };
        return o = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
            return this;
        }), o;
        function u(o) {
            return function(u) {
                return function(o) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 
                        0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                        switch (r = 0, i && (o = [ 2 & o[0], i.value ]), o[0]) {
                          case 0:
                          case 1:
                            i = o;
                            break;

                          case 4:
                            return a.label++, {
                                value: o[1],
                                done: !1
                            };

                          case 5:
                            a.label++, r = o[1], o = [ 0 ];
                            continue;

                          case 7:
                            o = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                a.label = o[1];
                                break;
                            }
                            if (6 === o[0] && a.label < i[1]) {
                                a.label = i[1], i = o;
                                break;
                            }
                            if (i && a.label < i[2]) {
                                a.label = i[2], a.ops.push(o);
                                break;
                            }
                            i[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        o = t.call(e, a);
                    } catch (e) {
                        o = [ 6, e ], r = 0;
                    } finally {
                        n = i = 0;
                    }
                    if (5 & o[0]) throw o[1];
                    return {
                        value: o[0] ? o[1] : void 0,
                        done: !0
                    };
                }([ o, u ]);
            };
        }
    }, s = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.temData = void 0;
    var c = e("../utils/obj"), l = e("../utils/tool"), f = e("./share"), p = s(e("./report")), d = e("./collect"), h = o(e("../platform/storage"));
    function m() {
        return a(this, void 0, void 0, function() {
            var e;
            return u(this, function(t) {
                switch (t.label) {
                  case 0:
                    return e = {}, [ 4, h.get("srcPage") ];

                  case 1:
                    return e.srcPage = t.sent() || "", [ 4, h.get("srcPageId") ];

                  case 2:
                    return e.srcPageId = t.sent() || "", [ 4, h.get("srcModule") ];

                  case 3:
                    return e.srcModule = t.sent() || "", [ 4, h.get("srcPosition") ];

                  case 4:
                    return e.srcPosition = t.sent() || "", [ 2, e ];
                }
            });
        });
    }
    n.temData = {};
    var g = function() {
        function e(e, t) {
            this.init(e, t), p.default.init();
        }
        return e.prototype.init = function(e, t) {
            var r;
            for (var i in this.commonProps = "string" == typeof e ? ((r = {})[e] = t, r) : e, 
            this.commonProps) "item" === i && (n.temData.page = this.commonProps[i]), "itemId" === i && (n.temData.pageId = this.commonProps[i]);
        }, e.prototype.pageView = function(e) {
            return a(this, void 0, void 0, function() {
                var t, n;
                return u(this, function(r) {
                    switch (r.label) {
                      case 0:
                        return t = this.mergeCommon(), t = c.merge(t, e), n = c.merge, [ 4, m() ];

                      case 1:
                        return (t = n.apply(void 0, [ r.sent(), t ])).serviceId = "pageview", t.appName = t.appName || "event", 
                        this.report(t), [ 2 ];
                    }
                });
            });
        }, e.prototype.event = function(e) {
            var t = this.mergeCommon();
            t.srcPage = t.srcPage || this.commonProps.item, t.srcPageId = t.srcPageId || this.commonProps.itemId, 
            n.temData.module = e.srcModule || "", n.temData.postion = e.srcPosition || "", (t = c.merge(t, e)).appName = t.appName || "event", 
            this.report(t);
        }, e.prototype.mergeCommon = function() {
            var e = c.merge({
                uuid: f.sid
            }, this.commonProps);
            return c.merge(e, d.collectData());
        }, e.prototype.report = function(e) {
            p.default.send(this.format(e));
        }, e.prototype.format = function(e) {
            var t = Object.keys(e).reduce(function(t, n) {
                return null != e[n] && "" !== e[n] && (t[n] = e[n]), t;
            }, {});
            return {
                _key: l.generateUUID(),
                props: t,
                ts: l.getTimestamp()
            };
        }, e;
    }();
    n.default = g;
}, function(e) {
    return n({
        "../utils/obj": 1690770624134,
        "../utils/tool": 1690770624135,
        "./share": 1690770624136,
        "./report": 1690770624142,
        "./collect": 1690770624144,
        "../platform/storage": 1690770624141
    }[e], e);
}), t(1690770624134, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.merge = n.trim = n.isString = void 0, n.isString = function(e) {
        return "string" == typeof e;
    }, n.trim = function(e) {
        return e.replace(/(^\s*)|(\s*$)/g, "");
    }, n.merge = function(e, t, n) {
        var r = {};
        for (var i in e) e.hasOwnProperty(i) && (r[i] = e[i]);
        for (var o in t) t.hasOwnProperty(o) && ("_" !== o[0] || n) && (r[o] = t[o]);
        return r;
    };
}, function(e) {
    return n({}[e], e);
}), t(1690770624135, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.generateUUID = n.getTimestamp = void 0, n.getTimestamp = function() {
        return +new Date();
    }, n.generateUUID = function() {
        for (var e = "", t = 1; t <= 36; t++) e += 9 === t || 14 === t || 19 === t || 24 === t ? "-" : 15 === t ? 4 : 20 === t ? "0123456789abcdef"[4 * Math.random() | 8] : "0123456789abcdef"[16 * Math.random() | 0];
        return e;
    };
}, function(e) {
    return n({}[e], e);
}), t(1690770624136, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.parseCachedData = n.sid = n.url = void 0;
    var r = e("../config"), i = e("../utils/app");
    n.url = "https://xdcs-collector." + (r.isDev() ? "test." : "") + "ximalaya.com/api/v1/statistics", 
    n.sid = i.info.deviceId, n.parseCachedData = function(e) {
        var t;
        try {
            t = JSON.parse(e);
        } catch (e) {
            t = [];
        }
        return t;
    };
}, function(e) {
    return n({
        "../config": 1690770624137,
        "../utils/app": 1690770624138
    }[e], e);
}), t(1690770624137, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.reportWriteKey = n.reportSwitchKey = n.nativeInfoCookieKey = n.maxAllowRetryTimes = n.mergeRequestDuration = n.repTypes = n.reportErrorUrl = n.getApiUrlMini = n.getApiUrl = n.getPlatform = n.setPlatform = n.setEnv = n.isDev = n.setDebugMode = void 0;
    var r = "https://mermaid.ximalaya.com/collector-web/web-pl/v1/mini-j", i = "https://mermaid.test.ximalaya.com/collector-web/web-pl/v1", o = ("undefined" != typeof process ? process.env.NODE_ENV : "") || "test", a = !1;
    n.setDebugMode = function(e) {
        a = e;
    };
    var u, s = "";
    n.isDev = function() {
        return "test" === (s || o);
    }, n.setEnv = function(e) {
        s = e;
    }, n.setPlatform = function(e) {
        u = e;
    }, n.getPlatform = function() {
        return u;
    }, n.getApiUrl = function() {
        return {
            test: i,
            uat: "https://mermaid.uat.ximalaya.com/collector-web/web-pl/v1",
            production: "https://mermaid.ximalaya.com/collector-web/web-pl/v1"
        }[s] || i;
    }, n.getApiUrlMini = function() {
        return {
            test: a ? "https://mermaid.test.ximalaya.com/collector-web/web-pld/v1/mini-j" : "https://mermaid.test.ximalaya.com/collector-web/web-pl/v1/mini-j",
            uat: a ? "https://mermaid.uat.ximalaya.com/collector-web/web-pld/v1/mini-j" : "https://mermaid.uat.ximalaya.com/collector-web/web-pl/v1/mini-j",
            production: r
        }[s] || r;
    }, n.reportErrorUrl = "", n.repTypes = {
        APM: {
            name: "apm_web",
            priority: 2,
            switchKey: "apm",
            subTypes: {
                PAGE: "page",
                NETWORK: "network"
            }
        },
        SHARE: {
            name: "share_web",
            priority: 102,
            switchKey: "share",
            subTypes: {
                STATE: "share_stat_record",
                FEEDBACK: "share_feedback"
            }
        },
        UBT: {
            name: "ubt_web",
            switchKey: "ubt",
            priority: 101,
            subTypes: {
                PAGE_VIEW: "pageview",
                PAGE_EXIT: "pageExit",
                CLICK: "click",
                CLICK_BUTTON: "clickButton",
                SLIP_PAGE: "slipPage"
            }
        }
    }, n.mergeRequestDuration = 1e3, n.maxAllowRetryTimes = 3, n.nativeInfoCookieKey = "xmly_ubt", 
    n.reportSwitchKey = "xlog.send", n.reportWriteKey = "xlog.write";
}, function(e) {
    return n({}[e], e);
}), t(1690770624138, function(e, t, n) {
    var r = this && this.__awaiter || function(e, t, n, r) {
        return new (n || (n = Promise))(function(i, o) {
            function a(e) {
                try {
                    s(r.next(e));
                } catch (e) {
                    o(e);
                }
            }
            function u(e) {
                try {
                    s(r.throw(e));
                } catch (e) {
                    o(e);
                }
            }
            function s(e) {
                var t;
                e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                    e(t);
                })).then(a, u);
            }
            s((r = r.apply(e, t || [])).next());
        });
    }, i = this && this.__generator || function(e, t) {
        var n, r, i, o, a = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1];
            },
            trys: [],
            ops: []
        };
        return o = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
            return this;
        }), o;
        function u(o) {
            return function(u) {
                return function(o) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 
                        0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                        switch (r = 0, i && (o = [ 2 & o[0], i.value ]), o[0]) {
                          case 0:
                          case 1:
                            i = o;
                            break;

                          case 4:
                            return a.label++, {
                                value: o[1],
                                done: !1
                            };

                          case 5:
                            a.label++, r = o[1], o = [ 0 ];
                            continue;

                          case 7:
                            o = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                a.label = o[1];
                                break;
                            }
                            if (6 === o[0] && a.label < i[1]) {
                                a.label = i[1], i = o;
                                break;
                            }
                            if (i && a.label < i[2]) {
                                a.label = i[2], a.ops.push(o);
                                break;
                            }
                            i[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        o = t.call(e, a);
                    } catch (e) {
                        o = [ 6, e ], r = 0;
                    } finally {
                        n = i = 0;
                    }
                    if (5 & o[0]) throw o[1];
                    return {
                        value: o[0] ? o[1] : void 0,
                        done: !0
                    };
                }([ o, u ]);
            };
        }
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.info = n.uuid = void 0;
    var o, a, u, s = e("./tool"), c = e("./env"), l = e("../platform/storage");
    r(void 0, void 0, void 0, function() {
        return i(this, function(e) {
            switch (e.label) {
              case 0:
                return [ 4, l.get("__xlog") ];

              case 1:
                return [ 2, a = e.sent() ];
            }
        });
    });
    var f = s.getTimestamp(), p = 0;
    n.uuid = s.generateUUID(), n.info = {
        get appId() {
            return u;
        },
        set appId(e) {
            e && (u = e);
        },
        get bId() {
            return o;
        },
        set bId(e) {
            e && (o = e);
        },
        get deviceId() {
            return a || (a = n.uuid, l.set("__xlog", n.uuid)), a;
        },
        get deviceType() {
            return c.getLiteType();
        },
        get sessionId() {
            return f;
        },
        get seq() {
            return ++p;
        }
    };
}, function(e) {
    return n({
        "./tool": 1690770624135,
        "./env": 1690770624139,
        "../platform/storage": 1690770624141
    }[e], e);
}), t(1690770624139, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.getLiteType = n.isKwai = n.isQuickApp = n.isToutiao = n.isBaidu = n.isAli = n.isXm = n.isWx = void 0;
    var r = e("../config"), i = e("../constants");
    function o() {
        return r.getPlatform() === i.platforms.WEIXIN || !r.getPlatform() && "undefined" != typeof wx;
    }
    function a() {
        return r.getPlatform() === i.platforms.XIMA || !r.getPlatform() && "undefined" != typeof xm;
    }
    function u() {
        return r.getPlatform() === i.platforms.ALIPAY || !r.getPlatform() && "undefined" != typeof my;
    }
    function s() {
        return r.getPlatform() === i.platforms.BAIDU || !r.getPlatform() && "undefined" != typeof swan;
    }
    function c() {
        return r.getPlatform() === i.platforms.TOUTIAO || !r.getPlatform() && "undefined" != typeof tt;
    }
    function l() {
        return r.getPlatform() === i.platforms.QUICKAPP || !r.getPlatform() && "undefined" != typeof qa;
    }
    function f() {
        return r.getPlatform() === i.platforms.KWAI || !r.getPlatform() && "undefined" != typeof ks;
    }
    n.isWx = o, n.isXm = a, n.isAli = u, n.isBaidu = s, n.isToutiao = c, n.isQuickApp = l, 
    n.isKwai = f, n.getLiteType = function() {
        return c() ? "lite-tt" : o() ? "lite-wx" : s() ? "lite-baidu" : a() ? "lite-xm" : u() ? "lite-ali" : l() ? "lite-qa" : f() ? "lite-ks" : "lite-unknown";
    };
}, function(e) {
    return n({
        "../config": 1690770624137,
        "../constants": 1690770624140
    }[e], e);
}), t(1690770624140, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.platforms = void 0, function(e) {
        e.WEIXIN = "wx", e.ALIPAY = "my", e.BAIDU = "swan", e.XIMA = "xm", e.TOUTIAO = "tt", 
        e.QUICKAPP = "qa", e.KWAI = "ks";
    }(n.platforms || (n.platforms = {}));
}, function(e) {
    return n({}[e], e);
}), t(1690770624141, function(e, t, n) {
    var r = this && this.__awaiter || function(e, t, n, r) {
        return new (n || (n = Promise))(function(i, o) {
            function a(e) {
                try {
                    s(r.next(e));
                } catch (e) {
                    o(e);
                }
            }
            function u(e) {
                try {
                    s(r.throw(e));
                } catch (e) {
                    o(e);
                }
            }
            function s(e) {
                var t;
                e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                    e(t);
                })).then(a, u);
            }
            s((r = r.apply(e, t || [])).next());
        });
    }, i = this && this.__generator || function(e, t) {
        var n, r, i, o, a = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1];
            },
            trys: [],
            ops: []
        };
        return o = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
            return this;
        }), o;
        function u(o) {
            return function(u) {
                return function(o) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 
                        0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                        switch (r = 0, i && (o = [ 2 & o[0], i.value ]), o[0]) {
                          case 0:
                          case 1:
                            i = o;
                            break;

                          case 4:
                            return a.label++, {
                                value: o[1],
                                done: !1
                            };

                          case 5:
                            a.label++, r = o[1], o = [ 0 ];
                            continue;

                          case 7:
                            o = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                a.label = o[1];
                                break;
                            }
                            if (6 === o[0] && a.label < i[1]) {
                                a.label = i[1], i = o;
                                break;
                            }
                            if (i && a.label < i[2]) {
                                a.label = i[2], a.ops.push(o);
                                break;
                            }
                            i[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        o = t.call(e, a);
                    } catch (e) {
                        o = [ 6, e ], r = 0;
                    } finally {
                        n = i = 0;
                    }
                    if (5 & o[0]) throw o[1];
                    return {
                        value: o[0] ? o[1] : void 0,
                        done: !0
                    };
                }([ o, u ]);
            };
        }
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.get = n.set = void 0;
    var o = e("../utils/env");
    n.set = function(e, t) {
        return r(this, void 0, void 0, function() {
            return i(this, function(n) {
                switch (n.label) {
                  case 0:
                    return o.isXm() ? [ 4, xm.setStorageSync(e, t) ] : [ 3, 2 ];

                  case 1:
                    return n.sent(), [ 3, 14 ];

                  case 2:
                    return o.isBaidu() ? [ 4, swan.setStorageSync(e, t) ] : [ 3, 4 ];

                  case 3:
                    return n.sent(), [ 3, 14 ];

                  case 4:
                    return o.isWx() ? [ 4, wx.setStorageSync(e, t) ] : [ 3, 6 ];

                  case 5:
                    return n.sent(), [ 3, 14 ];

                  case 6:
                    return o.isToutiao() ? [ 4, tt.setStorageSync(e, t) ] : [ 3, 8 ];

                  case 7:
                    return n.sent(), [ 3, 14 ];

                  case 8:
                    return o.isAli() ? [ 4, my.setStorageSync({
                        key: e,
                        data: t
                    }) ] : [ 3, 10 ];

                  case 9:
                    return n.sent(), [ 3, 14 ];

                  case 10:
                    return o.isQuickApp() ? [ 4, qa.setStorageSync(e, t) ] : [ 3, 12 ];

                  case 11:
                    return n.sent(), [ 3, 14 ];

                  case 12:
                    return o.isKwai() ? [ 4, ks.setStorageSync(e, t) ] : [ 3, 14 ];

                  case 13:
                    n.sent(), n.label = 14;

                  case 14:
                    return [ 2 ];
                }
            });
        });
    }, n.get = function(e) {
        return r(this, void 0, void 0, function() {
            return i(this, function(t) {
                switch (t.label) {
                  case 0:
                    return o.isBaidu() ? [ 4, swan.getStorageSync(e) ] : [ 3, 2 ];

                  case 1:
                    return [ 2, t.sent() ];

                  case 2:
                    return o.isWx() ? [ 4, wx.getStorageSync(e) ] : [ 3, 4 ];

                  case 3:
                    return [ 2, t.sent() ];

                  case 4:
                    return o.isToutiao() ? [ 4, tt.getStorageSync(e) ] : [ 3, 6 ];

                  case 5:
                    return [ 2, t.sent() ];

                  case 6:
                    return o.isXm() ? [ 4, xm.getStorageSync(e) ] : [ 3, 8 ];

                  case 7:
                    return [ 2, t.sent() ];

                  case 8:
                    return o.isAli() ? [ 4, my.getStorageSync({
                        key: e
                    }).data ] : [ 3, 10 ];

                  case 9:
                    return [ 2, t.sent() ];

                  case 10:
                    return o.isQuickApp() ? [ 4, qa.getStorageSync(e) ] : [ 3, 12 ];

                  case 11:
                    return [ 2, t.sent() ];

                  case 12:
                    return o.isKwai() ? [ 4, ks.getStorageSync(e) ] : [ 3, 14 ];

                  case 13:
                    return [ 2, t.sent() ];

                  case 14:
                    return [ 2, Promise.resolve("") ];
                }
            });
        });
    };
}, function(e) {
    return n({
        "../utils/env": 1690770624139
    }[e], e);
}), t(1690770624142, function(e, t, n) {
    var r = this && this.__createBinding || (Object.create ? function(e, t, n, r) {
        void 0 === r && (r = n), Object.defineProperty(e, r, {
            enumerable: !0,
            get: function() {
                return t[n];
            }
        });
    } : function(e, t, n, r) {
        void 0 === r && (r = n), e[r] = t[n];
    }), i = this && this.__setModuleDefault || (Object.create ? function(e, t) {
        Object.defineProperty(e, "default", {
            enumerable: !0,
            value: t
        });
    } : function(e, t) {
        e.default = t;
    }), o = this && this.__importStar || function(e) {
        if (e && e.__esModule) return e;
        var t = {};
        if (null != e) for (var n in e) "default" !== n && Object.hasOwnProperty.call(e, n) && r(t, e, n);
        return i(t, e), t;
    }, a = this && this.__awaiter || function(e, t, n, r) {
        return new (n || (n = Promise))(function(i, o) {
            function a(e) {
                try {
                    s(r.next(e));
                } catch (e) {
                    o(e);
                }
            }
            function u(e) {
                try {
                    s(r.throw(e));
                } catch (e) {
                    o(e);
                }
            }
            function s(e) {
                var t;
                e.done ? i(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                    e(t);
                })).then(a, u);
            }
            s((r = r.apply(e, t || [])).next());
        });
    }, u = this && this.__generator || function(e, t) {
        var n, r, i, o, a = {
            label: 0,
            sent: function() {
                if (1 & i[0]) throw i[1];
                return i[1];
            },
            trys: [],
            ops: []
        };
        return o = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
            return this;
        }), o;
        function u(o) {
            return function(u) {
                return function(o) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (n = 1, r && (i = 2 & o[0] ? r.return : o[0] ? r.throw || ((i = r.return) && i.call(r), 
                        0) : r.next) && !(i = i.call(r, o[1])).done) return i;
                        switch (r = 0, i && (o = [ 2 & o[0], i.value ]), o[0]) {
                          case 0:
                          case 1:
                            i = o;
                            break;

                          case 4:
                            return a.label++, {
                                value: o[1],
                                done: !1
                            };

                          case 5:
                            a.label++, r = o[1], o = [ 0 ];
                            continue;

                          case 7:
                            o = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((i = (i = a.trys).length > 0 && i[i.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === o[0] && (!i || o[1] > i[0] && o[1] < i[3])) {
                                a.label = o[1];
                                break;
                            }
                            if (6 === o[0] && a.label < i[1]) {
                                a.label = i[1], i = o;
                                break;
                            }
                            if (i && a.label < i[2]) {
                                a.label = i[2], a.ops.push(o);
                                break;
                            }
                            i[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        o = t.call(e, a);
                    } catch (e) {
                        o = [ 6, e ], r = 0;
                    } finally {
                        n = i = 0;
                    }
                    if (5 & o[0]) throw o[1];
                    return {
                        value: o[0] ? o[1] : void 0,
                        done: !0
                    };
                }([ o, u ]);
            };
        }
    }, s = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var c = o(e("../platform/storage")), l = s(e("../platform/request")), f = e("../config"), p = e("./share"), d = new (function() {
        function e() {
            this.isSending = !1, this.pendingData = [], this.failData = [];
        }
        return e.prototype.checkSending = function() {
            return this.isSending;
        }, e.prototype.send = function(e) {
            this.addSend(e);
        }, e.prototype.init = function() {
            return a(this, void 0, void 0, function() {
                var e, t, n = this;
                return u(this, function(r) {
                    switch (r.label) {
                      case 0:
                        return t = p.parseCachedData, [ 4, c.get("_xmlog_cache") ];

                      case 1:
                        return (e = t.apply(void 0, [ r.sent() ])) && e.length && this.addSend(e), this.timer && clearInterval(this.timer), 
                        this.timer = setInterval(function() {
                            !n.isSending && n.pendingData.length > 0 && n.sendNext();
                        }, 1e3), [ 2 ];
                    }
                });
            });
        }, e.prototype.addSend = function(e) {
            this.pendingData = this.pendingData.concat(e), this.saveData();
        }, e.prototype.report = function(e) {
            var t = this;
            f.isDev() && console.log("[XLOG-XMLITE#XMLog] sending data:", JSON.parse(JSON.stringify(e))), 
            l.default(p.url, {
                events: e
            }, function(n) {
                200 === n.statusCode ? t.saveData() : t.failData = t.failData.concat(e), t.isSending = !1;
            }, function() {
                t.failData = t.failData.concat(e), t.isSending = !1;
            });
        }, e.prototype.sendNext = function() {
            this.pendingData.length && (this.report(this.pendingData.slice()), this.pendingData.length = 0);
        }, e.prototype.saveData = function() {
            var e = this.pendingData.concat(this.failData);
            e.length ? c.set("_xmlog_cache", JSON.stringify(e)) : c.set("_xmlog_cache", null);
        }, e;
    }())();
    n.default = d;
}, function(e) {
    return n({
        "../platform/storage": 1690770624141,
        "../platform/request": 1690770624143,
        "../config": 1690770624137,
        "./share": 1690770624136
    }[e], e);
}), t(1690770624143, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var r = e("../utils/env");
    n.default = function(e, t, n, i) {
        var o = {
            url: e,
            fail: i,
            method: "post",
            data: t,
            dataType: "string",
            success: function(e) {
                e.statusCode = e.statusCode || e.status, e.header = e.header || e.headers, n(e);
            }
        };
        r.isQuickApp() && (o.header = {
            "Content-Type": "application/json;charset=UTF-8"
        });
        var a = r.isWx() ? wx : r.isAli() ? my : r.isBaidu() ? swan : r.isToutiao() ? tt : r.isXm() ? xm : r.isQuickApp() ? qa : r.isKwai() ? ks : void 0;
        a && a.request(o);
    };
}, function(e) {
    return n({
        "../utils/env": 1690770624139
    }[e], e);
}), t(1690770624144, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.collectData = void 0, n.collectData = function() {
        return {
            trackType: "H5",
            siteType: "offPage"
        };
    };
}, function(e) {
    return n({}[e], e);
}), t(1690770624145, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.getCustomCommon = n.setCustomCommon = n.formatTimeData = n.logTimeLabel = void 0;
    var i, o = e("../config");
    n.logTimeLabel = "undefined" != typeof Symbol ? Symbol("logtime") : "__logTime", 
    n.formatTimeData = function(e) {
        return e[n.logTimeLabel] = +new Date(), e;
    };
    var a = [ "string", "number", "undefined" ];
    n.setCustomCommon = function(e) {
        for (var t in e) {
            var n = r(e[t]);
            if (!a.includes(n) && o.isDev()) throw new Error("[XLog-ERR] custom props('" + t + "') type should be string or number, but got '" + n + "'");
        }
        i = e;
    }, n.getCustomCommon = function() {
        return i;
    };
}, function(e) {
    return n({
        "../config": 1690770624137
    }[e], e);
}), t(1690770624146, function(e, t, n) {
    var r = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.ubt = n.pageView = n.pageExit = n.clickButton = n.click = n.event = void 0;
    var i = r(e("./event"));
    n.event = i.default;
    var o = r(e("./click"));
    n.click = o.default;
    var a = r(e("./clickButton"));
    n.clickButton = a.default;
    var u = r(e("./pageExit"));
    n.pageExit = u.default;
    var s = r(e("./pageView"));
    n.pageView = s.default, n.ubt = {
        event: i.default,
        click: o.default,
        clickButton: a.default,
        pageExit: u.default,
        pageView: s.default
    };
}, function(e) {
    return n({
        "./event": 1690770624147,
        "./click": 1690770624150,
        "./clickButton": 1690770624152,
        "./pageExit": 1690770624153,
        "./pageView": 1690770624154
    }[e], e);
}), t(1690770624147, function(e, t, n) {
    var i = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var o = i(e("../utils/report")), a = e("../utils/data"), u = e("../utils/app"), s = e("../config");
    n.default = function(e, t, n) {
        for (var i in n) {
            var c = r(n[i]);
            if ("string" !== c && "number" !== c && "undefined" !== c && s.isDev()) throw new Error("[XLog-ERR] event props('" + i + "') type should be string or number, but got '" + c + "'");
        }
        o.default({
            type: s.repTypes.UBT,
            subType: t,
            data: [ a.formatTimeData({
                metaId: e,
                serviceId: t,
                isManual: !0,
                seq: u.info.seq,
                sessionId: u.info.sessionId,
                props: n
            }) ]
        });
    };
}, function(e) {
    return n({
        "../utils/report": 1690770624148,
        "../utils/data": 1690770624145,
        "../utils/app": 1690770624138,
        "../config": 1690770624137
    }[e], e);
}), t(1690770624148, function(e, t, n) {
    var r = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var i = e("@xmly/binary-report"), o = r(e("../platform/request")), a = e("./app"), u = e("../config"), s = e("./data"), c = e("./base64"), l = new (function() {
        function e() {
            this.sendList = [], this.retryTimes = 0, this.stopKeys = "", this.canReport = !0, 
            this.initLoop();
        }
        return e.prototype.initLoop = function() {
            var e = this;
            this.timer = setInterval(function() {
                e.sendList.length > 0 && e.sendNext();
            }, u.mergeRequestDuration);
        }, e.prototype.send = function(e) {
            (this.canReport && (!this.stopKeys || !~this.stopKeys.indexOf(e.type.switchKey)) || this.retryTimes > u.maxAllowRetryTimes) && this.addSend(e);
        }, e.prototype.sendNext = function() {
            this.canReport ? this.sendList.length && (this.report(e.formatData(this.sendList.slice())), 
            this.sendList.length = 0) : this.timer && clearInterval(this.timer);
        }, e.prototype.addSend = function(t) {
            this.pushSendList(e.formatDataItem(t));
        }, e.prototype.pushSendList = function(e) {
            this.sendList = this.sendList.concat(e);
        }, e.prototype.report = function(e) {
            var t = this;
            u.isDev() && console.log("[XLOG] sending data:", JSON.parse(JSON.stringify(e)));
            var n = i.getSendData(e.env, e.items), r = c.arrayBufferToBase64(n);
            o.default(u.getApiUrlMini(), {
                data: r
            }, function(e) {
                try {
                    var n = e.header[u.reportWriteKey] || "", r = e.header[u.reportSwitchKey] || "";
                    t.stopKeys = n, t.canReport = !/true/.test(r);
                } catch (e) {
                    t.retryTimes = u.maxAllowRetryTimes;
                }
            }, function() {
                t.retryTimes++;
            });
        }, e.formatDataItem = function(e) {
            return e.data.map(function(t) {
                var n = t[s.logTimeLabel];
                return delete t[s.logTimeLabel], {
                    time: n,
                    subType: e.subType,
                    type: e.type.name,
                    msg: t
                };
            });
        }, e.formatData = function(e) {
            return {
                items: e,
                env: {
                    appId: a.info.appId,
                    deviceId: a.info.deviceId,
                    dt: a.info.deviceType,
                    bid: a.info.bId,
                    clientSendTime: +new Date(),
                    ext: s.getCustomCommon()
                }
            };
        }, e;
    }())();
    n.default = function(e) {
        l.send(e);
    };
}, function(e) {
    return n({
        "../platform/request": 1690770624143,
        "./app": 1690770624138,
        "../config": 1690770624137,
        "./data": 1690770624145,
        "./base64": 1690770624149
    }[e], e);
}), t(1690770624149, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.arrayBufferToBase64 = void 0, n.arrayBufferToBase64 = function(e) {
        for (var t = "", n = new Uint8Array(e), r = n.byteLength, i = 0; i < r; i++) t += String.fromCharCode(n[i]);
        return function(e) {
            for (var t, n, r, i, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a = "", u = 0, s = (e = String(e)).length % 3; u < e.length; ) {
                if ((n = e.charCodeAt(u++)) > 255 || (r = e.charCodeAt(u++)) > 255 || (i = e.charCodeAt(u++)) > 255) throw new TypeError("Failed to execute 'btoa' on 'Window': The string to be encoded contains characters outside of the Latin1 range.");
                a += o.charAt((t = n << 16 | r << 8 | i) >> 18 & 63) + o.charAt(t >> 12 & 63) + o.charAt(t >> 6 & 63) + o.charAt(63 & t);
            }
            return s ? a.slice(0, s - 3) + "===".substring(s) : a;
        }(t);
    };
}, function(e) {
    return n({}[e], e);
}), t(1690770624150, function(e, t, n) {
    var r = this && this.__assign || function() {
        return (r = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
        }).apply(this, arguments);
    }, i = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var o = i(e("./event")), a = e("../config"), u = i(e("../utils/pageData"));
    n.default = function(e, t, n) {
        !function(e, t, n) {
            var i = {};
            "string" == typeof t ? (i.currModule = t || void 0, u.default.prevModule = t || void 0) : (i = t, 
            u.default.prevModule = void 0), o.default.bind(this)(e, a.repTypes.UBT.subTypes.CLICK, r(r({}, i), n));
        }(e, t, n);
    };
}, function(e) {
    return n({
        "./event": 1690770624147,
        "../config": 1690770624137,
        "../utils/pageData": 1690770624151
    }[e], e);
}), t(1690770624151, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var r, i, o = e("./obj"), a = +new Date(), u = {
        set prevModule(e) {
            r = o.isString(e) ? e.trim() : void 0;
        },
        get prevModule() {
            return r;
        },
        set prevPage(e) {
            i = o.isString(e) ? e.trim() : void 0;
        },
        get prevPage() {
            return i;
        },
        get time() {
            return a;
        },
        set time(e) {
            a = e;
        }
    };
    n.default = u;
}, function(e) {
    return n({
        "./obj": 1690770624134
    }[e], e);
}), t(1690770624152, function(e, t, n) {
    var r = this && this.__assign || function() {
        return (r = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
        }).apply(this, arguments);
    }, i = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var o = i(e("./event")), a = e("../config");
    n.default = function(e, t, n) {
        !function(e, t, n) {
            var i = {};
            "string" == typeof t ? i.currModule = t : i = t, o.default.bind(this)(e, a.repTypes.UBT.subTypes.CLICK_BUTTON, r(r({}, i), n));
        }(e, t, n);
    };
}, function(e) {
    return n({
        "./event": 1690770624147,
        "../config": 1690770624137
    }[e], e);
}), t(1690770624153, function(e, t, n) {
    var r = this && this.__assign || function() {
        return (r = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
        }).apply(this, arguments);
    }, i = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var o = i(e("./event")), a = e("../config"), u = i(e("../utils/pageData"));
    n.default = function(e, t) {
        var n = Math.ceil((+new Date() - u.default.time) / 1e3);
        return o.default.bind(this)(e, a.repTypes.UBT.subTypes.PAGE_EXIT, r({
            durationTime: n,
            currPage: u.default.prevPage
        }, t), !0);
    };
}, function(e) {
    return n({
        "./event": 1690770624147,
        "../config": 1690770624137,
        "../utils/pageData": 1690770624151
    }[e], e);
}), t(1690770624154, function(e, t, n) {
    var r = this && this.__assign || function() {
        return (r = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
        }).apply(this, arguments);
    }, i = this && this.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    };
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var o = i(e("./event")), a = e("../config"), u = i(e("../utils/pageData"));
    n.default = function(e, t, n) {
        void 0 === n && (n = {});
        var i = u.default.prevPage, s = u.default.prevModule;
        return u.default.time = +new Date(), u.default.prevPage = t, u.default.prevModule = void 0, 
        o.default.bind(this)(e, a.repTypes.UBT.subTypes.PAGE_VIEW, r({
            prevPage: i,
            currPage: t,
            prevModule: s
        }, n.pageShowNum ? n : r({
            pageShowNum: 1
        }, n)));
    };
}, function(e) {
    return n({
        "./event": 1690770624147,
        "../config": 1690770624137,
        "../utils/pageData": 1690770624151
    }[e], e);
}), n(1690770624131));