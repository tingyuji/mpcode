var e, t, n = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, t = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var o = e[t].m;
        o._exports = o._tempexports;
        var u = Object.getOwnPropertyDescriptor(o, "exports");
        u && u.configurable && Object.defineProperty(o, "exports", {
            set: function(e) {
                "object" === n(e) && e !== o._exports && (o._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    o._exports[t] = e[t];
                })), o._tempexports = e;
            },
            get: function() {
                return o._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, o, o.exports);
    }
    return e[t].m.exports;
}, function(t, n, r) {
    e[t] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1690770624112, function(e, t, r) {
    var o, u;
    o = this, u = function(e) {
        var t = function(e, t) {
            for (var n = [], r = 0, o = 0; o < e.length; o++) {
                var u = e.charCodeAt(o);
                0 <= u && u <= 127 ? (r += 1, n.push(u)) : 128 <= u && u <= 2047 ? (r += 2, n.push(192 | 31 & u >> 6), 
                n.push(128 | 63 & u)) : (2048 <= u && u <= 55295 || 57344 <= u && u <= 65535) && (r += 3, 
                n.push(224 | 15 & u >> 12), n.push(128 | 63 & u >> 6), n.push(128 | 63 & u));
            }
            for (var s = 0; s < n.length; s++) n[s] &= 255;
            return t ? n : r <= 255 ? [ 0, r ].concat(n) : [ r >> 8, 255 & r ].concat(n);
        }, n = function(e) {
            var n = e.type, r = e.subType, o = e.msg, u = e.time, s = t(n, !0), i = t(r, !0), a = t(JSON.stringify(o), !0), p = function(e) {
                for (var t = []; e > 0; ) t.push(e % 256), e = parseInt(e / 256);
                for (;t.length < 8; ) t.push(0);
                return t;
            }(u);
            return {
                len: s.length + 2 + i.length + 2 + a.length + 4 + 8,
                uType: s,
                uSubType: i,
                uMsg: a,
                uTime: p
            };
        }, r = function(e, t, n) {
            var r = n.uType, o = n.uSubType, u = n.uMsg, s = n.uTime;
            e.setInt16(t, r.length, !0), t += 2;
            for (var i = 0; i < r.length; i++) e.setUint8(t++, r[i]);
            e.setInt16(t, o.length, !0), t += 2;
            for (var a = 0; a < o.length; a++) e.setUint8(t++, o[a]);
            for (var p = 0; p < s.length; p++) e.setInt8(t++, s[p]);
            e.setInt32(t, u.length, !0), t += 4;
            for (var f = 0; f < u.length; f++) e.setUint8(t++, u[f]);
        };
        function o(e, o) {
            for (var u, s, i = (u = e, {
                uGg: s = t(JSON.stringify(u), !0),
                len: s.length + 4
            }), a = o.map(n), p = new ArrayBuffer(i.len + a.reduce(function(e, t) {
                return e + t.len;
            }, 0)), f = new DataView(p), c = 0, l = 0; l < a.length; l++) r(f, c, a[l]), c += a[l].len;
            return function(e, t, n) {
                for (var r = n.uGg, o = 0; o < r.length; o++, t++) e.setUint8(t, r[o]);
                e.setInt32(t, r.length, !0);
            }(f, c, i), f.buffer;
        }
        e.default = function(e, t, n, r) {
            var u, s, i = o(t, n);
            return r && navigator.sendBeacon ? (u = e, s = new Uint8Array(i), void navigator.sendBeacon(u, s)) : function(e, t) {
                var n = new XMLHttpRequest();
                return n.open("POST", e, !0), n.setRequestHeader("content-type", "application/octet-stream"), 
                n.withCredentials = !0, n.send(t), n;
            }(e, i);
        }, e.getSendData = o, Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, "object" === n(r) && void 0 !== t ? u(r) : "function" == typeof define && define.amd ? define([ "exports" ], u) : u((o = o || self).binaryReport = {});
}, function(e) {
    return t({}[e], e);
}), t(1690770624112));