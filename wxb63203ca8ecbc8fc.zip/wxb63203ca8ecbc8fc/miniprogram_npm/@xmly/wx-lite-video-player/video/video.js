var t = require("../../../../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    var o = {};
    function n(t) {
        if (o[t]) return o[t].exports;
        var i = o[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
    }
    return n.m = e, n.c = o, n.d = function(t, e, o) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: o
        });
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, n.t = function(e, o) {
        if (1 & o && (e = n(e)), 8 & o) return e;
        if (4 & o && "object" === t(e) && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
            enumerable: !0,
            value: e
        }), 2 & o && "string" != typeof e) for (var r in e) n.d(i, r, function(t) {
            return e[t];
        }.bind(null, r));
        return i;
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return n.d(e, "a", e), e;
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, n.p = "", n(n.s = 1);
}([ function(e, o, n) {
    o.__esModule = !0;
    var i = "function" == typeof Symbol && "symbol" === t(Symbol.iterator) ? function(e) {
        return t(e);
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : t(e);
    };
    function r(t) {
        return "[object Array]" == Object.prototype.toString.call(t);
    }
    o.isArray = r, o.paramStr = function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], o = "";
        if ("string" == typeof t) return t;
        if ("object" === (void 0 === t ? "undefined" : i(t)) && !r(t)) for (var n in t) {
            var a = t[n];
            if (r(a)) {
                var s = "";
                e || (s = "[]");
                for (var u = 0, c = a.length; u < c; u++) o += "&" + n + s + "=" + a[u];
            } else "function" == typeof a || (o += "&" + n + "=" + a);
        }
        return o.substring(1);
    }, o.getVideoSize = function(t) {
        return Math.round(t / 1024 / 1024);
    };
}, function(t, e, o) {
    var n, i = o(2), r = (n = i) && n.__esModule ? n : {
        default: n
    }, a = o(7), s = o(8), u = o(0);
    Component({
        properties: {
            videoId: {
                type: Number,
                value: 0,
                observer: function(t, e) {
                    t !== e && this.getVideoInfo(t);
                }
            },
            videoList: {
                type: Array,
                value: []
            },
            options: {
                type: Object,
                value: {},
                observer: function(t, e) {
                    if (JSON.stringify(t) !== JSON.stringify(e)) {
                        var o = this.data.option;
                        this.setData({
                            option: Object.assign(Object.assign({}, o), t)
                        });
                    }
                }
            },
            linkProtecterOptions: Object,
            env: String
        },
        attached: function() {
            this.handleNetworkChangeBind = this.handleNetworkChange.bind(this), this.initNetworkTypeBind = this.initNetworkType.bind(this);
            var t = this.data.option;
            this.init(), t.monitorNetworkChange && wx.onNetworkStatusChange(this.handleNetworkChangeBind);
        },
        detached: function() {
            wx.offNetworkStatusChange(this.handleNetworkChangeBind);
        },
        data: {
            name: "video-player",
            src: "",
            duration: 0,
            PlayState: a.PlayState,
            networkType: "wifi",
            option: {
                controls: !0,
                showPlayBtn: !0,
                showCenterPlayBtn: !0,
                autoplay: !0,
                showMuteBtn: !0,
                initialTime: 0,
                showTitle: !0,
                monitorNetworkChange: !0,
                showShareIcon: !0,
                unauthorizedMsg: "试看结束，请购买后收看"
            }
        },
        methods: {
            init: function() {
                var t = this.data, e = t.option, o = t.videoList, n = t.videoId, i = t.linkProtecterOptions, a = t.env;
                this.video = new r.default(Object.assign(Object.assign({}, e), {
                    list: o,
                    id: n,
                    linkProtecterOptions: i,
                    env: a
                }), this), this.getVideoInfo(n), this.firstPlay = !1;
            },
            getVideoInfo: function(t) {
                var e = this;
                console.log(t, "getVideoInfo"), t ? this.video && this.video.getVideoSrc(t).then(function(t) {
                    if ("unauthorized" === t) return e.video.stop(), void e.setData({
                        showAuthorizedMsg: !0
                    });
                    var o = t.src, n = t.sampleDuration, i = t.sampleLength, r = t.totalLength, a = t.trackId, s = t.title, c = t.isAuthorized, l = t.duration;
                    console.log(t, "videoInfo"), e.setData({
                        src: o,
                        duration: c ? l : n,
                        sampleLength: i,
                        totalLength: r,
                        currentId: a,
                        title: s,
                        size: (0, u.getVideoSize)(c || i <= 0 ? r : i),
                        isAuthorized: c
                    });
                }).catch(function(t) {
                    e.video.stop(), e.setData({
                        errMsg: JSON.stringify(t)
                    }), console.error(t, "获取视频信息错误");
                }) : console.error("缺少视频id");
            },
            initNetworkType: function() {
                var t = this;
                wx.getNetworkType({
                    success: function(e) {
                        var o = e.networkType;
                        t.setData({
                            networkType: o
                        }), "wifi" !== o && setTimeout(function() {
                            t.stopPlayOnMobileData(o);
                        }, 500);
                    }
                });
            },
            handleNetworkChange: function(t) {
                var e = t.networkType;
                console.log("handleNetworkChange", t), "wifi" !== e && this.stopPlayOnMobileData(e);
            },
            stopPlayOnMobileData: function(t) {
                (0, s.todayFirstMobileDataTip)() === s.today || (this.triggerEvent("onmobiletipshow"), 
                (0, s.todayFirstMobileDataTip)(!0), this.video.stop(), this.setData({
                    showMobileTip: !0,
                    "option.initialTime": Math.round(this.currentTime)
                })), this.setData({
                    networkType: t
                });
            },
            onFullScreenChange: function(t) {
                var e = t.detail.fullScreen;
                this.setData({
                    fullScreen: e
                });
            },
            onControlsToggle: function(t) {
                var e = t.detail.show;
                this.setData({
                    controlsShow: e
                });
            },
            tapMobileTip: function() {
                this.triggerEvent("ontapmobiletip"), this.play();
            },
            play: function() {
                this.setData({
                    showMobileTip: !1
                }), this.video.play();
            },
            onPlay: function() {
                this.triggerEvent("onplay"), this.setData({
                    showAuthorizedMsg: !1
                }), this.firstPlay || (this.initNetworkTypeBind(), this.firstPlay = !0), this.setData({
                    playState: a.PlayState.PLAYING
                });
            },
            onPause: function() {
                this.triggerEvent("onpause"), this.setData({
                    playState: a.PlayState.PAUSE
                });
            },
            onEnded: function() {
                this.triggerEvent("onend"), this.setData({
                    playState: a.PlayState.ENDED
                }), this.next();
            },
            onError: function() {
                this.setData({
                    playState: a.PlayState.ERROR
                });
            },
            onSeekComplete: function() {
                this.triggerEvent("onseekcomplete");
            },
            onTimeUpdate: function(t) {
                var e = t.detail.currentTime;
                this.currentTime = e, this.handleSampleSeek(e), this.triggerEvent("ontimeupdate", e);
            },
            next: function() {
                var t = this.data, e = t.currentId, o = t.videoList, n = t.sampleLength, i = t.isAuthorized, r = o.findIndex(function(t) {
                    return t === e;
                });
                n > 0 && !i ? this.setData({
                    showAuthorizedMsg: !0
                }) : r > -1 && r < o.length - 1 ? (this.triggerEvent("onvideochange", o[r + 1]), 
                this.getVideoInfo(o[r + 1])) : wx.showToast({
                    title: "没有更多了",
                    icon: "none"
                });
            },
            onTapUnauthorizedMsg: function() {
                this.video.exitFullScreen();
            },
            handleSampleSeek: function(t) {
                var e = this.data, o = e.duration, n = e.sampleLength, i = e.isAuthorized;
                o === t && n > 0 && !i && (this.video.stop(), this.setData({
                    showAuthorizedMsg: !0
                }));
            }
        }
    });
}, function(t, e, o) {
    e.__esModule = !0;
    var n, i = o(3), r = (n = i) && n.__esModule ? n : {
        default: n
    }, a = o(4), s = o(6), u = o(0);
    var c = function() {
        function t(e, o) {
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t), this.playlist = [], this.playRate = 1, this.events = {}, this.videoCtx = wx.createVideoContext("xm_lite_video_player", o), 
            this.options = Object.assign(Object.assign({}, this.options), e), this.getVideoInfo = new a.GetVideoInfo({
                linkProtecterOptions: e.linkProtecterOptions,
                env: e.env || "prod"
            } || {}), this.eventEmitter = (0, r.default)(this.events);
        }
        return t.prototype.getVideoSrc = function(t) {
            var e = this;
            return new Promise(function(o, n) {
                e.getVideoInfo.queryVideoSrc(t).then(function(t) {
                    var e = t.ret, i = t.msg;
                    if (0 !== e) return 726 === e ? o("unauthorized") : n(i);
                    var r = t.seed, a = t.fileId, c = t.ep, l = t.duration, d = t.domain, h = t.apiVersion, f = t.trackId, p = t.albumId, g = t.isAuthorized, v = t.resolutions, y = t.sampleDuration, m = t.sampleLength, S = t.totalLength, w = t.title, b = (0, 
                    s.getEncryptedFileName)(r, a), O = (0, s.getEncryptedFileParams)(c);
                    O.duration = l;
                    var C = function(t) {
                        return t.indexOf("audio.pay.xmcdn.com") > -1 ? "https://vod.xmcdn.com" : t;
                    }(d) + "/download/" + h + b + "?" + (0, u.paramStr)(O);
                    o({
                        src: C,
                        trackId: f,
                        albumId: p,
                        isAuthorized: g,
                        resolutions: v,
                        sampleDuration: y,
                        sampleLength: m,
                        totalLength: S,
                        title: w,
                        duration: l
                    });
                }).catch(function(t) {
                    n(t);
                });
            });
        }, t.prototype.getPlayList = function() {}, t.prototype.getNextId = function() {}, 
        t.prototype.getPlayerInstance = function() {
            return this.videoCtx;
        }, t.prototype.play = function() {
            this.trigger("video.play"), this.videoCtx.play();
        }, t.prototype.pause = function() {
            this.trigger("video.pause"), console.log("pause video"), this.videoCtx.pause();
        }, t.prototype.stop = function() {
            console.log("stop vidoe"), this.trigger("video.stop"), this.videoCtx.stop();
        }, t.prototype.exitFullScreen = function() {
            this.trigger("video.exitFullScreen"), this.videoCtx.exitFullScreen();
        }, t.prototype.next = function() {
            var t = this.options;
            t.list, t.id;
        }, t.prototype.on = function(t, e) {
            this.eventEmitter.on(t, e);
        }, t.prototype.off = function(t, e) {
            this.eventEmitter.off(t, e);
        }, t.prototype.trigger = function(t, e) {
            this.eventEmitter.emit(t, e);
        }, t;
    }();
    e.default = c;
}, function(t, e, o) {
    e.__esModule = !0, e.default = function(t) {
        return {
            all: t = t || {},
            on: function(e, o) {
                var n = t[e];
                n && n.push(o) || (t[e] = [ o ]);
            },
            off: function(e, o) {
                var n = t[e];
                n && n.splice(n.indexOf(o) >>> 0, 1);
            },
            emit: function(e, o) {
                (t[e] || []).slice().map(function(t) {
                    t(o);
                }), (t["*"] || []).slice().map(function(t) {
                    t(e, o);
                });
            }
        };
    };
}, function(t, e, o) {
    e.__esModule = !0, e.GetVideoInfo = void 0;
    var n = o(5);
    e.GetVideoInfo = function() {
        function t(e) {
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t), this.linkProtecterOptions = e.linkProtecterOptions || {}, this.vidoeInfoOptions = e.vidoeInfoOptions || {}, 
            this.env = e.env;
        }
        return t.prototype.queryVideoInfo = function(t) {
            var e, o = "test" === (e = this.env) ? "http://m.test.ximalaya.com" : "uat" === e ? "http://m.uat.ximalaya.com" : "https://m.ximalaya.com";
            return (0, n.request)({
                url: o + "/m-revision/page/track/queryMPTrackPage/" + t,
                data: Object.assign({}, this.vidoeInfoOptions)
            });
        }, t.prototype.queryVideoSrc = function(t) {
            var e, o = "test" === (e = this.env) ? "http://mpay.dev.test.ximalaya.com" : "uat" === e ? "http://mpay.dev.uat.ximalaya.com" : "https://mpay.ximalaya.com";
            return (0, n.request)({
                url: o + "/mobile/track/pay/video/" + t + "/" + new Date().getTime(),
                data: Object.assign({
                    device: "h5",
                    isBackend: !1,
                    videoQualityLevel: 1,
                    isDownload: !0
                }, this.linkProtecterOptions)
            });
        }, t;
    }();
}, function(t, e, o) {
    function n(t) {
        if (!t) throw new Error("请求参数不能为空");
        if (!1 == !!t.url) throw new Error("请求地址不能为空");
        var e = t.url, o = t.method, n = void 0 === o ? "GET" : o, i = t.data, r = void 0 === i ? {} : i, a = t.dataType, s = void 0 === a ? "json" : a, u = t.header, c = t.timeout, l = void 0 === c ? 1e4 : c;
        return n = n.toUpperCase(), new Promise(function(t, o) {
            wx.request({
                url: e,
                method: n,
                data: r,
                header: u,
                dataType: s,
                timeout: l,
                success: function(e) {
                    t(e.data);
                },
                fail: function(t) {
                    console.log("request error", e, t), o(t);
                }
            });
        });
    }
    e.__esModule = !0, e.request = n, n.get = function(t, e) {
        return n(Object.assign(Object.assign({}, e), {
            method: "GET",
            url: t
        }));
    }, n.post = function(t, e) {
        return n(Object.assign(Object.assign({}, e), {
            method: "POST",
            url: t
        }));
    };
}, function(t, e, o) {
    function n(t, e) {
        for (var o, n = [], i = 0, r = "", a = 0; 256 > a; a++) n[a] = a;
        for (a = 0; 256 > a; a++) i = (i + n[a] + t.charCodeAt(a % t.length)) % 256, o = n[a], 
        n[a] = n[i], n[i] = o;
        for (var s = i = a = 0; s < e.length; s++) i = (i + n[a = (a + 1) % 256]) % 256, 
        o = n[a], n[a] = n[i], n[i] = o, r += String.fromCharCode(e.charCodeAt(s) ^ n[(n[a] + n[i]) % 256]);
        return r;
    }
    function i(t) {
        this._randomSeed = t, this.cg_hun();
    }
    e.__esModule = !0, i.prototype = {
        cg_hun: function() {
            this._cgStr = "";
            var t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/\\:._-1234567890", e = t.length, o = 0;
            for (o = 0; o < e; o++) {
                var n = this.ran() * t.length, i = parseInt(n);
                this._cgStr += t.charAt(i), t = t.split(t.charAt(i)).join("");
            }
        },
        cg_fun: function(t) {
            t = t.split("*");
            var e = "", o = 0;
            for (o = 0; o < t.length - 1; o++) e += this._cgStr.charAt(t[o]);
            return e;
        },
        ran: function() {
            return this._randomSeed = (211 * this._randomSeed + 30031) % 65536, this._randomSeed / 65536;
        },
        cg_decode: function(t) {
            var e = "", o = 0;
            for (o = 0; o < t.length; o++) {
                var n = t.charAt(o), i = this._cgStr.indexOf(n);
                -1 !== i && (e += i + "*");
            }
            return e;
        }
    };
    e.getEncryptedFileName = function(t, e) {
        var o = new i(t).cg_fun(e);
        return "/" === o[0] ? o : "/" + o;
    };
    var r = n("xm", "Ä[ÜJ=Û3Áf÷N"), a = [ 19, 1, 4, 7, 30, 14, 28, 8, 24, 17, 6, 35, 34, 16, 9, 10, 13, 22, 32, 29, 31, 21, 18, 3, 2, 23, 25, 27, 11, 20, 5, 15, 12, 0, 33, 26 ];
    e.getEncryptedFileParams = function(t) {
        var e = n(function(t, e) {
            for (var o = [], n = 0; n < t.length; n++) {
                for (var i = "a" <= t[n] && "z" >= t[n] ? t[n].charCodeAt() - 97 : t[n].charCodeAt() - "0".charCodeAt() + 26, r = 0; 36 > r; r++) if (e[r] == i) {
                    i = r;
                    break;
                }
                o[n] = 25 < i ? String.fromCharCode(i - 26 + "0".charCodeAt()) : String.fromCharCode(i + 97);
            }
            return o.join("");
        }("d" + r + "9", a), function(t) {
            if (!t) return "";
            var e, o, n, i, r, a = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
            for (i = (t = t.toString()).length, n = 0, r = ""; n < i; ) {
                do {
                    e = a[255 & t.charCodeAt(n++)];
                } while (n < i && -1 == e);
                if (-1 == e) break;
                do {
                    o = a[255 & t.charCodeAt(n++)];
                } while (n < i && -1 == o);
                if (-1 == o) break;
                r += String.fromCharCode(e << 2 | (48 & o) >> 4);
                do {
                    if (61 == (e = 255 & t.charCodeAt(n++))) return r;
                    e = a[e];
                } while (n < i && -1 == e);
                if (-1 == e) break;
                r += String.fromCharCode((15 & o) << 4 | (60 & e) >> 2);
                do {
                    if (61 == (o = 255 & t.charCodeAt(n++))) return r;
                    o = a[o];
                } while (n < i && -1 == o);
                if (-1 == o) break;
                r += String.fromCharCode((3 & e) << 6 | o);
            }
            return r;
        }(t)).split("-"), o = e[0];
        return {
            sign: e[1],
            buy_key: o,
            token: e[2],
            timestamp: e[3]
        };
    };
}, function(t, e, o) {
    e.__esModule = !0;
    e.PlayState = {
        ERROR: -1,
        INITIAL: 0,
        PLAYING: 1,
        PAUSE: 2,
        ENDED: 3,
        LOADING: 4
    }, e.PlayMode = {
        ORDERED: 0,
        RANDOM: 1,
        SINGLE_LOOP: 2,
        LIST_LOOP: 3,
        ERROR: -1
    }, e.ErrorCode = {
        INFO: 0,
        NOSOURCE: 1
    }, e.PlaySort = {
        ASC: !0,
        DESC: !1
    };
}, function(t, e, o) {
    e.__esModule = !0;
    var n = e.set = function(t, e) {
        return e = "string" == typeof e ? e : JSON.stringify(e), wx.setStorageSync(t, e);
    }, i = e.get = function(t) {
        var e = wx.getStorageSync(t);
        try {
            return JSON.parse(e);
        } catch (t) {
            return e;
        }
    }, r = e.today = new Date().toLocaleDateString();
    e.todayFirstMobileDataTip = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        return t ? (n("todayFirstMobileDataTip", r), r) : i("todayFirstMobileDataTip");
    };
} ]);