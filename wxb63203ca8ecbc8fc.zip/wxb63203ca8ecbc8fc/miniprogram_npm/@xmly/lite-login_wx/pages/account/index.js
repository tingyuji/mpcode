var e = require("../../lib/index"), t = require("../../inner_modules/@xmly/captcha-xmlite/dist/data");

Component({
    properties: {
        loginLinkVisible: {
            type: Boolean,
            value: !0
        },
        enterByRoot: {
            type: Boolean,
            value: !1
        },
        noTip: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        type: "password",
        env: (0, e.get)().XM_ENV
    },
    onInit: function() {
        this.initEnv();
    },
    created: function() {
        this.initEnv();
    },
    attached: function() {
        this.initEnv(), (0, e.log)(9572, "pageview", {
            currPage: "phoneLogin",
            loginType: "password"
        });
    },
    detached: function() {
        (0, e.log)(9573, "pageExit", {
            currPage: "phoneLogin",
            loginType: "password"
        });
    },
    methods: {
        initEnv: function() {
            var t = this.data.env = (0, e.get)().XM_ENV;
            this.setData({
                env: t
            });
        },
        initcap: function() {
            var i = (0, t.getInstance)();
            this.cap = i, i.once("success", function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.token;
                i && (e.cookies.set("fds_otp", i, {
                    expires: Date.now() + 864e5
                }), (0, e.setFdsOtp)(i));
            });
        },
        startCap: function(t) {
            var i = this.cap;
            return i.start(null, t), new Promise(function(t, n) {
                i.once("success", function() {
                    var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = i.token;
                    n ? t(e.cookies.set("fds_otp", n, {
                        expires: Date.now() + 864e5,
                        domain: "ximalaya.com"
                    }), (0, e.setFdsOtp)(n)) : t();
                }), i.once("error", n);
            });
        },
        onPhoneInput: function(e) {
            this.mobile = e.detail;
        },
        onPwdInput: function(e) {
            this.password = e.detail.value.trim();
        },
        changeLogin: function() {
            (0, e.log)(9575, "click", {
                currPage: "phoneLogin",
                item: "其他登录方式",
                loginType: "securityCode"
            }), (0, e.getHistory)().push("/login");
        },
        onSubmit: function() {
            if ((0, e.checkUserHasAgree)()) {
                var t = this.data.type;
                "email" === t ? this.submitEmailForm() : "password" === t && this.submitPwdForm();
            }
        },
        submitPwdForm: function() {
            var t = this.mobile, i = this.password, n = this.props || this.data || {}, o = (n.enterByRoot, 
            n.noTip), s = (0, e.get)().APP_KEY;
            (0, e.log)(9574, "click", {
                currPage: "phoneLogin",
                item: "登录",
                loginType: "password"
            });
            var a = (0, e.getHistory)();
            if (!i) return e.Toast.info("密码不能为空");
            if (!t) return e.Toast.info("手机号不能为空");
            if (!s) return e.Toast.info("appkey不能为空");
            var r = {
                account: t,
                password: i,
                appKey: s
            };
            this.startCap(t).then(function() {
                return (0, e.accoutLogin)(r);
            }).then(function(t) {
                var i = t.ret, n = t.msg, s = t.bizKey, r = t.mobileMask, c = t.mobileCipher, p = t.uid, u = t.loginType, l = t.thirdpartyId, h = void 0 === l ? "" : l;
                if (0 === i) e.onSuccess.call({
                    uid: p,
                    loginType: u
                }); else if (20004 === i) a.push("/bindPhone?bizKey=" + s + "&thirdpartyId=" + h); else if (20005 === i) {
                    var d = "/checkPhone?bizKey=" + s + "&mobileMask=" + r + "&mobileCipher=" + c + "&thirdpartyId=" + h;
                    a.push(d);
                } else if (20007 === i) {
                    if (o) return e.Toast.info("密码错误");
                    (0, e.Alert)("密码错误", "试试验证码登录吧", {
                        text: "知道了"
                    }).then(function(e) {
                        e && a.push("/smscode");
                    });
                } else if (20011 === i) {
                    if (o) return e.Toast.info("登录频繁稍后再试~");
                    (0, e.Alert)("登录频繁", "请使用验证码登录", {
                        text: "知道了"
                    }).then(function(e) {
                        e && a.push("/smscode");
                    });
                } else e.Toast.info(n || "network error");
            });
        }
    }
});