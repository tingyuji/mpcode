var e = require("../../../../../@babel/runtime/helpers/objectWithoutProperties"), t = require("../../../../../@babel/runtime/helpers/objectSpread2"), r = require("../../lib/index"), o = [ "key" ], i = [ "code" ], n = [ "key" ], a = [ "code", "message" ];

Component({
    properties: {
        noAuth: {
            type: Boolean,
            value: !1
        },
        appKey: {
            type: String,
            value: ""
        },
        ignoreWays: {
            type: Array,
            value: []
        }
    },
    data: {
        RUN_ENV: (0, r.get)().RUN_ENV,
        platform: "",
        canIUseGetUserProfile: !1,
        ignoreWay: {},
        hasAgree: !1
    },
    attached: function() {
        this.updateAgreeRadio(), (0, r.log)(9562, "pageview", {
            currPage: "login",
            fromUrl: (0, r.get)().RUN_ENV
        }), "wx" === (0, r.get)().RUN_ENV && wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        });
        var e = this.props || this.data || {};
        e.appKey && ((0, r.set)("APP_KEY", e.appKey), this.appKey = e.appKey);
        try {
            var t = {};
            e.ignoreWays && e.ignoreWays.forEach(function(e) {
                t[e] = !0;
            }), this.setData({
                ignoreWay: t
            });
        } catch (e) {
            throw new Error("Error: " + e);
        }
    },
    detached: function() {
        (0, r.log)(9563, "pageExit", {
            currPage: "login",
            fromUrl: (0, r.get)().RUN_ENV
        }), clearTimeout(this.codeTimer);
    },
    methods: {
        updateAgreeRadio: function() {
            var e = (0, r.getUserHasAgree)();
            this.setData({
                hasAgree: e
            });
        },
        toCheckPhone: function(e) {
            var t = e.detail.url;
            (0, r.getHistory)().push(t);
        },
        getCode: function() {
            var e = this;
            return new Promise(function(t, o) {
                if ("wx" === (0, r.get)().RUN_ENV && "undefined" != typeof wx) {
                    wx.login({
                        success: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.code;
                            t(r);
                        },
                        fail: function(t) {
                            return e.codeError = t, o(t);
                        }
                    });
                }
            });
        },
        getUserInfo: function(e) {
            var t = this, o = e.detail, i = o.iv, n = o.encryptedData;
            this.getCode().then(function(e) {
                e && new Promise(function(r, o) {
                    e ? r({
                        code: e
                    }) : o(t.codeError || "授权码获取失败");
                }).then(function(e) {
                    var r = e.code;
                    return t.onAuth({
                        code: r,
                        encryptedData: n,
                        iv: i
                    });
                }).then(t.onThirdPartyLogin.bind(t)).catch(t.onThirdPartyError.bind(t));
            }).catch(function(e) {
                r.Toast.info("授权code获取失败:".concat(e.message));
            });
            (0, r.log)(9564, "clickButton", {
                currPage: "login",
                item: "微信账号登录"
            });
        },
        onBtnClicked: function(e) {
            if ((0, r.checkUserHasAgree)()) {
                var t = e.target.targetDataset || e.target.dataset, o = t.type, i = t.url, n = (0, 
                r.getHistory)(), a = "";
                if ("alipay-account" === o) a = "支付宝账号登录"; else if ("baidu-account" === o) a = "百度账号登录"; else {
                    if ("wechat-account" === o) return;
                    "qq-account" === o && (a = "QQ账号登录");
                }
                a && ((0, r.getAuthUniInfo)().then(this.onAuth.bind(this)).then(this.onThirdPartyLogin.bind(this)).catch(this.onThirdPartyError.bind(this)), 
                (0, r.log)(9564, "clickButton", {
                    currPage: "login",
                    item: a
                })), i && n.push(i);
            }
        },
        getUserProfile: function() {
            var e = this;
            if (!wx.getUserProfile) return r.Toast.info("不支持wx.getUserProfile");
            this.hasClicked || (this.hasClicked = !0, wx.getUserProfile({
                desc: "用于完善会员资料",
                success: function(o) {
                    e.hasClicked = !1;
                    var i = o.userInfo;
                    e.getCode().then(function(r) {
                        r && new Promise(function(t, o) {
                            r ? t({
                                code: r
                            }) : o(e.codeError || "授权码获取失败");
                        }).then(function(r) {
                            return e.onAuthV2(t(t({
                                code: r ? r.code : ""
                            }, i), {}, {
                                avatar: i.avatarUrl
                            }));
                        }).then(e.onThirdPartyLogin.bind(e)).catch(e.onThirdPartyError.bind(e));
                    }).catch(function(e) {
                        r.Toast.info("授权code获取失败:".concat(e.message));
                    });
                },
                fail: function(t) {
                    e.hasClicked = !1, r.Toast.info("已取消授权");
                }
            }));
        },
        onAuth: function(i) {
            var n = i.code, a = i.encryptedData, c = i.iv, s = (0, r.get)().THIRD_PART_ID, d = this.appKey;
            return (0, r.authLogin)({
                thirdpartyId: s,
                code: n,
                encryptedData: a,
                iv: c,
                appKey: d
            }).then(function(r) {
                var i = r.key, a = e(r, o);
                return t(t({
                    key: i
                }, a), {}, {
                    code: n
                });
            });
        },
        onAuthV2: function(o) {
            var a = o.code, c = e(o, i), s = (0, r.get)().THIRD_PART_ID, d = this.appKey;
            return (0, r.authLoginV2)(t({
                thirdpartyId: s,
                code: a,
                appKey: d
            }, c)).then(function(r) {
                var o = r.key, i = e(r, n);
                return t(t({
                    key: o
                }, i), {}, {
                    code: a
                });
            });
        },
        onThirdPartyLogin: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.ret, o = e.msg, i = e.bizKey, n = e.mobileMask, a = e.mobileCipher, c = e.uid, s = e.loginType, d = e.thirdpartyId, h = void 0 === d ? "" : d, u = (0, 
            r.getHistory)();
            switch (t) {
              case 0:
                (0, r.log)("send", "event", {
                    serviceId: "login",
                    userId: c,
                    loginType: s,
                    id: 6548
                }), r.onSuccess.call({
                    uid: c,
                    loginType: s
                });
                break;

              case 20004:
                u.push("/bindPhone?bizKey=" + i + "&thirdpartyId=" + h + "&loginType=" + s);
                break;

              case 20005:
                u.push("/checkPhone?bizKey=" + i + "&mobileMask=" + n + "&mobileCipher=" + a + "&thirdpartyId=" + h);
                break;

              default:
                throw {
                    code: t,
                    message: o
                };
            }
        },
        onThirdPartyError: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = t.code, i = void 0 === o ? -1 : o, n = t.message, c = void 0 === n ? "未知异常" : n, s = e(t, a);
            if (-2 === i) return (0, r.Alert)("系统异常提示", "请在设置中开启公开信息按钮").then(function() {
                return swan.openSetting({});
            });
            console.log(s, "error rest info"), r.Toast.info(c);
        }
    }
});