var e = require("../../../../../@babel/runtime/helpers/objectWithoutProperties"), o = require("../../lib/index"), i = [ "message", "code" ];

Component({
    properties: {
        env: {
            type: String,
            value: "test"
        }
    },
    data: {},
    attached: function() {
        var e = (0, o.getHistory)().location.query, i = (e = void 0 === e ? {} : e).bizKey, t = e.loginType;
        this.bizKey = i, this._loginPage = !0, (0, o.log)(9566, "pageview", {
            currPage: "bindPhone",
            loginType: t
        });
    },
    detached: function() {
        var e = (0, o.getHistory)().location.query, i = (e = void 0 === e ? {} : e).loginType;
        (0, o.log)(9567, "pageExit", {
            currPage: "bindPhone",
            loginType: i
        });
    },
    methods: {
        onPhoneInput: function(e) {
            var o = this.mobile = e.detail;
            this.setData({
                mobile: o
            });
        },
        onCodeInput: function(e) {
            this.code = e.detail;
        },
        onSubmit: function() {
            var t = this.mobile, n = this.code, r = this.bizKey, a = (0, o.get)().APP_KEY;
            return n ? t ? r ? a ? ((0, o.log)(9568, "click", {
                currPage: "bindPhone",
                item: "绑定并登录"
            }), void (0, o.bindPhone)({
                mobile: t,
                code: n,
                bizKey: r,
                appKey: a
            }).then(function(e) {
                var i = e.ret, t = e.msg, n = e.uid, r = e.loginType;
                if (0 !== i) throw {
                    code: i,
                    message: t
                };
                (0, o.log)("send", "event", {
                    serviceId: "login",
                    userId: n,
                    loginType: r,
                    id: 6548
                }), o.onSuccess.call({
                    uid: n,
                    loginType: r
                });
            }).catch(function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.message, r = void 0 === n ? "network error" : n, a = t.code, s = e(t, i);
                console.log(s, "err info"), 33009 === a && (r = r.replace("是否强制绑定？", "请更换手机号")), 
                o.Toast.info(r);
            })) : o.Toast.info("appkey不能为空") : o.Toast.info("bizKey不能为空") : o.Toast.info("手机号不能为空") : o.Toast.info("验证码不能为空");
        }
    }
});