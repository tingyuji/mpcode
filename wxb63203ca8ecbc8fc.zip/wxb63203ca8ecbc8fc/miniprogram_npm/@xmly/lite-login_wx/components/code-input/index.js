var t = require("../../lib/index"), n = require("../../inner_modules/@xmly/captcha-xmlite/dist/data");

Component({
    properties: {
        placeholder: {
            type: String,
            value: "请输入验证码"
        },
        mobile: {
            type: String,
            value: ""
        }
    },
    data: {
        codeBtnText: "获取验证码",
        env: (0, t.get)().XM_ENV
    },
    onInit: function() {
        this.initEnv();
    },
    created: function() {
        this.initEnv();
    },
    attached: function() {
        this.initEnv();
    },
    methods: {
        initEnv: function() {
            var n = (0, t.get)().XM_ENV, e = "test" === n ? 143 : 139;
            (this.props || this.data || {}).bpid = e, this.data.env = n, this.setData({
                bpid: e,
                env: n
            });
        },
        initcap: function() {
            var t = (0, n.getInstance)();
            this.cap = t;
        },
        startCap: function(n) {
            var e = this.cap;
            return e.start(null, n), new Promise(function(n, i) {
                e.once("success", function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = e.token;
                    i ? n(t.cookies.set("fds_otp", i, {
                        expires: Date.now() + 864e5,
                        domain: "ximalaya.com"
                    }), (0, t.setFdsOtp)(i)) : n();
                }), e.once("error", i);
            });
        },
        onInput: function(t) {
            var n = t.detail.value;
            this.triggerEvent("input", n);
        },
        onCodeBtnClick: function() {
            var n = this, e = this.data.mobile;
            if (!e) return t.Toast.info("手机号不能为空");
            this._counting || this.startCap(e).then(function() {
                return (0, t.getSMSCode)({
                    mobile: e
                });
            }).then(function(e) {
                var i = e.ret, a = e.msg;
                if (n._clicked = !1, 0 === i) return n._startCount();
                t.Toast.info(a);
            }).catch(function() {
                var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                t.Toast.info(n.msg || "network error");
            });
        },
        _startCount: function() {
            var t = this;
            this._timer && clearInterval(this._timer), this._counting = !0;
            var n = 60;
            this._timer = setInterval(function() {
                --n <= 0 ? (clearInterval(t._timer), t._counting = !1, t.setData({
                    codeBtnText: "重新发送"
                })) : t.setData({
                    codeBtnText: n + "秒后重发"
                });
            }, 1e3);
        }
    }
});