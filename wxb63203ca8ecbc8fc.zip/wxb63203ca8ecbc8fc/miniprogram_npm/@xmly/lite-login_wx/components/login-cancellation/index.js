var t = require("../../lib/index");

Component({
    externalClasses: [ "cancellation-class" ],
    properties: {
        env: {
            type: String,
            value: ""
        }
    },
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {
        handleLogout: function() {
            var e = this, n = this.props || this.data || {}, o = n.env ? {
                env: n.env
            } : {};
            (0, t.logout)(o).then(function() {
                e.triggerEvent("logoutsuccess");
            });
        },
        closeModal: function() {
            this.triggerEvent("closeModal");
        }
    }
});