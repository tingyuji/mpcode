var e = require("../../../../../@babel/runtime/helpers/objectWithoutProperties"), t = require("../../../../../@babel/runtime/helpers/objectSpread2"), i = require("../../lib/index"), n = [ "key" ], r = [ "code", "encryptedData", "iv" ], o = [ "key" ];

Component({
    externalClasses: [ "c-class" ],
    properties: {
        text: {
            type: String,
            value: ""
        },
        thirdpartyId: {
            type: Number,
            value: void 0
        },
        env: {
            type: String,
            value: ""
        },
        scoped: {
            type: Boolean,
            value: !1
        },
        appKey: {
            type: String,
            value: ""
        }
    },
    data: {
        showPop: !1,
        RUN_ENV: (0, i.get)().RUN_ENV,
        canIUseGetUserProfile: !1
    },
    attached: function() {
        var e = this.props || this.data || {};
        this.thirdpartyId = e.thirdpartyId || (0, i.get)().THIRD_PART_ID, e.env && (0, i.set)("XM_ENV", e.env), 
        "wx" === (0, i.get)().RUN_ENV && wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        }), e.appKey && ((0, i.set)("APP_KEY", e.appKey), this.appKey = e.appKey);
    },
    detached: function() {
        clearTimeout(this.codeTimer);
    },
    methods: {
        isNotWx: function() {
            return "wx" !== (0, i.get)().RUN_ENV || "undefined" == typeof wx;
        },
        isNotSwan: function() {
            return "swan" !== (0, i.get)().RUN_ENV || "undefined" == typeof swan;
        },
        getCode: function() {
            var e = this;
            return new Promise(function(t, n) {
                if (e.isNotWx() && e.isNotSwan()) t(); else {
                    ("wx" === (0, i.get)().RUN_ENV ? wx.login : swan.getLoginCode)({
                        success: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = e.code;
                            t(i);
                        },
                        fail: function(t) {
                            return e.codeError = t, n(t);
                        }
                    });
                }
            });
        },
        getUserInfo: function(e) {
            var t = this, n = e.detail, r = n.iv, o = n.encryptedData;
            o && (this.appKey ? this.getCode().then(function(e) {
                e && new Promise(function(i, n) {
                    e ? i({
                        code: e
                    }) : n(t.codeError || "授权码获取失败");
                }).then(function(e) {
                    var i = e.code;
                    return t.onAuth({
                        code: i,
                        encryptedData: o,
                        iv: r
                    });
                }).then(t.onAuthSuccess.bind(t)).then(t.success.bind(t), t.fail.bind(t));
            }).catch(function(e) {
                i.Toast.info("授权code获取失败:".concat(e.message));
            }) : i.Toast.info("appkey不能为空"));
        },
        getUserProfile: function() {
            var e = this;
            if (!wx.getUserProfile) return i.Toast.info("不支持wx.getUserProfile");
            this.hasClicked || (this.appKey ? (this.hasClicked = !0, wx.getUserProfile({
                desc: "用于完善会员资料",
                success: function(n) {
                    e.hasClicked = !1;
                    var r = n.userInfo;
                    e.getCode().then(function(i) {
                        i && new Promise(function(t, n) {
                            i ? t({
                                code: i
                            }) : n(e.codeError || "授权码获取失败");
                        }).then(function(i) {
                            return e.onAuthV2(t(t({
                                code: i ? i.code : ""
                            }, r), {}, {
                                avatar: r.avatarUrl
                            }));
                        }).then(e.onAuthSuccess.bind(e)).then(e.success.bind(e), e.fail.bind(e));
                    }).catch(function(e) {
                        i.Toast.info("授权code获取失败:".concat(e.message));
                    });
                },
                fail: function(t) {
                    e.hasClicked = !1, i.Toast.info("已取消授权");
                }
            })) : i.Toast.info("appkey不能为空"));
        },
        getPhoneNumber: function(e) {
            this.appKey ? (this.authData = e.detail, this.authData.encryptedData && (0, i.getAuthUniInfo)().then(this.onAuth.bind(this)).then(this.onAuthSuccess.bind(this)).then(this.success.bind(this), this.fail.bind(this))) : i.Toast.info("appkey不能为空");
        },
        success: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.ret, n = e.msg, r = this.props || this.data;
            if (0 !== t) throw {
                code: t,
                message: n
            };
            return r.scoped || i.onSuccess.call(e), this.triggerEvent("success", e), e;
        },
        fail: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.message, n = void 0 === t ? "auth error" : t;
            console.log(e, "error"), this.triggerEvent("fail", e), i.Toast.info(n);
        },
        onAuth: function(r) {
            var o = r.code, a = r.encryptedData, s = r.iv, c = this.thirdpartyId, h = this.appKey;
            return (0, i.authLogin)({
                thirdpartyId: c,
                code: o,
                encryptedData: a,
                iv: s,
                appKey: h
            }).then(function(i) {
                var r = i.key, a = e(i, n);
                return t(t({
                    key: r
                }, a), {}, {
                    code: o
                });
            });
        },
        onAuthV2: function(n) {
            var a = n.code, s = n.encryptedData, c = n.iv, h = e(n, r), d = this.thirdpartyId, u = this.appKey;
            return (0, i.authLoginV2)(t({
                thirdpartyId: d,
                code: a,
                encryptedData: s,
                iv: c,
                appKey: u
            }, h)).then(function(i) {
                var n = i.key, r = e(i, o);
                return t(t({
                    key: n
                }, r), {}, {
                    code: a
                });
            });
        },
        onAuthSuccess: function(e) {
            var t = this, i = e.bizKey, n = e.ret, r = e.mobileCipher, o = e.mobileMask, a = e.msg, s = e.loginType, c = this.thirdpartyId;
            if (console.log("onAuthSuccess", n), 0 === n) return e;
            if (20005 !== n) {
                if (20004 === n) return this.getPermit().then(function() {
                    return t.toBindPhone({
                        thirdpartyLoginKey: i
                    });
                }).catch(function(e) {
                    t.triggerEvent("bindphone", {
                        url: "/bindPhone?bizKey=" + i + "&thirdpartyId=" + c + "&loginType=" + s
                    });
                });
                throw {
                    code: n,
                    message: a
                };
            }
            this.triggerEvent("checkphone", {
                url: "/checkPhone?bizKey=" + i + "&mobileMask=" + o + "&mobileCipher=" + r + "&thirdpartyId=" + c
            });
        },
        getPermit: function() {
            var e = this;
            return new Promise(function(t) {
                "wx" === (0, i.get)().RUN_ENV || "swan" === (0, i.get)().RUN_ENV ? (e._resolver = t, 
                e.setData({
                    showPop: !0
                })) : t();
            });
        },
        onPermitBtnClick: function(e) {
            this.authData = e.detail, this.setData({
                showPop: !1
            }), this._resolver();
        },
        closePop: function() {
            this.setData({
                showPop: !1
            });
        },
        toBindPhone: function(e) {
            var t = e.thirdpartyLoginKey, n = this.authData || {}, r = n.encryptedData, o = n.iv, a = n.errMsg;
            if (!r) throw {
                code: 500,
                message: void 0 === a ? "获取手机号失败" : a
            };
            var s = this.thirdpartyId;
            return (0, i.getMyEncryptPhone)({
                encryptedData: r,
                iv: o
            }).then(function(e) {
                var n = e.encryptedData, r = e.iv;
                return (0, i.decryptPhone)({
                    encryptedData: n,
                    iv: r,
                    thirdpartyId: s
                }).then(function(e) {
                    var n = e.ret, r = e.msg, o = e.data;
                    if (0 !== n) throw {
                        code: n,
                        message: r
                    };
                    return (0, i.liteBindPhone)({
                        thirdpartyLoginKey: t,
                        mobileKey: o,
                        forceBind: !1,
                        thirdpartyId: s
                    });
                });
            });
        }
    }
});