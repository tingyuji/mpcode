var t = require("../../lib/index"), e = require("./areaCode.js");

Component({
    properties: {
        open: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        areaCodeList: e,
        queryList: [],
        history: [ {
            name: "中国",
            code: "+86",
            engName: "China",
            index: "0",
            firstWord: "C",
            shouzimu: "ZG"
        } ]
    },
    attached: function() {
        var a = this;
        this._dataSet = [], e.forEach(function(t) {
            var e = t.list;
            a._dataSet = a._dataSet.concat(e);
        }), t.storage.get("area_search_history").then(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.data;
            Array.isArray(e) && e.length > 0 && a.setData({
                history: e
            });
        });
    },
    detached: function() {
        t.storage.set("area_search_history", this.data.history);
    },
    methods: {
        onItemClicked: function(t) {
            var e = this, a = t.target.targetDataset || t.target.dataset, r = a.code, i = a.coutry;
            r && (setTimeout(function() {
                e._addHfsItem(i);
            }, 200), this.triggerEvent("selected", r));
        },
        closePanel: function() {
            this.triggerEvent("close");
        },
        clearSearchInput: function() {
            this.setData({
                inputData: ""
            });
        },
        onSearchInput: function(t) {
            var e = this, a = t.detail.value, r = this._dataSet.filter(function(t) {
                var r = t.name, i = t.code, o = t.engName, n = t.shouzimu;
                return e._compare(a, r) || e._compare(a, i) || e._compare(a, o) || e._compare(a, n);
            });
            this.setData({
                inputData: a,
                queryList: r
            });
        },
        _compare: function(t, e) {
            return t = t.toLowerCase(), -1 !== (e = e.toLowerCase()).indexOf(t);
        },
        _addHfsItem: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = this.data.history;
            if (e.find(function(e) {
                return e.code === t.code;
            })) return !1;
            e = e.concat(t), this.setData({
                history: e
            });
        }
    }
});