var n = require("../../common/apis/channellist"), e = require("../../common/utils/index"), a = require("../../common/utils/logger");

Page({
    data: {
        groups: [],
        channels: [],
        currentGroupId: 0,
        channelTop: 0
    },
    onLoad: function() {
        this.init();
    },
    onTabItemTap: function() {},
    init: function() {
        var e = this;
        (0, n.queyrAllChannelGroups)().then(function(n) {
            var a = n[0] && n[0].id || 0;
            e.setData({
                groups: n
            }), e.getChannels(a);
        });
    },
    getChannels: function(e) {
        var a = this;
        (0, n.queryChannelsByGroupId)(e).then(function(n) {
            a.setData({
                channels: n,
                currentGroupId: e
            });
        });
    },
    changeGroup: function(n) {
        var t = (0, e.getDataset)(n).id;
        (0, a.genLogger)(30125, "click", {
            categoryCode: t,
            currPage: "AllChannel"
        }), this.setData({
            channelTop: 0
        }), this.getChannels(t);
    },
    onTapChannel: function(n) {
        var t = (0, e.getDataset)(n).id, r = this.data.currentGroupId;
        (0, a.genLogger)(30126, "click", {
            categoryCode: r,
            channelId: t,
            currPage: "AllChannel"
        }), wx.navigateTo({
            url: "/pages/channel/index?id=".concat(t)
        });
    },
    onShareAppMessage: function() {
        return {
            title: "全部频道-喜马拉雅",
            path: "/pages/channellist/index"
        };
    }
});