var a = require("../../common/utils/index"), t = (require("../../common/utils/logger"), 
{
    album: "/pages/albumDetail/albumDetail",
    track: "/pages/soundPage/soundPage"
}), e = {
    album: "albumId",
    track: "trackId"
};

Page({
    data: {
        animationData: {}
    },
    onLoad: function(a) {
        a.type;
        this.animation = wx.createAnimation({
            duration: 1e3,
            timingFunction: "ease",
            delay: 0
        }), this.animateHand();
    },
    onUnload: function() {},
    onClickClose: function() {
        var n = getCurrentPages();
        if (n.length > 1) {
            var i = this.options, o = i.pageType, s = i.id, r = t[o] ? t[o] + "?" + e[o] + "=" + s : "";
            return r ? wx.redirectTo({
                url: r
            }) : wx.navigateBack();
        }
        1 === n.length && "/pages/index/index" === n[0].path || (0, a.toHome)();
    },
    animateHand: function() {
        this.animation.scale(1.2).step().scale(1).step(), this.setData({
            animationData: this.animation.export()
        });
    }
});