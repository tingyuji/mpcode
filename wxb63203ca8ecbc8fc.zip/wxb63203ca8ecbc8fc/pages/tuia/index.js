var t = require("../../@babel/runtime/helpers/objectSpread2"), a = function(t, a) {
    var n = "a_oId=".concat(a);
    return -1 !== t.indexOf("?") ? t + "&".concat(n) : t + "?".concat(n);
}, n = function(t, a) {
    a._t = Date.now();
    var n = Object.keys(a).map(function(t) {
        return "".concat(t, "=").concat(encodeURIComponent(a[t]));
    }).join("&"), e = "https://activity.yuyiya.com" + t + "?".concat(n);
    console.log("http", e), wx.getImageInfo({
        src: e
    });
};

Page({
    data: {
        log: null,
        appConfig: null,
        bgImage: "",
        btnImage: ""
    },
    onLoad: function(t) {
        console.log(t);
        var n = t.appId, e = t.url, o = t.orderId, i = t.consumerId, l = t.slotId, s = t.deviceId, p = t.userId, g = t.wxAppId, r = t.wxAppPath, c = t.bgImage, d = t.btnImage, u = t.title;
        r = unescape(r), c && this.setData({
            bgImage: unescape(c)
        }), d && this.setData({
            btnImage: unescape(d)
        }), this.data.appConfig = {
            appId: g,
            path: a(r, o),
            extraData: {}
        }, console.log(this.data.appConfig), u ? wx.setNavigationBarTitle({
            title: unescape(u)
        }) : wx.setNavigationBarTitle({
            title: "天天领好礼"
        });
        var I = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            if (-1 === t.indexOf("?")) return {};
            var a = t.split("?")[1], n = a.split("&"), e = {};
            return n.forEach(function(t) {
                var a = t.split("=");
                e[a[0]] = a[1];
            }), e;
        }(e = unescape(e)).id;
        this.data.log = {
            version: "2.0.0",
            url: encodeURIComponent(e),
            cid: i,
            tuiaId: o,
            oId: o,
            landId: I,
            slotId: l,
            deviceId: s,
            appId: n,
            userId: p
        }, this.singleExp({
            typeData: {
                type: 7,
                url: "/log/inner"
            },
            json: this.data.log
        }), this.singleExp({
            typeData: {
                type: 49,
                url: "/log/landLog"
            },
            json: this.data.log
        });
    },
    openApp: function() {
        var a = this;
        this.singleClk({
            typeData: {
                type: 110,
                url: "/log/landLog"
            },
            json: t(t({}, this.data.log), {}, {
                location: 5,
                sign_type: "expose"
            })
        });
        var n = this.data.appConfig;
        wx.navigateToMiniProgram ? wx.navigateToMiniProgram({
            appId: n.appId,
            path: n.path,
            extraData: n.extraData,
            success: function() {
                a.singleClk({
                    typeData: {
                        type: 110,
                        url: "/log/landLog"
                    },
                    json: t(t({}, a.data.log), {}, {
                        location: 1,
                        sign_type: "click"
                    })
                });
            },
            fail: function() {
                a.singleClk({
                    typeData: {
                        type: 110,
                        url: "/log/landLog"
                    },
                    json: t(t({}, a.data.log), {}, {
                        location: 3,
                        sign_type: "click"
                    })
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        });
    },
    singleExp: function(t) {
        var a = t.json, e = t.typeData;
        if (console.log("singleExp", a, e), a.oId) {
            var o = e.url, i = e.type;
            n(o, {
                type: i,
                json: JSON.stringify(a)
            });
        }
    },
    singleClk: function(a) {
        var e = a.json, o = a.typeData;
        if (console.log("singleClk", e, o), e.oId) {
            var i = o.url, l = o.type;
            n(i, {
                type: l,
                json: JSON.stringify(t(t({}, e), {}, {
                    group: 1
                }))
            });
        }
    }
});