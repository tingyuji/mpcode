var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/utils/index"), o = require("../../common/utils/storage"), i = require("../../common/apis/home"), a = require("../../common/utils/logger"), n = require("../../packages/lite-player/event"), r = require("../../common/utils/tabbar"), s = {
    type: "ad",
    data: {
        id: t.hpFeedVideoAdId
    }
}, c = [ {
    index: 1,
    src: (0, t.fillImageUrl)("storages/64d6-audiofreehighqps/9E/FC/GMCoOSQG55RyAAARjwGbOQ5t.png"),
    title: "排行榜",
    url: "/pages/rankpage/rankpage"
}, {
    index: 2,
    src: (0, t.fillImageUrl)("storages/47ca-audiofreehighqps/F5/8C/GKwRIJIG55RyAAAWMQGbOQ5P.png"),
    title: "广播",
    url: "/pages/radio/radio",
    isRadio: !0
}, {
    index: 3,
    src: (0, t.fillImageUrl)("storages/2cc2-audiofreehighqps/11/5F/GKwRIDoG55RyAAAT-QGbOQ4v.png"),
    title: "助眠解压",
    url: "/subpackage/pages/sleep/index",
    hiddenAfterClick: !0
}, {
    index: 4,
    src: (0, t.fillImageUrl)("storages/faf4-audiofreehighqps/5D/1F/GKwRIUEG55RxAAAVQQGbOQ3L.png"),
    title: "今日热点",
    url: "/pages/hotNews/index?trackId=448791417&groupId=80"
}, {
    index: 5,
    src: (0, t.fillImageUrl)("storages/3c39-audiofreehighqps/BE/0E/GKwRIW4G55VIAAAR2gGbOZnU.png"),
    title: "全部分类",
    url: "/pages/channellist/index"
} ];

Page({
    data: {
        scrollY: !0,
        modules: [],
        categoryPinyin: "recommend",
        cateList: [ {
            categoryName: ""
        } ],
        upgradeModalVisible: !1,
        homeBanner: {},
        feedInfos: [],
        hasMoreFeed: !0,
        scrollTop: 0,
        showSkeleton: !0,
        tabTopHeight: ((0, t.isOldVersion)() ? 0 : (0, t.getStatusBarHeight)()) + 38 + 3,
        showTip: !0,
        isFeedLoading: !1,
        isLogin: (0, t.isLogin)(),
        isTest: !1,
        innerTop: -((0, t.getStatusBarHeight)() + 38 + 3 + 111)
    },
    onLoad: function() {
        this.path = "/pages/index/index", this.queryCategories(), this.queryRecommendBannerInfo(), 
        this.queryFeedInfo(!0, !0), n.EventBus.on("close_add_tip", this.closeShowTip), n.EventBus.on("backHomeTop", this.onTabItemTap), 
        this.showBackTop = !1, this.canBackTop = !0, this.feedErrorIndex = 0;
        var e = c;
        this.setData({
            isLogin: (0, t.isLogin)(),
            tomatoList: e
        });
    },
    onReady: function() {
        this.showUpgradeModal();
    },
    onUnload: function() {
        n.EventBus.off("close_add_tip", this.closeShowTip), n.EventBus.on("backHomeTop", this.onTabItemTap);
    },
    onShow: function() {
        var e = this;
        (0, r.setTabBar)(this), setTimeout(function() {
            e.canBackTop = !0, e.showBackTop && e.setHomeTabBar(!0);
        }, 300), this.setData({
            showTip: !(0, o.get)("close_add_tip") && !(0, t.hideAddToMyTip)()
        }), this.createTomatoObserver(), this.createHistoryObserver(), this.createHotrecommendObserver(), 
        this.createFeedObserver();
    },
    onHide: function() {
        this.setHomeTabBar(!1), this.canBackTop = !1;
    },
    closeShowTip: function() {
        this.setData({
            showTip: !1
        });
    },
    createTomatoObserver: function() {
        var e = this;
        this._observer1 = wx.createIntersectionObserver(this), this._observer1.relativeToViewport({
            top: this.data.innerTop
        }).observe(".tomato-wrapper", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47579, {
                currPage: "wx-newhome"
            }), e._observer1.disconnect());
        });
    },
    createHistoryObserver: function() {
        var e = this;
        this._observer4 = wx.createIntersectionObserver(this), this._observer4.relativeToViewport({
            top: this.data.innerTop
        }).observe(".historylist-new", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47577, {
                currPage: "wx-newhome"
            }), e._observer4.disconnect());
        });
    },
    createHotrecommendObserver: function() {
        var e = this;
        this._observer2 = wx.createIntersectionObserver(this), this._observer2.relativeToViewport({
            top: this.data.innerTop
        }).observe(".hot-recommend", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47581, {
                currPage: "wx-newhome"
            }), e._observer2.disconnect());
        });
    },
    createFeedObserver: function() {
        var e = this;
        this._observer3 = wx.createIntersectionObserver(this), this._observer3.relativeToViewport({
            top: this.data.innerTop
        }).observe("#feed", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47583, {
                currPage: "wx-newhome"
            }), e._observer3.disconnect());
        });
    },
    runTest: function() {
        var e = "202209_exper_cpp", t = wx.getExptInfoSync([ e ]), o = !1;
        o = void 0 !== t[e] && ("0" != t[e] && "1" == t[e]), this.setData({
            isTest: o
        });
    },
    onTabItemTap: function() {
        var e = this;
        this.showBackTop && this.canBackTop && (this.canBackTop = !1, this.setData({
            scrollTop: 0
        }, function() {
            e.setHomeTabBar(!1), e.showBackTop = !1, e.canBackTop = !0;
        }));
    },
    onScroll: function(e) {
        var t = e.detail.scrollTop > 300;
        this.showBackTop !== t && this.canBackTop && (this.setHomeTabBar(t), this.showBackTop = t);
    },
    setHomeTabBar: function() {
        var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
        n.EventBus.emit("setHomeBackIcon", e);
    },
    queryCategories: function() {
        var e = this;
        (0, i.getIndexCategories)().then(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            e.setData({
                cateList: t,
                categoryPinyin: t[0].categoryPinyin || ""
            }, e.queryIndexContent(t[0].categoryPinyin));
        });
    },
    queryIndexContent: function(e) {
        var t = this, o = this;
        (0, i.getIndexContent)(e).then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            e.length && o.setData({
                modules: e
            }, function() {
                wx.hideToast(), setTimeout(function() {
                    t.setData({
                        showSkeleton: !1
                    });
                }, 500);
            });
        }).catch(function() {
            t.setData({
                showSkeleton: !1
            });
        });
    },
    queryRecommendBannerInfo: function() {
        var e = this;
        (0, i.queryRecommendBanner)().then(function(t) {
            var o = (t || {}).slideshow, i = void 0 === o ? [] : o;
            setTimeout(function() {
                e.setData({
                    homeBanner: {
                        moduleInfo: i
                    }
                });
            }, 200);
        }).catch(function() {
            e.setData({
                homeBanner: {
                    moduleInfo: []
                }
            });
        });
    },
    queryFeedInfo: function() {
        var e = this, o = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = this.data, r = n.feedInfos, c = n.hasMoreFeed, d = n.categoryPinyin;
        if (c) {
            var h = !0;
            if (this.setData({
                isFeedLoading: !0
            }), this.feedErrorIndex > 0) {
                h = r.length + 10 <= this.feedErrorIndex;
                var g = r[this.feedErrorIndex];
                g && "ad" === g.type && (r[this.feedErrorIndex].show = !1);
            }
            s.show = h;
            var l = "recommend" === d || o, u = l ? i.getIndexFeed : i.getCategoryFeed, p = l ? "" : this.categoryId;
            u(p).then(function(o) {
                var i = o;
                r.length < 50 && l && (i = (0, t.insertBetween)(o, 10, s)), e.setData({
                    feedInfos: a ? i : [].concat(r, i),
                    hasMoreFeed: o.length > 0
                }, function() {
                    e.setData({
                        isFeedLoading: !1
                    });
                });
            });
        }
    },
    loadMore: function() {
        this.data.feedInfos.length > 0 && this.queryFeedInfo(!1, !1);
    },
    switchCategory: function(e) {
        var t = this, o = this.data, i = o.categoryPinyin, n = o.scrollY, r = e.detail, s = r.index, c = r.name, d = r.id;
        s && (s !== i && (this.categoryId = d, this.setData({
            categoryPinyin: s,
            modules: []
        }), (0, a.genLogger)(19430, "click", {
            currPage: "index",
            item: c
        }), wx.showToast({
            icon: "loading",
            title: "加载中"
        }), this.queryIndexContent(s), this.setData({
            scrollTop: 0,
            hasMoreFeed: !0
        }, function() {
            t.setHomeTabBar(!1), t.showBackTop = !1, t.queryFeedInfo(!1, !0);
        })), n || this.closeCategoryMask());
    },
    openCategoryMask: function() {
        this.setData({
            scrollY: !1
        });
    },
    closeCategoryMask: function() {
        this.setData({
            scrollY: !0
        });
    },
    showUpgradeModal: function() {
        var e = this;
        (0, i.queryShowUpgradeModal)().then(function(t) {
            var i = t.showUpgrade, a = void 0 !== i && i;
            !(0, o.get)("upgrade_showed") && a && e.setData({
                upgradeModalVisible: !0
            });
        });
    },
    toggleUpgradeModal: function() {
        var e = this.data.upgradeModalVisible;
        this.setData({
            upgradeModalVisible: !e
        });
    },
    toSearch: function() {
        (0, a.genLogger)(47575, "click", {
            currPage: "wx-newhome"
        }), wx.navigateTo({
            url: "/pages/search/search"
        });
    },
    onTapTomato: function(e) {
        var i = (0, t.getDataset)(e).tomato, n = i.url, r = i.title, s = i.pageType, d = i.id, h = i.hiddenAfterClick, g = i.index;
        switch ((0, a.genLogger)(47578, "click", {
            item: r,
            position: g,
            currPage: "wx-newhome",
            abtest: this.data.isTest
        }), s) {
          case "tab":
            (0, t.safeSwitchTab)({
                url: n
            });
            break;

          case "app":
            wx.navigateToMiniProgram({
                appId: d
            });
            break;

          default:
            wx.navigateTo({
                url: n
            });
        }
        if (h) {
            (0, o.set)("isTomatoClicked" + r, !0);
            var l = c.findIndex(function(e) {
                return e.hiddenAfterClick;
            }), u = c.slice();
            u[l].icon = "", this.setData({
                tomatoList: u
            });
        }
    },
    toCatePage: function() {
        var e = this.data.categoryPinyin;
        (0, a.genLogger)(17047, "click", {
            currPage: "index",
            moduleName: e
        }), wx.navigateTo({
            url: "/pages/categorylist/categorylist?categoryCode=".concat(e)
        });
    },
    clickFeedLogger: function(e) {
        var t = this.data.categoryPinyin, o = e.detail;
        (o = void 0 === o ? {} : o).type, o.id, o.recsrc, o.rectrack;
        "recommend" === t && (0, a.genLogger)(47582, "click", {
            currPage: "wx-newhome"
        });
    },
    onFeedAdError: function(e) {
        var t = e.detail, o = (t = void 0 === t ? {} : t).index;
        this.feedErrorIndex = o;
    },
    bannerLog: function() {
        (0, a.genLogger)(19510, "click", {});
    },
    onShareAppMessage: function() {
        if (this.selectComponent("#dailyHot")) {
            var t = this.selectComponent("#dailyHot").shareDailyHotInfo();
            return e({}, t);
        }
        return {};
    }
});