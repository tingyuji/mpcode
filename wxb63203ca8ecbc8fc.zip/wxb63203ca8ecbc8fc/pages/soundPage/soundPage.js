var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/album"), i = require("../../common/apis/track"), a = require("../../common/utils/index"), o = require("../../common/utils/navBar"), r = require("../../packages/lite-player/event"), n = require("../../packages/lite-player/index"), s = require("../../common/apis/anchor"), c = require("../../common/utils/copyCode"), l = require("../../common/utils/logger"), u = require("../../common/utils/wxScopeData"), h = require("../../common/utils/shareFromApp"), d = require("../../common/utils/myAdapter"), g = getApp();

Page({
    shareCount: 0,
    data: {
        trackInfo: {},
        albumInfo: {},
        richIntro: "",
        isFavourite: !1,
        isSubscribe: !1,
        hasScroll: !0,
        anchorInfo: {},
        breakSecond: 0,
        isIos: (0, o.isIos)(),
        xmcdn: (0, a.xmcdnImg)(),
        centerAdId: wx.canIUse("ad") ? a.trackCenterAdId : "",
        recommendAlbums: [],
        tabActivity: 0,
        scrollId: "",
        showBackTop: !1,
        scrollTop: 0,
        statusBarHeight: ((0, a.isOldVersion)() ? 0 : (0, a.getStatusBarHeight)()) + 38,
        isIPhoneX: (0, a.isIPhoneX)()
    },
    onShareAppMessage: function(t) {
        var i = g.sq;
        this.shareCount = (0, h.returnShareCount)(i);
        var o = e(e(e({}, this.options), i), {}, {
            count: this.shareCount,
            trackId: this.trackId || this.options.trackId
        });
        !o.count && delete o.count, !o.from && delete o.from;
        var r = (0, d.getDataset)(t).modal, n = void 0 === r ? "" : r;
        return "like" === n && (0, l.clickLikeModalShare)(), "sub" === n && (0, l.clickSubscribeModalShare)(), 
        this.url = (0, a.getUrl)(o, "pages/soundPage/soundPage"), this.shareAppMessage.path = "/".concat(this.url), 
        this.shareAppMessage;
    },
    onShareTimeline: function() {
        return (0, l.clickShareTimeline)("track"), this.shareAppMessage;
    },
    onSubscribeChange: function(e) {
        this.setData({
            isSubscribe: e.detail.isSubscribe
        });
    },
    onLoad: function(e) {
        this.path = "/pages/soundPage/soundPage";
        var t = e.trackId, i = void 0 === t ? 270402771 : t, o = e.breakSecond, n = void 0 === o ? 0 : o, s = e.scene;
        this.setData({
            breakSecond: n,
            isInScene: (0, c.canOpenApp)()
        }), s && (i = (0, a.getIdFromScene)(decodeURIComponent(s))), (0, h.toRequestShortUrl)(e), 
        this.init(i), this._init = this.init.bind(this), this._refreshTrack = this.refreshTrack.bind(this), 
        this._fix = this.fixPage.bind(this), this._scrollToComment = this.scrollToComment.bind(this), 
        r.EventBus.on("initTrack", this._init), r.EventBus.on("fixTrackPage", this._fix), 
        r.EventBus.on("commentDone", this._scrollToComment), r.EventBus.on("refreshTrack", this._refreshTrack), 
        (0, a.setShareMenu)();
    },
    onReady: function() {
        var e = this;
        wx.createSelectorQuery().select("#tab").boundingClientRect(function(t) {
            t && t.top && (e.tabTop = t.top);
        }).exec(), this.createTabObserver();
    },
    onShow: function() {
        this.pageHide && (this.pageHide = !1, this.init(this.trackId)), this.delayShowBubble();
    },
    onHide: function() {
        this.pageHide = !0, r.EventBus.emit("closeFavModal");
    },
    onUnload: function() {
        r.EventBus.off("initTrack", this._init), r.EventBus.off("fixTrackPage", this._fix), 
        r.EventBus.off("commentDone", this._scrollToComment), r.EventBus.off("refreshTrack", this._refreshTrack), 
        clearTimeout(this.timer), this.showBubbleTimer && clearTimeout(this.showBubbleTimer), 
        this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), (0, l.genLogger)(12058, "pageExit", e({
            currPageId: this.trackId,
            currPage: "track"
        }, this.paidLogParams));
    },
    initLoad: function(e) {
        this.refresh = e, this.getTrackInfo();
    },
    init: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.trackId = Number(e), this.pageHide || this.initLoad(t);
    },
    refreshTrack: function() {
        this.initLoad(this.trackId, !0);
    },
    scrollToComment: function() {
        this.setData({
            scrollId: "comment"
        });
    },
    createTabObserver: function() {
        var e = this;
        this._observer1 = wx.createIntersectionObserver(this), this._observer1.relativeTo(".container").observe(".anchorWrapper", function(t) {
            if (t.intersectionRatio > 0) {
                if (0 === e.data.tabActivity) return;
                e.setData({
                    tabActivity: 0
                });
            }
        }), this._observer2 = wx.createIntersectionObserver(this), this._observer2.relativeTo(".container").observe("#comment", function(t) {
            if (t.intersectionRatio > 0) {
                if (1 === e.data.tabActivity) return;
                e.setData({
                    tabActivity: 1
                });
            }
        });
    },
    delayShowBubble: function() {
        var e = this;
        this.showBubbleTimer && clearTimeout(this.showBubbleTimer), this.showBubbleTimer = setTimeout(function() {
            r.EventBus.emit("showShareBubble"), e.delayCloseBubble();
        }, 12e4);
    },
    delayCloseBubble: function() {
        this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), this.closeBubbleTimer = setTimeout(function() {
            r.EventBus.emit("closeShareBubble");
        }, 5e3);
    },
    initTrackPlaylist: function(e) {
        var t = this.data.albumInfo.includeTrackCount, i = (0, n.getCurrentPlayer)(), a = i.checkingSource().id, o = (i.playlist() || {}).list, r = void 0 === o ? [] : o, s = r.findIndex(function(t) {
            return t.id === e.id;
        });
        if (this.refresh) this.getRecommendTrackList(e, i); else if (a !== e.id) return r.length > 1 && s > -1 ? (r[s] = e, 
        void i.playlist(r, {
            auto: !0,
            index: s,
            total: t
        })) : void this.getRecommendTrackList(e, i);
    },
    getRecommendTrackList: function(e, t) {
        var a = this;
        (0, i.queryRelativeTracks)(this.trackId).then(function(i) {
            var o = i.findIndex(function(e) {
                return e.id === a.trackId;
            });
            -1 === o ? (o = 0, i = [ e ]) : i[o] = e;
            var n = a.data.breakSecond;
            n && n > 0 ? t.playlist(i, {
                auto: !0,
                index: o
            }, n) : t.playlist(i, {
                auto: !0,
                index: o
            }), setTimeout(function() {
                r.EventBus.emit("playListChange");
            }, 500);
        });
    },
    getTrackInfo: function() {
        var t = this;
        (0, i.getTrackInfo)(this.trackId).then(function() {
            var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = i.trackInfo, r = i.albumInfo, n = void 0 === r ? {} : r, s = i.albumMetaValueInfos, c = void 0 === s ? [] : s, h = i.canPlayXimiTrack;
            if (o) {
                var d = n.isPaid, g = n.albumPayType, m = n.albumVipPayType, f = n.discountedPrice, b = n.isVipFirst, p = 1 == m, k = 2 == m;
                o.canPlayXimiTrack = h, t.setData(e(e({}, i), {}, {
                    priceInfo: {
                        isPaid: d,
                        discountedPrice: f,
                        isVIPZX: p,
                        isVIPCT: k,
                        unitPrice: 1 == g ? "喜点/集" : 2 == g ? "喜点" : "",
                        albumPayType: g,
                        albumVipPayType: m,
                        isVipFirst: b
                    },
                    wxScopeData: (0, u.convertDataToWXScopeData)(o)
                })), t.trackId = o.id, t.albumId = n.id;
                var v = n.anchor, I = void 0 === v ? "" : v, T = n.title, P = void 0 === T ? "" : T;
                t.getAnchorInfo(I), t.setShareMessage(o, e(e({}, n), {}, {
                    albumMetaValueInfos: c
                })), t.initTrackPlaylist(o), t.initRecommendAlbums(n.id);
                var y = "free";
                d && (y = "paid", k && (y = "vipListen"), p && (y = "vipOnly")), t.paidLogParams = {
                    isPurchased: d && o.userPermission,
                    albumType: y,
                    paidType: 1 == g ? "single" : 2 == g ? "whole" : "",
                    isVip: (p || k) + ""
                }, o.isVideo && t.log_play_video_button_slip(), (0, l.genLogger)(12057, "pageView", e({
                    currPageId: t.trackId,
                    currPage: "track"
                }, t.paidLogParams)), (0, a.setNavigationBarTitle)(P), console.log("----getTrackInfo", t.data.trackInfo);
            }
        }).catch(function(e) {
            if (e && "request:fail app in background" === e.errMsg) return t.pageHide = !0;
            wx.redirectTo({
                url: "/pages/error/index?type=content&errorType=".concat(e ? JSON.stringify(e) : "", "&pageType=track&id=").concat(t.trackId)
            });
        });
    },
    getAnchorInfo: function(e) {
        var t = this;
        (0, i.queryAnchorName)(e).then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            t.setData({
                anchorInfo: e
            });
        });
    },
    setShareMessage: function(t, i) {
        var o = this;
        this.shareAppMessage = {
            title: "".concat(t.title, " - ").concat(i.title),
            desc: i.subTitle || "我在喜马拉雅发现了一个很棒的节目，一起听听吧",
            path: "/".concat(this.url),
            imageUrl: (0, a.getOriginImgUrl)(t.cover),
            templateId: "af8063b6g711eeib3g",
            success: function() {
                console.log("转发发布器已调起，并不意味着用户转发成功，微头条不提供这个时机的回调");
            },
            fail: function() {
                console.log("转发发布器调起失败");
            }
        }, (0, a.drawSharePic)("track-share", e(e({}, t), {}, {
            albumMetaValueInfos: i.albumMetaValueInfos
        }), function(e) {
            o.shareAppMessage.imageUrl = e;
        });
    },
    beforeSourceChange: function(e) {
        e.hasOwnProperty("detail") && (e = e.detail), e.id !== this.data.trackInfo.id && (this.init(e.id), 
        this.setData({
            trackInfo: e,
            scrollTop: 0
        }));
    },
    initRecommendAlbums: function(e) {
        var i = this;
        this.data.recommendAlbums.length > 0 || (0, t.queryRelateRecommendAlbums)({
            id: e
        }).then(function(e) {
            var t = e.albumInfo;
            i.setData({
                recommendAlbums: {
                    title: "相似推荐",
                    moduleInfo: t
                }
            });
        });
    },
    toAlbum: function() {
        var e = this.data.albumInfo;
        (0, a.track2album)(e), this.log_to_album();
    },
    tabChange: function(e) {
        var t = (0, d.getDataset)(e).index, i = this.data.tabActivity, a = Number(t);
        this.setData({
            scrollId: {
                0: "album",
                1: "ad"
            }[a]
        }), a !== i && (this.setData({
            tabActivity: a
        }), (0, l.genLogger)(26324, "click", {
            item: 1 === a ? "评论" : "详情",
            currPageId: this.trackId,
            currPage: "声音页"
        }));
    },
    panelChange: function(e) {
        e.hasOwnProperty("detail") && (e = e.detail), this.setData({
            hasScroll: e.detail || e
        });
    },
    onScroll: (0, a.throttle)(function(e) {
        this.hideFuncBar();
        var t = e.detail.scrollTop, i = t > 300;
        this.setData({
            showBackTop: i
        }), this.tabTop && this.setData({
            isTabFixed: t > this.tabTop
        });
        var a = this, o = wx.createSelectorQuery();
        o.select(".open-app_track").boundingClientRect(), o.exec(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = e[0] || {};
            a.setData({
                showBottomShare: t.top < 0,
                showBottomOpenApp: !!(0, c.canOpenApp)() && t.top < 0
            });
        });
    }, 500, 500),
    scrollToTop: function() {
        this.setData({
            showBackTop: !1,
            scrollTop: 0
        }), (0, l.genLogger)(26913, "click", {
            currPageId: this.trackId,
            currPage: "track"
        });
    },
    loadMore: function() {
        r.EventBus.emit("loadMore");
    },
    followAnchor: function() {
        var t = this, i = this.data, a = i.anchorInfo, o = i.albumInfo.anchor, r = i.anchorInfo.isFollow;
        (a.isFollow ? s.cancelFollow : s.setFollow)({
            followingUid: o
        }).then(function() {
            wx.showToast({
                title: r ? "成功取消关注" : "成功关注",
                icon: "success"
            }), t.setData({
                anchorInfo: e(e({}, a), {}, {
                    isFollow: !r
                })
            });
        });
    },
    likeTrack: function() {
        var e = this, t = this.data.isFavourite, a = t ? i.dislikeTrack : i.likeTrack;
        (0, l.genLogger)(17074, "click", {
            item: t ? "取消喜欢" : "喜欢",
            currPageId: this.trackId
        }), a(this.trackId).then(function() {
            t || ((0, l.exposureLikeModal)(), r.EventBus.emit("showFavModal", {})), e.setData({
                isFavourite: !t
            });
        });
    },
    writeComment: function() {
        (0, l.genLogger)(30062, "click", {
            currPage: "声音页"
        }), r.EventBus.emit("writeComment");
    },
    hideFuncBar: function() {
        r.EventBus.emit("toggleTrackFuncBar", !1);
    },
    onHideTrackIntro: function() {
        this.setData({
            scrollId: "album"
        });
    },
    onWXAdError: function() {
        this.setData({
            centerAdId: ""
        });
    },
    share: function() {
        r.EventBus.emit("showSharePanel", "track");
    },
    onWriteComment: function() {
        (0, l.genLogger)(18991, "click", {
            currPageId: this.trackId
        });
    },
    onReplayComment: function() {
        (0, l.genLogger)(18993, "click", {
            currPageId: this.trackId
        });
    },
    toAnchor: function() {
        var e = this.data.albumInfo.anchor;
        (0, a.goPage)({
            url: "/pages/announcer/announcer?id=".concat(e)
        });
    },
    toVideo: function() {
        this.log_play_video_button_click(), (0, a.track2Video)(this.trackId);
    },
    fixPage: function(e) {
        this.setData({
            hasScroll: !e
        });
    },
    copyPagePath: function() {
        (0, l.genLogger)(27058, "longPress", {
            currPageId: this.trackId
        }), (0, a.copyPagePath)(this.trackId);
    },
    log_to_album: function() {
        (0, l.genLogger)(17095, "click", {
            currPageId: this.data.trackInfo.id
        });
    },
    log_share_wechat: function() {
        (0, l.genLogger)(17075, "click", {
            currPageId: this.data.trackInfo.id
        });
    },
    log_share_wechat_bottom: function() {
        (0, l.genLogger)(17350, "click", {
            currPageId: this.data.trackInfo.id
        });
    },
    log_recommend_album: function() {
        (0, l.genLogger)(26326, "click", {
            currPageId: this.data.trackInfo.id,
            currPage: "声音页"
        });
    },
    log_play_video_button_slip: function() {
        (0, l.genLogger)(33749, "slipPage", {
            currPage: "声音页"
        });
    },
    log_play_video_button_click: function() {
        (0, l.genLogger)(33750, "click", {
            currPage: "声音页"
        });
    }
});