var n = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../common/apis/hotNews");

Page({
    data: {
        channelInfos: []
    },
    onLoad: function() {
        var n = this;
        (0, e.getHotNewsTabList)().then(function(e) {
            var t = e.channelInfos, a = e.customChannelInfos, s = t.filter(function(n) {
                return 1 === n.type;
            }), i = a.filter(function(n) {
                return 1 === n.type;
            }), r = [ {
                type: "minus",
                channels: s,
                title: "我的频道"
            } ];
            i.length > 0 && r.push({
                type: "plus",
                channels: i,
                title: "更多频道"
            }), n.initChannelInfos = r, n.setData({
                channelInfos: r
            });
        });
    },
    switchTab: function(n) {
        var e = n.currentTarget.dataset.channelid;
        wx.navigateTo({
            url: "/pages/hotNews/index?channelId=".concat(e)
        });
    },
    changeChannel: function(t) {
        var a = this, s = t.currentTarget.dataset, i = s.index, r = s.index2, c = 0 === i ? i + 1 : i - 1, o = n(this.data.channelInfos), h = o[i].channels.splice(r, 1);
        o[c].channels.push(h[0]);
        var l = o.find(function(n) {
            return "minus" === n.type;
        }).channels.map(function(n) {
            return n.radioId;
        });
        (0, e.saveHotNesChannels)(l.join()).then(function(n) {
            n.data && a.setData({
                channelInfos: o
            });
        });
    }
});