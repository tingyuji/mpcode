var a = require("../../common/apis/pointsdetail");

Page({
    data: {
        page: 1,
        pageSize: 20,
        infos: [],
        hasMore: !1
    },
    onLoad: function() {
        this.getDetail();
    },
    loadMore: function() {
        var a = this, e = this.data, t = e.page;
        e.hasMore && this.setData({
            page: t + 1
        }, function() {
            a.getDetail();
        });
    },
    getDetail: function() {
        var e = this, t = this.data, i = t.page, o = t.pageSize;
        (0, a.queryDetail)({
            page: i,
            pageSize: o
        }).then(function(a) {
            var t = a.page, i = a.pageSize, o = a.infos, s = a.hasMore, n = e.data.infos;
            e.setData({
                page: t,
                pageSize: i,
                hasMore: s,
                infos: [].concat(n, o)
            });
        });
    }
});