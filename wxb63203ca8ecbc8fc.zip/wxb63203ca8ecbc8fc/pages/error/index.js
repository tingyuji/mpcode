var t = require("../../common/utils/index"), e = require("../../common/utils/logger"), n = {
    content: {
        imgType: "content",
        tip: "您的网络不太稳定哦~",
        subTip: "",
        button: "刷新重试"
    },
    network: {
        imgType: "network",
        tip: "无法连接到网络",
        subTip: "请检查您的手机设置",
        button: "重新加载"
    },
    crowed: {
        imgType: "crowed",
        tip: "访问的人数过多",
        subTip: "请稍后重试",
        button: "重新加载"
    }
}, i = {
    album: "/pages/albumDetail/albumDetail",
    track: "/pages/soundPage/soundPage"
}, a = {
    album: "albumId",
    track: "trackId"
};

Page({
    data: {
        imgType: "",
        tip: "",
        subTip: "",
        button: ""
    },
    onLoad: function(t) {
        var e = t.type, i = n[e] || n.content;
        this.setData(i);
    },
    onUnload: function() {},
    onClick: function() {
        var n = getCurrentPages();
        if ("刷新重试" === this.data.button && n.length > 1) {
            (0, e.genLogger)(27126, "click");
            var o = this.options, u = o.pageType, r = o.id, g = i[u] ? i[u] + "?" + a[u] + "=" + r : "";
            return g ? wx.redirectTo({
                url: g
            }) : wx.navigateBack();
        }
        1 === n.length && "/pages/index/index" === n[0].path || (0, t.toHome)();
    }
});