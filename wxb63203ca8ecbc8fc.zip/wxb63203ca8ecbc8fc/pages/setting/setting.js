var o = require("@xmly/lite-login_wx/lib/index"), e = require("../../common/utils/logger"), t = require("../../common/utils/index");

Page({
    data: {
        showTimer: !1,
        showContact: !1,
        showLogoffModal: !1
    },
    onLoad: function() {},
    toggleTimer: function() {
        var o = this.data.showTimer;
        this.setData({
            showTimer: !o
        });
    },
    switchContact: function() {
        wx.showActionSheet({
            itemList: [ "立即拨打" ],
            itemColor: "#ff411d",
            alertText: "客服电话：400-838-5616",
            success: function(o) {
                o.cancel || 0 !== o.tapIndex || wx.makePhoneCall({
                    phoneNumber: "400-838-5616"
                });
            }
        });
    },
    changeAccount: function() {
        (0, o.logout)({
            env: t.env
        }).then(function() {
            wx.removeStorage({
                key: "uid"
            }), wx.removeStorage({
                key: "userInfo"
            });
        }), wx.navigateTo({
            url: "/pages/login/login"
        });
    },
    toggleLogoffModal: function() {
        var o = this.data.showLogoffModal;
        this.setData({
            showLogoffModal: !o
        });
    },
    logoutsuccess: function() {
        wx.removeStorage({
            key: "uid"
        }), wx.removeStorage({
            key: "userInfo"
        }), this.toggleLogoffModal(), setTimeout(function() {
            wx.navigateBack();
        }, 500);
    },
    log_night_mode: function() {
        (0, e.genLogger)(18990, "click", {
            currPage: "settings"
        });
    }
});