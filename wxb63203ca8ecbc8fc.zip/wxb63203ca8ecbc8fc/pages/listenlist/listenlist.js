var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/apis/ugc"), i = require("../../common/utils/navigate"), o = require("../../common/utils/image"), n = require("../../common/utils/index"), s = (require("../../packages/lite-player/index"), 
require("../../common/apis/anchor"));

Page({
    data: {
        listenType: 3,
        commentList: [],
        reply: [],
        tracks: [],
        albums: [],
        ugcInfo: {},
        seeMore: !1,
        xmcdnImg: (0, n.xmcdnImg)()
    },
    onLoad: function(t) {
        this.path = "/pages/listenlist/listenlist";
        var e = t.ugcId, i = void 0 === e ? 29569760 : e;
        this.init(i);
    },
    init: function(t) {
        this.ugcId = t, this.pageNo = 1, this.getUgcList(), this.getUgcComments();
    },
    changeSeeMoreValue: function() {
        this.setData({
            seeMore: !1
        });
    },
    getUgcList: function() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.pageNo, o = this;
        (0, e.getUgcList)({
            pageNo: i,
            ugcId: this.ugcId,
            pageSize: 99
        }).then(function(e) {
            console.log("getUgcList", e);
            var i = e.ugcInfo, n = e.tracks, s = e.albums;
            o.setData({
                listenType: i.listenType,
                ugcInfo: t({}, i),
                tracks: n,
                albums: s,
                seeMore: i.listenIntro && i.listenIntro.length > 40
            });
        });
    },
    getUgcComments: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.pageNo, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.ugcId, o = this;
        (0, e.getUgcComments)({
            pageNo: t,
            ugcId: i,
            pageSize: 99
        }).then(function(t) {
            var e = t.commentList;
            o.setData({
                commentList: e
            });
        });
    },
    userImageError: function(t) {
        var e = this, i = t.currentTarget.dataset.index;
        this.userImageErrorList || (this.userImageErrorList = []), this.userImageErrorList.push(i), 
        clearTimeout(this.timer), this.timer = setTimeout(function() {
            var t = e.data.commentList;
            e.userImageErrorList.forEach(function(e) {
                t && t[e] && (t[e].avatar = o.defaultUserImg);
            }), e.setData({
                commentList: t
            });
        }, 20);
    },
    toTrack: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/soundPage/soundPage?trackId=" + e
        });
    },
    toAlbum: function(t) {
        (0, i.toAlbum)((0, i.getAlbum)(t, this.data.albums));
    },
    followAnchor: function() {
        var e = this, i = this.data.ugcInfo, o = i.anchorId, n = i.isFollow;
        (n ? s.cancelFollow : s.setFollow)({
            followingUid: o
        }).then(function() {
            wx.showToast({
                title: n ? "成功取消关注" : "成功关注",
                icon: "success"
            }), e.setData({
                ugcInfo: t(t({}, i), {}, {
                    isFollow: !n
                })
            });
        });
    },
    toAnchor: function() {
        var t = this.data.ugcInfo.anchorId, e = void 0 === t ? 0 : t;
        0 != e && (0, n.goPage)({
            url: "/pages/announcer/announcer?id=".concat(e)
        });
    }
});