var e = require("../../@babel/runtime/helpers/objectWithoutProperties"), i = require("../../common/utils/index"), o = [ "url", "encode" ];

Page({
    data: {
        src: ""
    },
    onLoad: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.url, a = void 0 === n ? "" : n, r = t.encode, s = void 0 === r || r, c = e(t, o);
        this.path = "/pages/webview/index", this.url = decodeURIComponent(a) + "?".concat((0, 
        i.obj2url)(c, s)), this.initLoad();
    },
    initLoad: function() {
        this.setData({
            src: this.url
        });
    },
    onShow: function() {
        this.initLoad();
    },
    messageHandle: function(e) {
        e.detail.data.forEach(function(e) {
            var i = e.message;
            i && console.log(i);
        });
    }
});