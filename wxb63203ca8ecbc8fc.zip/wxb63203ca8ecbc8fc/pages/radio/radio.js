var e = require("../../@babel/runtime/helpers/objectSpread2"), o = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../common/apis/radio"), t = require("../../common/apis/parse"), r = require("../../common/utils/index"), i = require("../../common/const/trackType");

Page({
    data: {
        focusModuleInfo: {},
        favorAndLatestModuleInfo: {},
        searchRadioInitInfo: {
            categories: [],
            locations: [],
            focusRadios: [],
            searchRadios: []
        },
        loading: !0,
        isNavBarPChange: !1,
        scrollSelectedFixed: !1,
        scrollTop: 0
    },
    onScrollTopChange: function(e) {
        var o = e.detail;
        this.setData({
            scrollTop: o
        });
    },
    formatFavorRadios: function(e) {
        return e.map(function(e) {
            return {
                id: e.id,
                cover: e.coverLarge,
                className: "FAVORITE" === e.type ? "favor-tip" : "history-tip",
                title: e.name
            };
        });
    },
    onLoad: function() {
        var e = this;
        this.data.loading || this.setData({
            loading: !0
        }), (0, a.getRadioHomepage)().then(function(a) {
            var r = o(a.modules, 3), n = r[0], s = r[1], l = r[2], c = n.radios, d = l.radios, u = l.hasMore, f = s.radios, p = s.categories, m = s.locations, h = c.map(function(e) {
                return {
                    id: e.id,
                    cover: e.coverLarge,
                    className: "focus-tip",
                    title: e.name
                };
            });
            e.setData({
                loading: !1,
                focusModuleInfo: {
                    module: {
                        title: "推荐电台",
                        moduleType: i.RADIOS,
                        subModuleType: "focus",
                        moduleInfo: h,
                        canChange: !1,
                        showPicTip: !1
                    }
                },
                favorAndLatestModuleInfo: {
                    module: {
                        title: "",
                        moduleType: i.RADIOS,
                        subModuleType: "favor",
                        moduleInfo: e.formatFavorRadios(d),
                        canChange: !1,
                        showPicTip: !1
                    },
                    pageNum: 1,
                    pageSize: d.length,
                    hasMore: u
                },
                searchRadioInitInfo: {
                    categories: p,
                    locations: m,
                    focusRadios: c.map(function(e) {
                        return (0, t.parseRadio)(e);
                    }),
                    searchRadios: f.map(function(e) {
                        return (0, t.parseRadio)(e);
                    })
                }
            }, function() {
                var o = wx.createSelectorQuery();
                o.select(".seprate-line").boundingClientRect(function(o) {
                    e.seprateTop = o.top;
                }).exec(), o.select("#search-list").boundingClientRect(function(o) {
                    e.selectTop = o.top;
                }).exec();
            });
        });
    },
    loadMoreRadios: function() {
        this.selectComponent("#search-list").onLoadMore();
    },
    favorBindScrollToLower: function() {
        var o = this, t = this.data, r = t.favorAndLatestModuleInfo, i = t.favorAndLatestModuleInfo, n = i.pageNum, s = i.pageSize, l = i.hasMore, c = i.module, d = i.module.moduleInfo;
        if (l) {
            var u = n + 1;
            (0, a.getListFavoriteRadios)({
                pageNum: u,
                pageSize: s
            }).then(function(a) {
                var t = a.radios, i = a.hasMore, n = [].concat(d, o.formatFavorRadios(t));
                o.setData({
                    favorAndLatestModuleInfo: e(e({}, r), {}, {
                        pageNum: u,
                        hasMore: i,
                        module: e(e({}, c), {}, {
                            moduleInfo: n
                        })
                    })
                });
            });
        }
    },
    onScroll: (0, r.throttle)(function(e) {
        var o = e.detail.scrollTop, a = o > this.seprateTop, t = {};
        a === this.data.isNavBarPChange || (t.isNavBarPChange = a, wx.setNavigationBarColor({
            frontColor: a ? "#000000" : "#ffffff",
            backgroundColor: a ? "#ffffff" : "#322d3d"
        }));
        var r = o >= this.selectTop;
        r === this.data.scrollSelectedFixed || (t.scrollSelectedFixed = r), this.setData(t);
    }, 500)
});