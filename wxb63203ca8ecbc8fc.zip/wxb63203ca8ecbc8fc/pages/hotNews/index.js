var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/hotNews"), n = require("../../common/utils/index");

Page({
    data: {
        channelId: "",
        trackId: "",
        channelType: 1,
        tabList: [],
        lineArr: [],
        lineMiddleIndex: null,
        scrollLeft: 0,
        hotNBHeight: (0, n.isLiuHaiScreen)() ? 193 : 173
    },
    onLoad: function(e) {
        var n = this, a = e.channelId, i = void 0 === a ? t.HOTNEWSPARAM.channelId : a, o = e.trackId;
        (0, t.getHotNewsTabList)().then(function(e) {
            n.setData({
                tabList: e.channelInfos.filter(function(e) {
                    return 1 === e.type;
                }),
                channelId: i,
                trackId: o
            }, function() {
                n.updateScrollLeft(i);
            });
        });
        var r = wx.getSystemInfoSync().windowWidth;
        this.windowWidth = r;
        var l = Math.floor(r / 11), c = new Array(l);
        this.setData({
            lineArr: c
        });
    },
    onScroll: function(e) {
        var t = e.detail.scrollLeft;
        this.tmpScrollLeft = t;
    },
    switchTab: function(e) {
        var t = this, n = e.currentTarget.dataset, a = n.id, i = n.type;
        this.setData({
            channelId: a,
            channelType: i
        }, function() {
            t.updateScrollLeft(a);
        });
    },
    updateScrollLeft: function(e) {
        var t = this;
        wx.createSelectorQuery().select("#trackId" + e).boundingClientRect(function(n) {
            var a = n.left, i = (t.tmpScrollLeft || 0) + a;
            console.log("++left0++", a), t.setData({
                scrollLeft: i
            }, function() {
                setTimeout(function() {
                    t.updateMiddleIndex(e);
                }, 300);
            });
        }).exec();
    },
    updateMiddleIndex: function(e) {
        var t = this, n = wx.createSelectorQuery();
        n.select("#trackId" + e).boundingClientRect(), n.exec(function(e) {
            var n = e[0], a = n.left, i = n.width;
            console.log("++中线++", a, e);
            var o = Math.floor((24 + a + i / 2 - 6 - 4 - 9) / 11) + 1;
            t.setData({
                lineMiddleIndex: o
            });
        });
    },
    jumpToChannel: function() {
        wx.navigateTo({
            url: "/pages/hotNews-channel/index"
        });
    },
    onShareAppMessage: function() {
        var t = this.selectComponent("#groupTrackList").shareDailyHotInfo();
        return e({}, t);
    }
});