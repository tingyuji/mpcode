Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getShareConfigInfo = function(e, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
    return {
        title: "".concat(n, "-喜马拉雅"),
        imageUrl: t,
        path: "/pages/hotNews/index?channelId=".concat(e, "&trackId=").concat(o)
    };
};

require("../../common/utils/time");