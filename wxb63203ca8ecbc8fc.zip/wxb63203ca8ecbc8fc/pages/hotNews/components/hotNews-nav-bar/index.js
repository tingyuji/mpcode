var e = require("../../../../common/utils/navBar"), t = require("../../../../common/utils/index"), a = (0, 
e.getNavStatusBarHeight)(), r = a.statusBarHeight, i = a.navBarHeight;

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        className: String,
        NBHeight: Number
    },
    data: {
        statusBarHeight: r,
        navBarHeight: i
    },
    methods: {
        toPrev: function() {
            (0, t.getCurrentRoute)().indexOf("pages/hotNews/index") > -1 ? (0, t.toHome)() : getCurrentPages().length <= 1 ? wx.reLaunch({
                url: "/pages/hotNews/index"
            }) : wx.navigateBack();
        }
    }
});