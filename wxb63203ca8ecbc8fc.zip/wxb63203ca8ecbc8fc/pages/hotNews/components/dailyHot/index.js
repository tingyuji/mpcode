var t = require("../../../../@babel/runtime/helpers/objectSpread2"), e = require("../../../../common/apis/hotNews"), a = require("../../utils"), n = require("../../../../packages/lite-player/index").createComponent;

Component(n({
    properties: {},
    data: {
        trackList: [],
        activeIndex: 0,
        transformStyle: "",
        channelId: e.HOTNEWSPARAM.channelId
    },
    observers: {
        activeIndex: function(t) {
            var e = 18 * t;
            this.setData({
                transformStyle: "transform: translateY(-".concat(e, "px); transition: transform 0.6s;")
            });
        }
    },
    attached: function() {
        var t = this;
        (0, e.getHotNewsTrackList)().then(function(e) {
            var a = e.list, n = e.smallCover;
            t.shareImg = n, t.setData({
                trackList: a
            }), t.timer = setInterval(function() {
                var e = t.data.activeIndex, n = e === a.length - 1 ? 0 : e + 1;
                t.setData({
                    activeIndex: n
                });
            }, 3e3);
        });
    },
    detached: function() {
        this.timer && clearInterval(this.timer);
    },
    methods: {
        playTrack: function() {
            var t = this.data, e = t.activeIndex, a = t.trackList, n = t.channelId, r = a[e].trackId;
            wx.navigateTo({
                url: "/pages/hotNews/index?channelId=".concat(n, "&trackId=").concat(r)
            });
        },
        shareDailyHotInfo: function() {
            return t({}, (0, a.getShareConfigInfo)(this.data.channelId, this.shareImg));
        }
    }
}));