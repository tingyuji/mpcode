var t = require("../../../../@babel/runtime/helpers/objectSpread2"), e = require("../../../../@babel/runtime/helpers/toConsumableArray"), a = require("../../../../common/apis/hotNews"), i = require("../../../../common/utils/index"), n = require("../../utils"), r = require("../../../../packages/lite-player/index").createComponent;

Component(r({
    properties: {
        channelId: {
            type: String,
            observer: function(t, e) {
                if (t !== e) {
                    var a = !e && t;
                    this.updateTrackList(1, t, void 0, !0, a);
                }
            }
        },
        channelType: Number,
        trackId: String,
        hotNBHeight: Number
    },
    data: {
        trackList: [],
        pageId: 1,
        maxPageId: 1,
        pageSize: 20,
        loading: null,
        timeStamp: new Date().getTime(),
        scrollTop: 0,
        xmcdn: (0, i.xmcdnImg)(),
        showBackToPlay: !1
    },
    attached: function() {
        this.sourceChangeBind = this.sourceChange.bind(this), r.Player.on("beforeSourceChange", this.sourceChangeBind), 
        this.onPlayStartedBind = this.onPlayStarted.bind(this), r.Player.on("playStarted", this.onPlayStartedBind);
    },
    detached: function() {
        r.Player.off("beforeSourceChange", this.sourceChangeBind), r.Player.off("playStarted", this.onPlayStartedBind);
    },
    methods: {
        onScrollTrack: function(t) {
            var e = this;
            wx.createSelectorQuery().in(this).select("#hot" + t.trackId).boundingClientRect(function(a) {
                if (a) {
                    var i = a.top - e.data.hotNBHeight + 12, n = (e.tmpScrollTop || 0) + i;
                    e.setData({
                        scrollTop: n
                    });
                } else console.log("找不到了，trackId:".concat(t.trackId, ",title:").concat(t.title));
            }).exec();
        },
        onScroll: (0, i.throttle)(function(t) {
            var e = t.detail, a = e.scrollTop, i = e.scrollHeight;
            this.tmpScrollTop = a, this.tmpScrollHeight = i;
            var n = this.data, r = n.showBackToPlay, o = a > n.scrollTop;
            r !== o && this.setData({
                showBackToPlay: o
            });
        }, 500),
        backToPlay: function() {
            this.setData({
                scrollTop: this.data.scrollTop
            });
        },
        playOne: function(t) {
            var e = t.currentTarget.dataset.index, a = this.data, i = a.trackList, n = a.currentSource, r = i[e];
            r.trackId !== n.id ? this.playlist(i.slice(e), {
                auto: !0
            }) : this.play(r);
        },
        onPlayStarted: function() {
            this.onScrollTrack(this.data.currentSource);
        },
        sourceChange: function() {
            var t = this.data, a = t.currentSource, i = a.id, n = a.title, r = t.playPercent, o = t.trackList, c = o.findIndex(function(t) {
                return t.trackId === i;
            });
            if (c > -1) {
                var s = e(o);
                s[c].playPercent = r, s[c].isSeen = !0, this.setData({
                    trackList: s
                });
            } else console.log("没找到，".concat(i, "-").concat(n));
        },
        getNewestTrackList: function(t, e) {
            for (var a = [], i = function(i) {
                var n = t[i].trackId;
                -1 === e.findIndex(function(t) {
                    return t.trackId === n;
                }) && a.push(t[i]);
            }, n = 0; n < t.length; n++) i(n);
            return a;
        },
        scrolltoupper: (0, i.throttle)(function() {
            var t = this;
            new Date().getTime - this.data.timeStamp > 7200 ? wx.showToast({
                title: "已更新到最新",
                icon: "none"
            }) : this.updateTrackList(1, void 0, function(e) {
                var a = t.data.trackList, i = t.getNewestTrackList(e, a);
                t.setData({
                    trackList: i.concat(a),
                    pageId: 1
                }, function() {
                    var t = i.length, e = t > 0 ? "新增".concat(t, "条最新内容") : "已更新到最新";
                    wx.showToast({
                        title: e,
                        icon: "none"
                    });
                });
            });
        }, 500),
        scrolltolower: (0, i.throttle)(function(t) {
            console.log("top 上滑加载被触发了", t);
            var e = this.data.pageId;
            this.updateTrackList(e + 1);
        }, 500),
        updateTrackList: function() {
            var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.data.pageId, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.data.channelId, n = arguments.length > 2 ? arguments[2] : void 0, r = arguments.length > 3 ? arguments[3] : void 0, o = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
            if (!this.data.loading) {
                var c = this.data, s = c.channelType, l = c.pageSize, d = c.maxPageId, h = c.playState, u = c.PlayState, g = c.trackId, p = r ? [] : this.data.trackList;
                !r && !n && e > d || this.setData({
                    loading: !0
                }, function() {
                    (0, a.getHotNewsTrackList)({
                        channelId: i,
                        pageSize: l,
                        pageId: e,
                        channelType: s
                    }).then(function(a) {
                        var c = a.list, s = a.maxPageId, l = a.smallCover;
                        if (t.shareImg = l, n) n(c), t.setData({
                            timeStamp: new Date().getTime(),
                            maxPageId: s,
                            loading: !1
                        }); else if (t.setData({
                            trackList: p.concat(c),
                            channelId: i,
                            pageId: e,
                            timeStamp: new Date().getTime(),
                            maxPageId: s,
                            loading: !1
                        }), r) if (o || h !== u.PLAYING) {
                            var d = 0;
                            if (g) {
                                var f = c.findIndex(function(t) {
                                    return t.trackId === g;
                                });
                                -1 !== f && (d = f);
                            }
                            t.playlist(c, {
                                auto: !0,
                                index: d
                            });
                        } else t.setData({
                            scrollTop: 0
                        });
                    });
                });
            }
        },
        onSubscribeChange: function(t) {
            for (var a = t.detail, i = a.albumId, n = a.isSubscribe, r = this.data.trackList, o = e(r), c = 0; c < o.length; c++) {
                i === o[c].albumId && (o[c].subscribe = n);
            }
            this.setData({
                trackList: o
            });
        },
        shareDailyHotInfo: function() {
            var e = this.data.source, a = void 0 === e ? {} : e;
            return t({}, (0, n.getShareConfigInfo)(this.data.channelId, a.coverMiddle, a.title, a.id));
        }
    }
}));