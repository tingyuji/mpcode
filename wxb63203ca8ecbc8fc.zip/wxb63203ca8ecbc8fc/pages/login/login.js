var e = require("../../common/utils/index"), i = require("../../common/utils/navBar");

Page({
    data: {
        env: e.env,
        hasTip: !!(0, i.isLowerDevice)("7.0.4")
    }
});