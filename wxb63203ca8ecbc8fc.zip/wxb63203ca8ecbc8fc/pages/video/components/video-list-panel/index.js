var e = require("../../../../common/utils/index"), o = require("../../../../common/utils/logger");

Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        list: {
            type: Array,
            value: []
        },
        currentVideoId: {
            type: Number,
            value: 0
        },
        isLoadingPrev: Boolean,
        isLoadingNext: Boolean,
        hasMoreNext: Boolean,
        playState: String
    },
    data: {
        isIPhoneX: (0, e.isIPhoneX)()
    },
    methods: {
        close: function() {
            this.triggerEvent("togglepanel");
        },
        onScrollToTop: function() {
            this.triggerEvent("loadup");
        },
        onScrollToBottom: function() {
            this.triggerEvent("loaddown");
        },
        onTapVideo: function(t) {
            var n = (0, e.getDataset)(t).id;
            (0, o.genLogger)(33759, "click", {
                currPage: "video"
            }), this.triggerEvent("ontapvideo", n);
        }
    },
    created: function() {},
    attached: function() {},
    ready: function() {},
    moved: function() {},
    detached: function() {}
});