var e = require("../../../../common/utils/index"), t = require("../../../../common/utils/logger");

Component({
    properties: {
        list: Array,
        currentVideoId: Number,
        isLoadingPrev: {
            type: Boolean,
            value: !1
        },
        isLoadingNext: {
            type: Boolean,
            value: !1
        },
        hasMoreNext: Boolean,
        playState: String
    },
    data: {},
    methods: {
        onTapVideo: function(o) {
            var n = (0, e.getDataset)(o).id;
            (0, t.genLogger)(33758, "click", {
                currPage: "video"
            }), this.triggerEvent("ontapvideo", n);
        },
        openPanel: function() {
            this.triggerEvent("openpanel");
        },
        onScrollToLeft: function() {
            this.triggerEvent("loadup");
        },
        onScrollToRight: function() {
            this.triggerEvent("loaddown");
        }
    },
    created: function() {},
    attached: function() {},
    ready: function() {},
    detached: function() {}
});