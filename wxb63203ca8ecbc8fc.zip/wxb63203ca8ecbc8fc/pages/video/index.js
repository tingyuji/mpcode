var i = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/track"), a = require("../../packages/lite-player/event"), o = require("../../common/utils/index"), n = require("../../common/utils/logger"), s = require("../../packages/lite-player/index");

Page({
    data: {
        id: "",
        playlist: [],
        videoList: [],
        panelVisible: !1,
        isLoadingPrev: !1,
        isLoadingNext: !1,
        linkProteceterOptions: {
            isDownload: !1
        },
        options: {
            unauthorizedMsg: (0, o.isIos)() ? "由于IOS相关规范，无法继续播放" : "试看结束，请购买后收看"
        },
        env: o.env,
        playState: ""
    },
    onLoad: function(i) {
        var e = this;
        this.path = "/pages/video/index";
        var t = i.id;
        this.id = "", this.setData({
            id: "",
            hasMorePrev: !0,
            hasMoreNext: !0
        }, function() {
            e.init(t, !0);
        }), this.hasMorePrev = !0, this.hasMoreNext = !0, this.pauseMusic();
    },
    pauseMusic: function() {
        var i = (0, s.getCurrentPlayer)();
        i && i.audioManager && i.audioManager.pause();
    },
    onShow: function() {
        this.pauseMusic();
    },
    onReachBottom: (0, o.debounce)(function() {
        this.loadMoreComments();
    }, 200),
    setShareMessage: function(i, t) {
        var a = this;
        this.shareAppMessage = {
            title: i.title,
            desc: t.subTitle || "我在喜马拉雅发现了一个很棒的节目，一起听听吧",
            path: "/".concat(this.url),
            imageUrl: (0, o.getOriginImgUrl)(i.cover)
        }, (0, o.drawSharePic)("video-share", e(e({}, i), {}, {
            albumMetaValueInfos: t.albumMetaValueInfos,
            cover: i.cover
        }), function(i) {
            a.shareAppMessage.imageUrl = i;
        });
    },
    onShareAppMessage: function(i) {
        var t = e(e({}, this.options), {}, {
            id: this.id || this.options.id
        });
        return this.url = (0, o.getUrl)(t, "pages/video/index"), this.shareAppMessage.path = "/".concat(this.url), 
        this.shareAppMessage;
    },
    onSubscribeChange: function(i) {
        this.setData({
            isSubscribe: i.detail.isSubscribe
        });
    },
    init: function(i) {
        var a = this, o = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (0, t.getTrackInfo)(i).then(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.trackInfo, s = void 0 === n ? {} : n, r = t.albumInfo, l = t.isSubscribe, c = t.albumMetaValueInfos;
            a.id = i, a.setData({
                trackInfo: s,
                albumInfo: r,
                id: i,
                isSubscribe: l
            }), a.setShareMessage(s, e(e({}, r), {}, {
                albumMetaValueInfos: c
            })), o && a.getList(i, 10, 10, function(i, e) {
                a.setData({
                    videoList: i,
                    playlist: e
                });
            }, !1);
        });
    },
    getList: function(i) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10, a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10, o = arguments.length > 3 ? arguments[3] : void 0, n = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        (0, t.queryRelativeTracks)(i, e, a, !0).then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = [], a = (t = n ? e.filter(function(e) {
                return e.isVideo && e.id != i;
            }) : e.filter(function(i) {
                return i.isVideo;
            })).map(function(i) {
                return i.id;
            });
            o && "function" == typeof o && o(t, a, i);
        });
    },
    loadMore: function() {
        var i = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], e = arguments.length > 1 ? arguments[1] : void 0, t = this.data.videoList, a = 10, o = 10, n = 0, s = t.slice();
        i ? (o = "0", n = s.pop().id) : (a = "0", n = s.shift().id), this.getList(n, o, a, e);
    },
    loadNext: function() {
        var e = this;
        if (this.hasMoreNext && !this.loading) {
            var t = this.data, a = t.videoList, o = t.playlist;
            t.id;
            this.loading = !0, this.setData({
                isLoadingNext: !0
            }), this.loadMore(!0, function(t, n, s) {
                if (e.loading = !1, e.setData({
                    isLoadingNext: !1
                }), !t || 0 === t.length) return e.hasMoreNext = !1, void e.setData({
                    hasMoreNext: !1
                });
                e.setData({
                    videoList: [].concat(i(a), i(t)),
                    playlist: [].concat(i(o), i(n))
                });
            });
        }
    },
    loadPrev: function() {
        var e = this;
        if (this.hasMorePrev && !this.loading) {
            var t = this.data, a = t.videoList, o = t.playlist;
            t.id;
            this.loading = !0, this.setData({
                isLoadingPrev: !0
            }), this.loadMore(!1, function(t, n, s) {
                e.loading = !1, e.setData({
                    isLoadingPrev: !1
                }), t && 0 !== t.length ? e.setData({
                    videoList: [].concat(i(t), i(a)),
                    playlist: [].concat(i(n), i(o))
                }) : e.hasMorePrev = !1;
            });
        }
    },
    loadMoreComments: function() {
        a.EventBus.emit("loadMore");
    },
    onVideoIdChange: function(i) {
        var e = i.detail;
        this.init(e);
    },
    handleVideoTap: function(i) {
        var e = i.detail;
        this.init(e);
    },
    likeTrack: function() {
        var i = this, e = this.data.trackInfo.isFavourite;
        (e ? t.dislikeTrack : t.likeTrack)(this.id).then(function() {
            e || a.EventBus.emit("showFavModal", {}), i.setData({
                "trackInfo.isFavourite": !e
            }), i.log_like_video(e ? "取消喜欢" : "喜欢");
        });
    },
    togglePanelVisible: function() {
        this.setData({
            panelVisible: !this.data.panelVisible
        });
    },
    toTrack: function() {
        this.log_back_to_track(), (0, o.video2Track)(this.id);
    },
    toAlbum: function() {
        this.log_click_album_info();
        var i = this.data.albumInfo.id;
        wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(i)
        });
    },
    onPlay: function() {
        this.setData({
            playState: "playing"
        });
    },
    onPause: function() {
        this.setData({
            playState: "pause"
        });
    },
    onEnd: function() {
        this.setData({
            playState: "end"
        });
    },
    log_back_to_track: function() {
        (0, n.genLogger)(33755, "click", {
            currPage: "video"
        });
    },
    log_like_video: function(i) {
        (0, n.genLogger)(33756, "click", {
            currPage: "video",
            item: i
        });
    },
    log_share_video: function() {
        (0, n.genLogger)(33757, "click", {
            currPage: "video"
        });
    },
    log_click_album_info: function() {
        (0, n.genLogger)(33760, "click", {
            currPage: "video"
        });
    },
    log_write_comment: function() {
        (0, n.genLogger)(33762, "click", {
            currPage: "video"
        });
    },
    log_replay_comment: function() {
        (0, n.genLogger)(33763, "click", {
            currPage: "video"
        });
    },
    log_mobile_tip_show: function() {
        (0, n.genLogger)(33753, "slipPage", {
            currPage: "video"
        });
    },
    log_mobile_tip_tap: function() {
        (0, n.genLogger)(33754, "click", {
            currPage: "video"
        });
    }
});