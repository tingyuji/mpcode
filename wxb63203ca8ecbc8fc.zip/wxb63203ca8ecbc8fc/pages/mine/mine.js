var t = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../common/utils/index"), i = require("../../common/apis/mineapi"), s = require("../../common/utils/myAdapter"), n = require("../../common/utils/storage"), o = require("../../common/utils/logger"), u = require("../../packages/lite-player/event"), r = require("../../common/apis/album"), c = require("../../common/utils/wxSubscribe"), l = require("../../common/utils/navBar"), g = require("../../common/utils/tabbar"), h = null;

Page({
    data: {
        tabArr: [ {
            value: "订阅",
            id: 2
        }, {
            value: "喜欢",
            id: 3
        }, {
            value: "已购",
            id: 1
        }, {
            value: "历史",
            id: 0
        } ],
        subType: 2,
        albums: [],
        page: 1,
        pageSize: 20,
        total: 0,
        category: "all",
        userInfo: {},
        tracks: [],
        isLogin: !1,
        subModalVisible: !1
    },
    onLoad: function() {
        this.retryAdCount = 1, this.resetData(), (0, n.isLogin)() ? (this.init(), this.handleSubModalShow(), 
        this.createAdInstance()) : ((0, n.checkLogin)(), this.setData({
            isLogin: !1
        }));
    },
    onShow: function() {
        var t = this;
        if ((0, g.setTabBar)(this), (0, n.isLogin)() || this.resetData(), (0, n.isLogin)()) {
            var e = this.data.userInfo, a = (e = void 0 === e ? {} : e).uid;
            if ((0, n.isSameUser)(a)) {
                var i = this.data.subType;
                this.setData({
                    page: 1
                }, function() {
                    t.getDatas(i, !0);
                });
            } else this.init(!0);
        }
    },
    onScroll: function() {},
    init: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this.setData({
            isLogin: !0
        });
        var e = this.data.subType, a = (0, n.getUid)();
        t && this.setData({
            page: 1
        }), this.getDatas(e, t), this.queryUserInfo(a);
    },
    createAdInstance: function() {
        var t = this;
        (h = wx.createInterstitialAd({
            adUnitId: "adunit-f8ac8a9de2bf59ae"
        })).onLoad(function() {
            t.showInterstitialAd();
        }), h.onError(function(e) {
            console.log("createAdInstance", e), !(0, n.getTodayFirstMineAd)() && t.retryAdCount <= 3 && (t.retryAdCount++, 
            h.load());
        }), h.onClose(function() {
            (0, n.getTodayFirstMineAd)(!0);
        });
    },
    showInterstitialAd: function() {
        (0, n.get)("SUBSCRIBE_REMIND_SHOWED") && (!(0, n.getTodayFirstMineAd)() && h && h.show().catch(function(t) {
            console.log("createAdInstance", t);
        }));
    },
    getLikeTracks: function() {
        var t = this, a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], s = this.data, n = s.page, o = s.pageSize, u = s.tracks, r = {
            pageNum: n,
            pageSize: o
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, i.queryLikeTracks)(r).then(function(i) {
            wx.hideToast(), t.setData(e(e({}, i), {}, {
                tracks: a ? i.tracksList : [].concat(u, i.tracksList)
            }));
        });
    },
    getSubscribeAlbums: function() {
        var t = this, a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], s = this.data, n = s.page, o = s.pageSize, u = s.category, r = s.subType, c = s.albums, l = {
            num: n,
            size: o,
            subType: r,
            category: u
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, i.querySubscribeAlbum)(l).then(function(i) {
            wx.hideToast(), t.setData(e(e({}, i), {}, {
                albums: a ? i.albumList : [].concat(c, i.albumList)
            }));
        }).catch(function(t) {
            console.log("error", t), wx.hideToast();
        });
    },
    getHasBroughtAlbums: function() {
        var t = this, a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], s = this.data, n = s.page, o = s.pageSize, u = s.albums, r = {
            pageNum: n,
            pageSize: o
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, i.queryHasBroughtAlbums)(r).then(function(i) {
            wx.hideToast(), t.setData(e(e({}, i), {}, {
                albums: a ? i.albumList : [].concat(u, i.albumList)
            }));
        }).catch(function(t) {
            console.log("error", t), wx.hideToast();
        });
    },
    getDatas: function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        switch (console.log("index", t), t) {
          case 1:
            this.getHasBroughtAlbums(e);
            break;

          case 2:
            this.getSubscribeAlbums(e);
            break;

          case 3:
            this.getLikeTracks(e);
        }
    },
    tabSwitch: function(t) {
        var e = this, a = t.currentTarget.dataset.index, i = this.data, s = i.subType, n = i.tabArr;
        parseInt(a) !== parseInt(s) && ((0, o.clickMineTab)(n.find(function(t) {
            return t.id === parseInt(a);
        }).value), this.setData({
            subType: a,
            page: 1,
            albums: [],
            tracks: [],
            trackData: {
                yesterday: [],
                earlier: []
            }
        }, function() {
            return e.getDatas(a);
        }));
    },
    getMoreAlbums: function() {
        var t = this, e = this.data.subType, a = this.data.page;
        switch (e) {
          case 1:
            a++, this.setData({
                page: a
            }, function() {
                return t.getHasBroughtAlbums();
            });
            break;

          case 2:
            a++, this.setData({
                page: a
            }, function() {
                return t.getSubscribeAlbums();
            });
            break;

          case 3:
            a++, this.setData({
                page: a
            }, function() {
                return t.getLikeTracks();
            });
        }
    },
    loadMoreAlbums: function() {
        console.log("到底了"), (0, a.debounce)(this.loadMore.bind(this), 200)();
    },
    loadMore: function() {
        var t = this;
        console.log("到底了啊");
        var e = this.data, a = e.page, i = e.total, s = e.pageSize;
        i - e.albums.length > 0 && i > a * s && this.setData({
            page: a++
        }, function() {
            return t.getMoreAlbums();
        });
    },
    toAlbum: function(t) {
        this.data.subType;
        this.clickAlbum(), (0, a.toAlbum)((0, a.getAlbum)(t, this.data.albums));
    },
    queryUserInfo: function(t) {
        var e = this;
        (0, i.queryUserInfo)({
            uid: t
        }).then(function(t) {
            e.setData({
                userInfo: t
            }), (0, n.set)("userInfo", t);
        });
    },
    toFollow: function(t) {
        var e = (0, s.getDataset)(t).type;
        this.data.isLogin && (this.log_click_fans("fans" === e ? "粉丝" : "关注"), wx.navigateTo({
            url: "/pages/follow/follow?type=".concat(e)
        }));
    },
    toSetting: function() {
        wx.navigateTo({
            url: "/pages/setting/setting"
        });
    },
    logIn: function() {
        if ((0, n.isLogin)()) {
            this.log_click_user(), (0, o.genLogger)(27124, "click", {
                currPage: "my"
            });
            var t = this.data.userInfo.uid;
            return wx.navigateTo({
                url: "/pages/announcer/announcer?id=".concat(t)
            });
        }
        wx.navigateTo({
            url: "/pages/login/login"
        });
    },
    toPoints: function() {
        (0, o.clickSigninEntrance)(), wx.showToast({
            title: "因业务调整，小程序签到功能已关闭，请前往APP完成签到",
            icon: "none",
            duration: 3e3
        });
    },
    resetData: function() {
        this.setData({
            page: 1,
            albums: [],
            tracks: [],
            trackData: {
                yesterday: [],
                earlier: []
            },
            userInfo: {},
            isLogin: !1
        });
    },
    clickAlbum: function() {
        var t = this.data, e = t.subType, a = t.tabArr;
        (0, c.addSubCount)(this.getClickAlbumType()), (0, o.genLogger)(17136, "click", {
            currPage: "my",
            moduleName: a.find(function(t) {
                return t.id === parseInt(e);
            }).value
        });
    },
    getClickAlbumType: function() {
        var t = this.data.subType, e = "我页点击喜欢声音";
        return 1 == t && (e = "我页点击已购专辑"), 2 == t && (e = "我页点击订阅专辑"), e;
    },
    subWxAlbum: function(t) {
        var e = this, i = t.detail.value, n = (0, s.getDataset)(t), c = n.id;
        n.index;
        (0, o.genLogger)(19481, "click", {
            item: i ? "open" : "close",
            albumId: c
        });
        var l = function(t) {
            "accept" === t && (0, r.addAlbumPushCount)().then(function(t) {
                (!t.today_count || t.today_count < 10) && (0, a.wxSubscribeAlbum)();
            }), "query" === t && (0, a.wxSubscribeAlbum)(function(t) {
                u.EventBus.emit("showSubTip", !1), (0, o.genLogger)(19482, "click", {
                    item: "accept" === t ? "允许一次" : "取消一次"
                }), "accept" === t && ((0, r.addAlbumPushCount)(), e.switchAlbumSubStatus(c, !0)), 
                "reject" === t && e.switchAlbumSubStatus(c);
            });
        };
        c && i ? (0, a.queryWxSubStatus)("我页订阅开关", function(t) {
            switch (t) {
              case "reject":
                u.EventBus.emit("showSettingTip", "sub"), e.switchAlbumSubStatus(c, !1);
                break;

              case "query":
                u.EventBus.emit("showSubTip", !0), l(t);
                break;

              case "accept":
                l(t), e.switchAlbumSubStatus(c, !0);
                break;

              case "error":
                wx.showToast({
                    icon: "none",
                    title: "出了点小问题，请明天再尝试"
                }), e.switchAlbumSubStatus(c);
            }
        }) : !i && c && this.switchAlbumSubStatus(c);
    },
    switchAlbumSubStatus: function(a) {
        var i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], s = this.data.albums, n = s.findIndex(function(t) {
            return Number(t.id) === Number(a);
        });
        (0, r.switchPushAlbum)({
            albumId: a,
            status: i ? 1 : 0
        });
        var o = JSON.parse(JSON.stringify(s[n]));
        this.setData(t({}, "albums[".concat(n, "]"), e(e({}, o), {}, {
            pushSwitchForWechat: i
        })));
    },
    showModal: function() {
        this.setData({
            modalVisible: !0
        });
    },
    closeModal: function() {
        this.setData({
            modalVisible: !1
        });
    },
    handleSubModalShow: function() {
        (0, n.get)("SUBSCRIBE_REMIND_SHOWED") || this.showSubModal();
    },
    closeSubModal: function() {
        this.setData({
            subModalVisible: !1
        });
    },
    showSubModal: function() {
        this.setData({
            subModalVisible: !0
        });
    },
    toVip: function() {
        (0, l.isAndroid)() && wx.navigateTo({
            url: "/pages/vip/vip"
        }), (0, o.genLogger)(28691, "click", {});
    },
    log_click_user: function() {
        (0, o.genLogger)(27124, "click", {
            currPage: "my"
        });
    },
    log_click_fans: function(t) {
        (0, o.genLogger)(27125, "click", {
            item: t,
            currPage: "my"
        });
    }
});