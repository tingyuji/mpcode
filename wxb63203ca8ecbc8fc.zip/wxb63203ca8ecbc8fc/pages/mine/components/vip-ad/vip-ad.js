var i = require("../../../../common/utils/storage"), e = require("../../../../common/utils/logger"), o = require("../../../../packages/lite-player/event"), s = require("../../../../common/utils/index");

Component({
    attached: function() {
        this.setData({
            isLogin: (0, i.isLogin)()
        });
    },
    properties: {
        isVip: Boolean
    },
    data: {
        isAndroid: !1,
        isLogin: !1,
        isIos: (0, s.isIos)()
    },
    methods: {
        joinVip: function() {
            o.EventBus.emit("openGModal", {
                vipModal: {
                    visible: !0
                }
            }), (0, e.clickVipBar)();
        }
    }
});