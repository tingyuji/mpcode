var t = require("../../common/utils/index"), a = require("../../common/apis/rankpage"), e = require("../../common/apis/anchor"), n = require("../../common/utils/logger");

Page({
    data: {
        pageNum: 1,
        pageSize: 20,
        hasMore: !0,
        originRankList: [],
        data: {
            type: "album",
            rankTypes: [],
            rankCategory: [],
            rankList: [],
            curRankId: 0,
            scrollTop: 0
        },
        xmcdnImg: (0, t.xmcdnImg)()
    },
    onLoad: function(t) {
        var a = t.typeId, e = t.clusterId;
        this.getRankTypes(Number(a), Number(e));
    },
    onReady: function() {
        (0, t.setNavigationBarTitle)("排行榜");
    },
    getRankTypes: function(t, e) {
        var n = this;
        (0, a.getRankType)().then(function(a) {
            var i = a.tabLists, o = void 0 === i ? [] : i;
            n.rankCategories = [];
            var s = o.map(function(t) {
                return n.rankCategories.push(t.tabWraps || []), {
                    id: t.tabWraps[0].rankingId,
                    title: t.name
                };
            }), r = -1;
            n.rankCategories = n.rankCategories.map(function(t, a) {
                return t.map(function(t) {
                    return e && t.rankingId === e && (r = a), {
                        id: t.rankingId,
                        title: t.name
                    };
                });
            }), n.getRankList(n.rankCategories[0][0].id), n.setData({
                rankTypes: s,
                curRankId: t || s[0].id,
                rankCategorie: r > -1 ? n.rankCategories[r] : n.rankCategories[0],
                curRankClusterId: e || n.rankCategories[0][0].id
            });
        });
    },
    getRankList: function(t) {
        var e = this;
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), this.hasMore = !0, this.pageNum = 1, (0, a.getRankList)({
            rankingId: t
        }).then(function(t) {
            wx.hideToast();
            var n = t.rankList, i = void 0 === n ? [] : n, o = i[0].albums.length, s = o ? i[0].albums : i[0].anchors;
            s = s.map(a.parseRankList), e.originRankList = s, e.setData({
                scrollTop: 0,
                rankList: s.slice(0, e.pageSize),
                type: o ? "album" : "anchor"
            });
        }).catch(function() {
            wx.hideToast();
        });
    },
    changeRankType: function(a) {
        var e = (0, t.getDataset)(a), n = e.id, i = e.idx;
        e.title;
        console.log("id", n, i, this.rankCategories), n !== this.data.curRankId && null != n && null != n && (this.setData({
            curRankId: n,
            rankCategorie: this.rankCategories[i],
            curRankClusterId: this.rankCategories[i][0].id
        }), this.getRankList(this.rankCategories[i][0].id));
    },
    changeRankCategory: function(a) {
        var e = (0, t.getDataset)(a), n = e.id;
        e.title;
        n !== this.data.curRankClusterId && (console.log("id", n), null != n && null != n && (this.setData({
            curRankClusterId: n
        }), this.getRankList(this.data.curRankClusterId)));
    },
    toFollow: function(a) {
        var n = this, i = (0, t.getDataset)(a), o = i.uid, s = i.idx;
        console.log("follow", o), o && (0, t.checkLogin)() && (0, e.setFollow)({
            followingUid: o
        }).then(function(t) {
            200 == t.ret ? (wx.showToast({
                icon: "none",
                title: "关注成功  可在首页-底部我的中找到"
            }), n.refreshFollowStatus(s, !0)) : wx.showToast({
                icon: "none",
                title: t.msg || "关注失败"
            });
        });
    },
    cancelFollow: function(a) {
        var n = this, i = (0, t.getDataset)(a), o = i.uid, s = i.idx;
        console.log("cancelFollow", o), o && (0, e.cancelFollow)({
            followingUid: o
        }).then(function(t) {
            200 == t.ret && (wx.showToast({
                icon: "none",
                title: "已取消"
            }), n.refreshFollowStatus(s, !1));
        });
    },
    refreshFollowStatus: function(t, a) {
        var e = this.data.rankList.slice();
        e[t].isFollow = a, this.setData({
            rankList: e
        });
    },
    loadMore: (0, t.debounce)(function() {
        if (this.hasMore) {
            wx.showToast({
                icon: "loading",
                title: "加载中"
            }), this.pageNum++;
            var t = this.originRankList.slice((this.pageNum - 1) * this.pageSize, this.pageNum * this.pageSize);
            t.length < this.pageSize && (this.hasMore = !1), this.setData({
                rankList: this.data.rankList.concat(t)
            }), wx.hideToast();
        }
    }, 300),
    logAlbumClick: function() {
        (0, n.genLogger)(27110, "click", {
            currPage: "newRank"
        });
    },
    onShareAppMessage: function() {
        return {
            title: "排行榜-喜马拉雅",
            path: "/pages/rankpage/rankpage"
        };
    }
});