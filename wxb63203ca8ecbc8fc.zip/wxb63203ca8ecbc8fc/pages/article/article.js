var t = require("../../common/apis/article"), e = require("../../common/apis/categoryapi"), a = require("../../common/utils/myAdapter"), i = require("../../common/apis/rankapi");

Page({
    data: {
        cateList: [],
        info: {},
        recommendList: []
    },
    onLoad: function(t) {
        var e = t.id, a = void 0 === e ? 104 : e;
        if (!a) return wx.redirectTo({
            url: "/pages/404/index"
        });
        this.getDetail(a), this.getCategoryList();
    },
    getDetail: function(e) {
        var a = this;
        (0, t.getArticleDetail)(e).then(function(t) {
            a.setData({
                info: t
            }, function() {
                a.getRecommmendAlbums();
            });
        });
    },
    getCategoryList: function() {
        var t = this;
        (0, e.queryCategories)().then(function(e) {
            var a = (e || []).map(function(t) {
                return t.category;
            });
            t.setData({
                cateList: a
            });
        });
    },
    toCatePage: function(t) {
        var e = t.detail, a = (e = void 0 === e ? {} : e).index;
        wx.navigateTo({
            url: "/pages/categorylist/categorylist?categoryCode=".concat(a)
        });
    },
    goAlbum: function(t) {
        var e = (0, a.getDataset)(t).id;
        wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(e)
        });
    },
    getRecommmendAlbums: function() {
        var t = this, e = this.data.info, a = (e = void 0 === e ? {} : e).categoryCode;
        (0, i.queryRank)({
            categoryCode: a,
            clusterCode: "hotplay"
        }).then(function(e) {
            var a = e.rankList;
            t.setData({
                recommendList: a.slice(0, 10)
            });
        });
    }
});