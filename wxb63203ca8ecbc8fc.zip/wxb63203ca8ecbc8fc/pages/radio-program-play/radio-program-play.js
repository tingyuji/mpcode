var a = require("../../@babel/runtime/helpers/slicedToArray"), r = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/apis/radio"), i = require("../../common/apis/parse"), t = require("../../packages/lite-player/index"), o = require("../../common/utils/time"), n = require("../../common/utils/index"), s = require("../../common/utils/logger");

Page({
    data: {
        radio: {},
        swiperMargin: "90px",
        prevRadioId: "",
        radioIndex: -1,
        dayPrograms: [],
        changeRadios: [],
        tabIndex: 1,
        playListInfo: null,
        isTabBarFixed: !1,
        showPlayStatus: !1,
        playState: t.PlayState.INITIAL,
        PlayStateP: t.PlayState
    },
    onShareAppMessage: function() {
        var a = this.currentPlayer.currentSource(), e = a.album.url, i = a.cover;
        return r(r({}, a), {}, {
            title: this.data.radio.name + "免费在线收听-喜马拉雅",
            imageUrl: i,
            path: e
        });
    },
    getTimeStatus: function(a, r, e) {
        var i = "", t = !1, n = !1, s = !1, d = {
            type: r,
            startTime: a.startTime,
            endTime: a.endTime
        };
        return (0, o.isLivePlayback)(d) ? (i = "回听", s = !0) : (0, o.isLiveStreaming)(d) ? e || (i = "直播中", 
        t = !0, e = !0) : (0, o.isLivePreview)(d) && (i = "", n = !0), {
            isPre: n,
            isLive: t,
            isLiveBack: s,
            statusTip: i,
            hasLive: e
        };
    },
    getRadioProgramsInfo: function(t) {
        var s = this, d = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], u = [ (0, 
        e.getRadioProsInfo)(t) ];
        d && u.push((0, e.getChangeRadios)()), Promise.all(u).then(function(e) {
            var t = a(e, 2), u = t[0], c = t[1], l = u.radio, g = u.radio, m = g.name, h = g.id, p = g.programId, P = g.programName, v = g.playUrl, y = g.programScheduleId, S = u.currentProgram, f = u.yesterdayPrograms, I = u.todayPrograms, T = u.tomorrowPrograms;
            (0, n.setNavigationBarTitle)("".concat(m, "-").concat(P)), S.programScheduledId || (S.programScheduledId = l.programScheduleId);
            var L = [], w = 1, R = s.currentPlayer.currentSource().id, x = -1, b = -1, U = !1, D = [ {
                id: o.YESTERDAY,
                name: "昨天",
                programs: f
            }, {
                id: o.TODAY,
                name: "今天",
                programs: I
            }, {
                id: o.TOMORROW,
                name: "明天",
                programs: T
            } ];
            if (D.forEach(function(a, e) {
                var t = a.id, o = a.programs;
                a.programs = (o || []).map(function(a) {
                    var o = a.announcerNames, n = a.programScheduledId, d = a.radioPlayUrlDTO, u = L.length;
                    S.programScheduledId === n && (a.radioPlayUrlDTO = v, b = u), R === n && (x = u, 
                    w = e);
                    var c = s.getTimeStatus(a, t, U), g = c.isPre, m = c.isLive, h = c.isLiveBack, p = c.statusTip, P = (0, 
                    i.parseRadioProgram)(l, a, m);
                    return U = c.hasLive, (h || m) && L.push(P), r(r({}, a), {}, {
                        sourcePlayUrl: d,
                        statusTip: p,
                        isLive: m,
                        isPre: g,
                        announcerName: !!o && o.join(" ") || ""
                    });
                });
            }), -1 === b && -1 === x && v) {
                var M = (0, i.parseRadioProgram)(l, {
                    name: P,
                    id: p,
                    programScheduleId: y,
                    radioPlayUrlDTO: v
                }, !0);
                L = [ M ], b = 0;
            }
            d && (c.find(function(a) {
                return a.id === h;
            }) || c.unshift(l));
            var C = d ? c : s.data.changeRadios, A = C.findIndex(function(a) {
                return a.id === l.id;
            }), F = C[A].name, O = A > 0 && C[A - 1].id, k = s.calcSwiperMargin(F);
            s.setData({
                prevRadioId: O,
                swiperMargin: k,
                radioIndex: A,
                changeRadios: C,
                dayPrograms: D,
                radio: l,
                tabIndex: w,
                playListInfo: {
                    playList: L,
                    index: -1 === x ? b : x
                }
            }, function() {
                wx.createSelectorQuery().select(".radio-program-content>>>.tab-container").boundingClientRect(function(a) {
                    s.tabTop = a.top;
                }).exec();
            });
        });
    },
    calcSwiperMargin: function(a) {
        var r = wx.createCanvasContext("canvas");
        r.setFontSize(20);
        var e = r.measureText(a).width + 48, i = this.windowWidth - 18 - 26;
        return Math.ceil((i - e) / 2);
    },
    onLoad: function(a) {
        this.currentPlayer = (0, t.getCurrentPlayer)(), this.windowWidth = wx.getSystemInfoSync().windowWidth;
        var r = a.radioId;
        this.getRadioProgramsInfo(r, !0);
    },
    onRadioChange: function(a) {
        var r = a.currentTarget.dataset.id;
        r && this.getRadioProgramsInfo(r);
    },
    swiperChange: function(a) {
        var r = this.data.changeRadios[a.detail.current].id;
        r !== this.data.radio.id && r && (this.getRadioProgramsInfo(r), (0, s.genLogger)(30726, "handSlip", {
            radioId: r,
            currModule: "广播播放页-滑动顶部换台",
            currPage: "radio"
        }));
    },
    onRadioChangeModal: function(a) {
        var r = a.detail.radioId;
        this.getRadioProgramsInfo(r);
    },
    onUpdateLiveProgram: function(a) {
        var e = this, t = a.detail, o = this.data, n = o.dayPrograms, s = o.radio, d = o.radio.playUrl, u = [], c = !1, l = -1, g = n.map(function(a) {
            var o = a.id, n = a.programs;
            return a.programs = n.map(function(a) {
                var n = a.sourcePlayUrl, g = a.programScheduledId, m = e.getTimeStatus(a, o, c), h = m.isPre, p = m.isLive, P = m.isLiveBack, v = m.statusTip;
                c = m.hasLive, a.radioPlayUrlDTO = p ? d : n;
                var y = (0, i.parseRadioProgram)(s, a, p);
                return (P || p) && (t && t === g && (l = u.length), u.push(y)), r(r({}, a), {}, {
                    statusTip: v,
                    isLive: p,
                    isPre: h
                });
            }), a;
        });
        this.setData({
            dayPrograms: g,
            playListInfo: {
                playList: u,
                index: -1 === l ? u.length - 1 : l
            }
        });
    },
    onFavoriteChange: function() {
        var a = this, i = this.data, t = i.radio, o = i.radio, n = o.id, d = o.isFavorite;
        (0, e.operateFavorite)(n, d).then(function(e) {
            var i = e.success, o = e.isFavorite;
            i && ((0, s.genLogger)(30731, "click", {
                currModule: "广播播放收藏",
                radioId: a.data.radio.id,
                currPage: "radio",
                item: o ? "收藏" : "取消收藏"
            }), wx.showToast({
                title: o ? "已收藏" : "已取消收藏",
                icon: "none"
            }), a.setData({
                radio: r(r({}, t), {}, {
                    isFavorite: o
                })
            }));
        });
    },
    onScroll: (0, n.throttle)(function(a) {
        var r = a.detail.scrollTop, e = this.data, i = e.isTabBarFixed, t = e.showPlayStatus, o = r > this.tabTop - 76, n = r > 10, s = {};
        o !== i && (s.isTabBarFixed = o), n !== t && (s.showPlayStatus = n), Object.keys(s).length > 0 && this.setData(s);
    }, 500),
    onPlay: function() {
        var a = this.currentPlayer.playState;
        a === t.PlayState.PLAYING ? this.currentPlayer.pause() : a === t.PlayState.PAUSE && this.currentPlayer.resume();
        var r = this.currentPlayer.currentSource(), e = a === t.PlayState.PLAYING ? "暂停" : a === t.PlayState.PAUSE ? "播放" : "";
        e && (0, s.genLogger)(30727, "click", {
            item: e,
            program: r,
            radioId: r.albumId,
            currModule: "广播播放页-顶部导航点击播放/暂停",
            currPage: "radio"
        });
    },
    onPlayStateChange: function(a) {
        var r = a.detail;
        this.setData({
            playState: r
        });
    }
});