Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.countPrice = void 0;

exports.countPrice = function(e, t) {
    var o = t.discountType, r = t.discountRate, u = t.couponValue;
    return o && (e = "RATE" === o ? 100 * e * r * 100 / 1e4 : e - u) < 0 ? 0 : e;
};