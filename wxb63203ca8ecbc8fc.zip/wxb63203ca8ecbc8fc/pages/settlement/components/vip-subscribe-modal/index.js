var e = require("../../../../packages/lite-player/event"), t = require("../../../../common/apis/paid"), s = require("../../../../common/utils/index"), o = require("../../../../common/utils/handleVipSubsribe");

Component({
    properties: {},
    data: {
        visible: !1,
        queryText: "点击重新查询"
    },
    attached: function() {
        this._showModal = this.showModal.bind(this), this._close = this.close.bind(this), 
        e.EventBus.on("showAutoRenewQueryModal", this._showModal), e.EventBus.on("closeAutoRenewQueryModal", this._close);
    },
    detached: function() {
        e.EventBus.off("showAutoRenewQueryModal", this._showModal), e.EventBus.off("closeAutoRenewQueryModal", this._close);
    },
    pageLifetimes: {
        hide: function() {}
    },
    methods: {
        showModal: function() {
            this.setData({
                visible: !0
            });
        },
        close: function() {
            this.setData({
                visible: !1
            });
        },
        closeModal: function() {
            e.EventBus.emit("closeAutoRenewQueryModal");
        },
        queryStatus: function() {
            var e = this;
            this.setData({
                queryText: "查询中..."
            }), (0, t.getVipSubscribeStatus)((0, s.getUid)()).then(function(t) {
                wx.disableAlertBeforeUnload && wx.disableAlertBeforeUnload({}), 1 === t.statusId ? (e.closeModal(), 
                (0, o.showSuccessModal)(t.itemId)) : e.setData({
                    queryText: "点击重新查询"
                });
            });
        }
    }
});