var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/utils/index"), i = require("../../common/utils/logger"), o = require("../../common/apis/paid"), n = require("./utils/index"), s = require("../albumDetail/utils/index"), a = require("../../packages/lite-player/event"), r = getApp();

Page({
    businessTypeId: 202,
    channelTypeId: 64,
    context: "",
    pageNum: 1,
    orderItemsStr: "",
    compositeItemId: "",
    fromUri: "",
    data: {
        defaultImg: "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/images/album/default-album2.jpg",
        vipImg: "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/images/anchor/vip.png",
        nickname: "",
        showModal: !1,
        canSenvenDayRefund: null,
        trackList: [],
        useCoupon: !1,
        autoRenewModalVisible: !0
    },
    onLoad: function() {
        var t = this, e = this.options, n = e.albumId, s = e.trackId, a = e.isSingleAllBuy, u = e.isVipAlbum, d = e.tracksCount, c = e.isBuyVip, l = e.vipProductId, m = e.jointVipPromoter, h = e.isTrainCamp, p = e.itemId, I = e.discountRate, f = e.isAutoRenew, g = void 0 !== f && f, b = e.unitPrice;
        if (this.albumId = n, this.trackId = s, (0, o.getCurrentUser)().then(function(e) {
            t.setData({
                nickname: e.nickname,
                isVipAlbum: u
            });
        }), wx.enableAlertBeforeUnload) {
            var T = this;
            wx.enableAlertBeforeUnload({
                message: c ? "加入喜马拉雅VIP，27800+好书好课免费听~确认放弃？" : "购买后永久收听，早买早享受哦~ 超多用户已购买 确认放弃？",
                success: function() {
                    (0, i.genLogger)(28689, "slipPage", {}), T.showEnableAlert = !0;
                },
                fail: function() {}
            });
        }
        if (c) {
            var y = "true" === g.toString().toLowerCase();
            return this.setData({
                isBuyVip: c,
                isAutoRenew: y
            }), r.globalData.isAutoRenew = y, this.isAutoRenew = y, this.orderItemsStr = l, 
            this.businessTypeId = 1226, this.isAutoRenew && (this.unitPrice = b), m && (this.context = "{jointVipPromoter:1}"), 
            void this.loadPageInfo({
                domain: 1,
                businessTypeId: this.businessTypeId,
                orderItems: l,
                returnUrl: this.fromUri
            });
        }
        return this.senvenDayRefund(s || n), d ? (this.fromUri = "/pages/albumDetail/albumDetail?albumId=".concat(n), 
        void this.filterSingleBuyTracks({
            trackId: s,
            count: d
        })) : s ? (this.fromUri = "/pages/soundPage/soundPage?trackId=".concat(s), void this.filterAllBuyAlbumOrTrack({
            id: s,
            productType: 2
        })) : n && "true" == a ? (this.fromUri = "/pages/albumDetail/albumDetail?albumId=".concat(n), 
        void this.filterSingleBuyAlbum(n)) : n && "true" == h ? (this.itemId = p, this.fromUri = "/subpackage/pages/joinGuide/index", 
        this.isTrainCamp = !0, this.discountRate = I, void this.filterAllBuyAlbumOrTrack({
            id: n,
            productType: 1
        })) : (this.fromUri = "/pages/albumDetail/albumDetail?albumId=".concat(n), void this.filterAllBuyAlbumOrTrack({
            id: n,
            productType: 1
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onUnload: function() {
        this.showEnableAlert && (0, i.genLogger)(28690, "click", {
            item: "放弃"
        });
    },
    filterSingleBuyAlbum: function(t) {
        var e = this;
        (0, o.prepareBatchAlbumVo)({
            albumId: t,
            returnUrl: this.fromUri
        }).then(function(t) {
            var i = t.data, o = t.code, n = t.msg;
            if (0 == o || 200 == o) {
                var s = i.businessTypeId, a = i.domain, r = i.context, u = i.orderItemsStr, d = i.returnUrl, c = (r = r.replace(/\&quot\;/g, "")).match(/compositeItemId\:(\d+)/)[1];
                e.context = r, e.compositeItemId = c, e.orderItemsStr = u, e.loadPageInfo({
                    domain: a,
                    businessTypeId: s,
                    context: r,
                    orderItems: u,
                    returnUrl: d
                });
            } else wx.showToast({
                title: n,
                icon: "none"
            });
        });
    },
    filterAllBuyAlbumOrTrack: function(t) {
        var e = this, i = t.id, n = t.productType;
        this.isTrainCamp ? (this.businessTypeId = 1275, this.context = decodeURI('{originSite:"wxxcx-xly"}'), 
        this.loadPageInfo({
            domain: 1,
            businessTypeId: this.businessTypeId,
            orderItems: this.itemId,
            returnUrl: this.fromUri
        })) : (1 == n && (this.businessTypeId = 201), (0, o.genProductItemId)({
            id: i,
            productType: n
        }).then(function(t) {
            var i = t.data;
            e.orderItemsStr = i, 2 == n ? e.context = "{trackIdsNum:1,orderTypeId:1,compositeItemId:".concat(i, "}") : 1 === n && (e.context = "{refundable:true}"), 
            e.loadPageInfo({
                domain: 1,
                businessTypeId: e.businessTypeId,
                orderItems: i,
                returnUrl: e.fromUri
            });
        }));
    },
    filterSingleBuyTracks: function(t) {
        var e = this, i = t.trackId, n = t.count;
        (0, o.queryProductMulti)({
            trackId: i,
            count: n
        }).then(function(t) {
            var i = t.data.productVo, o = void 0 === i ? {} : i, n = o.businessTypeId, s = o.context, a = s.compositeItemId, r = s.orderTypeId, u = s.trackIdsNum, d = o.domain, c = o.orderItems;
            e.context = "{trackIdsNum:".concat(u, ",orderTypeId:").concat(r, ",compositeItemId:").concat(a, "}"), 
            e.compositeItemId = a, e.orderItemsStr = c, e.loadPageInfo({
                domain: d,
                context: e.context,
                businessTypeId: n,
                orderItems: c,
                returnUrl: e.fromUri
            });
        }).catch(function(t) {
            wx.showToast({
                title: "接口异常，过滤多集购买失败",
                icon: "none"
            });
        });
    },
    loadPageInfo: function(e) {
        var i = this, s = e.domain, a = e.businessTypeId, r = e.context, u = e.orderItems, d = e.returnUrl, c = {};
        r && (c.context = r), (0, o.prepareorderInfo)(t(t({
            domain: s,
            businessTypeId: a
        }, c), {}, {
            orderItems: u,
            returnUrl: d
        })).then(function(t) {
            if (t.orderContext || !t.msg) {
                var e = t.orderContext, o = e.orderItems, s = void 0 === o ? [] : o, a = e.totalAmount, r = e.totalQuantity, u = e.couponInfo || {}, d = u.promoCodes, c = u.supportCoupon && d && d.length > 0, l = {};
                c && ((l = d[0]).discountRate = i.discountRate, l.usedAmount = (0, n.countPrice)(a, l)), 
                i.setData({
                    totalAmount: i.isAutoRenew ? i.unitPrice : a,
                    totalQuantity: r,
                    orderItems: s,
                    useCoupon: c,
                    coupon: l
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            wx.showToast({
                title: "接口异常，结算页信息获取失败",
                icon: "none"
            });
        });
    },
    senvenDayRefund: function(t) {
        var e = this;
        (0, o.isAlbumSupportRefund)(t).then(function(t) {
            t && 0 == t.ret && e.setData({
                canSenvenDayRefund: t.data
            });
        });
    },
    showTrackList: function() {
        this.setData({
            showModal: !0
        }), 1 == this.pageNum && this.loadData();
    },
    hideTrackList: function() {
        this.setData({
            showModal: !1
        });
    },
    loadMoreOrder: (0, e.debounce)(function() {
        this.loadData();
    }, 200),
    loadData: function() {
        if (0 !== this.pageNum && !this.loading) {
            wx.showToast({
                icon: "loading",
                title: "加载中"
            }), this.loading = !0;
            var t = 10 * (this.pageNum - 1), e = this.data.orderItems.slice(t, t + 10);
            e.length <= 0 ? (this.pageNum = 0, wx.hideToast()) : (this.setData({
                trackList: this.data.trackList.concat(e)
            }), this.pageNum++, this.loading = !1, wx.hideToast());
        }
    },
    buyAutoRenewVip: function() {
        (0, o.subscriptionSign)({
            itemId: this.orderItemsStr,
            channelTypeId: 3,
            accessChannel: 5,
            salesChannel: 22
        }).then(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.params, i = (e = void 0 === e ? {} : e).payInfo, o = "";
            try {
                o = JSON.parse(i);
            } catch (t) {
                console.error("error", t);
            }
            if (!o) return wx.showToast({
                title: "签约失败，请稍后再试",
                icon: "none"
            });
            wx.disableAlertBeforeUnload && wx.disableAlertBeforeUnload({});
            var n = {
                appId: "wxbd687630cd02ce1d",
                extraData: o,
                path: "pages/index/index"
            };
            wx.navigateToMiniProgram(n);
        });
    },
    submitOrder: function() {
        var e = this;
        if (this.data.isAutoRenew) return this.buyAutoRenewVip();
        var n = this.data, s = n.useCoupon, a = n.coupon, r = {
            itemId: this.compositeItemId || this.orderItemsStr
        };
        this.isTrainCamp && (r.itemId = this.itemId), this.compositeItemId && (r.childItemIds = this.orderItemsStr), 
        this.context && (r.context = this.context), s && (r.couponId = a.couponId, r.promoCode = a.promoCode), 
        (0, o.genOrderSign)(t({
            domain: 1,
            businessTypeId: this.businessTypeId,
            channelTypeId: this.channelTypeId,
            returnUrl: this.fromUri
        }, r)).then(function(n) {
            var u = n.data, d = u.sign, c = u.timestamp;
            (0, o.placeorderandmakepayment)(t({
                domain: 1,
                businessTypeId: e.businessTypeId,
                channelTypeId: e.channelTypeId,
                sign: d,
                timestamp: c,
                returnUrl: e.fromUri
            }, r)).then(function(t) {
                if (t) {
                    var o = t.ret, n = t.msg, r = t.params;
                    if (r || !o) {
                        if (s && 0 === a.usedAmount) return wx.showToast({
                            icon: "none",
                            title: "支付成功...跳转中",
                            mask: !0,
                            duration: 1e3
                        }), void e.jumpWithFromUri();
                        var u = r.timeStamp, d = r.nonceStr, c = r.package, l = r.signType, m = r.paySign, h = r.unifiedOrderNo;
                        wx.requestPayment({
                            timeStamp: u,
                            nonceStr: d,
                            package: c,
                            signType: l,
                            paySign: m,
                            success: function(t) {
                                var o = e;
                                wx.disableAlertBeforeUnload && wx.disableAlertBeforeUnload({}), (0, i.genLogger)(26735, "slipPage", {
                                    amount: e.data.totalAmount,
                                    id: h,
                                    type: o.isTrainCamp ? "训练营" : ""
                                }), wx.showModal({
                                    title: "【购买成功】",
                                    content: "".concat(o.options.isBuyVip ? "快去畅听VIP精品内容吧~ " : "可在【我的-已购】中找到"),
                                    confirmText: "好的",
                                    confirmColor: "#F24821",
                                    showCancel: !1,
                                    success: function(t) {
                                        wx.showToast({
                                            icon: "loading",
                                            title: "加载中",
                                            mask: !0,
                                            duration: 1e3
                                        }), o.jumpWithFromUri();
                                    }
                                });
                            },
                            fail: function(t) {
                                var o = t.errCode, n = t.errMsg;
                                (0, i.genLogger)(26736, "slipPage", {
                                    errorType: "".concat(o, ":").concat(n),
                                    amount: e.data.totalAmount
                                }), wx.showToast({
                                    title: "您已取消支付",
                                    icon: "none"
                                });
                            }
                        });
                    } else wx.showToast({
                        title: n,
                        icon: "none"
                    });
                } else wx.showToast({
                    title: "接口异常，请稍后再试",
                    icon: "none"
                });
            }).catch(function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                wx.showToast({
                    title: "errCode:".concat(t.ret, " errMsg:").concat(t.msg),
                    icon: "none"
                });
            });
        });
    },
    closeModal: function() {
        this.setData({
            modalVisible: !1
        });
    },
    jumpWithFromUri: function() {
        var t = this;
        this.fromUri ? setTimeout(function() {
            if (t.refreshAlbumInfo(), t.refreshTrackInfo(), 1 == t.isTrainCamp) {
                var e = t.options.itemId;
                (0, s.getJoinGroupUrl)(e).then(function(t) {
                    wx.redirectTo({
                        url: t
                    });
                });
            } else wx.navigateBack();
        }, 1e3) : wx.navigateBack();
    },
    refreshTrackInfo: function() {
        setTimeout(function() {
            a.EventBus.emit("refreshTrack");
        }, 2e3);
    },
    refreshAlbumInfo: function() {
        var t = this;
        setTimeout(function() {
            t.albumId && a.EventBus.emit("refreshAlbum", t.albumId, t.options.trackId);
        }, 2e3);
    }
});