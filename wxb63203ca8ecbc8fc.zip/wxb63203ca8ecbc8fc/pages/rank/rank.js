var e = require("../../common/apis/rankapi"), t = require("../../common/utils/index");

Page({
    data: {
        clusterCode: "",
        categoryCode: "",
        ranks: [],
        afterThree: [],
        bgClass: ""
    },
    onLoad: function(e) {
        var t = this, a = e.clusterCode, o = void 0 === a ? "free" : a, r = e.categoryCode, s = void 0 === r ? "all" : r;
        this.setData({
            clusterCode: o,
            categoryCode: s,
            bgClass: {
                reputation: "reputation",
                free: "free",
                subscribe: "subscribe",
                rise: "rise"
            }[o] || "normal"
        }, function() {
            return t.getRanks();
        });
    },
    getRanks: function() {
        var t = this, a = this.data, o = {
            clusterCode: a.clusterCode,
            categoryCode: a.categoryCode
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, e.queryRank)(o).then(function(e) {
            wx.hideToast();
            var a = (e || {}).rankList;
            t.setData({
                ranks: a,
                afterThree: a.filter(function(e, t) {
                    return t > 2;
                })
            });
        }).catch(function(e) {
            console.log("rankk", e), wx.hideToast();
        });
    },
    toAlbum: function(e) {
        (0, t.toAlbum)((0, t.getAlbum)(e, this.data.ranks));
    },
    listToAlbum: function(e) {
        (0, t.toAlbum)((0, t.getAlbum)(e, this.data.afterThree));
    }
});