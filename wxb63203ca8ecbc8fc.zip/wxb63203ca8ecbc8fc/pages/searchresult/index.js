var a = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/utils/index.js"), e = require("../../common/apis/resultapi"), r = require("../../common/utils/logger.js"), s = {
    0: "all",
    1: "album",
    2: "track",
    3: "user"
}, o = {
    0: "all",
    1: "album",
    2: "sound",
    3: "anchor"
}, i = {
    0: "relation",
    1: "play",
    2: "recent"
}, c = {
    user: 27215,
    album: 27216,
    track: 27217
};

Page({
    data: {
        tabs: [ "全部", "专辑", "声音", "主播" ],
        sortTabs: [ "相关度", "最近播放", "最新上传" ],
        tabIndex: 0,
        sortIndex: 0,
        albumData: {
            albums: []
        },
        trackData: {
            tracks: []
        },
        userData: {
            users: []
        },
        categories: [],
        category_id: -1,
        page: 1,
        pageSize: 20,
        core: "album",
        kw: "",
        windowHeight: 350,
        scrollTop: 0,
        scrollLeft: 0,
        isLoading: !1
    },
    onLoad: function(a) {
        var t = this, e = a.kw, r = void 0 === e ? "" : e, i = a.type, c = void 0 === i ? "all" : i, n = this.findKey(o, c);
        "album" === c && this.getSearchCategory(r), this.setData({
            kw: r,
            tabIndex: n,
            core: s[n]
        }, function() {
            return t.getSearchData();
        }), this.getWindowHeight();
    },
    onScroll: function() {},
    getSearchData: function() {
        var t = this, r = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], o = this.data, c = o.core, n = o.page, u = o.pageSize, l = o.kw, h = o.sortIndex, g = o.category_id;
        r ? this.setData({
            isLoading: !0
        }) : wx.showToast({
            icon: "loading",
            title: "加载中"
        });
        var d = {
            kw: l,
            core: c,
            page: n,
            rows: "all" === c ? 5 : u
        }, b = "album" === c ? a(a({}, d), {}, {
            category_id: g,
            condition: i[h]
        }) : d;
        (0, e.querySearchResult)(b).then(function(e) {
            var r = e.albumViews, o = e.trackViews, i = e.userViews, n = t.data, u = n.albumData, l = n.trackData, h = n.userData, g = n.page, d = n.pageSize;
            switch (c) {
              case s[0]:
                t.setData({
                    albumData: a(a({}, r), {}, {
                        albums: [].concat(u.albums, r.albums)
                    }),
                    trackData: a(a({}, o), {}, {
                        tracks: [].concat(l.tracks, o.tracks)
                    }),
                    userData: a(a({}, i), {}, {
                        users: [].concat(h.users, i.users)
                    }),
                    hasMore: !1
                }), t.hasMore = !1;
                break;

              case s[1]:
                t.hasMore = g * d <= r.total, t.setData({
                    albumData: a(a({}, r), {}, {
                        albums: [].concat(u.albums, r.albums)
                    }),
                    hasMore: t.hasMore
                });
                break;

              case s[2]:
                t.hasMore = g * d <= o.total, t.setData({
                    trackData: a(a({}, o), {}, {
                        tracks: [].concat(l.tracks, o.tracks)
                    }),
                    hasMore: t.hasMore
                });
                break;

              case s[3]:
                t.hasMore = g * d <= i.total, t.setData({
                    userData: a(a({}, i), {}, {
                        users: [].concat(h.users, i.users)
                    }),
                    hasMore: t.hasMore
                });
            }
            wx.hideToast(), t.setData({
                isLoading: !1
            });
        }).catch(function(a) {
            console.log("error", a), wx.hideToast(), t.setData({
                isLoading: !1
            });
        });
    },
    getSearchCategory: function(a) {
        var t = this;
        (0, e.queryAllCategory)({
            kw: a
        }).then(function(a) {
            var e = a.categories;
            t.setData({
                categories: e
            });
        });
    },
    findKey: function(a, t) {
        var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function(a, t) {
            return a === t;
        };
        return Object.keys(a).find(function(r) {
            return e(a[r], t);
        });
    },
    getWindowHeight: function() {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                a.setData({
                    windowHeight: t.windowHeight
                });
            }
        });
    },
    loadMoreData: function() {
        (0, t.debounce)(this.loadMore.bind(this), 200)();
    },
    loadMore: function() {
        var a = this, t = this.data, e = t.page, r = t.core, o = t.albumData, i = t.trackData, c = t.userData;
        if (this.hasMore) {
            switch (e++, r) {
              case s[0]:
                return;

              case s[1]:
                if (e > o.totalPage) return;
                break;

              case s[2]:
                if (e > i.totalPage) return;
                break;

              case s[3]:
                if (e > c.totalPage) return;
            }
            this.setData({
                page: e
            }, function() {
                return a.getSearchData(!0);
            });
        }
    },
    goBackPage: function() {
        wx.navigateBack();
    },
    tabSwitch: function(a) {
        var t = this, e = this.data, r = e.tabIndex, o = e.kw, i = a.target.dataset.index;
        i != r && this.setData({
            tabIndex: i,
            core: s[i],
            page: 1,
            sortIndex: 0,
            albumData: {
                albums: []
            },
            trackData: {
                tracks: []
            },
            userData: {
                users: []
            }
        }, function() {
            t.getSearchData(), 1 === Number(i) && t.getSearchCategory(o);
        });
    },
    sortTabSwitch: function(a) {
        var t = this, e = this.data.sortIndex, r = a.target.dataset.index;
        r != e && this.setData({
            sortIndex: r,
            page: 1,
            albumData: {
                albums: []
            }
        }, function() {
            return t.getSearchData();
        });
    },
    categorySwitch: function(a) {
        var t = this, e = this.data.category_id, r = a.target.dataset.code;
        parseInt(r) != parseInt(e) && (this.switchAnimation(a), this.setData({
            scrollTop: 0,
            categorySort: 0,
            page: 1,
            albumData: {
                albums: []
            },
            category_id: r
        }, function() {
            return t.getSearchData();
        }));
    },
    switchAnimation: function(a) {
        var t = a.currentTarget.dataset.index, e = this.data.windowWidth / 6;
        this.setData({
            scrollLeft: (t - 2) * e
        });
    },
    log_all_tab: function(a) {
        var e = (0, t.getDataset)(a).type, s = c[e];
        (0, r.genLogger)(s, "click", {
            moduleName: "全部",
            currPage: "searchresult"
        });
    }
});