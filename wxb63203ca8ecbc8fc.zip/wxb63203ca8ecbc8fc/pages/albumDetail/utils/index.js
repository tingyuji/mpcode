Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAlbumLogType = void 0, exports.getJoinGroupUrl = function(t) {
    return new Promise(function(o, n) {
        (0, e.getGroupCode)(t).then(function(e) {
            var t = e.groupCode, n = e.processType, i = "/subpackage/pages/joinGuide/index?type=".concat(n, "&code=").concat(t);
            o(i);
        }, function() {
            n();
        });
    });
}, exports.getSaleTimeStr = function(e) {
    var t = new Date(e), o = t.getMonth() + 1, n = t.getDate();
    return "".concat(o, "月").concat(n, "日");
};

var e = require("../../../common/apis/album");

exports.getAlbumLogType = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        isPaid: !1,
        isVIPCT: !1,
        isVIPZX: !1
    }, t = e.isPaid, o = e.isVIPCT, n = e.isVIPZX, i = "free";
    return t && (i = "paid", o && (i = "vipListen"), n && (i = "vipOnly")), i;
};