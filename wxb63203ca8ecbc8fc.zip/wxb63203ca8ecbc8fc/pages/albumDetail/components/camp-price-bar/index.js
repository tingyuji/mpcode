var t = require("../../../../@babel/runtime/helpers/objectSpread2"), o = require("../../../../common/apis/album"), e = require("../../../../common/apis/paid"), n = require("../../../../common/utils/index"), i = require("../../../../common/utils/logger"), a = require("../../utils/index"), s = require("../../../../packages/lite-player/event"), c = function() {
    wx.showToast({
        title: "人有点多哦，请稍后重试",
        icon: "none"
    });
};

Component({
    properties: {
        campInfo: {
            type: Object,
            observer: function() {
                this.initCountDownInfo();
            }
        },
        albumId: {
            type: Number
        },
        trackId: {
            type: Number
        },
        info: {
            type: Object
        },
        couponInfos: {
            type: Object,
            observer: function(t) {
                if (t.couponInfo && t.couponInfo.list && t.couponInfo.list.length > 0) {
                    var o = t.couponInfo.list[0] || {};
                    this.discountRate = o.discountRate, this.setData({
                        hasCoupon: !0,
                        coupon: o,
                        hasFreeCoupon: 0 === o.usingCouponPrice
                    });
                }
            }
        },
        campExtraInfo: {
            type: Object,
            observer: function() {
                this.initCountDownInfo();
            }
        }
    },
    data: {
        saleInfoStr: "",
        saleEndTimeStr: "",
        remainDateStr: "",
        isIos: (0, n.isIos)(),
        hasFreeCoupon: !1,
        isIphoneX: (0, n.isIPhoneX)()
    },
    attached: function() {
        this.isAllocating = !1;
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        initCountDownInfo: function() {
            var t = this.data, o = t.campInfo, e = t.campExtraInfo;
            if (o && e) {
                var n = Date.now(), i = o.saleEnd, s = o.saleStart, c = o.stockQuantity, r = e.remainMilliseconds, u = s > n ? 0 : i < n ? 2 : 1;
                1 === u && c <= 0 && (u = 2);
                var l = [ Math.ceil((s - n) / 864e5) + "天后开始报名", "", "报名已结束" ], m = "", p = "";
                s && (p = (0, a.getSaleTimeStr)(s)), i && (m = (0, a.getSaleTimeStr)(i)), console.log(l[u], u, m, p, parseInt(r / 864e5, 10), "initCountDownInfo"), 
                this.setData({
                    saleInfoStr: l[u],
                    saleType: u,
                    saleEndTimeStr: m,
                    saleStartTimeStr: p,
                    remainDateStr: parseInt(r / 864e5, 10),
                    remainHourStr: parseInt(r / 36e5, 10)
                });
            }
        },
        toAllocateAndBuy: function() {
            var t = this;
            if ((0, n.checkLogin)() && !this.isAllocating) {
                var e = this.data.coupon, i = e.couponId, a = e.isReceived;
                this.isAllocating = !0, a ? this.toBuyWithCoupon() : (0, o.allocateCoupon)(i).then(function(o) {
                    721 === o.code && t.data.isIos ? t.isAllocating = !1 : (wx.showToast({
                        icon: "loading"
                    }), setTimeout(function() {
                        wx.hideToast(), t.toBuyWithCoupon();
                    }, 1e3));
                }).catch(function() {
                    t.isAllocating = !1, c();
                });
            }
        },
        toBuyWithCoupon: function() {
            var t = this, o = this.data.campInfo.itemId;
            if (this.data.isIos) return this.toAllocateAlbumInIos();
            this.log_buy_camp(), wx.navigateTo({
                url: "/pages/settlement/settlement?albumId=".concat(this.data.albumId, "&isTrainCamp=", !0, "&itemId=").concat(o, "&discountRate=").concat(this.discountRate),
                success: function() {
                    t.isAllocating = !1;
                }
            });
        },
        toAllocateAlbumInIos: function() {
            var o = this, n = this.data, i = n.campInfo.itemId, r = (n.coupon, decodeURI('{originSite:"wxxcx-xly"}'));
            this.log_buy_album_in_ios(), wx.showToast({
                icon: "loading",
                title: "领取中..."
            }), (0, e.prepareorderInfo)({
                domain: 1,
                businessTypeId: 1275,
                orderItems: i
            }).then(function(n) {
                if (!n.orderContext && n.msg) return wx.showToast({
                    title: n.msg,
                    icon: "none"
                }), void (o.isAllocating = !1);
                var u = n.orderContext || {}, l = u.couponInfo, m = u.totalAmount;
                if (!l && m > 0) return o.isAllocating = !1, c();
                var p = {
                    itemId: i,
                    context: r
                }, d = l || {}, h = d.promoCodes;
                d.supportCoupon && h && h.length > 0 && (p.couponId = h[0].couponId, p.promoCode = h[0].promoCode), 
                (0, e.genOrderSign)(t({
                    domain: 1,
                    businessTypeId: 1275,
                    channelTypeId: 65
                }, p)).then(function(n) {
                    var c = n.data, r = c.sign, u = c.timestamp;
                    (0, e.placeorderandmakepayment)(t({
                        domain: 1,
                        businessTypeId: 1275,
                        channelTypeId: 65,
                        sign: r,
                        timestamp: u
                    }, p)).then(function(t) {
                        if (o.isAllocating = !1, t) {
                            var e = t.ret, n = t.msg;
                            t.params || !e ? (setTimeout(function() {
                                (0, a.getJoinGroupUrl)(i).then(function(t) {
                                    wx.navigateTo({
                                        url: t
                                    });
                                });
                            }, 1e3), setTimeout(function() {
                                s.EventBus.emit("refreshAlbum", o.data.albumId);
                            }, 1e3)) : wx.showToast({
                                title: n,
                                icon: "none"
                            });
                        } else wx.showToast({
                            title: "接口异常，请稍后再试",
                            icon: "none"
                        });
                    });
                });
            });
        },
        toBuy: function() {
            var t = this.data, o = t.campInfo.itemId;
            1 === t.saleType && (this.log_buy_camp(!1), wx.navigateTo({
                url: "/pages/settlement/settlement?albumId=".concat(this.data.albumId, "&isTrainCamp=", !0, "&itemId=").concat(o)
            }));
        },
        log_buy_camp: function() {
            var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], o = this.data.albumId;
            (0, i.genLogger)(17348, "click", {
                currPageId: o,
                item: t ? "训练营领券购买" : "训练营无券购买"
            });
        },
        log_buy_album_in_ios: function() {
            (0, i.genLogger)(33742, "click", {
                currPage: "album"
            });
        }
    }
});