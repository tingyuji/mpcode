var o = require("../../../../@babel/runtime/helpers/objectSpread2"), e = require("../../../../common/utils/time"), t = require("../../utils/index"), n = require("../../../../common/utils/logger"), r = require("../../../../common/utils/index");

Component({
    properties: {
        albumId: {
            type: Number
        },
        userPermission: {
            type: Boolean,
            value: !1,
            observer: function(o, e) {
                o !== e && !0 === o && (0, n.genLogger)(33740, "slipPage", {
                    currPage: "album"
                });
            }
        },
        albumInfo: {
            type: Object
        },
        campInfo: {
            type: Object,
            observer: function(t, n) {
                if (JSON.stringify(t) !== JSON.stringify(n)) {
                    var r = function(t) {
                        return o(o({}, t), {}, {
                            openEndStr: (0, e.dateFmt2)(t.openEnd),
                            openStartStr: (0, e.dateFmt2)(t.openStart),
                            saleEndStr: (0, e.dateFmt2)(t.saleEnd),
                            saleStartStr: (0, e.dateFmt2)(t.saleStart)
                        });
                    }(t);
                    console.log(r, "info-bar======"), t && t.openStart && this.setData({
                        info: r,
                        showOpenBar: Date.now() < r.openEnd
                    });
                }
            }
        },
        couponInfos: {
            type: Object,
            observer: function(o) {
                o.couponInfo && o.couponInfo.list && o.couponInfo.list.length > 0 && (this.discountRate = o.couponInfo.list[0].discountRate, 
                console.log("couponInfos info", o.couponInfo.list[0]), this.setData({
                    hasCoupon: !0,
                    coupon: o.couponInfo.list[0]
                }));
            }
        }
    },
    data: {
        isIos: (0, r.isIos)()
    },
    attached: function() {},
    detached: function() {},
    pageLifetimes: {
        show: function() {}
    },
    methods: {
        joinGroup: function() {
            (0, n.genLogger)(33741, "click", {
                currModule: "专辑页-训练营入群条点击按钮",
                currPage: "album"
            });
            var o = this.data.campInfo.itemId;
            (0, t.getJoinGroupUrl)(o).then(function(o) {
                wx.navigateTo({
                    url: o
                });
            });
        }
    }
});