var e = require("../../@babel/runtime/helpers/defineProperty"), t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../common/apis/album"), i = require("../../common/utils/index"), o = require("../../common/apis/point"), s = require("../../common/utils/myAdapter"), n = require("../../common/utils/storage"), r = require("../../packages/lite-player/event"), u = require("../../common/utils/copyCode"), l = require("../../common/utils/logger"), c = require("../../common/utils/wxScopeData"), m = require("../../common/utils/shareFromApp"), h = require("../../common/utils/navBar"), b = require("../../common/apis/anchor"), g = require("./utils/index"), d = getApp(), f = {
    0: "节目",
    1: "简介",
    2: "评价",
    3: "找相似"
};

Page({
    shareCount: 0,
    data: {
        scrollTop: 0,
        albumInfo: {},
        isSubscribe: !1,
        richIntro: "",
        tabActivity: 0,
        hasScroll: !0,
        userPermission: !1,
        isLogin: null,
        pointInfo: {},
        xmcdn: (0, i.xmcdnImg)(),
        statusBarHeight: ((0, h.isOldVersion)() ? 0 : (0, h.getStatusBarHeight)()) + 44,
        isIos: (0, i.isIos)(),
        recommendAlbums: [],
        comments: {
            list: []
        },
        commentHasMore: !1,
        commentIsLoading: !1,
        couponInfos: {}
    },
    paidLogParams: {},
    commentPageId: 1,
    onShareAppMessage: function(e) {
        var a = d.sq;
        this.shareCount = (0, m.returnShareCount)(a);
        var o = t(t(t({}, this.options), a), {}, {
            count: this.shareCount
        });
        !o.count && delete o.count, !o.from && delete o.from;
        var n = (0, s.getDataset)(e).modal;
        return "sub" === (void 0 === n ? "" : n) && (0, l.clickSubscribeModalShare)(), this.url = (0, 
        i.getUrl)(o, "pages/albumDetail/albumDetail"), this.shareAppMessage.path = "/".concat(this.url), 
        this.shareAppMessage;
    },
    onShareTimeline: function(e) {
        return (0, l.clickShareTimeline)("album"), this.shareAppMessage;
    },
    onLoad: function(e) {
        this.path = "/pages/albumDetail/albumDetail";
        var t = this.options, a = t.albumId, o = void 0 === a ? 4308484 : a, s = t.scene;
        (0, m.toRequestShortUrl)(this.options), s && (o = (0, i.getIdFromScene)(decodeURIComponent(s))), 
        (0, i.setShareMenu)(), this.init(o), this._refresh = this.refreshAlbum.bind(this), 
        this._fix = this.fixPage.bind(this), this.refreshTrackId = "", r.EventBus.on("refreshAlbum", this._refresh), 
        r.EventBus.on("fixAlbumPage", this._fix);
    },
    onUnload: function() {
        r.EventBus.off("refreshAlbum", this._refresh), this.showBubbleTimer && clearTimeout(this.showBubbleTimer), 
        this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), (0, l.genLogger)(12060, "pageExit", t({
            currPageId: this.albumId,
            currPage: "album"
        }, this.paidLogParams));
    },
    onShow: function() {
        this.delayShowBubble();
    },
    onHide: function() {
        this.showBubbleTimer && clearTimeout(this.showBubbleTimer), this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), 
        r.EventBus.emit("closeShareBubble"), r.EventBus.emit("closeFavModal");
    },
    init: function(e) {
        this.albumId = e, this.initLoad(), this.setData({
            albumId: e
        });
    },
    refreshAlbum: function(e, t) {
        console.log("refreshAlbum after purchase===========", e, t), Number(e) === Number(this.albumId) && (t && (this.refreshTrackId = t), 
        this.init(e));
    },
    initLoad: function(e) {
        this.setData({
            isLogin: (0, n.getUid)(),
            isInScene: (0, u.canOpenApp)()
        }), this.delayShowBubble(), this.getAlbumInfo(), this.getPointsInfo(), this.getAlbumCommentList(!0), 
        this.getAlbumStarInfo(), this.queryAlbumRankTag(), console.log("initLoad reloadProgramList", this.refreshTrackId), 
        r.EventBus.emit("reloadProgramList", this.refreshTrackId), this.refreshTrackId = "";
    },
    getAlbumInfo: function() {
        var e = this;
        (0, a.getAlbumInfo)(this.albumId).then(function() {
            var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = a.albumInfo, s = a.isSubscribe, n = a.richIntro, r = a.userPermission, u = a.albumMetaValueInfos, m = void 0 === u ? [] : u, h = a.albumType;
            if (o) {
                3 === h && (e.getCampInfo(), e.getActivityInfo(), e.setData({
                    tabActivity: r ? 0 : 1
                }));
                var b = o.isPaid, d = o.albumPayType, f = o.albumVipPayType, p = o.discountedPrice, I = o.isVipFirst, v = o.campPhraseInfo, T = o.title, P = void 0 === T ? "" : T, A = 1 == f, y = 2 == f;
                e.setData({
                    wxScopeData: (0, c.convertDataToWXScopeData)(o),
                    albumInfo: o,
                    isSubscribe: s,
                    richIntro: n,
                    userPermission: r,
                    campPhraseInfo: v,
                    priceInfo: {
                        isPaid: b,
                        discountedPrice: p,
                        isVIPZX: A,
                        isVIPCT: y,
                        unitPrice: 1 == d ? "喜点/集" : 2 == d ? "喜点" : "",
                        albumPayType: d,
                        albumVipPayType: f,
                        isVipFirst: I
                    }
                }), e.getAnchorName(o.anchor), e.setShareMessage(t(t({}, o), {}, {
                    albumMetaValueInfos: m
                }));
                var S = (0, g.getAlbumLogType)({
                    isPaid: b,
                    isVIPCT: y,
                    isVIPZX: A
                });
                e.paidLogParams = {
                    isPurchased: b && r + "",
                    albumType: S,
                    paidType: 1 == d ? "single" : 2 == d ? "whole" : "",
                    isVip: A + "" || y + ""
                }, e.refreshTrackId = "", (0, l.genLogger)(12059, "pageView", t({
                    currPageId: e.albumId,
                    currPage: "album",
                    albumType: o.type
                }, e.paidLogParams)), (0, i.setNavigationBarTitle)(P);
            }
        }).catch(function(t) {
            console.error(t), e.refreshTrackId = "", wx.redirectTo({
                url: "/pages/error/index?type=content&errorType=".concat(t ? JSON.stringify(t) : "", "&pageType=album&id=").concat(e.albumId)
            });
        });
    },
    getCampInfo: function() {
        var e = this;
        (0, a.getCampExtraInfo)(this.albumId).then(function(t) {
            e.setData({
                campExtraInfo: t
            });
        });
    },
    getActivityInfo: function() {
        var e = this;
        (0, a.getAlbumActivityInfo)(this.albumId).then(function(a) {
            console.log("训练营", a);
            a.couponInfo;
            e.setData({
                couponInfos: t(t({}, a), {}, {
                    albumType: 3
                })
            });
        });
    },
    getAnchorName: function(e) {
        var i = this, o = this.data.albumInfo;
        (0, a.queryAnchorName)(e).then(function(e) {
            i.setData({
                albumInfo: t(t({}, o), e)
            });
        });
    },
    delayShowBubble: function() {
        var e = this;
        this.showBubbleTimer && clearTimeout(this.showBubbleTimer), this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), 
        this.showBubbleTimer = setTimeout(function() {
            r.EventBus.emit("showShareBubble"), e.delayCloseBubble();
        }, 12e4);
    },
    delayCloseBubble: function() {
        this.showBubbleTimer && clearTimeout(this.showBubbleTimer), this.closeBubbleTimer && clearTimeout(this.closeBubbleTimer), 
        this.closeBubbleTimer = setTimeout(function() {
            r.EventBus.emit("closeShareBubble");
        }, 5e3);
    },
    getPointsInfo: function() {
        var e = this;
        this.albumId && (0, o.getAlbumPoints)(this.albumId).then(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.data, i = void 0 === a ? {} : a;
            t.ret;
            e.setData({
                pointInfo: i
            });
        }).catch(function(e) {
            console.error(e);
        });
    },
    getAlbumCommentList: function(t) {
        var i = this, o = this.options.albumId;
        this.setData({
            commentIsLoading: !0
        }), (0, a.queryAlbumCommentList)({
            albumId: o,
            pageId: this.commentPageId
        }).then(function(a) {
            var o = a.comments;
            t ? i.setData({
                comments: o
            }) : i.setData(e({}, "comments.list", i.data.comments.list.concat(o.list))), i.setData({
                commentIsLoading: !1,
                commentHasMore: o.list.length > 0
            });
        }).catch(function(e) {
            i.setData({
                commentIsLoading: !1
            });
        });
    },
    getAlbumStarInfo: function() {
        var e = this, t = this.options.albumId;
        (0, a.queryAlbumStar)({
            albumId: t
        }).then(function(t) {
            var a = t.albumScore, i = t.isAlbumCommentShow;
            e.setData({
                albumScore: a,
                isAlbumCommentShow: i
            });
        });
    },
    queryAlbumRankTag: function() {
        var e = this, t = this.options.albumId;
        (0, a.queryAlbumRankTag)({
            albumId: t
        }).then(function(t) {
            var a = t.positionChange, i = t.aggregateName, o = t.rankCategoryName, s = t.clusterId, n = t.clusterTypeId;
            e.rankTypeId = n, e.rankClusterId = s, e.setData({
                rankPosition: a,
                rankCategory: o,
                rankName: i
            });
        });
    },
    goRank: function() {
        var e = this.rankTypeId, t = this.rankClusterId;
        (0, l.genLogger)(28671, "click", {
            currPage: "album"
        }), wx.navigateTo({
            url: "/pages/rankpage/rankpage?typeId=".concat(e, "&clusterId=").concat(t)
        });
    },
    getRelateRecommendAlbums: function() {
        var e = this;
        this.data.recommendAlbums.length > 0 || (0, a.queryRelateRecommendAlbums)({
            id: this.albumId
        }).then(function(t) {
            var a = t.albumInfo;
            e.setData({
                recommendAlbums: a
            });
        });
    },
    followAnchor: function() {
        var t = this, a = this.data.albumInfo, i = a.isFollow, o = a.anchor;
        (i ? b.cancelFollow : b.setFollow)({
            followingUid: o
        }).then(function() {
            wx.showToast({
                title: i ? "成功取消关注" : "成功关注",
                icon: "success"
            }), t.setData(e({}, "albumInfo.isFollow", !i));
        });
    },
    toRecommendAlbum: function(e) {
        var t = (0, s.getDataset)(e).id;
        t && ((0, l.genLogger)(26321, "click", {
            currPageId: this.albumId,
            currPage: "album"
        }), wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(t)
        }));
    },
    setShareMessage: function(e) {
        var a = this;
        this.shareAppMessage = {
            title: e.title,
            desc: e.subTitle,
            path: "/".concat(this.url),
            imageUrl: (0, i.getOriginImgUrl)(e.cover),
            templateId: "af8063b6g711eeib3g",
            success: function() {
                console.log("转发发布器已调起，并不意味着用户转发成功，微头条不提供这个时机的回调");
            },
            fail: function() {
                console.log("转发发布器调起失败");
            }
        }, (0, i.drawSharePic)("album-share", t({}, e), function(e) {
            a.shareAppMessage.imageUrl = e;
        });
    },
    onSubscribeChange: function(e) {
        var a = e.detail.isSubscribe, o = this.data, s = o.albumInfo.oldSubscribeCount, n = o.albumInfo;
        this.setData({
            isSubscribe: a,
            albumInfo: t(t({}, n), {}, {
                subscribeCount: a ? (0, i.parseNum)(++s) : (0, i.parseNum)(--s)
            })
        });
    },
    tabChange: function(e) {
        var t = (0, s.getDataset)(e), a = t.index, i = t.type;
        if (a) {
            var o = Number(a);
            o !== this.data.tabActivity && (3 === o && this.getRelateRecommendAlbums(), this.setData({
                tabActivity: o,
                showOptionList: !1,
                hasScroll: !0,
                scrollTop: 0
            }), "score" === i ? this.log_click_score() : this.log_toggle_tab(o));
        }
    },
    loadMore: (0, i.throttle)(function() {
        var e = this.data.tabActivity;
        0 === e && r.EventBus.emit("loadMore"), 2 === e && (this.commentPageId++, this.getAlbumCommentList(), 
        console.log("评价"));
    }),
    panelChange: function(e) {
        e.hasOwnProperty("detail") && (e = e.detail), this.setData({
            hasScroll: e.detail || e
        });
    },
    share: function() {
        r.EventBus.emit("showSharePanel", "album");
    },
    toAnchor: function() {
        var e = this.data.albumInfo;
        (0, i.goPage)({
            url: "/pages/announcer/announcer?id=".concat(e.anchor)
        });
    },
    joinTrainGroup: function() {
        wx.navigateTo({
            url: "/pages/wxgroup/wxgroup"
        });
    },
    fixPage: function(e) {
        this.setData({
            hasScroll: !e
        });
    },
    copyPagePath: function() {
        (0, l.genLogger)(27055, "longPress", {
            currPageId: this.albumId
        }), (0, i.copyPagePath)(this.albumId);
    },
    onScroll: (0, i.throttle)(function() {
        var e = this, t = wx.createSelectorQuery();
        t.select(".subscribeWrapper").boundingClientRect(), t.exec(function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            console.log("res", t);
            var a = t[0] || {};
            e.setData({
                showBottomShare: a.top < 0,
                showBottomOpenApp: !!(0, u.canOpenApp)() && a.top < 0
            });
        });
    }, 500, 500),
    log_share_wechat: function() {
        (0, l.genLogger)(17098, "click", {
            currPageId: this.albumId
        });
    },
    log_share_wechat_bottom: function() {
        (0, l.genLogger)(17349, "click", {
            currPageId: this.albumId
        });
    },
    log_toggle_tab: function(e) {
        (0, l.genLogger)(17100, "click", {
            item: f[e]
        });
    },
    log_click_score: function() {
        (0, l.genLogger)(28670, "click", {});
    },
    log_subscribe: function(e) {
        (0, l.genLogger)(17097, "click", {
            item: e,
            currPageId: this.albumId
        });
    }
});