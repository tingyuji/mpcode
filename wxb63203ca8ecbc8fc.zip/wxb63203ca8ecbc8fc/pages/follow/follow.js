var a = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/apis/follow"), t = require("../../common/utils/index"), n = require("../../common/utils/myAdapter"), o = require("../../common/apis/anchor");

Page({
    data: {
        type: "fans",
        fans: [],
        page: 1,
        pageSize: 10,
        total: 0,
        uid: ""
    },
    onLoad: function(a) {
        var e = this, t = a.uid, n = a.type;
        this.setData({
            uid: t,
            type: n
        }, function() {
            e.queryFans();
        }), wx.setNavigationBarTitle({
            title: "fans" == n ? "粉丝" : "关注主播"
        });
    },
    queryFans: function() {
        var t = this, n = this.data, o = n.page, i = n.pageSize, s = n.fans, r = n.type, l = n.uid, u = l ? {
            page: o,
            pageSize: i,
            uid: l
        } : {
            page: o,
            pageSize: i
        }, c = "fans" == r ? e.queryUserFans : e.queryUserFollowings;
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), c(u).then(function(e) {
            wx.hideToast(), t.setData(a(a({}, e), {}, {
                fans: [].concat(s, e.fansList)
            }));
        });
    },
    loadMoreFans: function() {
        console.log("到底了"), (0, t.debounce)(this.loadMore.bind(this), 200)();
    },
    loadMore: function() {
        var a = this;
        console.log("到底了啊");
        var e = this.data, t = e.page, n = e.total, o = e.pageSize;
        n - e.fans.length > 0 && n > t * o && this.setData({
            page: t++
        }, function() {
            return a.getMoreFans();
        });
    },
    getMoreFans: function() {
        var a = this, e = this.data.page;
        this.setData({
            page: ++e
        }, function() {
            return a.queryFans();
        });
    },
    followUser: function(a) {
        var e = this, t = this.data.fans, i = (0, n.getDataset)(a), s = i.id, r = i.follow, l = i.index, u = r ? o.cancelFollow : o.setFollow, c = t.slice();
        u({
            followingUid: s
        }).then(function() {
            wx.showToast({
                title: r ? "成功取消关注" : "成功关注",
                icon: "success"
            });
            var a = c[l].isFollow;
            c[l].isFollow = !a, e.setData({
                fans: c
            });
        });
    },
    toAnchor: function(a) {
        var e = (a.currentTarget.dataset || (0, n.getDataset)(a)).id;
        e && (0, t.goPage)({
            url: "/pages/announcer/announcer?id=".concat(e)
        });
    }
});