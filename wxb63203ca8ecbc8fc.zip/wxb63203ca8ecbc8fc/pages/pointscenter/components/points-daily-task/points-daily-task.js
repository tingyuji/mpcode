var s = require("../../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../../common/utils/storage"), i = require("../../../../common/utils/myAdapter"), e = require("../../../../common/utils/index"), a = require("../../../../common/apis/pointscenter"), n = require("../../../../common/utils/logger"), o = require("../../../../packages/lite-player/event"), r = require("../../../../common/utils/wxAdVideo"), d = [ {}, {}, {} ], c = null, u = e.isDevelopment ? {
    video: 15,
    signin: 16,
    follow: 17
} : {
    video: 21,
    signin: 20,
    follow: 22
}, g = function(s) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none";
    wx.showToast({
        title: s,
        icon: t
    });
};

Component({
    properties: {
        isFromShare: {
            type: Boolean,
            value: !1,
            observer: function(s) {
                s && (this.data.isLogin && this.assistFriendTask());
            }
        },
        assistInfos: {
            type: Object,
            value: {}
        },
        isLogin: {
            type: Boolean,
            value: !1,
            observer: function(s) {
                s && this.init();
            }
        },
        signinText: {
            type: String,
            value: "签到"
        }
    },
    data: {
        friends: [],
        taskList: [],
        isVideoEnded: !1,
        shareInfo: {},
        signinText: "",
        assistTask: {},
        assistFriendList: [ {}, {}, {} ],
        showWxAd: (0, e.canIUse)("createRewardedVideoAd"),
        assistersList: [],
        helpStatus: 0,
        noMoreAssistTask: !1,
        isLogin: !1,
        xmcdnImg: (0, e.xmcdnImg)(),
        signinTask: {},
        defaultAvatar: "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist/wx_images/images/login-avatar.png",
        bannerImg: (0, e.image2Url)("storages/c842-audiofreehighqps/38/23/CMCoOScDyewGAACWngB4ZAu-.jpg", {
            name: "large_pop"
        }),
        showTuia: !0,
        bannerWxId: e.pointscenterVideoAdId
    },
    attached: function() {
        this.init(), this._getAssist = this.getAssistTaskKey.bind(this), o.EventBus.on("getAssisTaskInfos", this._getAssist);
    },
    detached: function() {
        o.EventBus.off("getAssisTaskInfos", this._getAssist);
    },
    methods: {
        init: function() {
            var s = this.data, t = s.showWxAd;
            s.isLogin && (this.getTaskInfos(), this.getAssistTaskKey(), t && this.initWxAdVideo());
        },
        doTask: function(e) {
            if ((0, t.checkLogin)()) {
                var a = (0, i.getDataset)(e), n = a.id, o = a.status, r = a.step, d = a.text;
                if (2 !== o) {
                    if (this.clickTaskLogger(n, d), 1 === o) {
                        var c = {
                            taskId: n
                        };
                        return 0 !== r && (c = s(s({}, c), {}, {
                            stepNo: r
                        })), this.drawAward(c);
                    }
                    if (n === u.video) {
                        if (!this.data.showWxAd) return g("您当前微信版本暂不支持，请升级后重试");
                        this.watchWxAdVideo();
                    }
                }
            }
        },
        getTaskInfos: function() {
            var s = this;
            (0, a.queryTasks)({
                aid: 6
            }).then(function(t) {
                console.log(t, "------日常任务-------");
                var i = t.find(function(s) {
                    return 0 === s.taskType;
                });
                s.getSigninAward(i), s.setData({
                    taskList: t,
                    signinTask: i
                });
            });
        },
        getAssistTaskKey: function() {
            var t = this;
            (0, a.queryBasicShareInfo)({
                aid: 38
            }).then(function(i) {
                i.isParticipate ? function(s) {
                    var i = s.key;
                    t.assistTaskKey = i, t.getAssistTaskInfos(i);
                }(i) : (0, a.participateShareActicity)({
                    aid: 38
                }).then(function() {
                    var i = t.filterAssistTaskInfos([]);
                    t.setData(s({}, i));
                });
            });
        },
        getAssistTaskInfos: function(t) {
            var i = this;
            (0, a.queryShareRecords)({
                aid: 38,
                key: t
            }).then(function(t) {
                var e = i.filterAssistTaskInfos(t);
                i.setData(s({}, e));
            });
        },
        filterAssistTaskInfos: function(s) {
            console.log(s, "-------助力任务列表-------");
            var t = s.findIndex(function(s) {
                return s.award && 0 === s.sharerStatus;
            });
            if (t < 0 && 15 === s.length) return this.setData({
                noMoreAssistTask: !0
            });
            var i = this.getCurrentAssistTask(t, s);
            console.log(i, "------当前助力任务------");
            var e = t < 0 ? s.length % 3 : 3, a = d.map(function(s, t) {
                return s.logo = i[t] && i[t].logo, s.assistId = i[t] && i[t].assistId, s;
            });
            console.log(a, "-------当前用户助力列表------");
            var n = [];
            return s.map(function(s) {
                n = n.concat([ s ]);
            }), console.log(n, "-------所有助力用户列表-------"), {
                assistTask: {
                    aid: 38,
                    key: this.assistTaskKey,
                    condition: 3,
                    progress: e,
                    status: e - 3 == 0 ? 1 : 0
                },
                assistFriendList: a,
                assistersList: n
            };
        },
        getCurrentAssistTask: function(s, t) {
            var i = [];
            if (s < 0) {
                var e = Math.floor(t.length / 3);
                i = t.slice(3 * e, t.length);
            } else {
                var a = (s + 1) / 3;
                i = t.slice(3 * (a - 1), 3 * a), this.assistTaskStep = s + 1;
            }
            return i;
        },
        getSigninBtnText: function() {
            var s = this.data, t = s.isFromShare, i = !s.isLogin && t ? "签到助力" : "签到";
            this.setData({
                signinText: i
            });
        },
        updateProgress: function(s) {
            var t = this;
            return (0, a.updateTaskProgress)(s).then(function(i) {
                return 0 === i.status && (console.log("任务刷新成功", s), t.getTaskInfos(), !0);
            });
        },
        refreshTasks: function() {
            this.getTaskInfos(), this.getAssistTaskKey(), this.triggerEvent("getUserPoints", {});
        },
        drawAward: function(s) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            (0, a.drawTaskAward)(s).then(function(s) {
                if (0 === s.status) {
                    if (t.refreshTasks(), i) return (0, n.signinSuccessToast)(), g("签到成功", "success");
                    t.triggerEvent("showModal", {
                        taskPoint: s.awardCount
                    });
                } else g(i ? "签到失败" : "领取失败");
            }).catch(function() {
                g(i ? "签到失败" : "领取失败");
            });
        },
        initWxAdVideo: function() {
            var s = this, t = this;
            c = wx.createRewardedVideoAd({
                adUnitId: "adunit-39abca9ecdb1711a"
            }), (0, r.initAdVideo)(c, function(i) {
                i && i.isEnded && s.updateProgress(u.video).then(function(s) {
                    s && t.getTaskInfos();
                });
            });
        },
        watchWxAdVideo: function() {
            (0, r.watchAdVideo)(c);
        },
        toggleHelpModal: function() {
            var s = this.data.helpStatus;
            this.triggerEvent("toggleHelpModal", {
                helpStatus: s
            });
        },
        getSigninAward: function(s) {
            1 === s.status && this.drawAward({
                taskId: u.signin
            }, !0);
        },
        assistFriendTask: function() {
            var s = this.data, t = s.assistInfos.key;
            s.isLogin && (0, a.assistShareTask)({
                key: t,
                aid: 38
            }).then(function(s) {
                var t = s.code, i = s.msg, e = t;
                "-1" === t && (e = 1), "-2" !== t && "-3" !== t || (e = -3), -3 === t ? g("助力失败") : o.EventBus.emit("showHelpModalEvent", {
                    helpStatus: e,
                    msg: i
                });
            });
        },
        drawAssistAward: function() {
            var s = this;
            1 === this.data.assistTask.status && this.assistTaskStep && ((0, n.clickDrawAssistAward)(), 
            (0, a.drawAssisAward)({
                aid: 38,
                key: this.assistTaskKey,
                step: this.assistTaskStep
            }).then(function(t) {
                0 === t.data.code ? (s.refreshTasks(), s.triggerEvent("showModal", {
                    taskPoint: 200
                })) : g("领取失败");
            }).catch(function() {
                g("领取失败");
            }));
        },
        showFriendsPanel: function() {
            var s = this.data.assistersList;
            this.triggerEvent("showFriendsPanel", {
                list: s
            });
        },
        toTuia: function() {
            wx.navigateTo({
                url: "/pages/webview/index?url=".concat("https://engine.zadtc.com/index/activity&appKey=4SLyCq26sMmaEWDSMne8e65G6J5R&adslotId=375197", "&encode=", !1)
            });
        },
        clickTaskLogger: function(s, t) {
            s === u.video && (0, n.clickWatchVideo)(t), s === u.signin && (0, n.clickSignin)(t), 
            s === u.follow && (0, n.clickGzhTask)(t);
        },
        onWXAdError: function() {
            this.setData({
                bannerWxId: ""
            });
        },
        checkLogin: t.checkLogin
    }
});