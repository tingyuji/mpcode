var t = require("../../../../common/utils/index");

Component({
    properties: {
        modalVisible: {
            type: Boolean,
            value: !1
        },
        signinDays: {
            type: Number,
            value: 0
        },
        modalType: {
            type: String,
            value: "signin"
        },
        starPoints: {
            type: Number,
            value: 0
        },
        taskPoint: {
            type: Number,
            value: 0
        }
    },
    data: {
        signinPoints: [ 0, 100, 120, 150, 180, 230, 300 ],
        xmcdnImg: (0, t.xmcdnImg)()
    },
    attached: function() {},
    detached: function() {},
    methods: {
        onTap: function() {
            this.setData({});
        },
        close: function() {
            "star" === this.data.modalType && (this.triggerEvent("getStarInfos", {}), this.triggerEvent("getUserPoints", {})), 
            this.triggerEvent("toggleModal", {});
        }
    }
});