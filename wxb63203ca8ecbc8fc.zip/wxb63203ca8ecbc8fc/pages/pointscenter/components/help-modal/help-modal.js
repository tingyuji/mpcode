var e = require("../../../../common/utils/logger"), t = require("../../../../common/utils/myAdapter"), a = require("../../../../packages/lite-player/event"), l = {
    1: "好友任务已完成，无需助力",
    0: "助力成功！",
    "-1": "助力失败，请稍后重试",
    "-3": "没有助力机会了呢"
}, i = [ "1", "0", "-1", "-3" ];

Component({
    properties: {
        modalVisible: {
            type: Boolean,
            value: !1
        },
        helpUserInfo: {
            type: Object,
            value: {}
        },
        helpStatus: {
            type: Number,
            value: 0,
            observer: function(e) {
                var t = "";
                t = i.indexOf(e + "") < 0 ? this.data.helpMsg : l[e + ""], this.setData({
                    helpTitle: t
                });
            }
        },
        taskPoint: {
            type: Number,
            value: 0
        },
        paidAlbums: {
            type: Array,
            value: []
        },
        helpMsg: String
    },
    data: {
        type: 0,
        albums: [],
        helpTitle: "助力成功！"
    },
    attached: function() {},
    detached: function() {},
    methods: {
        close: function() {
            this.triggerEvent("toggleModal"), a.EventBus.emit("getAssisTaskInfos");
        },
        closeHelpModal: function() {
            var t = this.data.helpStatus;
            (0, e.clickHelpBtn)(0 == t ? "成功" : "失败"), this.triggerEvent("toPaid", {}), this.close();
        },
        onClickHelp: function() {
            this.setData({
                type: 1
            });
        },
        toAlbum: function(a) {
            var l = (0, t.getDataset)(a).id, i = this.data.helpStatus;
            (0, e.clickHelpAlbum)(0 == i ? "成功" : "失败", l), wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(l)
            });
        }
    }
});