var t = require("../../../../common/utils/storage"), e = require("../../../../common/apis/pointscenter");

Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        showClose: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showTip: !1
    },
    attached: function() {
        (0, t.getUid)() && this.getMigrateData() && this.isAssistMigrateUser();
    },
    detached: function() {},
    methods: {
        isAssistMigrateUser: function() {
            var i = this, s = (0, t.getUid)();
            (0, e.getAssistMigrateUsers)().then(function(t) {
                console.log("------getAssistMigrateUsers-------");
                for (var e = t.length, r = 0; r < e; r++) {
                    var o = t[r] && t[r].uids && t[r].uids.split(",");
                    if (o.length && o.length > 0 && o.findIndex(function(t) {
                        return String(t) === String(s);
                    }) > -1) {
                        i.setMigrateShow(!0);
                        break;
                    }
                    i.setMigrateShow(!1);
                }
            });
        },
        getMigrateData: function() {
            var t = this.getShowStatus();
            return "boolean" != typeof t || (this.setData({
                showTip: t
            }), !1);
        },
        setMigrateShow: function(e) {
            var i = (0, t.getUid)();
            this.setData({
                showTip: e
            }), (0, t.set)("ASSIST_MIGRATE_SHOW" + i, e);
        },
        closeTip: function() {
            this.setMigrateShow(!1);
        },
        getShowStatus: function() {
            var e = "ASSIST_MIGRATE_SHOW" + (0, t.getUid)();
            return (0, t.get)(e);
        }
    }
});