var e = require("../../../../common/apis/pointscenter");

Component({
    properties: {
        showPanel: {
            type: Boolean,
            value: !1
        },
        friendsList: {
            type: Array,
            value: []
        }
    },
    data: {
        rules: []
    },
    attached: function() {
        var t = this;
        (0, e.queryRules)().then(function(e) {
            t.setData({
                rules: e
            });
        });
    },
    detached: function() {},
    methods: {
        togglePanel: function() {
            this.triggerEvent("toggleRules", {});
        }
    }
});