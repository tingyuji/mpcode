var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/utils/myAdapter"), s = require("../../common/utils/storage"), i = require("../../common/utils/index"), a = require("../../common/apis/pointscenter"), o = require("../../common/apis/paidpage"), n = require("../../common/apis/points"), r = require("../../common/utils/logger"), u = require("../../packages/lite-player/event"), l = require("../../common/utils/shareFromApp"), h = require("../../common/utils/copyCode"), c = {
    unlock: "/pages/pointsunlock/pointsunlock",
    detail: "/pages/pointsdetail/pointsdetail"
}, d = "assisttask", g = getApp();

Page({
    data: {
        showMenu: !1,
        albums: [],
        showRules: !1,
        isLogin: !1,
        isSignin: !1,
        points: 0,
        showModal: !1,
        modalType: "signin",
        starInfo: {
            isExchanged: !0
        },
        shareInfo: {},
        showHelpModal: !1,
        currentTaskPoint: 0,
        isFromShare: !1,
        assistInfos: {},
        helpStatus: 0,
        assistFriendList: [],
        paidAlbums: [],
        migrationTips: {},
        signinText: "签到",
        isIos: (0, i.isIos)(),
        bottomGridAdId: i.pointscenetrAdId
    },
    onLoad: function(t) {
        this._showModal = this.toggleHelpModal.bind(this), u.EventBus.on("showHelpModalEvent", this._showModal), 
        this.setData({
            isLogin: (0, s.isLogin)()
        }), this.getPaidAlbums();
        var e = t.sourceType;
        if ((0, s.isLogin)()) this.setTaskParams(t), this.getMigrationTips(), this.getUserPoints(), 
        this.getShareInfos(), this.getStarInfos(); else {
            if (!(e && e === d || (0, s.checkLogin)())) return;
            this.setData({
                signinText: "签到助力"
            });
        }
    },
    onShow: function() {},
    onUnload: function() {
        u.EventBus.off("showHelpModalEvent", this._showModal);
    },
    onShareAppMessage: function(s) {
        var a = this.data.shareInfo, o = (0, e.getDataset)(s).shareinfo, n = o.aid, u = o.key;
        (0, r.clickInviteFriend)();
        var h = g.sq;
        this.shareCount = (0, l.returnShareCount)(h);
        var c = t(t({
            aid: n,
            key: u,
            sourceType: d
        }, h), {}, {
            count: this.shareCount
        });
        !c.count && delete c.count, !c.from && delete c.from;
        var p = (0, i.getUrl)(c, "pages/pointscenter/pointscenter");
        return {
            path: "/".concat(p),
            title: a.shareTitle,
            imageUrl: a.shareImage
        };
    },
    getStarInfos: function() {
        var t = this;
        (0, a.queryStarInfo)().then(function(e) {
            t.setData({
                starInfo: e
            });
        });
    },
    getUserPoints: function() {
        var t = this;
        (0, n.queryPoints)().then(function(e) {
            t.setData({
                points: e.point
            });
        });
    },
    getMigrationTips: function() {
        var t = this;
        (0, n.queryMigrationTips)().then(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            t.setData({
                migrationTips: e[0]
            });
        });
    },
    setTaskParams: function(t) {
        var e = this, s = t.sourceType, i = t.aid, a = t.key;
        if (i && a && s === d) {
            var o = {
                aid: i,
                key: a
            };
            this.setData({
                assistInfos: o
            }, function() {
                e.setData({
                    isFromShare: !0
                });
            });
        }
    },
    getShareInfos: function() {
        var t = this;
        (0, a.queryShareInfos)().then(function(e) {
            t.setData({
                shareInfo: e[0]
            });
        });
    },
    getPaidAlbums: function() {
        var t = this;
        (0, o.queryPageInfo)().then(function(e) {
            var s = e.find(function(t) {
                return "rank" === t.moduleType;
            });
            console.log(s, "------精品页排行榜-------"), t.setData({
                albums: s && s.moduleInfo,
                paidAlbums: s && s.moduleInfo.slice(0, 3)
            });
        });
    },
    clickMenu: function() {
        var t = this.data.showMenu;
        this.setData({
            showMenu: !t
        });
    },
    clickMenuItem: function(t) {
        if (this.setData({
            showMenu: !1
        }), (0, s.checkLogin)()) {
            var i = (0, e.getDataset)(t).type;
            if ("rules" === i) return this.setData({
                assistFriendList: []
            }), this.toggleRules();
            wx.navigateTo({
                url: c[i]
            });
        }
    },
    toggleRules: function() {
        var t = this.data.showRules;
        this.setData({
            showRules: !t
        });
    },
    toggleModal: function() {
        var t = this.data.showModal;
        this.setData({
            showModal: !t
        });
    },
    showModals: function(t) {
        var s = this, i = (0, e.getDataset)(t).type;
        this.setData({
            modalType: i
        }, function() {
            s.toggleModal();
        });
    },
    showTaskModal: function(t) {
        var e = this;
        this.setData({
            currentTaskPoint: t.detail.taskPoint
        }), this.setData({
            modalType: "task"
        }, function() {
            e.toggleModal();
        });
    },
    toAlbum: function(t) {
        var s = (0, e.getDataset)(t).id;
        (0, r.clickRecommandAlbum)(s), wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(s)
        });
    },
    seeMoreAlbum: function() {
        (0, r.clickPointSeeMore)(), this.toPaid();
    },
    toPaid: function() {
        (0, i.safeSwitchTab)({
            url: "/pages/paid/paid"
        });
    },
    showPaidTip: function() {
        setTimeout(function() {
            (0, h.copyCodeByEvent)("jfzx");
        }, 500), wx.showToast({
            title: "小程序暂不支持",
            icon: "none"
        });
    },
    exchangeStars: function(t) {
        var e = this;
        (0, s.checkLogin)() && (0, a.exchangeStar)().then(function() {
            e.showModals(t);
        });
    },
    toggleHelpModal: function(t) {
        var e = this, s = this.data.showHelpModal;
        this.setData({
            helpStatus: t.helpStatus,
            helpMsg: t.msg
        }, function() {
            (0, r.helpModalShow)(0 == t.helpStatus ? "成功" : "失败"), e.setData({
                showHelpModal: !s
            });
        });
    },
    showInvitedPanel: function(t) {
        var e = this;
        this.setData({
            assistFriendList: t.detail.list
        }, function() {
            e.toggleRules();
        });
    },
    onAdError: function() {
        this.setData({
            bottomGridAdId: ""
        });
    }
});