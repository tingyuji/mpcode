var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/paid"), i = require("../../common/apis/vipChannel"), a = require("../../common/utils/index"), n = require("../../common/utils/logger"), o = require("../../common/utils/tabbar"), s = require("../../packages/lite-player/event"), r = require("../../common/utils/time");

Page({
    data: {
        rankList: {},
        userName: "欢迎你，新朋友",
        isLogin: !1,
        tabList: [],
        activeTab: "youshengshu",
        tabContent: [],
        isIos: (0, a.isIos)(),
        imgAddress: a.imgAddress,
        hasMore: !0,
        isLoading: !1,
        vipSignInfo: {},
        autoRenewModalVisible: !1,
        nextChargeTime: "",
        userInfo: {}
    },
    onLoad: function() {
        this.initUserInfo(), this.getVipSignInfo(), this.initRankList(), this.getCategories(), 
        this.getCategoryAlbum(this.data.activeTab), this.pageNum = 1;
    },
    onShow: function() {
        (0, a.isLogin)() || this.setData({
            isLogin: !1,
            userInfo: {
                headLogo: a.defaultUserImg
            }
        }), (0, a.isLogin)() && (this.initUserInfo(), this.getVipSignInfo()), (0, o.setTabBar)(this);
    },
    onReachBottom: (0, a.debounce)(function() {
        this.loadMore();
    }, 200),
    initUserInfo: function() {
        var t = this;
        (0, i.getUserInfo)().then(function(i) {
            var n = !1;
            i && (n = !0), t.setData({
                userInfo: e(e({}, i), {}, {
                    headLogo: i ? (0, a.image2Url)(i.headLogo) : a.defaultUserImg
                }),
                isLogin: n
            }), n && t.initVipInfo();
        });
    },
    getVipSignInfo: function() {
        var e = this;
        if ((0, a.isLogin)()) {
            var i = (0, a.getUid)();
            i && (0, t.getVipSubscribeStatus)(i).then(function(t) {
                var i = t.nextChargeTime, a = t.statusId;
                e.setData({
                    nextChargeTime: 1 !== a ? "" : i ? (0, r.dateFmt2)(i, !0) : ""
                });
            });
        }
    },
    initVipInfo: function() {
        var e = this;
        (0, t.queryVipBasicInfo)().then(function(t) {
            var i = (t || {}).data, a = (void 0 === i ? {} : i).userVipInfoVo, n = void 0 === a ? {} : a;
            e.setData({
                userName: n.userNickName,
                expireDate: n.expireDate,
                isVipNow: n.expireDays > 0 && 2 == n.vipStatus
            });
        });
    },
    initRankList: function() {
        var e = this;
        (0, i.queryPaidRankList)().then(function(t) {
            e.setData({
                rankList: {
                    moduleInfo: t,
                    moduleType: "rank",
                    linkForMore: "/pages/rankpage/rankpage?typeId=13&clusterId=66"
                }
            });
        });
    },
    getCategories: function() {
        var e = this;
        (0, i.queryPaidCategory)().then(function(t) {
            e.setData({
                tabList: t
            });
        });
    },
    switchCategory: function(e) {
        var t = (0, a.getDataset)(e), i = t.code, o = t.name;
        i && i != this.data.activeTab && (this.setData({
            activeTab: i,
            hasMore: !0
        }), this.pageNum = 1, this.getCategoryAlbum(i), (0, n.genLogger)(28694, "click", {
            currPage: "VIPpage",
            item: o
        }));
    },
    getCategoryAlbum: function(e) {
        var t = this;
        (0, i.queryVipCategoryPageAlbum)({
            page: 1,
            category: e
        }).then(function(e) {
            var i = e.albums, a = void 0 === i ? [] : i;
            t.originAlbums = a, t.totalPage = Math.ceil(a.length / 10), t.refreshTabContent(t.pageNum, !0), 
            t.pageNum++;
        });
    },
    refreshTabContent: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], i = this.data.tabContent, a = this.originAlbums.slice(10 * (e - 1), 10 * e);
        console.log(a), this.setData({
            tabContent: t ? a : [].concat(i, a),
            isLoading: !1
        });
    },
    buyVip: function() {
        (0, a.checkLogin)() && ((0, n.genLogger)(26316, "click", {
            currPage: "VIPpage"
        }), s.EventBus.emit("openGModal", {
            vipModal: {
                visible: !0
            }
        }));
    },
    toAlbum: function(e) {
        var t = (0, a.getDataset)(e).id;
        t && ((0, n.genLogger)(26319, "click", {
            currPage: "VIPpage"
        }), wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(t)
        }));
    },
    loadMore: function() {
        this.pageNum > this.totalPage ? this.setData({
            hasMore: !1
        }) : (this.setData({
            isLoading: !0
        }), this.refreshTabContent(this.pageNum), this.pageNum++, wx.hideToast());
    },
    checkMorePrivilege: function() {
        wx.navigateTo({
            url: "/subpackage/pages/viprights/index"
        }), (0, n.genLogger)(28695, "click", {
            currPage: "VIPpage"
        });
    },
    toggleAutoRenewModal: function() {
        var e = this.data.autoRenewModalVisible;
        this.setData({
            autoRenewModalVisible: !e
        });
    }
});