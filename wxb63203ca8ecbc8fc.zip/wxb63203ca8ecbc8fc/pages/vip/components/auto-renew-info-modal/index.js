Component({
    properties: {
        visible: Boolean,
        chargeTime: String
    },
    data: {},
    attached: function() {},
    detached: function() {},
    pageLifetimes: {
        hide: function() {}
    },
    methods: {
        closeModal: function() {
            this.triggerEvent("close");
        }
    }
});