Page({
    data: {
        queryParamsStr: "{}"
    },
    onLoad: function(n) {
        this.setData({
            queryParamsStr: JSON.stringify(n)
        });
    },
    onReady: function(n) {
        console.log("bbb", n);
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});