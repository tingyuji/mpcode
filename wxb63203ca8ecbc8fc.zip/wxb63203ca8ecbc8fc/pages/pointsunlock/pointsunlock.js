var t = require("../../common/utils/myAdapter"), r = require("../../common/apis/unlock");

Page({
    data: {
        orderList: [ "最新解锁", "最早解锁" ],
        order: 1,
        showOrder: !1,
        list: []
    },
    onLoad: function() {
        this.queryUnlockList();
    },
    toggleOrderMenu: function() {
        var t = this.data.showOrder;
        this.setData({
            showOrder: !t
        });
    },
    queryUnlockList: function() {
        var t = this, e = this.data.order;
        (0, r.queryUnlock)({
            order: e
        }).then(function(r) {
            var e = (r || {}).unlockInfos;
            t.setData({
                list: e
            });
        });
    },
    onClickItem: function(r) {
        var e = this, o = (0, t.getDataset)(r).order, i = this.data.order;
        this.toggleOrderMenu(), i != o && this.setData({
            order: o
        }, function() {
            e.queryUnlockList();
        });
    }
});