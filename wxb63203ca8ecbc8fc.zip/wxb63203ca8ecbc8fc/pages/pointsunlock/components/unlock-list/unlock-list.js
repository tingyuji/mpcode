var e = require("../../../../common/apis/unlock");

Component({
    properties: {
        list: {
            type: Array,
            value: []
        },
        hasMore: {
            type: Boolean,
            value: !1
        },
        order: {
            type: Number,
            value: 1,
            observer: function() {
                this.setData({
                    page: 1
                });
            }
        },
        albumInfo: {
            type: Object,
            value: {}
        }
    },
    data: {
        pageSize: 10,
        offset: 2,
        page: 1
    },
    attached: function() {},
    detached: function() {},
    methods: {
        getMoreTracks: function() {
            var a = this, t = this.data, s = t.albumInfo.id, o = t.order, r = t.page, i = t.pageSize, n = t.offset, c = t.list;
            if (!t.hasMore) return this.collapseList();
            var p = {
                albumId: s,
                order: o,
                offset: n,
                page: r,
                pageSize: i
            };
            (0, e.queryTracks)(p).then(function(e) {
                var t = e || {}, s = t.page, o = t.hasMore, r = t.trackInfos;
                a.setData({
                    hasMore: o,
                    list: [].concat(c, r),
                    page: s + 1
                });
            });
        },
        collapseList: function() {
            var e = this.data.list.slice();
            e.splice(2), this.setData({
                page: 1,
                list: e,
                hasMore: !0
            });
        }
    }
});