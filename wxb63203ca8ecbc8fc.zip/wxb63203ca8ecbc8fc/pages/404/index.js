var e = require("../../common/apis/404"), o = require("../../common/utils/myAdapter"), t = require("../../common/utils/index"), a = require("../../common/utils/logger");

Page({
    data: {
        recommendInfoList: [],
        categoryCode: "",
        isIPhoneX: (0, t.isIPhoneX)()
    },
    onLoad: function() {
        var e = this.options, o = e.ptype, t = void 0 === o ? "" : o, a = e.id, i = void 0 === a ? "" : a;
        this.getRecommendData({
            ptype: t,
            id: i
        });
    },
    getRecommendData: function(o) {
        var t = this, a = o.ptype, i = o.id;
        (0, e.queryRecommend)({
            ptype: a,
            id: i
        }).then(function(e) {
            var o = e.list, a = e.categoryCode;
            t.setData({
                recommendInfoList: o,
                categoryCode: a
            });
        }).catch(function(e) {
            console.log("getRecommendData error", e), t.setData({
                recommendInfoList: [],
                categoryCode: ""
            });
        });
    },
    toAlbum: function(e) {
        var t = (0, o.getDataset)(e).id;
        t && ((0, a.genLogger)(27127, "click"), wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(t)
        }));
    },
    log_click_more: function(e) {
        var t = (0, o.getDataset)(e).code;
        (0, a.genLoggerClick)(27128, t, {
            currPage: "下架错误页"
        });
    }
});