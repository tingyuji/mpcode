var e = require("../../common/utils/index"), t = require("../../common/utils/index.js"), r = require("../../common/utils/storage"), s = require("../../common/apis/searchapi"), a = require("../../common/utils/logger");

Page({
    data: {
        hotTagList: [],
        searchKeys: [],
        cateList: [],
        categoryId: -1,
        placeholder: "搜索",
        focus: !1,
        showSelector: !1,
        albumResultList: [],
        queryResultList: [],
        value: "",
        showHistory: !1,
        showRecommend: !1,
        recommendList: [],
        innerTop: -100
    },
    onLoad: function(e) {
        var t = e.source, r = "hotSearch" !== (void 0 === t ? "normal" : t);
        this.setData({
            showHistory: r,
            showRecommend: !0
        }), this.getHotWordCategory(), this.getRecommendList();
    },
    onReady: function() {
        this.createHistoryObserver(), this.createrecommendObserver(), this.createHotObserver();
    },
    onShow: function() {
        var e = (0, r.get)("searchHistory") || [];
        this.setData({
            searchKeys: e.filter(function(e, t) {
                return t < 10;
            })
        });
    },
    createHistoryObserver: function() {
        var e = this;
        this._observer1 = wx.createIntersectionObserver(this), this._observer1.relativeTo(".search-container").observe(".search-history", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47587, {
                moduleName: "搜索历史",
                currPage: "wx-newsearch"
            }), e._observer1.disconnect());
        });
    },
    createrecommendObserver: function() {
        var e = this;
        this._observer2 = wx.createIntersectionObserver(this), this._observer2.relativeToViewport({
            top: this.data.innerTop,
            bottom: -50
        }).observe(".search-recommend", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47587, {
                moduleName: "推荐搜索",
                currPage: "wx-newsearch"
            }), e._observer2.disconnect());
        });
    },
    createHotObserver: function() {
        var e = this;
        this._observer3 = wx.createIntersectionObserver(this), this._observer3.relativeToViewport({
            top: this.data.innerTop
        }).observe(".category", function(t) {
            t.intersectionRatio > 0 && ((0, a.exposureModule)(47587, {
                moduleName: "热搜榜",
                currPage: "wx-newsearch"
            }), e._observer3.disconnect());
        });
    },
    getHotWordCategory: function() {
        var e = this;
        (0, s.queryHotWordCategory)().then(function(t) {
            var r = Number(t[0].categoryId);
            e.setData({
                cateList: t || [],
                categoryId: r
            }), e.getHotSearchData(r);
        });
    },
    getRecommendList: function() {
        var e = this;
        try {
            var t = (0, r.get)("LISTENED_ALBUM_LIST"), a = (t = t.length ? t.slice(0, 5) : []).map(function(e) {
                return e.id + ":" + e.createdAt;
            }), o = t.map(function(e) {
                return e.albumId + ":" + e.createdAt;
            }), i = (0, r.get)("searchHistory") || [];
            i = i.map(function(e) {
                return "".concat(e, ":").concat(Date.now());
            }), (0, s.recommendSearch)({
                trackPlay: a,
                albumExposure: o,
                history: i,
                userId: (0, r.getUid)()
            }).then(function(t) {
                e.setData({
                    recommendList: t.filter(function(e) {
                        return 1 !== e.display_type;
                    }).slice(0, 10)
                });
            });
        } catch (e) {
            console.log(e);
        }
    },
    switchCategory: function(e) {
        var t = this.data.categoryId, r = e.target.dataset || e.currentTarget.dataset, s = r.index, o = r.btnname;
        s = Number(s), (0, a.genLogger)(47586, "click", {
            moduleName: "热搜榜",
            currPage: "wx-newsearch",
            item: o
        }), s !== t && (this.setData({
            categoryId: s,
            hotTagList: []
        }), this.getHotSearchData(t));
    },
    getHotSearchData: function() {
        var e = this, t = this.data.categoryId;
        (0, s.queryHotWords)({
            categoryId: t,
            size: 20
        }).then(function(t) {
            var r = t.hotWordResultList;
            e.setData({
                hotTagList: r
            });
        });
    },
    setSearchHistoryKey: function(e) {
        (0, r.set)("searchHistory", e);
    },
    clearValue: function() {
        this.setData({
            showSelector: !1,
            value: ""
        });
    },
    hideSuggest: function() {
        this.setData({
            showSelector: !1
        });
    },
    doSearch: function(e) {
        var r = (0, t.debounce)(this.searchRequest.bind(this), 100), s = e.detail.value;
        (s = s.trim()) ? r(s) : this.hideSuggest();
    },
    doConfirm: function(e) {
        var t = e.detail.value || "";
        if (t = t.trim()) {
            var s = (0, r.get)("searchHistory") || [];
            if (s.some(function(e) {
                return e.toString() === t.toString();
            })) {
                for (var a = 0; a < s.length; a++) if (s[a] === t) {
                    s.splice(a, 1);
                    break;
                }
                s.unshift(t);
            } else s.unshift(t), this.setSearchHistoryKey(s);
            this.setSearchHistoryKey(s), wx.navigateTo({
                url: "/pages/searchresult/index?kw=".concat(t)
            }), this.hideSuggest();
        } else this.setData({
            placeholder: "请输入搜索内容"
        });
    },
    searchRequest: function(e) {
        var t = this;
        this.setData({
            value: e
        }), (0, s.querySearchSuggest)(e).then(function(e) {
            var r = e.albumResultList, s = e.queryResultList;
            t.setData({
                showSelector: !0,
                albumResultList: r,
                queryResultList: s
            });
        });
    },
    clickHistory: function(e) {
        var t = e.target.dataset || e.currentTarget.dataset, s = t.kw, o = t.modulename, i = (0, 
        r.get)("searchHistory") || [];
        "search-history" === o ? (0, a.genLogger)(47586, "click", {
            moduleName: "搜索历史",
            currPage: "wx-newsearch"
        }) : (0, a.genLogger)(47586, "click", {
            moduleName: "推荐搜索",
            currPage: "wx-newsearch"
        });
        for (var c = 0; c < i.length; c++) if (i[c] === s.toString()) {
            i.splice(c, 1);
            break;
        }
        i.unshift(s), this.setSearchHistoryKey(i), wx.navigateTo({
            url: "/pages/searchresult/index?kw=".concat(s)
        });
    },
    goSearchResult: function(e) {
        var t = e.currentTarget.dataset.kw;
        (0, a.genLogger)(47586, "click", {
            moduleName: "热搜榜",
            currPage: "wx-newsearch"
        });
        var s = (0, r.get)("searchHistory") || [];
        if (s.some(function(e) {
            return e.toString() === t.toString();
        })) {
            for (var o = 0; o < s.length; o++) if (s[o] == t) {
                s.splice(o, 1);
                break;
            }
            s.unshift(t);
        } else s.unshift(t);
        this.setSearchHistoryKey(s), this.hideSuggest(), wx.navigateTo({
            url: "/pages/searchresult/index?kw=".concat(t)
        });
    },
    toAlbum: function(t) {
        (0, e.toAlbum)((0, e.getAlbum)(t, this.data.albumResultList));
    },
    deleteHistory: function() {
        (0, r.set)("searchHistory", ""), this.setData({
            searchKeys: []
        });
    }
});