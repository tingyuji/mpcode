var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/utils/index"), o = require("../../common/apis/categorylistapi");

Page({
    data: {
        subCategories: [],
        cartegoryAlbumList: [],
        subCategoryCode: "quanbu",
        categoryCode: "youshengshu",
        sortTabs: [ "综合排序", "最近更新", "最多播放" ],
        sort: 0,
        scrollTop: 0,
        page: 1,
        pageSize: 20,
        windowHeight: 350
    },
    onLoad: function(t) {
        var e = this, o = t.categoryCode, a = void 0 === o ? "youshengshu" : o, s = t.subCategoryCode, r = void 0 === s ? "quanbu" : s;
        this.setData({
            categoryCode: a,
            subCategoryCode: r
        }, function() {
            return e.getPageData();
        }), this.getWindowHeight();
    },
    onReady: function() {
        var t = this, e = this.data.subCategoryCode;
        setTimeout(function() {
            t.setData({
                subCategoryCode: e
            });
        }, 500);
    },
    getWindowHeight: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    windowHeight: e.windowHeight
                });
            }
        });
    },
    getPageData: function() {
        var e = this, a = this.data, s = a.page, r = a.pageSize, i = a.categoryCode, n = a.subCategoryCode, g = {
            page: s,
            pageSize: r,
            categoryCode: i,
            sort: a.sort
        }, u = "quanbu" == n ? g : t(t({}, g), {}, {
            subCategoryCode: n
        });
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, o.queryCategoryPage)(u).then(function(t) {
            var o = t.categoryDisplayName, a = t.subCategories, s = t.totalCount, r = t.categoryAlbumList;
            console.log("res+++", r), wx.hideToast(), e.setData({
                subCategories: a,
                totalCount: s,
                cartegoryAlbumList: r
            }), wx.setNavigationBarTitle({
                title: o.replace("付费", "")
            });
        }).catch(function(t) {
            console.log("error", t), wx.hideToast();
        });
    },
    subcategorySwitch: function(t) {
        var e = this, o = t.target.dataset.code;
        o != this.data.subCategoryCode && this.setData({
            page: 1,
            subCategoryCode: o
        }, function() {
            return e.getPageData();
        });
    },
    sortSwitch: function(t) {
        var e = this, o = t.target.dataset.index, a = this.data.sort;
        parseInt(o) !== parseInt(a) && this.setData({
            sort: o,
            page: 1,
            scrollTop: 0,
            cartegoryAlbumList: []
        }, function() {
            return e.getPageData();
        });
    },
    loadMoreDatas: function() {
        console.log("到底了"), (0, e.debounce)(this.loadMore.bind(this), 200)();
    },
    loadMore: function() {
        var t = this;
        console.log("到底了啊");
        var e = this.data, o = e.page, a = e.cartegoryAlbumList, s = e.totalCount, r = e.pageSize;
        s - a.length > 0 && s > o * r && (o++, this.setData({
            page: o
        }, function() {
            return t.getMoreAlbums();
        }));
    },
    getMoreAlbums: function() {
        var e = this;
        console.log("开始");
        var a = this.data, s = a.page, r = a.pageSize, i = a.categoryCode, n = a.subCategoryCode, g = {
            page: s,
            pageSize: r,
            categoryCode: i,
            sort: a.sort
        }, u = "quanbu" == n ? g : t(t({}, g), {}, {
            subCategoryCode: n
        });
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, o.queryCategoryAlbumsByPage)(u).then(function(t) {
            var o = t.totalCount, a = t.albumList;
            wx.hideToast();
            var s = e.data.cartegoryAlbumList;
            e.setData({
                totalCount: o,
                cartegoryAlbumList: s.concat(a)
            });
        }).catch(function(t) {
            console.log("error", t), wx.hideToast();
        });
    },
    toAlbum: function(t) {
        (0, e.toAlbum)((0, e.getAlbum)(t, this.data.cartegoryAlbumList));
    }
});