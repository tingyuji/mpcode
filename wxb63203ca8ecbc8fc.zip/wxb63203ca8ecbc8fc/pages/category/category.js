var t = require("../../common/apis/categoryapi"), a = require("../../common/utils/index");

Page({
    data: {
        categoryList: []
    },
    onLoad: function() {
        this.getCategoryList();
    },
    getCategoryList: function() {
        var e = this;
        (0, t.queryCategories)().then(function(t) {
            var r = t || [], o = (0, a.isIos)(), i = r.map(function(t) {
                var a = t.category.displayName, e = a.indexOf("付费") > -1;
                return {
                    name: a,
                    url: t.category.code,
                    hasPaid: e && o
                };
            });
            e.setData({
                categoryList: i
            });
        });
    },
    tapCategory: function(t) {
        var a = t.target.dataset.url;
        wx.navigateTo({
            url: "/pages/categorylist/categorylist?categoryCode=".concat(a)
        });
    }
});