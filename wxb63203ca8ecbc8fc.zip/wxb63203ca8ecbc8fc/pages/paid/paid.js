var t = require("../../common/apis/paidpage"), e = require("../../common/apis/points"), o = require("../../common/utils/storage"), a = require("../../common/utils/myAdapter"), n = require("../../common/utils/tabbar"), i = require("../../common/utils/logger"), s = require("../../common/utils/index");

Page({
    data: {
        modules: [],
        points: 0,
        isLogin: !1,
        categoryId: 0,
        feedInfos: [],
        hasMore: !0,
        helpUserInfo: {},
        isIos: (0, s.isIos)(),
        feedLoading: !1
    },
    onLoad: function() {},
    onShow: function() {
        this.getModules(), this.setData({
            isLogin: (0, o.isLogin)()
        }), (0, o.isLogin)() && this.getUserPoint(), (0, n.setTabBar)(this);
    },
    onScroll: function() {},
    getModules: function() {
        var e = this;
        (0, t.queryPageInfo)().then(function(t) {
            e.setFirstCate(t), e.setData({
                modules: t
            });
        });
    },
    getUserPoint: function() {
        var t = this;
        (0, e.queryPoints)().then(function(e) {
            t.setData({
                points: e.point
            });
        });
    },
    getCateInfos: function() {
        var e = this, o = this.data, a = o.categoryId, n = o.feedInfos;
        o.hasMore && (this.setData({
            feedLoading: !0
        }), (0, t.queryCategory)({
            categoryId: a
        }).then(function(t) {
            wx.hideToast(), e.setData({
                feedInfos: [].concat(n, t),
                hasMore: t.length > 0,
                feedLoading: !1
            });
        }));
    },
    setFirstCate: function(t) {
        var e = this, o = t.find(function(t) {
            return "feed" === t.moduleType;
        }), a = o && o.moduleInfo ? o.moduleInfo[0].categoryId : 0;
        this.setData({
            categoryId: a
        }, function() {
            e.getCateInfos();
        });
    },
    switchCategory: function(t) {
        var e = this, o = (0, a.getDataset)(t).index, n = this.data.categoryId;
        (o || 0 === o) && o != n && this.setData({
            categoryId: o,
            feedInfos: []
        }, function() {
            e.getCateInfos();
        });
    },
    loadMore: function() {
        this.getCateInfos();
    },
    toUnlock: function() {
        wx.navigateTo({
            url: "/pages/pointsunlock/pointsunlock"
        });
    },
    toPoint: function() {
        (0, i.clickGetPoints)(), wx.navigateTo({
            url: "/pages/pointscenter/pointscenter"
        });
    },
    toStarAlbum: function(t) {
        var e = (0, a.getDataset)(t).id;
        (0, i.clickStar)(e), wx.navigateTo({
            url: "/pages/albumDetail/albumDetail?albumId=".concat(e)
        });
    },
    toCate: function(t) {
        var e = (0, a.getDataset)(t), o = e.text, n = e.code;
        (0, i.clickTomato)(o), wx.navigateTo({
            url: "/pages/categorylist/categorylist?categoryCode=".concat(n)
        });
    },
    clickFeedLogger: function(t) {
        var e = t.detail, o = (e = void 0 === e ? {} : e).type, a = e.id, n = e.currentTabName, s = e.recsrc, c = e.rectrack;
        (0, i.clickFeedItem)("".concat("album" === o ? "专辑" : "声音"), "".concat("album" === o ? a : ""), "".concat("album" === o ? "" : a), n, s, c);
    }
});