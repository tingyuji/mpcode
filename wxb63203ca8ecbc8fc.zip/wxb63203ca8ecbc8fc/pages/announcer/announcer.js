var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/anchor"), a = require("../../common/utils/index"), i = require("../../common/utils/myAdapter"), o = require("../../common/utils/logger"), s = require("../../common/utils/storage"), n = require("../../common/utils/wxScopeData"), r = require("../../common/utils/shareFromApp"), c = getApp();

Page({
    data: {
        tabArr: [ {
            value: "专辑",
            id: 2
        }, {
            value: "声音",
            id: 1
        }, {
            value: "听单",
            id: 0
        } ],
        anchorInfo: {},
        subType: 2,
        uid: "",
        list: [],
        page: 1,
        pageSize: 20,
        total: 0,
        isFollow: !1,
        seeMore: !1,
        isSelf: !1,
        is10Pages: 10 === getCurrentPages().length,
        xmcdnImg: (0, a.xmcdnImg)()
    },
    onLoad: function(e) {
        var a = this, i = e.id;
        this.setData({
            uid: i,
            isSelf: i == (0, s.getUid)()
        }), (0, t.queryAnchorInfo)({
            uid: e.id || 1266964
        }).then(function(e) {
            a.setData({
                wxScopeData: (0, n.convertDataToWXScopeData)(e),
                anchorInfo: e,
                isFollow: !!e.relation && e.relation.isFollow,
                seeMore: e.personalSignature && e.personalSignature.length > 20
            });
        }), this.queryAlbums();
    },
    tabSwitch: function(e) {
        var t = this, a = e.currentTarget.dataset.index, i = this.data.subType;
        parseInt(a) !== parseInt(i) && this.setData({
            subType: a,
            page: 1,
            pageSize: 20,
            list: []
        }, function() {
            return t.getDatas(a);
        });
    },
    loadMoreList: function() {
        console.log("到底了"), (0, a.debounce)(this.loadMore.bind(this), 200)();
    },
    loadMore: function() {
        var e = this;
        console.log("到底了啊");
        var t = this.data, a = t.page, i = t.total, o = t.pageSize;
        i - t.list.length > 0 && i > a * o && this.setData({
            page: a++
        }, function() {
            return e.getMoreList();
        });
    },
    getMoreList: function() {
        var e = this, t = this.data.subType, a = this.data.page;
        switch (t) {
          case 0:
            this.setData({
                page: ++a
            }, function() {
                return e.queryListenList();
            });
            break;

          case 1:
            this.setData({
                page: ++a
            }, function() {
                return e.queryTracks();
            });
            break;

          case 2:
            this.setData({
                page: ++a
            }, function() {
                return e.queryAlbums();
            });
        }
    },
    getDatas: function(e) {
        switch (e) {
          case 2:
            this.queryAlbums();
            break;

          case 1:
            this.queryTracks();
            break;

          case 0:
            this.queryListenList();
        }
    },
    queryAlbums: function() {
        var e = this, a = this.data, i = a.page, o = a.pageSize, s = a.list, n = {
            anchorId: this.data.uid || 1266964,
            page: i,
            pageSize: o
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, t.queryAnchorAlbums)(n).then(function(t) {
            wx.hideToast();
            var a = t.page, i = t.pageSize, o = t.total;
            e.setData({
                page: a,
                pageSize: i,
                total: o,
                list: [].concat(s, t.albums)
            });
        });
    },
    queryTracks: function() {
        var e = this, a = this.data, i = a.page, o = a.pageSize, s = a.list, n = {
            anchorId: a.uid || 1266964,
            page: i,
            pageSize: o
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, t.queryAnchorTracks)(n).then(function(t) {
            wx.hideToast();
            var a = t.page, i = t.pageSize, o = t.total;
            e.setData({
                page: a,
                pageSize: i,
                total: o,
                list: [].concat(s, t.tracks)
            });
        });
    },
    queryListenList: function() {
        var e = this, a = this.data, i = a.page, o = a.pageSize, s = a.list, n = {
            uid: a.uid || 1266964,
            page: i,
            pageSize: o
        };
        wx.showToast({
            icon: "loading",
            title: "加载中"
        }), (0, t.queryAnchorListenList)(n).then(function(t) {
            wx.hideToast();
            var a = t.page, i = t.pageSize, o = t.total;
            e.setData({
                page: a,
                pageSize: i,
                total: o,
                list: [].concat(s, t.list)
            });
        });
    },
    toFollow: function(e) {
        var t = (0, i.getDataset)(e).type, o = this.data.uid;
        (0, a.goPage)({
            url: "/pages/follow/follow?type=".concat(t, "&uid=").concat(o)
        });
    },
    followUser: function() {
        var e = this, a = this.data, i = a.isFollow, s = a.uid, n = i ? t.cancelFollow : t.setFollow;
        (0, o.clickAnchorFollow)(i ? "取消关注" : "关注", s), n({
            followingUid: s
        }).then(function() {
            wx.showToast({
                title: i ? "成功取消关注" : "成功关注",
                icon: "success"
            }), e.setData({
                isFollow: !i
            });
        });
    },
    seeMore: function() {
        this.setData({
            seeMore: !1
        });
    },
    toPage: function(e) {
        var t, o = e.currentTarget.dataset || (0, i.getDataset)(e), s = o.type, n = o.id;
        switch (console.log(s, n), s) {
          case "albumId":
            t = "/pages/albumDetail/albumDetail";
            break;

          case "trackId":
            t = "/pages/soundPage/soundPage";
            break;

          case "ugcId":
            t = "/pages/listenlist/listenlist";
            break;

          default:
            t = "";
        }
        t && n && (0, a.goPage)({
            url: "".concat(t, "?").concat(s, "=").concat(n)
        });
    },
    copyPagePath: function() {
        var e = this.data.uid;
        (0, a.copyPagePath)(e), (0, o.genLogger)(27059, "longPress", {
            currPageId: e
        });
    },
    onShareAppMessage: function() {
        var t = this.data, i = t.uid, o = t.anchorInfo, s = c.sq;
        this.shareCount = (0, r.returnShareCount)(s);
        var n = e(e({
            id: i
        }, s), {}, {
            count: this.shareCount
        });
        !n.count && delete n.count, !n.from && delete n.from;
        var u = (0, a.getUrl)(n, "pages/announcer/announcer");
        return {
            path: "/".concat(u),
            title: "".concat(o.nickName),
            imageUrl: (0, a.getOriginImgUrl)("".concat(o.cover))
        };
    }
});