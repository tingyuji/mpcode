require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/channel"), a = require("../../common/utils/index"), r = require("./utils/parseMetaToArray"), i = require("./utils/parseMeta"), s = require("../../common/utils/logger"), o = {
    pageNum: 1,
    pageSize: 20
}, n = [];

Page({
    data: {
        sortFilterData: [ {
            title: "综合排序",
            sort: 1
        }, {
            title: "播放最多",
            sort: 3
        }, {
            title: "最近更新",
            sort: 2
        } ],
        currentSort: 1,
        currentSortStr: "综合排序",
        showFilter: !0,
        hasMore: !0,
        albums: [],
        isLoading: !1,
        showBackTop: !1,
        statusBarHeight: (0, a.getStatusBarHeight)() || 43,
        isSortTabFixed: !1,
        filterDataStr: [],
        selectedMetaNames: [],
        scrollFilterVisible: !1,
        showFixedHeader: !1,
        isAndroid: (0, a.isAndroid)(),
        isIPhoneX: (0, a.isIPhoneX)(),
        menuBtnHeight: (0, a.getMenuButtonHeight)(),
        menuBtnTop: (0, a.getMenuButtonTop)()
    },
    onLoad: function(e) {
        var a = this;
        n = [], o.pageNum = 1;
        var r = e.id, i = void 0 === r ? 10880 : r;
        this.metadataValueId = i, (0, t.queryChannelInfo)(i).then(function(e) {
            var t = e.metadata, r = e.info;
            a.setData({
                info: r
            }), a.metadata = t, a.getFilterData();
        });
    },
    onReady: function() {
        this.createFilterObserver(), this.createHeaderObserver();
    },
    createFilterObserver: function() {
        var e = this;
        this._observer1 = wx.createIntersectionObserver(this), this._observer1.relativeTo(".channel-fix-header").observe(".albums-wrapper", function(t) {
            e.setData({
                isSortTabFixed: t.intersectionRatio > 0
            });
        });
    },
    createHeaderObserver: function() {
        var e = this;
        this._observer2 = wx.createIntersectionObserver(this), this._observer2.relativeTo(".channel-fix-header").observe(".content-wrapper", function(t) {
            e.setData({
                showFixedHeader: t.intersectionRatio > 0
            });
        });
    },
    onReachBottom: function() {
        this.loadMore();
    },
    onPageScroll: function(e) {
        var t = e.scrollTop, a = this.data, r = a.showBackTop;
        a.scrollFilterVisible && this.hideScrollFilter(), r && t < 500 && this.setData({
            showBackTop: !1
        }), !r && t >= 500 && this.setData({
            showBackTop: !0
        });
    },
    loadMore: function() {
        var e = o.pageNum;
        e * o.pageSize > this.total ? this.setData({
            hasMore: !1
        }) : (o.pageNum = e + 1, this.getAlbumList());
    },
    getAlbumList: function() {
        var a = this, r = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], s = this.metadataValueId, l = this.data, c = l.albums, h = l.currentSort;
        this.setData({
            isLoading: !0
        }), r && this.resetSearchParams(), (0, t.queryChannelAlbumsByMeta)(e(e({}, o), {}, {
            metadataValueId: s,
            sort: h,
            metadata: (0, i.getMetaDataJSON)(n)
        })).then(function(e) {
            wx.hideToast();
            var t = e.total, i = e.albums;
            a.total = t;
            var s = r ? i : c.concat(i);
            a.setData({
                albums: r ? i : c.concat(i),
                isLoading: !1,
                hasMore: t > s.length
            });
        });
    },
    resetSearchParams: function() {
        o.pageNum = 1, this.setData({
            hasMore: !0
        }), wx.showToast({
            icon: "loading",
            title: "加载中"
        });
    },
    getFilterData: function() {
        (0, r.setSelectedMetaValue)(n);
        var e = (0, r.getFilterRows)(this.metadata[0], [], 0, this.metadata[0]), t = e.filterDataList, a = e.selectedMetaNames;
        this.setData({
            filterData: t,
            selectedMetaNames: a
        }), this.getAlbumList(!0);
    },
    changeSort: function(e) {
        var t = this, r = (0, a.getDataset)(e), i = r.sort, o = r.name, n = this.data.sortFilterData;
        (0, s.genLogger)(30121, "click", {
            item: o,
            currPage: "channelPage"
        }), this.setData({
            currentSort: Number(i),
            currentSortStr: n.find(function(e) {
                return e.sort === Number(i);
            }).title
        }, function() {
            t.getAlbumList(!0);
        });
    },
    onTapMeta: function(e) {
        (0, s.genLogger)(30123, "click");
        var t = (0, a.getDataset)(e), i = t.depth, o = t.id, l = t.selected, c = (e.currentTarget.dataset || (0, 
        a.getDataset)(e)).array;
        if (o && !l) {
            var h = c[0].id, u = o, d = JSON.parse(JSON.stringify(n)), g = (0, r.getSelectedMetaArrIndex)(i), m = d[g] || [];
            if (m.includes(h)) for (var p = 0; p < m.length; p += 2) {
                var f = m[p], v = m[p + 1];
                f === h && v !== u && u !== h ? (m[p + 1] = u, d.splice(g + 1, d.length)) : f === h && u === h && ((0, 
                r.removeMeta)(h, m), 0 === m.length && d.splice(g, d.length));
            } else h !== u ? m.push(h, u) : m.push(h), d[g] || d.push(m);
            n = d, this.getFilterData();
        }
    },
    goBack: function() {
        (0, a.safeNavigateBack)();
    },
    toggleFilter: function() {
        var e = this.data.showFilter;
        this.setData({
            showFilter: !e
        });
    },
    showScrollFilter: function() {
        this.setData({
            scrollFilterVisible: !0
        });
    },
    hideScrollFilter: function() {
        this.setData({
            scrollFilterVisible: !1
        });
    },
    onTapScrollMeta: function(e) {
        this.onTapMeta(e), this.scrollToTop(0);
    },
    clickFeedLogger: function() {
        (0, s.genLogger)(30124, "click", {
            currPage: "channelPage"
        });
    },
    scrollToTop: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 300;
        wx.pageScrollTo({
            scrollTop: 0,
            duration: e
        });
    },
    onShareAppMessage: function() {
        var e = this.data.info || {};
        return {
            title: e.channelName + "在线收听-喜马拉雅",
            path: "/pages/channel/index?id=" + e.relationMetadataValueId,
            imageUrl: e.coverPath
        };
    }
});