Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setSelectedMetaValue = exports.removeMeta = exports.getSelectedMetaArrIndex = exports.getMetaDatas = exports.getFilterRows = void 0;

var e = require("../../../@babel/runtime/helpers/toConsumableArray");

exports.getMetaDatas = function(e) {
    return function e(t, a, r, i, n, d) {
        return n || (n = 0), t.forEach(function(t, i) {
            var s = a ? a + "," + t.id : t.id + "";
            if (t.path = s, t.hasChild = !1, t.isRoot = 1 === s.split(",").length, t.parentId = r, 
            t.depth = n, t.pIndex = i, t.isRowKey = n % 2 == 0, t.metadataValues && t.metadataValues instanceof Array && t.metadataValues.length > 0) {
                t.hasChild = !0;
                var l = t.metadataValues.map(function(e) {
                    return {
                        id: e.id,
                        displayName: e.displayName,
                        path: t.path + "," + e.id,
                        parentId: t.id,
                        depth: t.depth + 1,
                        pIndex: i
                    };
                });
                t.childs = l;
            }
            t.isRowKey && d.push(t), t.hasChild && (e(t.metadataValues, s, t.id, i, n + 1, d), 
            t.metadataValues = "");
        }), d;
    }(e, void 0, void 0, 0, void 0, []);
};

var t = function(t, a, r) {
    var i = {
        displayName: t.displayName,
        id: t.id,
        isRoot: !0,
        isSelected: 0 === a,
        depth: r
    }, n = t.metadataValues.map(function(e, t) {
        return {
            displayName: e.displayName,
            id: e.id,
            isRoot: !1,
            isSelected: t + 1 === a,
            depth: r
        };
    });
    return [ i ].concat(e(n));
}, a = function(e) {
    return e % 2 == 0 ? e / 2 : (e - 1) / 2;
};

exports.getSelectedMetaArrIndex = a;

var r = function(e, t, r) {
    for (var i = a(t), n = e[i] || [], d = -1, s = function(t) {
        var a = n[t], i = n[t + 1];
        if (-1 !== (d = r.metadataValues.findIndex(function(t) {
            return +t.id == +i && e && a === r.id;
        }))) return "break";
    }, l = 0; l < n.length; l += 2) {
        if ("break" === s(l)) break;
    }
    return -1 === d ? 0 : d + 1;
}, i = function(e, t) {
    for (var a = e.length, r = 0; r < a; r++) {
        var i = e[r];
        if (!(i && i.length > 0)) return !1;
        for (var n = 0; n < i.length; n++) {
            if (i[n] === t) return !0;
        }
    }
}, n = [];

exports.getFilterRows = function e(a) {
    var d = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, l = arguments.length > 3 ? arguments[3] : void 0, o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [];
    if (!a || !a.metadataValues || !a.metadataValues.length) return {
        filterDataList: d,
        selectedMetaNames: o
    };
    var u = r(n, s, a), p = t(a, u, s);
    if (0 === n.length) return d.push(p), {
        filterDataList: d,
        selectedMetaNames: o
    };
    if (s % 2 == 1 && !i(n, a.id)) return {
        filterDataList: d,
        selectedMetaNames: o
    };
    if (i(n, l.id) && s % 2 == 0) {
        var f = p.find(function(e) {
            return e.isSelected;
        });
        f && !f.isRoot && o.push(f.displayName), d.push(p);
    }
    return i(n, l.id) && a.metadataValues.forEach(function(t) {
        e(t, d, s + 1, a, o);
    }), {
        filterDataList: d,
        selectedMetaNames: o
    };
};

exports.setSelectedMetaValue = function(e) {
    n = e;
};

exports.removeMeta = function(e, t) {
    var a = t.indexOf(e);
    return -1 !== a && t.splice(a, 2), t;
};