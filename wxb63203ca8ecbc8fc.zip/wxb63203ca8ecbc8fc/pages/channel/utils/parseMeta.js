Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.parseMetaToQuery = exports.isInPath = exports.getSelectedMetaNames = exports.getRowMetaPath = exports.getMetaDataJSON = void 0;

exports.getRowMetaPath = function(e) {
    return e.path.split(",").splice(0, e.depth).toString();
};

exports.parseMetaToQuery = function(e) {
    if (0 === e.length) return "";
    var t = {};
    return e.map(function(e) {
        t[e.parentId] = e.id;
    }), JSON.stringify(t);
};

exports.getSelectedMetaNames = function(e) {
    var t = e.filter(function(e) {
        return !(!e.isRowKey || e.isSelected) || !(e.isRowKey || !e.isSelected);
    }), r = [];
    return t.map(function(e) {
        if (e.isRowKey) {
            var t = e.childs.find(function(e) {
                return e.isSelected;
            });
            r.push(t);
        }
        e.isRowKey || r.push(e);
    }), r;
};

exports.isInPath = function(e, t) {
    for (var r = e.split(","), n = t.split(","), i = n.length, o = 0; o < i; o++) if (r[o] !== n[o]) return !1;
    return !0;
};

exports.getMetaDataJSON = function(e) {
    for (var t = e.length, r = {}, n = 0; n < t; n++) {
        var i = e[n];
        if (i) for (var o = i.length, s = 0; s < o; s += 2) {
            var a = i[s], p = i[s + 1];
            r[a.toString()] = p;
        }
    }
    return JSON.stringify(r);
};