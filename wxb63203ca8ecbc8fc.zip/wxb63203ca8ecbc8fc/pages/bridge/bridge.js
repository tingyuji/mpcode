var o = require("../../common/utils/index");

Page({
    onLoad: function(r) {
        try {
            if (r && r.url) {
                var t = decodeURIComponent(r.url);
                return wx.reportAnalytics("bridge", {
                    url: t
                }), (0, o.safeNavigateTo)({
                    url: t
                });
            }
        } catch (o) {
            console.error(o);
        }
        (0, o.toHome)();
    },
    onShow: function() {
        this.firstLoad && (0, o.toHome)(), this.firstLoad = !0;
    }
});