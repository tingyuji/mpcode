var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../common/apis/wxgroup"), r = require("../../common/utils/logger");

Page({
    data: {
        pageButton: "",
        pageImage: "",
        org: "",
        actId: "",
        cardTitle: "请勿点击",
        cardImage: ""
    },
    onLoad: function(r) {
        var o = this, a = r.org, n = r.actId;
        (0, e.queryActivitySettings)().then(function(e) {
            if (0 === e.length && o.to404(), e.length >= 1) {
                var r = e.filter(function(t) {
                    return t.actId + "" === n && t.org + "" === a;
                });
                if (r.length > 0) return o.setData(t({}, r[0]));
                o.to404();
            }
        });
    },
    onShow: function() {},
    to404: function() {
        wx.redirectTo({
            url: "/pages/404/index"
        });
    },
    tapButton: function() {
        var t = this.data, e = t.actId, o = t.org;
        (0, r.genLogger)(30050, "click", {
            actId: e,
            org: o
        });
    }
});