var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("./regex.js"));

var t = function(e) {
    return "string" == typeof e && r.default.test(e);
};

exports.default = t;