var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("./rng.js")), t = e(require("./stringify.js"));

var u = function(e, u, a) {
    var i = (e = e || {}).random || (e.rng || r.default)();
    if (i[6] = 15 & i[6] | 64, i[8] = 63 & i[8] | 128, u) {
        a = a || 0;
        for (var n = 0; n < 16; ++n) u[a + n] = i[n];
        return u;
    }
    return (0, t.default)(i);
};

exports.default = u;