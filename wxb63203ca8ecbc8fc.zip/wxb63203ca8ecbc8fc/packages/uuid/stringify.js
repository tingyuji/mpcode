var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

for (var r = e(require("./validate.js")), t = [], i = 0; i < 256; ++i) t.push((i + 256).toString(16).substr(1));

var o = function(e) {
    var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, o = (t[e[i + 0]] + t[e[i + 1]] + t[e[i + 2]] + t[e[i + 3]] + "-" + t[e[i + 4]] + t[e[i + 5]] + "-" + t[e[i + 6]] + t[e[i + 7]] + "-" + t[e[i + 8]] + t[e[i + 9]] + "-" + t[e[i + 10]] + t[e[i + 11]] + t[e[i + 12]] + t[e[i + 13]] + t[e[i + 14]] + t[e[i + 15]]).toLowerCase();
    if (!(0, r.default)(o)) throw TypeError("Stringified UUID is invalid");
    return o;
};

exports.default = o;