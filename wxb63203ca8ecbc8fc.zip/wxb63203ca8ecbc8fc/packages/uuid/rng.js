Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return new Array(16).fill(0).forEach(function(e, t) {
        var n = function(r, e) {
            switch (arguments.length) {
              case 1:
                return parseInt(Math.random() * r + 1, 10);

              case 2:
                return parseInt(Math.random() * (e - r + 1) + r, 10);

              default:
                return 0;
            }
        }(10, 300);
        r.fill(n, t, t + 1);
    }), r;
};

var r = new Uint8Array(16);