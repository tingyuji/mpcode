Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.decrypt = void 0;

var e = require("crypto-js"), r = e;

exports.decrypt = function(t) {
    return r.AES.decrypt({
        ciphertext: e.enc.Base64url.parse(t)
    }, r.enc.Hex.parse("aaad3e4fd540b0f79dca95606e72bf93"), {
        mode: r.mode.ECB,
        padding: r.pad.Pkcs7
    }).toString(r.enc.Utf8);
};