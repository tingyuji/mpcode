Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.hasCanPlay = s;

var e = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), r = require("@xmly/lite-login_wx/lib/index"), i = require("./decrypt"), a = require("../../common/utils/navBar"), n = require("../../common/utils/env"), l = (require("../qs"), 
require("./event").EventBus), o = require("./encrypt.js"), c = (o.getEncryptedFileName, 
o.getEncryptedFileParams, n.isDevelopment ? "http://mpay.dev.test.ximalaya.com" : "https://mobile.ximalaya.com");

function s(e) {
    return !(!e.userPermission && !e.canPlay || e.isXimiFirst && !e.canPlayXimiTrack);
}

var u = function() {
    function n() {
        e(this, n);
    }
    return t(n, [ {
        key: "apply",
        value: function(e) {
            e.on("checkSource", function(t, n) {
                if (!s(t)) return l.emit("openGModal", {
                    tipModal: {
                        albumId: t.albumId,
                        trackId: t.id,
                        visible: !0,
                        trackTitle: t.title,
                        tip: "该节目为精品内容，请".concat((0, a.isIos)() ? "解锁" : "购买", "后收听~")
                    }
                }), void e.trackCannotPlay(t);
                t.src ? n(t) : t.id ? (0, r.request)({
                    url: "".concat(c, "/mobile-playpage/track/v3/baseInfo/").concat(Date.now()),
                    data: {
                        device: "web",
                        trackQualityLevel: 0,
                        isBackend: !1,
                        trackId: t.id
                    }
                }).then(function(e) {
                    var r = e.ret, a = e.msg, l = e.trackInfo, o = "下载喜马拉雅，收听完整版";
                    if (0 !== r) return 999 !== r && 927 !== r || (o = a), wx.showToast({
                        title: o,
                        icon: "none"
                    });
                    var c = l.playUrlList;
                    if (!c || !c.length) return wx.showToast({
                        title: o,
                        icon: "none"
                    });
                    var s = c[0].url;
                    t.src = (0, i.decrypt)(s), n(t);
                }) : n(t);
            });
        }
    } ]), n;
}();

module.exports = {
    LinkProtector: u,
    hasCanPlay: s
};