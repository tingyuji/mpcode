var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../@babel/runtime/helpers/classCallCheck"), a = require("../../@babel/runtime/helpers/createClass"), n = require("../../@babel/runtime/helpers/inherits"), r = require("../../@babel/runtime/helpers/createSuper"), o = require("../../common/utils/ttAdapter"), u = require("../../common/apis/track"), l = require("../../common/utils/logger"), s = e(require("@xmly/raven-lite")), c = require("../../common/utils/storage"), h = require("../../common/const/trackType"), d = require("../../common/utils/index"), y = require("./event").Event, v = require("./consts"), p = v.PlayState, f = v.PlayMode, g = v.PlaySort, _ = v.ErrorCode, m = require("./playlist"), k = function(e) {
    return e;
}, S = function(e) {
    n(S, y);
    var v = r(S);
    function S() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return i(this, S), (e = v.call(this)).needInit = !0, e.key = "", e.readyQueue = [], 
        e._ready = !1, e._cache = {}, e.playState = p.INITIAL, e.sort = g.ASC, e.mode = f.ORDERED, 
        e._plugins = t.plugins || [], e._playInfo = [], e._init(), e._delayCount = -1, e._delayCountTimer = 0, 
        e;
    }
    return a(S, [ {
        key: "_initAudioManager",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.src, i = void 0 === t ? "" : t, a = e.title, n = void 0 === a ? "" : a, r = e.albumName, o = void 0 === r ? "" : r, u = e.singer, l = void 0 === u ? "" : u, s = e.cover, h = void 0 === s ? "" : s, d = e.audioPage, y = void 0 === d ? "" : d, v = e.playbackRate, p = void 0 === v ? (0, 
            c.get)("_playRate") || 1 : v, f = e.startTime, g = void 0 === f ? 0 : f, _ = e.protocol, m = void 0 === _ ? "http" : _, k = this.audioManager;
            k.title = "喜马拉雅 - ".concat(n || o), k.epname = o, k.singer = l, k.coverImgUrl = h, 
            k.audioPage = y, k.playbackRate = p, k.startTime = g, k.src = i, k.protocol = m;
        }
    }, {
        key: "_autoPlayNext",
        value: function() {
            if (!this.auditionEnd(this.currentTime())) {
                if (!this._playlist || this._changingSrc || this._delayClose) return !1;
                this.playNext(!0);
            }
        }
    }, {
        key: "_init",
        value: function() {
            var e = this;
            this.ready(function() {
                var t = e.audioManager, i = e._plugins;
                e.on("ended", function() {
                    e._autoPlayNext();
                }), e.on("stopped", function() {
                    var t = e.currentSource();
                    (0, d.isIos)() && t.type === h.RADIOS && (e.currentTime() && e._autoPlayNext());
                });
                for (var a = 0; a < i.length; a++) {
                    i[a].apply(e);
                }
                t.onCanplay(function(e) {
                    console.log("oncanplay", e);
                }), t.onPlay(e._handlePlayStart.bind(e)), t.onPause(e._handlePlayPause.bind(e)), 
                t.onStop(e._handlePlayStop.bind(e)), t.onEnded(e._handlePlayEnded.bind(e)), t.onTimeUpdate(e._handleTimeupdate.bind(e)), 
                setTimeout(function() {
                    return t.onError(e._handlePlayError.bind(e));
                }, 1e3), t.onWaiting(e._handlePlayWaiting.bind(e)), t.onPrev(e.playPrev.bind(e)), 
                t.onNext(e.playNext.bind(e));
            });
        }
    }, {
        key: "addManager",
        value: function(e) {
            this.audioManager = e, this.triggerReady();
        }
    }, {
        key: "ready",
        value: function(e) {
            this._ready ? setTimeout(e, 1) : this.readyQueue.push(e);
        }
    }, {
        key: "triggerReady",
        value: function() {
            for (this._ready = !0; this.readyQueue.length; ) {
                this.readyQueue.shift()();
            }
        }
    }, {
        key: "getTrackInfo",
        value: function(e, t) {
            if (e) {
                var i = e.id || e.trackId;
                if (!i) return {};
                (0, u.getTrackInfo)(i, !1).then(function(e) {
                    var i = e.trackInfo;
                    t && "function" == typeof t && t(i);
                }).catch(function() {
                    t && "function" == typeof t && t({});
                });
            }
        }
    }, {
        key: "justPlay",
        value: function(e) {
            this.play(e, {}, 0, !1);
        }
    }, {
        key: "setNeedInit",
        value: function(e) {
            this.needInit = e;
        }
    }, {
        key: "play",
        value: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, a = i.listMode, n = i.flag, r = arguments.length > 2 ? arguments[2] : void 0, o = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], u = function(e) {
                t.playWithUpdatedSource(e, {
                    listMode: a,
                    flag: n
                }, r, o);
            };
            (null == e ? void 0 : e.type) === h.RADIOS || (null == e ? void 0 : e.type) === h.HOTNEWS ? u(e) : this.getTrackInfo(e, function(e) {
                u(e);
            });
        }
    }, {
        key: "playWithUpdatedSource",
        value: function(e) {
            var i = arguments, a = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = n.listMode, o = n.flag, u = arguments.length > 2 ? arguments[2] : void 0, s = arguments.length > 3 ? arguments[3] : void 0;
            if (this.setNeedInit(s), !this.audioManager) return setTimeout(function() {
                return a.play.apply(a, t(i));
            }, 1e3);
            var c = this._playlist, h = this.currentSource();
            if (0 === e.auditStatus) return this.emit("auditReject");
            if (e.startTime = void 0 === e.startTime ? u : e.startTime, c && !r) {
                var d = c.indexInPlaylist(e);
                -1 !== d ? (c.setIndex(d), this.isSource(h) && c.push(h)) : (c.destroy(), this._playlist = void 0);
            } else c && this.isSource(h) && 0 !== o && c.push(h);
            this.emit("beforeSourceChange", e), this.updateCheckingSourceCache(e), this._checkSource(e, function(t) {
                a.emit("afterSourceChange", t), a.once("timeupdate", function() {
                    a.compareDuration(e), a.emit("firstPlay", e), (0, l.genLogger)(27219, "slipPage", {
                        currPage: "play"
                    });
                }), a.audioManager.onCanplay(function() {
                    if (0 === e.auditStatus) return a.emit("auditReject");
                }), (0, l.genLogger)(26999, "pageview", {
                    trackId: e.id
                });
            });
        }
    }, {
        key: "playAD",
        value: function(e) {
            var t = this;
            this.setNeedInit(!0), this._setSource(e), this._changingSrc = !0, this.once("ended", function() {
                t.nextTick(function() {
                    return t._changingSrc = !1;
                });
            });
        }
    }, {
        key: "replay",
        value: function(e) {
            console.log("replay", this.currentTime(), this.duration());
            var t = e || 0;
            this.seek(t), this.play(this.currentSource(), {}, e);
        }
    }, {
        key: "playNew",
        value: function() {}
    }, {
        key: "pause",
        value: function() {
            this.audioManager.pause();
        }
    }, {
        key: "resume",
        value: function() {
            this.audioManager.play();
        }
    }, {
        key: "seek",
        value: function(e) {
            this.auditionEnd(e) || this.audioManager.seek(e);
        }
    }, {
        key: "stop",
        value: function() {
            this.audioManager.stop();
        }
    }, {
        key: "end",
        value: function() {
            this._handlePlayEnded(), this.pause();
        }
    }, {
        key: "auditionEnd",
        value: function(e) {
            var t = this.currentSource(), i = t.needPay, a = t.sampleDuration;
            if (i && (void 0 === e || e >= a)) return this.emit("auditionEnd");
        }
    }, {
        key: "isCurrentSource",
        value: function(e) {
            var t = this.currentSource();
            return e.id && e.id === t.id || e.src && e.src === t.src;
        }
    }, {
        key: "isRadioCurrentSource",
        value: function(e) {
            var t = this.currentSource();
            return e && e.id && e.id === t.id && e.src && e.src === t.src;
        }
    }, {
        key: "isSource",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return !!e && (e.id || e.src);
        }
    }, {
        key: "updateSourceCache",
        value: function(e) {
            this._cache.source = e, this._cache.src = e.src, this._cache.duration = e.duration;
        }
    }, {
        key: "currentSource",
        value: function() {
            return this._cache.source || {};
        }
    }, {
        key: "updateCheckingSourceCache",
        value: function(e) {
            this._cache.checkingSource = e;
        }
    }, {
        key: "checkingSource",
        value: function() {
            return this._cache.checkingSource || {};
        }
    }, {
        key: "compareDuration",
        value: function(e) {
            var t = (0, o.getAudioDuration)(this.audioManager);
            (!e.duration || Math.abs(e.duration - t) > 60) && this.duration(t);
        }
    }, {
        key: "currentTime",
        value: function(e) {
            return void 0 === e ? this._cache.currentTime : this._cache.currentTime = e;
        }
    }, {
        key: "duration",
        value: function(e) {
            if (void 0 === e) return this._cache.duration;
            this._cache.duration = e;
        }
    }, {
        key: "nextTick",
        value: function(e) {
            setTimeout(e, 1);
        }
    }, {
        key: "_checkSource",
        value: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : k;
            this.emitAsyncSerialWaterfall("checkSource", e, function() {
                t._setSrc(e, function(e) {
                    t.updateSourceCache(e), console.log(e, "src++++"), i(e);
                });
            });
        }
    }, {
        key: "_setSrc",
        value: function(e) {
            var t = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : k;
            this._changingSrc = !0, this._playInfo = [], this.isSource(this.currentSource()) && this.playState === p.PLAYING && this.end(), 
            this.emitAsyncSerialWaterfall("setSource", e, function() {
                var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : e, n = t._setSource(a);
                if (t._changingSrc = !1, n) return t._handlePlayError(n);
                i(a);
            });
        }
    }, {
        key: "_setSource",
        value: function(e) {
            if (!e.src) return new Error("source must has src property");
            !0 === this.needInit && this._initAudioManager(e);
        }
    }, {
        key: "_playStateChange",
        value: function(e) {
            this.playState = e;
            var t = {
                t: Date.now(),
                s: this.playState,
                p: this._cache.currentTime || 0
            };
            this._playInfo.push(t), this.emit("playStateChange", e, this._playInfo, this.audioManager.currentTime), 
            (!this.playState || this.playState === p.ERROR || this._playInfo.length > 3e3) && (this._playInfo = []);
        }
    }, {
        key: "_handlePlayEnded",
        value: function() {
            var e = this, t = function() {
                e._playStateChange(p.ENDED), e.emit("ended");
            };
            if (this.currentSource().type === h.RADIOS) {
                var i = this.currentTime();
                i !== this.key ? (this.key = i, t()) : this.key = "";
            } else this.key = "", t();
        }
    }, {
        key: "_handlePlayError",
        value: function(e) {
            this.emit("error", e), this._playStateChange(p.ERROR);
            var t = this.currentSource();
            (0, l.genLogger)(20063, "exposure", {
                trackId: t && t.id,
                errorType: "errCode:".concat(e.errCode, ",").concat(e.errMsg || "播放出错了！")
            }), s.default.captureException("播放出错了:".concat(e.errCode, ",").concat(e.errMsg, ",id:").concat(t.id), {
                level: "error"
            });
        }
    }, {
        key: "_handlePlayPause",
        value: function() {
            this._playStateChange(p.PAUSE);
        }
    }, {
        key: "_handlePlayStart",
        value: function() {
            this.emit("playStarted"), this._playStateChange(p.PLAYING);
        }
    }, {
        key: "_handlePlayStop",
        value: function() {
            console.log("stop"), this.emit("stopped"), this._playStateChange(p.ENDED);
        }
    }, {
        key: "_handlePlayWaiting",
        value: function() {
            console.log("waiting"), this._playStateChange(p.LOADING);
        }
    }, {
        key: "_handleTimeupdate",
        value: function() {
            var e = this.audioManager.currentTime;
            this.auditionEnd(e) || (this.currentTime(e), this.emit("timeupdate", e));
        }
    }, {
        key: "_handleError",
        value: function(e) {
            this.emit("error", e);
        }
    }, {
        key: "_checkHasMore",
        value: function() {
            var e = this, i = (this.currentSource() || {}).id;
            console.log("checkHasMore", this.sort, this.currentSource()), i && (0, u.queryRelativeTracks)(i, "0", 10, this.sort).then(function() {
                var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                if (1 != i.length) {
                    var a = t(i);
                    a.shift(), e.appendPlaylist(a), setTimeout(function() {
                        return e.playNext();
                    }, 0);
                } else e._handleError({
                    code: _.INFO,
                    message: "没有下一首"
                });
            });
        }
    }, {
        key: "_setCurrentIndex",
        value: function() {
            var e = this._playlist;
            if (e) {
                var t = (this.currentSource() || {}).id, i = e.list.findIndex(function(e) {
                    return e.id === t;
                });
                i > -1 && this.setIndex(i);
            }
        }
    }, {
        key: "trackCannotPlay",
        value: function(e) {
            this.updateSourceCache(e), this.stop(), this.emit("trackCannotPlay", e);
        }
    }, {
        key: "playlist",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, i = t.mode, a = void 0 === i ? f.ORDERED : i, n = t.index, r = void 0 === n ? 0 : n, o = t.auto, u = arguments.length > 2 ? arguments[2] : void 0;
            return a = this.mode, void 0 === e ? this._playlist || {} : e[r] && 0 === e[r].auditStatus ? (this._playlist = new m({
                list: [ e[r] ],
                mode: a,
                index: r
            }), this.stop(), this.emit("auditReject")) : (this._playlist = new m({
                list: e,
                mode: a,
                index: r,
                sort: this.sort
            }), void (o && this.play(e[r], {
                listMode: !0
            }, u)));
        }
    }, {
        key: "appendPlaylist",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = this._playlist;
            if (t) return t.append(e);
        }
    }, {
        key: "prependPlaylist",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = this._playlist;
            if (t) return t.prepend(e);
        }
    }, {
        key: "setIndex",
        value: function(e) {
            if (null != e && null !== e) {
                var t = this._playlist;
                t && t.setIndex(e);
            }
        }
    }, {
        key: "changeSort",
        value: function(e) {
            this.sort = e;
        }
    }, {
        key: "playMode",
        value: function(e) {
            var t = this._playlist;
            return t ? void 0 === e ? t.mode : (this.mode = e, t.changeMode(e), e) : f.ERROR;
        }
    }, {
        key: "playNext",
        value: function(e) {
            this._setCurrentIndex();
            var t = this.next(e);
            if (console.log("===playNext", t), e && this._delayCount >= 1 && (this._delayCount = this._delayCount - 1), 
            e && 0 === this._delayCount) return this._delayCount = -1, this._delayCountTimer = 0, 
            void this.emit("delayDurationEnded", !0);
            if (t) this.play(t, {
                listMode: !0
            }); else if (null == t) {
                if ((this.currentSource() || {}).type === h.RADIOS) return void this._handleError({
                    code: _.INFO,
                    message: "没有下一首"
                });
                this._checkHasMore();
            }
        }
    }, {
        key: "playPrev",
        value: function() {
            var e = this.prev();
            e ? this.play(e, {
                listMode: !0,
                flag: 0
            }) : null == e && this._handleError({
                code: _.INFO,
                message: "没有上一首"
            });
        }
    }, {
        key: "prev",
        value: function() {
            var e = this._playlist;
            return e || this._handleError(new Error("播放列表为空")), e && e.hasPrev() ? e.prev() : null;
        }
    }, {
        key: "next",
        value: function(e) {
            var t = this._playlist;
            return t || this._handleError(new Error("播放列表为空")), t && t.next && t.next(e);
        }
    }, {
        key: "delayClose",
        value: function(e) {
            var t = this, i = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], a = arguments.length > 2 ? arguments[2] : void 0;
            if ("boolean" != typeof e && void 0 !== e || (i = !!e), this._delayCount = -1, this._delayCountTimer = 0, 
            this._delayTimer && clearInterval(this._delayTimer), !i) return this._delayClose = !1, 
            void this.emit("delayDurationUpdate", 0, a);
            -1 === e && (this._delayClose = !0);
            var n = e;
            this.emit("delayDurationUpdate", n, a), this._delayTimer = setInterval(function() {
                n--, t.emit("delayDurationUpdate", n, a), n <= .5 && (t.pause(), clearInterval(t._delayTimer), 
                t.emit("delayDurationUpdate", 0), t.emit("delayDurationEnd"));
            }, 1e3);
        }
    }, {
        key: "delayCountClose",
        value: function(e) {
            var t = arguments.length > 2 ? arguments[2] : void 0;
            this._delayCount = e, this._delayClose = !1, this._delayCountTimer = t, this._delayTimer && clearInterval(this._delayTimer), 
            this.emit("delayDurationUpdate", 0, t);
        }
    }, {
        key: "currentDelayTimer",
        value: function() {
            return this._delayCountTimer;
        }
    }, {
        key: "changePlayRate",
        value: function(e) {
            this.audioManager.playbackRate = e;
            var t = this.currentTime();
            this.emit("playRateUpdate", e), this.audioManager.startTime = t;
        }
    } ]), S;
}();

S.PlayState = p, module.exports = S;