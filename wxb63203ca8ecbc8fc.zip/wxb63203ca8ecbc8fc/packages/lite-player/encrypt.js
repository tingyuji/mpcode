var r = require("../../@babel/runtime/helpers/slicedToArray");

function t(r, t) {
    for (var e, n = [], o = 0, a = "", i = 0; 256 > i; i++) n[i] = i;
    for (i = 0; 256 > i; i++) o = (o + n[i] + r.charCodeAt(i % r.length)) % 256, e = n[i], 
    n[i] = n[o], n[o] = e;
    for (var h = o = i = 0; h < t.length; h++) o = (o + n[i = (i + 1) % 256]) % 256, 
    e = n[i], n[i] = n[o], n[o] = e, a += String.fromCharCode(t.charCodeAt(h) ^ n[(n[i] + n[o]) % 256]);
    return a;
}

function e(r) {
    this._randomSeed = r, this.cg_hun();
}

e.prototype = {
    cg_hun: function() {
        this._cgStr = "";
        var r = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/\\:._-1234567890", t = r.length, e = 0;
        for (e = 0; e < t; e++) {
            var n = this.ran() * r.length, o = parseInt(n);
            this._cgStr += r.charAt(o), r = r.split(r.charAt(o)).join("");
        }
    },
    cg_fun: function(r) {
        r = r.split("*");
        var t = "", e = 0;
        for (e = 0; e < r.length - 1; e++) t += this._cgStr.charAt(r[e]);
        return t;
    },
    ran: function() {
        return this._randomSeed = (211 * this._randomSeed + 30031) % 65536, this._randomSeed / 65536;
    },
    cg_decode: function(r) {
        var t = "", e = 0;
        for (e = 0; e < r.length; e++) {
            var n = r.charAt(e), o = this._cgStr.indexOf(n);
            -1 !== o && (t += o + "*");
        }
        return t;
    }
};

var n = t("xm", "Ä[ÜJ=Û3Áf÷N"), o = [ 19, 1, 4, 7, 30, 14, 28, 8, 24, 17, 6, 35, 34, 16, 9, 10, 13, 22, 32, 29, 31, 21, 18, 3, 2, 23, 25, 27, 11, 20, 5, 15, 12, 0, 33, 26 ];

module.exports = {
    getEncryptedFileName: function(r, t) {
        var n = new e(r).cg_fun(t);
        return "/" === n[0] ? n : "/".concat(n);
    },
    getEncryptedFileParams: function(e) {
        var a = t(function(r, t) {
            for (var e = [], n = 0; n < r.length; n++) {
                for (var o = "a" <= r[n] && "z" >= r[n] ? r[n].charCodeAt() - 97 : r[n].charCodeAt() - "0".charCodeAt() + 26, a = 0; 36 > a; a++) if (t[a] == o) {
                    o = a;
                    break;
                }
                e[n] = 25 < o ? String.fromCharCode(o - 26 + "0".charCodeAt()) : String.fromCharCode(o + 97);
            }
            return e.join("");
        }("d" + n + "9", o), function(r) {
            if (!r) return "";
            var t, e, n, o, a, i = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
            for (o = (r = r.toString()).length, n = 0, a = ""; n < o; ) {
                do {
                    t = i[255 & r.charCodeAt(n++)];
                } while (n < o && -1 == t);
                if (-1 == t) break;
                do {
                    e = i[255 & r.charCodeAt(n++)];
                } while (n < o && -1 == e);
                if (-1 == e) break;
                a += String.fromCharCode(t << 2 | (48 & e) >> 4);
                do {
                    if (61 == (t = 255 & r.charCodeAt(n++))) return a;
                    t = i[t];
                } while (n < o && -1 == t);
                if (-1 == t) break;
                a += String.fromCharCode((15 & e) << 4 | (60 & t) >> 2);
                do {
                    if (61 == (e = 255 & r.charCodeAt(n++))) return a;
                    e = i[e];
                } while (n < o && -1 == e);
                if (-1 == e) break;
                a += String.fromCharCode((3 & t) << 6 | e);
            }
            return a;
        }(e)).split("-"), i = r(a, 4), h = i[0];
        return {
            sign: i[1],
            buy_key: h,
            token: i[2],
            timestamp: i[3]
        };
    }
};