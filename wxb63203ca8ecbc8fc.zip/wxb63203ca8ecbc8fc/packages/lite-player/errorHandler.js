var e = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/classCallCheck"), t = require("../../@babel/runtime/helpers/createClass"), o = require("../../common/utils/logger"), n = require("../../common/utils/index"), i = require("./event"), a = function(e) {
    (0, o.genLogger)(27160, "slipPage", {
        errorType: "errCode:".concat(e.errCode, ",").concat(e.errMsg || "播放出错了！"),
        currPage: "overall"
    });
}, s = function() {
    function o() {
        var e = this;
        r(this, o), this.retryCount = 1, this.isPlayStarted = !1, this.isHide = !1, this.retryInterval = null, 
        wx.onAppHide(function() {
            e.isHide = !0;
        }), wx.onAppShow(function() {
            e.isHide = !1;
        });
    }
    return t(o, [ {
        key: "apply",
        value: function(r) {
            var t = this;
            r.on("error", function(o) {
                t.isPlayStarted = !1;
                var s = function() {
                    wx.showToast({
                        title: "网络错误，重新载入中",
                        icon: "none",
                        duration: 4500
                    }), t.retryCount <= 3 ? setTimeout(function() {
                        r.play(e({}, r._cache.source), {}, r.audioManager.currentTime || 0), t.retryCount = t.retryCount + 1;
                    }, 1500) : (t.retryCount = 1, wx.showToast({
                        title: "播放出错了，errCode:" + o.errCode,
                        icon: "none"
                    })), r.on("playStarted", function() {
                        wx.hideToast(), t.isPlayStarted || (a(o), t.retryCount = 1, t.isPlayStarted = !0);
                    });
                };
                if (10001 === o.errCode && s(), 10002 === o.errCode && s(), 10003 === o.errCode) {
                    var u = (0, n.get)("play_error_10003") || {}, l = u.count, c = u.date, d = new Date().toLocaleDateString();
                    Number(l) >= 2 && c === d ? (i.EventBus.emit("showErrorGuide"), (0, n.set)("play_error_guide", d)) : c !== d && c ? c !== d && (0, 
                    n.set)("play_error_10003", {
                        date: d,
                        count: 1
                    }) : (0, n.set)("play_error_10003", {
                        date: d,
                        count: l ? l + 1 : 1
                    });
                }
                10004 === o.errCode && s(), 10002 !== o.errCode && 10004 !== o.errCode && (10003 === o.errCode || 10001 === o.errCode ? wx.showToast({
                    title: "播放出错了，errCode:" + o.errCode,
                    icon: "none"
                }) : wx.showToast({
                    title: o.msg || o.message || "播放出错了！",
                    icon: "none"
                }));
            });
        }
    } ]), o;
}();

module.exports = s;