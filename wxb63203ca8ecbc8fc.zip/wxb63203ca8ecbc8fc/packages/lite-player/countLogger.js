var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("../../@babel/runtime/helpers/classCallCheck"), a = require("../../@babel/runtime/helpers/createClass"), n = require("../../common/apis/index"), r = require("../../common/utils/env"), o = require("../../common/utils/wxCookie"), i = require("../../common/const/trackType"), c = require("./consts").PlayState, u = function(t) {
    var e = 0, a = t.length, n = t.length - 1;
    return a && (e = t[n].s === c.PAUSE ? t[n].p : t[n <= 0 ? n : n - 1].p), e;
}, d = {
    HOST: r.isDevelopment ? "https://m.test.ximalaya.com" : "https://m.ximalaya.com",
    MOBILEHOST: r.isDevelopment ? "https://mobile.test.ximalaya.com" : "https://mobile.ximalaya.com",
    device: (0, o.getWXAccessOpenId)(),
    radioPlayCount: function(t) {
        var e = "".concat(this.MOBILEHOST, "/nyx/v2/radio/count/web"), a = {
            radioId: t
        };
        return (0, n.request)({
            method: "post",
            url: e,
            data: a
        }).then(function() {
            console.log("+++广播计数：", t);
        }).catch(function(t) {
            console.warn("radio count api error: ", t);
        });
    },
    radioPlayStatistic: function(t) {
        var e = "".concat(this.MOBILEHOST, "/nyx/v2/radio/statistic/web");
        return (0, n.request)({
            method: "post",
            url: e,
            data: t
        }).then(function(e) {
            console.log("+++广播统计：", t, e);
        }).catch(function(t) {
            console.warn("radio statistic api error: ", t);
        });
    },
    getInterval: function() {
        return (0, n.request)({
            url: "".concat(this.HOST, "/nyx/v2/track/statistic/interval")
        }).then(function(t) {
            var e = 0;
            return 0 === t.ret && (e = t.data.interval), e;
        }).catch(function() {});
    },
    postCount: function(t) {
        var e = "".concat(this.HOST, "/nyx/v2/track/count/wxapp"), a = {
            trackId: t,
            device: this.device
        };
        return !this.device && delete a.device, (0, n.request)({
            method: "post",
            headers: {
                "content-type": "application/x-www-form-urlencoded"
            },
            url: e,
            data: a
        }).then(function(t) {
            var e = null;
            return 0 === t.ret && (e = t.data.token), e;
        }).catch(function(t) {
            console.warn("track count: ", t);
        });
    },
    postStatistic: function(t) {
        var e = t.trackId, a = t.albumId, r = t.startedAt, o = t.endedAt, i = t.duration, c = t.breakSecond, u = t.token, d = "".concat(this.HOST, "/nyx/v2/track/statistic/wxapp"), s = {
            trackId: e,
            albumId: a,
            startedAt: r,
            endedAt: o,
            duration: i,
            breakSecond: c,
            token: u,
            device: this.device,
            subApp: 100
        };
        return !this.device && delete s.device, (0, n.request)({
            method: "post",
            headers: {
                "content-type": "application/x-www-form-urlencoded"
            },
            url: d,
            data: s
        }).catch(function(t) {
            console.warn("track statistic: ", t);
        });
    }
}, s = function() {
    function n() {
        e(this, n), this.playInfo = void 0, this.timerFn = null, this.intervalTime = 0, 
        this.TOKEN = "", this.isRadioPlay = !1;
    }
    return a(n, [ {
        key: "judgeRadioPlay",
        value: function(t) {
            return t && t.type === i.RADIOS;
        }
    }, {
        key: "apply",
        value: function(t) {
            var e = this;
            t.on("setSource", function(a, n) {
                e.timerFn && clearInterval(e.timerFn), e.radioPlayStatistic(a, t), e.isRadioPlay = e.judgeRadioPlay(a), 
                e.isRadioPlay ? e.radioPlayHandler(a, t) : e.soundPlayCount(a, t), n(a);
            }), t.on("playStateChange", function(a, n) {
                e.isRadioPlay ? a === c.PLAYING && (e.playInfo = n) : e.soundPlayStatistic(t);
            });
        }
    }, {
        key: "soundPlayCount",
        value: function(e, a) {
            var n = this, r = [ d.getInterval().then(function(t) {
                return n.intervalTime = t;
            }), d.postCount(e.id || 0).then(function(t) {
                return n.TOKEN = t;
            }) ];
            Promise.all(r).then(function(e) {
                var r = t(e, 1)[0];
                r <= 0 || !r || (n.timerFn = setInterval(function() {
                    return n.soundPlayStatistic(a, !0);
                }, 1e3 * r));
            }).catch(function(t) {
                console.warn("接口请求出错", t);
            });
        }
    }, {
        key: "soundPlayStatistic",
        value: function(t, e) {
            var a = t.playState, n = t._cache;
            if (n && n !== JSON.stringify({}) && (e && a === c.PLAYING || !e && a === c.PAUSE)) {
                var r = t._playInfo, o = e ? Number(n.currentTime).toFixed(0) : Math.round(u(r)), i = Math.round((Date.now() - (r && r[0] && r[0].t || 0)) / 1e3), s = {
                    trackId: n.source.id,
                    albumId: n.source.albumId,
                    startedAt: r && r[0] && r[0].t || 0,
                    endedAt: Date.now(),
                    duration: i,
                    breakSecond: o,
                    token: this.TOKEN
                };
                d.postStatistic(s);
            }
        }
    }, {
        key: "radioPlayHandler",
        value: function(t, e) {
            var a = t.album.radioId, n = e._cache, r = n && n.source;
            r && r.album && r.album.programScheduleId === t.album.programScheduleId || d.radioPlayCount(a);
        }
    }, {
        key: "radioPlayStatistic",
        value: function(t, e) {
            var a = e._cache, n = a && a.source;
            if (this.judgeRadioPlay(n) && this.playInfo) {
                var r = n.album, o = r.radioId, i = r.programScheduleId, c = r.programId, s = this.playInfo[0].t || 0;
                if (0 === s) return;
                var l = Date.now(), h = {
                    radioId: o,
                    programScheduleId: i,
                    programId: c,
                    startedAt: s,
                    endedAt: l,
                    duration: Math.round((l - s) / 1e3),
                    breakSecond: Math.round(u(this.playInfo))
                };
                d.radioPlayStatistic(h);
            }
        }
    } ]), n;
}();

module.exports = s;