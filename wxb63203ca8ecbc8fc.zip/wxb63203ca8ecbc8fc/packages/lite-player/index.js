var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/utils/time"), a = require("./event"), r = require("../../common/utils/storage"), n = require("../../common/utils/hotNews"), i = require("./consts"), o = i.PlayMode, u = i.PlayState, s = require("./link-protector"), c = require("./audioPage"), l = require("./countLogger"), d = require("./errorHandler"), p = require("./player"), y = new p({
    plugins: [ new s.LinkProtector(), new c(), new l(), new d() ]
}), h = null;

function f() {}

function S() {
    var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, c = i.lifetimes || {}, l = i.attached || c.attached || f, d = i.detached || c.detached || f;
    l ? (delete i.attached, delete c.attached, delete i.detached, delete c.detached) : (l = f, 
    d = f);
    var p = {
        afterSourceChange: function(e) {
            this.setData({
                currentSource: e
            });
            var t = y.playlist(), a = (t.list, t.index, t.sort);
            (0, r.set)("_playTrack", {
                currentSource: e,
                sort: a
            });
        },
        firstPlay: function(e) {
            var t = e.duration || y.duration();
            this.setData({
                duration: t,
                durationStr: e.durationStr
            });
        },
        playStateChange: function(e, t, a) {
            var n = this.data.source || {
                id: this.data.trackId,
                src: this.data.src
            };
            ("item" !== this.data.type || y.isCurrentSource(n)) && this.setData({
                playState: e
            }), a && (0, r.set)("_playCurrentTime", a);
        },
        beforeSourceChange: function(e) {
            this.setData({
                source: e,
                durationStr: e.durationStr
            }), this.triggerEvent("beforeSourceChange", e), (0, n.setLocalPlayProgress)(this.data.currentSource, this.data.playPercent);
        },
        timeupdate: function(e) {
            var n = this.data.duration > 0 ? e / this.data.duration * 100 : 0;
            this.setData({
                currentTime: e,
                currentTimeStr: (0, t.parseTime)(e),
                playPercent: n
            }), a.EventBus.emit("sourceTimeUpdate", e), 0 != e && (0, r.set)("_playCurrentTime", e);
        },
        delayDurationUpdate: function(e, a) {
            0 === e && a === this.data.currentTimer || this.setData({
                currentTimer: a,
                delayDuration: e,
                delayDurationStr: (0, t.parseTime)(e)
            });
        },
        delayDurationEnded: function(e) {
            this.setData({
                currentTimer: 0,
                isDelayEnd: e
            });
        },
        auditionEnd: function() {
            wx.showToast({
                title: "试听已经结束",
                icon: "none"
            }), y.stop();
        },
        showAuditReject: function() {
            wx.showToast({
                icon: "none",
                title: "声音审核中，过会试试~"
            });
        },
        updateBreakSecond: function(e) {
            this.breakSecond = e;
        },
        updatePlayRate: function(e) {
            this.setData({
                currentSpeed: e
            }), (0, r.set)("_playRate", e);
        },
        trackCannotPlay: function(e) {
            var t = e.duration || y.duration();
            this.setData({
                currentSource: e,
                playState: u.ENDED,
                duration: t,
                currentTimeStr: "00:00",
                durationStr: e.durationStr,
                currentTime: 0
            });
            var a = y.playlist().sort;
            (0, r.set)("_playTrack", {
                currentSource: e,
                sort: a
            });
        },
        onCanplay: function(e) {
            console.log("onCanplay", e);
        }
    }, S = e(e({}, i), {}, {
        properties: e(e({}, i.properties), {}, {
            type: {
                type: String,
                value: "wrapper"
            },
            trackId: {
                type: Number,
                value: -1
            },
            src: {
                type: String,
                value: ""
            },
            source: {
                type: Object,
                value: null
            }
        }),
        data: e({
            playState: y.playState,
            PlayState: u,
            PlayMode: o,
            currentTime: 0,
            currentTimeStr: "00:00",
            duration: 0,
            durationStr: "00:00",
            playPercent: 0,
            currentSource: y.currentSource() || {},
            delayDuration: 0,
            delayDurationStr: "00:00",
            currentTimer: 0,
            currentSpeed: 1
        }, i.data),
        attached: function() {
            var e = this, a = this.data.source, n = y.currentSource(), i = n !== a ? 0 : y.currentTime(), o = a && a.duration || n && n.duration || 0, u = y.currentDelayTimer(), s = (0, 
            r.get)("_playRate") || 1, c = o > 0 ? i / o * 100 : 0;
            this.setData({
                playState: y.playState,
                currentTime: i,
                currentTimeStr: (0, t.parseTime)(i),
                duration: o,
                durationStr: (0, t.parseTime)(o),
                playPercent: c,
                title: (a ? a.title : n ? n.title : "") || "",
                currentSource: n,
                currentTimer: u,
                currentSpeed: s
            }), Object.keys(p).forEach(function(t) {
                var a = p[t];
                e[t] = a.bind(e);
            }), y.on("afterSourceChange", this.afterSourceChange), y.on("firstPlay", this.firstPlay), 
            y.on("playStateChange", this.playStateChange), y.on("beforeSourceChange", this.beforeSourceChange), 
            y.on("auditReject", this.showAuditReject), y.on("canplay", this.onCanplay), y.on("trackCannotPlay", this.trackCannotPlay), 
            "progress" !== this.data.type && "global" !== this.data.type || (console.log(this.data.type, "type++="), 
            y.on("timeupdate", this.timeupdate), y.on("delayDurationUpdate", this.delayDurationUpdate), 
            y.on("delayDurationEnded", this.delayDurationEnded), y.on("auditionEnd", this.auditionEnd), 
            y.on("updateBreakSecond", this.updateBreakSecond), y.on("playRateUpdate", this.updatePlayRate)), 
            h || (h = wx.getBackgroundAudioManager(), y.addManager(h));
            for (var d = arguments.length, f = new Array(d), S = 0; S < d; S++) f[S] = arguments[S];
            l.apply(this, f);
        },
        detached: function() {
            y.off("afterSourceChange", this.afterSourceChange), y.off("firstPlay", this.firstPlay), 
            y.off("playStateChange", this.playStateChange), y.off("beforeSourceChange", this.beforeSourceChange), 
            y.off("timeupdate", this.timeupdate), y.off("delayDurationUpdate", this.delayDurationUpdate), 
            y.off("auditionEnd", this.auditionEnd), y.off("auditReject", this.showAuditReject), 
            y.off("updateBreakSecond", this.updateBreakSecond), y.off("playRateUpdate", this.updatePlayRate), 
            y.off("canplay", this.onCanplay), y.off("trackCannotPlay", this.trackCannotPlay);
            for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
            d.apply(this, t);
        },
        methods: e(e({}, i.methods), {}, {
            onPlayBtnClicked: function() {
                "global" === this.data.type || "wrapper" === this.data.type ? this.play(this.data.currentSource) : this.play();
            },
            playRadio: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], a = y.isRadioCurrentSource(e), r = 0;
                if (a) {
                    var n = e.album, i = n.startTime, o = n.endTime, s = y.currentSource().album, c = s.startTime, l = s.endTime;
                    switch (i === c && o === l || y.justPlay(e), this.data.playState) {
                      case u.INITIAL:
                        y.play(e);
                        break;

                      case u.PAUSE:
                        y.resume();
                        break;

                      case u.ENDED:
                        y.replay(r);
                        break;

                      case u.PLAYING:
                        t && y.pause();
                    }
                } else y.play(e);
            },
            play: function(e) {
                if (e || (e = ("global" === this.data.type ? this.data.currentSource : this.data.source) || {
                    id: this.data.trackId,
                    src: this.data.src
                }), y.isCurrentSource(e)) switch (this.data.playState) {
                  case u.INITIAL:
                    y.play(e, {}, this.breakSecond);
                    break;

                  case u.PAUSE:
                    s.hasCanPlay(e) ? y.resume() : y.play(e, {}, this.breakSecond);
                    break;

                  case u.ENDED:
                    y.replay(this.breakSecond);
                    break;

                  case u.PLAYING:
                    y.pause();
                } else y.play(e, {}, this.breakSecond);
            },
            playNext: function() {
                y.playNext();
            },
            playPrev: function() {
                y.playPrev();
            },
            pause: function() {
                y.pause();
            },
            resume: function() {
                y.resume();
            },
            seek: function(e) {
                y.seek(e);
            },
            playlist: function() {
                return y.playlist.apply(y, arguments);
            },
            changeSort: function(e) {
                y.changeSort(e);
            },
            appendPlaylist: function() {
                y.appendPlaylist.apply(y, arguments);
            },
            prependPlaylist: function() {
                y.prependPlaylist.apply(y, arguments);
            },
            setIndex: function() {
                y.setIndex.apply(y, arguments);
            },
            playMode: function() {
                y.playMode.apply(y, arguments);
            },
            delayClose: function() {
                y.delayClose.apply(y, arguments);
            },
            delayCountClose: function() {
                y.delayCountClose.apply(y, arguments);
            },
            changePlayRate: function() {
                y.changePlayRate.apply(y, arguments);
            }
        })
    });
    return Object.assign({}, S);
}

S.Player = y, S.PlayState = u, module.exports = {
    createComponent: S,
    Player: p,
    PlayState: u,
    getCurrentPlayer: function() {
        return y;
    }
};