module.exports = {
    PlayState: {
        ERROR: -1,
        INITIAL: 0,
        PLAYING: 1,
        PAUSE: 2,
        ENDED: 3,
        LOADING: 4
    },
    PlayMode: {
        ORDERED: 0,
        RANDOM: 1,
        SINGLE_LOOP: 2,
        LIST_LOOP: 3,
        ERROR: -1
    },
    ErrorCode: {
        INFO: 0,
        NOSOURCE: 1
    },
    PlaySort: {
        ASC: !0,
        DESC: !1
    }
};