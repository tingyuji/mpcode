var e = require("../../@babel/runtime/helpers/classCallCheck"), r = require("../../@babel/runtime/helpers/createClass"), u = require("../../common/utils/index"), a = function() {
    function a() {
        e(this, a);
    }
    return r(a, [ {
        key: "apply",
        value: function(e) {
            e.on("setSource", function(e, r) {
                e.audioPage = (0, u.getBridgeAudioPage)("/pages/soundPage/soundPage?trackId=".concat(e.id)), 
                r(e);
            });
        }
    } ]), a;
}();

module.exports = a;