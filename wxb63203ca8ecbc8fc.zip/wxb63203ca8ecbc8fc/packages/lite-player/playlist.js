var t = require("../../@babel/runtime/helpers/classCallCheck"), i = require("../../@babel/runtime/helpers/createClass"), e = require("./consts").PlayMode, s = function() {
    function s() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = i.index, l = void 0 === n ? 0 : n, r = i.mode, h = void 0 === r ? e.ORDERED : r, a = i.list, o = void 0 === a ? [] : a, u = i.sort, c = i.total, d = void 0 === c ? 0 : c;
        t(this, s), this.list = o, this._list = o.concat(), this.mode = h, this.index = l, 
        this.sort = u, this.total = d, h === e.RANDOM && (this.list = this.shuffle(this.list));
    }
    return i(s, [ {
        key: "shuffle",
        value: function() {
            for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], i = t.length, e = Array(i), s = i; s--; ) {
                var n = Math.floor(Math.random() * (s + 1)), l = e[n];
                e[n] = e[s], e[s] = l;
            }
            return e;
        }
    }, {
        key: "setIndex",
        value: function(t) {
            this.index = t;
        }
    }, {
        key: "next",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i = this.list, s = void 0 === i ? [] : i, n = this.mode, l = this.index, r = this.total, h = s.length, a = null;
            switch (l++, n) {
              case e.ORDERED:
              case e.RANDOM:
                a = s[l];
                break;

              case e.LIST_LOOP:
                a = s[l % (r || h)];
                break;

              case e.SINGLE_LOOP:
                t ? l-- : l = l, a = s[l];
            }
            return this.index = l, a;
        }
    }, {
        key: "prev",
        value: function() {
            var t = this.list;
            return this.index > 0 ? t[--this.index] : null;
        }
    }, {
        key: "hasPrev",
        value: function() {
            return this.index > 0;
        }
    }, {
        key: "hasNext",
        value: function() {
            var t = this.list.length;
            return this.index < t;
        }
    }, {
        key: "includeInPlaylist",
        value: function(t) {
            return !!this.list.find(function(i) {
                return i.id === t.id || i.src === t.src;
            });
        }
    }, {
        key: "indexInPlaylist",
        value: function(t) {
            return this.list.findIndex(function(i) {
                return i.id === t.id || !!t.src && i.src === t.src;
            });
        }
    }, {
        key: "append",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], i = this.list, e = this._list;
            return i = i.concat(t), e = e.concat(t), this.list = i, this._list = e, this.list;
        }
    }, {
        key: "prepend",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], i = this.list, e = this._list;
            return i = t.concat(i), e = t.concat(e), this.list = i, this._list = e, this.list;
        }
    }, {
        key: "changeMode",
        value: function(t) {
            var i = this.list, s = this._list, n = this.mode;
            switch (t) {
              case e.RANDOM:
                this.mode = t, this.list = this.shuffle(i);
                break;

              case e.LIST_LOOP:
              case e.ORDERED:
              case e.SINGLE_LOOP:
                n === e.RANDOM && (this.list = s.concat()), this.mode = t;
            }
        }
    }, {
        key: "changeSort",
        value: function(t) {
            console.log("playlist changeSort", t, this), this.sort = t;
        }
    }, {
        key: "push",
        value: function(t) {}
    }, {
        key: "destroy",
        value: function() {
            console.log("destory playlist"), this.list = null;
        }
    } ]), s;
}();

module.exports = s;