var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/classCallCheck"), n = require("../../@babel/runtime/helpers/createClass"), i = require("../../@babel/runtime/helpers/typeof"), s = Number.isNaN || function(e) {
    return e != e;
}, a = function(e) {
    return e;
};

function o() {
    for (var e = [], t = this.target, r = this.type, n = this.fired, i = 0; i < arguments.length; i++) e.push(arguments[i]);
    n || (t.removeListener(r, this.wrapFn), this.fired = !0, this.listener.apply(t, e));
}

var u = function() {
    function s() {
        r(this, s), this.trigger = this.emit, this.on = this.addListener, this.off = this.removeListener, 
        void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), 
        this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
    }
    return n(s, [ {
        key: "emit",
        value: function() {
            for (var e = arguments.length, r = new Array(e), n = 0; n < e; n++) r[n] = arguments[n];
            var i = r.shift(), s = this._events, a = s[i];
            if (void 0 === a) return !1;
            if ("function" == typeof a && a.apply(this, r), Array.isArray(a)) {
                var o, u = t(a);
                try {
                    for (u.s(); !(o = u.n()).done; ) {
                        var l = o.value;
                        l.apply(this, r);
                    }
                } catch (e) {
                    u.e(e);
                } finally {
                    u.f();
                }
            }
            return !0;
        }
    }, {
        key: "emitRace",
        value: function() {
            var e = arguments, r = this, n = [].slice.call(arguments, 0), s = n.shift(), o = n.pop() || a, u = this._events, l = u[s] || [], f = [];
            if (Array.isArray(l)) f = f.concat(l); else {
                if ("function" != typeof l) throw new TypeError("event ".concat(s, "'s listener must be a type of Function. but now type is ").concat(i(l)));
                f.push(l);
            }
            var h = !1, v = function() {
                !1 === h && (h = !0, o.apply(r, e));
            };
            f.length < 1 && v(), n.push(v);
            var c, p = t(f);
            try {
                for (p.s(); !(c = p.n()).done; ) {
                    var y = c.value;
                    y.apply(this, n);
                }
            } catch (e) {
                p.e(e);
            } finally {
                p.f();
            }
        }
    }, {
        key: "emitAsyncParel",
        value: function() {
            var e, r = [].slice.call(arguments, 0), n = [], i = r.shift(), s = r.pop() || a, o = t(r);
            try {
                for (o.s(); !(e = o.n()).done; ) {
                    var u = e.value;
                    Array.isArray(u) ? n = n.concat(u) : n.push(u);
                }
            } catch (e) {
                o.e(e);
            } finally {
                o.f();
            }
            var l = this._events, f = l[i], h = [];
            if ("function" == typeof f) h.push(f); else if (Array.isArray(f)) {
                var v, c = t(f);
                try {
                    for (c.s(); !(v = c.n()).done; ) {
                        var p = v.value;
                        h.push(p);
                    }
                } catch (e) {
                    c.e(e);
                } finally {
                    c.f();
                }
            }
            h.length < 1 && s.apply(this, n), n.push(function() {
                h.length || s.apply(void 0, arguments);
            });
            for (var y = h.length, d = 0; d < y; d++) {
                var b = h.shift();
                b.apply(this, n);
            }
        }
    }, {
        key: "emitAsyncSerialWaterfall",
        value: function() {
            var r, n = this, i = [].slice.call(arguments, 0), s = [], o = 0, u = i.shift(), l = i.pop() || a, f = t(i);
            try {
                for (f.s(); !(r = f.n()).done; ) {
                    var h = r.value;
                    Array.isArray(h) ? s = s.concat(h) : s.push(h);
                }
            } catch (e) {
                f.e(e);
            } finally {
                f.f();
            }
            var v = this._events, c = v[u], p = [];
            if ("function" == typeof c) p.push(c); else if (Array.isArray(c)) {
                var y, d = t(c);
                try {
                    for (d.s(); !(y = d.n()).done; ) {
                        var b = y.value;
                        p.push(b);
                    }
                } catch (e) {
                    d.e(e);
                } finally {
                    d.f();
                }
            }
            var m = function t(r) {
                var a = p[o];
                if (!a) return l.apply(void 0, e(i));
                0 === o ? (o++, a.apply(n, [].concat(e(s), [ t ]))) : (o++, a.apply(n, [ r, t ]));
            };
            m();
        }
    }, {
        key: "addListener",
        value: function(e, t) {
            return function(e, t, r) {
                var n, s, a = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                if ("function" != typeof r) throw new TypeError("listener must be a type of Function. received type:" + i(r));
                return void 0 === (n = e._events) ? (n = e._events = Object.create(null), e._eventsCount = 0) : s = n[t], 
                void 0 === s ? (s = n[t] = r, e._eventsCount++) : "function" == typeof s ? s = n[t] = a ? [ r, s ] : [ s, r ] : a ? s.unshift(r) : s.push(r), 
                e;
            }(this, e, t);
        }
    }, {
        key: "once",
        value: function(e, t) {
            if ("function" != typeof t) throw new TypeError("once function listener must be a type of Function. received type::" + i(t));
            return this.on(e, function(e, t, r) {
                var n = {
                    target: e,
                    type: t,
                    listener: r,
                    fired: !1,
                    wrapFn: void 0
                }, i = o.bind(n);
                return i.listener = r, n.wrapFn = i, i;
            }(this, e, t)), this;
        }
    }, {
        key: "removeListener",
        value: function(e, t) {
            if ("function" != typeof t) throw new TypeError("removeListener listener must be a type of function received type::" + i(t));
            var r = this._events;
            if (void 0 === r) return !1;
            var n = r[e];
            if (!n || n !== t && n.listener !== t) {
                if (Array.isArray(n)) {
                    for (var s = -1, a = 0; a < n.length; a++) if (n[a] === t || n[a].listener === t) {
                        s = a;
                        break;
                    }
                    if (s < 0) return this;
                    0 === s ? n.shift() : n.splice(s, 1), 1 === n.length && (r[e] = n[0]);
                }
            } else this._eventsCount--, 0 === this._eventsCount ? this._events = Object.create(null) : delete this._events[e];
            return this;
        }
    }, {
        key: "removeAllListeners",
        value: function(e) {
            var t = this._events;
            return void 0 === e ? (this._events = Object.create(null), this._eventsCount = 0, 
            this) : (void 0 === t[e] || delete t[e], this);
        }
    } ]), s;
}(), l = 15;

Object.defineProperty(u, "defaultMaxListeners", {
    enumerable: !0,
    get: function() {
        return l;
    },
    set: function(e) {
        if ("number" != typeof e || e < 0 || s(e)) throw new RangeError("defaultMaxListeners is out of range");
        l = e;
    }
}), module.exports = {
    Event: u,
    EventBus: new u()
};