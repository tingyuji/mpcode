var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.mpParse = o;

var r = require("../../common/utils/env"), t = e(require("./html2json.js"));

function o() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : '<div class="color:red;">数据不能为空</div>';
    if (!r.isMy) return e;
    try {
        var o = (0, t.default)(e) || {}, i = o.children, u = void 0 === i ? [] : i;
        return u;
    } catch (e) {
        return console.log(e), [];
    }
}

var i = o;

exports.default = i;