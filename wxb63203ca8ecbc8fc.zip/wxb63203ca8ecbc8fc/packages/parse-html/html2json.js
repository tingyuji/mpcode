var e = require("../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("./htmlParser"));

var n = function(e) {
    e = function(e) {
        return e.replace(/<\?xml.*\?>\n/, "").replace(/<!doctype.*\>\n/, "").replace(/<!DOCTYPE.*\>\n/, "");
    }(e);
    var n = [], t = {
        node: "root",
        children: []
    };
    return (0, r.default)(e, {
        start: function(e, r, i) {
            var l = {
                name: e
            };
            if (0 !== r.length && (l.attrs = r.reduce(function(e, r) {
                var n = r.name, t = r.value;
                return t.match(/ /) && (t = t.split(" ")), t instanceof Array && (t = t.reduce(function(e, r) {
                    return e + r;
                })), e[n] ? e[n] = e[n] + t : e[n] = t, e;
            }, {})), i) {
                var c = n[0] || t;
                void 0 === c.children && (c.children = []), c.children.push(l);
            } else n.unshift(l);
        },
        end: function(e) {
            var r = n.shift();
            if (r.tag, 0 === n.length) t.children.push(r); else {
                var i = n[0];
                void 0 === i.children && (i.children = []), i.children.push(r);
            }
        },
        chars: function(e) {
            var r = {
                type: "text",
                text: e
            };
            if (0 === n.length) t.children.push(r); else {
                var i = n[0];
                void 0 === i.children && (i.children = []), i.children.push(r);
            }
        },
        comment: function(e) {
            var r = {
                type: "text",
                text: e
            }, t = n[0];
            void 0 === t.children && (t.children = []), t.children.push(r);
        }
    }), t;
};

exports.default = n;