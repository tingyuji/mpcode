Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = "<([-A-Za-z0-9_]+)((?:\\s+[a-zA-Z_:][-a-zA-Z0-9_:.]*(?:\\s*=\\s*(?:(?:\"[^\"]*\")|(?:'[^']*')|[^>\\s]+))?)*)\\s*(\\/?)>", a = "(".concat(e, ")|(").concat("</([-A-Za-z0-9_]+)[^>]*>", ")"), r = new RegExp(e), t = new RegExp("</([-A-Za-z0-9_]+)[^>]*>"), i = new RegExp(a), s = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g, l = f("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr"), o = f("a,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video"), c = f("abbr,acronym,applet,b,basefont,bdo,big,br,button,cite,code,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,const"), n = f("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr"), u = f("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected"), d = f("script,style"), p = f("a,abbr,b,blockquote,br,code,col,colgroup,dd,del,div,dl,dt,em,fieldset,h1,h2,h3,h4,h5,h6,hr,i,img,ins,label,legend,li,ol,p,q,span,strong,sub,sup,table,tbody,td,tfoot,th,thead,tr,ul"), h = f("class,style"), m = {
    col: f("span,width"),
    colgroup: f("span,width"),
    img: f("alt,src,height,width"),
    ol: f("start,type"),
    table: f("width"),
    td: f("colspan,height,rowspan,width"),
    th: f("colspan,height,rowspan,width")
}, g = /&quot;|&#039;|&lt;|&gt;|&nbsp;|&iexcl;|&cent;|&pound;|&curren;|&yen;|&brvbar;|&sect;|&uml;|&copy;|&ordf;|&laquo;|&not;|&shy;|&reg;|&macr;|&deg;|&plusmn;|&sup2;|&sup3;|&acute;|&micro;|&para;|&middot;|&cedil;|&sup1;|&ordm;|&raquo;|&frac14;|&frac12;|&frac34;|&iquest;|&Agrave;|&Aacute;|&Acirc;|&Atilde;|&Auml;|&Aring;|&AElig;|&Ccedil;|&Egrave;|&Eacute;|&Ecirc;|&Euml;|&Igrave;|&Iacute;|&Icirc;|&Iuml;|&ETH;|&Ntilde;|&Ograve;|&Oacute;|&Ocirc;|&Otilde;|&Ouml;|&times;|&Oslash;|&Ugrave;|&Uacute;|&Ucirc;|&Uuml;|&Yacute;|&THORN;|&szlig;|&agrave;|&aacute;|&acirc;|&atilde;|&auml;|&aring;|&aelig;|&ccedil;|&egrave;|&eacute;|&ecirc;|&euml;|&igrave;|&iacute;|&icirc;|&iuml;|&eth;|&ntilde;|&ograve;|&oacute;|&ocirc;|&otilde;|&ouml;|&divide;|&oslash;|&ugrave;|&uacute;|&ucirc;|&uuml;|&yacute;|&thorn;|&yuml;|&OElig;|&oelig;|&Scaron;|&scaron;|&Yuml;|&fnof;|&circ;|&tilde;|&Alpha;|&Beta;|&Gamma;|&Delta;|&Epsilon;|&Zeta;|&Eta;|&Theta;|&Iota;|&Kappa;|&Lambda;|&Mu;|&Nu;|&Xi;|&Omicron;|&Pi;|&Rho;|&Sigma;|&Tau;|&Upsilon;|&Phi;|&Chi;|&Psi;|&Omega;|&alpha;|&beta;|&gamma;|&delta;|&epsilon;|&zeta;|&eta;|&theta;|&iota;|&kappa;|&lambda;|&mu;|&nu;|&xi;|&omicron;|&pi;|&rho;|&sigmaf;|&sigma;|&tau;|&upsilon;|&phi;|&chi;|&psi;|&omega;|&upsih;|&piv;|&ensp;|&emsp;|&thinsp;|&zwnj;|&zwj;|&lrm;|&rlm;|&ndash;|&mdash;|&lsquo;|&rsquo;|&sbquo;|&ldquo;|&rdquo;|&bdquo;|&dagger;|&Dagger;|&bull;|&hellip;|&permil;|&prime;|&Prime;|&lsaquo;|&rsaquo;|&oline;|&frasl;|&euro;|&image;|&weierp;|&real;|&trade;|&alefsym;|&larr;|&uarr;|&rarr;|&darr;|&harr;|&crarr;|&lArr;|&uArr;|&rArr;|&dArr;|&hArr;|&forall;|&part;|&exist;|&empty;|&nabla;|&isin;|&notin;|&ni;|&prod;|&sum;|&minus;|&lowast;|&radic;|&prop;|&infin;|&ang;|&and;|&or;|&cap;|&cup;|&int;|&there4;|&sim;|&cong;|&asymp;|&ne;|&equiv;|&le;|&ge;|&sub;|&sup;|&nsub;|&sube;|&supe;|&oplus;|&otimes;|&perp;|&sdot;|&lceil;|&rceil;|&lfloor;|&rfloor;|&lang;|&rang;|&loz;|&spades;|&clubs;|&hearts;|&diams;/g;

function f(e) {
    for (var a = {}, r = e.split(","), t = 0; t < r.length; t++) a[r[t]] = !0;
    return a;
}

var b = function(e, a) {
    var f, b, v, A = [], w = e;
    for (A.last = function() {
        return this[this.length - 1];
    }, e = e.replace(g, " "); e; ) {
        if (b = !0, !A.last() || !d[A.last()] && 0 !== e.indexOf("<<")) {
            if (0 === e.indexOf("\x3c!--")) (f = e.indexOf("--\x3e")) >= 0 && (e = e.substring(f + 3), 
            b = !1); else if (0 === e.indexOf("<")) {
                var x = 0 === e.search(r), q = 0 === e.search(t);
                if (x || q) {
                    var y = x ? r : t, O = x ? z : k;
                    v = e.match(y), e = e.substring(v[0].length), v[0].replace(y, O), b = !1;
                }
            }
            if (b) {
                var E = (f = e.search(i)) < 0 ? e : e.substring(0, f);
                e = f < 0 ? "" : e.substring(f), a.chars && a.chars(E);
            }
        } else e = e.replace(new RegExp("([\\s\\S]*?)</" + A.last() + "[^>]*>"), function(e, r) {
            return r = r.replace(/<!--([\s\S]*?)-->|<!\[CDATA\[([\s\S]*?)]]>/g, "$1$2"), a.chars && a.chars(r), 
            "";
        }), k("", A.last());
        if (e === w) throw "Parse Error: " + e;
        w = e;
    }
    function z(e, r, t, i) {
        if (r = r.toLowerCase(), p[r] || k("", r = "div"), o[r]) for (;A.last() && c[A.last()]; ) k("", A.last());
        if (n[r] && A.last() === r && k("", r), (i = l[r] || !!i) || A.push(r), a.start) {
            var d = [];
            t.replace(s, function(e, a) {
                var t = arguments[2] ? arguments[2] : arguments[3] ? arguments[3] : arguments[4] ? arguments[4] : u[a] ? a : "";
                (h[a] || m[r] && m[r][a]) && d.push({
                    name: a,
                    value: t
                });
            }), a.start && a.start(r, d, i);
        }
    }
    function k(e, r) {
        var t;
        if (r) for (t = A.length - 1; t >= 0 && A[t] !== r; t--) ; else t = 0;
        if (t >= 0) {
            for (var i = A.length - 1; i >= t; i--) a.end && a.end(A[i]);
            A.length = t;
        }
    }
    k();
};

exports.default = b;