var e = require("../@babel/runtime/helpers/typeof");

!function(r) {
    if ("object" === ("undefined" == typeof exports ? "undefined" : e(exports)) && "undefined" != typeof module) module.exports = r(); else if ("function" == typeof define && define.amd) define([], r); else {
        ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).Qs = r();
    }
}(function() {
    return function e(r, t, o) {
        function n(a, l) {
            if (!t[a]) {
                if (!r[a]) {
                    var c = "function" == typeof require && require;
                    if (!l && c) return c(a, !0);
                    if (i) return i(a, !0);
                    var s = new Error("Cannot find module '" + a + "'");
                    throw s.code = "MODULE_NOT_FOUND", s;
                }
                var f = t[a] = {
                    exports: {}
                };
                r[a][0].call(f.exports, function(e) {
                    return n(r[a][1][e] || e);
                }, f, f.exports, e, r, t, o);
            }
            return t[a].exports;
        }
        for (var i = "function" == typeof require && require, a = 0; a < o.length; a++) n(o[a]);
        return n;
    }({
        1: [ function(e, r, t) {
            var o = String.prototype.replace, n = /%20/g, i = e("./utils"), a = {
                RFC1738: "RFC1738",
                RFC3986: "RFC3986"
            };
            r.exports = i.assign({
                default: a.RFC3986,
                formatters: {
                    RFC1738: function(e) {
                        return o.call(e, n, "+");
                    },
                    RFC3986: function(e) {
                        return String(e);
                    }
                }
            }, a);
        }, {
            "./utils": 5
        } ],
        2: [ function(e, r, t) {
            var o = e("./stringify"), n = e("./parse"), i = e("./formats");
            r.exports = {
                formats: i,
                parse: n,
                stringify: o
            };
        }, {
            "./formats": 1,
            "./parse": 3,
            "./stringify": 4
        } ],
        3: [ function(e, r, t) {
            var o = e("./utils"), n = Object.prototype.hasOwnProperty, i = {
                allowDots: !1,
                allowPrototypes: !1,
                arrayLimit: 20,
                charset: "utf-8",
                charsetSentinel: !1,
                comma: !1,
                decoder: o.decode,
                delimiter: "&",
                depth: 5,
                ignoreQueryPrefix: !1,
                interpretNumericEntities: !1,
                parameterLimit: 1e3,
                parseArrays: !0,
                plainObjects: !1,
                strictNullHandling: !1
            }, a = function(e) {
                return e.replace(/&#(\d+);/g, function(e, r) {
                    return String.fromCharCode(parseInt(r, 10));
                });
            }, l = function(e, r, t) {
                if (e) {
                    var o = t.allowDots ? e.replace(/\.([^.[]+)/g, "[$1]") : e, i = /(\[[^[\]]*])/g, a = t.depth > 0 && /(\[[^[\]]*])/.exec(o), l = a ? o.slice(0, a.index) : o, c = [];
                    if (l) {
                        if (!t.plainObjects && n.call(Object.prototype, l) && !t.allowPrototypes) return;
                        c.push(l);
                    }
                    for (var s = 0; t.depth > 0 && null !== (a = i.exec(o)) && s < t.depth; ) {
                        if (s += 1, !t.plainObjects && n.call(Object.prototype, a[1].slice(1, -1)) && !t.allowPrototypes) return;
                        c.push(a[1]);
                    }
                    return a && c.push("[" + o.slice(a.index) + "]"), function(e, r, t) {
                        for (var o = r, n = e.length - 1; n >= 0; --n) {
                            var i, a = e[n];
                            if ("[]" === a && t.parseArrays) i = [].concat(o); else {
                                i = t.plainObjects ? Object.create(null) : {};
                                var l = "[" === a.charAt(0) && "]" === a.charAt(a.length - 1) ? a.slice(1, -1) : a, c = parseInt(l, 10);
                                t.parseArrays || "" !== l ? !isNaN(c) && a !== l && String(c) === l && c >= 0 && t.parseArrays && c <= t.arrayLimit ? (i = [])[c] = o : i[l] = o : i = {
                                    0: o
                                };
                            }
                            o = i;
                        }
                        return o;
                    }(c, r, t);
                }
            };
            r.exports = function(e, r) {
                var t = function(e) {
                    if (!e) return i;
                    if (null !== e.decoder && void 0 !== e.decoder && "function" != typeof e.decoder) throw new TypeError("Decoder has to be a function.");
                    if (void 0 !== e.charset && "utf-8" !== e.charset && "iso-8859-1" !== e.charset) throw new Error("The charset option must be either utf-8, iso-8859-1, or undefined");
                    var r = void 0 === e.charset ? i.charset : e.charset;
                    return {
                        allowDots: void 0 === e.allowDots ? i.allowDots : !!e.allowDots,
                        allowPrototypes: "boolean" == typeof e.allowPrototypes ? e.allowPrototypes : i.allowPrototypes,
                        arrayLimit: "number" == typeof e.arrayLimit ? e.arrayLimit : i.arrayLimit,
                        charset: r,
                        charsetSentinel: "boolean" == typeof e.charsetSentinel ? e.charsetSentinel : i.charsetSentinel,
                        comma: "boolean" == typeof e.comma ? e.comma : i.comma,
                        decoder: "function" == typeof e.decoder ? e.decoder : i.decoder,
                        delimiter: "string" == typeof e.delimiter || o.isRegExp(e.delimiter) ? e.delimiter : i.delimiter,
                        depth: "number" == typeof e.depth || !1 === e.depth ? +e.depth : i.depth,
                        ignoreQueryPrefix: !0 === e.ignoreQueryPrefix,
                        interpretNumericEntities: "boolean" == typeof e.interpretNumericEntities ? e.interpretNumericEntities : i.interpretNumericEntities,
                        parameterLimit: "number" == typeof e.parameterLimit ? e.parameterLimit : i.parameterLimit,
                        parseArrays: !1 !== e.parseArrays,
                        plainObjects: "boolean" == typeof e.plainObjects ? e.plainObjects : i.plainObjects,
                        strictNullHandling: "boolean" == typeof e.strictNullHandling ? e.strictNullHandling : i.strictNullHandling
                    };
                }(r);
                if ("" === e || null == e) return t.plainObjects ? Object.create(null) : {};
                for (var c = "string" == typeof e ? function(e, r) {
                    var t, l = {}, c = r.ignoreQueryPrefix ? e.replace(/^\?/, "") : e, s = r.parameterLimit === 1 / 0 ? void 0 : r.parameterLimit, f = c.split(r.delimiter, s), u = -1, p = r.charset;
                    if (r.charsetSentinel) for (t = 0; t < f.length; ++t) 0 === f[t].indexOf("utf8=") && ("utf8=%E2%9C%93" === f[t] ? p = "utf-8" : "utf8=%26%2310003%3B" === f[t] && (p = "iso-8859-1"), 
                    u = t, t = f.length);
                    for (t = 0; t < f.length; ++t) if (t !== u) {
                        var d, y, m = f[t], h = m.indexOf("]="), b = -1 === h ? m.indexOf("=") : h + 1;
                        -1 === b ? (d = r.decoder(m, i.decoder, p), y = r.strictNullHandling ? null : "") : (d = r.decoder(m.slice(0, b), i.decoder, p), 
                        y = r.decoder(m.slice(b + 1), i.decoder, p)), y && r.interpretNumericEntities && "iso-8859-1" === p && (y = a(y)), 
                        y && r.comma && y.indexOf(",") > -1 && (y = y.split(",")), n.call(l, d) ? l[d] = o.combine(l[d], y) : l[d] = y;
                    }
                    return l;
                }(e, t) : e, s = t.plainObjects ? Object.create(null) : {}, f = Object.keys(c), u = 0; u < f.length; ++u) {
                    var p = f[u], d = l(p, c[p], t);
                    s = o.merge(s, d, t);
                }
                return o.compact(s);
            };
        }, {
            "./utils": 5
        } ],
        4: [ function(r, t, o) {
            var n = r("./utils"), i = r("./formats"), a = Object.prototype.hasOwnProperty, l = {
                brackets: function(e) {
                    return e + "[]";
                },
                comma: "comma",
                indices: function(e, r) {
                    return e + "[" + r + "]";
                },
                repeat: function(e) {
                    return e;
                }
            }, c = Array.isArray, s = Array.prototype.push, f = function(e, r) {
                s.apply(e, c(r) ? r : [ r ]);
            }, u = Date.prototype.toISOString, p = i.default, d = {
                addQueryPrefix: !1,
                allowDots: !1,
                charset: "utf-8",
                charsetSentinel: !1,
                delimiter: "&",
                encode: !0,
                encoder: n.encode,
                encodeValuesOnly: !1,
                format: p,
                formatter: i.formatters[p],
                indices: !1,
                serializeDate: function(e) {
                    return u.call(e);
                },
                skipNulls: !1,
                strictNullHandling: !1
            }, y = function r(t, o, i, a, l, s, u, p, y, m, h, b, g) {
                var v, O = t;
                if ("function" == typeof u ? O = u(o, O) : O instanceof Date ? O = m(O) : "comma" === i && c(O) && (O = O.join(",")), 
                null === O) {
                    if (a) return s && !b ? s(o, d.encoder, g) : o;
                    O = "";
                }
                if ("string" == typeof (v = O) || "number" == typeof v || "boolean" == typeof v || "symbol" === e(v) || "bigint" == typeof v || n.isBuffer(O)) return s ? [ h(b ? o : s(o, d.encoder, g)) + "=" + h(s(O, d.encoder, g)) ] : [ h(o) + "=" + h(String(O)) ];
                var j, w = [];
                if (void 0 === O) return w;
                if (c(u)) j = u; else {
                    var x = Object.keys(O);
                    j = p ? x.sort(p) : x;
                }
                for (var N = 0; N < j.length; ++N) {
                    var S = j[N];
                    l && null === O[S] || (c(O) ? f(w, r(O[S], "function" == typeof i ? i(o, S) : o, i, a, l, s, u, p, y, m, h, b, g)) : f(w, r(O[S], o + (y ? "." + S : "[" + S + "]"), i, a, l, s, u, p, y, m, h, b, g)));
                }
                return w;
            };
            t.exports = function(r, t) {
                var o, n = r, s = function(e) {
                    if (!e) return d;
                    if (null !== e.encoder && void 0 !== e.encoder && "function" != typeof e.encoder) throw new TypeError("Encoder has to be a function.");
                    var r = e.charset || d.charset;
                    if (void 0 !== e.charset && "utf-8" !== e.charset && "iso-8859-1" !== e.charset) throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
                    var t = i.default;
                    if (void 0 !== e.format) {
                        if (!a.call(i.formatters, e.format)) throw new TypeError("Unknown format option provided.");
                        t = e.format;
                    }
                    var o = i.formatters[t], n = d.filter;
                    return ("function" == typeof e.filter || c(e.filter)) && (n = e.filter), {
                        addQueryPrefix: "boolean" == typeof e.addQueryPrefix ? e.addQueryPrefix : d.addQueryPrefix,
                        allowDots: void 0 === e.allowDots ? d.allowDots : !!e.allowDots,
                        charset: r,
                        charsetSentinel: "boolean" == typeof e.charsetSentinel ? e.charsetSentinel : d.charsetSentinel,
                        delimiter: void 0 === e.delimiter ? d.delimiter : e.delimiter,
                        encode: "boolean" == typeof e.encode ? e.encode : d.encode,
                        encoder: "function" == typeof e.encoder ? e.encoder : d.encoder,
                        encodeValuesOnly: "boolean" == typeof e.encodeValuesOnly ? e.encodeValuesOnly : d.encodeValuesOnly,
                        filter: n,
                        formatter: o,
                        serializeDate: "function" == typeof e.serializeDate ? e.serializeDate : d.serializeDate,
                        skipNulls: "boolean" == typeof e.skipNulls ? e.skipNulls : d.skipNulls,
                        sort: "function" == typeof e.sort ? e.sort : null,
                        strictNullHandling: "boolean" == typeof e.strictNullHandling ? e.strictNullHandling : d.strictNullHandling
                    };
                }(t);
                "function" == typeof s.filter ? n = (0, s.filter)("", n) : c(s.filter) && (o = s.filter);
                var u, p = [];
                if ("object" !== e(n) || null === n) return "";
                u = t && t.arrayFormat in l ? t.arrayFormat : t && "indices" in t ? t.indices ? "indices" : "repeat" : "indices";
                var m = l[u];
                o || (o = Object.keys(n)), s.sort && o.sort(s.sort);
                for (var h = 0; h < o.length; ++h) {
                    var b = o[h];
                    s.skipNulls && null === n[b] || f(p, y(n[b], b, m, s.strictNullHandling, s.skipNulls, s.encode ? s.encoder : null, s.filter, s.sort, s.allowDots, s.serializeDate, s.formatter, s.encodeValuesOnly, s.charset));
                }
                var g = p.join(s.delimiter), v = !0 === s.addQueryPrefix ? "?" : "";
                return s.charsetSentinel && ("iso-8859-1" === s.charset ? v += "utf8=%26%2310003%3B&" : v += "utf8=%E2%9C%93&"), 
                g.length > 0 ? v + g : "";
            };
        }, {
            "./formats": 1,
            "./utils": 5
        } ],
        5: [ function(r, t, o) {
            var n = Object.prototype.hasOwnProperty, i = Array.isArray, a = function() {
                for (var e = [], r = 0; r < 256; ++r) e.push("%" + ((r < 16 ? "0" : "") + r.toString(16)).toUpperCase());
                return e;
            }(), l = function(e, r) {
                for (var t = r && r.plainObjects ? Object.create(null) : {}, o = 0; o < e.length; ++o) void 0 !== e[o] && (t[o] = e[o]);
                return t;
            };
            t.exports = {
                arrayToObject: l,
                assign: function(e, r) {
                    return Object.keys(r).reduce(function(e, t) {
                        return e[t] = r[t], e;
                    }, e);
                },
                combine: function(e, r) {
                    return [].concat(e, r);
                },
                compact: function(r) {
                    for (var t = [ {
                        obj: {
                            o: r
                        },
                        prop: "o"
                    } ], o = [], n = 0; n < t.length; ++n) for (var a = t[n], l = a.obj[a.prop], c = Object.keys(l), s = 0; s < c.length; ++s) {
                        var f = c[s], u = l[f];
                        "object" === e(u) && null !== u && -1 === o.indexOf(u) && (t.push({
                            obj: l,
                            prop: f
                        }), o.push(u));
                    }
                    return function(e) {
                        for (;e.length > 1; ) {
                            var r = e.pop(), t = r.obj[r.prop];
                            if (i(t)) {
                                for (var o = [], n = 0; n < t.length; ++n) void 0 !== t[n] && o.push(t[n]);
                                r.obj[r.prop] = o;
                            }
                        }
                    }(t), r;
                },
                decode: function(e, r, t) {
                    var o = e.replace(/\+/g, " ");
                    if ("iso-8859-1" === t) return o.replace(/%[0-9a-f]{2}/gi, unescape);
                    try {
                        return decodeURIComponent(o);
                    } catch (e) {
                        return o;
                    }
                },
                encode: function(r, t, o) {
                    if (0 === r.length) return r;
                    var n = r;
                    if ("symbol" === e(r) ? n = Symbol.prototype.toString.call(r) : "string" != typeof r && (n = String(r)), 
                    "iso-8859-1" === o) return escape(n).replace(/%u[0-9a-f]{4}/gi, function(e) {
                        return "%26%23" + parseInt(e.slice(2), 16) + "%3B";
                    });
                    for (var i = "", l = 0; l < n.length; ++l) {
                        var c = n.charCodeAt(l);
                        45 === c || 46 === c || 95 === c || 126 === c || c >= 48 && c <= 57 || c >= 65 && c <= 90 || c >= 97 && c <= 122 ? i += n.charAt(l) : c < 128 ? i += a[c] : c < 2048 ? i += a[192 | c >> 6] + a[128 | 63 & c] : c < 55296 || c >= 57344 ? i += a[224 | c >> 12] + a[128 | c >> 6 & 63] + a[128 | 63 & c] : (l += 1, 
                        c = 65536 + ((1023 & c) << 10 | 1023 & n.charCodeAt(l)), i += a[240 | c >> 18] + a[128 | c >> 12 & 63] + a[128 | c >> 6 & 63] + a[128 | 63 & c]);
                    }
                    return i;
                },
                isBuffer: function(r) {
                    return !(!r || "object" !== e(r)) && !!(r.constructor && r.constructor.isBuffer && r.constructor.isBuffer(r));
                },
                isRegExp: function(e) {
                    return "[object RegExp]" === Object.prototype.toString.call(e);
                },
                merge: function r(t, o, a) {
                    if (!o) return t;
                    if ("object" !== e(o)) {
                        if (i(t)) t.push(o); else {
                            if (!t || "object" !== e(t)) return [ t, o ];
                            (a && (a.plainObjects || a.allowPrototypes) || !n.call(Object.prototype, o)) && (t[o] = !0);
                        }
                        return t;
                    }
                    if (!t || "object" !== e(t)) return [ t ].concat(o);
                    var c = t;
                    return i(t) && !i(o) && (c = l(t, a)), i(t) && i(o) ? (o.forEach(function(o, i) {
                        if (n.call(t, i)) {
                            var l = t[i];
                            l && "object" === e(l) && o && "object" === e(o) ? t[i] = r(l, o, a) : t.push(o);
                        } else t[i] = o;
                    }), t) : Object.keys(o).reduce(function(e, t) {
                        var i = o[t];
                        return n.call(e, t) ? e[t] = r(e[t], i, a) : e[t] = i, e;
                    }, c);
                }
            };
        }, {} ]
    }, {}, [ 2 ])(2);
});