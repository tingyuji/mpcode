var e = require("../../packages/lite-player/event"), s = require("../../common/utils/storage");

Component({
    properties: {
        infos: {
            type: Object,
            value: {}
        },
        arrowDirection: {
            type: String,
            value: ""
        },
        positions: {
            type: String,
            value: ""
        }
    },
    data: {
        modalVisible: !1
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        e.EventBus.on("showShareBubble", this._show), e.EventBus.on("closeShareBubble", this._close);
    },
    detached: function() {
        e.EventBus.off("showShareBubble", this._show), e.EventBus.off("closeShareBubble", this._close);
    },
    methods: {
        showModal: function() {
            (0, s.get)("show_bubble") && this.setData({
                modalVisible: !0
            });
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1
            });
        },
        close: function() {
            e.EventBus.emit("closeShareBubble");
        },
        closeBubble: function() {
            (0, s.set)("show_bubble", "false"), this.close();
        }
    }
});