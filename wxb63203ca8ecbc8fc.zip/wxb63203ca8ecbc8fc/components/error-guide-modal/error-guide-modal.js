var e = require("../../packages/lite-player/event"), o = require("../../common/utils/index"), t = require("../../common/utils/logger");

Component({
    data: {
        visible: !1
    },
    attached: function() {
        this._showModal = this.showModal.bind(this), this._close = this.close.bind(this), 
        e.EventBus.on("showErrorGuide", this._showModal), e.EventBus.on("closeErrorGuide", this._close);
    },
    detached: function() {
        this.closeModal(), e.EventBus.off("showErrorGuide", this._showModal), e.EventBus.off("closeErrorGuide", this._close);
    },
    pageLifetimes: {
        hide: function() {
            this.closeModal();
        }
    },
    methods: {
        close: function() {
            this.setData({
                visible: !1
            });
        },
        closeModal: function() {
            e.EventBus.emit("closeErrorGuide");
        },
        closeTry: function() {
            var e = new Date().toLocaleDateString();
            (0, o.set)("play_error_tried", e), (0, t.genLoggerClick)(27214, "", {
                currPage: "overall"
            }), this.closeModal(), wx.showToast({
                title: "已收到反馈，我们会尽力排查原因",
                icon: "none"
            });
        },
        showModal: function() {
            var e = new Date().toLocaleDateString();
            (0, o.get)("play_error_tried") !== e && ((0, t.genLogger)(27199, "slipPage", {
                currPage: "overall"
            }), this.setData({
                visible: !0
            }));
        },
        toGuide: function() {
            this.closeModal(), (0, t.genLoggerClick)(27200, "", {
                currPage: "overall"
            }), wx.navigateTo({
                url: "/subpackage/pages/errorguide/index"
            });
        }
    }
});