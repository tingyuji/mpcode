var e = require("../../common/utils/index");

Component({
    properties: {
        modalVisible: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    pageLifetimes: {
        hide: function() {
            this.close();
        }
    },
    attached: function() {},
    detached: function() {},
    methods: {
        close: function() {
            (0, e.set)("SUBSCRIBE_REMIND_SHOWED", !0), this.triggerEvent("closeSubModal");
        },
        catchTouch: function() {},
        catchClose: function() {}
    }
});