var e = require("../../common/utils/index"), t = require("../../common/utils/logger");

Component({
    properties: {
        trackId: {
            type: Number,
            value: 0
        },
        albumId: {
            type: Number,
            value: 0
        },
        currentSource: {
            type: Object,
            value: {}
        }
    },
    data: {
        show: !0,
        listenedInfo: {}
    },
    attached: function() {},
    detached: function() {},
    pageLifetimes: {
        show: function() {
            var t = (0, e.getListenedAlbums)() || [], a = this.data, n = a.albumId, o = a.currentSource, u = t.find(function(e) {
                return Number(e.albumId) === Number(n);
            }), r = o.album && o.album.id;
            u && r !== n && (console.log("==========listenedInfo==========", u), this.setData({
                listenedInfo: u
            }));
        }
    },
    methods: {
        goTrack: function() {
            var e = this.data, a = e.listenedInfo, n = e.albumId;
            (0, t.genLogger)(26320, "click", {
                currPageId: n,
                currPage: "album"
            }), wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(a.id, "&breakSecond=").concat(a.breakSecond)
            });
        },
        close: function() {
            this.setData({
                show: !1
            });
        }
    }
});