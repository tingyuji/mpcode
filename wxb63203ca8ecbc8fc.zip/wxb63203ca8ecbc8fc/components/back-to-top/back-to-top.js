Component({
    properties: {
        style: String
    },
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {
        toTop: function() {
            wx.pageScrollTo && wx.pageScrollTo({
                scrollTop: 0
            });
        }
    }
});