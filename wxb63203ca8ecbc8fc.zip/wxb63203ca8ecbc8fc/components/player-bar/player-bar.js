var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../packages/lite-player/event"), i = require("../../common/utils/storage"), r = require("../../common/utils/logger"), a = require("../../common/utils/wxSubscribe"), n = require("../../common/utils/navBar"), s = require("../../common/utils/index"), o = require("../../common/apis/track"), c = require("../../packages/lite-player/index").createComponent, u = Math.abs((0, 
n.getTabBarHeight)());

Component(c({
    properties: {
        selfStyle: {
            type: String,
            value: ""
        },
        addBottomHeight: {
            type: Number,
            value: 0
        }
    },
    data: {
        mPlayerVisible: !1,
        playerVisible: !0,
        defaultImgSource: "https://imagev2.xmcdn.com/group61/M01/57/F1/wKgMcF1D2W-S6tE2AAADUIJ3rgc368.png",
        isLiked: !1,
        tabbarHeight: (0, s.isIPhoneX)() ? 100 : (0, n.isAndroid)() ? u : u + 15
    },
    attached: function() {
        this.sourceChangeBind = this.sourceChange.bind(this), this.refeshListBind = this.refeshList.bind(this), 
        this.toggleMiniBind = this.toggleMini.bind(this), this.init(), t.EventBus.on("refreshPlayList", this.refeshListBind), 
        t.EventBus.on("setPlayerBarMiniVisible", this.toggleMiniBind), c.Player.on("afterSourceChange", this.sourceChangeBind), 
        (0, r.genLogger)(17115, "exposure", {});
    },
    detached: function() {
        t.EventBus.off("refreshPlayList", this.refeshListBind), t.EventBus.off("setPlayerBarMiniVisible", this.toggleMiniBind), 
        c.Player.off("afterSourceChange", this.sourceChangeBind);
    },
    pageLifetimes: {
        show: function() {
            this.init();
        },
        hide: function() {}
    },
    methods: {
        init: function() {
            this.initPlayer(), this.initTrackIsLiked();
            var i = this.data.currentSource, r = i.cover, a = i.title, n = i.id, s = i.album;
            n && t.EventBus.emit("globalPlayerShare", e(e({}, this.data.currentSource), {}, {
                title: a,
                imageUrl: r || this.data.defaultImgSource,
                path: s && s.jumpUrl || ""
            }));
        },
        initPlayer: function() {
            var e = this.data;
            if (e.playState !== e.PlayState.PLAYING) {
                var t = ((0, i.get)("_playTrack") || {}).currentSource, r = void 0 === t ? {} : t, a = (0, 
                i.get)("_playCurrentTime");
                if (!r || !r.src) return;
                this.breakSecond = a, this.setData({
                    currentSource: r,
                    playPercent: a / r.duration * 100
                });
            }
        },
        setTrackList: function(e, t) {
            var i = this;
            e.id && (0, o.queryRelativeTracks)(e.id, 10, 10, t).then(function(e) {
                i.playlist(e);
            });
        },
        onTitleClicked: function() {
            (0, a.addSubCount)("全局播放器点击声音标题"), (0, r.genLogger)(25672, "click", {});
            var e = this.data.currentSource, t = (e = void 0 === e ? {} : e).id, i = e.album, n = (i = void 0 === i ? {} : i).jumpUrl, s = void 0 === n ? "" : n;
            t && s && s.length && wx.navigateTo({
                url: "".concat(s, "&breakSecond=").concat(this.breakSecond)
            });
        },
        imageError: function(e) {
            console.log(e);
            var t = this.data.currentSource;
            t.cover;
            t.cover = "", this.setData({
                currentSource: t
            });
        },
        _onPlayBtnClicked: function() {
            (0, a.addSubCount)("全局播放器点击播放按钮");
            var e = this.data, n = e.playState, s = e.PlayState;
            if ((0, r.genLogger)(25671, "click", {
                item: n === s.PLAYING ? "暂停" : "播放"
            }), this.breakSecond && t.EventBus.emit("updateBreakSecond", this.breakSecond), 
            this.onPlayBtnClicked(), this.breakSecond = 0, !this.playlist().list) {
                var o = ((0, i.get)("_playTrack") || {}).sort;
                this.setTrackList(this.data.currentSource, o);
            }
        },
        _playNext: function() {
            (0, r.genLogger)(30060, "click", {
                currPage: "overall"
            }), this.playNext();
        },
        initTrackIsLiked: function() {
            var e = this, t = this.data.currentSource.id;
            t && !isNaN(Number(t)) && (0, o.isTrackLiked)(t).then(function(t) {
                return e.setData({
                    isLiked: t
                });
            });
        },
        toggleLike: function() {
            var e = this;
            if ((0, i.checkLogin)()) {
                var t = this.data.currentSource.id, a = function() {
                    e.setData({
                        isLiked: !e.data.isLiked
                    }, function() {
                        e.data.isLiked && wx.showToast({
                            title: "已喜欢\n可在【我的-喜欢】中找到",
                            icon: "none"
                        });
                    });
                };
                this.data.isLiked ? (0, o.dislikeTrack)(t).then(a) : ((0, o.likeTrack)(t).then(a), 
                (0, r.genLogger)(18060, "click", {
                    trackId: t
                }));
            }
        },
        sourceChange: function(i) {
            var r = i.cover, a = i.title, n = i.album.jumpUrl, s = void 0 === n ? "" : n;
            t.EventBus.emit("globalPlayerShare", e(e({}, i), {}, {
                title: a,
                imageUrl: r || this.data.defaultImgSource,
                path: s
            })), this.initTrackIsLiked();
        },
        toShare: function() {
            var e = this.data.currentSource.id;
            (0, r.genLogger)(18061, "click", {
                trackId: e
            });
        },
        refeshList: function(e) {
            if (e) {
                var t = this.playlist().list, i = void 0 === t ? [] : t, r = i.findIndex(function(t) {
                    return t.id === e;
                });
                if (r > -1) {
                    var a = i[r];
                    a.isLock = !1, a.userPermission = !0, a.needPay = !1, i[r] = a, this.playlist(i);
                }
            }
        },
        toggleMini: function(e) {
            this.setData({
                mPlayerVisible: e
            });
        }
    }
}));