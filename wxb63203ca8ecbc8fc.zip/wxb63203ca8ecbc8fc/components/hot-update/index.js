var t = require("../../common/utils/index"), e = require("../../common/utils/logger"), i = require("../../common/apis/hotsale");

Component({
    data: {
        title: "",
        subtitle: "",
        albumList: []
    },
    pageLifetimes: {
        show: function() {}
    },
    attached: function() {
        this.init();
    },
    detached: function() {},
    methods: {
        init: function() {
            var t = this;
            (0, i.queryFlushUpdate)().then(function(e) {
                var i = e.title, a = e.subtitle, u = e.albumList;
                t.setData({
                    title: i,
                    subtitle: a,
                    albumList: u
                });
            });
        },
        toAlbum: function(i) {
            var a = (0, t.getDataset)(i).id;
            a && (wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(a)
            }), (0, e.genLogger)(28693, "click", {}));
        }
    }
});