var o = require("../../packages/lite-player/event"), s = require("../../common/utils/index");

Component({
    properties: {},
    options: {},
    data: {
        modalVisible: !1,
        info: {
            content: ""
        }
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        o.EventBus.on("showKnowModal", this._show), o.EventBus.on("closeKnowModal", this._close);
    },
    detached: function() {
        o.EventBus.off("showKnowModal", this._show), o.EventBus.off("closeKnowModal", this._close);
    },
    methods: {
        showModal: (0, s.debounce)(function(o) {
            var s = o.info;
            this.setData({
                info: s,
                modalVisible: !0
            });
        }),
        close: function() {
            o.EventBus.emit("closeKnowModal", {});
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1
            });
        }
    }
});