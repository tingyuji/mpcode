Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        wrapperStyle: {
            type: String,
            value: ""
        }
    },
    addGlobalClass: !0,
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {
        close: function() {
            this.triggerEvent("closeModal", {});
        },
        catchTouch: function() {},
        catchClose: function() {}
    }
});