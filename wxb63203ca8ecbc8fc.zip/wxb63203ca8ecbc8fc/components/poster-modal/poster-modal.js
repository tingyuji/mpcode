require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../packages/lite-player/event"), t = require("../../common/utils/genPoster"), o = require("../../common/apis/mineapi"), n = require("../../common/apis/qrcode"), a = require("../../common/utils/toast"), i = require("../../common/utils/logger"), s = require("../../common/utils/storage"), c = {};

Component({
    properties: {
        trackInfo: {
            type: Object,
            value: {}
        },
        albumInfo: {
            type: Object,
            value: {}
        },
        pageType: {
            type: String,
            value: ""
        },
        id: {
            type: String,
            value: {}
        }
    },
    data: {
        modalVisible: !1,
        canvasH: 0,
        canvasW: 0,
        path: "",
        showSaveBtn: !1,
        currentPage: ""
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        e.EventBus.on("showPosterBox", this._show), e.EventBus.on("closePosterBox", this._close);
    },
    detached: function() {
        e.EventBus.off("showPosterBox", this._show), e.EventBus.off("closePosterBox", this._close);
    },
    methods: {
        showModal: function(e) {
            var t = this;
            this.pageFix(!0), this.setData({
                modalVisible: !0,
                currentPage: e
            }), wx.showLoading({
                title: "图片正在生成中"
            }), this.getUserInfo(function() {
                t.drawPoster();
            });
        },
        close: function() {
            e.EventBus.emit("closePosterBox");
        },
        closeModal: function() {
            this.setData({
                path: "",
                showSaveBtn: !1
            }), this.pageFix(!1), this.setData({
                modalVisible: !1
            });
        },
        catchTouch: function() {},
        catchClose: function() {},
        pageFix: function(t) {
            var o = this.data.pageType;
            "album" === o && e.EventBus.emit("fixAlbumPage", t), "track" === o && e.EventBus.emit("fixTrackPage", t);
        },
        genQrCode: function(e, t) {
            var o = this.data, a = o.pageType, i = o.albumInfo, s = o.trackInfo;
            (0, n.getQrCode)({
                scene: "track" === a ? s.id + ",fromqrposter" : i.id + ",fromqrposter",
                page: "track" === a ? "pages/soundPage/soundPage" : "pages/albumDetail/albumDetail"
            }).then(function(o) {
                "string" == typeof o && o.includes("http") && "function" == typeof e ? e(o) : "function" == typeof t && t(o);
            });
        },
        savePoster: function() {
            var t = this.data.path;
            (0, i.genLoggerClick)(17856, "XX", {
                currPage: "overall"
            }), wx.authorize({
                scope: "scope.writePhotosAlbum",
                success: function() {
                    wx.saveImageToPhotosAlbum({
                        filePath: t,
                        success: function(e) {
                            console.log(e, "poster"), (0, a.showLongToast)({
                                title: "保存成功，可以去发朋友圈啦～",
                                icon: "none"
                            });
                        },
                        fail: function(e) {
                            console.log(e), (0, a.showLongToast)({
                                title: "您未开启【微信】访问相册的权限，请在手机设置中开启",
                                icon: "none"
                            });
                        },
                        complete: function() {
                            e.EventBus.emit("closePosterBox");
                        }
                    });
                },
                fail: function() {
                    e.EventBus.emit("closePosterBox"), e.EventBus.emit("showSettingTip");
                }
            });
        },
        drawPoster: function() {
            var e = this;
            this.getImageTempPath(function(o) {
                var n = e;
                (0, t.getImageInfoAndInitCanvas)().then(function(a) {
                    var i = a.canvasH, s = a.canvasW;
                    n.setData({
                        canvasH: i,
                        canvasW: s
                    });
                    var r = e.data, u = (r.id, r.albumInfo), l = r.trackInfo, f = r.pageType, h = wx.createCanvasContext("poster", e);
                    (0, t.createPoster)(h, a, c, {
                        scene: "track" === f ? l.id : u.id,
                        page: "track" === f ? "pages/soundPage/soundPage" : "pages/albumDetail/albumDetail",
                        albumInfo: u,
                        trackInfo: l
                    }), (0, t.qrCodeDraw)(h, a, o, e, function(e) {
                        var t = e.tempFilePath;
                        n.setData({
                            path: t,
                            showSaveBtn: !0
                        }, function() {
                            wx.hideLoading();
                        });
                    });
                });
            }, function(t) {
                e.setData({
                    modalVisible: !1
                });
            }), setTimeout(function() {
                wx.hideLoading();
            }, 5e3);
        },
        getUserInfo: function(e) {
            var t = (0, s.getUid)();
            if (!t) return e(), c = {};
            (0, o.queryUserInfo)({
                uid: t
            }).then(function(t) {
                c = t, "function" == typeof e && e();
            });
        },
        getImageTempPath: function(e, o) {
            var n = this.data, a = n.albumInfo.cover, i = n.trackInfo.cover, s = n.pageType, r = c.cover;
            this.genQrCode(function(o) {
                return Promise.all([ (0, t.downloadFile)(o), (0, t.downloadFile)(r || "https://imagev2.xmcdn.com/group61/M0A/7C/F3/wKgMZl0wBcnxgorbAABWZX_GLtM979.jpg"), (0, 
                t.downloadFile)("track" === s ? i : a) ]).then(function(t) {
                    "function" == typeof e && t.length > 0 && e(t);
                });
            }, function(e) {
                "function" == typeof o && o(e);
            });
        }
    }
});