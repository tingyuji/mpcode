var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/apis/home"), a = require("../../common/utils/index"), i = require("../../common/utils/logger"), o = require("../../packages/lite-player/event"), r = {
    page: wx.navigateTo,
    tabPage: wx.switchTab,
    app: wx.navigateToMiniProgram
};

Component({
    properties: {
        style: String
    },
    data: {
        show: !1,
        adClosed: (0, a.getTodayAdClosed)(),
        adInfo: {}
    },
    attached: function() {
        var i = this, o = (0, a.getCurrentRoute)();
        (0, t.getExAdWidgetSetting)().then(function(t) {
            var r = t.displayPage;
            r && r.indexOf(o) > -1 && i.setData({
                show: !0,
                adInfo: e(e({}, t), {}, {
                    imageSrc: (0, a.fillImageUrl)(t.imageSrc)
                })
            });
        });
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {
            this.setData({
                adClosed: (0, a.getTodayAdClosed)()
            });
        }
    },
    methods: {
        clickAd: function(t) {
            var n = (0, a.getCurrentRoute)(), d = (0, a.getDataset)(t), s = d.id, g = d.path;
            (0, i.genLogger)(19509, "click", {
                currPage: n
            });
            var p = this.data.adInfo, u = (p = void 0 === p ? {} : p).navigateType, c = p.pagePath, l = p.popupEvent;
            if ("popup" !== u) {
                var h = "app" === u ? {
                    appId: s,
                    path: g
                } : {
                    url: c
                };
                r[u](e({}, h));
            } else o.EventBus.emit(l, {
                route: n
            });
        },
        closeAd: function() {
            (0, a.getTodayAdClosed)(!0), this.setData({
                show: !1
            });
        }
    }
});