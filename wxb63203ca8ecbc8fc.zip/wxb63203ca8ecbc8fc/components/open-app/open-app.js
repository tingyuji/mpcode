var t = require("../../common/utils/copyCode"), e = require("../../common/utils/index"), n = require("../../common/utils/logger"), o = require("../../common/utils/myAdapter"), a = require("../../common/utils/navBar"), i = require("../../common/apis/open-app");

Component({
    properties: {
        schema: String,
        type: String,
        title: String,
        showBottomOpenApp: Boolean,
        pageId: Number
    },
    addGlobalClass: !0,
    timer: null,
    modalContent: [],
    data: {
        isInScene: !1,
        isIos: (0, a.isIos)(),
        xmcdn: (0, e.xmcdnImg)()
    },
    created: function() {},
    attached: function() {
        this.canShare(), this.setData({
            srcPage: this.getCurrentPageUrl()
        }), this.loadModalUI();
    },
    ready: function() {},
    detached: function() {},
    methods: {
        canShare: function() {
            this.setData({
                isInScene: (0, t.canOpenApp)()
            });
        },
        loadModalUI: function() {
            var t = this;
            (0, i.queryOpenAppContent)().then(function(e) {
                return t.modalContent = e;
            });
        },
        getCurrentPageUrl: function() {
            var t = (0, e.getCurrPage)();
            return (0, e.getUrl)(t.options, t.route);
        },
        onOpenApp: function(e) {
            var n = (0, o.getDataset)(e).size, a = this.data, i = a.type, r = a.schema, s = this.getCurrentPageUrl();
            this.openType = n, (0, t.copyCode)({
                srcPage: s,
                type: i,
                schema: r
            }, this.log_openapp.bind(this));
        },
        launchAppError: function(t) {
            this.filterContent("fail");
        },
        launchAppSuccess: function(t) {
            this.data.isIos || this.filterContent("success");
        },
        filterContent: function(t) {
            var e = this.data.pageId, o = (this.modalContent.filter(function(e) {
                return e.launchStatus === t;
            }) || [])[0] || {};
            this.setData({
                customerModalVisible: !0,
                customerModalTitle: o.title,
                customerModalSubtitle: o.subtitle,
                customerModalImg: o.tipImg,
                customerModalStatus: t
            }), (0, n.genLogger)(17372, "exposure", {
                currPageId: e,
                type: "success" == t ? "成功" : "失败"
            });
        },
        closeModal: function() {
            this.setData({
                customerModalVisible: !1
            });
        },
        handleContact: function(t) {
            var e = this.data, o = e.customerModalStatus, a = e.pageId;
            (0, n.genLogger)(17373, "click", {
                currPageId: a,
                type: "success" == o ? "成功" : "失败"
            });
        },
        log_openapp: function(t) {
            var e = this.data.pageId;
            (0, n.genLogger)("mini" === this.openType ? 17346 : 17345, "click", {
                currPageId: e,
                sharecmd: t
            });
        }
    }
});