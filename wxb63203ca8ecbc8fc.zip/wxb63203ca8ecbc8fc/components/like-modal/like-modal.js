var o = require("../../packages/lite-player/event"), s = require("../../common/utils/index");

Component({
    properties: {},
    data: {
        modalVisible: !1,
        info: {}
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        o.EventBus.on("showFavModal", this._show), o.EventBus.on("closeFavModal", this._close);
    },
    detached: function() {
        o.EventBus.off("showFavModal", this._show), o.EventBus.off("closeFavModal", this._close);
    },
    methods: {
        showModal: (0, s.debounce)(function(o) {
            var s = o.info;
            this.setData({
                info: s,
                modalVisible: !0
            });
        }),
        close: function() {
            o.EventBus.emit("closeFavModal");
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1
            });
        },
        closeShare: function() {
            this.close();
        }
    }
});