var i = require("../../common/utils/storage"), e = require("../../common/utils/logger"), o = require("../../packages/lite-player/event");

Component({
    attached: function() {
        var e = wx.getSystemInfoSync().platform;
        this.setData({
            isAndroid: "android" == e,
            isLogin: (0, i.isLogin)()
        });
    },
    properties: {
        isVip: Boolean
    },
    data: {
        isAndroid: !1,
        isLogin: !1
    },
    methods: {
        joinVip: function() {
            o.EventBus.emit("openGModal", {
                vipModal: {
                    visible: !0
                }
            }), (0, e.clickVipBar)();
        }
    }
});