var t = require("../../common/utils/time");

Component({
    properties: {
        remain: {
            type: Number,
            value: 0,
            observer: function(t, e) {
                t !== e && this.init();
            }
        }
    },
    data: {
        dateObj: {}
    },
    attached: function() {},
    pageLifetimes: {},
    methods: {
        init: function() {
            var e = this.data.remain;
            if (e < 0) return null;
            var i = (0, t.parseTimeStamp)(e), a = i.d, n = i.h, r = i.m;
            console.log("d", a, n, r), this.setData({
                dateObj: {
                    d: a,
                    h: n,
                    m: r
                }
            });
        }
    }
});