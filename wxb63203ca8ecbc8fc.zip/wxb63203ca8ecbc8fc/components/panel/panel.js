Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        showClose: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    attached: function() {
        console.log(this.data, "----data-----");
    },
    detached: function() {},
    methods: {
        close: function() {
            this.triggerEvent("closePanel", {});
        },
        catchClose: function(e) {}
    }
});