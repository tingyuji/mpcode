var e = require("../../common/utils/index"), t = require("../../common/utils/storage");

Component({
    properties: {
        modalVisible: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isiOS: !1
    },
    attached: function() {
        var e = wx.getSystemInfoSync().platform;
        this.setData({
            isiOS: "ios" == e
        });
    },
    detached: function() {},
    methods: {
        close: function() {
            this.triggerEvent("toggleModal", {}), (0, t.set)("upgrade_showed", !0);
        },
        toPaid: function() {
            this.close(), (0, e.safeSwitchTab)({
                url: "/pages/paid/paid"
            });
        },
        toMine: function() {
            this.close(), (0, e.safeSwitchTab)({
                url: "/pages/mine/mine"
            });
        },
        toPointsCenter: function() {
            this.close(), wx.navigateTo({
                url: "/pages/pointscenter/pointscenter"
            });
        }
    }
});