var t = require("../../packages/lite-player/index").createComponent;

Component(t({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        timerList: [ {
            content: "不开启",
            duration: null
        }, {
            content: "10分钟后",
            duration: 600
        }, {
            content: "20分钟后",
            duration: 1200
        }, {
            content: "30分钟后",
            duration: 1800
        }, {
            content: "60分钟后",
            duration: 3600
        }, {
            content: "90分钟后",
            duration: 5400
        } ]
    },
    attached: function() {
        console.log(this.data, "----data-----");
    },
    methods: {
        closeTimer: function() {
            this.triggerEvent("toggleTimer", {});
        },
        changeTimer: function(t) {
            var e = t.currentTarget.dataset, n = e.timer, i = e.index, a = this.data, r = (a.currentTime, 
            a.currentTimer), o = (a.source, a.delayDuration), c = a.playState, s = a.PlayState;
            if (i === r && o || c !== s.PAUSE && c !== s.PLAYING) return this.closeTimer();
            0 === i ? this.delayClose() : this.delayClose(n.duration, !0, i), this.closeTimer();
        }
    }
}));