Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.filterVipStr = function(e) {
    return e.map(function(e) {
        return e.name && (e.name = e.name.replace("VIP会员", "")), e;
    });
}, exports.isCanBuyVip = function(e) {
    return 3 === e.vipStatus || e.expireDays / 365 < 3;
}, exports.parseAutoRenewVip = function(e) {
    return e.map(function(e) {
        return {
            itemId: e.itemId,
            name: e.name,
            description: e.description,
            unitPrice: e.unitPrice,
            autoRenew: e.autoRenew,
            canEnjoyPromotion: e.canEnjoyPromotion,
            subUnitPrice: e.subVipProduct ? e.subVipProduct.unitPrice : e.unitPrice
        };
    });
}, exports.showVipCannotBuyModal = function() {
    wx.showModal({
        content: "掐指一算，您剩余会员有效期已超过3年，不宜继续购买了~",
        showCancel: !1,
        confirmText: "我知道了",
        confirmColor: "#F24821"
    });
};