Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initState = void 0;

exports.initState = {
    currentBuyIndex: 0,
    currentBuyType: "all",
    currentVipIndex: 0,
    currentVipAmount: 0
};