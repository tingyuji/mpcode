var t = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../packages/lite-player/event"), e = require("../../common/apis/paid"), o = require("../../common/apis/album"), a = (require("../../common/apis/point"), 
require("../../common/utils/index")), n = require("../../common/utils/storage"), s = require("../../common/utils/navBar"), l = require("../../common/utils/logger"), u = require("../../common/utils/copyCode"), c = require("./utils/const"), r = require("./utils/index"), d = require("../../packages/lite-player/index").createComponent;

Component(d({
    data: t(t({}, c.initState), {}, {
        vipProducts: [],
        tipModal: {},
        buyModal: {},
        vipModal: {},
        pointModal: {},
        priceInfo: {},
        isIos: (0, s.isIos)(),
        jumpToAlbum: !1
    }),
    attached: function() {
        this.route = (0, a.getCurrentRoute)(), this._init = this.init.bind(this), this._close = this.hideModal.bind(this), 
        i.EventBus.on("openGModal", this._init), i.EventBus.on("hideGModal", this._close);
    },
    detached: function() {
        this.closeModal(), i.EventBus.off("openGModal", this._init), i.EventBus.off("hideGModal", this._close);
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {
            this.closeModal();
        }
    },
    methods: {
        init: function(t) {
            if (this.route === (0, a.getCurrentRoute)()) {
                var i = t.buyModal, e = void 0 === i ? {} : i, o = t.vipModal, n = void 0 === o ? {} : o, s = t.tipModal, l = void 0 === s ? {} : s, c = t.pointModal, r = void 0 === c ? {} : c;
                l.visible && l.albumId && (this.data.isIos && (0, u.copyCodeByEvent)("stjs"), this.tipModal_getBtns(l), 
                this.log_tip_show({
                    trackId: l.trackId
                })), n.visible && this.vipModal_getVipList(), e.visible && e.trackId && this.buyModal_getPriceList(e), 
                r.visible && this.pointModal_showPanel(r);
            }
        },
        preventTouchMove: function() {},
        hideModal: function() {
            this.setData({
                tipModal: t(t({}, this.data.tipModal), {}, {
                    visible: !1
                }),
                buyModal: t(t({}, this.data.buyModal), {}, {
                    visible: !1
                }),
                vipModal: t(t({}, this.data.vipModal), {}, {
                    visible: !1
                }),
                pointModal: t(t({}, this.data.pointModal), {}, {
                    visible: !1
                })
            });
        },
        closeModal: function() {
            i.EventBus.emit("hideGModal");
        },
        isCanBuy: function() {
            return !!(0, n.isLogin)() || (this.closeModal(), wx.navigateTo({
                url: "/pages/login/login"
            }), !1);
        },
        tipModal_getBtns: function(t) {
            var i = this, e = t.albumId, a = t.trackId, n = t.tip, s = t.title, l = t.trackTitle;
            (0, o.getAlbumInfo)(e).then(function(t) {
                var u = t.albumInfo, c = t.albumXimiVipPayType, r = u.isPaid, d = u.albumPayType, p = u.albumVipPayType, h = u.discountedPrice, g = u.isVipFirst;
                3 === u.type && (0, o.getAlbumActivityInfo)(e).then(function(t) {
                    var e = t.couponInfo.list, o = void 0 === e ? [] : e;
                    if (o.length > 0) if (i.data.isIos) {
                        var a = 0 === o[0].usingCouponPrice;
                        i.setData({
                            jumpToAlbum: a
                        });
                    } else console.log("训练营 else"), i.setData({
                        jumpToAlbum: !0
                    });
                }), i.setData({
                    tipModal: {
                        tip: n,
                        title: s,
                        trackId: a,
                        trackTitle: l,
                        visible: !0
                    },
                    priceInfo: {
                        albumId: e,
                        isPaid: r,
                        discountedPrice: h,
                        isVIPZX: 1 == p,
                        isVIPCT: 2 == p,
                        isXiMiOnly: 1 === c,
                        unitPrice: 1 == d ? "喜点/集" : 2 == d ? "喜点" : "",
                        isVipFirst: g,
                        isAlbumFree: d <= 0 && p <= 0 && !r
                    }
                });
            }), this.pointModal_reloadPanel(a, !1);
        },
        tipModal_toPaid: function() {
            var t = this.data.priceInfo || {}, i = t.discountedPrice, e = t.unitPrice, o = this.data.tipModal.trackId;
            this.log_tip_click({
                trackId: o,
                item: "付费购买"
            }), this.isCanBuy() && (0 != Number(i) ? "喜点/集" == e ? this.tipModal_singleBuy() : this.tipModal_allBuy() : wx.showToast({
                title: "没有可购买的声音",
                icon: "none"
            }));
        },
        tipModal_toVip: function() {
            var t = this.data.tipModal.trackId;
            console.log(this.data), this.log_tip_click({
                trackId: t,
                item: "购VIP"
            }), this.isCanBuy() && i.EventBus.emit("openGModal", {
                vipModal: {
                    visible: !0
                }
            });
        },
        tipModal_singleBuy: function() {
            var t = this.data.tipModal, e = t.trackId, o = t.title;
            this.closeModal(), i.EventBus.emit("openGModal", {
                buyModal: {
                    visible: !0,
                    trackId: e,
                    title: o
                }
            });
        },
        tipModal_allBuy: function() {
            var t = this.data.priceInfo, i = t.unitPrice, e = t.isVIPCT, o = t.isVIPZX, a = t.albumId, n = "喜点/集" == i, s = !(!e && !o);
            this.closeModal(), wx.navigateTo({
                url: "/pages/settlement/settlement?albumId=".concat(a, "&isSingleAllBuy=").concat(n, "&isVipAlbum=").concat(s)
            });
        },
        tipModal_toAlbum: function() {
            var t = "pages/albumDetail/albumDetail", i = (0, a.getCurrentRoute)();
            if ((0, l.genLogger)(33742, "click", {
                currPage: i
            }), (0, a.getCurrentRoute)() === t) return this.closeModal();
            var e = this.data.priceInfo.albumId;
            wx.navigateTo({
                url: "/".concat(t, "?albumId=").concat(e)
            });
        },
        buyModal_getPriceList: function(i) {
            var o = this, a = i.trackId;
            (0, e.queryTrackPayList)(a).then(function() {
                var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                o.setData(t(t({}, c.initState), {}, {
                    buyModal: t({
                        trackId: a,
                        visible: !0
                    }, i.vo)
                }));
            }), this.pointModal_reloadPanel(a, !1);
        },
        buyModal_choosePaidType: function(t) {
            var i = t.currentTarget.dataset, e = i.index, o = i.type, a = i.count;
            this.setData({
                currentBuyIndex: e,
                currentBuyType: o,
                currentBuyCount: a
            });
        },
        buyModal_buyNow: function() {
            "all" != this.data.currentBuyType ? "batch" != this.data.currentBuyType ? ("vip" == this.data.currentBuyType && (this.closeModal(), 
            i.EventBus.emit("openGModal", {
                vipModal: {
                    visible: !0
                }
            })), "point" == this.data.currentBuyType && this.pointModal_unlockTrack()) : 0 == this.data.currentBuyIndex ? this.buyModal_buyCurrent() : this.buyModal_buyTracks() : this.buyModal_buyAll();
        },
        buyModal_buyAll: function() {
            var t = this.data.buyModal, i = t.albumId, e = t.isVipFreeAlbum;
            this.closeModal(), wx.navigateTo({
                url: "/pages/settlement/settlement?albumId=".concat(i, "&isSingleAllBuy=", !0, "&isVipAlbum=").concat(e)
            });
        },
        buyModal_buyCurrent: function() {
            var t = this.data.buyModal, i = t.albumId, e = t.isVipFreeAlbum, o = t.quickTrackBuyItems, a = (void 0 === o ? [] : o)[0].trackIds[0];
            this.closeModal(), wx.navigateTo({
                url: "/pages/settlement/settlement?trackId=".concat(a, "&albumId=").concat(i, "&isVipAlbum=").concat(e)
            });
        },
        buyModal_buyTracks: function() {
            var t = this.data.currentBuyCount, i = this.data.buyModal, e = i.albumId, o = i.isVipFreeAlbum, a = i.quickTrackBuyItems, n = (void 0 === a ? [] : a)[0].trackIds[0];
            this.closeModal(), wx.navigateTo({
                url: "/pages/settlement/settlement?trackId=".concat(n, "&albumId=").concat(e, "&isVipAlbum=").concat(o, "&tracksCount=").concat(t)
            });
        },
        vipModal_getVipList: function() {
            var i = this;
            (0, e.queryVipBuyList)().then(function(e) {
                var o = (e || {}).data, n = o.vipProducts, s = void 0 === n ? [] : n, l = o.unionVipProducts, u = void 0 === l ? [] : l, d = o.autoRenewVipProducts, p = void 0 === d ? [] : d, h = o.isAutoRenew, g = void 0 !== h && h, v = ((0, 
                r.parseAutoRenewVip)(p), g ? s : (0, a.crossMergeArr)([], s) || []);
                console.log(v, "连续订阅vip======="), i.setData(t(t({}, c.initState), {}, {
                    vipModal: {
                        visible: !0
                    },
                    vipProducts: (0, r.filterVipStr)(v),
                    unionVipProducts: u,
                    currentVipAmount: v[0].canEnjoyPromotion ? v[0].subUnitPrice : v[0].unitPrice,
                    currentVipProductId: v[0].itemId
                }));
            }), this.log_vip_show();
        },
        vipModal_chooseVipType: function(t) {
            var i = t.currentTarget.dataset, e = i.index, o = i.amount, a = i.id;
            this.setData({
                currentVipIndex: e,
                currentVipAmount: o,
                currentVipProductId: a
            }), this.log_vip_click();
        },
        vipModal_buyAll: function() {
            if (this.closeModal(), this.isCanBuy()) {
                var t = this.data, i = t.vipProducts, o = t.currentVipIndex, a = t.currentVipProductId, n = t.currentVipAmount;
                (0, e.queryVipBasicInfo)().then(function(t) {
                    var e = t || {}, s = e.data, l = void 0 === s ? {} : s, u = (e.ret, l.userVipInfoVo), c = void 0 === u ? {} : u;
                    if (!(0, r.isCanBuyVip)(c)) return (0, r.showVipCannotBuyModal)();
                    o >= i.length ? wx.navigateTo({
                        url: "/subpackage/pages/unionvip/index?itemId=".concat(a)
                    }) : o < i.length && wx.navigateTo({
                        url: "/pages/settlement/settlement?isBuyVip=true&vipProductId=".concat(a, "&isAutoRenew=").concat(i[o].autoRenew, "&unitPrice=").concat(n)
                    });
                });
            }
        },
        goVipChannelPage: function() {
            this.data.currentVipProductId;
            this.closeModal(), wx.navigateTo({
                url: "/pages/vipchannel/vipchannel"
            });
        },
        pointModal_showPanel: function(t) {
            wx.showToast({
                title: "由于ios相关规范，请到喜马拉雅APP收听",
                icon: "none"
            });
        },
        pointModal_reloadPanel: function(t) {},
        pointModal_unlockTrack: function() {
            var t = this.data.pointModal, i = t.trackId;
            t.currentPoint, t.priceForPoint, t.isExceedMaxExchangeTime;
            this.log_tip_click({
                trackId: i,
                item: "积分解锁"
            }), this.isCanBuy() && this.closeModal();
        },
        pointModal_toTrackPage: function() {
            var t = this.data.pointModal.trackId, i = (0, a.getCurrPage)();
            i && "pages/soundPage/soundPage" === i.route ? this.closeModal() : wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(t)
            });
        },
        log_tip_show: function(t) {
            var i = t.trackId;
            (0, l.genLogger)(17116, "exposure", {
                trackId: i
            });
        },
        log_tip_click: function(t) {
            var i = t.trackId, e = t.item;
            (0, l.genLogger)(17117, "click", {
                trackId: i,
                item: e
            });
        },
        log_lock_success: function(t) {
            var i = t.trackId, e = t.albumId, o = t.points;
            (0, l.genLogger)(17118, "exposure", {
                trackId: i,
                albumId: e,
                points: o
            });
        },
        log_icon_click: function() {
            (0, l.genLogger)(19508, "click", {});
        },
        log_vip_click: function() {
            (0, l.genLogger)(28685, "click", {});
        },
        log_go_vip: function() {
            (0, l.genLogger)(28684, "click", {});
        },
        log_vip_show: function() {
            (0, l.genLogger)(28686, "slipPage", {});
        }
    }
}));