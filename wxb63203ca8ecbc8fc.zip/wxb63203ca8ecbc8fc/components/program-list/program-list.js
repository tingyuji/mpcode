var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("../../common/apis/album"), i = require("../../common/utils/myAdapter"), e = require("../../packages/lite-player/event"), s = require("../../common/utils/storage"), o = require("../../common/utils/navBar"), n = require("../../common/utils/logger"), r = require("../../common/utils/navigate"), l = require("../../common/utils/wxSubscribe"), c = require("../../packages/lite-player/index").createComponent;

Component(c({
    properties: {
        albumId: {
            type: Number,
            value: "",
            observer: function() {
                var t = this, a = this.data.albumId;
                this.setData({
                    asc: !(0, s.isInSortAlbum)(a)
                }, function() {
                    t.getTrackList({
                        asc: t.data.asc,
                        init: !0
                    });
                });
            }
        },
        userPermission: Boolean,
        isVip: Boolean,
        isSingleAlbum: Boolean,
        pointInfo: Object,
        albumInfo: Object
    },
    data: {
        asc: !0,
        showOptionList: !1,
        currentOption: 0,
        trackList: [],
        totalCount: 0,
        loading: !0,
        ended: !1,
        currentPlaying: !1,
        isIos: (0, o.isIos)(),
        statusBarHeight: ((0, o.isOldVersion)() ? 0 : (0, o.getStatusBarHeight)()) + 44
    },
    attached: function() {
        this.loadMore = this._loadMore.bind(this), this.reloadList = this.reloadList.bind(this), 
        this.refeshList = this.refeshList.bind(this), e.EventBus.on("loadMore", this.loadMore), 
        e.EventBus.on("reloadProgramList", this.reloadList), e.EventBus.on("refreshProgramList", this.refeshList), 
        this.pageSize = 20, this.getPlatform();
    },
    detached: function() {
        e.EventBus.off("loadMore", this.loadMore), e.EventBus.off("reloadProgramList", this.reloadList), 
        e.EventBus.off("refreshProgramList", this.refeshList);
    },
    methods: {
        getTrackList: function() {
            var i = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, s = e.page, o = void 0 === s ? 1 : s, n = e.asc, r = void 0 === n ? this.data.asc : n, l = e.init, c = void 0 !== l && l, u = e.isLoad, d = void 0 !== u && u, g = this.data, h = g.albumId, p = g.ended;
            !h || d && p || (0, a.getTrackList)({
                albumId: h,
                page: o,
                asc: r
            }).then(function(a) {
                var e = a.trackList, s = a.totalCount, n = a.totalPage;
                i.loading = !1, i.page = o;
                var l = o < n;
                console.log(e, "=====getTrackList"), i.setData({
                    trackList: c ? e : [].concat(t(i.data.trackList), t(e)),
                    totalCount: s,
                    asc: r,
                    loading: l,
                    ended: !1
                }), l || setTimeout(function() {
                    i.setData({
                        ended: !0
                    });
                }, 20);
            }).catch(function() {
                return i.loading = !1;
            });
        },
        reloadList: function(t) {
            console.log("reloadList======", t);
            var a = this.page;
            if (t) {
                var i = this.getCurrentTrackIdPage(t);
                a = -1 === i ? this.page : i;
            }
            this.getTrackList({
                page: a,
                asc: this.data.asc,
                init: !0,
                isLoad: !1
            });
        },
        getCurrentTrackIdPage: function(t) {
            var a = this.data, i = a.asc, e = a.trackList, s = this.page, o = this.pageSize, n = e.findIndex(function(a) {
                return +a.id == +t;
            });
            if (console.log("getCurrentTrackIdPage====index", n), n < 0) return -1;
            var r = Math.floor(n / o), l = Math.round(e.length / o) - r - 1;
            return console.log("getCurrentTrackIdPage====", l, i, s), s - l;
        },
        refeshList: function(t) {
            if (t) {
                var a = this.data.trackList, i = a.findIndex(function(a) {
                    return a.id == t;
                }), e = this.data.trackList[i];
                return e.isLock = !1, e.userPermission = !0, e.needPay = !1, a[i] = e, this.setData({
                    trackList: a
                }), void this.playlist(a);
            }
        },
        playAll: function() {
            var t = this.data, a = t.albumId, i = t.currentSource, e = t.showOptionList, s = t.trackList, o = t.playState, n = t.PlayState;
            t.totalCount;
            if (!e) {
                if (console.log("播放全部"), 1 * a === i.albumId && o === n.PLAYING) return this.log_play_all("暂停"), 
                this.pause();
                this.playlist(s, {
                    auto: !0
                }), this.log_play_all("播放");
            }
        },
        onOptionList: function() {
            var t = this.data, a = t.totalCount, i = t.showOptionList, e = t.asc, s = Math.ceil(a / 20), o = new Array(s).fill("").map(function(t, i) {
                return e ? 20 * i + 1 + "~" + (i + 1 === s ? a : 20 * (i + 1)) : a - 20 * i + "~" + (i + 1 === s ? 1 : a - 20 * (i + 1) + 1);
            });
            this.triggerEvent("panelChange", i), this.setData({
                showOptionList: !i,
                optionList: o
            }), this.log_choose_page();
        },
        selectOption: function(t) {
            var a = (0, i.getDataset)(t).index;
            void 0 !== a && (this.triggerEvent("panelChange", !0), this.setData({
                currentOption: a,
                showOptionList: !1
            }), this.getTrackList({
                page: a + 1,
                init: !0
            }));
        },
        closeOptionList: function() {
            this.triggerEvent("panelChange", !0), this.setData({
                showOptionList: !1
            });
        },
        changeOrder: function() {
            var t = this.data, a = t.asc, i = t.showOptionList, e = t.albumId;
            i || (a ? (0, s.addSortAlbum)(e) : (0, s.removeSortAlbum)(e), this.setData({
                currentOption: 0
            }), this.getTrackList({
                asc: !a,
                init: !0
            }), this.log_sort(!a));
        },
        _loadMore: function() {
            this.loading || (this.loading = !0, console.log("list more", Date.now()), this.page++, 
            this.getTrackList({
                page: this.page,
                isLoad: !0
            }));
        },
        onClickTrack: function(t) {
            (0, l.addSubCount)("专辑页声音列表点击声音");
            var a = t.currentTarget.dataset, i = a.track, s = a.current;
            if (i.userPermission) this.changeSort(this.data.asc), this.updatePlayListByTrackPage(s), 
            (0, r.goPage)({
                url: "/pages/soundPage/soundPage?trackId=".concat(i.id)
            }); else {
                var n = "该节目为精品内容，请".concat((0, o.isIos)() ? "解锁" : "购买", "后收听~");
                e.EventBus.emit("openGModal", {
                    tipModal: {
                        albumId: i.albumId,
                        trackId: i.id,
                        visible: !0,
                        trackTitle: i.title,
                        tip: n
                    }
                });
            }
        },
        onClickPlay: function(t) {
            (0, l.addSubCount)("专辑页点击播放声音"), this.log_click_play_icon("track");
            var a = (0, i.getDataset)(t).type, e = t.currentTarget.dataset.track, s = this.data, o = s.trackList, n = s.currentSource.id, r = s.playState, c = s.PlayState.PAUSE;
            if (e.id !== n && (this.playlist().list !== o && this.playlist(o), e.id !== n && this.play(e)), 
            "play" !== a) return "pause" === a ? this.play(e) : void (e.id === n && r === c && this.play(e));
        },
        updatePlayListByTrackPage: function(t) {
            var a = this.data.trackList, i = t - 10 < 0 ? 0 : t - 10, e = t + 10 > a.length ? a.length : t + 10, s = [].concat(a.slice(i, t), a.slice(t, e));
            this.playlist(s);
        },
        onClickVideo: function(t) {
            this.log_click_play_icon("video");
            var a = (0, i.getDataset)(t).track;
            wx.navigateTo({
                url: "/pages/video/index?id=".concat(a.id)
            });
        },
        getPlatform: function() {
            var t = this;
            wx.getSystemInfo({
                success: function(a) {
                    var i = a.model;
                    t.setData({
                        platform: a.platform,
                        isIphoneX: -1 != i.search("iPhone X")
                    });
                }
            });
        },
        isCanBuy: function() {
            return !!this.data.isLogin || (wx.navigateTo({
                url: "/pages/login/login"
            }), !1);
        },
        openPriceModal: function(t) {
            var a = t.currentTarget.dataset.id;
            this.log_buy(a), (0, s.checkLogin)() && e.EventBus.emit("openGModal", {
                buyModal: {
                    visible: !0,
                    trackId: a
                }
            });
        },
        log_buy: function(t) {
            (0, n.genLogger)(17106, "click", {
                trackId: t,
                currPageId: this.data.albumId
            });
        },
        log_choose_page: function() {
            (0, n.genLogger)(17103, "click", {
                currPageId: this.data.albumId
            });
        },
        log_sort: function(t) {
            (0, n.genLogger)(17102, "click", {
                item: t ? "正序" : "倒序",
                currPageId: this.data.albumId
            });
        },
        log_play_all: function(t) {
            (0, n.genLogger)(17101, "click", {
                item: t,
                currPageId: this.data.albumId
            });
        },
        log_click_play_icon: function(t) {
            (0, n.genLogger)(51411, "click", {
                itemType: t,
                currPage: "wx-newalbum"
            });
        }
    }
}));