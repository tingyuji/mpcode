Component({
    properties: {
        score: {
            type: Number,
            value: 0
        },
        showScore: {
            type: Boolean,
            value: !0
        },
        starSize: {
            type: Number,
            value: 16
        }
    },
    data: {
        startList: []
    },
    attached: function() {
        var t = this.data.score, e = this.transferScoreToStar(t);
        this.setData({
            startList: e
        });
    },
    methods: {
        transferScoreToStar: function(t) {
            var e = new Array(5).fill(""), r = t / 2, a = t % 2 == 0;
            return e.fill("whole", 0, r), a || (e[Math.floor(r)] = "half"), e;
        }
    }
});