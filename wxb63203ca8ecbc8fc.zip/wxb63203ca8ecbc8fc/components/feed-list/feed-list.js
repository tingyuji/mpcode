var e = require("../../@babel/runtime/helpers/objectSpread2"), t = require("../../common/utils/myAdapter");

Component({
    properties: {
        list: {
            type: Array,
            value: []
        },
        hasMore: {
            type: Boolean,
            value: !1
        },
        cateInfo: {
            type: Array,
            value: []
        },
        cateId: {
            type: Number,
            value: 0
        },
        title: {
            type: String,
            value: ""
        },
        needMinHeight: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {
        onClickFeedItem: function(e) {
            var a = (0, t.getDataset)(e), r = a.type, i = a.id, n = a.recsrc, c = a.rectrack;
            this.feed_logger({
                type: r,
                id: i,
                recsrc: n,
                rectrack: c
            }), "album" === r && wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(i)
            }), "track" === r && wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(i)
            });
        },
        onAdError: function(e) {
            var a = (0, t.getDataset)(e).index, r = this.data.list.slice();
            r && r[a] && (r[a].show = !1), this.setData({
                list: r
            }), this.triggerEvent("aderror", {
                index: a
            });
        },
        feed_logger: function(t) {
            var a = this.data, r = a.cateInfo, i = a.cateId, n = "";
            r && i && (n = r.find(function(e) {
                return e.categoryId === i;
            }).tabName), this.triggerEvent("clicklogger", e(e({}, t), {}, {
                currentTabName: n
            }));
        }
    }
});