var t = require("../../packages/lite-player/event");

Component({
    properties: {},
    data: {
        modalVisible: !1,
        type: "album"
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        t.EventBus.on("showSettingTip", this._show), t.EventBus.on("closeSettingTip", this._close);
    },
    detached: function() {
        t.EventBus.off("showSettingTip", this._show), t.EventBus.off("closeSettingTip", this._close);
    },
    methods: {
        showModal: function(t) {
            this.setData({
                modalVisible: !0,
                type: t
            });
        },
        close: function() {
            t.EventBus.emit("closeSettingTip");
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1,
                type: "album"
            });
        }
    }
});