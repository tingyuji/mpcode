var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../@babel/runtime/helpers/toConsumableArray"), n = require("../../common/apis/track"), a = require("../../common/utils/index"), i = require("../../common/utils/storage"), o = require("../../common/utils/logger"), r = require("../../common/utils/myAdapter"), s = require("../../common/utils/image"), m = require("../../packages/lite-player/event"), c = require("../../common/apis/mineapi"), d = require("../../common/apis/parse");

Component({
    properties: {
        trackId: {
            type: Number,
            value: "",
            observer: function() {
                this.init();
            }
        },
        userInfo: {
            type: Object,
            value: {}
        }
    },
    data: {
        totalCount: null,
        commentList: [],
        empty: !1,
        loading: !0,
        ended: !1,
        showCommentArea: !1,
        placeholderStr: "不愧是你。提笔就是一条热评～"
    },
    attached: function() {
        this.parentId = 0, this.trackId = 0, this.setData({
            commentStr: ""
        }), this.loadMore = this._loadMore.bind(this), this.writeComment = this.toggleCommentMask.bind(this), 
        m.EventBus.on("loadMore", this.loadMore), m.EventBus.on("writeComment", this.writeComment);
    },
    detached: function() {
        console.log("detached comment"), m.EventBus.off("loadMore", this.loadMore), m.EventBus.off("writeComment", this.writeComment);
    },
    methods: {
        init: function() {
            this.parentId = 0, this.page = 1, this.replyPageInfo = {}, this.data.showCommentArea && (this.setData({
                showCommentArea: !1
            }), wx.showToast({
                title: "已播放下一首",
                icon: "none"
            })), this.getCommentList(!0);
        },
        getCommentList: function() {
            var t = this, a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.page, o = this.data.totalCount;
            (0, n.getCommentList)({
                trackId: this.data.trackId,
                page: i
            }).then(function(n) {
                var r = n.totalCount, s = n.pageSize, m = n.commentList, c = i * s < r;
                m = a ? m : [].concat(e(t.data.commentList), e(m)), t.setData({
                    totalCount: a ? r : o,
                    commentList: m,
                    empty: 0 === m.length,
                    loading: c,
                    ended: !c
                });
            }).catch(function(t) {
                console.log(t);
            });
        },
        getReplyList: function(t) {
            var a = this;
            if (!this.fatchLoading) {
                this.fatchLoading = !0;
                var i = this.data.commentList, o = t.currentTarget.dataset.id;
                this.replyPageInfo[o] || (this.replyPageInfo[o] = {
                    page: 1
                }), console.log(this.replyPageInfo);
                var r = this.replyPageInfo[o];
                (0, n.getReplyList)({
                    trackId: this.data.trackId,
                    commentId: Number(o),
                    page: r.page
                }).then(function(t) {
                    var n = t.replies, s = t.end, m = i.find(function(t) {
                        return t.id === o;
                    });
                    m.replies = 1 === r.page ? n : [].concat(e(m.replies), e(n));
                    var c = m.replies.length;
                    s && (m.replyCount = c), r.page++, a.fatchLoading = !1, a.setData({
                        commentList: i
                    });
                }).catch(function() {
                    a.fatchLoading = !1;
                });
            }
        },
        userImageError: function(t) {
            var e = this, n = t.currentTarget.dataset.index;
            this.userImageErrorList || (this.userImageErrorList = []), this.userImageErrorList.push(n), 
            clearTimeout(this.timer), this.timer = setTimeout(function() {
                var t = e.data.commentList;
                e.userImageErrorList.forEach(function(e) {
                    t && t[e] && (t[e].avatar = s.defaultUserImg);
                }), e.setData({
                    commentList: t
                });
            }, 20);
        },
        _loadMore: function() {
            console.log("loadMore"), this.data.ended || (this.page++, this.getCommentList());
        },
        praiseHandle: function(t) {
            var e = this, i = t.currentTarget.dataset.item, o = i.id, r = i.liked, s = this.data.commentList, m = s.find(function(t) {
                return t.id === o;
            }), c = function() {
                m.liked = !r, m.likesStr = (0, a.parseNum)(m.likes), e.setData({
                    commentList: s
                });
            };
            r ? (0, n.dislikeComment)(this.data.trackId, o).then(function() {
                m.likes--, c();
            }) : (0, n.likeComment)(this.data.trackId, o).then(function() {
                m.likes++, c();
            });
        },
        toggleCommentMask: function(t) {
            var e = this.data, n = e.showCommentArea, a = e.trackId;
            if (this.trackId = a || 0, this.setData({
                showCommentArea: !n,
                commentStr: ""
            }), t) {
                var i = (0, r.getDataset)(t), o = i.id, s = i.nickname;
                this.triggerEvent(o ? "onreplaycomment" : "onwritecomment");
                var m = s ? "@".concat(s, "：") : "不愧是你。提笔就是一条热评～";
                this.setData({
                    placeholderStr: m
                }), this.parentId = o || 0, this.nickname = s || "";
            }
        },
        createComment: (0, a.debounce)(function() {
            var e = this, a = this.data, i = a.commentStr, r = a.commentList;
            i && ((0, o.genLogger)(18992, "click", {
                currPageId: this.trackId
            }), (0, n.createTrackComment)({
                content: i,
                parentId: this.parentId,
                trackId: this.trackId
            }).then(function(n) {
                if (0 == n.parent) e.fakeFirstComment(t(t({}, n), {}, {
                    commentStr: i
                })); else {
                    var a = r.findIndex(function(t) {
                        return t.id === e.parentId;
                    }), o = r.slice();
                    0 === o[a].replyCount ? e.fakeFirstComment({
                        child: 0,
                        commentStr: i,
                        commentListCopy: o,
                        replayIndex: a
                    }, !0) : (o[a].replyCount++, e.setData({
                        commentList: o
                    }));
                }
                e.toggleCommentMask(), m.EventBus.emit("commentDone");
            }));
        }),
        onCommentInput: (0, a.throttle)(function(t) {
            var e = t.detail.value;
            this.setData({
                commentStr: e
            });
        }),
        fakeFirstComment: function(e) {
            var n = this, a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], o = e.child, r = e.commentStr, s = e.commentListCopy, m = e.replayIndex, h = this.trackId, l = this.nickname, u = this.parentId, p = this.data, g = p.totalCount, f = p.commentList;
            (0, i.getUid)() && (0, c.queryUserInfo)({
                uid: (0, i.getUid)()
            }).then(function(e) {
                var i = e.cover, c = e.uid, p = e.nickName, I = {};
                I = {
                    id: o,
                    trackId: h,
                    content: r,
                    smallHeader: i,
                    uid: c,
                    nickname: p,
                    likes: 0,
                    liked: !1,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                    parentId: 0,
                    parentUid: 0,
                    ancestorId: 0,
                    replyCount: 0,
                    replies: []
                }, a && (I = t(t({}, I), {}, {
                    pNickname: l,
                    parentId: u,
                    parentUid: s[m].uid,
                    ancestorId: u,
                    replyCount: 1
                }));
                var C = (0, d.parseComment)(I);
                a ? (s[m].replies = [].concat([], C), s[m].replyCount++, n.setData({
                    commentList: s
                })) : n.setData({
                    empty: !1,
                    totalCount: g + 1,
                    commentList: [].concat(C, f)
                });
            });
        }
    }
});