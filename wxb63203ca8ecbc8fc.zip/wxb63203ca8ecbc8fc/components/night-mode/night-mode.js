var t = require("../../common/utils/storage"), e = require("../../packages/lite-player/event");

Component({
    properties: {
        iconStyle: String,
        textStyle: String
    },
    options: {
        addGlobalClass: !0
    },
    data: {
        nightModeList: [ {
            text: "日间模式",
            icon: "iconic_rijian",
            filter: "0"
        }, {
            text: "夜间模式",
            icon: "iconyejianmoshi",
            filter: "0.1"
        }, {
            text: "夜间模式2",
            icon: "iconyejianmoshi",
            filter: "0.25"
        }, {
            text: "夜间模式3",
            icon: "iconyejianmoshi",
            filter: "0.4"
        } ],
        currentNightMode: (0, t.get)("night_mode") || 0
    },
    attached: function() {
        this.setData({
            currentNightMode: (0, t.get)("night_mode") || 0
        });
    },
    detached: function() {},
    methods: {
        changeNightMode: function() {
            var t = this.data.currentNightMode, i = t + 1 >= 4 ? 0 : t + 1;
            e.EventBus.emit("changeNightMode", i), this.setData({
                currentNightMode: i
            });
        }
    }
});