Component({
    properties: {},
    externalClasses: [ "search-outside" ],
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {}
});