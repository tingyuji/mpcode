var e = require("../../@babel/runtime/helpers/objectSpread2"), n = require("../../packages/lite-player/event"), t = require("../../common/utils/index"), o = require("../../common/apis/unionvip"), i = {
    phone: "",
    code: "",
    hasSend: !1,
    count: 60
}, s = null;

Component({
    properties: {},
    options: {},
    data: e({
        modalVisible: !1,
        info: {
            clientId: ""
        }
    }, i),
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        n.EventBus.on("showCheckPhoneModal", this._show), n.EventBus.on("closeCheckPhoneModal", this._close);
    },
    detached: function() {
        n.EventBus.off("showCheckPhoneModal", this._show), n.EventBus.off("closeCheckPhoneModal", this._close);
    },
    methods: {
        onPhoneChange: (0, t.debounce)(function(e) {
            var n = e.detail.value.trim();
            this.setData({
                phone: n
            });
        }),
        onCodeChange: (0, t.debounce)(function(e) {
            var n = e.detail.value.trim();
            this.setData({
                code: n
            });
        }),
        beforeSend: function(e) {
            var n = this, t = this.data, i = t.phone;
            if (!t.hasSend) {
                /^1[3-9]\d{9}$/.test(i) ? (0, o.mobileSend)({
                    mobile: i
                }).then(function(e) {
                    0 === e.ret ? n.beginSend() : wx.showToast({
                        icon: "none",
                        title: e.msg
                    });
                }) : wx.showToast({
                    icon: "none",
                    title: "请填写正确手机号"
                });
            }
        },
        beginSend: function() {
            var e = this, n = this.data.count;
            this.setData({
                hasSend: !0
            }), setTimeout(function() {
                e.setData({
                    hasSend: !1,
                    count: 60
                }), e.clearInterval();
            }, 6e4), s = setInterval(function() {
                e.setData({
                    count: --n
                });
            }, 1e3);
        },
        onSubmit: function() {
            var e = this, n = this.data, t = n.code, i = n.phone, s = n.info.clientId;
            (0, o.mobileVerify)({
                code: t,
                mobile: i
            }).then(function(n) {
                0 === n.ret ? e.toBind({
                    phone: i,
                    clientId: s
                }) : wx.showToast({
                    icon: "none",
                    title: n.msg
                });
            });
        },
        toBind: function(e) {
            var n = e.phone, t = e.clientId;
            (0, o.bindMobile)({
                mobile: n,
                clientId: t
            }).then(this.onBindSuccess.bind(this));
        },
        onBindSuccess: function(e) {
            var n = this, t = this.data.info.clientId;
            0 === e.ret ? (0, o.querybindMobile)({
                clientId: t
            }).then(function(e) {
                n.triggerEvent("onPhoneMaskChange", {
                    maskPhone: e
                }), n.close();
            }) : wx.showToast({
                icon: "none",
                title: "".concat(e.msg)
            });
        },
        clearInterval: function(e) {
            function n() {
                return e.apply(this, arguments);
            }
            return n.toString = function() {
                return e.toString();
            }, n;
        }(function() {
            s && clearInterval(s), s = null;
        }),
        showModal: (0, t.debounce)(function(n) {
            var t = n.info;
            this.clearInterval(), this.setData(e({
                info: t,
                modalVisible: !0
            }, i));
        }),
        close: function() {
            n.EventBus.emit("closeCheckPhoneModal", {});
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1
            });
        }
    }
});