var e = require("../../packages/lite-player/event"), s = require("../../common/utils/logger"), t = require("../../common/utils/index");

Component({
    properties: {
        pageType: {
            type: String,
            value: ""
        }
    },
    data: {
        visible: !1,
        currentPage: "",
        isIPhoneX: (0, t.isIPhoneX)()
    },
    attached: function() {
        this._show = this.showPanel.bind(this), this._close = this.closePanel.bind(this), 
        e.EventBus.on("showSharePanel", this._show), e.EventBus.on("closeSharePanel", this._close);
    },
    detached: function() {
        e.EventBus.off("showSharePanel", this._show), e.EventBus.off("closeSharePanel", this._close);
    },
    methods: {
        showPanel: function(e) {
            this.setData({
                visible: !0,
                currentPage: e
            });
        },
        close: function() {
            e.EventBus.emit("closeSharePanel");
        },
        closePanel: function() {
            this.setData({
                visible: !1
            });
        },
        poster: function() {
            (0, s.genLoggerClick)(17855, "XX", {
                currPage: "overall"
            });
            var t = this.data.currentPage;
            e.EventBus.emit("showPosterBox", t);
        },
        log_choose_share: function() {
            (0, s.genLoggerClick)(17854, "XX", {
                currPage: "overall"
            });
        }
    }
});