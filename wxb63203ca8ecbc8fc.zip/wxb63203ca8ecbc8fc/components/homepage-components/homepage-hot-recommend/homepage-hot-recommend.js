var e = require("../../../common/utils/logger"), t = (require("../../../common/utils/wxSubscribe"), 
require("../../../common/apis/rankpage")), n = [], a = 0;

Component({
    properties: {
        className: String,
        module: {
            type: Object,
            value: {
                title: ""
            },
            observer: function(e, t) {
                e !== t && (e.moduleInfo && e.moduleInfo.length || 0) !== (t.moduleInfo && t.moduleInfo.length || 0) && this.init();
            }
        },
        showDivider: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        list: []
    },
    lifetimes: {
        ready: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e = this;
            (0, t.getRankList)({
                typeId: 0,
                clusterId: ""
            }).then(function(t) {
                var a = t.rankList;
                n = void 0 === a ? [] : a, e.dealSortData();
            });
        },
        createModuleObserver: function() {},
        toAlbum: function(t) {
            (0, e.genLogger)(47580, "click", {
                currPage: "wx-newhome",
                contentType: "专辑"
            });
            var n = t.currentTarget.dataset.index;
            wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(n)
            });
        },
        changeData: function() {
            ++a >= n.length && (a = 0), (0, e.genLogger)(47580, "click", {
                currPage: "wx-newhome",
                contentType: "换一批"
            }), this.dealSortData();
        },
        dealSortData: function() {
            if (n && n[a] && n[a].albums) {
                var e = n[a].albums;
                e.sort(function() {
                    return .5 - Math.random();
                }), e = e.slice(0, 6).map(t.parseRankList), this.setData({
                    list: e
                });
            }
        }
    }
});