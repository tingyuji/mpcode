require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../common/utils/index"), n = require("../../../common/utils/logger"), a = require("../../../common/apis/home"), r = {
    1: "/pages/announcer/announcer",
    2: "/pages/albumDetail/albumDetail",
    3: "/pages/soundPage/soundPage"
}, i = {
    1: "id",
    2: "albumId",
    3: "trackId"
}, o = t.bannerAdId;

Component({
    properties: {
        module: {
            type: Object,
            value: {
                title: ""
            },
            observer: function(n, r) {
                var i = this;
                if (n !== r && n.moduleInfo && 0 !== n.moduleInfo.length) {
                    n.moduleInfo = n.moduleInfo.map(this.parseBanner);
                    var u = n.moduleInfo;
                    wx.canIUse("ad") && (u = (0, t.insertBetween)(n.moduleInfo, 3, {
                        show: !0,
                        type: "wxad",
                        unitId: o
                    })), (0, a.getBannerAdSetting)().then(function(a) {
                        a && a.length && a.map(function(n, a) {
                            var r = n.framePos, i = e(e({
                                type: "hlxcx",
                                show: !0
                            }, n), {}, {
                                imageSrc: (0, t.image2Url)(n.imageSrc, {
                                    name: "large_pop",
                                    columns: 690,
                                    rows: 276
                                })
                            });
                            r && u.splice(r - 1 + a, 0, i);
                        }), n.moduleInfo = u.filter(function(e) {
                            return e.show;
                        }), i.setData({
                            list: n
                        });
                    }).catch(function() {
                        n.moduleInfo = u, i.setData({
                            list: n
                        });
                    });
                }
            }
        },
        currentCate: {
            type: String,
            value: ""
        }
    },
    data: {
        current: 0,
        currentBanner: 0,
        indicatorDots: !1,
        vertical: !1,
        autoplay: !0,
        circular: !0,
        interval: 3e3,
        duration: 500,
        previousMargin: 25,
        nextMargin: 25,
        bannerAd: {},
        list: {}
    },
    lifetimes: {
        attached: function() {
            this.isScrolling = !1;
        }
    },
    methods: {
        bannerChange: function(e) {
            var t = this, n = this.data.currentBanner, a = e.detail.current;
            n !== a && (this.bannerChanging = !0, this.setData({
                currentBanner: a
            }, function() {
                setTimeout(function() {
                    t.bannerChanging = !1;
                }, 600);
            }));
        },
        clickBanner: function(e) {
            var a = this.data.currentCate, r = void 0 === a ? "" : a, i = (0, t.getDataset)(e), o = i.source, u = void 0 === o ? "" : o, c = i.link, s = void 0 === c ? "" : c, l = i.type, h = i.id, d = i.path, g = i.index;
            if ((0, n.genLogger)(51407, "click", {
                currentModule: r,
                currPage: "wx-newhome",
                type: l,
                index: g
            }), "hlxcx" === l) return wx.navigateToMiniProgram({
                appId: h,
                path: d
            });
            var m = (0, t.url2obj)(s), p = m.trackId, f = void 0 === p ? "" : p, v = m.albumId, b = void 0 === v ? "" : v;
            if ("xima" === l) {
                if (s.includes("trackId")) return wx.navigateTo({
                    url: "/pages/soundPage/soundPage?trackId=".concat(f)
                });
                if (s.includes("albumId")) return b = u.replace(/[\/a-z]/g, ""), wx.navigateTo({
                    url: "/pages/albumDetail/albumDetail?albumId=".concat(b)
                });
            }
        },
        onTouchStart: function(e) {
            this.time = 0, this.touchDotX = e.touches[0].pageX, this.touchDotY = e.touches[0].pageY;
        },
        onTouchEnd: function(e) {
            var t = e.changedTouches[0].pageX, a = e.changedTouches[0].pageY, r = t - this.touchDotX, i = a - this.touchDotY;
            Math.abs(r) > 2 * Math.abs(i) && (0, n.genLogger)(27123, "click", {
                item: r < 0 ? "左滑" : "右滑"
            });
        },
        parseBanner: function(n) {
            return e({
                cover: (0, t.image2Url)(n.cover || n.coverPath, {
                    name: "large_pop",
                    columns: 690,
                    rows: 276
                }),
                realLink: n.realLink || n.url && n.contentType && (a = n.url, o = n.contentType, 
                u = a.split("/"), r[o] + "?" + i[o] + "=" + (u[u.length - 2] || u[u.length - 1])),
                type: "xima",
                show: [ 1, 2, 3 ].indexOf(n.contentType) > -1
            }, n);
            var a, o, u;
        },
        onWXAdError: function(e) {
            var t = this.data.list, n = (t = void 0 === t ? {} : t).moduleInfo.filter(function(e) {
                return "wxad" !== e.type;
            }), a = {};
            a.moduleInfo = n, this.setData({
                list: a
            });
        },
        tapChange: function(e) {
            if (!this.bannerChanging) {
                var a = this.data.currentBanner;
                this.setData({
                    autoplay: !1
                });
                var r = this.getBannerLength(), i = (0, t.getDataset)(e).type;
                "prev" === i && this.toPrev(a, r), "next" === i && this.toNext(a, r), (0, n.genLogger)(26915, "click", {
                    item: i,
                    currentPage: "index"
                });
            }
        },
        toPrev: function(e, t) {
            var n = this, a = e - 1 < 0 ? t - 1 : e - 1;
            this.setData({
                current: a,
                currentBanner: a
            }, function() {
                n.setData({
                    autoplay: !0
                });
            });
        },
        toNext: function(e, t) {
            var n = this, a = e + 1 > t - 1 ? 0 : e + 1;
            this.setData({
                current: a,
                currentBanner: a
            }, function() {
                n.setData({
                    autoplay: !0
                });
            });
        },
        getBannerLength: function() {
            var e = this.data.list.moduleInfo, t = e.length, n = 0;
            return e.map(function(e) {
                e.show && n++;
            }), !isNaN(n) && n < t ? n : t;
        }
    }
});