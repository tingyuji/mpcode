var t = require("../../../common/apis/home"), e = require("../../../common/utils/myAdapter"), a = require("../../../common/apis/rankpage"), r = require("../../../common/utils/logger");

Component({
    properties: {
        rankInfo: {
            type: Object,
            value: {}
        },
        currentTabRank: {
            type: Object,
            value: {}
        },
        category: {
            type: String,
            value: "",
            observer: function(t, e) {
                t !== e && this.init();
            }
        }
    },
    data: {
        typeId: 0,
        clusterId: 0,
        rankList: [],
        currentRank: {},
        showRank: !0,
        showAlbums: !0
    },
    attached: function() {},
    methods: {
        init: function() {
            var e = this;
            this.setData({
                showRank: !1
            }), this.rankList ? this.getCurrentTabRankInfo(this.rankList) : (0, t.queryIndexTabRankList)().then(function(t) {
                e.getCurrentTabRankInfo(t), e.rankList = t;
            });
        },
        getCurrentTabRankInfo: function(t) {
            var e = this.data.category, a = t.find(function(t) {
                return t.categoryCode === e;
            });
            if (!a) return this.setData({
                showRank: !1
            });
            var r = a.rankList;
            this.currentRankInfo = a;
            var n = r[0];
            this.setData({
                rankList: r,
                currentRank: n,
                showRank: !0
            });
            var s = n.typeId, i = n.clusterId;
            this.queryCurrentTabRankList({
                typeId: s,
                clusterId: i
            });
        },
        queryCurrentTabRankList: function(t) {
            var e = this, r = t.typeId, n = t.clusterId;
            (0, a.getRankList)({
                typeId: r,
                clusterId: n
            }).then(function(t) {
                var r = t.rankList, n = ((void 0 === r ? [] : r)[0] || {}).albums, s = void 0 === n ? [] : n;
                e.setData({
                    albums: s.slice(0, 9).map(a.parseRankList)
                });
            });
        },
        onTapRank: function(t) {
            var a = (0, e.getDataset)(t).index;
            this.setData({
                showAlbums: !1
            });
            var n = this.currentRankInfo.rankList[a];
            this.setData({
                currentRank: n,
                showAlbums: !0
            });
            var s = n.typeId, i = n.clusterId, c = n.rankName;
            (0, r.genLogger)(30055, "click", {
                item: c,
                currPage: "categroy"
            }), this.queryCurrentTabRankList({
                typeId: s,
                clusterId: i
            });
        },
        seeMore: function() {
            var t = this.data, e = t.currentRank, a = t.category, n = e.typeId, s = e.clusterId;
            (0, r.genLogger)(30057, "click", {
                item: a,
                currPage: "categroy"
            }), wx.navigateTo({
                url: "/pages/rankpage/rankpage?typeId=".concat(n, "&clusterId=").concat(s)
            });
        },
        log_click_album: function() {
            var t = this.data.category;
            (0, r.genLogger)(30056, "click", {
                item: t,
                currPage: "categroy"
            });
        }
    }
});