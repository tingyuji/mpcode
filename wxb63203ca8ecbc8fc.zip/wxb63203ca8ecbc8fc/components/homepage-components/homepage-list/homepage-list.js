var e = require("../../../common/utils/index"), t = require("../../../common/utils/logger"), o = require("../../../common/utils/wxSubscribe"), i = require("../../../common/const/trackType");

Component({
    properties: {
        className: String,
        module: {
            type: Object,
            value: {
                title: ""
            },
            observer: function(e, t) {
                e !== t && (e.moduleInfo && e.moduleInfo.length || 0) !== (t.moduleInfo && t.moduleInfo.length || 0) && this.init();
            }
        },
        isLast: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {}
        },
        listLength: {
            type: Number,
            value: 0,
            observer: function(e, t) {
                e !== t && this.setData({
                    stopIndex: e
                });
            }
        },
        showDivider: {
            type: Boolean,
            value: !0
        },
        currPage: {
            type: String,
            value: ""
        },
        currentCate: {
            type: String,
            value: ""
        },
        showRank: {
            type: Boolean,
            value: !0
        },
        needScroll: Boolean
    },
    options: {
        addGlobalClass: !0
    },
    data: {
        count: 0,
        faverAllList: [],
        faverList: [],
        stopIndex: 0,
        btnChange: !1,
        noBtn: !0,
        btnSeeMore: !1,
        cateSeeMore: !1,
        cateCode: "",
        showPicTip: !0
    },
    lifetimes: {
        ready: function() {
            this.init();
        }
    },
    methods: {
        onScrollToLower: function() {
            this.triggerEvent("onScrollToLower");
        },
        init: function() {
            var e = this.data, t = e.module, o = (t = void 0 === t ? {} : t).moduleInfo, i = void 0 === o ? [] : o, a = t.link, n = void 0 === a ? "" : a, l = t.canChange, r = void 0 === l || l, c = t.tag, u = void 0 === c ? [] : c, d = t.canPlay, s = void 0 === d || d, v = t.showPicTip, g = void 0 === v || v, m = e.listLength, h = !n && !r, f = this.initCateCode();
            this.setData({
                count: i.length,
                faverAllList: i,
                faverList: h ? i : i.slice(0, m || 3),
                btnChange: !n && r,
                btnSeeMore: n && !r,
                cateSeeMore: !s && !r,
                noBtn: h,
                isRank: u.indexOf("rank") > -1,
                cateCode: f,
                showPicTip: g
            });
        },
        initCateCode: function() {
            var e = this.data.module, t = (e = void 0 === e ? {} : e).moduleInfo, o = void 0 === t ? [] : t, i = e.canChange, a = void 0 === i || i, n = e.canPlay, l = void 0 === n || n;
            return o.length > 0 && !a && !l ? o[0].categoryCode : "";
        },
        toAlbum: function(t) {
            var i = this.data, a = i.faverList, n = void 0 === a ? [] : a, l = i.currPage, r = i.module, c = (r = void 0 === r ? {} : r).title, u = r.moduleType, d = i.currentCate;
            (0, o.addSubCount)("".concat(l, ", 点击专辑"));
            var s = n[t.currentTarget.dataset.index].id;
            this.log_click_album(l, d, c, s), (0, e.toAlbum)((0, e.getAlbum)(t, n), u);
        },
        changeData: function() {
            var e = this.data, o = e.faverAllList, i = e.stopIndex, a = e.count, n = e.listLength, l = e.currentCate, r = [];
            (0, t.clickGuessChange)(l);
            var c = 0;
            i + (n || 3) > a ? (c = i + (n || 3) - a, r = [].concat(o.slice(i, o.length), o.slice(0, c))) : (r = o.slice(i, i + (n || 3)), 
            c = i + (n || 3)), this.setData({
                faverList: r,
                stopIndex: c
            });
        },
        clickSeeMore: function() {
            var e = this.data, o = e.module, i = (o = void 0 === o ? {} : o).link, a = o.title, n = e.currentCate;
            (0, t.clickIndexModuleSeeMore)(a, n), wx.navigateTo({
                url: i
            });
        },
        log_click_album: function(e, o, a, n) {
            if ("paid" === e) (0, t.clickPaidGuessAlbum)(n); else if ("recommend" === o) (0, 
            t.clickModuleAlbum)(n, o, a); else {
                var l = this.data.module, r = (l = void 0 === l ? {} : l).moduleType, c = l.title, u = l.subModuleType;
                r === i.RADIOS ? "focus" === u ? (0, t.genLogger)(30722, "click", {
                    moduleName: c,
                    currPage: "radioPlay"
                }) : (0, t.genLogger)(30723, "click", {
                    moduleName: "最近收听",
                    currPage: "radioPlay"
                }) : (0, t.genLogger)(30058, "click", {
                    moduleName: a,
                    currPage: "categroy"
                });
            }
        }
    }
});