var e = require("../../../common/utils/index"), t = require("../../../common/apis/mineapi"), i = require("../../../common/utils/logger"), n = require("../../../packages/lite-player/index").createComponent;

Component(n({
    properties: {
        categoryPinyin: String
    },
    data: {
        showHistory: !0,
        list: []
    },
    pageLifetimes: {
        show: function() {
            this.init();
        }
    },
    attached: function() {
        this.init();
    },
    detached: function() {},
    methods: {
        init: function() {
            var t = this.data.showHistory;
            (0, e.isLogin)() ? (!t && this.setData({
                showHistory: !0
            }), this.getListened()) : this.setData({
                showHistory: !1
            });
        },
        getListened: function() {
            var i = this;
            (0, t.queryGetListened)().then(function(t) {
                var n = t || {}, o = n.yesterday, a = void 0 === o ? [] : o, r = n.earlier, s = void 0 === r ? [] : r, c = n.today, d = void 0 === c ? [] : c, u = 0 === a.length && 0 === d.length && 0 === s.length, g = d.concat(a, s), h = g.map(function(e) {
                    return {
                        albumId: e.album.id,
                        title: e.title,
                        id: e.id,
                        breakSecond: e.breakSecond,
                        createdAt: e.createdAt
                    };
                });
                (0, e.setListenedAlbums)(h), i.setData({
                    list: g.slice(0, 10),
                    showHistory: !u
                });
            }).catch(function(e) {
                console.log("error", e);
            });
        },
        toTrack: function(t) {
            var n = (0, e.getDataset)(t), o = n.track;
            n.index;
            o.id && o && ((0, i.genLogger)(47576, "click", {
                currPage: "wx-newhome"
            }), wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(o.id, "&breakSecond=").concat(o.breakSecond || 0)
            }));
        },
        toHistory: function() {
            wx.navigateTo({
                url: "/pages/mine/mine"
            });
        }
    }
}));