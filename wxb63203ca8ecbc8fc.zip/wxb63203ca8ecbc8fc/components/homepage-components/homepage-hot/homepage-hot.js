var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../common/utils/index"), a = require("../../../common/utils/logger"), i = require("../../../common/apis/hotsale");

Component({
    data: {
        isAndroid: (0, t.isAndroid)(),
        current: 0,
        tabList: [],
        activeObj: {},
        scrollLeft: 0,
        isXianshimianfei: "限时免费"
    },
    pageLifetimes: {
        show: function() {
            (0, a.genLogger)(28664, "slipPage", {});
        }
    },
    attached: function() {
        this.init(), this.isHomePage = (0, t.isHomePage)(), (0, a.genLogger)(28664, "slipPage", {});
    },
    detached: function() {},
    methods: {
        init: function() {
            var t = this;
            (0, i.queryHotSale)().then(function(a) {
                var i = a.map(function(t) {
                    return e(e({}, t), {}, {
                        tabName: t.tabName,
                        albumLength: t.albums.length
                    });
                });
                i && i[0] && t.setData({
                    activeObj: i[0],
                    tabList: i
                });
            });
        },
        toAlbum: function(e) {
            var i = (0, t.getDataset)(e).id, n = this.data, s = n.current, o = n.tabList;
            i && (wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(i)
            }), (0, a.genLogger)(this.isHomePage ? 28662 : 28666, "click", {
                moduleName: o[s].tabName
            }));
        },
        goLimitAlbumPage: function() {
            (0, a.genLogger)(this.isHomePage ? 28663 : 28667, "click", {}), wx.navigateTo({
                url: "/subpackage/pages/limitfree/index"
            });
        },
        onTabChange: function(e) {
            var i = (0, t.getDataset)(e).index, n = this.data.tabList;
            i === n.length - 1 && (n[i].albums = n[i].albums.slice(0, 6)), this.setData({
                current: i,
                activeObj: n[i],
                scrollLeft: 0
            }), (0, a.genLogger)(this.isHomePage ? 28661 : 28665, "click", {
                moduleName: n[i].tabName
            });
        }
    }
});