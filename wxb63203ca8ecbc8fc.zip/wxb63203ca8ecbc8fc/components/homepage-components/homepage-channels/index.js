var n = require("../../../common/utils/logger"), e = require("../../../common/utils/myAdapter"), t = require("../../../common/apis/home"), a = require("../../../common/apis/channellist");

Component({
    properties: {
        categoryPinyin: {
            type: String,
            observer: function(n, e) {
                n !== e && this.init(n);
            }
        }
    },
    data: {
        channels: []
    },
    attached: function() {},
    methods: {
        init: function(n) {
            var e = this;
            if (this.allCategoryChannels) {
                var a = this.allCategoryChannels.find(function(e) {
                    return e.categoryCode === n;
                });
                if (!a) return this.setData({
                    channels: []
                });
                var r = a.channelGroupId;
                this.channelGroupId = r, this.queryChannels();
            } else (0, t.getCategoryHotChannels)().then(function(t) {
                e.allCategoryChannels = t;
                var a = t.find(function(e) {
                    return e.categoryCode === n;
                });
                if (!a) return e.setData({
                    channels: []
                });
                var r = a.channelGroupId;
                e.channelGroupId = r, e.queryChannels();
            });
        },
        queryChannels: function() {
            var n = this;
            (0, a.queryChannelsByGroupId)(this.channelGroupId).then(function(e) {
                n.allChannels = e, n.setData({
                    channels: e.slice(0, 7),
                    hasMore: e.length > 7
                });
            });
        },
        toggleMore: function() {
            this.data.channels.length <= 7 ? this.setData({
                channels: this.allChannels.slice(0, 15)
            }) : this.setData({
                channels: this.allChannels.slice(0, 7)
            });
        },
        log_click_channel: function(t) {
            var a = (0, e.getDataset)(t).name, r = this.data.categoryPinyin;
            (0, n.genLogger)(30054, "click", {
                currModule: r,
                subCategoryCode: a,
                currPage: "categroy"
            });
        }
    }
});