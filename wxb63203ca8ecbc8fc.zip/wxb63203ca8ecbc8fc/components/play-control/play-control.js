var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../common/utils/index"), n = require("../../common/utils/logger"), a = require("../../common/utils/myAdapter"), s = require("../../common/utils/storage"), r = require("../../common/utils/time"), o = require("../../packages/lite-player/event"), c = require("../../common/apis/track"), h = require("../../common/utils/wxSubscribe"), l = require("./const"), u = require("../../packages/lite-player/index").createComponent;

Component(u({
    properties: {
        isSample: Boolean,
        breakSecond: Number,
        isFavourite: Boolean
    },
    data: {
        showList: !1,
        showTimer: !1,
        playList: [],
        timerList: l.timerList,
        speedList: l.speedList,
        movingTime: 0,
        nextTrack: null,
        isIos: (0, i.isIos)(),
        scrollTop: 1,
        currentPlayMode: 0,
        playModeList: l.playModeList,
        showSpeed: !1,
        showChangeSpeed: !(0, i.isLowerSDK)("2.11.0"),
        statusBarHeight: (0, i.getStatusBarHeight)(),
        isFunctionBarHide: !0
    },
    attached: function() {
        this.touchMoveHandle = (0, i.throttle)(this._touchMoveHandle, 20), this.windowWidth = wx.getSystemInfoSync().windowWidth, 
        this.padding = 50, this.initPlayList(), this.initFunctionBar(), this.playListChangeBind = this.initPlayList.bind(this), 
        this.sourceChangeBind = this.sourceChange.bind(this), this.timeUpdateBind = (0, 
        i.throttle)(this.timeUpdate.bind(this), 1e3, 1e3), this.toggleFuncBar = this.toggleBar.bind(this), 
        o.EventBus.on("playListChange", this.playListChangeBind), o.EventBus.on("toggleTrackFuncBar", this.toggleFuncBar), 
        u.Player.on("afterSourceChange", this.sourceChangeBind), u.Player.on("sourceTimeUpdate", this.timeUpdateBind);
    },
    detached: function() {
        o.EventBus.off("playListChange", this.playListChangeBind), o.EventBus.off("toggleTrackFuncBar", this.toggleFuncBar), 
        u.Player.off("afterSourceChange", this.sourceChangeBind), u.Player.off("sourceTimeUpdate", this.timeUpdateBind), 
        clearTimeout(this.timer);
    },
    methods: {
        initPlayList: function() {
            var t = this, e = this.playlist(), i = e.list, n = void 0 === i ? [] : i, a = e.sort, s = e.mode;
            this.setData({
                playList: n,
                sort: a,
                currentPlayMode: this.findOrder(s)
            }, function() {
                t.log_playbtn_click(), t.sourceChange();
            });
        },
        sourceChange: function(t) {
            var e = this.data, i = e.playList, n = e.currentSource, a = i.findIndex(function(t) {
                return t.id === n.id;
            });
            this.setIndex(a), n !== this.currentSource && (this.currentSource = n, a < i.length ? this.nextTrack = i[a + 1] : this.nextTrack = null, 
            this.handleInitTip());
        },
        changeNextTip: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.nextTrack;
            this.setData({
                nextTrack: t
            }), t && (0, n.trackNextTip)();
        },
        handleInitTip: function() {
            var t = this;
            return this.data.duration && this.data.duration < 20 ? this.changeNextTip() : (0, 
            s.getNextTrackTip)() ? this.changeNextTip(null) : void (this.timer = setTimeout(function() {
                t.changeNextTip(), t.timer = setTimeout(function() {
                    return t.changeNextTip(null);
                }, 5e3);
            }, 5e3));
        },
        timeUpdate: function(t) {
            var e = this.data, i = e.nextTrack, n = e.source.duration;
            !i && t + 5 > n && this.changeNextTip();
        },
        fast: function(t) {
            var e = this.data, i = e.currentTime, n = e.duration, a = "forward" === t ? Math.min(i + 15, n) : Math.max(i - 15, 0);
            console.log(a, i, "fast"), this.seek(a), this.setData({
                currentTime: i
            });
        },
        fastBackward: function() {
            this.fast("backward");
        },
        fastForward: function() {
            this.fast("forward");
        },
        _touchHandle: function(t) {
            var i = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = t.touches[0] || t.changedTouches[0], a = n.clientX, s = this.data.duration;
            if (a > this.padding && this.windowWidth - a > this.padding) {
                var o = Math.floor((a - this.padding) / (this.windowWidth - 2 * this.padding) * s), c = (0, 
                r.parseTime)(o);
                !i && this.seek(o);
                var h = i ? {
                    movingTime: o,
                    movingTimeStr: c
                } : {
                    currentTime: o,
                    currentTimeStr: c
                };
                i && (this.clicking = !1), this.setData(e(e({}, h), {}, {
                    touchMoving: i,
                    currentTimeStr: c
                }));
            }
        },
        _touchMoveHandle: function(t) {
            this._touchHandle(t);
        },
        touchHandle: function(t) {
            var e = this;
            this.clicking || (this.clicking = !0, setTimeout(function() {
                e._touchHandle(t, !1);
            }, 50), setTimeout(function() {
                e.clicking = !1;
            }, 500));
        },
        changeTrack: function(t) {
            var e = (0, a.getDataset)(t).track;
            this.play(e), this.closeList();
        },
        toNextTrack: function() {
            var t = this.data.nextTrack;
            this.play(t), (0, n.clickTrackNextTip)(t.id);
        },
        changeTimer: function(t) {
            var e = (0, a.getDataset)(t), i = e.timer, n = e.index, s = this.data, r = s.currentTimer, o = s.delayDuration, c = s.playState, h = s.PlayState;
            if (n === r && o || c !== h.PAUSE && c !== h.PLAYING && c !== h.ENDED) return this.closeTimer();
            -1 === i.duration ? this.delayCountClose(i.song, !0, n) : this.delayClose(i.duration, 0 !== i.duration, n), 
            this.setData({
                showTimer: !1
            }), this.triggerEvent("panelChange", !0);
        },
        changeSpeed: function(t) {
            var e = (0, a.getDataset)(t).speed, i = this.data, s = i.currentSpeed, r = i.currentSource, o = void 0 === r ? {} : r;
            e.speed !== s && ((0, n.genLogger)(26323, "click", {
                item: e.speed,
                currPageId: o.id,
                currPage: "声音页"
            }), this.changePlayRate(e.speed), this.setData({
                showSpeed: !1
            }), this.triggerEvent("panelChange", !0));
        },
        showList: function() {
            this.triggerEvent("panelChange", !1), this.setData({
                showList: !0
            });
            var t = 48 * this.playlist().index;
            this.setData({
                scrollTop: t
            }), this.log_play_list();
        },
        closeList: function() {
            this.triggerEvent("panelChange", !0), this.setData({
                showList: !1
            });
        },
        showTimer: function() {
            this.triggerEvent("panelChange", !1), this.setData({
                showTimer: !0
            }), this.log_time_close();
        },
        closeTimer: function() {
            this.triggerEvent("panelChange", !0), this.setData({
                showTimer: !1,
                showSpeed: !1
            });
        },
        showSpeed: function() {
            var t = this.data.currentSource, e = void 0 === t ? {} : t;
            (0, n.genLogger)(26322, "click", {
                currPageId: e.id,
                currPage: "声音页"
            }), this.triggerEvent("panelChange", !1), this.setData({
                showSpeed: !0
            });
        },
        loadUp: function() {
            if (!this.loading) {
                this.loading = !0;
                var t = this.playlist(), e = t.sort, i = t.list, n = void 0 === i ? [] : i;
                if (n.length) {
                    var a = n.slice().shift();
                    a && this._loadUp(a.id, e);
                }
            }
        },
        _loadUp: function(t, e) {
            this.data.top || this._queryPlayListByTrack({
                id: t,
                sort: e,
                type: l.PLAYLIST_TYPE.UPPER
            });
        },
        loadMore: function(t) {
            if (!this.loading) {
                this.loading = !0;
                var e = this.playlist(), i = e.sort, n = e.list.slice().pop();
                n && this._loadMore(n.id, i, t);
            }
        },
        _loadMore: function(t, e, i) {
            this.data.end || this._queryPlayListByTrack({
                id: t,
                sort: e,
                type: l.PLAYLIST_TYPE.LOWER,
                cb: i
            });
        },
        _changeSort: function() {
            var t = this.data.currentSource, e = (void 0 === t ? {} : t).id, i = this.playlist().sort;
            this.setData({
                top: !1,
                end: !1,
                sort: !i
            }), this.changeSort(!i), this._queryPlayListByTrack({
                id: e,
                sort: !i,
                type: l.PLAYLIST_TYPE.INIT
            });
        },
        _queryPlayListByTrack: function(e) {
            var i = this, n = e.id, a = e.sort, s = e.type, r = e.cb, o = s === l.PLAYLIST_TYPE.UPPER, h = s === l.PLAYLIST_TYPE.LOWER;
            this.setData({
                loadingUpper: o,
                loadingLower: h
            });
            var u = h ? "0" : 10, d = o ? "0" : 10;
            n && (0, c.queryRelativeTracks)(n, u, d, a).then(function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                if (setTimeout(function() {
                    return i.loading = !1;
                }, 1500), s === l.PLAYLIST_TYPE.INIT) return i.playlist(e), i.setData({
                    playList: e
                }), void i._setCurrentIndex(e);
                if (h && 1 == e.length) i.setData({
                    loadingLower: !1,
                    end: !0
                }); else {
                    if (h) {
                        var n = t(e);
                        n.shift(), i.appendPlaylist(n), i._setCurrentIndex(i.playlist().list), i._delayLoading({
                            playList: i.playlist().list,
                            loadingLower: !1
                        });
                    }
                    if (o) {
                        var a = t(e);
                        a.pop(), i.prependPlaylist(a), i._setCurrentIndex(i.playlist().list);
                        var c = 10 * Math.random();
                        i._delayLoading({
                            playList: i.playlist().list,
                            loadingUpper: !1,
                            scrollTop: c < 1 ? 10 * c : c
                        });
                    }
                }
                r && "function" == typeof r && r();
            });
        },
        _setCurrentIndex: function(t) {
            var e = this.data.source, i = t.findIndex(function(t) {
                return t.id === e.id;
            });
            i > -1 && this.setIndex(i);
        },
        _delayLoading: function(t) {
            var i = this;
            setTimeout(function() {
                i.setData(e({}, t));
            }, 1500);
        },
        _playPrev: function() {
            (0, h.addSubCount)("声音页点击上一首"), this.playPrev(), this.log_play_prevnext("上一首");
        },
        _playNext: function() {
            (0, h.addSubCount)("声音页点击下一首");
            this.playlist().list;
            this.playNext(), this.log_play_prevnext("下一首");
        },
        _onPlayBtnClicked: function() {
            (0, h.addSubCount)("声音页点击播放按钮"), this.onPlayBtnClicked();
        },
        changePlayMode: function() {
            var t = this.data, e = t.currentPlayMode, i = t.playModeList, n = e + 1 >= i.length ? 0 : e + 1;
            return this.setData({
                currentPlayMode: n
            }), this.log_play_mode(), this.playMode(i[n].order), this.playlist().mode;
        },
        findOrder: function(t) {
            var e = 0;
            return l.playModeList.forEach(function(i, n) {
                i.order == t && (e = n);
            }), e;
        },
        toggleBar: function(t) {
            (0, s.getFirstTrackOps)() || t || (0, s.getFirstTrackOps)(!0), this.setData({
                isFunctionBarHide: !t
            });
        },
        showFuncMenu: function() {
            (0, n.genLogger)(30061, "click", {
                item: "展开",
                currPage: "声音页"
            }), o.EventBus.emit("toggleTrackFuncBar", !0);
        },
        hideFuncMenu: function() {
            (0, n.genLogger)(30061, "click", {
                item: "收起",
                currPage: "声音页"
            }), o.EventBus.emit("toggleTrackFuncBar", !1);
        },
        delayShowFuncMenu: function() {
            var t = this;
            this.delayShow && clearTimeout(this.delayShow), this.delayShow = setTimeout(function() {
                t.showFuncMenu();
            }, 1e3);
        },
        delayHideFuncMenu: function() {
            var t = this;
            this.delayHide && clearTimeout(this.delayHide), this.delayHide = setTimeout(function() {
                t.hideFuncMenu();
            }, 3e3);
        },
        initFunctionBar: function() {
            (0, s.getFirstTrackOps)() || this.delayShowFuncMenu();
        },
        genTrackLogger: function(t) {
            var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, a = this.data.currentSource, s = void 0 === a ? {} : a;
            (0, n.genLogger)(t, "click", e(e({}, i), {}, {
                currPageId: s.id
            }));
        },
        log_night_mode: function() {
            this.genTrackLogger(18989);
        },
        log_play_mode: function() {
            this.genTrackLogger(18988);
        },
        log_play_list: function() {
            this.genTrackLogger(17083);
        },
        log_time_close: function() {
            this.genTrackLogger(17082);
        },
        log_play_prevnext: function(t) {
            this.genTrackLogger(17078, {
                item: t
            });
        },
        log_playbtn_click: function() {
            var t = this.data, e = t.playState, i = t.PlayState;
            this.genTrackLogger(51412, {
                item: e === i.PLAYING ? "暂停" : "播放",
                currPage: "WX-newvoicepage"
            });
        },
        nothing: function() {},
        log_click_feedback: function() {
            (0, n.genLogger)(30063, "click", {
                currPage: "声音页"
            });
        }
    }
}));