Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.timerList = exports.speedList = exports.playModeList = exports.PLAYLIST_TYPE = void 0;

exports.timerList = [ {
    content: "不开启",
    duration: 0
}, {
    content: "播完当前声音",
    duration: -1,
    song: 1
}, {
    content: "播完2集声音",
    duration: -1,
    song: 2
}, {
    content: "播完3集声音",
    duration: -1,
    song: 3
}, {
    content: "10分钟后",
    duration: 600
}, {
    content: "20分钟后",
    duration: 1200
}, {
    content: "30分钟后",
    duration: 1800
}, {
    content: "60分钟后",
    duration: 3600
}, {
    content: "90分钟后",
    duration: 5400
} ];

exports.speedList = [ {
    content: "0.5X",
    speed: .5
}, {
    content: "0.75X",
    speed: .75
}, {
    content: "1.0X",
    speed: 1
}, {
    content: "1.25X",
    speed: 1.25
}, {
    content: "1.5X",
    speed: 1.5
}, {
    content: "2.0X",
    speed: 2
} ];

exports.PLAYLIST_TYPE = {
    INIT: "INIT",
    UPPER: "UPPER",
    LOWER: "LOWER"
};

exports.playModeList = [ {
    eng: "ORDERED",
    zh: "顺序播放",
    icon: "iconic_shunxu",
    order: 0
}, {
    eng: "SINGLE_LOOP",
    zh: "单曲循环",
    icon: "iconic_danquxunhuan",
    order: 2,
    iconStyle: "font-size:13px;",
    textStyle: "margin-top:0;"
} ];