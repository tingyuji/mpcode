var t = require("../../common/utils/storage"), i = require("../../common/apis/paid"), a = require("../../packages/lite-player/event"), e = require("../../common/utils/logger"), o = require("../../common/utils/index");

Component({
    properties: {
        albumId: {
            type: Number
        },
        trackId: {
            type: Number
        },
        info: {
            type: Object
        }
    },
    data: {
        albumId: null,
        trackId: null,
        isIphoneX: (0, o.isIPhoneX)(),
        showPriceModal: !1,
        info: {},
        isVipFirst: !1,
        isLogin: (0, t.getUid)(),
        isIos: (0, o.isIos)(),
        hasCoupon: !1,
        coupon: {}
    },
    attached: function() {
        console.log("价格条：", this.data);
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    methods: {
        isCanBuy: function() {
            return !!(0, t.getUid)() || (wx.navigateTo({
                url: "/pages/login/login"
            }), !1);
        },
        closePriceModal: function() {
            this.setData({
                showPriceModal: !1
            });
        },
        toPaid: function() {
            var t = this.data, i = t.info, e = t.trackId;
            this.log_paid(), this.isCanBuy() && (i.discountedPrice ? (console.log("info.unitPrice", i.unitPrice, e), 
            "喜点/集" == i.unitPrice ? e ? a.EventBus.emit("openGModal", {
                buyModal: {
                    visible: !0,
                    trackId: e
                }
            }) : this.showPriceModa() : this.allBuy()) : wx.showToast({
                title: "没有可购买的声音",
                icon: "none"
            }));
        },
        singleBuy: function() {
            if (this.setData({
                showPriceModal: !1
            }), this.data.trackId) {
                var t = this.data.info, i = t.isVIPCT, a = t.isVIPZX, e = !(!i && !a);
                wx.navigateTo({
                    url: "/pages/settlement/settlement?trackId=".concat(this.data.trackId, "&albumId=").concat(this.data.albumId, "&isVipAlbum=").concat(e)
                });
            } else wx.showToast({
                title: "请点击声音进行购买",
                icon: "none"
            });
        },
        allBuy: function() {
            this.setData({
                showPriceModal: !1
            });
            var t = this.data.lastNotBuyPrice, i = this.data.info, a = i.unitPrice, e = i.isVIPCT, o = i.isVIPZX, n = "喜点/集" == a, s = !(!e && !o);
            n && 0 == t ? wx.showToast({
                title: "没有可购买的声音",
                icon: "none"
            }) : wx.navigateTo({
                url: "/pages/settlement/settlement?albumId=".concat(this.data.albumId, "&isSingleAllBuy=").concat(n, "&isVipAlbum=").concat(s)
            });
        },
        toVip: function() {
            this.log_vip(), this.isCanBuy() && a.EventBus.emit("openGModal", {
                vipModal: {
                    visible: !0
                }
            });
        },
        showPriceModa: function() {
            var t = this;
            this.setData({
                showPriceModal: !0
            }), this.data.albumId && !isNaN(Number(this.data.albumId)) && (0, i.querySingleAlbumLastNotBuy)(this.data.albumId).then(function(i) {
                var a = (i.singleBuyPriceInfo || {}).buyPrice;
                t.setData({
                    lastNotBuyPrice: a
                });
            });
        },
        log_paid: function() {
            var t = this.data, i = t.albumId, a = t.trackId, o = t.info;
            (0, e.genLogger)(17348, "click", {
                currPageId: a || i,
                item: "喜点/集" == o.unitPrice ? "单集购买" : "整张购买"
            });
        },
        log_vip: function() {
            var t = this.data, i = t.albumId, a = t.trackId;
            (0, e.genLogger)(17347, "click", {
                currPageId: a || i
            });
        }
    }
});