var e = require("../../common/utils/myAdapter"), t = require("../../common/utils/logger");

Component({
    properties: {
        module: {
            type: Object,
            value: []
        },
        moreText: {
            type: String,
            value: "更多"
        },
        currPage: {
            type: String,
            value: ""
        }
    },
    data: {},
    attached: function() {},
    detached: function() {},
    methods: {
        toAlbum: function(a) {
            var r = this.data.currPage, u = (0, e.getDataset)(a).id;
            u && ("vip" === r ? (0, t.genLogger)(26317, "click", {
                currPage: "VIPpage"
            }) : (0, t.clickRankAlbum)(u), wx.navigateTo({
                url: "/pages/albumDetail/albumDetail?albumId=".concat(u)
            }));
        },
        log_to_more: function() {
            "vip" === this.data.currPage && (0, t.genLogger)(26318, "click", {
                currPage: "VIPpage"
            });
        }
    }
});