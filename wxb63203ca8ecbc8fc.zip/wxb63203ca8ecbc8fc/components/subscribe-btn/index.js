var e = require("../../common/apis/album"), u = require("../../common/utils/wxSubscribe"), b = require("../../common/utils/logger");

Component({
    properties: {
        albumInfo: Object,
        isSubscribe: Boolean,
        pageName: String,
        autoSub: Boolean,
        trackId: String
    },
    data: {},
    methods: {
        subscribeAlbum: function() {
            var b = this, a = this.data, i = a.isSubscribe, r = a.albumInfo.id, o = a.albumInfo, s = a.pageName;
            (i ? e.unsubscribeAlbum : e.subscribeAlbum)(r).then(function() {
                i || (0, u.handleAlbumSub)(o, r, s), b.triggerEvent("onSubscribeChange", {
                    isSubscribe: !i,
                    albumId: r
                }), b.log_subscribe_album(i ? "取消订阅" : "订阅");
            });
        },
        log_subscribe_album: function(e) {
            var u, a, i, r = this.data, o = r.pageName, s = r.albumInfo, t = s.id, n = s.trackId;
            "video" === o ? (u = 33761, i = o) : "track" === o ? (u = 17084, a = n) : "album" === o && (a = t, 
            u = 17097), u && (0, b.genLogger)(u, "click", {
                currPage: i,
                currPageId: a,
                item: e
            });
        }
    }
});