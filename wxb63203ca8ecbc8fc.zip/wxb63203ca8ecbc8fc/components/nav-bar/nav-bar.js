var e = require("../../common/utils/navBar"), t = require("../../common/utils/index"), o = [ "pages/index/index" ];

Component({
    properties: {
        hideBack: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showOption: !0,
        statusBarHeight: (0, e.isOldVersion)() ? 0 : (0, e.getStatusBarHeight)()
    },
    attached: function() {
        var e = (0, t.getCurrentRoute)();
        this.setData({
            showOption: o.indexOf(e) < 0
        });
    },
    methods: {
        toPrev: function() {
            var e = getCurrentPages(), o = e[e.length - 1], a = o.route, n = o.options, i = (n = void 0 === n ? {} : n).fromOldVersion;
            return "pages/albumDetail/albumDetail" === a && "1" === i ? (0, t.toHome)() : getCurrentPages().length > 1 ? wx.navigateBack() : (0, 
            t.toHome)();
        },
        toHome: function() {
            (0, t.toHome)();
        }
    }
});