require("../../common/utils/index");

var e = require("../../common/utils/logger");

Component({
    properties: {
        categories: {
            type: Array,
            value: [],
            observer: function(e) {
                if (e.length > 0) {
                    var t = e.map(this.parseCategory);
                    this.setData({
                        cateList: t,
                        currentCode: t[0] && t[0].code || ""
                    });
                }
            }
        },
        showFocus: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        showMask: !1,
        cateList: [],
        currentCode: ""
    },
    attached: function() {},
    detached: function() {},
    methods: {
        switchCategory: function(e) {
            var t = this.data, a = t.currentCode, o = t.showFocus, n = e.target.dataset || e.currentTarget.dataset, r = n.index, s = n.name, i = n.id;
            r && (o && r !== a && this.setData({
                currentCode: r
            }), this.setData({
                showMask: !1
            }), this.triggerEvent("onTapCategory", {
                index: r,
                name: s,
                id: i
            }));
        },
        parseCategory: function(e) {
            return {
                id: e.categoryId,
                code: e.categoryPinyin || e.code,
                name: e.categoryName || e.displayName,
                hadPaid: (e.categoryName || e.displayName || "").indexOf("付费") > -1
            };
        },
        closeCategoryMask: function() {
            this.setData({
                showMask: !1
            });
        },
        openCategoryMask: function() {
            this.setData({
                showMask: !0
            });
        },
        toChannel: function() {
            (0, e.genLogger)(30115, "click", {
                currPage: "index"
            }), wx.navigateTo({
                url: "/pages/channellist/index"
            });
        }
    }
});