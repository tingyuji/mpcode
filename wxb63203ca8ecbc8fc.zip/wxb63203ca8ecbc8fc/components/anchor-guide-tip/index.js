var e = require("../../common/apis/mineapi"), t = require("../../common/utils/logger"), o = require("../../common/utils/index"), i = require("../../common/apis/index");

Component({
    properties: {
        style: String,
        type: String
    },
    data: {
        isAnchor: !1,
        showCopyCover: !0,
        show: !0
    },
    attached: function() {
        this.currentRoute = (0, o.getCurrentRoute)();
    },
    detached: function() {},
    options: {
        addGlobalClass: !0
    },
    pageLifetimes: {
        show: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var t = this;
            if ((0, o.getUid)()) {
                if ((0, o.get)("CLOSE_ANCHOR_TIP")) return this.setData({
                    show: !1
                });
                (0, o.get)("COPY_COVER_SHOWED") && this.setData({
                    showCopyCover: !1
                });
                var i = (0, o.get)("userInfo"), n = Object.keys(i);
                if (n.indexOf("tracksCount") > -1 && n.indexOf("anchorGrade") > -1) {
                    var r = i.tracksCount;
                    i.anchorGrade;
                    r > 0 && this.showTip();
                } else (0, e.queryUserInfo)({
                    uid: (0, o.getUid)()
                }).then(function(e) {
                    var i = e.tracksCount;
                    e.anchorGrade;
                    i > 0 && t.showTip(), (0, o.set)("userInfo", e);
                });
            }
        },
        showTip: function() {
            var e = this, o = this.data.type;
            this.setData({
                isAnchor: !0
            }, function() {
                "bar" === o && (0, t.genLogger)(27766, "slipPage", {
                    currPage: e.currentRoute
                }), e.hideCopyCover();
            });
        },
        hideCopyCover: function() {
            var e = this;
            (0, o.set)("COPY_COVER_SHOWED", !0), setTimeout(function() {
                e.setData({
                    showCopyCover: !1
                });
            }, 3e3);
        },
        toGuide: function() {
            (0, t.genLogger)(27767, "click", {
                currPage: this.currentRoute
            });
            var e = "".concat(i.origin, "/gatekeeper/mp-anchor-guide&openId=").concat((0, o.getWXAccessOpenId)(), "&uid=").concat((0, 
            o.getUid)());
            wx.navigateTo({
                url: "/pages/webview/index?url=".concat(e)
            });
        },
        close: function() {
            (0, o.set)("CLOSE_ANCHOR_TIP", !0), (0, t.genLogger)(27768, "click", {
                currPage: this.currentRoute
            }), this.setData({
                show: !1
            });
        }
    }
});