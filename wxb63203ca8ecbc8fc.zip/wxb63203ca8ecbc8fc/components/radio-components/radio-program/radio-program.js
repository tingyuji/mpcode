var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../common/apis/parse"), a = require("../../../common/utils/navBar"), r = require("../../../common/utils/logger"), i = require("../../../common/utils/time"), n = require("../../../packages/lite-player/index").createComponent, o = (0, 
a.getNavStatusBarHeight)().navBarHeight;

Component(n({
    properties: {
        isTabBarFixed: Boolean,
        radio: Object,
        dayPrograms: {
            type: Array,
            observer: function(e, t) {
                if (!t || e.length !== t.length || JSON.stringify(e) !== JSON.stringify(t)) {
                    var a = !e.find(function(e) {
                        return e.programs.length > 0;
                    });
                    this.setData({
                        emptyDayPrograms: a
                    });
                }
            }
        },
        changeRadios: Array,
        tabIndex: Number,
        playListInfo: {
            type: Object,
            observer: function(t, a) {
                var r = t.playList, i = t.index;
                a && r.length === a.playList.length && i === a.index && JSON.stringify(r) === JSON.stringify(a.playList) || (this.playlist(r), 
                this.playRadio(e({}, r[i])));
            }
        }
    },
    data: {
        tabIndex: -1,
        fixedTopStyle: "top:".concat(o, "px;"),
        emptyDayPrograms: !1,
        titleWidth: 0
    },
    observers: {
        playState: function(e) {
            this.triggerEvent("onPlayStateChange", e);
        }
    },
    attached: function() {
        var e = this;
        wx.createSelectorQuery().in(this).select(".radio-detail").boundingClientRect(function(t) {
            var a = t.width;
            e.setData({
                titleWidth: "".concat(a - 100, "px")
            });
        }).exec();
    },
    methods: {
        onTabClick: function(e) {
            this.setData({
                tabIndex: e.currentTarget.dataset.index
            });
        },
        onProgramChange: function(e) {
            var a = e.currentTarget.dataset.program, n = a.isLive, o = a.startTime, s = a.endTime, d = a.programScheduledId;
            if (n && !(0, i.isLiveStreaming)({
                type: i.TODAY,
                startTime: o,
                endTime: s
            })) this.triggerEvent("onUpdateLiveProgram", d); else {
                var g = (0, t.parseRadioProgram)(this.data.radio, a, n);
                this.playRadio(g);
            }
            n || (0, r.genLogger)(30732, "click", {
                currModule: "广播播放回放节目",
                radioId: this.data.radio.id,
                item: a,
                currPage: "radio"
            });
        },
        favoriteChange: function() {
            this.triggerEvent("onFavoriteChange");
        },
        shareRadio: function() {
            (0, r.genLogger)(30730, "click", {
                radioId: this.data.radio.id,
                currModule: "广播播放分享",
                currPage: "radio"
            });
        }
    }
}));