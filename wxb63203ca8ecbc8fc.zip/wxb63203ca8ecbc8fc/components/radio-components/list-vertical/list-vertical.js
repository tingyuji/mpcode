var a = require("../../../common/apis/parse"), r = require("../../../common/utils/logger"), o = require("../../../packages/lite-player/index").createComponent;

Component(o({
    properties: {
        className: String,
        focusRadios: Array,
        radios: Array,
        hasMore: Boolean
    },
    methods: {
        jumpToProgramList: function(a) {
            var o = a.currentTarget.dataset, e = o.radioinfo, i = o.radioinfo, d = i.id, t = i.name, c = i.programScheduleId, n = this.data, l = n.playState, s = n.currentSource;
            if (this.data.className) {
                var g = s.id === c ? l : null;
                this.onChangeRadiosClick(e, g);
            } else wx.navigateTo({
                url: "/pages/radio-program-play/radio-program-play?radioId=".concat(d)
            }), (0, r.genLogger)(30725, "click", {
                currModule: "找电台：radioId:".concat(d, ",radioName:").concat(t),
                currPage: "radioPlay"
            });
        },
        onChangeRadiosClick: function(a, o) {
            var e = a.id, i = a.name, d = this.data, t = d.currentSource, c = d.PlayState, n = c.PAUSE;
            o === c.PLAYING || o === n ? this.playRadio(t, !0) : this.triggerEvent("onRadioChange", {
                radioId: e
            }, {
                bubbles: !0,
                composed: !0
            }), (0, r.genLogger)(30733, "click", {
                radioId: e,
                currModule: "换台列表电台点击：radioId:".concat(e, ",radioName:").concat(i),
                currPage: "radio"
            });
        },
        onClickPlay: function(o) {
            var e = o.currentTarget.dataset, i = e.radioinfo, d = e.radioinfo, t = d.id, c = d.name, n = d.coverSmall, l = d.playUrl, s = d.programId, g = d.programName, m = d.programScheduleId, u = e.radioplaystate, p = this.data, h = p.className, y = p.currentSource, I = p.PlayState, P = I.PAUSE, S = I.PLAYING, f = I.INITIAL;
            if (h) this.onChangeRadiosClick(i, u); else {
                var v = "";
                if (u === S || u === P) this.playRadio(y, !0), v = u === S ? "暂停" : "播放"; else if (u === f) {
                    var C = {
                        id: t,
                        name: c,
                        coverSmall: n
                    }, N = {
                        name: g,
                        id: s,
                        programScheduleId: m,
                        radioPlayUrlDTO: l
                    }, R = (0, a.parseRadioProgram)(C, N, !0);
                    this.playlist([ R ]), this.playRadio(R), v = "播放";
                }
                v && (0, r.genLogger)(33715, "click", {
                    item: v,
                    program: "radioId:".concat(t, ",radioName:").concat(c, ",programScheduleId: ").concat(m),
                    currModule: "找电台列表-播放暂停icon",
                    currPage: "radioPlay"
                });
            }
        }
    }
}));