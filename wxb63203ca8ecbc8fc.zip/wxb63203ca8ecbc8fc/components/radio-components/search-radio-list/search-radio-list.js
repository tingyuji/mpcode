var o = require("../../../@babel/runtime/helpers/defineProperty"), e = require("../../../@babel/runtime/helpers/objectSpread2"), a = require("../../../common/apis/radio"), t = require("../../../common/utils/index");

Component({
    properties: {
        searchRadioInitInfo: {
            type: Object,
            observer: function(o, e) {
                var a = o && o.categories && o.categories.length >>> 0, t = e && e.categories && e.categories.length >>> 0;
                a > 0 && !t && this.init();
            }
        },
        scrollSelectedFixed: Boolean
    },
    data: {
        categoryLocationInfo: {
            categories: [],
            locations: [],
            locationId: 0,
            locationTypeId: 0,
            categoryId: 0
        },
        searchListInfo: {
            focusRadios: [],
            radios: [],
            pageNum: 1,
            total: 0,
            hasMore: !1
        },
        searchLoading: !1
    },
    attached: function() {
        var o = this;
        this.getSearchScrollTop(function(e) {
            var a = e.scrollTop;
            o.positionScrollTop = a;
        });
    },
    methods: {
        getSearchScrollTop: function(o) {
            var e = wx.createSelectorQuery().in(this);
            e.selectViewport().scrollOffset(), e.select(".search-radio-container").boundingClientRect(), 
            e.exec(function(e) {
                var a = e[0].scrollTop + e[1].top;
                o({
                    scrollTop: a,
                    eleTop: e[1].top
                });
            });
        },
        init: function() {
            var o = this.data.searchRadioInitInfo, e = o.categories, a = o.locations, t = o.focusRadios, i = o.searchRadios;
            this.setData({
                categoryLocationInfo: {
                    categories: e,
                    locations: a,
                    locationId: 0,
                    locationTypeId: 0,
                    categoryId: 0
                },
                searchListInfo: {
                    focusRadios: t,
                    radios: i,
                    pageNum: 1,
                    total: 0,
                    hasMore: !0
                }
            });
        },
        onSelectChange: function(a) {
            var t, i = this, r = a.detail, c = r.key, n = r.index, s = r.arrKey, d = this.data.categoryLocationInfo, l = d[s][n], h = l.id, p = l.type, g = e(e({}, d), {}, (o(t = {}, c, h), 
            o(t, "locationTypeId", void 0 === p ? d.locationTypeId : p), t));
            this.onSearchRadios(g, 1, function() {
                i.triggerEvent("onScrollTopChange", i.positionScrollTop - 80, {
                    bubbles: !0,
                    composed: !0
                });
            });
        },
        onSearchRadios: function(o, t, i) {
            var r = this, c = o.categoryId, n = o.locationId, s = o.locationTypeId;
            this.setData({
                searchLoading: !0
            }), (0, a.searchRadiosWithLoCaId)({
                categoryId: c,
                locationId: n,
                locationTypeId: s,
                pageNum: t,
                pageSize: 10
            }).then(function(a) {
                var c = a.total, n = a.radios, s = r.data.searchListInfo;
                r.setData({
                    categoryLocationInfo: o,
                    searchListInfo: e(e({}, s), {}, {
                        radios: 1 === t ? n : [].concat(s.radios, n),
                        pageNum: t,
                        total: c,
                        hasMore: r.hasMore(c, t),
                        searchLoading: !1
                    })
                }), i && i();
            });
        },
        hasMore: function(o, e) {
            var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10;
            return o > e * a;
        },
        onLoadMore: (0, t.debounce)(function() {
            var o = this.data, e = o.categoryLocationInfo, a = o.searchListInfo, t = a.pageNum;
            a.hasMore && this.onSearchRadios(e, t + 1);
        }, 200)
    }
});