var t = require("../../../common/utils/navBar"), e = require("../../../common/utils/logger"), a = (0, 
t.getNavStatusBarHeight)().navBarHeight;

Component({
    properties: {
        info: {
            type: Object,
            observer: function(t, e) {
                var a = this.data.info, o = a.locations, i = a.categories;
                if (t.locations.length > 0 && (!this.data.locationName || t.locationId !== e.locationId || t.locationTypeId !== e.locationTypeId || t.categoryId !== e.categoryId)) {
                    var n = function(e, a) {
                        return e.find(function(e) {
                            var o = e.id, i = e.type;
                            return o === a && (void 0 === i || i === t.locationTypeId);
                        }).name;
                    };
                    this.setData({
                        locationName: n(o, t.locationId),
                        categoryName: n(i, t.categoryId)
                    });
                }
            }
        },
        scrollSelectedFixed: {
            type: Boolean,
            observer: function(t, e) {
                t !== e && (this.data.showMask || this.setData({
                    searchFixed: t
                }));
            }
        }
    },
    data: {
        showOptions: !1,
        options: [],
        activeSelectKey: "",
        locationName: "",
        categoryName: "",
        searchFixed: !1,
        showMask: !1,
        fixedTopStyle: "top:".concat(a, "px;")
    },
    observers: {
        showOptions: function(t) {
            var e = this.data.scrollSelectedFixed;
            this.setData({
                searchFixed: t || e,
                showMask: t
            });
        }
    },
    methods: {
        selectToggle: function(t) {
            var e = this.data, a = e.showOptions, o = e.activeSelectKey, i = t.currentTarget.dataset.activekey, n = !1;
            i === o ? (n = !a, this.setData({
                showOptions: n,
                activeSelectKey: ""
            })) : (n = !0, this.setData({
                activeSelectKey: i,
                showOptions: n,
                options: this.getOptions(i)
            }));
        },
        getOptions: function(t) {
            var e = [], a = this.data.info, o = a.locations, i = a.categories, n = a.locationId, c = a.locationTypeId, s = a.categoryId;
            return "locationId" === t ? e = o.map(function(t) {
                return {
                    id: t.id,
                    name: t.name,
                    selected: t.id === n && t.type === c
                };
            }) : "categoryId" === t && (e = i.map(function(t) {
                return {
                    id: t.id,
                    name: t.name,
                    selected: t.id === s
                };
            })), e;
        },
        hideSelect: function() {
            this.data.searchFixed && this.setData({
                showOptions: !1,
                activeSelectKey: ""
            });
        },
        onChange: function(t) {
            var a = this.data, o = a.activeSelectKey, i = a.options, n = t.currentTarget.dataset.index, c = "locationId" === o ? "locations" : "categories";
            this.setData({
                showOptions: !1,
                activeSelectKey: ""
            }), this.triggerEvent("onSelectChange", {
                arrKey: c,
                key: o,
                index: n
            }), (0, e.genLogger)(30724, "click", {
                item: "".concat("locationId" === o ? "地区" : "分类", "：").concat(i[n].name),
                currModule: "广播筛选项",
                currPage: "radioPlay"
            });
        }
    }
});