var e = require("../../../common/utils/navBar"), a = require("../../../common/utils/index"), t = (0, 
e.getNavStatusBarHeight)(), r = t.statusBarHeight, i = t.navBarHeight;

Component({
    properties: {
        className: String,
        fixed: {
            type: Boolean,
            value: !0
        },
        bChange: Boolean
    },
    data: {
        statusBarHeight: r,
        navBarHeight: i
    },
    methods: {
        toPrev: function() {
            (0, a.getCurrentRoute)().indexOf("pages/radio/radio") > -1 ? (0, a.toHome)() : getCurrentPages().length <= 1 ? wx.reLaunch({
                url: "/pages/radio/radio"
            }) : wx.navigateBack();
        }
    }
});