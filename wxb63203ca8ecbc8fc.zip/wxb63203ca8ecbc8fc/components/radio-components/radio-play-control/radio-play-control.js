var e = require("../../../@babel/runtime/helpers/objectSpread2"), i = require("../../../common/utils/index"), t = require("../../../common/utils/myAdapter"), r = require("../../../common/utils/time"), o = require("./const"), a = require("../../../common/utils/logger"), s = require("../../../packages/lite-player/index").createComponent;

Component(s({
    properties: {
        radioId: String,
        changeRadios: Array,
        type: String,
        emptyDayPrograms: Boolean
    },
    data: {
        showTimer: !1,
        timerList: o.timerList,
        showList: !1,
        showTime: 0,
        showTimeStr: "00:00",
        movingTime: 0,
        touchMoving: !1,
        movingTimeStr: ""
    },
    observers: {
        "currentTime,currentSource": function(e, i) {
            if (i.isLive) {
                var t = this.data, o = t.emptyDayPrograms, a = t.duration, s = (0, r.currentTimeSecond)(i.album.startTime);
                a > 0 && s > a ? o ? this.setData({
                    showTime: 0,
                    showTimeStr: (0, r.parseTime)(0)
                }) : this.triggerEvent("onUpdateLiveProgram", {}, {
                    bubbles: !0,
                    composed: !0
                }) : this.setData({
                    showTime: s,
                    showTimeStr: (0, r.parseTime)(s)
                });
            } else this.setData({
                showTime: e,
                showTimeStr: this.data.currentTimeStr
            });
        }
    },
    attached: function() {
        var e = this;
        this.touchMoveHandle = (0, i.throttle)(this._touchMoveHandle, 20), this.windowWidth = wx.getSystemInfoSync().windowWidth, 
        wx.createSelectorQuery().in(this).select(".progressAll").boundingClientRect(function(i) {
            e.progressWidth = i.width, e.padding = Math.floor((e.windowWidth - e.progressWidth) / 2);
        }).exec();
    },
    methods: {
        _onPlayBtnClicked: function() {
            var e = this.data, i = e.radioId, t = e.currentSource, r = e.playState, o = e.PlayState;
            this.playRadio(t, !0);
            var s = r === o.PLAYING ? "暂停" : r === o.PAUSE ? "播放" : "";
            s && (0, a.genLogger)(30727, "click", {
                program: t,
                item: s,
                radioId: i,
                currModule: "广播播放页-点击播放/暂停",
                currPage: "radio"
            });
        },
        sliderchanging: function(e) {
            this.sliderHandler(e.detail.value, !0);
        },
        sliderchange: function(e) {
            var i = e.detail.value;
            this.sliderHandler(i), this.seek(i);
        },
        sliderHandler: function(i, t) {
            var o = !!t, a = (0, r.parseTime)(i), s = o ? {
                movingTime: i,
                movingTimeStr: a
            } : {
                showTime: i,
                showTimeStr: a
            };
            console.log("进度： showTime:".concat(i, ",showTimeStr:").concat(a, ",changing:").concat(t)), 
            this.setData(e({
                touchMoving: o
            }, s));
        },
        showList: function() {
            (0, a.genLogger)(30729, "click", {
                currModule: "广播播放-换台",
                radioId: this.data.radioId,
                currPage: "radio"
            }), this.setData({
                showList: !0
            });
        },
        closeList: function() {
            this.setData({
                showList: !1
            });
        },
        showTimer: function() {
            (0, a.genLogger)(30728, "click", {
                currModule: "广播播放-定时关闭",
                radioId: this.data.radioId,
                currPage: "radio"
            }), this.setData({
                showTimer: !0
            });
        },
        closeTimer: function() {
            this.setData({
                showTimer: !1
            });
        },
        changeTimer: function(e) {
            var i = (0, t.getDataset)(e), r = i.timer, o = i.index, a = this.data, s = a.currentTimer, n = a.delayDuration, d = a.playState, c = a.PlayState;
            if (o === s && n || d !== c.PAUSE && d !== c.PLAYING && d !== c.ENDED) return this.closeTimer();
            this.delayClose(r.duration, 0 !== r.duration, o), this.setData({
                showTimer: !1
            });
        },
        jumpToRadioList: function() {
            (0, a.genLogger)(30734, "click", {
                currModule: "广播播放-换台列表-点击全部电台",
                radioId: this.data.radioId,
                currPage: "radio"
            }), wx.navigateTo({
                url: "/pages/radio/radio"
            });
        }
    }
}));