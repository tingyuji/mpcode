Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.timerList = exports.PLAYLIST_TYPE = void 0;

exports.timerList = [ {
    content: "不开启",
    duration: 0
}, {
    content: "10分钟",
    duration: 600
}, {
    content: "20分钟",
    duration: 1200
}, {
    content: "30分钟",
    duration: 1800
}, {
    content: "60分钟",
    duration: 3600
}, {
    content: "90分钟",
    duration: 5400
} ];

exports.PLAYLIST_TYPE = {
    INIT: "INIT",
    UPPER: "UPPER",
    LOWER: "LOWER"
};