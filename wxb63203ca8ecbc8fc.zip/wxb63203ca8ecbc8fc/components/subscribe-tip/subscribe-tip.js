var e = require("../../packages/lite-player/event"), t = require("../../common/utils/navBar");

Component({
    properties: {
        showSubsribeTip: {
            value: !1,
            type: Boolean
        }
    },
    data: {
        bottomValue: .5 * (0, t.getScreenHeight)() - ((0, t.getSafeHeight)() > 750 ? 100 : 0) - ((0, 
        t.isAndroid)() && (0, t.getSafeHeight)() > 750 ? (0, t.getSafeTopHeight)() : 0)
    },
    attached: function() {
        this._show = this.showTip.bind(this), e.EventBus.on("showSubTip", this._show);
    },
    detached: function() {
        e.EventBus.off("showSubTip", this._show);
    },
    methods: {
        showTip: function(e) {
            this.setData({
                showSubsribeTip: e
            });
        }
    }
});