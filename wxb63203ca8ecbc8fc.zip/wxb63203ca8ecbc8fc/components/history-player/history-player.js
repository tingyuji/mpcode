var e = require("../../common/apis/mineapi"), t = require("../../common/utils/myAdapter"), a = require("../../common/utils/logger"), r = require("../../common/utils/wxSubscribe"), o = require("../../packages/lite-player/index").createComponent;

Component(o({
    properties: {},
    data: {
        trackData: {
            yesterday: [],
            earlier: []
        },
        showNullBlock: !0
    },
    attached: function() {
        this.getListenedTracks();
    },
    methods: {
        getListenedTracks: function() {
            var t = this;
            wx.showToast({
                icon: "loading",
                title: "加载中"
            }), (0, e.queryGetListened)().then(function(e) {
                wx.hideToast();
                var a = e || {}, r = a.yesterday, o = void 0 === r ? [] : r, i = a.earlier, n = void 0 === i ? [] : i, c = a.today, s = void 0 === c ? [] : c, d = 0 === o.length && 0 === s.length && 0 === n.length;
                t.setData({
                    trackData: {
                        yesterday: e.yesterday,
                        earlier: e.earlier,
                        today: e.today
                    },
                    showNullBlock: d
                });
            }).catch(function(e) {
                console.log("error", e), wx.hideToast();
            });
        },
        onClickTrack: function(e) {
            (0, r.addSubCount)("我页历史声音");
            var a = (0, t.getDataset)(e).track;
            wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(a.id, "&breakSecond=").concat(a.breakSecond || 0)
            });
        },
        delete: function(r) {
            var o = this;
            (0, a.genLoggerClick)(17862, "XX", {
                currPage: "my"
            });
            var i = (0, t.getDataset)(r).id;
            wx.showModal({
                title: "确定删除该条历史记录？",
                success: function(t) {
                    t.confirm && (0, e.deleteListenedTrack)(i).then(function() {
                        o.getListenedTracks();
                    });
                }
            });
        },
        clickTrack: function() {
            (0, a.genLogger)(17136, "click", {
                currPage: "my",
                moduleName: "历史"
            });
        }
    }
}));