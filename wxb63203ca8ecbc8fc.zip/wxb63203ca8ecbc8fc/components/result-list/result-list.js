var e = require("../../common/utils/index"), r = require("../../common/utils/logger").genLoggerClick, a = require("../../packages/lite-player/index").createComponent;

Component(a({
    properties: {
        tracks: {
            type: Array,
            value: [],
            observer: function(e, r) {}
        },
        albums: {
            type: Array,
            value: [],
            observer: function(e, r) {}
        },
        users: {
            type: Array,
            value: [],
            observer: function(e, r) {}
        },
        source: {
            type: Object,
            value: null
        },
        type: {
            type: String,
            value: ""
        }
    },
    methods: {
        toAlbum: function(a) {
            r(27216, "", {
                moduleName: "专辑",
                currPage: "searchresult"
            }), (0, e.toAlbum)((0, e.getAlbum)(a, this.data.albums));
        },
        clickTrack: function(e) {
            var a = e.currentTarget.dataset.track;
            r(27217, "", {
                moduleName: "声音",
                currPage: "searchresult"
            }), wx.navigateTo({
                url: "/pages/soundPage/soundPage?trackId=".concat(a.id)
            });
        },
        log_click_anchor: function() {
            r(27215, "", {
                moduleName: "主播",
                currPage: "searchresult"
            });
        }
    }
}));