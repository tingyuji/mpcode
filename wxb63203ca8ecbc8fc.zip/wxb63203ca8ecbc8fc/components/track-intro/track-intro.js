var t = require("../../common/utils/logger").genLogger;

Component({
    properties: {
        id: {
            type: Number,
            value: 0,
            observer: function(t, e) {
                t !== e && this.init();
            }
        },
        richIntro: {
            type: String | Array,
            value: ""
        }
    },
    data: {
        hide: !1,
        showAll: !1,
        hideControl: !1
    },
    created: function() {},
    attached: function() {
        this.init();
    },
    ready: function() {},
    detached: function() {},
    methods: {
        init: function() {
            var t = this;
            this.height = 0, this.setData({
                hide: !1,
                showAll: !1
            }, function() {
                return t.queryHeight();
            });
        },
        queryHeight: function() {
            var t = this;
            wx.createSelectorQuery().in(this).select(".intro-content").boundingClientRect(function(e) {
                var i = (e || {}).height, n = void 0 === i ? 80 : i;
                return t.height ? t.height === n ? (t.setData({
                    hideControl: !0
                }), t.showAll()) : void t.setData({
                    hide: !0
                }) : (t.height = n, void t.setData({
                    hide: !0
                }, function() {
                    return t.queryHeight();
                }));
            }).exec();
        },
        showAll: function() {
            this.logger_intro_click("展开"), this.setData({
                hide: !1,
                showAll: !0
            });
        },
        hideAll: function() {
            this.logger_intro_click("收起"), this.triggerEvent("onhide"), this.setData({
                hide: !0,
                showAll: !1
            });
        },
        logger_intro_click: function(e) {
            t(26325, "click", {
                item: e,
                currPage: "声音页"
            });
        }
    }
});