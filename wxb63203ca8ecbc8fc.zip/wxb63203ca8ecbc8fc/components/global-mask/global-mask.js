var e = require("../../packages/lite-player/event"), t = require("../../common/utils/storage"), i = require("../../common/utils/navBar"), n = [ {
    text: "日间模式",
    icon: "icontaiyang-",
    filter: "0"
}, {
    text: "夜间模式1",
    icon: "iconyejianmoshi",
    filter: "0.1"
}, {
    text: "夜间模式2",
    icon: "iconyejianmoshi",
    filter: "0.25"
}, {
    text: "夜间模式3",
    icon: "iconyejianmoshi",
    filter: "0.4"
} ];

Component({
    properties: {},
    data: {
        opFilter: n[(0, t.get)("night_mode") || 0].filter
    },
    pageLifetimes: {
        show: function() {
            this.change();
        }
    },
    attached: function() {
        this._change = this.change.bind(this), e.EventBus.on("changeNightMode", this._change);
    },
    detached: function() {
        e.EventBus.off("changeNightMode", this._change);
    },
    methods: {
        change: function(e) {
            var a = n[0 == e ? 0 : (0, t.get)("night_mode") || 0].filter;
            (e || 0 == e) && (0, t.set)("night_mode", e), 0 == a && (0, i.changeNavBarStyle)(), 
            a > 0 && (0, i.changeNavBarStyle)("night"), this.setData({
                opFilter: a
            });
        }
    }
});