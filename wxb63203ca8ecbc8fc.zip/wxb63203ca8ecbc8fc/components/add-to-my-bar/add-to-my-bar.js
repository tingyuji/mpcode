var e = require("../../common/utils/index"), i = require("../../common/utils/storage"), t = require("../../common/utils/logger"), o = require("../../packages/lite-player/event");

Component({
    properties: {},
    data: {
        showTip: !(0, i.get)("close_add_tip") && !(0, e.hideAddToMyTip)(),
        isIos: (0, e.isIos)(),
        isAndroid: (0, e.isAndroid)()
    },
    attached: function() {
        this.init();
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var o = this.data, s = o.isIos, d = o.isAndroid;
            this.setData({
                showTip: !(0, i.get)("close_add_tip") && !(0, e.hideAddToMyTip)()
            }), (0, i.get)("close_add_tip") || (0, e.hideAddToMyTip)() || (s && (0, t.genLogger)(17860, "exposure", {
                currPage: "index"
            }), d && (0, t.genLogger)(17858, "exposure", {
                currPage: "index"
            }));
        },
        close: function() {
            var e = this.data, s = e.isAndroid, d = e.isIos;
            this.setData({
                showTip: !1
            }), o.EventBus.emit("close_add_tip"), (0, i.set)("close_add_tip", !0), d && (0, 
            t.genLoggerClick)(17861, "XX", {
                currPage: "index"
            }), s && (0, t.genLoggerClick)(17857, "XX", {
                currPage: "index"
            });
        }
    }
});