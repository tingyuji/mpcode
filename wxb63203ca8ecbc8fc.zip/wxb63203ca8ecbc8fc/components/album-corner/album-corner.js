var e = require("../../common/utils/navBar");

Component({
    properties: {
        albumTag: {
            type: Number,
            value: !1,
            observer: function(e, i) {
                e !== i && this.init();
            }
        },
        albumPreferTag: {
            type: Number,
            value: !1,
            observer: function(e, i) {
                e !== i && this.init();
            }
        },
        vipType: {
            type: Number,
            value: !1,
            observer: function(e, i) {
                e !== i && this.init();
            }
        },
        isTimeLimited: {
            type: Boolean,
            value: !1,
            observer: function(e, i) {
                e !== i && this.init();
            }
        },
        albumSubscript: {
            type: Number,
            value: 0,
            observer: function(e, i) {
                e !== i && this.init();
            }
        }
    },
    addGlobalClass: !0,
    created: function() {},
    attached: function() {},
    ready: function() {
        this.init();
    },
    detached: function() {},
    methods: {
        init: function() {
            var i = this.data.albumSubscript, a = i ? this.transAlbumScript(i) : this.queryAlbumTypeClass();
            (0, e.isIos)() && (a = ""), this.setData({
                className: a
            });
        },
        transAlbumScript: function(e) {
            var i = "";
            switch (e) {
              case 1:
                i = "prefer";
                break;

              case 2:
                i = "vip";
                break;

              case 3:
                i = "prefer-vip";
                break;

              case 4:
                i = "paid";
                break;

              case 5:
              case 17:
                i = "prefer-paid";
                break;

              case 8:
                i = "xinpinxianmian";
            }
            return i;
        },
        queryAlbumTypeClass: function() {
            var e = this.data, i = e.albumTag, a = e.albumPreferTag, r = (e.vipType, ""), t = 1 == a;
            if (e.isTimeLimited) return r = "xinpinxianmian";
            switch (i) {
              case 0:
                r = t && "prefer";
                break;

              case 1:
                r = t ? "prefer-paid" : "paid";
                break;

              case 2:
                r = t ? "prefer-vip" : "vip";
                break;

              case 3:
                r = "xinpixianmian";
            }
            return r;
        }
    }
});