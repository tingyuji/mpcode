require("../../@babel/runtime/helpers/objectSpread2");

var e = require("../../packages/lite-player/event"), i = require("../../common/utils/storage"), t = (require("../../common/apis/point"), 
require("../../common/utils/logger")), o = require("../../common/utils/index");

Component({
    properties: {
        trackId: Number,
        pointInfo: {
            type: Object,
            value: {},
            observer: function(e, i) {
                this.isLogin();
            }
        }
    },
    addGlobalClass: !0,
    data: {},
    attached: function() {},
    detached: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    methods: {
        isLogin: function() {
            this.setData({
                isLogin: (0, i.getUid)()
            });
        },
        openPointModal: function() {
            var i = this.data, t = i.trackId, o = i.pointInfo;
            o.currentPoint, o.priceForPoint, o.isExceedMaxExchangeTime;
            this.log_point_click(), this.data.isLogin ? e.EventBus.emit("openGModal", {
                buyModal: {
                    visible: !0,
                    trackId: t
                }
            }) : wx.navigateTo({
                url: "/pages/login/login"
            });
        },
        log_point_click: function() {
            var e = (0, o.getCurrPage)();
            (0, t.genLogger)(17104, "click", {
                currPageId: e.options.albumId || e.options.trackId,
                trackId: this.data.trackId
            });
        }
    }
});