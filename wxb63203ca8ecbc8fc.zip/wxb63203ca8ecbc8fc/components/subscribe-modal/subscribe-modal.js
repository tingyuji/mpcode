var e = require("../../packages/lite-player/event"), o = require("../../common/utils/index");

Component({
    properties: {
        pageType: {
            type: String,
            value: ""
        }
    },
    data: {
        modalVisible: !1,
        info: {},
        currentPage: ""
    },
    attached: function() {
        this._show = this.showModal.bind(this), this._close = this.closeModal.bind(this), 
        e.EventBus.on("showSubModal", this._show), e.EventBus.on("closeSubModal", this._close);
    },
    detached: function() {
        e.EventBus.off("showSubModal", this._show), e.EventBus.off("closeSubModal", this._close);
    },
    methods: {
        showModal: (0, o.debounce)(function(e) {
            var o = e.info, s = e.currentPage;
            this.setData({
                info: o,
                currentPage: s,
                modalVisible: !0
            });
        }),
        close: function() {
            e.EventBus.emit("closeSubModal");
        },
        closeModal: function() {
            this.setData({
                modalVisible: !1
            });
        },
        closeShare: function() {
            this.close();
        }
    }
});