var t = require("../../common/apis/sleep"), a = require("../../packages/lite-player/index").createComponent;

Component(a({
    properties: {
        sleepTrack: {
            type: Object,
            observer: function(t, a) {
                t && t.trackId && this.setData({
                    curTrack: t
                });
            }
        }
    },
    data: {
        trackList: [],
        curTrack: {}
    },
    attached: function() {
        1 === Number(this.data.playState) && this.triggerEvent("changePlaystate", {
            playState: "playing",
            track: this.data.curTrack
        });
    },
    detached: function() {},
    methods: {
        initAudio: function(a) {
            var i = this;
            (0, t.getPlayInfo)(a.trackId).then(function(t) {
                var a = t.data;
                i.setData({
                    curTrack: a
                }), i.play(a);
            });
        },
        onPlay: function(t) {
            var a = this.data, i = (a.currentSource.id, a.playState), e = a.PlayState, r = e.PAUSE, c = e.PLAYING;
            i === r ? t.isFirst ? (this.play(), this.triggerEvent("changePlaystate", {
                playState: "playing",
                track: this.data.curTrack
            }), this.initAudio(this.data.curTrack)) : (this.triggerEvent("changePlaystate", {
                playState: "playing",
                track: this.data.curTrack
            }), this.play()) : i === c ? t.isFirst ? (this.play(), this.initAudio(this.data.curTrack), 
            this.triggerEvent("changePlaystate", {
                playState: "playing",
                track: this.data.curTrack
            })) : (this.triggerEvent("changePlaystate", {
                playState: "stop",
                track: this.data.curTrack
            }), this.play()) : (this.initAudio(this.data.curTrack), this.triggerEvent("changePlaystate", {
                playState: "playing",
                track: this.data.curTrack
            }));
        }
    }
}));