var e = require("../../common/utils/image");

Component({
    properties: {
        item: Object,
        width: Number,
        replaceStyle: String
    },
    data: {
        defaultCover: ""
    },
    created: function() {},
    attached: function() {},
    ready: function() {},
    detached: function() {},
    methods: {
        imageError: function() {
            this.setData({
                defaultCover: e.defaultAlbumImg
            });
        }
    }
});