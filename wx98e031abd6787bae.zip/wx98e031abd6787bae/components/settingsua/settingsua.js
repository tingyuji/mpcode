Component({
    properties: {},
    data: {
        index: 2
    },
    methods: {}
});