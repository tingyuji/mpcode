var e = require("@babel/runtime/helpers/interopRequireDefault")(require("@babel/runtime/regenerator")), t = require("@babel/runtime/helpers/asyncToGenerator"), r = require("utils/wxRequest"), n = require("utils/wxApi");

App({
    onShow: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                var r = t.screenHeight, n = t.screenWidth, a = t.statusBarHeight;
                e.globalData.isFullScreen = parseInt(n / r * 100) < parseInt(9 / 17 * 100), e.globalData.statusBarHeight = a, 
                e.globalData.capsuleBarHeight = 44, e.globalData.screenHeight = r, e.globalData.screenWidth = n;
            }
        }), this.globalData.inited = this.init();
    },
    init: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var n, a, s, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = "null", e.prev = 1, e.next = 4, r.parseQrcode();

                  case 4:
                    a = e.sent, s = a.user_id, c = a.scene_id, n = s, r.globalData.qrcode_scene_scene_id = c, 
                    e.next = 13;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(1);

                  case 13:
                    return wx.getStorageSync("inviter") || wx.setStorageSync("inviter", n), e.prev = 14, 
                    e.next = 17, r.checkSessionValid();

                  case 17:
                    return e.next = 19, r.getTideUserInfo();

                  case 19:
                    r.globalData.userInfo.nickname || r.setUserInfo(), e.next = 25;
                    break;

                  case 22:
                    throw e.prev = 22, e.t1 = e.catch(14), "user not logined";

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 11 ], [ 14, 22 ] ]);
        }))();
    },
    parseQrcode: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var a, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, !(a = n.globalData.qrcode_scene)) {
                        e.next = 7;
                        break;
                    }
                    return e.next = 5, r({
                        url: "/v1/tidesleep/qrcode_info",
                        data: {
                            id: a
                        }
                    });

                  case 5:
                    return s = e.sent, e.abrupt("return", s);

                  case 7:
                    e.next = 12;
                    break;

                  case 9:
                    throw e.prev = 9, e.t0 = e.catch(0), e.t0;

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 9 ] ]);
        }))();
    },
    getTideUserInfo: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var a;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, r({
                        url: "/wechatmp/users/self"
                    });

                  case 2:
                    a = e.sent, n.globalData.userInfo = a;

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    checkSessionValid: function() {
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (wx.getStorageSync("sid")) {
                        e.next = 5;
                        break;
                    }
                    throw "sid not exist";

                  case 5:
                    return r = n.wxCheckSession(), e.next = 8, r();

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    checkUserAuth: function() {
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = n.wxGetSetting(), e.next = 3, r();

                  case 3:
                    if (e.sent.authSetting["scope.userInfo"]) {
                        e.next = 6;
                        break;
                    }
                    throw "user not auth";

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    login: function() {
        var r = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r.globalData.userInfo && r.globalData.userInfo.nickname) {
                        e.next = 14;
                        break;
                    }
                    return e.prev = 1, e.next = 4, r.checkSessionValid();

                  case 4:
                    return e.next = 6, r.getTideUserInfo();

                  case 6:
                    if (r.globalData.userInfo.nickname) {
                        e.next = 9;
                        break;
                    }
                    return e.next = 9, r.setUserInfo();

                  case 9:
                    e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(1), r.relogin();

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 1, 11 ] ]);
        }))();
    },
    relogin: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var s, c, u, i, o, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = n.wxLogin(), e.next = 3, s();

                  case 3:
                    return c = e.sent, u = {
                        code: c.code
                    }, "null" !== (i = wx.getStorageSync("inviter")) && Object.assign(u, {
                        inviter: i
                    }), e.next = 9, r({
                        url: "/v1/wechat_mp_login",
                        method: "POST",
                        data: u
                    });

                  case 9:
                    return o = e.sent, l = o.tide_sid, wx.setStorageSync("sid", l), e.next = 14, a.getTideUserInfo();

                  case 14:
                    if (a.globalData.userInfo.nickname) {
                        e.next = 17;
                        break;
                    }
                    return e.next = 17, a.setUserInfo();

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    setUserInfo: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var a, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n.getUserInfo();

                  case 2:
                    return a = e.sent, s = wx.getStorageSync("sid"), e.next = 6, r({
                        url: "/wechatmp/users/self/profile",
                        method: "POST",
                        data: {
                            rawData: a.rawData,
                            signature: a.signature,
                            encryptedData: a.encryptedData,
                            userInfo: a.userInfo,
                            iv: a.iv,
                            sid: s
                        }
                    });

                  case 6:
                    n.getTideUserInfo();

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getUserInfo: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var a, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, r.checkUserAuth();

                  case 2:
                    return a = n.wxGetUserInfo(), e.next = 5, a({
                        withCredentials: !0
                    });

                  case 5:
                    return s = e.sent, e.abrupt("return", s);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLaunch: function(r) {
        var n = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    console.log(r), n.globalData.qrcode_scene = r.query.scene;

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    globalData: {
        isFullScreen: !1,
        inited: null,
        userInfo: null,
        userAuth: !1,
        qrcode_scene: "",
        qrcode_scene_scene_id: ""
    }
});