var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/lunar"), a = require("../../utils/util").formatTime, s = require("../../utils/wxRequest");

Component({
    externalClasses: [ "banner" ],
    options: {
        multipleSlots: !0
    },
    data: {
        greeting: "",
        quote: "",
        dateText: "",
        extraData: {
            source: "dailypic"
        }
    },
    ready: function() {
        this.setGreetings(), this.setMotto();
    },
    methods: {
        setMotto: function() {
            var r = this;
            return t(e.default.mark(function t() {
                var n, i, u, c;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, i = new Date(), u = a(i, "yyyy-MM-dd"), e.next = 5, s({
                            url: "/v1/dailypics/".concat(u)
                        });

                      case 5:
                        c = e.sent, n = c.content["zh-Hans"].quote.text, e.next = 12;
                        break;

                      case 9:
                        e.prev = 9, e.t0 = e.catch(0), n = "我们在黑暗中并肩而行，走在各自的朝圣路上";

                      case 12:
                        r.setData({
                            quote: n
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 9 ] ]);
            }))();
        },
        setGreetings: function() {
            var e = this, t = new Date(), s = t.getHours(), n = a(t, "M 月 d 日"), i = r(t), u = "";
            switch (!0) {
              case s >= 0 && s < 5:
                u = "夜深了";
                break;

              case s >= 5 && s < 9:
                u = "晨光起";
                break;

              case s >= 9 && s < 11:
                u = "早上好";
                break;

              case s >= 11 && s < 14:
                u = "中午好";
                break;

              case s >= 14 && s < 17:
                u = "下午好";
                break;

              case s >= 17 && s < 19:
                u = "傍晚好";
                break;

              case s >= 19 && s < 21:
                u = "晚上好";
                break;

              default:
                u = "夜空下";
            }
            this.setData({
                greeting: u,
                date: t.getDate(),
                dateText: "".concat(n, " · ").concat(i.lMonth, "月").concat(i.lDate)
            }), clearTimeout(this.refreshGreeting), this.refreshGreeting = setTimeout(function() {
                e.setGreetings();
            }, 6e4);
        }
    }
});