Component({
    externalClasses: [ "disc" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        like: {
            type: String,
            value: "light"
        },
        theme: {
            type: String,
            value: "light"
        },
        color: {
            type: String,
            value: "0,0,0"
        },
        cover: {
            type: String
        },
        icon: {
            type: String
        },
        gif: {
            type: String
        },
        current: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                !t && this.initDisc();
            }
        },
        disableAnimated: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                this.data.playing && (t || this.startAnimation());
            }
        },
        playing: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.startAnimation();
            }
        }
    },
    data: {
        animationData: {},
        deg: 0
    },
    created: function() {
        this.initDisc();
    },
    animationIntervalId: null,
    methods: {
        catchtouchmove: function() {},
        startAnimation: function() {
            this.rotateDisc();
        },
        rotateDisc: function() {
            var t = 4.5 * ++this.rotateCount;
            this.setData({
                deg: t
            });
        },
        transitionend: function() {
            var t = this.data, i = t.playing, n = t.disableAnimated;
            i && !n && this.rotateDisc();
        },
        initDisc: function() {
            this.rotateCount = 0, this.setData({
                deg: 0
            });
        },
        onBtnTap: function() {
            var t = {
                status: this.data.playing ? "stop" : "play"
            };
            this.triggerEvent("tapbtn", t, {});
        }
    }
});