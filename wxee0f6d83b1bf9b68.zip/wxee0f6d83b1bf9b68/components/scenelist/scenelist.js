var e = getApp();

Component({
    externalClasses: [ "tab-container" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        scrollTop: {
            type: Number,
            value: 0
        },
        scenes: {
            type: Array,
            value: []
        },
        currentItemId: {
            type: String,
            value: ""
        },
        playing: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        currentTab: 0,
        isFullScreen: e.globalData.isFullScreen,
        statusBarHeight: e.globalData.statusBarHeight,
        capsuleBarHeight: e.globalData.capsuleBarHeight
    },
    ready: function() {
        var e = wx.getStorageSync("currentTab");
        e && this.setData({
            currentTab: e
        });
    },
    methods: {
        tapScene: function(e) {
            var t = e.currentTarget.dataset.sceneid;
            this.triggerEvent("tapscene", {
                sceneid: t
            });
        },
        onscroll: function(e) {
            var t = e.detail;
            this.triggerEvent("scroll", t);
        }
    }
});