var t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../utils/seen");

Component({
    externalClasses: [ "tab-container" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        scenes: {
            type: Array,
            value: []
        },
        currentItemId: {
            type: String,
            value: ""
        },
        size: {
            type: Number
        },
        offset: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.vpx = this.data.size / 2 + t;
            }
        },
        opacity: {
            type: Number,
            value: 1
        }
    },
    data: {
        currentTab: 0
    },
    ready: function() {
        this.initCurrentTab(), this.initPlanet();
    },
    methods: {
        touchstart: function(t) {
            this.dragger._onDragStart(t);
        },
        touchmove: function(t) {
            this.dragger._onDrag(t);
        },
        touchend: function(t) {
            this.dragger._onDragEnd(t);
        },
        initCurrentTab: function() {
            var t = wx.getStorageSync("currentTab");
            t && this.setData({
                currentTab: t
            });
        },
        initPlanet: function() {
            var i = this, n = this.data, e = n.scenes, r = n.size, s = this;
            this.vpx = r / 2, this.vpy = r / 2, this.angleX = .005, this.angleY = .005;
            var o = wx.createCanvasContext("planet", this), h = [];
            this.dragger = new a.Drag({
                inertia: !0
            }), this.dragger.on("drag.rotate", function(a) {
                var n = t(a.offsetRelative, 2), e = n[0], r = n[1];
                i.angleY = .01 * -e, i.angleX = .01 * -r;
            });
            var c = function() {
                this.init();
            };
            function u() {
                o.clearRect(0, 0, r, r), function() {
                    for (var t = Math.cos(s.angleX), a = Math.sin(s.angleX), i = 0; i < h.length; i++) {
                        var n = h[i].y * t - h[i].z * a, e = h[i].z * t + h[i].y * a;
                        h[i].y = n, h[i].z = e;
                    }
                }(), function() {
                    for (var t = Math.cos(s.angleY), a = Math.sin(s.angleY), i = 0; i < h.length; i++) {
                        var n = h[i].x * t - h[i].z * a, e = h[i].z * t + h[i].x * a;
                        h[i].x = n, h[i].z = e;
                    }
                }(), function() {
                    for (var t = Math.cos(s.angleY), a = Math.sin(s.angleY), i = 0; i < h.length; i++) {
                        var n = h[i].x * t - h[i].y * a, e = h[i].y * t + h[i].x * a;
                        h[i].x = n, h[i].y = e;
                    }
                }();
                for (var t = 0; t < h.length; t++) h[t].paint(t);
                o.draw(), v.isrunning && setTimeout(u, 40);
            }
            c.prototype = {
                isrunning: !1,
                init: function() {
                    for (var t = 0; t <= 3; t++) {
                        new p(t, 1).draw(), new p(t, -1).draw();
                    }
                },
                start: function() {
                    this.isrunning = !0, u();
                },
                stop: function() {
                    this.isrunning = !1;
                }
            };
            var p = function(t, a) {
                this.radius = Math.sqrt(Math.pow(150, 2) - Math.pow(150 * Math.cos(t * Math.PI * 2 / 10), 2)), 
                this.x = 0, this.y = 0, this.up = a;
            }, l = [];
            p.prototype = {
                setBalls: function(t) {
                    for (var a = 0; a < 10; a++) {
                        var i = 2 * Math.PI / 10 * a, n = t * Math.cos(i), r = t * Math.sin(i), s = this.up * Math.sqrt(Math.pow(150, 2) - Math.pow(t, 2)), o = "".concat(n, "_").concat(r, "_").concat(s), c = void 0;
                        if (~l.indexOf(o)) ; else {
                            c = l.length % e.length;
                            var u = e[c], p = new g(n, r, s, 1.5, u);
                            p.paint(), h.push(p), l.push(o);
                        }
                    }
                },
                draw: function() {
                    o.beginPath(), o.arc(s.vpx, s.vpy, this.radius, 0, 2 * Math.PI, !0), o.strokeStyle = "#FFF", 
                    o.stroke(), this.setBalls(this.radius);
                }
            };
            var g = function(t, a, i, n, e) {
                this.x = t, this.y = a, this.z = i, this.r = n, this.width = 2 * n, this.scene = e;
            };
            g.prototype = {
                paint: function(t) {
                    o.save(), o.beginPath();
                    var a = 450 / (450 - this.z), i = (this.z + 150) / 300;
                    o.arc(s.vpx + this.x, s.vpy + this.y, this.r * a, 0, 2 * Math.PI, !0), opacity = (i + .5) * s.data.opacity, 
                    opacity >= 1 ? opacity = 1 : opacity <= 0 ? opacity = 0 : opacity = opacity.toFixed(2), 
                    o.fillStyle = "rgba(255,255,255,".concat(opacity, ")"), o.fill(), o.setFontSize(13), 
                    o.textAlign = "center", o.scale(a, a), o.fillText("".concat(this.scene.name), (s.vpx + this.x) / a, (s.vpy + this.y - 10) / a), 
                    o.restore();
                }
            };
            var v = new c();
            v.start(), this.animation = v;
        },
        tapScene: function(t) {
            var a = t.currentTarget.dataset.sceneid;
            this.triggerEvent("tapscene", {
                sceneid: a
            });
        }
    }
});