Component({
    properties: {
        disableAnimated: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                this.data.playing && (t ? this.pauseAnimation() : this.startAnimation());
            }
        },
        playing: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t ? this.startAnimation() : this.pauseAnimation();
            }
        }
    },
    data: {
        animationData: {}
    },
    created: function() {
        this.initDisc();
    },
    methods: {
        startAnimation: function() {
            this.rotateDisc();
        },
        pauseAnimation: function() {
            clearTimeout(this.animationIntervalId), this.animationIntervalId = null;
        },
        rotateDisc: function() {
            var t = this;
            this.animation.rotate(9 * ++this.rotateCount).step(), this.setData({
                animationData: this.animation.export()
            }), this.animationIntervalId = setTimeout(function() {
                t.rotateDisc();
            }, 300);
        },
        initDisc: function() {
            this.rotateCount = 0, this.animation = wx.createAnimation({
                duration: 300
            }), this.animation.rotate(0).step(), this.setData({
                animationData: this.animation.export()
            });
        },
        onBtnTap: function() {
            var t = {
                status: this.data.playing ? "stop" : "play"
            };
            this.triggerEvent("tapbtn", t, {});
        }
    }
});