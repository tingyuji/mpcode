Component({
    externalClasses: [ "grip" ],
    properties: {
        presentProgress: {
            type: Number,
            value: 0
        },
        theme: {
            type: String,
            value: "light"
        }
    },
    data: {
        direction: 0
    },
    created: function() {},
    methods: {}
});