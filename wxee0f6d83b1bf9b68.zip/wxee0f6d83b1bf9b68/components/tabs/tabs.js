Component({
    externalClasses: [ "disc" ],
    options: {
        multipleSlots: !0
    },
    data: {
        currentTab: 0
    },
    ready: function() {
        var t = wx.getStorageSync("currentTab");
        t && this.setData({
            currentTab: t
        });
    },
    methods: {
        catchtouchmove: function() {},
        swiperTab: function(t) {
            var a = t.detail.current;
            this.setData({
                currentTab: a
            }), wx.setStorageSync("currentTab", a);
        },
        touchStart: function(t) {
            this.triggerEvent("changestart");
        },
        animationfinish: function(t) {
            this.triggerEvent("changeend");
        },
        clickTab: function(t) {
            if (this.data.currentTab === t.target.dataset.current) return !1;
            this.setData({
                currentTab: t.target.dataset.current
            });
        }
    }
});