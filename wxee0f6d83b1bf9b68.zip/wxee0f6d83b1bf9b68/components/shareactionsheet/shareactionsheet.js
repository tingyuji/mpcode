var e = getApp();

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        sceneid: {
            type: String
        }
    },
    data: {
        isFullScreen: e.globalData.isFullScreen
    },
    ready: function() {},
    methods: {
        goPoster: function() {
            this.triggerEvent("hide"), wx.navigateTo({
                url: "/pages/poster/poster?sceneid=".concat(this.data.sceneid)
            });
        },
        cancel: function() {
            this.triggerEvent("hide");
        }
    }
});