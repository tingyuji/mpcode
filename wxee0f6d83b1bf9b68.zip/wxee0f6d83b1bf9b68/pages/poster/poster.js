var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = getApp(), n = require("../../utils/wxRequest"), i = require("../../utils/wxApi"), s = require("../../utils/puzzle");

new Date().getHours();

Page({
    onShareAppMessage: function() {
        var e = this.data.scene;
        return {
            title: e.shareText || "和大自然一起，好好睡觉",
            imageUrl: "https://pics.tide.moreless.io/scenes/forward_".concat(e.id, ".png?").concat(e.updated_at),
            path: "/pages/index/index?sceneid=".concat(e.id)
        };
    },
    data: {
        loadFail: !1,
        picPath: "",
        scene: {},
        screenHeight: a.globalData.screenHeight,
        screenWidth: a.globalData.screenWidth,
        statusBarHeight: a.globalData.statusBarHeight,
        capsuleBarHeight: a.globalData.capsuleBarHeight,
        isFullScreen: a.globalData.isFullScreen
    },
    init: function(i) {
        var o = this;
        return t(e.default.mark(function t() {
            var c, r, u, l, d, h;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n({
                        url: "/v1/tidesleep/scenes/".concat(i),
                        method: "get"
                    });

                  case 2:
                    return c = e.sent, o.setData({
                        scene: c
                    }), u = a.globalData.userInfo, r = u ? u.nickname : "我", e.prev = 6, e.next = 9, 
                    n({
                        url: "/v1/users/self/tidesleep_qrcode",
                        method: "get",
                        data: {
                            page: "pages/index/index",
                            scene_id: c.id
                        }
                    });

                  case 9:
                    d = e.sent, l = d.url, e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(6), l = "";

                  case 16:
                    h = s.drawPoster({
                        nickname: r,
                        qrcode_url: l,
                        scene_id: c.id,
                        updated_at: c.updated_at
                    }), wx.downloadFile({
                        url: h.replace("http://", "https://"),
                        fail: function(e) {
                            o.askRetry();
                        },
                        success: function(e) {
                            200 !== e.statusCode ? o.askRetry() : (wx.hideLoading(), o.setData({
                                picPath: e.tempFilePath
                            }));
                        }
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 6, 13 ] ]);
        }))();
    },
    askRetry: function() {
        var e = this;
        wx.hideLoading(), wx.showModal({
            title: "海报生成失败",
            content: "是否重试？",
            confirmText: "确定",
            showCancel: !0,
            success: function(t) {
                t.confirm ? e.init(e.data.scene.id) : t.cancel && e.gohome();
            }
        });
    },
    gohome: function() {
        wx.navigateBack();
    },
    onImageLoad: function() {},
    onImageLoadFail: function() {},
    checkAuth: function(e) {
        wx.getSetting({
            fail: function(t) {
                e(!1);
            },
            success: function(t) {
                t.authSetting["scope.writePhotosAlbum"] || void 0 === t.authSetting["scope.writePhotosAlbum"] ? e(!0) : wx.showModal({
                    title: "需要打开保存到相册的权限",
                    success: function(t) {
                        t.confirm ? wx.openSetting({
                            fail: function(t) {
                                e(!1);
                            },
                            success: function(t) {
                                t.authSetting["scope.writePhotosAlbum"] ? e(!0) : e(!1);
                            }
                        }) : e(!1);
                    }
                });
            }
        });
    },
    preview: function() {
        i.wxPreviewImage()({
            urls: [ this.data.picPath ]
        });
    },
    save: function() {
        var e = this;
        this.checkAuth(function(t) {
            t && (wx.showLoading({
                mask: !0,
                title: "正在生成海报"
            }), wx.saveImageToPhotosAlbum({
                filePath: e.data.picPath,
                fail: function() {
                    wx.hideLoading(), wx.showModal({
                        title: "未能保存",
                        content: "保存到系统相册时失败",
                        confirmText: "确定",
                        showCancel: !1
                    });
                },
                success: function() {
                    wx.hideLoading(), wx.showModal({
                        title: "声音海报已保存到系统相册",
                        content: "快去分享给朋友，叫伙伴们来围观吧",
                        confirmText: "我知道了",
                        showCancel: !1
                    });
                }
            }));
        });
    },
    onLoad: function(e) {
        wx.showLoading({
            mask: !0
        }), this.init(e.sceneid);
    }
});