var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/toConsumableArray"), a = t(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../utils/util.js"), r = s.formatNumber, i = s.randomSort, o = getApp(), c = require("../../utils/wxRequest"), u = require("../../data/scenes"), d = {};

function h(t) {
    var e = parseInt(t / 60), a = t % 60;
    return e = e < 10 ? "0".concat(e) : e, a = a < 10 ? "0".concat(a) : a, "".concat(e, ":").concat(a);
}

u.forEach(function(t) {
    var e = t.id;
    d[e] = t;
}), Page({
    onShareAppMessage: function() {
        this.setData({
            shareActionSheetShow: !1
        });
        var t = this.data, e = t.scenesData[t.currentItemId];
        return {
            title: e.shareText || "和大自然一起，好好睡觉",
            imageUrl: "https://pics.tide.moreless.io/scenes/forward_".concat(e.id, ".png?").concat(e.updated_at),
            path: "/pages/index/index?sceneid=".concat(e.id)
        };
    },
    lastMoveDirection: 0,
    lastMoveTime: 0,
    lastMoveStart: 0,
    data: {
        screenHeight: o.globalData.screenHeight,
        screenWidth: o.globalData.screenWidth,
        statusBarHeight: o.globalData.statusBarHeight,
        capsuleBarHeight: o.globalData.capsuleBarHeight,
        isFullScreen: o.globalData.isFullScreen,
        scrollTop: 0,
        currentScrollTop: 0,
        disableAnimated: !1,
        theme: wx.getStorageSync("theme") || "dark",
        tomatoPickerShow: !1,
        shareActionSheetShow: !1,
        BGM: null,
        currentTab: 0,
        currentItemId: u[0].id,
        startAt: wx.getStorageSync("startAt"),
        duration: wx.getStorageSync("duration") || 1800,
        remainDuration: 0,
        remain: 0,
        durationStr: h(wx.getStorageSync("duration") || 1800),
        remainStr: "",
        status: wx.getStorageSync("status") || "stop",
        bgPosition: 60,
        width: 375,
        height: 0,
        topPosition: o.globalData.statusBarHeight + o.globalData.capsuleBarHeight,
        bottomPosition: o.globalData.screenHeight - (o.globalData.isFullScreen ? 24 : 0) - 80 / (375 / o.globalData.screenWidth),
        sleepPanelPosition: o.globalData.screenHeight - (o.globalData.isFullScreen ? 24 : 0) - 80 / (375 / o.globalData.screenWidth),
        presentProgress: 0,
        scenesData: d,
        scenes: u,
        randomList: u
    },
    catchtouchmove: function() {},
    dragPanelStart: function(t) {
        var e = t.changedTouches;
        if (e[0]) {
            var a = e[0].pageY;
            this.dragOrigin = a;
        }
    },
    onPresent: function(t) {
        var e = this, a = t.detail.y, n = this.data, s = n.topPosition, r = n.bottomPosition, i = 1 - parseInt(1e3 * ((a - s) / (r - s))) / 1e3;
        i !== this.data.presentProgress && this.setData({
            presentProgress: i
        }), this.data.disableAnimated || this.setData({
            disableAnimated: !0
        }), clearTimeout(this.recoverAnimation), this.recoverAnimation = setTimeout(function() {
            e.setData({
                disableAnimated: !1
            }), e.recoverAnimation = null;
        }, 100);
    },
    dragPanelEnd: function(t) {
        var e = t.changedTouches[0].pageY, a = this.data, n = a.topPosition, s = a.bottomPosition, r = e - this.dragOrigin, i = (s - n) / 10, o = 0;
        o = this.data.sleepPanelPosition === n ? r > i ? s : n : r < -i ? n : s, this.setData({
            sleepPanelPosition: o
        });
    },
    onTopbarTap: function() {
        var t = this.data, e = t.sleepPanelPosition, a = t.bottomPosition;
        e === a ? this.setData({
            scrollTop: 0
        }) : this.setData({
            sleepPanelPosition: a
        });
    },
    showTimePicker: function() {
        this.setData({
            tomatoPickerShow: !0
        });
    },
    switchTheme: function() {
        var t = "light" === this.data.theme ? "dark" : "light";
        wx.setStorageSync("theme", t), this.setData({
            theme: t
        });
    },
    hideTimePicker: function() {
        this.setData({
            tomatoPickerShow: !1
        });
    },
    showShareActionSheet: function(t) {
        var e = this;
        return n(a.default.mark(function n() {
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if ("getUserInfo:ok" !== t.detail.errMsg) {
                        a.next = 7;
                        break;
                    }
                    return a.next = 4, o.login();

                  case 4:
                    e.setData({
                        shareActionSheetShow: !0
                    }), a.next = 8;
                    break;

                  case 7:
                    wx.showModal({
                        title: "用户授权失败",
                        showCancel: !1,
                        content: "需要用户授权才能进行分享"
                    });

                  case 8:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    hideShareActionSheet: function() {
        this.setData({
            shareActionSheetShow: !1
        });
    },
    changeRemainTime: function(t) {
        var e = t.detail.duration, a = h(e);
        wx.setStorageSync("duration", e);
        var n = {
            duration: e,
            remain: e,
            remainDuration: e,
            durationStr: a,
            remainStr: a
        };
        "playing" === this.data.status && (n.startAt = +new Date(), wx.setStorageSync("remainDuration", e), 
        wx.setStorageSync("remain", e)), this.setData(Object.assign(n, {
            tomatoPickerShow: !1
        }));
    },
    convertCodeToDate: function(t) {
        var e = parseInt(t / 1e4), a = parseInt(t / 100) % (100 * e), n = t % (100 * (100 * e + a));
        return "".concat(e, "-").concat(r(a), "-").concat(r(n));
    },
    toggleStatus: function(t) {
        "play" === t.detail.status ? this.start() : this.stop();
    },
    start: function() {
        var t = this.data, e = (t.status, t.scenes, t.duration), a = t.remainDuration, n = t.currentItemId, s = this.data.scenesData[n], r = +new Date();
        this.playBGM(s), this.setData({
            status: "playing",
            remainDuration: a || e,
            startAt: r
        }), wx.setStorage({
            key: "status",
            data: "playing"
        }), wx.setStorage({
            key: "startAt",
            data: r
        }), this.progress(), wx.reportAnalytics("play_scene", {
            scene_name: s.name,
            scene_id: s.id,
            duration: e
        });
    },
    continue: function() {
        var t = this.data, e = t.status, a = (t.scenes, t.remain, t.currentItemId);
        if ("playing" !== e) {
            var n = this.data.scenesData[a], s = +new Date();
            this.playBGM(n), this.setData({
                status: "playing",
                startAt: s
            }), wx.setStorage({
                key: "status",
                data: "playing"
            }), wx.setStorage({
                key: "startAt",
                data: s
            }), wx.removeStorage({
                key: "remainDuration"
            }), this.progress();
        }
    },
    pause: function() {
        var t = this.data.remain;
        this.setData({
            status: "pause",
            remainDuration: t
        }), this.pauseBGM(), wx.setStorage({
            key: "status",
            data: "pause"
        }), wx.setStorage({
            key: "remainDuration",
            data: t
        });
    },
    stop: function() {
        this.setData({
            status: "stop",
            startAt: 0,
            remain: this.data.duration,
            remainStr: h(this.data.duration),
            remainDuration: this.data.duration
        }), this.stopBGM(), wx.setStorage({
            key: "status",
            data: "stop"
        }), wx.setStorage({
            key: "startAt",
            data: 0
        }), wx.removeStorage({
            key: "remainDuration"
        });
    },
    progress: function() {
        var t = this, e = this.data, a = e.remainDuration, n = e.startAt, s = e.status, r = e.duration;
        if ("playing" === s) {
            var i = (a = a || r) - parseInt((+new Date() - n) / 1e3);
            i <= 0 && a > 0 ? this.stop() : (this.setData({
                remain: i,
                remainStr: h(i)
            }), wx.setStorageSync("remain", i), this.countDownHandle || (this.countDownHandle = setTimeout(function() {
                clearTimeout(t.countDownHandle), t.countDownHandle = null, t.progress();
            }, 1e3)));
        }
    },
    tapScene: function(t) {
        var e = t.detail.sceneid;
        this.data.currentItemId !== e ? (this.setData({
            currentItemId: e
        }), this.start()) : "stop" === this.data.status ? this.start() : this.stop();
    },
    switchScene: function(t) {
        var e = t.detail.currentItemId, a = this.data.scenesData[e];
        this.setData({
            currentItemId: a.id
        }), wx.setStorageSync("currentItemId", a.id), "playing" === this.data.status && this.playBGM(a);
    },
    nextScene: function() {
        var t = this.data, e = t.currentItemId, a = t.randomList, n = a.findIndex(function(t) {
            return t.id === e;
        }), s = a[n === a.length - 1 ? 0 : n + 1];
        this.setData({
            currentItemId: s.id
        });
    },
    prevScene: function() {
        var t = this.data, e = t.currentItemId, a = t.randomList, n = a.findIndex(function(t) {
            return t.id === e;
        }), s = a[0 === n ? a.length - 1 : n - 1];
        this.setData({
            currentItemId: s.id
        });
    },
    initScenes: function() {
        var t = this;
        return n(a.default.mark(function n() {
            var s, r, o;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return s = [], a.prev = 1, a.next = 4, c({
                        url: "/v1/tidesleep/scenes",
                        method: "get"
                    });

                  case 4:
                    s = a.sent, a.next = 10;
                    break;

                  case 7:
                    a.prev = 7, a.t0 = a.catch(1), s = u;

                  case 10:
                    r = i(e(s)), o = {}, s.forEach(function(t) {
                        var e = t.id;
                        o[e] = t;
                    }), t.setData({
                        scenesData: o,
                        scenes: s,
                        randomList: r
                    });

                  case 14:
                  case "end":
                    return a.stop();
                }
            }, n, null, [ [ 1, 7 ] ]);
        }))();
    },
    onScroll: function(t) {
        var e = t.detail;
        this.setData({
            currentScrollTop: e.scrollTop
        });
    },
    initBGM: function() {
        var t = this, e = "stop", a = 0;
        try {
            e = this.data.status, a = this.data.startAt;
            var n, s = this.data.duration, r = this.data.remainDuration;
            (n = r || s - parseInt((+new Date() - a) / 1e3)) > 0 ? (this.setData({
                status: e,
                startAt: a || 0,
                remain: n,
                remainStr: h(n)
            }), "playing" === e && this.progress()) : this.setData({
                status: "stop",
                startAt: 0,
                remain: s,
                remainStr: h(s)
            });
        } catch (t) {}
        var i = this.data.BGM, o = this.data.scenesData[this.data.currentItemId];
        i.src && i.src !== o.audio_url ? this.playBGM(o) : "playing" === e && (i.src || this.encore()), 
        i.onPlay(function() {
            t.continue();
        }), i.onPause(function() {
            t.pause();
        }), i.onStop(function() {
            t.stop();
        }), i.onEnded(function() {
            t.encore();
        }), i.onPrev(function() {
            t.prevScene();
        }), i.onNext(function() {
            t.nextScene();
        }), this.setData({
            BGM: i
        });
    },
    playBGM: function(t) {
        var e = t.name, a = t.audio_url, n = t.id, s = t.updated_at;
        wx.playBackgroundAudio({
            title: "潮汐睡眠 · ".concat(e),
            coverImgUrl: "https://pics.tide.moreless.io/scenes/forward_".concat(n, ".png?imageMogr2/thumbnail/!640x512r/crop/!360x360a140a76&").concat(s),
            dataUrl: a
        });
    },
    pauseBGM: function() {
        wx.pauseBackgroundAudio();
    },
    stopBGM: function() {
        wx.stopBackgroundAudio();
    },
    encore: function() {
        var t = this.data, e = t.status, a = t.scenesData, n = t.currentItemId;
        if ("playing" === e) {
            var s = a[n];
            this.playBGM(s);
        }
    },
    parseQrcode: function(t) {
        return n(a.default.mark(function e() {
            var n;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, c({
                        url: "/v1/tidesleep/qrcode_info",
                        data: {
                            id: t
                        }
                    });

                  case 3:
                    return n = e.sent, e.abrupt("return", n);

                  case 7:
                    throw e.prev = 7, e.t0 = e.catch(0), e.t0;

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 7 ] ]);
        }))();
    },
    init: function(t) {
        var e = this;
        return n(a.default.mark(function n() {
            var s, r, i, c, u, d, l, p, g;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    wx.showShareMenu(), s = wx.getSystemInfoSync(), r = wx.getBackgroundAudioManager(), 
                    i = {
                        BGM: r,
                        width: s.windowWidth,
                        height: s.windowHeight,
                        pixelRatio: s.pixelRatio,
                        disableAnimated: !1,
                        status: wx.getStorageSync("status") || "stop"
                    }, c = wx.getStorageSync("duration") || 1800, i.duration = c, u = wx.getStorageSync("remainDuration"), 
                    d = wx.getStorageSync("startAt") || 0, (l = o.globalData.qrcode_scene_scene_id || t.sceneid) ? (i.currentItemId = l, 
                    i.status = "playing", d = d || +new Date(), u = u || c, wx.setStorageSync("startAt", d), 
                    setTimeout(function() {
                        e.setData({
                            sleepPanelPosition: e.data.topPosition
                        });
                    }, 1e3)) : r.src ? (p = e.data.scenes.find(function(t) {
                        return t.audio_url === r.src;
                    }), i.currentItemId = p.id) : i.currentItemId = e.data.scenes[0].id, i.startAt = d, 
                    i.durationStr = h(u || c), u ? (g = u, i.remainDuration = u) : g = c - parseInt((+new Date() - d) / 1e3), 
                    g < 0 && (g = u || c), i.remain = g, i.remainStr = h(g), e.setData(i);

                  case 17:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    onHide: function() {
        this.setData({
            disableAnimated: !0
        });
    },
    onShow: function() {
        this.setData({
            disableAnimated: !1
        });
    },
    onLoad: function(t) {
        var e = this;
        return n(a.default.mark(function n() {
            var s;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, e.initScenes();

                  case 2:
                    e.init(t), e.initBGM(), s = wx.createSelectorQuery(), e.discover = s.select("#discover").fields({
                        rect: !0
                    }, function(t) {
                        e.setData({
                            offset: t.left
                        });
                    });

                  case 6:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    onUnload: function() {
        this.setData({
            disableAnimated: !0
        });
    },
    tabsChangeStart: function(t) {
        this.refreshOffsetAllow = !0, this.refreshOffset();
    },
    tabsChangeEnd: function(t) {
        this.refreshOffsetAllow = !1, this.discover.exec();
    },
    refreshOffset: function() {
        var t = this;
        this.discover.exec(), setTimeout(function() {
            t.refreshOffsetAllow && t.refreshOffset();
        }, 32);
    },
    presentPanel: function(t) {
        var e = this.data, a = e.sleepPanelPosition, n = e.topPosition, s = e.bottomPosition;
        this.setData({
            sleepPanelPosition: a === n ? s : n
        });
    },
    hidePanel: function() {
        var t = this.data.bottomPosition;
        this.setData({
            sleepPanelPosition: t
        });
    }
});