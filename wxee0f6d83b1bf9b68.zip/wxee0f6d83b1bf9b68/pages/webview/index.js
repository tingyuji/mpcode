Page({
    data: {
        url: ""
    },
    onLoad: function(a) {
        this.setData({
            url: unescape(a.url)
        });
    }
});