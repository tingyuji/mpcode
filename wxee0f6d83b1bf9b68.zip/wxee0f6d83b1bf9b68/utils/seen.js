var t, i = function(t, i) {
    return function() {
        return t.apply(i, arguments);
    };
};

(t = {
    Util: {
        defaults: function(t, i, e) {
            var a, n;
            for (a in i) null == t[a] && (t[a] = i[a]);
            for (a in n = [], e) null == t[a] ? n.push(t[a] = e[a]) : n.push(void 0);
            return n;
        }
    }
}).Events = {
    dispatch: function() {
        var i, e, a;
        for (i = new t.Events.Dispatcher(), a = 0, e = arguments.length; a < e; a++) i[arguments[a]] = t.Events.Event();
        return i;
    }
}, t.Events.Dispatcher = function() {
    function t() {
        this.on = i(this.on, this);
    }
    return t.prototype.on = function(t, i) {
        var e, a;
        return a = "", (e = t.indexOf(".")) > 0 && (a = t.substring(e + 1), t = t.substring(0, e)), 
        null != this[t] && this[t].on(a, i), this;
    }, t;
}(), t.Events.Event = function() {
    var t;
    return (t = function() {
        var i, e, a, n;
        for (e in n = [], a = t.listenerMap) null != (i = a[e]) ? n.push(i.apply(this, arguments)) : n.push(void 0);
        return n;
    }).listenerMap = {}, t.on = function(i, e) {
        if (delete t.listenerMap[i], null != e) return t.listenerMap[i] = e;
    }, t;
}, t.InertialMouse = function() {
    function i() {
        this.reset();
    }
    return i.inertiaExtinction = .1, i.smoothingTimeout = 300, i.inertiaMsecDelay = 30, 
    i.prototype.get = function() {
        var i;
        return i = 1e3 / t.InertialMouse.inertiaMsecDelay, [ this.x * i, this.y * i ];
    }, i.prototype.reset = function() {
        return this.xy = [ 0, 0 ], this;
    }, i.prototype.update = function(i) {
        var e, a;
        return null != this.lastUpdate ? (e = new Date().getTime() - this.lastUpdate.getTime(), 
        i = i.map(function(t) {
            return t / Math.max(e, 1);
        }), a = Math.min(1, e / t.InertialMouse.smoothingTimeout), this.x = a * i[0] + (1 - a) * this.x, 
        this.y = a * i[1] + (1 - a) * this.y) : (this.x = i[0], this.y = i[1]), this.lastUpdate = new Date(), 
        this;
    }, i.prototype.damp = function() {
        return this.x *= 1 - t.InertialMouse.inertiaExtinction, this.y *= 1 - t.InertialMouse.inertiaExtinction, 
        this;
    }, i;
}(), t.Drag = function() {
    function e(e) {
        this._stopInertia = i(this._stopInertia, this), this._startInertia = i(this._startInertia, this), 
        this._onInertia = i(this._onInertia, this), this._onDrag = i(this._onDrag, this), 
        this._onDragEnd = i(this._onDragEnd, this), this._onDragStart = i(this._onDragStart, this), 
        this._getPageCoords = i(this._getPageCoords, this), t.Util.defaults(this, e, this.defaults), 
        this._inertiaRunning = !1, this._dragState = {
            dragging: !1,
            origin: null,
            last: null,
            inertia: new t.InertialMouse()
        }, this.dispatch = t.Events.dispatch("drag", "dragStart", "dragEnd", "dragEndInertia"), 
        this.on = this.dispatch.on;
    }
    return e.prototype.defaults = {
        inertia: !1
    }, e.prototype._getPageCoords = function(t) {
        var i, e;
        return (null != (i = t.touches) ? i.length : void 0) > 0 ? [ t.touches[0].pageX, t.touches[0].pageY ] : (null != (e = t.changedTouches) ? e.length : void 0) > 0 ? [ t.changedTouches[0].pageX, t.changedTouches[0].pageY ] : [ t.pageX, t.pageY ];
    }, e.prototype._onDragStart = function(t) {
        return this._stopInertia(), this._dragState.dragging = !0, this._dragState.origin = this._getPageCoords(t), 
        this._dragState.last = this._getPageCoords(t), this.dispatch.dragStart(t);
    }, e.prototype._onDragEnd = function(t) {
        var i, e;
        return this._dragState.dragging = !1, this.inertia && (i = {
            offset: [ (e = this._getPageCoords(t))[0] - this._dragState.origin[0], e[1] - this._dragState.origin[1] ],
            offsetRelative: [ e[0] - this._dragState.last[0], e[1] - this._dragState.last[1] ]
        }, this._dragState.inertia.update(i.offsetRelative), this._startInertia()), this.dispatch.dragEnd(t);
    }, e.prototype._onDrag = function(t) {
        var i, e;
        return i = {
            offset: [ (e = this._getPageCoords(t))[0] - this._dragState.origin[0], e[1] - this._dragState.origin[1] ],
            offsetRelative: [ e[0] - this._dragState.last[0], e[1] - this._dragState.last[1] ]
        }, this.dispatch.drag(i), this.inertia && this._dragState.inertia.update(i.offsetRelative), 
        this._dragState.last = e;
    }, e.prototype._onInertia = function() {
        var t;
        if (this._inertiaRunning) return t = this._dragState.inertia.damp().get(), Math.abs(t[0]) < 1 && Math.abs(t[1]) < 1 ? (this._stopInertia(), 
        void this.dispatch.dragEndInertia()) : (this.dispatch.drag({
            offset: [ this._dragState.last[0] - this._dragState.origin[0], this._dragState.last[0] - this._dragState.origin[1] ],
            offsetRelative: t
        }), this._dragState.last = [ this._dragState.last[0] + t[0], this._dragState.last[1] + t[1] ], 
        this._startInertia());
    }, e.prototype._startInertia = function() {
        return this._inertiaRunning = !0, setTimeout(this._onInertia, t.InertialMouse.inertiaMsecDelay);
    }, e.prototype._stopInertia = function() {
        return this._dragState.inertia.reset(), this._inertiaRunning = !1;
    }, e;
}(), module.exports = t;