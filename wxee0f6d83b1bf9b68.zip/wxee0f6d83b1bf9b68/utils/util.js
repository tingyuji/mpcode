var t = require("../plugins/es6-promise.js");

t.prototype.finally = function(t) {
    var e = this.constructor;
    return this.then(function(n) {
        return e.resolve(t()).then(function() {
            return n;
        });
    }, function(n) {
        return e.resolve(t()).then(function() {
            throw n;
        });
    });
};

var e = function(t) {
    return (t = t.toString())[1] ? "".concat(t) : "0".concat(t);
}, n = [ "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" ], r = [ "周日", "周一", "周二", "周三", "周四", "周五", "周六" ], o = [ "十", "一", "二", "三", "四", "五", "六", "七", "八", "九" ], a = [ "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" ];

module.exports = {
    Promise: t,
    getUTC8Date: function(t, e, n) {
        var r, o = (r = n ? new Date(t, e, n) : e ? new Date(t, e) : t ? new Date(t) : new Date()).getTime(), a = 6e4 * r.getTimezoneOffset();
        return new Date(o + a - -288e5);
    },
    formatTime: function(t, e) {
        e = e || "yyyy-MM-dd hh:mm:ss";
        var n = {
            "M+": (t = new Date(t)).getMonth() + 1,
            "d+": t.getDate(),
            "h+": t.getHours(),
            "m+": t.getMinutes(),
            "s+": t.getSeconds(),
            "q+": Math.floor((t.getMonth() + 3) / 3),
            S: t.getMilliseconds()
        };
        for (var r in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (t.getFullYear() + "").substr(4 - RegExp.$1.length))), 
        n) new RegExp("(" + r + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
        return e;
    },
    formatNumber: e,
    unique: function(t, e) {
        for (var n = {}, r = [], o = 0; o < t.length; o++) n[t[o][e]] = t[o];
        for (var a in n) r.push(n[a]);
        return r;
    },
    getDateStrings: function(t) {
        return t = new Date(t), {
            day: e(t.getDate()),
            month: n[t.getMonth()],
            year: "".concat(t.getFullYear())
        };
    },
    getZHDateStrings: function(t) {
        var e = (t = new Date(t)).getMonth(), n = t.getDay(), u = "", i = "".concat(t.getDate());
        return i.split("").forEach(function(t) {
            u += o[parseInt(t)];
        }), {
            day: i,
            month: e + 1,
            zhDay: u,
            zhMonth: a[e],
            zhWeekday: r[n]
        };
    },
    randomSort: function(t) {
        return t.sort(function(t, e) {
            return Math.random() > .5 ? -1 : 1;
        }), t;
    }
};