var c = require("./base64.min.js").Base64, t = {
    drawPoster: function(t) {
        var a, e = t.nickname, o = t.scene_id, n = t.updated_at, r = t.qrcode_url, i = new Date().getHours(), s = i >= 7 && i < 21 ? "在这里快要睡着了" : "在这里和你说晚安", d = "https://pics.tide.moreless.io/scenes/share_".concat(o, ".png"), u = "text/".concat(c.encodeURI(e), "/font/5b6u6L2v6ZuF6buR/fontsize/800/fill/").concat(c.encodeURI("#FFFFFF"), "/dissolve/80/gravity/North/dx/0/dy/701/ws/0"), F = "text/".concat(c.encodeURI(s), "/font/5b6u6L2v6ZuF6buR/fontsize/800/fill/").concat(c.encodeURI("#FFFFFF"), "/dissolve/80/gravity/North/dx/0/dy/776/ws/0");
        if (r) {
            var l = "image/".concat(c.encodeURI("".concat(r, "?imageMogr2/thumbnail/!240x240r/crop/!240x240a0a0")), "/gravity/North/dx/0/dy/1328/ws/0");
            a = "".concat(d, "?watermark/3/").concat(u, "/").concat(F, "/").concat(l, "&").concat(n);
        } else a = "".concat(d, "?watermark/3/").concat(u, "/").concat(F, "&").concat(n);
        return a;
    },
    drawSharePic: function(t) {
        var a = t.base_image_url, e = t.icon_url, o = t.title, n = "".concat(a, "?imageMogr2/thumbnail/!675x675r/crop/!675x540a0a0"), r = "image/".concat(c.encodeURI("".concat(e, "?imageMogr2/thumbnail/!192x192r/crop/!216x216a0a0")), "/gravity/North/dx/0/dy/144/ws/0"), i = "text/".concat(c.encodeURI(o), "/font/5b6u6L2v6ZuF6buR/fontsize/1080/fill/").concat(c.encodeURI("#FFFFFF"), "/gravity/North/dx/0/dy/360/ws/0");
        return "".concat(n, "|watermark/3/").concat(r, "/").concat(i);
    }
};

module.exports = t;