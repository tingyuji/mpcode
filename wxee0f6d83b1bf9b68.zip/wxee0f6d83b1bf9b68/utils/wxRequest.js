var e = require("../@babel/runtime/helpers/interopRequireDefault");

require("../@babel/runtime/helpers/Arrayincludes");

var r, t = e(require("../@babel/runtime/regenerator")), n = require("../@babel/runtime/helpers/asyncToGenerator"), a = require("./base64.min.js").Base64, s = require("../plugins/es6-promise.js");

function o(e) {
    return function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new s(function(t, n) {
            r.success = function(e) {
                200 === e.statusCode ? t(e) : n({
                    errMsg: e.data.message,
                    error: e.data.error,
                    details: e.data.details
                });
            }, r.fail = function(e) {
                n(e);
            }, e(r);
        });
    };
}

function u() {
    return (u = n(t.default.mark(function e(n) {
        var s, u, i, c;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return s = o(wx.request), r || (r = getApp()), u = wx.getStorageSync("sid"), n.header || (n.header = {}), 
                i = {
                    Authorization: "Basic ".concat(a.encode("W8TxC2uDKWy6P8G7u4mjV:khsvJs9pjhoP943o7VK9A"))
                }, n.method && "post" === n.method.toLowerCase() && (i["Content-Type"] = "application/json"), 
                u && (i.Cookie = "tide_sid=".concat(u)), n.header = Object.assign(i, n.header), 
                n.url = "https://tide-api.moreless.io".concat(n.url), e.next = 11, s(n);

              case 11:
                if ("request:ok" === (c = e.sent).errMsg) {
                    e.next = 16;
                    break;
                }
                throw c.errMsg;

              case 16:
                if ([ 200, 204 ].includes(c.statusCode)) {
                    e.next = 20;
                    break;
                }
                throw c.data;

              case 20:
                return e.abrupt("return", c.data);

              case 21:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

s.prototype.finally = function(e) {
    var r = this.constructor;
    return this.then(function(t) {
        return r.resolve(e()).then(function() {
            return t;
        });
    }, function(t) {
        return r.resolve(e()).then(function() {
            throw t;
        });
    });
}, module.exports = function(e) {
    return u.apply(this, arguments);
};