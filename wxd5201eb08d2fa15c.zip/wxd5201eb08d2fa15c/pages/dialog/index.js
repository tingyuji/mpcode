Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Dialog = void 0;

var t = require("tslib"), e = require("../../common/urlDecNavigator"), i = require("../../config/constants"), o = require("../../core/decorator/pageDecorator"), a = require("../../core/base/basePage"), r = require("../../config/index"), n = t.__importDefault(require("../../common/navigator")), s = require("../../core/base/helpers/index"), l = require("../../core/globalData"), d = t.__importDefault(require("../../store/index")), g = require("../../common/http-client/index"), u = require("../../utils/helper"), c = require("../../utils/themeUtil"), p = require("../../services/session/index"), f = require("../../utils/prefetch"), h = [], D = [];

try {
    h = JSON.parse(wx.getStorageSync(r.DIALOG_LIST) || "[]");
} catch (t) {
    console.error(t);
}

l.$global(r.PERSONAL_NEW_SHOWED, wx.getStorageSync(r.PERSONAL_NEW_SHOWED));

var v = function(a) {
    function v() {
        var t = null !== a && a.apply(this, arguments) || this;
        return t.data = {
            dialogEditing: !1,
            dialogList: h,
            inspireDialogList: D,
            firstDeleteTap: !1,
            seletedDialogId: -1,
            triggered: !1,
            theme: {
                name: "light"
            },
            navigatorBar: {
                openImmersive: !1,
                type: "0",
                bgColor: {
                    hex: "transparent"
                },
                image: null
            },
            currentTab: "0",
            modelCompareEnable: !1,
            hasNewMessage: !1
        }, t._data = {
            forceClose: !1,
            offset: 0,
            webViewLoaded: !1
        }, t;
    }
    return t.__extends(v, a), v.prototype.onLoad = function() {
        var t = p.session.getUserName();
        this.setData({
            userName: t,
            avatarUrl: l.$global("avatarUrl")
        }), l.$global(r.PERSONAL_NEW_SHOWED) || this.setData({
            isFirstEntryPersonal: !0
        });
    }, v.prototype.onShow = function() {
        this.init();
    }, v.prototype.onReady = function() {
        var t = this;
        this._data.webViewLoaded || setTimeout(function() {
            var e;
            t._data.webViewLoaded = !0, null === (e = wx.preloadWebview) || void 0 === e || e.call(wx);
        }, 100);
    }, v.prototype.init = function() {
        var e;
        return t.__awaiter(this, void 0, void 0, function() {
            var i, o;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return c.updateNavBarStyleByTheme(this.data.theme.name), [ 4, f.memoizedGetConfig.call() ];

                  case 1:
                    return i = t.sent(), o = null === (e = null == i ? void 0 : i.privilege) || void 0 === e ? void 0 : e.modelCompetition, 
                    this.setData({
                        modelCompareEnable: !!o
                    }), this.getDialogList(!0), this.checkMessageStatus(), [ 2 ];
                }
            });
        });
    }, v.prototype.getDialogList = function(o) {
        return t.__awaiter(this, void 0, void 0, function() {
            var a, n, l, d, g, u, c = this;
            return t.__generator(this, function(t) {
                return a = this._data.offset, n = i.DIALOG_FETCH_CONFIG.limit, l = this.data, d = l.currentTab, 
                g = l.modelCompareEnable, u = "" + ("0" === d ? g ? "0,1" : "0" : d), this.setData({
                    triggered: !0
                }), e.memoizedGetDialog.call(o ? 0 : a, n, u).then(function(t) {
                    if (e.memoizedGetDialog.reset(), c._freshing = !1, t && (o || t.length > 0)) {
                        var i = o ? t : c.data.dialogList.concat(t);
                        c.setData({
                            dialogList: i,
                            triggered: !1
                        }, function() {
                            o && !c._data.webViewLoaded && setTimeout(function() {
                                var t;
                                c._data.webViewLoaded = !0, null === (t = wx.preloadWebview) || void 0 === t || t.call(wx);
                            }, 16.7);
                        }), c._data.offset = o ? t.length : c._data.offset + t.length, "0" === c.data.currentTab && wx.setStorageSync(r.DIALOG_LIST, o ? JSON.stringify(t) : JSON.stringify(i));
                    }
                }).catch(function(t) {
                    e.memoizedGetDialog.reset(), c._freshing = !1, c.setData({
                        triggered: !1
                    }), console.error(t), s.toast({
                        text: "获取会话列表失败",
                        icon: "error"
                    });
                }), [ 2 ];
            });
        });
    }, v.prototype.findLocalDialogById = function(t) {
        return this.data.dialogList.findIndex(function(e) {
            return (null == e ? void 0 : e.id) === t;
        });
    }, v.prototype.deleteLocalDialog = function(t) {
        var e, i = this, o = this.findLocalDialogById(t);
        this.setData(((e = {})["dialogList[" + o + "].hidden"] = !0, e), function() {
            0 === i.data.dialogList.filter(function(t) {
                return !t.hidden;
            }).length && i.getDialogList();
        });
    }, v.prototype.updateLocalDialog = function(t, e) {
        var i, o = this.findLocalDialogById(e);
        this.setData(((i = {})["dialogList[" + o + "].title"] = t, i));
    }, v.prototype.deleteDialog = function(t) {
        var e = this;
        this.deleteLocalDialog(t), g.apis.dialog.deleteConvs({
            id: t
        }).then(function() {
            e.setData({
                dialogList: e.data.dialogList.filter(function(e) {
                    return e.id !== t;
                })
            });
        }).catch(function(t) {
            console.error(t), s.toast({
                text: "删除会话失败",
                icon: "error"
            });
        });
    }, v.prototype.editDialogTitle = function(t, e) {
        this.updateLocalDialog(t, e), g.apis.dialog.editCovsTitle({
            title: t,
            id: e
        }).then(function() {}).catch(function(t) {
            console.error(t), s.toast({
                text: "编辑会话失败",
                icon: "error"
            });
        });
    }, v.prototype.onSwiperTap = function() {}, v.prototype.onDialogTouchend = function() {
        this.data.firstDeleteTap && this.resetOperateState();
    }, v.prototype.onDialogTap = function(e) {
        var o, a = e.currentTarget.dataset, r = a.id, s = a.relationId, l = a.templateId;
        if (s) {
            var d = this.data.dialogList.find(function(t) {
                return t.relationId === s;
            }), g = "gpt_175B_0404%2Cgpt-35-turbo";
            if ((null === (o = null == d ? void 0 : d.relatedModels) || void 0 === o ? void 0 : o.length) > 0) {
                var u = t.__spreadArray([], d.relatedModels);
                u.sort(function(t, e) {
                    return t.sortOrder = i.MODEL_ORDER[t.modelId], e.sortOrder = i.MODEL_ORDER[e.modelId], 
                    t.sortOrder - e.sortOrder;
                }), g = u.map(function(t) {
                    return t.modelId;
                }).join(",");
            }
            n.default.gotoPage("compare", {
                relationId: s,
                modelIds: g
            }, {
                redirect: !1
            });
        } else n.default.gotoPage("home", {
            id: r,
            templateId: l
        }, {
            redirect: !1
        });
    }, v.prototype.onEditDialog = function(t) {
        var e = this, i = t.currentTarget.dataset.id;
        console.log("onEditDialog"), this._data.forceClose = !0, setTimeout(function() {
            e.setData({
                dialogEditing: !0,
                seletedDialogId: i
            });
        }, 500);
    }, v.prototype.onDeleteDialog = function(t) {
        var e = t.currentTarget.dataset.id;
        this.data.firstDeleteTap ? (this.resetOperateState(), this.deleteDialog(e), this.setData({
            seletedDialogId: -1
        })) : this.setData({
            firstDeleteTap: !0,
            seletedDialogId: e
        });
    }, v.prototype.onCloseDialog = function(t) {
        var e = t.detail.instance;
        this._dialogInstance = e, console.log("onCloseDialog", this.data.firstDeleteTap), 
        (this.data.firstDeleteTap || this._data.forceClose) && (null == e || e.close(), 
        this._data.forceClose = !1);
    }, v.prototype.confirmEditDialog = function(t) {
        var e, i = this, o = t.currentTarget.dataset.id, a = null === (e = null == t ? void 0 : t.detail) || void 0 === e ? void 0 : e.value;
        this.setData({
            dialogEditing: !1,
            seletedDialogId: -1
        }, function() {
            i.editDialogTitle(a, o);
        });
    }, v.prototype.onEditDialogBlur = function() {
        this.resetOperateState();
    }, v.prototype.onReachBottom = function() {
        this.getDialogList();
    }, v.prototype.onDialogRefresh = function() {
        this._freshing || (this._freshing = !0, this.getDialogList(!0));
    }, v.prototype.onAddDialog = function() {
        var t = getCurrentPages();
        if ("2" !== this.data.currentTab) if ("pages/home/index" === t[0].route) {
            var e = t.length;
            t[0].setInitialState(), wx.navigateBack({
                delta: e - 1
            });
        } else u.relaunch(); else {
            u.relaunch("/pages/home/index", {
                tab: "playground"
            });
        }
    }, v.prototype.resetOperateState = function() {
        var t;
        null === (t = this._dialogInstance) || void 0 === t || t.close(), this.setData({
            firstDeleteTap: !1,
            dialogEditing: !1,
            seletedDialogId: -1
        });
    }, v.prototype.onMaskTap = function() {
        this.resetOperateState();
    }, v.prototype.onBeforeUnload = function() {}, v.prototype.onTabTap = function(t) {
        var e = this, i = t.currentTarget.dataset.type;
        this._data.offset = 0, this.setData({
            currentTab: i,
            dialogList: null
        }, function() {
            e.getDialogList(!0);
        });
    }, v.prototype.handleGoSetting = function() {
        l.$global(r.PERSONAL_NEW_SHOWED, !0), wx.setStorageSync(r.PERSONAL_NEW_SHOWED, !0), 
        this.setData({
            isFirstEntryPersonal: !1
        }), n.default.gotoPage("personal");
    }, v.prototype.handleGoMessage = function() {
        n.default.gotoPage("personal", {
            anchor: "message"
        });
    }, v.prototype.checkMessageStatus = function() {
        var t = this;
        g.apis.message.list({
            endpoint: 1
        }).then(function(e) {
            var i;
            if ((null === (i = null == e ? void 0 : e.messages) || void 0 === i ? void 0 : i.length) > 0) {
                var o = e.messages.find(function(t) {
                    return 1 === t.viewStatus;
                });
                t.setData({
                    hasNewMessage: !!o
                });
            }
        });
    }, v = t.__decorate([ o.wxPage({
        storeBindingOptions: {
            store: d.default,
            fields: [ "theme" ],
            actions: [ "updateThemeConfig" ]
        }
    }) ], v);
}(a.BasePage);

exports.Dialog = v;