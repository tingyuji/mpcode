var e = require("../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Home = void 0;

var t, a = require("tslib"), o = require("../../common/http-client/index"), n = require("../../common/urlDecNavigator"), i = require("../../components/base-page/utils"), s = a.__importDefault(require("../../components/notify/notify")), r = require("../../services/session/authLogin"), u = require("../../config/constants"), d = require("../../core/decorator/pageDecorator"), c = require("../../core/base/basePage"), l = require("../../config/index"), h = require("../../services/session/index"), p = require("../../utils/guid"), g = require("../../utils/helper"), m = require("../../core/globalData"), f = require("../../utils/prefetch"), v = a.__importDefault(require("../../store/index")), S = require("../../core/base/helpers/index"), _ = require("../../utils/report"), w = require("../../utils/themeUtil"), y = g.getNavBarInfo().menuButtonRect;

t = wx.getStorageSync(l.KEYBOARD_HEIGHT), m.$global(l.TAB_NEW_SHOWED, wx.getStorageSync(l.TAB_NEW_SHOWED));

var T = function(c) {
    function T() {
        var e = null !== c && c.apply(this, arguments) || this;
        return e.data = {
            homePageMode: !0,
            currentCid: "",
            chatOptions: {},
            menuButtonRect: y,
            inputFocus: !1,
            showPlugin: !1,
            inputContent: "",
            inputPureContent: "",
            exampleList: [],
            navigatorBar: {
                openImmersive: !1,
                type: "0",
                bgColor: {
                    hex: "transparent"
                },
                image: null
            },
            pluginId: u.CHAT_PLUGIN_LIST.default,
            isIOS: g.isIOS,
            placeholderLoadText: "",
            pluginList: u.PLUGIN_LIST,
            keyboardOffsetY: t,
            duration: 200,
            editorHeight: 84,
            chatWindowKey: 0,
            theme: {
                name: ""
            },
            selectMode: !1,
            showTemplate: !1,
            shouldPluginTipsShow: !1,
            agreeUserRules: !1,
            shouldAgreementShow: !1,
            templateId: "",
            chatName: "腾讯混元助手",
            currentTab: "chat",
            pageStackLength: 1,
            copyMsg: "",
            hasNewMessage: !1
        }, e._data = {
            webViewLoaded: !1,
            defaultPluginId: u.CHAT_PLUGIN_LIST.default,
            templateIdFromHistory: ""
        }, e;
    }
    return a.__extends(T, c), T.prototype.onLoad = function(t) {
        var o;
        return a.__awaiter(this, void 0, void 0, function() {
            var n, s, r, d, c;
            return a.__generator(this, function(a) {
                switch (a.label) {
                  case 0:
                    h.session.getIsLogin() && h.session.hasAuth() || i.showLoading(), this.judgeHideLoading(!!t.id), 
                    this.getUserInfo(), this.handleLoad(t), a.label = 1;

                  case 1:
                    return a.trys.push([ 1, 3, , 4 ]), [ 4, f.memoizedGetConfig.call() ];

                  case 2:
                    return a.sent(), [ 3, 4 ];

                  case 3:
                    return n = a.sent(), console.error("Error loading config", n), _.customReport({
                        event: "ERROR_LOADING_CONFIG",
                        error: "object" === e(n) ? n.message ? n.message : JSON.stringify(n) : n
                    }), -1 === (null == n ? void 0 : n.message.indexOf("timeout")) ? [ 2 ] : (f.memoizedGetConfig.reset(), 
                    wx.showModal({
                        title: "提示",
                        content: "小程序配置拉取失败",
                        showCancel: !0,
                        confirmText: "重新加载",
                        success: function(e) {
                            e.confirm && g.relaunch();
                        }
                    }), [ 3, 4 ]);

                  case 4:
                    return m.$global(l.TAB_NEW_SHOWED) || this.setData({
                        isFirstEntryTab: !0
                    }), t.theme && t.theme !== this.data.theme.name && w.updateAppTheme({
                        theme: t.theme || "light",
                        forGlobal: !0,
                        saveStorage: !1
                    }), [ 4, f.memoizedGetConfig.call() ];

                  case 5:
                    return s = a.sent(), r = s.plugins, d = {}, null == r || r.map(function(e) {
                        d[e.id || "default"] = e.templates || [];
                    }), c = (null === (o = null == r ? void 0 : r.filter(function(e) {
                        return e.default;
                    })[0]) || void 0 === o ? void 0 : o.id) || u.CHAT_PLUGIN_LIST.default, this._data.defaultPluginId = c, 
                    this.updataNewestPlugin(r), this.checkHasNewestPlugin(), this.setData({
                        pluginList: r,
                        pluginId: c,
                        pluginTemplateMap: d
                    }), [ 2 ];
                }
            });
        });
    }, T.prototype.judgeHideLoading = function(e) {
        var t;
        return void 0 === e && (e = !1), a.__awaiter(this, void 0, void 0, function() {
            var o;
            return a.__generator(this, function(a) {
                switch (a.label) {
                  case 0:
                    return [ 4, r.authLogin.waitAuth() ];

                  case 1:
                    return a.sent(), o = null === (t = this.data.chatOptions) || void 0 === t ? void 0 : t.showPromptList, 
                    e || !h.session.hasAuth() || o ? [ 4, f.memoizedGetConfig.call() ] : (i.hideLoading(), 
                    [ 2 ]);

                  case 2:
                    return a.sent(), i.hideLoading(), [ 2 ];
                }
            });
        });
    }, T.prototype.onShow = function() {
        g.judgeLoginAuth();
        var e = this.data, t = e.homePageMode, a = e.currentTab;
        setTimeout(function() {
            t && ("chat" === a && _.customReport({
                event: _.CustomEvents.EXPOSE_GENERAL_CHAT
            }), "playground" === a && _.customReport({
                event: _.CustomEvents.EXPOSE_INSPIRE_CHAT
            }));
        }, 1e3), this.checkMessageStatus();
    }, T.prototype.onUnload = function() {
        this.stopChat();
    }, T.prototype.updataNewestPlugin = function(e) {
        void 0 === e && (e = this.data.pluginList);
        var t = wx.getStorageSync(l.NEWEST_PLUGIN_MAP) || {};
        e.map(function(e) {
            !e.newest || 0 !== Object.keys(t).length && -1 !== Object.keys(t).indexOf(e.id || "default") || (t[e.id || "default"] = !0);
        }), wx.setStorageSync(l.NEWEST_PLUGIN_MAP, t);
    }, T.prototype.checkHasNewestPlugin = function() {
        var e = wx.getStorageSync(l.NEWEST_PLUGIN_MAP), t = !e || Object.keys(e).some(function(t) {
            return e[t];
        });
        this.setData({
            shouldPluginTipsShow: t
        });
    }, T.prototype.markNewestPluginShowed = function() {
        var e = wx.getStorageSync(l.NEWEST_PLUGIN_MAP);
        e && (Object.keys(e).map(function(t) {
            e[t] = !1;
        }), wx.setStorageSync(l.NEWEST_PLUGIN_MAP, e), this.setData({
            shouldPluginTipsShow: !1
        }));
    }, T.prototype.onReady = function() {
        var e = this;
        this._data.webViewLoaded || setTimeout(function() {
            var t;
            e._data.webViewLoaded = !0, null === (t = wx.preloadWebview) || void 0 === t || t.call(wx);
        }, 200);
    }, T.prototype.onShareAppMessage = function(e) {
        var t, a = e.from, o = "light" === this.data.theme.name ? u.SHARE_LOGO_LIGHT : u.SHARE_LOGO_DARK, n = "light" === this.data.theme.name ? u.SHARE_CHAT_LIGHT : u.SHARE_CHAT_DARK, i = this.data.chatName, s = u.CHAT_MODELS.find(function(e) {
            return e.text === i;
        }) ? i : "腾讯混元助手";
        if ("menu" === a) return {
            title: "震惊了，这个人工智能语言模型居然可以回答我任何问题哦",
            path: "/pages/home/index?theme=" + this.data.theme.name,
            imageUrl: o
        };
        var r = p.guidMaker.produce(), d = this.selectComponent("#chat-window");
        return {
            title: h.session.getUserName() + "和" + s + "的对话记录",
            path: "/pages/share-chat/index?shareId=" + r + "&theme=" + this.data.theme.name + "&templateId=" + ((null == d ? void 0 : d.data.inspireCardSelected) || (null === (t = null == d ? void 0 : d.data.inspireInfo) || void 0 === t ? void 0 : t.id) || ""),
            imageUrl: n
        };
    }, T.prototype.handleGoHistory = function() {
        var e = this;
        this.commonLeaveConfirm(function() {
            e.stopChat(), n.navigateToHistory();
        });
    }, T.prototype.handleNewSession = function(e) {
        void 0 === e && (e = !0);
        var t = this.data.templateId;
        t && _.customReport({
            event: _.CustomEvents.CLICK_INSPIRE_NEW_SESSION,
            data: {
                templateId: t
            }
        }), !e || this.data.currentCid || "playground" === this.data.currentTab ? this.commonLeaveConfirm(this.newSessionLogic) : s.default.info({
            message: "当前已是新对话"
        });
    }, T.prototype.commonLeaveConfirm = function(e) {
        var t, a, o;
        if (global.imageTextAnswering || global.contentAnswering) {
            S.dialog.confirm({
                title: "确认离开吗",
                message: "内容正在生成，离开当前页面\n会中止内容生成",
                confirmButtonText: "继续生成",
                cancelButtonText: "离开"
            }).then(function() {
                console.log("confirm");
            }).catch(function() {
                e();
            });
        } else {
            if (null === (o = null === (a = null === (t = this.selectComponent("#chat-window")) || void 0 === t ? void 0 : t.selectComponent("#pdf-parse")) || void 0 === a ? void 0 : a.data) || void 0 === o ? void 0 : o.isUploading) return void S.dialog.confirm({
                title: "确认离开吗",
                message: "文档正常上传中，离开当前页面会终止文档上传",
                confirmButtonText: "继续上传",
                cancelButtonText: "离开"
            }).then(function() {
                console.log("confirm");
            }).catch(function() {
                e();
            });
            e();
        }
    }, T.prototype.newSessionLogic = function() {
        if (this.stopChat(), this.data.templateId) this.setTemplateChatState(); else {
            var e = getCurrentPages();
            if ("pages/home/index" === e[0].route) {
                var t = e.length;
                e[0].setInitialState(), t > 1 && wx.navigateBack({
                    delta: t - 1
                });
            } else g.relaunch();
        }
    }, T.prototype.setInitialState = function() {
        this.setData({
            currentTab: "chat",
            chatWindowKey: this.data.chatWindowKey + 1,
            currentCid: "",
            chatName: "腾讯混元助手"
        });
    }, T.prototype.setTemplateChatState = function() {
        var e = this.data.chatOptions.plugin, t = this.data.templateId;
        this.setData({
            chatWindowKey: this.data.chatWindowKey + 1,
            chatOptions: {
                id: "",
                q: "",
                plugin: e,
                showPromptList: !1,
                templateId: t
            },
            currentCid: "",
            chatName: "腾讯混元助手"
        });
    }, T.prototype.getUserInfo = function() {
        return a.__awaiter(this, void 0, void 0, function() {
            var e, t, n;
            return a.__generator(this, function(a) {
                switch (a.label) {
                  case 0:
                    return (e = h.session.geWaterMarkString()) ? [ 3, 2 ] : [ 4, r.authLogin.refreshLogin() ];

                  case 1:
                    a.sent(), e = h.session.geWaterMarkString(), a.label = 2;

                  case 2:
                    if (global[u.CURRENT_LOGIN_TYPE] === u.LOGIN_USER_TYPE.outerUser) return [ 2 ];
                    a.label = 3;

                  case 3:
                    return a.trys.push([ 3, 5, , 6 ]), [ 4, o.apis.conv.getShareContent({
                        shareId: e
                    }) ];

                  case 4:
                    return t = a.sent(), n = JSON.parse((null == t ? void 0 : t.data) || "{}").agreeUserRules, 
                    console.log(n), this.setData({
                        shouldAgreementShow: !n
                    }), [ 3, 6 ];

                  case 5:
                    return a.sent(), this.setData({
                        shouldAgreementShow: !0
                    }), [ 3, 6 ];

                  case 6:
                    return this.data.shouldAgreementShow || g.judgeShowWorkwxTips(), [ 2 ];
                }
            });
        });
    }, T.prototype.handleLoad = function(e) {
        "playground" === e.tab && this.setData({
            currentTab: "playground"
        }), console.log("%chome page load params:", "color: #ff0000", e);
        var t = e.plugin || this._data.defaultPluginId, a = !("false" === e.homePageMode || e.id), o = e.id, n = void 0 === o ? "" : o, i = e.q, s = void 0 === i ? "" : i, r = e.templateId, u = void 0 === r ? "" : r;
        this.setData({
            currentCid: n,
            chatOptions: {
                id: n,
                q: decodeURIComponent(s),
                plugin: t,
                showPromptList: a && !u,
                templateId: u
            },
            templateId: u,
            homePageMode: a,
            pageStackLength: getCurrentPages().length
        });
    }, T.prototype.onPluginTap = function(e) {
        var t = e.currentTarget.dataset.id;
        this.setData({
            pluginId: t
        });
    }, T.prototype.handleStatusChange = function(e) {
        this.setData({
            currentCid: e.detail.convId
        });
    }, T.prototype.stopChat = function() {
        this.data.currentCid && o.apis.conv.stopChat({
            cid: this.data.currentCid
        }).then(function() {}).catch(function(e) {
            console.error("stoping chat err", e);
        });
    }, T.prototype.handleSetSelectMode = function(e) {
        var t = e.detail.selectMode;
        this.setData({
            selectMode: t
        });
    }, T.prototype.cancelSelectMode = function() {
        this.setData({
            selectMode: !1
        });
    }, T.prototype.onTabTap = function(e) {
        var t = this, a = e.currentTarget.dataset.path;
        this.commonLeaveConfirm(function() {
            "playground" === a && (m.$global(l.TAB_NEW_SHOWED, !0), wx.setStorageSync(l.TAB_NEW_SHOWED, !0), 
            t.setData({
                isFirstEntryTab: !1
            })), t.setData({
                currentTab: a
            }), t.stopChat();
        }), "chat" === a && _.customReport({
            event: _.CustomEvents.EXPOSE_GENERAL_CHAT
        }), "playground" === a && _.customReport({
            event: _.CustomEvents.EXPOSE_INSPIRE_CHAT
        }), "playground" === a && _.tamEventReport({
            event: _.CustomEvents.CLICK_INSPIRE_TAB
        });
    }, T.prototype.onLeave = function() {
        this.setData({
            currentTab: "chat"
        });
    }, T.prototype.onTitleChange = function(e) {
        this.setData({
            chatName: e.detail.title
        });
    }, T.prototype.handleGoBack = function() {
        var e = this;
        this.commonLeaveConfirm(function() {
            e.stopChat(), wx.navigateBack();
        });
    }, T.prototype.handleSetTemplateId = function(e) {
        this.setData({
            templateId: e.detail
        });
    }, T.prototype.checkMessageStatus = function() {
        var e = this;
        o.apis.message.list({
            endpoint: 1
        }).then(function(t) {
            var a;
            if ((null === (a = null == t ? void 0 : t.messages) || void 0 === a ? void 0 : a.length) > 0) {
                var o = t.messages.find(function(e) {
                    return 1 === e.viewStatus;
                });
                e.setData({
                    hasNewMessage: !!o
                });
            }
        });
    }, T = a.__decorate([ d.wxPage({
        storeBindingOptions: {
            store: v.default,
            fields: [ "theme" ]
        }
    }) ], T);
}(c.BasePage);

exports.Home = T;