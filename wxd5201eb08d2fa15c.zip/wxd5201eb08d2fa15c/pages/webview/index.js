Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Webview = void 0;

var e = require("tslib"), t = require("../../core/decorator/pageDecorator"), a = require("../../core/base/basePage"), r = e.__importDefault(require("../../store/index")), o = require("../../services/session/index"), i = function(a) {
    function i() {
        var e = null !== a && a.apply(this, arguments) || this;
        return e.data = {
            theme: {
                name: "light"
            },
            warning: !1,
            show: !0
        }, e;
    }
    return e.__extends(i, a), i.prototype.onLoad = function(e) {
        var t = e.url, a = encodeURIComponent(o.session.geWaterMarkString() || ""), r = +new Date();
        t || this.setData({
            warning: !0
        }), this.setData({
            url: t + "?username=" + a + "&ts=" + r
        });
    }, i.prototype.onShow = function() {
        this.setData({
            show: !0
        });
    }, i.prototype.onHide = function() {
        this.setData({
            show: !1
        });
    }, i.prototype.handleMessage = function(e) {
        var t, a = e.detail;
        a.data && a.data.length > 0 && wx.setClipboardData({
            data: (null === (t = a.data[a.data.length - 1]) || void 0 === t ? void 0 : t.url) || ""
        });
    }, i = e.__decorate([ t.wxPage({
        storeBindingOptions: {
            store: r.default,
            fields: [ "theme" ]
        }
    }) ], i);
}(a.BasePage);

exports.Webview = i;