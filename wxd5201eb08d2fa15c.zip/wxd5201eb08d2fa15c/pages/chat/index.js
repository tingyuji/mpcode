require("../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Chat = void 0;

var t = require("tslib"), e = require("../../common/http-client/index"), n = require("../../common/urlDecNavigator"), i = require("../../components/base-page/utils"), s = t.__importDefault(require("../../components/notify/notify")), o = require("../../config/constants"), a = require("../../config/index"), r = require("../../core/base/baseComponent"), c = require("../../core/decorator/componentDecorator"), u = require("../../interface/type"), l = require("../../utils/guid"), d = require("../../utils/helper"), p = require("../../utils/prefetch"), h = require("../../utils/preGenCid"), v = require("../../utils/report"), f = require("../../services/session/index"), g = require("../../utils/share/type"), m = t.__importDefault(require("../../common/navigator")), _ = 0;

try {
    _ = wx.getStorageSync(a.KEYBOARD_HEIGHT);
} catch (t) {}

function C(t) {
    for (var e, n, i = -1, s = 0; s < t.length; s++) {
        var o = "string" == typeof t[s] ? t[s] : (null === (e = t[s]) || void 0 === e ? void 0 : e.msg) || (null === (n = t[s]) || void 0 === n ? void 0 : n.text) || "";
        if (d.CHAT_NO_FEED_BACK_MSGS.includes(o)) i = -1; else {
            if (-1 !== i && s - i == 1) return s;
            i = s;
        }
    }
    return -1;
}

var T = [ "很抱歉，我还未学习到这个问题的内容，无法提供相关信息。", "很抱歉，由于访问量过大，建议您稍后或闲时再试，感谢您的理解与支持。", "抱歉，当前访问人数过多，服务繁忙，请稍后再试。", "请求超时，请重试", "网络异常，请重试", "抱歉，生成失败，请重新生成", "未知消息返回格式未知", "服务器错误" ], I = function(r) {
    function I() {
        var n = null !== r && r.apply(this, arguments) || this;
        return n.properties = {
            options: {
                type: Object,
                observer: function(t) {
                    var e = this;
                    setTimeout(function() {
                        t && Object.keys(t).length && e.init(t);
                    });
                }
            },
            selectMode: {
                type: Boolean,
                observer: function(t) {
                    this.data.isSelectMode !== t && this.setData({
                        isSelectMode: t
                    });
                }
            },
            templateId: {
                type: String,
                value: "",
                observer: function(t) {
                    this.initPdf(t);
                }
            },
            showPromptDerive: {
                type: Boolean,
                value: !1
            },
            isHome: {
                type: Boolean,
                value: !1
            }
        }, n.data = {
            singleRoundInspireStyle: !1,
            convStatus: o.CONV_STREAM_TYPE.DONE,
            convId: "",
            convList: [],
            selectedPlugin: o.CHAT_PLUGIN_LIST.default,
            firstConv: !1,
            inputContent: "",
            inputPureContent: "",
            inputFocus: !1,
            isIOS: d.isIOS,
            pluginIdInfoMap: o.PLUGIN_ID_INFO_MAP,
            CHAT_MAX_ROUND: o.CHAT_MAX_ROUND,
            keyboardOffsetY: _,
            duration: 200,
            editorHeight: 84,
            isSelectMode: !1,
            selectedList: [],
            curMsgIndex: -1,
            listMinHeight: "100vh",
            stoppingChat: !1,
            chatIcon: "",
            chatModelId: o.CHAT_MODELS[0].key,
            isHintCollapse: !0,
            inspireCardSelected: "",
            inspireInfo: null,
            isPdfParse: !1,
            step: null,
            promptDeriveList: null,
            chatQuota: -1,
            modelCompareEnable: !1,
            showRepeatFeedBackIndex: -1,
            historyConvListLen: 0,
            showSliceHistory: !1,
            isCutoff: !1,
            showInstructs: !1,
            showInstructGuide: !1,
            showRecommendInstruct: !1,
            inspirationListFold: !1
        }, n.pageLifetimes = {
            show: function() {
                var n;
                return t.__awaiter(this, void 0, void 0, function() {
                    var i, s, o = this;
                    return t.__generator(this, function(t) {
                        switch (t.label) {
                          case 0:
                            return e.apis.conv.getQuotaInfo().then(function(t) {
                                ((null == t ? void 0 : t.remainQuota) <= 0 || (null == t ? void 0 : t.remainQuota) <= t.alarmQuota) && o.setData({
                                    chatQuota: t.remainQuota <= 0 ? 0 : t.remainQuota
                                });
                            }).catch(function(t) {
                                console.error("page onshow 获取限额错误", t);
                            }), [ 4, p.memoizedGetConfig.call() ];

                          case 1:
                            return i = t.sent(), s = null === (n = null == i ? void 0 : i.privilege) || void 0 === n ? void 0 : n.modelCompetition, 
                            this.setData({
                                modelCompareEnable: !!s
                            }), [ 2 ];
                        }
                    });
                });
            }
        }, n;
    }
    return t.__extends(I, r), I.prototype.attached = function() {
        var e;
        return t.__awaiter(this, void 0, void 0, function() {
            var n, i, s;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return [ 4, p.getPluginIdInfoMap() ];

                  case 1:
                    return n = t.sent(), this.setData({
                        pluginIdInfoMap: n
                    }), [ 4, p.memoizedGetConfig.call() ];

                  case 2:
                    return i = t.sent(), s = null === (e = null == i ? void 0 : i.privilege) || void 0 === e ? void 0 : e.modelCompetition, 
                    this.setData({
                        modelCompareEnable: !!s
                    }), global.imageTextAnswering = !1, global.goodsTextAnswering = !1, global.contentAnswering = !1, 
                    this.checkInstructGuide(), [ 2 ];
                }
            });
        });
    }, I.prototype.detached = function() {
        global.imageTextAnswering = !1, global.goodsTextAnswering = !1, global.contentAnswering = !1;
    }, I.prototype.ready = function() {
        var t = this;
        setTimeout(function() {
            t.setData({
                listMinHeight: "auto"
            });
        }, 50), this.getInspirationList();
    }, I.prototype.getInspirationList = function() {
        return t.__awaiter(this, void 0, void 0, function() {
            var e, n;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return [ 4, p.memoizedGetConfig.call() ];

                  case 1:
                    return e = t.sent().inspirations || [], n = e.filter(function(t) {
                        return t.shortcut;
                    }).sort(function(t, e) {
                        return t.shortcutSort - e.shortcutSort;
                    }), this.setData({
                        inspirationList: n
                    }), [ 2 ];
                }
            });
        });
    }, I.prototype.getInspirationById = function(n) {
        var i;
        return t.__awaiter(this, void 0, void 0, function() {
            var s, o, a, r, c;
            return t.__generator(this, function(u) {
                switch (u.label) {
                  case 0:
                    return [ 4, p.memoizedGetConfig.call() ];

                  case 1:
                    return s = u.sent().inspirations || [], (null == (o = s.filter(function(t) {
                        var e;
                        return (null === (e = t.template) || void 0 === e ? void 0 : e.id) === n;
                    })[0]) ? void 0 : o.template) && (delete (a = t.__assign({}, o)).template, o = t.__assign(t.__assign({}, o.template), a)), 
                    o ? [ 3, 3 ] : [ 4, e.apis.conv.getInspirationDetail({
                        id: n
                    }) ];

                  case 2:
                    o = u.sent(), u.label = 3;

                  case 3:
                    return r = d.getCurrentPage(), (c = null === (i = s.find(function(t) {
                        return t.template.id === n;
                    })) || void 0 === i ? void 0 : i.scene) && r && r.setData({
                        chatName: c
                    }), [ 2, o ];
                }
            });
        });
    }, I.prototype.getScrollViewAndScroll = function() {
        var t = this;
        this.createSelectorQuery().select("#chat-msgs-scroll-view").node().exec(function(e) {
            var n, i = null === (n = null == e ? void 0 : e[0]) || void 0 === n ? void 0 : n.node;
            i && (d.isIOS ? setTimeout(function() {
                i.scrollTo({
                    top: -10,
                    duration: 100
                });
            }, 160) : i.scrollTo({
                top: 0,
                duration: 100
            }), t.chatScrollView = i);
        });
    }, I.prototype.getInspireScrollViewAndScroll = function() {
        var t = this;
        this.chatScrollView ? wx.createSelectorQuery().selectViewport().scrollOffset(function(e) {
            t.chatScrollView.scrollTo({
                top: e.scrollHeight + 9999,
                duration: 0
            });
        }).exec() : this.createSelectorQuery().select("#chat-msgs-scroll-view").node().exec(function(e) {
            var n, i = null === (n = null == e ? void 0 : e[0]) || void 0 === n ? void 0 : n.node;
            i && (t.chatScrollView = i, wx.createSelectorQuery().selectViewport().scrollOffset(function(e) {
                t.chatScrollView.scrollTo({
                    top: e.scrollHeight,
                    duration: 0
                });
            }).exec());
        });
    }, I.prototype.init = function(e) {
        return t.__awaiter(this, void 0, void 0, function() {
            var i, s, a, r, c;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return console.log("%cchat initialization %s %o", "color:#00ff00", this.__wxExparserNodeId__, e), 
                    this.setData({
                        convList: [],
                        inputContent: "",
                        inputPureContent: "",
                        showPromptList: e.showPromptList
                    }), e.id ? [ 4, n.memoizedGetConvList.call(e.id) ] : [ 3, 4 ];

                  case 1:
                    return i = t.sent(), n.memoizedGetConvList.reset(), s = i.convs.length, a = o.CHAT_MODELS.find(function(t) {
                        return t.key === i.modelId;
                    }), r = d.handleChatListTransform(i.convs), this.setData({
                        convId: e.id,
                        convList: r,
                        convStatus: s && i.sensitive ? o.CONV_STREAM_TYPE.SENSITIVE_DONE : o.CONV_STREAM_TYPE.DONE,
                        selectedPlugin: i.pluginId || o.CHAT_PLUGIN_LIST.default,
                        chatIcon: null == a ? void 0 : a.chatIcon,
                        chatModelId: null == a ? void 0 : a.key,
                        historyConvListLen: s,
                        showSliceHistory: !i.sensitive && !r[0].isLastSkipHistory && s < 2 * o.CHAT_MAX_ROUND,
                        hasSkipHistory: i.convs.some(function(t) {
                            return "ai" === t.speaker && t.isSkipHistory;
                        })
                    }), this.triggerEvent("onTitleChange", {
                        title: null == a ? void 0 : a.text
                    }), i.inspirationTemplate ? [ 4, this.getInspirationById(i.inspirationTemplate) ] : [ 3, 3 ];

                  case 2:
                    c = t.sent(), this.triggerEvent("setTemplateId", i.inspirationTemplate), c && (this.setData({
                        inspireInfo: c
                    }), d.getCurrentPage().setData({
                        templateId: c.id
                    }), this.initPdf(c.id, i)), t.label = 3;

                  case 3:
                    return [ 3, 5 ];

                  case 4:
                    this.setData({
                        selectedPlugin: e.plugin || o.CHAT_PLUGIN_LIST.default,
                        chatIcon: o.CHAT_MODELS[0].chatIcon
                    }), e.q ? this.chat(e.q, o.CONV_CHAT_TYPE.CHAT) : this.setData({
                        convStatus: o.CONV_STREAM_TYPE.DONE
                    }), t.label = 5;

                  case 5:
                    return !e.templateId || e.id ? [ 3, 7 ] : (this.initPdf(e.templateId), [ 4, this.getInspirationById(e.templateId) ]);

                  case 6:
                    c = t.sent(), this.setData({
                        inspireInfo: c
                    }), t.label = 7;

                  case 7:
                    return [ 2 ];
                }
            });
        });
    }, I.prototype.initPdf = function(t, e) {
        var n, i, s, r;
        if (t === a.PDF_TEMPLATE_ID && (this.setData({
            selectedPlugin: o.CHAT_PLUGIN_LIST.PDF,
            isPdfParse: !0
        }), d.getCurrentPage().setData(((n = {})["navigatorBar.bgColor.hex"] = "#fff", n)), 
        e)) {
            var c, u = null, l = e.convs.find(function(t) {
                return "human" === t.speaker;
            }), p = e.convs.find(function(t) {
                return "ai" === t.speaker;
            });
            if (l) if (c = null === (i = null == l ? void 0 : l.speechesV2) || void 0 === i ? void 0 : i.find(function(t) {
                return "multimodal" === (null == t ? void 0 : t.speechType);
            })) {
                var h = c.content.find(function(t) {
                    return "pdf" === t.type;
                });
                h && (u = h);
            }
            if (p) if (c = null === (s = null == p ? void 0 : p.speechesV2) || void 0 === s ? void 0 : s.find(function(t) {
                return "pdf_content_parse" === (null == t ? void 0 : t.speechType);
            })) {
                var v = c.content.find(function(t) {
                    return "step" === t.type && "failed" === t.status;
                });
                v ? this.setData({
                    step: v
                }) : this.setData({
                    step: {
                        msg: "summary"
                    }
                });
            }
            null === (r = this.selectComponent("#pdf-parse")) || void 0 === r || r.setData({
                actionType: e.sensitive ? "prepare" : "repeat",
                curFile: u,
                inHistory: !0
            });
        }
    }, I.prototype.onLastMessageLoad = function() {
        setTimeout(function() {
            i.hideLoading();
        }, 150);
    }, I.prototype.chat = function(n, i, a) {
        var r, c, l, p, f, g, m, _, C;
        return void 0 === i && (i = o.CONV_CHAT_TYPE.CHAT), t.__awaiter(this, void 0, void 0, function() {
            var I, S, y, D, E, A, P, w, L, M, N, O, R, H, x, b, k, V, Y, F, G = this;
            return t.__generator(this, function(U) {
                switch (U.label) {
                  case 0:
                    return this.data.convId ? [ 3, 2 ] : [ 4, h.getCids() ];

                  case 1:
                    I = U.sent()[0], this.setData({
                        convId: I
                    }), this.triggerEvent("pageStatusChange", {
                        convId: I
                    }), U.label = 2;

                  case 2:
                    return this.setData({
                        promptDeriveList: [],
                        showRepeatFeedBackIndex: -1,
                        isCutoff: !1,
                        inspirationListFold: !0
                    }), S = this.data, y = S.convList, D = S.inspireInfo, 0, E = i === o.CONV_CHAT_TYPE.CHAT ? [ "" ] : (null === (r = y[0]) || void 0 === r ? void 0 : r.speeches) || [ "" ], 
                    A = i === o.CONV_CHAT_TYPE.CHAT ? [ "" ] : (null === (l = null === (c = y[0]) || void 0 === c ? void 0 : c.pluginContext) || void 0 === l ? void 0 : l.pluginDescs) || new Array(E.length).fill(""), 
                    P = E.length - 1, w = (null === (f = null === (p = y[0]) || void 0 === p ? void 0 : p.speeches) || void 0 === f ? void 0 : f[P]) || "", 
                    i === o.CONV_CHAT_TYPE.CHAT ? (L = d.getInitialActiveQA(), M = {
                        createTime: +new Date(),
                        speaker: u.ChatRole.HUMAN,
                        speech: n,
                        key: u.ChatRole.HUMAN + (+new Date()).toString(),
                        voiceTempPath: a
                    }, N = {
                        question: n,
                        createTime: +new Date(),
                        feedback: [ 0 ],
                        speaker: u.ChatRole.AI,
                        speeches: [ L.answer ],
                        textMsgErrorType: L.textMsgErrorType,
                        pluginContext: {
                            pluginDescs: [ L.matchedPluginInfo ]
                        },
                        suitable: [ 0 ],
                        status: o.CONV_STREAM_TYPE.ADD,
                        key: u.ChatRole.AI + (+new Date()).toString()
                    }, this.setData({
                        convStatus: o.CONV_STREAM_TYPE.ADD,
                        convList: t.__spreadArray([ N, M ], y)
                    })) : i === o.CONV_CHAT_TYPE.RE_CHAT && y[0].status !== o.CONV_STREAM_TYPE.ERROR ? (E.push(""), 
                    A.push(""), null === (g = y[0].feedback) || void 0 === g || g.push(0), null === (m = y[0].suitable) || void 0 === m || m.push(0), 
                    P += 1, this.setData(((Y = {
                        convStatus: o.CONV_STREAM_TYPE.ADD
                    })["convList[0].status"] = o.CONV_STREAM_TYPE.ADD, Y["convList[0].speeches"] = E, 
                    Y["convList[0].pluginContext.pluginDescs"] = A, Y["convList[0].feedback"] = y[0].feedback, 
                    Y["convList[0].suitable"] = y[0].suitable, Y))) : i === o.CONV_CHAT_TYPE.RE_CHAT && y[0].status === o.CONV_STREAM_TYPE.ERROR ? (E[P] = "", 
                    this.setData(((F = {
                        convStatus: o.CONV_STREAM_TYPE.ADD
                    })["convList[0].status"] = o.CONV_STREAM_TYPE.ADD, F["convList[0].speeches"] = E, 
                    F["convList[0].pluginContext.pluginDescs"] = A, F))) : i === o.CONV_CHAT_TYPE.CONTINUE_CHAT && this.setData({
                        convStatus: o.CONV_STREAM_TYPE.ADD
                    }), D ? (R = (O = D).id, H = O.tag, x = O.scene, setTimeout(function() {
                        v.tamEventReport({
                            event: v.CustomEvents.SESSION_ASK,
                            data: {
                                cid: G.data.convId,
                                chatType: 2,
                                inspireTag: H,
                                sceneId: R,
                                sceneName: x,
                                model: G.data.chatModelId,
                                plugin: G.data.selectedPlugin,
                                prompt: n
                            }
                        });
                    }, 200)) : setTimeout(function() {
                        v.tamEventReport({
                            event: v.CustomEvents.SESSION_ASK,
                            data: {
                                cid: G.data.convId,
                                chatType: 0,
                                model: G.data.chatModelId,
                                plugin: G.data.selectedPlugin,
                                prompt: n
                            }
                        });
                    }, 200), b = {
                        cid: this.data.convId,
                        model: this.data.chatModelId,
                        plugin: this.data.selectedPlugin,
                        prompt: n,
                        inspirationTemplate: (null === (_ = this.data.inspireInfo) || void 0 === _ ? void 0 : _.id) || "",
                        continue: i === o.CONV_CHAT_TYPE.CONTINUE_CHAT,
                        isSkipHistory: null == D ? void 0 : D.singleRound
                    }, this.data.isPdfParse && (k = this.selectComponent("#pdf-parse"), ((null == (V = null === (C = null == k ? void 0 : k.data) || void 0 === C ? void 0 : C.curFile) ? void 0 : V.url) || (null == V ? void 0 : V.path)) && (b.multimedia = [ {
                        url: V.url || V.path,
                        type: "pdf",
                        fileName: V.name || V.fileName,
                        size: V.size
                    } ])), e.requestChatStream(b, i, function(t, e, n, a, r) {
                        var c, l, d;
                        console.log("数据类型是: ", t, n), n === u.StreamSpeechType.imageWithText ? global.imageTextAnswering = !0 : global.contentAnswering = !0;
                        var p = "";
                        n === u.StreamSpeechType.pdf && (G.setData({
                            step: {
                                msg: e.msg,
                                status: e.status
                            }
                        }), p = "string" == typeof e ? e : e.text), t === o.CONV_STREAM_TYPE.ERROR && !p && G.data.isPdfParse && s.default.error({
                            message: e
                        }), n === u.StreamSpeechType.cutoff && G.setData({
                            isCutoff: !0
                        }), n === u.StreamSpeechType.revoke && G.setData({
                            isCutoff: !1
                        });
                        var h = e;
                        n === u.StreamSpeechType.pdf && (h = p || e), i !== o.CONV_CHAT_TYPE.CONTINUE_CHAT || T.includes(h) || (h = w + h), 
                        G.setData(((c = {
                            convStatus: t
                        })["convList[0].speeches[" + P + "]"] = h, c["convList[0].status"] = t, c["convList[0].textMsgErrorType"] = r, 
                        c)), a && (A[P] = a, G.setData(((l = {})["convList[0].pluginContext.pluginDescs"] = A, 
                        l))), t === o.CONV_STREAM_TYPE.DONE && (G.data.isCutoff || G.getPromptDeriveList(), 
                        G.checkShowRepeatFeedBack()), (t === o.CONV_STREAM_TYPE.DONE || t === o.CONV_STREAM_TYPE.ERROR) && G.data.convList.length < 2 * o.CHAT_MAX_ROUND && G.setData({
                            showSliceHistory: !0
                        }), t !== o.CONV_STREAM_TYPE.DONE && t !== o.CONV_STREAM_TYPE.ERROR && t !== o.CONV_STREAM_TYPE.SENSITIVE_DONE || (global.imageTextAnswering = !1, 
                        global.goodsTextAnswering = !1, global.contentAnswering = !1, G.setData({
                            stoppingChat: !1,
                            step: {
                                msg: "summary"
                            }
                        }), null === (d = G.selectComponent("#pdf-parse")) || void 0 === d || d.setData({
                            actionType: t === o.CONV_STREAM_TYPE.SENSITIVE_DONE ? "prepare" : "repeat"
                        }));
                    }), [ 2 ];
                }
            });
        });
    }, I.prototype.reChat = function() {
        var t, e, n = this.data.convList;
        if ((null === (t = n[0]) || void 0 === t ? void 0 : t.speeches).length >= o.CHAT_MAX_REGEN_TIMES) return s.default.error({
            message: "重新生成已达次数上限，请提新问题"
        }), void (null === (e = this.selectComponent("#pdf-parse")) || void 0 === e || e.setData({
            actionType: "prepare"
        }));
        if (n.length > 1) {
            var i = n[1].speech;
            this.setData({
                step: {
                    msg: "pdf-parse"
                }
            }), this.chat(i, o.CONV_CHAT_TYPE.RE_CHAT);
        }
    }, I.prototype.continueChat = function() {
        var t = this.data.convList;
        if (t.length > 1) {
            var e = t[1].speech;
            this.setData({
                step: {
                    msg: "pdf-parse"
                }
            }), this.chat(e, o.CONV_CHAT_TYPE.CONTINUE_CHAT);
        }
    }, I.prototype.selectExample = function(t) {
        var e = this;
        if (0 !== this.data.chatQuota) {
            var n = t.detail;
            this.data.inputContent = n, this.data.inputPureContent = n, this.getScrollViewAndScroll(), 
            setTimeout(function() {
                e.onSend("promptList");
            }, 10), this.setData({
                showInstructGuide: !1
            });
        }
    }, I.prototype.onInputChange = function(t) {
        var e = t.detail.value;
        this.setData({
            inputContent: e,
            inputPureContent: e.trim()
        });
    }, I.prototype.onInputSend = function(t) {
        var e = t.detail, n = e.value, i = e.voiceTempPath;
        e.isRepeat ? this.reChat() : (this.data.inputPureContent = n, this.onSend("input", i));
    }, I.prototype.onSend = function(t, e) {
        var n = this.data, i = n.inputPureContent, a = n.convStatus;
        if (n.convList.length >= 2 * o.CHAT_MAX_ROUND) s.default.error({
            message: "本次会话回合数已达上限",
            duration: 2500
        }); else if ("" !== i && "sensitive" !== a && "add" !== a) {
            var r = d.getPromptText(this.data.inputPureContent);
            this.setData({
                inputContent: "",
                inputPureContent: "",
                inputFocus: "sceneCard" !== t
            }), this.getScrollViewAndScroll(), this.chat(r, o.CONV_CHAT_TYPE.CHAT, e);
        } else this.setData({
            inputFocus: !1
        });
    }, I.prototype.onSliceHistoryDone = function() {
        var t, e, n = this.data.convList.findIndex(function(t) {
            return !!t.isLastSkipHistory;
        });
        -1 !== n && this.setData(((t = {})["convList[" + n + "].isLastSkipHistory"] = !1, 
        t)), this.setData(((e = {
            hasSkipHistory: !0,
            showSliceHistory: !1
        })["convList[0].isLastSkipHistory"] = !0, e));
    }, I.prototype.handleShareMsg = function() {
        return t.__awaiter(this, void 0, void 0, function() {
            var n, i, o, a, r, c, u;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return n = [], i = this.data, o = i.selectedList, a = i.convList, r = i.singleRoundInspireStyle, 
                    o.length ? (c = a.length, o.sort(function(t, e) {
                        return r ? e - t : t - e;
                    }).forEach(function(t) {
                        r ? n.push(a[c - 1 - t]) : n.push(a[t]);
                    }), this.triggerEvent("setSelectMode", {
                        selectMode: !1
                    }), [ 4, l.guidMaker.consume() ]) : [ 2 ];

                  case 1:
                    return u = t.sent(), this.setData({
                        inspireCardSelected: "",
                        selectedList: []
                    }), e.apis.conv.getShareId({
                        shareId: u,
                        platform: "MINIPROGRAM",
                        nickname: f.session.getUserName(),
                        id: this.data.convId,
                        convs: n.map(function(t) {
                            return d.transformMsgForShare(t);
                        })
                    }).then(function(t) {
                        console.log("%cshare success:", "color: #00ff00", t);
                    }).catch(function(t) {
                        console.error("share id generation error", t), s.default.error({
                            message: "分享出错，请重试"
                        });
                    }), [ 2 ];
                }
            });
        });
    }, I.prototype.onMaskTap = function() {
        this.data.inputFocus && wx.hideKeyboard(), this.setData({
            inputFocus: !1
        });
    }, I.prototype.hideActionMenu = function() {
        var t, e = this.data.curMsgIndex;
        -1 !== e && (null === (t = this.selectComponent("#chat-msg-" + e)) || void 0 === t || t.hideActionMenu()), 
        this.setData({
            curMsgIndex: -1
        });
    }, I.prototype.onWrapTap = function() {
        var t;
        this.data.singleRoundInspireStyle ? this.hideActionMenu() : (null === (t = this.selectComponent("#chat-input")) || void 0 === t || t.setData({
            inputFocus: !1,
            showFunctions: !1
        }), this.setData({
            inputFocus: !1
        }), wx.hideKeyboard(), global.__MSG_TOOL_TAP || this.hideActionMenu());
    }, I.prototype.onKeyboardHeightChange = function(t) {
        console.error("keyboard height event", t);
        try {
            var e = null == t ? void 0 : t.detail, n = e.height, i = e.duration;
            if (!n) return;
            this.setData({
                keyboardOffsetY: n,
                duration: i
            }), wx.setStorageSync(a.KEYBOARD_HEIGHT, n);
        } catch (t) {
            console.error(t);
        }
    }, I.prototype.onLineChange = function(t) {
        var e = t.detail.height;
        if (e) {
            var n = e + 36 + 2 + 26;
            this.setData({
                editorHeight: n
            });
        }
    }, I.prototype.onInputFocus = function() {
        this.getScrollViewAndScroll(), this.setData({
            inputFocus: !0,
            showInstructGuide: !1
        }), this.resetOperateState();
    }, I.prototype.onInputLongpress = function() {
        this.onInputFocus();
    }, I.prototype.onInputBlur = function() {
        this.setData({
            inputFocus: !1
        });
    }, I.prototype.resetOperateState = function() {
        this.hideActionMenu();
    }, I.prototype.toggleMsgSelect = function(t) {
        var e;
        if (this.data.isSelectMode) {
            var n = t.currentTarget.dataset.index;
            if (-1 !== n) {
                var i = this.data.selectedList;
                i.includes(n) ? i = i.filter(function(t) {
                    return !(t === n || (n % 2 == 1 ? t === n - 1 : t === n + 1));
                }) : (i.push(n), i.push(n % 2 == 1 ? n - 1 : n + 1)), this.setData({
                    selectedList: i
                });
            } else this.setData({
                inspireCardSelected: this.data.inspireCardSelected ? "" : null === (e = this.data.inspireInfo) || void 0 === e ? void 0 : e.id
            });
        }
    }, I.prototype.handleShareSingleMsg = function(n) {
        return t.__awaiter(this, void 0, void 0, function() {
            var i, o, a, r, c, u, p, h, v = this;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return [ 4, l.guidMaker.consume() ];

                  case 1:
                    return i = t.sent(), o = n.detail.index, a = o % 2 == 1 ? o - 1 : o + 1, r = this.data, 
                    c = r.singleRoundInspireStyle, u = r.convList, p = u.length, h = (c ? [ p - 1 - o, p - 1 - a ] : [ o, a ]).sort(function(t, e) {
                        return t - e;
                    }).map(function(t) {
                        return d.transformMsgForShare(v.data.convList[t]);
                    }), e.apis.conv.getShareId({
                        shareId: i,
                        platform: "MINIPROGRAM",
                        nickname: f.session.getUserName(),
                        id: this.data.convId,
                        convs: h
                    }).then(function(t) {
                        console.log("%cshare success:", "color: #00ff00", t);
                    }).catch(function(t) {
                        console.error("share id generation error", t), s.default.error({
                            message: "分享出错，请重试"
                        });
                    }), [ 2 ];
                }
            });
        });
    }, I.prototype.handleSharePdfMsg = function(n) {
        return t.__awaiter(this, void 0, void 0, function() {
            var i, o, a, r = this;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return [ 4, l.guidMaker.consume() ];

                  case 1:
                    return i = t.sent(), o = n.detail.index, a = [ o ].map(function(t) {
                        return d.transformMsgForShare(r.data.convList[t]);
                    }), e.apis.conv.getShareId({
                        shareId: i,
                        platform: "MINIPROGRAM",
                        nickname: f.session.getUserName(),
                        data: JSON.stringify({
                            share_type: g.ChatDataShareType.SINGLE_PDF_PARSE,
                            userId: f.session.getUserName(),
                            shareFile: this.selectComponent("#pdf-parse").data.curFile,
                            chatInfo: [ {
                                moduleId: this.data.chatModelId,
                                moduleName: this.data.chatModelId,
                                cid: this.data.convId,
                                convs: a
                            } ]
                        })
                    }).then(function(t) {
                        console.log("%cshare success:", "color: #00ff00", t);
                    }).catch(function(t) {
                        console.error("share id generation error", t), s.default.error({
                            message: "分享出错，请重试"
                        });
                    }), [ 2 ];
                }
            });
        });
    }, I.prototype.handleSetSelectMode = function(t) {
        var e = this;
        setTimeout(function() {
            var n = t.currentTarget.dataset.index, i = n % 2 == 1 ? n - 1 : n + 1;
            e.setData({
                selectedList: [ n, i ]
            });
        }, 30), this.triggerEvent("setSelectMode", {
            selectMode: !0
        });
    }, I.prototype.handleInstructGuideTap = function() {
        this.setData({
            showInstructGuide: !1
        });
    }, I.prototype.handleOpenFeedbackWindow = function(t) {
        var e, n, i, s, o, a = this.data, r = a.convList, c = a.singleRoundInspireStyle, u = t.detail, l = u.type, d = u.msgIndex, p = u.cid, h = u.msgCount, v = u.currentAnswerIndex, f = r.length, g = c ? f - 2 - d : d, m = {
            msgIndex: d,
            cid: p,
            msgCount: h,
            currentAnswerIndex: v,
            imageList: (null === (n = null === (e = null == r ? void 0 : r[g].speeches) || void 0 === e ? void 0 : e[v]) || void 0 === n ? void 0 : n.images) ? (null === (i = r[g].speeches) || void 0 === i ? void 0 : i[v]).images.map(function(t) {
                return t.highDefImageUrl;
            }) : [],
            goodsList: (null === (o = null === (s = null == r ? void 0 : r[g].speeches) || void 0 === s ? void 0 : s[v]) || void 0 === o ? void 0 : o.goods) || [],
            qaCombined: c
        };
        this.setData({
            selectedMsgInfo: m,
            feedbackShow: !0,
            feedbackType: l
        });
    }, I.prototype.handleUpdateFeedBack = function(t) {
        var e, n = t.detail, i = n.msgIndex, s = n.currentAnswerIndex, o = n.suitable, a = i % 2 == 1 ? i - 1 : i + 1, r = this.data, c = r.singleRoundInspireStyle, u = r.convList.length, l = c ? u - 1 - a : i;
        this.setData(((e = {})["convList[" + l + "].suitable[" + s + "]"] = o, e));
    }, I.prototype.handleCloseFeedback = function() {
        this.setData({
            feedbackShow: !1
        });
    }, I.prototype.handleLongPress = function(t) {
        var e = t.detail;
        this.setData({
            curMsgIndex: e
        });
    }, I.prototype.handleNewSession = function() {
        var t, e = getCurrentPages(), n = e[e.length - 1];
        null === (t = n.newSessionLogic) || void 0 === t || t.call(n);
    }, I.prototype.stopGenerate = function() {
        return t.__awaiter(this, void 0, void 0, function() {
            var n = this;
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return this.data.stoppingChat ? [ 2 ] : (this.setData({
                        stoppingChat: !0
                    }), [ 4, e.apis.conv.stopChat({
                        cid: this.data.convId
                    }).then(function() {}).catch(function(t) {
                        console.error("stoping chat err", t), n.setData({
                            stoppingChat: !1
                        });
                    }) ]);

                  case 1:
                    return t.sent(), [ 2 ];
                }
            });
        });
    }, I.prototype.pdfParse = function(t) {
        var e, n;
        switch (t.detail.eventType) {
          case "onChat":
            this.setData({
                step: {
                    msg: "pdf_parse"
                }
            });
            this.chat("帮我总结这个文档，生成300字左右的总结内容，需要包括以下内容：1、这个文档主要在讲什么内容？或者这个文档的中心思想是什么？2、列举3-5点这个文档的关键内容");
            break;

          case "onStopChat":
            this.stopGenerate();
            break;

          case "onReChat":
            null === (e = this.selectComponent("pdf-parse")) || void 0 === e || e.setData({
                actionType: "working"
            }), this.setData({
                step: {
                    msg: "pdf_parse"
                }
            }), this.reChat();
            break;

          case "replaceFile":
            this.init({
                showPromptList: !1,
                templateId: null === (n = this.data.inspireInfo) || void 0 === n ? void 0 : n.id
            });
        }
    }, I.prototype.checkShowRepeatFeedBack = function() {
        if (this.data.showPromptDerive && 0 !== this.data.chatQuota && !this.data.inspireInfo && this.data.historyConvListLen !== this.data.convList.length) {
            var t = this.data.convList.filter(function(t) {
                return !!("ai" === t.speaker && t.speeches && t.speeches.length > 1) && C(t.speeches) > -1;
            }), e = C(this.data.convList[0].speeches);
            t.length % 4 == 1 && e > -1 ? this.setData({
                showRepeatFeedBackIndex: e
            }) : this.setData({
                showRepeatFeedBackIndex: -1
            });
        }
    }, I.prototype.getPromptDeriveList = function() {
        var t, n, i, s, a, r, c, u = this, l = this.data, d = l.showPromptDerive, p = l.stoppingChat, h = l.inspireInfo, f = l.convList, g = l.chatQuota;
        if (d && !p && !h && !(null === (i = null === (n = null === (t = f[0]) || void 0 === t ? void 0 : t.speeches) || void 0 === n ? void 0 : n[0]) || void 0 === i ? void 0 : i.type) && 0 !== g) {
            for (var m = [], _ = !1, C = f.filter(function(t) {
                return !_ && (!t.isLastSkipHistory || (_ = !0, !1));
            }).map(function(t) {
                var e, n = "ai" === t.speaker && t.speeches ? t.speeches[(null === (e = t.speeches) || void 0 === e ? void 0 : e.length) - 1] : t.speech;
                return {
                    speaker: t.speaker,
                    speech: n,
                    status: t.status
                };
            }), T = 0; T < C.length; ) {
                var I = void 0 !== (null === (s = C[T].speech) || void 0 === s ? void 0 : s.msg) ? null === (a = C[T].speech) || void 0 === a ? void 0 : a.msg : C[T].speech;
                if (null === (r = I) || void 0 === r ? void 0 : r.type) T += 2; else {
                    if (0 === T && (!I || (null === (c = I) || void 0 === c ? void 0 : c.type) || "error" === C[T].status || "sensitive" === C[T].status || 0 === ("string" == typeof I ? I : I.text || "").indexOf("很抱歉，由于访问量过大"))) return;
                    -1 === ("string" == typeof I ? I : I.text || "").indexOf("已暂停生成") && "error" !== C[T].status && "sensitive" !== C[T].status && [ C[T], C[T + 1] ].forEach(function(t) {
                        var e;
                        m.push({
                            speaker: t.speaker,
                            speech: void 0 !== (null === (e = t.speech) || void 0 === e ? void 0 : e.msg) ? t.speech.msg : t.speech
                        });
                    }), T += 2;
                }
            }
            0 !== m.length && e.apis.conv.getPrompt({
                convs: m.slice(0, 8).reverse()
            }).then(function(t) {
                var e;
                (null === (e = null == t ? void 0 : t.prompts) || void 0 === e ? void 0 : e.length) > 0 && u.data.convStatus === o.CONV_STREAM_TYPE.DONE && (u.setData({
                    promptDeriveList: t.prompts || []
                }), v.tamEventReport({
                    event: v.CustomEvents.SHOW_RECOMMEND_PROMPT,
                    data: {
                        cid: u.data.convId,
                        prompts: t.prompts || []
                    }
                }));
            }).catch(function(t) {
                console.log("error is: ", t), u.setData({
                    promptDeriveList: []
                });
            });
        }
    }, I.prototype.handlePromptTap = function(t) {
        var e = this, n = t.currentTarget.dataset, i = n.prompt, s = n.index;
        this.setData({
            inputContent: i,
            inputPureContent: i.trim()
        }), this.getScrollViewAndScroll(), setTimeout(function() {
            e.onSend("sceneCard");
        }, 10);
        var o = this.data.inspireInfo, a = o.id, r = o.tag, c = o.scene;
        v.tamEventReport({
            event: v.CustomEvents.CLICK_INSPIRE_CARD_PROMPT,
            data: {
                index: s + 1,
                prompt: i,
                cid: this.data.convId,
                inspireTag: r,
                sceneId: a,
                sceneName: c
            }
        });
    }, I.prototype.handleInspirationTap = function(t) {
        var e = {
            templateId: t.currentTarget.dataset.id,
            homePageMode: !1
        };
        m.default.gotoPage("home", e);
    }, I.prototype.handleShowInstruct = function() {
        wx.hideKeyboard(), this.setData({
            showInstructs: !0,
            showInstructGuide: !1
        }), wx.setStorageSync(o.INSTRUCT_GUIDE_KEY, 1);
    }, I.prototype.checkInstructGuide = function() {
        wx.getStorageSync(o.INSTRUCT_GUIDE_KEY) || this.setData({
            showInstructGuide: !0
        });
    }, I.prototype.handleInputChange = function(t) {
        var n = this, i = t.detail;
        this.setData({
            recommendInstruct: [],
            showRecommendInstruct: "/" === i
        }), setTimeout(function() {
            n.data.showRecommendInstruct && !n.data.inspireInfo && e.apis.instruct.recommend().then(function(t) {
                var e;
                n.data.showRecommendInstruct && (null === (e = null == t ? void 0 : t.results) || void 0 === e ? void 0 : e.length) > 0 && n.setData({
                    recommendInstruct: t.results || []
                });
            });
        }, 500);
    }, I.prototype.selectInstruct = function(t) {
        var e = this.selectComponent("#chat-input"), n = t.currentTarget.dataset.value;
        e && (null == e || e.setData({
            inputContent: n,
            inputPureContent: n
        }), this.setData({
            showRecommendInstruct: !1,
            recommendInstruct: []
        }));
    }, I.prototype.toggleInspirationList = function() {
        this.setData({
            inspirationListFold: !this.data.inspirationListFold
        });
    }, I = t.__decorate([ c.wxComponent() ], I);
}(r.BaseComponent);

exports.Chat = I;