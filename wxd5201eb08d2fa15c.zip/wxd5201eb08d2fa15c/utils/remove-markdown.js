module.exports = function(e, r) {
    (r = r || {}).listUnicodeChar = !!r.hasOwnProperty("listUnicodeChar") && r.listUnicodeChar, 
    r.stripListLeaders = !r.hasOwnProperty("stripListLeaders") || r.stripListLeaders, 
    r.gfm = !r.hasOwnProperty("gfm") || r.gfm, r.useImgAltText = !r.hasOwnProperty("useImgAltText") || r.useImgAltText, 
    r.abbr = !!r.hasOwnProperty("abbr") && r.abbr, r.replaceLinksWithURL = !!r.hasOwnProperty("replaceLinksWithURL") && r.replaceLinksWithURL, 
    r.htmlTagsToSkip = r.hasOwnProperty("htmlTagsToSkip") ? r.htmlTagsToSkip : [];
    var s = e || "";
    s = s.replace(/^(-\s*?|\*\s*?|_\s*?){3,}\s*/gm, "");
    try {
        r.stripListLeaders && (s = r.listUnicodeChar ? s.replace(/^([\s\t]*)([\*\-\+])\s+/gm, r.listUnicodeChar + " $1") : s.replace(/^([\s\t]*)([\*\-\+]|\d+\.)\s+/gm, "$1")), 
        r.gfm && (s = s.replace(/\n={2,}/g, "\n").replace(/~{3}.*\n/g, "").replace(/~~/g, "").replace(/`{3}.*\n/g, "")), 
        r.abbr && (s = s.replace(/\*\[.*\]:.*\n/, "")), s = s.replace(/<[^>]*>/g, "");
        var a = new RegExp("<[^>]*>", "g");
        if (r.htmlTagsToSkip.length > 0) {
            var t = "(?!" + r.htmlTagsToSkip.join("|") + ")";
            a = new RegExp("<" + t + "[^>]*>", "ig");
        }
        s = s.replace(a, "").replace(/^[=\-]{2,}\s*$/g, "").replace(/\[\^.+?\](\: .*?$)?/g, "").replace(/\s{0,2}\[.*?\]: .*?$/g, "").replace(/\!\[(.*?)\][\[\(].*?[\]\)]/g, r.useImgAltText ? "$1" : "").replace(/\[([^\]]*?)\][\[\(](.*?)[\]\)]/g, r.replaceLinksWithURL ? "$2" : "$1").replace(/^(\n)?\s{0,3}>\s?/gm, "$1").replace(/^\s{1,2}\[(.*?)\]: (\S+)( ".*?")?\s*$/g, "").replace(/^(\n)?\s{0,}#{1,6}\s*( (.+))? +#+$|^(\n)?\s{0,}#{1,6}\s*( (.+))?$/gm, "$1$3$4$6").replace(/([\*]+)(\S)(.*?\S)??\1/g, "$2$3").replace(/(^|\W)([_]+)(\S)(.*?\S)??\2($|\W)/g, "$1$3$4$5").replace(/(`{3,})(.*?)\1/gm, "$2").replace(/`(.+?)`/g, "$1").replace(/~(.*?)~/g, "$1");
    } catch (r) {
        return console.error(r), e;
    }
    return s;
};