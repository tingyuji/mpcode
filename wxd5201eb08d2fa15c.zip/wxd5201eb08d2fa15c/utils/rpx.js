Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getActionMenuPosition = exports.px2px = exports.px2rpx = exports.rpx2ppx = exports.rpx2px = exports.loadSystemInfo = void 0;

var t = require("./helper"), e = 0, r = 0, o = 0, p = 70, x = 34;

exports.loadSystemInfo = function() {
    if (e) return {
        systemWidth: e,
        systemHeight: r,
        pixelRatio: o,
        navBarHeight: p,
        bottomSafeArea: x
    };
    try {
        var t = wx.getSystemInfoSync();
        e = t.screenWidth, r = t.screenHeight, o = t.pixelRatio, p = s(), x = r - t.safeArea.bottom;
    } catch (t) {
        e = 375, r = 667;
    }
    return {
        systemWidth: e,
        systemHeight: r,
        pixelRatio: o,
        navBarHeight: p,
        bottomSafeArea: x
    };
};

exports.rpx2px = function(t, r) {
    void 0 === r && (r = !1), exports.loadSystemInfo();
    var o = t * e / 750;
    return r ? Math.floor(o) : o;
};

exports.rpx2ppx = function(t) {
    exports.loadSystemInfo();
    var r = t * e / 750 * o;
    return Math.floor(r);
}, exports.px2rpx = function(t, e) {
    return void 0 === e && (e = 750), exports.loadSystemInfo(), 750 * t / e;
};

exports.px2px = function(t, r) {
    return void 0 === r && (r = 750), exports.loadSystemInfo(), t * e / r;
};

var i = !1;

function s() {
    return i ? p : (i = !0, p = t.getNavBarInfo().navBarHeight);
}

exports.getActionMenuPosition = function(t) {
    var e = t.rect, o = t.customHeader, i = void 0 === o || o, n = t.menuHeight, a = void 0 === n ? 150 : n, f = t.bottomHeight, u = void 0 === f ? 370 : f, d = t.extraTopHeight, h = void 0 === d ? 0 : d, g = t.rightAdjust, l = void 0 === g ? 120 : g, m = t.topAdjust, v = void 0 === m ? 0 : m, c = t.bubbleType, y = void 0 === c ? "question" : c;
    exports.loadSystemInfo(), i && s();
    var S, H = exports.rpx2px(a) + (i ? p : 0) + (h ? exports.rpx2px(h) : 0), b = r - exports.rpx2px(a) - exports.rpx2px(u) - x, I = 0, w = "right: " + l + "rpx;";
    if (e.top > H) S = "up"; else if (e.bottom < b) S = "down", I = e.height + 16; else {
        S = -(H - e.top + exports.rpx2px(v) + 10);
    }
    return e.width < exports.rpx2px(520) && (w = "answer" === y ? "right: 82rpx;left:auto;" : "right: auto;left:82rpx;"), 
    {
        msgPosition: S,
        topOffset: I,
        caretOffset: e.width > exports.rpx2px(400) ? "left: 50%;" : "answer" !== y ? "right: " + e.width / 2 + "px;left:auto;margin-right: -12rpx;" : "right: auto;left:" + e.width / 2 + "px;margin-left: -12rpx;",
        msgRightOffset: w
    };
};