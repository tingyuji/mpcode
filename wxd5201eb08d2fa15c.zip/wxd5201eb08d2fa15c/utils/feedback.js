Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setTodayFeedBackTime = exports.getTodayHadFeed = exports.setUserOld = exports.getIsNewUser = void 0;

exports.getIsNewUser = function() {
    if (void 0 !== global.isNewUser) return global.isNewUser;
    var e = wx.getStorageSync("IS_NEW_USER");
    return global.isNewUser = !(!e && "" !== e), global.isNewUser;
}, exports.setUserOld = function() {
    !1 !== global.isNewUser && (wx.setStorageSync("IS_NEW_USER", !1), global.isNewUser = !1);
}, exports.getTodayHadFeed = function() {
    if (void 0 !== global.todayHadFeed) return global.todayHadFeed;
    var e = wx.getStorageSync("TODAY_FIRST_FEEDBACK_TIME"), t = new Date(), a = +new Date(t.getFullYear(), t.getMonth(), t.getDate());
    return global.todayHadFeed = e && e >= a, global.todayHadFeed;
}, exports.setTodayFeedBackTime = function() {
    !0 !== global.todayHadFeed && (global.todayHadFeed = !0, wx.setStorage({
        key: "TODAY_FIRST_FEEDBACK_TIME",
        data: +new Date()
    }));
};