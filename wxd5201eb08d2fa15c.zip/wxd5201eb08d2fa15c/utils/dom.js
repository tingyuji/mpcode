Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getBoundRect = void 0;

exports.getBoundRect = function(e, t) {
    return new Promise(function(n, o) {
        var r = wx.createSelectorQuery().in(e);
        r.selectAll(t).boundingClientRect(), r.exec(function(e) {
            var t = e[0];
            t ? n(t) : o(t);
        });
    });
};