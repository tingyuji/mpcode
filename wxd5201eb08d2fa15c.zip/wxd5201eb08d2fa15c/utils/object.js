var e = require("../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.URLStrToObj = exports.objToURLStr = exports.isPlainObject = exports.isObject = exports.toObject = exports.iterateInheritedPrototype = exports.getPrototypeOf = void 0;

var t = require("tslib");

function r(e) {
    return Object.getPrototypeOf ? Object.getPrototypeOf(e) : e.__proto__;
}

function o(e, t, o, n) {
    void 0 === n && (n = !0);
    for (var i = t.prototype || t, p = o.prototype || o; i && (n || i !== p) && !1 !== e(i) && i !== p; ) i = r(i);
}

function n(t) {
    var r = e(t);
    return null !== t && ("function" === r || "object" === r);
}

exports.getPrototypeOf = r, exports.iterateInheritedPrototype = o, exports.toObject = function(e, r) {
    void 0 === r && (r = {});
    var i = {};
    if (!n(e)) return i;
    var p = r.excludes || [ "constructor" ], c = r.enumerable, a = void 0 === c || c, s = r.configurable, u = void 0 === s ? 0 : s, f = r.writable, b = void 0 === f ? 0 : f, O = {};
    return 0 !== a && (O.enumerable = a), 0 !== u && (O.configurable = u), 0 !== b && (O.writable = b), 
    o(function(e) {
        Object.getOwnPropertyNames(e).forEach(function(o) {
            if (!(p.indexOf(o) >= 0 || i.hasOwnProperty(o))) {
                var n = Object.getOwnPropertyDescriptor(e, o);
                [ "get", "set", "value" ].forEach(function(e) {
                    if ("function" == typeof n[e]) {
                        var t = n[e];
                        n[e] = function() {
                            for (var e = [], o = 0; o < arguments.length; o++) e[o] = arguments[o];
                            return t.apply(r.hasOwnProperty("bindTo") ? r.bindTo : this, e);
                        };
                    }
                }), Object.defineProperty(i, o, t.__assign(t.__assign({}, n), O));
            }
        });
    }, e, r.till || Object, !1), i;
}, exports.isObject = n, exports.isPlainObject = function(e) {
    return "[object Object]" === Object.prototype.toString.call(e);
}, exports.objToURLStr = function(e, t, r) {
    void 0 === r && (r = !1);
    var o = "";
    for (var n in e) "function" != typeof e[n] && (o += n + "=" + (r ? encodeURIComponent(e[n]) : e[n]) + t);
    return o;
}, exports.URLStrToObj = function(e, t) {
    void 0 === t && (t = !1);
    var r = -1 !== e.indexOf("?") ? e.split("?")[1] : e, o = t ? decodeURIComponent(r) : r;
    return o = '{"' + o.replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}', 
    JSON.parse(o);
};