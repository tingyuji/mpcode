Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("./base");

function r(r, t) {
    if (r.length !== t.length) return !1;
    for (var n = 0; n < r.length; n++) if (!e.deepCompare(r[n], t[n])) return !1;
    return !0;
}

exports.default = function(e, t) {
    var n, i;
    void 0 === t && (t = r);
    var u = [], o = !1;
    function a() {
        for (var r = [], a = 0; a < arguments.length; a++) r[a] = arguments[a];
        return o && i === this && t(r, u) || (n = e.apply(this, r), i = this, u = r, o = !0), 
        n;
    }
    return {
        call: a,
        run: a,
        reset: function() {
            n = void 0, i = void 0, u = [], o = !1;
        }
    };
};