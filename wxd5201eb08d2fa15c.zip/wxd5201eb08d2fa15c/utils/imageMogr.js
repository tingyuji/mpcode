require("../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getPixelFitImage = exports.getFormat = void 0;

var e = require("tslib"), t = require("./base"), i = require("./rpx"), r = require("../core/globalData"), a = e.__importDefault(require("./memoize"));

function o(e, i) {
    if (!t.isString(e) || !e) return "";
    if (-1 !== e.indexOf("qlogo.cn") || 0 === e.indexOf("wxfile://") || 0 === e.indexOf("http://tmp/wx") || -1 !== e.indexOf("imageMogr2")) return e;
    if (0 === e.indexOf("http://") ? e = e.replace("http://", "https://") : 0 === e.indexOf("//") && (e = "https:" + e), 
    !i) return e;
    var r = i.width, a = i.height, o = i.format, s = void 0 === o ? exports.getFormat() : o, n = i.quality, l = void 0 === n ? 70 : n, u = i.strip, p = void 0 === u || u, g = i.crop, x = t.isNumber(r) && r > 0, d = t.isNumber(a) && a > 0, m = "", f = "";
    x && d ? f = r + "x" + a : x ? f = r + "x" : d && (f = "x" + a), f && (m += "/" + (g ? "crop" : "thumbnail") + "/" + f, 
    g && (m += "/gravity/center")), t.isNumber(l) && (m += "/quality/" + l), p && (m += "/strip");
    var c = t.getFileExt(e);
    return ".gif" === c ? m += "/cgif/1" : s && (m += "/format/".concat(s)), "jpg" !== s && (s || ".jpg" !== c && ".jpeg" !== c) || (m += "/interlace/1"), 
    m ? e + (e.includes("?") ? "&" : "?") + "imageMogr2" + m : e;
}

exports.getFormat = a.default(function() {
    var e = r.globalData.systemInfo, i = e.system, a = e.SDKVersion;
    return -1 !== t.compareVersion(a, "2.9.0") || /android/gi.test(i) ? "webp" : null;
}).call, exports.default = o, exports.getPixelFitImage = function(a, s) {
    var n = t.get(r.globalData, "systemInfo.pixelRatio", 3), l = s.width, u = s.height, p = e.__rest(s, [ "width", "height" ]);
    return o(a, e.__assign(e.__assign({}, p), {
        width: t.isNumber(l) ? Math.ceil(i.rpx2px(l) * n) : void 0,
        height: t.isNumber(u) ? Math.ceil(i.rpx2px(u) * n) : void 0
    }));
};