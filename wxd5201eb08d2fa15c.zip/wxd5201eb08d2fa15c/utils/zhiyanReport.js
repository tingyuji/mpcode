Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pvReport = exports.chatApiSuccessReport = exports.chatApiErrorReport = exports.chatApiReport = exports.commonReport = void 0;

var e = require("tslib"), r = require("../common/envConfig"), t = require("../services/session/index"), o = require("../services/session/libs/authLogin"), s = wx.getSystemInfoSync(), n = s.platform, i = s.SDKVersion, a = s.version, p = s.model, c = wx.getAccountInfoSync().miniProgram, u = c.version, _ = c.envVersion;

function d(s, n, i) {
    return function(a, p) {
        void 0 === p && (p = {}), function(s, n, i, a) {
            void 0 === s && (s = {}), void 0 === n && (n = {}), e.__awaiter(this, void 0, void 0, function() {
                var p, c, u, d, v, m, h, l, g, f;
                return e.__generator(this, function(x) {
                    switch (x.label) {
                      case 0:
                        return p = "fengye_brand", c = "5b203aceb079a90060e5b656ed6b7ea8", u = r.getEnvConfig(), 
                        d = u.api, "prod" !== u.env || "release" !== _ ? [ 2 ] : (v = "/api/fybrand/event/monitor", 
                        m = new Date().getTime(), [ 4, require.async("../subPackages/utils/js-md5/index.js") ]);

                      case 1:
                        return h = x.sent(), l = h(p + c + m.toString()), [ 4, o.authLogin.waitAuth() ];

                      case 2:
                        return x.sent(), g = t.session.getUserName(), f = {
                            scene: global.scene,
                            userId: g
                        }, wx.request({
                            url: "" + d.zhiyanReportHost + v,
                            method: "POST",
                            data: [ {
                                appMark: a,
                                latitudes: e.__assign(e.__assign({}, f), s),
                                indicators: n,
                                sec_lvl_en_name: i
                            } ],
                            header: {
                                "Content-Type": "application/json",
                                ts: m,
                                sign: l,
                                appID: p
                            },
                            success: function(e) {
                                console.log("reqSuccess", e);
                            }
                        }), [ 2 ];
                    }
                });
            });
        }(e.__assign(e.__assign({}, i || {}), a), p, s, n);
    };
}

exports.commonReport = d("hunyuan_weapp_common_report", "9860_76413_chatai-vue", {
    wxVersion: a,
    SDKVersion: i,
    platform: n,
    mpVersion: u,
    deviceModel: p,
    source: 0
}), exports.chatApiReport = d("hunyuan_weapp_interface_chat", "9860_76413_chatai-vue", {
    wxVersion: a,
    SDKVersion: i,
    platform: n,
    mpVersion: u,
    deviceModel: p
});

exports.chatApiErrorReport = function(e) {
    return exports.chatApiReport(e, {
        chat_api_fail: 1
    });
};

exports.chatApiSuccessReport = function(r) {
    return exports.chatApiReport(e.__assign({}, r), {
        chat_api_success: 1
    });
};

exports.pvReport = function(r) {
    return exports.commonReport(e.__assign({}, r), {
        weapp_pv: 1
    });
};