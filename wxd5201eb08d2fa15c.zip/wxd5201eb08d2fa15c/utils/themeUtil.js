Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.updateAppTheme = exports.updateNavBarStyleByTheme = exports.getAppTheme = void 0;

var e = require("tslib"), t = require("../config/index"), o = e.__importStar(require("../store/index"));

exports.getAppTheme = function() {
    return "light";
};

exports.updateNavBarStyleByTheme = function(e) {
    wx.setNavigationBarColor({
        backgroundColor: "light" === e ? t.PAGE_BG_LIGHT : t.PAGE_BG_DARK,
        frontColor: "light" === e ? "#000000" : "#ffffff"
    });
};

exports.updateAppTheme = function(e) {
    var r = e.theme, a = e.forGlobal, i = void 0 !== a && a, p = e.saveStorage, n = void 0 !== p && p, l = e.animation;
    exports.updateNavBarStyleByTheme(r || "light"), (i || null != l) && o.default.dispatch(o.globalSlice.actions.updateThemeConfig({
        name: r,
        animation: l
    })), n && wx.setStorageSync(t.APP_THEME, r);
};