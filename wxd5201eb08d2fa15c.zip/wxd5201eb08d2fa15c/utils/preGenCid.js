Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCids = void 0;

var e = require("tslib"), t = require("../common/http-client/index"), n = [];

function r(e) {
    return void 0 === e && (e = 1), t.apis.conv.generate({
        count: e
    }).then(function(e) {
        console.log("%c conv.generate: %o", "color: #0000ff", e);
        var t = e.split(",");
        n.push.apply(n, t);
    });
}

r(), exports.getCids = function(t) {
    return void 0 === t && (t = 1), e.__awaiter(this, void 0, void 0, function() {
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return n.length >= t ? (r(), [ 2, n.splice(0, t) ]) : [ 4, r(t - n.length) ];

              case 1:
                return e.sent(), r(), [ 2, n.splice(0, t) ];
            }
        });
    });
};