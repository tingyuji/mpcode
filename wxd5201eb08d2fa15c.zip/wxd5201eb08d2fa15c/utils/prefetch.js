Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getPluginIdInfoMap = exports.memoizedGetConfig = exports.getAllConfig = void 0;

var e = require("tslib"), o = require("../common/http-client/index"), n = e.__importDefault(require("../common/storage")), t = require("../config/constants"), a = e.__importDefault(require("./downloadUserAvatar")), r = e.__importDefault(require("./memoize"));

a.default();

var s;

function u() {
    return e.__awaiter(this, void 0, void 0, function() {
        var a, r, s;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return e.trys.push([ 0, 2, , 4 ]), [ 4, o.apis.config.general() ];

              case 1:
                return a = e.sent(), console.log("%cget all config success", "color: #00ff00", a), 
                n.default.setSync(t.ALL_CONFIG_OLD, a), [ 2, a ];

              case 2:
                return r = e.sent(), console.error("get all config error", r), (s = n.default.getSync(t.ALL_CONFIG_OLD)) ? [ 2, s ] : [ 4, o.apis.config.general() ];

              case 3:
                return [ 2, e.sent() ];

              case 4:
                return [ 2 ];
            }
        });
    });
}

s = [ "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo/animation/logo-loading.gif", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/share/share-bg.png", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/share/share-bg2.png", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo/animation/logo-fail.gif", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/hunyuan-logo-border.png?imageMogr2/thumbnail/72x72", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo-s2.png", "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/gpt-logo.png" ], 
console.log("%c=====预加载的图片资源", "color: #ff0000", s), s.forEach(function(e) {
    e && wx.preloadAssets && wx.preloadAssets({
        data: [ {
            type: "image",
            src: e
        } ],
        success: function(o) {
            console.log("%c" + e + "成功", "color: #00ff00", o);
        },
        fail: function(o) {
            console.error(e + "失败", o);
        }
    });
}), exports.getAllConfig = u, exports.memoizedGetConfig = r.default(u), exports.memoizedGetConfig.call(), 
exports.getPluginIdInfoMap = function() {
    return e.__awaiter(this, void 0, void 0, function() {
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return [ 4, exports.memoizedGetConfig.call() ];

              case 1:
                return [ 2, e.sent().plugins.reduce(function(e, o) {
                    return e[o.id] = o, e;
                }, {}) ];
            }
        });
    });
}, wx.loadFontFace({
    family: "tencent",
    source: 'url("https://cdn-we-retail.ym.tencent.com/fy/landingPage/ai/tencent.woff")'
});