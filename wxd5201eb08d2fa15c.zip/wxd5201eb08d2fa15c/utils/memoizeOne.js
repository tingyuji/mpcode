Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("./base");

exports.default = function(e, s) {
    void 0 === s && (s = {});
    var r = s.isEqual, i = void 0 === r ? t.deepCompare : r, l = s.cachePromiseRejection, a = void 0 === l || l, n = null;
    function u() {
        for (var s = [], r = 0; r < arguments.length; r++) s[r] = arguments[r];
        if (n && n.lastThis === this && i(s, n.lastArgs)) return n.lastResult;
        var l = e.apply(this, s);
        return !a && t.isFunction(l.catch) && l.catch(function() {
            n = null;
        }), n = {
            lastResult: l,
            lastArgs: s,
            lastThis: this
        }, l;
    }
    return u.clear = function() {
        n = null;
    }, u;
};