Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.hexToRGB = exports.hexToRGBObject = void 0;

var e = function(e) {
    e = e.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(e, r, t, o) {
        return console.log(e), r + r + t + t + o + o;
    });
    var r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
    return r ? {
        r: parseInt(r[1], 16),
        g: parseInt(r[2], 16),
        b: parseInt(r[3], 16)
    } : null;
};

exports.hexToRGBObject = e, exports.hexToRGB = function(r) {
    var t = e(r);
    return null === t ? "rgba(255, 255, 255)" : "rgba(" + +t.r + "," + +t.g + "," + +t.b + ")";
};