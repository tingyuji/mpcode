Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.guidMaker = void 0;

var r = require("tslib");

function e() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(r) {
        var e = 16 * Math.random() | 0;
        return ("x" == r ? e : 3 & e | 8).toString(16);
    });
}

exports.default = e;

var t = function() {
    function t() {
        this.gid = "";
    }
    return t.prototype.produce = function() {
        var r = e();
        return this.resolver ? (this.resolver(r), this.gid = "", this.resolver = null) : this.gid = r, 
        r;
    }, t.prototype.consume = function() {
        return r.__awaiter(this, void 0, void 0, function() {
            var e = this;
            return r.__generator(this, function(r) {
                return [ 2, new Promise(function(r) {
                    e.gid ? (r(e.gid), e.gid = "") : e.resolver = r;
                }) ];
            });
        });
    }, t;
}();

exports.guidMaker = new t();