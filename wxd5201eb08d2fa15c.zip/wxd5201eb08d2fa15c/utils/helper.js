var e = require("../@babel/runtime/helpers/typeof");

require("../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.judgeIsPcEnv = exports.chunkArray = exports.isSharePage = exports.decryptVoiceKey = exports.URLStrToObj = exports.judgeShowWorkwxTips = exports.throttleByStreamLength = exports.isAbnormalStreamText = exports.CHAT_NO_FEED_BACK_MSGS = exports.getInspirationById = exports.getReportMsg = exports.getCurrentPagePath = exports.getCurrentPage = exports.judgeLoginAuth = exports.relaunchAuthBanned = exports.relaunchNoAuth = exports.relaunch = exports.getRequestBaseUrl = exports.throttle = exports.isIOS = exports.handleChatListTransform = exports.fixPossiblePluginDescsError = exports.transformMsgForShare = exports.transformSpeechForShare = exports.formatHistoryMsg = exports.formatProgress = exports.getInitialActiveQA = exports.getPromptText = exports.handleStreamData = exports.arrayBufferToString = exports.setConfig = exports.config = exports.getNavBarInfo = exports.isIphoneProMax = void 0;

var t = require("tslib"), r = require("../common/envConfig"), o = require("../common/http-client/index"), n = t.__importDefault(require("../components/notify/notify")), s = require("../config/constants"), i = require("../interface/type"), a = require("../services/session/index"), p = require("../services/session/libs/authLogin"), g = require("./base"), u = require("./prefetch"), l = t.__importDefault(require("../lib/tam")), c = "";

exports.isIphoneProMax = function() {
    var e = wx.getSystemInfoSync(), t = e.system, r = e.model;
    return -1 !== (null == t ? void 0 : t.toLowerCase().indexOf("ios")) && -1 !== r.toLowerCase().indexOf("pro max");
};

exports.getNavBarInfo = function() {
    var e = wx.getSystemInfoSync(), t = e.statusBarHeight, r = e.system, o = e.platform, n = e.windowWidth, s = e.windowHeight, i = e.screenHeight, a = -1 !== (null == r ? void 0 : r.toLowerCase().indexOf("ios")), p = null, g = 0, u = function() {
        var t, r = i - s - 20;
        return r > 10 && r < 80 ? r : r = (null === (t = e.model) || void 0 === t ? void 0 : t.includes("iPhone X")) ? 44 : a ? 20 : 24;
    };
    try {
        if (!((null == (p = wx.getMenuButtonBoundingClientRect ? wx.getMenuButtonBoundingClientRect() : null) ? void 0 : p.width) && p.top && p.left && p.height)) throw new Error("no menu button rect");
    } catch (e) {
        var l = 96;
        "android" === o ? (g = 8, l = 96) : "devtools" === o ? g = a ? 5.5 : 7.5 : (g = 4, 
        l = 88);
        var c = t || u();
        p = {
            width: l,
            height: 32,
            top: c + g,
            bottom: c + g + 32,
            left: n - l - 10,
            right: n - 10
        };
    }
    var f = 0;
    return t ? f = t + 2 * (g = p.top - t) + p.height : (t = u(), f = 2 * (g = a ? 4 : 8) + p.height, 
    p.top > 20 && (p.top = 4)), {
        isIos: a,
        gap: g,
        navBarHeight: a ? f + 4 : f,
        menuButtonRect: p,
        windowWidth: n,
        statusBarHeight: t
    };
}, exports.config = {
    homePath: "/pages/home/index",
    forbidPath: "/pages/forbid/index",
    personal: "/pages/personal/index"
};

exports.setConfig = function(e) {
    Object.assign(exports.config, e);
}, exports.arrayBufferToString = function(e) {
    if ("string" == typeof e) return e;
    for (var t = new DataView((null == e ? void 0 : e.buffer) ? e.buffer : e), r = new Uint8Array(e.byteLength), o = 0; o < r.length; o++) r[o] = t.getUint8(o);
    var n = "", s = r;
    for (o = 0; o < s.length; o++) {
        var i = s[o].toString(2), a = i.match(/^1+?(?=0)/);
        if (a && 8 == i.length) {
            for (var p = a[0].length, g = s[o].toString(2).slice(7 - p), u = 1; u < p; u++) g += s[u + o].toString(2).slice(2);
            n += String.fromCharCode(parseInt(g, 2)), o += p - 1;
        } else n += String.fromCharCode(s[o]);
    }
    return n;
};

var f = [ {
    tag: "[ENTRY]",
    msg: "换行",
    replacement: "\n"
} ];

function h(e) {
    var t, r, o = e.speechType;
    o === i.StreamSpeechType.imageWithText ? (r = s.getOriginImageText()).images.map(function(e) {
        return e.failed = !0;
    }) : o === i.StreamSpeechType.goodsWithText ? (r = s.getOriginGoodsText()).goodsGroup = [] : (o === i.StreamSpeechType.text || o === i.StreamSpeechType.pdf || o === i.StreamSpeechType.cutoff) && (r = {
        type: i.MsgType.text,
        msg: "",
        textMsgErrorType: i.TextMsgErrorType.normal
    });
    var n = -1, a = -1;
    return null === (t = e.content) || void 0 === t || t.forEach(function(e) {
        var t;
        if (e.type === i.MsgType.image) e.idx ? n = e.idx : n += 1, e.imageUrlLow && (r.images[n] = {
            imageUrl: e.imageUrlLow,
            highDefImageUrl: e.imageUrlHigh,
            progress: 100,
            failed: !1
        }); else if (e.type === i.MsgType.goods) {
            var s = e || {}, p = s.imageUrl, g = s.title, u = s.goodsId, l = s.traceId, c = s.currentPrice, f = s.miniprogramAppId, h = s.miniprogramUrl, d = s.idx, x = s.total;
            d ? a = d : a += 1, f && h && (r.goods || (r.goods = [], r.goodsGroup = []), r.goods[a] = {
                imageUrl: p,
                title: g,
                price: c,
                appid: f,
                path: h,
                total: x,
                goodsId: u,
                traceId: l
            });
        } else e.type === i.MsgType.text && (o === i.StreamSpeechType.imageWithText ? e.msg && (r.text += e.msg || "") : o === i.StreamSpeechType.goodsWithText ? (null === (t = r.goods) || void 0 === t ? void 0 : t.length) > 0 ? (r.text || (r.text = ""), 
        r.text += e.msg || "") : (r.preText || (r.preText = ""), r.preText += e.msg || "") : (o === i.StreamSpeechType.text || o === i.StreamSpeechType.pdf || o === i.StreamSpeechType.cutoff) && (e.msg && (r.msg += e.msg || ""), 
        e.msgType === i.TextMsgErrorType.error && (r.textMsgErrorType = i.TextMsgErrorType.error)));
    }), (null == r ? void 0 : r.goods) && (r.goods = r.goods.filter(function(e) {
        return e.appid && e.path;
    }), r.goodsGroup = exports.chunkArray(r.goods)), r;
}

function d(t) {
    if ("string" == typeof t) return {
        speechType: i.StreamSpeechType.text,
        content: [ {
            type: i.MsgType.text,
            msg: t
        } ]
    };
    if ("object" === e(t)) {
        if (t.type === i.MsgType.text) return {
            speechType: i.StreamSpeechType.text,
            content: [ t ]
        };
        if (t.type === i.MsgType.image) {
            var r = {
                speechType: i.StreamSpeechType.imageWithText,
                content: []
            };
            return t.images.map(function(e, t) {
                r.content.push({
                    type: i.MsgType.image,
                    imageUrlLow: e.imageUrl,
                    imageUrlHigh: e.highDefImageUrl,
                    idx: t
                });
            }), t.text && r.content.push({
                type: i.MsgType.text,
                msg: t.text
            }), r;
        }
        if (t.type === i.MsgType.goods) {
            var o = {
                speechType: i.StreamSpeechType.goodsWithText,
                content: []
            };
            return t.preText && o.content.push({
                type: i.MsgType.text,
                msg: t.preText
            }), t.goods.map(function(e, t) {
                o.content.push({
                    type: i.MsgType.goods,
                    imageUrl: e.imageUrl,
                    miniprogramAppId: e.appid,
                    miniprogramUrl: e.path,
                    currentPrice: e.price,
                    title: e.title,
                    idx: t,
                    total: e.total,
                    goodsId: e.goodsId,
                    traceId: e.traceId
                });
            }), t.text && o.content.push({
                type: i.MsgType.text,
                msg: t.text
            }), o;
        }
    }
    return console.error("transformMsgForShare error: unknown msg type: " + t), t;
}

function x(e) {
    var t, r, o, n, s, i = null === (t = null == e ? void 0 : e.pluginContext) || void 0 === t ? void 0 : t.pluginDescs;
    return i ? i.length < ((null === (o = e.speeches) || void 0 === o ? void 0 : o.length) || 0) && (i = new Array(((null === (n = e.speeches) || void 0 === n ? void 0 : n.length) || 0) - i.length).fill("").concat(i)) : i = new Array((null === (r = e.speeches) || void 0 === r ? void 0 : r.length) || 0).fill(""), 
    e.pluginContext = {
        pluginDescs: i,
        pluginIds: null === (s = e.pluginContext) || void 0 === s ? void 0 : s.pluginIds
    }, e;
}

exports.handleStreamData = function(e) {
    var t = void 0, r = s.CONV_STREAM_TYPE.ADD, o = e, n = "", a = [];
    if (-1 === e.indexOf("data: ") && -1 === e.indexOf("event: ")) {
        console.error("注意：会话返回格式未知，未处理返回"), r = s.CONV_STREAM_TYPE.ERROR;
        a.push({
            type: i.MsgType.text,
            msg: "未知消息返回格式未知"
        });
    } else if (-1 !== o.indexOf("event: speech_type\n") && (o = o.replace(s.SPEECH_TYPE_REG, function(e, r) {
        return console.log("%cmatch speech type:", "color: #0000ff", e, r), t = r, "";
    })), -1 !== o.indexOf(s.REVOKE_EVENT_CONST) && (t = i.StreamSpeechType.revoke, o = o.replace(s.REVOKE_EVENT_CONST, "")), 
    -1 !== o.indexOf(s.CUTOFF_EVENT_CONST) && (t = i.StreamSpeechType.cutoff, o = o.replace(s.CUTOFF_EVENT_CONST, "")), 
    -1 !== o.indexOf(s.ERROR_EVENT_CONST) && (o = o.replace(s.ERROR_REG, function(e, t) {
        console.log("%cmatch error:", "color: #ff0000", e, t);
        try {
            f.map(function(e) {
                -1 !== t.indexOf(e.tag) && (t = t.replaceAll(e.tag, e.replacement));
            }), a.push({
                type: i.MsgType.text,
                msg: t
            }), r = s.CONV_STREAM_TYPE.ERROR;
        } catch (e) {
            console.error("%craw msg parse error", e);
        }
        return "";
    })), -1 !== o.indexOf("data:") && (o = (o = o.replace(s.PLUGIN_REG, function(e, t) {
        return n = t || "", "";
    })).replace(s.DATA_REG, function(e, t) {
        if (-1 !== [ s.CONV_STREAM_REPLACE.DONE, s.CONV_STREAM_REPLACE.SENSITIVE_DONE ].indexOf(t)) r = s.CONV_STREAM_TYPE_MAP[t]; else if (f.map(function(e) {
            -1 !== t.indexOf(e.tag) && (t = t.replaceAll(e.tag, e.replacement));
        }), 0 === t.indexOf("{")) try {
            a.push(JSON.parse(t));
        } catch (e) {
            a.push({
                type: i.MsgType.text,
                msg: t
            }), console.error("parse msg json error:", e, t);
        } else a.push({
            type: i.MsgType.text,
            msg: t
        });
        return "";
    })), o) {
        var p = '传入消息不是"data: text \r\n" 结构。不合规的text如下：' + o;
        console.error(p), l.default.report({
            event: "errorParseMsg:FormatError",
            errMsg: p
        });
    }
    return {
        type: r,
        data: a,
        msgTypeDeclaration: t,
        matchedPluginInfo: n
    };
}, exports.getPromptText = function(e) {
    for (var t = 0; t < s.FUNCTIONAL_PROMPT_PREFIX.length; t++) if (0 === e.indexOf(s.FUNCTIONAL_PROMPT_PREFIX[t])) return e.substring(1);
    return e;
}, exports.getInitialActiveQA = function() {
    return {
        question: "",
        answer: "",
        status: s.CONV_STREAM_TYPE.ADD,
        matchedPluginInfo: "",
        textMsgErrorType: i.TextMsgErrorType.normal
    };
}, exports.formatProgress = function(e) {
    return e < 1 ? Math.round(100 * e) : e;
}, exports.formatHistoryMsg = h, exports.transformSpeechForShare = d, exports.transformMsgForShare = function(e) {
    if (!e.speeches) return e;
    var r = t.__assign({}, e);
    return r.speechesV2 = r.speeches.map(function(e) {
        return d(e);
    }), delete r.speeches, r;
}, exports.fixPossiblePluginDescsError = x, exports.handleChatListTransform = function(e) {
    e.map(function(t, r) {
        r % 2 == 1 && (t.question = e[r - 1].speech);
    });
    var r = !1;
    return e.reverse().map(function(e) {
        var o, n, s, a = i.TextMsgErrorType.normal;
        e.speechesV2 && (e.speeches = e.speechesV2.map(function(e) {
            return h(e);
        }), delete e.speechesV2), (null === (o = e.speeches) || void 0 === o ? void 0 : o.length) && (null === (n = e.speeches[e.speeches.length - 1]) || void 0 === n ? void 0 : n.textMsgErrorType) === i.TextMsgErrorType.error && (a = i.TextMsgErrorType.error);
        var p = !1;
        return !r && e.isSkipHistory && "ai" === e.speaker && (p = !0, r = !0), t.__assign(t.__assign({}, x(e)), {
            isLastSkipHistory: p,
            textMsgErrorType: a,
            key: e.speaker + (null === (s = e.createTime) || void 0 === s ? void 0 : s.toString()),
            forbidLogoAnimate: !0
        });
    });
};

var m = wx.getSystemInfoSync() || {};

function T(e, t) {
    void 0 === e && (e = "/pages/home/index"), void 0 === t && (t = {});
    var r = g.obj2Params(t), o = "" + e + (-1 === e.indexOf("?") && r ? "?" + r : r), n = S(), s = n.route, i = n.options;
    "/" + s + (g.obj2Params(i) ? "?" + g.obj2Params(i) : "") !== o && (c !== o ? (c = o, 
    wx.reLaunch({
        url: o
    })) : setTimeout(function() {
        c = "";
    }, 200));
}

function y() {
    T("/pages/noAuth/index?" + (global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser ? "userType=outerUser" : "userType=innerUser"));
}

function v() {
    T("/pages/forbid/index?" + (global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser ? "userType=outerUser" : "userType=innerUser"));
}

function S() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

function _() {
    var e = S();
    return null == e ? void 0 : e.route;
}

exports.isIOS = "ios" === m.platform, exports.throttle = function(e, t) {
    var r = !1, o = null;
    function n() {
        null == o ? r = !1 : (e.apply(void 0, o), o = null, setTimeout(n, t));
    }
    return function() {
        for (var s = [], i = 0; i < arguments.length; i++) s[i] = arguments[i];
        r ? o = s : (e.apply(this, s), r = !0, setTimeout(n, t));
    };
}, global[s.CURRENT_LOGIN_TYPE] = wx.getStorageSync(s.CURRENT_LOGIN_TYPE), exports.getRequestBaseUrl = function() {
    var e = r.getEnvConfig().api || {}, t = e.host, o = void 0 === t ? "" : t, n = e.prefix, i = void 0 === n ? "" : n, a = e.outerHost;
    return "" + (global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser ? a : o) + i;
}, exports.relaunch = T, exports.relaunchNoAuth = y, exports.relaunchAuthBanned = v, 
exports.judgeLoginAuth = function() {
    return t.__awaiter(this, void 0, void 0, function() {
        var e, r;
        return t.__generator(this, function(t) {
            switch (t.label) {
              case 0:
                return (e = a.session.hasAuth()) ? [ 3, 2 ] : [ 4, p.authLogin.refreshLogin() ];

              case 1:
                t.sent(), e = a.session.hasAuth(), t.label = 2;

              case 2:
                if (!e) {
                    if (global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser && a.session.getUserAuthStatus() === s.AUTH_STATUS.authBaned) return v(), 
                    [ 2 ];
                    (null == (r = getCurrentPages()) ? void 0 : r.length) && -1 === s.AUTH_FREE_PATHS.indexOf(r[0].route) && y();
                }
                return [ 2 ];
            }
        });
    });
}, exports.getCurrentPage = S, exports.getCurrentPagePath = _, exports.getReportMsg = function(t) {
    if ("string" == typeof t) return t;
    if ("object" === e(t)) try {
        if ("image" === t.type) {
            var r = t.images.map(function(e, t) {
                return {
                    name: "图片" + (t + 1),
                    url: e.failed ? "生成失败或取消" : e.highDefImageUrl
                };
            });
            return JSON.stringify(r);
        }
        return JSON.stringify(t);
    } catch (e) {
        console.error("getReportMsg error:", e);
    }
    return "";
}, exports.getInspirationById = function(e) {
    return t.__awaiter(this, void 0, void 0, function() {
        var r, n, s;
        return t.__generator(this, function(i) {
            switch (i.label) {
              case 0:
                return [ 4, u.memoizedGetConfig.call() ];

              case 1:
                return r = i.sent().inspirations || [], (null == (n = r.filter(function(t) {
                    var r;
                    return (null === (r = t.template) || void 0 === r ? void 0 : r.id) === e;
                })[0]) ? void 0 : n.template) && (delete (s = t.__assign({}, n)).template, n = t.__assign(t.__assign({}, n.template), s)), 
                n ? [ 3, 3 ] : [ 4, o.apis.conv.getInspirationDetail({
                    id: e
                }) ];

              case 2:
                n = i.sent(), i.label = 3;

              case 3:
                return [ 2, n ];
            }
        });
    });
}, exports.CHAT_NO_FEED_BACK_MSGS = [ "很抱歉，我还未学习到这个问题的内容，无法提供相关信息。", "很抱歉，由于访问量过大，建议您稍后或闲时再试，感谢您的理解与支持。", "抱歉，当前访问人数过多，服务繁忙，请稍后再试。", "请求超时，请重试", "网络异常，请重试", "抱歉，生成失败，请重新生成", "未知消息返回格式未知", "服务器错误", "已暂停生成。", "抱歉, 生成失败, 请重新生成画作。" ], 
exports.isAbnormalStreamText = function(e) {
    return -1 !== exports.CHAT_NO_FEED_BACK_MSGS.indexOf(e);
}, exports.throttleByStreamLength = function(e, t, r, o, n, s) {
    var i, a = Date.now(), p = a;
    return function() {
        for (var g = this, u = [], l = 0; l < arguments.length; l++) u[l] = arguments[l];
        clearTimeout(i);
        var c = Date.now(), f = u[1], h = 0;
        "string" == typeof f && (h = f.length);
        var d = c - a, x = c - p, m = Math.min(1e3, Math.max(Math.floor(h / r) * n, Math.pow(Math.floor((x - 5e3) / o), 1.5) * s));
        d >= t + m ? (a = c, e.apply(this, u)) : i = setTimeout(function() {
            e.apply(g, u);
        }, t + m);
    };
}, exports.judgeShowWorkwxTips = function() {
    if ("wxwork" === wx.getSystemInfoSync().environment) {
        if (global.HAD_SHOW_WORKWX_TIPS) return;
        global.HAD_SHOW_WORKWX_TIPS = !0, n.default.warning({
            message: "为提供更好的服务和体验，请前往手机微信打开",
            duration: 5e3
        });
    }
}, exports.URLStrToObj = function(e, t) {
    void 0 === t && (t = !1);
    var r = -1 !== e.indexOf("?") ? e.split("?")[1] : e, o = t ? decodeURIComponent(r) : r;
    o = '{"' + o.replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}';
    try {
        return JSON.parse(o);
    } catch (e) {
        return {};
    }
}, exports.decryptVoiceKey = function(e) {
    var t = decodeURIComponent(e), r = "";
    t = t.split("").reverse().join("");
    for (var o = 0; o < t.length; o++) {
        var n = t.charCodeAt(o);
        n -= 12, r += String.fromCharCode(n);
    }
    return r;
}, exports.isSharePage = function() {
    return "pages/share-chat/index" === _();
};

exports.chunkArray = function(e, t) {
    if (void 0 === t && (t = 3), Array.isArray(e)) return e.reduce(function(e, r, o) {
        var n = Math.floor(o / t);
        return e[n] || (e[n] = []), e[n].push(r), e;
    }, []);
}, exports.judgeIsPcEnv = function() {
    var e = m.platform;
    return "windows" === e || "mac" === e;
};