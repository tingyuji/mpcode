var t = require("../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getRect = exports.formatColor = exports.RGBAToHexA = exports.omitBy = exports.isNull = exports.getFileExt = exports.isDef = exports.tryParseArr = exports.isPositiveInteger = exports.isPositiveNum = exports.priceFormat = exports.percentToDiscount = exports.fenToYuan = exports.highlightWord = exports.get = exports.isNumber = exports.isUndefined = exports.isFunction = exports.isEmpty = exports.pick = exports.isString = exports.isArray = exports.deepCompare = exports.compareVersion = exports.countDown = exports.getSDKVersion = exports.getCurrentPage = exports.getCurrentRoute = exports.getPageInstance = exports.throttle = exports.debounce = exports.obj2Params = exports.isNaN = void 0;

var r = require("./object"), e = Object.prototype.toString;

exports.isNaN = function(t) {
    return t != t;
};

exports.obj2Params = function(t, r) {
    void 0 === t && (t = {}), void 0 === r && (r = !1);
    var e = [];
    return Object.keys(t).forEach(function(n) {
        return e.push(n + "=" + (r ? encodeURIComponent(decodeURIComponent(t[n])) : t[n]));
    }), e.join("&");
};

exports.debounce = function(t, r) {
    var e;
    return function() {
        for (var n = this, o = [], i = 0; i < arguments.length; i++) o[i] = arguments[i];
        e && clearTimeout(e), e = setTimeout(function() {
            return t.apply(n, o);
        }, r);
    };
}, exports.throttle = function(t, r, e) {
    var n, o = +new Date();
    return function() {
        for (var i = this, s = [], u = 0; u < arguments.length; u++) s[u] = arguments[u];
        var p = +new Date();
        n && clearTimeout(n), p - o >= (e || r) ? (t.apply(this, s), o = p) : n = setTimeout(function() {
            t.apply(i, s);
        }, r);
    };
}, exports.getPageInstance = function(t) {
    var r, e = getCurrentPages(), n = t.route ? t : null;
    if (!n) {
        try {
            r = parseInt(t.getPageId().slice(7));
        } catch (e) {
            r = t ? t.__wxWebviewId__ : "";
        }
        e && (n = e.find(function(t) {
            return !!t && t.__wxWebviewId__ === r;
        }));
    }
    return n;
}, exports.getCurrentRoute = function() {
    var t = getCurrentPages(), r = t.length;
    return r >= 1 && t[r - 1] ? t[r - 1].__route__ : "";
}, exports.getCurrentPage = function() {
    var t = getCurrentPages();
    return t[t.length - 1] || null;
};

exports.getSDKVersion = function(t) {
    var r;
    void 0 === t && (t = wx);
    try {
        var e = t.getSystemInfoSync();
        r = e ? e.SDKVersion : null;
    } catch (t) {
        console.error(t);
    }
    return r;
};

exports.countDown = function(t, r, e) {
    console.log(t, r, e);
};

exports.compareVersion = function(t, r) {
    for (var e = t.split("."), n = r.split("."), o = Math.max(e.length, n.length); e.length < o; ) e.push("0");
    for (;n.length < o; ) n.push("0");
    for (var i = 0; i < o; i++) {
        var s = parseInt(e[i]), u = parseInt(n[i]);
        if (s > u) return 1;
        if (s < u) return -1;
    }
    return 0;
}, exports.deepCompare = function() {
    for (var r, e, n, o, i = [], s = 0; s < arguments.length; s++) i[s] = arguments[s];
    function u(r, e) {
        var i;
        if (exports.isNaN(r) && exports.isNaN(e) && "number" == typeof r && "number" == typeof e) return !0;
        if (r === e) return !0;
        if ("function" == typeof r && "function" == typeof e || r instanceof Date && e instanceof Date || r instanceof RegExp && e instanceof RegExp || r instanceof String && e instanceof String || r instanceof Number && e instanceof Number) return r.toString() === e.toString();
        if (!(r instanceof Object && e instanceof Object)) return !1;
        if (r.isPrototypeOf(e) || e.isPrototypeOf(r)) return !1;
        if (r.constructor !== e.constructor) return !1;
        if (r.prototype !== e.prototype) return !1;
        if (n.indexOf(r) > -1 || o.indexOf(e) > -1) return !1;
        for (i in e) {
            if (e.hasOwnProperty(i) !== r.hasOwnProperty(i)) return !1;
            if (t(e[i]) !== t(r[i])) return !1;
        }
        for (i in r) {
            if (e.hasOwnProperty(i) !== r.hasOwnProperty(i)) return !1;
            if (t(e[i]) !== t(r[i])) return !1;
            switch (t(r[i])) {
              case "object":
              case "function":
                if (n.push(r), o.push(e), !u(r[i], e[i])) return !1;
                n.pop(), o.pop();
                break;

              default:
                if (r[i] !== e[i]) return !1;
            }
        }
        return !0;
    }
    if (arguments.length < 1) return !0;
    for (r = 1, e = arguments.length; r < e; r++) if (n = [], o = [], !u(arguments[0], arguments[r])) return !1;
    return !0;
};

exports.isArray = function(t) {
    return Array.isArray && Array.isArray(t) || "[object Array]" == {}.toString.call(t);
};

exports.isString = function(t) {
    return "[object String]" === Object.prototype.toString.call(t);
};

exports.pick = function(t) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    if (!r.isObject(t) && "function" != typeof t) return {};
    var o = {};
    if (exports.isString(e)) return e in t && (o[e] = t[e]), o;
    for (var i = e.length, s = -1; ++s < i; ) {
        var u = e[s];
        exports.isArray(u) ? u.forEach(function(r) {
            r in t && (o[r] = t[r]);
        }) : u in t && (o[u] = t[u]);
    }
    return o;
};

exports.isEmpty = function(t) {
    if (!t) return !0;
    if (exports.isArray(t) || exports.isString(t) || "function" == typeof t.splice) return !t.length;
    for (var r in t) if (Object.hasOwnProperty.call(t, r)) return !1;
    return !0;
};

exports.isFunction = function(t) {
    return "function" == typeof t;
};

exports.isUndefined = function(t) {
    return void 0 === t;
};

exports.isNumber = function(t) {
    return "number" == typeof t && !exports.isNaN(t);
};

exports.get = function(t, r, e) {
    "string" == typeof r && (r = r.replace(/\[/g, ".").replace(/\]/g, "").split(".").filter(Boolean));
    for (var n = r.length, o = 0; null != t && o < n; ) t = t[r[o++]];
    return void 0 === t || 0 === o ? e : t;
}, exports.highlightWord = function t(r, e) {
    var n = e.indexOf(r), o = [];
    return n >= 1 ? ((o = t(r, e.substr(n))).unshift({
        str: e.substring(0, n)
    }), o) : 0 === n ? ((o = t(r, e.substr(r.length))).unshift({
        key: !0,
        str: r
    }), o) : [ {
        str: e
    } ];
}, exports.fenToYuan = function(t) {
    return ((parseInt(t) || 0) / 100).toString();
}, exports.percentToDiscount = function(t) {
    return ((parseInt(t, 10) || 0) / 10).toString();
}, exports.priceFormat = function(t, r) {
    if (void 0 === r && (r = 0), exports.isNaN(t) || null === t || t === 1 / 0) return t;
    if (t = Math.round(parseFloat(t + "") * Math.pow(10, 8)) / Math.pow(10, 8), t = Math.ceil(t) / 100 + "", 
    r > 0) {
        -1 == t.indexOf(".") && (t += ".");
        for (var e = r - t.split(".")[1].length, n = 0; n < e; n++) t += "0";
    }
    return t;
};

exports.isPositiveNum = function(t) {
    return exports.isNumber(t) && t > 0;
};

exports.isPositiveInteger = function(t) {
    return exports.isPositiveNum(t) && t % 1 == 0;
};

function n(t, r, e, n) {
    return t = t.toString(16), r = r.toString(16), e = e.toString(16), n = Math.round(255 * n).toString(16), 
    1 == t.length && (t = "0" + t), 1 == r.length && (r = "0" + r), 1 == e.length && (e = "0" + e), 
    1 == n.length && (n = "0" + n), "#" + t + r + e + n;
}

exports.tryParseArr = function(t) {
    try {
        return JSON.parse(t);
    } catch (t) {
        return [];
    }
}, exports.isDef = function(t) {
    return null != t;
}, exports.getFileExt = function(t) {
    if (!exports.isString(t)) return "";
    var r = (/\.[^\.]+$/.exec(t) || [])[0];
    return void 0 === r ? "" : r;
}, exports.isNull = function(t) {
    return "[object Null]" === e.call(t);
}, exports.omitBy = function(t, r) {
    var e = {};
    return Object.keys(t).forEach(function(n) {
        var o = t[n];
        r(o, n) || (e[n] = o);
    }), e;
}, exports.RGBAToHexA = n, exports.formatColor = function(r) {
    var e = "";
    if ("string" == typeof e && (e = r), "object" === t(e)) if (r.rgb) {
        var o = r.rgb;
        e = n(o.r, o.g, o.b, o.a || 1);
    } else e = r.hex ? r.hex : n(r.r, r.g, r.b, r.a || 1);
    return e;
};

exports.getRect = function(t, r, e) {
    return void 0 === e && (e = !1), new Promise(function(n, o) {
        wx.createSelectorQuery().in(t)[e ? "selectAll" : "select"](r).boundingClientRect(function(t) {
            t ? n(t) : o(t);
        }).exec();
    });
};