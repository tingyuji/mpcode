Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e, t) {
    var r = global[t];
    return r || (r = e(), global[t] = r), r;
};