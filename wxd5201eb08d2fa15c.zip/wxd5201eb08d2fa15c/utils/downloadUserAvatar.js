Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../common/http-client/index"), a = require("../config/constants"), o = require("../core/globalData"), r = require("../services/session/index");

exports.default = function() {
    global[a.CURRENT_LOGIN_TYPE] !== a.LOGIN_USER_TYPE.outerUser ? wx.getFileSystemManager().access({
        path: a.AVATAR_PATH,
        success: function(e) {
            console.log("%cavatar exist", "color: #1aad19", e), o.$global("avatarUrl", a.AVATAR_PATH);
        },
        fail: function(r) {
            console.log("%cavatar doesn't exist", "color: #ff0000", r), e.apis.session.profile().then(function(e) {
                var r = wx.getFileSystemManager();
                global[a.CURRENT_LOGIN_TYPE] !== a.LOGIN_USER_TYPE.outerUser && (console.log("get avatar success111", e), 
                r.writeFile({
                    filePath: a.AVATAR_PATH,
                    data: e,
                    encoding: "binary",
                    success: function() {
                        o.$global("avatarUrl", a.AVATAR_PATH), console.log("avatar保存成功11", o.$global("avatarUrl"));
                    },
                    fail: function(e) {
                        console.error("avatar保存失败", e);
                    }
                }));
            });
        }
    }) : r.session.getOuterUserHeaderImg() && o.$global("avatarUrl", r.session.getOuterUserHeaderImg());
};