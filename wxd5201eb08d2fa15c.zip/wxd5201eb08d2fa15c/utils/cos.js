Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getPrivateCosFileUrl = exports.uploadToCos = exports.cos = void 0;

var e = require("tslib"), t = require("../common/http-client/index"), o = e.__importDefault(require("./cos-wx-sdk-v5")), n = {
    BucketName: "hunyuanbot-1258344699",
    Region: "ap-guangzhou",
    Location: "/multimedia/*"
}, r = t.apis.cos.getTmpCredential();

r.then(function(e) {
    return console.info("cosInfo pre get:", e);
}), exports.cos = new o.default({
    Timeout: 4e4,
    SimpleUploadMethod: "putObject",
    getAuthorization: function(e, o) {
        t.apis.cos.getTmpCredential().then(function(e) {
            console.info("credential", e), o({
                TmpSecretId: e.EncryptTmpSecretId,
                TmpSecretKey: e.EncryptTmpSecretKey,
                SecurityToken: e.EncryptToken,
                StartTime: e.StartTime,
                ExpiredTime: e.ExpiredTime
            });
        }), console.info("cos get credentials options:", e);
    }
}), exports.uploadToCos = function(t) {
    return e.__awaiter(this, void 0, void 0, function() {
        var o;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                o = n, e.label = 1;

              case 1:
                return e.trys.push([ 1, 4, , 5 ]), [ 4, r ];

              case 2:
                return o = e.sent(), [ 4, exports.cos.uploadFile({
                    Bucket: o.BucketName,
                    Region: o.Region,
                    Key: o.Location.replace("/*", "") + "/pdf/" + +new Date() + "/" + t.name,
                    FilePath: t.path,
                    FileSize: t.size,
                    SliceSize: 11534336,
                    onTaskReady: function(e) {
                        var o;
                        console.info("taskId:", e), null === (o = t.onReady) || void 0 === o || o.call(t, e);
                    },
                    onProgress: function(e) {
                        var o;
                        null === (o = t.onProgress) || void 0 === o || o.call(t, e);
                    },
                    onFileFinish: function(e, o, n) {
                        var r;
                        null === (r = t.onFinish) || void 0 === r || r.call(t, e, o, n);
                    }
                }) ];

              case 3:
                return [ 2, {
                    err: null,
                    data: e.sent()
                } ];

              case 4:
                return [ 2, {
                    err: e.sent(),
                    data: null
                } ];

              case 5:
                return [ 2 ];
            }
        });
    });
}, exports.getPrivateCosFileUrl = function(t) {
    return e.__awaiter(this, void 0, void 0, function() {
        var o, i, a;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return [ 4, r ];

              case 1:
                return o = e.sent() || n, i = t.indexOf(o.Location.replace("/*", "")), a = t.slice(i), 
                [ 2, exports.cos.getObjectUrl({
                    Bucket: o.BucketName,
                    Region: o.Region,
                    Key: a
                }) ];
            }
        });
    });
};