Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.shareEntryDataTransform = exports.shareDataTransform = void 0;

var e = require("tslib"), r = require("../../common/http-client/index"), t = require("./type");

exports.shareDataTransform = function(a) {
    return e.__awaiter(void 0, void 0, void 0, function() {
        var s, n, o, i, _, d, c, h;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return a.share_type !== t.ChatDataShareType.SINGLE_FULL_CHAT_SHARE_FROM_ADMIN ? [ 3, 2 ] : (d = a.userId, 
                s = a.cid, [ 4, r.apis.conv.getOpConvDetail({
                    cid: s
                }) ]);

              case 1:
                return n = e.sent(), o = n.convs, i = n.modelId, o.reverse(), [ 2, {
                    convs: o,
                    userId: d,
                    modelId: i
                } ];

              case 2:
                if (a.share_type === t.ChatDataShareType.SINGLE_PARTIAL_CHAT_SHARE_FROM_ADMIN) return d = a.userId, 
                o = a.convs, i = a.modelId, [ 2, {
                    convs: o,
                    userId: d,
                    modelId: i
                } ];
                if (a.share_type === t.ChatDataShareType.SINGLE_PDF_PARSE) return d = a.userId, 
                c = a.share_type, h = a.chatInfo, _ = a.shareFile, [ 2, {
                    shareType: c,
                    convs: h,
                    userId: d,
                    shareFile: _
                } ];
                if (a.share_type === t.ChatDataShareType.BATCH_CHAT_SHARE_FROM_MODEL_COMPARE) return d = a.userId, 
                c = a.share_type, h = a.chatInfo, [ 2, {
                    shareType: c,
                    convs: h,
                    userId: d
                } ];
                throw new Error("不支持的分享类型");
            }
        });
    });
};

exports.shareEntryDataTransform = function(a) {
    return e.__awaiter(void 0, void 0, void 0, function() {
        var s, n, o, i, _;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return a.share_type !== t.ChatDataShareType.BATCH_FULL_CHAT_SHARE_FROM_ADMIN ? [ 3, 2 ] : (s = a.userId, 
                n = a.cidList, [ 4, r.apis.conv.getOpBatchConvs({
                    cids: n
                }) ]);

              case 1:
                return (o = e.sent()).sort(function(e, r) {
                    return r.lastRepliedAt - e.lastRepliedAt;
                }), i = o.length, _ = [ o[i - 1].lastRepliedAt, o[0].lastRepliedAt ], console.log("日志", _), 
                [ 2, {
                    convInfos: o,
                    userId: s,
                    dateRange: _
                } ];

              case 2:
                throw new Error("不支持的分享类型");
            }
        });
    });
};