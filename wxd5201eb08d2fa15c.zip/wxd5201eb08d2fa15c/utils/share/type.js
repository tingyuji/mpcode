Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatDataShareType = void 0, function(_) {
    _.SINGLE_FULL_CHAT_SHARE_FROM_ADMIN = "single_full_chat_share_from_admin", _.SINGLE_PARTIAL_CHAT_SHARE_FROM_ADMIN = "single_partial_chat_share_from_admin", 
    _.BATCH_FULL_CHAT_SHARE_FROM_ADMIN = "batch_full_chat_share_from_admin", _.BATCH_CHAT_SHARE_FROM_MODEL_COMPARE = "model_compare_weapp", 
    _.SINGLE_PDF_PARSE = "single_pdf_share";
}(exports.ChatDataShareType || (exports.ChatDataShareType = {}));