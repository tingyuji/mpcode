Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.HELPER_DOC_URL = exports.USE_AGREEMENT_URL = exports.PRIVATE_AGREEMENT_URL = exports.SERVICE_AGREEMENT_URL = exports.HELPER_DOC = exports.USE_AGREEMENT = exports.PRIVATE_AGREEMENT = exports.SERVICE_AGREEMENT = exports.openUrlByWebview = exports.openDoc = void 0;

var o = require("tslib").__importDefault(require("../common/navigator"));

exports.openDoc = function(o) {
    var e = "pages/detail/detail?url=" + encodeURIComponent(o);
    "function" == typeof wx.openEmbeddedMiniProgram ? wx.openEmbeddedMiniProgram({
        appId: "wxd45c635d754dbf59",
        path: e
    }) : wx.navigateToMiniProgram({
        appId: "wxd45c635d754dbf59",
        path: e
    });
}, exports.openUrlByWebview = function(e) {
    var t = {
        url: e
    };
    o.default.gotoPage("webview", t);
}, exports.SERVICE_AGREEMENT = "https://docs.qq.com/doc/DSHpKQmtsUElRZHdX", exports.PRIVATE_AGREEMENT = "https://docs.qq.com/doc/DSHd3VUFESGdUY2NP", 
exports.USE_AGREEMENT = "https://docs.qq.com/doc/DTUtZbEh4TkNtWWll", exports.HELPER_DOC = "https://docs.qq.com/doc/DSHlma1Bpb1F1YWpq", 
exports.SERVICE_AGREEMENT_URL = "https://zhuanhuabao-5gqf84946751a1cb-1300912497.tcloudbaseapp.com/userService.html", 
exports.PRIVATE_AGREEMENT_URL = "https://zhuanhuabao-5gqf84946751a1cb-1300912497.tcloudbaseapp.com/privacy.html", 
exports.USE_AGREEMENT_URL = "https://zhuanhuabao-5gqf84946751a1cb-1300912497.tcloudbaseapp.com/agreement.html", 
exports.HELPER_DOC_URL = "https://zhuanhuabao-5gqf84946751a1cb-1300912497.tcloudbaseapp.com/helper.html";