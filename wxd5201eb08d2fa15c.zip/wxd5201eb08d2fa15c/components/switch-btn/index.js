Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SwitchBtn = void 0;

var t = require("tslib"), e = require("../../core/base/baseComponent"), n = require("../../core/decorator/componentDecorator"), i = require("../../utils/dom"), r = function(e) {
    function r() {
        var n = null !== e && e.apply(this, arguments) || this;
        return n.properties = {
            value: "",
            dts: []
        }, n.data = {
            itemsRect: [],
            activeBg: "",
            enableAnimation: !1
        }, n.observers = {
            "itemsRect, value, dts": function(t, e, n) {
                var i = this;
                if (t.length) {
                    var r = t[n.findIndex(function(t) {
                        return t.id === e;
                    })];
                    r && e !== i.lastValue && (i.lastValue = e, i.setData({
                        activeBg: "left: " + r.left + "px; width: " + r.width + "px; height: " + r.height + "px"
                    }), i.data.enableAnimation || setTimeout(function() {
                        i.setData({
                            enableAnimation: !0
                        });
                    }, 100));
                }
            }
        }, n.lifetimes = {
            ready: function() {
                return t.__awaiter(this, void 0, void 0, function() {
                    var e, n, r, a;
                    return t.__generator(this, function(o) {
                        switch (o.label) {
                          case 0:
                            return e = this, [ 4, Promise.all([ i.getBoundRect(e, ".switch-btn"), i.getBoundRect(e, ".switch-btn-item") ]) ];

                          case 1:
                            return n = o.sent(), r = n[0], a = n[1], e.setData({
                                itemsRect: a.map(function(e) {
                                    return t.__assign(t.__assign({}, e), {
                                        left: e.left - r[0].left
                                    });
                                })
                            }), [ 2 ];
                        }
                    });
                });
            }
        }, n;
    }
    return t.__extends(r, e), r.prototype.onIdChange = function(t) {
        var e = t.currentTarget.dataset.id;
        this.triggerEvent("onValueChange", e);
    }, r = t.__decorate([ n.wxComponent() ], r);
}(e.BaseComponent);

exports.SwitchBtn = r;