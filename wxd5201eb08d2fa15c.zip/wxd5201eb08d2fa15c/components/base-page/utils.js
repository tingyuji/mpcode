Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getConnectAsync = exports.dialog = exports.toast = exports.hideLoading = exports.showLoading = exports.hideError = exports.showError = exports.toggleSubscribeMsgTip = void 0;

var n = require("tslib"), o = function(n) {
    if (!n) {
        var o = getCurrentPages();
        n = o[o.length - 1];
    }
    var e = null == n ? void 0 : n.$$basePage;
    return e || (console.warn("页面未引入base-page组件,请检查"), null);
};

exports.toggleSubscribeMsgTip = function(n) {
    var e, t = (null == (e = o()) ? void 0 : e.selectComponent("#subscribe-msg-tip")) || null;
    t && (n ? t.show() : t.close());
};

var e = function(n) {
    var e = o(n);
    return (null == e ? void 0 : e.selectComponent("#wr-dialog")) || null;
};

exports.showError = function(n, e) {
    var t = o(e);
    t && t.showError(n);
};

exports.hideError = function(n) {
    var e = o(n);
    e && e.hideError();
};

exports.showLoading = function(n) {
    var e = o(n);
    e && e.showLoading();
};

exports.hideLoading = function(n) {
    var e = o(n);
    e && e.hideLoading();
};

exports.toast = function(e, t) {
    var r = o(t), s = null == r ? void 0 : r.selectComponent("#wr-toast");
    s && s.show(n.__assign({
        duration: 2e3
    }, e));
}, exports.dialog = {
    confirm: function(o, t) {
        return new Promise(function(r, s) {
            var i = e(t);
            i ? (i.setData(n.__assign(n.__assign({
                actions: [],
                zIndex: 1001,
                textAlign: "center",
                showCancelButton: !0,
                showConfirmButton: !0
            }, o), {
                show: !0
            })), i._onComfirm = r, i._onCancel = s) : s();
        });
    },
    alert: function(o, e) {
        return exports.dialog.confirm(n.__assign(n.__assign({}, o), {
            showCancelButton: !1
        }), e);
    },
    action: function(o, t) {
        return new Promise(function(r) {
            var s = e(t);
            s.setData(n.__assign(n.__assign({
                zIndex: 1001,
                textAlign: "center",
                direction: "column"
            }, o), {
                show: !0
            })), s._onAction = r;
        });
    },
    close: function(n) {
        return new Promise(function(o, t) {
            var r = e(n);
            r ? (r.close(), o()) : t();
        });
    }
};

exports.getConnectAsync = function() {
    return new Promise(function(n) {
        wx.getNetworkType({
            success: function(o) {
                var e = o.networkType;
                return n("none" !== e);
            },
            fail: function() {
                return n(!0);
            }
        });
    });
};