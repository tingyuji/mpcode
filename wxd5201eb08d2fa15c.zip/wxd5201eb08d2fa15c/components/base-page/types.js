Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.EnumHttpErrorType = void 0, function(t) {
    t[t.System = 1] = "System", t[t.Status = 2] = "Status", t[t.Code = 3] = "Code", 
    t[t.Custom = 4] = "Custom";
}(exports.EnumHttpErrorType || (exports.EnumHttpErrorType = {}));