Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.BasePage = void 0;

var e = require("tslib"), t = require("../../core/base/baseComponent"), o = require("../../core/decorator/componentDecorator"), r = require("../../utils/base"), n = require("../../utils/helper"), s = require("./types"), a = require("./utils"), i = e.__importDefault(require("../../common/navigator")), u = {
    type: s.EnumHttpErrorType.Custom,
    responseText: "",
    message: "",
    icon: "",
    refreshText: "重新加载"
}, c = "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/error.png", l = function(t) {
    function s() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.externalClasses = [ "wr-class", "loading-class", "empty-class", "error-class" ], 
        e.properties = {
            tabbar: Boolean,
            loading: Boolean,
            empty: Object,
            autoRefresh: {
                type: Boolean,
                value: !0
            },
            refreshName: {
                type: String,
                value: "init"
            },
            floatNav: {
                type: Boolean,
                value: !0
            },
            customNav: Boolean
        }, e.data = {
            showPCForbiddenWindow: n.judgeIsPcEnv(),
            error: null,
            devMode: !1,
            top: 0,
            isConnected: !0,
            defaultErrorIcon: c,
            defaultNoNetworkText: "网络不太顺畅，请检查后重试"
        }, e.clickTimes = 0, e;
    }
    return e.__extends(s, t), s.prototype.attached = function() {
        var e = this, t = r.getPageInstance(this);
        t && (t.$$basePage = this), a.getConnectAsync().then(function(t) {
            !t && e.setData({
                isConnected: !1
            });
        });
    }, s.prototype.showError = function(t) {
        this.setData({
            error: e.__assign(e.__assign({}, u), t),
            loading: !1
        });
    }, s.prototype.hideError = function() {
        this.setData({
            error: null
        });
    }, s.prototype.showLoading = function() {
        this.setData({
            loading: !0
        });
    }, s.prototype.hideLoading = function() {
        this.data.loading && this.setData({
            loading: !1
        });
    }, s.prototype.refresh = function() {
        return e.__awaiter(this, void 0, void 0, function() {
            var t, o, n, s, u, c, l, p, d;
            return e.__generator(this, function(e) {
                switch (e.label) {
                  case 0:
                    return t = this.properties, o = t.refreshName, n = t.autoRefresh, s = t.tabbar, 
                    (null == (u = t.empty) ? void 0 : u.buttonEvent) ? [ 2, u.buttonEvent() ] : [ 4, a.getConnectAsync() ];

                  case 1:
                    if (!e.sent()) return a.toast({
                        text: "网络不太顺畅，请检查后重试",
                        icon: ""
                    }), this.setData({
                        isConnected: !1
                    }), [ 2 ];
                    if (this.setData({
                        loading: !0,
                        isConnected: !0,
                        error: null,
                        empty: null
                    }), (c = r.getPageInstance(this)) && n) {
                        if (l = c[o], r.isFunction(l)) return l.bind(c)(), [ 2 ];
                        if (!s) return p = r.obj2Params(c.options || {}), d = "/" + c.route + (p ? "?" + p : ""), 
                        i.default.redirectTo(d), [ 2 ];
                    }
                    return this.triggerEvent("refresh"), [ 2 ];
                }
            });
        });
    }, s.prototype.onIconClick = function() {
        var e, t = null === (e = this.data.error) || void 0 === e ? void 0 : e.responseText;
        this.clickTimes += 1, this.clickTimes % 8 == 0 && t && this.setData({
            devMode: !0
        });
    }, s = e.__decorate([ o.wxComponent() ], s);
}(t.BaseComponent);

exports.BasePage = l;