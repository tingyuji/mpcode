require("../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatInput = void 0;

var t = require("tslib"), e = require("../../common/http-client/index"), o = require("../../core/decorator/componentDecorator"), r = require("../../core/base/baseComponent"), n = require("../../config/index"), a = require("../../utils/helper"), i = require("../../config/constants"), s = require("../../utils/report"), c = require("../../utils/rpx"), u = t.__importDefault(require("../notify/notify")), h = 0, p = c.rpx2px(376);

try {
    h = wx.getStorageSync(n.KEYBOARD_HEIGHT) || 0;
} catch (t) {}

var l, d = [ {
    id: "mode-compare",
    label: "模型对比",
    iconName: "vs",
    online: !0,
    isNew: !1
}, {
    id: "pdf_parse",
    label: "文档解析",
    iconName: "file",
    online: !1,
    isNew: !1
} ], g = "开始", v = "录音出错，点击重试", f = "停止", y = "done", C = "error", m = "doing", T = "cancel", S = "edit", w = requirePlugin("QCloudAIVoice"), D = y, x = a.decryptVoiceKey("%5B%60%5DOST%3DENA%7BZ%7B%3Cm%3DZ%40dxnQzMWV%C2%83b%5C%3F%60u%C2%88a%C2%80PD%5Cctup%C2%81%C2%84y%5Bzn%3FUCP%C2%83e%3F%3D%7B%5BezsXy%3EBPUWM%C2%88CE%40%3E%3DE%3C%3C%3F%3D").split("|");

w.setQCloudSecret(x[0], x[1], x[2], !0);

var E = w.getRecordRecognitionManager();

E.onStart(function(t) {
    console.log("recorder start callback", t.msg), D = m;
}), E.onStop(function(t) {
    D = y, console.error("recorder stop callback", t.tempFilePath, t.result);
    var e = t.result || l.data.wxRecorder.text, o = l.data.wxRecorder.status, r = o === T;
    l.setData({
        wxRecorder: {
            btnName: g,
            status: y,
            voiceFilePath: "",
            text: ""
        },
        recordMode: !1
    }), !r && l.onRecordSuccess(e, t.tempFilePath, o);
}), E.onError(function(t) {
    D = C, console.error("recorder error callback", t.errMsg), l.setData({
        wxRecorder: {
            btnName: v,
            status: C,
            voiceFilePath: "",
            text: t.errMsg
        },
        recordMode: !1
    });
}), E.onRecognize(function(t) {
    var e;
    t.result || t.resList ? l.setData(((e = {})["wxRecorder.text"] = t.result, e)) : t.errMsg && console.error("recognize error", t.errMsg);
});

var R = function(r) {
    function v() {
        var t, e = null !== r && r.apply(this, arguments) || this;
        return e.data = {
            inputFocus: !1,
            keyboardOffsetY: h,
            duration: 200,
            inputContent: "",
            isIOS: a.isIOS,
            editorHeight: 84,
            inputPureContent: "",
            showFunctions: !1,
            showModelList: !1,
            showTemplate: !1,
            wxRecorder: {
                btnName: g,
                status: y,
                text: "",
                voiceFilePath: ""
            },
            inputPlaceholderHeight: 84,
            chatFunctions: e.getFunctions(d),
            hasViewFunctions: e.checkFirstView("hy_functions-panel-toggle"),
            voiceMode: !1,
            recordMode: !1,
            _recordCancelRect: {
                top: 0,
                bottom: 0,
                left: 0,
                right: 0
            }
        }, e.observers = ((t = {})["editorHeight, inputFocus, showFunctions, keyboardOffsetY"] = function(t, e, o, r) {
            var n = t;
            e && r ? n += r : o && (n += c.rpx2px(420)), this.setData({
                inputPlaceholderHeight: n,
                chatFunctions: this.getFunctions(d),
                hasViewFunctions: this.checkFirstView("hy_functions-panel-toggle")
            });
        }, t), e.properties = {
            mode: {
                type: String,
                value: i.CHAT_MODE_TYPE.NORMAL
            },
            chatStopping: {
                type: Boolean,
                value: !1
            },
            hideBackground: {
                type: Boolean,
                value: !1
            },
            convStatus: {
                type: String,
                value: i.CONV_STREAM_TYPE.DONE
            },
            convList: {
                type: Array,
                value: []
            },
            chatId: {
                type: String,
                value: ""
            },
            selectedList: {
                type: Array,
                value: []
            },
            relationId: {
                type: String,
                value: ""
            },
            convId: {
                type: String,
                value: ""
            },
            placeholder: {
                type: String,
                value: "请输入问题"
            },
            plugins: {
                type: Array,
                value: []
            },
            scene: {
                type: String,
                value: i.CHAT_SCENE_TYPE.NORMAL
            },
            chatStatus: {
                type: String,
                value: ""
            },
            showSliceHistory: Boolean,
            hasInspirationList: Boolean,
            showTogglePanelBtn: {
                type: Boolean,
                value: !0
            },
            chatQuota: {
                type: Number,
                value: -1
            },
            showRecommendInstructArea: {
                type: Boolean,
                value: !1
            }
        }, e.pageLifetimes = {
            hide: function() {
                D === m && this.stopWxRecorder();
            }
        }, e;
    }
    return t.__extends(v, r), v.prototype.ready = function() {
        var t = this;
        this.createSelectorQuery().select("#record-cancel").boundingClientRect(function(e) {
            t.setData({
                _recordCancelRect: e
            });
        }).exec();
    }, v.prototype.tapWxRecorder = function() {
        E ? (l = this, this.data.wxRecorder.status !== m ? (setTimeout(function() {
            wx.vibrateShort({
                type: "heavy",
                success: function() {
                    console.error("震动success");
                },
                fail: function(t) {
                    console.error("震动failed", t);
                }
            }), console.error("tap btn: vibrateShort called");
        }, 250), console.error("tap btn: manager.start called"), E.start({
            duration: 6e4,
            engine_model_type: "16k_zh"
        }), this.setData({
            recordMode: !0,
            wxRecorder: {
                btnName: f,
                status: m,
                voiceFilePath: "",
                text: ""
            }
        })) : console.error("tap btn:manager.stop called")) : u.default.warning({
            message: "录音插件初始化中，请稍后重试",
            duration: 2500
        });
    }, v.prototype.onRecordSuccess = function(t, e, o) {
        t && (this.setData({
            inputPureContent: t
        }), o !== S ? this.onSend(e) : this.setData({
            inputContent: t,
            inputPureContent: t,
            inputFocus: !0
        }));
    }, v.prototype.stopWxRecorder = function() {
        this.setData({
            recordMode: !1,
            remainingRecordSeconds: 0,
            voiceMode: this.data.wxRecorder.status !== S && this.data.voiceMode
        }), this.recorderTimer && (clearTimeout(this.recorderTimer), this.recorderTimer = null), 
        this.recorderCountDownTimer && (clearInterval(this.recorderCountDownTimer), this.recorderCountDownTimer = null);
        var t = +new Date() - this.recorderBtnTouchStartTs;
        setTimeout(function() {
            console.error("stopRecorder"), E.stop();
        }, Math.max(0, 800 - t));
    }, v.prototype.handleLongPress = function(t) {
        var e = this;
        if (0 !== this.data.chatQuota) {
            this.hasCalcRect || (setTimeout(function() {
                e.createSelectorQuery().select("#record-cancel").boundingClientRect(function(t) {
                    e.setData({
                        _recordCancelRect: t
                    });
                }).exec();
            }, 100), this.hasCalcRect = !0), console.error("TouchStart"), s.tamEventReport({
                event: s.CustomEvents.CLICK_VOICE_INPUT
            }), this.recorderBtnTouchStartTs = +new Date(), this.recorderTimer = setTimeout(function() {
                var t = 10;
                e.recorderCountDownTimer = setInterval(function() {
                    e.setData({
                        remainingRecordSeconds: t
                    }), 0 === (t -= 1) && (clearInterval(e.recorderCountDownTimer), e.recorderCountDownTimer = null);
                }, 1e3), clearTimeout(e.recorderTimer), e.recorderTimer = null;
            }, 49e3);
            var o = this.properties, r = o.convStatus, n = o.chatStatus;
            if (r !== i.CONV_STREAM_TYPE.ADD && "CHATTING" !== n) {
                if (r !== i.CONV_STREAM_TYPE.SENSITIVE_DONE) if (D !== m) {
                    var a = t.touches[t.touches.length - 1].clientY;
                    this.touchStartYpos = a, this.tapWxRecorder();
                } else u.default.info({
                    message: "录音正在结束，请稍后重试"
                });
            } else u.default.info({
                message: "回答输出中，请稍后操作"
            });
        }
    }, v.prototype.handleTouchMove = function(t) {
        var e, o, r;
        if (0 !== this.data.chatQuota) {
            var n = this.data._recordCancelRect.bottom, a = t.touches[t.touches.length - 1], i = a.clientY, s = a.clientX;
            i < n || this.touchStartYpos - i > .7 * c.rpx2px(220) ? s >= c.rpx2px(750) / 2 ? this.data.wxRecorder.status !== S && this.setData(((e = {})["wxRecorder.status"] = S, 
            e)) : this.data.wxRecorder.status !== T && this.setData(((o = {})["wxRecorder.status"] = T, 
            o)) : this.data.wxRecorder.status !== m && this.setData(((r = {})["wxRecorder.status"] = m, 
            r));
        }
    }, v.prototype.handleTouchEnd = function() {
        console.error("TouchEnd"), this.stopWxRecorder();
    }, v.prototype.onInputFocus = function() {
        this.setData({
            inputFocus: !0,
            showFunctions: !1
        }), this.triggerEvent("onInputFocus");
    }, v.prototype.onInputLongpress = function() {
        this.onInputFocus();
    }, v.prototype.onLineChange = function(t) {
        var e = t.detail.height;
        if (e) {
            var o = Math.min(e, p) + c.rpx2px(132);
            this.setData({
                editorHeight: o
            });
        }
    }, v.prototype.onInputBlur = function() {
        this.setData({
            inputFocus: !1
        });
    }, v.prototype.onInputChange = function(t) {
        var e = t.detail.value;
        this.setData({
            inputContent: e,
            inputPureContent: e.trim(),
            showTemplate: "/" === e
        }), this.triggerEvent("inputChange", e);
    }, v.prototype.onTemplateTap = function(t) {
        var e = t.currentTarget.dataset.prompt;
        this.setData({
            inputContent: e,
            inputPureContent: e,
            showTemplate: !1,
            inputFocus: !0
        });
    }, v.prototype.onSend = function(t) {
        if (0 !== this.data.chatQuota) {
            var e = t;
            "string" != typeof e && (e = "");
            var o = this.data, r = o.inputContent, n = o.inputPureContent;
            r && !n && (this.data.inputPureContent = r.trim());
            var a = this.data, s = a.inputPureContent, c = a.convStatus, h = a.convList, p = a.chatStatus;
            if ("" !== s && c !== i.CONV_STREAM_TYPE.SENSITIVE_DONE && c !== i.CONV_STREAM_TYPE.ADD && "CHATTING" !== p) {
                if (h.length >= 2 * i.CHAT_MAX_ROUND) return u.default.error({
                    message: "本次会话回合数已达上限",
                    duration: 2500
                }), void this.setData({
                    inputFocus: !1
                });
                this.triggerEvent("onSend", {
                    value: s,
                    voiceTempPath: e
                }), this.setData({
                    inputContent: e ? r : "",
                    inputPureContent: "",
                    inputFocus: !e
                });
            } else if ("CHATTING" === p) {
                var l = getCurrentPages();
                l[l.length - 1].route.includes("compare") && u.default.info({
                    message: "请等待上一条消息返回"
                });
            }
        }
    }, v.prototype.onKeyboardHeightChange = function(t) {
        console.error("keyboard height event", t);
        try {
            var e = null == t ? void 0 : t.detail, o = e.height, r = e.duration;
            if (!o) return;
            this.setData({
                keyboardOffsetY: o,
                duration: r
            }), wx.setStorageSync(n.KEYBOARD_HEIGHT, o);
        } catch (t) {
            console.error(t);
        }
    }, v.prototype.handleShareMsg = function() {
        var t = [], e = this.data, o = e.selectedList, r = e.convList;
        o.length && (o.forEach(function(e) {
            t.push(r[e]);
        }), this.triggerEvent("onShare", {
            sharedConvs: t,
            selectedList: o
        }));
    }, v.prototype.stopGenerate = function() {
        if (!this.data.chatStopping) {
            var t = this.data, e = t.relationId, o = t.convId, r = t.scene, n = r === i.CHAT_SCENE_TYPE.COMPARE ? 1 : r === i.CHAT_SCENE_TYPE.INSPIRE ? 2 : 0;
            s.tamEventReport({
                event: s.CustomEvents.CLICK_CHAT_STOP,
                data: {
                    cid: o,
                    chatType: n,
                    relationId: e
                }
            }), this.triggerEvent("onChatStop");
        }
    }, v.prototype.sliceHistory = function() {
        var t = this, o = this.data, r = o.relationId, n = o.convId;
        (r ? e.apis.conv.sliceRelationHistory : e.apis.conv.sliceHistory)({
            cid: r || n
        }).then(function() {
            t.triggerEvent("onSliceHistoryDone");
        });
    }, v.prototype.onFunctionToggle = function() {
        wx.setStorageSync("hy_functions-panel-toggle", !0), this.setData({
            hasViewFunctions: !0
        }), "EMPTY" !== this.data.chatStatus ? (this.data.showFunctions || this.setData({
            voiceMode: !1
        }), this.setData({
            showFunctions: !this.data.showFunctions,
            inputFocus: !1
        }), wx.hideKeyboard()) : u.default.info({
            message: "当前已是新对话"
        });
    }, v.prototype.doFunctions = function(t) {
        var e = this, o = t.currentTarget.dataset.id;
        wx.setStorageSync("hy_" + o, !0), this.setData({
            chatFunctions: this.getFunctions(this.data.chatFunctions)
        }), "mode-compare" === o ? this.setData({
            showModelList: !0
        }) : "pdf_parse" === o && wx.chooseMessageFile({
            count: 1,
            type: "file",
            extension: [ "pdf" ],
            success: function(t) {
                var o = t.tempFiles;
                console.error("%ctempFilePaths", o), e.setData({
                    pdfFileName: o[0].name
                });
            }
        });
    }, v.prototype.getFunctions = function(t) {
        return t.map(function(t) {
            return wx.getStorageSync("hy_" + t.id) && (t.isNew = !1), t;
        });
    }, v.prototype.compareEvent = function(t) {
        switch (t.detail.type) {
          case "cancel":
            this.setData({
                showModelList: !1
            });
            break;

          case "jump":
            this.setData({
                showFunctions: !1,
                showModelList: !1
            });
        }
    }, v.prototype.checkFirstView = function(t) {
        return !!wx.getStorageSync(t);
    }, v.prototype.toggleVoiceMode = function() {
        var t = this.data.voiceMode;
        t || this.setData({
            showFunctions: !1
        }), this.setData({
            voiceMode: !t
        }), t ? this.onInputFocus() : this.onInputBlur();
    }, v = t.__decorate([ o.wxComponent() ], v);
}(r.BaseComponent);

exports.ChatInput = R;