Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../core/decorator/componentDecorator"), o = require("../../core/base/baseComponent"), r = e.__importDefault(require("../../store/index")), i = require("../../utils/themeUtil"), n = function(o) {
    function n() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.options = {
            multipleSlots: !0,
            styleIsolation: "shared"
        }, e.data = {
            theme: {
                name: "light",
                animation: !1
            }
        }, e.pageLifetimes = {
            show: function() {
                i.updateNavBarStyleByTheme(this.data.theme.name);
            }
        }, e;
    }
    return e.__extends(n, o), n = e.__decorate([ t.wxComponent({
        storeBindingOptions: {
            store: r.default,
            fields: [ "themeStyle", "theme" ]
        }
    }) ], n);
}(o.BaseComponent);

exports.default = n;