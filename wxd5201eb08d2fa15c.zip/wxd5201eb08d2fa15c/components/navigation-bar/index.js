var e = require("../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.DesignNavigationBar = void 0;

var t = require("tslib"), o = require("../../core/decorator/componentDecorator"), r = require("../../core/base/baseComponent"), a = require("../../utils/helper"), i = t.__importDefault(require("../behavior/page-scroll-bh")), n = t.__importDefault(require("../../utils/imageMogr")), p = function(r) {
    function p() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.externalClasses = [ "wr-class" ], e.behaviors = [ i.default ], e.properties = {
            navigatorBar: {
                type: Object,
                value: {
                    openImmersive: !1,
                    type: "0",
                    bgColor: {
                        hex: "#ffffff"
                    },
                    image: null
                },
                observer: "setStyle"
            },
            back: {
                type: Boolean,
                value: !0,
                observer: "setStyle"
            },
            title: {
                type: String,
                value: ""
            },
            home: {
                type: Boolean,
                value: !0,
                observer: "setStyle"
            },
            color: {
                type: String,
                value: "#000",
                observer: "setStyle"
            },
            zIndex: {
                type: Number,
                value: 9999,
                observer: "setStyle"
            },
            delta: {
                type: Number,
                value: 1
            },
            isDark: {
                type: Boolean,
                value: !1
            },
            closeStyle: {
                type: Boolean,
                value: !1
            }
        }, e.data = {
            showPCForbiddenWindow: a.judgeIsPcEnv(),
            isIos: !1,
            containerStyle: "",
            leftStyle: "",
            leftMenuStyle: "",
            navBarHeight: 0,
            showBackIcon: !0,
            menuButtonRect: null,
            opacity: 0,
            bgWidth: e.app.globalData.systemInfo.screenWidth * e.app.globalData.systemInfo.pixelRatio
        }, e.mounted = !1, e;
    }
    return t.__extends(p, r), p.prototype.attached = function() {
        this.mounted = !0, this.setStyle();
    }, p.prototype.getNavigationStyle = function(e) {
        return e.openImmersive ? e.openImmersive && "0" === e.type ? "background: " + e.bgColor.hex : e.openImmersive && "1" === e.type ? "background-image: url(" + n.default(e.image.src, {
            width: this.data.bgWidth
        }) + ")" : "" : "background: " + e.bgColor.hex || "background: #ffffff";
    }, p.prototype.setStyle = function() {
        if (this.mounted) {
            var e = a.getNavBarInfo(), t = e.navBarHeight, o = e.menuButtonRect, r = e.windowWidth, i = e.isIos, n = e.gap, p = o.width, s = o.height, l = o.left, u = o.right, g = o.top, c = this.properties, h = c.home, d = c.navigatorBar, f = c.color, v = c.back, y = [ "color:" + f, "height:" + t + "px", "padding-top:" + g + "px", "padding-bottom:" + n + "px", "padding-left:" + (r - u) + "px", "padding-right:" + (r - l) + "px", "" + this.getNavigationStyle(d) ].join(";"), m = [ "width:" + p + "px" ].join(";"), b = "";
            (h || v) && (b = [ "width:" + (v && h ? p : Math.round(p / 2)) + "px", "height:" + s + "px", "border-radius:" + Math.round(s / 2) + "px" ].join(";")), 
            this.setData({
                isIos: i,
                navBarHeight: t,
                containerStyle: y,
                leftStyle: m,
                leftMenuStyle: b,
                showBackIcon: v,
                menuButtonRect: o
            });
        }
    }, p.prototype.beforeJump = function(t) {
        var o = getCurrentPages(), r = o[o.length - 1];
        if ("function" == typeof r.onBeforeUnload) {
            var a = r.onBeforeUnload();
            if (!0 === a) return;
            "object" === e(a) && a.then ? a.then(function() {}).catch(function() {
                t();
            }) : t();
        }
    }, p.prototype.navigateToHome = function() {
        var e = this;
        this.beforeJump(function() {
            wx.redirectTo({
                url: a.config.homePath
            }), e.triggerEvent("home");
        });
    }, p.prototype.navigateBack = function() {
        var e = this, t = a.getCurrentPage();
        if ("pages/personal/index" === t.route && "forbid" === t.data.sourceFrom) return wx.redirectTo({
            url: a.config.forbidPath
        });
        this.beforeJump(function() {
            var t = e.properties.delta;
            getCurrentPages().length > (t || 1) ? (wx.navigateBack({
                delta: t
            }), e.triggerEvent("back")) : (wx.redirectTo({
                url: a.config.homePath
            }), e.triggerEvent("home"));
        });
    }, p.prototype.getOpacity = function(e, t) {
        return e >= t ? 1 : 0;
    }, p.prototype.onPageScroll = function(e) {
        var t = e.scrollTop, o = this.data.navBarHeight;
        if (this.properties.navigatorBar.openImmersive) {
            var r = this.getOpacity(t, o);
            this.data.opacity !== r && this.setData({
                opacity: r
            });
        }
    }, p = t.__decorate([ o.wxComponent() ], p);
}(r.BaseComponent);

exports.DesignNavigationBar = p;