Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), e = require("@tencent/retailwe-ui-common/index"), i = "horizontal", s = "vertical", r = function(r) {
    function o() {
        var t = null !== r && r.apply(this, arguments) || this;
        return t.externalClasses = [ "wr-class", "wr-class-active" ], t.properties = {
            tabList: {
                type: Array,
                value: []
            },
            height: String,
            isScroll: {
                type: Boolean,
                value: !0
            },
            status: {
                type: Number,
                value: 0
            },
            activeFontSize: String,
            activeColor: String,
            color: String,
            fontSize: String,
            lineColor: String,
            lineHeight: String,
            lineWidth: String,
            showBottomLine: {
                type: Boolean,
                value: !0
            },
            slideable: Boolean
        }, t.data = {
            sortType: ""
        }, t;
    }
    return t.__extends(o, r), o.prototype.tabChange = function(t) {
        var e = this.properties.status, i = t.currentTarget.dataset.status, s = this.properties.tabList.find(function(t) {
            return t.key === i;
        });
        if (null == s ? void 0 : s.sort) {
            var r = "asc";
            if (e === i) switch (this.data.sortType) {
              case "asc":
                r = "desc";
                break;

              case "desc":
                r = "asc";
            }
            this.setData({
                sortType: r
            }), this.triggerEvent("sortchange", {
                sortType: r,
                key: i
            });
        }
        null != i && e != i && this.triggerEvent("tabChange", i);
    }, o.prototype.resetTouchStatus = function() {
        this.direction = "", this.deltaX = 0, this.deltaY = 0, this.offsetX = 0, this.offsetY = 0;
    }, o.prototype.touchStart = function(t) {
        if (this.properties.slideable) {
            this.resetTouchStatus();
            var e = t.touches[0];
            this.startX = e.clientX, this.startY = e.clientY;
        }
    }, o.prototype.getDirection = function(t, e) {
        return t > e && t > 10 ? i : e > t && e > 10 ? s : "";
    }, o.prototype.touchMove = function(t) {
        if (this.properties.slideable) {
            var e = t.touches[0];
            this.deltaX = e.clientX - this.startX, this.deltaY = e.clientY - this.startY, this.offsetX = Math.abs(this.deltaX), 
            this.offsetY = Math.abs(this.deltaY), this.direction = this.getDirection(this.offsetX, this.offsetY);
        }
    }, o.prototype.onTouchEnd = function() {
        if (this.properties.slideable) {
            var t = this.direction, e = this.deltaX, s = this.offsetX;
            if (t === i && s >= 50) {
                var r = this.getAvailableTabIndex(e);
                -1 !== r && this.triggerEvent("tabChange", r);
            }
        }
    }, o.prototype.getAvailableTabIndex = function(t) {
        var e = t > 0 ? -1 : 1, i = this.properties.status, s = this.properties.tabList, r = s.length;
        if (i + e >= 0 && i + e < r) {
            var o = i + e;
            if (o >= 0 && o < r && s[o]) return o;
        }
        return -1;
    }, o = t.__decorate([ e.wxComponent() ], o);
}(e.SuperComponent);

exports.default = r;