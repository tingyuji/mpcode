Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SwitchBtn = void 0;

var e = require("tslib"), t = require("../../core/base/baseComponent"), o = require("../../core/decorator/componentDecorator"), r = e.__importDefault(require("../../store/index")), n = require("../../utils/themeUtil"), i = require("../../utils/base").debounce(function(e) {
    n.updateAppTheme({
        theme: e,
        forGlobal: !0,
        animation: !1
    });
}, 300), a = function(t) {
    function a() {
        return null !== t && t.apply(this, arguments) || this;
    }
    return e.__extends(a, t), a.prototype.onValueChange = function(e) {
        var t = e.detail;
        n.updateAppTheme({
            theme: t,
            saveStorage: !0,
            forGlobal: !0,
            animation: !0
        }), i(t);
    }, a = e.__decorate([ o.wxComponent({
        storeBindingOptions: {
            store: r.default,
            fields: [ "themeStyle", "theme" ]
        }
    }) ], a);
}(t.BaseComponent);

exports.SwitchBtn = a;