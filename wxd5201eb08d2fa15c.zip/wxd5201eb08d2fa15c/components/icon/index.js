Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), r = require("../../core/decorator/componentDecorator"), t = function(t) {
    function n() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            name: {
                type: String,
                require: !0,
                observer: function(e) {
                    this.setData({
                        isImageName: -1 !== e.indexOf("/")
                    });
                }
            },
            classPrefix: {
                type: String,
                value: "icon"
            },
            size: {
                type: null,
                value: 24
            },
            color: {
                type: String,
                value: "currentColor"
            },
            info: String,
            customStyle: String
        }, e;
    }
    return e.__extends(n, t), n = e.__decorate([ r.wxComponent() ], n);
}(require("../../core/base/baseComponent").BaseComponent);

exports.default = t;