Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../../utils/base");

function t(t) {
    var n = e.getPageInstance(this);
    if (n && n.pageScroller && n.pageScroller.length) {
        var a = n.pageScroller;
        (void 0 === a ? [] : a).forEach(function(e) {
            "function" == typeof e && e(t);
        });
    }
}

exports.default = Behavior({
    attached: function() {
        if (this.pageInstance = e.getPageInstance(this), this.onPageScroll && "function" == typeof this.onPageScroll) {
            if (!this.pageInstance) return;
            this.scroller = this.onPageScroll.bind(this), Array.isArray(this.pageInstance.pageScroller) ? this.pageInstance.pageScroller.push(this.scroller) : this.pageInstance.pageScroller = "function" == typeof this.pageInstance.onPageScroll ? [ this.pageInstance.onPageScroll.bind(this.pageInstance), this.scroller ] : [ this.scroller ], 
            this.pageInstance.onPageScroll = t;
        }
    },
    detached: function() {
        var e, t = this;
        this.onPageScroll && "function" == typeof this.onPageScroll && this.pageInstance && (this.pageInstance.pageScroller = (null === (e = this.pageInstance.pageScroller) || void 0 === e ? void 0 : e.filter(function(e) {
            return e !== t.scroller;
        })) || []);
    }
});