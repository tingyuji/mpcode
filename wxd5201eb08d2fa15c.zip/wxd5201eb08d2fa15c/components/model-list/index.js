require("../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ModelList = void 0;

var e = require("tslib"), t = require("../../core/decorator/componentDecorator"), n = require("../../core/base/baseComponent"), o = require("../../utils/prefetch"), r = [ {
    id: "gpt-35-turbo",
    name: "GPT-3.5-turbo",
    profile: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/gpt-logo.png",
    selected: !1
}, {
    id: "gpt-4",
    name: "GPT-4",
    profile: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/gpt4_circle.png",
    selected: !1
} ];

function a() {
    return e.__awaiter(this, void 0, void 0, function() {
        var t, n;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return [ 4, o.memoizedGetConfig.call() ];

              case 1:
                return t = e.sent(), (n = t.competitionModelMetaInfo) ? [ 2, n.filter(function(e) {
                    return "gpt_175B_0404" !== e.modelId;
                }).map(function(e) {
                    return {
                        id: e.modelId,
                        name: e.modelName,
                        profile: e.iconCircle
                    };
                }) ] : [ 2, r ];
            }
        });
    });
}

var i = function(n) {
    function o() {
        var t, o = null !== n && n.apply(this, arguments) || this;
        return o.externalClasses = [ "wr-class" ], o.properties = {
            navigatorBar: {
                type: Object,
                value: {
                    openImmersive: !1,
                    type: "0",
                    bgColor: {
                        hex: "#ffffff"
                    },
                    image: null
                },
                observer: "setStyle"
            },
            show: {
                type: Boolean
            }
        }, o.data = {
            modelList: r,
            selectedNum: 0,
            maxCompareModelNum: 2
        }, o.observers = ((t = {}).modelList = function(e) {
            var t = e.filter(function(e) {
                return e.selected;
            });
            this.setData({
                selectedNum: t.length
            });
        }, t.show = function(t) {
            var n = this;
            t || a().then(function(t) {
                n.setData({
                    modelList: t.map(function(t) {
                        return e.__assign(e.__assign({}, t), {
                            selected: !1
                        });
                    })
                });
            });
        }, t), o;
    }
    return e.__extends(o, n), o.prototype.attached = function() {
        var t = this;
        a().then(function(n) {
            t.setData({
                modelList: n.map(function(t) {
                    return e.__assign(e.__assign({}, t), {
                        selected: !1
                    });
                })
            });
        });
    }, o.prototype.onSelect = function(e) {
        var t = e.currentTarget.dataset.id, n = this.data, o = n.maxCompareModelNum, r = n.selectedNum, a = this.data.modelList.map(function(e) {
            return e.id === t && (r >= o ? e.selected && (e.selected = !1) : e.selected = !e.selected), 
            e;
        });
        this.setData({
            modelList: a,
            cdb: "aaa",
            ccc: "bbb"
        });
    }, o.prototype.jumpCompare = function() {
        if (this.data.selectedNum) {
            var e = getCurrentPages(), t = e[e.length - 1].route, n = encodeURIComponent("gpt_175B_0404," + this.data.modelList.map(function(e) {
                return e.selected && e.id;
            }).join(","));
            this.triggerEvent("onchange", {
                type: "jump"
            }), t.includes("home") ? wx.navigateTo({
                url: "/pages/compare/index?modelIds=" + n
            }) : this.triggerEvent("onchange", {
                type: "refresh",
                modelIds: n
            });
        }
    }, o.prototype.onCancel = function() {
        this.triggerEvent("onchange", {
            type: "cancel"
        });
    }, o = e.__decorate([ t.wxComponent() ], o);
}(n.BaseComponent);

exports.ModelList = i;