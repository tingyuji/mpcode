Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), e = require("../../core/decorator/componentDecorator"), i = require("../../core/base/baseComponent"), o = require("./notify"), n = function(i) {
    function n() {
        var t = null !== i && i.apply(this, arguments) || this;
        return t.externalClasses = [ "wr-class" ], t.options = {
            styleIsolation: "apply-shared",
            multipleSlots: !0
        }, t.properties = {
            show: {
                type: Boolean,
                value: !1
            },
            type: {
                type: String,
                value: o.NotifyType.default
            },
            iconName: {
                type: null,
                value: ""
            },
            bgColor: {
                type: null,
                value: ""
            },
            textColor: {
                type: null,
                value: ""
            },
            showCloseIcon: {
                type: Boolean,
                value: !1
            },
            btnContent: {
                type: String,
                value: ""
            },
            message: {
                type: String,
                value: ""
            },
            duration: {
                type: Number,
                value: 2e3
            }
        }, t.data = {
            show: !1,
            animation: [],
            local: {
                iconName: ""
            }
        }, t.closeTimeoutContext = 0, t.initalData = {}, t.nextAnimationContext = 0, t.resetAnimation = wx.createAnimation({
            duration: 0,
            timingFunction: "linear"
        }), t;
    }
    return t.__extends(n, i), n.prototype.ready = function() {
        this.memoInitalData(), this.refreshIconName();
    }, n.prototype.memoInitalData = function() {
        this.initalData = t.__assign(t.__assign({}, this.properties), this.data);
    }, n.prototype.resetData = function(e) {
        this.setData(t.__assign({}, this.initalData), e);
    }, n.prototype.detached = function() {
        this.cleanAnimation();
    }, n.prototype.refreshIconName = function(t) {
        if (void 0 === t && (t = this.properties.iconName), !1 !== t) if (t) this.setData({
            "local.iconName": "" + t
        }); else {
            var e = "default";
            switch (this.properties.type) {
              case o.NotifyType.scroll:
                e = "question";
                break;

              case o.NotifyType.success:
                e = "success";
                break;

              case o.NotifyType.warning:
                e = "warning";
                break;

              case o.NotifyType.error:
                e = "error";
                break;

              case o.NotifyType.default:
                e = "default";
            }
            this.setData({
                "local.iconName": e
            });
        } else this.setData({
            "local.iconName": ""
        });
    }, n.prototype.checkAnimation = function() {
        var t = this;
        if (this.properties.type === o.NotifyType.scroll) {
            this.nextAnimationContext && this.cleanAnimation();
            Promise.all([ this.queryWidth("#notify--text"), this.queryWidth("#notify--text-wrap") ]).then(function(e) {
                var i = e[0], o = e[1];
                t.setData({
                    animation: t.resetAnimation.translateX(o).step().export()
                }, function() {
                    var e = (i + o) / 50 * 1e3, n = wx.createAnimation({
                        duration: e
                    }).translateX(-i).step().export();
                    setTimeout(function() {
                        t.nextAnimationContext = setTimeout(t.checkAnimation.bind(t), e), t.setData({
                            animation: n
                        });
                    }, 20);
                });
            });
        }
    }, n.prototype.queryWidth = function(t) {
        var e = this;
        return new Promise(function(i) {
            e.createSelectorQuery().select(t).boundingClientRect(function(t) {
                var e = t.width;
                i(e);
            }).exec();
        });
    }, n.prototype.cleanAnimation = function() {
        clearTimeout(this.nextAnimationContext), this.nextAnimationContext = 0;
    }, n.prototype.show = function() {
        var t = this, e = this.properties, i = e.duration, o = e.iconName;
        this.setData({
            show: !0
        }), this.refreshIconName(o), this.checkAnimation(), i && i > 0 && (this.closeTimeoutContext = setTimeout(function() {
            t.hide();
        }, i));
    }, n.prototype.hide = function() {
        clearTimeout(this.closeTimeoutContext), this.closeTimeoutContext = 0, this.setData({
            show: !1,
            animation: []
        });
    }, n.prototype.closeHandle = function() {
        this.hide(), this.triggerEvent("close");
    }, n.prototype.btnClickHandle = function() {
        this.triggerEvent("click-btn", {
            self: this
        });
    }, n = t.__decorate([ e.wxComponent() ], n);
}(i.BaseComponent);

exports.default = n;