Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.NotifyType = void 0;

var e, r = require("tslib");

function t(e, r) {
    if (void 0 === r && (r = "#wr-notify"), !e) {
        var t = getCurrentPages(), n = t[t.length - 1];
        e = n.$$basePage || n;
    }
    var o = e && e.selectComponent(r);
    return o || (console.warn("未找到notify组件, 请检查selector是否正确"), null);
}

function n(n, o) {
    void 0 === o && (o = e.default);
    var s = t(n.context, n.selector);
    return s ? (s.hide(), s.resetData(function() {
        s.setData(r.__assign({
            type: o
        }, n), s.show);
    }), s) : Promise.reject();
}

!function(e) {
    e.default = "default", e.scroll = "scroll", e.success = "success", e.warning = "warning", 
    e.error = "error";
}(e = exports.NotifyType || (exports.NotifyType = {})), exports.default = {
    info: function(r) {
        return n(r, e.default);
    },
    success: function(r) {
        return n(r, e.success);
    },
    warning: function(r) {
        return n(r, e.warning);
    },
    error: function(r) {
        return n(r, e.error);
    },
    hide: function() {
        var e = t();
        e && e.hide();
    }
};