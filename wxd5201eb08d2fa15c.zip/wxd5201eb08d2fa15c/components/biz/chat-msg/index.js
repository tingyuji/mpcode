var e = require("../../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatMsg = void 0;

var t, a, r = require("tslib"), s = require("../../../common/http-client/index"), i = r.__importDefault(require("../../notify/notify")), o = require("../../../core/base/baseComponent"), n = require("../../../core/decorator/componentDecorator"), d = require("../../../core/globalData"), p = require("../../../interface/type"), g = require("../../../utils/feedback"), u = require("../../../utils/helper"), c = require("../../../utils/prefetch"), l = require("../../../utils/rpx"), h = require("../../../utils/base"), m = r.__importDefault(require("../../../store/index")), v = require("../../../config/constants"), f = r.__importDefault(require("../../../utils/remove-markdown")), y = require("../../../utils/report"), M = /\|\n\n\|/g;

require.async("../../../towxml/index").then(function(e) {
    t = e;
}), wx.setInnerAudioOption({
    obeyMuteSwitch: !1
});

var x = wx.createInnerAudioContext({
    useWebAudioImplement: !1
});

x.onEnded(function() {
    a.setData({
        audioPlayStatus: "ready"
    });
}), x.onError(function() {
    a.setData({
        audioPlayStatus: "ready"
    });
});

var T = function(o) {
    function T() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.options = {
            styleIsolation: "apply-shared"
        }, e.properties = {
            forbidLogoAnimate: Boolean,
            text: {
                type: String
            },
            convScene: String,
            voicePath: String,
            convStatus: {
                type: String,
                value: v.CONV_STREAM_TYPE.DONE
            },
            isLastMsg: {
                type: Boolean
            },
            pluginNames: {
                type: Array
            },
            msg: {
                type: Array,
                observer: function(e) {
                    (e.length > this.data.msgLength || e.length < this.data.msgLength) && this.setData({
                        msgLength: e.length,
                        currentAnswerIndex: e.length - 1
                    }), this.formatMsgWxml(e[this.data.currentAnswerIndex]);
                }
            },
            textMsgErrorType: p.TextMsgErrorType,
            msgCount: Number,
            type: {
                type: String,
                value: "question"
            },
            cid: String,
            showRegenerate: Boolean,
            showContinueBtn: {
                type: Boolean,
                value: !1
            },
            likes: Array,
            msgIndex: Number,
            msgStatus: {
                type: String,
                value: v.CONV_STREAM_TYPE.DONE,
                observer: function(e) {
                    this.setData({
                        unlockLogoAnimate: !0
                    }), e === v.CONV_STREAM_TYPE.ADD && this.properties.isLastMsg && this.setData({
                        foldCard: !1
                    });
                    var t = this.properties, a = t.isLastMsg, r = t.isModelCompare, s = t.showType;
                    if (a && e === v.CONV_STREAM_TYPE.DONE && !r && "qaCombined" !== s) {
                        var i = this.properties.msg;
                        if (!i || u.isAbnormalStreamText(i[i.length - 1])) return;
                        var o = g.getIsNewUser(), n = g.getTodayHadFeed();
                        this.setData({
                            isNewUser: o,
                            hadFeedback: n
                        }), o ? (g.setUserOld(), g.setTodayFeedBackTime()) : n || g.setTodayFeedBackTime();
                    }
                }
            },
            shareMode: Boolean,
            selectMode: Boolean,
            extraInfo: Object,
            chatIcon: {
                type: String,
                value: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo-s2.png"
            },
            chatName: {
                type: String,
                value: "腾讯混元助手"
            },
            chatId: {
                type: String,
                value: ""
            },
            isModelCompare: {
                type: Boolean,
                value: !1
            },
            chatStatus: {
                type: String,
                value: ""
            },
            isPdfParse: {
                type: Boolean,
                value: !1
            },
            showType: {
                type: String,
                value: ""
            },
            question: {
                type: String,
                value: ""
            },
            createTime: {
                type: Number,
                value: 0
            },
            showPromptDerive: {
                type: Boolean,
                value: !1
            },
            promptDeriveList: {
                type: Array,
                value: null
            },
            showRepeatFeedBackIndex: {
                type: Number,
                value: -1
            }
        }, e.data = {
            hasShareAuth: !0,
            _rawTextMsg: "",
            hadFeedback: !0,
            isNewUser: !1,
            unlockLogoAnimate: !1,
            audioPlayStatus: "ready",
            currentAnswerIndex: 0,
            isLastAnswer: !0,
            formatedMsg: null,
            msgLength: 0,
            avatar: getApp().globalData.avatarUrl,
            showActionMenu: !1,
            imageTextMsg: !1,
            imageGenFailed: !1,
            imageGeneratingText: "好的，我正在创作中，请稍等",
            foldCard: !0,
            originMsg: "",
            repeatFeedBack: [ {
                label: "🤩更好",
                value: 1
            }, {
                label: "😐差不多",
                value: 0
            }, {
                label: "😡更差",
                value: -1
            } ],
            curRepeatFeedBack: null
        }, e;
    }
    return r.__extends(T, o), T.prototype.attached = function() {
        return r.__awaiter(this, void 0, void 0, function() {
            var e;
            return r.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return d.$global("avatarUrl") !== this.data.avatar && this.setData({
                        avatar: d.$global("avatarUrl")
                    }), [ 4, c.memoizedGetConfig.call() ];

                  case 1:
                    return e = t.sent().messageText, this.setData({
                        imageGeneratingText: e.imgGenerating
                    }), [ 2 ];
                }
            });
        });
    }, T.prototype.togglePlayAudio = function() {
        "ready" === this.data.audioPlayStatus ? (a = this, x.src = this.properties.voicePath, 
        x.play(), this.setData({
            audioPlayStatus: "playing"
        })) : (x.stop(), this.setData({
            audioPlayStatus: "ready"
        }));
    }, T.prototype.ready = function() {
        var e;
        return r.__awaiter(this, void 0, void 0, function() {
            var t, a;
            return r.__generator(this, function(r) {
                switch (r.label) {
                  case 0:
                    return this.triggerEvent("scrollToMsg"), [ 4, c.memoizedGetConfig.call() ];

                  case 1:
                    return t = r.sent(), a = null === (e = null == t ? void 0 : t.privilege) || void 0 === e ? void 0 : e.share, 
                    this.setData({
                        hasShareAuth: a
                    }), [ 2 ];
                }
            });
        });
    }, T.prototype.regenerate = function() {
        this.setData({
            isNewUser: !1,
            hadFeedback: !0
        }), this.triggerEvent("regenerate"), y.tamEventReport({
            event: y.CustomEvents.CLICK_CHAT_REPEAT,
            data: {
                cid: this.properties.chatId,
                chatType: this.properties.isModelCompare ? 1 : this.properties.convScene === v.CHAT_SCENE_TYPE.INSPIRE ? 2 : 0
            }
        });
    }, T.prototype.continueChat = function() {
        this.triggerEvent("continueChat"), y.tamEventReport({
            event: y.CustomEvents.CLICK_CHAT_CONTINUE,
            data: {
                cid: this.properties.chatId,
                chatType: this.properties.isModelCompare ? 1 : this.properties.convScene === v.CHAT_SCENE_TYPE.INSPIRE ? 2 : 0
            }
        });
    }, T.prototype.handleLike = function(e) {
        var t = this;
        this.setData({
            isNewUser: !1,
            hadFeedback: !0
        });
        var a = this.data, r = a.likes, o = a.currentAnswerIndex, n = a.chatId, d = e.currentTarget.dataset.like, p = this.properties, g = p.msgIndex, u = p.cid, c = p.msgCount, l = p.showType, h = r[o] === +d, m = h ? 0 : +d, v = "qaCombined" === l ? g + 1 : c - 1 - g;
        s.apis.conv.feedback({
            idx: v,
            msg_idx: this.data.currentAnswerIndex,
            suitable: m,
            cid: u
        }).then(function(e) {
            h || t.openDetailFeedBackWindow(m), console.log(e), t.triggerEvent("updateFeedBack", {
                currentAnswerIndex: o,
                suitable: m,
                msgIndex: g,
                chatId: n
            });
        }).catch(function(e) {
            console.error(e), i.default.error({
                message: "操作失败，请重试"
            });
        });
    }, T.prototype.openDetailFeedBackWindow = function(e) {
        var t = this.properties, a = t.msgIndex, r = t.cid, s = t.msgCount, i = this.data.currentAnswerIndex;
        this.triggerEvent("openFeedbackWindow", {
            type: e,
            msgIndex: a,
            cid: r,
            msgCount: s,
            currentAnswerIndex: i
        });
    }, T.prototype.switchMsg = function(e) {
        var t = e.currentTarget.dataset, a = t.direction;
        if (t.available) {
            var r = this.properties.msg, s = "left" === a ? -1 : 1, i = this.data.currentAnswerIndex + s;
            this.formatMsgWxml(r[i]), this.setData({
                isNewUser: !1,
                hadFeedback: !0,
                currentAnswerIndex: i,
                isLastAnswer: i === r.length - 1
            });
        }
    }, T.prototype.handleMsgLongPress = function(e) {
        var t = this;
        if (!this.data.isPdfParse) if (this.properties.shareMode) this.copyMsg(); else {
            var a = e.currentTarget.dataset.bubbleType, r = this.properties, s = r.showType, i = r.isLastMsg, o = "#chat-bubble-" + this.properties.chatId + this.properties.msgIndex;
            this.createSelectorQuery().select(o).boundingClientRect(function(e) {
                var r = l.getActionMenuPosition({
                    rect: e,
                    rightAdjust: "qaCombined" === s ? 0 : 90,
                    topAdjust: "qaCombined" === s ? 266 : 0,
                    extraTopHeight: t.properties.isModelCompare ? 120 : 0,
                    bubbleType: a
                }), o = 0;
                "up" === r.msgPosition && "qaCombined" === s && i && (o = -l.rpx2px(144)), t.setData({
                    msgPosition: r.msgPosition,
                    caretOffset: r.caretOffset,
                    topOffset: r.topOffset,
                    msgRightOffset: r.msgRightOffset,
                    firstInspireMenuMargin: o
                });
            }).exec(), this.setData({
                showActionMenu: !0
            });
            var n = this.properties.msgIndex;
            this.triggerEvent("longPress", n);
        }
    }, T.prototype.copyMsg = function() {
        this.setData({
            showActionMenu: !1
        });
        var t = this.properties.msg[this.data.currentAnswerIndex], a = t;
        "object" === e(t) && (t.type === p.MsgType.text ? a = t.msg : t.type === p.MsgType.image ? a = t.text : t.type === p.MsgType.goods && (a = t.preText + t.text)), 
        console.log("%ccopyMsg: %o", "color:#0000ff", this.properties.msg[this.data.currentAnswerIndex]), 
        wx.setClipboardData({
            data: a,
            success: function() {}
        }), global.__MSG_TOOL_TAP = !1;
    }, T.prototype.setSelectMode = function() {
        this.setData({
            showActionMenu: !1
        }), this.triggerEvent("setSelectMode"), global.__MSG_TOOL_TAP = !1;
    }, T.prototype.shareSingleMsg = function() {
        this.setData({
            showActionMenu: !1
        }), this.triggerEvent("shareSingleMsg", {
            index: this.properties.msgIndex
        }), global.__MSG_TOOL_TAP = !1;
    }, T.prototype.shareCardMsg = function() {
        this.data.isPdfParse ? this.triggerEvent("sharePdfMsg", {
            index: this.properties.msgIndex
        }) : this.triggerEvent("shareSingleMsg", {
            index: this.properties.msgIndex
        }), global.__MSG_TOOL_TAP = !1;
    }, T.prototype.formatMsgWxml = function(a) {
        var s;
        return r.__awaiter(this, void 0, void 0, function() {
            var i, o;
            return r.__generator(this, function(r) {
                switch (r.label) {
                  case 0:
                    return this.properties.isLastMsg && this.properties.msgStatus !== v.CONV_STREAM_TYPE.ADD && this.triggerEvent("lastMsgLoaded"), 
                    a ? "answer" === this.properties.type ? [ 3, 1 ] : (this.setData({
                        formatedMsg: a
                    }), this.data._rawTextMsg = a, [ 3, 4 ]) : [ 3, 5 ];

                  case 1:
                    if ("object" === e(a)) {
                        if (a.type === p.MsgType.image) return this.setData({
                            imageTextMsg: !0,
                            formatedMsg: a,
                            imageGenFailed: a.images.every(function(e) {
                                return e.failed;
                            }),
                            originMsg: ""
                        }), this.data._rawTextMsg = a.text, [ 2 ];
                        if (a.goods) return this.setData({
                            cardTextMsg: !0,
                            formatedMsg: a
                        }), this.data._rawTextMsg = a.text, [ 2 ];
                        if (a.type === p.MsgType.text) {
                            if (!(a = a.msg || "")) return this.setData({
                                imageTextMsg: !1,
                                cardTextMsg: !1,
                                imageGenFailed: !1,
                                formatedMsg: ""
                            }), [ 2 ];
                        } else if (a.type === p.MsgType.step) return this.setData({
                            formatedMsg: "object" === e(a) ? null === (s = a) || void 0 === s ? void 0 : s.text : a
                        }), [ 2 ];
                    }
                    return i = (n = a) ? null == n ? void 0 : n.replace(M, "|\n|") : "", t ? [ 3, 3 ] : [ 4, require.async("../../../towxml/index") ];

                  case 2:
                    t = r.sent(), r.label = 3;

                  case 3:
                    o = t(i, "markdown", {
                        theme: m.default.getState().theme.name,
                        events: {}
                    }), this.data._rawTextMsg = i, o || console.error("formatDataEmpty error:", o, a), 
                    this.setData({
                        imageTextMsg: !1,
                        cardTextMsg: !1,
                        imageGenFailed: !1,
                        formatedMsg: o,
                        originMsg: i
                    }), r.label = 4;

                  case 4:
                    return [ 3, 6 ];

                  case 5:
                    this.data.formatedMsg ? (console.error("formatDataEmpty error:", this.data.formatedMsg, a), 
                    this.setData({
                        imageTextMsg: !1,
                        cardTextMsg: !1,
                        imageGenFailed: !1,
                        formatedMsg: ""
                    })) : this.data._rawTextMsg = v.ERROR_EMPTY_ANSWER, r.label = 6;

                  case 6:
                    return [ 2 ];
                }
                var n;
            });
        });
    }, T.prototype.hideActionMenu = function() {
        this.setData({
            showActionMenu: !1
        });
    }, T.prototype.onImageTap = function(e) {
        var t = this.data.formatedMsg, a = null == t ? void 0 : t.images.map(function(e) {
            return e.highDefImageUrl;
        }), r = h.get(e, "target.dataset.index", -1);
        -1 !== r && wx.previewImage({
            urls: a,
            current: a[r]
        });
    }, T.prototype.onImageError = function(e) {
        var t, a = h.get(e, "target.dataset.index", -1);
        this.setData(((t = {})["formatedMsg.images[" + a + "].loadFail"] = !0, t));
    }, T.prototype.onNavigate = function(e) {
        var t = (e.currentTarget.dataset || {}).item, a = t.appid, r = t.path, i = t.goodsId, o = t.traceId;
        u.isSharePage() || s.apis.behavior.report({
            goodsId: i,
            traceId: o,
            behaviorType: "click",
            behaviorValue: "1",
            timestamp: Math.round(+new Date() / 1e3)
        }), a && r && wx.navigateToMiniProgram({
            appId: a,
            path: r,
            extraData: {}
        });
    }, T.prototype.onGoodsExpose = function(e) {
        u.isSharePage() || s.apis.behavior.report({
            goodsId: e.detail.goodsId,
            traceId: e.detail.traceId,
            behaviorType: "expose",
            behaviorValue: "1",
            timestamp: Math.round(+new Date() / 1e3)
        });
    }, T.prototype.hackTapNoWork = function() {
        global.__MSG_TOOL_TAP = !0;
    }, T.prototype.handleCardChange = function() {
        this.setData({
            foldCard: !this.data.foldCard
        });
    }, T.prototype.promptTap = function(e) {
        var t = e.currentTarget.dataset.value;
        this.triggerEvent("promptDeriveTap", t), y.tamEventReport({
            event: y.CustomEvents.CLICK_RECOMMEND_PROMPT,
            data: {
                prompt: t
            }
        });
    }, T.prototype.onRepeatFeedBack = function(e) {
        var t = e.currentTarget.dataset.value, a = this.data.repeatFeedBack.find(function(e) {
            return e.value === t;
        });
        a && this.setData({
            curRepeatFeedBack: a
        }), i.default.success({
            message: "感谢你帮助腾讯混元助手做得更好"
        });
        var r = this.data, o = r.msgIndex, n = r.cid, d = r.msgCount, p = "qaCombined" === r.showType ? o + 1 : d - 1 - o;
        s.apis.conv.compareFeedback({
            idx: p,
            msg_idx: this.data.currentAnswerIndex,
            feedback: t,
            cid: n
        }).then(function(e) {
            console.log("忽略结果", e);
        }).catch(function(e) {
            console.log("反馈发生错误: ", e);
        });
    }, T.prototype.handleCopyPartial = function() {
        u.getCurrentPage().setData({
            copyMsg: f.default(this.data._rawTextMsg, {
                stripListLeaders: !0,
                listUnicodeChar: "○"
            })
        });
    }, T.prototype.handleSelectInstruct = function() {
        var t, a, r;
        this.setData({
            showActionMenu: !1
        });
        var s = this.properties.msg[this.data.currentAnswerIndex], i = s;
        "object" === e(s) && (s.type === p.MsgType.text ? i = s.msg : s.type === p.MsgType.image ? i = s.text : s.type === p.MsgType.goods && (i = s.preText + s.text));
        var o = u.getCurrentPage(), n = null == o ? void 0 : o.selectComponent("#chat-window");
        null == n || n.setData({
            showInstructs: !0
        }), null === (a = null == n ? void 0 : n.selectComponent("#custom-instruct")) || void 0 === a || a.handleAction({
            currentTarget: {
                dataset: {
                    actionType: "create"
                }
            }
        }), null === (r = null == n ? void 0 : n.selectComponent("#custom-instruct")) || void 0 === r || r.setData(((t = {})["formData.content"] = i, 
        t["formData.public"] = !0, t));
    }, T = r.__decorate([ n.wxComponent() ], T);
}(o.BaseComponent);

exports.ChatMsg = T;