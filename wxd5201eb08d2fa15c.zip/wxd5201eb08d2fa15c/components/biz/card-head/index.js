Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), r = require("../../../core/base/baseComponent"), a = require("../../../services/session/index");

function n(e) {
    var t = new Date(), r = new Date(e), a = t.getFullYear(), n = r.getFullYear(), o = t.getMonth(), s = r.getMonth(), i = t.getDate(), u = r.getDate(), l = [ "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" ][r.getDay()], g = r.getHours(), p = r.getMinutes(), c = (g > 9 ? g : "0" + g.toString()) + ":" + (p > 9 ? p : "0" + p.toString());
    return a === n ? o === s && i === u ? c : o === s && i - u == 1 ? "昨天 " + c : r.getTime() > function() {
        var e = new Date(), t = e.getDay(), r = 0 === t ? 6 : t - 1, a = new Date(e.getTime() - 24 * r * 60 * 60 * 1e3);
        return a.setHours(0, 0, 0, 0), a.getTime();
    }() ? l + " " + c : s + 1 + "月" + u + "日 " + c : n + "年 " + (s + 1) + "月" + u + "日 " + c;
}

var o = function(r) {
    function o() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            q: {
                type: String,
                value: ""
            },
            createTime: {
                type: Number,
                value: null,
                observer: function(e) {
                    e && this.setData({
                        date: n((null == e ? void 0 : e.toString().length) < 13 ? 1e3 * e : e)
                    });
                }
            },
            status: {
                type: String,
                value: "add",
                observer: function(e) {
                    "add" === e && this.setData({});
                }
            },
            userName: String,
            foldCard: {
                type: Boolean,
                value: !1
            },
            question: {
                type: String,
                value: ""
            },
            hideSplitLine: {
                type: Boolean,
                value: !1
            }
        }, e.data = {
            showToggleIcon: !0,
            userName: a.session.getUserName(),
            date: ""
        }, e;
    }
    return e.__extends(o, r), o.prototype.attached = function() {
        var e = this.properties.userName || a.session.getUserName();
        this.setData({
            userName: e
        });
    }, o.prototype.toggle = function() {
        this.triggerEvent("cardChange");
    }, o = e.__decorate([ t.wxComponent() ], o);
}(r.BaseComponent);

exports.default = o;