Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), r = function(r) {
    function n() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            show: {
                type: Boolean,
                value: !1
            },
            title: {
                type: String,
                value: ""
            },
            okText: {
                type: String,
                value: "继续生成"
            },
            cancelText: {
                type: String,
                value: "离开"
            }
        }, e;
    }
    return e.__extends(n, r), n.prototype.onChange = function(e) {
        var t = e.currentTarget.dataset.id;
        this.triggerEvent("retainAction", t);
    }, n = e.__decorate([ t.wxComponent() ], n);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.default = r;