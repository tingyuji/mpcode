Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), o = function(o) {
    function r() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            type: {
                type: String,
                value: "doc"
            },
            size: {
                type: String,
                value: "default"
            },
            fileSize: {
                type: Boolean,
                value: 0
            },
            title: String,
            fileType: String,
            filePath: {
                type: String,
                observer: function(e) {}
            },
            url: String,
            info: String
        }, e.data = {
            progress: 0,
            status: "done"
        }, e;
    }
    return e.__extends(r, o), r.prototype.abortUpload = function() {
        this.setData({
            status: "ready",
            progress: 0
        }), this.triggerEvent("uploadStatus", "cancel");
    }, r.prototype.reUpload = function() {}, r.prototype.onFileTap = function(t) {
        return e.__awaiter(this, void 0, void 0, function() {
            var o, r, n, i, s = this;
            return e.__generator(this, function(e) {
                if (console.log("file tapped", t), o = this.properties, r = o.filePath, n = o.url, 
                r) {
                    if (!r) return [ 2 ];
                    wx.openDocument({
                        filePath: r,
                        success: function() {
                            console.log("打开文档成功");
                        }
                    });
                } else i = n.indexOf("http") > -1 ? n : "https://" + n, wx.downloadFile({
                    url: i,
                    success: function(e) {
                        var t = null == e ? void 0 : e.tempFilePath;
                        wx.openDocument({
                            filePath: t,
                            success: function() {
                                console.log("打开文档成功");
                            },
                            fail: function(e) {
                                console.error("open pdf file failed", e);
                            }
                        }), s.triggerEvent("downloadStatus", "success");
                    },
                    fail: function(e) {
                        console.error(e), s.triggerEvent("downloadStatus", "fail");
                    }
                }).onProgressUpdate(function(e) {
                    var t = e.progress, o = void 0 === t ? 0 : t;
                    s.setData({
                        progress: o
                    });
                });
                return [ 2 ];
            });
        });
    }, r = e.__decorate([ t.wxComponent() ], r);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.default = o;