Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), r = require("../../../core/decorator/componentDecorator"), o = function(o) {
    function t() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            stop: !1,
            color: ""
        }, e;
    }
    return e.__extends(t, o), t = e.__decorate([ r.wxComponent() ], t);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.default = o;