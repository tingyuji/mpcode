Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), r = require("../../../core/base/baseComponent"), o = require("../../../services/session/index"), n = require("../../../common/http-client/index"), i = e.__importDefault(require("../../notify/notify")), s = require("../../../utils/helper"), a = require("../../../utils/openUrl"), u = require("../../../utils/prefetch"), c = function(r) {
    function c() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            show: {
                type: Boolean,
                value: !1,
                observer: function(e) {
                    this.setData({
                        showIntro: e
                    });
                }
            },
            userType: String
        }, e.data = {
            showIntro: !1,
            isAgree: !0
        }, e;
    }
    return e.__extends(c, r), c.prototype.getPhoneNumber = function(t) {
        return e.__awaiter(this, void 0, void 0, function() {
            var r = this;
            return e.__generator(this, function(e) {
                return t.detail.code || t.detail.iv ? (n.apis.session.getPhoneNumber({
                    phoneNumberCode: t.detail.code || "16763284582"
                }).then(function(e) {
                    console.error("获取手机号res:", e), r.triggerEvent("verifyPhoneNumber", {
                        status: e.status
                    }), o.session.setSessionValue("isAuthenticated", !0), u.memoizedGetConfig.reset();
                }).catch(function(e) {
                    console.error("获取手机号err:", e), i.default.error({
                        message: "授权手机号失败，请点击按钮重试"
                    });
                }), [ 2 ]) : [ 2 ];
            });
        });
    }, c.prototype.confirmIntro = function() {
        var e = this;
        this.setData({
            showIntro: !1
        });
        var t = "" + o.session.geWaterMarkString();
        n.apis.conv.getShareId({
            shareId: t,
            platform: "MINIPROGRAM",
            data: JSON.stringify({
                agreeUserRules: !0
            })
        }).then(function() {
            e.setData({
                show: !1
            });
        }).catch(function() {
            i.default.success({
                message: "同步出错，请重试"
            }), console.error("设置用户agreement信息出错");
        }), s.judgeShowWorkwxTips();
    }, c.prototype.handleCloseWarning = function() {}, c.prototype.cancelIntro = function() {
        "inner" === this.properties.type ? wx.exitMiniProgram() : this.triggerEvent("onRejectAgreement");
    }, c.prototype.onAgreementChange = function(e) {
        var t = -1 !== e.detail.value.indexOf("agree");
        this.setData({
            isAgree: t
        });
    }, c.prototype.handleAgreement = function(e) {
        switch (e.currentTarget.dataset.type) {
          case "service":
            a.openUrlByWebview(a.SERVICE_AGREEMENT_URL);
            break;

          case "private":
            a.openUrlByWebview(a.PRIVATE_AGREEMENT_URL);
            break;

          case "use":
            a.openUrlByWebview(a.USE_AGREEMENT_URL);
        }
    }, c = e.__decorate([ t.wxComponent() ], c);
}(r.BaseComponent);

exports.default = c;