Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = e.__importDefault(require("../../../common/storage")), a = require("../../../config/constants"), r = require("../../../core/decorator/componentDecorator"), s = require("../../../core/base/baseComponent"), n = require("../../../utils/prefetch"), i = require("../../../utils/report"), o = [], l = function(s) {
    function l() {
        var e = null !== s && s.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            showMask: Boolean,
            exampleList: Array
        }, e.data = {
            promptPreGet: !1,
            greetings: {
                welcome: "",
                lastChangePeriod: [ NaN, 1 / 0 ],
                intro: ""
            }
        }, e._data = {
            exampleOffset: 0,
            exampleLimit: 5
        }, e.pageLifetimes = {
            show: function() {
                this.getGreetings();
            }
        }, e;
    }
    return e.__extends(l, s), l.prototype.attached = function() {
        this.setExampleList(), this.getGreetings();
    }, l.prototype.setExampleList = function() {
        return e.__awaiter(this, void 0, void 0, function() {
            var r, s, i;
            return e.__generator(this, function(e) {
                switch (e.label) {
                  case 0:
                    return r = t.default.getSync(a.ALL_CONFIG_OLD), (s = null == r ? void 0 : r.promptExamples) && this.setData({
                        promptPreGet: !0
                    }), (i = s) ? [ 3, 2 ] : [ 4, n.memoizedGetConfig.call() ];

                  case 1:
                    i = e.sent().promptExamples, e.label = 2;

                  case 2:
                    return o = i, this.changeExample(), [ 2 ];
                }
            });
        });
    }, l.prototype.getGreetings = function() {
        var r;
        return e.__awaiter(this, void 0, void 0, function() {
            var s, i, o, l, g, p, c, u, m, h, d, f, _, v, x, C, E;
            return e.__generator(this, function(e) {
                switch (e.label) {
                  case 0:
                    return s = new Date(), i = s.getHours(), (o = this.data.greetings).lastChangePeriod && (l = o.lastChangePeriod, 
                    p = l[0], c = l[1], i >= p && i < c) ? [ 2 ] : (null === (r = global.greetingsSettings) || void 0 === r ? void 0 : r.lastChangePeriod) && (g = global.greetingsSettings.lastChangePeriod, 
                    p = g[0], c = g[1], i >= p && i < c) ? (this.setData({
                        greetings: global.greetingsSettings
                    }), [ 2 ]) : (u = t.default.getSync(a.ALL_CONFIG_OLD), m = null == u ? void 0 : u.greetings, 
                    (_ = m) ? [ 3, 2 ] : [ 4, n.memoizedGetConfig.call() ]);

                  case 1:
                    _ = e.sent().greetings, e.label = 2;

                  case 2:
                    return d = (h = _).welcomeMsgs, f = h.introduceMsgs, d.map(function(e) {
                        i >= e.start && i < e.end && (v = e);
                    }), x = Math.floor(Math.random() * v.msgs.length), C = Math.floor(Math.random() * f.length), 
                    E = {
                        welcome: v.msgs[x],
                        lastChangePeriod: [ v.start, v.end ],
                        intro: f[C]
                    }, global.greetingsSettings = E, this.setData({
                        greetings: E
                    }), [ 2 ];
                }
            });
        });
    }, l.prototype.changeExample = function() {
        var e, t = this._data, a = t.exampleLimit, r = t.exampleOffset, s = r + a;
        r < ((null == o ? void 0 : o.length) || 0) ? (e = o.slice(r, s), this._data.exampleOffset = s) : (e = o.slice(0, a), 
        this._data.exampleOffset = a), this.setData({
            exampleList: e
        }), i.tamEventReport({
            event: i.CustomEvents.CLICK_EXAMPLE_SWITCH
        });
    }, l.prototype.selectExample = function(e) {
        var t = e.currentTarget.dataset.value;
        this.triggerEvent("selectExample", t), i.tamEventReport({
            event: i.CustomEvents.CLICK_EXAMPLE_PROMPT,
            data: {
                prompt: t
            }
        });
    }, l.prototype.onMaskTap = function() {
        this.triggerEvent("onMaskTap");
    }, l = e.__decorate([ r.wxComponent() ], l);
}(s.BaseComponent);

exports.default = l;