Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), e = require("../../../config/constants"), a = require("../../../core/decorator/componentDecorator"), i = require("../../../core/base/baseComponent"), s = require("../../../common/http-client/index"), r = t.__importDefault(require("../../notify/notify")), n = require("../../../core/base/helpers/index"), o = require("../../../utils/helper"), d = require("../../../utils/report"), h = require("../../../utils/base"), l = require("../../../utils/rpx"), u = l.rpx2px(164), c = l.rpx2px(72), m = l.rpx2px(11), f = l.rpx2px(16);

var p = {
    name: "全部",
    id: ""
};

var v = h.debounce(function(e) {
    var a, i, r = e._this;
    r.data.searchText && r.setData({
        curTheme: p
    }), r.setData({
        instructs: [],
        isLoading: !0
    });
    var n = r.data.themeList.find(function(t) {
        return "默认" === t.name;
    }), o = r.data.searchText ? "" : (null === (i = null === (a = r.data) || void 0 === a ? void 0 : a.curTheme) || void 0 === i ? void 0 : i.id) || (null == n ? void 0 : n.id), d = {
        limit: r.data.limit,
        offset: r.data.offset,
        themeId: o,
        keyword: r.data.searchText
    };
    return s.apis.instruct.list(d).then(function(e) {
        var a, i = e.result, s = e.totalLength, o = e.themeList, d = r.data.instructs, h = (null == i ? void 0 : i.length) > 0 ? i : [], l = r.data.searchText ? p : (null === (a = r.data) || void 0 === a ? void 0 : a.curTheme) || n, u = r.data.searchText ? t.__spreadArray([ p ], o) : t.__spreadArray([], o);
        r.setData({
            instructs: t.__spreadArray(t.__spreadArray([], d), h),
            total: s,
            themeList: u,
            curTheme: l,
            isLoading: !1
        });
    }).catch(function(t) {
        r.setData({
            instructs: [],
            isLoading: !1
        }), console.error("获取指令错误", t);
    });
}, 500), g = function(i) {
    function h() {
        var e, a = null !== i && i.apply(this, arguments) || this;
        return a.externalClasses = [ "icon-class" ], a.properties = {}, a.data = {
            isStaff: !0,
            themeList: [],
            curTheme: {
                id: "",
                name: ""
            },
            instructs: [],
            offset: 0,
            limit: 10,
            formData: {
                themeInfo: {
                    id: "",
                    name: ""
                },
                title: "",
                content: "",
                public: !0
            },
            searchText: "",
            keyboardHeight: 0,
            popupType: "list",
            editType: "instruct",
            tagViewType: "list",
            modalTitle: "指令集",
            tag: "",
            themeDelList: [],
            themeRenderList: [],
            total: 0,
            showTitleLenErr: !1,
            themeErrorMsg: "",
            sysThemes: [],
            isLoading: !1,
            tagLen: 0,
            completeThemes: [],
            movableDisabled: !0,
            currentId: -1
        }, a.observers = ((e = {})["editType, popupType, completeThemes, tagViewType, themeDelList"] = function(e, a, i, s, r) {
            if ("list" === a && this.setData({
                modalTitle: "指令集"
            }), "create" === a && this.setData({
                modalTitle: "创建指令"
            }), "edit" === a && this.setData({
                modalTitle: "编辑指令"
            }), "tag" === e && this.setData({
                modalTitle: "指令分类"
            }), "delete" === s) {
                var n = this.data.themeRenderList, o = i.slice(1).filter(function(t) {
                    return !r.find(function(e) {
                        return e.id === t.id;
                    });
                });
                n = this.generateRectList(t.__spreadArray([], o)), this.setData({
                    themeRenderList: n
                });
            } else this.setData({
                themeRenderList: i.slice(1)
            });
        }, e), a.operations = {}, a;
    }
    return t.__extends(h, i), h.prototype.attached = function() {
        return t.__awaiter(this, void 0, void 0, function() {
            return t.__generator(this, function(t) {
                switch (t.label) {
                  case 0:
                    return [ 4, this.getThemeList() ];

                  case 1:
                    return t.sent(), [ 4, this.getInstructs() ];

                  case 2:
                    return t.sent(), this.setData({
                        isStaff: global[e.CURRENT_LOGIN_TYPE] !== e.LOGIN_USER_TYPE.outerUser
                    }), [ 2 ];
                }
            });
        });
    }, h.prototype.getThemeList = function(e) {
        return void 0 === e && (e = ""), t.__awaiter(this, void 0, void 0, function() {
            var a, i = this;
            return t.__generator(this, function(r) {
                return a = this.data.searchText ? [ p ] : [], [ 2, s.apis.theme.list().then(function(s) {
                    var r, n, o = s.result;
                    if ((null == o ? void 0 : o.length) > 0) {
                        var d = o.find(function(t) {
                            return "推荐" === t.name;
                        }), h = o.find(function(t) {
                            return "默认" === t.name;
                        });
                        if (i.setData({
                            themeList: t.__spreadArray(t.__spreadArray([], a), o),
                            curTheme: o[0],
                            sysThemes: [ d, h ],
                            completeThemes: o
                        }), i.data.formData.themeInfo.id || i.setData(((r = {})["formData.themeInfo"] = o[1], 
                        r)), e) {
                            var l = o.find(function(t) {
                                return t.name === e;
                            });
                            l && i.setData(((n = {})["formData.themeInfo"] = l, n.curTheme = l, n));
                        }
                    } else i.setData({
                        themeList: t.__spreadArray([], a)
                    });
                }).catch(function(t) {
                    console.error("获取主题错误", t);
                }) ];
            });
        });
    }, h.prototype.getCompleteThemes = function() {
        var t = this;
        s.apis.theme.list().then(function(e) {
            t.setData({
                completeThemes: e.result || []
            });
        });
    }, h.prototype.generateRectList = function(e) {
        for (var a = [], i = 0; i < e.length; i++) {
            var s, r;
            r = (c + f) * parseInt(i / 4) + l.rpx2px(48), s = (u + m) * (i % 4) + l.rpx2px(32);
            var n = t.__assign(t.__assign({}, e[i]), {
                x: s,
                y: r
            });
            a.push(n);
        }
        return console.log(a), this.setData({
            areaHeight: a.length / 4 * (c + f) + l.rpx2px(72)
        }), a;
    }, h.prototype.refreshLists = function(e) {
        var a = this, i = t.__spreadArray([], this.data.themeRenderList), s = null == i ? void 0 : i.find(function(t) {
            return t.id === a.data.currentId;
        }), r = (null == i ? void 0 : i.findIndex(function(t) {
            return t.id === e;
        })) || 0;
        if (s) return i.splice(this.originIndex, 1), i.splice(r, 0, s), this.operations.id = r + 1, 
        console.log(this.operations), i;
    }, h.prototype.createMovableObserver = function() {
        var t, e = this;
        null === (t = this.movableObserver) || void 0 === t || t.disconnect(), this.movableObserver = this.createIntersectionObserver({
            thresholds: [ .3 ],
            observeAll: !0
        }), this.movableObserver.relativeTo(".opeartor__tag.dragged").observe(".opeartor__tag.drag", function(t) {
            var a = t.intersectionRatio, i = t.dataset;
            console.log("intersectionRatio", a), a < .3 || 1 === a || (e.themeRenderList = e.refreshLists(i.id));
        });
    }, h.prototype.handleLongPress = function(t) {
        var e = this, a = t.currentTarget.dataset, i = a.id, s = a.index;
        this.originIndex = s, this.setData({
            movableDisabled: !1,
            currentId: i
        }, function() {
            e.createMovableObserver();
        });
    }, h.prototype.handleTouchEnd = function() {
        var t, e = this;
        this.data.movableDisabled || ((null === (t = this.themeRenderList) || void 0 === t ? void 0 : t.length) > 0 ? this.setData({
            themeRenderList: this.generateRectList(this.themeRenderList)
        }, function() {
            var t;
            null === (t = e.movableObserver) || void 0 === t || t.disconnect(), e.themeRenderList = [];
        }) : this.setData({
            themeRenderList: this.data.themeRenderList
        }), setTimeout(function() {
            e.setData({
                currentId: -1,
                movableDisabled: !0
            });
        }, 500));
    }, h.prototype.getInstructs = function() {
        var e;
        return t.__awaiter(this, void 0, void 0, function() {
            var a, i = this;
            return t.__generator(this, function(r) {
                return a = {
                    limit: this.data.limit,
                    offset: this.data.offset,
                    themeId: null === (e = this.data.curTheme) || void 0 === e ? void 0 : e.id,
                    keyword: this.data.searchText
                }, this.setData({
                    isLoading: !0
                }), [ 2, s.apis.instruct.list(a).then(function(e) {
                    var a = e.result, s = e.totalLength, r = e.themeList, n = i.data.instructs, o = (null == a ? void 0 : a.length) > 0 ? a : [], d = i.data.searchText ? t.__spreadArray([ p ], r) : t.__spreadArray([], r);
                    i.setData({
                        instructs: t.__spreadArray(t.__spreadArray([], n), o),
                        total: s,
                        themeList: d,
                        isLoading: !1
                    }, function() {
                        i.data.searchText && 0 === i.data.instructs.length && i.setData({
                            themeList: [ p ]
                        });
                    });
                }).catch(function(t) {
                    i.setData({
                        instructs: [],
                        isLoading: !1
                    }), console.error("获取指令错误", t);
                }) ];
            });
        });
    }, h.prototype.handleScrollBottom = function() {
        var t = this, e = this.data, a = e.offset, i = e.limit;
        a + i < e.total && this.setData({
            offset: a + i
        }, function() {
            t.getInstructs();
        });
    }, h.prototype.deleteInstruct = function(t) {
        var e = this;
        n.dialog.confirm({
            message: "确定删除所选指令?",
            confirmButtonText: "删除",
            cancelButtonText: "取消"
        }).then(function() {
            s.apis.instruct.delete({
                id: t
            }).then(function() {
                e.setData({
                    instructs: [],
                    offset: 0
                }), r.default.success({
                    message: "删除成功"
                }), e.setData({
                    popupType: "list"
                }), e.getInstructs();
            }).catch(function(t) {
                console.error("删除失败", t);
            });
        });
    }, h.prototype.selectTheme = function(t) {
        var e, a = t.currentTarget.dataset.id;
        if ((null === (e = this.data.curTheme) || void 0 === e ? void 0 : e.id) !== a) {
            var i = this.data.themeList.find(function(t) {
                return t.id === a;
            });
            this.setData({
                curTheme: i,
                offset: 0,
                instructs: []
            }), this.getInstructs();
        }
    }, h.prototype.handleInput = function(t) {
        var e = t.detail.value;
        if (this.setData({
            searchText: null == e ? void 0 : e.trim(),
            offset: 0
        }), !this.data.searchText && "全部" === this.data.themeList[0].name) {
            var a = this.data.sysThemes.find(function(t) {
                return "推荐" === t.name;
            });
            this.setData({
                curTheme: a
            });
        }
        v({
            _this: this
        });
    }, h.prototype.handleAction = function(e) {
        var a, i, s, r = e.currentTarget.dataset, n = r.id, o = r.actionType, d = this.data.instructs.find(function(t) {
            return t.id === n;
        }), h = t.__assign({}, d);
        if ("edit" === o) {
            var l = this.data.themeList.find(function(t) {
                return t.id === (null == h ? void 0 : h.themeId);
            });
            h.themeInfo = l;
        }
        this.setData({
            popupType: {
                edit: "edit",
                collect: "edit",
                delete: "list",
                list: "list",
                create: "create"
            }[o],
            formData: h
        });
        var u = this.data.sysThemes.find(function(t) {
            return "默认" === t.name;
        });
        "create" === o && (this.resetFormData(), this.setData(((a = {})["formData.themeInfo"] = "推荐" === (null === (s = this.data.curTheme) || void 0 === s ? void 0 : s.name) ? u : this.data.curTheme, 
        a))), "delete" === o && this.deleteInstruct(n), "collect" === o && this.setData(((i = {})["formData.id"] = "", 
        i["formData.themeInfo"] = u, i["formData.public"] = !0, i.curTheme = this.data.themeList[1], 
        i)), this.setData({
            editType: "instruct"
        });
    }, h.prototype.handleKeyboardHeight = function(t) {
        var e = t.detail.height;
        this.setData({
            keyboardHeight: 2 * e - 160
        });
    }, h.prototype.goBackToList = function() {
        "tag" === this.data.editType ? ("list" === this.data.tagViewType && this.setData({
            editType: "instruct"
        }), "create" !== this.data.tagViewType && "delete" !== this.data.tagViewType || this.setData({
            tagViewType: "list",
            themeDelList: []
        })) : (this.setData({
            offset: 0,
            instructs: [],
            showTitleLenErr: !1
        }), this.getInstructs(), this.setData({
            popupType: "list"
        }));
    }, h.prototype.handleSave = function() {
        var e, a, i, n, o = this;
        if ("tag" === this.data.editType) return this.handleCreateTag();
        if (null === (a = null === (e = this.data.formData) || void 0 === e ? void 0 : e.content) || void 0 === a ? void 0 : a.trim()) {
            var d = t.__assign({}, this.data.formData);
            d.themeId = d.themeInfo.id, d.content = null === (i = d.content) || void 0 === i ? void 0 : i.trim(), 
            d.title = null === (n = d.title) || void 0 === n ? void 0 : n.trim(), delete d.theme, 
            delete d.themeInfo, ("edit" === this.data.popupType && d.id ? s.apis.instruct.edit : s.apis.instruct.create)(d).then(function() {
                o.setData({
                    curTheme: o.data.formData.themeInfo || o.data.curTheme,
                    limit: 10,
                    offset: 0,
                    instructs: [],
                    showTitleLenErr: !1
                }, function() {
                    var t;
                    o.goBackToList(), o.setData({
                        scrollIntoViewId: "t" + (null === (t = o.data.curTheme) || void 0 === t ? void 0 : t.id)
                    });
                });
            }).catch(function(t) {
                console.error("创建指令出错： ", t);
            });
        } else r.default.error({
            message: "指令内容不能为空"
        });
    }, h.prototype.handleFormChange = function(e) {
        var a, i, s, r = e.detail.value, n = e.currentTarget.dataset, o = n.formType, d = n.themeId;
        switch (o) {
          case "instructContent":
            this.setData(((a = {})["formData.content"] = r, a));
            break;

          case "instructTitle":
            this.setData(((i = {})["formData.title"] = null == r ? void 0 : r.slice(0, 16), 
            i.showTitleLenErr = (null == r ? void 0 : r.length) > 16, i));
            break;

          case "theme":
            var h = this.data.completeThemes.find(function(t) {
                return t.id === d;
            });
            if ("推荐" === (null == h ? void 0 : h.name)) break;
            if ("delete" === this.data.tagViewType) {
                "默认" !== (null == h ? void 0 : h.name) && this.setData({
                    themeDelList: t.__spreadArray(t.__spreadArray([], this.data.themeDelList), [ h ])
                });
                break;
            }
            this.setData(((s = {})["formData.themeInfo"] = h, s.editType = "instruct", s));
            break;

          default:
            console.error("kong");
        }
    }, h.prototype.handleTogglePublic = function(t) {
        var e;
        this.setData(((e = {})["formData.public"] = t.detail.value, e));
    }, h.prototype.handleCloseModal = function() {
        var t = o.getCurrentPage(), e = null == t ? void 0 : t.selectComponent("#chat-window");
        e && e.setData({
            showInstructs: !1
        });
    }, h.prototype.changeEditType = function(t) {
        var e = t.currentTarget.dataset.type;
        this.setData({
            editType: e
        });
    }, h.prototype.handleTagInput = function(t) {
        var e = t.detail.value, a = function(t) {
            if (!t) return {
                len: 0,
                res: ""
            };
            for (var e = 0, a = "", i = 0; i < t.length; i++) {
                null !== t.charAt(i).match(/[^\x00-\xff]/gi) ? e += 1 : e += .5, e <= 4 && (a += t[i]);
            }
            return {
                len: e,
                res: a
            };
        }(null == e ? void 0 : e.trim()), i = a.len, s = a.res;
        this.setData({
            tag: s,
            tagLen: Math.floor(i),
            themeErrorMsg: i > 4 ? "输入已达上限" : ""
        });
    }, h.prototype.handleCreateTag = function() {
        var t, e, a = this;
        (null === (t = this.data.tag) || void 0 === t ? void 0 : t.trim()) ? this.data.themeList.find(function(t) {
            return t.name === a.data.tag;
        }) ? this.setData({
            themeErrorMsg: "分类已存在，请重新命名"
        }) : (null === (e = this.data.completeThemes) || void 0 === e ? void 0 : e.length) >= 30 ? r.default.error({
            message: "指令分类数量已达上限30个"
        }) : s.apis.theme.create({
            name: this.data.tag
        }).then(function(t) {
            console.log("res is: ", t), r.default.success({
                message: "指令分类新建成功"
            }), a.getThemeList(a.data.tag), a.setData({
                tagViewType: "list",
                tag: "",
                tagLen: 0
            }), a.getCompleteThemes();
        }).catch(function(t) {
            console.error("创建指令失败: ", t), r.default.error({
                message: "创建指令失败"
            });
        }) : this.setData({
            themeErrorMsg: "请输入分类名称"
        });
    }, h.prototype.handleDeleteTag = function() {
        var t = this, e = this.data, a = e.themeDelList, i = e.themeRenderList.slice(1);
        if (0 === (null == a ? void 0 : a.length) && 0 === i.length) return this.setData({
            tagViewType: "list"
        }), void r.default.success({
            message: "修改已保存"
        });
        n.dialog.confirm({
            title: "确定保存当前设置?",
            message: "系统检测到指令分类有调整，无归类指令将自动移至「默认」分类中",
            confirmButtonText: "确定",
            cancelButtonText: "取消"
        }).then(function() {
            var e = a.map(function(t) {
                return t.id;
            }), n = [];
            i.map(function(t) {
                n.push(t.id);
            });
            var o = [];
            e.length > 0 && o.push(s.apis.theme.delete({
                idList: e
            })), n.length > 0 && o.push(s.apis.theme.move({
                idList: n
            })), 0 !== o.length && Promise.all(o).then(function() {
                var e;
                if (r.default.success({
                    message: "修改已保存"
                }), t.data.themeDelList.find(function(e) {
                    var a, i;
                    return e.id === (null === (i = null === (a = t.data.formData) || void 0 === a ? void 0 : a.themeInfo) || void 0 === i ? void 0 : i.id);
                })) {
                    var a = t.data.themeList.find(function(t) {
                        return "默认" === t.name;
                    });
                    t.setData(((e = {})["formData.themeInfo"] = a, e.curTheme = a, e));
                }
                t.setData({
                    themeDelList: [],
                    tagViewType: "list",
                    offset: 0,
                    instructs: []
                }), t.getInstructs(), t.getCompleteThemes();
            }).catch(function() {
                r.default.error({
                    message: "保存指令分类错误"
                });
            });
        });
    }, h.prototype.toggleTagView = function(t) {
        var e = t.currentTarget.dataset.type;
        this.setData({
            tagViewType: e,
            tag: "",
            tagLen: 0
        });
    }, h.prototype.selectInstruct = function(t) {
        var e;
        this.handleCloseModal();
        var a = t.currentTarget.dataset, i = a.id, s = a.content, r = a.public, n = a.title, h = a.theme, l = a.themeId, u = this.data.instructs.find(function(t) {
            return t.id === i;
        }), c = o.getCurrentPage();
        null === (e = null == c ? void 0 : c.selectComponent("#chat-window")) || void 0 === e || e.selectComponent("#chat-input").setData({
            inputContent: null == u ? void 0 : u.content,
            inputPureContent: null == u ? void 0 : u.content
        }), d.tamEventReport({
            event: d.CustomEvents.CLICK_CUSTOM_PROMPT,
            data: {
                id: i,
                content: s,
                isPublic: r,
                title: n,
                theme: h,
                themeId: l
            }
        });
    }, h.prototype.checkAndScroll = function() {}, h.prototype.resetFormData = function() {
        this.setData({
            formData: {
                theme: this.data.curTheme,
                title: "",
                content: "",
                public: !0
            }
        });
    }, h = t.__decorate([ a.wxComponent() ], h);
}(i.BaseComponent);

exports.default = g;