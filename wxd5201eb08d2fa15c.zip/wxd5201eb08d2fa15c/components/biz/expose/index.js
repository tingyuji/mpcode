Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CommonExposeContainer = void 0;

var e = require("tslib"), o = require("../../../core/decorator/componentDecorator"), t = function(t) {
    function r() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.properties = {
            appendData: Object,
            stopObserveOnExpose: {
                type: Boolean,
                value: !0
            }
        }, e.externalClasses = [ "wr-class" ], e;
    }
    return e.__extends(r, t), r.prototype.ready = function() {
        this.doObserve();
    }, r.prototype.detached = function() {
        this.stopObserve();
    }, r.prototype.doObserve = function() {
        var o = this;
        this._observer = this.createIntersectionObserver({
            thresholds: [ .34 ]
        }), this._observer.relativeToViewport().observe(".expose-container", function(t) {
            var r = o.properties.appendData;
            o.triggerEvent("onCompExpose", e.__assign(e.__assign({}, r || {}), {
                intersectionRatio: t.intersectionRatio
            }), {
                bubbles: !0,
                composed: !0
            }), o.properties.stopObserveOnExpose && o.stopObserve();
        });
    }, r.prototype.stopObserve = function() {
        this._observer && (this._observer.disconnect(), this._observer = null);
    }, r = e.__decorate([ o.wxComponent() ], r);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.CommonExposeContainer = t;