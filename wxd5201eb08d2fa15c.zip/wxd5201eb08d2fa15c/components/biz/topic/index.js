Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), r = require("../../../core/base/baseComponent"), n = require("../../../utils/prefetch"), i = e.__importDefault(require("../../../common/navigator")), a = require("../../../utils/report"), o = function(r) {
    function o() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.properties = {
            name: {
                type: String,
                require: !0,
                observer: function(e) {
                    this.setData({
                        isImageName: -1 !== e.indexOf("/")
                    });
                }
            },
            classPrefix: {
                type: String,
                value: "icon"
            },
            size: {
                type: null,
                value: 24
            },
            color: {
                type: String,
                value: "currentColor"
            },
            info: String,
            customStyle: String
        }, e.data = {
            currentKey: 0,
            list: [ {
                text: "全部",
                key: 0
            } ]
        }, e;
    }
    return e.__extends(o, r), o.prototype.attached = function() {
        this.init();
    }, o.prototype.init = function() {
        return e.__awaiter(this, void 0, void 0, function() {
            var t, r, i, a, o, s;
            return e.__generator(this, function(e) {
                switch (e.label) {
                  case 0:
                    return t = [ {
                        text: "全部",
                        key: 0
                    } ], [ 4, n.memoizedGetConfig.call() ];

                  case 1:
                    return r = e.sent() || {}, i = r.inspirations, a = void 0 === i ? [] : i, o = r.inspirationTags, 
                    (s = void 0 === o ? [] : o).length > 0 && s.map(function(e, r) {
                        t.push({
                            text: e,
                            key: ++r
                        });
                    }), this.setData({
                        inspirations: a,
                        list: t
                    }), [ 2 ];
                }
            });
        });
    }, o.prototype.tabChange = function(e) {
        var t = e.detail;
        this.setData({
            currentKey: t
        });
        var r = this.data.list[t].text;
        a.tamEventReport({
            event: a.CustomEvents.CLICK_INSPIRE_TOPIC,
            data: {
                index: t,
                inspireTag: r
            }
        });
    }, o.prototype.handleTopicTap = function(e) {
        var t = e.currentTarget.dataset, r = t.id, n = t.tag, o = t.scene, s = {
            templateId: r,
            homePageMode: !1
        };
        a.tamEventReport({
            event: a.CustomEvents.CLICK_INSPIRE_SCENE,
            data: {
                inspireTag: n,
                sceneName: o,
                sceneId: r
            }
        }), i.default.gotoPage("home", s);
    }, o = e.__decorate([ t.wxComponent() ], o);
}(r.BaseComponent);

exports.default = o;