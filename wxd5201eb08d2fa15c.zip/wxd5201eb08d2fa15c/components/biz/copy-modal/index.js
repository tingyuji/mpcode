Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), o = require("../../../core/base/baseComponent"), r = require("../../../utils/helper"), s = function(o) {
    function s() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            msg: {
                type: String,
                value: "",
                observer: function(e) {
                    console.log("传递的复制内容是: ", e), this.setData({
                        show: !!e
                    });
                }
            }
        }, e.data = {
            inputFocus: !1,
            keyboardOffsetY: 0,
            show: !1
        }, e;
    }
    return e.__extends(s, o), s.prototype.onInputFocus = function() {
        this.setData({
            inputFocus: !0
        });
    }, s.prototype.onKeyboardHeightChange = function(e) {
        try {
            var t = (null == e ? void 0 : e.detail).height;
            if (console.log("键盘高度是: ", t), null == t) return;
            this.setData({
                keyboardOffsetY: t || 0
            });
        } catch (e) {
            console.error(e);
        }
    }, s.prototype.handleClose = function() {
        this.setData({
            show: !1,
            inputFocus: !1,
            keyboardOffsetY: 0
        }), r.getCurrentPage().setData({
            copyMsg: ""
        });
    }, s = e.__decorate([ t.wxComponent() ], s);
}(o.BaseComponent);

exports.default = s;