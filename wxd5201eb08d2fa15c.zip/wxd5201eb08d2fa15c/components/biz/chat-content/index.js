require("../../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatContent = void 0;

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), o = require("../../../core/base/baseComponent"), n = require("../../../config/constants"), i = e.__importDefault(require("../../notify/notify")), r = function(o) {
    function r() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.properties = {
            shareMode: Boolean,
            shareUserName: String,
            chatId: {
                type: String,
                value: "chat-msgs-scroll-view"
            },
            convId: {
                type: String,
                value: ""
            },
            convStatus: {
                type: String,
                value: n.CONV_STREAM_TYPE.DONE
            },
            convList: {
                type: Array,
                value: []
            },
            showSliceHistory: Boolean,
            mode: {
                type: String,
                value: n.CHAT_MODE_TYPE.NORMAL
            },
            selectedList: {
                type: Array,
                value: []
            },
            show: {
                type: Boolean,
                value: !1
            },
            chatIcon: {
                type: String,
                value: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo-s2.png"
            },
            chatName: {
                type: String,
                value: "腾讯混元助手"
            },
            chatStatus: {
                type: String,
                value: ""
            }
        }, e.data = {
            listMinHeight: "100vh",
            showFeedback: !1,
            feedbackType: "",
            selectedMsgInfo: {}
        }, e;
    }
    return e.__extends(r, o), r.prototype.ready = function() {
        var e = this;
        setTimeout(function() {
            e.setData({
                listMinHeight: "auto"
            });
        }, 50);
    }, r.prototype.toggleMsgSelect = function(e) {
        if (this.data.mode === n.CHAT_MODE_TYPE.SELECT) {
            var t = this.data.selectedList, o = e.currentTarget.dataset.index, i = o % 2 == 0 ? o + 1 : o - 1;
            if (t.includes(o)) t = t.filter(function(e) {
                return e != o && e != i;
            }); else {
                var r = [ o, i ].sort();
                t.push.apply(t, r);
            }
            this.triggerEvent("onMsgSelect", {
                selectedList: t
            });
        }
    }, r.prototype.handleCloseFeedback = function() {
        this.setData({
            showFeedback: !1
        });
    }, r.prototype.reChat = function() {
        this.triggerEvent("onRegenerate");
    }, r.prototype.handleShareSingleMsg = function(t) {
        return e.__awaiter(this, void 0, void 0, function() {
            var o, n;
            return e.__generator(this, function(e) {
                return "CHATTING" === this.data.chatStatus ? (i.default.info({
                    message: "有模型正在生成内容中，请稍后重试～"
                }), [ 2 ]) : (o = t.detail.index, n = [ o, o % 2 == 0 ? o + 1 : o - 1 ].sort(), 
                [ 2, this.triggerEvent("onShare", {
                    selectedList: n
                }) ]);
            });
        });
    }, r.prototype.handleSetSelectMode = function(e) {
        var t = this;
        setTimeout(function() {
            var o = e.currentTarget.dataset.index, n = [ o, o % 2 == 0 ? o + 1 : o - 1 ].sort();
            t.triggerEvent("onMsgSelect", {
                selectedList: n
            });
        }, 30), this.triggerEvent("onModeSelect", {
            mode: n.CHAT_MODE_TYPE.SELECT
        });
    }, r.prototype.handleOpenFeedbackWindow = function(e) {
        var t, o, n, i = this.data.convList, r = e.detail, a = r.type, s = r.msgIndex, c = r.cid, d = r.msgCount, l = r.currentAnswerIndex, u = {
            msgIndex: s,
            cid: c,
            msgCount: d,
            currentAnswerIndex: l,
            imageList: (null === (t = null == i ? void 0 : i[s].speeches) || void 0 === t ? void 0 : t[l]).images ? (null === (o = i[s].speeches) || void 0 === o ? void 0 : o[l]).images.map(function(e) {
                return e.highDefImageUrl;
            }) : [],
            goodsList: (null === (n = null == i ? void 0 : i[s].speeches) || void 0 === n ? void 0 : n[l]).goods || []
        };
        this.setData({
            selectedMsgInfo: u,
            showFeedback: !0,
            feedbackType: a
        });
    }, r.prototype.handleLongPress = function(e) {
        this.triggerEvent("onMsgLongPress", e.detail);
    }, r.prototype.hideActionMenu = function(e) {
        var t;
        null === (t = this.selectComponent("#chat-msgs-scroll-view-" + this.data.chatId + "-" + e)) || void 0 === t || t.hideActionMenu();
    }, r.prototype.getScrollViewAndScroll = function() {
        var e = this;
        this.createSelectorQuery().select("#chat-msgs-scroll-view-" + this.data.chatId).node().exec(function(t) {
            var o, n = null === (o = null == t ? void 0 : t[0]) || void 0 === o ? void 0 : o.node;
            n && (n.scrollTo({
                top: 0
            }), e.chatScrollView = n);
        });
    }, r.prototype.handleNewSession = function() {
        var e = getCurrentPages(), t = e[e.length - 1];
        wx.redirectTo({
            url: "/" + t.route + "?modelIds=" + t.options.modelIds + "&t=" + Date.now()
        });
    }, r.prototype.handleUpdateFeedBack = function(t) {
        this.triggerEvent("updateFeedBack", e.__assign({}, t.detail));
    }, r.prototype.continueChat = function() {
        this.triggerEvent("continueChat", {
            chatId: this.data.chatId
        });
    }, r = e.__decorate([ t.wxComponent() ], r);
}(o.BaseComponent);

exports.ChatContent = r;