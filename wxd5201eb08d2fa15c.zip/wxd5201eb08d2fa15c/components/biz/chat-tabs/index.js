Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatTabs = void 0;

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), r = function(r) {
    function o() {
        var e = null !== r && r.apply(this, arguments) || this;
        return e.properties = {
            tabs: {
                type: Array,
                value: []
            },
            activeTab: {
                type: String,
                value: "1"
            },
            chatShareNum: {
                type: Number,
                value: 0
            }
        }, e.data = {
            showModelList: !1
        }, e;
    }
    return e.__extends(o, r), o.prototype.onModelListShow = function() {}, o.prototype.onTabChange = function(e) {
        this.triggerEvent("onTabChange", {
            current: e.currentTarget.dataset.tabItem.key
        });
    }, o = e.__decorate([ t.wxComponent() ], o);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.ChatTabs = r;