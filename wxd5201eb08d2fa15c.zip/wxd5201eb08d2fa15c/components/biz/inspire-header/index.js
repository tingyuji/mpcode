Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.InspireHeader = void 0;

var t = require("tslib"), e = t.__importDefault(require("../../notify/notify")), n = require("../../../config/constants"), o = require("../../../core/base/baseComponent"), i = require("../../../core/base/helpers/index"), a = require("../../../core/decorator/componentDecorator"), r = require("../../../interface/type"), s = function(o) {
    function s() {
        var t, e = null !== o && o.apply(this, arguments) || this;
        return e.properties = {
            mode: {
                type: String,
                value: n.CHAT_MODE_TYPE.NORMAL
            },
            convStatus: {
                type: String,
                value: n.CONV_STREAM_TYPE.DONE
            },
            convList: {
                type: Array,
                value: []
            },
            chatId: {
                type: String,
                value: ""
            },
            selectedList: {
                type: Array,
                value: []
            },
            convId: {
                type: String,
                value: ""
            },
            inspireInfo: {
                type: Object,
                value: null
            },
            shareMode: Boolean,
            chatQuota: {
                type: Number,
                value: -1
            }
        }, e.data = {
            selectedPrompt: null,
            inputContent: "",
            inputPureContent: "",
            inputFocus: !1,
            actionType: r.ChatBtnActions.noContent,
            btnName: "开始生成"
        }, e.observers = ((t = {}).inputContent = function(t) {
            this.setData({
                inputPureContent: t.trim(),
                actionType: t.trim() ? r.ChatBtnActions.ready : r.ChatBtnActions.noContent,
                btnName: "开始生成"
            });
        }, t.convStatus = function(t) {
            var e = r.ChatBtnActions.noContent, o = "开始生成";
            t === n.CONV_STREAM_TYPE.ADD ? (e = r.ChatBtnActions.doing, o = "停止生成") : t === n.CONV_STREAM_TYPE.SENSITIVE_DONE ? (e = r.ChatBtnActions.disabled, 
            o = "开始生成") : t !== n.CONV_STREAM_TYPE.ERROR && t !== n.CONV_STREAM_TYPE.DONE || !this.data.inputPureContent || (e = r.ChatBtnActions.repeat, 
            o = "重新生成"), this.setData({
                actionType: e,
                btnName: o
            });
        }, t), e;
    }
    return t.__extends(s, o), s.prototype.selectPresetPrompt = function() {
        if (this.properties.convStatus === n.CONV_STREAM_TYPE.DONE && 0 !== this.data.chatQuota) {
            var t = this.properties.inspireInfo.prompts, e = this.data.selectedPrompt, o = 0;
            null !== e && (o = (t.findIndex(function(t) {
                return t === e;
            }) + 1) % t.length), this.setData({
                _selectedIndex: o,
                selectedPrompt: t[o],
                inputContent: t[o]
            });
        }
    }, s.prototype.onInputChange = function(t) {
        if (this.properties.convStatus !== n.CONV_STREAM_TYPE.SENSITIVE_DONE) {
            var e = t.detail.value;
            this.setData({
                inputContent: e
            });
        }
    }, s.prototype.onSend = function() {
        var t = this.data, o = t.actionType, i = t.inputPureContent;
        if (o === r.ChatBtnActions.doing) return this.setData({
            actionType: r.ChatBtnActions.stopping,
            btnName: "停止中..."
        }), void this.triggerEvent("onChatStop");
        o !== r.ChatBtnActions.stopping && o !== r.ChatBtnActions.noContent && o !== r.ChatBtnActions.disabled && (this.properties.convList.length >= 2 * n.CHAT_MAX_ROUND ? e.default.error({
            message: "本次会话回合数已达上限",
            duration: 1500
        }) : 0 !== this.data.chatQuota ? (this.triggerEvent("onSend", {
            value: i,
            isRepeat: o === r.ChatBtnActions.repeat
        }), wx.hideKeyboard()) : e.default.info({
            message: "今日提问次数已达上限，请明日再试"
        }));
    }, s.prototype.clearInput = function() {
        this.properties.convStatus !== n.CONV_STREAM_TYPE.SENSITIVE_DONE && this.setData({
            inputContent: ""
        });
    }, s.prototype.handleTipModal = function() {
        var t = this.properties.inspireInfo.hint;
        i.dialog.confirm({
            title: "完整指令",
            message: t,
            confirmButtonText: "复制",
            cancelButtonText: "取消",
            textAlign: "left"
        }).then(function() {
            wx.setClipboardData({
                data: t,
                success: function() {}
            });
        });
    }, s = t.__decorate([ a.wxComponent() ], s);
}(o.BaseComponent);

exports.InspireHeader = s;