Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), s = require("../../../core/decorator/componentDecorator"), e = function(e) {
    function a() {
        var s = null !== e && e.apply(this, arguments) || this;
        return s.externalClasses = [ "icon-class" ], s.properties = {
            type: {
                type: String,
                value: "step"
            },
            step: {
                type: Object,
                value: null,
                observer: function(s) {
                    var e = this;
                    if (s) {
                        var a = t.__spreadArray([], this.data.stepList).map(function(t) {
                            return t.msg === s.msg && (t.status = s.status), t;
                        });
                        this.setData({
                            stepList: a
                        });
                        var r = a.find(function(t) {
                            return t.msg === s.msg;
                        });
                        r && this.setData({
                            curStep: t.__assign(t.__assign({}, r), {
                                msg: s.msg,
                                status: s.status
                            })
                        }, function() {
                            var t;
                            "failed" === (null === (t = e.data.curStep) || void 0 === t ? void 0 : t.status) && e.setData({
                                isFold: !0
                            });
                        });
                    }
                }
            }
        }, s.data = {
            stepList: [ {
                label: "提取内容信息",
                msg: "pdf_parse",
                status: "",
                order: 0
            }, {
                label: "处理图片内容",
                msg: "ocr",
                status: "",
                order: 1
            }, {
                label: "处理文本内容",
                msg: "slice",
                status: "",
                order: 2
            }, {
                label: "提炼核心信息",
                msg: "extract",
                status: "",
                order: 3
            }, {
                label: "整理合并摘要",
                msg: "summary",
                status: "",
                order: 4
            } ],
            curStep: {
                label: "提取内容信息",
                msg: "pdf_parse",
                status: "",
                order: 0
            },
            isFold: !1
        }, s;
    }
    return t.__extends(a, e), a.prototype.togglePanel = function() {
        this.setData({
            isFold: !this.data.isFold
        });
    }, a = t.__decorate([ s.wxComponent() ], a);
}(require("../../../core/base/baseComponent").BaseComponent);

exports.default = e;