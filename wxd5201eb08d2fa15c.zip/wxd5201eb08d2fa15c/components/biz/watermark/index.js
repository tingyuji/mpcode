Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), r = require("../../../core/decorator/componentDecorator"), t = require("../../../core/base/baseComponent"), s = require("../../../services/session/index"), n = require("../../../services/session/libs/authLogin"), i = function(t) {
    function i() {
        var r = null !== t && t.apply(this, arguments) || this;
        return r.properties = {
            zIndex: -1
        }, r.data = {
            userName: ""
        }, r.pageLifetimes = {
            show: function() {
                return e.__awaiter(this, void 0, void 0, function() {
                    var r;
                    return e.__generator(this, function(e) {
                        switch (e.label) {
                          case 0:
                            return (r = s.session.geWaterMarkString()) ? [ 3, 2 ] : [ 4, n.authLogin.refreshLogin() ];

                          case 1:
                            e.sent(), r = s.session.geWaterMarkString(), e.label = 2;

                          case 2:
                            return this.setData({
                                userName: r
                            }), [ 2 ];
                        }
                    });
                });
            }
        }, r;
    }
    return e.__extends(i, t), i = e.__decorate([ r.wxComponent() ], i);
}(t.BaseComponent);

exports.default = i;