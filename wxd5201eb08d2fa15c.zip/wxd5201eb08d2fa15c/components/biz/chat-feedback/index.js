Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../../../core/decorator/componentDecorator"), a = require("../../../core/base/baseComponent"), n = require("../../../config/constants"), i = require("../../../common/http-client/index"), o = e.__importDefault(require("../../notify/notify")), r = require("../../../interface/type"), s = require("../../../utils/prefetch"), c = function(a) {
    function c() {
        var e = null !== a && a.apply(this, arguments) || this;
        return e.externalClasses = [ "icon-class" ], e.properties = {
            show: Boolean,
            type: {
                type: Number,
                value: 0,
                observer: function(e) {
                    this.setData({
                        feedBackWindowType: e
                    });
                }
            },
            msgInfo: {
                type: Object,
                value: {}
            }
        }, e.data = {
            CHAT_FEEDBACK_ARRAY: n.CHAT_TEXT_FEEDBACK_MAP_V2,
            CHAT_IMG_FEEDBACK_ARRAY: n.CHAT_IMG_FEEDBACK_MAP_V2,
            CHAT_GOODS_FEEDBACK_MAP: n.CHAT_GOODS_FEEDBACK_MAP,
            feedBackWindowType: r.ChatComment.up,
            feedBackData: {
                idMap: {},
                ids: "",
                message: "",
                imgIdx: -1
            },
            inputFocus: !1
        }, e;
    }
    return e.__extends(c, a), c.prototype.attached = function() {
        return e.__awaiter(this, void 0, void 0, function() {
            var t, a, n, i, o;
            return e.__generator(this, function(e) {
                switch (e.label) {
                  case 0:
                    return [ 4, s.memoizedGetConfig.call() ];

                  case 1:
                    return t = e.sent().feedbackCodeConfigV2, a = t.text2imageFeedbackCode, n = t.text2textFeedbackCode, 
                    i = null == n ? void 0 : n.map(function(e) {
                        return {
                            title: e.title,
                            type: e.type,
                            value: Object.keys(e.code || {}).map(function(t) {
                                return {
                                    id: t,
                                    text: e.code[t],
                                    type: e.type
                                };
                            })
                        };
                    }), o = null == a ? void 0 : a.map(function(e) {
                        return {
                            title: e.title,
                            type: e.type,
                            value: Object.keys(e.code || {}).map(function(t) {
                                return {
                                    id: t,
                                    text: e.code[t],
                                    type: e.type
                                };
                            })
                        };
                    }), this.setData({
                        CHAT_FEEDBACK_ARRAY: i,
                        CHAT_IMG_FEEDBACK_ARRAY: o
                    }), [ 2 ];
                }
            });
        });
    }, c.prototype.onInputFocus = function() {
        this.setData({
            inputFocus: !0
        });
    }, c.prototype.onInputBlur = function() {
        this.setData({
            inputFocus: !1
        }), wx.hideKeyboard();
    }, c.prototype.handleDetailFeedBackTap = function(e) {
        var t = e.currentTarget.dataset.id, a = this.data.feedBackData.idMap;
        a[t] = !a[t];
        var n = Object.keys(a).filter(function(e) {
            return a[e];
        });
        this.setData({
            "feedBackData.idMap": a,
            "feedBackData.ids": n
        });
    }, c.prototype.onImgSelect = function(e) {
        var t = e.currentTarget.dataset.index;
        this.setData({
            "feedBackData.imgIdx": t
        });
    }, c.prototype.handleDetailFeedBackInput = function(e) {
        this.setData({
            "feedBackData.message": e.detail.value
        });
    }, c.prototype.sendDetailFeedBack = function() {
        var e = this, t = this.data.feedBackData, a = t.idMap, n = t.message, r = t.imgIdx, s = Object.keys(a).filter(function(e) {
            return a[e];
        });
        if (s || n) {
            var c = this.properties.msgInfo, d = c.msgIndex, u = c.cid, p = c.msgCount, f = c.currentAnswerIndex, l = c.qaCombined ? d + 1 : p - 1 - d;
            i.apis.conv.detailedFeedback({
                idx: l,
                msg_idx: f,
                img_idx: r,
                categories: s.map(function(e) {
                    return parseInt(e);
                }),
                message: n,
                cid: u
            }).then(function() {
                o.default.success({
                    message: "感谢您的反馈"
                }), e.closeFeedBack();
            }).catch(function(t) {
                console.error(t), o.default.error({
                    message: "反馈失败，请重新提交"
                }), e.closeFeedBack();
            });
        }
    }, c.prototype.closeFeedBack = function() {
        this.setData({
            feedBackData: {
                idMap: {},
                ids: "",
                message: ""
            }
        }), this.triggerEvent("closeDetailFeedBack");
    }, c = e.__decorate([ t.wxComponent() ], c);
}(a.BaseComponent);

exports.default = c;