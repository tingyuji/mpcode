Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), e = require("@tencent/retailwe-ui-common/index"), o = [], n = function(n) {
    function i() {
        var t = null !== n && n.apply(this, arguments) || this;
        return t.externalClasses = [ "wr-class" ], t.options = {
            multipleSlots: !0
        }, t.properties = {
            disabled: Boolean,
            leftWidth: {
                type: Number,
                value: 0
            },
            rightWidth: {
                type: Number,
                value: 0
            },
            asyncClose: Boolean,
            name: {
                type: [ Number, String ],
                value: ""
            }
        }, t.data = {
            wrapperStyle: "",
            asyncClose: !1,
            closed: !0
        }, t;
    }
    return t.__extends(i, n), i.prototype.attached = function() {
        o.push(this);
    }, i.prototype.detached = function() {
        var t = this;
        o = o.filter(function(e) {
            return e !== t;
        });
    }, i.prototype.open = function(t) {
        this.setData({
            closed: !1
        }), this.triggerEvent("close", {
            position: t,
            instance: this,
            name: this.properties.name
        });
    }, i.prototype.close = function() {
        this.setData({
            closed: !0
        });
    }, i.prototype.closeOther = function() {
        var t = this;
        o.filter(function(e) {
            return e !== t;
        }).forEach(function(t) {
            return t.close();
        });
    }, i.prototype.noop = function() {}, i.prototype.onClick = function(t) {
        var e = t.currentTarget.dataset.key, o = void 0 === e ? "outside" : e;
        this.triggerEvent("click", o), this.data.closed || (this.data.asyncClose ? this.triggerEvent("close", {
            position: o,
            instance: this,
            name: this.properties.name
        }) : this.close());
    }, i = t.__decorate([ e.wxComponent() ], i);
}(e.SuperComponent);

exports.default = n;