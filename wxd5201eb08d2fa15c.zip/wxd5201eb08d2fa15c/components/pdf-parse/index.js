require("../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PdfParse = void 0;

var e = require("tslib"), t = require("../../core/decorator/componentDecorator"), i = require("../../core/base/baseComponent"), n = require("../../core/base/helpers/index"), r = e.__importDefault(require("../notify/notify")), o = "prepare", a = "ready", s = "working", l = "repeat", p = function(i) {
    function p() {
        var e = null !== i && i.apply(this, arguments) || this;
        return e.properties = {
            step: {
                type: Object,
                value: null
            },
            mode: {
                type: String,
                value: ""
            },
            userName: {
                type: String,
                value: ""
            },
            presetFiles: Array,
            inHistory: {
                type: Boolean,
                value: !1
            },
            convStatus: {
                type: String,
                value: ""
            }
        }, e.data = {
            _selectedFile: null,
            curFile: null,
            actionType: o,
            inHistory: !1,
            isUploading: !1
        }, e.observers = {}, e;
    }
    return e.__extends(p, i), p.prototype.doImportFile = function() {
        var e = this;
        return new Promise(function(t) {
            wx.chooseMessageFile({
                count: 1,
                type: "file",
                extension: [ "pdf" ],
                success: function(i) {
                    var n, a = i.errMsg, s = i.tempFiles, l = (null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.size) / 1048576 > 10;
                    a.includes(":ok") && (null == s ? void 0 : s.length) > 0 && !l ? e.setData({
                        curFile: s[0],
                        actionType: o,
                        isUploading: !0,
                        inHistory: !1
                    }, function() {
                        t(!0);
                    }) : l && r.default.info({
                        message: "目前仅支持10M以内的文件"
                    });
                },
                fail: function(e) {
                    console.log("err is: ", e);
                }
            });
        });
    }, p.prototype.selectPresetFile = function() {
        var t = this, i = this.data._selectedFile, r = 0;
        null !== i && (r = (this.properties.presetFiles.findIndex(function(e) {
            return e.url === i.url;
        }) + 1) % this.properties.presetFiles.length);
        var o = this.properties.presetFiles[r];
        this.data.actionType === l ? n.dialog.confirm({
            title: "确认要更换文档吗？",
            message: "更换文档后，原有文档的总结内容将保存在历史记录中",
            cancelButtonText: "取消",
            confirmButtonText: "重新选择"
        }).then(function() {
            t.setData({
                actionType: a,
                curFile: e.__assign(e.__assign({}, o), {
                    name: o.fileName,
                    size: o.size
                }),
                _selectedFile: o,
                inHistory: !1
            }, function() {
                t.triggerEvent("parseAction", {
                    prompt: "",
                    eventType: "replaceFile",
                    curFile: t.data.curFile
                });
            });
        }) : this.setData({
            actionType: a,
            curFile: e.__assign(e.__assign({}, o), {
                name: o.fileName,
                size: o.size
            }),
            _selectedFile: o,
            inHistory: !1
        }, function() {
            t.triggerEvent("parseAction", {
                prompt: "",
                eventType: "replaceFile",
                curFile: t.data.curFile
            });
        });
    }, p.prototype.reImportFile = function() {
        return e.__awaiter(this, void 0, void 0, function() {
            var t = this;
            return e.__generator(this, function(i) {
                switch (i.label) {
                  case 0:
                    return this.data.actionType !== l ? [ 3, 1 ] : (n.dialog.confirm({
                        title: "确认要更换文档吗？",
                        message: "更换文档后，原有文档的总结内容将保存在历史记录中",
                        cancelButtonText: "取消",
                        confirmButtonText: "重新选择"
                    }).then(function() {
                        return e.__awaiter(t, void 0, void 0, function() {
                            return e.__generator(this, function(e) {
                                switch (e.label) {
                                  case 0:
                                    return [ 4, this.doImportFile() ];

                                  case 1:
                                    return e.sent() && this.triggerEvent("parseAction", {
                                        prompt: "",
                                        eventType: "replaceFile",
                                        curFile: this.data.curFile
                                    }), [ 2 ];
                                }
                            });
                        });
                    }), [ 3, 3 ]);

                  case 1:
                    return [ 4, this.doImportFile() ];

                  case 2:
                    i.sent() && this.triggerEvent("parseAction", {
                        prompt: "",
                        eventType: "replaceFile",
                        curFile: this.data.curFile
                    }), i.label = 3;

                  case 3:
                    return [ 2 ];
                }
            });
        });
    }, p.prototype.onChat = function() {
        this.setData({
            actionType: s
        }), this.triggerEvent("parseAction", {
            prompt: "请帮我总结一下这篇pdf",
            eventType: "onChat"
        });
    }, p.prototype.onStopChat = function() {
        this.triggerEvent("parseAction", {
            prompt: "",
            eventType: "onStopChat"
        });
    }, p.prototype.onReChat = function() {
        this.setData({
            actionType: s
        }), this.triggerEvent("parseAction", {
            prompt: "",
            eventType: "onReChat"
        });
    }, p.prototype.onUploadStatusChange = function(e) {
        var t, i = e.detail, n = i.status, o = i.url;
        "success" === n ? this.setData(((t = {
            actionType: a
        })["curFile.url"] = o, t)) : r.default.info({
            message: "网络异常，文件上传失败"
        }), this.setData({
            isUploading: !1
        });
    }, p.prototype.onDownloadStatusChange = function(e) {
        "fail" === e.detail && r.default.info({
            message: "文件下载失败"
        });
    }, p.prototype.handleTipModal = function() {
        var e = "帮我总结这个文档，生成300字左右的总结内容，需要包括以下内容：\n1、这个文档主要在讲什么内容？或者这个文档的中心思想是什么？\n2、列举3-5点这个文档的关键内容\n";
        n.dialog.confirm({
            title: "完整指令",
            message: e,
            confirmButtonText: "复制",
            cancelButtonText: "取消",
            textAlign: "left"
        }).then(function() {
            wx.setClipboardData({
                data: e,
                success: function() {}
            }), global.__MSG_TOOL_TAP = !1;
        });
    }, p.prototype.resetData = function() {
        this.setData({
            curFile: null
        });
    }, p = e.__decorate([ t.wxComponent() ], p);
}(i.BaseComponent);

exports.PdfParse = p;