Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Notice = void 0;

var e = require("tslib"), t = require("../../core/base/baseComponent"), o = require("../../core/decorator/componentDecorator"), n = {
    develop: "https://v.qq.com/cache/wuji/object/1?appid=hunyuan_bot&schemaid=hunyuan_notice_test&schemakey=1fd766a45442409ba80a346913ee9838",
    trial: "https://v.qq.com/cache/wuji/object/1?appid=hunyuan_bot&schemaid=hunyuan_notice_pre_release&schemakey=c04cc4aaeba3431b89deeaba9400fd65",
    release: "https://v.qq.com/cache/wuji/object/1?appid=hunyuan_bot&schemaid=hunyuan_notice&schemakey=8020264226d84b368ac60ec969afea94"
}, a = function(t) {
    function a() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.properties = {}, e.data = {
            toggle: !1,
            notice: "",
            show: !1
        }, e.timer = void 0, e;
    }
    return e.__extends(a, t), a.prototype.attached = function() {
        var e = this;
        this.getNotice().then(function() {
            return function t() {
                e.timer = setTimeout(function() {
                    e.getNotice().then(function() {
                        return t();
                    });
                }, 3e5);
            }();
        });
    }, a.prototype.detached = function() {
        this.timer && clearTimeout(this.timer);
    }, a.prototype.onNoticeToggle = function() {
        this.setData({
            toggle: !this.data.toggle
        });
    }, a.prototype.getNotice = function() {
        var e = this, t = wx.getAccountInfoSync().miniProgram.envVersion, o = n[t] || n.release;
        return new Promise(function(t) {
            wx.request({
                url: o,
                method: "GET",
                timeout: 2e4,
                success: function(o) {
                    var n = o.data.data;
                    n ? e.setData({
                        show: !!n.show,
                        notice: n.notice
                    }) : e.setData({
                        show: !1,
                        notice: ""
                    }), t();
                },
                fail: function(o) {
                    console.error("公告消息获取出错", o), e.setData({
                        show: !1,
                        notice: ""
                    }), t();
                }
            });
        });
    }, a = e.__decorate([ o.wxComponent() ], a);
}(t.BaseComponent);

exports.Notice = a;