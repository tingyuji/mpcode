Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ChatBtnActions = exports.StreamSpeechType = exports.MsgType = exports.EnumRequestLevel = exports.TextMsgErrorType = exports.ChatRole = exports.ChatComment = void 0, 
function(e) {
    e[e.down = -1] = "down", e[e.init = 0] = "init", e[e.up = 1] = "up";
}(exports.ChatComment || (exports.ChatComment = {})), function(e) {
    e.AI = "ai", e.HUMAN = "human";
}(exports.ChatRole || (exports.ChatRole = {})), function(e) {
    e[e.normal = 0] = "normal", e[e.error = 1] = "error";
}(exports.TextMsgErrorType || (exports.TextMsgErrorType = {})), function(e) {
    e[e.Key = 1] = "Key", e[e.Minor = 2] = "Minor", e[e.Negligible = 3] = "Negligible";
}(exports.EnumRequestLevel || (exports.EnumRequestLevel = {})), function(e) {
    e.text = "text", e.image = "image", e.goods = "goods", e.url = "url", e.progress = "progress", 
    e.step = "step", e.cutoff = "cutoff";
}(exports.MsgType || (exports.MsgType = {})), function(e) {
    e.goodsWithText = "goods_with_text", e.imageWithText = "image_with_text", e.text = "text", 
    e.pdf = "pdf_content_parse", e.revoke = "message_revoke", e.cutoff = "message_cutoff";
}(exports.StreamSpeechType || (exports.StreamSpeechType = {})), function(e) {
    e.disabled = "disabled", e.noContent = "no-content", e.ready = "ready", e.doing = "doing", 
    e.stopping = "stopping", e.repeat = "repeat";
}(exports.ChatBtnActions || (exports.ChatBtnActions = {}));