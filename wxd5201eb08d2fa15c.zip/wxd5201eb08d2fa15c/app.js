Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib");

require("./lib/tam");

var r = require("./core/decorator/appDecorator"), o = require("./core/base/baseApp"), t = require("./core/globalData"), a = require("./utils/object"), n = e.__importDefault(require("./lib/common/withCache")), u = e.__importDefault(require("./common/navigator"));

require("./style/loadFontFace"), n.default(wx, "getSystemInfoSync"), n.default(wx, "getAccountInfoSync"), 
require("./utils/prefetch"), require("./common/onAppLaunch"), require("./common/onAppShow");

var i = function(o) {
    function n() {
        var e = null !== o && o.apply(this, arguments) || this;
        return e.globalData = t.$global(), e;
    }
    return e.__extends(n, o), n.prototype.onLaunch = function(r) {
        return e.__awaiter(this, void 0, void 0, function() {
            return e.__generator(this, function(e) {
                return console.log("App onLaunch", r), require.async("./subPackages/utils/latex"), 
                [ 2 ];
            });
        });
    }, n.prototype.onPageNotFound = function(e) {
        console.error("page not found: ", e);
        var r = e.query, o = a.objToURLStr(r, "&", !0);
        u.default.switchTab("pages/home/index?" + o);
    }, n = e.__decorate([ r.wxApp() ], n);
}(o.BaseApp);

exports.default = i;