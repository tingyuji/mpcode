Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxComponent = exports.toComponent = void 0;

var e = require("tslib"), t = require("../../utils/object"), o = require("./wxDecoratorConfig"), r = e.__importDefault(require("../../lib/mp-redux/connect")), i = e.__importStar(require("../../store/index")), n = [ "Created", "Attached", "Ready", "Moved", "Detached" ].map(function(e) {
    return e.toLowerCase();
}), a = [ "externalClasses", "properties", "data", "options", "relations", "behaviors" ];

function s(e) {
    void 0 === e && (e = {}), e.properties && Object.keys(e.properties).forEach(function(o) {
        var r = e.properties[o];
        t.isPlainObject(r) || (r = {
            type: r
        }), e.properties[o] = r;
    }), e.methods || (e.methods = {});
    var o = {};
    if (Object.getOwnPropertyNames(e).forEach(function(t) {
        var r = Object.getOwnPropertyDescriptor(e, t);
        r && (n.indexOf(t) < 0 && "function" == typeof r.value ? (Object.defineProperty(e.methods, t, r), 
        delete e[t]) : a.indexOf(t) < 0 && (o[t] = r));
    }), Object.keys(o).length) {
        var r = e.created;
        e.created = function() {
            Object.defineProperties(this, o), r && r.apply(this, arguments);
        };
    }
    return e;
}

exports.toComponent = s, exports.wxComponent = function(n) {
    var a = (n || {}).storeBindingOptions;
    return function(n) {
        var p = new (function(t) {
            function o() {
                for (var e = [], o = 0; o < arguments.length; o++) e[o] = arguments[o];
                return t.call(this) || this;
            }
            return e.__extends(o, t), o.prototype.created = function() {
                t.prototype.created && t.prototype.created.call(this);
            }, o.prototype.attached = function() {
                t.prototype.attached && t.prototype.attached.call(this);
            }, o.prototype.detached = function() {
                this.storeBindings && this.storeBindings.destroyStoreBindings(), t.prototype.detached && t.prototype.detached.call(this);
            }, o;
        }(n))(), c = s(t.toObject(p));
        if (c.behaviors = o.wxDecoratorConfig.extendBehaviors.concat(c.behaviors || []), 
        a) {
            var d = a.actions, l = a.fields, u = a.optimize, f = void 0 !== u && u;
            Component(r.default({
                fields: l,
                actions: d,
                store: i.default,
                globalActions: i.globalSlice.actions,
                instanceType: "component",
                optimize: f
            })(c));
        } else Component(c);
    };
};