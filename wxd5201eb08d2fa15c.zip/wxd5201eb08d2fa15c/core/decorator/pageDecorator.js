Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxPage = void 0;

var o = require("tslib"), t = require("../../services/convertShortUrl"), e = require("../../utils/object"), r = require("./wxDecoratorConfig"), n = o.__importDefault(require("../../common/trackHooks")), i = o.__importStar(require("../../store/index")), a = o.__importDefault(require("../../lib/mp-redux/connect"));

exports.wxPage = function(c) {
    var s = (c || {}).storeBindingOptions;
    return function(c) {
        var u = new (function(e) {
            function r() {
                for (var o = [], t = 0; t < arguments.length; t++) o[t] = arguments[t];
                var r = e.call(this) || this, i = e.prototype.onShareAppMessage;
                return i && (r.onShareAppMessage = function(o) {
                    try {
                        n.default.onShareAppMessage(o);
                    } catch (o) {
                        console.error(o);
                    }
                    return i.call(this, o);
                }), r;
            }
            return o.__extends(r, e), r.prototype.onLoad = function(r) {
                return o.__awaiter(this, void 0, void 0, function() {
                    var i;
                    return o.__generator(this, function(o) {
                        switch (o.label) {
                          case 0:
                            try {
                                n.default.onLoad(r);
                            } catch (o) {
                                console.error(o);
                            }
                            return [ 4, t.convertShortUrl(r) ];

                          case 1:
                            return i = o.sent(), e.prototype.onLoad && e.prototype.onLoad.call(this, i), [ 2 ];
                        }
                    });
                });
            }, r.prototype.onReady = function() {
                return o.__awaiter(this, void 0, void 0, function() {
                    return o.__generator(this, function(o) {
                        try {
                            n.default.onReady();
                        } catch (o) {
                            console.error(o);
                        }
                        return this.mounted = !0, e.prototype.onReady && e.prototype.onReady.call(this), 
                        [ 2 ];
                    });
                });
            }, r.prototype.onShow = function() {
                return o.__awaiter(this, void 0, void 0, function() {
                    return o.__generator(this, function(o) {
                        try {
                            n.default.onShow();
                        } catch (o) {
                            console.error(o);
                        }
                        return e.prototype.onShow && e.prototype.onShow.call(this), [ 2 ];
                    });
                });
            }, r.prototype.onUnload = function() {
                try {
                    n.default.onUnload();
                } catch (o) {
                    console.error(o);
                }
                e.prototype.onUnload && e.prototype.onUnload.call(this);
            }, r;
        }(c))(), l = e.toObject(u);
        if (s) {
            var p = s.actions, d = s.fields, f = s.optimize, h = void 0 !== f && f;
            r.wxDecoratorConfig.Page(a.default({
                fields: d,
                actions: p,
                store: i.default,
                globalActions: i.globalSlice.actions,
                instanceType: "page",
                optimize: h
            })(l));
        } else r.wxDecoratorConfig.Page(l);
    };
};