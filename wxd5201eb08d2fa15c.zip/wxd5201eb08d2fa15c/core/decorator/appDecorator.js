Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxApp = void 0;

var e = require("tslib"), t = require("../../utils/object");

exports.wxApp = function() {
    return function(r) {
        var n = new (function(t) {
            function r() {
                for (var e = [], r = 0; r < arguments.length; r++) e[r] = arguments[r];
                return t.call(this) || this;
            }
            return e.__extends(r, t), r;
        }(r))(), i = t.toObject(n);
        App(i);
    };
};