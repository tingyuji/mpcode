Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxDecoratorConfig = void 0, exports.wxDecoratorConfig = {
    set Page(e) {
        this.newPage = e;
    },
    get Page() {
        return this.newPage || Page;
    },
    newPage: null,
    set Component(e) {
        this.newComponent = e;
    },
    get Component() {
        return this.newComponent || Component;
    },
    newComponent: null,
    set extendBehaviors(e) {
        this.behaviors = e;
    },
    get extendBehaviors() {
        return this.behaviors;
    },
    behaviors: []
};