Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.BaseApp = void 0;

var e = function() {
    this.globalData = {};
};

exports.BaseApp = e;