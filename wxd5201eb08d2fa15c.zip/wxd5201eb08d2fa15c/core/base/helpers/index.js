Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.EnumHttpErrorType = exports.hideError = exports.showError = exports.toast = exports.dialog = void 0;

var e = require("../../../components/base-page/types");

Object.defineProperty(exports, "EnumHttpErrorType", {
    enumerable: !0,
    get: function() {
        return e.EnumHttpErrorType;
    }
});

var r = require("../../../components/base-page/utils");

Object.defineProperty(exports, "showError", {
    enumerable: !0,
    get: function() {
        return r.showError;
    }
}), Object.defineProperty(exports, "hideError", {
    enumerable: !0,
    get: function() {
        return r.hideError;
    }
}), Object.defineProperty(exports, "dialog", {
    enumerable: !0,
    get: function() {
        return r.dialog;
    }
}), Object.defineProperty(exports, "toast", {
    enumerable: !0,
    get: function() {
        return r.toast;
    }
}), exports.default = {
    dialog: r.dialog,
    toast: r.toast,
    showError: r.showError,
    hideError: r.hideError
};