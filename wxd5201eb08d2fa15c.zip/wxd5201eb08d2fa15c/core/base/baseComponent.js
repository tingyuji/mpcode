Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.BaseComponent = void 0;

var e = require("../globalData"), o = function() {
    this.options = {
        addGlobalClass: !0
    }, this.app = e.$getApp(), this.$global = e.$global;
};

exports.BaseComponent = o;