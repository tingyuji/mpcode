Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.BasePage = void 0;

var e = require("../globalData"), a = function() {
    this.app = e.$getApp(), this.$global = e.$global;
};

exports.BasePage = a;