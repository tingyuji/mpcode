Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.$removeGlobalKey = exports.$global = exports.$getApp = exports.globalData = void 0;

var t = require("tslib"), e = require("../config/constants"), o = t.__importDefault(require("../utils/getGlobalSingleton"));

exports.globalData = o.default(function() {
    return {
        versionInfo: wx.getAccountInfoSync(),
        systemInfo: wx.getSystemInfoSync() || {},
        appInfo: {},
        avatarUrl: e.ANONYMOUS_AVATAR,
        userInfo: {},
        launchOptions: {}
    };
}, "__global_data__");

exports.$getApp = function() {
    var t = getApp({
        allowDefault: !0
    });
    return t.globalData = exports.globalData, t;
};

exports.$global = function(t, e) {
    return t ? void 0 === e ? exports.globalData[t] : exports.globalData[t] = e : exports.globalData;
};

exports.$removeGlobalKey = function(t) {
    t && delete exports.globalData[t];
};