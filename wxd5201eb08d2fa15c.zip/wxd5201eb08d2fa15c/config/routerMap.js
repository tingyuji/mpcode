require("../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isTabRoute = exports.isMustAuthRouter = exports.getRouterPath = exports.routerMap = void 0;

var e = [ "/home/home/home", "/home/user/center" ].map(function(e) {
    return "/pages" + e;
}), t = {
    chat: {
        path: "/home/index"
    },
    noAuth: {
        path: "/noAuth/index"
    },
    home: {
        path: "/home/index"
    },
    history: {
        path: "/dialog/index"
    },
    "share-chat": {
        path: "/share-chat/index"
    },
    compare: {
        path: "/compare/index"
    },
    webview: {
        path: "/webview/index"
    },
    personal: {
        path: "/personal/index"
    }
};

exports.routerMap = t;

var r = [];

exports.getRouterPath = function(e) {
    var r = t[e] || {}, o = r.path, a = r.type;
    if (o) return {
        path: "/pages" + o,
        type: a
    };
};

exports.isTabRoute = function(t) {
    return e.filter(function(e) {
        return t.startsWith(e);
    }).length > 0;
};

exports.isMustAuthRouter = function(e) {
    return r.length || Object.keys(t).forEach(function(e) {
        t[e].mustAuth && r.push("/pages" + t[e].path);
    }), r.includes(e);
};