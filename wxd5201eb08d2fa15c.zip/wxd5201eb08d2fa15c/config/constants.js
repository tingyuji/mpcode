Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.LOGIN_USER_TYPE = exports.CURRENT_LOGIN_TYPE = exports.DEFAULT_GREETINGS = exports.CHAT_SCENE_TYPE = exports.CHAT_MODELS = exports.SHARE_CHAT_DARK = exports.SHARE_CHAT_LIGHT = exports.SHARE_LOGO_DARK = exports.SHARE_LOGO_LIGHT = exports.CHAT_MODE_TYPE = exports.FUNCTIONAL_PROMPT_PREFIX = exports.DIALOG_FETCH_CONFIG = exports.AVATAR_PATH = exports.getCutoffText = exports.getPdfText = exports.getOriginGoodsText = exports.getOriginImageText = exports.ERROR_EMPTY_ANSWER = exports.ERROR_GENERATE_FAILED = exports.CUTOFF_EVENT_CONST = exports.ERROR_EVENT_CONST = exports.REVOKE_EVENT_CONST = exports.SPEECH_TYPE_REG = exports.ERROR_REG = exports.DATA_REG = exports.PLUGIN_REG = exports.PLUGIN_ID_INFO_MAP = exports.INSTRUCT_GUIDE_KEY = exports.ALL_CONFIG_OLD = exports.PLUGIN_LIST = exports.CONV_CHAT_TYPE = exports.CONV_STREAM_TYPE_MAP = exports.CONV_STREAM_TYPE = exports.CONV_STREAM_REPLACE = exports.ANONYMOUS_AVATAR = exports.RESPONSE_CODE = exports.CHAT_INSPIRATION_MAP = exports.CHAT_FEEDBACK_ARRAY = exports.CHAT_GOODS_FEEDBACK_MAP = exports.CHAT_FEEDBACK_MAP_V2 = exports.CHAT_TEXT_FEEDBACK_MAP_V2 = exports.CHAT_IMG_FEEDBACK_MAP_V2 = exports.CHAT_FEEDBACK_MAP = exports.CHAT_MAX_REGEN_TIMES = exports.CHAT_MAX_ROUND = exports.CHAT_PLUGIN_LIST = exports.CHAT_MODULES = exports.AUTH_FREE_INTERFACE = exports.AUTH_FREE_PATHS = exports.THEME = void 0, 
exports.MODEL_ORDER = exports.AUTH_STATUS = void 0;

var e, t, o = require("../interface/type");

exports.THEME = {
    DARK: {
        name: "dark",
        custom: {
            colorPrimary: "#FA4126",
            colorSecondary: "#FFECE9"
        }
    },
    LIGHT: {
        name: "light",
        custom: {
            colorPrimary: "#FA4126",
            colorSecondary: "#FFECE9"
        }
    }
}, exports.AUTH_FREE_PATHS = [ "pages/noAuth/index" ], exports.AUTH_FREE_INTERFACE = [ /\/api\/convs\/share\/\w+/ ], 
exports.CHAT_MODULES = {
    default: "gpt_175B_0404"
}, function(e) {
    e.default = "", e.browser = "Browsing", e.calc = "Calculating", e.adapt = "Adaptive", 
    e.shopping = "Shopping", e.PDF = "PDF";
}(e = exports.CHAT_PLUGIN_LIST || (exports.CHAT_PLUGIN_LIST = {})), exports.CHAT_MAX_ROUND = 30, 
exports.CHAT_MAX_REGEN_TIMES = 10, exports.CHAT_FEEDBACK_MAP = {
    1000: "正确性",
    1001: "规范性",
    1002: "专业性",
    1003: "功能性",
    2000: "理解问题有误",
    2001: "回复存在错误",
    2002: "存在违法有害信息",
    2003: "审核过严",
    3000: "艺术感强",
    3001: "细节刻画精美",
    3002: "语义理解精准",
    3003: "人物刻画精致",
    3004: "风格效果准确",
    4000: "画面毫无美感",
    4001: "细节非常差",
    4002: "语义理解非常差",
    4003: "人物刻画非常差",
    4004: "风格效果非常差"
}, exports.CHAT_IMG_FEEDBACK_MAP_V2 = [ {
    title: "图片正确性",
    type: 1,
    code: {
        7101: "图片表达准确",
        7102: "图片表达完整",
        7103: "图片风格匹配"
    }
}, {
    title: "图片质量过关",
    type: 1,
    code: {
        7104: "图片清晰度满意",
        7105: "图片清晰度满意"
    }
}, {
    title: "内容画错",
    type: -1,
    code: {
        8101: "图片风格错误",
        8102: "图不对文",
        8103: "图片缺失部分要求元素",
        8104: "图片擅自增加额外元素"
    }
}, {
    title: "图片生成错误",
    type: -1,
    code: {
        8105: "无需画图但生成图片",
        8106: "需要画图但没生成图片"
    }
}, {
    title: "图片事实错误",
    type: -1,
    code: {
        8107: "人物畸形",
        8108: "动物畸形",
        8109: "物品畸形",
        8110: "场景畸形",
        8111: "图片逻辑错误"
    }
}, {
    title: "图片质量问题",
    type: -1,
    code: {
        8112: "图片清晰度低",
        8113: "图片构图差",
        8114: "图片乱码"
    }
}, {
    title: "其他错误",
    type: -1,
    code: {
        8115: "内容无意义",
        8116: "存在违法有害信息",
        8117: "图片存在低俗敏感信息",
        8118: "其他"
    }
} ], exports.CHAT_TEXT_FEEDBACK_MAP_V2 = [ {
    title: "正确性",
    type: 1,
    code: {
        7001: "回答准确有效",
        7002: "回答思维连贯，逻辑正确",
        7003: "回答全面"
    }
}, {
    title: "规范性",
    type: 1,
    code: {
        7004: "价值观正确",
        7005: "立场正确",
        7006: "格式规范"
    }
}, {
    title: "上下文",
    type: 1,
    code: {
        7007: "上下文关联准确"
    }
}, {
    title: "问题理解错误",
    type: -1,
    code: {
        8001: "未准确理解题目要求",
        8002: "多轮上下文理解不对",
        8003: "未识别问题中的错误"
    }
}, {
    title: "回答内容错误",
    type: -1,
    code: {
        8004: "事实错误",
        8005: "逻辑推理错误",
        8006: "内容不完整（不专业/缺乏深度）",
        8007: "计算错误",
        8008: "格式错误",
        8009: "乱码错误",
        8010: "内容不断重复",
        8011: "回答中误生成图片"
    }
}, {
    title: "其他错误",
    type: -1,
    code: {
        8012: "内容无意义",
        8013: "存在违法有害信息",
        8014: "存在价值观问题",
        8015: "其他"
    }
} ], exports.CHAT_FEEDBACK_MAP_V2 = {
    text2textFeedbackCode: exports.CHAT_TEXT_FEEDBACK_MAP_V2,
    text2imageFeedbackCode: exports.CHAT_IMG_FEEDBACK_MAP_V2
}, exports.CHAT_GOODS_FEEDBACK_MAP = [ {
    title: "推荐商品",
    code: {
        5001: "种类丰富",
        5002: "商品时尚",
        6001: "不符合需求",
        6002: "种类单一"
    }
}, {
    title: "介绍信息",
    code: {
        5101: "全面客观",
        5102: "信息充足",
        6101: "信息冗杂无用",
        6102: "信息不足"
    }
}, {
    title: "服务体验",
    code: {
        5201: "排序合理",
        5202: "链接跳转流畅",
        6201: "商品排序不合理",
        6202: "链接跳转不流畅"
    }
} ], exports.CHAT_FEEDBACK_ARRAY = Object.keys(exports.CHAT_FEEDBACK_MAP).map(function(e) {
    return {
        id: e,
        text: exports.CHAT_FEEDBACK_MAP[e],
        type: +e < 2e3 || +e >= 3e3 && +e < 4e3 ? o.ChatComment.up : o.ChatComment.down
    };
}), exports.CHAT_INSPIRATION_MAP = [ {
    scene: "小红书种草文案",
    tag: "创作",
    desc: "",
    icon: "xxx",
    shortcut: !0,
    shortcutSort: 1,
    template: {
        id: "xxxx",
        notice: "xxx",
        hint: "xxx",
        prompts: [ "xxx", "xxx", "xxx" ]
    }
} ], exports.RESPONSE_CODE = {
    SUCCESS: 200,
    AUTH_FAIL: 401,
    SRV_AUTH_FAIL: 400,
    COS_AUTH_FAIL: 404
}, exports.ANONYMOUS_AVATAR = "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0", 
exports.CONV_STREAM_REPLACE = {
    DONE: "[DONE]",
    SENSITIVE_DONE: "[SENSITIVE]",
    ENTRY: "[ENTRY]"
}, function(e) {
    e.ADD = "add", e.DONE = "done", e.SENSITIVE_DONE = "sensitive", e.ERROR = "error";
}(t = exports.CONV_STREAM_TYPE || (exports.CONV_STREAM_TYPE = {})), exports.CONV_STREAM_TYPE_MAP = {
    "[DONE]": t.DONE,
    "[SENSITIVE]": t.SENSITIVE_DONE
}, function(e) {
    e[e.CHAT = 0] = "CHAT", e[e.RE_CHAT = 1] = "RE_CHAT", e[e.CONTINUE_CHAT = 2] = "CONTINUE_CHAT";
}(exports.CONV_CHAT_TYPE || (exports.CONV_CHAT_TYPE = {})), exports.PLUGIN_LIST = [ {
    title: "通用模型 V0.9",
    id: e.default,
    description: "不使用插件，内容输出精准又快",
    default: !1,
    newest: !1,
    templates: [ {
        color: "",
        icon: "",
        sample: "",
        title: ""
    } ]
}, {
    title: "自适应插件",
    id: e.adapt,
    description: "根据用户输入的问题，自动选择插件",
    default: !1,
    newest: !1,
    templates: [ {
        color: "",
        icon: "",
        sample: "",
        title: ""
    } ]
} ], exports.ALL_CONFIG_OLD = "ALL_CONFIG_OLD", exports.INSTRUCT_GUIDE_KEY = "instruct-guide-key", 
exports.PLUGIN_ID_INFO_MAP = exports.PLUGIN_LIST.reduce(function(e, t) {
    return e[t.id] = t, e;
}, {}), exports.PLUGIN_REG = /data: \[plugin: ([\w\W]*?)]\r\n/g, exports.DATA_REG = /data: (.*?)\r\n/g, 
exports.ERROR_REG = /event: error\ndata: ([\w\W]+?)\r\n/, exports.SPEECH_TYPE_REG = /event: speech_type\ndata: ([_a-z]+)\r\n/, 
exports.REVOKE_EVENT_CONST = "event: message_revoke\n", exports.ERROR_EVENT_CONST = "event: error\n", 
exports.CUTOFF_EVENT_CONST = "event: message_cutoff\n", exports.ERROR_GENERATE_FAILED = "抱歉，生成失败，请重新生成", 
exports.ERROR_EMPTY_ANSWER = "抱歉，生成失败，请重新生成", exports.getOriginImageText = function() {
    return {
        type: o.MsgType.image,
        images: [ {
            imageUrl: "",
            highDefImageUrl: "",
            progress: 0,
            failed: !1
        }, {
            imageUrl: "",
            highDefImageUrl: "",
            progress: 0,
            failed: !1
        }, {
            imageUrl: "",
            highDefImageUrl: "",
            progress: 0,
            failed: !1
        }, {
            imageUrl: "",
            highDefImageUrl: "",
            progress: 0,
            failed: !1
        } ],
        text: ""
    };
}, exports.getOriginGoodsText = function() {
    return {
        type: o.MsgType.goods,
        goods: [],
        text: "",
        goodsGroup: [],
        preText: ""
    };
}, exports.getPdfText = function() {
    return {
        type: o.MsgType.step,
        msg: "",
        status: "",
        text: ""
    };
}, exports.getCutoffText = function() {
    return {
        type: o.MsgType.cutoff,
        msg: "",
        text: ""
    };
}, exports.AVATAR_PATH = wx.env.USER_DATA_PATH + "/image-avatar.png", exports.DIALOG_FETCH_CONFIG = {
    limit: 15
}, exports.FUNCTIONAL_PROMPT_PREFIX = [ "/画一幅画：", "/好物推荐：" ], function(e) {
    e.NORMAL = "normal", e.SELECT = "select";
}(exports.CHAT_MODE_TYPE || (exports.CHAT_MODE_TYPE = {})), exports.SHARE_LOGO_LIGHT = "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/share/share-bg.png", 
exports.SHARE_LOGO_DARK = "https://cdn-we-retail.ym.tencent.com/fy/landingPage/ai/share.png", 
exports.SHARE_CHAT_LIGHT = "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/share/share-bg2.png", 
exports.SHARE_CHAT_DARK = "https://cdn-we-retail.ym.tencent.com/fy/landingPage/ai/share-chat.png", 
exports.CHAT_MODELS = [ {
    key: "gpt_175B_0404",
    text: "腾讯混元助手",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/hunyuan-logo-border.png?imageMogr2/thumbnail/72x72",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/logo-s2.png"
}, {
    key: "gpt-35-turbo",
    text: "GPT3.5",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/gpt-logo.png",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/chatgpt3-5.png"
}, {
    key: "gpt-4",
    text: "GPT4",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/gpt4_circle.png",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/chatgpt4.png"
}, {
    key: "ernie_bot",
    text: "文心一言",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/wenxin_circle.png",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/wenxin_round.png"
}, {
    key: "spark_desk",
    text: "讯飞星火",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/spark_circle.png",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/models/spark_circle.png"
}, {
    key: "doubao",
    text: "字节豆包",
    icon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/doubao-circle.png",
    chatIcon: "https://xj-psd-1258344703.cos.ap-guangzhou.myqcloud.com/image/hunyuan/doubao-round.png"
} ], function(e) {
    e.COMPARE = "compare", e.INSPIRE = "inspire", e.NORMAL = "normal";
}(exports.CHAT_SCENE_TYPE || (exports.CHAT_SCENE_TYPE = {})), exports.DEFAULT_GREETINGS = {
    welcomeMsgs: [ {
        start: 0,
        end: 6,
        msgs: [ "Hello" ]
    }, {
        start: 6,
        end: 9,
        msgs: [ "早安，朋友！", "Hello" ]
    }, {
        start: 9,
        end: 12,
        msgs: [ "Hi，上午好", "Hello" ]
    }, {
        start: 12,
        end: 14,
        msgs: [ "中午好！", "Hello" ]
    }, {
        start: 14,
        end: 18,
        msgs: [ "下午好啊！", "Hello" ]
    }, {
        start: 18,
        end: 24,
        msgs: [ "晚上好！", "Good evening" ]
    } ],
    introduceMsgs: [ "我是你的专属AI伙伴，可以回答你的问题，为你提供有用信息，帮助你完成创作", "AI小助手在此，随时等待你的提问～快抛出你的问题，让我们一起愉快地探讨吧", "不管你遇到了什么问题，都可以向我咨询，我时刻准备着为您提供协助，让您的生活更加美好～" ]
}, exports.CURRENT_LOGIN_TYPE = "CURRENT_LOGIN_TYPE", exports.LOGIN_USER_TYPE = {
    innerUser: "inner_user_login",
    outerUser: "outer_user_login"
}, function(e) {
    e[e.notApply = 0] = "notApply", e[e.authWaiting = 1] = "authWaiting", e[e.authApproved = 2] = "authApproved", 
    e[e.authDenied = 3] = "authDenied", e[e.authBaned = 4] = "authBaned";
}(exports.AUTH_STATUS || (exports.AUTH_STATUS = {})), exports.MODEL_ORDER = exports.CHAT_MODELS.reduce(function(e, t, o) {
    return e[t.key] = o, e;
}, {});