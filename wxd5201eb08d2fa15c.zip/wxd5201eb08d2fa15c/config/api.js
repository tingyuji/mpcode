Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.api = void 0;

var e = require("../interface/type"), l = {
    cos: {
        getTmpCredential: {
            url: "/api/generate/tmpkey",
            config: {
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    config: {
        prompt: {
            url: "/api/examples/prompt",
            config: {
                level: e.EnumRequestLevel.Negligible
            }
        },
        plugins: {
            url: "/api/plugins",
            config: {
                level: e.EnumRequestLevel.Negligible
            }
        },
        general: {
            url: "/api/info/general",
            config: {
                timeout: 3e3,
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    base: {
        convertScene: {
            url: "/api/weixin/parse/scene",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    conv: {
        generate: {
            url: "/api/generate/id",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getOpBatchConvs: {
            url: "/api/op/convs",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getOpConvDetail: {
            url: "/api/op/conv/#{cid}",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        },
        stopChat: {
            url: "/api/stop/chat/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        sliceHistory: {
            url: "/api/stop/conversation/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        sliceRelationHistory: {
            url: "/api/stop/relation_convs/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getPrompt: {
            url: "/api/generate/prompts",
            config: {
                method: "post",
                timeout: 3e3,
                level: e.EnumRequestLevel.Negligible
            }
        },
        getQuotaInfo: {
            url: "/api/chat/quotainfo",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        },
        feedback: {
            url: "/api/ai/suitable/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        compareFeedback: {
            url: "/api/ai/feedback/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        detailedFeedback: {
            url: "/api/ai/complaint/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getDetail: "/api/conv/#{cid}",
        preChat: {
            url: "api/chat/prechat/#{cid}",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        chat: {
            url: "api/chat/#{cid}",
            config: {
                method: "post"
            }
        },
        reGenerateChat: {
            url: "api/chat/repeat/#{cid}",
            config: {
                method: "post"
            }
        },
        generateChatTitle: {
            url: "/api/chat/title/#{cid}",
            config: {
                method: "post"
            }
        },
        getShareId: {
            url: "/api/convs/share",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getShareContent: {
            url: "/api/convs/share/#{shareId}",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getInspirationDetail: {
            url: "/api/inspirations/template/{id}",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        },
        generateV2: {
            url: "/api/v2/generate/id",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getCompareDetail: {
            url: "/api/relation/conv",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    instruct: {
        list: {
            url: "/api/shortcut/list",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        create: {
            url: "/api/shortcut/create",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        edit: {
            url: "/api/shortcut/update",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        delete: {
            url: "/api/shortcut/delete",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        recommend: {
            url: "/api/shortcut/recommend",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    message: {
        list: {
            url: "/api/message_center/list",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        update: {
            url: "/api/message_center/update",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    theme: {
        list: {
            url: "/api/shortcut/theme/list",
            config: {
                method: "get",
                level: e.EnumRequestLevel.Negligible
            }
        },
        create: {
            url: "/api/shortcut/theme/create",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        delete: {
            url: "/api/shortcut/theme/delete",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        move: {
            url: "/api/shortcut/theme/move",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    session: {
        login: "api/oalogin",
        profile: {
            url: "/api/profile",
            config: {
                method: "post",
                responseType: "arraybuffer",
                level: e.EnumRequestLevel.Negligible
            }
        },
        getPhoneNumber: {
            url: "api/miniregister",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        },
        updateUserInfo: {
            url: "api/updateuserinfo",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    behavior: {
        report: {
            url: "/api/behavior/report",
            config: {
                method: "post",
                level: e.EnumRequestLevel.Negligible
            }
        }
    },
    dialog: {
        deleteConvs: {
            url: "/api/conv/#{id}",
            config: {
                method: "delete"
            }
        },
        getConvs: "/api/convs",
        editCovsTitle: {
            url: "/api/conv/title/#{id}",
            config: {
                method: "post"
            }
        }
    }
};

exports.api = l;