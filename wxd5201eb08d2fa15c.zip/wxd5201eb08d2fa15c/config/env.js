module.exports = {
    env: "prod",
    api: {
        host: "https://hunyuanmini.woa.com/",
        outerHost: "https://hunyuan.tencent.com/",
        prefix: "",
        smartGateUrl: "https://hunyuanmini.woa.com/__code2key/",
        smartGateAppKey: "easp_hunyuanmini_woa_com",
        zhiyanReportHost: "https://api.fy.qq.com"
    },
    appid: "wxd5201eb08d2fa15c"
};