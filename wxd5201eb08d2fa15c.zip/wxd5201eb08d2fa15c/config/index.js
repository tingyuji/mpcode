Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.APP_THEME = exports.PDF_TEMPLATE_ID = exports.RESPONSE_CODE = exports.PAGE_BG_LIGHT = exports.PAGE_BG_DARK = exports.KEYBOARD_HEIGHT = exports.DIALOG_LIST = exports.NEWEST_PLUGIN_MAP = exports.PERSONAL_NEW_SHOWED = exports.TAB_NEW_SHOWED = exports.INTRO_SHOWED = void 0, 
exports.INTRO_SHOWED = "introShowed", exports.TAB_NEW_SHOWED = "introShowedAgain", 
exports.PERSONAL_NEW_SHOWED = "personalShowedAgain", exports.NEWEST_PLUGIN_MAP = "newestPluginMap", 
exports.DIALOG_LIST = "dialogList", exports.KEYBOARD_HEIGHT = "keyboardHeight", 
exports.PAGE_BG_DARK = "#242627", exports.PAGE_BG_LIGHT = "#F5F6F8", exports.RESPONSE_CODE = {
    SUCCESS: "SUCCESS",
    FAIL: "FAIL"
}, exports.PDF_TEMPLATE_ID = "Mr9zH9H78b", exports.APP_THEME = "HUNYUAN_THEME";