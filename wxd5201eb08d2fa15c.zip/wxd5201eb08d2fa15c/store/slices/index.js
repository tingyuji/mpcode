Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.globalSlice = void 0;

var e = require("tslib").__importDefault(require("./global/index"));

exports.globalSlice = e.default;