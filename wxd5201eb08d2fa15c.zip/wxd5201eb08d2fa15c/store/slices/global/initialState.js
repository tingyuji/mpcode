Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("./theme"), t = {
    theme: e.theme,
    themeStyle: e.themeStyle,
    tabPageParams: [],
    userAuthConfig: {
        isPhoneAuth: !1,
        isUserInfoAuth: !1
    }
};

exports.default = t;