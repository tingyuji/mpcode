Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.updateTheme = exports.themeStyle = exports.theme = void 0;

var e, o, t = require("../../../utils/themeUtil");

function r(t) {
    exports.theme = e = t, exports.themeStyle = o = function(e) {
        var o, t, r = [];
        return (null === (o = e.custom) || void 0 === o ? void 0 : o.colorPrimary) && r.push("--color-primary: " + e.custom.colorPrimary), 
        (null === (t = e.custom) || void 0 === t ? void 0 : t.colorSecondary) && r.push("--color-secondary: " + e.custom.colorSecondary), 
        r.join(";");
    }(t);
}

exports.theme = e, exports.themeStyle = o, exports.updateTheme = r;

r({
    name: t.getAppTheme(),
    custom: {},
    animation: !1
});