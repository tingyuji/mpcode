Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), a = require("../../../lib/mp-redux/index"), t = e.__importDefault(require("./initialState")), s = require("./theme");

exports.default = a.createSlice({
    namespace: "",
    initialState: t.default,
    reducers: {
        update: function(e, a) {
            return a.payload[0];
        },
        setUserAuthConfig: function(a, t) {
            var s = t.payload[0];
            return e.__assign(e.__assign({}, a), {
                userAuthConfig: e.__assign(e.__assign({}, a.userAuthConfig), s)
            });
        },
        setTabPageParams: function(a, t) {
            var s = t.payload[0];
            return e.__assign(e.__assign({}, a), {
                tabPageParams: e.__assign(e.__assign({}, a.tabPageParams), s)
            });
        },
        updateThemeConfig: function(a, t) {
            var r = t.payload[0];
            return s.updateTheme(r), e.__assign(e.__assign({}, a), {
                theme: s.theme,
                themeStyle: s.themeStyle
            });
        }
    },
    effects: {}
});