Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.globalSlice = void 0;

var e = require("tslib"), r = require("redux/dist/redux.min"), t = e.__importDefault(require("redux-thunk")), l = e.__importDefault(require("../utils/getGlobalSingleton")), i = require("./slices/index");

Object.defineProperty(exports, "globalSlice", {
    enumerable: !0,
    get: function() {
        return i.globalSlice;
    }
});

var u = l.default(function() {
    return r.createStore(i.globalSlice.reducer, r.applyMiddleware(t.default));
}, "__redux_store__");

exports.default = u;