Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getSuffix = exports.loadFontFace = void 0;

var a = function(a, o) {
    switch (void 0 === a && (a = "normal"), void 0 === o && (o = !1), a) {
      case "normal":
        return o ? "Italic" : "Regular";

      case "bold":
        return o ? "BoldItalic" : "Bold";

      default:
        return "Regular";
    }
};

exports.getSuffix = a;

var o = function(o, r, l) {
    void 0 === r && (r = "normal"), void 0 === l && (l = !1);
    var e = "KaTeX_" + o + "-" + a(r, l), n = "https://cdn-we-retail.ym.tencent.com/fy/landingPage/ai";
    wx.loadFontFace({
        family: "KaTeX_" + o,
        source: 'url("' + n + "/" + e + '.woff")',
        global: !0,
        desc: {
            style: l ? "italic" : "normal",
            weight: r
        },
        success: function() {},
        fail: function(a) {
            console.error("loadFontFace fail:", a, 'url("' + n + "/" + e + '.woff")');
        }
    });
};

exports.loadFontFace = o, o("AMS", "normal"), o("Caligraphic", "bold"), o("Caligraphic", "normal"), 
o("Fraktur", "bold"), o("Fraktur", "normal"), o("Main", "bold"), o("Main", "bold", !0), 
o("Main", "normal", !0), o("Main", "normal"), o("Math", "bold", !0), o("Math", "normal", !0), 
o("SansSerif", "bold"), o("SansSerif", "normal", !0), o("SansSerif", "normal"), 
o("Script", "normal"), o("Size1", "normal"), o("Size2", "normal"), o("Size3", "normal"), 
o("Size4", "normal"), o("Typewriter", "normal");