Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.convertShortUrl = exports.convertScene = void 0;

var e = require("tslib"), r = require("../common/http-client/index"), t = require("../utils/helper"), n = e.__importDefault(require("../utils/memoizeOne"));

exports.convertScene = function(n) {
    return e.__awaiter(void 0, void 0, void 0, function() {
        var s, o, c, i, u;
        return e.__generator(this, function(a) {
            switch (a.label) {
              case 0:
                return a.trys.push([ 0, 2, , 3 ]), s = n.scene, o = e.__rest(n, [ "scene" ]), s && 32 === s.length && 0 === s.indexOf("sid-") ? [ 4, r.apis.base.convertScene({
                    scene: s
                }) ] : [ 2, n ];

              case 1:
                return c = a.sent().args, i = t.URLStrToObj(c), [ 2, e.__assign(e.__assign({}, o), i) ];

              case 2:
                return u = a.sent(), console.error("convertScene failed", u), [ 2, n ];

              case 3:
                return [ 2 ];
            }
        });
    });
}, exports.convertShortUrl = n.default(exports.convertScene, {
    cachePromiseRejection: !1
});