Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), n = [ {
    envId: "zhuanhuabao-5gqf84946751a1cb",
    appId: "wxc1ae86764f20003d"
} ];

exports.default = function() {
    return e.__awaiter(this, void 0, void 0, function() {
        return e.__generator(this, function(e) {
            return [ 2, new Promise(function(e, t) {
                var r = wx.getStorageSync("openId");
                if (r) e(r); else {
                    var o = new wx.cloud.Cloud({
                        resourceAppid: n[0].appId,
                        resourceEnv: n[0].envId
                    });
                    o.init().then(function() {
                        o.callFunction({
                            name: "baseFunctions",
                            data: {
                                type: "getOpenId"
                            }
                        }).then(function(n) {
                            var t = n.result.openid;
                            wx.setStorageSync("openId", t), e(t);
                        }).catch(function(e) {
                            console.error("callFunctionFailed", e), t(new Error("CallFunctionFailed:" + e.message));
                        });
                    });
                }
            }) ];
        });
    });
};