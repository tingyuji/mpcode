Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e, t, n = require("tslib"), i = require("@tencent/retailwe-ui-common/index"), r = require("@tencent/retailwe-ui-common/index");

!function(e) {
    e.PRIMARY = "primary", e.NORMAL = "normal", e.DISABLE = "disabled";
}(e || (e = {})), function(e) {
    e.SMALL = "small", e.MIDDLE = "middle", e.LARGE = "large";
}(t || (t = {}));

var o = function(i) {
    function o() {
        var n = null !== i && i.apply(this, arguments) || this;
        return n.externalClasses = [ "wr-class" ], n.properties = {
            type: {
                type: String,
                value: e.NORMAL
            },
            size: {
                type: String,
                value: t.MIDDLE
            },
            hairline: Boolean,
            noBorder: Boolean,
            block: {
                type: Boolean,
                value: !1
            },
            text: String,
            btnStyle: String,
            loading: Boolean,
            disabled: Boolean,
            openType: String,
            businessId: Number,
            sessionFrom: String,
            sendMessageTitle: String,
            sendMessagePath: String,
            sendMessageImg: String,
            showMessageCard: Boolean,
            appParameter: String
        }, n.data = {}, n;
    }
    return n.__extends(o, i), o.prototype.bindTap = function(e) {
        this.data.disabled ? this.triggerEvent("click-disabled", e.detail) : this.triggerEvent("click", e.detail);
    }, o.prototype.bindGetUserInfo = function(e) {
        this.triggerEvent("getuserinfo", e.detail);
    }, o.prototype.bindContact = function(e) {
        this.triggerEvent("contact", e.detail);
    }, o.prototype.bindGetPhoneNumber = function(e) {
        this.triggerEvent("getphonenumber", e.detail);
    }, o.prototype.bindError = function(e) {
        this.triggerEvent("error", e.detail);
    }, o.prototype.bindLaunchApp = function(e) {
        this.triggerEvent("launchapp", e.detail);
    }, o.prototype.bindOpenSetting = function(e) {
        this.triggerEvent("opensetting", e.detail);
    }, o = n.__decorate([ r.wxComponent() ], o);
}(i.SuperComponent);

exports.default = o;