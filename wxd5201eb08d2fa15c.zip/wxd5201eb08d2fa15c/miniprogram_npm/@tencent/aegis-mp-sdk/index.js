require("../../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../../@babel/runtime/helpers/typeof");

!function(t, n) {
    "object" == ("undefined" == typeof exports ? "undefined" : e(exports)) && "undefined" != typeof module ? module.exports = n() : "function" == typeof define && define.amd ? define(n) : (t = "undefined" != typeof globalThis ? globalThis : t || self).Aegis = n();
}(void 0, function() {
    var t = function(e, n) {
        return (t = Object.setPrototypeOf || ({
            __proto__: []
        } instanceof Array ? function(e, t) {
            e.__proto__ = t;
        } : function(e, t) {
            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
        }))(e, n);
    };
    function n(e, n) {
        function o() {
            this.constructor = e;
        }
        t(e, n), e.prototype = null === n ? Object.create(n) : (o.prototype = n.prototype, 
        new o());
    }
    var o = function() {
        return (o = Object.assign || function(e) {
            for (var t, n = 1, o = arguments.length; n < o; n++) for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e;
        }).apply(this, arguments);
    };
    function r() {
        for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
        var o = Array(e), r = 0;
        for (t = 0; t < n; t++) for (var i = arguments[t], a = 0, s = i.length; a < s; a++, 
        r++) o[r] = i[a];
        return o;
    }
    Object.assign || Object.defineProperty(Object, "assign", {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        value: function(e) {
            if (null == e) throw new TypeError("Cannot convert first argument to object");
            for (var t = Object(e), n = 1; n < arguments.length; n++) if (null != (o = arguments[n])) for (var o = Object(o), r = Object.keys(Object(o)), i = 0, a = r.length; i < a; i++) {
                var s = r[i], l = Object.getOwnPropertyDescriptor(o, s);
                null != l && l.enumerable && (t[s] = o[s]);
            }
            return t;
        }
    });
    var i = /_?t(\d)?(imestamp)?=\d+&?/g, a = [ "aegis.qq.com", "tamaegis.com", "/aegis-sdk", "rumt-", "/flog.core.min.js", "pingfore.qq.com", "pingfore.tencent.com", "zhiyan.tencent-cloud.net", "h.trace.qq.com", "btrace.qq.com", "beacon.qq.com", "dmplog.qq.com", "qq.com/report", "svibeacon.onezapp.com", "cube.weixinbridge.com", "doubleclick.net", "pcmgrmonitor.3g.qq.com", "tdm.qq.com", "report.qqweb.qq.com", "tpstelemetry.tencent.com", "insight.cloud.tencent.com", "facebook.com", "facebook.net", "google", "yahoo.com", "twitter.com", "ga-audiences", "report.idqqimg.com", "arms-retcode.aliyuncs.com", "px.effirst.com", "sentry", "baidu.com", "hot-update.json", "u.c.b.r.o.w.s.e.r", "report.url.cn", "sockjs-node", "m3u8" ], s = [ "ext1", "ext2", "ext3", "level", "trace", "tag", "seq", "code" ], l = (u.prototype.indexOf = function(e, t) {
        for (var n = 0; n < e.length; n++) if (e[n].callback === t) return n;
        return -1;
    }, u.prototype.on = function(e, t, n) {
        var o;
        if (void 0 === n && (n = 0), this) return (o = this.eventsList[e]) || (this.eventsList[e] = [], 
        o = this.eventsList[e]), -1 === this.indexOf(o, t) && o.push({
            name: e,
            type: n || 0,
            callback: t
        }), this;
    }, u.prototype.one = function(e, t) {
        this.on(e, t, 1);
    }, u.prototype.remove = function(e, t) {
        if (this) {
            var n = this.eventsList[e];
            if (n) {
                if (t) return n.length && (t = this.indexOf(n, t), n.splice(t, 1)), this;
                try {
                    delete this.eventsList[e];
                } catch (e) {}
            }
            return null;
        }
    }, u.prototype.clear = function() {
        this.eventsList = {};
    }, u), c = function(e) {
        if (!e || 0 === e.length) return "{}";
        e = Array.isArray(e) ? e : [ e ];
        var t = Object.keys(e[0]), n = {}, o = (t.forEach(function(t) {
            n[t] = e.map(function(e) {
                return e[t];
            });
        }), n.count = e.length, n);
        if ("string" == typeof o) return o;
        try {
            return JSON.stringify(o, M()) || "undefined";
        } catch (o) {
            return "error happen when aegis stringify: \n " + o.message + " \n " + o.stack;
        }
    };
    function u() {
        var e = this;
        this.emit = function(t, n) {
            if (e) {
                var o;
                if (null != (r = e.eventsList[t]) && r.length) for (var r = r.slice(), i = 0; i < r.length; i++) {
                    o = r[i];
                    try {
                        var a = o.callback.apply(e, [ n ]);
                        if (1 === o.type && e.remove(t, o.callback), !1 === a) break;
                    } catch (t) {
                        throw t;
                    }
                }
                return e;
            }
        }, this.eventsList = {};
    }
    function f(e, t) {
        return "string" == typeof e ? e.split("?")[t ? 1 : 0] || "" : e;
    }
    function p(e) {
        return "string" == typeof e && /^\//.test(e) ? "https:" === (null === location || void 0 === location ? void 0 : location.protocol) : /^https/.test(e);
    }
    function d(e, t, n) {
        var o, r;
        try {
            if ("function" == typeof (null == t ? void 0 : t.retCodeHandler)) return {
                code: void 0 === (i = (r = t.retCodeHandler(e, null == n ? void 0 : n.url, null == n ? void 0 : n.ctx, null == n ? void 0 : n.payload) || {}).code) ? "unknown" : i,
                isErr: r.isErr
            };
            if (!(e = "string" == typeof e ? JSON.parse(e) : e)) return {
                code: "unknown",
                isErr: !1
            };
            "function" == typeof (null == (o = null == t ? void 0 : t.ret) ? void 0 : o.join) && (D = [].concat(t.ret.map(function(e) {
                return e.toLowerCase();
            })));
            var i, a = Object.getOwnPropertyNames(e).filter(function(e) {
                return -1 !== D.indexOf(e.toLowerCase());
            });
            return a.length ? {
                code: "" + (i = "未知" !== (i = e[a[0]]) && "" !== i ? i : "unknown"),
                isErr: 0 !== i && "0" !== i && "unknown" !== i
            } : {
                code: "unknown",
                isErr: !1
            };
        } catch (e) {
            return {
                code: "unknown",
                isErr: !1
            };
        }
    }
    function h(e, t, n) {
        try {
            var o = "function" == typeof t ? t(e, null == n ? void 0 : n.url) || "" : e;
            return B(o).slice(0, 102400);
        } catch (e) {
            return "";
        }
    }
    function g(e, t) {
        return "string" != typeof e || !e || t && -1 < e.indexOf(t) || G.test(e) || a.some(function(t) {
            return -1 < e.indexOf(t);
        });
    }
    function m(e, t) {
        var n, o = [], r = e.config;
        return e.lifeCycle.on("destroy", function() {
            o.length = 0;
        }), function(i, a) {
            Array.isArray(i) ? o = o.concat(i) : o.push(i), t && o.length >= t || e.sendNow && 0 < o.length ? (o = J(o), 
            a(o.splice(0, o.length)), n && clearTimeout(n)) : (n && clearTimeout(n), n = setTimeout(function() {
                n = null, 0 < (o = J(o)).length && a(o.splice(0, o.length));
            }, r.delay));
        };
    }
    function y(e, t) {
        return Array.isArray(e) ? t(e.map(function(e) {
            return t = o(o({}, e), {
                msg: "string" == typeof e.msg ? e.msg : [].concat(e.msg).map(F).join(" ")
            }), s.forEach(function(e) {
                t[e] || delete t[e];
            }), t;
            var t;
        })) : t([ o(o({}, e), {
            msg: "string" == typeof e.msg ? e.msg : F(e.msg)
        }) ]);
    }
    function v(e, t) {
        return function(n, r) {
            var i, a, l, c = Array.isArray(n), u = c ? n : [ n ], f = (e.lifeCycle.emit("beforeRequest", n), 
            e.config.beforeRequest);
            (u = "function" == typeof f ? u.map(function(e) {
                try {
                    var n = f({
                        logs: e,
                        logType: t
                    });
                    return (null == n ? void 0 : n.logType) === t && null != n && n.logs ? n.logs : !1 !== n && e;
                } catch (n) {
                    return e;
                }
            }).filter(function(e) {
                return !1 !== e;
            }) : u).length && (i = u, n = s, !Array.isArray(i) || i.length <= 1 || (a = [], 
            l = [], !(l = "string" == typeof n ? [ n ] : n)) || l.length <= 0 || (l.forEach(function(e) {
                i.forEach(function(t) {
                    null != t && t[e] && a.push(e);
                });
            }), 0 < a.length && (i = i.map(function(e) {
                var t = {};
                return a.forEach(function(e) {
                    t[e] = "";
                }), o(o({}, t), e);
            }))), u = i, r(c ? u : u[0]));
        };
    }
    function b(t) {
        return function(n, o) {
            t.lifeCycle.emit("modifyRequest", n);
            var r = t.config.modifyRequest;
            if ("function" == typeof r) try {
                var i = r(n);
                "object" == e(i) && "url" in i && (n = i);
            } catch (n) {
                console.error(n);
            }
            o(n);
        };
    }
    function E(e) {
        return function(t, n) {
            null != (o = e.lifeCycle) && o.emit("afterRequest", t);
            var o = (e.config || {}).afterRequest;
            "function" == typeof o && !1 === o(t) || n(t);
        };
    }
    function O(e) {
        if (e && e.reduce && e.length) return 1 === e.length ? function(t, n) {
            e[0](t, n || Z);
        } : e.reduce(function(e, t) {
            return function(n, o) {
                return void 0 === o && (o = Z), e(n, function(e) {
                    return null == t ? void 0 : t(e, o);
                });
            };
        });
        throw new TypeError("createPipeline need at least one function param");
    }
    function R(e, t) {
        Object.getOwnPropertyNames(e).forEach(function(n) {
            "function" == typeof e[n] && "constructor" !== n && (t ? t[n] = "sendPipeline" === n ? function() {
                return function() {};
            } : function() {} : e[n] = function() {});
        });
    }
    function w(e) {
        try {
            var t, n, o, r = "";
            return r = e.pageUrl || (n = (t = getCurrentPages())[t.length - 1] || {}, i = n.options, 
            o = Object.keys(i).length ? "?" + Object.keys(i).map(function(e) {
                return e + "=" + i[e];
            }).join("&") : "", n.route ? n.route + o : ""), (r = "function" == typeof e.urlHandler ? e.urlHandler() : r).slice(0, 2048);
        } catch (e) {
            return "";
        }
        var i;
    }
    function P(e, t) {
        if ("string" == typeof e && "string" == typeof t) {
            if (e === t) return 1;
            for (var n = e.split("."), o = t.split("."), r = Math.max(n.length, o.length), i = 0; i < r; i++) {
                var a = ~~n[i], s = ~~o[i];
                if (a < s) return;
                if (s < a) return 1;
            }
        }
    }
    function k(e, t) {
        var n = this;
        this.taskQueue = [], this.count = 1, this.maxCount = 2, this.addTask = function(e) {
            n.taskQueue.push(e);
        }, this.fireTask = function() {
            var e = n.taskQueue.length;
            n.count > n.maxCount || 0 === e || (n.count = n.count + 1, (e = n.taskQueue.shift()) && n.sendRequest(e.options, null == e ? void 0 : e.success, null == e ? void 0 : e.fail));
        }, this.complete = function() {
            1 < n.count && (n.count = n.count - 1), n.fireTask();
        }, t && (this.maxCount = t), this.sendRequest = e;
    }
    function T(e) {
        return P(oe = oe || ne.getSystemInfoSync().SDKVersion, "1.1.1") && ne.canIUse ? ne.canIUse(e) : !!ne[e];
    }
    function S(e) {
        for (var t, n = {
            unknown: /unknown|none/i,
            wifi: /wifi/i,
            net2g: /2g/i,
            net3g: /3g/i,
            net4g: /4g/i,
            net5g: /5g/i,
            net6g: /6g/i
        }, o = q.unknown, r = 0; r < Object.keys(n).length; r++) {
            var i = Object.keys(n)[r];
            if (null != (t = n[i]) && t.test(e)) {
                o = q[i];
                break;
            }
        }
        return o;
    }
    function x(e) {
        var t = e.apiName, n = ce[t];
        n ? n.hackCloudReq.addCallback(e) : (n = le.cloud[t], ce[t] = {
            hackCloudReq: new ue(e),
            originApi: n
        }), ce[t];
    }
    function C(e) {
        var t = e.apiName, n = pe[t];
        n ? n.hackReq.addCallback(e) : (n = wx[t], pe[t] = {
            hackReq: new de(e),
            originApi: n
        }), pe[t];
    }
    var N, L, q, A, _, U, j, I, H, D = [ "ret", "retcode", "code", "errcode" ], M = function() {
        var t = new WeakSet();
        return function(n, o) {
            if (o instanceof Error) return "Error.message: " + o.message + " \n  Error.stack: " + o.stack;
            if ("object" == e(o) && null !== o) {
                if (t.has(o)) return "[Circular " + (n || "root") + "]";
                t.add(o);
            }
            return o;
        };
    }, F = function(e) {
        if ("string" == typeof e) return e;
        try {
            return e instanceof Error ? (JSON.stringify(e, M(), 4) || "undefined").replace(/"/gim, "") : JSON.stringify(e, M(), 4) || "undefined";
        } catch (e) {
            return "error happen when aegis stringify: \n " + e.message + " \n " + e.stack;
        }
    }, B = function t(n, o) {
        void 0 === o && (o = 3);
        var r, i, a, s = "";
        return Array.isArray(n) ? (s += "[", r = n.length, n.forEach(function(n, i) {
            s = (s += "object" == e(n) && 1 < o ? t(n, o - 1) : V(n)) + (i === r - 1 ? "" : ",");
        }), s += "]") : n instanceof Object ? (s = "{", i = Object.keys(n), a = i.length, 
        i.forEach(function(r, l) {
            "object" == e(n[r]) && 1 < o ? s += '"' + r + '":' + t(n[r], o - 1) : s += W(r, n[r]), 
            s += l === a - 1 || l < a - 1 && void 0 === n[i[l + 1]] ? "" : ",";
        }), s += "}") : s += n, s;
    }, W = function(t, n) {
        var o = e(n), r = "";
        return "string" == o || "object" == o ? r += '"' + t + '":"' + n + '"' : "function" == typeof n ? r += '"' + t + '":"function ' + n.name + '"' : "symbol" == e(n) ? r += '"' + t + '":"symbol"' : "number" != typeof n && "boolean" != o || (r += '"' + t + '": ' + n), 
        r;
    }, V = function(t) {
        var n = e(t);
        return "" + ("undefined" == n || "symbol" == n || "function" == n ? "null" : "string" == n || "object" == n ? '"' + t + '"' : t);
    }, G = /data:(image|text|application|font)\/.*;base64/, J = ((ee = N = N || {}).INFO_ALL = "-1", 
    ee.API_RESPONSE = "1", ee.INFO = "2", ee.ERROR = "4", ee.PROMISE_ERROR = "8", ee.AJAX_ERROR = "16", 
    ee.SCRIPT_ERROR = "32", ee.IMAGE_ERROR = "64", ee.CSS_ERROR = "128", ee.CONSOLE_ERROR = "256", 
    ee.MEDIA_ERROR = "512", ee.RET_ERROR = "1024", ee.REPORT = "2048", ee.PV = "4096", 
    ee.EVENT = "8192", ee.PAGE_NOT_FOUND_ERROR = "16384", ee.WEBSOCKET_ERROR = "32768", 
    ee.BRIDGE_ERROR = "65536", ee.LAZY_LOAD_ERROR = "131072", (ee = L = L || {})[ee.android = 1] = "android", 
    ee[ee.ios = 2] = "ios", ee[ee.windows = 3] = "windows", ee[ee.macos = 4] = "macos", 
    ee[ee.linux = 5] = "linux", ee[ee.devtools = 6] = "devtools", ee[ee.other = 100] = "other", 
    (ee = q = q || {})[ee.unknown = 100] = "unknown", ee[ee.wifi = 1] = "wifi", ee[ee.net2g = 2] = "net2g", 
    ee[ee.net3g = 3] = "net3g", ee[ee.net4g = 4] = "net4g", ee[ee.net5g = 5] = "net5g", 
    ee[ee.net6g = 6] = "net6g", (ee = A = A || {}).LOG = "log", ee.SPEED = "speed", 
    ee.PERFORMANCE = "performance", ee.OFFLINE = "offline", ee.WHITE_LIST = "whiteList", 
    ee.VITALS = "vitals", ee.PV = "pv", ee.CUSTOM_PV = "customPV", ee.EVENT = "event", 
    ee.CUSTOM = "custom", ee.SDK_ERROR = "sdkError", ee.SET_DATA = "setData", ee.LOAD_PACKAGE = "loadPackage", 
    (ee = _ = _ || {}).production = "production", ee.development = "development", ee.gray = "gray", 
    ee.pre = "pre", ee.daily = "daily", ee.local = "local", ee.test = "test", ee.others = "others", 
    function(e) {
        return e.filter(function(t, n) {
            return "static" !== t.type || !e.find(function(e, o) {
                return t.url === e.url && 200 === t.status && n < o;
            });
        });
    }), K = function(e) {
        e.level === N.INFO_ALL && (e.level = N.INFO);
    }, z = {}, $ = {}, Y = function(e) {
        return z[e] || (z[e] = setTimeout(function() {
            $[e] = {}, z[e] = null;
        }, 6e4)), z[e];
    }, Q = function(e) {
        return (Array.isArray(e) ? e : [ e ]).map(function(e) {
            return Object.getOwnPropertyNames(e).reduce(function(t, n) {
                return "ctx" !== n && (t[n] = e[n]), t;
            }, {
                level: N.INFO,
                msg: ""
            });
        });
    }, X = function(e) {
        return function(t) {
            return e.sendPipeline([ function(t, n) {
                return n({
                    url: e.config.url || "",
                    data: c(Q(t)),
                    method: "post",
                    contentType: "application/json",
                    type: A.LOG,
                    log: t,
                    requestConfig: {
                        timeout: 5e3
                    },
                    success: function() {
                        var o = e.config.onReport;
                        "function" == typeof o && t.forEach(function(e) {
                            o(e);
                        }), "function" == typeof n && n([]);
                    }
                });
            } ], A.LOG)(t);
        };
    }, Z = function() {}, ee = (Object.defineProperty(Oe.prototype, "__version__", {
        get: function() {
            return console.warn("__version__ has discard, please use version"), "1.41.6";
        },
        enumerable: !1,
        configurable: !0
    }), Object.defineProperty(Oe.prototype, "LogType", {
        get: function() {
            return console.warn("LogType has discard, please use logType"), N;
        },
        enumerable: !1,
        configurable: !0
    }), Oe.prototype.init = function(e) {
        this.setConfig(e);
        for (var t = 0; t < Oe.installedPlugins.length; t++) try {
            Oe.installedPlugins[t].patch(this);
        } catch (e) {
            this.sendSDKError(e);
        }
        this.lifeCycle.emit("onInited");
    }, Oe.prototype.setConfig = function(e) {
        Object.assign(this.config, e);
        var t = (e = this.config).id, n = e.uin, o = e.version, r = e.ext1, i = e.ext2, a = e.ext3, s = e.aid, l = void 0 === (c = e.env) ? "production" : c, c = e.pageUrl;
        e = this.bean.id !== t || this.bean.uin !== n || this.bean.aid !== s;
        return this.bean.id = t || "", this.bean.uin = n || "", this.bean.version = o || "1.41.6", 
        this.bean.aid = s || "", this.bean.env = function() {
            switch (l) {
              case _.production:
              case _.development:
              case _.gray:
              case _.pre:
              case _.daily:
              case _.local:
              case _.test:
              case _.others:
                return 1;

              default:
                return;
            }
        }() ? l : _.others, c && this.extendBean("from", encodeURIComponent(c.slice(0, 2048))), 
        r && this.extendBean("ext1", encodeURIComponent(r)), i && this.extendBean("ext2", encodeURIComponent(i)), 
        a && this.extendBean("ext3", encodeURIComponent(a)), e && this.lifeCycle.emit("onConfigChange", this.config), 
        this.config;
    }, Oe.use = function(e) {
        -1 === Oe.installedPlugins.indexOf(e) && e.aegisPlugin && Oe.installedPlugins.push(e);
    }, Oe.unuse = function(e) {
        -1 !== (e = Oe.installedPlugins.indexOf(e)) && Oe.installedPlugins.splice(e, 1);
    }, Oe.prototype.info = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = {
            level: N.INFO,
            msg: e
        };
        1 === e.length && e[0].msg && Object.assign(n, o({}, e[0]), {
            level: N.INFO
        }), this.normalLogPipeline(n);
    }, Oe.prototype.infoAll = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = {
            level: N.INFO_ALL,
            msg: e
        };
        1 === e.length && e[0].msg && Object.assign(n, o({}, e[0]), {
            level: N.INFO_ALL
        }), this.normalLogPipeline(n);
    }, Oe.prototype.report = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = {
            level: N.REPORT,
            msg: e
        };
        1 === e.length && e[0].msg && Object.assign(n, o({}, e[0])), this.normalLogPipeline(n);
    }, Oe.prototype.error = function() {
        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
        var n = {
            level: N.ERROR,
            msg: e
        };
        1 === e.length && e[0].msg && Object.assign(n, o({}, e[0]), {
            level: N.ERROR
        }), this.normalLogPipeline(n);
    }, Oe.prototype.speedLogPipeline = function(e) {
        throw new Error('You need to override "speedLogPipeline" method');
    }, Oe.prototype.reportPv = function(e) {
        var t, n = this;
        e && (console.warn("reportPv is deprecated, please use reportEvent"), t = "" + Object.getOwnPropertyNames(this.bean).filter(function(e) {
            return "id" !== e;
        }).map(function(e) {
            return e + "=" + n.bean[e];
        }).join("&"), this.sendPipeline([ function(o, r) {
            r({
                url: n.config.url + "/" + e + "?" + t,
                addBean: !1,
                type: A.CUSTOM_PV
            });
        } ], A.CUSTOM_PV)(null));
    }, Oe.prototype.reportEvent = function(e) {
        e && ((e = "string" == typeof e ? {
            name: e,
            ext1: this.config.ext1 || "",
            ext2: this.config.ext2 || "",
            ext3: this.config.ext3 || ""
        } : e).name ? ("string" != typeof e.name && (console.warn("reportEvent params name must be string"), 
        e.name = String(e.name)), this.eventPipeline(e)) : console.warn("reportEvent params error"));
    }, Oe.prototype.reportTime = function(t, n) {
        if ("object" == e(t)) return this.reportT(t);
        "string" == typeof t ? "number" == typeof n ? n < 0 || 6e4 < n ? console.warn("reportTime: duration must between 0 and 60000") : this.submitCustomTime(t, n) : console.warn("reportTime: second param must be number") : console.warn("reportTime: first param must be a string");
    }, Oe.prototype.reportT = function(e) {
        var t = e.name, n = e.duration, o = void 0 === (o = e.ext1) ? "" : o, r = void 0 === (r = e.ext2) ? "" : r, i = void 0 === (i = e.ext3) ? "" : i;
        e = e.from;
        if ("string" == typeof t && "number" == typeof n && "string" == typeof o && "string" == typeof r && "string" == typeof i) {
            if (!(n < 0 || 6e4 < n)) return this.submitCustomTime(t, n, o, r, i, void 0 === e ? "" : e);
            console.warn("reportTime: duration must between 0 and 60000");
        } else console.warn("reportTime: params error");
    }, Oe.prototype.time = function(e) {
        "string" == typeof e ? this.timeMap[e] ? console.warn("Timer " + e + " already exists") : this.timeMap[e] = Date.now() : console.warn("time: first param must be a string");
    }, Oe.prototype.timeEnd = function(e) {
        "string" == typeof e ? this.timeMap[e] ? (this.submitCustomTime(e, Date.now() - this.timeMap[e]), 
        delete this.timeMap[e]) : console.warn("Timer " + e + " does not exist") : console.warn("timeEnd: first param must be a string");
    }, Oe.prototype.submitCustomTime = function(e, t, n, o, r, i) {
        this.customTimePipeline({
            name: e,
            duration: t,
            ext1: n || this.config.ext1,
            ext2: o || this.config.ext2,
            ext3: r || this.config.ext3,
            from: i || void 0
        });
    }, Oe.prototype.extendBean = function(e, t) {
        this.bean[e] = t;
    }, Oe.prototype.sendPipeline = function(e, t) {
        var n, o = this;
        return O(r([ function(e, t) {
            if ("number" != typeof n.config.random && (console.warn("random must in [0, 1], default is 1."), 
            n.config.random = 1), !n.isHidden || !n.isGetSample) if (n.isGetSample) n.isHidden || t(e); else {
                if (n.isGetSample = !0, Math.random() < n.config.random) return n.isHidden = !1, 
                t(e);
                n.isHidden = !0;
            }
        }, v(n = this, t) ], e, [ b(this), function(e, t) {
            o.request(e, function() {
                for (var n = [], i = 0; i < arguments.length; i++) n[i] = arguments[i];
                var a = !1;
                -1 < ("" + n[o.failRequestCount = 0]).indexOf("403 forbidden") && (a = !0, o.destroy()), 
                t({
                    isErr: a,
                    result: n,
                    logType: null == e ? void 0 : e.type,
                    logs: null == e ? void 0 : e.log
                }), null != (a = null == e ? void 0 : e.success) && a.call.apply(a, r([ e ], n));
            }, function() {
                for (var n, i = [], a = 0; a < arguments.length; a++) i[a] = arguments[a];
                60 <= ++o.failRequestCount && o.destroy(), -1 < ("" + i[0]).indexOf("403 forbidden") && o.destroy(), 
                t({
                    isErr: !0,
                    result: i,
                    logType: null == e ? void 0 : e.type,
                    logs: null == e ? void 0 : e.log
                }), null != (n = null == e ? void 0 : e.fail) && n.call.apply(n, r([ e ], i));
            });
        }, E(this) ]));
    }, Oe.prototype.send = function(e, t, n) {
        var o = this;
        return O([ b(this), function(e, r) {
            o.request(e, function() {
                for (var n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
                r({
                    isErr: !1,
                    result: n,
                    logType: e.type,
                    logs: e.log
                }), null != t && t.apply(void 0, n);
            }, function() {
                for (var t = [], o = 0; o < arguments.length; o++) t[o] = arguments[o];
                r({
                    isErr: !0,
                    result: t,
                    logType: e.type,
                    logs: e.log
                }), null != n && n.apply(void 0, t);
            });
        }, E(this) ])(e);
    }, Oe.prototype.ready = function(e, t, n) {
        throw new Error('You need to override "ready" method');
    }, Oe.prototype.request = function(e, t, n) {
        throw new Error('You need to override "request" method');
    }, Oe.prototype.sendSDKError = function(e) {
        var t = this;
        this.sendPipeline([ function(e, n) {
            n({
                url: t.config.url + "?id=1085&msg[0]=" + encodeURIComponent(F(e)) + "&level[0]=2&from=" + t.config.id + "&count=1&version=" + t.config.id + "(1.41.6)",
                addBean: !1,
                method: "get",
                type: A.SDK_ERROR,
                log: e
            });
        } ], A.SDK_ERROR)(e);
    }, Oe.prototype.destroy = function(e) {
        void 0 === e && (e = !1);
        var t, n, o = Oe.instances.indexOf(this);
        -1 !== o && Oe.instances.splice(o, 1);
        for (var r = Oe.installedPlugins.length - 1; 0 <= r; r--) try {
            Oe.installedPlugins[r].unpatch(this);
        } catch (e) {
            this.sendSDKError(e);
        }
        if (this.lifeCycle.emit("destroy"), this.lifeCycle.clear(), e) t = this, n = Object.getOwnPropertyDescriptors(t), 
        Object.keys(n).forEach(function(e) {
            n[e].writable && (t[e] = null);
        }), Object.setPrototypeOf(this, null); else {
            for (var i = this; i.constructor !== Object && R(i, this), i = Object.getPrototypeOf(i); ) ;
            0 === Oe.instances.length && (R(o = Object.getPrototypeOf(this).constructor), R(Oe));
        }
    }, Oe.version = "1.41.6", Oe.instances = [], Oe.logType = N, Oe.environment = _, 
    Oe.installedPlugins = [], Oe), te = (Ee.prototype.patch = function(e) {
        this.canUse(e) && this.exist(e) && (this.instances.push(e), this.triggerInit(e), 
        this.triggerOnNewAegis(e));
    }, Ee.prototype.unpatch = function(e) {
        var t = this.instances.indexOf(e);
        -1 !== t && (this.instances.splice(t, 1), 0 === this.instances.length) && this.uninstall(e);
    }, Ee.prototype.countInstance = function() {
        return this.instances.length;
    }, Ee.prototype.uninstall = function(e) {
        var t;
        null != (t = null == (t = this.option) ? void 0 : t.destroy) && t.apply(this, [ e ]);
    }, Ee.prototype.walk = function(e) {
        var t = this;
        this.instances.forEach(function(n) {
            var o = t.canUse(n);
            o && e(n, o);
        });
    }, Ee.prototype.canUse = function(t) {
        return !(!(t = this.getConfig(t)) || "object" != e(t)) || !!t;
    }, Ee.prototype.getConfig = function(e) {
        return null == (e = e.config) ? void 0 : e[this.name];
    }, Ee.prototype.exist = function(e) {
        return -1 === this.instances.indexOf(e);
    }, Ee.prototype.triggerInit = function(e) {
        var t;
        this.inited || (this.inited = !0, null == (t = null == (t = this.option) ? void 0 : t.init)) || t.call(this.option, this.getConfig(e));
    }, Ee.prototype.triggerOnNewAegis = function(e) {
        var t;
        null != (t = null == (t = this.option) ? void 0 : t.onNewAegis) && t.call(this.option, e, this.getConfig(e));
    }, Ee), ne = wx || qq, oe = "", re = new te({
        name: "device",
        onNewAegis: function(e) {
            return t = this, r = function() {
                return function(e, t) {
                    var n, o, r, i = {
                        label: 0,
                        sent: function() {
                            if (1 & r[0]) throw r[1];
                            return r[1];
                        },
                        trys: [],
                        ops: []
                    }, a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    };
                    return "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                        return this;
                    }), a;
                    function s(a) {
                        return function(s) {
                            var l = [ a, s ];
                            if (n) throw new TypeError("Generator is already executing.");
                            for (;i; ) try {
                                if (n = 1, o && (r = 2 & l[0] ? o.return : l[0] ? o.throw || ((r = o.return) && r.call(o), 
                                0) : o.next) && !(r = r.call(o, l[1])).done) return r;
                                switch (o = 0, (l = r ? [ 2 & l[0], r.value ] : l)[0]) {
                                  case 0:
                                  case 1:
                                    r = l;
                                    break;

                                  case 4:
                                    return i.label++, {
                                        value: l[1],
                                        done: !1
                                    };

                                  case 5:
                                    i.label++, o = l[1], l = [ 0 ];
                                    continue;

                                  case 7:
                                    l = i.ops.pop(), i.trys.pop();
                                    continue;

                                  default:
                                    if (!((r = 0 < (r = i.trys).length && r[r.length - 1]) || 6 !== l[0] && 2 !== l[0])) {
                                        i = 0;
                                        continue;
                                    }
                                    if (3 === l[0] && (!r || l[1] > r[0] && l[1] < r[3])) i.label = l[1]; else if (6 === l[0] && i.label < r[1]) i.label = r[1], 
                                    r = l; else {
                                        if (!(r && i.label < r[2])) {
                                            r[2] && i.ops.pop(), i.trys.pop();
                                            continue;
                                        }
                                        i.label = r[2], i.ops.push(l);
                                    }
                                }
                                l = t.call(e, i);
                            } catch (s) {
                                l = [ 6, s ], o = 0;
                            } finally {
                                n = r = 0;
                            }
                            if (5 & l[0]) throw l[1];
                            return {
                                value: l[0] ? l[1] : void 0,
                                done: !0
                            };
                        };
                    }
                }(this, function(t) {
                    return this.setSystemInfo(e), this.setNetworkType(e), this.setNetworkChange(e), 
                    [ 2 ];
                });
            }, new (o = (o = n = void 0) || Promise)(function(e, i) {
                function a(e) {
                    try {
                        l(r.next(e));
                    } catch (e) {
                        i(e);
                    }
                }
                function s(e) {
                    try {
                        l(r.throw(e));
                    } catch (e) {
                        i(e);
                    }
                }
                function l(t) {
                    var n;
                    t.done ? e(t.value) : ((n = t.value) instanceof o ? n : new o(function(e) {
                        e(n);
                    })).then(a, s);
                }
                l((r = r.apply(t, n || [])).next());
            });
            var t, n, o, r;
        },
        setSystemInfo: function(e) {
            var t = this;
            try {
                T("getSystemInfo") && ne.getSystemInfo({
                    success: function(n) {
                        var o = n.platform, r = n.model, i = n.windowHeight, a = n.windowWidth, s = void 0 === (s = n.screenWidth) ? 0 : s;
                        n = void 0 === (n = n.screenHeight) ? 0 : n;
                        e.extendBean("platform", t.getPlatFormType(o)), e.extendBean("model", r), e.extendBean("vp", Math.round(a) + " * " + Math.round(i)), 
                        e.extendBean("sr", Math.round(s) + " * " + Math.round(n));
                    }
                });
            } catch (e) {}
        },
        getPlatFormType: function(e) {
            for (var t, n = {
                android: /android/i,
                ios: /ios/i,
                windows: /windows/i,
                macos: /mac/i,
                devtools: /devtools/i
            }, o = L.other, r = 0; r < Object.keys(n).length; r++) {
                var i = Object.keys(n)[r];
                if (null != (t = n[i]) && t.test(e)) {
                    o = L[i];
                    break;
                }
            }
            return o;
        },
        setNetworkChange: function(e) {
            T("onNetworkStatusChange") && ne.onNetworkStatusChange(function(t) {
                t = S(t.networkType), e.extendBean("netType", t);
            });
        },
        setNetworkType: function(e) {
            T("getNetworkType") && ne.getNetworkType({
                success: function(t) {
                    t = S(t.networkType), e.extendBean("netType", t);
                }
            });
        }
    }), ie = ne.request, ae = (ee = (n(be, I = ee), Object.defineProperty(be.prototype, "getBean", {
        get: function() {
            var e = this;
            return this.bean ? Object.getOwnPropertyNames(this.bean).map(function(t) {
                return t + "=" + e.bean[t];
            }).join("&") + "&from=" + encodeURIComponent(w(this.config)) : "from=" + encodeURIComponent(w(this.config));
        },
        enumerable: !1,
        configurable: !0
    }), be.prototype.initRequestSchedule = function() {
        this.requestSchedule = new k(this.sendRequest);
    }, be.prototype.uploadLogs = function(e, t) {
        this.lifeCycle.emit("uploadLogs", e = void 0 === e ? {} : e, t = void 0 === t ? {} : t);
    }, be.prototype.reportPv = function(e) {
        var t, n = this;
        e && (t = Object.getOwnPropertyNames(this.bean).filter(function(e) {
            return "id" !== e;
        }).map(function(e) {
            return e + "=" + n.bean[e];
        }).join("&") + "&from=" + encodeURIComponent(w(this.config)), this.send({
            url: this.config.url + "/" + e + "?" + t,
            addBean: !1,
            type: A.CUSTOM_PV,
            log: A.CUSTOM_PV
        }, function() {}, function() {}));
    }, be.sessionID = "session-" + Date.now(), be.asyncPluginIndex = 0, be), new te({
        name: "aid",
        onNewAegis: function(e) {
            this.initAid(function(t) {
                e.bean.aid = t, e.config.aid = t;
            });
        },
        initAid: function(e) {
            ne.getStorage({
                key: "AEGIS_ID",
                success: function(t) {
                    e(t.data);
                },
                fail: function() {
                    var t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                        var t = 16 * Math.random() | 0;
                        return ("x" === e ? t : 3 & t | 8).toString(16);
                    });
                    ne.setStorage({
                        key: "AEGIS_ID",
                        data: t,
                        success: function() {
                            e(t);
                        }
                    });
                }
            });
        }
    })), se = (ve.prototype.addCallback = function(e) {
        e && this.callbacks.push(e);
    }, ve.prototype.prefixHandler = function(e) {
        return o(o({}, e), {
            aegisRequestStartTime: +new Date()
        });
    }, ve.prototype.successHandler = function(e, t) {
        var n;
        this.callbacks.forEach(function(n) {
            var o;
            try {
                null != (o = n.success) && o.call(n, e, t);
            } catch (n) {}
        }), null != (n = t.success) && n.call(t, e, t);
    }, ve.prototype.failHandler = function(e, t) {
        var n;
        this.callbacks.forEach(function(n) {
            var o;
            try {
                null != (o = n.fail) && o.call(n, e, t);
            } catch (n) {}
        }), null != (n = t.fail) && n.call(t, e, t);
    }, ve.prototype.completeHandler = function(e, t) {
        var n;
        this.callbacks.forEach(function(n) {
            var o;
            try {
                null != (o = n.complete) && o.call(n, e, t);
            } catch (n) {}
        }), null != (n = t.complete) && n.call(t, e, t);
    }, ve.prototype.override = function() {
        try {
            this.defineApiProperty();
        } catch (e) {
            console.warn("cannot override `" + this.apiName + "`, error is: " + e);
        } finally {
            this.isOverride = !0;
        }
    }, ve), le = wx || qq, ce = {}, ue = (n(ye, j = se), ye.prototype.defineApiProperty = function() {
        var e = this;
        le.cloud && le.cloud[this.apiName] && Object.defineProperty(le.cloud, this.apiName, {
            get: function() {
                return e.hackHandler.bind(e);
            }
        });
    }, ye.prototype.hackHandler = function(e) {
        var t = this, n = this.prefixHandler(e);
        return new Promise(function(e, r) {
            var i = null == (i = ce[t.apiName]) ? void 0 : i.originApi;
            null != i && i(o(o({}, n), {
                success: function(o) {
                    t.successHandler(o, n), e(o);
                },
                fail: function(e) {
                    t.failHandler(e, n), r(e);
                },
                complete: function(e) {
                    t.completeHandler(e, n);
                }
            }));
        });
    }, ye), fe = wx || qq, pe = {}, de = (n(me, U = se), me.prototype.defineApiProperty = function() {
        var e = this;
        Object.defineProperty(fe, this.apiName, {
            get: function() {
                return e.hackHandler.bind(e);
            }
        });
    }, me.prototype.hackHandler = function(e) {
        var t = this, n = this.prefixHandler(e);
        return null == (e = null == (e = pe[this.apiName]) ? void 0 : e.originApi) ? void 0 : e(o(o({}, n), {
            success: function(e) {
                t.successHandler(e, n);
            },
            fail: function(e) {
                t.failHandler(e, n);
            },
            complete: function(e) {
                t.completeHandler(e, n);
            }
        }));
    }, me), he = wx || qq, ge = he.request;
    function me() {
        return null !== U && U.apply(this, arguments) || this;
    }
    function ye() {
        return null !== j && j.apply(this, arguments) || this;
    }
    function ve(e) {
        this.callbacks = [], this.isOverride = !1;
        var t = e.apiName;
        this.apiName = t, this.isOverride || this.override(), this.callbacks.push(e);
    }
    function be(t) {
        var n, r, i = I.call(this, t) || this;
        i.originRequest = ie, i.speedLogPipeline = O([ (r = i.config, function(e, t) {
            var n, o, i, a = "number" == typeof r.repeat ? r.repeat : 60;
            !r.speedSample || a <= 0 ? t(e) : (n = (null == r ? void 0 : r.id) || "0", o = $[n] || {}, 
            Array.isArray(e) ? (i = e.filter(function(e) {
                var t = !o[e.url] || o[e.url] < a;
                return t ? (o[e.url] = 1 + ~~o[e.url], $[n] = o) : z[n] || Y(n), t;
            })).length && t(i) : !o[e.url] || o[e.url] < a ? (o[e.url] = 1 + ~~o[e.url], $[n] = o, 
            t(e)) : z[n] || Y(n));
        }), m(i), function(e, t) {
            T("getNetworkType") ? ne.getNetworkType({
                success: function(o) {
                    o = S(o.networkType), n.extendBean("netType", o), t(e);
                }
            }) : t(e);
        }, function(e, t) {
            i.lifeCycle.emit("beforeReportSpeed", e);
            var n = i.config.beforeReportSpeed;
            if ((e = "function" == typeof n ? e.filter(function(e) {
                return !1 !== n(e);
            }) : e).length) return t(e);
        }, v(n = i, A.SPEED), function(e, t) {
            t(e.map(function(e) {
                return void 0 !== e.payload && delete e.payload, e;
            }));
        }, function(e) {
            var t, n, r, a;
            i.send({
                url: "" + i.config.speedUrl,
                method: "post",
                data: (e = e, t = i.bean, r = {
                    fetch: [],
                    static: [],
                    bridge: []
                }, a = {}, Array.isArray(e) ? e.forEach(function(e) {
                    var t;
                    null != (t = r[e.type]) && t.push(e);
                }) : null != (n = r[e.type]) && n.push(e), a.payload = JSON.stringify(o({
                    duration: r
                }, t)), a)
            });
        } ]), i.request = function(e, t, n) {
            e.url && i.bean.id && (!/^\w{8}-\w{4}-\w{4}-\w{4}-\w{12}$/.test(String(i.bean.aid)) || T("getNetworkType") && void 0 === i.bean.netType ? i.requestSchedule.addTask({
                options: e,
                success: t,
                fail: n
            }) : (i.requestSchedule.addTask({
                options: e,
                success: t,
                fail: n
            }), i.requestSchedule.fireTask()));
        }, i.sendRequest = function(t, n, r) {
            var a, s, l, c = t.url, u = void 0 === (u = (i.config.whiteListUrl === c && (a = n, 
            n = function(e) {
                null != a && a(JSON.stringify(e.data));
            }), t.method)) ? "get" : u, f = (!1 !== t.addBean && (c = c + (-1 === (null == c ? void 0 : c.indexOf("?")) ? "?" : "&") + i.getBean), 
            t), p = i.config.onBeforeRequest;
            return (f = p ? p(t, i) : f) && f.url ? (p = i.config.enableHttp2 || !1, "get" === u ? (u = c, 
            s = f.data, c = "string" != typeof u ? "" : "object" == e(s) && s ? (l = Object.getOwnPropertyNames(s).map(function(e) {
                var t = s[e];
                return e + "=" + ("string" == typeof t ? encodeURIComponent(t) : encodeURIComponent(JSON.stringify(t)));
            }).join("&").replace(/eval/gi, "evaI"), u + (-1 === u.indexOf("?") ? "?" : "&") + l) : u, 
            i.originRequest(o({
                url: c,
                enableHttp2: p,
                success: n,
                fail: r,
                complete: i.requestSchedule.complete
            }, t.requestConfig))) : ("string" == typeof f.data && (f.data = f.data.replace(/eval/gi, "evaI")), 
            i.originRequest(o({
                url: c,
                enableHttp2: p,
                header: f.contentType ? {
                    "content-type": f.contentType
                } : void 0,
                method: "POST",
                data: f.data,
                success: n,
                fail: r,
                complete: i.requestSchedule.complete
            }, t.requestConfig))), !0) : (l = "", f && f.url || (l = "Sending request blocked. Please handle the parameters reasonably, options.url is necessary", 
            console.log(l)), null != r && r(l), i.requestSchedule.complete(), !1);
        };
        try {
            i.initRequestSchedule(), i.init(t), i.extendBean("sessionId", be.sessionID), i.extendBean("referer", (T("getLaunchOptionsSync") ? ne.getLaunchOptionsSync() : {
                scene: ""
            }).scene || "");
        } catch (t) {
            console.warn(t), console.log("%cThe above error occurred in the process of initializing Aegis, which will affect your normal use of Aegis.\nIt is recommended that you contact us for feedback and thank you for your support.", "color: red"), 
            i.sendSDKError(t);
        }
        return i;
    }
    function Ee(e) {
        this.aegisPlugin = !0, this.name = "", this.instances = [], this.inited = !1, e.$walk = this.walk.bind(this), 
        e.$getConfig = this.getConfig.bind(this), this.option = e, this.name = e.name;
    }
    function Oe(e) {
        var t, n, o, r, i, a, s, c, u, f, p, d, h, g, v = this;
        this.isGetSample = !1, this.isHidden = !1, this.config = {
            version: 0,
            delay: 1e3,
            onError: !0,
            repeat: 60,
            random: 1,
            aid: !0,
            device: !0,
            pagePerformance: !0,
            webVitals: !0,
            speedSample: !0,
            onClose: !0,
            reportLoadPackageSpeed: !0,
            hostUrl: "https://aegis.qq.com",
            env: "production",
            url: "",
            offlineUrl: "",
            whiteListUrl: "",
            pvUrl: "",
            speedUrl: "",
            customTimeUrl: "",
            performanceUrl: "",
            webVitalsUrl: "",
            eventUrl: "",
            setDataReportUrl: "",
            reportImmediately: !0
        }, this.isWhiteList = !1, this.lifeCycle = new l(), this.bean = {}, this.normalLogPipeline = O([ m(this, 5), y, function(e, n) {
            var o = t.config;
            n(e = e.map(function(e) {
                var t, n = o.maxLength || 102400;
                try {
                    if (!e.msg || e.msg.length <= n) return e;
                    e.msg = null == (t = e.msg) ? void 0 : t.substring(0, n);
                } catch (t) {
                    e.msg = F(e.msg).substring(0, o.maxLength);
                }
                return e;
            }));
        }, (g = (t = this).config, function(e, t) {
            var n = "number" == typeof g.repeat ? g.repeat : 60;
            if (n <= 0) return t(e);
            var o = (null == g ? void 0 : g.id) + "_error", r = $[o] || {};
            t(e.filter(function(e) {
                if (e.level === N.ERROR || e.level === N.PROMISE_ERROR || e.level === N.AJAX_ERROR || e.level === N.SCRIPT_ERROR || e.level === N.IMAGE_ERROR || e.level === N.CSS_ERROR || e.level === N.MEDIA_ERROR || e.level === N.RET_ERROR || e.level === N.BRIDGE_ERROR || e.level === N.PAGE_NOT_FOUND_ERROR || e.level === N.WEBSOCKET_ERROR || e.level === N.LAZY_LOAD_ERROR) {
                    if (e = e.msg.slice(0, 200), r[e] > n) return z[o] || Y(o), !1;
                    r[e] = 1 + ~~r[e], $[o] = r;
                }
                return !0;
            }));
        }), (d = this.lifeCycle.emit, h = this.config, function(e, t) {
            var n, o = h.logCreated;
            return "function" == typeof o ? (n = e.filter(function(e) {
                return !1 !== o(e);
            }), d("beforeWrite", n), t(n)) : (d("beforeWrite", e), t(e));
        }), (p = this, setTimeout(function() {
            var e = void 0 === (t = (n = p.config).pvUrl) ? "" : t, t = n.spa, n = -1 < [ "web-sdk", "mp-sdk" ].indexOf("mp-sdk");
            e && (n && !t || !n) && p.sendPipeline([ function(t, n) {
                n({
                    url: e,
                    type: A.PV
                });
            } ], A.PV)(null);
        }, 100), function(e, t) {
            t(e);
        }), (u = c = s = !1, f = [], (i = this).lifeCycle.on("onConfigChange", function() {
            a && clearTimeout(a), a = setTimeout(function() {
                var e, t;
                !u && i.config && (u = !0, e = i.config.whiteListUrl, (t = void 0 === e ? "" : e) && i.sendPipeline([ function(e, n) {
                    n({
                        url: t,
                        type: A.WHITE_LIST,
                        success: function(e) {
                            c = !0;
                            try {
                                var t = e.data || JSON.parse(e), n = t.retcode, o = t.result, r = void 0 === o ? {} : o, a = (0 === n && (s = r.is_in_white_list, 
                                i.isWhiteList = s, 0 <= r.rate) && r.rate <= 1 && (i.config.random = r.rate, i.isGetSample = !1), 
                                i.isWhiteList && f.length ? X(i)(f.splice(0), function() {}) : !i.isWhiteList && f.length && (f.length = 0), 
                                i.config.onWhitelist);
                                "function" == typeof a && a(s);
                            } catch (e) {}
                        },
                        fail: function() {
                            c = !0;
                        }
                    });
                } ], A.WHITE_LIST)(null), u = !1);
            }, i.config.uin ? 50 : 500);
        }), i.lifeCycle.on("destroy", function() {
            f.length = 0;
        }), function(e, t) {
            var n;
            s || null != (n = null == (n = i.config) ? void 0 : n.api) && n.reportRequest ? t(e.concat(f.splice(0)).map(function(e) {
                return K(e), e;
            })) : (n = e.filter(function(e) {
                return e.level !== N.INFO && e.level !== N.API_RESPONSE ? (K(e), !0) : (c || (f.push(e), 
                200 <= f.length && (f.length = 200)), !1);
            })).length && t(n);
        }), function(e, t) {
            try {
                var n = JSON.parse(JSON.stringify(e)), o = (v.lifeCycle.emit("beforeReport", n), 
                v.config.beforeReport);
                (e = "function" == typeof o ? e.filter(function(e) {
                    return !1 !== o(e);
                }) : e).length && t(e);
            } catch (e) {}
        }, X(this) ]), this.eventPipeline = O([ m(this, 10), (r = this, function(e) {
            r.sendPipeline([ function(e, t) {
                var n = e.map(function(e) {
                    return {
                        name: e.name,
                        ext1: e.ext1 || r.config.ext1 || "",
                        ext2: e.ext2 || r.config.ext2 || "",
                        ext3: e.ext3 || r.config.ext3 || ""
                    };
                });
                t({
                    url: r.config.eventUrl + "?payload=" + encodeURIComponent(JSON.stringify(n)),
                    type: A.EVENT,
                    log: e
                });
            } ], A.EVENT)(e);
        }) ]), this.timeMap = {}, this.failRequestCount = 0, this.customTimePipeline = O([ m(this, 10), (o = this, 
        function(e) {
            return o.sendPipeline([ function(e, t) {
                t({
                    url: o.config.customTimeUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                        custom: e
                    })),
                    type: A.CUSTOM,
                    log: e
                });
            } ], A.CUSTOM)(e);
        }) ]), this.config = (n = this.config, void 0 === (e = e.hostUrl) && (e = "https://aegis.qq.com"), 
        n.url = n.url || e + "/collect", n.offlineUrl = n.offlineUrl || e + "/offline", 
        n.whiteListUrl = n.whiteListUrl || e + "/collect/whitelist", n.pvUrl = n.pvUrl || e + "/collect/pv", 
        n.eventUrl = n.eventUrl || e + "/collect/events", n.speedUrl = n.speedUrl || e + "/speed", 
        n.customTimeUrl = n.customTimeUrl || e + "/speed/custom", n.performanceUrl = n.performanceUrl || e + "/speed/performance", 
        n.webVitalsUrl = n.webVitalsUrl || e + "/speed/webvitals", n.setDataReportUrl = n.SetDataReportUrl || e + "/speed/miniProgramData", 
        n), Oe.instances.push(this);
    }
    function Re() {
        return null !== H && H.apply(this, arguments) || this;
    }
    function we(t, n, o) {
        return null != n && n.length && "object" == e(t) ? n.reduce(function(e, n) {
            var r = t[n];
            return r ? e + ("" === e ? "\n" : "\n\n") + o + " header " + n + ": " + r : e;
        }, "") : "";
    }
    n(Re, H = se), Re.prototype.defineApiProperty = function() {
        var e = this;
        Object.defineProperty(he, "request", {
            get: function() {
                return e.hackHandler.bind(e);
            }
        });
    };
    var Pe, ke, Te = new te({
        name: "reportApiSpeed",
        override: !(Re.prototype.hackHandler = function(e) {
            var t = this, n = this.prefixHandler(e);
            return ge(o(o({}, n), {
                success: function(e) {
                    t.successHandler(e, n);
                },
                fail: function(e) {
                    t.failHandler(e, n);
                },
                complete: function(e) {
                    t.completeHandler(e, n);
                }
            }));
        }),
        onNewAegis: function(e) {
            this.override || (this.override = !0, this.hackRequest(e.config), this.overrideCallFunction(e.config), 
            this.overrideCallContainer(e.config));
        },
        hackRequest: function(e) {
            var t = this;
            C({
                apiName: "request",
                success: function(n, o) {
                    var r, i, a, s, l, c, u;
                    g(o.url, e.hostUrl) || (r = {
                        method: o.method || "get",
                        url: f(o.url),
                        duration: Date.now() - o.aegisRequestStartTime,
                        status: n.statusCode || 0,
                        nextHopProtocol: "",
                        isHttps: p(o.url),
                        type: "fetch"
                    }, s = null == (s = e.api) ? void 0 : s.apiDetail, i = (a = d(n.data, e.api, {
                        url: o.url,
                        ctx: n,
                        payload: o.data
                    }) || {}).code, a = a.isErr, u = s ? h(o.data, null == (u = e.api) ? void 0 : u.reqParamHandler, {
                        url: o.url
                    }) : "", s = s ? h(n.data, null == (s = e.api) ? void 0 : s.resBodyHandler, {
                        url: o.url
                    }) : "", l = (null == (l = e.api) ? void 0 : l.reqHeaders) || [], l = we(null == o ? void 0 : o.header, l, "req"), 
                    c = (null == (c = e.api) ? void 0 : c.resHeaders) || [], c = we(null == n ? void 0 : n.header, c, "res"), 
                    u = "req url: " + r.url + " \n                        \nres status: " + (n.statusCode || 0) + " \n                        \nres duration: " + r.duration + "ms \n                        \nreq method: " + r.method + " \n                        \nreq param: " + u + "  \n                        \nres retcode: " + i + " \n                        \nres data: " + s + "\n                        " + l + "\n                        " + c, 
                    t.publishNormalLog({
                        msg: u,
                        level: N.API_RESPONSE,
                        ctx: n
                    }), r.ret = i, r.isErr = +a, r.payload = o.data, t.publishSpeedLog(r), a && t.publishNormalLog({
                        msg: u,
                        level: N.RET_ERROR,
                        ctx: n
                    }));
                },
                fail: function(n, o) {
                    g(o.url, e.hostUrl) || (o = {
                        method: o.method || "get",
                        url: f(o.url),
                        duration: Date.now() - o.aegisRequestStartTime,
                        status: 0,
                        nextHopProtocol: "",
                        isHttps: p(o.url),
                        type: "fetch"
                    }, t.publishSpeedLog(o));
                }
            });
        },
        overrideCallFunction: function(e) {
            var t = this;
            x({
                apiName: "callFunction",
                success: function(n, o) {
                    t.cloudSuccessCallback(e, o, n, "callFunction");
                },
                fail: function(e, n) {
                    n = {
                        method: "call",
                        url: "wx.cloud.callFunction." + n.name,
                        duration: Date.now() - n.aegisRequestStartTime,
                        status: 0,
                        nextHopProtocol: "",
                        type: "fetch",
                        errMsg: e.errMsg,
                        isHttps: !0
                    }, t.publishSpeedLog(n);
                }
            });
        },
        overrideCallContainer: function(e) {
            var t = this;
            x({
                apiName: "callContainer",
                success: function(n, o) {
                    t.cloudSuccessCallback(e, o, n, "callContainer");
                },
                fail: function(e, n) {
                    n = {
                        method: "call",
                        url: "wx.cloud.callContainer." + n.path,
                        duration: Date.now() - n.aegisRequestStartTime,
                        status: 0,
                        nextHopProtocol: "",
                        type: "fetch",
                        errMsg: e.errMsg,
                        isHttps: !0
                    }, t.publishSpeedLog(n);
                }
            });
        },
        cloudSuccessCallback: function(e, t, n, o) {
            var r = "callFunction" === o ? t.name : t.path, i = "callFunction" === o ? n.result : n.data, a = (r = {
                method: "call",
                url: "wx.cloud." + o + "." + r,
                duration: Date.now() - t.aegisRequestStartTime,
                status: 200,
                nextHopProtocol: "",
                type: "fetch",
                isHttps: !0
            }, [ "apiName", "aegisRequestStartTime", "config", "success", "fail", "complete" ]), s = Object.keys(t).reduce(function(e, n) {
                return a.includes(n) || (e[n] = t[n]), e;
            }, {}), l = (o = "callFunction" === o ? (null == (o = n.data) ? void 0 : o.code) || 0 : n.statusCode, 
            (c = d(i, e.api, {
                url: r.url,
                ctx: n,
                payload: s
            }) || {}).code), c = void 0 !== (c = c.isErr) && c;
            s = (l = (r.ret = l, r.isErr = +c, r.payload = s, null == (l = e.api) ? void 0 : l.apiDetail)) ? h(s, null == (s = e.api) ? void 0 : s.reqParamHandler, {
                url: r.url
            }) : "", i = l ? h(i, null == (l = e.api) ? void 0 : l.resBodyHandler, {
                url: r.url
            }) : "", l = (null == (l = e.api) ? void 0 : l.reqHeaders) || [], l = we(null == t ? void 0 : t.header, l, "req"), 
            e = (null == (e = e.api) ? void 0 : e.resHeaders) || [], e = we(null == n ? void 0 : n.header, e, "res"), 
            o = "req url: " + r.url + "\n                    \nres status: " + o + "\n                    \nres duration: " + r.duration + "ms \n                    \nreq type: " + r.type + "\n                    \nreq params: " + s + "\n                    \nres retcode: " + r.ret + "\n                    \nres data: " + i + "\n                    " + l + "\n                    " + e;
            this.publishNormalLog({
                msg: o,
                level: N.API_RESPONSE,
                ctx: n
            }), this.publishSpeedLog(r), c && this.publishNormalLog({
                msg: o,
                level: N.RET_ERROR,
                ctx: n
            });
        },
        publishSpeedLog: function(e) {
            this.$walk(function(t) {
                t.speedLogPipeline(e);
            });
        },
        publishNormalLog: function(e) {
            this.$walk(function(t) {
                t.normalLogPipeline(e);
            });
        }
    }), Se = wx || qq, xe = Se.connectSocket, Ce = (Ue.prototype.addConfig = function(e) {
        var t = e.send;
        e = e.onError;
        t && this.sends.push(t), e && this.onErrors.push(e);
    }, Ue.prototype.toHack = function(e) {
        var t = this, n = (this.onErrors.forEach(function(t) {
            e.onError(t);
        }), e.send);
        return Object.defineProperty(e, "send", {
            get: function() {
                return function(r) {
                    return new Promise(function(i) {
                        n.call(e, o(o({}, r), {
                            fail: function(e) {
                                t.sends.forEach(function(t) {
                                    var n;
                                    null != (n = t.fail) && n.call(t, e, r);
                                }), i(e);
                            }
                        }));
                    });
                };
            }
        }), e;
    }, Ue), Ne = (n(_e, ke = se), _e.prototype.addTaskConf = function(e) {
        this.taskHack.addConfig(e);
    }, _e.prototype.defineApiProperty = function() {
        var e = this;
        Object.defineProperty(Se, "connectSocket", {
            get: function() {
                return e.hackHandler.bind(e);
            }
        });
    }, _e.prototype.hackHandler = function(e) {
        var t = this, n = this.prefixHandler(e);
        e = xe(o(o({}, n), {
            success: function(e) {
                t.successHandler(e, n);
            },
            fail: function(e) {
                t.failHandler(e, n);
            },
            complete: function(e) {
                t.completeHandler(e, n);
            }
        }));
        return this.taskHack.toHack(e), e;
    }, _e), Le = (se = new te({
        name: "onError",
        onNewAegis: function(e) {
            var t = ne.getSystemInfoSync().SDKVersion;
            this.listenError(), this.hackNetWork(e), this.hackCloud(e), e.config.websocketHack && P(t, "1.7.0") && this.hackWsConnect();
        },
        listenError: function() {
            var e = this;
            "function" == typeof ne.onError && ne.onError(function(t) {
                t && e.publishErrorLog({
                    msg: t,
                    level: N.ERROR
                });
            }), T("onUnhandledRejection") && ne.onUnhandledRejection(function(t) {
                !(t = t.reason) || -1 < JSON.stringify(t).indexOf("request:fail") || e.publishErrorLog({
                    msg: t,
                    level: N.PROMISE_ERROR
                });
            }), T("onPageNotFound") && ne.onPageNotFound(function(t) {
                t && e.publishErrorLog({
                    msg: t,
                    level: N.PAGE_NOT_FOUND_ERROR
                });
            }), T("onLazyLoadError") && ne.onLazyLoadError(function(t) {
                t && e.publishErrorLog({
                    msg: t,
                    level: N.LAZY_LOAD_ERROR
                });
            });
        },
        publishErrorLog: function(e) {
            this.$walk(function(t) {
                t.normalLogPipeline(e);
            });
        },
        hackNetWork: function(e) {
            for (var t = this, n = e.config, o = 0, r = [ {
                apiName: "request",
                complete: function(e, o) {
                    return t.requestCompleteError(e, o, n);
                }
            }, {
                apiName: "uploadFile",
                complete: function(e, o) {
                    return t.uploadFileCompleteError(e, o, n);
                }
            }, {
                apiName: "downloadFile",
                complete: function(e, o) {
                    return t.downloadFileCompleteError(e, o, n);
                }
            } ]; o < r.length; o++) {
                var i;
                C({
                    apiName: (i = r[o]).apiName,
                    complete: i = i.complete
                });
            }
        },
        requestCompleteError: function(e, t, n) {
            var o = e.errMsg, r = e.statusCode;
            g(t.url, n.hostUrl) || (o = this.getErrorType({
                errMsg: o,
                statusCode: r
            })) && this.publishNetWorkError({
                apiName: "request",
                opts: t,
                res: e,
                config: n,
                type: o
            });
        },
        downloadFileCompleteError: function(e, t, n) {
            var o = e.errMsg, r = e.statusCode, i = e.filePath, a = e.tempFilePath;
            (o = this.getErrorType({
                errMsg: o,
                statusCode: r
            })) && this.publishNetWorkError({
                apiName: "downloadFile",
                opts: t,
                res: e,
                config: n,
                type: o
            }, {
                extraInfo: "\nres filePath: " + i + "\nres tempFilePath: " + a
            });
        },
        uploadFileCompleteError: function(e, t, n) {
            var o = e.errMsg, r = e.statusCode;
            (o = this.getErrorType({
                errMsg: o,
                statusCode: r
            })) && this.publishNetWorkError({
                apiName: "uploadFile",
                opts: t,
                res: e,
                config: n,
                type: o
            });
        },
        hackCloud: function(e) {
            for (var t = this, n = e.config, o = 0, r = [ {
                apiName: "callFunction",
                complete: function(e, o) {
                    return t.callFunctionCompleteError(e, o, n);
                }
            }, {
                apiName: "callContainer",
                complete: function(e, o) {
                    return t.callContainerCompleteError(e, o, n);
                }
            } ]; o < r.length; o++) {
                var i;
                x({
                    apiName: (i = r[o]).apiName,
                    complete: i = i.complete
                });
            }
        },
        callFunctionCompleteError: function(e, t, n) {
            var o = e.errMsg;
            (o = this.getErrorType({
                errMsg: o
            })) && this.publishNetWorkError({
                apiName: "cloud.callFunction",
                opts: t,
                res: e,
                config: n,
                type: o
            });
        },
        callContainerCompleteError: function(e, t, n) {
            var o = e.errMsg, r = e.statusCode;
            (o = this.getErrorType({
                errMsg: o,
                statusCode: r
            })) && this.publishNetWorkError({
                apiName: "cloud.callContainer",
                opts: t,
                res: e,
                config: n,
                type: o
            });
        },
        publishNetWorkError: function(e, t) {
            t = void 0 === (t = t.extraInfo) ? "" : t;
            var n = e.apiName, o = e.opts, r = e.res, i = e.config, a = (e = e.type, r.errMsg), s = r.statusCode, l = r.data, c = o.url, u = d(l, i.api, {
                url: c,
                ctx: r,
                payload: o.data
            }).code, f = (p = null == (p = i.api) ? void 0 : p.apiDetail) ? h(o.data, null == (f = i.api) ? void 0 : f.reqParamHandler, {
                url: c
            }) : "", p = (l = p ? h(l, null == (p = i.api) ? void 0 : p.resBodyHandler, {
                url: c
            }) : "", c = (null == (p = i.api) ? void 0 : p.reqHeaders) || [], we(null == o ? void 0 : o.header, c, "req"));
            i = (null == (c = i.api) ? void 0 : c.resHeaders) || [], c = we(null == r ? void 0 : r.header, i, "res");
            this.publishErrorLog({
                msg: "AJAX_ERROR: " + n + " " + e + "\n                  \nreq url: " + o.url + "\n                  \nres status: " + (s || 0) + "\n                  \nres duration: " + (Date.now() - o.aegisRequestStartTime) + "ms\n                  \nreq method: " + (o.method || "get") + "\n                  \nreq param: " + f + "\n                  \nres retcode: " + u + "\n                  \nres data: " + l + "\n                  \nerrMsg: " + a.slice(0, 1e3) + "\n                  " + t + "\n                  " + p + "\n                  " + c,
                level: N.AJAX_ERROR
            });
        },
        getErrorType: function(e) {
            var t = e.errMsg, n = (e = e.statusCode, ""), o = t;
            return [ "timeout", "time out", "ERR_CONNECTION_TIMED_OUT", "ERR_TIMED_OUT", "超时" ].some(function(e) {
                return String(o || "").includes(e);
            }) ? n = "timeout" : 400 <= e ? n = "error" : (-1 < t.indexOf("fail") || !e || e < 0) && (n = "failed"), 
            n;
        },
        hackWsConnect: function() {
            var e, t, n = this;
            C({
                apiName: "sendSocketMessage",
                fail: function(e) {
                    n.publishSocketError(e);
                }
            }), e = (t = {
                connectCallback: {
                    fail: function(e) {
                        n.publishSocketError(e);
                    }
                },
                taskOpt: {
                    onError: function(e) {
                        n.publishSocketError(e);
                    },
                    send: {
                        fail: function(e) {
                            n.publishSocketError(e);
                        }
                    }
                }
            }).connectCallback, t = t.taskOpt, Pe ? Pe.addCallback(e) : Pe = new Ne(e), t && Pe.addTaskConf(t);
        },
        publishSocketError: function(e) {
            e && this.publishErrorLog({
                msg: e.errMsg,
                level: N.WEBSOCKET_ERROR
            });
        }
    }), new te({
        name: "reportAssetSpeed",
        isStart: !1,
        onNewAegis: function(e) {
            this.isStart || (this.isStart = !0, this.start(e));
        },
        start: function(e) {
            var t = this;
            ne.getPerformance && ne.getPerformance().createObserver(function(n) {
                null != (n = n.getEntries()) && n.forEach(function(n) {
                    g(n.uri, e.config.hostUrl) || "number" != typeof n.duration || n.duration <= 0 || t.publishAssetLog(n);
                });
            }).observe({
                entryTypes: [ "resource" ]
            });
        },
        generateLog: function(e) {
            var t, n, o = e.transferSize;
            return {
                url: (t = e.uri, void 0 === n && (n = 2048), String(t).replace(i, "").slice(0, n)),
                method: "get",
                duration: Math.round(100 * e.duration) / 100,
                status: 200,
                type: "static",
                isHttps: !0,
                urlQuery: f(e.uri, !0),
                nextHopProtocol: "",
                domainLookup: 0,
                connectTime: 0,
                transferSize: 0 < o ? o : -1
            };
        },
        publishAssetLog: function(e) {
            var t = this;
            this.$walk(function(n) {
                n.speedLogPipeline(t.generateLog(e));
            });
        }
    })), qe = [ "onLaunch", "onHide", "onError", "onLoad", "onReady", "onShow", "onUnload" ], Ae = new te({
        name: "pagePerformance",
        pageNavigationStartTime: {},
        onNewAegis: function(e) {
            try {
                T("getPerformance") && this.reportPerformance(e), this.setPagePV(e), this.reportSetDataTiming(e);
            } catch (e) {}
        },
        reportPerformance: function(e) {
            var t, n = this;
            null != (t = null == (t = ne.getPerformance()) ? void 0 : t.createObserver(function(t) {
                var o = {}, r = null == (r = t.getEntriesByName("appLaunch")) ? void 0 : r[0], i = null == (i = t.getEntriesByName("firstRender")) ? void 0 : i[0], a = null == (a = t.getEntriesByName("evaluateScript")) ? void 0 : a[0], s = null == (s = t.getEntriesByName("route")) ? void 0 : s[0], l = null == (l = null == (l = t.getEntriesByName("firstPaint")) ? void 0 : l[0]) ? void 0 : l.startTime, c = null == (c = null == (c = t.getEntriesByName("largestContentfulPaint")) ? void 0 : c[0]) ? void 0 : c.startTime, u = null == (u = null == (u = t.getEntriesByName("firstContentfulPaint")) ? void 0 : u[0]) ? void 0 : u.startTime, f = null == (f = (null == (f = t.getEntriesByName("firstPaint")) ? void 0 : f[0]) || (null == (f = t.getEntriesByName("route")) ? void 0 : f[0]) || (null == (f = t.getEntriesByName("appLaunch")) ? void 0 : f[0])) ? void 0 : f.pageId, p = null == (t = (null == (p = t.getEntriesByName("route")) ? void 0 : p[0]) || (null == (p = t.getEntriesByName("appLaunch")) ? void 0 : p[0])) ? void 0 : t.startTime;
                f && (n.pageNavigationStartTime[f] = null, p) && (n.pageNavigationStartTime[f] = p), 
                r && (o.appLaunch = r.duration || -1), i && (o.firstScreenTiming = i.duration || -1), 
                a && (o.scriptEvaluateTiming = a.duration || -1), s && (o.pageRouteTiming = s.duration || -1), 
                l && p ? o.firstPaintTiming = Math.max(l - p, -1) : l && n.pageNavigationStartTime[f] && (o.firstPaintTiming = Math.max(l - n.pageNavigationStartTime[f], -1)), 
                c && p ? o.LCP = Math.max(c - p, -1) : c && n.pageNavigationStartTime[f] && (o.LCP = Math.max(c - n.pageNavigationStartTime[f], -1)), 
                u && p ? o.FCP = Math.max(u - p, -1) : u && n.pageNavigationStartTime[f] && (o.FCP = Math.max(u - n.pageNavigationStartTime[f], -1)), 
                0 < Object.keys(o).length && n.publish(o, e);
            })) && t.observe({
                entryTypes: [ "navigation", "render", "script" ]
            });
        },
        publish: function(e, t) {
            var n, o, r, i = [], a = t.config, s = -1 === (null == (n = t.config.performanceUrl) ? void 0 : n.indexOf("?")) ? "?" : "&";
            for (o in e) i.push(o + "=" + e[o]);
            "function" == typeof a.urlHandler ? (r = a.urlHandler() || window.location.href, 
            this.$walk(function(n) {
                n.send({
                    url: t.config.performanceUrl + s + i.join("&") + "&from=" + encodeURIComponent(r),
                    beanFilter: [ "from" ],
                    type: A.PERFORMANCE,
                    log: e
                });
            })) : this.$walk(function(n) {
                n.send({
                    url: t.config.performanceUrl + s + i.join("&"),
                    type: A.PERFORMANCE,
                    log: e
                });
            });
        },
        setPagePV: function(e) {
            var t = this;
            ne.onAppRoute && ne.onAppRoute(function(n) {
                "appLaunch" === n.openType && !e.config.spa || (t.$walk(function(e) {
                    e.send({
                        url: "" + e.config.pvUrl,
                        type: A.PV
                    });
                }), t.reportPageLoaded(n));
            });
        },
        reportPageLoaded: function(e) {
            e = "infoType: behaviorBacktracking\ndataType: pageLoadAndRoute\npageLoadedPath: " + e.path + "\nopenType: " + e.openType, 
            this.publishNormalLog({
                msg: e,
                level: N.INFO
            });
        },
        publishNormalLog: function(e) {
            this.$walk(function(t) {
                t.normalLogPipeline(e);
            });
        },
        reportSetDataTiming: function(e) {
            var t, n, o, r, i, a, s, l, c, u = this;
            !0 !== (c = void 0 === (c = e.config.setDataReportConfig) ? {} : c).disabled && (t = c.timeThreshold, 
            n = !1 !== c.withDataPaths, o = t && 0 < +t ? +t : 30, r = O([ m(e, 10), function(t) {
                t = t.map(function(e) {
                    return {
                        type: A.SET_DATA,
                        component: e.from,
                        duration: e.duration,
                        fields: e.dataPaths && e.dataPaths.length ? e.dataPaths.sort().join(";") : void 0,
                        size: e.size
                    };
                }), e.send({
                    url: e.config.setDataReportUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                        miniProgramData: t
                    })),
                    type: A.SET_DATA,
                    log: t
                });
            } ]), i = Page, a = Component, s = function(e, t) {
                var i, a, s = t.updateStartTimestamp, l = t.updateEndTimestamp;
                t = void 0 === (t = t.dataPaths) ? [] : t, l -= s;
                isNaN(l) || l < o || (s = {
                    from: e.is,
                    duration: l
                }, n && 0 < t.length && Object.assign(s, {
                    dataPaths: t.slice(0, 30),
                    size: (l = t, a = 0, null != (i = e) && i.data ? (l.forEach(function(e) {
                        for (var t = i.data[e[0]], n = 1, o = e.length; n < o; n++) t[e[n]] && (t = t[e[n]]);
                        var r = "";
                        try {
                            r = JSON.stringify(t);
                        } catch (e) {
                            r = "";
                        }
                        a += 2 * (void 0 === r ? "" : r).replace(/[\u4e00-\u9fa5]/g, "aa").length;
                    }), a = Math.min(a, 10485760)) : a)
                }), r(s));
            }, l = function(e) {
                var t = "infoType: behaviorBacktracking\ndataType: tapEvent" + Object.keys(e[0]).reduce(function(t, n) {
                    var o = "";
                    try {
                        o = n + ": " + JSON.stringify(e[0][n]);
                    } catch (t) {
                        o = "";
                    }
                    return t + "\n" + o;
                }, "");
                u.publishNormalLog({
                    msg: t,
                    level: N.INFO
                });
            }, Page = function(e) {
                var t = e.onReady;
                return e.onReady = function() {
                    var e = this;
                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                        withDataPaths: n
                    }, function(t) {
                        s(e, t);
                    }), null == t ? void 0 : t.call(this);
                }, Object.keys(e).forEach(function(t) {
                    var n;
                    "function" != typeof e[t] || qe.includes(t) || (n = e[t], e[t] = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return null != e && e[0] && "tap" === e[0].type && l(e), null == n ? void 0 : n.apply(this, e);
                    });
                }), i(e);
            }, Component = function(e) {
                e.lifetimes && e.lifetimes.attached ? (t = e.lifetimes.attached, e.lifetimes.attached = function() {
                    var e = this;
                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                        withDataPaths: n
                    }, function(t) {
                        s(e, t);
                    }), null == t ? void 0 : t.call(this);
                }) : (o = e.attached, e.attached = function() {
                    var e = this;
                    return "function" == typeof this.setUpdatePerformanceListener && this.setUpdatePerformanceListener({
                        withDataPaths: n
                    }, function(t) {
                        s(e, t);
                    }), null == o ? void 0 : o.call(this);
                });
                var t, o, r = e.methods;
                return r && "[object Object]" === Object.prototype.toString.call(r) && Object.keys(r).forEach(function(e) {
                    var t;
                    "function" == typeof r[e] && (t = r[e], r[e] = function() {
                        for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                        return null != e && e[0] && "tap" === e[0].type && l(e), null == t ? void 0 : t.apply(this, e);
                    });
                }), a(e);
            });
        }
    });
    te = new te({
        name: "reportLoadPackageSpeed",
        isLoaded: !1,
        onNewAegis: function(e) {
            this.isLoaded || (this.isLoaded = !0, this.start(e));
        },
        start: function() {
            var e = this;
            ne.getPerformance && ne.getPerformance().createObserver(function(t) {
                null != (t = t.getEntries()) && t.forEach(function(t) {
                    "number" != typeof t.duration || t.duration <= 0 || e.publishPackageLog(t);
                });
            }).observe({
                entryTypes: [ "loadPackage" ]
            });
        },
        generateLog: function(e) {
            return [ {
                type: A.LOAD_PACKAGE,
                packageName: e.packageName,
                size: Math.round(100 * e.packageSize) / 100,
                duration: Math.round(100 * e.duration) / 100
            } ];
        },
        publishPackageLog: function(e) {
            var t = this;
            this.$walk(function(n) {
                var o = t.generateLog(e);
                n.send({
                    url: n.config.setDataReportUrl + "?payload=" + encodeURIComponent(JSON.stringify({
                        miniProgramData: o
                    })),
                    type: A.LOAD_PACKAGE,
                    log: o
                });
            });
        }
    });
    function _e(e) {
        return (e = ke.call(this, e) || this).taskHack = new Ce(), e;
    }
    function Ue() {
        this.onErrors = [], this.sends = [];
    }
    return ee.use(se), ee.use(Te), ee.use(ae), ee.use(Le), ee.use(Ae), ee.use(te), ee.use(re), 
    ee;
});