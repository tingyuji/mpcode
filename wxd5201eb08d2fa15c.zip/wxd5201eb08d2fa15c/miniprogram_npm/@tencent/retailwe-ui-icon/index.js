Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("@tencent/retailwe-ui-common/index"), r = require("@tencent/retailwe-ui-common/index"), n = function(t) {
    function n() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.externalClasses = [ "wr-class" ], e.properties = {
            name: {
                type: String,
                require: !0,
                observer: function(e) {
                    this.setData({
                        isImageName: -1 !== e.indexOf("/")
                    });
                }
            },
            classPrefix: {
                type: String,
                value: "wr"
            },
            size: {
                type: null,
                value: 24
            },
            color: {
                type: String,
                value: ""
            },
            info: String,
            dot: Boolean,
            customStyle: String
        }, e;
    }
    return e.__extends(n, t), n = e.__decorate([ r.wxComponent() ], n);
}(t.SuperComponent);

exports.default = n;