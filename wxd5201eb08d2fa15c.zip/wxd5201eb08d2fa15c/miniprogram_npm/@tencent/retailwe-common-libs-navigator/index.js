Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Navigator = exports.PathType = void 0;

var t, r = require("@tencent/retailwe-common-libs-logger"), e = function(t, r) {
    void 0 === t && (t = {}), void 0 === r && (r = !1);
    var e = [];
    return Object.keys(t).forEach(function(o) {
        return e.push(o + "=" + (r ? encodeURIComponent(t[o]) : t[o]));
    }), e.join("&");
};

!function(t) {
    t.NORMAL = "normal", t.TAB = "tab";
}(t = exports.PathType || (exports.PathType = {}));

var o = function() {
    function o() {
        this.logger = new r.Logger({
            prefix: "retailwe-navigator"
        }), this.maxDeep = 10;
    }
    return o.prototype.gotoPage = function(r, o, n) {
        this.logger.debug("call gotoPage", {
            path: r,
            query: o,
            options: n
        });
        var i = "string" == typeof r ? {
            path: r,
            type: t.NORMAL
        } : r;
        if (!i) return this.throwError({
            errMsg: "gotoPage:fail 页面路径不存在 " + r
        });
        var a = getCurrentPages(), c = a.length, u = e(o), s = u ? "?" + u : "", p = "" + i.path + s, g = this.findPageInHistory(i.path);
        return i.type === t.TAB ? this.switchTab(p) : a.length >= this.maxDeep ? g > -1 ? this.navigateBack(o, c - g) : this.redirectTo(p) : (null == n ? void 0 : n.redirect) ? this.redirectTo(p) : (this.logger.debug({
            toUrl: p
        }), this.navigateTo(p));
    }, o.prototype.navigateTo = function(t, r, o, n, i) {
        var a = this, c = t;
        if ("string" != typeof c && (null == t ? void 0 : t.path)) {
            var u = "", s = t.path, p = t.query, g = void 0 === p ? null : p;
            null !== g && (u = "?" + e(g)), c = "" + s + u;
        }
        wx.navigateTo({
            url: c,
            events: r || {},
            success: function(t) {
                o && o(t);
            },
            fail: function(t) {
                n && n(t), a.throwError(t);
            },
            complete: function() {
                i && i();
            }
        });
    }, o.prototype.redirectTo = function(t, r, e, o) {
        var n = this;
        wx.redirectTo({
            url: t,
            success: function() {
                r && r();
            },
            fail: function(t) {
                e && e(t), n.throwError(t);
            },
            complete: function() {
                o && o();
            }
        });
    }, o.prototype.switchTab = function(t, r, e, o) {
        var n = this;
        wx.switchTab({
            url: t,
            success: function() {
                r && r();
            },
            fail: function(t) {
                e && e(t), n.throwError(t);
            },
            complete: function() {
                o && o();
            }
        });
    }, o.prototype.navigateBack = function(t, r) {
        var e = getCurrentPages(), o = r || 1;
        if (t) {
            var n = e[e.length - 1 - o];
            null == n || n.setData(t);
        }
        wx.navigateBack({
            delta: o,
            complete: function() {}
        });
    }, o.prototype.gotoMiniProgram = function(t, r, e, o, n, i) {
        var a = this;
        wx.navigateToMiniProgram({
            appId: t,
            path: r,
            extraData: e,
            success: function() {
                o && o();
            },
            fail: function(t) {
                n && n(t), a.throwError(t);
            },
            complete: function() {
                i && i();
            }
        });
    }, o.prototype.findPageInHistory = function(t) {
        for (var r, e = getCurrentPages(), o = -1, n = 0; n < e.length; n++) {
            var i = /^\//, a = null === (r = e[n]) || void 0 === r ? void 0 : r.route, c = t;
            if (a && c && a.replace(i, "") === c.replace(i, "")) {
                o = n + 1;
                break;
            }
        }
        return o;
    }, o.prototype.throwError = function(t) {
        var r = (t || {}).errMsg;
        throw new Error("navigator " + (void 0 === r ? "" : r));
    }, o;
}();

exports.Navigator = o, exports.default = o;