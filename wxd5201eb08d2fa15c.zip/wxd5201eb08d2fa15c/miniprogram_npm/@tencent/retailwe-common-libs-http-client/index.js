Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib");

e.__exportStar(require("./build/main/http-client"), exports), exports.interceptors = e.__importStar(require("./build/main/interceptors/index"));

var r = require("./build/main/libs/log");

Object.defineProperty(exports, "logger", {
    enumerable: !0,
    get: function() {
        return r.default;
    }
});