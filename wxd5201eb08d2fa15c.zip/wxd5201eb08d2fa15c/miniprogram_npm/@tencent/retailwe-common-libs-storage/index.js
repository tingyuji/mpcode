Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Storage = exports.StorageEventActions = exports.STORAGE_EVENT_CLEAR = void 0;

var e, t = require("tslib"), o = t.__importDefault(require("@tencent/retailwe-common-libs-event"));

exports.STORAGE_EVENT_CLEAR = "storageClear", function(e) {
    e.STORAGE_SET = "storageSet", e.STORAGE_REMOVE = "storageRemove";
}(e = exports.StorageEventActions || (exports.StorageEventActions = {}));

var r = function(o) {
    function r(e) {
        var t = void 0 === e ? {} : e, r = t.appVersion, n = t.expires, i = t.env, a = t.enableMemoryCache, c = o.call(this) || this;
        return c.config = {}, c.memoryCache = {}, c.config = {
            appVersion: r,
            expires: n,
            env: i,
            enableMemoryCache: a
        }, c;
    }
    return t.__extends(r, o), r.prototype.fillMemoryCache = function() {
        var e = this;
        return Promise.resolve().then(function() {
            return new Promise(function(e, t) {
                wx.getStorageInfo({
                    success: function(t) {
                        return e(t.keys);
                    },
                    fail: function(e) {
                        return t(e);
                    }
                });
            });
        }).then(function(e) {
            var t = [];
            return e.forEach(function(e) {
                t.push(new Promise(function(t) {
                    wx.getStorage({
                        key: e,
                        success: function(o) {
                            return t({
                                key: e,
                                value: o.data
                            });
                        },
                        fail: function() {
                            return t();
                        }
                    });
                }));
            }), Promise.all(t);
        }).then(function(t) {
            t.forEach(function(t) {
                var o = void 0 === t ? {} : t, r = o.key, n = o.value;
                r && n && (e.memoryCache[r] = n);
            });
        });
    }, r.prototype.get = function(e) {
        var t = this, o = this.beforeGet(e);
        return Promise.resolve().then(function() {
            if (t.config.enableMemoryCache) {
                var e = t.memoryCache[o];
                if (void 0 !== e) return e;
            }
            return new Promise(function(e, r) {
                wx.getStorage({
                    key: o,
                    success: function(r) {
                        return r.data ? (t.config.enableMemoryCache && void 0 !== r.data && (t.memoryCache[o] = r.data), 
                        e(r.data)) : e(void 0);
                    },
                    fail: function(e) {
                        return r(e);
                    }
                });
            });
        }).then(function(e) {
            if (e) return t.afterGet(e);
        });
    }, r.prototype.getSync = function(e) {
        var t, o = this.beforeGet(e);
        return this.config.enableMemoryCache && (t = this.memoryCache[o]), void 0 === t && (t = wx.getStorageSync(o), 
        this.config.enableMemoryCache && void 0 !== t && (this.memoryCache[o] = t)), this.afterGet(t);
    }, r.prototype.set = function(t, o) {
        var r = this, n = this.beforeSet(t, o), i = n.key, a = n.value;
        return this.config.enableMemoryCache && (this.memoryCache[i] = a), new Promise(function(n, c) {
            wx.setStorage({
                key: i,
                data: a,
                success: function(i) {
                    n(i), r.emit(t, {
                        action: e.STORAGE_SET,
                        value: o
                    });
                },
                fail: function(e) {
                    return c(e);
                }
            });
        });
    }, r.prototype.setSync = function(t, o) {
        var r = this.beforeSet(t, o), n = r.key, i = r.value;
        this.config.enableMemoryCache && (this.memoryCache[n] = i), wx.setStorageSync(n, i), 
        this.emit(t, {
            action: e.STORAGE_SET,
            value: o
        });
    }, r.prototype.remove = function(t) {
        var o = this, r = this.beforeRemove(t);
        return this.config.enableMemoryCache && void 0 !== this.memoryCache[r] && (this.memoryCache[r] = void 0), 
        new Promise(function(n, i) {
            wx.removeStorage({
                key: r,
                success: function(r) {
                    n(r), o.emit(t, {
                        action: e.STORAGE_REMOVE,
                        value: null
                    });
                },
                fail: function(e) {
                    return i(e);
                }
            });
        });
    }, r.prototype.removeSync = function(t) {
        var o = this.beforeRemove(t);
        this.config.enableMemoryCache && void 0 !== this.memoryCache[o] && (this.memoryCache[o] = void 0), 
        wx.removeStorageSync(o), this.emit(t, {
            action: e.STORAGE_REMOVE,
            value: null
        });
    }, r.prototype.clear = function() {
        var e = this;
        return this.config.enableMemoryCache && (this.memoryCache = {}), new Promise(function(t, o) {
            wx.clearStorage({
                success: function(o) {
                    t(o), e.emit(exports.STORAGE_EVENT_CLEAR);
                },
                fail: function(e) {
                    return o(e);
                }
            });
        });
    }, r.prototype.clearSync = function() {
        this.config.enableMemoryCache && (this.memoryCache = {}), wx.clearStorageSync(), 
        this.emit(exports.STORAGE_EVENT_CLEAR);
    }, r.prototype.beforeSet = function(e, t) {
        var o = {
            data: t
        };
        return this.config.expires && (o.expires = Date.now() + this.config.expires), {
            key: this.keyProxy(e),
            value: o
        };
    }, r.prototype.beforeGet = function(e) {
        return this.keyProxy(e);
    }, r.prototype.afterGet = function(e) {
        if (e) {
            var t = e.expires, o = e.data;
            if (!t || !function(e) {
                return e <= Date.now();
            }(t)) return o;
        }
    }, r.prototype.beforeRemove = function(e) {
        return this.keyProxy(e);
    }, r.prototype.keyProxy = function(e) {
        var t = [ e ], o = this.config, r = o.appVersion, n = o.env;
        return r && t.push(r), n && t.push(n), t.join(":");
    }, r;
}(o.default);

exports.Storage = r;