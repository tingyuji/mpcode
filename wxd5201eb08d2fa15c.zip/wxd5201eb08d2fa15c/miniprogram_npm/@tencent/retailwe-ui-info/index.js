Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("@tencent/retailwe-ui-common/index"), r = require("@tencent/retailwe-ui-common/index"), n = function(t) {
    function n() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.externalClasses = [ "wr-class" ], e.properties = {
            dot: Boolean,
            info: String
        }, e;
    }
    return e.__extends(n, t), n = e.__decorate([ r.wxComponent() ], n);
}(t.SuperComponent);

exports.default = n;