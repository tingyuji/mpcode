Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("@tencent/retailwe-ui-common/index"), n = require("@tencent/retailwe-ui-common/index"), o = function(t) {
    function o() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.externalClasses = [ "wr-class", "wr_cancel_btn", "wr-cancel-btn", "wr_confirm_btn", "wr-confirm-btn" ], 
        e.properties = {
            show: {
                type: Boolean,
                value: !1
            },
            title: String,
            message: String,
            textAlign: {
                type: String,
                value: "center"
            },
            showCancelButton: Boolean,
            width: null,
            zIndex: {
                type: Number,
                value: 2e3
            },
            confirmButtonText: {
                type: String,
                value: "确认"
            },
            cancelButtonText: {
                type: String,
                value: "取消"
            },
            showConfirmButton: {
                type: Boolean,
                value: !0
            },
            position: {
                type: String,
                value: "center"
            },
            direction: {
                type: String,
                value: "row"
            },
            actions: {
                type: Array,
                value: []
            },
            confirmOpenTypeValue: String,
            asyncClose: {
                type: Boolean,
                value: !1
            },
            maskClosable: {
                type: Boolean,
                value: !1
            }
        }, e.data = {}, e;
    }
    return e.__extends(o, t), o.prototype.onConfirm = function() {
        this.properties.asyncClose || this.setData({
            show: !1
        }), this.triggerEvent("confirm"), this._onComfirm && this._onComfirm();
    }, o.prototype.onCancel = function() {
        this.properties.asyncClose || this.setData({
            show: !1
        }), this.triggerEvent("cancel"), this._onCancel && this._onCancel();
    }, o.prototype.close = function() {
        this.setData({
            show: !1
        }), this.triggerEvent("close");
    }, o.prototype.onActionTap = function(e) {
        this.properties.asyncClose || this.setData({
            show: !1
        });
        var t = e.currentTarget.dataset.index;
        this.triggerEvent("action", {
            index: t
        }), this._onAction && this._onAction({
            index: t
        });
    }, o.prototype.openValueCBHandle = function(e) {
        this.triggerEvent("open-type-event", e.detail);
    }, o.prototype.openValueErrCBHandle = function(e) {
        this.triggerEvent("open-type-error-event", e.detail);
    }, o = e.__decorate([ n.wxComponent() ], o);
}(t.SuperComponent);

exports.default = o;