Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib");

function n(e, n) {
    if (void 0 === n && (n = "#wr-dialog"), !e) {
        var t = getCurrentPages(), o = t[t.length - 1];
        e = o.$$basePage || o;
    }
    var s = e && e.selectComponent(n);
    return s || (console.warn("未找到dialog组件,请检查selector是否正确"), null);
}

var t = {
    zIndex: 1001,
    actions: []
};

exports.default = {
    alert: function(o) {
        var s = o.context, r = o.selector, i = e.__rest(o, [ "context", "selector" ]), a = n(s, r);
        return a ? new Promise(function(n) {
            a.setData(e.__assign(e.__assign(e.__assign(e.__assign({}, t), {
                showConfirmButton: !0
            }), i), {
                showCancelButton: !1,
                show: !0
            })), a._onComfirm = n;
        }) : Promise.reject();
    },
    confirm: function(o) {
        var s = o.context, r = o.selector, i = e.__rest(o, [ "context", "selector" ]), a = n(s, r);
        return a ? new Promise(function(n, o) {
            a.setData(e.__assign(e.__assign(e.__assign(e.__assign({}, t), {
                showConfirmButton: !0
            }), i), {
                showCancelButton: !0,
                show: !0
            })), a._onComfirm = n, a._onCancel = o;
        }) : Promise.reject();
    },
    close: function() {
        var e = n();
        return e ? (e.close(), Promise.resolve()) : Promise.reject();
    },
    action: function(o) {
        var s = o.context, r = o.selector, i = o.actions, a = e.__rest(o, [ "context", "selector", "actions" ]), c = n(s, r);
        return c ? ((!i || 0 === i.length || i.length > 7) && console.warn("action 数量建议控制在1至7个"), 
        new Promise(function(n) {
            c.setData(e.__assign(e.__assign(e.__assign(e.__assign({}, t), {
                actions: i,
                direction: "column"
            }), a), {
                show: !0
            })), c._onAction = n;
        })) : Promise.reject();
    }
};