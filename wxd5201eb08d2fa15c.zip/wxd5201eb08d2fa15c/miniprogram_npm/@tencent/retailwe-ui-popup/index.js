var t = require("../../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), n = require("@tencent/retailwe-ui-common/index"), i = require("@tencent/retailwe-ui-common/index"), o = function(n) {
    function o() {
        var t = null !== n && n.apply(this, arguments) || this;
        return t.options = {
            multipleSlots: !0
        }, t.externalClasses = [ "wr-class", "mask-class" ], t.properties = {
            show: {
                type: Boolean,
                value: !1,
                observer: function(t) {
                    var e = this;
                    this.animationTimer && clearTimeout(this.animationTimer), t ? (this.setData({
                        isShow: !0
                    }), this.startAnimation(t)) : this.startAnimation(t).then(function() {
                        e.setData({
                            isShow: !1
                        });
                    });
                }
            },
            fixed: {
                type: Boolean,
                value: !0
            },
            normal: {
                type: Boolean,
                value: !1
            },
            title: String,
            subtitle: String,
            height: {
                type: String,
                value: "auto"
            },
            maxHeight: {
                type: String,
                value: "960rpx"
            },
            minHeight: {
                type: String,
                value: "480rpx"
            },
            scrollable: {
                type: Boolean,
                value: !0
            },
            transition: {
                type: String,
                value: ""
            },
            zIndex: {
                type: Number,
                value: 2001
            },
            position: {
                type: String,
                value: "center"
            },
            duration: {
                type: null,
                value: {
                    enter: 300,
                    leave: 200
                }
            },
            timingFunction: {
                type: String,
                value: "ease"
            },
            mask: {
                type: Boolean,
                value: !0
            },
            maskClosable: {
                type: Boolean,
                value: !0
            },
            maskColor: {
                type: String,
                value: "rgba(0,0,0,0.5)"
            },
            maskStyle: String,
            contentStyle: String,
            bottomSafeAreaStyle: String,
            forbideScroll: {
                type: Boolean,
                value: !1
            },
            forbidBgScroll: {
                type: Boolean,
                value: !1
            },
            isIcon: {
                type: Boolean,
                value: !1
            },
            catchTouchMove: {
                type: Boolean,
                value: !0
            }
        }, t.data = {
            isShow: !1,
            animationStyle: {
                mask: "",
                content: ""
            }
        }, t;
    }
    return e.__extends(o, n), o.prototype.startAnimation = function(t) {
        var e = this, n = this.getAnimationStyle(t), i = n.animationStyle, o = n.duration;
        return new Promise(function(n) {
            e.setData({
                animationStyle: i
            }, function() {
                e.animationTimer = setTimeout(function() {
                    var i = t ? "openover" : "closeover";
                    e.triggerEvent(i), n();
                }, o);
            });
        });
    }, o.prototype.getDuration = function(e) {
        var n = this.properties.duration;
        return "object" === t(n) && (n = e ? n.enter : n.leave), n || 0;
    }, o.prototype.getAnimationStyle = function(t) {
        var e = this.getDuration(t), n = this.properties, i = n.position, o = n.transition, a = (t ? "enter" : "leave") + " " + e + "ms " + n.timingFunction + " both", r = "fade-" + a, l = (o || ("center" === i ? "fade" : "slide-" + i)) + "-" + a;
        return {
            animationStyle: {
                mask: "animation:" + r + ";-webkit-animation:" + r + ";",
                content: "animation:" + l + ";-webkit-animation:" + l + ";"
            },
            duration: e
        };
    }, o.prototype.bindTapMask = function() {
        this.properties.maskClosable && this.close();
    }, o.prototype.close = function() {
        this.triggerEvent("close");
    }, o.prototype.noop = function() {}, o = e.__decorate([ i.wxComponent() ], o);
}(n.SuperComponent);

exports.default = o;