Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("@tencent/retailwe-ui-common/index"), i = require("@tencent/retailwe-ui-common/index"), r = {
    icon: "success",
    iconColor: "",
    iconSize: "",
    text: "",
    textColor: "",
    zIndex: 10002,
    fontSize: "",
    duration: 2e3
}, o = function(t) {
    function o() {
        var e = null !== t && t.apply(this, arguments) || this;
        return e.hideTimer = null, e.removeTimer = null, e.data = {
            inserted: !1,
            show: !1
        }, e.externalClasses = [ "wr-class" ], e.properties = {
            icon: String,
            iconColor: String,
            iconSize: null,
            text: String,
            textColor: String,
            zIndex: Number,
            fontSize: null,
            duration: Number
        }, e;
    }
    return e.__extends(o, t), o.prototype.show = function(t) {
        var i = this;
        this.hideTimer && clearTimeout(this.hideTimer), this.removeTimer && clearTimeout(this.removeTimer);
        var o = e.__assign(e.__assign(e.__assign({}, r), t), {
            show: !0,
            inserted: !0
        }), n = o.duration;
        this.setData(o), this.hideTimer = setTimeout(function() {
            i.hide();
        }, n);
    }, o.prototype.hide = function() {
        var e = this;
        this.setData({
            show: !1
        }), this.removeTimer = setTimeout(function() {
            e.setData({
                inserted: !1
            });
        }, 300);
    }, o.prototype.detached = function() {
        this.destroyed();
    }, o.prototype.destroyed = function() {
        this.removeTimer && (clearTimeout(this.removeTimer), this.removeTimer = null), this.hideTimer && (clearTimeout(this.hideTimer), 
        this.hideTimer = null);
    }, o = e.__decorate([ i.wxComponent() ], o);
}(t.SuperComponent);

exports.default = o;