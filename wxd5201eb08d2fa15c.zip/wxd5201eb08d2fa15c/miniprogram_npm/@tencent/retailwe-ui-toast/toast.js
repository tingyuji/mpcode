Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib");

exports.default = function(t) {
    var r = t.context, o = t.selector, s = e.__rest(t, [ "context", "selector" ]), n = function(e, t) {
        if (void 0 === t && (t = "#wr-toast"), !e) {
            var r = getCurrentPages(), o = r[r.length - 1];
            e = o.$$basePage || o;
        }
        var s = e && e.selectComponent(t);
        return s || (console.warn("未找到toast组件,请检查selector是否正确"), null);
    }(r, o);
    n && n.show(e.__assign(e.__assign({}, s), {
        duration: s.duration || 2e3
    }));
};