Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib").__importDefault(require("./build/main/event"));

exports.default = e.default;