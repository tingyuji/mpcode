var t = require("../../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isPlainObject = exports.isObject = exports.toObject = exports.iterateInheritedPrototype = exports.getPrototypeOf = void 0;

var e = require("tslib");

function r(t) {
    return Object.getPrototypeOf ? Object.getPrototypeOf(t) : t.__proto__;
}

function o(t, e, o, n) {
    void 0 === n && (n = !0);
    for (var i = e.prototype || e, c = o.prototype || o; i && (n || i !== c) && !1 !== t(i) && i !== c; ) i = r(i);
}

function n(e) {
    var r = t(e);
    return null !== e && ("function" === r || "object" === r);
}

exports.getPrototypeOf = r, exports.iterateInheritedPrototype = o, exports.toObject = function(t, r) {
    void 0 === r && (r = {});
    var i = {};
    if (!n(t)) return i;
    var c = r.excludes || [ "constructor" ], p = r.enumerable, s = void 0 === p || p, a = r.configurable, u = void 0 === a ? 0 : a, f = r.writable, b = void 0 === f ? 0 : f, O = {};
    return 0 !== s && (O.enumerable = s), 0 !== u && (O.configurable = u), 0 !== b && (O.writable = b), 
    o(function(t) {
        Object.getOwnPropertyNames(t).forEach(function(o) {
            if (!(c.indexOf(o) >= 0 || i.hasOwnProperty(o))) {
                var n = Object.getOwnPropertyDescriptor(t, o);
                [ "get", "set", "value" ].forEach(function(t) {
                    if ("function" == typeof n[t]) {
                        var e = n[t];
                        n[t] = function() {
                            for (var t = [], o = 0; o < arguments.length; o++) t[o] = arguments[o];
                            return e.apply(r.hasOwnProperty("bindTo") ? r.bindTo : this, t);
                        };
                    }
                }), Object.defineProperty(i, o, e.__assign(e.__assign({}, n), O));
            }
        });
    }, t, r.till || Object, !1), i;
}, exports.isObject = n, exports.isPlainObject = function(t) {
    return "[object Object]" === Object.prototype.toString.call(t);
};