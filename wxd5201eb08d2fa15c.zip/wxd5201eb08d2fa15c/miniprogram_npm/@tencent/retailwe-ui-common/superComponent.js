Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SuperComponent = void 0;

var e = function() {
    this.app = "function" == typeof getApp ? getApp() : {};
};

exports.SuperComponent = e;