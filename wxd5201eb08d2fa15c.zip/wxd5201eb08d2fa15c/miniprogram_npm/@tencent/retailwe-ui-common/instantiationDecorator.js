Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxComponent = exports.toComponent = void 0;

var e = require("tslib"), t = require("./flatTool"), o = [ "Created", "Attached", "Ready", "Moved", "Detached" ].map(function(e) {
    return e.toLowerCase();
}), r = [ "externalClasses", "properties", "data", "options", "relations", "behaviors" ];

function n(e) {
    e.properties && Object.keys(e.properties).forEach(function(o) {
        var r = e.properties[o];
        t.isPlainObject(r) || (r = {
            type: r
        }), e.properties[o] = r;
    }), e.methods || (e.methods = {});
    var n = {};
    if (Object.getOwnPropertyNames(e).forEach(function(t) {
        var p = Object.getOwnPropertyDescriptor(e, t);
        p && (o.indexOf(t) < 0 && "function" == typeof p.value ? (Object.defineProperty(e.methods, t, p), 
        delete e[t]) : r.indexOf(t) < 0 && (n[t] = p));
    }), Object.keys(n).length) {
        var p = e.created;
        e.created = function() {
            Object.defineProperties(this, n), p && p.apply(this, arguments);
        };
    }
    return e;
}

exports.toComponent = n, exports.wxComponent = function() {
    return function(o) {
        var r = new (function(t) {
            function o() {
                for (var e = [], o = 0; o < arguments.length; o++) e[o] = arguments[o];
                return t.call(this) || this;
            }
            return e.__extends(o, t), o.prototype.created = function() {
                t.prototype.created && t.prototype.created.call(this);
            }, o.prototype.attached = function() {
                t.prototype.attached && t.prototype.attached.call(this);
            }, o.prototype.detached = function() {
                t.prototype.detached && t.prototype.detached.call(this);
            }, o;
        }(o))();
        r.options = r.options || {}, void 0 === r.options.addGlobalClass && (r.options.addGlobalClass = !0);
        var p = n(t.toObject(r));
        Component(p);
    };
};