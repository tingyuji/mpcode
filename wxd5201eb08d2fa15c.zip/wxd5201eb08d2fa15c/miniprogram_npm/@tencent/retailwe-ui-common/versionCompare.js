var e = require("../../../@babel/runtime/helpers/typeof");

function r(r, t) {
    if (e(r) + e(t) != "stringstring") return !1;
    for (var n = r.split("."), s = t.split("."), p = Math.max(n.length, s.length), a = 0; a < p; a++) {
        if (n[a] && !s[a] && parseInt(n[a]) > 0 || parseInt(n[a]) > parseInt(s[a])) return 1;
        if (s[a] && !n[a] && parseInt(s[a]) > 0 || parseInt(n[a]) < parseInt(s[a])) return -1;
    }
    return 0;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.versionCompare = void 0, exports.versionCompare = r, exports.default = r;