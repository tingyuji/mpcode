Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("tslib"), e = require("@tencent/retailwe-common-libs-navigator"), a = require("../config/routerMap"), r = t.__importDefault(require("../store/index")), p = t.__importDefault(require("../store/slices/global/index")), o = new (function(o) {
    function i() {
        return null !== o && o.apply(this, arguments) || this;
    }
    return t.__extends(i, o), i.prototype.gotoPageDelay = function(r) {
        for (var p = this, i = [], s = 1; s < arguments.length; s++) i[s - 1] = arguments[s];
        var u = "string" == typeof r ? {
            path: r,
            type: e.PathType.NORMAL
        } : r, h = a.getRouterPath(u.path);
        h && (u.path = h.path || u.path, u.type = h.type || u.type), this.timer && clearTimeout(this.timer), 
        i[1] && i[1].delay ? this.timer = setTimeout(function() {
            o.prototype.gotoPage.apply(p, t.__spreadArray([ u ], i));
        }, i[1].delay) : o.prototype.gotoPage.apply(this, t.__spreadArray([ u ], i));
    }, i.prototype.gotoPage = function(i) {
        for (var s, u = [], h = 1; h < arguments.length; h++) u[h - 1] = arguments[h];
        var n = "string" == typeof i ? {
            path: i,
            type: e.PathType.NORMAL
        } : i, y = a.getRouterPath(n.path);
        y && (n.path = y.path || n.path, n.type = y.type || n.type), a.isTabRoute(n.path) && r.default.dispatch(p.default.actions.setTabPageParams(((s = {})[n.path] = u[0], 
        s))), a.isMustAuthRouter(n.path) || o.prototype.gotoPage.apply(this, t.__spreadArray([ n ], u));
    }, i;
}(e.Navigator))();

exports.default = o;