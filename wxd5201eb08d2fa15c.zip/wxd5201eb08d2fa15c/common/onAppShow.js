require("../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib").__importDefault(require("./updateManager")), r = require("../core/globalData");

function a(a) {
    var l = (a || {}).scene;
    global.scene = l;
    var o = {
        channels: [ 1175 ].includes(l)
    };
    e.default(), r.$global("launchOptions", a), r.$global("scenes", o);
}

global.appShowSubscribed || wx.onAppShow(a), global.appShowSubscribed = !0;