Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../services/session/authLogin"), s = require("../services/session/index");

!function() {
    if (!global.onAppLaunchCalled) {
        global.onAppLaunchCalled = !0;
        var n = wx.getStorageSync("hasOpenIdLogged");
        e.authLogin.login(!n || !s.session.hasAuth());
    }
}();