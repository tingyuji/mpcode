Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.navigateToHome = exports.navigateToHistory = exports.navigateToChat = exports.memoizedGetConvList = exports.memoizedGetDialog = exports.memoizedGenerateConvId = exports.handleGetConvList = exports.handleGetDialog = exports.generateConvId = void 0;

var e = require("tslib"), t = require("../config/constants"), o = e.__importDefault(require("./navigator")), i = require("../utils/base"), r = require("./http-client/index"), n = e.__importDefault(require("../utils/memoize"));

function a(t, o, i) {
    return e.__awaiter(this, void 0, void 0, function() {
        return e.__generator(this, function(e) {
            return [ 2, r.apis.dialog.getConvs({
                offset: t,
                limit: o,
                chatTypeList: i,
                orderBy: "last"
            }) ];
        });
    });
}

function s(t) {
    return e.__awaiter(this, void 0, void 0, function() {
        return e.__generator(this, function(e) {
            return [ 2, r.apis.conv.getDetail({
                cid: t
            }) ];
        });
    });
}

exports.generateConvId = function(e) {
    return console.log("generating", e), r.apis.conv.generate().then(function(e) {
        return console.log("%c conv.generate: %o", "color: #0000ff", e), e;
    });
}, exports.handleGetDialog = a, exports.handleGetConvList = s, exports.memoizedGenerateConvId = n.default(exports.generateConvId), 
exports.memoizedGetDialog = n.default(a), exports.memoizedGetConvList = n.default(s);

exports.navigateToChat = function(t, r) {
    void 0 === r && (r = !1);
    var n = t.id ? void 0 : "" + Math.random() + new Date().getTime(), a = i.omitBy(e.__assign(e.__assign({}, t), {
        randomConvId: n
    }), i.isUndefined);
    o.default.gotoPage("chat", a, {
        redirect: r
    }), n && (exports.memoizedGenerateConvId.reset(), exports.memoizedGenerateConvId.call(n));
};

exports.navigateToHistory = function(e) {
    void 0 === e && (e = !1), exports.memoizedGetDialog.reset(), exports.memoizedGetDialog.call(0, t.DIALOG_FETCH_CONFIG.limit, 0), 
    o.default.gotoPage("history", {}, {
        redirect: e
    });
};

exports.navigateToHome = function(e, t) {
    void 0 === t && (t = !1), exports.memoizedGetConvList.reset(), (null == e ? void 0 : e.id) && exports.memoizedGetConvList.call(e.id), 
    o.default.gotoPage("home", e, {
        redirect: t
    });
};