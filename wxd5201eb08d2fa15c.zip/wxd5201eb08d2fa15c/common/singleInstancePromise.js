Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.singleInstancePromise = void 0;

exports.singleInstancePromise = function(e) {
    var r = void 0;
    return function() {
        for (var n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
        return r || (r = e.bind(void 0).apply(void 0, n).then(function(e) {
            return r = void 0, Promise.resolve(e);
        }).catch(function(e) {
            return r = void 0, Promise.reject(e);
        }));
    };
};