Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = e.__importDefault(require("../lib/pify"));

exports.default = function() {
    if (wx.canIUse("getUpdateManager")) {
        var r = wx.getUpdateManager();
        r.onUpdateReady(function() {
            return e.__awaiter(void 0, void 0, void 0, function() {
                return e.__generator(this, function(e) {
                    switch (e.label) {
                      case 0:
                        return e.trys.push([ 0, 2, , 3 ]), [ 4, t.default(wx.showModal)({
                            title: "更新提示",
                            content: "新版本已经准备好，是否更新并重启？",
                            confirmText: "更新"
                        }) ];

                      case 1:
                        return e.sent().confirm && r.applyUpdate(), [ 3, 3 ];

                      case 2:
                        return e.sent(), [ 3, 3 ];

                      case 3:
                        return [ 2 ];
                    }
                });
            });
        }), r.onUpdateFailed(function() {});
    }
};