Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.STORAGE_EVENT_CLEAR = exports.StorageEventActions = void 0;

var e = require("tslib"), t = require("@tencent/retailwe-common-libs-storage");

Object.defineProperty(exports, "STORAGE_EVENT_CLEAR", {
    enumerable: !0,
    get: function() {
        return t.STORAGE_EVENT_CLEAR;
    }
}), Object.defineProperty(exports, "StorageEventActions", {
    enumerable: !0,
    get: function() {
        return t.StorageEventActions;
    }
});

var r = e.__importDefault(require("../utils/getGlobalSingleton"));

exports.default = r.default(function() {
    return new t.Storage(function() {
        var e = {
            expires: 288e5,
            enableMemoryCache: !0
        };
        try {
            var t = wx.getExtConfigSync().env;
            t && (e.env = t);
        } catch (e) {}
        return e;
    }());
}, "__storage__");