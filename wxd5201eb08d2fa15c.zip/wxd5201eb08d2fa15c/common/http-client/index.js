Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.requestChatStream = exports.apis = exports.httpClient = void 0;

var e, t = require("tslib"), r = t.__importDefault(require("../../components/notify/notify")), o = require("../../config/constants"), a = require("../../interface/type"), i = require("../../services/session/index"), s = require("../../services/session/libs/authLogin"), n = require("../../utils/helper"), p = require("../../utils/index"), c = require("../../utils/zhiyanReport"), l = require("@tencent/retailwe-common-libs-http-client"), u = t.__importDefault(require("./register-apis")), g = t.__importDefault(require("./register-interceptors"));

t.__exportStar(require("./types"), exports), exports.httpClient = new l.HttpClient(), 
g.default(exports.httpClient), exports.apis = u.default(exports.httpClient);

exports.requestChatStream = function(l, u, g) {
    var d;
    return t.__awaiter(this, void 0, void 0, function() {
        function T(e) {
            var r, i = e.lastIndexOf("\r\n"), s = "";
            if (-1 !== i ? (s = e.substring(0, i + 2), f = e.substring(i + 2)) : f = e, "data: [DONE]\n\n" !== f && "data: [SENSITIVE]\n\n" !== f || (s += f.replace("\n\n", "\r\n"), 
            f = ""), s) {
                var u = n.handleStreamData(s), g = u.type, d = u.data, T = u.msgTypeDeclaration, _ = u.matchedPluginInfo, h = g;
                if (T && (T === a.StreamSpeechType.revoke ? (y = a.StreamSpeechType.text, R = "") : y = T), 
                _ && (S = _), y === a.StreamSpeechType.text ? d.map(function(e) {
                    e.type === a.MsgType.text ? R += e.msg || "" : console.error("unexpected message type, do nothing"), 
                    e.msgType === a.TextMsgErrorType.error && (v = a.TextMsgErrorType.error);
                }) : y === a.StreamSpeechType.imageWithText ? ("" === R && (R = o.getOriginImageText()), 
                d.map(function(e) {
                    e.type === a.MsgType.image ? R.images[e.idx || 0] = {
                        imageUrl: e.imageUrlLow,
                        highDefImageUrl: e.imageUrlHigh,
                        failed: !1,
                        progress: 100
                    } : e.type === a.MsgType.text ? R.text += e.msg || "" : e.type === a.MsgType.progress && (R.images[e.idx || 0].progress = n.formatProgress(e.value));
                })) : y === a.StreamSpeechType.goodsWithText ? ("" === R && (R = o.getOriginGoodsText()), 
                d.map(function(e) {
                    var t;
                    if (e.type === a.MsgType.goods) {
                        var r = e.imageUrl, o = e.title, i = e.goodsId, s = e.traceId, p = e.currentPrice, c = e.miniprogramAppId, l = e.miniprogramUrl, u = e.idx, g = e.total;
                        R.goods[u || 0] = {
                            imageUrl: r,
                            price: p,
                            title: o,
                            appid: c,
                            path: l,
                            total: g,
                            goodsId: i,
                            traceId: s
                        }, R.goods = R.goods.filter(function(e) {
                            return e.appid && e.path;
                        }), R.goodsGroup = n.chunkArray(R.goods);
                    } else e.type === a.MsgType.text && ((null === (t = R.goods) || void 0 === t ? void 0 : t.length) > 0 ? R.text += e.msg || "" : R.preText += e.msg || "");
                })) : y === a.StreamSpeechType.pdf ? ("" === R && (R = o.getPdfText()), d.map(function(e) {
                    e.type === a.MsgType.step ? (R.msg = e.msg, R.status = e.status) : e.type === a.MsgType.text && (R.text += e.msg || "");
                })) : y === a.StreamSpeechType.cutoff && d.map(function(e) {
                    e.type === a.MsgType.text ? R += e.msg || "" : console.error("unexpected message type, do nothing"), 
                    e.msgType === a.TextMsgErrorType.error && (v = a.TextMsgErrorType.error);
                }), h !== o.CONV_STREAM_TYPE.DONE || "" !== R || l.continue ? h !== o.CONV_STREAM_TYPE.ERROR && h !== o.CONV_STREAM_TYPE.SENSITIVE_DONE || "" !== R || (R = o.ERROR_GENERATE_FAILED) : (R = o.ERROR_EMPTY_ANSWER, 
                h = o.CONV_STREAM_TYPE.ERROR), h === o.CONV_STREAM_TYPE.DONE && y === a.StreamSpeechType.imageWithText && R.images.map(function(e) {
                    e.imageUrl || (e.failed = !0);
                }), C(h, R, y, S, v), h !== o.CONV_STREAM_TYPE.ADD && function() {
                    t.__awaiter(this, void 0, void 0, function() {
                        var e, r, o;
                        return t.__generator(this, function(t) {
                            switch (t.label) {
                              case 0:
                                return [ 4, new Promise(function(e) {
                                    exports.apis.conv.getQuotaInfo().then(function(t) {
                                        ((null == t ? void 0 : t.remainQuota) <= 0 || (null == t ? void 0 : t.remainQuota) <= t.alarmQuota) && e(t.remainQuota <= 0 ? 0 : t.remainQuota);
                                    }).catch(function(e) {
                                        console.error("获取限额发生错误: ", e);
                                    });
                                }) ];

                              case 1:
                                if (void 0 !== (e = t.sent()) || null !== e) {
                                    if ("pages/compare/index" === (null == (r = p.getCurrentPage()) ? void 0 : r.route)) return r.setData({
                                        chatQuota: e
                                    }), [ 2 ];
                                    (o = null == r ? void 0 : r.selectComponent("#chat-window")) && (null == o || o.setData({
                                        chatQuota: e
                                    }));
                                }
                                return [ 2 ];
                            }
                        });
                    });
                }(), u.type === o.CONV_STREAM_TYPE.ERROR) try {
                    c.chatApiErrorReport(t.__assign(t.__assign({
                        errorType: JSON.stringify(u.data)
                    }, l), {
                        api: m,
                        footPrint: S,
                        answer: n.getReportMsg(R)
                    }));
                } catch (e) {} else u.type !== o.CONV_STREAM_TYPE.ADD && c.chatApiSuccessReport(t.__assign(t.__assign({}, l), {
                    api: m,
                    footPrint: S,
                    answer: n.getReportMsg(R)
                }));
                u.type !== o.CONV_STREAM_TYPE.ADD && (x = !0, null === (r = M.offChunkReceived) || void 0 === r || r.call(M));
            }
        }
        var _, m, h, E, f, y, R, x, S, v, C, M;
        return t.__generator(this, function(p) {
            switch (p.label) {
              case 0:
                return delete (_ = t.__assign({}, l)).cid, m = u === o.CONV_CHAT_TYPE.CHAT || u === o.CONV_CHAT_TYPE.CONTINUE_CHAT ? "api/chat/" : "api/chat/repeat/", 
                h = "" + n.getRequestBaseUrl() + m + l.cid, E = "", f = "", y = a.StreamSpeechType.text, 
                R = "", x = !1, S = "", v = a.TextMsgErrorType.normal, C = n.throttleByStreamLength(g, 67, 200, 1e3, n.isIOS ? 100 : 20, 10), 
                [ 4, s.authLogin.login(!1) ];

              case 1:
                return p.sent(), (M = wx.request({
                    method: "POST",
                    url: h,
                    timeout: 1e3 * ("doubao" === l.model ? 60 : 20),
                    dataType: "json",
                    enableChunked: !0,
                    responseType: "text",
                    header: t.__assign({
                        Accept: "text/plain"
                    }, i.session.getRequestAuthHeader()),
                    data: t.__assign({}, _),
                    success: function(e) {
                        if (console.log("%c get chat response success", "color: #1aad19", R, e), !x) {
                            try {
                                return void ((null == e ? void 0 : e.data) && !R && T(decodeURIComponent(e.data)));
                            } catch (e) {
                                console.error("stream fallback data parse error:", e);
                            }
                            C(R ? o.CONV_STREAM_TYPE.DONE : o.CONV_STREAM_TYPE.ERROR, R || o.ERROR_GENERATE_FAILED, a.StreamSpeechType.text, void 0, a.TextMsgErrorType.normal);
                        }
                    },
                    fail: function(e) {
                        var i;
                        console.error("chat fail", e);
                        var s = "request:fail timeout" === (null == e ? void 0 : e.errMsg) ? "请求超时，请重试" : "网络异常，请重试";
                        C(R ? o.CONV_STREAM_TYPE.DONE : o.CONV_STREAM_TYPE.ERROR, R || s, a.StreamSpeechType.text, void 0, a.TextMsgErrorType.normal), 
                        R && r.default.error({
                            message: s,
                            duration: 2500
                        }), null === (i = M.offChunkReceived) || void 0 === i || i.call(M), x = !0, c.chatApiErrorReport(t.__assign(t.__assign({
                            errorType: e.errMsg
                        }, l), {
                            api: m,
                            footPrint: S,
                            answer: n.getReportMsg(R)
                        }));
                    }
                })).onChunkReceived(function(t) {
                    var r, o = E + n.arrayBufferToString(t.data);
                    try {
                        var a = f + decodeURIComponent(o);
                        E = "", console.log("%c decodedText: %s", "color: #9922bb", a), T(a);
                    } catch (t) {
                        E += o, console.error("Error decoding", t), clearTimeout(e), r = E, e = setTimeout(function() {
                            console.error("errorData:", r);
                        }, 3e3);
                    }
                }), null === (d = M.onHeadersReceived) || void 0 === d || d.call(M, function(e) {
                    var r;
                    console.log("___________onHeadersReceived", e);
                    var i = e.statusCode, s = e.header, p = i || s.statusCode || 200, u = "";
                    p >= 400 && p < 500 ? u = "权限校验出错，请删除小程序重试" : p >= 500 && p < 600 && (u = "服务器错误"), 
                    u && (x = !0, C(o.CONV_STREAM_TYPE.ERROR, u, a.StreamSpeechType.text, void 0, a.TextMsgErrorType.normal), 
                    c.chatApiErrorReport(t.__assign(t.__assign({
                        errorType: "httpCode: " + p
                    }, l), {
                        api: m,
                        footPrint: S,
                        answer: n.getReportMsg(R)
                    })), null === (r = M.offChunkReceived) || void 0 === r || r.call(M));
                }), [ 2 ];
            }
        });
    });
}, exports.default = exports.httpClient;