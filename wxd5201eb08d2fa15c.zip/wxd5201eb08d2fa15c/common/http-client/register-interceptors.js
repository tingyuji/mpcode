Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), r = require("../../utils/helper"), t = require("@tencent/retailwe-common-libs-http-client"), n = e.__importDefault(require("./interceptors/biz-res-handler")), i = e.__importDefault(require("./interceptors/auth")), o = require("../../utils/index"), u = t.interceptors.injectReqHeaders, s = t.interceptors.injectReqBody, c = t.interceptors.baseUrl, a = t.interceptors.httpLogger;

exports.default = function(t) {
    var p = this;
    return t.registerInterceptor(c(function() {
        return e.__awaiter(p, void 0, void 0, function() {
            return e.__generator(this, function(e) {
                return [ 2, r.getRequestBaseUrl() ];
            });
        });
    })), t.registerInterceptor(n.default()), t.registerInterceptor(i.default(t)), t.registerInterceptor(u(function() {
        return e.__awaiter(p, void 0, void 0, function() {
            var r, t, n, i, u;
            return e.__generator(this, function(e) {
                return r = getCurrentPages(), t = r[r.length - 1] || {}, n = t.route, i = t.options, 
                u = o.obj2Params(i, !0), [ 2, {
                    http_referer: n + "?" + u
                } ];
            });
        });
    })), t.registerInterceptor(s(function() {
        return e.__awaiter(p, void 0, void 0, function() {
            return e.__generator(this, function(e) {
                return [ 2, {} ];
            });
        });
    })), t.registerInterceptor(a()), t;
};