Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.EnumRequestLevel = void 0, function(e) {
    e[e.Key = 1] = "Key", e[e.Minor = 2] = "Minor", e[e.Negligible = 3] = "Negligible";
}(exports.EnumRequestLevel || (exports.EnumRequestLevel = {}));