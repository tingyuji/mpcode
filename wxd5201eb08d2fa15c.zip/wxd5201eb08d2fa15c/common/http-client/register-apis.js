var r = require("../../@babel/runtime/helpers/typeof");

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), i = require("../../config/api"), t = {
    method: "GET"
};

exports.default = function(n) {
    function u(r) {
        return function(i, t) {
            if (-1 !== r.url.indexOf("#{")) {
                var u = r.url.replace(/#{(\w+)}/g, function(r, e) {
                    if (i[e]) {
                        var t = i[e];
                        return delete i[e], t;
                    }
                    return r;
                });
                return n.registerApi(e.__assign(e.__assign({}, r), {
                    url: u
                }))(i, t);
            }
            return n.registerApi(r)(i, t);
        };
    }
    return function e(i) {
        if ("string" == typeof i) return u({
            url: i,
            config: t
        });
        if ("object" === r(i)) {
            if (i.url) return i.config = Object.assign({}, t, i.config || {}), u(i);
            var n = {};
            for (var f in i) n[f] = e(i[f]);
            return n;
        }
    }(i.api);
};