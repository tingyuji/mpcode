Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib");

exports.default = function() {
    var t = this;
    return {
        name: "bizResHandler",
        request: function(r) {
            return e.__awaiter(t, void 0, void 0, function() {
                var t, n, i, a, o;
                return e.__generator(this, function(s) {
                    return t = Math.random().toString() + Date.now(), n = new Date(), i = n.getTime(), 
                    a = r.body, o = e.__assign(e.__assign({}, a), {
                        _reqId_: t
                    }), [ 2, Object.assign(r, {
                        body: o,
                        _startTime_: i
                    }) ];
                });
            });
        },
        response: function(r) {
            return e.__awaiter(t, void 0, void 0, function() {
                return e.__generator(this, function(e) {
                    return [ 2, r.data ];
                });
            });
        }
    };
};