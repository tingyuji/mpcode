require("../../../@babel/runtime/helpers/Arrayincludes"), Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), r = require("../index"), t = require("../libs/index"), s = require("../../../config/constants"), n = require("../../../utils/helper"), i = require("../../../services/session/index"), u = require("../../../services/session/authLogin");

function o(o, a) {
    return e.__awaiter(this, void 0, void 0, function() {
        var l, c, d, h, f, _;
        return e.__generator(this, function(e) {
            switch (e.label) {
              case 0:
                return l = o.request, c = o.status, d = o.message, global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser ? [ 3, 5 ] : (h = i.session.getWxAppKey(), 
                401 !== c || "is-retry" === (null == l ? void 0 : l.headers["is-retry"]) ? [ 3, 4 ] : (null == l ? void 0 : l.headers.wxappkey) !== h ? [ 3, 2 ] : [ 4, u.authLogin.refreshLogin() ]);

              case 1:
                e.sent(), e.label = 2;

              case 2:
                return l.headers["is-retry"] = "is-retry", [ 4, a.fly.request(l) ];

              case 3:
                return [ 2, e.sent() ];

              case 4:
                return [ 3, 9 ];

              case 5:
                return h = i.session.getOuterLoginToken(), 401 !== c || "is-retry" === (null == l ? void 0 : l.headers["is-retry"]) ? [ 3, 9 ] : (null == l ? void 0 : l.headers["X-Token"]) !== h ? [ 3, 7 ] : [ 4, u.authLogin.refreshLogin() ];

              case 6:
                e.sent(), e.label = 7;

              case 7:
                return l.headers["is-retry"] = "is-retry", [ 4, a.fly.request(l) ];

              case 8:
                return [ 2, e.sent() ];

              case 9:
                if (c >= 200 && c < 300 || 304 === c) return [ 2, o ];
                if (401 === c) throw new Error("无权限用户");
                if (403 === c && -1 === o.request.url.indexOf("api/generate/prompts")) throw n.relaunchAuthBanned(), 
                new Error("被封号用户");
                throw f = l.level, _ = void 0 === f ? r.EnumRequestLevel.Minor : f, (null == d ? void 0 : d.includes("timeout")) && (o.timeout = !0), 
                c ? t.StatusErrorHandle(_ || 0, c, d) : t.SystemErrorHandle(_ || 0, d), o;
            }
        });
    });
}

exports.default = function(r) {
    var t = this;
    return {
        name: "auth",
        request: function(r) {
            return e.__awaiter(this, void 0, void 0, function() {
                var t;
                return e.__generator(this, function(e) {
                    switch (e.label) {
                      case 0:
                        return t = i.session.getRequestAuthHeader(), global[s.CURRENT_LOGIN_TYPE] === s.LOGIN_USER_TYPE.outerUser || t.wxappkey ? [ 3, 2 ] : [ 4, u.authLogin.refreshLogin() ];

                      case 1:
                        e.sent(), t = i.session.getRequestAuthHeader(), e.label = 2;

                      case 2:
                        return Object.assign(r.headers, t), [ 2, r ];
                    }
                });
            });
        },
        response: function(s) {
            return e.__awaiter(t, void 0, void 0, function() {
                return e.__generator(this, function(e) {
                    return [ 2, o(s, r) ];
                });
            });
        },
        responseError: function(e) {
            return o(e, r);
        }
    };
};