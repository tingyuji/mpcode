Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("tslib"), t = require("../utils/helper"), o = require("../utils/index"), r = require("../utils/zhiyanReport"), n = new (function() {
    function n() {}
    return n.prototype.onLoad = function(n) {
        return e.__awaiter(this, void 0, void 0, function() {
            var i, u;
            return e.__generator(this, function(e) {
                return i = t.getCurrentPagePath(), u = o.obj2Params(n), r.pvReport({
                    path: i,
                    href: u ? i + "?" + u : i
                }), [ 2 ];
            });
        });
    }, n.prototype.onShow = function() {}, n.prototype.onReady = function() {}, n.prototype.onUnload = function() {}, 
    n.prototype.onShareAppMessage = function(e) {
        console.log("share hook:", e);
    }, n;
}())();

exports.default = n;