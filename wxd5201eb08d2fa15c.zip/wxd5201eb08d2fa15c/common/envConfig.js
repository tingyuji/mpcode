Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getEnvConfig = void 0;

var e = require("tslib").__importDefault(require("../config/env"));

exports.getEnvConfig = function() {
    return e.default;
};