(0, require("../common/component").VantComponent)({
    props: {
        title: String,
        border: {
            type: Boolean,
            value: !0
        }
    }
});