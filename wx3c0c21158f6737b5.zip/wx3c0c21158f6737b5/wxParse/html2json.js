var e = wx.getStorageSync("http"), t = "", r = "", n = {}, s = require("./wxDiscode.js"), a = require("./htmlparser.js"), o = (c("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr"), 
c("br,a,code,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video")), i = c("abbr,acronym,applet,b,basefont,bdo,big,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), l = c("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr"), d = (c("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected"), 
c("wxxxcode-style,script,style,view,scroll-view,block"), [ "small_font", "small_font", "middle_font", "large_font" ]);

function c(e) {
    for (var t = {}, r = e.split(","), n = 0; n < r.length; n++) t[r[n]] = !0;
    return t;
}

function u(e) {
    var s = [];
    if (0 == t.length || !n) return (d = {
        node: "text"
    }).text = e, o = [ d ];
    e = e.replace(/\[([^\[\]]+)\]/g, ":$1:");
    for (var a = new RegExp("[:]"), o = e.split(a), i = 0; i < o.length; i++) {
        var l = o[i], d = {};
        n[l] ? (d.node = "element", d.tag = "emoji", d.text = n[l], d.baseSrc = r) : (d.node = "text", 
        d.text = l), s.push(d);
    }
    return s;
}

module.exports = {
    html2json: function(t, r) {
        t = function(e) {
            return e.replace(/\r?\n+/g, "").replace(/<!--.*?-->/gi, "").replace(/\/\*.*?\*\//gi, "").replace(/[ ]+</gi, "<");
        }(t = function(e) {
            return e.replace(/<\?xml.*\?>\n/, "").replace(/<.*!doctype.*\>\n/, "").replace(/<.*!DOCTYPE.*\>\n/, "");
        }(t)), t = s.strDiscode(t);
        var n = [], c = {
            node: r,
            nodes: [],
            images: [],
            imageUrls: []
        }, p = 0;
        return a(t, {
            start: function(t, a, d) {
                var u, g = {
                    node: "element",
                    tag: t
                };
                0 === n.length ? (g.index = p.toString(), p += 1) : (void 0 === (u = n[0]).nodes && (u.nodes = []), 
                g.index = u.index + "." + u.nodes.length);
                if (o[t] ? g.tagType = "block" : i[t] ? g.tagType = "inline" : l[t] && (g.tagType = "closeSelf"), 
                0 !== a.length && (g.attr = a.reduce(function(e, t) {
                    var r = t.name, n = t.value;
                    return "class" == r && (g.classStr = n), "style" == r && (g.styleStr = n), n.match(/ /) && (n = n.split(" ")), 
                    e[r] ? Array.isArray(e[r]) ? e[r].push(n) : e[r] = [ e[r], n ] : e[r] = n, e;
                }, {})), "img" === g.tag) {
                    g.imgIndex = c.images.length;
                    var f = g.attr.src;
                    "" == f[0] && f.splice(0, 1), f = s.urlToHttpUrl(f, e), g.attr.src = f, g.from = r, 
                    c.images.push(g), c.imageUrls.push(f);
                }
                if ("font" === g.tag) {
                    var m = [ "x-small", "small", "medium", "large", "x-large", "xx-large", "-webkit-xxx-large" ], h = {
                        color: "color",
                        face: "font-family",
                        size: "font-size"
                    };
                    for (var v in g.attr.style || (g.attr.style = []), g.styleStr || (g.styleStr = ""), 
                    h) if (g.attr[v]) {
                        var x = "size" === v ? m[g.attr[v] - 1] : g.attr[v];
                        g.attr.style.push(h[v]), g.attr.style.push(x), g.styleStr += h[v] + ": " + x + ";";
                    }
                }
                ("source" === g.tag && (c.source = g.attr.src), d) ? (void 0 === (u = n[0] || c).nodes && (u.nodes = []), 
                u.nodes.push(g)) : n.unshift(g);
            },
            end: function(e) {
                var t = n.shift();
                if (t.tag !== e && console.error("invalid state: mismatch end tag"), "video" === t.tag && c.source && (t.attr.src = c.source, 
                delete c.source), 0 === n.length) c.nodes.push(t); else {
                    var r = n[0];
                    void 0 === r.nodes && (r.nodes = []), r.nodes.push(t);
                }
            },
            chars: function(e) {
                var t = 0, s = "small_font";
                if ("ParseTitle" == r || "wxParseOption" == r.substr(0, 13) || "article" == r) {
                    t = 1;
                    var a = parseInt(wx.getStorageSync("userinfo").fontsize);
                    console.log("fontid:" + a), s = d[a];
                }
                var o = {
                    node: "text",
                    text: e,
                    isDiy: t,
                    diyFont: s,
                    textArray: u(e)
                };
                if (0 === n.length) o.index = p.toString(), p += 1, c.nodes.push(o); else {
                    var i = n[0];
                    void 0 === i.nodes && (i.nodes = []), o.index = i.index + "." + i.nodes.length, 
                    i.nodes.push(o);
                }
            },
            comment: function(e) {}
        }), c;
    },
    emojisInit: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "/wxParse/emojis/", a = arguments.length > 2 ? arguments[2] : void 0;
        t = e, r = s, n = a;
    }
};