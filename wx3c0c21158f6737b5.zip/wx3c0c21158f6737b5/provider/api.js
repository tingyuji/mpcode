var t = getApp(), e = "entry/wxapp/", u = "goouc_fullexam";

module.exports = {
    post: function(o, a) {
        return new Promise(function(n, r) {
            a || (a = {}), a.m = u, t.util.request({
                url: e + o,
                data: a,
                method: "post",
                header: {},
                success: function(t) {
                    n(t.data);
                },
                fail: function(t) {
                    r(t.data);
                }
            });
        });
    }
};