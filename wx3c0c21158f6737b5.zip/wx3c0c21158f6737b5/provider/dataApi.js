var t = require("api.js");

getApp();

module.exports = {
    myTika: function(n) {
        return t.post("myTika", n);
    },
    setting: function(n) {
        return t.post("setting", n);
    },
    testRecord1: function(n) {
        return t.post("testRecord1", n);
    },
    lx_record: function(n) {
        return t.post("lx_record", n);
    },
    planlist: function(n) {
        return t.post("planlist", n);
    },
    videoNotes: function(n) {
        return t.post("videoNotes", n);
    },
    video: function(n) {
        return t.post("video", n);
    },
    myerrListNew: function(n) {
        return t.post("myerrListNew", n);
    },
    myCollect: function(n) {
        return t.post("myCollect", n);
    },
    login: function(n) {
        return t.post("login", n);
    },
    docount: function(n) {
        return t.post("docount", n);
    },
    getMyFeedBack: function(n) {
        return t.post("getMyFeedBack", n);
    },
    updateInfo: function(n) {
        return t.post("updateInfo", n);
    },
    knowlock: function(n) {
        return t.post("knowlock", n);
    },
    alltest: function(n) {
        return t.post("alltest", n);
    },
    knowSelect: function(n) {
        return t.post("knowSelect", n);
    },
    testRecord: function(n) {
        return t.post("testRecord", n);
    },
    knowRecord: function(n) {
        return t.post("knowRecord", n);
    },
    islock: function(n) {
        return t.post("islock", n);
    },
    fidselect: function(n) {
        return t.post("fidselect", n);
    },
    phoneLogin: function(n) {
        return t.post("phonelogin", n);
    },
    getBind: function(n) {
        return t.post("getbind", n);
    },
    relieve: function(n) {
        return t.post("relieve", n);
    },
    userinfo: function(n) {
        return t.post("Setuserinfo", n);
    },
    uploadImage: function(n) {
        return t.post("UploadImage", n);
    },
    updateHeadimg: function(n) {
        return t.post("UpdateHeadimg", n);
    },
    indexData: function(n) {
        return t.post("Index", n);
    },
    readNotice: function(n) {
        return t.post("Readnotice", n);
    },
    article: function(n) {
        return t.post("Article", n);
    },
    readVideo: function(n) {
        return t.post("Readvideo", n);
    },
    medal: function(n) {
        return t.post("Medal", n);
    },
    giftList: function(n) {
        return t.post("GiftList", n);
    },
    exchangeGift: function(n) {
        return t.post("ExchangeGift", n);
    },
    exchangeGiftList: function(n) {
        return t.post("ExchangeGiftList", n);
    },
    aboutus: function(n) {
        return t.post("Aboutus", n);
    },
    mockExam: function(n) {
        return t.post("Mockexam", n);
    },
    preExamInfo: function(n) {
        return t.post("PreExamInfo", n);
    },
    getExamList: function(n) {
        return t.post("GetExamList", n);
    },
    sequence: function(n) {
        return t.post("Sequence", n);
    },
    totalqNum: function(n) {
        return t.post("TotalqNum", n);
    },
    mockexam_submit: function(n) {
        return t.post("Mockexam_submit", n);
    },
    getAchievement: function(n) {
        return t.post("GetAchievement", n);
    },
    addWrong: function(n) {
        return t.post("AddWrong", n);
    },
    share: function(n) {
        return t.post("Share", n);
    },
    feedback: function(n) {
        return t.post("Feedback", n);
    },
    notes: function(n) {
        return t.post("notes", n);
    },
    getnotes: function(n) {
        return t.post("getnotes", n);
    },
    sequence_submit: function(n) {
        return t.post("Sequence_submit", n);
    },
    myerrList: function(n) {
        return t.post("MyerrList", n);
    },
    atype: function(n) {
        return t.post("Atype", n);
    },
    advert: function(n) {
        return t.post("Advert", n);
    },
    knowledge: function(n) {
        return t.post("Knowledge", n);
    },
    setCDKey: function(n) {
        return t.post("SetCDKey", n);
    },
    wxPay: function(n) {
        return t.post("WxPay", n);
    },
    getFormid: function(n) {
        return t.post("GetFormid", n);
    },
    member: function(n) {
        return t.post("member", n);
    },
    examInfo: function(n) {
        return t.post("examinfo", n);
    },
    myTest: function(n) {
        return t.post("mytest", n);
    },
    myTestExplain: function(n) {
        return t.post("mytestexplain", n);
    }
};