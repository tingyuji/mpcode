module.exports = {
    nametransform: function(e) {
        return e && 1 < e.length ? e.slice(0, 1) : e;
    },
    formatDateTime: function(e) {
        var t, r;
        return (e = (t = e ? new Date(1e3 * Number(e)) : new Date()).getFullYear()) + "-" + (r = (r = t.getMonth() + 1) < 10 ? "0" + r : r) + "-" + ((t = t.getDate()) < 10 ? "0" + t : t);
    },
    strcharacterDiscode: function(e) {
        return (e = (e = (e = (e = (e = (e = (e = e.replace(/&nbsp;/g, " ")).replace(/&quot;/g, "'")).replace(/&amp;/g, "&")).replace(/&lt;/g, "<")).replace(/&gt;/g, ">")).replace(/&#8226;/g, "•")).replace(/&nbsp;/g, " ")).replace(/&nbsp;/g, " ");
    },
    formatDateTimehour: function(e) {
        var t = (e = e ? new Date(1e3 * Number(e)) : new Date()).getFullYear(), r = (r = e.getMonth() + 1) < 10 ? "0" + r : r, n = (n = e.getDate()) < 10 ? "0" + n : n, a = (a = e.getHours()) < 10 ? "0" + a : a, u = e.getMinutes();
        return e.getSeconds(), t + "-" + r + "-" + n + " " + a + ":" + (u < 10 ? "0" + u : u);
    },
    readingvolume: function(e) {
        return 1e4 <= e && (e = (e / 1e4).toFixed(2) + "万"), e;
    },
    transtr: function(e) {
        return e.split(",");
    },
    formatImg: function(e) {
        return e.replace(/<img[^>]*>/gi, function(e, t) {
            return (e = (e = e.replace(/style=[\'\"]?([^\'\"]*)[\'\"]?/i, "")).replace(/src=[\'\"]/i, function(e, t) {
                return e + "https://e.zkezy.com/";
            })).replace(/src=[\'\"]?([^\'\"]*)[\'\"]?/gi, function(e, t) {
                return MyPreviewList.push(t), "onclick=\"mypreviewfun('" + t + "')\"" + e;
            });
        });
    },
    formatImgtwo: function(e) {
        return e.replace(/<img[^>]*>/gi, function(e, t) {
            return e.replace(/src=[\'\"]/i, function(e, t) {
                return e + "https://e.zkezy.com/";
            });
        });
    },
    transType: function(e) {
        var t = "";
        return 1 == e && (t = "普通考试"), 2 == e && (t = "报名考试"), 3 == e && (t = "固定人群考试"), 
        4 == e && (t = "付费考试"), 5 == e && (t = "密码考试"), 6 == e && (t = "VIP考试"), 7 == e && (t = "班级考试"), 
        t;
    },
    formatDateDayTimehour: function(e) {
        var t;
        if (0 < (t = e - (t = new Date().getTime()))) {
            var r = parseInt(t / 1e3 / 60 / 60 / 24, 10);
            return parseInt(t / 1e3 / 60 / 60 % 24, 10), parseInt(t / 1e3 / 60 % 60, 10), parseInt(t / 1e3 % 60, 10), 
            new Date(e).toDateString() === new Date().toDateString() ? 0 : t < 86400 ? 1 : r + 1;
        }
        return 0;
    }
};