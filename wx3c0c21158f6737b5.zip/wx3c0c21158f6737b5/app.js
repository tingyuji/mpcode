var e = "wxc6c960d5d1f4361e";

App({
    onLaunch: function() {
        var e = this, t = this;
        wx.getSystemInfo({
            success: function(e) {
                var a;
                console.log(e), a = -1 !== e.model.indexOf("iPhone") ? 44 : 48, t.globalData.statusBarHeight = e.statusBarHeight, 
                t.globalData.titleBarHeight = a;
            },
            failure: function(e) {
                console.log(e), t.globalData.statusBarHeight = 0, t.globalData.titleBarHeight = 0;
            }
        });
        var a = wx.getStorageSync("logs") || [];
        a.unshift(Date.now()), wx.setStorageSync("logs", a), wx.login({
            success: function(e) {}
        }), wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userInfo"] && wx.getUserInfo({
                    success: function(t) {
                        e.globalData.userInfo = t.userInfo, e.userInfoReadyCallback && e.userInfoReadyCallback(t);
                    }
                });
            }
        });
    },
    getCache: function(t, a) {
        var n = +new Date() / 1e3, o = "";
        n = parseInt(n);
        try {
            (o = wx.getStorageSync(t + e)).expire > n || 0 == o.expire ? o = o.value : (o = "", 
            this.removeCache(t));
        } catch (t) {
            o = void 0 === a ? "" : a;
        }
        return o || "";
    },
    setCache: function(t, a, n) {
        var o = +new Date() / 1e3, r = !0, s = {
            expire: n ? o + parseInt(n) : 0,
            value: a
        };
        try {
            wx.setStorageSync(t + e, s);
        } catch (t) {
            r = !1;
        }
        return r;
    },
    removeCache: function(t) {
        var a = !0;
        try {
            wx.removeStorageSync(t + e);
        } catch (t) {
            a = !1;
        }
        return a;
    },
    globalData: {
        userInfo: null
    },
    util: require("we7/resource/js/util.js"),
    siteInfo: require("siteinfo.js")
});