getApp();

var t = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        type: 2,
        scroll_height: "",
        statusBarHeight: "",
        titleBarHeight: "",
        rankingArr: [ "刷题数量" ],
        rankingArrindex: 0,
        tongji_chart: [],
        myexam_info: {},
        info: {},
        list: [],
        userinfo: ""
    },
    goSwitch: function(t) {
        this.setData({
            type: t.currentTarget.dataset.type
        });
    },
    chakan: function() {
        wx.showModal({
            title: "提示",
            content: "每天做题达到" + this.data.info.dabiao_num + "道视为达标",
            showCancel: !1,
            success: function(t) {}
        });
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), t = wx.getSystemInfoSync().windowHeight;
        var a = wx.getSystemInfoSync().windowWidth;
        this.setData({
            scroll_height: 750 * t / a - 144
        });
    },
    bindPickerChange: function(t) {
        var a = parseInt(t.currentTarget.dataset.index) + 1;
        console.log(t), this.setData({
            rankingArrindex: t.currentTarget.dataset.index
        }), this.ranking(a);
    },
    onShow: function() {
        this.getAchievement(), this.getuserinfo(), this.ranking(this.data.rankingArrindex + 1);
    },
    getuserinfo: function() {
        var t = wx.getStorageSync("userinfo");
        this.setData({
            userinfo: t,
            rankingArr: 1 == t.stu_have ? [ "刷题数量", "坚持天数", "错题排行", "笔记热度" ] : [ "刷题数量" ]
        });
    },
    getAchievement: function() {
        var a = this;
        t.getAchievement({
            uid: wx.getStorageSync("uid"),
            op: "myexam_info"
        }).then(function(t) {
            console.log(t);
            var n = {};
            n.calculate = t.data.calculate, n.doexam_num = t.data.doexam_num, n.dotest_num = t.data.dotest_num, 
            n.myscore = t.data.myscore, n.not_donum = t.data.not_donum, n.pass_num = t.data.pass_num, 
            n.right_lv = t.data.right_lv, a.setData({
                tongji_chart: t.data.tongji_chart,
                myexam_info: n,
                info: t.data.info
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    ranking: function(a) {
        console.log(a, "ttt");
        var n = this, e = this.data.userinfo;
        t.getAchievement({
            uid: wx.getStorageSync("uid"),
            school_id: e.school_id,
            banji_id: e.banji_id,
            op: "rankings",
            rankType: a
        }).then(function(t) {
            console.log(t), n.setData({
                list: t.data.list,
                rankType: t.data.rankType
            });
        }).catch(function(t) {
            console.log(t), n.setData({
                list: t.data.list,
                rankType: t.data.rankType
            });
        });
    },
    onShareAppMessage: function() {}
});