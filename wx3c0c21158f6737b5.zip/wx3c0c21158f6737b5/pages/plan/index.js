var a = getApp(), t = require("../../provider/dataApi.js");

require("../../provider/pipe.js"), require("../../wxParse/wxParse.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        is_create: null,
        planlist: {},
        show: !0,
        list: {
            study_progress: "10",
            learned: "10",
            amount: "100",
            show: !1
        }
    },
    onLoad: function(a) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            day: "星期" + "日一二三四五六".charAt(new Date().getDay()),
            date: new Date().getMonth() + 1 + "月" + new Date().getDate() + "日"
        });
    },
    makePlan: function() {
        wx.navigateTo({
            url: "/promotion/plan/select"
        });
    },
    myPlan: function() {
        wx.navigateTo({
            url: "/promotion/plan/myplan"
        });
    },
    start: function(t) {
        console.log(this.data.planlist.plan.id, "查看做题数量");
        var n = t.currentTarget.dataset.num, e = t.currentTarget.dataset.id, o = t.currentTarget.dataset.type, i = this.data.planlist.plan.id;
        1 == o || 3 == o ? (a.globalData.op = "testplan", a.globalData.testnum = n, a.globalData.plan_id = i, 
        a.globalData.id = e, wx.navigateTo({
            url: "/promotion/plan/practice"
        })) : 2 == o && (a.globalData.op = "knowplan", a.globalData.testnum = n, a.globalData.plan_id = i, 
        a.globalData.id = e, wx.navigateTo({
            url: "/promotion/plan/knowledge"
        }));
    },
    review: function(t) {
        var n = t.currentTarget.dataset.id, e = t.currentTarget.dataset.type, o = this.data.planlist.plan.id;
        1 == e || 3 == e ? (a.globalData.op = "reviewtest", a.globalData.plan_id = o, a.globalData.id = n, 
        wx.navigateTo({
            url: "/promotion/plan/review"
        })) : 2 == e && (a.globalData.op = "reviewknow", a.globalData.plan_id = o, a.globalData.id = n, 
        wx.navigateTo({
            url: "/promotion/plan/knowledge_review"
        }));
    },
    onReady: function() {},
    onShow: function() {
        if (!wx.getStorageSync("uid")) return wx.reLaunch({
            url: "/pages/mine/mine"
        }), !1;
        this.getinfo(), this.plan();
    },
    getinfo: function() {
        var a = this;
        t.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(t) {
            console.log(t), wx.setStorageSync("userinfo", t.data.info), wx.setStorageSync("http", t.data.http), 
            a.setData({
                userinfo: t.data.info,
                phone: t.data.info.phone,
                isloading: !1
            }), 2 == t.data.pay_status && wx.showToast({
                title: "已激活",
                icon: "none"
            });
        }).catch(function(t) {
            console.log(t), a.setData({
                isloading: !1
            });
        });
    },
    plan: function() {
        var a = this;
        t.planlist({
            uid: wx.getStorageSync("uid"),
            op: "plan"
        }).then(function(t) {
            if (console.log(t, "999"), t) {
                a.setData({
                    show: !0,
                    planlist: t.data,
                    content: JSON.parse(t.data.plan.content),
                    value: t.data.plan.value,
                    total: (t.data.done / t.data.plan.total_num * 100).toFixed(2),
                    today_num: (t.data.done_num / JSON.parse(t.data.plan.content).day_list[a.data.value] * 100).toFixed(2)
                });
                var n = a.data.planlist.done_num / a.data.content.day_list[a.data.value] * 100;
                a.setData({
                    today_num: n.toFixed(1)
                });
            } else a.setData({
                show: !1
            });
            console.log(t);
        }).catch(function(t) {
            a.setData({
                show: !1
            }), console.log(t);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareTimeline: function() {
        return {
            title: "红果研名师名题"
        };
    },
    onShareAppMessage: function() {}
});