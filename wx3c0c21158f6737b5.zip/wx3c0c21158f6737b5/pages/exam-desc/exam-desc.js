var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        userinfo: "",
        info: {
            total_score: 100,
            pass_score: 60,
            paper_time: 90,
            highest: 0
        }
    },
    onLoad: function(t) {
        wx.getStorageSync("uid") ? (t = wx.getStorageSync("userinfo"), this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            userinfo: t
        }), this.preExamInfo()) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goExam: function(e) {
        console.log(e), t.globalData.item = e.currentTarget.dataset.item, wx.navigateTo({
            url: "../exam/exam?exam_type=" + e.currentTarget.id
        });
    },
    goSimulate: function(e) {
        t.globalData.item = e.currentTarget.dataset.item, wx.navigateTo({
            url: "/pages/type-lx/type-lx?type=" + e.currentTarget.id
        });
    },
    onShow: function() {
        this.preExamInfo();
    },
    gozt: function(e) {
        t.globalData.item = e.currentTarget.dataset.item, wx.navigateTo({
            url: "/pages/type-lx/type-lx?type=" + e.currentTarget.id
        });
    },
    preExamInfo: function() {
        var t = this;
        e.preExamInfo({
            uid: wx.getStorageSync("uid")
        }).then(function(e) {
            e.data.highest || (e.data.highest = 0), t.setData({
                info: e.data
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShareAppMessage: function() {}
});