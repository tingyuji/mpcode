var t = getApp(), o = require("../../provider/dataApi.js"), e = require("../../provider/pipe.js"), n = require("../../wxParse/wxParse.js");

Page({
    data: {
        uid: "",
        statusBarHeight: "",
        titleBarHeight: "",
        wxshow: !1,
        userinfo: {},
        shareBtn: "",
        isshare: "",
        phone: "",
        isloading: !0,
        systemInfo: "",
        canIUseGetUserProfile: !1
    },
    onLoad: function(t) {
        wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        });
        var o = this;
        wx.login({
            success: function(t) {
                var e = t.code;
                o.setData({
                    code: e
                });
            }
        }), this.getSystemInfo(), this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), console.log(t), t.parentId && this.btnShare(t.parentId);
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(o) {
                console.log(o.platform), "devtools" == o.platform ? t.setData({
                    systemInfo: "PC"
                }) : "ios" == o.platform ? t.setData({
                    systemInfo: "IOS"
                }) : "android" == o.platform && t.setData({
                    systemInfo: "android"
                });
            }
        });
    },
    goLogin: function() {
        wx.showModal({
            title: "需先手机绑定",
            content: "需要绑定手机才能进行下一步操作,点击手机绑定去绑定",
            showCancel: !0,
            confirmText: "确定"
        });
    },
    goVip: function() {
        "IOS" != this.data.systemInfo ? wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "../vip/vip"
        }) : this.goLogin() : wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.showToast({
            title: "ios暂不支持",
            icon: "none",
            duration: 2e3
        }) : this.goLogin();
    },
    getCode: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : this.setData({
            activationShow: !0
        }) : this.goLogin();
    },
    onClose: function() {
        this.setData({
            activationShow: !1
        });
    },
    onChange: function(t) {
        this.setData({
            setCDKey: t.detail
        });
    },
    confirm: function() {
        this.data.setCDKey ? (wx.showLoading({
            title: "激活中"
        }), o.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(t) {
            console.log(t), wx.hideLoading(), wx.showModal({
                title: "提示",
                content: "您已成功激活小程序，快去刷题吧！",
                success: function(t) {
                    t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
                }
            });
        }).catch(function(t) {
            wx.hideLoading(), console.log(t), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        })) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    goMyExam: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "/pages/myExam/myExam"
        }) : this.goLogin();
    },
    goMyNotes: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : (t.globalData.op = "goMyNotes", 
        wx.navigateTo({
            url: "/pages/mynote/index"
        })) : this.goLogin();
    },
    goMedal: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "../my-medal/my-medal"
        }) : this.goLogin();
    },
    goInfo: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "../my-info/my-info"
        }) : this.goLogin();
    },
    goIntegralmall: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "../integral-mall/integral-mall"
        }) : this.goLogin();
    },
    setting: function() {
        wx.getStorageSync("uid") ? 0 == this.data.userinfo.is_bind ? this.bindWechat() : wx.navigateTo({
            url: "../setting/setting"
        }) : this.goLogin();
    },
    goAbout: function() {
        this.setData({
            wxshow: !0
        });
    },
    confirmwx: function(t) {
        console.log(t.detail);
    },
    onClosewx: function() {
        this.setData({
            close: !1
        });
    },
    gosafeset: function() {
        wx.navigateTo({
            url: "../bindWechat/bindWechat"
        });
    },
    goSignout: function() {
        wx.showModal({
            title: "登出提示",
            content: "点击确定后将清空所有缓存,并退出到登录页,确定登出吗?",
            showCancel: !0,
            confirmText: "确定",
            success: function(t) {
                console.log(t), t.confirm && (wx.clearStorage(), wx.reLaunch({
                    url: "../home/home"
                }));
            }
        });
    },
    bindWechat: function() {
        wx.showModal({
            title: "绑定微信",
            content: "需要绑定微信才能进行下一步操作,点击确定去绑定",
            showCancel: !0,
            confirmText: "确定",
            success: function(t) {
                console.log(t), t.confirm && wx.navigateTo({
                    url: "../bindWechat/bindWechat"
                });
            }
        });
    },
    onShow: function() {
        this.setData({
            uid: wx.getStorageSync("uid")
        }), this.getinfo(), this.aboutus();
    },
    btnShare: function(t) {
        o.share({
            uid: t
        }).then(function(t) {
            console.log(t);
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShareAppMessage: function(t) {
        return console.log(t), {
            title: "分享有礼",
            path: "/pages/mine/mine?parentId=" + this.data.uid
        };
    },
    getinfo: function() {
        var t = this;
        o.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(o) {
            console.log(o), wx.setStorageSync("userinfo", o.data.info), wx.setStorageSync("http", o.data.http), 
            t.setData({
                userinfo: o.data.info,
                phone: o.data.info.phone,
                isloading: !1
            });
        }).catch(function(o) {
            console.log(o), t.setData({
                isloading: !1
            });
        });
    },
    getUserInfo: function() {
        console.log(this.data.code);
        var t = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.getUserInfo({
            success: function(e) {
                console.log(e), o.login({
                    code: t.data.code,
                    is_bind: 2,
                    encryptedData: e.encryptedData,
                    iv: e.iv
                }).then(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    }), 0 == t.errno && (wx.setStorageSync("uid", t.data.uid), wx.reLaunch({
                        url: "/pages/mine/mine"
                    }));
                }).catch(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    getUserProfile: function() {
        var t = this;
        wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(e) {
                console.log(e), o.login({
                    code: t.data.code,
                    is_bind: 2,
                    encryptedData: e.encryptedData,
                    iv: e.iv
                }).then(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    }), 0 == t.errno && (wx.setStorageSync("uid", t.data.uid), wx.reLaunch({
                        url: "/pages/mine/mine"
                    }));
                }).catch(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    getPhoneNumber: function(t) {
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.login({
            success: function(e) {
                "getPhoneNumber:ok" == t.detail.errMsg ? o.userinfo({
                    encryptedData: t.detail.encryptedData,
                    iv: t.detail.iv,
                    op: "jmPhone",
                    code: e.code
                }).then(function(t) {
                    console.log(t.data.phone), wx.showToast({
                        title: t.message,
                        icon: "none"
                    }), 0 == t.errno && (wx.setStorageSync("uid", t.data.uid), wx.reLaunch({
                        url: "/pages/mine/mine"
                    }));
                }).catch(function(t) {
                    console.log(t), wx.showToast({
                        title: t.message,
                        icon: "none"
                    });
                }) : (wx.hideLoading && wx.hideLoading(), wx.showToast({
                    title: "您拒绝了授权",
                    icon: "none",
                    duration: 2e3
                }));
            }
        });
    },
    aboutus: function() {
        var t = this;
        o.aboutus({}).then(function(o) {
            console.log(o), null != o.data.about && (o.data.about = e.strcharacterDiscode(o.data.about).replace(/\<img/gi, '<img style="max-width:100px!important;height:auto"'), 
            n.wxParse("article", "html", o.data.about, t, 5));
        }).catch(function(t) {
            console.log(t);
        });
    }
});