var t = {
    scope: {}
};

t.defineProperty = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, a) {
    if (a.get || a.set) throw new TypeError("ES3 does not support getters and setters.");
    t != Array.prototype && t != Object.prototype && (t[e] = a.value);
}, t.getGlobal = function(t) {
    return "undefined" != typeof window && window === t ? t : "undefined" != typeof global ? global : t;
}, t.global = t.getGlobal(void 0), t.SYMBOL_PREFIX = "jscomp_symbol_", t.initSymbol = function() {
    t.initSymbol = function() {}, t.global.Symbol || (t.global.Symbol = t.Symbol);
}, t.symbolCounter_ = 0, t.Symbol = function(e) {
    return t.SYMBOL_PREFIX + (e || "") + t.symbolCounter_++;
}, t.initSymbolIterator = function() {
    t.initSymbol();
    var e = t.global.Symbol.iterator;
    e || (e = t.global.Symbol.iterator = t.global.Symbol("iterator")), "function" != typeof Array.prototype[e] && t.defineProperty(Array.prototype, e, {
        configurable: !0,
        writable: !0,
        value: function() {
            return t.arrayIterator(this);
        }
    }), t.initSymbolIterator = function() {};
}, t.arrayIterator = function(e) {
    var a = 0;
    return t.iteratorPrototype(function() {
        return a < e.length ? {
            done: !1,
            value: e[a++]
        } : {
            done: !0
        };
    });
}, t.iteratorPrototype = function(e) {
    return t.initSymbolIterator(), (e = {
        next: e
    })[t.global.Symbol.iterator] = function() {
        return this;
    }, e;
}, t.makeIterator = function(e) {
    t.initSymbolIterator();
    var a = e[Symbol.iterator];
    return a ? a.call(e) : t.arrayIterator(e);
}, t.arrayFromIterator = function(t) {
    for (var e, a = []; !(e = t.next()).done; ) a.push(e.value);
    return a;
}, t.arrayFromIterable = function(e) {
    return e instanceof Array ? e : t.arrayFromIterator(t.makeIterator(e));
};

var e = getApp(), a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        title: "题型练习",
        statusBarHeight: "",
        titleBarHeight: "",
        list: [],
        isloading: !0,
        params: "",
        isShowTest: !1,
        showPay: !1,
        item: {},
        page: 1,
        type: "",
        totalPage: "",
        isData: !0,
        isSon: 2,
        systemInfo: "",
        sureshow: !1
    },
    onLoad: function(t) {
        if (1 == t.type) var a = "全真模拟试卷列表"; else if (2 == t.type) a = "历年真题试卷列表";
        wx.getStorageSync("uid") ? (this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            title: e.globalData.title
        }), "{}" !== JSON.stringify(t) && this.setData({
            params: t,
            title: a,
            type: t.type,
            isShowTest: !0
        }), this.data.isShowTest || this.getSequence()) : wx.reLaunch({
            url: "/pages/mine/mine"
        }), this.getSystemInfo();
    },
    bindKeyInput: function(t) {
        console.log(t.detail.value, "查看激活码"), this.setData({
            sureshow: !0,
            setCDKey: t.detail.value
        });
    },
    onConfirm: function() {
        var t = this;
        this.data.setCDKey ? a.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(e) {
            wx.showModal({
                title: "提示",
                content: "您已激活成功，请不要重复输入激活码呦~",
                success: function(e) {
                    e.confirm ? (t.setData({
                        showPay: !1
                    }), t.getExamList(1)) : e.cancel && console.log("用户点击取消");
                }
            });
        }).catch(function(t) {
            console.log(t), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        }) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                "devtools" == e.platform ? t.setData({
                    systemInfo: "PC"
                }) : "ios" == e.platform ? t.setData({
                    systemInfo: "IOS"
                }) : "android" == e.platform && t.setData({
                    systemInfo: "android"
                });
            }
        });
    },
    getSequence: function() {
        var t = this;
        a.sequence({
            uid: wx.getStorageSync("uid"),
            op: "getalltypes"
        }).then(function(e) {
            console.log(e), e.data.type_list && t.setData({
                list: e.data.type_list,
                isSon: e.data.son,
                isloading: !1
            }), wx.stopPullDownRefresh();
        }).catch(function(t) {
            console.log(t);
        });
    },
    getExamList: function(e) {
        var o = this;
        console.log(this.data.type), a.getExamList({
            uid: wx.getStorageSync("uid"),
            type: this.data.type,
            page: e
        }).then(function(e) {
            if (console.log(e), e.data.list) {
                var a, i = !1;
                0 < (a = [].concat(t.arrayFromIterable(o.data.list), t.arrayFromIterable(e.data.list))).length && (i = !0), 
                o.setData({
                    list: a,
                    totalPage: Math.ceil(e.data.total / e.data.psize),
                    isData: i,
                    isloading: !1
                });
            }
            wx.stopPullDownRefresh();
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goLx: function(t) {
        if (this.data.params) {
            if (1 == this.data.type) var a = 1; else if (2 == this.data.type) a = "zt";
            var o = t.currentTarget.dataset.item;
            console.log(o, "查看item"), 1 != o.is_repeat && 0 < o.do_number ? wx.showToast({
                title: "不可重复答题",
                icon: "none"
            }) : wx.navigateTo({
                url: "../exam-before-see/exam-before-see?exam_type=" + a + "&paperid=" + t.currentTarget.id
            });
        } else 1 == this.data.isSon ? 8 != (t = t.currentTarget.id) ? (e.globalData.op = "qtype", 
        e.globalData.id = t, wx.navigateTo({
            url: "../practice/practice"
        })) : wx.navigateTo({
            url: "/pages/shortAnswerList/shortAnswerList"
        }) : (t = t.currentTarget.id, e.globalData.op = "qtype", e.globalData.id = t, wx.navigateTo({
            url: "../practice/practice"
        }));
    },
    gojx: function(t) {
        console.log(t, "查看id");
        var a = t.currentTarget.dataset.id;
        e.globalData.op = "see", e.globalData.paperId = a, wx.navigateTo({
            url: "/pages/resolution/practice"
        });
    },
    goPayPopup: function(t) {
        1 != (t = t.currentTarget.dataset.item).is_repeat && 0 < t.do_number ? wx.showToast({
            title: "本套试卷暂不可购买",
            icon: "none"
        }) : this.setData({
            item: t,
            showPay: !0
        });
    },
    getUserInfo: function() {
        var t = this;
        a.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(e) {
            console.log(e), t.setData({
                userInfo: e.data.info
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        this.data.isShowTest && (this.setData({
            page: 1,
            list: []
        }), this.getUserInfo(), this.getExamList(1));
    },
    closePayPopup: function() {
        this.setData({
            showPay: !1
        });
    },
    goPayBtn: function() {
        this.requestPayment();
    },
    requestPayment: function() {
        var t = this;
        a.wxPay({
            uid: wx.getStorageSync("uid"),
            id: this.data.item.id,
            type: "4"
        }).then(function(e) {
            console.log(e), wx.requestPayment({
                timeStamp: String(e.data.timeStamp),
                nonceStr: e.data.nonceStr,
                package: e.data.package,
                signType: e.data.signType,
                paySign: e.data.paySign,
                success: function(e) {
                    console.log(e), wx.showToast({
                        icon: "success",
                        title: "支付成功"
                    }), t.setData({
                        showPay: !1
                    }), t.getExamList(1);
                },
                fail: function(e) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    }), t.setData({
                        showPay: !1
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goVipBtn: function() {
        wx.navigateTo({
            url: "../vip/vip"
        });
    },
    onPullDownRefresh: function() {
        this.data.isShowTest ? (this.setData({
            page: 1,
            list: [],
            isloading: !0
        }), this.getExamList(1)) : this.getSequence();
    },
    onReachBottom: function() {
        var t = parseInt(this.data.totalPage), e = parseInt(this.data.page);
        e < t && (this.setData({
            page: e + 1
        }), this.getExamList(this.data.page));
    },
    onShareAppMessage: function() {}
});