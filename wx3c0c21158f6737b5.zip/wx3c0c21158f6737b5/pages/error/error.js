var t = getApp(), a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        typelist: [],
        total: 0,
        day_have_err: 2,
        all_have_err: 2,
        group: {},
        currentid: 0
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            windowHeight: wx.getSystemInfoSync().windowHeight
        });
    },
    swichNav: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            currentid: a
        }), console.log(a, "查看cur");
    },
    group: function(a) {
        console.log(a);
        for (var e = a.currentTarget.dataset.item, i = [], n = 0; n < e.length; n++) i.push(e[n].id);
        wx.getStorageSync("uid") ? 0 == this.data.isBind ? this.bindWechat() : (t.globalData.op = "err_group", 
        t.globalData.id = a.currentTarget.id, t.globalData.groupid = i, wx.navigateTo({
            url: "../practice/practice"
        })) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goToday: function() {
        t.globalData.op = "todayerr_question", wx.getStorageSync("uid") ? 0 == this.data.isBind ? this.bindWechat() : 2 == this.data.day_have_err ? wx.showToast({
            icon: "none",
            title: "今日无错题~"
        }) : wx.navigateTo({
            url: "../practice/practice"
        }) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goAll: function() {
        t.globalData.op = "allerr_question", wx.getStorageSync("uid") ? 0 == this.data.isBind ? this.bindWechat() : 2 == this.data.all_have_err ? wx.showToast({
            icon: "none",
            title: "暂无错题~"
        }) : wx.navigateTo({
            url: "../practice/practice"
        }) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goType: function(a) {
        wx.getStorageSync("uid") ? 0 == this.data.isBind ? this.bindWechat() : (t.globalData.op = "geterr_bytype", 
        t.globalData.id = a.currentTarget.id, wx.navigateTo({
            url: "../practice/practice"
        })) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    gotype: function() {
        wx.navigateTo({
            url: "/pages/errtype/errtype"
        });
    },
    bindWechat: function() {
        wx.showModal({
            title: "绑定微信",
            content: "需要绑定微信才能进行下一步操作,点击确定去绑定",
            showCancel: !0,
            confirmText: "确定",
            success: function(t) {
                console.log(t), t.confirm && wx.navigateTo({
                    url: "../bindWechat/bindWechat"
                });
            }
        });
    },
    onShow: function() {
        this.getuserinfo(), this.myerrList();
    },
    getuserinfo: function() {
        var t = this;
        a.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(a) {
            console.log(a);
            var e = a.data.info.is_bind;
            wx.setStorageSync("userinfo", a.data.info), wx.setStorageSync("http", a.data.http), 
            t.setData({
                isBind: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    myerrList: function() {
        var t = this;
        a.myerrList({
            uid: wx.getStorageSync("uid")
        }).then(function(a) {
            var e = {};
            if (a.data.group) e = a.data.group;
            t.setData({
                total: a.data.total,
                typelist: a.data.typelist,
                day_have_err: a.data.day_have_err,
                all_have_err: a.data.all_have_err,
                group: e
            }), console.log(a.data.total, t.data.group, "查看是否更新");
        }).catch(function(t) {
            console.log(t);
        });
    },
    handleCategoryChange: function(t) {
        console.log(t), this.setData({
            currentid: t.detail.current
        }), this.checkCor();
    },
    checkCor: function() {
        this.data.currentid >= 3 ? this.setData({
            scrollLeft: 300
        }) : this.setData({
            scrollLeft: 0
        });
    },
    onShareAppMessage: function() {}
});