getApp();

var a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        userinfo: "",
        info: {},
        num: 0,
        isloading: !0
    },
    onLoad: function(a) {
        wx.getStorageSync("uid") ? (this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), a = wx.getStorageSync("userinfo"), this.setData({
            userinfo: a
        }), this.medal()) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    medal: function() {
        var t = this;
        a.medal({
            uid: wx.getStorageSync("uid")
        }).then(function(a) {
            if (console.log(a), a.data) {
                var e, i = 0;
                for (e in a.data) 1 == a.data[e].have && i++;
                t.setData({
                    info: a.data,
                    num: i,
                    isloading: !1
                });
            }
        }).catch(function(a) {
            console.log(a);
        });
    },
    onShareAppMessage: function() {}
});