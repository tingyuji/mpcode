var a = getApp(), t = require("../../provider/dataApi.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        handpapershow: !1,
        resuser: {},
        userinfo: {},
        paperId: "",
        params: {},
        isloading: !0,
        isShowBtn: !0,
        type: "",
        scores: ""
    },
    onLoad: function(t) {
        if (console.log(t, "查看结果参数"), wx.getStorageSync("uid")) {
            var e = wx.getStorageSync("userinfo");
            this.setData({
                statusBarHeight: getApp().globalData.statusBarHeight,
                titleBarHeight: getApp().globalData.titleBarHeight,
                userinfo: e,
                params: t
            }), console.log(t), "" != t.paperid && this.setData({
                paperId: t.paperid
            }), 1 == t.type && this.setData({
                resuser: a.globalData.resuser,
                isloading: !1,
                type: t.type
            }), 5 == t.type && this.setData({
                resuser: a.globalData.resuser,
                isloading: !1,
                type: t.type
            }), 3 == t.type && this.setData({
                resuser: a.globalData.resuser,
                isloading: !1,
                type: t.type
            }), 2 == t.type && (this.setData({
                resuser: a.globalData.resuser,
                isloading: !1,
                type: t.type
            }), this.getexamResult());
        } else wx.reLaunch({
            url: "/pages/mine/mine"
        });
        "result" == t.param && this.setData({
            type: 1
        });
    },
    onShow: function() {
        this.tika();
    },
    tika: function() {
        var a = this, e = this.data.params;
        t.myTika({
            uid: wx.getStorageSync("uid"),
            paperid: e.paperid,
            id: e.id
        }).then(function(t) {
            console.log(t, "查看结果"), a.setData({
                tika: t.data.tika
            });
        }).catch(function(a) {
            console.log(a);
        });
    },
    getexamResult: function() {
        var a = this, e = this.data.params;
        t.myTestExplain({
            uid: wx.getStorageSync("uid"),
            paperid: e.paperid,
            id: e.id
        }).then(function(t) {
            console.log(t, "查看结果"), a.setData({
                resuser: t.data.resuser,
                scores: "scores",
                isloading: !1
            });
        }).catch(function(t) {
            console.log(t), a.setData({
                isloading: !1
            });
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    seeError: function() {
        console.log(this.data.params.id);
        var t = this.data.resuser;
        1 == t.is_simple && 2 == t.complete ? this.showTip("试卷中包含主观题，请耐心等待评卷") : (a.globalData.op = "seeErr", 
        a.globalData.paperId = this.data.paperId, a.globalData.recordid = this.data.params.id, 
        wx.navigateTo({
            url: "/pages/resolution/practice"
        }));
    },
    see: function() {
        console.log(this.data.params.id);
        var t = this.data.resuser;
        1 == t.is_simple && 2 == t.complete ? this.showTip("试卷中包含主观题，请耐心等待评卷") : (a.globalData.op = "see", 
        a.globalData.paperId = this.data.paperId, a.globalData.recordid = this.data.params.id, 
        wx.navigateTo({
            url: "/pages/resolution/practice"
        }));
    },
    test_one: function(t) {
        console.log(t);
        var e = t.currentTarget.dataset.index;
        a.globalData.op = "see", a.globalData.paperId = this.data.paperId, a.globalData.recordid = this.data.params.id, 
        wx.navigateTo({
            url: "/pages/resolution/practice?testindex=" + e
        });
    },
    backIndex: function() {
        wx.reLaunch({
            url: "/pages/home/home"
        });
    },
    showTip: function(a) {
        wx.showModal({
            title: "提示",
            content: a,
            showCancel: !1,
            confirmText: "关闭",
            success: function(a) {
                console.log(a);
            }
        });
    },
    onShareAppMessage: function() {}
});