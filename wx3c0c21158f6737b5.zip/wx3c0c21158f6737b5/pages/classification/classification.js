var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        windowHeight: 0,
        knowledgeList: [],
        knowledgeIndex: 0,
        pay_open: "",
        title: "",
        total_num: "0",
        item: {},
        isloading: !0,
        isBool: !0,
        show: !1,
        qrecord: {},
        activationShow: !1,
        setCDKey: "",
        fItem: {},
        systemInfo: "",
        doneid: {},
        qseenid: {},
        userInfo: {},
        sureshow: !1,
        currentid: 0,
        scrollLeft: 0
    },
    getCode: function() {
        this.setData({
            show: !1,
            activationShow: !0
        });
    },
    bindKeyInput: function(t) {
        console.log(t.detail.value, "查看激活码"), this.setData({
            sureshow: !0,
            setCDKey: t.detail.value
        });
    },
    swichNav: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            currentid: e
        }), console.log(e, "查看cur");
    },
    handleCategoryChange: function(t) {
        console.log(t), this.setData({
            currentid: t.detail.current
        }), this.checkCor();
    },
    checkCor: function() {
        this.data.currentid >= 3 ? this.setData({
            scrollLeft: 300
        }) : this.setData({
            scrollLeft: 0
        });
    },
    onConfirm: function() {
        var t = this;
        this.data.setCDKey ? e.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(e) {
            console.log(e), wx.showModal({
                title: "提示",
                content: "您已激活成功，请不要重复输入激活码呦~",
                success: function(e) {
                    e.confirm ? (t.setData({
                        show: !1
                    }), t.getSequence()) : e.cancel && console.log("用户点击取消");
                }
            });
        }).catch(function(t) {
            console.log(t), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        }) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    onClose: function() {
        this.setData({
            activationShow: !1
        });
    },
    onChange: function(t) {
        this.setData({
            setCDKey: t.detail
        });
    },
    onLoad: function(e) {
        wx.getStorageSync("uid") ? (e = wx.getSystemInfoSync().windowHeight, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            windowHeight: e,
            title: t.globalData.title
        })) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.switchTab({
            url: "../home/home"
        });
    },
    onReady: function() {},
    knowledge: function() {
        var a = this;
        e.knowledge({
            op: "cate",
            type: t.globalData.type,
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t), a.setData({
                knowledgeList: t.data.list,
                pay_open: t.data.pay_open
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    ltChoose: function(t) {
        this.setData({
            knowledgeIndex: t.currentTarget.dataset.i
        });
    },
    rtChoose: function(e) {
        var a = e.currentTarget.dataset.chapterid, o = e.currentTarget.dataset.fitem, n = (e.currentTarget.dataset.oitem.id, 
        this.data.qrecord);
        void 0 === n[e.currentTarget.dataset.oitem.id] && (n[e.currentTarget.dataset.oitem.id] = [ e.currentTarget.dataset.oitem.id ]), 
        this.setData({
            qrecord: n
        }), wx.setStorageSync("qrecord", this.data.qrecord), console.log(e), (e = e.currentTarget.dataset.oitem).chapterId = a, 
        this.setData({
            total_num: e.total_num,
            item: e,
            fItem: o
        }), 1 == this.data.userInfo.ismember ? 0 == o.is_can && 0 != o.vip_price ? this.setData({
            show: !0
        }) : (t.globalData.id = e.id, t.globalData.classType = t.globalData.classType, wx.navigateTo({
            url: "../practice/practice"
        })) : 1 != o.is_can ? this.setData({
            show: !0
        }) : (t.globalData.id = e.id, t.globalData.classType = t.globalData.classType, wx.navigateTo({
            url: "../practice/practice"
        }));
    },
    onShow: function() {
        this.getUserInfo(), this.getSequence(), this.getSystemInfo(), this.testRecord1();
    },
    testRecord1: function() {
        var t = this;
        e.testRecord1({
            uid: wx.getStorageSync("uid")
        }).then(function(e) {
            console.log(e, "testreocrd1"), t.setData({
                lx_record_arr: e.data
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    testRecord: function() {
        var t = this;
        e.testRecord({
            uid: wx.getStorageSync("uid")
        }).then(function(e) {
            var a = JSON.parse(e.data.testid);
            t.setData({
                qseenid: a
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getSequence: function() {
        var a = this;
        t.globalData.op = "special", e.sequence({
            uid: wx.getStorageSync("uid"),
            is_student: Number(t.globalData.is_student),
            class_type: t.globalData.classType,
            op: "getallspecial"
        }).then(function(t) {
            var e = !1;
            0 < t.data.list.length && (e = !0), a.setData({
                knowledgeList: t.data.list,
                isloading: !1,
                pay_open: t.data.pay_open,
                freenum: t.data.freenum,
                isBool: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onHide: function() {},
    tryAnswer: function(e) {
        console.log(e), e = e.currentTarget.dataset.num, t.globalData.id = this.data.item.id, 
        t.globalData.classType = t.globalData.classType, wx.navigateTo({
            url: "../practice/practice?num=" + e
        });
    },
    getUserInfo: function() {
        var t = this;
        e.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(e) {
            console.log(e), t.setData({
                userInfo: e.data.info
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    closePayPopup: function() {
        this.setData({
            show: !1
        });
    },
    goVipBtn: function() {
        wx.navigateTo({
            url: "../vip/vip"
        }), this.setData({
            show: !1
        });
    },
    goPay: function() {
        var t = this;
        console.log(this.data.item.chapterId, "查看支付"), e.wxPay({
            uid: wx.getStorageSync("uid"),
            id: this.data.item.chapterId,
            type: "1"
        }).then(function(e) {
            console.log(e), wx.requestPayment({
                timeStamp: String(e.data.timeStamp),
                nonceStr: e.data.nonceStr,
                package: e.data.package,
                signType: e.data.signType,
                paySign: e.data.paySign,
                success: function(e) {
                    wx.showToast({
                        icon: "success",
                        title: "支付成功"
                    }), t.setData({
                        show: !1
                    }), t.update();
                },
                fail: function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    update: function() {
        var t = this;
        console.log(this.data.item.chapterId, "查看支付"), e.userinfo({
            uid: wx.getStorageSync("uid"),
            id: this.data.item.chapterId,
            op: "updatepool"
        }).then(function(e) {
            console.log(e), t.getSequence();
        }).catch(function(t) {
            console.log(t);
        });
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                console.log(e.platform, "型号"), "devtools" == e.platform ? t.setData({
                    systemInfo: "PC"
                }) : "ios" == e.platform ? t.setData({
                    systemInfo: "IOS"
                }) : "android" == e.platform && t.setData({
                    systemInfo: "android"
                });
            }
        });
    },
    onUnload: function() {
        wx.switchTab({
            url: "../home/home"
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});