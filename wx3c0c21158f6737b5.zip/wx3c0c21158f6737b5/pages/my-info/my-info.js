var e;

function t(e, t, o) {
    return t in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e;
}

var o = getApp(), n = require("../../provider/dataApi.js"), a = (require("../../provider/pipe.js"), 
require("../../we7/resource/js/util.js"));

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        if_checked: !1,
        isSetShow: !1,
        show: !1,
        phone: "",
        sex: 1,
        userinfo: (e = {
            name: "",
            id_card: "",
            student_name: "",
            sex: ""
        }, t(e, "id_card", ""), t(e, "school", ""), t(e, "phone", ""), t(e, "grade", ""), 
        t(e, "sex", ""), e),
        studentInfo: "",
        code: "",
        iscode: !1,
        codetxt: "获取验证码",
        newPhone: ""
    },
    onLoad: function(e) {
        wx.getStorageSync("uid") ? this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    boxcheck: function(e) {
        var t = e.detail.value[0];
        t = void 0 !== t, this.setData({
            if_checked: t
        });
    },
    goAgreement: function(e) {
        1 == e.currentTarget.dataset.type ? wx.navigateTo({
            url: "/promotion/agreement/agreement"
        }) : wx.navigateTo({
            url: "/promotion/privacy/privacy"
        });
    },
    editHeadimgBtn: function() {
        var e = this, t = a.url("entry/wxapp/uploadImage", {
            m: "goouc_fullexam"
        });
        wx.showActionSheet({
            itemList: [ "拍照", "从手机相册选择" ],
            success: function(o) {
                "0" == o.tapIndex ? wx.chooseImage({
                    count: 1,
                    sizeType: [ "original", "compressed" ],
                    sourceType: [ "camera" ],
                    success: function(o) {
                        wx.showToast({
                            title: "正在上传...",
                            icon: "loading",
                            mask: !0,
                            duration: 1e4
                        }), wx.uploadFile({
                            url: t,
                            filePath: o.tempFilePaths[0],
                            name: "upfile",
                            formData: {},
                            success: function(t) {
                                console.log(t);
                                var o = {};
                                e.setData((o["userinfo.headimg"] = t.data, o)), wx.hideToast();
                            },
                            fail: function(e) {
                                wx.hideToast(), console.log(e);
                            }
                        });
                    }
                }) : wx.chooseImage({
                    count: 1,
                    sizeType: [ "original", "compressed" ],
                    sourceType: [ "album" ],
                    success: function(o) {
                        console.log(o), wx.showToast({
                            title: "正在上传...",
                            icon: "loading",
                            mask: !0,
                            duration: 1e4
                        }), wx.uploadFile({
                            url: t,
                            filePath: o.tempFilePaths[0],
                            name: "upfile",
                            formData: {},
                            success: function(t) {
                                console.log(t);
                                var o = t.data;
                                n.updateHeadimg({
                                    uid: wx.getStorageSync("uid"),
                                    headimg: o
                                }).then(function(t) {
                                    t = {}, e.setData((t["userinfo.headimg"] = o, t)), wx.hideToast();
                                }).catch(function(e) {
                                    console.lgo(e);
                                });
                            },
                            fail: function(e) {
                                wx.hideToast(), console.log(e);
                            }
                        });
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                });
            }
        });
    },
    inputblur: function() {
        this.getUserInfo(this.data.userinfo.name, this.data.userinfo.phone, this.data.userinfo.sex);
    },
    getPhoneNumber: function(e) {
        var t = this;
        wx.login({
            success: function(o) {
                "getPhoneNumber:ok" == e.detail.errMsg ? n.userinfo({
                    encryptedData: e.detail.encryptedData,
                    iv: e.detail.iv,
                    op: "jmPhone",
                    code: o.code
                }).then(function(e) {
                    t.setData({
                        phone: e.data.phone
                    }), console.log(e.data.phone), wx.showToast({
                        title: e.message,
                        icon: "none"
                    }), 0 == e.errno && wx.setStorageSync("uid", e.data.uid);
                }).catch(function(e) {
                    console.log(e), wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                }) : wx.showToast({
                    title: "您拒绝了授权",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    getUserInfo: function(e, t) {
        var o = this;
        "" != e && null != e && "" != t && null != t && null != t && n.userinfo({
            phone: t,
            name: e,
            op: "checkStudent"
        }).then(function(e) {
            if ("" !== (e = e.data.list).length) {
                var t = {};
                o.setData((t.isSetShow = !0, t.studentInfo = e, t["userinfo.student_name"] = e.student_name, 
                t.sex = e.sex, t["userinfo.school"] = e.school_name, t["userinfo.grade"] = e.banji_name, 
                t["userinfo.sex"] = e.sex, t));
            }
        }).catch(function(e) {
            console.log(e);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goBind: function() {
        this.setData({
            show: !0
        });
    },
    confirm: function(e) {
        var t = this;
        console.log(e.detail), console.log(t.data.userinfo.phone), null == t.data.newPhone || t.data.newPhone.length < 11 ? (console.log(11), 
        wx.showToast({
            icon: "none",
            title: "请输入正确的手机号"
        })) : n.userinfo({
            phone: t.data.newPhone,
            code: t.data.code,
            uid: wx.getStorageSync("uid"),
            op: "checkcode"
        }).then(function(e) {
            t.goSave(!1), wx.showToast({
                icon: "none",
                title: "绑定成功"
            }), t.getUserInfo(t.data.userinfo.name, t.data.newPhone), t.setData({
                iscode: !0,
                phone: t.data.newPhone
            });
        }).catch(function(e) {
            console.log(e), t.setData({
                iscode: !0
            }), wx.showToast({
                icon: "none",
                title: e.message
            });
        });
    },
    onClose: function() {
        this.setData({
            close: !1
        });
    },
    onShow: function() {
        var e = wx.getStorageSync("userinfo");
        e && (this.setData({
            userinfo: e
        }), null != e.phone && "" != e.phone && "null" != e.phone && this.setData({
            phone: e.phone
        })), 1 == e.stu_have && this.setData({
            isSetShow: !0
        }), console.log(e), this.getUserInfo(this.data.userinfo.name, this.data.userinfo.phone);
    },
    getName: function(e) {
        var t = {};
        this.setData((t["userinfo.name"] = e.detail.value, t));
    },
    getSex: function(e) {
        var t = 1;
        "女" == e.detail.value && (t = 2), this.setData({
            sex: t
        });
    },
    getXh: function(e) {
        var t = {};
        this.setData((t["userinfo.student_name"] = e.detail.value, t));
    },
    getIdcard: function(e) {
        var t = {};
        this.setData((t["userinfo.id_card"] = e.detail.value, t));
    },
    getSchool: function(e) {
        var t = {};
        this.setData((t["userinfo.school"] = e.detail.value, t));
    },
    getClass: function(e) {
        var t = {};
        this.setData((t["userinfo.grade"] = e.detail.value, t));
    },
    getPhone: function(e) {
        this.setData({
            newPhone: e.detail.value
        });
    },
    getCode: function(e) {
        this.setData({
            code: e.detail.value
        });
    },
    sendCode: function() {
        var e = this;
        /^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(this.data.newPhone) ? "获取验证码" == this.data.codetxt || "重新发送" == this.data.codetxt ? n.userinfo({
            phone: this.data.newPhone,
            uid: wx.getStorageSync("uid"),
            op: "getcode"
        }).then(function(t) {
            e.setData({
                codetxt: "60秒"
            });
            var o = 60, n = setInterval(function() {
                o--, e.setData({
                    codetxt: o + "秒"
                }), o <= 0 && (e.setData({
                    codetxt: "重新发送"
                }), clearInterval(n));
            }, 1e3);
        }).catch(function(e) {
            console.log(e), wx.showToast({
                icon: "none",
                title: e.message
            });
        }) : wx.showToast({
            icon: "none",
            title: "请不要重复发送~"
        }) : wx.showToast({
            icon: "none",
            title: "请输入正确的手机号~"
        });
    },
    goToSave: function() {
        this.goSave(!0);
    },
    goSave: function(e) {
        if (null != this.data.if_checked && 0 != this.data.if_checked) {
            var t = this, a = this.data.userinfo;
            e = {};
            t.setData((e["userinfo.sex"] = t.data.sex, e)), "null" == a.name || null == a.name || "" == a.name ? wx.showToast({
                title: "请输入姓名",
                icon: "none"
            }) : ("null" == a.phone && (a.phone = ""), n.userinfo({
                uid: wx.getStorageSync("uid"),
                name: a.name,
                phone: a.phone,
                sex: t.data.sex
            }).then(function(n) {
                console.log(n), 1 == n.data && (wx.showToast({
                    icon: "none",
                    title: "保存成功"
                }), t.updateUserInfo(), e ? (wx.showToast({
                    icon: "none",
                    title: "保存成功"
                }), setTimeout(function() {
                    wx.navigateBack({
                        delta: -1
                    });
                }, 1e3)) : wx.showToast({
                    icon: "none",
                    title: "绑定成功"
                }), console.log(o.globalData.userinfo));
            }).catch(function(o) {
                t.updateUserInfo(), e && wx.showToast({
                    icon: "none",
                    title: "并未有任何改动哦"
                });
            }));
        } else wx.showToast({
            icon: "none",
            title: "请先阅读并同意协议"
        });
    },
    updateUserInfo: function() {
        n.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(e) {
            console.log(e), o.globalData.userinfo = e.data.info;
        }).catch(function(e) {});
    },
    onShareAppMessage: function() {}
});