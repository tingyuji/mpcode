getApp();

var t = require("../../provider/dataApi.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        viewHeight: "",
        params: {},
        info: {}
    },
    onLoad: function(t) {
        console.log(t, "查看传参"), this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            viewHeight: wx.getSystemInfoSync().windowHeight
        }), "{}" != JSON.stringify(t) && this.setData({
            params: t
        }), console.log(this.data.params);
    },
    getExamInfo: function(a) {
        var e = this;
        t.examInfo({
            uid: wx.getStorageSync("uid"),
            paper_id: a
        }).then(function(t) {
            console.log(t), e.setData({
                info: t.data.list
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goExam: function() {
        var t = this.data.info;
        if (2 == t.chuti_type) var a = 5; else a = 1;
        1 != t.is_repeat && 0 < t.do_number ? wx.showToast({
            title: "不可重复答题",
            icon: "none"
        }) : wx.navigateTo({
            url: "../exam/exam?exam_type=" + a + "&paperid=" + this.data.params.paperid + "&time=" + this.data.info.times + "&etype=" + this.data.params.exam_type
        });
    },
    onReady: function() {},
    onShow: function() {
        this.getExamInfo(this.data.params.paperid);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});