var t = require("../../provider/dataApi.js"), e = (require("../../provider/pipe.js"), 
getApp());

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        windowHeight: 0,
        knowledgeList: [],
        knowledgeIndex: 0,
        pay_open: "",
        title: "",
        record: {},
        isBool: !0,
        isloading: !0,
        userInfo: {},
        seenid: {}
    },
    onLoad: function(t) {
        wx.getStorageSync("uid") ? (t = wx.getSystemInfoSync().windowHeight, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            windowHeight: t,
            title: e.globalData.title
        })) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.switchTab({
            url: "../home/home"
        });
    },
    onReady: function() {},
    getUserInfo: function() {
        var e = this;
        t.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(t) {
            console.log(t), e.setData({
                userInfo: t.data.info
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        "" == wx.getStorageSync("record") && wx.setStorageSync("record", {});
        var t = wx.getStorageSync("record");
        this.setData({
            record: t
        });
        var e = wx.getStorageSync("seenid");
        this.setData({
            seenid: e
        }), console.log(wx.getStorageSync("lookid"), "查看数值"), this.getUserInfo(), this.knowledge(), 
        this.knowRecord();
    },
    knowRecord: function() {
        var e = this;
        t.knowRecord({
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            var o = JSON.parse(t.data.testid);
            console.log(o, "成功了吗"), e.setData({
                seenid: o
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    knowSelect: function() {
        t.knowSelect({
            uid: wx.getStorageSync("uid"),
            seenid: JSON.stringify(wx.getStorageSync("seenid")),
            lookid: JSON.stringify(wx.getStorageSync("lookid"))
        }).then(function(t) {
            console.log("成功了吗");
        }).catch(function(t) {
            console.log(t);
        });
    },
    knowledge: function() {
        var o = this;
        t.knowledge({
            op: "newcate",
            type: e.globalData.classType,
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t);
            var e = !1;
            0 < t.data.list.length && (e = !0), o.setData({
                knowledgeList: t.data.list,
                isloading: !1,
                pay_open: t.data.pay_open,
                isBool: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    handleCategoryChange: function(t) {
        console.log(t), this.setData({
            knowledgeIndex: t.detail.current
        });
    },
    ltChoose: function(t) {
        this.setData({
            knowledgeIndex: t.currentTarget.dataset.i
        });
    },
    rtChoose: function(t) {
        var o = t.currentTarget.dataset.chapterid, n = (t.currentTarget.dataset.oitem.id, 
        this.data.record);
        void 0 === n[t.currentTarget.dataset.oitem.id] && (n[t.currentTarget.dataset.oitem.id] = [ t.currentTarget.dataset.oitem.id ], 
        console.log(n, "11111")), console.log(t), t = t.currentTarget.dataset.oitem, this.setData({
            item: t,
            record: n
        }), wx.setStorageSync("record", this.data.record), t.chapterId = o, e.globalData.oItem = t, 
        wx.navigateTo({
            url: "../knowledgePoints-list/knowledgePoints-list"
        });
    },
    closePayPopup: function() {
        this.setData({
            showPay: !1
        });
    },
    onHide: function() {},
    onUnload: function() {
        wx.switchTab({
            url: "../home/home"
        });
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});