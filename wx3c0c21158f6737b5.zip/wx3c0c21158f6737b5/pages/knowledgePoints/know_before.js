var t = getApp();

require("../../provider/dataApi.js"), require("../../provider/pipe.js");

Page({
    data: {},
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goTest: function(a) {
        t.globalData.op = "randoms", t.globalData.classType = a.currentTarget.dataset.classtype, 
        wx.navigateTo({
            url: "../knowledgePoints/knowledgePoints"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});