var t = getApp(), a = require("../../provider/dataApi.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        payText: "立即开通",
        id: "",
        isloading: !0,
        userInfo: {},
        vipList: [],
        isTui: 0,
        systemInfo: "",
        scale: ""
    },
    onLoad: function(a) {
        this.setData({
            statusBarHeight: t.globalData.statusBarHeight,
            titleBarHeight: t.globalData.titleBarHeight
        }), this.getUserInfo();
    },
    getUserInfo: function() {
        var t = this;
        a.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(a) {
            console.log(a);
            var e = "立即开通";
            2 != a.data.info.ismember && (e = "续费会员"), t.setData({
                userInfo: a.data.info,
                payText: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getVipList: function() {
        var t = this, e = this;
        a.member({}).then(function(a) {
            console.log(a), t.setData({
                vipList: a.data.info.info,
                isTui: a.data.info.istui,
                scale: a.data.info.scale,
                id: a.data.info.info[0].id
            }), setTimeout(function() {
                e.setData({
                    isloading: !1
                });
            }, 500);
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goChoose: function(t) {
        this.setData({
            id: t.currentTarget.dataset.item.id
        });
    },
    goPay: function() {
        this.requestPayment();
    },
    requestPayment: function() {
        a.wxPay({
            uid: wx.getStorageSync("uid"),
            memberid: this.data.id,
            type: "3"
        }).then(function(t) {
            console.log(t), wx.requestPayment({
                timeStamp: String(t.data.timeStamp),
                nonceStr: t.data.nonceStr,
                package: t.data.package,
                signType: t.data.signType,
                paySign: t.data.paySign,
                success: function(t) {
                    console.log(t), wx.showToast({
                        icon: "success",
                        title: "支付成功",
                        duration: 1500
                    }), setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 1500);
                },
                fail: function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(a) {
                console.log(a.platform), "devtools" == a.platform ? t.setData({
                    systemInfo: "PC"
                }) : "ios" == a.platform ? t.setData({
                    systemInfo: "IOS"
                }) : "android" == a.platform && t.setData({
                    systemInfo: "android"
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        this.getVipList(), this.getSystemInfo();
    },
    onShareAppMessage: function() {}
});