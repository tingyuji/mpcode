var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        phone: "",
        testid: "",
        contentVal: ""
    },
    onLoad: function(e) {
        console.log(t.globalData.id, "查看shitiid"), e = t.globalData.id, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            id: e,
            testid: e
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    getPhone: function(t) {
        this.setData({
            phone: t.detail.value
        });
    },
    getCon: function(t) {
        this.setData({
            contentVal: t.detail.value
        });
    },
    goSubmit: function() {
        if ("" == this.data.contentVal.trim()) return wx.showToast({
            icon: "none",
            title: "请输入内容~"
        }), !1;
        var t = this;
        wx.showModal({
            title: "提示",
            content: "是否公开发表？",
            confirmText: "公开",
            cancelText: "不公开",
            success: function(e) {
                e.confirm ? t.do_submit() : e.cancel && t.do_submitt();
            }
        });
    },
    do_submit: function() {
        e.notes({
            tid: this.data.id,
            uid: wx.getStorageSync("uid"),
            status: "note",
            type: 1,
            content: this.data.contentVal
        }).then(function(t) {
            console.log(t), wx.showToast({
                title: "提交成功~",
                icon: "none",
                duration: 2e3
            }), wx.navigateBack({
                delta: 1
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    do_submitt: function() {
        e.notes({
            tid: this.data.id,
            uid: wx.getStorageSync("uid"),
            status: "note",
            type: 2,
            content: this.data.contentVal
        }).then(function(t) {
            console.log(t), wx.showToast({
                title: "提交成功~",
                icon: "none",
                duration: 2e3
            }), wx.navigateBack({
                delta: 1
            });
        }).catch(function(t) {
            wx.showToast({
                title: "提交失败~",
                icon: "none",
                duration: 2e3
            }), console.log(t);
        });
    }
});