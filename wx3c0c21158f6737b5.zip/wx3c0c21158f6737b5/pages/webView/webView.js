var t = getApp();

Page({
    data: {
        item: {
            link: "",
            title: ""
        },
        statusBarHeight: "",
        titleBarHeight: ""
    },
    onLoad: function(a) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), wx.setNavigationBarTitle({
            title: t.globalData.item.title,
            success: function(t) {},
            fail: function(t) {},
            complete: function(t) {}
        }), this.setData({
            item: t.globalData.item
        }), console.log(t.globalData.item);
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onShareAppMessage: function() {}
});