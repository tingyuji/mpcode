var t = getApp(), o = require("../../provider/dataApi.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        isloading: !0,
        param: [ {
            id: 1,
            name: "小"
        }, {
            id: 2,
            name: "中"
        }, {
            id: 3,
            name: "大"
        } ]
    },
    onLoad: function(o) {
        this.setData({
            statusBarHeight: t.globalData.statusBarHeight,
            titleBarHeight: t.globalData.titleBarHeight
        }), this.getUserInfo();
    },
    getUserInfo: function() {
        var t = this;
        o.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(o) {
            console.log(o), t.setData({
                userInfo: o.data.info,
                isloading: !1
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    radioChange: function(t) {
        var e = t.detail.value, n = this;
        o.updateInfo({
            uid: wx.getStorageSync("uid"),
            fontid: e,
            op: "fontsize"
        }).then(function(t) {
            console.log(t), n.getUserInfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    clear: function() {
        wx.showModal({
            title: "提示",
            content: "清除后答题记录和背知识点记录将全部消失，确定清除吗？",
            success: function(t) {
                t.confirm ? o.userinfo({
                    uid: wx.getStorageSync("uid"),
                    op: "clearRecord"
                }).then(function(t) {
                    console.log(t), wx.removeStorageSync("seenid"), wx.removeStorageSync("fidselect"), 
                    wx.showToast({
                        title: "清除成功",
                        icon: "none",
                        duration: 2e3
                    });
                }).catch(function(t) {
                    console.log(t);
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    cutoff: function(t) {
        if (1 == (e = t.currentTarget.dataset.value)) var e = 0; else if (0 == e) e = 1;
        var n = this;
        o.updateInfo({
            uid: wx.getStorageSync("uid"),
            cutoff: e,
            op: "cutoff"
        }).then(function(t) {
            console.log(t), n.getUserInfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    dim: function(t) {
        if (1 == (e = t.currentTarget.dataset.value)) var e = 0; else if (0 == e) e = 1;
        var n = this;
        o.updateInfo({
            uid: wx.getStorageSync("uid"),
            dim: e,
            op: "dim"
        }).then(function(t) {
            console.log(t), n.getUserInfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    night: function(t) {
        if (1 == (e = t.currentTarget.dataset.value)) var e = 0; else if (0 == e) e = 1;
        var n = this;
        o.updateInfo({
            uid: wx.getStorageSync("uid"),
            night: e,
            op: "night"
        }).then(function(t) {
            console.log(t), n.getUserInfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onShareAppMessage: function() {}
});