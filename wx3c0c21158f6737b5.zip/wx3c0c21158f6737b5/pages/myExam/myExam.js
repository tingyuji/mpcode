var t = {
    scope: {}
};

t.defineProperty = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, o) {
    if (o.get || o.set) throw new TypeError("ES3 does not support getters and setters.");
    t != Array.prototype && t != Object.prototype && (t[e] = o.value);
}, t.getGlobal = function(t) {
    return "undefined" != typeof window && window === t ? t : "undefined" != typeof global ? global : t;
}, t.global = t.getGlobal(void 0), t.SYMBOL_PREFIX = "jscomp_symbol_", t.initSymbol = function() {
    t.initSymbol = function() {}, t.global.Symbol || (t.global.Symbol = t.Symbol);
}, t.symbolCounter_ = 0, t.Symbol = function(e) {
    return t.SYMBOL_PREFIX + (e || "") + t.symbolCounter_++;
}, t.initSymbolIterator = function() {
    t.initSymbol();
    var e = t.global.Symbol.iterator;
    e || (e = t.global.Symbol.iterator = t.global.Symbol("iterator")), "function" != typeof Array.prototype[e] && t.defineProperty(Array.prototype, e, {
        configurable: !0,
        writable: !0,
        value: function() {
            return t.arrayIterator(this);
        }
    }), t.initSymbolIterator = function() {};
}, t.arrayIterator = function(e) {
    var o = 0;
    return t.iteratorPrototype(function() {
        return o < e.length ? {
            done: !1,
            value: e[o++]
        } : {
            done: !0
        };
    });
}, t.iteratorPrototype = function(e) {
    return t.initSymbolIterator(), (e = {
        next: e
    })[t.global.Symbol.iterator] = function() {
        return this;
    }, e;
}, t.makeIterator = function(e) {
    t.initSymbolIterator();
    var o = e[Symbol.iterator];
    return o ? o.call(e) : t.arrayIterator(e);
}, t.arrayFromIterator = function(t) {
    for (var e, o = []; !(e = t.next()).done; ) o.push(e.value);
    return o;
}, t.arrayFromIterable = function(e) {
    return e instanceof Array ? e : t.arrayFromIterator(t.makeIterator(e));
};

var e = getApp(), o = require("../../provider/dataApi.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        list: [],
        page: 1,
        totalPage: 1,
        isData: !0,
        isloading: !0
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), this.getExamList(1);
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    getExamList: function(e) {
        var a = this;
        o.myTest({
            uid: wx.getStorageSync("uid"),
            page: e
        }).then(function(e) {
            console.log(e);
            var o = [].concat(t.arrayFromIterable(a.data.list), t.arrayFromIterable(e.data.list));
            e = Math.ceil(e.data.total / e.data.psize);
            var r = !1;
            0 < o.length && (r = !0), a.setData({
                list: o,
                totalPage: e,
                isData: r,
                isloading: !1
            }), wx.stopPullDownRefresh();
        }).catch(function(t) {
            console.log(t);
        });
    },
    seeError: function(t) {
        console.log(t, "查看"), 1 == (t = t.currentTarget.dataset.item).is_simple && 2 == t.complete ? this.showTip("试卷中包含主观题，请耐心等待评卷") : (e.globalData.op = "seeErr", 
        e.globalData.paperId = t.examid, console.log(t.examid), wx.navigateTo({
            url: "/pages/resolution/practice"
        }));
    },
    goResult: function(t) {
        console.log(t, "查看"), 1 == (t = t.currentTarget.dataset.item).is_simple && 2 == t.complete ? this.showTip("试卷中包含主观题，请耐心等待评卷") : (e.globalData.etype = t.chuti_type, 
        wx.navigateTo({
            url: "/pages/result/result?type=2&paperid=" + t.id + "&id=" + t.rid + "&param=result"
        }));
    },
    showTip: function(t) {
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: !1,
            confirmText: "关闭",
            success: function(t) {
                console.log(t);
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.setData({
            page: 1,
            list: [],
            isloading: !0
        }), this.getExamList(1);
    },
    onReachBottom: function() {
        var t = parseInt(this.data.totalPage), e = parseInt(this.data.page);
        e < t && (this.setData({
            page: e + 1
        }), this.getExamList(this.data.page));
    },
    onShareAppMessage: function() {}
});