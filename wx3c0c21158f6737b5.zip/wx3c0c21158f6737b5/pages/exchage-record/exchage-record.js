getApp();

var t = require("../../provider/dataApi.js"), a = require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        list: []
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), this.exchangeGiftList();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    exchangeGiftList: function() {
        var e = this;
        t.exchangeGiftList({
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t), t.data && (t.data.forEach(function(t) {
                t.createtime = a.formatDateTimehour(t.createtime);
            }), e.setData({
                list: t.data
            }));
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShareAppMessage: function() {}
});