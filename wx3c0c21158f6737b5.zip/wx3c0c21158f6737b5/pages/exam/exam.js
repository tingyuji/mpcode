var t, e;

function a(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var i = getApp(), s = require("../../provider/dataApi.js"), o = (require("../../provider/pipe.js"), 
require("../../wxParse/wxParse.js"));

Page((a(e = {
    data: (t = {
        title: "全真模拟",
        paperid: "",
        startPoint: [ 0, 0 ],
        curPoint: [],
        statusBarHeight: "",
        titleBarHeight: "",
        show: !1,
        num: 0,
        num_length: 0,
        remainder: 0,
        handpapershow: !1,
        item: {
            total_score: 100,
            pass_score: 60,
            paper_time: 90,
            highest: 0
        },
        timer: null,
        ruletime: "",
        durationtime: "",
        usetime: "",
        index: 0,
        paperdetail: "",
        answerlist: [],
        audiolist: [],
        answerlength: 0,
        isaudio: 1,
        inputHeight: 0,
        exam_type: ""
    }, a(t, "paperid", ""), a(t, "isloading", !1), a(t, "isPageWait", !0), a(t, "playTime", "00:00"), 
    a(t, "totalTime", "00:00"), a(t, "progressBar", 0), a(t, "audioTimeList", []), a(t, "audioTimer", null), 
    t),
    mytouchstart: function(t) {
        this.setData({
            startPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchmove: function(t) {
        this.setData({
            curPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchend: function(t) {
        t.changedTouches[0].pageX - this.data.startPoint[0] < 0 ? this.data.index + 1 < this.data.paperdetail.length && this.setData({
            index: this.data.index + 1
        }) : 0 < this.data.index && this.setData({
            index: this.data.index - 1
        });
    },
    bindplay: function(t) {
        if (console.log(t), t = t.currentTarget.id, this.data.playIndex) {
            var e = wx.createVideoContext([ "index", this.data.playIndex ].join(""));
            e.seek(0), e.pause();
        }
        this.setData({
            playIndex: t
        }), wx.createVideoContext([ "index", this.data.playIndex ].join("")).play(), this.readVideo(t);
    },
    onLoad: function(t) {
        console.log(t, "查看传参11111"), wx.getStorageSync("uid") ? (this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            item: i.globalData.item,
            course_type: t.course_type,
            ruletime: 60 * i.globalData.item.paper_time
        }), t.exam_type && (this.setData({
            exam_type: t.exam_type
        }), "1" == t.exam_type && this.setData({
            paperid: t.paperid
        }), "zt" == t.etype && this.setData({
            paperid: t.paperid,
            title: "历年真题"
        }), "5" == t.exam_type && this.setData({
            paperid: t.paperid,
            title: "随机试题"
        }), this.mockExam(t.exam_type), this.timer(60 * t.time)), "2" == t.exam_type && (this.setData({
            title: "未做试题"
        }), this.timer(60 * i.globalData.item.paper_time)), "3" == t.exam_type && (this.setData({
            title: "智能考试"
        }), this.timer(60 * i.globalData.item.paper_time))) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    showTk: function() {
        if (100 < this.data.paperdetail) {
            var t = Math.floor(this.data.paperdetail.length / 100), e = this.data.paperdetail.length % 100;
            console.log(t, e), this.setData({
                num: 100,
                num_length: t,
                remainder: e
            });
        } else this.setData({
            num: this.data.paperdetail
        });
        this.setData({
            show: !0
        });
    },
    onClose: function() {
        this.setData({
            show: !1
        });
    },
    goUp: function() {
        if (0 == this.data.index) return wx.showToast({
            title: "这是第一题",
            icon: "none"
        }), !1;
        this.setData({
            index: this.data.index - 1,
            isPageWait: !0
        }), this.changepic(this.data.index), this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    goDown: function() {
        if (this.data.index + 1 >= this.data.paperdetail.length) return wx.showToast({
            title: "已经是最后一题了",
            icon: "none"
        }), !1;
        this.setData({
            index: this.data.index + 1,
            isPageWait: !0
        }), this.changepic(this.data.index), this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    jumptap: function(t) {
        this.setData({
            index: t.currentTarget.dataset.i,
            show: !1,
            isPageWait: !0
        }), this.changepic(this.data.index), this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    scrolltolower: function(t) {
        this.data.num < this.data.paperdetail.length && (Math.floor(this.data.num / 100) == this.data.num_length ? this.setData({
            num: this.data.num + this.data.remainder
        }) : this.setData({
            num: this.data.num + 100
        }));
    },
    timer: function(t) {
        clearInterval(this.data.timer);
        var e = this, a = t;
        e.setData({
            durationtime: e.djstimer(a)
        }), this.data.timer = setInterval(function() {
            a--, e.setData({
                durationtime: e.djstimer(a),
                usetime: e.djstimer(t - a)
            }), a <= 0 && (clearInterval(e.data.timer), e.mockexam_submit());
        }, 1e3);
    },
    djstimer: function(t) {
        var e = (e = Math.floor(t / 60 / 60 % 24)) < 10 ? "0" + e : e, a = (a = Math.floor(t / 60 % 60)) < 10 ? "0" + a : a;
        return t = (t = Math.floor(t % 60)) < 10 ? "0" + t : t, 0 < e ? e + ":" + a + ":" + t : a + ":" + t;
    },
    goHandpaper: function() {
        this.setData({
            handpapershow: !0
        });
    },
    Handpaper: function() {
        this.setData({
            handpapershow: !1
        }), this.mockexam_submit();
    },
    goDati: function() {
        this.setData({
            handpapershow: !1
        });
    },
    honClose: function() {
        this.setData({
            handpapershow: !1
        });
    },
    choice: function(t) {
        var e = this.data.answerlist;
        e[t.currentTarget.dataset.fjtit].choose = t.currentTarget.dataset.option, this.setData({
            answerlist: e
        }), this.getAnswerlength();
    },
    multipleChoice: function(t) {
        var e = t.currentTarget.dataset.fjtit, a = t.currentTarget.dataset.option, i = 0;
        (t = this.data.answerlist)[e].choose.forEach(function(t, e) {
            t.o == a && (t.ischoose = !t.ischoose);
        });
        for (var s = 0; s < t[e].choose.length; s++) {
            if (t[e].choose[s].ischoose) {
                i = 1, t[e].flag = !1;
                break;
            }
            i = 0, t[e].flag = !1;
        }
        t[e].flag = 1 == i, this.setData({
            answerlist: t
        }), this.getAnswerlength();
    },
    textInput: function(t) {
        var e = t.currentTarget.dataset.fjnum, a = this.data.answerlist;
        a[e].choose[t.currentTarget.dataset.inputnum] = t.detail.value, this.isempty(a[e].choose) ? a[e].issure = !0 : a[e].issure = !1, 
        this.setData({
            answerlist: a
        }), this.getAnswerlength();
    },
    vioceChoice: function(t) {
        console.log(t);
        var e = t.currentTarget.dataset.fjnum, a = this.data.answerlist, i = {};
        for (this.setData((i["answerlist[" + e + "].choose[" + t.currentTarget.dataset.zjnum + "].choose"] = t.currentTarget.dataset.option, 
        i)), t = !0, i = 0; i < a[e].choose.length; i++) if ("" == a[e].choose[i].choose) {
            t = !1;
            break;
        }
        a[e].iscomplete = t, this.setData({
            answerlist: a
        }), this.getAnswerlength();
    },
    chooseOption: function(t) {
        var e = this.data.index, a = this.data.answerlist;
        a[e].choose[t.currentTarget.dataset.findex].choose = t.currentTarget.dataset.zindex, 
        t = !0;
        for (var i = 0; i < a[e].choose.length; i++) if ("" == a[e].choose[i].choose) {
            t = !1;
            break;
        }
        a[e].issure = t, this.setData({
            answerlist: a
        }), this.getAnswerlength();
    },
    bindTextAreaBlur: function(t) {
        var e = t.currentTarget.dataset.index;
        t = t.detail.value;
        var a = this.data.answerlist;
        a[e].choose = t, a[e].issure = "" != t, this.setData({
            answerlist: a
        }), this.getAnswerlength();
    },
    getAnswerlength: function() {
        var t = 0;
        this.data.answerlist.forEach(function(e) {
            1 == e.type || 3 == e.type || 8 == e.type ? e.choose && t++ : 2 == e.type ? e.flag && t++ : 4 == e.type ? e.issure && t++ : 5 == e.type ? e.iscomplete && t++ : (6 == e.type || 7 == e.type) && e.issure && t++;
        }), this.setData({
            answerlength: t
        });
    },
    onReady: function() {
        var t = wx.createInnerAudioContext();
        this.setData({
            audioCtx: t
        });
    },
    onHide: function() {
        this.changepic(this.data.index), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
    },
    onUnload: function() {
        this.changepic(this.data.index), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
        var t = clearInterval(_this.data.audioTimer);
        _this.setData({
            audioTimer: t
        });
    },
    mockExam: function(t) {
        var e = this;
        this.setData({
            isloading: !0
        });
        if ("zt" == t) t = 1;
        s.mockExam({
            uid: wx.getStorageSync("uid"),
            exam_type: t,
            course_type: this.data.course_type,
            paperid: e.data.paperid
        }).then(function(t) {
            if (console.log(t), t.data.list.length <= 0) e.setData({
                isloading: !1
            }); else {
                console.log(t);
                var a = [], i = [], s = [];
                t.data.list && (t.data.list.forEach(function(t) {
                    if (1 == t.type || 3 == t.type || 8 == t.type) a.push({
                        type: t.type,
                        tid: t.id,
                        issure: !1,
                        choose: ""
                    }); else if (2 == t.type) {
                        var e = [];
                        t.option.forEach(function(t) {
                            e.push({
                                o: t.o,
                                ischoose: !1
                            });
                        }), a.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            flag: !1,
                            choose: e
                        });
                    } else if (4 == t.type) {
                        for (var o = [], n = 0; n < t.rightarray.length; n++) o.push("");
                        a.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            choose: o
                        });
                    } else if (5 == t.type) {
                        var r = [];
                        t.list.forEach(function(t) {
                            r.push({
                                tid: t.id,
                                choose: ""
                            });
                        }), a.push({
                            type: t.type,
                            tid: t.id,
                            iscomplete: !1,
                            choose: r
                        });
                    } else 6 != t.type && 7 != t.type || (o = t.list.map(function(t, e) {
                        return {
                            tid: t.id,
                            choose: ""
                        };
                    }), a.push({
                        type: t.type,
                        tid: t.id,
                        issure: !1,
                        choose: o
                    }));
                    t.qaudio ? i.push({
                        audiosrc: t.qaudio,
                        time: 0
                    }) : i.push({
                        audiosrc: "",
                        time: 0
                    }), 2 == t.a_type ? s.push(t.option) : s.push("");
                }), console.log(a), t.data.list && e.setData({
                    paperdetail: t.data.list,
                    answerlist: a,
                    audiolist: i
                }), t.data.paperid && e.setData({
                    paperid: t.data.paperid
                }), e.setData({
                    isloading: !1
                }), e.getAllAudioTime(), e.wxParseTitle(e.data.index));
            }
        }).catch(function(t) {
            e.setData({
                isloading: !1
            }), console.log(t);
        });
    },
    wxParseTitle: function(t) {
        t = this.data.paperdetail[t], o.wxParse("ParseTitle", "html", t.question, this, 5), 
        0 != t.a_type || 1 != t.type && 2 != t.type ? this.setData({
            isPageWait: !1
        }) : this.wxParseOptions(t.option);
    },
    wxParseOptions: function(t) {
        console.log(t);
        for (var e = 0; e < t.length; e++) o.wxParse("wxParseOption" + e, "html", t[e].p, this);
        console.log(this.data.wxParseOption0), this.setData({
            isPageWait: !1
        });
    },
    isempty: function(t) {
        var e;
        for (var a in new Boolean(), e = !0, t) t[a] || (e = !1);
        return !!e;
    },
    changepic: function(t) {
        this.data.paperdetail.length <= 0 || 0 == this.data.audiolist.length || this.data.audiolist[t].url && !(this.data.audiolist[t].url != this.data.audiolist[t - 1].url && 0 < t) || (this.setData({
            isaudio: 1
        }), this.data.audioCtx.pause());
    },
    getAllAudioTime: function() {
        var t = this, e = [];
        this.data.paperdetail.forEach(function(a, i) {
            if (a.qaudio) {
                var s = t.data.audioCtx;
                s.src = a.qaudio, console.log(s), setTimeout(function() {
                    s.currentTime;
                    var a = t.handleTime(Math.round(s.duration));
                    e.push(a);
                }, 2 * i);
            } else e.push("00:00");
        }), console.log(e);
    },
    myAudioStart: function(t) {
        var e = this.data.audioCtx, a = this, i = this.data.audiolist;
        this.setData({
            isaudio: 2
        }), e.src = t.currentTarget.dataset.src, 0 != i[t.currentTarget.dataset.num].time ? (e.play(), 
        e.seek(i[t.currentTarget.dataset.num].time)) : e.play(), this.currenttime(), this.data.onEnded || (this.data.onEnded = !0, 
        e.onEnded(function() {
            a.setData({
                isaudio: 1,
                currentTime: 0
            }), a.audiotime(t.currentTarget.dataset.src, 0);
        }));
        var s = t.currentTarget.dataset.num, o = a.data.audioTimeList, n = setInterval(function() {
            var t, i = Math.round(e.currentTime), r = Math.round(e.duration);
            t = 100 * (i / r).toFixed(3);
            var d = a.handleTime(i), h = a.handleTime(r);
            o[s] = h, a.setData({
                playTime: d,
                totalTime: h,
                progressBar: t,
                audioTimeList: o,
                audioTimer: n
            }), r == i && (console.log("停止"), setTimeout(function() {
                clearInterval(n), a.setData({
                    playTime: "00:00",
                    totalTime: h,
                    progressBar: 0,
                    audioTimer: n
                });
            }, 1e3));
        }, 1e3);
    },
    myAudioPause: function(t) {
        var e = this.data.audioCtx, a = this;
        e.pause(), this.data.onPause || (this.data.onPause = !0, e.onPause(function() {
            e.currentTime, a.setData({
                isaudio: 1
            }), a.audiotime(t.currentTarget.dataset.src, Math.floor(e.currentTime));
        }));
        var i = clearInterval(a.data.audioTimer);
        a.setData({
            audioTimer: i
        });
    },
    handleTime: function(t) {
        if (60 <= t) {
            var e = parseInt(t / 60 % 60);
            return (e < 10 ? "0" + e : e) + ":" + ((t = parseInt(t % 60)) < 10 ? "0" + t : t);
        }
        return "00:" + (t < 10 ? "0" + t : t);
    },
    clearAudioTime: function() {
        var t = this.data.index, e = this.data.audioTimeList;
        0 < e.length && (t = e[t], clearInterval(this.data.audioTimer), console.log(e), 
        this.setData({
            playTime: "00:00",
            totalTime: t,
            progressBar: 0
        }));
    },
    currenttime: function(t) {
        var e = this.data.audioCtx;
        setTimeout(function() {
            e.currentTime, e.onTimeUpdate(function() {});
        }, 100);
    },
    audiotime: function(t, e) {
        this.data.audiolist.forEach(function(a) {
            a.url == t && (a.time = e);
        });
    },
    mockexam_submit: function() {
        console.log(this.data.answerlist, "查看类型haha");
        var t = this, e = [];
        this.data.answerlist.forEach(function(t) {
            if (1 == t.type || 3 == t.type || 8 == t.type) e.push({
                tid: t.tid,
                type: t.type,
                answer: t.choose
            }); else if (2 == t.type) {
                var a = [];
                t.choose.forEach(function(t) {
                    t.ischoose && a.push(t.o);
                }), e.push({
                    tid: t.tid,
                    type: t.type,
                    answer: a
                });
            } else if (4 == t.type) {
                var i = [];
                t.choose.forEach(function(t) {
                    i.push("【" + t + "】");
                }), i = i.join(","), e.push({
                    tid: t.tid,
                    type: t.type,
                    answer: i
                });
            } else {
                var s = [];
                t.choose.forEach(function(t) {
                    s.push({
                        tid: t.tid,
                        answer: t.choose
                    });
                }), e.push({
                    tid: t.tid,
                    type: t.type,
                    answer: s
                });
            }
        }), s.mockexam_submit({
            uid: wx.getStorageSync("uid"),
            exam_type: this.data.exam_type,
            paperid: this.data.paperid,
            answerdata: JSON.stringify(e),
            usetime: this.data.usetime,
            course_type: this.data.course_type
        }).then(function(e) {
            console.log(e), e.data.resuser && (i.globalData.resuser = e.data.resuser, wx.redirectTo({
                url: "../result/result?type=" + t.data.exam_type + "&paperid=" + t.data.paperid + "&id=" + e.data.rid
            }));
        }).catch(function(t) {
            console.log(t);
        });
    }
}, "onUnload", function() {
    clearInterval(this.data.timer);
}), a(e, "onShareAppMessage", function() {
    return {
        path: "/pages/home/home"
    };
}), e));