var t = require("../../wxParse/wxParse.js"), e = getApp(), a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        oItem: "",
        answer: "",
        textshow: 0,
        kindex: 0,
        knowlist: {},
        seenid: {},
        freenum: "",
        lookid: {},
        isPlaying: !1
    },
    onLoad: function(t) {
        this.knowRecord(), t = e.globalData.oItem, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            oItem: t.currentTarget.dataset.item,
            knowlist: e.globalData.list,
            kindex: e.globalData.kindex,
            answer: t.answer
        }), this.knowdetail(this.data.knowlist, this.data.kindex);
    },
    knowRecord: function() {
        var t = this;
        a.knowRecord({
            uid: wx.getStorageSync("uid")
        }).then(function(e) {
            var a = JSON.parse(e.data.testid);
            console.log(a, "成功了吗"), t.setData({
                seenid: a,
                lookid: JSON.parse(e.data.knowledgeid)
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    knowdetail: function(e, a) {
        t.wxParse("article", "html", e[a].content, this, 15), t.wxParse("answer", "html", e[a].answer, this, 5);
    },
    threeLevel: function() {
        if (console.log(this.data.oItem, "查看题库"), 0 == this.data.oItem.libraryid) wx.showModal({
            title: "提示",
            content: "该知识点暂未添加对应的三级题库",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        }); else {
            var t = this;
            a.islock({
                uid: wx.getStorageSync("uid"),
                libraryid: this.data.oItem.libraryid
            }).then(function(e) {
                console.log(e, "查看freenum"), 1 == e.data.is_can ? t.rtChoose(e.data.freenum) : 0 == e.data.is_can ? t.rtChoose() : 2 == e.data.is_can && wx.showModal({
                    title: "提示",
                    content: "该题库为学员专项题库，您暂无权限刷题",
                    success: function(t) {
                        t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
                    }
                });
            }).catch(function(t) {
                console.log(t);
            });
        }
    },
    rtChoose: function(t) {
        console.log(t, "查看freenum"), "" != t ? (e.globalData.op = "special", e.globalData.id = this.data.oItem.libraryid, 
        wx.navigateTo({
            url: "../practice/practice?num=" + t
        })) : (e.globalData.op = "special", e.globalData.id = this.data.oItem.libraryid, 
        wx.navigateTo({
            url: "../practice/practice"
        }));
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    prompt: function() {
        this.setData({
            textshow: 1
        });
    },
    reanswer: function() {
        this.setData({
            textshow: 2
        });
    },
    noRemember: function() {
        this.setData({
            textshow: 2
        });
    },
    finish: function(t) {
        var e = t.currentTarget.dataset.kindex + 1;
        if (e + 1 > this.data.knowlist.length) return wx.showModal({
            title: "提示",
            content: "该分类下的知识点已看完",
            success: function(t) {
                t.confirm ? (console.log("用户点击确定"), wx.navigateBack({
                    delta: 2
                })) : t.cancel && console.log("用户点击取消");
            }
        }), !1;
        if (e + 1 < this.data.knowlist.length && 0 == this.data.knowlist[e].is_can) return wx.showModal({
            title: "提示",
            content: "下个知识点为付费知识点，您暂无权限查看",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        }), !1;
        this.setData({
            kindex: e,
            oItem: this.data.knowlist[e]
        });
        var a = this.data.knowlist[e].id, o = this.data.knowlist[e].three, i = {};
        this.data.lookid && (i = this.data.lookid);
        var n = {};
        this.data.seenid && (n = this.data.seenid), i[a] || (i[a] = [ a ], n[o] ? n[o].push(o) : n[o] = [ o ]), 
        this.setData({
            lookid: i,
            seenid: n,
            textshow: 0
        }), wx.setStorageSync("lookid", this.data.lookid), wx.setStorageSync("seenid", this.data.seenid), 
        this.knowSelect(), this.knowdetail(this.data.knowlist, e);
    },
    knowSelect: function() {
        if ("" == wx.getStorageSync("seenid")) var t = ""; else t = JSON.stringify(wx.getStorageSync("seenid"));
        a.knowSelect({
            uid: wx.getStorageSync("uid"),
            seenid: t,
            lookid: JSON.stringify(wx.getStorageSync("lookid"))
        }).then(function(t) {
            console.log("成功了吗");
        }).catch(function(t) {
            console.log(t);
        });
    },
    audioClick: function(t) {
        this.setData({
            isPlaying: !this.data.isPlaying
        }), this.data.isPlaying ? (this.audioCtx.play(), console.log("播放")) : this.audioCtx.pause();
    },
    onReady: function() {
        this.audioCtx = wx.createAudioContext("mpvoice");
    },
    onShow: function() {},
    onHide: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});