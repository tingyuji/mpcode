var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js"), require("../../wxParse/wxParse.js");

Page({
    data: {
        notes: "",
        value: "",
        focus: !1,
        commentShow: !1,
        placeholder: "写评论..."
    },
    onLoad: function(e) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            notes: t.globalData.comment,
            uid: wx.getStorageSync("uid")
        });
    },
    inputFocus: function(t) {
        this.setData({
            inputBottom: t.detail.height
        });
    },
    inputBlur: function(t) {
        this.setData({
            content: t.detail.value,
            inputBottom: 0
        });
    },
    write_comment: function(t) {
        console.log(t.currentTarget.dataset.userid), "0" != t.currentTarget.dataset.userid ? this.comment_user(t.currentTarget.dataset.userid) : this.setData({
            placeholder: "写评论..."
        }), this.setData({
            focus: !0,
            commentShow: !0,
            userid: t.currentTarget.dataset.userid,
            commentid: t.currentTarget.dataset.commentid
        });
    },
    comment_user: function(t) {
        var n = this;
        e.getnotes({
            userid: t,
            status: "comment_user"
        }).then(function(t) {
            console.log(t), n.setData({
                placeholder: "回复" + t.data.nickname
            }), t.data.nickname;
        }).catch(function(t) {
            console.log(t);
        });
    },
    cancel: function() {
        this.setData({
            focus: !1,
            commentShow: !1
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    plinput: function(t) {
        this.setData({
            value: t.detail.value
        });
    },
    report: function() {
        if ("" == this.data.value) return wx.showToast({
            title: "内容不能为空",
            icon: "none",
            duration: 2e3
        }), !1;
        var t = this;
        e.getnotes({
            uid: wx.getStorageSync("uid"),
            id: t.data.notes.id,
            value: t.data.value,
            userid: t.data.userid,
            commentid: t.data.commentid,
            status: "comment"
        }).then(function(e) {
            t.setData({
                value: "",
                focus: !1,
                commentShow: !1
            }), wx.showToast({
                title: "发表成功",
                icon: "success",
                duration: 2e3
            }), t.comment();
        }).catch(function(t) {
            console.log(t);
        });
    },
    del: function(t) {
        var n = this, o = t.currentTarget.dataset.id;
        console.log(o), e.getnotes({
            id: o,
            status: "delcomment"
        }).then(function(t) {
            wx.showToast({
                title: "删除成功",
                icon: "success",
                duration: 2e3
            }), n.comment();
        }).catch(function(t) {
            console.log(t);
        });
    },
    onReady: function() {},
    comment: function() {
        var n = t.globalData.comment.id, o = this;
        e.getnotes({
            id: n,
            status: "allcomment"
        }).then(function(t) {
            console.log(t, "查看评论"), o.setData({
                comment: t.data.result,
                comment_num: t.data.comment_num
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        this.comment();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});