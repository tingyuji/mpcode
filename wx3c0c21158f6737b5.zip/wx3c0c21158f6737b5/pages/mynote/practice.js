var t = getApp(), e = require("../../provider/dataApi.js"), a = (require("../../provider/pipe.js"), 
require("../../wxParse/wxParse.js"));

Page({
    data: {
        special_id: "",
        myanswer: "",
        rate_show: 0,
        ymshow: !1,
        isAnalysisAudioPlay: 1,
        answerAudiolist: [],
        answerImglist: [],
        isfirstPlay: !0,
        have: 1,
        type: 2,
        startPoint: [ 0, 0 ],
        curPoint: [],
        statusBarHeight: "",
        titleBarHeight: "",
        show: !1,
        num: 0,
        note: "",
        num_length: 0,
        remainder: 0,
        handpapershow: !1,
        item: {
            total_score: 100,
            pass_score: 60,
            paper_time: 90,
            highest: 0
        },
        timer: null,
        ruletime: "",
        durationtime: "",
        usetime: "",
        index: 0,
        paperdetail: "",
        answerlist: [],
        audiolist: [],
        answerlength: 0,
        isaudio: 1,
        inputHeight: 0,
        rightAnswer: [],
        isloading: !1,
        adInfo: {},
        ad_have: 2,
        userAnswerJudge: [],
        trialBool: !1,
        trialNum: "",
        isPageWait: !0,
        titlePlayTime: "00:00",
        titleTotalTime: "00:00",
        titleAudioTimer: null,
        analysisPlayTime: "00:00",
        analysisTotalTime: "00:00",
        analysisAudioTimer: null,
        audioTimeList: [],
        tabshow: !1,
        myNoteShow: !0,
        userNoteShow: !1,
        mynote: "",
        usernote: "",
        selectid: {},
        fid: "",
        fidselect: {},
        err_question: "",
        isShowShortAnswer: !1
    },
    previewImg: function(t) {
        var e = this.data.paperdetail[this.data.index].qimage;
        wx.previewImage({
            current: e[t.currentTarget.dataset.index],
            urls: e
        });
    },
    tabshow: function() {
        this.setData({
            tabshow: !0,
            myNoteShow: !1,
            userNoteShow: !1
        });
    },
    myNoteShow: function() {
        this.setData({
            tabshow: !1,
            myNoteShow: !0,
            userNoteShow: !1
        }), console.log(this.data.index), this.getAllNotes();
    },
    userNoteShow: function() {
        this.setData({
            tabshow: !1,
            myNoteShow: !1,
            userNoteShow: !0
        }), this.getAllNotes();
    },
    wrong_del: function(t) {
        var a = this, i = t.currentTarget.dataset.id;
        e.getnotes({
            uid: wx.getStorageSync("uid"),
            testid: i,
            status: "wrongdel"
        }).then(function(t) {
            console.log(t), wx.showToast({
                title: "已移出",
                icon: "success",
                duration: 2e3
            }), a.data.index + 1 == a.data.paperdetail.length ? wx.navigateBack({
                delta: 1
            }) : a.goDown();
        }).catch(function(t) {
            console.log(t);
        });
    },
    previewImgJx: function(t) {
        var e = this.data.paperdetail[this.data.index].aimage;
        wx.previewImage({
            current: e[t.currentTarget.dataset.index],
            urls: e
        });
    },
    mytouchstart: function(t) {
        this.setData({
            startPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchmove: function(t) {
        this.setData({
            curPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchend: function(t) {
        t.changedTouches[0].pageX - this.data.startPoint[0] < 0 ? this.data.index + 1 < this.data.paperdetail.length && this.setData({
            index: this.data.index + 1
        }) : 0 < this.data.index && this.setData({
            index: this.data.index - 1
        });
    },
    goType: function(t) {
        var e = t.currentTarget.dataset.type;
        this.setData({
            type: e
        }), 2 == e && this.lookAnaiysis();
    },
    onLoad: function(e) {
        if (wx.getStorageSync("uid")) {
            if (this.setData({
                statusBarHeight: getApp().globalData.statusBarHeight,
                titleBarHeight: getApp().globalData.titleBarHeight
            }), "{}" != JSON.stringify(e)) {
                console.log(e);
                var a = "";
                e.sonType && (a = e.sonType), this.setData({
                    trialNum: e.num,
                    trialBool: !0,
                    sonType: a
                });
            }
            e = t.globalData.op, console.log(t.globalData.id), t.globalData.id ? (8 != t.globalData.id || "simple_type" != t.globalData.op && "qtype" != t.globalData.op || this.setData({
                isShowShortAnswer: !0
            }), a = t.globalData.id, this.mockExam(e, a), this.setData({
                special_id: a
            })) : this.mockExam(e, ""), this.queryAd();
        } else wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    queryAd: function() {
        var t = this;
        e.advert({
            op: "second"
        }).then(function(e) {
            t.setData({
                adInfo: e.data.info,
                ad_have: e.data.ad_have
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        2 != this.data.have && this.changepic(this.data.index), wx.navigateBack({
            delta: 1
        });
    },
    showTk: function() {
        if (100 < this.data.paperdetail) {
            var t = Math.floor(this.data.paperdetail.length / 100), e = this.data.paperdetail.length % 100;
            console.log(t, e), this.setData({
                num: 100,
                num_length: t,
                remainder: e
            });
        } else this.setData({
            num: this.data.paperdetail
        });
        this.setData({
            show: !0
        });
    },
    onClose: function() {
        this.setData({
            show: !1
        });
    },
    goUp: function() {
        if (0 == this.data.index) return !1;
        this.setData({
            index: this.data.index - 1
        });
        var t = {};
        this.setData((t["answerlist[" + (this.data.index + 1) + "].isanalysis"] = !1, t.isPageWait = !0, 
        t)), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.recordAnswer(), this.getAllNotes(), this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    goDown: function() {
        if (this.setData({
            tabshow: !1,
            myNoteShow: !0,
            userNoteShow: !1
        }), this.data.trialBool) {
            var t = this.data.trialNum;
            if (this.data.index + 1 >= t) return wx.showToast({
                title: "本套试题只能试答" + t + "题哦~",
                icon: "none"
            }), !1;
        }
        if (this.data.index + 1 >= this.data.paperdetail.length) return wx.showToast({
            title: "已做完所有习题",
            icon: "none"
        }), !1;
        this.setData({
            index: this.data.index + 1,
            isPageWait: !0,
            rate_show: 0
        }), t = {}, this.setData((t["answerlist[" + (this.data.index - 1) + "].isanalysis"] = !1, 
        t)), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.recordAnswer(), this.getAllNotes(), this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    jumptap: function(t) {
        if (this.data.trialBool) {
            var e = t.currentTarget.dataset.i;
            if (console.log(e), e >= this.data.trialNum) return wx.showToast({
                title: "此为试答，如想答剩下的题请先去购买此套试卷哦",
                icon: "none"
            }), !1;
        }
        this.setData({
            index: t.currentTarget.dataset.i,
            show: !1,
            isPageWait: !0
        }), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.wxParseTitle(this.data.index), this.clearAudioTime();
    },
    judgeShortAnswer: function() {
        this.data.isShowShortAnswer;
        2 == this.data.type && this.lookAnaiysis();
    },
    initUserAnswer: function(t) {
        if (4 == (e = this.data.paperdetail)[t].type) {
            t = e[t].rightarray;
            for (var e = [], a = 0; a < t.length; a++) e.push(!0);
            this.setData({
                userAnswerJudge: e
            });
        }
    },
    scrolltolower: function(t) {
        this.data.num < this.data.paperdetail.length && (Math.floor(this.data.num / 100) == this.data.num_length ? this.setData({
            num: this.data.num + this.data.remainder
        }) : this.setData({
            num: this.data.num + 100
        }));
    },
    addWrong: function() {
        var t = this;
        e.addWrong({
            uid: wx.getStorageSync("uid"),
            tid: this.data.paperdetail[this.data.index].id,
            test_type: this.data.paperdetail[this.data.index].type,
            wrong_have: this.data.paperdetail[this.data.index].wrong_have
        }).then(function(e) {
            console.log(e);
            var a = "paperdetail[" + t.data.index + "].wrong_have";
            1 == e.data ? (wx.showToast({
                title: "已加入收藏",
                icon: "none"
            }), e = {}, t.setData((e[a] = 1, e))) : (wx.showToast({
                title: "已移出收藏",
                icon: "none"
            }), e = {}, t.setData((e[a] = 2, e)));
        }).catch(function(t) {
            console.log(t);
        });
    },
    textInput: function(t) {
        var e = t.currentTarget.dataset.fjnum, a = this.data.answerlist;
        a[e].choose[t.currentTarget.dataset.inputnum] = t.detail.value;
        var i = 0;
        this.isempty(a[e].choose) ? a[e].issure = !0 : a[e].issure = !1, a.forEach(function(t) {
            2 == t.type ? t.flag && i++ : 4 == t.type ? t.issure && i++ : 5 == t.type ? t.iscomplete && i++ : t.choose && i++;
        }), this.setData({
            answerlist: a,
            answerlength: i
        });
    },
    judgeCompletionItem: function() {
        for (var t = this.data.index, e = this.data.paperdetail[t].rightkey.split("|"), a = this.data.answerlist[t].choose, i = (t = [], 
        e = e.map(function(t) {
            return t.replace(/\u3011\u3010/g, "】,【");
        }).map(function(t) {
            return t.split(",");
        }), a = a.map(function(t) {
            return "【" + t + "】";
        }), 0); i < a.length; i++) {
            for (var s = !1, o = 0; o < e.length; o++) a[i] == e[o][i] && (s = !0);
            t.push(s);
        }
        this.setData({
            userAnswerJudge: t
        });
    },
    vioceChoice: function(t) {
        console.log(t);
        var e = t.currentTarget.dataset.fjnum, a = this.data.answerlist, i = 0, s = {};
        this.setData((s["answerlist[" + e + "].choose[" + t.currentTarget.dataset.zjnum + "].choose"] = t.currentTarget.dataset.option, 
        s)), this.isempty(a[e].choose) ? a[e].iscomplete = !0 : a[e].iscomplete = !1, a.forEach(function(t) {
            2 == t.type ? t.flag && i++ : 4 == t.type ? t.issure && i++ : 5 == t.type ? t.iscomplete && i++ : t.choose && i++;
        }), console.log(a), this.setData({
            answerlist: a,
            answerlength: i
        }), this.isBigjudge(e), this.recordAnswer();
    },
    chooseOption: function(t) {
        var e = this.data.index, a = this.data.answerlist;
        a[e].choose[t.currentTarget.dataset.findex].userAnswer = t.currentTarget.dataset.zindex, 
        console.log(a[e].choose), this.setData({
            answerlist: a
        }), this.isBigjudge(e), this.recordAnswer();
    },
    isBigjudge: function(t) {
        var e = this.data.answerlist, a = e[t], i = a.choose.length, s = !0;
        if (5 == a.type) {
            for (var o = 0; o < i; o++) if ("" == a.choose[o].choose) return;
            for (o = 0; o < i; o++) a.choose[o].isright != a.choose[o].choose && (s = !1);
        }
        if (6 == e[t].type || 7 == e[t].type) {
            for (o = 0; o < i; o++) if ("" == a.choose[o].userAnswer) return;
            for (o = 0; o < i; o++) a.choose[o].isright != a.choose[o].userAnswer && (s = !1);
        }
        e[t].isjudge = s ? 1 : 2, this.setData({
            answerlist: e
        });
    },
    bindShortAnswerBlur: function(t) {
        var e = this.data.answerlist;
        e[this.data.index].choose = t.detail.value, this.setData({
            answerlist: e
        });
    },
    pageScrollTo: function(t) {
        var e = wx.createSelectorQuery();
        e.selectViewport().scrollOffset(), e.select(t).boundingClientRect(), e.exec(function(t) {
            console.log(t), wx.pageScrollTo({
                scrollTop: t[0].scrollTop + t[1].top - 500,
                duration: 300
            });
        });
    },
    onReady: function() {
        var t = wx.createInnerAudioContext();
        this.setData({
            audioCtx: t
        });
    },
    onHide: function() {
        this.changepic(this.data.index), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
    },
    onUnload: function() {
        this.changepic(this.data.index), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
        var t = clearInterval(this.data.titleAudioTimer), e = clearInterval(this.data.analysisAudioTimer);
        this.setData({
            titleAudioTimer: t,
            analysisAudioTimer: e
        });
    },
    bindTextAreaBlur: function(t) {
        var e = t.currentTarget.dataset.index;
        t = t.detail.value;
        var a = this.data.answerlist;
        a[e].choose = t, a[e].issure = "" != t, this.setData({
            answerlist: a
        }), this.getAnswerlength();
    },
    goCorrection: function(e) {
        t.globalData.id = e.currentTarget.id, wx.navigateTo({
            url: "../feedback/feedback"
        });
    },
    goNotes: function(e) {
        t.globalData.id = e.currentTarget.id, wx.navigateTo({
            url: "../notes/notes"
        });
    },
    bindplay: function(t) {
        if (console.log(t), t = t.currentTarget.id, this.data.playIndex) {
            var e = wx.createVideoContext([ "index", this.data.playIndex ].join(""));
            e.seek(0), e.pause(), console.log([ "index", this.data.playIndex ].join("")), this.setData({
                playIndex: t
            }), console.log([ "index", this.data.playIndex ].join("")), wx.createVideoContext([ "index", this.data.playIndex ].join("")).play();
        } else this.setData({
            playIndex: t
        }), wx.createVideoContext([ "index", t ].join("")).play();
    },
    mockExam: function(a, i) {
        var s = this;
        this.setData({
            isloading: !0,
            fid: i
        }), console.log(t.globalData.noteTestId, "查看paperId");
        var o = "";
        t.globalData.paperId && (o = t.globalData.paperId), console.log(a), e.sequence({
            uid: wx.getStorageSync("uid"),
            typeId: i,
            son_type: this.data.sonType,
            op: a,
            paperid: o,
            notetestid: t.globalData.noteTestId
        }).then(function(t) {
            if (console.log(t), t.data.list.length <= 0) s.setData({
                have: t.data.have,
                isloading: !1
            }); else {
                var e = [], a = [], i = [], o = [], n = [], r = [];
                t.data.list && (t.data.list.forEach(function(t) {
                    if (1 == t.type || 3 == t.type || 8 == t.type) e.push({
                        type: t.type,
                        tid: t.id,
                        issure: !1,
                        choose: "",
                        isanalysis: !1,
                        isjudge: 3
                    }); else if (2 == t.type) {
                        var s = t.rightkey.split(","), d = [];
                        t.option.forEach(function(t) {
                            d.push({
                                o: t.o,
                                ischoose: !1
                            });
                        }), e.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            flag: !1,
                            choose: d,
                            isanalysis: !1,
                            isjudge: 3
                        }), t.option.forEach(function(t) {
                            -1 != s.indexOf(t.o) ? t.right = !0 : t.right = !1;
                        });
                    } else if (4 == t.type) {
                        for (var l = [], h = 0; h < t.rightarray.length; h++) l.push("");
                        e.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            choose: l,
                            iswrite: !1,
                            isanalysis: !1,
                            isjudge: 3
                        });
                    } else if (5 == t.type) {
                        var u = [], c = [];
                        t.list.forEach(function(t) {
                            u.push({
                                tid: t.id,
                                isright: t.rightkey,
                                choose: ""
                            }), c.push(t.rightkey);
                        }), t.rightkey = c.join(","), e.push({
                            type: t.type,
                            tid: t.id,
                            iscomplete: !1,
                            choose: u,
                            isanalysis: !1,
                            isjudge: 3
                        });
                    } else if (6 == t.type || 7 == t.type) {
                        var p = [];
                        l = t.list.map(function(t, e) {
                            return p.push(t.rightkey), {
                                tid: t.id,
                                isright: t.rightkey,
                                userAnswer: ""
                            };
                        }), t.rightkey = p.join(","), e.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            choose: l,
                            isanalysis: !1,
                            isDo: !1,
                            isjudge: 3
                        });
                    } else 8 == t.type && "" == t.uanswer && (t.uanswer = "暂未作答");
                    t.qaudio ? a.push({
                        audiosrc: t.qaudio,
                        time: 0
                    }) : a.push({
                        audiosrc: "",
                        time: 0
                    }), 2 == t.a_type ? i.push(t.option) : i.push(""), 4 == t.type ? o.push(t.rightarray.join(",")) : o.push(t.rightkey), 
                    t.analysis_audio ? n.push({
                        audiosrc: t.analysis_audio,
                        time: 0
                    }) : n.push({
                        audiosrc: "",
                        time: 0
                    }), r.push(t.aimage);
                }), console.log(t.data.list), t.data.list && s.setData({
                    paperdetail: t.data.list,
                    err_question: t.data.err_question,
                    answerlist: e,
                    audiolist: a,
                    rightAnswer: o,
                    answerAudiolist: n,
                    answerImglist: r
                }), console.log(e), t.data.last_id && s.setData({
                    index: Number(t.data.last_id)
                }), s.setData({
                    isloading: !1
                }), s.getAllAudioTime(), s.judgeShortAnswer(), s.wxParseTitle(s.data.index), s.getAllNotes(s.data.index));
            }
        }).catch(function(t) {
            s.setData({
                isloading: !1
            }), console.log(t);
        });
    },
    getAllAudioTime: function() {
        var t = [];
        this.data.paperdetail.forEach(function() {
            t.push({
                title: "00:00",
                analysis: "00:00"
            });
        }), this.setData({
            audioTimeList: t
        });
    },
    wxParseTitle: function(t) {
        t = this.data.paperdetail[t], a.wxParse("ParseTitle", "html", t.question, this, 5), 
        0 != t.a_type || 1 != t.type && 2 != t.type ? this.setData({
            isPageWait: !1
        }) : this.wxParseOptions(t.option);
    },
    wxParseOptions: function(t) {
        for (var e = 0; e < t.length; e++) a.wxParse("wxParseOption" + e, "html", t[e].p, this);
        this.setData({
            isPageWait: !1
        });
    },
    isempty: function(t) {
        var e;
        for (var a in new Boolean(), e = !0, t) t[a] || (e = !1);
        return !!e;
    },
    lookAnaiysis: function() {
        var t = this.data.answerlist, e = this.data.index;
        t[e].isanalysis || (t[e].isanalysis = !0, this.setData({
            answerlist: t
        }), console.log(this.data.paperdetail[e].analysis), a.wxParse("article", "html", this.data.paperdetail[e].analysis, this, 15), 
        console.log(this.data.article));
    },
    changepic: function(t) {
        2 != this.data.have && 0 != this.data.audiolist.length && (!this.data.audiolist[t].url || this.data.audiolist[t].url != this.data.audiolist[t - 1].url && 0 < t) && (this.setData({
            isaudio: 1,
            isAnalysisAudioPlay: 1
        }), this.data.audioCtx.pause());
    },
    myAudioStart: function(t) {
        var e = this.data.audioCtx, a = this, i = t.currentTarget.dataset.type;
        if (console.log("播放解析=" + i), "paper" == i) {
            var s = clearInterval(this.data.analysisAudioTimer);
            this.setData({
                isaudio: 2,
                isAnalysisAudioPlay: 1,
                analysisPlayTime: "00:00",
                analysisAudioTimer: s
            }), e.src = t.currentTarget.dataset.src, e.play(), this.currenttime(), this.data.onEnded || (this.data.onEnded = !0, 
            e.onEnded(function() {
                a.setData({
                    isaudio: 1,
                    currentTime: 0
                }), a.audiotime(t.currentTarget.dataset.src, 0);
            }));
            var o = t.currentTarget.dataset.num, n = a.data.audioTimeList, r = setInterval(function() {
                var t = Math.round(e.currentTime), i = Math.round(e.duration), s = a.handleTime(t), d = a.handleTime(i);
                n[o].title = d, a.setData({
                    titlePlayTime: s,
                    titleTotalTime: d,
                    audioTimeList: n,
                    titleAudioTimer: r
                }), i == t && (console.log("停止"), setTimeout(function() {
                    clearInterval(r), a.setData({
                        titlePlayTime: "00:00",
                        titleTotalTime: d,
                        titleAudioTimer: r
                    });
                }, 1e3));
            }, 1e3);
        }
        if ("analysis" == i) {
            i = clearInterval(this.data.titleAudioTimer), this.setData({
                isAnalysisAudioPlay: 2,
                isaudio: 1,
                titlePlayTime: "00:00",
                titleAudioTimer: i
            }), e.src = t.currentTarget.dataset.src, e.play(), this.currenttime(), this.data.onEnded || (this.data.onEnded = !0, 
            e.onEnded(function() {
                a.setData({
                    isAnalysisAudioPlay: 1,
                    currentTime: 0
                }), a.audiotime(t.currentTarget.dataset.src, 0);
            }));
            var d = t.currentTarget.dataset.num, l = a.data.audioTimeList, h = setInterval(function() {
                var t = Math.round(e.currentTime), i = Math.round(e.duration), s = a.handleTime(t), o = a.handleTime(i);
                l[d].analysis = o, a.setData({
                    analysisPlayTime: s,
                    analysisTotalTime: o,
                    audioTimeList: l,
                    analysisAudioTimer: h
                }), i == t && (console.log("停止"), setTimeout(function() {
                    clearInterval(h), a.setData({
                        analysisPlayTime: "00:00",
                        analysisTotalTime: o,
                        analysisAudioTimer: h
                    });
                }, 1e3));
            }, 1e3);
        }
    },
    myAudioPause: function(t) {
        var e = this.data.audioCtx, a = this;
        e.pause();
        var i = t.currentTarget.dataset.type;
        if (console.log("暂停解析=" + i), "paper" == i) {
            e.onPause(function() {
                e.currentTime, a.setData({
                    isaudio: 1
                }), a.audiotime(t.currentTarget.dataset.src, Math.floor(e.currentTime));
            });
            var s = clearInterval(a.data.titleAudioTimer);
            a.setData({
                titleAudioTimer: s
            });
        }
        "analysis" == i && e.onPause(function() {
            e.currentTime, a.setData({
                isAnalysisAudioPlay: 1
            }), a.audiotime(t.currentTarget.dataset.src, Math.floor(e.currentTime));
        });
    },
    handleTime: function(t) {
        if (60 <= t) {
            var e = parseInt(t / 60 % 60);
            return (e < 10 ? "0" + e : e) + ":" + ((t = parseInt(t % 60)) < 10 ? "0" + t : t);
        }
        return "00:" + (t < 10 ? "0" + t : t);
    },
    clearAudioTime: function() {
        var t = this.data.index, e = this.data.audioTimeList, a = e[t].title;
        t = e[t].analysis, clearInterval(this.data.titleAudioTimer), clearInterval(this.data.analysisAudioTimer), 
        this.setData({
            titlePlayTime: "00:00",
            titleTotalTime: a,
            analysisPlayTime: "00:00",
            analysisTotalTime: t
        });
    },
    currenttime: function(t) {
        var e = this.data.audioCtx;
        setTimeout(function() {
            e.currentTime, e.onTimeUpdate(function() {});
        }, 100);
    },
    audiotime: function(t, e) {
        this.data.audiolist.forEach(function(a) {
            a.audiosrc == t && (a.time = e);
        });
    },
    judge: function(t) {
        var e = this.data.answerlist, a = this.data.rightAnswer, i = "";
        if (2 == e[t].type) {
            var s = [];
            e[t].choose.forEach(function(t) {
                t.ischoose && s.push(t.o);
            }), i = s.join(",");
        } else 4 == e[t].type ? i = e[t].choose.join(",") : 1 != e[t].type && 3 != e[t].type || (i = e[t].choose);
        i && (e[t].isjudge = i == a[t] ? 1 : 2), this.setData({
            answerlist: e
        });
    },
    recordAnswer: function() {
        var a = this, i = this.data.answerlist, s = this.data.index, o = [], n = "";
        i.forEach(function(t) {
            if (1 == t.type || 3 == t.type) o.push({
                tid: t.tid,
                type: t.type,
                answer: t.choose
            }); else if (2 == t.type) {
                var e = [];
                t.choose.forEach(function(t) {
                    t.ischoose && e.push(t.o);
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: e
                });
            } else if (4 == t.type) {
                var a = [];
                t.choose.forEach(function(t) {
                    a.push("【" + t + "】");
                }), a = a.join(","), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: a
                });
            } else if (5 == t.type) {
                var i = [];
                t.choose.forEach(function(t) {
                    i.push({
                        tid: t.tid,
                        answer: t.choose
                    });
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: i
                });
            } else if (6 == t.type || 7 == t.type) {
                var s = [];
                t.choose.forEach(function(t) {
                    s.push({
                        tid: t.tid,
                        answer: t.userAnswer
                    });
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: s
                });
            }
        });
        var r = o[this.data.index].answer;
        2 == o.type ? a.setData({
            myanswer: r.join(",")
        }) : a.setData({
            myanswer: r
        });
        var d = "", l = "";
        "sequence" == t.globalData.op ? n = "shunxu" : "qhigh" == t.globalData.op ? n = "qhigh" : "intensive" == t.globalData.op ? n = "intensive" : "special" == t.globalData.op || "qspecial" == t.globalData.op ? (n = "qspecial", 
        d = this.data.special_id) : "qtype" == t.globalData.op || "qtype_submit" == t.globalData.op ? (n = "qtype_submit", 
        l = this.data.special_id) : n = "other", e.sequence_submit({
            uid: wx.getStorageSync("uid"),
            answerdata: JSON.stringify(o[this.data.index]),
            op: n,
            index: this.data.index,
            special_id: d,
            type_id: l
        }).then(function(t) {
            console.log(t), 4 == i[s].type && a.judgeCompletionItem();
        }).catch(function(t) {
            console.log(t);
        });
    },
    getAllNotes: function(t) {
        var a = this;
        if (t) var i = a.data.paperdetail[t].id; else i = a.data.paperdetail[a.data.index].id;
        e.getnotes({
            id: i,
            uid: wx.getStorageSync("uid"),
            status: "getallnotes"
        }).then(function(t) {
            console.log(t, "笔记"), a.setData({
                mynote: t.data.mynote,
                usernote: t.data.usernote,
                title: t.data.title
            }), console.log(t);
        }).catch(function(t) {
            console.log(t);
        });
    },
    notesCollect: function(t) {
        var a = t.currentTarget.dataset.id;
        console.log(a);
        var i = this;
        e.getnotes({
            uid: wx.getStorageSync("uid"),
            id: a,
            status: "notescollect"
        }).then(function(t) {
            "1002" == t.data ? (wx.showToast({
                title: "收藏成功",
                icon: "success",
                duration: 2e3
            }), i.getAllNotes()) : "1001" == t.data && (wx.showToast({
                title: "移出收藏",
                icon: "success",
                duration: 2e3
            }), i.getAllNotes());
        }).catch(function(t) {
            console.log(t);
        });
    },
    notesGoods: function(t) {
        var a = t.currentTarget.dataset.id;
        console.log(a);
        var i = this;
        e.getnotes({
            uid: wx.getStorageSync("uid"),
            id: a,
            status: "notesgoods"
        }).then(function(t) {
            ("1002" == t.data || "1001" == t.data) && i.getAllNotes();
        }).catch(function(t) {
            console.log(t);
        });
    },
    del: function(t) {
        var a = this, i = t.currentTarget.dataset.id;
        console.log(i), e.getnotes({
            id: i,
            status: "delnotes"
        }).then(function(t) {
            console.log(t), wx.showToast({
                title: "删除成功",
                icon: "success",
                duration: 2e3
            }), a.getAllNotes();
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        "" != this.data.paperdetail && this.getAllNotes();
    },
    onShareAppMessage: function() {
        return {
            path: "/pages/home/home"
        };
    }
});