var t = getApp(), o = require("../../provider/dataApi.js");

require("../../provider/pipe.js"), require("../../wxParse/wxParse.js");

Page({
    data: {
        lookcollect: !1
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    notesCollect: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log(e);
        var a = this;
        o.getnotes({
            uid: wx.getStorageSync("uid"),
            id: e,
            status: "notescollect"
        }).then(function(t) {
            "1002" == t.data ? (wx.showToast({
                title: "收藏成功",
                icon: "success",
                duration: 2e3
            }), a.getAllNotes()) : "1001" == t.data && (wx.showToast({
                title: "移出收藏",
                icon: "success",
                duration: 2e3
            }), a.getAllNotes());
        }).catch(function(t) {
            console.log(t);
        });
    },
    notesGoods: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log(e);
        var a = this;
        o.getnotes({
            uid: wx.getStorageSync("uid"),
            id: e,
            status: "notesgoods"
        }).then(function(t) {
            ("1002" == t.data || "1001" == t.data) && a.getAllNotes();
        }).catch(function(t) {
            console.log(t);
        });
    },
    del: function(t) {
        var e = this, a = t.currentTarget.dataset.id;
        o.getnotes({
            id: a,
            status: "delnotes"
        }).then(function(t) {
            wx.showToast({
                title: "删除成功",
                icon: "success",
                duration: 2e3
            }), e.getAllNotes();
        }).catch(function(t) {
            console.log(t);
        });
    },
    looktest: function(o) {
        var e = o.currentTarget.dataset.id;
        t.globalData.noteTestId = e, t.globalData.op = "goMyNotes", wx.navigateTo({
            url: "/pages/mynote/practice"
        });
    },
    lookCollect: function() {
        var t = this;
        t.setData({
            lookcollect: !t.data.lookcollect
        }), o.getnotes({
            uid: wx.getStorageSync("uid"),
            status: "lookCollect"
        }).then(function(o) {
            t.setData({
                collectnote: o.data.mynote,
                title: o.data.title
            }), console.log(o);
        }).catch(function(t) {
            console.log(t);
        });
    },
    onReady: function() {},
    getAllNotes: function(t) {
        var e = this;
        o.getnotes({
            uid: wx.getStorageSync("uid"),
            status: "getmynotes"
        }).then(function(t) {
            console.log(t, "笔记"), e.setData({
                mynote: t.data.mynote,
                title: t.data.title
            }), console.log(t);
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        this.getAllNotes(), this.setData({
            uid: wx.getStorageSync("uid")
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});