var t = require("../../provider/dataApi.js");

getApp();

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        pageData: "",
        canIUseGetUserProfile: !1
    },
    onLoad: function(t) {
        wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        });
        var e = this;
        wx.login({
            success: function(t) {
                var a = t.code;
                e.setData({
                    code: a
                });
            }
        }), this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        }), this.initWechat();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    initWechat: function() {
        var e = this;
        console.log(wx.getStorageSync("uid")), t.getBind({
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t.data.data), 0 == t.errno && e.setData({
                pageData: t.data.data,
                is_band: t.data.data.is_band
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getUserInfo: function() {
        console.log(this.data.code);
        var e = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.getUserInfo({
            success: function(a) {
                console.log(a), t.login({
                    code: e.data.code,
                    is_bind: 2,
                    encryptedData: a.encryptedData,
                    iv: a.iv
                }).then(function(t) {
                    console.log(t, "hahahah"), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    }), wx.setStorageSync("uid", t.data.uid), 0 == t.errno && e.initWechat();
                }).catch(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    getUserProfile: function() {
        var e = this;
        wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(a) {
                console.log(a), t.login({
                    code: e.data.code,
                    is_bind: 2,
                    encryptedData: a.encryptedData,
                    iv: a.iv
                }).then(function(t) {
                    console.log(t, "hahahah"), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    }), wx.setStorageSync("uid", t.data.uid), 0 == t.errno && e.initWechat();
                }).catch(function(t) {
                    console.log(t), wx.hideLoading(), wx.showToast({
                        title: t.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    goUntie: function() {
        wx.navigateTo({
            url: "../untieWechat/untieWechat"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});