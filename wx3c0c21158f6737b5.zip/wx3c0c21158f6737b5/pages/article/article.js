var t = getApp(), a = require("../../provider/dataApi.js"), i = require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        list: [],
        page: 1,
        pages: "",
        isInit: !1,
        playIndex: "",
        isdone: !0,
        isloading: !0,
        lt_list: [],
        lt_index: 0,
        rt_list: [],
        rt_index: 0,
        total: 0,
        psize: 0,
        isTitleType: !0
    },
    ltbindPickerChange: function(t) {
        var a = this;
        this.setData({
            lt_index: t.detail.value,
            page: 1
        });
        var i = this;
        this.data.lt_list.forEach(function(e) {
            e.id == a.data.lt_list[t.detail.value].id && i.setData({
                rt_list: a.data.lt_list[t.detail.value].son,
                rt_index: 0
            });
        }), this.article(this.data.lt_list[t.detail.value].id, this.data.rt_list[this.data.rt_index].id, !1);
    },
    rtbindPickerChange: function(t) {
        this.setData({
            rt_index: t.detail.value,
            page: 1
        }), this.article(this.data.lt_list[this.data.lt_index].id, this.data.rt_list[t.detail.value].id, !1);
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            windowHeight: wx.getSystemInfoSync().windowHeight
        }), this.getuserinfo(), this.atype();
    },
    onShow: function() {},
    goArticle: function(a) {
        t.globalData.id = a.currentTarget.dataset.id, wx.navigateTo({
            url: "../article-info/article-info?type=article&title=" + a.currentTarget.dataset.title
        });
    },
    getuserinfo: function() {
        a.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(t) {
            console.log(t), wx.setStorageSync("userinfo", t.data.info), wx.setStorageSync("http", t.data.http);
        }).catch(function(t) {
            console.log(t);
        });
    },
    bindplay: function(t) {
        if (console.log(t), t = t.currentTarget.id, this.data.playIndex) {
            var a = wx.createVideoContext([ "index", this.data.playIndex ].join(""));
            a.seek(0), a.pause();
        }
        this.setData({
            playIndex: t
        }), wx.createVideoContext([ "index", this.data.playIndex ].join("")).play(), this.readVideo(t);
    },
    onHide: function() {
        console.log("隐藏"), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
    },
    onUnload: function() {
        console.log("卸载"), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
    },
    lookmore: function() {
        var t = this;
        this.data.page <= Math.ceil(this.data.total / this.data.psize) && this.setData({
            page: this.data.page + 1,
            isInit: !0
        }), a.article({
            page: this.data.page,
            pcate: this.data.lt_list[this.data.lt_index].id,
            ccate: this.data.rt_list[this.data.rt_index].id
        }).then(function(a) {
            if (console.log(a), a.data.list) {
                a.data.list.forEach(function(t) {
                    t.time = i.formatDateTimehour(t.createtime), t.readnum = i.readingvolume(t.readnum);
                });
                var e = (e = t.data.list).concat(a.data.list);
                t.setData({
                    list: e,
                    total: a.data.total,
                    psize: a.data.psize
                });
            }
            t.setData({
                isInit: !1
            }), wx.stopPullDownRefresh();
        }).catch(function(a) {
            t.setData({
                isInit: !1
            }), wx.stopPullDownRefresh(), console.log(a);
        });
    },
    article: function(t, e, n) {
        var s = this;
        n && this.setData({
            isloading: !0
        }), a.article({
            page: 1,
            pcate: t,
            ccate: e
        }).then(function(t) {
            console.log(t), t.data.list && t.data.list.forEach(function(t) {
                t.time = i.formatDateTimehour(t.createtime), t.readnum = i.readingvolume(t.readnum);
            }), s.setData({
                list: t.data.list,
                pages: Math.ceil(t.data.total / t.data.psize),
                isloading: !1,
                total: t.data.total,
                psize: t.data.psize
            }), t.data.list.length <= 0 || !t.data ? s.setData({
                isdone: !0,
                isloading: !1
            }) : s.setData({
                isdone: !1,
                isloading: !1
            });
        }).catch(function(t) {
            s.setData({
                isloading: !1
            }), console.log(t);
        });
    },
    readVideo: function(t) {
        a.readVideo({
            uid: wx.getStorageSync("uid"),
            id: t
        }).then(function(t) {}).catch(function(t) {
            console.log(t);
        });
    },
    atype: function() {
        var t = this;
        a.atype({}).then(function(a) {
            console.log(a), t.setData({
                lt_list: a.data.list,
                rt_list: a.data.list[0].son
            }), t.article(a.data.list[0].id, a.data.list[0].son[0].id, !0);
        }).catch(function(a) {
            console.log(a), 1 == a.errno && t.setData({
                isTitleType: !1,
                isloading: !1,
                isdone: !0
            });
        });
    },
    onShareAppMessage: function() {}
});