var e = require("../../provider/dataApi.js");

getApp();

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        canIUse: wx.canIUse("button.open-type.getUserInfo"),
        phone: "",
        code: "",
        codeText: "获取验证码"
    },
    onLoad: function(e) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    getPhone: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    getCode: function(e) {
        this.setData({
            code: e.detail.value
        });
    },
    sendCode: function() {
        var t = this;
        /^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(this.data.phone) ? "获取验证码" == this.data.codeText || "重新发送" == this.data.codeText ? e.userinfo({
            phone: this.data.phone,
            op: "getcode"
        }).then(function(e) {
            t.setData({
                codeText: "60秒"
            });
            var o = 60, n = setInterval(function() {
                o--, t.setData({
                    codeText: o + "秒"
                }), o <= 0 && (t.setData({
                    codeText: "重新发送"
                }), clearInterval(n));
            }, 1e3);
        }).catch(function(e) {
            console.log(e), wx.showToast({
                icon: "none",
                title: e.message
            });
        }) : wx.showToast({
            icon: "none",
            title: "请不要重复发送~"
        }) : wx.showToast({
            icon: "none",
            title: "请输入正确的手机号~"
        });
    },
    goLogin: function() {
        console.log(this.data.phone), console.log(this.data.code);
        var t = this.data.phone, o = this.data.code;
        11 != t.length ? wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }) : "" == o ? wx.showToast({
            title: "请输入验证码",
            icon: "none"
        }) : wx.login({
            success: function(n) {
                n = n.code, console.log(n), e.phoneLogin({
                    code: n,
                    phone: t,
                    sms_code: o
                }).then(function(e) {
                    console.log(e), wx.showToast({
                        title: e.message,
                        icon: "none"
                    }), 0 == e.errno && (wx.setStorageSync("uid", e.data.uid), setTimeout(function() {
                        wx.reLaunch({
                            url: "/pages/home/home"
                        });
                    }, 1500));
                }).catch(function(e) {
                    console.log(e), wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    getUserInfo: function(t) {
        var o = this;
        t.detail.userInfo ? (wx.showLoading({
            title: "加载中..."
        }), wx.login({
            success: function(t) {
                var n = t.code;
                wx.getSetting({
                    success: function(t) {
                        t.authSetting["scope.userInfo"] && wx.getUserInfo({
                            success: function(t) {
                                e.login({
                                    code: n,
                                    iv: t.iv,
                                    is_band: 1
                                }).then(function(t) {
                                    wx.showToast({
                                        title: t.message,
                                        icon: "none"
                                    }), wx.setStorageSync("uid", t.data.uid), e.userinfo({
                                        uid: t.data.uid,
                                        op: "getinfo"
                                    }).then(function(e) {
                                        console.log(e), wx.setStorageSync("userinfo", e.data.info), console.log(e.data.info.phone), 
                                        wx.reLaunch({
                                            url: "/pages/home/home"
                                        });
                                    }).catch(function(e) {
                                        console.log(e);
                                    }), wx.hideLoading();
                                }).catch(function(e) {
                                    wx.hideLoading(), console.log(e), 1 == e.errno && wx.showToast({
                                        icon: "none",
                                        title: e.message
                                    });
                                }), o.userInfoReadyCallback && o.userInfoReadyCallback(t);
                            }
                        });
                    }
                });
            }
        })) : wx.showToast({
            title: "授权失败",
            icon: "none",
            duration: 2e3
        });
    },
    onShareAppMessage: function() {}
});