var t = getApp(), a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        phone: "",
        submitShow: !0,
        contentVal: "",
        textareaShow: !0
    },
    onLoad: function(a) {
        a = t.globalData.id, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            id: a
        }), this.list();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    list: function() {
        var t = this;
        a.getMyFeedBack({
            uid: wx.getStorageSync("uid"),
            op: "myfeedback"
        }).then(function(a) {
            console.log(a), t.setData({
                myList: a.data
            });
        }).catch(function(a) {
            console.log(a), t.setData({
                myList: ""
            });
        });
    },
    getPhone: function(t) {
        this.setData({
            phone: t.detail.value
        });
    },
    getCon: function(t) {
        this.setData({
            contentVal: t.detail.value
        });
    },
    goSubmit: function() {
        var t = this;
        this.data.contentVal.trim() ? a.feedback({
            tid: this.data.id,
            uid: wx.getStorageSync("uid"),
            content: this.data.contentVal
        }).then(function(a) {
            t.setData({
                textareaShow: !1
            }), t.list();
        }).catch(function(t) {
            console.log(t);
        }) : wx.showToast({
            icon: "none",
            title: "请输入内容~"
        });
    }
});