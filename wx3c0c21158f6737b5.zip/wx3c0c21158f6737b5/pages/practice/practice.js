var t = getApp(), a = require("../../provider/dataApi.js"), e = (require("../../provider/pipe.js"), 
require("../../wxParse/wxParse.js"));

require("../../we7/resource/js/util.js");

Page({
    data: {
        special_id: "",
        myanswer: "",
        rate_show: 0,
        ymshow: !1,
        videoShow: !1,
        showNone: !1,
        isAnalysisAudioPlay: 1,
        answerAudiolist: [],
        answerImglist: [],
        isfirstPlay: !0,
        have: 1,
        type: 1,
        startPoint: [ 0, 0 ],
        curPoint: [],
        statusBarHeight: "",
        titleBarHeight: "",
        show: !1,
        num: 0,
        note: "",
        isInit: !1,
        num_length: 0,
        remainder: 0,
        handpapershow: !1,
        item: {
            total_score: 100,
            pass_score: 60,
            paper_time: 90,
            highest: 0
        },
        timer: null,
        ruletime: "",
        durationtime: "",
        usetime: "",
        index: 0,
        paperdetail: "",
        answerlist: [],
        audiolist: [],
        answerlength: 0,
        isaudio: 1,
        inputHeight: 0,
        rightAnswer: [],
        isloading: !1,
        adInfo: {},
        ad_have: 2,
        userAnswerJudge: [],
        trialBool: !1,
        trialNum: "",
        isPageWait: !0,
        titlePlayTime: "00:00",
        titleTotalTime: "00:00",
        titleAudioTimer: null,
        analysisPlayTime: "00:00",
        analysisTotalTime: "00:00",
        analysisAudioTimer: null,
        audioTimeList: [],
        tabshow: !0,
        myNoteShow: !1,
        userNoteShow: !1,
        mynote: {},
        usernote: {},
        selectid: {},
        fid: "",
        fidselect: {},
        pwidth: "",
        pheight: "",
        err_question: "",
        allid: "",
        isShowShortAnswer: !1,
        param: "11111",
        boxShow: !1,
        percentage: 0,
        goShow: !1,
        collect_show: "2",
        currentid: 0,
        tabbar: [ "试题解析", "笔记讨论区", "记笔记" ],
        total: 0,
        psize: 0,
        page: 1,
        pages: "",
        swiperHeight: 150,
        one_2: 0,
        two_2: 3
    },
    level: function(e) {
        var i = this;
        a.getnotes({
            uid: wx.getStorageSync("uid"),
            testid: this.data.paperdetail[this.data.index].id,
            type: t.globalData.type,
            status: "level",
            one_2: this.data.one_2
        }).then(function(t) {
            console.log(t), i.see_level();
        }).catch(function(t) {
            console.log(t);
        });
    },
    close_video: function() {
        this.setData({
            videoShow: !1
        });
    },
    see_level: function() {
        var t = this;
        a.getnotes({
            uid: wx.getStorageSync("uid"),
            testid: this.data.paperdetail[this.data.index].id,
            status: "seelevel"
        }).then(function(a) {
            console.log(a);
            var e = t.data.paperdetail;
            1 == a.data.wrong_have && (e[t.data.index].wrong_have = 1, t.setData({
                paperdetail: e
            })), 1 == a.data.test_level && (e[t.data.index].test_level = 1, t.setData({
                paperdetail: e
            })), t.setData({
                one_2: a.data.light,
                two_2: a.data.black,
                already: !0
            });
        }).catch(function(a) {
            t.setData({
                one_2: 0,
                two_2: 3
            });
        });
    },
    previewImg: function(t) {
        var a = this.data.paperdetail[this.data.index].qimage;
        wx.previewImage({
            current: a[t.currentTarget.dataset.index],
            urls: a
        });
    },
    in_xin: function(t) {
        console.log(t);
        var a, e = t.currentTarget.dataset.in;
        a = "star" == e ? Number(t.currentTarget.id) : Number(t.currentTarget.id) + this.data.one_2, 
        this.setData({
            one_2: a,
            two_2: 3 - a
        });
    },
    getElementHeight: function() {
        var t = wx.createSelectorQuery(), a = this;
        t.select(".getHeight").boundingClientRect(), t.exec(function(t) {
            a.setData({
                height: t[0].height
            });
        });
    },
    swichNav: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            currentid: a
        }), this.tabAnimation(this.data.currentid);
    },
    handleCategoryChange: function(t) {
        this.setData({
            currentid: t.detail.current
        }), this.tabAnimation(t.detail.current);
    },
    tabAnimation: function(a) {
        var e = this, i = t.globalData, s = i.screenWidth, o = i.rpx, n = (i.px, wx.createAnimation({
            duration: 200
        })), r = (s - 64 * o) / 3;
        n.left(r * (Number(a) + 1) - r / 2 + 20 * o).step(), this.setData({
            tabAnimation: n
        }, function() {
            wx.createSelectorQuery().in(e).select(".item" + a).boundingClientRect(function(t) {
                if (t) {
                    var a = t.height;
                    e.setData({
                        swiperHeight: a
                    });
                }
            }).exec();
        });
    },
    tabshow: function() {
        this.setData({
            tabshow: !0,
            myNoteShow: !1,
            userNoteShow: !1
        });
    },
    myNoteShow: function() {
        this.setData({
            tabshow: !1,
            myNoteShow: !0,
            userNoteShow: !1
        });
    },
    userNoteShow: function() {
        this.setData({
            tabshow: !1,
            myNoteShow: !1,
            userNoteShow: !0
        });
    },
    wrong_del: function(t) {
        var e = this, i = t.currentTarget.dataset.id;
        a.getnotes({
            uid: wx.getStorageSync("uid"),
            testid: i,
            status: "wrongdel"
        }).then(function(t) {
            wx.showToast({
                title: "已移出",
                icon: "success",
                duration: 2e3
            }), e.data.index + 1 == e.data.paperdetail.length ? wx.navigateBack({
                delta: 1
            }) : e.goDown();
        }).catch(function(t) {
            wx.showModal({
                title: "提示",
                content: "该错题回答正确，已自动移出",
                success: function(t) {
                    t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
                }
            }), console.log(t);
        });
    },
    previewImgJx: function(t) {
        var a = this.data.paperdetail[this.data.index].aimage;
        wx.previewImage({
            current: a[t.currentTarget.dataset.index],
            urls: a
        });
    },
    mytouchstart: function(t) {
        this.setData({
            startPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchmove: function(t) {
        this.setData({
            curPoint: [ t.touches[0].pageX, t.touches[0].pageY ]
        });
    },
    mytouchend: function(t) {
        t.changedTouches[0].pageX - this.data.startPoint[0] < 0 ? this.data.index + 1 < this.data.paperdetail.length && this.setData({
            index: this.data.index + 1
        }) : 0 < this.data.index && this.setData({
            index: this.data.index - 1
        });
    },
    goType: function(t) {
        var a = t.currentTarget.dataset.type;
        this.setData({
            type: a
        }), 2 == a && this.lookAnaiysis(), this.tabAnimation(this.data.currentid);
    },
    onLoad: function(a) {
        var e = this;
        if (wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    clientHeight: t.windowHeight
                });
            }
        }), a.knowledge_test && this.setData({
            knowledge_test: a.knowledge_test
        }), console.log(t.globalData.title, "查看op"), this.setData({
            op: t.globalData.op,
            knowledge_test: a.knowledge_test,
            lid: t.globalData.id,
            groupid: t.globalData.groupid,
            head_title: t.globalData.title,
            userinfo: wx.getStorageSync("userinfo")
        }), 1 == wx.getStorageSync("userinfo").night ? this.setData({
            background: "#1b1b1b",
            color: "#0B5A26",
            fontcolor: "#999",
            kbackground: "#2d2d2d",
            borderColor: "#000",
            vBackground: "#000",
            linecolor: "#2d2d2d",
            noteLineColor: "#000"
        }) : this.setData({
            borderColor: "#f2f1f6",
            vBackground: "#f2f1f6",
            linecolor: "#e0e0e0",
            noteLineColor: "#eee"
        }), this.alltest(), this.testRecord(), wx.getStorageSync("uid")) {
            if (this.setData({
                statusBarHeight: getApp().globalData.statusBarHeight,
                titleBarHeight: getApp().globalData.titleBarHeight,
                pheight: wx.getSystemInfoSync().windowHeight,
                pwidth: wx.getSystemInfoSync().windowWidth
            }), "{}" != JSON.stringify(a)) {
                var i = "";
                a.sonType && (i = a.sonType), this.setData({
                    trialNum: a.num,
                    trialBool: !0,
                    sonType: i
                });
            }
            a = t.globalData.op, console.log(t.globalData.id), t.globalData.id ? (8 != t.globalData.id || "simple_type" != t.globalData.op && "qtype" != t.globalData.op || this.setData({
                isShowShortAnswer: !0
            }), i = t.globalData.id, this.mockExam(a, i), this.setData({
                special_id: i
            })) : this.mockExam(a, "");
        } else wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    count: function(e) {
        console.log(e);
        var i = this;
        a.docount({
            uid: wx.getStorageSync("uid"),
            id: e,
            op: t.globalData.op
        }).then(function(t) {
            console.log(t.data.isset.testid, "查看进度条");
            JSON.parse(t.data.isset.testid);
            var a = t.data.count, e = (i.data.index + 1) / a * 100;
            console.log(e, i.data.index, "查看special_per"), i.setData({
                docount: JSON.parse(t.data.isset.testid),
                special_per: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    testRecord: function() {
        var t = this;
        a.testRecord({
            uid: wx.getStorageSync("uid")
        }).then(function(a) {
            console.log(a, "查看testrecord");
            var e = JSON.parse(a.data.testid);
            t.setData({
                fidselect: e,
                selectid: JSON.parse(a.data.selectid)
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    queryAd: function() {
        var t = this;
        a.advert({
            op: "second"
        }).then(function(a) {
            t.setData({
                adInfo: a.data.info,
                ad_have: a.data.ad_have
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    showTk: function() {
        if (100 < this.data.paperdetail) {
            var t = Math.floor(this.data.paperdetail.length / 100), a = this.data.paperdetail.length % 100;
            console.log(t, a), this.setData({
                num: 100,
                num_length: t,
                remainder: a
            });
        } else this.setData({
            num: this.data.paperdetail
        });
        this.setData({
            show: !0
        });
    },
    onClose: function() {
        this.setData({
            show: !1
        });
    },
    goUp: function() {
        if (console.log(this.data.index, this.data.answerlist, "查看"), 0 == this.data.index) return !1;
        this.setData({
            index: this.data.index - 1,
            videoShow: !1
        }), 3 != this.data.answerlist[this.data.index].isjudge ? this.setData({
            currentid: 0,
            rate_show: 1,
            goShow: !0
        }) : this.setData({
            currentid: 0,
            rate_show: 0,
            goShow: !1
        });
        var a = {};
        if (this.setData((a["answerlist[" + (this.data.index + 1) + "].isanalysis"] = !1, 
        a.isPageWait = !0, a)), this.judgeShortAnswer(), this.changepic(this.data.index), 
        this.initUserAnswer(this.data.index), this.recordAnswer(), this.getUserNotes(), 
        this.getMyNotes(), this.wxParseTitle(this.data.index), this.clearAudioTime(), this.lookAnaiysis(), 
        this.see_level(), "randoms" == t.globalData.op) {
            var e = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            this.setData({
                randoms_per: e
            });
        } else if ("special" == t.globalData.op) {
            var i = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            this.setData({
                special_per: i
            });
        } else if ("sequence" == t.globalData.op) {
            var s = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            this.setData({
                sequence_per: s
            });
        }
    },
    goDown: function() {
        if (console.log(this.data.answerlist), this.data.trialBool) {
            var a = this.data.trialNum;
            if (this.data.index + 1 >= a) return wx.showToast({
                title: "本套试题只能试答" + a + "题哦~",
                icon: "none"
            }), !1;
        }
        if (this.data.index + 1 >= this.data.paperdetail.length) return this.setData({
            boxShow: !0
        }), !1;
        if (console.log(this.data.answerlist, "查看answerlist"), 3 != this.data.answerlist[this.data.index + 1].isjudge ? this.setData({
            currentid: 0,
            rate_show: 1,
            goShow: !0
        }) : this.setData({
            currentid: 0,
            rate_show: 0,
            goShow: !1
        }), this.setData({
            index: this.data.index + 1,
            isPageWait: !0,
            videoShow: !1
        }), a = {}, this.setData((a["answerlist[" + (this.data.index - 1) + "].isanalysis"] = !1, 
        a)), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.getUserNotes(), this.getMyNotes(), this.wxParseTitle(this.data.index), this.clearAudioTime(), 
        this.see_level(), 3 != this.data.answerlist[this.data.index].isjudge && (this.recordAnswer(), 
        this.lookAnaiysis()), "randoms" == t.globalData.op) {
            var e = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            console.log(this.data.index, "查看"), this.setData({
                randoms_per: e
            });
        } else if ("special" == t.globalData.op) {
            var i = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            console.log(this.data.index, "查看"), this.setData({
                special_per: i
            });
        } else if ("sequence" == t.globalData.op) {
            var s = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            this.setData({
                sequence_per: s
            });
        }
    },
    gobUp: function() {
        if (this.setData({
            currentid: 0,
            videoShow: !1
        }), 0 == this.data.index) return !1;
        this.setData({
            index: this.data.index - 1
        });
        var t = {};
        this.setData((t["answerlist[" + (this.data.index + 1) + "].isanalysis"] = !1, t.isPageWait = !0, 
        t)), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.recordAnswer(), this.getUserNotes(), this.getMyNotes(), this.wxParseTitle(this.data.index), 
        this.clearAudioTime(), console.log(t, "查看解析");
    },
    gobDown: function() {
        if (this.setData({
            currentid: 0,
            videoShow: !1
        }), this.data.trialBool) {
            var t = this.data.trialNum;
            if (this.data.index + 1 >= t) return wx.showToast({
                title: "本套试题只能试答" + t + "题哦~",
                icon: "none"
            }), !1;
        }
        if (this.data.index + 1 >= this.data.paperdetail.length) return this.setData({
            boxShow: !0
        }), !1;
        this.setData({
            index: this.data.index + 1,
            isPageWait: !0,
            rate_show: 0
        }), t = {}, this.setData((t["answerlist[" + (this.data.index - 1) + "].isanalysis"] = !1, 
        t)), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.getUserNotes(), this.getMyNotes(), this.wxParseTitle(this.data.index), this.clearAudioTime(), 
        console.log(t, "查看解析");
    },
    boxshow: function() {
        this.setData({
            boxShow: !1
        });
    },
    video_play: function(t) {
        var a = t.currentTarget.dataset.src;
        this.setData({
            video_url: a,
            videoShow: !0
        });
    },
    alltest: function() {
        var e = this;
        a.alltest({
            uid: wx.getStorageSync("uid"),
            type: t.globalData.type,
            shuati_type: t.globalData.shuati_type,
            types: t.globalData.types,
            classType: t.globalData.classType
        }).then(function(t) {
            console.log(t, "查看所有id"), e.setData({
                allid: t.data.allid,
                freenum: t.data.freenum
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    finish: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    next: function() {
        for (var a = 0; a < this.data.allid.length; a++) if (this.data.allid[a].id == this.data.special_id) {
            var e = this.data.allid[a + 1];
            0 == e.is_can ? (t.globalData.id = e.id, wx.redirectTo({
                url: "../practice/practice"
            })) : 2 == e.is_can ? wx.showModal({
                title: "提示",
                content: "该题库为学员专项题库，您暂无权限刷题",
                success: function(t) {
                    t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
                }
            }) : 1 == e.is_can && (t.globalData.id = e.id, wx.redirectTo({
                url: "../practice/practice?num=" + this.data.freenum
            })), console.log(e, "查看是否正确");
        }
    },
    jumptap: function(a) {
        if (this.data.trialBool) {
            var e = a.currentTarget.dataset.i;
            if (console.log(e), e >= this.data.trialNum) return wx.showToast({
                title: "此为试答，如想答剩下的题请先去购买此套试卷哦",
                icon: "none"
            }), !1;
        }
        if (3 != this.data.answerlist[a.currentTarget.dataset.i].isjudge ? this.setData({
            currentid: 0,
            rate_show: 1,
            goShow: !0
        }) : this.setData({
            tabshow: !0,
            myNoteShow: !1,
            userNoteShow: !1,
            rate_show: 0,
            goShow: !1
        }), this.setData({
            index: a.currentTarget.dataset.i,
            videoShow: !1,
            show: !1,
            isPageWait: !0
        }), this.judgeShortAnswer(), this.changepic(this.data.index), this.initUserAnswer(this.data.index), 
        this.wxParseTitle(this.data.index), this.clearAudioTime(), this.see_level(), this.getUserNotes(), 
        this.getMyNotes(), 3 != this.data.answerlist[this.data.index].isjudge && (this.recordAnswer(), 
        this.lookAnaiysis()), "randoms" == t.globalData.op) {
            var i = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            console.log(this.data.index, "查看"), this.setData({
                randoms_per: i
            });
        } else if ("special" == t.globalData.op) {
            var s = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            console.log(this.data.index, "查看"), this.setData({
                special_per: s
            });
        } else if ("sequence" == t.globalData.op) {
            var o = ((this.data.index + 1) / this.data.paperdetail.length * 100).toFixed(2);
            this.setData({
                sequence_per: o
            });
        }
    },
    judgeShortAnswer: function() {
        this.data.isShowShortAnswer;
        2 == this.data.type && this.lookAnaiysis();
    },
    initUserAnswer: function(t) {
        if (4 == (a = this.data.paperdetail)[t].type) {
            t = a[t].rightarray;
            for (var a = [], e = 0; e < t.length; e++) a.push(!0);
            this.setData({
                userAnswerJudge: a
            });
        }
    },
    scrolltolower: function(t) {
        this.data.num < this.data.paperdetail.length && (Math.floor(this.data.num / 100) == this.data.num_length ? this.setData({
            num: this.data.num + this.data.remainder
        }) : this.setData({
            num: this.data.num + 100
        }));
    },
    addWrong: function() {
        var e = this;
        a.addWrong({
            uid: wx.getStorageSync("uid"),
            tid: this.data.paperdetail[this.data.index].id,
            test_type: this.data.paperdetail[this.data.index].type,
            wrong_have: this.data.paperdetail[this.data.index].wrong_have,
            type: t.globalData.type
        }).then(function(t) {
            var a = "paperdetail[" + e.data.index + "].wrong_have";
            1 == t.data ? (wx.showToast({
                title: "已加入收藏",
                icon: "none"
            }), t = {}, e.setData((t[a] = 1, t))) : (wx.showToast({
                title: "已移出收藏",
                icon: "none"
            }), t = {}, e.setData((t[a] = 2, t)));
        }).catch(function(t) {
            console.log(t);
        });
    },
    choice: function(t) {
        var a = this.data.answerlist, e = 0;
        this.setData({
            goShow: !0,
            currentid: 0
        }), this.tabAnimation(0), a[t.currentTarget.dataset.fjtit].choose = t.currentTarget.dataset.option, 
        a.forEach(function(t) {
            2 == t.type ? t.flag && e++ : 4 == t.type ? t.issure && e++ : 5 == t.type ? t.iscomplete && e++ : t.choose && e++;
        }), this.setData({
            answerlist: a,
            answerlength: e,
            rate_show: 1
        }), this.judge(this.data.index), this.recordAnswer(), this.lookAnaiysis();
    },
    multipleChoice: function(t) {
        var a = t.currentTarget.dataset.fjtit, e = t.currentTarget.dataset.option;
        t = this.data.answerlist;
        var i = 0, s = 0;
        t[a].choose.forEach(function(t, a) {
            t.o == e && (t.ischoose = !t.ischoose);
        });
        for (var o = 0; o < t[a].choose.length; o++) {
            if (t[a].choose[o].ischoose) {
                i = 1, t[a].flag = !1;
                break;
            }
            i = 0, t[a].flag = !1;
        }
        t.forEach(function(t) {
            2 == t.type ? t.flag && s++ : 4 == t.type ? t.issure && s++ : 5 == t.type ? t.iscomplete && s++ : t.choose && s++;
        }), t[a].flag = 1 == i, this.setData({
            answerlength: s + i,
            answerlist: t
        }), console.log();
    },
    gomultipleChoice: function(t) {
        this.setData({
            goShow: !0,
            currentid: 0
        }), this.tabAnimation(0);
        var a = t.currentTarget.dataset.fjtit, e = this.data.answerlist, i = t.currentTarget.dataset.item, s = [];
        e[a].choose.forEach(function(t) {
            t.ischoose && s.push(t.o);
        }), (s = s.join(",")) == i.rightkey && (e[a].isright = !0), 0 < s.length ? (e[a].issure = !0, 
        i.rightkey = i.rightkey.split(","), e[a].choose.forEach(function(t) {
            t.ischoose ? -1 != i.rightkey.indexOf(t.o) ? t.ischooseright = 1 : -1 == i.rightkey.indexOf(t.o) && (t.ischooseright = 2) : -1 != i.rightkey.indexOf(t.o) ? t.ischooseright = 3 : -1 == i.rightkey.indexOf(t.o) && (t.ischooseright = 4);
        }), this.setData({
            answerlist: e,
            rate_show: 1
        }), this.judge(this.data.index), this.recordAnswer(), this.lookAnaiysis()) : wx.showToast({
            icon: "none",
            title: "请选择你的答案~"
        });
    },
    fidselect: function() {
        console.log(this.data.fidselect, "查看最后的");
        var t = JSON.stringify(this.data.fidselect);
        a.fidselect({
            uid: wx.getStorageSync("uid"),
            fidselect: t,
            selectid: JSON.stringify(this.data.selectid)
        }).then(function(t) {
            console.log("成功了吗hahhhhah");
        }).catch(function(t) {
            console.log(t);
        });
    },
    textInput: function(t) {
        var a = t.currentTarget.dataset.fjnum, e = this.data.answerlist;
        e[a].choose[t.currentTarget.dataset.inputnum] = t.detail.value;
        var i = 0;
        this.isempty(e[a].choose) ? e[a].issure = !0 : e[a].issure = !1, e.forEach(function(t) {
            2 == t.type ? t.flag && i++ : 4 == t.type ? t.issure && i++ : 5 == t.type ? t.iscomplete && i++ : t.choose && i++;
        }), this.setData({
            answerlist: e,
            answerlength: i
        });
    },
    goSure: function(t) {
        this.setData({
            goShow: !0,
            currentid: 0
        }), this.tabAnimation(0), t = t.currentTarget.dataset.fjnum;
        var a = this.data.answerlist;
        a[t] && this.isempty(a[t].choose) ? (a[t].iswrite = !0, this.setData({
            answerlist: a,
            rate_show: 1
        }), this.judge(this.data.index), this.recordAnswer(), this.lookAnaiysis()) : wx.showToast({
            icon: "none",
            title: "请填写完整~"
        });
    },
    judgeCompletionItem: function() {
        for (var t = this.data.index, a = this.data.paperdetail[t].rightkey.split("|"), e = this.data.answerlist[t].choose, i = (t = [], 
        a = a.map(function(t) {
            return t.replace(/\u3011\u3010/g, "】,【");
        }).map(function(t) {
            return t.split(",");
        }), e = e.map(function(t) {
            return "【" + t + "】";
        }), 0); i < e.length; i++) {
            for (var s = !1, o = 0; o < a.length; o++) e[i] == a[o][i] && (s = !0);
            t.push(s);
        }
        this.setData({
            userAnswerJudge: t
        });
    },
    vioceChoice: function(t) {
        var a = t.currentTarget.dataset.fjnum, e = this.data.answerlist, i = 0, s = {};
        this.setData((s["answerlist[" + a + "].choose[" + t.currentTarget.dataset.zjnum + "].choose"] = t.currentTarget.dataset.option, 
        s)), this.isempty(e[a].choose) ? e[a].iscomplete = !0 : e[a].iscomplete = !1, e.forEach(function(t) {
            2 == t.type ? t.flag && i++ : 4 == t.type ? t.issure && i++ : 5 == t.type ? t.iscomplete && i++ : t.choose && i++;
        }), this.setData({
            answerlist: e,
            answerlength: i
        }), this.isBigjudge(a), this.recordAnswer();
    },
    chooseOption: function(t) {
        var a = this.data.index, e = this.data.answerlist;
        e[a].choose[t.currentTarget.dataset.findex].userAnswer = t.currentTarget.dataset.zindex, 
        console.log(e[a].choose), this.setData({
            answerlist: e,
            rate_show: 1
        }), this.isBigjudge(a), this.recordAnswer();
    },
    isBigjudge: function(t) {
        var a = this.data.answerlist, e = a[t], i = e.choose.length, s = !0;
        if (5 == e.type) {
            for (var o = 0; o < i; o++) if ("" == e.choose[o].choose) return;
            for (o = 0; o < i; o++) e.choose[o].isright != e.choose[o].choose && (s = !1);
        }
        if (6 == a[t].type || 7 == a[t].type) {
            for (o = 0; o < i; o++) if ("" == e.choose[o].userAnswer) return;
            for (o = 0; o < i; o++) e.choose[o].isright != e.choose[o].userAnswer && (s = !1);
        }
        a[t].isjudge = s ? 1 : 2, this.setData({
            answerlist: a
        });
    },
    bindShortAnswerBlur: function(t) {
        var a = this.data.answerlist;
        a[this.data.index].choose = t.detail.value, this.setData({
            answerlist: a
        });
    },
    shortAnswerSure: function(t) {
        this.setData({
            goShow: !0,
            currentid: 0
        }), this.tabAnimation(0);
        var a = this.data.index;
        t = this.data.answerlist;
        this.lookAnaiysis(), t[a].isanalysis = !0, t[a].issure = !0, t[a].isjudge = 1, this.setData({
            answerlist: t,
            rate_show: 1
        }), this.pageScrollTo("#analysis"), this.recordAnswer();
    },
    pageScrollTo: function(t) {
        var a = wx.createSelectorQuery();
        a.selectViewport().scrollOffset(), a.select(t).boundingClientRect(), a.exec(function(t) {
            wx.pageScrollTo({
                scrollTop: t[0].scrollTop + t[1].top - 500,
                duration: 300
            });
        });
    },
    onReady: function() {
        var t = wx.createInnerAudioContext();
        this.setData({
            audioCtx: t
        });
    },
    onHide: function() {
        this.changepic(this.data.index), wx.createVideoContext([ "index", this.data.playIndex ].join("")).pause();
    },
    bindTextAreaBlur: function(t) {
        var a = t.currentTarget.dataset.index;
        t = t.detail.value;
        var e = this.data.answerlist;
        e[a].choose = t, e[a].issure = "" != t, this.setData({
            answerlist: e
        }), this.getAnswerlength();
    },
    goCorrection: function(a) {
        t.globalData.id = a.currentTarget.id, wx.navigateTo({
            url: "../feedback/feedback"
        });
    },
    goNotes: function(a) {
        t.globalData.id = a.currentTarget.id, t.globalData.type = t.globalData.type, wx.navigateTo({
            url: "../notes/notes"
        });
    },
    bindplay: function(t) {
        if (console.log(t), t = t.currentTarget.id, this.data.playIndex) {
            var a = wx.createVideoContext([ "index", this.data.playIndex ].join(""));
            a.seek(0), a.pause(), console.log([ "index", this.data.playIndex ].join("")), this.setData({
                playIndex: t
            }), console.log([ "index", this.data.playIndex ].join("")), wx.createVideoContext([ "index", this.data.playIndex ].join("")).play();
        } else this.setData({
            playIndex: t
        }), wx.createVideoContext([ "index", t ].join("")).play();
    },
    mockExam: function(e, i) {
        console.log(t.globalData.type, "chakantype");
        var s = this;
        this.setData({
            isloading: !0,
            fid: i
        });
        var o = "";
        t.globalData.paperId && (o = t.globalData.paperId), console.log(e), a.sequence({
            uid: wx.getStorageSync("uid"),
            typeId: i,
            son_type: this.data.sonType,
            op: e,
            random_status: this.data.userinfo.random_status,
            type: t.globalData.type,
            groupid: JSON.stringify(this.data.groupid),
            paperid: o
        }).then(function(a) {
            console.log(a, "查看列表");
            var e = (1 / a.data.list.length * 100).toFixed(2), i = ((Number(a.data.last_id) + 1) / a.data.list.length * 100).toFixed(2);
            if (a.data.title) var o = a.data.title; else if (t.globalData.title) o = t.globalData.title; else o = "";
            if (s.setData({
                param: a.data.param
            }), a.data.list.length <= 0) s.setData({
                have: a.data.have,
                isloading: !1,
                showNone: !0
            }); else {
                var n = [], r = [], d = [], l = [], h = [], c = [];
                a.data.list && (a.data.list.forEach(function(t) {
                    if (1 == t.type || 3 == t.type || 8 == t.type) n.push({
                        type: t.type,
                        tid: t.id,
                        issure: !1,
                        choose: "",
                        isanalysis: !1,
                        isjudge: 3
                    }); else if (2 == t.type) {
                        var a = t.rightkey.split(","), e = [];
                        t.option.forEach(function(t) {
                            e.push({
                                o: t.o,
                                ischoose: !1
                            });
                        }), n.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            flag: !1,
                            choose: e,
                            isanalysis: !1,
                            isjudge: 3
                        }), t.option.forEach(function(t) {
                            -1 != a.indexOf(t.o) ? t.right = !0 : t.right = !1;
                        });
                    } else if (4 == t.type) {
                        for (var i = [], s = 0; s < t.rightarray.length; s++) i.push("");
                        n.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            choose: i,
                            iswrite: !1,
                            isanalysis: !1,
                            isjudge: 3
                        });
                    } else if (5 == t.type) {
                        var o = [], u = [];
                        t.list.forEach(function(t) {
                            o.push({
                                tid: t.id,
                                isright: t.rightkey,
                                choose: ""
                            }), u.push(t.rightkey);
                        }), t.rightkey = u.join(","), n.push({
                            type: t.type,
                            tid: t.id,
                            iscomplete: !1,
                            choose: o,
                            isanalysis: !1,
                            isjudge: 3
                        });
                    } else if (6 == t.type || 7 == t.type) {
                        var g = [];
                        i = t.list.map(function(t, a) {
                            return g.push(t.rightkey), {
                                tid: t.id,
                                isright: t.rightkey,
                                userAnswer: ""
                            };
                        }), t.rightkey = g.join(","), n.push({
                            type: t.type,
                            tid: t.id,
                            issure: !1,
                            choose: i,
                            isanalysis: !1,
                            isDo: !1,
                            isjudge: 3
                        });
                    } else 8 == t.type && "" == t.uanswer && (t.uanswer = "暂未作答");
                    t.qaudio ? r.push({
                        audiosrc: t.qaudio,
                        time: 0
                    }) : r.push({
                        audiosrc: "",
                        time: 0
                    }), 2 == t.a_type ? d.push(t.option) : d.push(""), 4 == t.type ? l.push(t.rightarray.join(",")) : l.push(t.rightkey), 
                    t.analysis_audio ? h.push({
                        audiosrc: t.analysis_audio,
                        time: 0
                    }) : h.push({
                        audiosrc: "",
                        time: 0
                    }), c.push(t.aimage);
                }), console.log(e, "haha"), a.data.list && s.setData({
                    paperdetail: a.data.list,
                    err_question: a.data.err_question,
                    randoms_per: e,
                    sequence_per: i,
                    answerlist: n,
                    audiolist: r,
                    rightAnswer: l,
                    answerAudiolist: h,
                    answerImglist: c,
                    showNone: !1,
                    head_title: o
                }), a.data.last_id && s.setData({
                    index: Number(a.data.last_id)
                }), s.setData({
                    isloading: !1
                }), s.getAllAudioTime(), s.judgeShortAnswer(), s.wxParseTitle(s.data.index)), s.getUserNotes(), 
                s.getMyNotes(), s.count(t.globalData.id), s.see_level();
            }
        }).catch(function(t) {
            s.setData({
                isloading: !1,
                showNone: !0
            }), console.log(t);
        });
    },
    getAllAudioTime: function() {
        var t = [];
        this.data.paperdetail.forEach(function() {
            t.push({
                title: "00:00",
                analysis: "00:00"
            });
        }), this.setData({
            audioTimeList: t
        });
    },
    wxParseTitle: function(t) {
        t = this.data.paperdetail[t], e.wxParse("ParseTitle", "html", t.question, this, 5), 
        0 != t.a_type || 1 != t.type && 2 != t.type ? this.setData({
            isPageWait: !1
        }) : this.wxParseOptions(t.option);
    },
    wxParseOptions: function(t) {
        for (var a = 0; a < t.length; a++) e.wxParse("wxParseOption" + a, "html", t[a].p, this);
        this.setData({
            isPageWait: !1
        });
    },
    isempty: function(t) {
        var a;
        for (var e in new Boolean(), a = !0, t) t[e] || (a = !1);
        return !!a;
    },
    lookAnaiysis: function() {
        var t = this.data.answerlist, a = this.data.index;
        t[a].isanalysis || (t[a].isanalysis = !0, this.setData({
            answerlist: t
        }), console.log(this.data.paperdetail[a].analysis), e.wxParse("article", "html", this.data.paperdetail[a].analysis, this, 15), 
        console.log(this.data.article));
    },
    changepic: function(t) {
        2 != this.data.have && 0 != this.data.audiolist.length && (!this.data.audiolist[t].url || this.data.audiolist[t].url != this.data.audiolist[t - 1].url && 0 < t) && (this.setData({
            isaudio: 1,
            isAnalysisAudioPlay: 1
        }), this.data.audioCtx.pause());
    },
    myAudioStart: function(t) {
        var a = this.data.audioCtx, e = this, i = t.currentTarget.dataset.type;
        if (console.log("播放解析=" + i), "paper" == i) {
            var s = clearInterval(this.data.analysisAudioTimer);
            this.setData({
                isaudio: 2,
                isAnalysisAudioPlay: 1,
                analysisPlayTime: "00:00",
                analysisAudioTimer: s
            }), a.src = t.currentTarget.dataset.src, a.play(), this.currenttime(), this.data.onEnded || (this.data.onEnded = !0, 
            a.onEnded(function() {
                e.setData({
                    isaudio: 1,
                    currentTime: 0
                }), e.audiotime(t.currentTarget.dataset.src, 0);
            }));
            var o = t.currentTarget.dataset.num, n = e.data.audioTimeList, r = setInterval(function() {
                var t = Math.round(a.currentTime), i = Math.round(a.duration), s = e.handleTime(t), d = e.handleTime(i);
                n[o].title = d, e.setData({
                    titlePlayTime: s,
                    titleTotalTime: d,
                    audioTimeList: n,
                    titleAudioTimer: r
                }), i == t && (console.log("停止"), setTimeout(function() {
                    clearInterval(r), e.setData({
                        titlePlayTime: "00:00",
                        titleTotalTime: d,
                        titleAudioTimer: r
                    });
                }, 1e3));
            }, 1e3);
        }
        if ("analysis" == i) {
            i = clearInterval(this.data.titleAudioTimer), this.setData({
                isAnalysisAudioPlay: 2,
                isaudio: 1,
                titlePlayTime: "00:00",
                titleAudioTimer: i
            }), a.src = t.currentTarget.dataset.src, a.play(), this.currenttime(), this.data.onEnded || (this.data.onEnded = !0, 
            a.onEnded(function() {
                e.setData({
                    isAnalysisAudioPlay: 1,
                    currentTime: 0
                }), e.audiotime(t.currentTarget.dataset.src, 0);
            }));
            var d = t.currentTarget.dataset.num, l = e.data.audioTimeList, h = setInterval(function() {
                var t = Math.round(a.currentTime), i = Math.round(a.duration), s = e.handleTime(t), o = e.handleTime(i);
                l[d].analysis = o, e.setData({
                    analysisPlayTime: s,
                    analysisTotalTime: o,
                    audioTimeList: l,
                    analysisAudioTimer: h
                }), i == t && (console.log("停止"), setTimeout(function() {
                    clearInterval(h), e.setData({
                        analysisPlayTime: "00:00",
                        analysisTotalTime: o,
                        analysisAudioTimer: h
                    });
                }, 1e3));
            }, 1e3);
        }
    },
    myAudioPause: function(t) {
        var a = this.data.audioCtx, e = this;
        a.pause();
        var i = t.currentTarget.dataset.type;
        if (console.log("暂停解析=" + i), "paper" == i) {
            a.onPause(function() {
                a.currentTime, e.setData({
                    isaudio: 1
                }), e.audiotime(t.currentTarget.dataset.src, Math.floor(a.currentTime));
            });
            var s = clearInterval(e.data.titleAudioTimer);
            e.setData({
                titleAudioTimer: s
            });
        }
        "analysis" == i && a.onPause(function() {
            a.currentTime, e.setData({
                isAnalysisAudioPlay: 1
            }), e.audiotime(t.currentTarget.dataset.src, Math.floor(a.currentTime));
        });
    },
    handleTime: function(t) {
        if (60 <= t) {
            var a = parseInt(t / 60 % 60);
            return (a < 10 ? "0" + a : a) + ":" + ((t = parseInt(t % 60)) < 10 ? "0" + t : t);
        }
        return "00:" + (t < 10 ? "0" + t : t);
    },
    clearAudioTime: function() {
        var t = this.data.index, a = this.data.audioTimeList, e = a[t].title;
        t = a[t].analysis, clearInterval(this.data.titleAudioTimer), clearInterval(this.data.analysisAudioTimer), 
        this.setData({
            titlePlayTime: "00:00",
            titleTotalTime: e,
            analysisPlayTime: "00:00",
            analysisTotalTime: t
        });
    },
    currenttime: function(t) {
        var a = this.data.audioCtx;
        setTimeout(function() {
            a.currentTime, a.onTimeUpdate(function() {});
        }, 100);
    },
    audiotime: function(t, a) {
        this.data.audiolist.forEach(function(e) {
            e.audiosrc == t && (e.time = a);
        });
    },
    judge: function(t) {
        var a = this.data.answerlist, e = this.data.rightAnswer, i = "";
        if (2 == a[t].type) {
            var s = [];
            a[t].choose.forEach(function(t) {
                t.ischoose && s.push(t.o);
            }), i = s.join(",");
        } else 4 == a[t].type ? i = a[t].choose.join(",") : 1 != a[t].type && 3 != a[t].type || (i = a[t].choose);
        i && (a[t].isjudge = i == e[t] ? 1 : 2), this.setData({
            answerlist: a
        });
    },
    recordAnswer: function() {
        console.log(this.data.answerlist, "查看answerlist");
        var e = this, i = this.data.answerlist, s = this.data.index, o = [], n = "";
        i.forEach(function(t) {
            if (1 == t.type || 3 == t.type || 8 == t.type) o.push({
                tid: t.tid,
                type: t.type,
                answer: t.choose
            }); else if (2 == t.type) {
                var a = [];
                t.choose.forEach(function(t) {
                    t.ischoose && a.push(t.o);
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: a
                });
            } else if (4 == t.type) {
                var e = [], i = [];
                t.choose.forEach(function(t) {
                    e.push("【" + t + "】"), i.push(t);
                }), e = e.join(","), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: e,
                    answer1: i
                });
            } else if (5 == t.type) {
                var s = [];
                t.choose.forEach(function(t) {
                    s.push({
                        tid: t.tid,
                        answer: t.choose
                    });
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: s
                });
            } else if (6 == t.type || 7 == t.type) {
                var n = [];
                t.choose.forEach(function(t) {
                    n.push({
                        tid: t.tid,
                        answer: t.userAnswer
                    });
                }), o.push({
                    tid: t.tid,
                    type: t.type,
                    answer: n
                });
            }
        });
        var r = o[this.data.index].answer;
        console.log(o, this.data.rightAnswer, "查看myanswer"), 2 == o[this.data.index].type ? e.setData({
            myanswer: r.join(",")
        }) : 4 == o[this.data.index].type ? e.setData({
            myanswer: o[this.data.index].answer1
        }) : e.setData({
            myanswer: r
        });
        var d = "";
        "sequence" == t.globalData.op ? n = "shunxu" : "qhigh" == t.globalData.op ? n = "qhigh" : "intensive" == t.globalData.op ? n = "intensive" : "special" == t.globalData.op || "qspecial" == t.globalData.op ? (n = "qspecial", 
        this.data.special_id) : "qtype" == t.globalData.op || "qtype_submit" == t.globalData.op ? (n = "qtype_submit", 
        d = this.data.special_id) : n = "other", console.log(n, this.data.op, "查看11"), a.sequence_submit({
            uid: wx.getStorageSync("uid"),
            answerdata: JSON.stringify(o[this.data.index]),
            op: n,
            index: this.data.index,
            special_id: this.data.special_id,
            cutoff: this.data.userinfo.cutoff,
            click_op: this.data.op,
            type_id: d,
            type: t.globalData.type
        }).then(function(t) {
            console.log(t, "查看"), e.answer_num(), 4 == i[s].type && e.judgeCompletionItem();
        }).catch(function(t) {
            console.log(t);
        });
    },
    answer_num: function() {
        var t = this;
        a.lx_record({
            uid: wx.getStorageSync("uid"),
            id: this.data.answerlist[this.data.index].tid,
            op: "answernum"
        }).then(function(a) {
            t.setData({
                answernum: a.data,
                answer_id: t.data.answerlist[t.data.index].tid
            }), console.log("成功了吗");
        }).catch(function(t) {
            console.log(t);
        });
    },
    notesCollect: function(e) {
        var i = e.currentTarget.dataset.id;
        console.log(i);
        var s = this;
        a.getnotes({
            uid: wx.getStorageSync("uid"),
            id: i,
            status: "notescollect",
            course_type: t.globalData.type
        }).then(function(t) {
            "1002" == t.data ? (wx.showToast({
                title: "收藏成功",
                icon: "success",
                duration: 2e3
            }), 1 == s.data.currentid ? s.allNotes() : s.getMyNotes()) : "1001" == t.data && (wx.showToast({
                title: "移出收藏",
                icon: "success",
                duration: 2e3
            }), 1 == s.data.currentid ? s.allNotes() : s.getMyNotes());
        }).catch(function(t) {
            console.log(t);
        });
    },
    notesGoods: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log(e);
        var i = this;
        a.getnotes({
            uid: wx.getStorageSync("uid"),
            id: e,
            status: "notesgoods"
        }).then(function(t) {
            ("1002" == t.data || "1001" == t.data) && (1 == i.data.currentid ? i.allNotes() : i.getMyNotes());
        }).catch(function(t) {
            console.log(t);
        });
    },
    allNotes: function() {
        var t = this, e = t.data.paperdetail[t.data.index].id;
        a.getnotes({
            id: e,
            uid: wx.getStorageSync("uid"),
            status: "allnotes",
            page: t.data.page
        }).then(function(a) {
            console.log(t.data.currentid, "查看currentid"), t.tabAnimation(t.data.currentid);
            var e = {};
            a.data.usernote && (e = a.data.usernote), t.setData({
                usernote: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getMyNotes: function() {
        var t = this, e = t.data.paperdetail[t.data.index].id;
        a.getnotes({
            id: e,
            uid: wx.getStorageSync("uid"),
            status: "getMyAllNotes"
        }).then(function(a) {
            t.tabAnimation(t.data.currentid);
            var e = {};
            a.data.mynote && (e = a.data.mynote), t.setData({
                mynote: e,
                title: a.data.title
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getUserNotes: function() {
        var t = this, e = t.data.paperdetail[t.data.index].id;
        console.log(t.data.paperdetail[t.data.index].id), a.getnotes({
            id: e,
            uid: wx.getStorageSync("uid"),
            status: "getUserNotes",
            page: 1
        }).then(function(a) {
            console.log(t.data.currentid, "查看currentid"), t.tabAnimation(t.data.currentid);
            var e = {};
            a.data.usernote && (e = a.data.usernote), t.setData({
                usernote: e,
                title: a.data.title,
                pages: Math.ceil(a.data.total / a.data.psize),
                total: a.data.total,
                psize: a.data.psize
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    del: function(t) {
        var e = this, i = t.currentTarget.dataset.id;
        a.getnotes({
            id: i,
            status: "delnotes"
        }).then(function(t) {
            wx.showToast({
                title: "删除成功",
                icon: "success",
                duration: 2e3
            }), e.getMyNotes(), e.allNotes(), e.tabAnimation(2);
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        var t = this;
        "" != t.data.paperdetail && 2 == t.data.currentid ? (t.getMyNotes(), t.allNotes()) : 1 == t.data.currentid && t.allNotes();
    },
    mycomment: function(a) {
        var e = a.currentTarget.dataset.item;
        t.globalData.comment = e, wx.navigateTo({
            url: "/pages/mycomment/mycomment"
        });
    },
    copy: function(t) {
        var a = this.data.index, e = this.data.paperdetail[a].analysis.replace(/<[^>]+>/g, "");
        wx.setClipboardData({
            data: e,
            success: function(t) {}
        });
    },
    lookdetail: function() {
        var t = this, e = t.data.paperdetail[t.data.index].id;
        this.data.page <= Math.ceil(this.data.total / this.data.psize) && this.setData({
            page: this.data.page + 1,
            isInit: !0
        }), a.getnotes({
            id: e,
            uid: wx.getStorageSync("uid"),
            status: "getUserNotes",
            page: this.data.page
        }).then(function(a) {
            if (console.log(a), a.data.usernote) {
                var e = (e = t.data.usernote).concat(a.data.usernote);
                t.setData({
                    usernote: e,
                    total: a.data.total,
                    psize: a.data.psize,
                    currentid: 1
                });
            }
            t.setData({
                isInit: !1
            }), wx.stopPullDownRefresh(), t.tabAnimation(t.data.currentid);
        }).catch(function(a) {
            t.setData({
                isInit: !1
            }), wx.stopPullDownRefresh(), console.log(a);
        });
    },
    onShareAppMessage: function() {
        return {
            path: "/pages/home/home"
        };
    }
});