var t = getApp(), a = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        title: "",
        statusBarHeight: "",
        titleBarHeight: "",
        list: [],
        parmas: {},
        isloading: !0,
        pay_open: "",
        freenum: "",
        show: !1,
        item: {},
        total_num: 0
    },
    onLoad: function(a) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            title: t.globalData.title
        }), console.log(a), this.getSequence();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goLx: function(a) {
        var e = a.currentTarget.dataset.item;
        this.setData({
            item: e,
            total_num: e.total_num
        }), t.globalData.id = a.currentTarget.id, 1 == this.data.pay_open && 1 != e.is_can || 1 != this.data.pay_open && 1 != e.is_can ? this.setData({
            show: !0
        }) : wx.navigateTo({
            url: "../practice/practice"
        });
    },
    tryAnswer: function() {
        wx.navigateTo({
            url: "../practice/practice"
        });
    },
    cancel: function() {
        this.setData({
            show: !1
        });
    },
    goPay: function() {
        var t = this;
        a.wxPay({
            uid: wx.getStorageSync("uid"),
            id: this.data.item.id,
            type: "1"
        }).then(function(a) {
            console.log(a), wx.requestPayment({
                timeStamp: String(a.data.timeStamp),
                nonceStr: a.data.nonceStr,
                package: a.data.package,
                signType: a.data.signType,
                paySign: a.data.paySign,
                success: function(a) {
                    wx.showToast({
                        icon: "success",
                        title: "支付成功"
                    }), t.setData({
                        show: !1
                    }), t.getSequence();
                },
                fail: function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getSequence: function() {
        var e = this;
        t.globalData.op = "special", a.sequence({
            uid: wx.getStorageSync("uid"),
            op: "getallspecial"
        }).then(function(t) {
            console.log(t), t.data.list && e.setData({
                list: t.data.list,
                isloading: !1,
                pay_open: t.data.pay_open,
                freenum: t.data.freenum
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getErr: function() {
        var t = this, e = this.data.parmas.id;
        a.myerrList({
            uid: wx.getStorageSync("uid")
        }).then(function(a) {
            var i = [];
            a.data.knowledge_list.map(function(t, a) {
                t.pid == e && i.push(t);
            }), console.log(i), t.setData({
                list: i,
                isloading: !1
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShareAppMessage: function() {}
});