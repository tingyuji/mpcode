var t = {
    scope: {}
};

t.defineProperty = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, o) {
    if (o.get || o.set) throw new TypeError("ES3 does not support getters and setters.");
    t != Array.prototype && t != Object.prototype && (t[e] = o.value);
}, t.getGlobal = function(t) {
    return "undefined" != typeof window && window === t ? t : "undefined" != typeof global ? global : t;
}, t.global = t.getGlobal(void 0), t.SYMBOL_PREFIX = "jscomp_symbol_", t.initSymbol = function() {
    t.initSymbol = function() {}, t.global.Symbol || (t.global.Symbol = t.Symbol);
}, t.symbolCounter_ = 0, t.Symbol = function(e) {
    return t.SYMBOL_PREFIX + (e || "") + t.symbolCounter_++;
}, t.initSymbolIterator = function() {
    t.initSymbol();
    var e = t.global.Symbol.iterator;
    e || (e = t.global.Symbol.iterator = t.global.Symbol("iterator")), "function" != typeof Array.prototype[e] && t.defineProperty(Array.prototype, e, {
        configurable: !0,
        writable: !0,
        value: function() {
            return t.arrayIterator(this);
        }
    }), t.initSymbolIterator = function() {};
}, t.arrayIterator = function(e) {
    var o = 0;
    return t.iteratorPrototype(function() {
        return o < e.length ? {
            done: !1,
            value: e[o++]
        } : {
            done: !0
        };
    });
}, t.iteratorPrototype = function(e) {
    return t.initSymbolIterator(), (e = {
        next: e
    })[t.global.Symbol.iterator] = function() {
        return this;
    }, e;
}, t.makeIterator = function(e) {
    t.initSymbolIterator();
    var o = e[Symbol.iterator];
    return o ? o.call(e) : t.arrayIterator(e);
}, t.arrayFromIterator = function(t) {
    for (var e, o = []; !(e = t.next()).done; ) o.push(e.value);
    return o;
}, t.arrayFromIterable = function(e) {
    return e instanceof Array ? e : t.arrayFromIterator(t.makeIterator(e));
};

var e = getApp(), o = require("../../provider/dataApi.js");

require("../../wxParse/wxParse.js");

Page({
    data: {
        isloading: !0,
        statusBarHeight: "",
        titleBarHeight: "",
        list: [],
        page: 1,
        totalPage: 0
    },
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            title: e.globalData.title
        }), this.getSequence(1);
    },
    getSequence: function(e, a) {
        var r = this;
        o.sequence({
            uid: wx.getStorageSync("uid"),
            op: "getallsimple",
            page: e
        }).then(function(e) {
            if (console.log(e), a) {
                var o = Math.ceil(e.data.total / e.data.psize);
                e = [].concat(t.arrayFromIterable(r.data.list), t.arrayFromIterable(e.data.type_list)), 
                console.log(o), r.setData({
                    list: e,
                    totalPage: o
                });
            } else o = Math.ceil(e.data.total / e.data.psize), console.log(o), r.setData({
                list: e.data.type_list,
                totalPage: o,
                isloading: !1
            });
            wx.stopPullDownRefresh();
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goLx: function(t) {
        console.log(t), t = t.currentTarget.dataset.item, e.globalData.op = "simple_type", 
        e.globalData.id = 8, wx.navigateTo({
            url: "../practice/practice?sonType=" + t.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.setData({
            page: 1,
            list: []
        }), this.getSequence(1);
    },
    onReachBottom: function() {
        var t = this.data.page;
        this.data.totalPage > t && (this.setData({
            page: t + 1
        }), this.getSequence(t + 1, !0));
    },
    onShareAppMessage: function() {}
});