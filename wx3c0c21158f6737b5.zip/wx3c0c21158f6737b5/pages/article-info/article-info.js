var t = getApp(), a = require("../../provider/dataApi.js"), e = require("../../provider/pipe.js"), i = require("../../wxParse/wxParse.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        isloading: !1,
        videoInfo: {},
        isShowVideo: !1,
        title: "",
        articleInfo: {}
    },
    onLoad: function(o) {
        var n = this;
        console.log(o), "notice" == o.type && this.setData({
            title: "通知详情"
        }), "article" == o.type && this.setData({
            title: "文章详情"
        }), this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            isloading: !0
        });
        var r = o.nId ? o.nId : t.globalData.id;
        a.readNotice({
            nid: r
        }).then(function(t) {
            console.log(t), t.data.info.content = e.strcharacterDiscode(t.data.info.content).replace(/\<img/gi, '<img style="max-width:100px!important;height:auto"'), 
            i.wxParse("article", "html", t.data.info.content, n, 15), void 0 !== t.data.info.video && n.setData({
                videoInfo: t.data.info.video,
                isShowVideo: !0
            }), n.setData({
                articleInfo: t.data.info,
                isloading: !1
            });
        }).catch(function(t) {
            n.setData({
                isloading: !1
            }), console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: -1
        });
    },
    onShareAppMessage: function() {
        return {
            title: "分享文章",
            path: "/pages/article-info/article-info?type=article&nId=" + t.globalData.id
        };
    }
});