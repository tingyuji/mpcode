var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        phone: "",
        mynote: "",
        usernote: "",
        id: "",
        title: "",
        contentVal: ""
    },
    onLoad: function(e) {
        e = t.globalData.id, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            id: e
        }), this.getAllNotes();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    getAllNotes: function() {
        var t = this;
        e.getnotes({
            id: this.data.id,
            uid: wx.getStorageSync("uid"),
            status: "getallnotes"
        }).then(function(e) {
            console.log(e), t.setData({
                mynote: e.data.mynote,
                usernote: e.data.usernote,
                title: e.data.title
            }), console.log(e);
        }).catch(function(t) {
            console.log(t);
        });
    }
});