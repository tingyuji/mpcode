var t = getApp();

require("../../provider/dataApi.js"), require("../../provider/pipe.js");

Page({
    data: {},
    onLoad: function(t) {
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    goTest: function(a) {
        var e = a.currentTarget.dataset.classtype;
        if (t.globalData.classType = e, 1 == e) t.globalData.is_student = 2; else {
            var o = Number(a.currentTarget.dataset.is_student);
            t.globalData.is_student = 6 == o ? 6 : 5;
        }
        t.globalData.op = "randoms", wx.navigateTo({
            url: "../disorderclass/disorderclass"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});