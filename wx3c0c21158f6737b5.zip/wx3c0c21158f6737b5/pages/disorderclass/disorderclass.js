var t = getApp(), o = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        windowHeight: 0,
        knowledgeList: [],
        knowledgeIndex: 0,
        pay_open: "",
        title: "",
        total_num: "0",
        item: {},
        isloading: !0,
        isBool: !0,
        show: !1,
        qrecord: {},
        activationShow: !1,
        setCDKey: "",
        fItem: {},
        systemInfo: "",
        doneid: {},
        qseenid: {},
        userInfo: {}
    },
    getCode: function() {
        this.setData({
            show: !1,
            activationShow: !0
        });
    },
    onClose: function() {
        this.setData({
            activationShow: !1
        });
    },
    onChange: function(t) {
        this.setData({
            setCDKey: t.detail
        });
    },
    onConfirm: function() {
        this.data.setCDKey ? o.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(t) {
            console.log(t), wx.showToast({
                icon: "none",
                title: t.message
            });
        }).catch(function(t) {
            console.log(t), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        }) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    onLoad: function(o) {
        wx.getStorageSync("uid") ? (o = wx.getSystemInfoSync().windowHeight, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            windowHeight: o,
            title: t.globalData.title,
            userinfo: wx.getStorageSync("userinfo")
        })) : wx.navigateTo({
            url: "/pages/home/home"
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {},
    knowledge: function() {
        var e = this;
        o.knowledge({
            op: "cate",
            type: t.globalData.type,
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t), e.setData({
                knowledgeList: t.data.list,
                pay_open: t.data.pay_open
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    ltChoose: function(o) {
        console.log(o.currentTarget.dataset.id, "查看"), t.globalData.op = "randoms", t.globalData.id = o.currentTarget.dataset.id, 
        t.globalData.type = 1, wx.navigateTo({
            url: "../practice/practice"
        });
    },
    onShow: function() {
        this.getSequence(), this.getSystemInfo();
    },
    getSequence: function() {
        var e = this;
        t.globalData.op = "randoms", o.sequence({
            uid: wx.getStorageSync("uid"),
            op: "getallspecial",
            is_student: Number(t.globalData.is_student),
            class_type: t.globalData.classType,
            type: 1
        }).then(function(t) {
            console.log(t);
            var o = !1;
            0 < t.data.list.length && (o = !0), e.setData({
                knowledgeList: t.data.list,
                isloading: !1,
                pay_open: t.data.pay_open,
                freenum: t.data.freenum,
                isBool: o
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    onHide: function() {},
    tryAnswer: function(o) {
        console.log(o), o = o.currentTarget.dataset.num, t.globalData.id = this.data.item.id, 
        t.globalData.type = 1, wx.navigateTo({
            url: "../practice/practice?num=" + o
        });
    },
    closePayPopup: function() {
        this.setData({
            show: !1
        });
    },
    random_open: function() {
        var t = this;
        o.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "random_status",
            status: 2
        }).then(function(o) {
            console.log(o), t.getinfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    random_close: function() {
        var t = this;
        o.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "random_status",
            status: 1
        }).then(function(o) {
            console.log(o), t.getinfo();
        }).catch(function(t) {
            console.log(t);
        });
    },
    getinfo: function() {
        var t = this;
        o.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(o) {
            var e = o.data.info, n = o.data.info.is_bind;
            t.setData({
                phone: o.data.info.phone,
                userinfo: o.data.info
            }), wx.setStorageSync("userinfo", e), wx.setStorageSync("http", o.data.http), o = !1, 
            1 == e.is_ok && (o = !0), t.setData({
                isCanAnswer: o,
                isBind: n
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goVipBtn: function() {
        wx.navigateTo({
            url: "../vip/vip"
        }), this.setData({
            show: !1
        });
    },
    goPay: function() {
        var t = this;
        o.wxPay({
            uid: wx.getStorageSync("uid"),
            id: this.data.item.chapterId,
            type: "1"
        }).then(function(o) {
            console.log(o), wx.requestPayment({
                timeStamp: String(o.data.timeStamp),
                nonceStr: o.data.nonceStr,
                package: o.data.package,
                signType: o.data.signType,
                paySign: o.data.paySign,
                success: function(o) {
                    wx.showToast({
                        icon: "success",
                        title: "支付成功"
                    }), t.setData({
                        show: !1
                    }), t.getSequence();
                },
                fail: function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(o) {
                console.log(o.platform, "型号"), "devtools" == o.platform ? t.setData({
                    systemInfo: "PC"
                }) : "ios" == o.platform ? t.setData({
                    systemInfo: "IOS"
                }) : "android" == o.platform && t.setData({
                    systemInfo: "android"
                });
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});