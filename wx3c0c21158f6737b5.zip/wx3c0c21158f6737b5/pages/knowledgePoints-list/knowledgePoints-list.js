var t = getApp(), e = require("../../provider/dataApi.js");

require("../../provider/pipe.js");

Page({
    data: {
        statusBarHeight: "",
        titleBarHeight: "",
        oItem: {},
        isData: !0,
        showPay: !1,
        price: "",
        systemInfo: "",
        lookid: {},
        seenid: {},
        vip_price: "",
        sureshow: !1
    },
    onLoad: function(e) {
        wx.getStorageSync("uid") ? (e = t.globalData.oItem, this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            oItem: e
        })) : wx.reLaunch({
            url: "/pages/mine/mine"
        });
    },
    bindKeyInput: function(t) {
        console.log(t.detail.value, "查看激活码"), this.setData({
            sureshow: !0,
            setCDKey: t.detail.value
        });
    },
    onConfirm: function() {
        var t = this;
        this.data.setCDKey ? e.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(e) {
            wx.showModal({
                title: "提示",
                content: "您已激活成功，请不要重复输入激活码呦~",
                success: function(e) {
                    e.confirm ? (t.setData({
                        showPay: !1
                    }), t.getKnowledge(t.data.oItem)) : e.cancel && console.log("用户点击取消");
                }
            });
        }).catch(function(t) {
            console.log(t), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        }) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    knowRecord: function() {
        var t = this;
        e.knowRecord({
            uid: wx.getStorageSync("uid")
        }).then(function(e) {
            var a = JSON.parse(e.data.testid);
            console.log(a, "成功了吗"), t.setData({
                seenid: a,
                lookid: JSON.parse(e.data.knowledgeid)
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getKnowledge: function(t) {
        console.log(t, "查看iscan");
        var a = this;
        e.knowledge({
            op: "knowledgelist",
            uid: wx.getStorageSync("uid"),
            cate: t.id
        }).then(function(t) {
            console.log(t, "查看列表");
            var e = !1;
            0 < t.data.list.length && (e = !0), a.setData({
                list: t.data.list,
                price: t.data.price,
                vip_price: t.data.vip_price,
                pay_open: t.data.pay_open,
                isData: e
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    getUserInfo: function() {
        var t = this;
        e.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(e) {
            console.log(e), t.setData({
                userInfo: e.data.info
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    closePayPopup: function() {
        this.setData({
            showPay: !1
        });
    },
    goLook: function(e) {
        var a = e.currentTarget.dataset.index;
        if (console.log(e, "查看"), i = e.currentTarget.dataset.item, 1 == this.data.userInfo.ismember) {
            if (1 != i.is_can && 0 != this.data.vip_price) return this.setData({
                showPay: !0
            }), !1;
        } else if (1 != i.is_can) return this.setData({
            showPay: !0
        }), !1;
        var o = e.currentTarget.dataset.item.id, n = e.currentTarget.dataset.item.three, i = {};
        this.data.lookid && (i = this.data.lookid);
        var s = {};
        this.data.seenid && (s = this.data.seenid), i[o] || (i[o] = [ o ], s[n] ? s[n].push(n) : s[n] = [ n ]), 
        this.setData({
            lookid: i,
            seenid: s
        }), wx.setStorageSync("lookid", this.data.lookid), wx.setStorageSync("seenid", this.data.seenid), 
        t.globalData.oItem = e, t.globalData.kindex = a, t.globalData.list = this.data.list, 
        wx.navigateTo({
            url: "../knowledgePoints-list-detail/knowledgePoints-list-detail"
        }), this.knowSelect();
    },
    knowSelect: function() {
        if ("" == wx.getStorageSync("seenid")) var t = ""; else t = JSON.stringify(wx.getStorageSync("seenid"));
        e.knowSelect({
            uid: wx.getStorageSync("uid"),
            seenid: t,
            lookid: JSON.stringify(wx.getStorageSync("lookid"))
        }).then(function(t) {
            console.log("成功了吗");
        }).catch(function(t) {
            console.log(t);
        });
    },
    goVipBtn: function() {
        wx.navigateTo({
            url: "../vip/vip"
        });
    },
    goPayBtn: function() {
        this.pay();
    },
    pay: function() {
        var t = this, a = this.data.oItem;
        e.wxPay({
            uid: wx.getStorageSync("uid"),
            id: a.chapterId,
            type: "2"
        }).then(function(e) {
            console.log(e), wx.requestPayment({
                timeStamp: String(e.data.timeStamp),
                nonceStr: e.data.nonceStr,
                package: e.data.package,
                signType: e.data.signType,
                paySign: e.data.paySign,
                success: function(e) {
                    wx.showToast({
                        icon: "success",
                        title: "支付成功"
                    }), t.setData({
                        showPay: !1
                    }), t.update();
                },
                fail: function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "支付失败,请重试~"
                    });
                }
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    update: function() {
        var t = this;
        e.userinfo({
            uid: wx.getStorageSync("uid"),
            id: this.data.oItem.chapterId,
            op: "updateknowledge"
        }).then(function(e) {
            console.log(e), t.getKnowledge(t.data.oItem);
        }).catch(function(t) {
            console.log(t);
        });
    },
    onShow: function() {
        this.knowRecord(), this.getSystemInfo(), this.getUserInfo(), this.getKnowledge(this.data.oItem);
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                ("devtools" == e.platform || "ios" == e.platform || "android" == e.platform) && t.setData({
                    systemInfo: "IOS"
                });
            }
        });
    },
    onShareAppMessage: function() {}
});