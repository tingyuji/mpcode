var e = getApp(), t = require("../../provider/dataApi.js"), a = require("../../provider/pipe.js");

Page({
    data: {
        isloading: !0,
        isCanAnswer: !1,
        statusBarHeight: "",
        titleBarHeight: "",
        banner: [],
        notice: [],
        last_id: 0,
        total: 0,
        check: 0,
        banner_height: "",
        is_can: "",
        adInfo: {},
        ad_have: 2,
        icons: {},
        countdown: {},
        countdownTime: 0,
        count_day: {},
        rate: {},
        phone: "",
        isBind: 0,
        activationShow: !1,
        setCDKey: "",
        knowledge_record: "",
        test_record: "",
        canIUseGetUserProfile: !1
    },
    registerFormSubmit: function(e) {
        wx.getStorageSync("uid") && t.getFormid({
            uid: wx.getStorageSync("uid"),
            formid: e.detail.formId
        }).then(function(e) {}).catch(function(e) {});
    },
    onLoad: function(e) {
        this.setting(), wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        });
        var t = this;
        wx.login({
            success: function(e) {
                var a = e.code;
                t.setData({
                    code: a
                });
            }
        });
        var a = wx.getStorageSync("fidselect"), o = wx.getStorageSync("lookid"), n = wx.getStorageSync("seenid"), i = wx.getStorageSync("selectid");
        this.setData({
            statusBarHeight: getApp().globalData.statusBarHeight,
            titleBarHeight: getApp().globalData.titleBarHeight,
            fidselect: a,
            lookid: o,
            seenid: n,
            selecid: i
        }), this.lxrecord();
    },
    lxrecord: function() {
        var e = this;
        t.lx_record({
            uid: wx.getStorageSync("uid"),
            op: "status"
        }).then(function(t) {
            console.log(t, "status"), 2 == t.data && e.sureLxRecord();
        }).catch(function(e) {
            console.log(e);
        });
    },
    sureLxRecord: function() {
        t.lx_record({
            uid: wx.getStorageSync("uid"),
            op: "record"
        }).then(function(e) {
            console.log(e);
        }).catch(function(e) {
            console.log(e);
        });
    },
    goBanner: function(t) {
        0 == this.data.isBind ? this.bindWechat() : (wx.getStorageSync("uid") || wx.reLaunch({
            url: "/pages/mine/mine"
        }), "1" == (t = e.globalData.item = t.currentTarget.dataset.item).type ? ("1" == (t = t.link) && wx.navigateTo({
            url: "/pages/my-medal/my-medal"
        }), "2" == t && wx.switchTab({
            url: "/pages/error/error"
        }), "3" == t && wx.navigateTo({
            url: "/pages/ranking/ranking"
        }), "4" == t && wx.switchTab({
            url: "/pages/mine/mine"
        }), "5" == t && wx.navigateTo({
            url: "/pages/exam-desc/exam-desc"
        }), "6" == t && wx.navigateTo({
            url: "/pages/integral-mall/integral-mall"
        }), "7" == t && wx.navigateTo({
            url: "/pages/vip/vip"
        })) : "2" == t.type ? wx.navigateTo({
            url: "../webView/webView"
        }) : "3" == t.type && (e.globalData.id = t.link, wx.navigateTo({
            url: "/pages/article-info/article-info?type=article"
        })));
    },
    goLx: function() {
        this.data.isCanAnswer;
        e.globalData.op = "sequence", wx.navigateTo({
            url: "../practice/practice"
        });
    },
    preserve: function() {
        this.fidselect(), this.knowSelect(), wx.showModal({
            title: "提示",
            content: "刷题记录已同步",
            success: function(e) {
                e.confirm ? wx.reLaunch({
                    url: "/pages/home/home"
                }) : e.cancel && console.log("用户点击取消");
            }
        });
    },
    fidselect: function() {
        if ("" == wx.getStorageSync("fidselect")) e = ""; else var e = JSON.stringify(wx.getStorageSync("fidselect"));
        t.fidselect({
            uid: wx.getStorageSync("uid"),
            fidselect: e,
            selectid: JSON.stringify(wx.getStorageSync("selectid"))
        }).then(function(e) {
            console.log("成功了吗");
        }).catch(function(e) {
            console.log(e);
        });
    },
    knowSelect: function() {
        if ("" == wx.getStorageSync("seenid")) var e = ""; else e = JSON.stringify(wx.getStorageSync("seenid"));
        t.knowSelect({
            uid: wx.getStorageSync("uid"),
            seenid: e,
            lookid: JSON.stringify(wx.getStorageSync("lookid"))
        }).then(function(e) {
            console.log("成功了吗");
        }).catch(function(e) {
            console.log(e);
        });
    },
    goExam: function() {
        this.data.isCanAnswer;
        wx.navigateTo({
            url: "../exam-desc/exam-desc"
        });
    },
    bindWechat: function() {
        wx.showModal({
            title: "绑定微信",
            content: "需要绑定微信才能进行下一步操作,点击确定去绑定",
            showCancel: !0,
            confirmText: "确定",
            success: function(e) {
                console.log(e), e.confirm && wx.navigateTo({
                    url: "../bindWechat/bindWechat"
                });
            }
        });
    },
    testInfo: function() {
        wx.showModal({
            title: "完善信息",
            content: "答题前需要完善姓名和手机号信息",
            showCancel: !0,
            confirmText: "去完善",
            success: function(e) {
                console.log(e), e.confirm && wx.navigateTo({
                    url: "../my-info/my-info"
                });
            }
        });
    },
    goThreeLx: function(t) {
        var a = Number(t.currentTarget.dataset.is_student);
        e.globalData.is_student = 6 == a ? 6 : 5, e.globalData.classType = 2, wx.navigateTo({
            url: "../classification/classification"
        });
    },
    golianX: function(t) {
        var a = Number(t.currentTarget.dataset.type);
        t = t.currentTarget.dataset.title;
        this.data.isCanAnswer, this.data.isBind;
        switch (e.globalData.title = t, a) {
          case 1:
            e.globalData.is_student = 2, e.globalData.classType = 1, wx.navigateTo({
                url: "../classification/classification"
            });
            break;

          case 2:
            wx.navigateTo({
                url: "../type-lx/type-lx"
            });
            break;

          case 3:
            e.globalData.op = "randoms", wx.navigateTo({
                url: "../disorderclass/disorder_before"
            });
            break;

          case 4:
            e.globalData.op = "collection_question", wx.navigateTo({
                url: "../practice/practice"
            });
            break;

          case 5:
            wx.navigateTo({
                url: "../error/error"
            });
            break;

          case 6:
            e.globalData.op = "notdone", wx.navigateTo({
                url: "../practice/practice"
            });
            break;

          case 7:
            e.globalData.type = 1, wx.navigateTo({
                url: "../knowledgePoints/know_before"
            });
            break;

          case 8:
            e.globalData.type = 2, wx.navigateTo({
                url: "../knowledgePoints/knowledgePoints"
            });
        }
    },
    getCode: function() {
        this.setData({
            activationShow: !0
        });
    },
    onClose: function() {
        this.setData({
            activationShow: !1
        });
    },
    onChange: function(e) {
        this.setData({
            setCDKey: e.detail
        });
    },
    onConfirm: function() {
        this.data.setCDKey ? t.setCDKey({
            uid: wx.getStorageSync("uid"),
            code: this.data.setCDKey
        }).then(function(e) {
            console.log(e), wx.showToast({
                icon: "none",
                title: e.message,
                setCDKey: ""
            });
        }).catch(function(e) {
            console.log(e), wx.showToast({
                icon: "none",
                title: "该激活码不可用"
            });
        }) : wx.showToast({
            icon: "none",
            title: "请输入激活码"
        });
    },
    queryAd: function() {
        var e = this;
        t.advert({
            op: "home"
        }).then(function(t) {
            console.log(t), e.setData({
                adInfo: t.data.info,
                ad_have: t.data.ad_have
            });
        }).catch(function(e) {
            console.log(e);
        });
    },
    onShow: function() {
        this.getinfo(), this.indexData(), console.log(this.data.isBind, "查看bind值");
    },
    goNotice: function(t) {
        wx.getStorageSync("uid") || wx.reLaunch({
            url: "/pages/mine/mine"
        }), e.globalData.id = t.currentTarget.dataset.id, wx.navigateTo({
            url: "../article-info/article-info?type=notice"
        });
    },
    indexRequest: function(a) {
        var o = this;
        t.indexData({
            uid: a
        }).then(function(t) {
            o.setData({
                banner: t.data.banner,
                notice: t.data.notice,
                banner_height: t.data.banner_height,
                share_title: t.data.share_title,
                icons: t.data.icons,
                countdown: t.data.countdown,
                count_day: t.data.count_day,
                rate: t.data.rate,
                isloading: !1
            }), o.djsFun(t.data.countdown.countdowntime), a && e.setCache("indexData", t, 600);
        }).catch(function(e) {
            console.log(e);
        });
    },
    indexData: function() {
        var t = this, a = parseInt(wx.getStorageSync("uid")), o = {};
        a ? (o = e.getCache("indexData")) ? (t.setData({
            banner: o.data.banner,
            notice: o.data.notice,
            banner_height: o.data.banner_height,
            share_title: o.data.share_title,
            icons: o.data.icons,
            countdown: o.data.countdown,
            count_day: o.data.count_day,
            rate: o.data.rate,
            isloading: !1
        }), t.djsFun(o.data.countdown.countdowntime)) : t.indexRequest(a) : o = t.indexRequest(a);
    },
    djsFun: function(e) {
        var t = 0;
        0 < 1e3 * e - new Date().getTime() && (t = a.formatDateDayTimehour(1e3 * e)), this.setData({
            countdownTime: t
        });
    },
    totalqNum: function() {
        var e = this;
        t.totalqNum({
            uid: wx.getStorageSync("uid")
        }).then(function(t) {
            console.log(t), e.setData({
                last_id: Number(t.data.last_id),
                total: t.data.total,
                is_can: t.data.is_can
            });
        }).catch(function(e) {
            console.log(e);
        });
    },
    getinfo: function() {
        var e = this;
        t.userinfo({
            uid: wx.getStorageSync("uid"),
            op: "getinfo"
        }).then(function(t) {
            console.log(t);
            var a = t.data.info, o = t.data.info.is_bind;
            e.setData({
                phone: t.data.info.phone,
                userinfo: t.data.info,
                test_record: t.data.info.test_record,
                knowledge_record: t.data.info.knowledge_record
            }), wx.setStorageSync("userinfo", a), wx.setStorageSync("http", t.data.http), t = !1, 
            1 == a.is_ok && (t = !0), e.setData({
                isCanAnswer: t,
                isBind: o
            });
        }).catch(function(e) {
            console.log(e);
        });
    },
    ranking: function() {
        wx.navigateTo({
            url: "/pages/ranking/ranking"
        });
    },
    myerror: function() {
        wx.navigateTo({
            url: "/promotion/error/error"
        });
    },
    setting: function() {
        var e = this;
        t.setting({}).then(function(t) {
            console.log(t), e.setData({
                video_open: t.data.video_open
            });
        }).catch(function(e) {
            console.log(e);
        });
    },
    goVideo: function() {
        e.globalData.video_tag = 1, wx.navigateTo({
            url: "/promotion/video/video"
        });
    },
    goLiNian: function() {
        e.globalData.headtitle = "历年真题", wx.navigateTo({
            url: "/promotion/before_test/index"
        });
    },
    mycollect: function() {
        e.globalData.op = "collection_question", e.globalData.type = 1, e.globalData.title = "我的收藏", 
        wx.navigateTo({
            url: "/promotion/collect/collect"
        });
    },
    getUserInfo: function() {
        console.log(this.data.code);
        var e = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.getUserInfo({
            success: function(a) {
                console.log(a), t.login({
                    code: e.data.code,
                    is_bind: 2,
                    encryptedData: a.encryptedData,
                    iv: a.iv
                }).then(function(e) {
                    console.log(e), wx.hideLoading(), wx.showToast({
                        title: e.message,
                        icon: "none"
                    }), 0 == e.errno && (wx.setStorageSync("uid", e.data.uid), wx.reLaunch({
                        url: "/pages/home/home"
                    }));
                }).catch(function(e) {
                    console.log(e), wx.hideLoading(), wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    getUserProfile: function() {
        var e = this;
        wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(a) {
                console.log(a), t.login({
                    code: e.data.code,
                    is_bind: 2,
                    encryptedData: a.encryptedData,
                    iv: a.iv
                }).then(function(e) {
                    console.log(e), wx.hideLoading(), wx.showToast({
                        title: e.message,
                        icon: "none"
                    }), 0 == e.errno && (wx.setStorageSync("uid", e.data.uid), wx.reLaunch({
                        url: "/pages/home/home"
                    }));
                }).catch(function(e) {
                    console.log(e), wx.hideLoading(), wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                });
            }
        });
    },
    goFeedback: function() {
        wx.navigateTo({
            url: "../feedback/feedback"
        });
    },
    getPhoneNumber: function(e) {
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.login({
            success: function(a) {
                "getPhoneNumber:ok" == e.detail.errMsg ? t.userinfo({
                    encryptedData: e.detail.encryptedData,
                    iv: e.detail.iv,
                    op: "jmPhone",
                    code: a.code
                }).then(function(e) {
                    console.log(e.data.phone), wx.showToast({
                        title: e.message,
                        icon: "none"
                    }), 0 == e.errno && (wx.setStorageSync("uid", e.data.uid), wx.reLaunch({
                        url: "/pages/home/home"
                    }));
                }).catch(function(e) {
                    console.log(e), wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                }) : (wx.hideLoading && wx.hideLoading(), wx.showToast({
                    title: "您拒绝了授权",
                    icon: "none",
                    duration: 2e3
                }));
            }
        });
    },
    onShareAppMessage: function() {}
});