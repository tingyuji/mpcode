!function(n) {
    function e(n, e) {
        var t = (65535 & n) + (65535 & e);
        return (n >> 16) + (e >> 16) + (t >> 16) << 16 | 65535 & t;
    }
    function t(n, t, o, r, c, u) {
        return e((n = e(e(t, n), e(r, u))) << c | n >>> 32 - c, o);
    }
    function o(n, e, o, r, c, u, a) {
        return t(e & o | ~e & r, n, e, c, u, a);
    }
    function r(n, e, o, r, c, u, a) {
        return t(e & r | o & ~r, n, e, c, u, a);
    }
    function c(n, e, o, r, c, u, a) {
        return t(o ^ (e | ~r), n, e, c, u, a);
    }
    function u(n, u) {
        n[u >> 5] |= 128 << u % 32, n[14 + (u + 64 >>> 9 << 4)] = u;
        var a, f, i, h, d, p = 1732584193, g = -271733879, l = -1732584194, C = 271733878;
        for (a = 0; a < n.length; a += 16) g = c(g = c(g = c(g = c(g = t((l = t((C = t((p = t((g = t((l = t((C = t((p = t((g = t((l = t((C = t((p = t((g = t((l = t((C = t((p = t((g = r(g = r(g = r(g = r(g = o(g = o(g = o(g = o(i = g, l = o(h = l, C = o(d = C, p = o(f = p, g, l, C, n[a], 7, -680876936), g, l, n[a + 1], 12, -389564586), p, g, n[a + 2], 17, 606105819), C, p, n[a + 3], 22, -1044525330), l = o(l, C = o(C, p = o(p, g, l, C, n[a + 4], 7, -176418897), g, l, n[a + 5], 12, 1200080426), p, g, n[a + 6], 17, -1473231341), C, p, n[a + 7], 22, -45705983), l = o(l, C = o(C, p = o(p, g, l, C, n[a + 8], 7, 1770035416), g, l, n[a + 9], 12, -1958414417), p, g, n[a + 10], 17, -42063), C, p, n[a + 11], 22, -1990404162), l = o(l, C = o(C, p = o(p, g, l, C, n[a + 12], 7, 1804603682), g, l, n[a + 13], 12, -40341101), p, g, n[a + 14], 17, -1502002290), C, p, n[a + 15], 22, 1236535329), l = r(l, C = r(C, p = r(p, g, l, C, n[a + 1], 5, -165796510), g, l, n[a + 6], 9, -1069501632), p, g, n[a + 11], 14, 643717713), C, p, n[a], 20, -373897302), l = r(l, C = r(C, p = r(p, g, l, C, n[a + 5], 5, -701558691), g, l, n[a + 10], 9, 38016083), p, g, n[a + 15], 14, -660478335), C, p, n[a + 4], 20, -405537848), l = r(l, C = r(C, p = r(p, g, l, C, n[a + 9], 5, 568446438), g, l, n[a + 14], 9, -1019803690), p, g, n[a + 3], 14, -187363961), C, p, n[a + 8], 20, 1163531501), l = r(l, C = r(C, p = r(p, g, l, C, n[a + 13], 5, -1444681467), g, l, n[a + 2], 9, -51403784), p, g, n[a + 7], 14, 1735328473), C, p, n[a + 12], 20, -1926607734)) ^ l ^ C, p, g, n[a + 5], 4, -378558)) ^ g ^ l, C, p, n[a + 8], 11, -2022574463)) ^ p ^ g, l, C, n[a + 11], 16, 1839030562)) ^ C ^ p, g, l, n[a + 14], 23, -35309556)) ^ l ^ C, p, g, n[a + 1], 4, -1530992060)) ^ g ^ l, C, p, n[a + 4], 11, 1272893353)) ^ p ^ g, l, C, n[a + 7], 16, -155497632)) ^ C ^ p, g, l, n[a + 10], 23, -1094730640)) ^ l ^ C, p, g, n[a + 13], 4, 681279174)) ^ g ^ l, C, p, n[a], 11, -358537222)) ^ p ^ g, l, C, n[a + 3], 16, -722521979)) ^ C ^ p, g, l, n[a + 6], 23, 76029189)) ^ l ^ C, p, g, n[a + 9], 4, -640364487)) ^ g ^ l, C, p, n[a + 12], 11, -421815835)) ^ p ^ g, l, C, n[a + 15], 16, 530742520)) ^ C ^ p, g, l, n[a + 2], 23, -995338651), l = c(l, C = c(C, p = c(p, g, l, C, n[a], 6, -198630844), g, l, n[a + 7], 10, 1126891415), p, g, n[a + 14], 15, -1416354905), C, p, n[a + 5], 21, -57434055), l = c(l, C = c(C, p = c(p, g, l, C, n[a + 12], 6, 1700485571), g, l, n[a + 3], 10, -1894986606), p, g, n[a + 10], 15, -1051523), C, p, n[a + 1], 21, -2054922799), l = c(l, C = c(C, p = c(p, g, l, C, n[a + 8], 6, 1873313359), g, l, n[a + 15], 10, -30611744), p, g, n[a + 6], 15, -1560198380), C, p, n[a + 13], 21, 1309151649), l = c(l, C = c(C, p = c(p, g, l, C, n[a + 4], 6, -145523070), g, l, n[a + 11], 10, -1120210379), p, g, n[a + 2], 15, 718787259), C, p, n[a + 9], 21, -343485551), 
        p = e(p, f), g = e(g, i), l = e(l, h), C = e(C, d);
        return [ p, g, l, C ];
    }
    function a(n) {
        var e, t = "", o = 32 * n.length;
        for (e = 0; e < o; e += 8) t += String.fromCharCode(n[e >> 5] >>> e % 32 & 255);
        return t;
    }
    function f(n) {
        var e, t = [];
        for (t[(n.length >> 2) - 1] = void 0, e = 0; e < t.length; e += 1) t[e] = 0;
        var o = 8 * n.length;
        for (e = 0; e < o; e += 8) t[e >> 5] |= (255 & n.charCodeAt(e / 8)) << e % 32;
        return t;
    }
    function i(n) {
        return a(u(f(n), 8 * n.length));
    }
    function h(n, e) {
        var t, o = f(n), r = [], c = [];
        for (r[15] = c[15] = void 0, 16 < o.length && (o = u(o, 8 * n.length)), t = 0; t < 16; t += 1) r[t] = 909522486 ^ o[t], 
        c[t] = 1549556828 ^ o[t];
        return t = u(r.concat(f(e)), 512 + 8 * e.length), a(u(c.concat(t), 640));
    }
    function d(n) {
        var e, t, o = "";
        for (t = 0; t < n.length; t += 1) e = n.charCodeAt(t), o += "0123456789abcdef".charAt(e >>> 4 & 15) + "0123456789abcdef".charAt(15 & e);
        return o;
    }
    module.exports = function(n, e, t) {
        return n = e ? t ? h(unescape(encodeURIComponent(e)), unescape(encodeURIComponent(n))) : d(n = h(unescape(encodeURIComponent(e)), unescape(encodeURIComponent(n)))) : t ? i(unescape(encodeURIComponent(n))) : d(i(unescape(encodeURIComponent(n))));
    };
}();