module.exports = {
    base64_encode: function(r) {
        for (var e, t, a, o = 0, h = r.length, c = ""; o < h; ) {
            if (e = 255 & r.charCodeAt(o++), o == h) {
                c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(e >> 2), 
                c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((3 & e) << 4), 
                c += "==";
                break;
            }
            if (t = r.charCodeAt(o++), o == h) {
                c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(e >> 2), 
                c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((3 & e) << 4 | (240 & t) >> 4), 
                c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((15 & t) << 2), 
                c += "=";
                break;
            }
            a = r.charCodeAt(o++), c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(e >> 2), 
            c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((3 & e) << 4 | (240 & t) >> 4), 
            c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((15 & t) << 2 | (192 & a) >> 6), 
            c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(63 & a);
        }
        return c;
    },
    base64_decode: function(r) {
        for (var e, t, a = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ], o = 0, h = r.length, c = ""; o < h; ) {
            for (;e = a[255 & r.charCodeAt(o++)], o < h && -1 == e; ) ;
            if (-1 == e) break;
            for (;t = a[255 & r.charCodeAt(o++)], o < h && -1 == t; ) ;
            if (-1 == t) break;
            c += String.fromCharCode(e << 2 | (48 & t) >> 4);
            do {
                if (61 == (e = 255 & r.charCodeAt(o++))) return c;
                e = a[e];
            } while (o < h && -1 == e);
            if (-1 == e) break;
            c += String.fromCharCode((15 & t) << 4 | (60 & e) >> 2);
            do {
                if (61 == (t = 255 & r.charCodeAt(o++))) return c;
                t = a[t];
            } while (o < h && -1 == t);
            if (-1 == t) break;
            c += String.fromCharCode((3 & e) << 6 | t);
        }
        return c;
    }
};