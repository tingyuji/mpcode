module.exports = {
    name: "CiCi教育学刷题背诵",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "3.6.5",
    siteroot: "https://cici.hongguoyan.com/app/index.php",
    design_method: "3"
};