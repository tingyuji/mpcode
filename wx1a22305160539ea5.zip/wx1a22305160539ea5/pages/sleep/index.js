(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 32 ], {
    275: function(e, t, s) {},
    290: function(e, t, s) {
        "use strict";
        s.r(t);
        var a = s(7), i = s(19), n = s(10), c = s(11), l = s(12), r = s(13), o = s(14), d = s(5), h = s.n(d), u = s(1), m = s(48), p = s.n(m), j = s(59), b = s.n(j), g = s(24), v = s.n(g), x = s(25), O = s.n(x), y = s(26), N = s.n(y), f = s(23), w = s.n(f), k = s(43), S = s.n(k), T = s(30), C = s.n(T), F = s(45), I = s.n(F), V = s(44), D = s.n(V), W = (s(275), 
        s(8)), A = s(3), B = s(6), U = s(2), P = s(46), H = s.n(P), z = s(0), L = function(e) {
            Object(l["a"])(s, e);
            var t = Object(r["a"])(s);
            function s(e) {
                var a, i;
                return Object(n["a"])(this, s), i = t.call(this, e), i.state = {
                    navTop: Object(A["a"])("navTop"),
                    height: Object(A["a"])("ButtonHeight"),
                    windowWidth: h.a.getSystemInfoSync().windowWidth,
                    anchorName: "allAnchor",
                    panelDetail: "all",
                    windowHeight: h.a.getSystemInfoSync().windowHeight,
                    isVip: (null === (a = Object(A["a"])("nowUser").nowVip) || void 0 === a ? void 0 : a.isVip) || !1,
                    menuData: [],
                    inviteVisible: !1,
                    inviteFriends: [],
                    unlockCourseSendFriends: "",
                    unlockCourseSendFriendTxt: [],
                    checkedNature: "",
                    sendCourse: {},
                    userData: Object(A["a"])("nowUser")
                }, i;
            }
            return Object(c["a"])(s, [ {
                key: "checkTabItem",
                value: function(e) {
                    console.log(e.currentTarget.dataset.categoryType), this.setState({
                        panelDetail: e.currentTarget.dataset.categoryType,
                        anchorName: e.currentTarget.dataset.categoryType + "Anchor"
                    });
                }
            }, {
                key: "handlePageScroll",
                value: function(e) {
                    var t = this, s = e.detail.scrollTop, a = [ 0 ];
                    h.a.createSelectorQuery().selectAll(".anchorItem").boundingClientRect(function(e) {
                        var i = 0;
                        e.map(function(e) {
                            i += e.height, a.push(i);
                        }), a.map(function(i, n) {
                            if (n < e.length) {
                                var c = a[n + 1];
                                s < c && s >= i && t.setState({
                                    anchorName: t.state.menuData[n].categoryType + "Anchor"
                                });
                            }
                        });
                    }).exec();
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    var e = this;
                    Object(W["d"])().then(function(t) {
                        var s, a;
                        Object(A["c"])("appConfig", t.result), e.setState({
                            unlockCourseSendFriendTxt: null === (s = t.result) || void 0 === s ? void 0 : s.unlockCourseSendFriendTxt.split("|"),
                            unlockCourseSendFriends: parseInt(null === (a = t.result) || void 0 === a ? void 0 : a.unlockCourseSendFriends)
                        });
                    }), Object(W["k"])({
                        id: Object(A["a"])("appConfig").sendCourse
                    }).then(function(t) {
                        e.setState({
                            sendCourse: t.result
                        });
                    }), Object(W["B"])().then(function(t) {
                        t.result[0].categoryName = "全部", t.result[0].categoryType = "all", e.setState({
                            menuData: Object(i["a"])(t.result)
                        });
                    });
                }
            }, {
                key: "refreshPage",
                value: function() {
                    var e = this;
                    Object(W["B"])().then(function(t) {
                        t.result[0].categoryName = "全部", t.result[0].categoryType = "all", e.setState({
                            menuData: Object(i["a"])(t.result)
                        }), console.log("请求得数据" + e.state.menuData);
                    });
                }
            }, {
                key: "toNature",
                value: function(e) {
                    if (this.state.isVip || "vip" != e.typeNew) Object(A["c"])("natureData", e), B["a"].navigatorTo("../naturePlay/index?id=".concat(e.id)); else if (Object(A["a"])("system").includes("iOS")) this.handleInviteVisible(e); else {
                        var t = Object(A["a"])("appConfig").gotoVip;
                        Object(A["c"])("webUrl", t + "?id=" + Object(A["a"])("nowUser").id), B["a"].navigatorTo("../webView/index?url=" + t + "?id=" + Object(A["a"])("nowUser").id);
                    }
                }
            }, {
                key: "handleInviteVisible",
                value: function(e) {
                    var t = this;
                    this.state.inviteVisible ? this.setState({
                        checkedNature: ""
                    }) : (this.setState({
                        checkedNature: e
                    }), Object(W["t"])({
                        courseId: e.id
                    }).then(function(e) {
                        Array.isArray(e.result) && (t.setState({
                            inviteFriends: e.result
                        }), e.result.length == t.state.unlockCourseSendFriends && t.setState({
                            isVip: !0
                        }));
                    })), this.setState({
                        inviteVisible: !this.state.inviteVisible
                    });
                }
            }, {
                key: "toDetail",
                value: function(e, t) {
                    "course" == t && B["a"].navigatorTo("../class/index?id=".concat(e.id)), "article" == t && (Object(A["c"])("webUrl", e.url), 
                    B["a"].navigatorTo("../webView/index?url=" + e.url)), "decompression" == t && (Object(A["c"])("videoData", e), 
                    B["a"].navigatorTo("../fullVideo/index?id=".concat(e.id)));
                }
            }, {
                key: "componentDidShow",
                value: function() {
                    var e;
                    this.setState({
                        isVip: (null === (e = Object(A["a"])("nowUser").nowVip) || void 0 === e ? void 0 : e.isVip) || !1
                    }), h.a.setTabBarStyle({
                        backgroundColor: "#0C1F41",
                        color: "#9f9f9f",
                        selectedColor: "#ffffff"
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function() {
                    if (this.state.checkedNature && "vip" == this.state.checkedNature.typeNew) return {
                        title: this.state.sendCourse.shareTitle,
                        path: "/pages/class/index?id=".concat(this.state.sendCourse.id, "&sendCourse=").concat(this.state.sendCourse.id, "&inviteCode=").concat(Object(A["a"])("nowUser").invitCode),
                        imageUrl: this.state.sendCourse.thumbImg
                    };
                }
            }, {
                key: "render",
                value: function() {
                    var e, t, s, a, i = this;
                    return Object(z["jsxs"])(u["m"], {
                        className: "contaniner sleepWrap",
                        children: [ Object(z["jsx"])(u["c"], {
                            className: "sleepBg",
                            src: p.a,
                            mode: "widthFix",
                            style: {
                                height: "".concat(this.state.windowHeight, "px")
                            }
                        }), Object(z["jsxs"])(u["m"], {
                            className: "topWrap",
                            style: {
                                paddingTop: "".concat(this.state.navTop, "px"),
                                lineHeight: "".concat(this.state.height, "px"),
                                height: "".concat(this.state.height + this.state.navTop + 25, "px"),
                                backgroundImage: "url(".concat(p.a, ")")
                            },
                            children: [ Object(z["jsx"])(u["m"], {
                                className: "navTop",
                                children: Object(z["jsx"])(u["m"], {
                                    style: "position: relative; z-index: 999",
                                    children: "睡眠"
                                })
                            }), Object(z["jsx"])(u["h"], {
                                scrollX: !0,
                                scrollWithAnimation: !0,
                                enhanced: !0,
                                showScrollbar: !1,
                                className: "scrollWrap menuWrap",
                                style: {
                                    paddingTop: "10px",
                                    backgroundImage: "url(".concat(p.a, ")")
                                },
                                scrollIntoView: this.state.anchorName,
                                children: this.state.menuData.map(function(e, t) {
                                    return Object(z["jsx"])(u["m"], {
                                        className: "menuItem",
                                        "data-index": t,
                                        "data-categoryType": e.categoryType,
                                        id: "".concat(e.categoryType, "Anchor"),
                                        onClick: function(e) {
                                            i.checkTabItem(e);
                                        },
                                        children: Object(z["jsxs"])(u["m"], {
                                            className: "mi",
                                            children: [ Object(z["jsx"])(u["l"], {
                                                children: e.categoryName
                                            }), i.state.anchorName == "".concat(e.categoryType, "Anchor") && Object(z["jsx"])(u["m"], {
                                                className: "tabsLine"
                                            }) ]
                                        })
                                    });
                                })
                            }) ]
                        }), Object(z["jsxs"])(u["h"], {
                            scrollY: !0,
                            scrollWithAnimation: !0,
                            enhanced: !0,
                            showScrollbar: !1,
                            className: "scrollWrap anchorsWrap",
                            scrollIntoView: this.state.panelDetail,
                            onScroll: function(e) {
                                return i.handlePageScroll(e);
                            },
                            style: {
                                height: "".concat(this.state.windowHeight - 10, "px"),
                                paddingTop: "".concat(this.state.height + this.state.navTop + 50, "px")
                            },
                            children: [ Object(z["jsxs"])(u["m"], {
                                className: "natureWrap anchorItem",
                                "data-categoryType": null === (e = this.state.menuData[0]) || void 0 === e ? void 0 : e.categoryType,
                                id: null === (t = this.state.menuData[0]) || void 0 === t ? void 0 : t.categoryType,
                                children: [ Object(z["jsx"])(u["m"], {
                                    className: "title",
                                    children: "大自然声"
                                }), Object(z["jsxs"])(u["h"], {
                                    scrollX: !0,
                                    scrollWithAnimation: !0,
                                    enhanced: !0,
                                    showScrollbar: !1,
                                    className: "scrollWrap circleWrap",
                                    children: [ Object(z["jsx"])(u["m"], {
                                        children: null === (s = this.state.menuData[0]) || void 0 === s ? void 0 : s.list.map(function(e, t) {
                                            var s;
                                            if (t <= (null === (s = i.state.menuData[0]) || void 0 === s ? void 0 : s.list.length) / 2) return Object(z["jsxs"])(u["m"], {
                                                className: "circleItem",
                                                onClick: function() {
                                                    return i.toNature(e);
                                                },
                                                children: [ Object(z["jsx"])(u["c"], {
                                                    className: "topImgBg",
                                                    webp: !0,
                                                    src: e.thumbImg,
                                                    mode: "aspectFill",
                                                    lazyLoad: !0
                                                }), Object(z["jsx"])(u["m"], {
                                                    className: "ellipsis",
                                                    children: e.title
                                                }), "vip" != e.typeNew || i.state.isVip ? null : Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: b.a,
                                                    mode: "heightFix"
                                                }) ]
                                            });
                                        })
                                    }), Object(z["jsx"])(u["m"], {
                                        children: null === (a = this.state.menuData[0]) || void 0 === a ? void 0 : a.list.map(function(e, t) {
                                            var s;
                                            if (t > (null === (s = i.state.menuData[0]) || void 0 === s ? void 0 : s.list.length) / 2) return Object(z["jsxs"])(u["m"], {
                                                className: "circleItem",
                                                onClick: function() {
                                                    return i.toNature(e);
                                                },
                                                children: [ Object(z["jsx"])(u["c"], {
                                                    className: "topImgBg",
                                                    webp: !0,
                                                    src: e.thumbImg,
                                                    mode: "aspectFill",
                                                    lazyLoad: !0
                                                }), Object(z["jsx"])(u["m"], {
                                                    className: "ellipsis",
                                                    children: e.title
                                                }), "vip" != e.typeNew || i.state.isVip ? null : Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: b.a,
                                                    mode: "heightFix"
                                                }) ]
                                            });
                                        })
                                    }) ]
                                }) ]
                            }), this.state.menuData.map(function(e, t) {
                                if (t >= 1) return Object(z["jsxs"])(u["m"], {
                                    className: "panelWrap anchorItem",
                                    "data-categoryType": e.categoryType,
                                    id: e.categoryType,
                                    children: [ Object(z["jsx"])(u["m"], {
                                        className: "title",
                                        children: e.categoryName
                                    }), Object(z["jsx"])(u["m"], {
                                        className: "itemWrap",
                                        children: e.list.map(function(e) {
                                            return Object(z["jsxs"])(u["m"], {
                                                className: "videoItem",
                                                onClick: function() {
                                                    return i.toDetail(e, e.type);
                                                },
                                                children: [ Object(z["jsx"])(u["m"], {
                                                    className: "vCover"
                                                }), Object(z["jsx"])(u["c"], {
                                                    className: "topImgBg",
                                                    webp: !0,
                                                    src: e.thumbImg,
                                                    mode: "aspectFill",
                                                    lazyLoad: !0
                                                }), 1 == e.isNew ? Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: O.a,
                                                    mode: "heightFix"
                                                }) : null, 0 != e.isNew || i.state.isVip || "1" != e.vipCourseUnlock ? null : Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: w.a,
                                                    mode: "heightFix"
                                                }), 0 != e.isNew || i.state.isVip || "0" != e.vipCourseUnlock ? null : Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: N.a,
                                                    mode: "heightFix"
                                                }), 0 != e.isNew || i.state.isVip || "2" != e.vipCourseUnlock ? null : Object(z["jsx"])(u["c"], {
                                                    className: "icon",
                                                    src: v.a,
                                                    mode: "heightFix"
                                                }), Object(z["jsxs"])(u["m"], {
                                                    className: "infoWrap",
                                                    children: [ Object(z["jsx"])(u["m"], {
                                                        className: "f28",
                                                        children: e.title
                                                    }), Object(z["jsx"])(u["m"], {
                                                        className: "f20",
                                                        children: "singles" == e.typeSubcat ? "".concat(parseInt(U["a"].duration(e.duration, "seconds").asMinutes() + ""), "分钟") : "".concat(e.smallNum, "课时")
                                                    }) ]
                                                }) ]
                                            });
                                        })
                                    }) ]
                                });
                            }) ]
                        }), this.state.inviteVisible && Object(z["jsx"])(u["m"], {
                            className: "cover",
                            onClick: this.handleInviteVisible.bind(this),
                            style: {
                                height: "100%"
                            }
                        }), this.state.inviteVisible && Object(z["jsxs"])(u["m"], {
                            className: "inviteWrap",
                            style: {
                                width: "".concat(this.state.windowWidth - 62, "px")
                            },
                            children: [ Object(z["jsx"])(u["c"], {
                                src: S.a,
                                mode: "aspectFill",
                                className: "topImg"
                            }), Object(z["jsx"])(u["m"], {
                                className: "f32 orange",
                                children: this.state.unlockCourseSendFriendTxt[0]
                            }), Object(z["jsx"])(u["m"], {
                                className: "f32",
                                children: this.state.unlockCourseSendFriendTxt[1]
                            }), Object(z["jsx"])(u["m"], {
                                className: "f24",
                                children: this.state.unlockCourseSendFriendTxt[2]
                            }), Object(z["jsxs"])(u["m"], {
                                className: "headWrap",
                                children: [ this.state.inviteFriends.map(function(e) {
                                    return Object(z["jsx"])(u["c"], {
                                        src: e.avatar || C.a,
                                        webp: !0,
                                        className: "head",
                                        mode: "aspectFill"
                                    });
                                }), H.a.times(this.state.unlockCourseSendFriends - this.state.inviteFriends.length, function() {
                                    return Object(z["jsx"])(u["c"], {
                                        src: D.a,
                                        className: "empty",
                                        mode: "aspectFill"
                                    });
                                }) ]
                            }), this.state.inviteFriends.length === this.state.unlockCourseSendFriends ? Object(z["jsxs"])(u["m"], {
                                className: "unlockWrap",
                                children: [ Object(z["jsx"])(u["c"], {
                                    src: w.a,
                                    mode: "aspectFit",
                                    className: "icon"
                                }), Object(z["jsx"])(u["l"], {
                                    children: "您已解锁"
                                }) ]
                            }) : Object(z["jsxs"])(u["m"], {
                                className: "f24 grey",
                                children: [ "还差", this.state.unlockCourseSendFriends - this.state.inviteFriends.length, "位" ]
                            }), this.state.inviteFriends.length === this.state.unlockCourseSendFriends && Object(z["jsx"])(u["m"], {
                                className: "btn",
                                onClick: function() {
                                    i.handleInviteVisible(), i.setState({
                                        isVip: !0
                                    }), i.refreshPage();
                                },
                                children: "现在去听课"
                            }), this.state.inviteFriends.length !== this.state.unlockCourseSendFriends && Object(z["jsx"])(u["a"], {
                                openType: "share",
                                className: "cleanBtn btn",
                                children: "立即赠送好友"
                            }), Object(z["jsx"])(u["j"], {
                                className: "tipSwiper",
                                vertical: !0,
                                autoplay: !0,
                                circular: !0,
                                children: this.state.inviteFriends.map(function(e) {
                                    return Object(z["jsx"])(u["k"], {
                                        children: Object(z["jsxs"])(u["m"], {
                                            className: "f24",
                                            children: [ e.nickname, "已领取成功" ]
                                        })
                                    });
                                })
                            }), Object(z["jsx"])(u["c"], {
                                src: I.a,
                                className: "closeBtn",
                                onClick: function() {
                                    return i.handleInviteVisible();
                                }
                            }) ]
                        }) ]
                    });
                }
            } ]), s;
        }(o["Component"]), M = {
            navigationBarTitleText: "睡眠",
            navigationStyle: "custom"
        };
        L.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(L, "pages/sleep/index", {
            root: {
                cn: []
            }
        }, M || {}));
    },
    48: function(e, t, s) {
        e.exports = s.p + "images/sleep/sleepBack.jpg";
    },
    59: function(e, t, s) {
        e.exports = s.p + "images/icons/vip2.png";
    }
}, [ [ 290, 0, 1, 2, 3 ] ] ]);