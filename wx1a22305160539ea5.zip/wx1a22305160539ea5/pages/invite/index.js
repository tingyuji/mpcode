(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 20 ], {
    221: function(e, t, s) {
        e.exports = s.p + "images/invite/ban.png";
    },
    222: function(e, t, s) {
        e.exports = s.p + "images/icons/press.png";
    },
    279: function(e, t, s) {},
    294: function(e, t, s) {
        "use strict";
        s.r(t);
        var n = s(7), a = s(10), i = s(11), c = s(12), o = s(13), r = s(14), p = s(5), l = s.n(p), u = s(1), h = s(6), m = s(221), d = s.n(m), j = s(222), g = s.n(j), b = (s(279), 
        s(8)), v = s(3), x = s(0), f = function(e) {
            Object(c["a"])(s, e);
            var t = Object(o["a"])(s);
            function s(e) {
                var n;
                return Object(a["a"])(this, s), n = t.call(this, e), n.state = {
                    options: h["a"].getCurrentPageParam(),
                    swiperIndex: 0,
                    postList: []
                }, n;
            }
            return Object(i["a"])(s, [ {
                key: "bindChange",
                value: function(e) {
                    this.setState({
                        swiperIndex: e.detail.current
                    });
                }
            }, {
                key: "savePost",
                value: function() {
                    l.a.downloadFile({
                        url: this.state.postList[this.state.swiperIndex].shareImg,
                        success: function(e) {
                            200 === e.statusCode && l.a.saveImageToPhotosAlbum({
                                filePath: e.tempFilePath,
                                success: function(e) {
                                    console.log(e), l.a.showToast({
                                        title: "已保存至相册",
                                        icon: "none"
                                    });
                                }
                            });
                        }
                    });
                }
            }, {
                key: "componentDidShow",
                value: function() {
                    var e = this;
                    this.state.options.activeId ? Object(b["m"])({
                        activeId: this.state.options.activeId
                    }).then(function(t) {
                        e.setState({
                            postList: t.result
                        });
                    }) : Object(b["o"])({
                        page: 1,
                        size: 10
                    }).then(function(e) {
                        return e.result.list[0].activeId;
                    }).then(function(t) {
                        Object(b["m"])({
                            activeId: t
                        }).then(function(t) {
                            e.setState({
                                postList: t.result
                            });
                        });
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function() {
                    var e = Object(v["a"])("appConfig").gotoVip, t = e + "?id=" + Object(v["a"])("nowUser").id + "&inviteCode=".concat(Object(v["a"])("nowUser").invitCode);
                    return {
                        title: Object(v["a"])("nowUser").nickname + "邀请你参与邀请有礼，快来参加吧",
                        path: "/pages/webView/index?url=" + t,
                        imageUrl: this.state.postList[this.state.swiperIndex].shareImg
                    };
                }
            }, {
                key: "render",
                value: function() {
                    var e = this;
                    return Object(x["jsxs"])(u["m"], {
                        className: "container inviteWrap",
                        children: [ Object(x["jsx"])(u["c"], {
                            src: d.a,
                            className: "topImg",
                            mode: "heightFix"
                        }), Object(x["jsx"])(u["m"], {
                            className: "swiperWrap",
                            children: Object(x["jsx"])(u["j"], {
                                className: "inviteImgs",
                                previousMargin: "60px",
                                nextMargin: "60px",
                                circular: !0,
                                onChange: this.bindChange.bind(this),
                                children: this.state.postList.map(function(t, s) {
                                    return Object(x["jsx"])(u["k"], {
                                        children: Object(x["jsx"])(u["c"], {
                                            showMenuByLongpress: !0,
                                            src: t.shareImg,
                                            mode: "aspectFill",
                                            lazyLoad: !0,
                                            webp: !0,
                                            className: e.state.swiperIndex == s ? "active img" : "quiet img"
                                        })
                                    });
                                })
                            })
                        }), Object(x["jsxs"])(u["m"], {
                            className: "card f24",
                            children: [ Object(x["jsx"])(u["c"], {
                                src: g.a,
                                className: "icon",
                                mode: "aspectFill"
                            }), Object(x["jsx"])(u["m"], {
                                className: "f24 orange",
                                children: "长按图片，立即分享给好友吧～"
                            }) ]
                        }), Object(x["jsx"])(u["m"], {
                            className: "shareWrap",
                            children: Object(x["jsx"])(u["m"], {
                                className: "btnWrap",
                                children: Object(x["jsx"])(u["m"], {
                                    onClick: function() {
                                        return e.savePost();
                                    },
                                    className: "goBtn",
                                    children: "保存本地"
                                })
                            })
                        }) ]
                    });
                }
            } ]), s;
        }(r["Component"]), O = {
            navigationBarTitleText: "邀请好友"
        };
        f.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(f, "pages/invite/index", {
            root: {
                cn: []
            }
        }, O || {}));
    }
}, [ [ 294, 0, 1, 2, 3 ] ] ]);