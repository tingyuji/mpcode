(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 22 ], {
    239: function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAWCAYAAADeiIy1AAAAAXNSR0IArs4c6QAAAuFJREFUSEu11U1IVFEUB/D/eTPjJw6jZGH5gWApBaGLNqJJMgsxCKcgbNGqZRBO6ygkClzYvIgWSosgqEBIaWPUIgKhMEvTcSFGILYoHR1n1NH5uOfEezNjpc6Hi3nre+/vnXPP/z3CAR7x3slbWs8f0hTfLW+5NXGAraBsF4uAfON9L4X5sgivMKu2ipbbs9nuzxryjfc9ZMYNCEOEAeZfpMVaDzf3fs8Gywpamei/yaz6hQVJSNgEF5gjrcfa7i1mwjJCq18fdLOS5yKK9oEMbM4SibYdcd7/nQ5LC/m+eNpJZFSE84x2pYBAItMxG52rau5dTYXR2szgBJF8ItDbsNXyvrzh2rqx2D/paWTWPogo+9927Wld8r4AyOfNUMB5vPNR0Ni/+MZdRqS1K1ZOEM5QwDs4CaDRfBORCIv6KEq9A+S6MFeYF58YgFQVIX5fEJExEjWmWJwk3MTCFogYJ09RcHZgWIS64o7Rnn8PTkxY9tBOhXHYOEtAkBFa9w54GNSTSwgQnfzegR4N5MklxCxu8k8PdGkaDaeCtHwHiirPYuPHKFRk478ckbUIjvqLCMy/RnRzybijfVvHLC7yex83arAZA7HvHZXUuWCzVyO6/hOBuSFILGyuI2shSk9dhbXoELaWZ+GffZEaUtJE/kmPQ7MV+1NBxoH2+m5Y8u0Ir84jOP8KgAbHySuwlVQiFvJhZeqJWW3Kirak1AxswDtoQI5UU2fJd8De0A3NWojtpW+wFJTBZq8ykdWZp1DbweR479e6tZoOzw5kZindeFuLj8J+4hLIkmdGjiMb8BmVhNeMD2w6aKqmw9NkVpTMUqYc5TmOo6TuAiQagt/7DNHQ8q4K9g4DCY9Ud+guE0pmKRNkfBkKyk8jElxAbDOOJH4ZaSpivaZDd5tQMkvZQLt+ExkhVuyu7dT1OJTIUo4gV22nPpKoKJ6lnEAxbqo9r0/FoUSWcgKFuLTWpa/9AabiVl+12rxRAAAAAElFTkSuQmCC";
    },
    240: function(e, t, a) {
        e.exports = a.p + "images/icons/vip3.png";
    },
    241: function(e, t, a) {
        e.exports = a.p + "images/icons/vipBg.png";
    },
    242: function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAAAXNSR0IArs4c6QAAAJ9QTFRFAAAAampqZmZmcXFxbW1tZqamap+fbGxsaqencHBwb29vcHBwcXFxcHBwbnV1b29va42Na42PboKCbYWFbIyMcHBwcHBwcHBwcHBwboGBboKCcHBwb29vbn19cHBwZd3ebJWVZd3eb29vb3Z2b3d3cHNzb3JyZdjYZd3eZ8HCZ8bHabO0abS0a5+gbJmZbYuLbYuMbnt7boaGb3h4cHBwk08nyQAAACd0Uk5TAAwUGxwoMDQ6QExQX2BmZ2lpcneOj5+rv8fKy+Pn6+3u9ff6+/3+YJhSVAAAALxJREFUSMftldkSgjAMRcEdFXcBxRUXwAW3/P+3SXHQZCZT+qAPKuc190zazDTVtBxVivYMpKzHFZwvZcQTpYYEGxQYISFuYHAnnQcpIcAKFWKfvVrwgkb+WnC4+Z/eKfzClIYO5Sw4SoQJN6WLRNANSijwv2tKTYsSCQ4SgV0eN4lQNSl7wS5/0w88AJ0Tls+8D7BBBRfAtRgWUcoVYIqEhsr27uLebS8rvh3Q0xbqJkur10/olPNv+qPcAWUwjmU/rX+NAAAAAElFTkSuQmCC";
    },
    243: function(e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAAAXNSR0IArs4c6QAAAUFQTFRFAAAAQEBAZszMVdTUbdvbYGBgYtjYYN/fa2trZmZmYdvbXdzcampqY97ec3NzcHBwampqb29vbm5ucnJybm5ubW1tYt3dbm5ucXFxbW1tcXFxaLi4b29vcHBwcXFxZN3db29vb29vcHBwcHBwb3Fxb29vcHBwcHBwb29vb29vZNzecHBwb29vb29vZNzeY9zeZd3eZdzdcHBwZNzeb29vZd3eb29vcHBwcHBwZN3ea6Cgb3Fxb29vZd3eaqOjcHBwb29vb29vb3FyZdzdcHBwZdbXZd3eZs/QZtLTaqSlaqana56ea5+fb3Nzb3Z3cHBwcXFxcnJydnZ2eHh4eXl5f39/gYGBhoaGk5OTlZWVmJiYmpqapaWlp6ensLCwxMTE09PT1NTU1tbW19fX29vb3d3d39/f6+vr9vb2+vr6////5mUgVQAAAEZ0Uk5TAAQFBgcIDRATFBUWGB8fICQnLC8zODw8P0RPXWdrb3BzdXt/gYOJj5OXm5ujp7CxtL6/xsfS19vf4uPj5+vu7/P3+Pr7/BmdgoQAAAFtSURBVEjH7ZZrNwJBGMcn1yK5phbLsihyTdoQLdag6F8ql1wjt/3+H8CL1rZR28wbx3H83j3n+f9m9jyzZ84Q8s+QLDotpVuaGrTNjwGI95nlgApoIzb59gTurhAxyyiubxGzEXpxrr8VIBLi8RBCZnDxrp/Bboc4SnoJagQAIpNa9kW/R7Re0umvEELh6TEHZPL5DIBi+SGHWaPnr07DFQYTYZchLIKRBUNIAJcMAAlDAKAzAOAnhTIDVUFhnZJiCCKrIH6eXBCIhetTmTgQ3gKC5lHLgNzg96rMA+jasWYYhPkkp0B/lfD6zCfcZFHkEqDtgUfYDYweHJ+yCwF35walRyfMAiHLlFJK2YUJyicM7/MJPduUS+hYp1xC6yrlElqWaANhHAh9z7etWPI0BUhmSwDU/q/57jVr/jANCGbPoQDqnFzD9GbSQioNKI7qal61+ZWh+az7e5veTYqv9osdgiTbIAmOP/RW+ADhViH/h3ThMwAAAABJRU5ErkJggg==";
    },
    244: function(e, t, a) {
        e.exports = a.p + "images/icons/star.png";
    },
    245: function(e, t, a) {
        e.exports = a.p + "images/icons/close.png";
    },
    286: function(e, t, a) {},
    300: function(e, t, a) {
        "use strict";
        a.r(t);
        var s = a(7), c = a(17), n = a.n(c), i = a(21), r = a(10), o = a(11), l = a(12), b = a(13), m = a(14), d = a(5), u = a.n(d), j = a(1), h = a(30), A = a.n(h), g = a(239), x = a.n(g), p = a(240), O = a.n(p), v = a(33), w = a.n(v), f = a(241), N = a.n(f), B = a(242), y = a.n(B), k = a(243), C = a.n(k), S = a(244), I = a.n(S), Z = a(245), F = a.n(Z), T = a(32), H = a.n(T), D = a(31), V = a.n(D), U = (a(286), 
        a(6)), W = a(3), M = a(8), Y = a(0), J = function(e) {
            Object(l["a"])(a, e);
            var t = Object(b["a"])(a);
            function a(e) {
                var s;
                return Object(r["a"])(this, a), s = t.call(this, e), s.state = {
                    windowHeight: u.a.getSystemInfoSync().windowHeight,
                    userData: Object(W["a"])("nowUser"),
                    menu: [],
                    modalVisible: !1,
                    extrasImg: "",
                    contactVisible: !1,
                    avatar: "",
                    extrasTitle: ""
                }, s;
            }
            return Object(o["a"])(a, [ {
                key: "getUserInfo",
                value: function() {
                    var e = this;
                    Object(M["w"])().then(function(t) {
                        t.result != {} ? (e.setState({
                            userData: t.result,
                            avatar: t.result.avatar
                        }), t.result.avatar != e.state.avatar && e.setState({
                            avatar: t.result.avatar
                        }), Object(W["c"])("nowUser", t.result), console.log("我是用户资料" + JSON.stringify(t.result))) : (Object(W["c"])("nowUser", ""), 
                        u.a.setStorageSync("accessToken", ""));
                    }).catch(function() {
                        Object(W["c"])("nowUser", "");
                    });
                }
            }, {
                key: "componentDidShow",
                value: function() {
                    var e = this;
                    u.a.setTabBarStyle({
                        backgroundColor: "#ffffff",
                        color: "#707070",
                        selectedColor: "#4CCBCC"
                    }), U["a"].requireLogin().then(function() {
                        e.getUserInfo();
                    });
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    var e = this;
                    Object(M["b"])().then(function(t) {
                        e.setState({
                            menu: t.result
                        });
                    });
                }
            }, {
                key: "toLogin",
                value: function() {
                    var e = Object(i["a"])(n.a.mark(function e() {
                        var t;
                        return n.a.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                t = this, u.a.getUserProfile({
                                    desc: "用于完善会员资料",
                                    success: function() {
                                        var e = Object(i["a"])(n.a.mark(function e(a) {
                                            return n.a.wrap(function(e) {
                                                while (1) switch (e.prev = e.next) {
                                                  case 0:
                                                    Object(W["c"])("userInfo", a.userInfo), u.a.login({
                                                        success: function(e) {
                                                            console.log(e), e.code ? Object(M["f"])({
                                                                code: e.code,
                                                                account: JSON.stringify(Object(W["a"])("userInfo")),
                                                                inviteCode: U["a"].getCurrentPageParam().inviteCode || "",
                                                                courseId: U["a"].getCurrentPageParam().id || ""
                                                            }).then(function(e) {
                                                                u.a.setStorageSync("accessToken", e.result.token), console.log("这是token" + e.result.token), 
                                                                t.getUserInfo(), console.log("登录成功！");
                                                            }) : console.log("登录失败！" + e.errMsg);
                                                        }
                                                    });

                                                  case 2:
                                                  case "end":
                                                    return e.stop();
                                                }
                                            }, e);
                                        }));
                                        function a(t) {
                                            return e.apply(this, arguments);
                                        }
                                        return a;
                                    }()
                                });

                              case 2:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    function t() {
                        return e.apply(this, arguments);
                    }
                    return t;
                }()
            }, {
                key: "goMenu",
                value: function(e) {
                    "view" == e.clickType && (Object(W["c"])("webUrl", e.extras), U["a"].navigatorTo("../webView/index?url=" + e.extras)), 
                    "modal" == e.clickType && (this.handleModalVisible(), this.setState({
                        extrasTitle: e.title,
                        extrasImg: e.extras
                    }));
                }
            }, {
                key: "handleModalVisible",
                value: function() {
                    this.setState({
                        modalVisible: !this.state.modalVisible
                    });
                }
            }, {
                key: "bindingMobile",
                value: function(e) {
                    var t = e.encryptedData, a = e.iv, s = this;
                    u.a.login({
                        success: function(e) {
                            var c = e.code, n = e.errMsg;
                            c ? Object(M["g"])({
                                code: c,
                                encryptedData: t,
                                iv: a
                            }).then(function(e) {
                                u.a.showToast({
                                    title: e.msg || "绑定成功！",
                                    icon: "none"
                                }), s.getUserInfo();
                            }).catch(function(e) {
                                u.a.showToast({
                                    title: e.msg,
                                    icon: "none"
                                });
                            }) : u.a.showToast({
                                title: n,
                                icon: "none"
                            });
                        }
                    });
                }
            }, {
                key: "toVip",
                value: function() {
                    var e = Object(W["a"])("appConfig").gotoVip;
                    Object(W["c"])("webUrl", e + "?id=" + Object(W["a"])("nowUser").id), U["a"].navigatorTo("../webView/index?url=" + e + "?id=" + Object(W["a"])("nowUser").id);
                }
            }, {
                key: "handleContact",
                value: function() {
                    this.setState({
                        contactVisible: !this.state.contactVisible
                    });
                }
            }, {
                key: "componentDidHide",
                value: function() {
                    this.setState({
                        contactVisible: !1
                    });
                }
            }, {
                key: "changeImg",
                value: function() {
                    this.state.userData.avatar = this.state.userData.avatar, this.setState({
                        userData: this.state.userData
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function() {}
            }, {
                key: "render",
                value: function() {
                    var e, t, a, s = this;
                    return Object(Y["jsxs"])(j["m"], {
                        className: "contaniner myWrap",
                        children: [ Object(Y["jsxs"])(j["m"], {
                            className: "userWrap",
                            style: Object(W["a"])("system").includes("iOS") ? {
                                paddingBottom: "0"
                            } : {},
                            children: [ this.state.userData && this.state.avatar ? Object(Y["jsx"])(j["m"], {
                                className: "avatarImg",
                                children: Object(Y["jsx"])(j["c"], {
                                    src: this.state.avatar,
                                    webp: !0,
                                    className: "img",
                                    mode: "aspectFill",
                                    onError: function() {
                                        return s.changeImg();
                                    }
                                })
                            }) : Object(Y["jsx"])(j["m"], {
                                className: "avatarImg",
                                children: Object(Y["jsx"])(j["c"], {
                                    src: A.a,
                                    className: "img",
                                    mode: "aspectFill"
                                })
                            }), Object(Y["jsx"])(j["m"], {
                                className: "infoWrap",
                                children: this.state.userData && this.state.userData.id ? Object(Y["jsxs"])(j["m"], {
                                    children: [ Object(Y["jsxs"])(j["m"], {
                                        className: "nameWrap",
                                        children: [ Object(Y["jsx"])(j["l"], {
                                            children: this.state.userData.nickname
                                        }), (null === (e = this.state.userData.nowVip) || void 0 === e ? void 0 : e.isVip) && Object(Y["jsx"])(j["c"], {
                                            src: x.a,
                                            className: "vipImg",
                                            mode: "widthFix"
                                        }) ]
                                    }), Object(Y["jsxs"])(j["m"], {
                                        className: "idWrap",
                                        children: [ "ID:", this.state.userData.id ]
                                    }) ]
                                }) : Object(Y["jsx"])(j["m"], {
                                    className: "noLogin",
                                    onClick: this.toLogin.bind(this),
                                    children: "登录体验更多"
                                })
                            }) ]
                        }), Object(W["a"])("system").includes("iOS") ? null : Object(Y["jsxs"])(j["m"], {
                            className: "vipWrap",
                            onClick: function() {
                                return s.toVip();
                            },
                            children: [ Object(Y["jsx"])(j["c"], {
                                src: N.a,
                                className: "vipBg",
                                mode: "heightFix"
                            }), Object(Y["jsxs"])(j["m"], {
                                className: "vipInfo",
                                children: [ Object(Y["jsxs"])(j["m"], {
                                    className: "name",
                                    children: [ Object(Y["jsx"])(j["c"], {
                                        src: O.a,
                                        className: "vipImg",
                                        mode: "aspectFit"
                                    }), Object(Y["jsx"])(j["l"], {
                                        children: "Now 会员卡"
                                    }) ]
                                }), Object(Y["jsx"])(j["m"], {
                                    className: "tip",
                                    children: null === (t = this.state.userData.nowVip) || void 0 === t ? void 0 : t.expireNotice
                                }) ]
                            }), Object(Y["jsx"])(j["m"], {
                                className: "btn",
                                children: null !== (a = this.state.userData.nowVip) && void 0 !== a && a.isVip ? "立即续费" : "立即加入"
                            }) ]
                        }), Object(Y["jsxs"])(j["m"], {
                            className: "card",
                            children: [ Object(Y["jsx"])(j["m"], {
                                className: "title",
                                children: "练习数据"
                            }), Object(Y["jsxs"])(j["m"], {
                                className: "dataWrap",
                                children: [ Object(Y["jsxs"])(j["m"], {
                                    className: "dataItem",
                                    children: [ Object(Y["jsx"])(j["m"], {
                                        className: "num",
                                        children: this.state.userData.durationMinutes || 0
                                    }), Object(Y["jsx"])(j["m"], {
                                        className: "unit",
                                        children: "累计（分钟）"
                                    }) ]
                                }), Object(Y["jsxs"])(j["m"], {
                                    className: "dataItem",
                                    children: [ Object(Y["jsx"])(j["m"], {
                                        className: "num",
                                        children: this.state.userData.practiceDays || 0
                                    }), Object(Y["jsx"])(j["m"], {
                                        className: "unit",
                                        children: "累计（天数）"
                                    }) ]
                                }), Object(Y["jsxs"])(j["m"], {
                                    className: "dataItem",
                                    children: [ Object(Y["jsx"])(j["m"], {
                                        className: "num",
                                        children: this.state.userData.continueDays || 0
                                    }), Object(Y["jsx"])(j["m"], {
                                        className: "unit",
                                        children: "连续（天数）"
                                    }) ]
                                }) ]
                            }) ]
                        }), Object(Y["jsx"])(j["m"], {
                            onClick: function() {
                                return s.handleContact();
                            },
                            className: "goBtn",
                            children: "去Now冥想App体验更多"
                        }), Object(Y["jsxs"])(j["m"], {
                            className: "card entryWrap",
                            style: Object(W["a"])("system").includes("iOS") ? {
                                padding: "0 80px"
                            } : {},
                            children: [ Object(Y["jsxs"])(j["m"], {
                                onClick: function() {
                                    return U["a"].navigatorTo("../myPractice/index");
                                },
                                children: [ Object(Y["jsx"])(j["c"], {
                                    src: y.a,
                                    className: "icon",
                                    mode: "aspectFit"
                                }), Object(Y["jsx"])(j["m"], {
                                    children: "我的练习"
                                }) ]
                            }), Object(Y["jsxs"])(j["m"], {
                                onClick: function() {
                                    return U["a"].navigatorTo("../collect/index");
                                },
                                children: [ Object(Y["jsx"])(j["c"], {
                                    src: I.a,
                                    className: "icon",
                                    mode: "aspectFit"
                                }), Object(Y["jsx"])(j["m"], {
                                    children: "我的收藏"
                                }) ]
                            }), Object(W["a"])("system").includes("iOS") ? null : Object(Y["jsxs"])(j["m"], {
                                onClick: function() {
                                    return U["a"].navigatorTo("../spread/index");
                                },
                                children: [ Object(Y["jsx"])(j["c"], {
                                    src: C.a,
                                    className: "icon",
                                    mode: "aspectFit"
                                }), Object(Y["jsx"])(j["m"], {
                                    children: "推广赚钱"
                                }) ]
                            }) ]
                        }), this.state.userData.bindingMobile ? Object(Y["jsxs"])(j["m"], {
                            className: "cleanBtn card cell",
                            children: [ Object(Y["jsx"])(j["m"], {
                                children: "已绑定手机号"
                            }), Object(Y["jsx"])(j["c"], {
                                src: w.a,
                                className: "goIcon",
                                mode: "widthFix"
                            }) ]
                        }) : Object(Y["jsxs"])(j["a"], {
                            openType: "getPhoneNumber",
                            className: "cleanBtn card cell",
                            onGetPhoneNumber: function(e) {
                                return s.bindingMobile(e.detail);
                            },
                            children: [ Object(Y["jsx"])(j["m"], {
                                children: "绑定手机号"
                            }), Object(Y["jsx"])(j["c"], {
                                src: w.a,
                                className: "goIcon",
                                mode: "widthFix"
                            }) ]
                        }), Object(Y["jsx"])(j["m"], {
                            className: "card",
                            children: this.state.menu.map(function(e) {
                                return Object(Y["jsxs"])(j["m"], {
                                    className: "cell",
                                    onClick: function() {
                                        return s.goMenu(e);
                                    },
                                    children: [ Object(Y["jsx"])(j["m"], {
                                        children: e.title
                                    }), Object(Y["jsx"])(j["c"], {
                                        src: w.a,
                                        className: "goIcon",
                                        mode: "widthFix"
                                    }) ]
                                });
                            })
                        }), this.state.modalVisible && Object(Y["jsx"])(j["m"], {
                            className: "cover",
                            onClick: this.handleModalVisible.bind(this),
                            style: {
                                height: "".concat(this.state.windowHeight, "px")
                            }
                        }), this.state.modalVisible && Object(Y["jsxs"])(j["m"], {
                            className: "modalWrap",
                            children: [ Object(Y["jsx"])(j["m"], {
                                children: this.state.extrasTitle
                            }), Object(Y["jsx"])(j["c"], {
                                showMenuByLongpress: !0,
                                src: this.state.extrasImg,
                                webp: !0,
                                mode: "widthFix",
                                className: "extraImg"
                            }), Object(Y["jsx"])(j["c"], {
                                src: F.a,
                                mode: "aspectFill",
                                onClick: this.handleModalVisible.bind(this),
                                className: "close"
                            }) ]
                        }), this.state.contactVisible && Object(Y["jsx"])(j["m"], {
                            className: "cover",
                            style: {
                                height: "".concat(this.state.windowHeight, "px")
                            }
                        }), this.state.contactVisible && Object(Y["jsx"])(j["m"], {
                            className: "conWrap",
                            children: Object(Y["jsxs"])(j["m"], {
                                className: "por-r",
                                children: [ Object(Y["jsx"])(j["a"], {
                                    className: "gotoApp",
                                    openType: "contact"
                                }), Object(Y["jsx"])(j["c"], {
                                    src: H.a,
                                    mode: "widthFix",
                                    className: "cenImg"
                                }), Object(Y["jsx"])(j["c"], {
                                    className: "close",
                                    onClick: function() {
                                        return s.handleContact();
                                    },
                                    src: V.a,
                                    mode: "aspectFill"
                                }) ]
                            })
                        }) ]
                    });
                }
            } ]), a;
        }(m["Component"]), E = {
            navigationBarTitleText: "我的"
        };
        J.enableShareAppMessage = !0;
        Page(Object(s["createPageConfig"])(J, "pages/my/index", {
            root: {
                cn: []
            }
        }, E || {}));
    }
}, [ [ 300, 0, 1, 2, 3 ] ] ]);