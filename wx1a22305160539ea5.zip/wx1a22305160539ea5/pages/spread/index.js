(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 34 ], {
    219: function(e, a, t) {
        e.exports = t.p + "images/icons/money.png";
    },
    220: function(e, a, t) {
        e.exports = t.p + "images/icons/homeActive.png";
    },
    278: function(e, a, t) {},
    293: function(e, a, t) {
        "use strict";
        t.r(a);
        var c = t(7), s = t(10), n = t(11), i = t(12), l = t(13), r = t(14), o = t(5), m = t.n(o), j = t(1), d = t(6), h = t(219), b = t.n(h), x = t(220), f = t.n(x), O = (t(278), 
        t(8)), u = t(3), p = t(0), N = function(e) {
            Object(i["a"])(t, e);
            var a = Object(l["a"])(t);
            function t(e) {
                var c;
                return Object(s["a"])(this, t), c = a.call(this, e), c.state = {
                    options: d["a"].getCurrentPageParam(),
                    dealerList: [],
                    accountInfo: {},
                    inviteNum: 0,
                    appConfig: Object(u["a"])("appConfig")
                }, c;
            }
            return Object(n["a"])(t, [ {
                key: "componentDidShow",
                value: function() {
                    var e = this;
                    Object(O["o"])({
                        page: 1,
                        size: 999
                    }).then(function(a) {
                        e.setState({
                            dealerList: a.result.list
                        });
                    }), Object(O["a"])({}).then(function(a) {
                        e.setState({
                            accountInfo: a.result
                        });
                    }), Object(O["x"])().then(function(a) {
                        e.setState({
                            inviteNum: a.result.number
                        });
                    });
                }
            }, {
                key: "backHome",
                value: function() {
                    m.a.switchTab({
                        url: "../index/index"
                    });
                }
            }, {
                key: "render",
                value: function() {
                    var e = this;
                    return Object(p["jsxs"])(j["m"], {
                        className: "container spreadWrap",
                        children: [ Object(p["jsxs"])(j["m"], {
                            className: "homeBtn",
                            onClick: function() {
                                return e.backHome();
                            },
                            children: [ Object(p["jsx"])(j["c"], {
                                src: f.a,
                                mode: "widthFix",
                                className: "icon"
                            }), Object(p["jsx"])(j["l"], {
                                className: "f24",
                                children: "首页"
                            }) ]
                        }), Object(p["jsxs"])(j["m"], {
                            className: "card moneyCard",
                            children: [ Object(p["jsxs"])(j["m"], {
                                className: "moneyBox",
                                children: [ Object(p["jsx"])(j["c"], {
                                    src: b.a,
                                    mode: "widthFix",
                                    className: "icon"
                                }), Object(p["jsx"])(j["l"], {
                                    children: "余额 (元)"
                                }), Object(p["jsxs"])(j["l"], {
                                    className: "f70 black",
                                    children: [ "￥", this.state.accountInfo.accountBalance ]
                                }) ]
                            }), Object(p["jsxs"])(j["m"], {
                                className: "totalWrap",
                                children: [ Object(p["jsxs"])(j["m"], {
                                    className: "totalItem",
                                    children: [ Object(p["jsx"])(j["m"], {
                                        className: "f24",
                                        children: "今日收益"
                                    }), Object(p["jsxs"])(j["m"], {
                                        className: "f40 grey",
                                        children: [ "￥", this.state.accountInfo.todayEarnings ]
                                    }) ]
                                }), Object(p["jsxs"])(j["m"], {
                                    className: "totalItem",
                                    children: [ Object(p["jsx"])(j["m"], {
                                        className: "f24",
                                        children: "累计收益"
                                    }), Object(p["jsxs"])(j["m"], {
                                        className: "f40 black",
                                        children: [ "￥", this.state.accountInfo.allEarnings ]
                                    }) ]
                                }) ]
                            }), Object(p["jsx"])(j["m"], {
                                className: "cashBtn",
                                "data-path": "../cashOut/index?accountBalance=".concat(this.state.accountInfo.accountBalance),
                                onClick: d["a"].navigatorTo,
                                children: "马上提现"
                            }), Object(p["jsx"])(j["m"], {
                                className: "f24 grey",
                                "data-path": "../profit/index",
                                onClick: d["a"].navigatorTo,
                                children: "收益明细"
                            }) ]
                        }), this.state.dealerList.map(function(e) {
                            return Object(p["jsxs"])(j["m"], {
                                className: "card goCard",
                                children: [ Object(p["jsxs"])(j["m"], {
                                    className: "title",
                                    children: [ Object(p["jsx"])(j["m"], {
                                        children: e.title
                                    }), Object(p["jsxs"])(j["m"], {
                                        className: "f24 orange",
                                        children: [ "预估收益：￥", e.forecastEarnings ]
                                    }) ]
                                }), Object(p["jsx"])(j["m"], {
                                    className: "btn f26",
                                    "data-path": "../invite/index?activeId=".concat(e.activeId),
                                    onClick: d["a"].navigatorTo,
                                    children: "去推广"
                                }) ]
                            });
                        }), 1 == this.state.appConfig.offerRewardIsOpen && Object(p["jsxs"])(j["m"], {
                            className: "card",
                            children: [ Object(p["jsxs"])(j["m"], {
                                className: "blockTitle",
                                children: [ Object(p["jsx"])(j["m"], {
                                    className: "line"
                                }), Object(p["jsx"])(j["m"], {
                                    className: "txt",
                                    children: "赏金任务"
                                }) ]
                            }), Object(p["jsxs"])(j["m"], {
                                className: "goCard",
                                children: [ Object(p["jsxs"])(j["m"], {
                                    className: "title",
                                    children: [ Object(p["jsx"])(j["m"], {
                                        children: this.state.appConfig.offerRewardTitle
                                    }), Object(p["jsxs"])(j["m"], {
                                        className: "f24 orange",
                                        children: [ "现金红包奖励：￥", this.state.appConfig.offerRewardBonus ]
                                    }) ]
                                }), Object(p["jsxs"])(j["m"], {
                                    className: "btn",
                                    children: [ Object(p["jsx"])(j["l"], {
                                        className: "f26",
                                        "data-path": "../invite/index",
                                        onClick: d["a"].navigatorTo,
                                        children: "去完成"
                                    }), Object(p["jsxs"])(j["l"], {
                                        className: "f24 grey",
                                        children: [ this.state.inviteNum, "/", this.state.appConfig.offerRewardOfOrders ]
                                    }) ]
                                }) ]
                            }) ]
                        }) ]
                    });
                }
            } ]), t;
        }(r["Component"]), g = {
            navigationBarTitleText: "推广赚钱"
        };
        Page(Object(c["createPageConfig"])(N, "pages/spread/index", {
            root: {
                cn: []
            }
        }, g || {}));
    }
}, [ [ 293, 0, 1, 2, 3 ] ] ]);