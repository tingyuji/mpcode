(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 28 ], {
    302: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e(7), i = e(10), c = e(11), o = e(12), s = e(13), r = e(14), u = e(5), p = e.n(u), g = e(6), l = e(1), f = e(8), b = e(0), m = function(n) {
            Object(o["a"])(e, n);
            var t = Object(s["a"])(e);
            function e(n) {
                var a;
                return Object(i["a"])(this, e), a = t.call(this, n), a.state = {
                    options: g["a"].getCurrentPageParam()
                }, a;
            }
            return Object(c["a"])(e, [ {
                key: "componentDidMount",
                value: function() {
                    var n = this;
                    g["a"].requireLogin().then(function() {
                        Object(f["v"])({
                            skuId: n.state.options.skuId
                        }).then(function(n) {
                            var t = n.result, e = t.timeStamp, a = t.nonceStr, i = t.signType, c = t.paySign;
                            p.a.requestPayment({
                                timeStamp: e,
                                nonceStr: a,
                                package: n.result.package,
                                signType: i,
                                paySign: c,
                                success: function(n) {
                                    p.a.showToast({
                                        title: "支付成功！",
                                        icon: "none"
                                    });
                                },
                                fail: function(n) {
                                    p.a.showToast({
                                        title: "支付失败！",
                                        icon: "none"
                                    });
                                },
                                complete: function() {
                                    g["a"].navigatorBack();
                                }
                            });
                        });
                    }).catch(function() {
                        p.a.switchTab({
                            url: "/pages/index/index"
                        });
                    });
                }
            }, {
                key: "render",
                value: function() {
                    return Object(b["jsx"])(l["m"], {
                        className: "container"
                    });
                }
            } ]), e;
        }(r["Component"]), h = {
            navigationBarTitleText: "购买",
            disableScroll: !0
        };
        Page(Object(a["createPageConfig"])(m, "pages/pay/index", {
            root: {
                cn: []
            }
        }, h || {}));
    }
}, [ [ 302, 0, 1, 2, 3 ] ] ]);