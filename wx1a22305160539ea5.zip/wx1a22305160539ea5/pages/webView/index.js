(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 36 ], {
    301: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a(7), r = a(10), o = a(11), s = a(12), c = a(13), i = a(14), b = a(5), l = a.n(b), w = a(6), p = a(1), u = a(3), g = a(0), h = function(e) {
            Object(s["a"])(a, e);
            var t = Object(c["a"])(a);
            function a(e) {
                var n;
                return Object(r["a"])(this, a), n = t.call(this, e), n.state = {
                    options: w["a"].getCurrentPageParam(),
                    webUrl: Object(u["a"])("webUrl") + "&pageType=wx"
                }, n;
            }
            return Object(o["a"])(a, [ {
                key: "componentDidMount",
                value: function() {
                    this.setState({
                        webUrl: Object(u["a"])("webUrl")
                    }), console.log(2, Object(u["a"])("webUrl") + "&pageType=wx"), l.a.showShareMenu({
                        withShareTicket: !0
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function(e) {
                    return "button" === e.from && console.log(e), console.log("/pages/webView/index?url=" + this.state.webUrl), 
                    {
                        path: "/pages/webView/index?url=" + this.state.webUrl
                    };
                }
            }, {
                key: "render",
                value: function() {
                    return Object(g["jsx"])(p["m"], {
                        className: "container videoWrap",
                        children: Object(g["jsx"])(p["n"], {
                            src: this.state.webUrl
                        })
                    });
                }
            } ]), a;
        }(i["Component"]), j = {};
        h.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(h, "pages/webView/index", {
            root: {
                cn: []
            }
        }, j || {}));
    }
}, [ [ 301, 0, 1, 2, 3 ] ] ]);