(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 26 ], {
    234: function(t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAYAAAA6RwvCAAAAAXNSR0IArs4c6QAAALhJREFUWEftWEsKQjEQS24g6kVmDqVb164fHsJDtRd5fm4QKbgQEfro82HB6arQTiZkQhZDzDjuvgNwekIcU0rnVji2FpY6M7uQXJe7pGvOedOKN4uIu+u1cUqpGa+5sBAIIu/zD0VCkVomhEfCI//pEXffSxpIbmsKLPEu6S7pQDO7kVwt0WQqpqSxCyIARpbRABgA/HY0U+X79C+SNZK15p/wSHgkPFJTIDxSU6ibHOlpLfG1Rc0DiGCfAMHofS0AAAAASUVORK5CYII=";
    },
    235: function(t, e, a) {
        t.exports = a.p + "images/nature/play.png";
    },
    236: function(t, e, a) {
        t.exports = a.p + "images/nature/pause.png";
    },
    237: function(t, e, a) {
        t.exports = a.p + "images/nature/share.png";
    },
    238: function(t, e, a) {
        t.exports = a.p + "images/nature/time.png";
    },
    285: function(t, e, a) {},
    299: function(t, e, a) {
        "use strict";
        a.r(e);
        for (var s, i, n = a(7), c = a(17), o = a.n(c), r = a(21), l = a(10), u = a(11), m = a(15), d = a(12), h = a(13), p = a(16), j = a(14), b = a(5), f = a.n(b), g = a(1), O = a(6), y = a(29), x = a.n(y), k = a(234), v = a.n(k), S = a(235), T = a.n(S), C = a(236), N = a.n(C), A = a(237), I = a.n(A), w = a(238), D = a.n(w), M = (a(285), 
        a(2)), P = a(47), H = a.n(P), B = a(3), U = a(8), V = a(0), F = [], W = 0; W <= 59; W++) F.push(W);
        var q = function(t) {
            Object(d["a"])(a, t);
            var e = Object(h["a"])(a);
            function a(t) {
                var n;
                return Object(l["a"])(this, a), n = e.call(this, t), Object(p["a"])(Object(m["a"])(n), "onChange", function(t, e) {
                    console.log(t.detail.value);
                    var a = {};
                    a[e] = t.detail.value, n.setState(a), setTimeout(function() {
                        n.setState({
                            pickerDisabled: !1
                        });
                    }, 100);
                }), Object(p["a"])(Object(m["a"])(n), "opemTimecustom", function(t) {
                    n.setState({
                        timeCustom: !0
                    });
                }), Object(p["a"])(Object(m["a"])(n), "backFn", function() {
                    n.state.timeCustom ? n.setState({
                        timeCustom: !1,
                        playHours: [ "00" ],
                        playMinutes: [ 10 ]
                    }) : (n.setState({
                        chooseTimeVisible: !1
                    }), !s && O["a"].navigatorBack());
                }), Object(p["a"])(Object(m["a"])(n), "startFn", Object(r["a"])(o.a.mark(function t() {
                    return o.a.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            s = void 0, s = f.a.getBackgroundAudioManager(), s.onTimeUpdate(function(t) {}), 
                            s.onEnded(function(t) {
                                var e = n.state.audioTime.split(":").filter(function(t) {
                                    return "00" !== t;
                                });
                                e.length ? (n.startFn(), s.src = n.state.natureData.sections[0].url, s.title = n.state.natureData.sections[0].title) : n.handleEnded();
                            }), s.onPlay(function(t) {
                                n.setState({
                                    playStatus: !0
                                });
                            }), s.onPause(function(t) {
                                i && clearInterval(i), n.setState({
                                    playStatus: !1
                                });
                            }), s.onStop(function(t) {
                                clearInterval(i), n.setState({
                                    playStatus: !1
                                });
                                var e = n.state.audioTime.split(":").filter(function(t) {
                                    return "00" !== t;
                                });
                                e.length && n.savePlayLogs("practice");
                            });

                          case 7:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))), Object(p["a"])(Object(m["a"])(n), "playAudio", Object(r["a"])(o.a.mark(function t() {
                    return o.a.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            if (!n.state.playStatus) {
                                t.next = 6;
                                break;
                            }
                            s.pause(), clearInterval(i), n.setState({
                                playStatus: !1
                            }), t.next = 15;
                            break;

                          case 6:
                            if (s.src = n.state.natureData.sections[0].url, s.title = n.state.natureData.sections[0].title, 
                            s.play(), n.countdown(), n.setState({
                                playStatus: !0
                            }), n.state.uniqueId) {
                                t.next = 15;
                                break;
                            }
                            return n.setState({
                                startTime: Object(M["a"])().valueOf(),
                                uniqueId: "".concat(Object(B["a"])("nowUser").id).concat(n.state.natureData.id).concat(n.state.natureData.sections[0].id).concat(Object(M["a"])().valueOf())
                            }), t.next = 15, n.savePlayLogs("playing");

                          case 15:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))), Object(p["a"])(Object(m["a"])(n), "countdown", function() {
                    var t = Object(m["a"])(n), e = 1e3, a = M["a"].duration({
                        hours: t.state.audioTime.split(":")[0],
                        minutes: t.state.audioTime.split(":")[1],
                        seconds: t.state.audioTime.split(":")[2]
                    }).asMilliseconds(), c = M["a"].duration({
                        minutes: 0,
                        hours: 0
                    }).asMilliseconds(), o = a - c, r = M["a"].duration(o, "milliseconds");
                    i = setInterval(function() {
                        r = M["a"].duration(r.asMilliseconds() - e, "milliseconds"), t.setState({
                            audioTime: Object(M["a"])({
                                minutes: r.minutes(),
                                hours: r.hours(),
                                seconds: r.seconds()
                            }).format("HH:mm:ss")
                        }), "00:00:00" == Object(M["a"])({
                            minutes: r.minutes(),
                            hours: r.hours(),
                            seconds: r.seconds()
                        }).format("HH:mm:ss") && (clearInterval(i), s.stop(), t.setState({
                            playStatus: !1
                        }), t.savePlayLogs("practice", 1));
                    }, e);
                }), n.state = {
                    options: O["a"].getCurrentPageParam(),
                    navTop: Object(B["a"])("navTop"),
                    windowHeight: f.a.getSystemInfoSync().windowHeight,
                    windowWidth: f.a.getSystemInfoSync().windowWidth,
                    chooseTimeVisible: !0,
                    timeCustom: !1,
                    mins: F,
                    playStatus: !1,
                    audioTime: "00:10:00",
                    playHours: [ "00" ],
                    playMinutes: [ 10 ],
                    natureData: {},
                    value: [],
                    uniqueId: "",
                    startTime: 0,
                    finishTime: 0,
                    pickerDisabled: !1
                }, n;
            }
            return Object(u["a"])(a, [ {
                key: "componentDidMount",
                value: function() {
                    var t = this;
                    Object(U["k"])({
                        id: this.state.options.id
                    }).then(function(e) {
                        t.setState({
                            natureData: e.result
                        }), t.startFn();
                    });
                }
            }, {
                key: "handlePlayTime",
                value: function() {
                    if (console.log(this.state.pickerDisabled), this.state.pickerDisabled && this.state.timeCustom) return !1;
                    "00" != this.state.playHours[0] || "00" != this.state.playMinutes[0] ? (clearInterval(i), 
                    this.setState({
                        playStatus: !1,
                        chooseTimeVisible: !1,
                        audioTime: this.state.playHours[0] + ":" + this.state.playMinutes[0] + ":00"
                    }), this.playAudio()) : f.a.showToast({
                        title: "请选择正确的播放时间～",
                        icon: "none"
                    });
                }
            }, {
                key: "handleEnded",
                value: function() {
                    this.savePlayLogs("practice", 1), Object(B["c"])("playingBackgroundImg", this.state.natureData.playingBackgroundImg), 
                    Object(B["c"])("quotes", this.state.natureData.quotes);
                }
            }, {
                key: "handleTime",
                value: function(t) {
                    console.log(t), this.setState({
                        playHours: [ "00" ],
                        playMinutes: [ t.currentTarget.dataset.time ]
                    });
                }
            }, {
                key: "savePlayLogs",
                value: function(t) {
                    var e = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, s = "playing" == t ? Object(M["a"])().valueOf() : this.state.startTime, i = "practice" == t ? Object(M["a"])().valueOf() : this.state.finishTime, n = "practice" == t ? M["a"].duration(i - s).asSeconds() : 0, c = {
                        uniqueId: H()(this.state.uniqueId),
                        courseType: "course",
                        courseId: parseInt(this.state.natureData.id),
                        sectionId: this.state.natureData.sections[0].id,
                        startTime: s,
                        finishTime: i,
                        duration: n,
                        completed: a
                    };
                    Object(U["z"])({
                        action: t,
                        data: JSON.stringify([ c ])
                    }).then(function(s) {
                        "practice" == t && 1 == a && O["a"].navigatorTo("../complete/index?title=".concat(e.state.natureData.title, "&courseId=").concat(e.state.natureData.id, "&durationMinutes=").concat(s.result.durationMinutes, "&continueDays=").concat(s.result.continueDays));
                    });
                }
            }, {
                key: "componentWillUnmount",
                value: function() {
                    console.log("hide"), s.destroy(), clearInterval(i), this.setState({
                        playStatus: !1
                    });
                    var t = this.state.audioTime.split(":").filter(function(t) {
                        return "00" !== t;
                    });
                    t.length && this.savePlayLogs("practice");
                }
            }, {
                key: "onShareAppMessage",
                value: function(t) {
                    return "button" === t.from && console.log(t), {
                        title: this.state.natureData.shareTitle,
                        path: "/pages/naturePlay/index?id=".concat(this.state.options.id, "&sendCourse=").concat(Object(B["a"])("appConfig").sendCourse, "&inviteCode=").concat(Object(B["a"])("nowUser").invitCode),
                        imageUrl: this.state.natureData.playingBackgroundImg
                    };
                }
            }, {
                key: "handleBack",
                value: function() {
                    var t = Object(r["a"])(o.a.mark(function t() {
                        var e, a;
                        return o.a.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                if (e = Object(b["getCurrentPages"])(), a = e[e.length - 2], !a) {
                                    t.next = 14;
                                    break;
                                }
                                if (a.route, !this.state.playStatus) {
                                    t.next = 10;
                                    break;
                                }
                                return s && s.stop(), t.next = 8, O["a"].navigatorBack();

                              case 8:
                                t.next = 12;
                                break;

                              case 10:
                                s && s.stop(), O["a"].navigatorBack();

                              case 12:
                                t.next = 16;
                                break;

                              case 14:
                                s && s.stop(), f.a.switchTab({
                                    url: "../index/index"
                                });

                              case 16:
                              case "end":
                                return t.stop();
                            }
                        }, t, this);
                    }));
                    function e() {
                        return t.apply(this, arguments);
                    }
                    return e;
                }()
            }, {
                key: "render",
                value: function() {
                    var t = this;
                    return Object(V["jsxs"])(g["m"], {
                        className: "container natureWrap",
                        children: [ Object(V["jsx"])(g["b"], {
                            src: x.a,
                            onClick: function() {
                                return t.handleBack();
                            },
                            className: "leftIcon",
                            style: {
                                top: "".concat(this.state.navTop + 4, "px")
                            }
                        }), Object(V["jsx"])(g["c"], {
                            src: this.state.natureData.playingBackgroundImg,
                            className: this.state.playStatus ? "nartureImg animate__zoomIn" : "nartureImg",
                            mode: "aspectFill",
                            webp: !0
                        }), Object(V["jsxs"])(g["m"], {
                            className: "infoWrap",
                            children: [ Object(V["jsx"])(g["m"], {
                                className: "title",
                                children: this.state.natureData.title
                            }), Object(V["jsx"])(g["m"], {
                                className: "time",
                                children: "00" == this.state.playHours[0] ? this.state.audioTime.split(":")[1] + ":" + this.state.audioTime.split(":")[2] : this.state.audioTime
                            }) ]
                        }), Object(V["jsxs"])(g["m"], {
                            className: "playWrap",
                            children: [ Object(V["jsx"])(g["c"], {
                                src: D.a,
                                mode: "aspectFit",
                                className: "icon",
                                onClick: function() {
                                    return t.setState({
                                        chooseTimeVisible: !0
                                    });
                                }
                            }), Object(V["jsx"])(g["c"], {
                                src: this.state.playStatus ? N.a : T.a,
                                mode: "aspectFit",
                                className: "big",
                                onClick: this.playAudio
                            }), Object(V["jsx"])(g["a"], {
                                className: "cleanBtn",
                                openType: "share",
                                disabled: this.state.chooseTimeVisible,
                                children: Object(V["jsx"])(g["c"], {
                                    src: I.a,
                                    mode: "aspectFit",
                                    className: "icon"
                                })
                            }) ]
                        }), this.state.chooseTimeVisible && Object(V["jsx"])(g["m"], {
                            className: "cover"
                        }), this.state.chooseTimeVisible && Object(V["jsxs"])(g["m"], {
                            className: "timeWrap",
                            style: {
                                width: "".concat(this.state.windowWidth - 40, "px")
                            },
                            children: [ Object(V["jsx"])(g["m"], {
                                className: "title",
                                children: this.state.timeCustom ? "自定义" : "选择你的时间"
                            }), this.state.timeCustom && Object(V["jsxs"])(g["m"], {
                                className: "timeFlex",
                                children: [ Object(V["jsxs"])(g["m"], {
                                    className: "flex",
                                    children: [ Object(V["jsx"])(g["f"], {
                                        className: "timePicker",
                                        indicatorStyle: " z-index: 0; height: 42px;",
                                        maskClass: "pickMask",
                                        value: this.state.playHours,
                                        onChange: function(e) {
                                            return t.onChange(e, "playHours");
                                        },
                                        onPickStart: function() {
                                            t.setState({
                                                pickerDisabled: !0
                                            });
                                        },
                                        children: Object(V["jsx"])(g["g"], {
                                            children: this.state.mins.map(function(t) {
                                                if (t <= 23) return Object(V["jsx"])(g["m"], {
                                                    children: t
                                                });
                                            })
                                        })
                                    }), Object(V["jsx"])(g["m"], {
                                        className: "timeUnit",
                                        children: "小时"
                                    }) ]
                                }), Object(V["jsxs"])(g["m"], {
                                    className: "flex",
                                    children: [ Object(V["jsx"])(g["f"], {
                                        className: "timePicker",
                                        indicatorStyle: " z-index: 0; height: 42px;",
                                        maskClass: "pickMask",
                                        value: this.state.playMinutes,
                                        onChange: function(e) {
                                            return t.onChange(e, "playMinutes");
                                        },
                                        onPickStart: function() {
                                            t.setState({
                                                pickerDisabled: !0
                                            });
                                        },
                                        children: Object(V["jsx"])(g["g"], {
                                            children: this.state.mins.map(function(t) {
                                                return Object(V["jsx"])(g["m"], {
                                                    children: t
                                                });
                                            })
                                        })
                                    }), Object(V["jsx"])(g["m"], {
                                        className: "timeUnit",
                                        children: "分钟"
                                    }) ]
                                }) ]
                            }), !this.state.timeCustom && Object(V["jsxs"])(g["m"], {
                                className: "selectWrap",
                                children: [ Object(V["jsxs"])(g["m"], {
                                    className: 5 == this.state.playMinutes[0] ? "timeCircle checked" : "timeCircle",
                                    "data-time": 5,
                                    onClick: function(e) {
                                        return t.handleTime(e);
                                    },
                                    children: [ Object(V["jsx"])(g["l"], {
                                        className: "num",
                                        children: "5"
                                    }), Object(V["jsx"])(g["l"], {
                                        className: "unit",
                                        children: "分钟"
                                    }) ]
                                }), Object(V["jsxs"])(g["m"], {
                                    className: 10 == this.state.playMinutes[0] ? "timeCircle checked" : "timeCircle",
                                    "data-time": 10,
                                    onClick: function(e) {
                                        return t.handleTime(e);
                                    },
                                    children: [ Object(V["jsx"])(g["l"], {
                                        className: "num",
                                        children: "10"
                                    }), Object(V["jsx"])(g["l"], {
                                        className: "unit",
                                        children: "分钟"
                                    }) ]
                                }), Object(V["jsxs"])(g["m"], {
                                    className: 20 == this.state.playMinutes[0] ? "timeCircle checked" : "timeCircle",
                                    "data-time": 20,
                                    onClick: function(e) {
                                        return t.handleTime(e);
                                    },
                                    children: [ Object(V["jsx"])(g["l"], {
                                        className: "num",
                                        children: "20"
                                    }), Object(V["jsx"])(g["l"], {
                                        className: "unit",
                                        children: "分钟"
                                    }) ]
                                }), Object(V["jsxs"])(g["m"], {
                                    className: "timeCircle",
                                    onClick: this.opemTimecustom,
                                    children: [ Object(V["jsx"])(g["m"], {
                                        className: "adWrap",
                                        children: Object(V["jsx"])(g["c"], {
                                            src: v.a,
                                            className: "addIcon",
                                            mode: "aspectFit"
                                        })
                                    }), Object(V["jsx"])(g["l"], {
                                        className: "unit",
                                        children: "自定义"
                                    }) ]
                                }) ]
                            }), Object(V["jsxs"])(g["m"], {
                                className: "bthWrap",
                                children: [ Object(V["jsx"])(g["m"], {
                                    className: "btn",
                                    onClick: function() {
                                        return O["a"].requireLogin().then(function() {
                                            t.backFn();
                                        });
                                    },
                                    children: "返回"
                                }), Object(V["jsx"])(g["m"], {
                                    className: "btn",
                                    onClick: function() {
                                        return O["a"].requireLogin().then(function() {
                                            t.handlePlayTime();
                                        });
                                    },
                                    children: "开始"
                                }) ]
                            }) ]
                        }) ]
                    });
                }
            } ]), a;
        }(j["Component"]), E = {
            navigationBarTitleText: "大自然声音播放页",
            navigationStyle: "custom",
            disableScroll: !0
        };
        q.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(q, "pages/naturePlay/index", {
            root: {
                cn: []
            }
        }, E || {}));
    }
}, [ [ 299, 0, 1, 2, 3 ] ] ]);