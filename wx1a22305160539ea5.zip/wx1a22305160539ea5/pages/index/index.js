(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 18 ], {
    202: function(e, s, a) {
        e.exports = a.p + "images/index/join.png";
    },
    203: function(e, s) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAATCAYAAAB7u5a2AAAAAXNSR0IArs4c6QAAAphJREFUOE+llE9IFGEYxp93ZrfRaCsocRshguggeSgkwmMUVER620uH2ER3YMFLSFSHZTpoLEVk0K5KGUKXRcFCK+pQ0bGEoFCoSxDOupi7+GfLXWfmiU8UIgTZ9TvOzPt7n3ne5/0EAFKp1CER6RaRNgAmAFHPt3EI4IMMDg42+r4/BuAwgB8AZkTErxIcJHkcgOH7fkr6+/tHAZwDcNNxnIe2bZerAScSiYBpmhEAaQATxWLxiqTT6XkAXw3DOBuNRlfWwBPJMHz3E8AZaOU2XLBnt2o4NDRUUy6X7wBoJ9lqWdYbpdwFMFIqlS53dXWVqoVnMpnafD5/X0QukTxmWdZ3BZ8GEABwurOz86eIsBrlfX19hmEY1wFcIxmzLGtYwbtJ9ojIJMlkMBj8PGEs7Rvb8+e5Ds62Loc6zhdr57ayhaTmuu5RXdcfk1x0Xfeigu8EcAtAHECNgixoPnrqFrDX0xDPh7Db17Zi//9eRXFyI8+qSZOyBsAeR3d3JesW22t9KXTNh0YOeIHfldCVtZ7nfdt8Wd4mAljQm0G9hNUjXxCJeJXAN75VUXwlIiGSVeX7n6ZKwJSIPHUc56Nt276yQw1rfzXKNqshuSIitx3H6VXwkwBekFQxPBOLxX5V0yiTyeiFQqGF5D0RaSIZkUQioZmmmVSb5XleNJfLjdu2rRar4qNY4XC4RdO0ZwDerQ10YGCgg+Rd3/evapr2JBaLrVZMXi9Yj/YUybkN5b0AYmqzstns6HaUm6Z5AsA4gPeSSqWaNE17CWDZdd1T8Xg8B0AtQUVHWdLQ0NBI8hHJZmWzGqi6ww+SXBKRAsmKwUqFiOwAUK/qReSB4zg3FFzdKfUiUrXP67+4CGCa5HA2m32trP0Lnp9SGRtWazkAAAAASUVORK5CYII=";
    },
    204: function(e, s, a) {
        e.exports = a.p + "images/index/box.png";
    },
    272: function(e, s, a) {},
    288: function(e, s, a) {
        "use strict";
        a.r(s);
        var t = a(7), c = a(10), i = a(11), l = a(12), n = a(13), o = a(14), r = a(5), m = a.n(r), d = a(1), j = a(6), u = a(56), b = a.n(u), x = a(202), h = a.n(x), p = a(203), O = a.n(p), g = a(204), A = a.n(g), N = a(33), f = a.n(N), w = a(24), v = a.n(w), y = a(25), C = a.n(y), I = a(26), k = a.n(I), T = a(23), U = a.n(T), F = (a(272), 
        a(3)), D = a(8), S = a(2), V = a(0), B = function(e) {
            Object(l["a"])(a, e);
            var s = Object(n["a"])(a);
            function a(e) {
                var t, i;
                return Object(c["a"])(this, a), i = s.call(this, e), i.state = {
                    dailyData: {},
                    courseList: [],
                    banners: [],
                    isVip: (null === (t = Object(F["a"])("nowUser").nowVip) || void 0 === t ? void 0 : t.isVip) || !1,
                    userData: Object(F["a"])("nowUser")
                }, i;
            }
            return Object(i["a"])(a, [ {
                key: "componentDidMount",
                value: function() {
                    var e = this;
                    Object(D["r"])().then(function(s) {
                        console.log(s.result), e.setState({
                            courseList: s.result
                        }), console.log("分类下的课程", s.result);
                    }), Object(D["q"])().then(function(s) {
                        e.setState({
                            dailyData: s.result
                        }), Object(F["c"])("audioData", s.result), console.log("每日正念", s.result);
                    }), Object(D["p"])().then(function(s) {
                        console.log(s), Array.isArray(s.result) && e.setState({
                            banners: s.result
                        });
                    });
                }
            }, {
                key: "dailyPage",
                value: function() {
                    j["a"].navigatorTo("../audioPlay/index?type=1&courseId=1&sectionId=".concat(this.state.dailyData.id, "&courseType=daily"));
                }
            }, {
                key: "toDetail",
                value: function(e, s) {
                    console.log("index", e), "course" == s && j["a"].navigatorTo("../class/index?id=".concat(e.id)), 
                    "article" == s && (Object(F["c"])("webUrl", e.url), j["a"].navigatorTo("../webView/index?url=" + e.url)), 
                    "decompression" == s && (Object(F["c"])("videoData", e), j["a"].navigatorTo("../fullVideo/index?id=".concat(e.id)));
                }
            }, {
                key: "handleBannerClick",
                value: function(e) {
                    Object(D["c"])({
                        bannerId: e.id
                    }), "sign" == e.tag && (Object(F["c"])("webUrl", e.lessionsID), j["a"].navigatorTo("../webView/index?url=" + e.lessionsID)), 
                    "lessions" == e.tag && j["a"].navigatorTo("../class/index?id=".concat(e.lessionsID)), 
                    "advertisment" == e.tag && (Object(F["c"])("webUrl", e.lessionsID), j["a"].navigatorTo("../webView/index?url=" + e.lessionsID)), 
                    "single_lessions" == e.tag && (Object(F["c"])("audioData", e), j["a"].navigatorTo("../audioPlay/index?type=2&courseId=".concat(e.lessionsID, "&type=2"))), 
                    "support" == e.tag && (Object(F["c"])("webUrl", e.lessionsID), j["a"].navigatorTo("../webView/index?url=" + e.lessionsID)), 
                    "courses" == e.tag && j["a"].navigatorTo("../class/index?id=".concat(e.lessionsID));
                }
            }, {
                key: "goAssociation",
                value: function() {
                    Object(F["c"])("webUrl", Object(F["a"])("appConfig").associationUri), j["a"].navigatorTo("../webView/index?url=" + Object(F["a"])("appConfig").associationUri);
                }
            }, {
                key: "componentDidShow",
                value: function() {
                    var e;
                    this.setState({
                        isVip: (null === (e = Object(F["a"])("nowUser").nowVip) || void 0 === e ? void 0 : e.isVip) || !1
                    }), m.a.setTabBarStyle({
                        backgroundColor: "#ffffff",
                        color: "#707070",
                        selectedColor: "#4CCBCC"
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function() {}
            }, {
                key: "render",
                value: function() {
                    var e, s, a = this;
                    return Object(V["jsxs"])(d["m"], {
                        className: "container homePage",
                        children: [ Object(V["jsxs"])(d["m"], {
                            className: "homeCard topCard",
                            onClick: this.dailyPage.bind(this),
                            children: [ Object(V["jsx"])(d["c"], {
                                src: this.state.dailyData.thumbImg,
                                webp: !0,
                                mode: "aspectFill",
                                className: "dailyBg"
                            }), Object(V["jsxs"])(d["m"], {
                                className: "time f20",
                                children: [ this.state.dailyData.date, " 星期", j["a"].toChinaWeek(Object(S["a"])(this.state.dailyData.date).days()) ]
                            }), Object(V["jsxs"])(d["m"], {
                                className: "coverWrap",
                                children: [ Object(V["jsxs"])(d["m"], {
                                    className: "titleWrap",
                                    children: [ Object(V["jsx"])(d["m"], {
                                        className: "topT",
                                        children: this.state.dailyData.title
                                    }), Object(V["jsx"])(d["m"], {
                                        className: "f20",
                                        children: this.state.dailyData.titlePrifix
                                    }) ]
                                }), Object(V["jsx"])(d["m"], {
                                    className: "iconWrap",
                                    children: Object(V["jsx"])(d["c"], {
                                        className: "playIcon",
                                        src: b.a,
                                        mode: "aspectFit"
                                    })
                                }) ]
                            }) ]
                        }), this.state.courseList.length ? Object(V["jsxs"])(d["m"], {
                            className: "homeCard firstWrap",
                            children: [ Object(V["jsxs"])(d["m"], {
                                className: "top",
                                children: [ Object(V["jsxs"])(d["m"], {
                                    className: "blockTitle",
                                    children: [ Object(V["jsx"])(d["m"], {
                                        className: "line"
                                    }), Object(V["jsx"])(d["m"], {
                                        className: "txt f36",
                                        children: null === (e = this.state.courseList[0]) || void 0 === e ? void 0 : e.title
                                    }) ]
                                }), Object(V["jsx"])(d["c"], {
                                    onClick: function() {
                                        return a.goAssociation();
                                    },
                                    className: "join",
                                    src: h.a,
                                    mode: "widthFix"
                                }) ]
                            }), Object(V["jsx"])(d["m"], {
                                className: "itemWrap",
                                children: null === (s = this.state.courseList[0]) || void 0 === s ? void 0 : s.childList.map(function(e, s) {
                                    if (s < 2) return Object(V["jsxs"])(d["m"], {
                                        onClick: function() {
                                            return a.toDetail(e, a.state.courseList[0].courseType);
                                        },
                                        className: "item",
                                        children: [ Object(V["jsx"])(d["c"], {
                                            className: "itemImg",
                                            src: e.thumbImg,
                                            webp: !0,
                                            mode: "aspectFill",
                                            lazyLoad: !0
                                        }), 1 == e.isNew ? Object(V["jsx"])(d["c"], {
                                            className: "icon",
                                            src: C.a,
                                            mode: "heightFix"
                                        }) : null, 0 != e.isNew || a.state.isVip || "1" != e.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                            className: "icon",
                                            src: U.a,
                                            mode: "heightFix"
                                        }), 0 != e.isNew || a.state.isVip || "0" != e.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                            className: "icon",
                                            src: k.a,
                                            mode: "heightFix"
                                        }), 0 != e.isNew || a.state.isVip || "2" != e.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                            className: "icon",
                                            src: v.a,
                                            mode: "heightFix"
                                        }), Object(V["jsxs"])(d["m"], {
                                            className: "title",
                                            children: [ Object(V["jsx"])(d["m"], {
                                                children: e.title
                                            }), Object(V["jsx"])(d["m"], {
                                                className: "f20",
                                                children: "singles" == e.typeSubcat ? "".concat(parseInt(S["a"].duration(e.duration, "seconds").asMinutes() + ""), "分钟") : "".concat(e.smallNum, "课时")
                                            }) ]
                                        }) ]
                                    });
                                })
                            }) ]
                        }) : null, this.state.banners.length ? Object(V["jsx"])(d["j"], {
                            className: "wrap radius20 bannerImg",
                            autoplay: !0,
                            circular: !0,
                            indicatorDots: !0,
                            indicatorColor: "#ffffff30",
                            indicatorActiveColor: "#ffffff",
                            children: this.state.banners.map(function(e) {
                                return Object(V["jsx"])(d["k"], {
                                    onClick: function() {
                                        return a.handleBannerClick(e);
                                    },
                                    children: Object(V["jsx"])(d["c"], {
                                        className: "bannerImg radius20",
                                        src: e.imgURL,
                                        webp: !0,
                                        mode: "aspectFill",
                                        lazyLoad: !0
                                    })
                                });
                            })
                        }) : null, this.state.courseList.map(function(e, s) {
                            return "decompression" == e.layoutTag ? Object(V["jsxs"])(d["m"], {
                                className: "homeCard",
                                children: [ Object(V["jsxs"])(d["m"], {
                                    className: "blockTitle",
                                    children: [ Object(V["jsx"])(d["m"], {
                                        className: "line"
                                    }), Object(V["jsx"])(d["m"], {
                                        className: "txt f36",
                                        children: null === e || void 0 === e ? void 0 : e.title
                                    }) ]
                                }), Object(V["jsx"])(d["h"], {
                                    scrollX: !0,
                                    enhanced: !0,
                                    showScrollbar: !1,
                                    scrollWithAnimation: !0,
                                    className: "scrollWrap unzip",
                                    children: null === e || void 0 === e ? void 0 : e.childList.map(function(s) {
                                        return Object(V["jsxs"])(d["m"], {
                                            className: "item",
                                            onClick: function() {
                                                return a.toDetail(s, e.courseType);
                                            },
                                            children: [ 1 == s.isNew ? Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: C.a,
                                                mode: "heightFix"
                                            }) : null, 0 != s.isNew || a.state.isVip || "1" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: U.a,
                                                mode: "heightFix"
                                            }), 0 != s.isNew || a.state.isVip || "0" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: k.a,
                                                mode: "heightFix"
                                            }), 0 != s.isNew || a.state.isVip || "2" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: v.a,
                                                mode: "heightFix"
                                            }), Object(V["jsx"])(d["c"], {
                                                className: "playBg",
                                                src: s.thumbImg,
                                                webp: !0,
                                                mode: "aspectFill",
                                                lazyLoad: !0
                                            }), Object(V["jsx"])(d["c"], {
                                                className: "playIcon",
                                                src: b.a,
                                                mode: "aspectFit"
                                            }), Object(V["jsx"])(d["m"], {
                                                className: "title",
                                                children: s.title
                                            }) ]
                                        });
                                    })
                                }) ]
                            }) : "article" == e.layoutTag ? Object(V["jsxs"])(d["m"], {
                                className: "homeCard",
                                children: [ Object(V["jsxs"])(d["m"], {
                                    className: "blockTitle",
                                    children: [ Object(V["jsx"])(d["m"], {
                                        className: "line"
                                    }), Object(V["jsx"])(d["m"], {
                                        className: "txt f36",
                                        children: null === e || void 0 === e ? void 0 : e.title
                                    }) ]
                                }), Object(V["jsx"])(d["h"], {
                                    scrollX: !0,
                                    enhanced: !0,
                                    showScrollbar: !1,
                                    scrollWithAnimation: !0,
                                    className: "scrollWrap dryStaff",
                                    children: null === e || void 0 === e ? void 0 : e.childList.map(function(s) {
                                        return Object(V["jsxs"])(d["m"], {
                                            className: "item radius20",
                                            onClick: function() {
                                                return a.toDetail(s, e.courseType);
                                            },
                                            children: [ Object(V["jsx"])(d["c"], {
                                                className: "itemImg",
                                                src: s.thumbImg,
                                                webp: !0,
                                                mode: "aspectFill",
                                                lazyLoad: !0
                                            }), Object(V["jsxs"])(d["m"], {
                                                className: "info",
                                                children: [ Object(V["jsx"])(d["m"], {
                                                    className: "title ellipsis",
                                                    children: s.title
                                                }), Object(V["jsxs"])(d["m"], {
                                                    className: "desc radius20",
                                                    children: [ Object(V["jsx"])(d["m"], {
                                                        className: "rowsEllipsis",
                                                        children: s.subtitle
                                                    }), Object(V["jsxs"])(d["m"], {
                                                        className: "flex readNum",
                                                        children: [ Object(V["jsx"])(d["c"], {
                                                            className: "iconImg",
                                                            src: O.a,
                                                            mode: "widthFix"
                                                        }), Object(V["jsxs"])(d["m"], {
                                                            children: [ "阅读量", s.readingNumber ]
                                                        }) ]
                                                    }) ]
                                                }) ]
                                            }) ]
                                        });
                                    })
                                }) ]
                            }) : "course" == e.layoutTag && s > 0 ? Object(V["jsxs"])(d["m"], {
                                className: "homeCard",
                                children: [ Object(V["jsxs"])(d["m"], {
                                    className: "blockTitle",
                                    children: [ Object(V["jsx"])(d["m"], {
                                        className: "line"
                                    }), Object(V["jsx"])(d["m"], {
                                        className: "txt f36",
                                        children: null === e || void 0 === e ? void 0 : e.title
                                    }) ]
                                }), Object(V["jsx"])(d["h"], {
                                    scrollX: !0,
                                    enhanced: !0,
                                    showScrollbar: !1,
                                    scrollWithAnimation: !0,
                                    className: "scrollWrap scene",
                                    children: null === e || void 0 === e ? void 0 : e.childList.map(function(s) {
                                        return Object(V["jsxs"])(d["m"], {
                                            className: "item",
                                            onClick: function() {
                                                return a.toDetail(s, e.courseType);
                                            },
                                            children: [ Object(V["jsx"])(d["c"], {
                                                className: "itemImg",
                                                src: s.thumbImg,
                                                webp: !0,
                                                mode: "aspectFill",
                                                lazyLoad: !0
                                            }), 1 == s.isNew ? Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: C.a,
                                                mode: "heightFix"
                                            }) : null, 0 != s.isNew || a.state.isVip || "1" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: U.a,
                                                mode: "heightFix"
                                            }), 0 != s.isNew || a.state.isVip || "0" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: k.a,
                                                mode: "heightFix"
                                            }), 0 != s.isNew || a.state.isVip || "2" != s.vipCourseUnlock ? null : Object(V["jsx"])(d["c"], {
                                                className: "icon",
                                                src: v.a,
                                                mode: "heightFix"
                                            }), Object(V["jsxs"])(d["m"], {
                                                className: "title",
                                                children: [ Object(V["jsx"])(d["m"], {
                                                    children: s.title
                                                }), Object(V["jsx"])(d["m"], {
                                                    className: "f20",
                                                    children: "singles" == s.typeSubcat ? "".concat(parseInt(S["a"].duration(s.duration, "seconds").asMinutes() + ""), "分钟") : "".concat(s.smallNum, "课时")
                                                }) ]
                                            }) ]
                                        });
                                    })
                                }) ]
                            }) : void 0;
                        }), Object(F["a"])("system").includes("iOS") ? null : Object(V["jsxs"])(d["m"], {
                            className: "homeCard spread",
                            onClick: function() {
                                return j["a"].navigatorTo("../invite/index");
                            },
                            children: [ Object(V["jsx"])(d["m"], {
                                style: "flex: 1",
                                children: "推广赚钱"
                            }), Object(V["jsx"])(d["c"], {
                                className: "boxImg",
                                src: A.a,
                                mode: "aspectFit"
                            }), Object(V["jsx"])(d["c"], {
                                className: "goImg",
                                src: f.a,
                                mode: "aspectFit"
                            }) ]
                        }) ]
                    });
                }
            } ]), a;
        }(o["Component"]), X = {
            navigationBarTitleText: "Now"
        };
        B.enableShareAppMessage = !0;
        Page(Object(t["createPageConfig"])(B, "pages/index/index", {
            root: {
                cn: []
            }
        }, X || {}));
    },
    56: function(e, s) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA3CAMAAABwx0lKAAAAAXNSR0IArs4c6QAAAUFQTFRFAAAA////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////bof29AAAAGp0Uk5TAAECAwQFBgcKCwwPERQXGBodHyAhJCYqKywvMTM3OT5AQkVHSEpMTlFXWF1hZmtvcHJzen1/goWGh4qMjpCUmZ6jpqitr7W3uby9v8DCxMXM0NHU1djZ2t/g4uXn6Ozt7/Lz9/j6+/z9/sxcalQAAAFJSURBVEjHndbXVsJgEATgxAYKYgU7oqKiYo29YEUENWIDxIISlTDv/wBeWDBw9Ow/c53vJuff3dG0r/iDHZpyJi4BPGwF1NR4CQCA4lK9gmrI4zvpQTmLoJLSdrOU7eB3cmEhi8OZQ5+IpaoYClFdwE5Rk7MAxWAZTQwDboIUgx3zMAy4j1AMOGqnGF7mdIYBZi/F8LbmYhiQCVEM5T0vw4DHKYoBiS6KoThfxzDgwkMxmG6KYZVjlo9imOHYBseWOTZCsWvqT76HGGZPM6/kaYx5k8fdxATUDpyA2bteYkwzw8QueV1xESvI7CH25POsTqzXf47A3yw/SVwcO9ZCHKqrIeKaWkYjcYSTfqIpFKKCXnJSfV/2WyUt6MCp7kZlnctwzP2mtOL1lysqPSAvlImfW7SgUl/bsp8q3qlWlt2L57fJ9T7x9x+nqXM1gA+DxgAAAABJRU5ErkJggg==";
    }
}, [ [ 288, 0, 1, 2, 3 ] ] ]);