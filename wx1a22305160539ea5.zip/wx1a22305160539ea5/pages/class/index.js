(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 12 ], {
    205: function(e, s, t) {
        e.exports = t.p + "images/icons/vip.png";
    },
    206: function(e, s, t) {
        e.exports = t.p + "images/class/share.png";
    },
    207: function(e, s, t) {
        e.exports = t.p + "images/class/time.png";
    },
    208: function(e, s, t) {
        e.exports = t.p + "images/class/heart.png";
    },
    209: function(e, s, t) {
        e.exports = t.p + "images/class/done.png";
    },
    210: function(e, s) {
        e.exports = "data:image/png;base64,UklGRigDAABXRUJQVlA4WAoAAAAQAAAALwAALwAAQUxQSPMAAAABv8AwAMCisdm2KyICYAa5Ot0R1vIvStCMYYQYGDSSpGgOnvFw/Gt9njcQ0X9Hbhs5UnPyzO6p0hvwzHbzusda477OncVXflgyb+Vl8PjATYkvpMnhJTMGvhRGgzeajR9szYu9DfwktI97X/hR6Z92CtxvbaFAuXvZBEqE65+ZjSKbOa+RMuNpd4EywR1rotAEwCcKJQ8MlBqAhVILbKZUth3Fupli80qxdafYHikWK8Wqfulv9J/o/0gfJ/o41Me5PI/0efpDHfihzvxQx/R18oc6rK/z0PcR6PsU9H0Q+j4LfR+Hfk4A5HMIAPmcc/g+RwEAVlA4IA4CAACwDACdASowADAAPpE6mEiloyIhLjQMyLASCWIA0dyrelLtyozQwIcQKgezt5t6AH6VpVgEG5N/+PwtjoYXSuk7r0n+InesRu9ew9eET3HxzBMndyVGviGtGE72sN8MdnoWBuFIlj0uuXnZpewAAAD++5HhcebZZRRjPOcSj4qdY+rvWyJD5ewoL6ZomJJ3hHbIdmRQt1GCFsbHsjOM7Xmbg/sZyi8FAkrY7pc375Zra8dLFUHRubRplJJAtHud4Fr/6loZTMeHpydE7/GMd4unQWSv/s6yR4hKLidhtQ3slM5j/w1u+4b51EBzQVzPwXmjw/r6wbJ2HmCPUcdnfFjX4s3izqOSZnNB/bIYRrg7kTKSMV9MhaiVS000+BKlRaIqy4lkaTbrne/Ww5umGuB6e+nKDUuN55OHUptqfBAlV94g7fZ6YTTq+TeqXmy1aMl5LIPyuIGSvR2ccPOTH7s2S7fnnnOztt/+4d37Os4+1sSBk069GqS3742cuvTvk31FIScQS5xoAk/k3M1KZWRb6dUWAJw3+YDx++TnnZ9yP6/X+0I9N+OU049hFnQwSJL02OtxZVkPhHy/wnqysz0Lgw3XXGCXl8DSgTRT80vIfzEVdUjJ9xh0NFzUDCcpexFy+/4W14r+hPlhR6EwI2VCsbKBD3kbw4i9uaMuhw2ZP3gzrwud0N/NiGZQoAAA";
    },
    211: function(e, s) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAAXNSR0IArs4c6QAAAMxQTFRFAAAAAH//QH//M5n/Sbb/TbP/TrH/UK//S7T/Tqb/TrH/Sqr/Sa3/TKz/T6r/Sqr/TK7/Sqr/Ta3/T7D/TKv/UK//T7D/Tq7/Ta7/TK3/Tq7/T67/Tq7/Ta//Ta3/T63/Tqz/T67/Ta7/Tq3/Tq//Tq7/T63/Tq7/Tq3/Tq7/Tq7/T63/T67/Tq7/T6//T67/Tq7/Tq7/Tq3/Tq3/T63/T67/Tq3/Tq3/Tq7/Tq7/T67/Tq7/T63/Tq3/Tq3/T67/Tq7/T67/Tq7/T67/AnhpPQAAAEN0Uk5TAAIEBQcKDRARFxcYHCUqLS8wNTdAQ0dIT1dYXl9jZ2dvgYePj5efp6utrru8w87P1Nja3uPj5Ofr7u/x8/T3+fv9/poJTnIAAACXSURBVBgZ3cHZFoEAFAXQgwgRMs9jMkXmqUzn//8Ja3kr95298dsScYiSuy0koRlHkHS5ViEo368GBKkDOxBEbE4g6XOlQlB5XLIQpI9sQaDMaUFichmDoE5Ph0+xhA/dYwN+J/bCeIs5HCJA88aphheLThRBCntu8kCLZx3BNJu3du7CKr4JD0iXJgQ1lwsFEmOcwZ96AiO7EHC6U7s1AAAAAElFTkSuQmCC";
    },
    212: function(e, s) {
        e.exports = "data:image/png;base64,UklGRnQDAABXRUJQVlA4WAoAAAAQAAAAKQAALAAAQUxQSPAAAAABX6Kwbds2WdlOdx9oRERDA4ddJKAwmT4ETDAiHXnoQ0XV0TPIyBqxBYVDUEByJEmRVMPMzMy0zMy79f8XNVXlcU8ZORH9nwBlsnxzrIBkePqrjzIPE6jeaNe7mqVI90L7vO5FjKUH+08d8OtkkAr56LU7/dFkubv80Ia/rjar2bDVkJ7+R/5DB+908EiHD3R4QQclOkX1QOUBmFFhIPpMA6yAOo06nGcUBK6JJ3sQN2Rebb0KvLMvdiQLv8l7G5KEf96aA6vAzTczDGUyvv4L9scCw4XzIOdQFiunf15/wrCcX387eJ0Dwdj4lhFTBgFWUDggXgIAADAOAJ0BKioALQA+kT6aSiWjIiGnOAtosBIJbACdMy+K2Bxln6gNsj5gPPssmqpJef1N8zR3DAPAGio9Az+w8k2oJ/Hv5z/w/WA9YH7VewB+zq+B0r0s2m7pAjS/2mD+IpTHIE+I5yzwBNJekt7b1B2CSrkoADVVoLUAAP7/GrvhBn0P9L5Q5r90qQqRFf/5p/+Qhvr4+8GPysMJ9H3AZ2mGvzs+g/zWlA8hWfg1uZKb2saqDJ4QUOiYRAtmv1+aHav8zt/xKJHFg9sGO2e3+v5L3hUnJGRotynvnsH2an09+s6Tm/3ePu2h3j1xwyyORYftWQ91MvWHkGP+dQaCpuR0Z0UxK6g58cCgEmL92r7H4Kz7G1Zh6leGYCa1r+M63KfD9piAjqrfdqsyPPl/MtvnDHCGKa3bta0VuUz4RPFOORsEGbb0zn9/+6aGl7uIpzKwv/0atksJt8KBcNED5zHy9ToR0UIZWYNbE5qTWZYdSzglmWVsl5klTeieiQTpnHvCEs8Tt+P/hzJwkTyPspqnzr42ZZt5ZeZiC9ierbfn/KMXK8da//wgMIcf+/9/K9CKiSnEaQ6DcGX1F7OinBSbfEeh2CSvkfQwZtyRFmSt1Vx2DsJoOHl1mMc6h+7NxdN3/8/QuH302Tx1C2b7JVSfAxv8NDisw9pBkJISeijhEtuohhKqBk6CHuccgQLNxYajTNX0JVL7vcP//4t7fV2dv8uO7+xIyT/eHVQLMuBTrxeoH2MOyEEYgTM2nV7pw7BoRn97fgysDrEcLNJV9JB3gM47JaY8wVl2a5nMAA==";
    },
    274: function(e, s, t) {},
    289: function(e, s, t) {
        "use strict";
        t.r(s);
        var a = t(7), n = t(19), i = t(10), c = t(11), o = t(12), l = t(13), r = t(14), h = t(1), d = t(6), u = t(5), m = t.n(u), j = t(29), b = t.n(j), p = t(205), f = t.n(p), g = t(206), O = t.n(g), x = t(57), A = t.n(x), v = t(207), I = t.n(v), T = t(208), C = t.n(T), k = t(42), y = t.n(k), N = t(209), w = t.n(N), S = t(58), V = t.n(S), B = t(30), F = t.n(B), U = t(210), q = t.n(U), D = t(43), P = t.n(D), H = t(44), Q = t.n(H), R = t(211), M = t.n(R), J = t(45), E = t.n(J), K = t(212), L = t.n(K), z = t(31), G = t.n(z), X = t(32), Z = t.n(X), W = (t(274), 
        t(8)), Y = t(3), $ = t(46), _ = t.n($), ee = t(2), se = t(0), te = !1, ae = function(e) {
            Object(o["a"])(t, e);
            var s = Object(l["a"])(t);
            function t(e) {
                var a, n;
                return Object(i["a"])(this, t), n = s.call(this, e), n.state = {
                    options: d["a"].getCurrentPageParam(),
                    navTop: Object(Y["a"])("navTop"),
                    height: Object(Y["a"])("ButtonHeight"),
                    windowHeight: m.a.getSystemInfoSync().windowHeight,
                    windowWidth: m.a.getSystemInfoSync().windowWidth,
                    activeTab: 0,
                    inviteVisible: !1,
                    isUnlock: !0,
                    classInfo: {},
                    isVip: (null === (a = Object(Y["a"])("nowUser").nowVip) || void 0 === a ? void 0 : a.isVip) || !1,
                    inviteFriends: [],
                    contactVisible: !1,
                    sendCourse: {},
                    unlockCourseSendFriendTxt: "",
                    unlockCourseSendFriends: "",
                    classFirst: ""
                }, n;
            }
            return Object(c["a"])(t, [ {
                key: "tabChange",
                value: function(e) {
                    this.setState({
                        activeTab: e.currentTarget.dataset.index
                    });
                }
            }, {
                key: "getUserInfo",
                value: function() {
                    var e = this;
                    Object(W["w"])().then(function(s) {
                        var t;
                        s.result != {} ? (e.setState({
                            isVip: null === (t = s.result.nowVip) || void 0 === t ? void 0 : t.isVip
                        }), Object(Y["c"])("nowUser", s.result)) : (Object(Y["c"])("nowUser", ""), m.a.setStorageSync("accessToken", ""));
                    });
                }
            }, {
                key: "handleInviteVisible",
                value: function() {
                    var e = this;
                    !this.state.inviteVisible && Object(W["t"])({
                        courseId: this.state.options.id
                    }).then(function(s) {
                        Array.isArray(s.result) && (e.setState({
                            inviteFriends: s.result
                        }), s.result.length == e.state.unlockCourseSendFriends && e.setState({
                            isVip: !0
                        }));
                    }), this.setState({
                        inviteVisible: !this.state.inviteVisible
                    });
                }
            }, {
                key: "getCourseDetail",
                value: function(e) {
                    var s = this;
                    Object(W["k"])({
                        id: e || this.state.options.id
                    }).then(function(e) {
                        var s = Object(n["a"])(e.result.sections);
                        return e.result.sections = Object(n["a"])(s.filter(function(e) {
                            return "cn" === e.language;
                        })), console.log("sections", s), e.result;
                    }).then(function(e) {
                        s.setState({
                            classInfo: e
                        }), console.log("classInfo", e);
                    });
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    var e = this;
                    console.log("options.id", this.state.options.id), console.log("sendCourse", this.state.options.sendCourse), 
                    console.log("courseUnlock", this.state.options.courseUnlock), Object(W["d"])().then(function(s) {
                        var t, a;
                        Object(Y["c"])("appConfig", s.result), e.setState({
                            unlockCourseSendFriendTxt: null === (t = s.result) || void 0 === t ? void 0 : t.unlockCourseSendFriendTxt.split("|"),
                            unlockCourseSendFriends: parseInt(null === (a = s.result) || void 0 === a ? void 0 : a.unlockCourseSendFriends)
                        }), console.log(s.result);
                    });
                }
            }, {
                key: "componentDidShow",
                value: function() {
                    var e = this;
                    Object(W["k"])({
                        id: Object(Y["a"])("appConfig").sendCourse
                    }).then(function(s) {
                        e.setState({
                            sendCourse: s.result
                        });
                    }), this.getUserInfo(), this.state.options.courseUnlock ? this.getCourseDetail(this.state.options.sendCourse) : this.getCourseDetail("");
                }
            }, {
                key: "getRecentClass",
                value: function() {
                    for (var e in this.state.classInfo.sections) {
                        var s = d["a"].toChineseNum(parseInt(e) + 1);
                        if (1 == this.state.classInfo.sections[e].isListen && parseInt(e) == this.state.classInfo.sections.length - 1) return te = !0, 
                        "重新开始";
                        if (0 == this.state.classInfo.sections[e].isListen) return "开始 第".concat(s, "节");
                    }
                }
            }, {
                key: "collect",
                value: function() {
                    var e = this;
                    Object(W["h"])({
                        courseId: this.state.classInfo.id
                    }).then(function() {
                        e.getCourseDetail("");
                    });
                }
            }, {
                key: "playClass",
                value: function(e, s, t) {
                    this.state.isVip || "0" == this.state.classInfo.vipCourseUnlock ? (console.log(te), 
                    te && Object(W["y"])({
                        courseId: s
                    }), e.playingBackgroundImg = this.state.classInfo.playingBackgroundImg, Object(Y["c"])("audioInfo", this.state.classInfo), 
                    Object(Y["c"])("audioData", e), d["a"].navigatorTo("../audioPlay/index?type=2&courseId=".concat(s, "&courseType=").concat(t))) : "2" == this.state.classInfo.vipCourseUnlock ? 1 == e.isInviteSuccess && 0 == e.isPlay ? (te && Object(W["y"])({
                        courseId: s
                    }), e.playingBackgroundImg = this.state.classInfo.playingBackgroundImg, Object(Y["c"])("audioInfo", this.state.classInfo), 
                    Object(Y["c"])("audioData", e), d["a"].navigatorTo("../audioPlay/index?type=2&courseId=".concat(s, "&courseType=").concat(t))) : this.toVipPage() : 1 == e.isInviteSuccess && 0 == e.isPlay ? (te && Object(W["y"])({
                        courseId: s
                    }), e.playingBackgroundImg = this.state.classInfo.playingBackgroundImg, Object(Y["c"])("audioInfo", this.state.classInfo), 
                    Object(Y["c"])("audioData", e), d["a"].navigatorTo("../audioPlay/index?type=2&courseId=".concat(s, "&courseType=").concat(t))) : 1 == e.isInviteSuccess && 1 == e.isPlay ? this.toVipPage() : this.handleInviteVisible();
                }
            }, {
                key: "handleContact",
                value: function() {
                    this.setState({
                        contactVisible: !this.state.contactVisible
                    });
                }
            }, {
                key: "componentDidHide",
                value: function() {
                    this.setState({
                        contactVisible: !1
                    });
                }
            }, {
                key: "onShareAppMessage",
                value: function(e) {
                    return "1" == this.state.classInfo.vipCourseUnlock ? {
                        title: this.state.sendCourse.shareTitle,
                        path: "/pages/class/index?id=".concat(this.state.options.id, "&sendCourse=").concat(this.state.sendCourse.id, "&inviteCode=").concat(Object(Y["a"])("nowUser").invitCode, "&courseUnlock=1"),
                        imageUrl: this.state.sendCourse.thumbImg
                    } : {
                        title: this.state.classInfo.shareTitle,
                        path: "/pages/class/index?id=".concat(this.state.options.id, "&inviteCode=").concat(Object(Y["a"])("nowUser").invitCode),
                        imageUrl: this.state.classInfo.thumbImg
                    };
                }
            }, {
                key: "toVipPage",
                value: function() {
                    if (Object(Y["a"])("system").includes("iOS")) this.handleInviteVisible(); else {
                        var e = Object(Y["a"])("appConfig").gotoVip;
                        Object(Y["c"])("webUrl", e + "?id=" + Object(Y["a"])("nowUser").id), d["a"].navigatorTo("../webView/index?url=" + e + "?id=" + Object(Y["a"])("nowUser").id);
                    }
                }
            }, {
                key: "render",
                value: function() {
                    var e, s = this;
                    return Object(se["jsxs"])(h["m"], {
                        className: "container classWrap",
                        children: [ Object(se["jsx"])(h["c"], {
                            src: b.a,
                            onClick: d["a"].navigatorBack,
                            className: "leftIcon",
                            style: {
                                top: "".concat(this.state.navTop + 4, "px")
                            }
                        }), Object(se["jsxs"])(h["m"], {
                            className: "classBox",
                            children: [ Object(se["jsx"])(h["c"], {
                                className: "classTopBg",
                                src: this.state.classInfo.thumbImg,
                                mode: "aspectFill",
                                webp: !0
                            }), Object(se["jsx"])(h["m"], {
                                className: "coverbg"
                            }), Object(se["jsxs"])(h["m"], {
                                className: "classInfo",
                                children: [ Object(se["jsxs"])(h["m"], {
                                    className: "title",
                                    children: [ this.state.classInfo.title, "vip" == this.state.classInfo.typeNew && Object(se["jsx"])(h["c"], {
                                        src: f.a,
                                        className: "vipIcon",
                                        mode: "heightFix"
                                    }) ]
                                }), Object(se["jsxs"])(h["m"], {
                                    className: "time",
                                    children: [ this.state.classInfo.smallNum, "课时" ]
                                }), Object(se["jsx"])(h["m"], {
                                    className: "info",
                                    children: this.state.classInfo.subtitle
                                }), Object(se["jsx"])(h["a"], {
                                    openType: "share",
                                    className: "cleanBtn",
                                    children: Object(se["jsx"])(h["c"], {
                                        src: O.a,
                                        mode: "widthFix",
                                        className: "shareBtn"
                                    })
                                }) ]
                            }) ]
                        }), Object(se["jsxs"])(h["m"], {
                            className: "infoWrap",
                            children: [ Object(se["jsxs"])(h["m"], {
                                className: "menuWrap",
                                children: [ Object(se["jsxs"])(h["m"], {
                                    className: 0 === this.state.activeTab ? "menuItem" : "menuItem active",
                                    "data-index": 1,
                                    onClick: function(e) {
                                        return s.tabChange(e);
                                    },
                                    children: [ Object(se["jsx"])(h["l"], {
                                        children: "详情"
                                    }), 1 === this.state.activeTab ? Object(se["jsx"])(h["m"], {
                                        className: "tabsLine"
                                    }) : "" ]
                                }), Object(se["jsxs"])(h["m"], {
                                    className: 1 === this.state.activeTab ? "menuItem" : "menuItem active",
                                    "data-index": 0,
                                    onClick: function(e) {
                                        return s.tabChange(e);
                                    },
                                    children: [ Object(se["jsx"])(h["l"], {
                                        children: "课程表"
                                    }), 0 === this.state.activeTab ? Object(se["jsx"])(h["m"], {
                                        className: "tabsLine"
                                    }) : "" ]
                                }) ]
                            }), Object(se["jsxs"])(h["m"], {
                                className: 0 === this.state.activeTab ? "scrollBox mb110" : "scrollBox",
                                style: {
                                    height: "".concat(this.state.windowHeight - 375, "px"),
                                    flex: 1
                                },
                                children: [ Object(se["jsx"])(h["m"], {
                                    onClick: function() {
                                        return s.handleContact();
                                    },
                                    className: "goBtn",
                                    children: "去Now冥想App体验更多"
                                }), 0 === this.state.activeTab ? Object(se["jsx"])(h["m"], {
                                    className: "classList",
                                    children: null === (e = this.state.classInfo.sections) || void 0 === e ? void 0 : e.map(function(e, t) {
                                        return Object(se["jsxs"])(h["m"], {
                                            className: "classItem",
                                            onClick: function() {
                                                return d["a"].requireLogin().then(function() {
                                                    s.playClass(e, s.state.classInfo.id, s.state.classInfo.type);
                                                });
                                            },
                                            children: [ Object(se["jsx"])(h["m"], {
                                                className: "index",
                                                children: t + 1
                                            }), Object(se["jsxs"])(h["m"], {
                                                className: "info",
                                                children: [ Object(se["jsx"])(h["m"], {
                                                    className: "title",
                                                    children: e.title
                                                }), Object(se["jsxs"])(h["m"], {
                                                    className: "time",
                                                    children: [ Object(se["jsx"])(h["c"], {
                                                        src: I.a,
                                                        mode: "widthFix",
                                                        className: "timeBtn"
                                                    }), Object(se["jsx"])(h["l"], {
                                                        children: Object(ee["a"])({
                                                            hours: ee["a"].duration(e.mainDuration, "seconds").hours(),
                                                            minutes: ee["a"].duration(e.mainDuration, "seconds").minutes(),
                                                            seconds: ee["a"].duration(e.mainDuration, "seconds").seconds()
                                                        }).format(ee["a"].duration(e.mainDuration, "seconds").hours() ? "HH:mm:ss" : "mm:ss")
                                                    }) ]
                                                }) ]
                                            }), s.state.isVip || "0" == s.state.classInfo.vipCourseUnlock ? Object(se["jsx"])(h["m"], {
                                                children: Object(se["jsx"])(h["c"], {
                                                    src: 1 == e.isListen ? w.a : A.a,
                                                    mode: "widthFix",
                                                    className: "playBtn"
                                                })
                                            }) : Object(se["jsx"])(h["m"], {
                                                children: 1 == e.isInviteSuccess ? Object(se["jsx"])(h["m"], {
                                                    children: Object(se["jsx"])(h["c"], {
                                                        src: 0 == e.isPlay ? A.a : V.a,
                                                        mode: "widthFix",
                                                        className: "playBtn"
                                                    })
                                                }) : Object(se["jsx"])(h["m"], {
                                                    children: Object(se["jsx"])(h["c"], {
                                                        src: V.a,
                                                        mode: "widthFix",
                                                        className: "playBtn"
                                                    })
                                                })
                                            }) ]
                                        });
                                    })
                                }) : Object(se["jsxs"])(h["m"], {
                                    className: "albumInfo",
                                    children: [ Object(se["jsxs"])(h["m"], {
                                        children: [ Object(se["jsx"])(h["m"], {
                                            className: "label",
                                            children: "专辑介绍"
                                        }), Object(se["jsx"])(h["m"], {
                                            className: "info",
                                            children: this.state.classInfo.content
                                        }) ]
                                    }), Object(se["jsxs"])(h["m"], {
                                        children: [ Object(se["jsx"])(h["m"], {
                                            className: "label",
                                            children: "名师"
                                        }), Object(se["jsxs"])(h["m"], {
                                            className: "flex",
                                            children: [ Object(se["jsx"])(h["m"], {
                                                className: "head",
                                                children: Object(se["jsx"])(h["c"], {
                                                    webp: !0,
                                                    src: this.state.classInfo.teachers.avatar,
                                                    className: "headimg",
                                                    mode: "aspectFill"
                                                })
                                            }), Object(se["jsxs"])(h["m"], {
                                                className: "teacherInfo",
                                                children: [ Object(se["jsx"])(h["m"], {
                                                    className: "name",
                                                    children: this.state.classInfo.teachers.uname
                                                }), Object(se["jsxs"])(h["m"], {
                                                    className: "flex",
                                                    children: [ "now" === this.state.classInfo.teachers.type ? Object(se["jsx"])(h["c"], {
                                                        src: q.a,
                                                        className: "icon",
                                                        mode: "aspectFill"
                                                    }) : null, "sole" === this.state.classInfo.teachers.type ? Object(se["jsx"])(h["c"], {
                                                        src: L.a,
                                                        className: "icon",
                                                        mode: "aspectFill"
                                                    }) : null, Object(se["jsx"])(h["l"], {
                                                        className: "title",
                                                        children: this.state.classInfo.teachers.typeDescription
                                                    }) ]
                                                }) ]
                                            }) ]
                                        }) ]
                                    }) ]
                                }) ]
                            }), 0 === this.state.activeTab ? Object(se["jsxs"])(h["m"], {
                                className: "classBottom",
                                children: [ Object(se["jsxs"])(h["m"], {
                                    className: "heartWrap",
                                    onClick: function() {
                                        return s.collect();
                                    },
                                    children: [ Object(se["jsx"])(h["c"], {
                                        src: 1 == this.state.classInfo.isCollect ? y.a : C.a,
                                        mode: "widthFix",
                                        className: "heartBtn"
                                    }), Object(se["jsxs"])(h["l"], {
                                        children: [ 1 == this.state.classInfo.isCollect ? "已收藏" : "收藏", " " ]
                                    }) ]
                                }), (this.state.isVip || "0" == this.state.classInfo.vipCourseUnlock) && Object(se["jsx"])(h["m"], {
                                    className: "classBtn",
                                    onClick: function() {
                                        var e = s.state.classInfo.sections.filter(function(e) {
                                            return 0 == e.isListen;
                                        }).length ? s.state.classInfo.sections.filter(function(e) {
                                            return 0 == e.isListen;
                                        })[0] : s.state.classInfo.sections[0];
                                        d["a"].requireLogin().then(function() {
                                            s.playClass(e, s.state.classInfo.id, s.state.classInfo.type);
                                        });
                                    },
                                    children: this.getRecentClass()
                                }), !this.state.isVip && "1" == this.state.classInfo.vipCourseUnlock && Object(se["jsx"])(h["m"], {
                                    className: "classBtn gold",
                                    onClick: function() {
                                        return d["a"].requireLogin().then(function() {
                                            s.handleInviteVisible();
                                        });
                                    },
                                    children: "免费解锁"
                                }), !this.state.isVip && "2" == this.state.classInfo.vipCourseUnlock && Object(Y["a"])("system").includes("iOS") && Object(se["jsx"])(h["m"], {
                                    className: "classBtn gold",
                                    onClick: function() {
                                        return d["a"].requireLogin().then(function() {
                                            s.handleInviteVisible();
                                        });
                                    },
                                    children: "免费解锁"
                                }), "2" == this.state.classInfo.vipCourseUnlock && !this.state.isVip && !Object(Y["a"])("system").includes("iOS") && Object(se["jsx"])(h["m"], {
                                    className: "classBtn",
                                    onClick: function() {
                                        return d["a"].requireLogin().then(function() {
                                            s.toVipPage();
                                        });
                                    },
                                    children: Object(Y["a"])("appConfig").wechatAppVipDefaultTxt
                                }) ]
                            }) : "" ]
                        }), this.state.inviteVisible && Object(se["jsx"])(h["m"], {
                            className: "cover",
                            onClick: this.handleInviteVisible.bind(this),
                            style: {
                                height: "100%"
                            }
                        }), this.state.inviteVisible && Object(se["jsxs"])(h["m"], {
                            className: "inviteWrap",
                            style: {
                                width: "".concat(this.state.windowWidth - 62, "px")
                            },
                            children: [ Object(se["jsx"])(h["c"], {
                                src: P.a,
                                mode: "aspectFill",
                                className: "topImg"
                            }), Object(se["jsx"])(h["m"], {
                                className: "f32 orange",
                                children: this.state.unlockCourseSendFriendTxt[0]
                            }), Object(se["jsx"])(h["m"], {
                                className: "f32",
                                children: this.state.unlockCourseSendFriendTxt[1]
                            }), Object(se["jsx"])(h["m"], {
                                className: "f24",
                                children: this.state.unlockCourseSendFriendTxt[2]
                            }), Object(se["jsxs"])(h["m"], {
                                className: "headWrap",
                                children: [ this.state.inviteFriends.map(function(e) {
                                    return Object(se["jsx"])(h["c"], {
                                        src: e.avatar || F.a,
                                        webp: !0,
                                        className: "head",
                                        mode: "aspectFill"
                                    });
                                }), _.a.times(this.state.unlockCourseSendFriends - this.state.inviteFriends.length, function() {
                                    return Object(se["jsx"])(h["c"], {
                                        src: Q.a,
                                        className: "empty",
                                        mode: "aspectFill"
                                    });
                                }) ]
                            }), this.state.inviteFriends.length === this.state.unlockCourseSendFriends ? Object(se["jsxs"])(h["m"], {
                                className: "unlockWrap",
                                children: [ Object(se["jsx"])(h["c"], {
                                    src: M.a,
                                    mode: "aspectFit",
                                    className: "icon"
                                }), Object(se["jsx"])(h["l"], {
                                    children: "您已解锁"
                                }) ]
                            }) : Object(se["jsxs"])(h["m"], {
                                className: "f24 grey",
                                children: [ "还差", this.state.unlockCourseSendFriends - this.state.inviteFriends.length, "位" ]
                            }), this.state.inviteFriends.length === this.state.unlockCourseSendFriends && Object(se["jsx"])(h["m"], {
                                className: "btn",
                                onClick: function() {
                                    s.handleInviteVisible(), s.setState({
                                        isVip: !0
                                    }), s.getCourseDetail("");
                                },
                                children: "现在去听课"
                            }), this.state.inviteFriends.length !== this.state.unlockCourseSendFriends && Object(se["jsx"])(h["a"], {
                                openType: "share",
                                className: "cleanBtn btn",
                                children: "立即赠送好友"
                            }), Object(se["jsx"])(h["j"], {
                                className: "tipSwiper",
                                vertical: !0,
                                autoplay: !0,
                                circular: !0,
                                children: this.state.inviteFriends.map(function(e) {
                                    return Object(se["jsx"])(h["k"], {
                                        children: Object(se["jsxs"])(h["m"], {
                                            className: "f24",
                                            children: [ e.nickname, "已领取成功" ]
                                        })
                                    });
                                })
                            }), Object(se["jsx"])(h["c"], {
                                src: E.a,
                                className: "closeBtn",
                                onClick: function() {
                                    return s.handleInviteVisible();
                                }
                            }) ]
                        }), this.state.contactVisible && Object(se["jsx"])(h["m"], {
                            className: "cover",
                            style: {
                                height: "".concat(this.state.windowHeight, "px")
                            }
                        }), this.state.contactVisible && Object(se["jsx"])(h["m"], {
                            className: "conWrap",
                            children: Object(se["jsxs"])(h["m"], {
                                className: "por-r",
                                children: [ Object(se["jsx"])(h["a"], {
                                    className: "gotoApp",
                                    openType: "contact"
                                }), Object(se["jsx"])(h["c"], {
                                    src: Z.a,
                                    mode: "widthFix",
                                    className: "cenImg"
                                }), Object(se["jsx"])(h["c"], {
                                    className: "close",
                                    onClick: function() {
                                        return s.handleContact();
                                    },
                                    src: G.a,
                                    mode: "aspectFill"
                                }) ]
                            })
                        }) ]
                    });
                }
            } ]), t;
        }(r["Component"]), ne = {
            navigationBarTitleText: "课程详情",
            navigationStyle: "custom",
            disableScroll: !0
        };
        ae.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(ae, "pages/class/index", {
            root: {
                cn: []
            }
        }, ne || {}));
    },
    57: function(e, s, t) {
        e.exports = t.p + "images/class/play.png";
    },
    58: function(e, s, t) {
        e.exports = t.p + "images/class/lock.png";
    }
}, [ [ 289, 0, 1, 2, 3 ] ] ]);