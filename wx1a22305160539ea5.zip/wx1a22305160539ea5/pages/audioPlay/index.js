(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 8 ], {
    226: function(t, a, e) {
        t.exports = e.p + "images/audio/play.png";
    },
    227: function(t, a, e) {
        t.exports = e.p + "images/audio/pause.png";
    },
    228: function(t, a, e) {
        t.exports = e.p + "images/audio/share.png";
    },
    229: function(t, a, e) {
        t.exports = e.p + "images/audio/go.png";
    },
    230: function(t, a, e) {
        t.exports = e.p + "images/audio/back.png";
    },
    231: function(t, a, e) {
        t.exports = e.p + "images/audio/heart.png";
    },
    232: function(t, a, e) {
        t.exports = e.p + "images/icons/ch.png";
    },
    233: function(t, a, e) {
        t.exports = e.p + "images/icons/en.png";
    },
    283: function(t, a, e) {},
    298: function(t, a, e) {
        "use strict";
        e.r(a);
        for (var s, n, i = e(7), o = e(17), c = e.n(o), u = e(21), r = e(10), d = e(11), l = e(15), p = e(12), h = e(13), m = e(16), f = e(14), g = e(5), y = e.n(g), b = e(1), j = e(6), v = e(29), O = e.n(v), S = e(226), I = e.n(S), k = e(227), x = e.n(k), D = e(228), T = e.n(D), w = e(229), C = e.n(w), N = e(230), P = e.n(N), B = e(231), F = e.n(B), L = e(42), q = e.n(L), M = e(232), V = e.n(M), W = e(233), J = e.n(W), A = e(3), U = (e(283), 
        e(2)), z = e(47), E = e.n(z), G = e(8), H = e(0), _ = [], K = 0; K <= 60; K++) _.push(K);
        var Q = function(t) {
            Object(p["a"])(e, t);
            var a = Object(h["a"])(e);
            function e(t) {
                var i;
                return Object(r["a"])(this, e), i = a.call(this, t), Object(m["a"])(Object(l["a"])(i), "onChange", function(t) {
                    var a = t.detail.value;
                    i.setState({
                        year: i.state.years[a[0]],
                        month: i.state.months[a[1]],
                        day: i.state.days[a[2]],
                        value: a
                    });
                }), Object(m["a"])(Object(l["a"])(i), "startFn", function() {
                    s = void 0, s = y.a.getBackgroundAudioManager(), s.onTimeUpdate(function(t) {
                        var a = s.currentTime / i.state.audioData.duration * 100;
                        i.setState({
                            sliderValue: a
                        });
                    }), s.onEnded(function(t) {
                        i.handleEnded();
                    }), s.onPlay(function(t) {
                        i.setState({
                            playStatus: !0
                        });
                    }), s.onPause(function(t) {
                        n && clearInterval(n), i.setState({
                            playStatus: !1
                        });
                    }), s.onStop(function(t) {
                        clearInterval(n), i.setState({
                            sliderValue: 0,
                            playDuration: "00:00",
                            playStatus: !1
                        }), i.savePlayLogs("practice");
                    });
                }), Object(m["a"])(Object(l["a"])(i), "playAudio", Object(u["a"])(c.a.mark(function t() {
                    return c.a.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            if (!i.state.playStatus) {
                                t.next = 6;
                                break;
                            }
                            s.pause(), clearInterval(n), i.setState({
                                playStatus: !1
                            }), t.next = 16;
                            break;

                          case 6:
                            if (s.src = i.state.audioData.url, s.title = i.state.audioData.title, console.log(s.src), 
                            s.play(), i.countup(), i.setState({
                                playStatus: !0
                            }), i.state.uniqueId) {
                                t.next = 16;
                                break;
                            }
                            return i.setState({
                                startTime: Object(U["a"])().valueOf(),
                                uniqueId: "".concat(Object(A["a"])("nowUser").id).concat(i.state.options.courseId).concat(i.state.audioData.id).concat(Object(U["a"])().valueOf())
                            }), t.next = 16, i.savePlayLogs("playing");

                          case 16:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))), Object(m["a"])(Object(l["a"])(i), "countup", function() {
                    var t = Object(l["a"])(i), a = 1e3;
                    n = setInterval(function() {
                        var e = U["a"].duration({
                            minutes: t.state.audioTime.split(":")[0],
                            seconds: t.state.audioTime.split(":")[1]
                        }).asMilliseconds(), s = U["a"].duration({
                            minutes: t.state.playDuration.split(":")[0],
                            seconds: t.state.playDuration.split(":")[1]
                        }).asMilliseconds(), n = U["a"].duration({
                            seconds: 0,
                            minutes: 0
                        }).asMilliseconds(), i = s - n, o = U["a"].duration(i, "milliseconds");
                        o = U["a"].duration(o.asMilliseconds() + a, "milliseconds"), o.asMilliseconds() < e && t.state.updateState && t.setState({
                            playDuration: Object(U["a"])({
                                seconds: o.seconds(),
                                minutes: o.minutes()
                            }).format("mm:ss")
                        });
                    }, 1e3);
                }), i.state = {
                    options: j["a"].getCurrentPageParam(),
                    navTop: Object(A["a"])("navTop"),
                    windowHeight: y.a.getSystemInfoSync().windowHeight,
                    windowWidth: y.a.getSystemInfoSync().windowWidth,
                    mins: _,
                    playStatus: !1,
                    audioTime: "",
                    audioData: {},
                    sliderValue: 0,
                    updateState: !1,
                    playDuration: "00:00",
                    uniqueId: "",
                    startTime: 0,
                    finishTime: 0,
                    audioInfo: {},
                    isChinese: !0
                }, i;
            }
            return Object(d["a"])(e, [ {
                key: "handleEnded",
                value: function() {
                    var t = Object(u["a"])(c.a.mark(function t() {
                        return c.a.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                Object(A["c"])("playingBackgroundImg", this.state.audioInfo.playingBackgroundImg), 
                                Object(A["c"])("quotes", this.state.audioInfo.quotes), this.savePlayLogs("practice", 1);

                              case 3:
                              case "end":
                                return t.stop();
                            }
                        }, t, this);
                    }));
                    function a() {
                        return t.apply(this, arguments);
                    }
                    return a;
                }()
            }, {
                key: "sliderChange",
                value: function(t) {
                    if (this.state.audioData.duration) {
                        var a = t.detail.value > 100 ? 100 : t.detail.value, e = (a - 1) / 100 * this.state.audioData.duration;
                        s.src || (s.startTime = e);
                        var n = null;
                        e >= this.state.audioData.duration ? n = U["a"].duration(this.state.audioData.duration, "seconds") : e <= 0 ? (n = U["a"].duration(0, "seconds"), 
                        a = 0) : n = U["a"].duration(e, "seconds"), this.setState({
                            playDuration: Object(U["a"])({
                                seconds: n.seconds(),
                                minutes: n.minutes()
                            }).format("mm:ss"),
                            sliderValue: a,
                            updateState: !0
                        }), s.seek(n.asSeconds());
                    }
                }
            }, {
                key: "onShareAppMessage",
                value: function(t) {
                    return "button" === t.from && console.log(t), {
                        title: this.state.audioInfo.shareTitle,
                        path: "/pages/audioPlay/index?type=".concat(this.state.options.type, "&courseId=").concat(this.state.audioInfo.id, "&sectionId=").concat(this.state.audioData.id, "&courseType=").concat(this.state.options.courseType, "&sendCourse=").concat(Object(A["a"])("appConfig").sendCourse, "&inviteCode=").concat(Object(A["a"])("nowUser").invitCode),
                        imageUrl: this.state.audioInfo.shareTitleImg
                    };
                }
            }, {
                key: "initPage",
                value: function(t) {
                    var a = this;
                    console.log("sectionId", this.state.options.sectionId), console.log("courseId", this.state.options.courseId), 
                    new Promise(function(e) {
                        if ("single" == a.state.options.sectionId && Object(G["k"])({
                            id: a.state.options.courseId
                        }).then(function(e) {
                            a.setState({
                                audioInfo: e.result
                            }), console.log(44, e.result), t = e.result.sections[0].id;
                        }), 1 == a.state.options.type) Object(G["q"])().then(function(t) {
                            return a.setState({
                                audioInfo: t.result
                            }), e(t.result);
                        }); else {
                            if (!a.state.options.courseId || !t) return a.setState({
                                audioInfo: Object(A["a"])("audioInfo")
                            }), e(Object(A["a"])("audioData"));
                            Object(G["k"])({
                                id: a.state.options.courseId
                            }).then(function(s) {
                                a.setState({
                                    audioInfo: s.result
                                }), s.result.sections.map(function(a) {
                                    if (a.id == t) return a.playingBackgroundImg = s.result.playingBackgroundImg, e(a);
                                });
                            });
                        }
                    }).then(function(t) {
                        var e = 1 == a.state.options.type ? U["a"].duration(t.duration, "seconds") : U["a"].duration(t.mainDuration, "seconds");
                        t.duration = 1 == a.state.options.type ? t.duration : t.mainDuration, a.setState({
                            audioData: t,
                            audioTime: Object(U["a"])({
                                seconds: e.seconds(),
                                minutes: e.minutes()
                            }).format("mm:ss")
                        });
                    }).then(function() {
                        a.startFn(), a.setState({
                            updateState: !0
                        });
                    });
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    this.initPage(this.state.options.sectionId);
                }
            }, {
                key: "componentWillUnmount",
                value: function() {
                    s.destroy(), clearInterval(n), this.setState({
                        playStatus: !1
                    }), this.savePlayLogs("practice");
                }
            }, {
                key: "fastGo",
                value: function(t) {
                    if (this.state.sliderValue > 0 || t) {
                        var a = this.state.sliderValue / 100 * this.state.audioData.duration;
                        s.src || (s.startTime = a);
                        var e = t ? a + 15 : a - 15, n = null;
                        n = e >= this.state.audioData.duration ? U["a"].duration(this.state.audioData.duration, "seconds") : e <= 0 ? U["a"].duration(0, "seconds") : U["a"].duration(e, "seconds"), 
                        this.setState({
                            playDuration: Object(U["a"])({
                                seconds: n.seconds(),
                                minutes: n.minutes()
                            }).format("mm:ss"),
                            sliderValue: t ? this.state.sliderValue + 15 / this.state.audioData.duration * 100 : this.state.sliderValue - 15 / this.state.audioData.duration * 100,
                            updateState: !0
                        }), s.seek(n.asSeconds());
                    }
                }
            }, {
                key: "handleCollect",
                value: function() {
                    var t = this;
                    j["a"].requireLogin().then(function() {
                        Object(G["i"])({
                            courseId: t.state.options.courseId,
                            sectionId: t.state.audioData.id
                        }).then(function(a) {
                            var e = JSON.parse(JSON.stringify(t.state.audioData));
                            0 == t.state.audioData.isLike ? e.isLike = 1 : e.isLike = 0, t.setState({
                                audioData: e
                            });
                        });
                    });
                }
            }, {
                key: "savePlayLogs",
                value: function(t) {
                    var a = this, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                    console.log("action:", t);
                    var s = "playing" == t ? Object(U["a"])().valueOf() : this.state.startTime, n = "practice" == t ? Object(U["a"])().valueOf() : this.state.finishTime, i = "practice" == t ? U["a"].duration(n - s).asSeconds() : 0, o = {
                        uniqueId: E()(this.state.uniqueId),
                        courseType: this.state.options.courseType,
                        courseId: parseInt(this.state.options.courseId),
                        sectionId: this.state.audioData.id,
                        startTime: s,
                        finishTime: n,
                        duration: i,
                        completed: e
                    };
                    Object(G["z"])({
                        action: t,
                        data: JSON.stringify([ o ])
                    }).then(function(s) {
                        "practice" == t && 1 == e && j["a"].navigatorTo("../complete/index?type=".concat(a.state.options.type, "&title=").concat(a.state.audioInfo.title, "&courseId=").concat(a.state.audioInfo.id, "&sectionId=").concat(a.state.audioData.id, "&durationMinutes=").concat(s.result.durationMinutes, "&continueDays=").concat(s.result.continueDays));
                    });
                }
            }, {
                key: "changeLanguage",
                value: function() {
                    var t = this;
                    j["a"].requireLogin().then(Object(u["a"])(c.a.mark(function a() {
                        var e, n;
                        return c.a.wrap(function(a) {
                            while (1) switch (a.prev = a.next) {
                              case 0:
                                if (t.setState({
                                    sliderValue: 0,
                                    playDuration: "00:00"
                                }), s.seek(0), t.playAudio(), !t.state.isChinese) {
                                    a.next = 9;
                                    break;
                                }
                                return e = JSON.parse(t.state.audioData.relatedSections).en, a.next = 7, t.initPage(e);

                              case 7:
                                a.next = 12;
                                break;

                              case 9:
                                return n = JSON.parse(t.state.audioData.relatedSections).cn, a.next = 12, t.initPage(n);

                              case 12:
                                t.setState({
                                    isChinese: !t.state.isChinese
                                });

                              case 13:
                              case "end":
                                return a.stop();
                            }
                        }, a);
                    })));
                }
            }, {
                key: "handleBack",
                value: function() {
                    var t = Object(u["a"])(c.a.mark(function t() {
                        var a, e;
                        return c.a.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                if (a = Object(g["getCurrentPages"])(), e = a[a.length - 2], !e) {
                                    t.next = 13;
                                    break;
                                }
                                if (!this.state.playStatus) {
                                    t.next = 9;
                                    break;
                                }
                                return s && s.stop(), t.next = 7, j["a"].navigatorBack();

                              case 7:
                                t.next = 11;
                                break;

                              case 9:
                                s && s.stop(), j["a"].navigatorBack();

                              case 11:
                                t.next = 15;
                                break;

                              case 13:
                                s && s.stop(), y.a.switchTab({
                                    url: "../index/index"
                                });

                              case 15:
                              case "end":
                                return t.stop();
                            }
                        }, t, this);
                    }));
                    function a() {
                        return t.apply(this, arguments);
                    }
                    return a;
                }()
            }, {
                key: "render",
                value: function() {
                    var t = this;
                    return Object(H["jsxs"])(b["m"], {
                        className: "container natureWrap",
                        children: [ Object(H["jsx"])(b["b"], {
                            src: O.a,
                            onClick: function() {
                                return t.handleBack();
                            },
                            className: "leftIcon",
                            style: {
                                top: "".concat(this.state.navTop + 4, "px")
                            }
                        }), Object(H["jsx"])(b["c"], {
                            webp: !0,
                            src: this.state.audioData.playingBackgroundImg || this.state.audioData.playBackgroundImg,
                            className: this.state.playStatus ? "nartureImg animate__zoomIn" : "nartureImg",
                            mode: "aspectFill"
                        }), Object(H["jsx"])(b["m"], {
                            className: "titleWrap",
                            children: this.state.audioData.title
                        }), this.state.audioData.relatedSections && "{}" != this.state.audioData.relatedSections && Object(H["jsx"])(b["c"], {
                            className: "tIcon",
                            src: this.state.isChinese ? V.a : J.a,
                            onClick: function() {
                                return t.changeLanguage();
                            }
                        }), Object(H["jsxs"])(b["m"], {
                            className: "playWrap",
                            children: [ Object(H["jsxs"])(b["m"], {
                                className: "shareWrap",
                                children: [ 1 != this.state.options.type && Object(H["jsx"])(b["c"], {
                                    src: 0 == this.state.audioData.isLike ? F.a : q.a,
                                    onClick: function() {
                                        return t.handleCollect();
                                    },
                                    mode: "aspectFit",
                                    className: "icon heart"
                                }), Object(H["jsx"])(b["a"], {
                                    openType: "share",
                                    className: "icon cleanBtn",
                                    children: Object(H["jsx"])(b["c"], {
                                        src: T.a,
                                        mode: "aspectFit",
                                        className: "icon"
                                    })
                                }) ]
                            }), Object(H["jsxs"])(b["m"], {
                                className: "playBar",
                                children: [ Object(H["jsx"])(b["m"], {
                                    className: "time",
                                    children: this.state.playDuration
                                }), Object(H["jsx"])(b["m"], {
                                    className: "barWrap",
                                    children: Object(H["jsx"])(b["i"], {
                                        onChange: this.sliderChange.bind(this),
                                        step: 1e-4,
                                        value: this.state.sliderValue,
                                        blockSize: 12,
                                        color: "#f5f5f550",
                                        backgroundColor: "#f5f5f550",
                                        activeColor: "#f5f5f550",
                                        blockColor: "#FFFFFF",
                                        style: {
                                            margin: 0
                                        }
                                    })
                                }), Object(H["jsx"])(b["m"], {
                                    className: "time",
                                    children: this.state.audioTime
                                }) ]
                            }), Object(H["jsxs"])(b["m"], {
                                className: "playBtns",
                                children: [ Object(H["jsx"])(b["c"], {
                                    src: P.a,
                                    mode: "aspectFit",
                                    onClick: function() {
                                        return t.fastGo(!1);
                                    },
                                    className: "icon"
                                }), Object(H["jsx"])(b["c"], {
                                    src: this.state.playStatus ? x.a : I.a,
                                    onClick: function(a) {
                                        j["a"].requireLogin().then(function() {
                                            t.playAudio();
                                        });
                                    },
                                    mode: "aspectFit",
                                    className: "big"
                                }), Object(H["jsx"])(b["c"], {
                                    src: C.a,
                                    mode: "aspectFit",
                                    onClick: function() {
                                        return t.fastGo(!0);
                                    },
                                    className: "icon"
                                }) ]
                            }) ]
                        }) ]
                    });
                }
            } ]), e;
        }(f["Component"]), R = {
            navigationBarTitleText: "播放功能",
            navigationStyle: "custom",
            disableScroll: !0
        };
        Q.enableShareAppMessage = !0;
        Page(Object(i["createPageConfig"])(Q, "pages/audioPlay/index", {
            root: {
                cn: []
            }
        }, R || {}));
    }
}, [ [ 298, 0, 1, 2, 3 ] ] ]);