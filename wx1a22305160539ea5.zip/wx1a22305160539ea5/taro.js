/*! For license information please see taro.js.LICENSE.txt */
(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 1 ], {
    1: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o;
        }), n.d(t, "b", function() {
            return d;
        }), n.d(t, "c", function() {
            return v;
        }), n.d(t, "d", function() {
            return a;
        }), n.d(t, "e", function() {
            return c;
        }), n.d(t, "f", function() {
            return u;
        }), n.d(t, "g", function() {
            return s;
        }), n.d(t, "h", function() {
            return f;
        }), n.d(t, "i", function() {
            return l;
        }), n.d(t, "j", function() {
            return h;
        }), n.d(t, "k", function() {
            return p;
        }), n.d(t, "l", function() {
            return i;
        }), n.d(t, "m", function() {
            return r;
        }), n.d(t, "n", function() {
            return b;
        });
        var r = "view", i = "text", o = "button", a = "input", c = "picker", u = "picker-view", s = "picker-view-column", l = "slider", d = "cover-image", f = "scroll-view", h = "swiper", p = "swiper-item", v = "image", b = "web-view";
    },
    200: function(e, t, n) {
        "use strict";
        var r = n(10), i = n(11), o = n(201), a = n.n(o), c = n(53), u = n(7), s = n(4);
        function l(e) {
            return "o" === e[0] && "n" === e[1];
        }
        var d = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
        function f(e, t, n) {
            var r;
            for (r in t) r in n || v(e, r, null, t[r]);
            var i = e instanceof u["FormElement"];
            for (r in n) (t[r] !== n[r] || i && "value" === r) && v(e, r, n[r], t[r]);
        }
        function h(e, t, n, r) {
            var i = t.endsWith("Capture"), o = t.toLowerCase().slice(2);
            i && (o = o.slice(0, -7));
            var a = Object(s["c"])(Object(s["t"])(e.tagName.toLowerCase()));
            "click" === o && a in s["g"] && (o = "tap"), Object(s["j"])(n) ? (r || e.addEventListener(o, n, i), 
            "regionchange" === o ? (e.__handlers.begin[0] = n, e.__handlers.end[0] = n) : e.__handlers[o][0] = n) : e.removeEventListener(o, r);
        }
        function p(e, t, n) {
            "-" === t[0] && e.setProperty(t, n.toString()), e[t] = Object(s["k"])(n) && !1 === d.test(t) ? n + "px" : null == n ? "" : n;
        }
        function v(e, t, n, r) {
            var i, o, a, c;
            if (t = "className" === t ? "class" : t, "key" === t || "children" === t || "ref" === t) ; else if ("style" === t) {
                var u = e.style;
                if (Object(s["m"])(n)) u.cssText = n; else {
                    if (Object(s["m"])(r) && (u.cssText = "", r = null), Object(s["l"])(r)) for (var d in r) n && d in n || p(u, d, "");
                    if (Object(s["l"])(n)) for (var f in n) r && n[f] === r[f] || p(u, f, n[f]);
                }
            } else if (l(t)) h(e, t, n, r); else if ("dangerouslySetInnerHTML" === t) {
                var v = null !== (o = null === (i = n) || void 0 === i ? void 0 : i.__html) && void 0 !== o ? o : "", b = null !== (c = null === (a = r) || void 0 === a ? void 0 : a.__html) && void 0 !== c ? c : "";
                (v || b) && b !== v && (e.innerHTML = v);
            } else Object(s["j"])(n) || (null == n ? e.removeAttribute(t) : e.setAttribute(t, n));
        }
        var b = c["unstable_now"];
        function m() {
            return !1;
        }
        var g = {
            createInstance: function(e) {
                return u["document"].createElement(e);
            },
            createTextInstance: function(e) {
                return u["document"].createTextNode(e);
            },
            getPublicInstance: function(e) {
                return e;
            },
            getRootHostContext: function() {
                return {};
            },
            getChildHostContext: function() {
                return {};
            },
            appendChild: function(e, t) {
                e.appendChild(t);
            },
            appendInitialChild: function(e, t) {
                e.appendChild(t);
            },
            appendChildToContainer: function(e, t) {
                e.appendChild(t);
            },
            removeChild: function(e, t) {
                e.removeChild(t);
            },
            removeChildFromContainer: function(e, t) {
                e.removeChild(t);
            },
            insertBefore: function(e, t, n) {
                e.insertBefore(t, n);
            },
            insertInContainerBefore: function(e, t, n) {
                e.insertBefore(t, n);
            },
            commitTextUpdate: function(e, t, n) {
                e.nodeValue = n;
            },
            finalizeInitialChildren: function(e, t, n) {
                return f(e, {}, n), !1;
            },
            prepareUpdate: function() {
                return s["a"];
            },
            commitUpdate: function(e, t, n, r, i) {
                f(e, r, i);
            },
            hideInstance: function(e) {
                var t = e.style;
                t.setProperty("display", "none");
            },
            unhideInstance: function(e, t) {
                var n = t.style, r = (null === n || void 0 === n ? void 0 : n.hasOwnProperty("display")) ? n.display : null;
                r = null == r || "boolean" === typeof r || "" === r ? "" : ("" + r).trim(), e.style["display"] = r;
            },
            clearContainer: function(e) {
                e.childNodes.length > 0 && (e.textContent = "");
            },
            queueMicrotask: "undefined" !== typeof Promise ? function(e) {
                return Promise.resolve(null).then(e).catch(function(e) {
                    setTimeout(function() {
                        throw e;
                    });
                });
            } : setTimeout,
            shouldSetTextContent: m,
            prepareForCommit: function() {
                return null;
            },
            resetAfterCommit: s["q"],
            commitMount: s["q"],
            now: b,
            cancelTimeout: clearTimeout,
            scheduleTimeout: setTimeout,
            preparePortalMount: s["q"],
            noTimeout: -1,
            supportsMutation: !0,
            supportsPersistence: !1,
            isPrimaryRenderer: !0,
            supportsHydration: !1
        }, y = a()(g), O = new WeakMap(), j = function() {
            function e(t, n) {
                Object(r["a"])(this, e), this.renderer = t, this.internalRoot = t.createContainer(n, 0, !1, null);
            }
            return Object(i["a"])(e, [ {
                key: "render",
                value: function(e, t) {
                    return this.renderer.updateContainer(e, this.internalRoot, null, t), this.renderer.getPublicRootInstance(this.internalRoot);
                }
            }, {
                key: "unmount",
                value: function(e) {
                    this.renderer.updateContainer(null, this.internalRoot, null, e);
                }
            } ]), e;
        }();
        function w(e, t, n) {
            var r = O.get(t);
            if (null != r) return r.render(e, n);
            var i = new j(y, t);
            return O.set(t, i), i.render(e, n);
        }
        var k = y.batchedUpdates;
        function E(e) {
            Object(s["f"])(e && [ 1, 8, 9, 11 ].includes(e.nodeType), "unmountComponentAtNode(...): Target container is not a DOM element.");
            var t = O.get(e);
            return !!t && (k(function() {
                t.unmount(function() {
                    O.delete(e);
                });
            }, null), !0);
        }
        function _(e) {
            if (null == e) return null;
            var t = e.nodeType;
            return 1 === t || 3 === t ? e : y.findHostInstance(e);
        }
        var T = "function" === typeof Symbol && Symbol.for ? Symbol.for("react.portal") : 60106;
        function S(e, t, n) {
            return {
                $$typeof: T,
                key: null == n ? null : String(n),
                children: e,
                containerInfo: t,
                implementation: null
            };
        }
        var C = {
            render: w,
            unstable_batchedUpdates: k,
            unmountComponentAtNode: E,
            findDOMNode: _,
            createPortal: S
        };
        t["a"] = C;
    },
    262: function(e, t, n) {
        "use strict";
        var r = n(4), i = new Set([ "authPrivateMessage", "disableAlertBeforeUnload", "enableAlertBeforeUnload", "getBackgroundFetchData", "getGroupEnterInfo", "getShareInfo", "getWeRunData", "join1v1Chat", "openVideoEditor", "saveFileToDisk", "scanItem", "setEnable1v1Chat", "setWindowSize", "sendBizRedPacket", "startFacialRecognitionVerify", "openCustomerServiceChat", "getLocalIPAddress" ]);
        function o(e) {
            Object(r["r"])(e, wx, {
                needPromiseApis: i,
                modifyApis: function(e) {
                    e.delete("lanDebug");
                }
            }), e.cloud = wx.cloud;
        }
        var a = {
            Progress: {
                "border-radius": "0",
                "font-size": "16",
                duration: "30",
                bindActiveEnd: ""
            },
            RichText: {
                space: ""
            },
            Text: {
                "user-select": "false"
            },
            Map: {
                polygons: "[]",
                subkey: "",
                rotate: "0",
                skew: "0",
                "max-scale": "20",
                "min-scale": "3",
                "enable-3D": "false",
                "show-compass": "false",
                "show-scale": "false",
                "enable-overlooking": "false",
                "enable-zoom": "true",
                "enable-scroll": "true",
                "enable-rotate": "false",
                "enable-satellite": "false",
                "enable-traffic": "false",
                setting: "[]",
                bindLabelTap: "",
                bindRegionChange: "",
                bindPoiTap: ""
            },
            Button: {
                lang: "en",
                "session-from": "",
                "send-message-title": "",
                "send-message-path": "",
                "send-message-img": "",
                "app-parameter": "",
                "show-message-card": "false",
                "business-id": "",
                bindGetUserInfo: "",
                bindContact: "",
                bindGetPhoneNumber: "",
                bindError: "",
                bindOpenSetting: "",
                bindLaunchApp: ""
            },
            Form: {
                "report-submit-timeout": "0"
            },
            Input: {
                "always-embed": "false",
                "adjust-position": "true",
                "hold-keyboard": "false",
                bindKeyboardHeightChange: ""
            },
            Picker: {
                "header-text": ""
            },
            PickerView: {
                bindPickStart: "",
                bindPickEnd: ""
            },
            Slider: {
                color: Object(r["s"])("#e9e9e9"),
                "selected-color": Object(r["s"])("#1aad19")
            },
            Textarea: {
                "show-confirm-bar": "true",
                "adjust-position": "true",
                "hold-keyboard": "false",
                "disable-default-padding": "false",
                "confirm-type": Object(r["s"])("return"),
                "confirm-hold": "false",
                bindKeyboardHeightChange: ""
            },
            ScrollView: {
                "enable-flex": "false",
                "scroll-anchoring": "false",
                "refresher-enabled": "false",
                "refresher-threshold": "45",
                "refresher-default-style": Object(r["s"])("black"),
                "refresher-background": Object(r["s"])("#FFF"),
                "refresher-triggered": "false",
                enhanced: "false",
                bounces: "true",
                "show-scrollbar": "true",
                "paging-enabled": "false",
                "fast-deceleration": "false",
                bindDragStart: "",
                bindDragging: "",
                bindDragEnd: "",
                bindRefresherPulling: "",
                bindRefresherRefresh: "",
                bindRefresherRestore: "",
                bindRefresherAbort: ""
            },
            Swiper: {
                "snap-to-edge": "false",
                "easing-function": Object(r["s"])("default")
            },
            SwiperItem: {
                "skip-hidden-item-layout": "false"
            },
            Navigator: {
                target: Object(r["s"])("self"),
                "app-id": "",
                path: "",
                "extra-data": "",
                version: Object(r["s"])("version")
            },
            Camera: {
                mode: Object(r["s"])("normal"),
                resolution: Object(r["s"])("medium"),
                "frame-size": Object(r["s"])("medium"),
                bindInitDone: "",
                bindScanCode: ""
            },
            Image: {
                webp: "false",
                "show-menu-by-longpress": "false"
            },
            LivePlayer: {
                mode: Object(r["s"])("live"),
                "sound-mode": Object(r["s"])("speaker"),
                "auto-pause-if-navigate": "true",
                "auto-pause-if-open-native": "true",
                "picture-in-picture-mode": "[]",
                bindstatechange: "",
                bindfullscreenchange: "",
                bindnetstatus: "",
                bindAudioVolumeNotify: "",
                bindEnterPictureInPicture: "",
                bindLeavePictureInPicture: ""
            },
            Video: {
                title: "",
                "play-btn-position": Object(r["s"])("bottom"),
                "enable-play-gesture": "false",
                "auto-pause-if-navigate": "true",
                "auto-pause-if-open-native": "true",
                "vslide-gesture": "false",
                "vslide-gesture-in-fullscreen": "true",
                "ad-unit-id": "",
                "poster-for-crawler": "",
                "show-casting-button": "false",
                "picture-in-picture-mode": "[]",
                "enable-auto-rotation": "false",
                "show-screen-lock-button": "false",
                "show-snapshot-button": "false",
                "show-background-playback-button": "false",
                "background-poster": "",
                bindProgress: "",
                bindLoadedMetadata: "",
                bindControlsToggle: "",
                bindEnterPictureInPicture: "",
                bindLeavePictureInPicture: "",
                bindSeekComplete: "",
                bindAdLoad: "",
                bindAdError: "",
                bindAdClose: "",
                bindAdPlay: ""
            },
            Canvas: {
                type: ""
            },
            Ad: {
                "ad-type": Object(r["s"])("banner"),
                "ad-theme": Object(r["s"])("white")
            },
            CoverView: {
                "marker-id": "",
                slot: ""
            },
            Editor: {
                "read-only": "false",
                placeholder: "",
                "show-img-size": "false",
                "show-img-toolbar": "false",
                "show-img-resize": "false",
                focus: "false",
                bindReady: "",
                bindFocus: "",
                bindBlur: "",
                bindInput: "",
                bindStatusChange: "",
                name: ""
            },
            MatchMedia: {
                "min-width": "",
                "max-width": "",
                width: "",
                "min-height": "",
                "max-height": "",
                height: "",
                orientation: ""
            },
            FunctionalPageNavigator: {
                version: Object(r["s"])("release"),
                name: "",
                args: "",
                bindSuccess: "",
                bindFail: "",
                bindCancel: ""
            },
            LivePusher: {
                url: "",
                mode: Object(r["s"])("RTC"),
                autopush: "false",
                muted: "false",
                "enable-camera": "true",
                "auto-focus": "true",
                orientation: Object(r["s"])("vertical"),
                beauty: "0",
                whiteness: "0",
                aspect: Object(r["s"])("9:16"),
                "min-bitrate": "200",
                "max-bitrate": "1000",
                "audio-quality": Object(r["s"])("high"),
                "waiting-image": "",
                "waiting-image-hash": "",
                zoom: "false",
                "device-position": Object(r["s"])("front"),
                "background-mute": "false",
                mirror: "false",
                "remote-mirror": "false",
                "local-mirror": "false",
                "audio-reverb-type": "0",
                "enable-mic": "true",
                "enable-agc": "false",
                "enable-ans": "false",
                "audio-volume-type": Object(r["s"])("voicecall"),
                "video-width": "360",
                "video-height": "640",
                "beauty-style": Object(r["s"])("smooth"),
                filter: Object(r["s"])("standard"),
                animation: "",
                bindStateChange: "",
                bindNetStatus: "",
                bindBgmStart: "",
                bindBgmProgress: "",
                bindBgmComplete: "",
                bindAudioVolumeNotify: ""
            },
            OfficialAccount: {
                bindLoad: "",
                bindError: ""
            },
            OpenData: {
                type: "",
                "open-gid": "",
                lang: Object(r["s"])("en"),
                "default-text": "",
                "default-avatar": "",
                bindError: ""
            },
            NavigationBar: {
                title: "",
                loading: "false",
                "front-color": "",
                "background-color": "",
                "color-animation-duration": "0",
                "color-animation-timing-func": Object(r["s"])("linear")
            },
            PageMeta: {
                "background-text-style": "",
                "background-color": "",
                "background-color-top": "",
                "background-color-bottom": "",
                "scroll-top": Object(r["s"])(""),
                "scroll-duration": "300",
                "page-style": Object(r["s"])(""),
                "root-font-size": Object(r["s"])(""),
                bindResize: "",
                bindScroll: "",
                bindScrollDone: ""
            },
            VoipRoom: {
                openid: "",
                mode: Object(r["s"])("camera"),
                "device-position": Object(r["s"])("front"),
                bindError: ""
            },
            AdCustom: {
                "unit-id": "",
                "ad-intervals": "",
                bindLoad: "",
                bindError: ""
            },
            PageContainer: {
                show: "false",
                duration: "300",
                "z-index": "100",
                overlay: "true",
                position: Object(r["s"])("bottom"),
                round: "false",
                "close-on-slideDown": "false",
                "overlay-style": "",
                "custom-style": "",
                bindBeforeEnter: "",
                bindEnter: "",
                bindAfterEnter: "",
                bindBeforeLeave: "",
                bindLeave: "",
                bindAfterLeave: "",
                bindClickOverlay: ""
            },
            KeyboardAccessory: {}
        }, c = {
            initNativeApi: o
        };
        Object(r["p"])(c), Object(r["o"])(a);
    },
    263: function(e, t, n) {
        var r = function() {
            return this;
        }() || Function("return this")(), i = r.regeneratorRuntime && Object.getOwnPropertyNames(r).indexOf("regeneratorRuntime") >= 0, o = i && r.regeneratorRuntime;
        if (r.regeneratorRuntime = void 0, e.exports = n(264), i) r.regeneratorRuntime = o; else try {
            delete r.regeneratorRuntime;
        } catch (e) {
            r.regeneratorRuntime = void 0;
        }
    },
    264: function(e, t, n) {
        (function(e) {
            var t = n(35);
            !function(n) {
                "use strict";
                var r, i = Object.prototype, o = i.hasOwnProperty, a = "function" === typeof Symbol ? Symbol : {}, c = a.iterator || "@@iterator", u = a.asyncIterator || "@@asyncIterator", s = a.toStringTag || "@@toStringTag", l = "object" === t(e), d = n.regeneratorRuntime;
                if (d) l && (e.exports = d); else {
                    d = n.regeneratorRuntime = l ? e.exports : {}, d.wrap = j;
                    var f = "suspendedStart", h = "suspendedYield", p = "executing", v = "completed", b = {}, m = {};
                    m[c] = function() {
                        return this;
                    };
                    var g = Object.getPrototypeOf, y = g && g(g(N([])));
                    y && y !== i && o.call(y, c) && (m = y);
                    var O = _.prototype = k.prototype = Object.create(m);
                    E.prototype = O.constructor = _, _.constructor = E, _[s] = E.displayName = "GeneratorFunction", 
                    d.isGeneratorFunction = function(e) {
                        var t = "function" === typeof e && e.constructor;
                        return !!t && (t === E || "GeneratorFunction" === (t.displayName || t.name));
                    }, d.mark = function(e) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(e, _) : (e.__proto__ = _, s in e || (e[s] = "GeneratorFunction")), 
                        e.prototype = Object.create(O), e;
                    }, d.awrap = function(e) {
                        return {
                            __await: e
                        };
                    }, T(S.prototype), S.prototype[u] = function() {
                        return this;
                    }, d.AsyncIterator = S, d.async = function(e, t, n, r) {
                        var i = new S(j(e, t, n, r));
                        return d.isGeneratorFunction(t) ? i : i.next().then(function(e) {
                            return e.done ? e.value : i.next();
                        });
                    }, T(O), O[s] = "Generator", O[c] = function() {
                        return this;
                    }, O.toString = function() {
                        return "[object Generator]";
                    }, d.keys = function(e) {
                        var t = [];
                        for (var n in e) t.push(n);
                        return t.reverse(), function n() {
                            while (t.length) {
                                var r = t.pop();
                                if (r in e) return n.value = r, n.done = !1, n;
                            }
                            return n.done = !0, n;
                        };
                    }, d.values = N, I.prototype = {
                        constructor: I,
                        reset: function(e) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = r, this.done = !1, this.delegate = null, 
                            this.method = "next", this.arg = r, this.tryEntries.forEach(A), !e) for (var t in this) "t" === t.charAt(0) && o.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = r);
                        },
                        stop: function() {
                            this.done = !0;
                            var e = this.tryEntries[0], t = e.completion;
                            if ("throw" === t.type) throw t.arg;
                            return this.rval;
                        },
                        dispatchException: function(e) {
                            if (this.done) throw e;
                            var t = this;
                            function n(n, i) {
                                return c.type = "throw", c.arg = e, t.next = n, i && (t.method = "next", t.arg = r), 
                                !!i;
                            }
                            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                                var a = this.tryEntries[i], c = a.completion;
                                if ("root" === a.tryLoc) return n("end");
                                if (a.tryLoc <= this.prev) {
                                    var u = o.call(a, "catchLoc"), s = o.call(a, "finallyLoc");
                                    if (u && s) {
                                        if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                        if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                    } else if (u) {
                                        if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                    } else {
                                        if (!s) throw new Error("try statement without catch or finally");
                                        if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                    }
                                }
                            }
                        },
                        abrupt: function(e, t) {
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var r = this.tryEntries[n];
                                if (r.tryLoc <= this.prev && o.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                    var i = r;
                                    break;
                                }
                            }
                            i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                            var a = i ? i.completion : {};
                            return a.type = e, a.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, 
                            b) : this.complete(a);
                        },
                        complete: function(e, t) {
                            if ("throw" === e.type) throw e.arg;
                            return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, 
                            this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), 
                            b;
                        },
                        finish: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), A(n), b;
                            }
                        },
                        catch: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.tryLoc === e) {
                                    var r = n.completion;
                                    if ("throw" === r.type) {
                                        var i = r.arg;
                                        A(n);
                                    }
                                    return i;
                                }
                            }
                            throw new Error("illegal catch attempt");
                        },
                        delegateYield: function(e, t, n) {
                            return this.delegate = {
                                iterator: N(e),
                                resultName: t,
                                nextLoc: n
                            }, "next" === this.method && (this.arg = r), b;
                        }
                    };
                }
                function j(e, t, n, r) {
                    var i = t && t.prototype instanceof k ? t : k, o = Object.create(i.prototype), a = new I(r || []);
                    return o._invoke = C(e, n, a), o;
                }
                function w(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        };
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        };
                    }
                }
                function k() {}
                function E() {}
                function _() {}
                function T(e) {
                    [ "next", "throw", "return" ].forEach(function(t) {
                        e[t] = function(e) {
                            return this._invoke(t, e);
                        };
                    });
                }
                function S(e) {
                    function n(r, i, a, c) {
                        var u = w(e[r], e, i);
                        if ("throw" !== u.type) {
                            var s = u.arg, l = s.value;
                            return l && "object" === t(l) && o.call(l, "__await") ? Promise.resolve(l.__await).then(function(e) {
                                n("next", e, a, c);
                            }, function(e) {
                                n("throw", e, a, c);
                            }) : Promise.resolve(l).then(function(e) {
                                s.value = e, a(s);
                            }, c);
                        }
                        c(u.arg);
                    }
                    var r;
                    function i(e, t) {
                        function i() {
                            return new Promise(function(r, i) {
                                n(e, t, r, i);
                            });
                        }
                        return r = r ? r.then(i, i) : i();
                    }
                    this._invoke = i;
                }
                function C(e, t, n) {
                    var r = f;
                    return function(i, o) {
                        if (r === p) throw new Error("Generator is already running");
                        if (r === v) {
                            if ("throw" === i) throw o;
                            return L();
                        }
                        n.method = i, n.arg = o;
                        while (1) {
                            var a = n.delegate;
                            if (a) {
                                var c = P(a, n);
                                if (c) {
                                    if (c === b) continue;
                                    return c;
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                                if (r === f) throw r = v, n.arg;
                                n.dispatchException(n.arg);
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = p;
                            var u = w(e, t, n);
                            if ("normal" === u.type) {
                                if (r = n.done ? v : h, u.arg === b) continue;
                                return {
                                    value: u.arg,
                                    done: n.done
                                };
                            }
                            "throw" === u.type && (r = v, n.method = "throw", n.arg = u.arg);
                        }
                    };
                }
                function P(e, t) {
                    var n = e.iterator[t.method];
                    if (n === r) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = r, P(e, t), "throw" === t.method)) return b;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method");
                        }
                        return b;
                    }
                    var i = w(n, e.iterator, t.arg);
                    if ("throw" === i.type) return t.method = "throw", t.arg = i.arg, t.delegate = null, 
                    b;
                    var o = i.arg;
                    return o ? o.done ? (t[e.resultName] = o.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", 
                    t.arg = r), t.delegate = null, b) : o : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), 
                    t.delegate = null, b);
                }
                function x(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), 
                    this.tryEntries.push(t);
                }
                function A(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t;
                }
                function I(e) {
                    this.tryEntries = [ {
                        tryLoc: "root"
                    } ], e.forEach(x, this), this.reset(!0);
                }
                function N(e) {
                    if (e) {
                        var t = e[c];
                        if (t) return t.call(e);
                        if ("function" === typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var n = -1, i = function t() {
                                while (++n < e.length) if (o.call(e, n)) return t.value = e[n], t.done = !1, t;
                                return t.value = r, t.done = !0, t;
                            };
                            return i.next = i;
                        }
                    }
                    return {
                        next: L
                    };
                }
                function L() {
                    return {
                        value: r,
                        done: !0
                    };
                }
            }(function() {
                return this;
            }() || Function("return this")());
        }).call(this, n(50)(e));
    },
    265: function(e, t, n) {
        "use strict";
        n.r(t), function(e, r) {
            var i = n(35), o = n.n(i), a = n(199), c = n.n(a), u = n(54), s = n.n(u), l = n(55), d = n.n(l), f = n(52), h = n.n(f), p = n(7);
            "function" !== typeof Object.assign && (Object.assign = function(e) {
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                for (var t = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (null != r) for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (t[i] = r[i]);
                }
                return t;
            }), "function" !== typeof Object.defineProperties && (Object.defineProperties = function(e, t) {
                function n(e) {
                    function t(e, t) {
                        return Object.prototype.hasOwnProperty.call(e, t);
                    }
                    function n(e) {
                        return "function" === typeof e;
                    }
                    if ("object" !== o()(e) || null === e) throw new TypeError("bad desc");
                    var r = {};
                    if (t(e, "enumerable") && (r.enumerable = !!e.enumerable), t(e, "configurable") && (r.configurable = !!e.configurable), 
                    t(e, "value") && (r.value = e.value), t(e, "writable") && (r.writable = !!e.writable), 
                    t(e, "get")) {
                        var i = e.get;
                        if (!n(i) && "undefined" !== typeof i) throw new TypeError("bad get");
                        r.get = i;
                    }
                    if (t(e, "set")) {
                        var a = e.set;
                        if (!n(a) && "undefined" !== typeof a) throw new TypeError("bad set");
                        r.set = a;
                    }
                    if (("get" in r || "set" in r) && ("value" in r || "writable" in r)) throw new TypeError("identity-confused descriptor");
                    return r;
                }
                if ("object" !== o()(e) || null === e) throw new TypeError("bad obj");
                t = Object(t);
                for (var r = Object.keys(t), i = [], a = 0; a < r.length; a++) i.push([ r[a], n(t[r[a]]) ]);
                for (var c = 0; c < i.length; c++) Object.defineProperty(e, i[c][0], i[c][1]);
                return e;
            });
            var v = {
                WEAPP: "WEAPP",
                WEB: "WEB",
                RN: "RN",
                SWAN: "SWAN",
                ALIPAY: "ALIPAY",
                TT: "TT",
                QQ: "QQ",
                JD: "JD",
                KWAI: "KWAI"
            }, b = null;
            function m() {
                return b || ("undefined" !== typeof jd && jd.getSystemInfo ? (b = v.JD, v.JD) : "undefined" !== typeof qq && qq.getSystemInfo ? (b = v.QQ, 
                v.QQ) : "undefined" !== typeof tt && tt.getSystemInfo ? (b = v.TT, v.TT) : "undefined" !== typeof wx && wx.getSystemInfo ? (b = v.WEAPP, 
                v.WEAPP) : "undefined" !== typeof swan && swan.getSystemInfo ? (b = v.SWAN, v.SWAN) : "undefined" !== typeof my && my.getSystemInfo ? (b = v.ALIPAY, 
                v.ALIPAY) : "undefined" !== typeof ks && ks.getSystemInfo ? (b = v.KWAI, v.KWAI) : "undefined" !== typeof e && e.__fbGenNativeModule ? (b = v.RN, 
                v.RN) : "undefined" !== typeof r ? (b = v.WEB, v.WEB) : "Unknown environment");
            }
            var g = function() {
                function e(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                    s()(this, e), this.index = r, this.requestParams = t, this.interceptors = n;
                }
                return d()(e, [ {
                    key: "proceed",
                    value: function(e) {
                        if (this.requestParams = e, this.index >= this.interceptors.length) throw new Error("chain 参数错误, 请勿直接修改 request.chain");
                        var t = this._getNextInterceptor(), n = this._getNextChain(), r = t(n), i = r.catch(function(e) {
                            return Promise.reject(e);
                        });
                        return "function" === typeof r.abort && (i.abort = r.abort), i;
                    }
                }, {
                    key: "_getNextInterceptor",
                    value: function() {
                        return this.interceptors[this.index];
                    }
                }, {
                    key: "_getNextChain",
                    value: function() {
                        return new e(this.requestParams, this.interceptors, this.index + 1);
                    }
                } ]), e;
            }(), y = function() {
                function e(t) {
                    s()(this, e), this.taroInterceptor = t, this.chain = new g();
                }
                return d()(e, [ {
                    key: "request",
                    value: function(e) {
                        var t = this;
                        return this.chain.interceptors = this.chain.interceptors.filter(function(e) {
                            return e !== t.taroInterceptor;
                        }), this.chain.interceptors.push(this.taroInterceptor), this.chain.proceed(c()({}, e));
                    }
                }, {
                    key: "addInterceptor",
                    value: function(e) {
                        this.chain.interceptors.push(e);
                    }
                }, {
                    key: "cleanInterceptors",
                    value: function() {
                        this.chain = new g();
                    }
                } ]), e;
            }();
            function O(e) {
                var t, n = e.requestParams, r = new Promise(function(r, i) {
                    var o = setTimeout(function() {
                        o = null, i(new Error("网络链接超时,请稍后再试！"));
                    }, n && n.timeout || 6e4);
                    t = e.proceed(n), t.then(function(e) {
                        o && (clearTimeout(o), r(e));
                    }).catch(function(e) {
                        o && clearTimeout(o), i(e);
                    });
                });
                return void 0 !== t && "function" === typeof t.abort && (r.abort = t.abort), r;
            }
            function j(e) {
                var t = e.requestParams, n = t.method, r = t.data, i = t.url;
                console.log("http ".concat(n || "GET", " --\x3e ").concat(i, " data: "), r);
                var o = e.proceed(t), a = o.then(function(e) {
                    return console.log("http <-- ".concat(i, " result:"), e), e;
                });
                return "function" === typeof o.abort && (a.abort = o.abort), a;
            }
            var w = Object.freeze({
                __proto__: null,
                timeoutInterceptor: O,
                logInterceptor: j
            });
            function k(e) {
                return e;
            }
            function E(e) {
                return function(t, n) {
                    "object" === o()(t) ? e.preloadData = t : void 0 !== t && void 0 !== n && (e.preloadData = h()({}, t, n));
                };
            }
            function _(e) {
                return function(t) {
                    var n = t.designWidth, r = void 0 === n ? 750 : n, i = t.deviceRatio, o = void 0 === i ? {
                        640: 1.17,
                        750: 1,
                        828: .905
                    } : i;
                    e.config = e.config || {}, e.config.designWidth = r, e.config.deviceRatio = o;
                };
            }
            function T(e) {
                return function(t) {
                    var n = e.config || {}, r = n.designWidth, i = void 0 === r ? 750 : r, o = n.deviceRatio, a = void 0 === o ? {
                        640: 1.17,
                        750: 1,
                        828: .905
                    } : o;
                    if (!(i in a)) throw new Error("deviceRatio 配置中不存在 ".concat(i, " 的设置！"));
                    return parseInt(t, 10) * a[i] + "rpx";
                };
            }
            var S = {
                Behavior: k,
                getEnv: m,
                ENV_TYPE: v,
                Link: y,
                interceptors: w,
                Current: p["Current"],
                getCurrentInstance: p["getCurrentInstance"],
                options: p["options"],
                nextTick: p["nextTick"],
                eventCenter: p["eventCenter"],
                Events: p["Events"],
                useDidShow: p["useDidShow"],
                useDidHide: p["useDidHide"],
                usePullDownRefresh: p["usePullDownRefresh"],
                useReachBottom: p["useReachBottom"],
                usePageScroll: p["usePageScroll"],
                useResize: p["useResize"],
                useShareAppMessage: p["useShareAppMessage"],
                useTabItemTap: p["useTabItemTap"],
                useTitleClick: p["useTitleClick"],
                useOptionMenuClick: p["useOptionMenuClick"],
                usePullIntercept: p["usePullIntercept"],
                useShareTimeline: p["useShareTimeline"],
                useAddToFavorites: p["useAddToFavorites"],
                useReady: p["useReady"],
                useRouter: p["useRouter"],
                getInitPxTransform: _
            };
            S.initPxTransform = _(S), S.preload = E(p["Current"]), S.pxTransform = T(S), t["default"] = S;
        }.call(this, n(36), n(7)["window"]);
    },
    303: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n(7);
        Component(Object(r["createRecursiveComponentConfig"])());
    },
    304: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = n(7);
        Component(r.createRecursiveComponentConfig("custom-wrapper"));
    },
    4: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return re;
        }), n.d(t, "b", function() {
            return ne;
        }), n.d(t, "c", function() {
            return ue;
        }), n.d(t, "d", function() {
            return te;
        }), n.d(t, "e", function() {
            return oe;
        }), n.d(t, "f", function() {
            return le;
        }), n.d(t, "g", function() {
            return ee;
        }), n.d(t, "h", function() {
            return d;
        }), n.d(t, "i", function() {
            return u;
        }), n.d(t, "j", function() {
            return s;
        }), n.d(t, "k", function() {
            return l;
        }), n.d(t, "l", function() {
            return c;
        }), n.d(t, "m", function() {
            return o;
        }), n.d(t, "n", function() {
            return a;
        }), n.d(t, "o", function() {
            return pe;
        }), n.d(t, "p", function() {
            return ve;
        }), n.d(t, "q", function() {
            return ie;
        }), n.d(t, "r", function() {
            return je;
        }), n.d(t, "s", function() {
            return p;
        }), n.d(t, "t", function() {
            return ce;
        }), n.d(t, "u", function() {
            return ae;
        });
        var r = n(19), i = n(20);
        function o(e) {
            return "string" === typeof e;
        }
        function a(e) {
            return "undefined" === typeof e;
        }
        function c(e) {
            return null !== e && "object" === Object(i["a"])(e);
        }
        function u(e) {
            return !0 === e || !1 === e;
        }
        function s(e) {
            return "function" === typeof e;
        }
        function l(e) {
            return "number" === typeof e;
        }
        var d = Array.isArray, f = ("i.".concat("st"), "i.".concat("cl"), {
            bindTouchStart: "",
            bindTouchMove: "",
            bindTouchEnd: "",
            bindTouchCancel: "",
            bindLongTap: ""
        }), h = {
            bindAnimationStart: "",
            bindAnimationIteration: "",
            bindAnimationEnd: "",
            bindTransitionEnd: ""
        };
        function p(e) {
            return "'".concat(e, "'");
        }
        var v = Object.assign(Object.assign({
            "hover-class": p("none"),
            "hover-stop-propagation": "false",
            "hover-start-time": "50",
            "hover-stay-time": "400",
            animation: ""
        }, f), h), b = {
            type: "",
            size: "23",
            color: ""
        }, m = Object.assign({
            longitude: "",
            latitude: "",
            scale: "16",
            markers: "[]",
            covers: "",
            polyline: "[]",
            circles: "[]",
            controls: "[]",
            "include-points": "[]",
            "show-location": "",
            "layer-style": "1",
            bindMarkerTap: "",
            bindControlTap: "",
            bindCalloutTap: "",
            bindUpdated: ""
        }, f), g = {
            percent: "",
            "stroke-width": "6",
            color: p("#09BB07"),
            activeColor: p("#09BB07"),
            backgroundColor: p("#EBEBEB"),
            active: "false",
            "active-mode": p("backwards"),
            "show-info": "false"
        }, y = {
            nodes: "[]"
        }, O = {
            selectable: "false",
            space: "",
            decode: "false"
        }, j = Object.assign({
            size: p("default"),
            type: "",
            plain: "false",
            disabled: "",
            loading: "false",
            "form-type": "",
            "open-type": "",
            "hover-class": p("button-hover"),
            "hover-stop-propagation": "false",
            "hover-start-time": "20",
            "hover-stay-time": "70",
            name: ""
        }, f), w = {
            value: "",
            disabled: "",
            checked: "false",
            color: p("#09BB07"),
            name: ""
        }, k = {
            bindChange: "",
            name: ""
        }, E = {
            "report-submit": "false",
            bindSubmit: "",
            bindReset: "",
            name: ""
        }, _ = {
            value: "",
            type: p(""),
            password: "false",
            placeholder: "",
            "placeholder-style": "",
            "placeholder-class": p("input-placeholder"),
            disabled: "",
            maxlength: "140",
            "cursor-spacing": "0",
            focus: "false",
            "confirm-type": p("done"),
            "confirm-hold": "false",
            cursor: "i.value.length",
            "selection-start": "-1",
            "selection-end": "-1",
            bindInput: "",
            bindFocus: "",
            bindBlur: "",
            bindConfirm: "",
            name: ""
        }, T = {
            for: "",
            name: ""
        }, S = {
            mode: p("selector"),
            disabled: "",
            range: "",
            "range-key": "",
            value: "",
            start: "",
            end: "",
            fields: p("day"),
            "custom-item": "",
            name: "",
            bindCancel: "",
            bindChange: "",
            bindColumnChange: ""
        }, C = {
            value: "",
            "indicator-style": "",
            "indicator-class": "",
            "mask-style": "",
            "mask-class": "",
            bindChange: "",
            name: ""
        }, P = {
            name: ""
        }, x = {
            value: "",
            checked: "false",
            disabled: "",
            color: p("#09BB07"),
            name: ""
        }, A = {
            bindChange: "",
            name: ""
        }, I = {
            min: "0",
            max: "100",
            step: "1",
            disabled: "",
            value: "0",
            activeColor: p("#1aad19"),
            backgroundColor: p("#e9e9e9"),
            "block-size": "28",
            "block-color": p("#ffffff"),
            "show-value": "false",
            bindChange: "",
            bindChanging: "",
            name: ""
        }, N = {
            checked: "false",
            disabled: "",
            type: p("switch"),
            color: p("#04BE02"),
            bindChange: "",
            name: ""
        }, L = {
            value: "",
            placeholder: "",
            "placeholder-style": "",
            "placeholder-class": p("textarea-placeholder"),
            disabled: "",
            maxlength: "140",
            "auto-focus": "false",
            focus: "false",
            "auto-height": "false",
            fixed: "false",
            "cursor-spacing": "0",
            cursor: "-1",
            "selection-start": "-1",
            "selection-end": "-1",
            bindFocus: "",
            bindBlur: "",
            bindLineChange: "",
            bindInput: "",
            bindConfirm: "",
            name: ""
        }, R = {
            src: "",
            bindLoad: "eh",
            bindError: "eh"
        }, B = Object.assign({
            "scroll-top": "false"
        }, f), F = {
            "scale-area": "false"
        }, D = Object.assign(Object.assign({
            direction: "none",
            inertia: "false",
            "out-of-bounds": "false",
            x: "",
            y: "",
            damping: "20",
            friction: "2",
            disabled: "",
            scale: "false",
            "scale-min": "0.5",
            "scale-max": "10",
            "scale-value": "1",
            animation: "true",
            bindChange: "",
            bindScale: "",
            bindHTouchMove: "",
            bindVTouchMove: "",
            width: p("10px"),
            height: p("10px")
        }, f), h), M = Object.assign(Object.assign({
            "scroll-x": "false",
            "scroll-y": "false",
            "upper-threshold": "50",
            "lower-threshold": "50",
            "scroll-top": "",
            "scroll-left": "",
            "scroll-into-view": "",
            "scroll-with-animation": "false",
            "enable-back-to-top": "false",
            bindScrollToUpper: "",
            bindScrollToLower: "",
            bindScroll: ""
        }, f), h), U = Object.assign({
            "indicator-dots": "false",
            "indicator-color": p("rgba(0, 0, 0, .3)"),
            "indicator-active-color": p("#000000"),
            autoplay: "false",
            current: "0",
            interval: "5000",
            duration: "500",
            circular: "false",
            vertical: "false",
            "previous-margin": "'0px'",
            "next-margin": "'0px'",
            "display-multiple-items": "1",
            bindChange: "",
            bindTransition: "",
            bindAnimationFinish: ""
        }, f), $ = {
            "item-id": ""
        }, q = {
            url: "",
            "open-type": p("navigate"),
            delta: "1",
            "hover-class": p("navigator-hover"),
            "hover-stop-propagation": "false",
            "hover-start-time": "50",
            "hover-stay-time": "600",
            bindSuccess: "",
            bindFail: "",
            bindComplete: ""
        }, H = {
            id: "",
            src: "",
            loop: "false",
            controls: "false",
            poster: "",
            name: "",
            author: "",
            bindError: "",
            bindPlay: "",
            bindPause: "",
            bindTimeUpdate: "",
            bindEnded: ""
        }, z = {
            "device-position": p("back"),
            flash: p("auto"),
            bindStop: "",
            bindError: ""
        }, W = Object.assign({
            src: "",
            mode: p("scaleToFill"),
            "lazy-load": "false",
            bindError: "",
            bindLoad: ""
        }, f), V = {
            src: "",
            autoplay: "false",
            muted: "false",
            orientation: p("vertical"),
            "object-fit": p("contain"),
            "background-mute": "false",
            "min-cache": "1",
            "max-cache": "3",
            animation: "",
            bindStateChange: "",
            bindFullScreenChange: "",
            bindNetStatus: ""
        }, G = {
            src: "",
            duration: "",
            controls: "true",
            "danmu-list": "",
            "danmu-btn": "",
            "enable-danmu": "",
            autoplay: "false",
            loop: "false",
            muted: "false",
            "initial-time": "0",
            "page-gesture": "false",
            direction: "",
            "show-progress": "true",
            "show-fullscreen-btn": "true",
            "show-play-btn": "true",
            "show-center-play-btn": "true",
            "enable-progress-gesture": "true",
            "object-fit": p("contain"),
            poster: "",
            "show-mute-btn": "false",
            animation: "",
            bindPlay: "",
            bindPause: "",
            bindEnded: "",
            bindTimeUpdate: "",
            bindFullScreenChange: "",
            bindWaiting: "",
            bindError: ""
        }, K = Object.assign({
            "canvas-id": "",
            "disable-scroll": "false",
            bindError: ""
        }, f), J = {
            "unit-id": "",
            "ad-intervals": "",
            bindLoad: "",
            bindError: "",
            bindClose: ""
        }, Y = {
            src: "",
            bindMessage: "",
            bindLoad: "",
            bindError: ""
        }, Q = {}, Z = {
            name: ""
        }, X = {
            name: ""
        }, ee = {
            View: v,
            Icon: b,
            Progress: g,
            RichText: y,
            Text: O,
            Button: j,
            Checkbox: w,
            CheckboxGroup: k,
            Form: E,
            Input: _,
            Label: T,
            Picker: S,
            PickerView: C,
            PickerViewColumn: P,
            Radio: x,
            RadioGroup: A,
            Slider: I,
            Switch: N,
            CoverImage: R,
            Textarea: L,
            CoverView: B,
            MovableArea: F,
            MovableView: D,
            ScrollView: M,
            Swiper: U,
            SwiperItem: $,
            Navigator: q,
            Audio: H,
            Camera: z,
            Image: W,
            LivePlayer: V,
            Video: G,
            Canvas: K,
            Ad: J,
            WebView: Y,
            Block: Q,
            Map: m,
            Slot: X,
            SlotView: Z
        }, te = new Set([ "input", "checkbox", "picker", "picker-view", "radio", "slider", "switch", "textarea" ]), ne = (new Set([ "input", "textarea" ]), 
        new Set([ "progress", "icon", "rich-text", "input", "textarea", "slider", "switch", "audio", "ad", "official-account", "open-data", "navigation-bar" ]), 
        new Map([ [ "view", -1 ], [ "catch-view", -1 ], [ "cover-view", -1 ], [ "static-view", -1 ], [ "pure-view", -1 ], [ "block", -1 ], [ "text", -1 ], [ "static-text", 6 ], [ "slot", 8 ], [ "slot-view", 8 ], [ "label", 6 ], [ "form", 4 ], [ "scroll-view", 4 ], [ "swiper", 4 ], [ "swiper-item", 4 ] ]), 
        {}), re = [], ie = function() {}, oe = Object.create(null);
        function ae(e) {
            return e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
        }
        function ce(e) {
            for (var t = "", n = !1, r = 0; r < e.length; r++) "-" !== e[r] ? (t += n ? e[r].toUpperCase() : e[r], 
            n = !1) : n = !0;
            return t;
        }
        function ue(e) {
            return e.charAt(0).toUpperCase() + e.slice(1);
        }
        Object.prototype.hasOwnProperty;
        var se = "如有疑问，请提交 issue 至：https://github.com/nervjs/taro/issues";
        function le(e, t) {
            if (!e) throw new Error(t + "\n" + se);
        }
        var de = 1, fe = new Date().getTime().toString();
        function he() {
            return fe + de++;
        }
        function pe(e) {
            Object.keys(e).forEach(function(t) {
                t in ee ? Object.assign(ee[t], e[t]) : ee[t] = e[t];
            });
        }
        function ve(e) {
            Object.keys(e).forEach(function(t) {
                var n = e[t], r = oe[t];
                r ? d(r) ? oe[t] = r.push(n) : oe[t] = [ r, n ] : oe[t] = n;
            });
        }
        function be(e) {
            return function() {
                console.warn("小程序暂不支持 ".concat(e));
            };
        }
        function me(e, t) {
            var n = "__key_", r = [ "navigateTo", "redirectTo", "reLaunch", "switchTab" ];
            if (r.indexOf(e) > -1) {
                var i = t.url = t.url || "", o = i.indexOf("?") > -1, a = he();
                t.url += (o ? "&" : "?") + "".concat(n, "=").concat(a);
            }
        }
        var ge = new Set([ "addPhoneContact", "authorize", "canvasGetImageData", "canvasPutImageData", "canvasToTempFilePath", "checkSession", "chooseAddress", "chooseImage", "chooseInvoiceTitle", "chooseLocation", "chooseVideo", "clearStorage", "closeBLEConnection", "closeBluetoothAdapter", "closeSocket", "compressImage", "connectSocket", "createBLEConnection", "downloadFile", "exitMiniProgram", "getAvailableAudioSources", "getBLEDeviceCharacteristics", "getBLEDeviceServices", "getBatteryInfo", "getBeacons", "getBluetoothAdapterState", "getBluetoothDevices", "getClipboardData", "getConnectedBluetoothDevices", "getConnectedWifi", "getExtConfig", "getFileInfo", "getImageInfo", "getLocation", "getNetworkType", "getSavedFileInfo", "getSavedFileList", "getScreenBrightness", "getSetting", "getStorage", "getStorageInfo", "getSystemInfo", "getUserInfo", "getWifiList", "hideHomeButton", "hideShareMenu", "hideTabBar", "hideTabBarRedDot", "loadFontFace", "login", "makePhoneCall", "navigateBack", "navigateBackMiniProgram", "navigateTo", "navigateToBookshelf", "navigateToMiniProgram", "notifyBLECharacteristicValueChange", "hideKeyboard", "hideLoading", "hideNavigationBarLoading", "hideToast", "openBluetoothAdapter", "openDocument", "openLocation", "openSetting", "pageScrollTo", "previewImage", "queryBookshelf", "reLaunch", "readBLECharacteristicValue", "redirectTo", "removeSavedFile", "removeStorage", "removeTabBarBadge", "requestSubscribeMessage", "saveFile", "saveImageToPhotosAlbum", "saveVideoToPhotosAlbum", "scanCode", "sendSocketMessage", "setBackgroundColor", "setBackgroundTextStyle", "setClipboardData", "setEnableDebug", "setInnerAudioOption", "setKeepScreenOn", "setNavigationBarColor", "setNavigationBarTitle", "setScreenBrightness", "setStorage", "setTabBarBadge", "setTabBarItem", "setTabBarStyle", "showActionSheet", "showFavoriteGuide", "showLoading", "showModal", "showShareMenu", "showTabBar", "showTabBarRedDot", "showToast", "startBeaconDiscovery", "startBluetoothDevicesDiscovery", "startDeviceMotionListening", "startPullDownRefresh", "stopBeaconDiscovery", "stopBluetoothDevicesDiscovery", "stopCompass", "startCompass", "startAccelerometer", "stopAccelerometer", "showNavigationBarLoading", "stopDeviceMotionListening", "stopPullDownRefresh", "switchTab", "uploadFile", "vibrateLong", "vibrateShort", "writeBLECharacteristicValue" ]);
        function ye(e) {
            return function() {
                if ("function" !== typeof e.getSystemInfoSync) return console.error("不支持 API canIUseWebp"), 
                !1;
                var t = e.getSystemInfoSync(), n = t.platform, r = n.toLowerCase();
                return "android" === r || "devtools" === r;
            };
        }
        function Oe(e) {
            return function(t) {
                t = t || {}, "string" === typeof t && (t = {
                    url: t
                });
                var n, r = t.success, i = t.fail, o = t.complete, a = new Promise(function(a, c) {
                    t.success = function(e) {
                        r && r(e), a(e);
                    }, t.fail = function(e) {
                        i && i(e), c(e);
                    }, t.complete = function(e) {
                        o && o(e);
                    }, n = e.request(t);
                });
                return a.abort = function(e) {
                    return e && e(), n && n.abort(), a;
                }, a;
            };
        }
        function je(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i = n.needPromiseApis || [], o = new Set([].concat(Object(r["a"])(i), Object(r["a"])(ge))), a = [ "getEnv", "interceptors", "Current", "getCurrentInstance", "options", "nextTick", "eventCenter", "Events", "preload", "webpackJsonp" ], c = new Set(n.isOnlyPromisify ? i : Object.keys(t).filter(function(e) {
                return -1 === a.indexOf(e);
            }));
            n.modifyApis && n.modifyApis(c), c.forEach(function(r) {
                if (o.has(r)) {
                    var i = r;
                    e[i] = function() {
                        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                        var c = i;
                        if ("string" === typeof e) return o.length ? t[c].apply(t, [ e ].concat(o)) : t[c](e);
                        if (n.transformMeta) {
                            var u = n.transformMeta(c, e);
                            if (c = u.key, e = u.options, !t.hasOwnProperty(c)) return be(c)();
                        }
                        var s = null, l = Object.assign({}, e);
                        me(c, e);
                        var d = new Promise(function(r, i) {
                            l.success = function(t) {
                                var i, o;
                                null === (i = n.modifyAsyncResult) || void 0 === i || i.call(n, c, t), null === (o = e.success) || void 0 === o || o.call(e, t), 
                                r("connectSocket" === c ? Promise.resolve().then(function() {
                                    return s ? Object.assign(s, t) : t;
                                }) : t);
                            }, l.fail = function(t) {
                                var n;
                                null === (n = e.fail) || void 0 === n || n.call(e, t), i(t);
                            }, l.complete = function(t) {
                                var n;
                                null === (n = e.complete) || void 0 === n || n.call(e, t);
                            }, s = o.length ? t[c].apply(t, [ l ].concat(o)) : t[c](l);
                        });
                        return "uploadFile" !== c && "downloadFile" !== c || (d.progress = function(e) {
                            return null === s || void 0 === s || s.onProgressUpdate(e), d;
                        }, d.abort = function(e) {
                            return null === e || void 0 === e || e(), null === s || void 0 === s || s.abort(), 
                            d;
                        }), d;
                    };
                } else {
                    var a = r;
                    if (n.transformMeta && (a = n.transformMeta(r, {}).key), !t.hasOwnProperty(a)) return void (e[r] = be(r));
                    "function" === typeof t[r] ? e[r] = function() {
                        for (var e = arguments.length, i = new Array(e), o = 0; o < e; o++) i[o] = arguments[o];
                        return n.handleSyncApis ? n.handleSyncApis(r, t, i) : t[a].apply(t, i);
                    } : e[r] = t[a];
                }
            }), !n.isOnlyPromisify && we(e, t, n);
        }
        function we(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            e.canIUseWebp = ye(e), e.getCurrentPages = getCurrentPages || be("getCurrentPages"), 
            e.getApp = getApp || be("getApp"), e.env = t.env || {};
            try {
                e.requirePlugin = requirePlugin || be("requirePlugin");
            } catch (t) {
                e.requirePlugin = be("requirePlugin");
            }
            var r = n.request ? n.request : Oe(t);
            function i(e) {
                return r(e.requestParams);
            }
            var o = new e.Link(i);
            e.request = o.request.bind(o), e.addInterceptor = o.addInterceptor.bind(o), e.cleanInterceptors = o.cleanInterceptors.bind(o), 
            e.miniGlobal = e.options.miniGlobal = t;
        }
    },
    5: function(e, t, n) {
        var r = n(7), i = r.container, o = r.SERVICE_IDENTIFIER, a = n(265).default, c = i.get(o.Hooks);
        "function" === typeof c.initNativeApi && c.initNativeApi(a), e.exports = a, e.exports.default = e.exports;
    },
    7: function(e, t, n) {
        "use strict";
        n.r(t), function(e, r, i, o, a, c) {
            n.d(t, "Current", function() {
                return ji;
            }), n.d(t, "ElementNames", function() {
                return Oe;
            }), n.d(t, "Events", function() {
                return ki;
            }), n.d(t, "FormElement", function() {
                return zn;
            }), n.d(t, "SERVICE_IDENTIFIER", function() {
                return S;
            }), n.d(t, "SVGElement", function() {
                return Wn;
            }), n.d(t, "Style", function() {
                return We;
            }), n.d(t, "TaroElement", function() {
                return Ye;
            }), n.d(t, "TaroEvent", function() {
                return ti;
            }), n.d(t, "TaroNode", function() {
                return ke;
            }), n.d(t, "TaroRootElement", function() {
                return Hn;
            }), n.d(t, "TaroText", function() {
                return Ee;
            }), n.d(t, "cancelAnimationFrame", function() {
                return mi;
            }), n.d(t, "connectReactPage", function() {
                return Vi;
            }), n.d(t, "connectVuePage", function() {
                return eo;
            }), n.d(t, "container", function() {
                return ei;
            }), n.d(t, "createComponentConfig", function() {
                return Mi;
            }), n.d(t, "createDocument", function() {
                return ui;
            }), n.d(t, "createEvent", function() {
                return ni;
            }), n.d(t, "createNativeComponentConfig", function() {
                return Xi;
            }), n.d(t, "createPageConfig", function() {
                return Di;
            }), n.d(t, "createReactApp", function() {
                return Ji;
            }), n.d(t, "createRecursiveComponentConfig", function() {
                return Ui;
            }), n.d(t, "createVue3App", function() {
                return oo;
            }), n.d(t, "createVueApp", function() {
                return no;
            }), n.d(t, "document", function() {
                return li;
            }), n.d(t, "eventCenter", function() {
                return _i;
            }), n.d(t, "getComputedStyle", function() {
                return gi;
            }), n.d(t, "getCurrentInstance", function() {
                return wi;
            }), n.d(t, "hydrate", function() {
                return ye;
            }), n.d(t, "injectPageInstance", function() {
                return Pi;
            }), n.d(t, "navigator", function() {
                return pi;
            }), n.d(t, "nextTick", function() {
                return _o;
            }), n.d(t, "now", function() {
                return si;
            }), n.d(t, "options", function() {
                return Mn;
            }), n.d(t, "processPluginHooks", function() {
                return Yr;
            }), n.d(t, "requestAnimationFrame", function() {
                return bi;
            }), n.d(t, "stringify", function() {
                return Ni;
            }), n.d(t, "useAddToFavorites", function() {
                return Oo;
            }), n.d(t, "useDidHide", function() {
                return uo;
            }), n.d(t, "useDidShow", function() {
                return co;
            }), n.d(t, "useOptionMenuClick", function() {
                return mo;
            }), n.d(t, "usePageScroll", function() {
                return fo;
            }), n.d(t, "usePullDownRefresh", function() {
                return so;
            }), n.d(t, "usePullIntercept", function() {
                return go;
            }), n.d(t, "useReachBottom", function() {
                return lo;
            }), n.d(t, "useReady", function() {
                return jo;
            }), n.d(t, "useResize", function() {
                return ho;
            }), n.d(t, "useRouter", function() {
                return wo;
            }), n.d(t, "useScope", function() {
                return ko;
            }), n.d(t, "useShareAppMessage", function() {
                return po;
            }), n.d(t, "useShareTimeline", function() {
                return yo;
            }), n.d(t, "useTabItemTap", function() {
                return vo;
            }), n.d(t, "useTitleClick", function() {
                return bo;
            }), n.d(t, "window", function() {
                return yi;
            });
            n(17), n(21);
            var u = n(60), s = n(197), l = n(19), d = n(22), f = n(18), h = n(246), p = n(198), v = n(15), b = n(12), m = n(13), g = n(16), y = n(10), O = n(11), j = n(20), w = n(9), k = n(4);
            function E(e, t, n, r) {
                var i, o = arguments.length, a = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
                if ("object" === ("undefined" === typeof Reflect ? "undefined" : Object(j["a"])(Reflect)) && "function" === typeof Reflect.decorate) a = Reflect.decorate(e, t, n, r); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (a = (o < 3 ? i(a) : o > 3 ? i(t, n, a) : i(t, n)) || a);
                return o > 3 && a && Object.defineProperty(t, n, a), a;
            }
            function _(e, t) {
                return function(n, r) {
                    t(n, r, e);
                };
            }
            function T(e, t) {
                if ("object" === ("undefined" === typeof Reflect ? "undefined" : Object(j["a"])(Reflect)) && "function" === typeof Reflect.metadata) return Reflect.metadata(e, t);
            }
            (function(t) {
                (function(e) {
                    var n = r(t);
                    function r(e, t) {
                        return function(n, r) {
                            "function" !== typeof e[n] && Object.defineProperty(e, n, {
                                configurable: !0,
                                writable: !0,
                                value: r
                            }), t && t(n, r);
                        };
                    }
                    e(n);
                })(function(t) {
                    var n = Object.prototype.hasOwnProperty, r = "function" === typeof Symbol, i = r && "undefined" !== typeof Symbol.toPrimitive ? Symbol.toPrimitive : "@@toPrimitive", o = r && "undefined" !== typeof Symbol.iterator ? Symbol.iterator : "@@iterator", a = "function" === typeof Object.create, c = {
                        __proto__: []
                    } instanceof Array, u = !a && !c, s = {
                        create: a ? function() {
                            return ae(Object.create(null));
                        } : c ? function() {
                            return ae({
                                __proto__: null
                            });
                        } : function() {
                            return ae({});
                        },
                        has: u ? function(e, t) {
                            return n.call(e, t);
                        } : function(e, t) {
                            return t in e;
                        },
                        get: u ? function(e, t) {
                            return n.call(e, t) ? e[t] : void 0;
                        } : function(e, t) {
                            return e[t];
                        }
                    }, l = Object.getPrototypeOf(Function), d = "object" === ("undefined" === typeof e ? "undefined" : Object(j["a"])(e)) && e.env && "true" === e.env["REFLECT_METADATA_USE_MAP_POLYFILL"], f = d || "function" !== typeof Map || "function" !== typeof Map.prototype.entries ? re() : Map, h = d || "function" !== typeof Set || "function" !== typeof Set.prototype.entries ? ie() : Set, p = d || "function" !== typeof WeakMap ? oe() : WeakMap, v = new p();
                    function b(e, t, n, r) {
                        if (D(n)) {
                            if (!G(e)) throw new TypeError();
                            if (!J(t)) throw new TypeError();
                            return S(e, t);
                        }
                        if (!G(e)) throw new TypeError();
                        if (!$(t)) throw new TypeError();
                        if (!$(r) && !D(r) && !M(r)) throw new TypeError();
                        return M(r) && (r = void 0), n = V(n), C(e, t, n, r);
                    }
                    function m(e, t) {
                        function n(n, r) {
                            if (!$(n)) throw new TypeError();
                            if (!D(r) && !Y(r)) throw new TypeError();
                            L(e, t, n, r);
                        }
                        return n;
                    }
                    function g(e, t, n, r) {
                        if (!$(n)) throw new TypeError();
                        return D(r) || (r = V(r)), L(e, t, n, r);
                    }
                    function y(e, t, n) {
                        if (!$(t)) throw new TypeError();
                        return D(n) || (n = V(n)), x(e, t, n);
                    }
                    function O(e, t, n) {
                        if (!$(t)) throw new TypeError();
                        return D(n) || (n = V(n)), A(e, t, n);
                    }
                    function w(e, t, n) {
                        if (!$(t)) throw new TypeError();
                        return D(n) || (n = V(n)), I(e, t, n);
                    }
                    function k(e, t, n) {
                        if (!$(t)) throw new TypeError();
                        return D(n) || (n = V(n)), N(e, t, n);
                    }
                    function E(e, t) {
                        if (!$(e)) throw new TypeError();
                        return D(t) || (t = V(t)), R(e, t);
                    }
                    function _(e, t) {
                        if (!$(e)) throw new TypeError();
                        return D(t) || (t = V(t)), B(e, t);
                    }
                    function T(e, t, n) {
                        if (!$(t)) throw new TypeError();
                        D(n) || (n = V(n));
                        var r = P(t, n, !1);
                        if (D(r)) return !1;
                        if (!r.delete(e)) return !1;
                        if (r.size > 0) return !0;
                        var i = v.get(t);
                        return i.delete(n), i.size > 0 || v.delete(t), !0;
                    }
                    function S(e, t) {
                        for (var n = e.length - 1; n >= 0; --n) {
                            var r = e[n], i = r(t);
                            if (!D(i) && !M(i)) {
                                if (!J(i)) throw new TypeError();
                                t = i;
                            }
                        }
                        return t;
                    }
                    function C(e, t, n, r) {
                        for (var i = e.length - 1; i >= 0; --i) {
                            var o = e[i], a = o(t, n, r);
                            if (!D(a) && !M(a)) {
                                if (!$(a)) throw new TypeError();
                                r = a;
                            }
                        }
                        return r;
                    }
                    function P(e, t, n) {
                        var r = v.get(e);
                        if (D(r)) {
                            if (!n) return;
                            r = new f(), v.set(e, r);
                        }
                        var i = r.get(t);
                        if (D(i)) {
                            if (!n) return;
                            i = new f(), r.set(t, i);
                        }
                        return i;
                    }
                    function x(e, t, n) {
                        var r = A(e, t, n);
                        if (r) return !0;
                        var i = ne(t);
                        return !M(i) && x(e, i, n);
                    }
                    function A(e, t, n) {
                        var r = P(t, n, !1);
                        return !D(r) && z(r.has(e));
                    }
                    function I(e, t, n) {
                        var r = A(e, t, n);
                        if (r) return N(e, t, n);
                        var i = ne(t);
                        return M(i) ? void 0 : I(e, i, n);
                    }
                    function N(e, t, n) {
                        var r = P(t, n, !1);
                        if (!D(r)) return r.get(e);
                    }
                    function L(e, t, n, r) {
                        var i = P(n, r, !0);
                        i.set(e, t);
                    }
                    function R(e, t) {
                        var n = B(e, t), r = ne(e);
                        if (null === r) return n;
                        var i = R(r, t);
                        if (i.length <= 0) return n;
                        if (n.length <= 0) return i;
                        for (var o = new h(), a = [], c = 0, u = n; c < u.length; c++) {
                            var s = u[c], l = o.has(s);
                            l || (o.add(s), a.push(s));
                        }
                        for (var d = 0, f = i; d < f.length; d++) {
                            s = f[d], l = o.has(s);
                            l || (o.add(s), a.push(s));
                        }
                        return a;
                    }
                    function B(e, t) {
                        var n = [], r = P(e, t, !1);
                        if (D(r)) return n;
                        var i = r.keys(), o = Z(i), a = 0;
                        while (1) {
                            var c = ee(o);
                            if (!c) return n.length = a, n;
                            var u = X(c);
                            try {
                                n[a] = u;
                            } catch (e) {
                                try {
                                    te(o);
                                } finally {
                                    throw e;
                                }
                            }
                            a++;
                        }
                    }
                    function F(e) {
                        if (null === e) return 1;
                        switch (Object(j["a"])(e)) {
                          case "undefined":
                            return 0;

                          case "boolean":
                            return 2;

                          case "string":
                            return 3;

                          case "symbol":
                            return 4;

                          case "number":
                            return 5;

                          case "object":
                            return null === e ? 1 : 6;

                          default:
                            return 6;
                        }
                    }
                    function D(e) {
                        return void 0 === e;
                    }
                    function M(e) {
                        return null === e;
                    }
                    function U(e) {
                        return "symbol" === Object(j["a"])(e);
                    }
                    function $(e) {
                        return "object" === Object(j["a"])(e) ? null !== e : "function" === typeof e;
                    }
                    function q(e, t) {
                        switch (F(e)) {
                          case 0:
                            return e;

                          case 1:
                            return e;

                          case 2:
                            return e;

                          case 3:
                            return e;

                          case 4:
                            return e;

                          case 5:
                            return e;
                        }
                        var n = 3 === t ? "string" : 5 === t ? "number" : "default", r = Q(e, i);
                        if (void 0 !== r) {
                            var o = r.call(e, n);
                            if ($(o)) throw new TypeError();
                            return o;
                        }
                        return H(e, "default" === n ? "number" : n);
                    }
                    function H(e, t) {
                        if ("string" === t) {
                            var n = e.toString;
                            if (K(n)) {
                                var r = n.call(e);
                                if (!$(r)) return r;
                            }
                            var i = e.valueOf;
                            if (K(i)) {
                                r = i.call(e);
                                if (!$(r)) return r;
                            }
                        } else {
                            i = e.valueOf;
                            if (K(i)) {
                                r = i.call(e);
                                if (!$(r)) return r;
                            }
                            var o = e.toString;
                            if (K(o)) {
                                r = o.call(e);
                                if (!$(r)) return r;
                            }
                        }
                        throw new TypeError();
                    }
                    function z(e) {
                        return !!e;
                    }
                    function W(e) {
                        return "" + e;
                    }
                    function V(e) {
                        var t = q(e, 3);
                        return U(t) ? t : W(t);
                    }
                    function G(e) {
                        return Array.isArray ? Array.isArray(e) : e instanceof Object ? e instanceof Array : "[object Array]" === Object.prototype.toString.call(e);
                    }
                    function K(e) {
                        return "function" === typeof e;
                    }
                    function J(e) {
                        return "function" === typeof e;
                    }
                    function Y(e) {
                        switch (F(e)) {
                          case 3:
                            return !0;

                          case 4:
                            return !0;

                          default:
                            return !1;
                        }
                    }
                    function Q(e, t) {
                        var n = e[t];
                        if (void 0 !== n && null !== n) {
                            if (!K(n)) throw new TypeError();
                            return n;
                        }
                    }
                    function Z(e) {
                        var t = Q(e, o);
                        if (!K(t)) throw new TypeError();
                        var n = t.call(e);
                        if (!$(n)) throw new TypeError();
                        return n;
                    }
                    function X(e) {
                        return e.value;
                    }
                    function ee(e) {
                        var t = e.next();
                        return !t.done && t;
                    }
                    function te(e) {
                        var t = e["return"];
                        t && t.call(e);
                    }
                    function ne(e) {
                        var t = Object.getPrototypeOf(e);
                        if ("function" !== typeof e || e === l) return t;
                        if (t !== l) return t;
                        var n = e.prototype, r = n && Object.getPrototypeOf(n);
                        if (null == r || r === Object.prototype) return t;
                        var i = r.constructor;
                        return "function" !== typeof i || i === e ? t : i;
                    }
                    function re() {
                        var e = {}, t = [], n = function() {
                            function e(e, t, n) {
                                this._index = 0, this._keys = e, this._values = t, this._selector = n;
                            }
                            return e.prototype["@@iterator"] = function() {
                                return this;
                            }, e.prototype[o] = function() {
                                return this;
                            }, e.prototype.next = function() {
                                var e = this._index;
                                if (e >= 0 && e < this._keys.length) {
                                    var n = this._selector(this._keys[e], this._values[e]);
                                    return e + 1 >= this._keys.length ? (this._index = -1, this._keys = t, this._values = t) : this._index++, 
                                    {
                                        value: n,
                                        done: !1
                                    };
                                }
                                return {
                                    value: void 0,
                                    done: !0
                                };
                            }, e.prototype.throw = function(e) {
                                throw this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), 
                                e;
                            }, e.prototype.return = function(e) {
                                return this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), 
                                {
                                    value: e,
                                    done: !0
                                };
                            }, e;
                        }();
                        return function() {
                            function t() {
                                this._keys = [], this._values = [], this._cacheKey = e, this._cacheIndex = -2;
                            }
                            return Object.defineProperty(t.prototype, "size", {
                                get: function() {
                                    return this._keys.length;
                                },
                                enumerable: !0,
                                configurable: !0
                            }), t.prototype.has = function(e) {
                                return this._find(e, !1) >= 0;
                            }, t.prototype.get = function(e) {
                                var t = this._find(e, !1);
                                return t >= 0 ? this._values[t] : void 0;
                            }, t.prototype.set = function(e, t) {
                                var n = this._find(e, !0);
                                return this._values[n] = t, this;
                            }, t.prototype.delete = function(t) {
                                var n = this._find(t, !1);
                                if (n >= 0) {
                                    for (var r = this._keys.length, i = n + 1; i < r; i++) this._keys[i - 1] = this._keys[i], 
                                    this._values[i - 1] = this._values[i];
                                    return this._keys.length--, this._values.length--, t === this._cacheKey && (this._cacheKey = e, 
                                    this._cacheIndex = -2), !0;
                                }
                                return !1;
                            }, t.prototype.clear = function() {
                                this._keys.length = 0, this._values.length = 0, this._cacheKey = e, this._cacheIndex = -2;
                            }, t.prototype.keys = function() {
                                return new n(this._keys, this._values, r);
                            }, t.prototype.values = function() {
                                return new n(this._keys, this._values, i);
                            }, t.prototype.entries = function() {
                                return new n(this._keys, this._values, a);
                            }, t.prototype["@@iterator"] = function() {
                                return this.entries();
                            }, t.prototype[o] = function() {
                                return this.entries();
                            }, t.prototype._find = function(e, t) {
                                return this._cacheKey !== e && (this._cacheIndex = this._keys.indexOf(this._cacheKey = e)), 
                                this._cacheIndex < 0 && t && (this._cacheIndex = this._keys.length, this._keys.push(e), 
                                this._values.push(void 0)), this._cacheIndex;
                            }, t;
                        }();
                        function r(e, t) {
                            return e;
                        }
                        function i(e, t) {
                            return t;
                        }
                        function a(e, t) {
                            return [ e, t ];
                        }
                    }
                    function ie() {
                        return function() {
                            function e() {
                                this._map = new f();
                            }
                            return Object.defineProperty(e.prototype, "size", {
                                get: function() {
                                    return this._map.size;
                                },
                                enumerable: !0,
                                configurable: !0
                            }), e.prototype.has = function(e) {
                                return this._map.has(e);
                            }, e.prototype.add = function(e) {
                                return this._map.set(e, e), this;
                            }, e.prototype.delete = function(e) {
                                return this._map.delete(e);
                            }, e.prototype.clear = function() {
                                this._map.clear();
                            }, e.prototype.keys = function() {
                                return this._map.keys();
                            }, e.prototype.values = function() {
                                return this._map.values();
                            }, e.prototype.entries = function() {
                                return this._map.entries();
                            }, e.prototype["@@iterator"] = function() {
                                return this.keys();
                            }, e.prototype[o] = function() {
                                return this.keys();
                            }, e;
                        }();
                    }
                    function oe() {
                        var e = 16, t = s.create(), r = i();
                        return function() {
                            function e() {
                                this._key = i();
                            }
                            return e.prototype.has = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && s.has(t, this._key);
                            }, e.prototype.get = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t ? s.get(t, this._key) : void 0;
                            }, e.prototype.set = function(e, t) {
                                var n = o(e, !0);
                                return n[this._key] = t, this;
                            }, e.prototype.delete = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && delete t[this._key];
                            }, e.prototype.clear = function() {
                                this._key = i();
                            }, e;
                        }();
                        function i() {
                            var e;
                            do {
                                e = "@@WeakMap@@" + u();
                            } while (s.has(t, e));
                            return t[e] = !0, e;
                        }
                        function o(e, t) {
                            if (!n.call(e, r)) {
                                if (!t) return;
                                Object.defineProperty(e, r, {
                                    value: s.create()
                                });
                            }
                            return e[r];
                        }
                        function a(e, t) {
                            for (var n = 0; n < t; ++n) e[n] = 255 * Math.random() | 0;
                            return e;
                        }
                        function c(e) {
                            return "function" === typeof Uint8Array ? "undefined" !== typeof crypto ? crypto.getRandomValues(new Uint8Array(e)) : "undefined" !== typeof msCrypto ? msCrypto.getRandomValues(new Uint8Array(e)) : a(new Uint8Array(e), e) : a(new Array(e), e);
                        }
                        function u() {
                            var t = c(e);
                            t[6] = 79 & t[6] | 64, t[8] = 191 & t[8] | 128;
                            for (var n = "", r = 0; r < e; ++r) {
                                var i = t[r];
                                4 !== r && 6 !== r && 8 !== r || (n += "-"), i < 16 && (n += "0"), n += i.toString(16).toLowerCase();
                            }
                            return n;
                        }
                    }
                    function ae(e) {
                        return e.__ = void 0, delete e.__, e;
                    }
                    t("decorate", b), t("metadata", m), t("defineMetadata", g), t("hasMetadata", y), 
                    t("hasOwnMetadata", O), t("getMetadata", w), t("getOwnMetadata", k), t("getMetadataKeys", E), 
                    t("getOwnMetadataKeys", _), t("deleteMetadata", T);
                });
            })(Reflect || (Reflect = {}));
            var S = {
                TaroElement: "TaroElement",
                TaroElementFactory: "Factory<TaroElement>",
                TaroText: "TaroText",
                TaroTextFactory: "Factory<TaroText>",
                TaroNodeImpl: "TaroNodeImpl",
                TaroElementImpl: "TaroElementImpl",
                Hooks: "hooks",
                onRemoveAttribute: "onRemoveAttribute",
                getLifecycle: "getLifecycle",
                getPathIndex: "getPathIndex",
                getEventCenter: "getEventCenter",
                isBubbleEvents: "isBubbleEvents",
                getSpecialNodes: "getSpecialNodes",
                eventCenter: "eventCenter",
                modifyMpEvent: "modifyMpEvent",
                modifyTaroEvent: "modifyTaroEvent",
                batchedEventUpdates: "batchedEventUpdates",
                mergePageInstance: "mergePageInstance",
                createPullDownComponent: "createPullDownComponent",
                getDOMNode: "getDOMNode",
                initNativeApi: "initNativeApi",
                modifyHydrateData: "modifyHydrateData",
                modifySetAttrPayload: "modifySetAttrPayload",
                modifyRmAttrPayload: "modifyRmAttrPayload",
                onAddEvent: "onAddEvent",
                patchElement: "patchElement"
            }, C = "taro-app", P = "小程序 setData", x = "页面初始化", A = "root", I = "html", N = "head", L = "body", R = "app", B = "container", F = "#document", D = "document-fragment", M = "id", U = "uid", $ = "class", q = "style", H = "focus", z = "view", W = "static-view", V = "pure-view", G = "props", K = "dataset", J = "object", Y = "value", Q = "input", Z = "change", X = "custom-wrapper", ee = "target", te = "currentTarget", ne = "type", re = "confirm", ie = "timeStamp", oe = "keyCode", ae = "touchmove", ce = "Date", ue = "catchMove", se = "catch-view", le = "comment", de = function() {
                var e = 0;
                return function() {
                    return (e++).toString();
                };
            };
            function fe(e) {
                return 1 === e.nodeType;
            }
            function he(e) {
                return 3 === e.nodeType;
            }
            function pe(e) {
                return e.nodeName === le;
            }
            function ve(e) {
                var t = Object.keys(e.props).find(function(e) {
                    return !(/^(class|style|id)$/.test(e) || e.startsWith("data-"));
                });
                return Boolean(t);
            }
            function be(e, t) {
                var n, r = !1;
                while ((null === e || void 0 === e ? void 0 : e.parentElement) && e.parentElement._path !== A) {
                    if (null === (n = e.parentElement.__handlers[t]) || void 0 === n ? void 0 : n.length) {
                        r = !0;
                        break;
                    }
                    e = e.parentElement;
                }
                return r;
            }
            function me(e) {
                switch (e) {
                  case q:
                    return "st";

                  case M:
                    return U;

                  case $:
                    return "cl";

                  default:
                    return e;
                }
            }
            var ge = function() {
                function e(t) {
                    Object(y["a"])(this, e), this.__handlers = {}, this.hooks = t;
                }
                return Object(O["a"])(e, [ {
                    key: "addEventListener",
                    value: function(e, t, n) {
                        var r, i;
                        if (null === (i = (r = this.hooks).onAddEvent) || void 0 === i || i.call(r, e, t, n, this), 
                        "regionchange" === e) return this.addEventListener("begin", t, n), void this.addEventListener("end", t, n);
                        e = e.toLowerCase();
                        var o = this.__handlers[e], a = (Boolean(n), !1);
                        if (Object(k["l"])(n) && (Boolean(n.capture), a = Boolean(n.once)), a) {
                            var c = function n() {
                                t.apply(this, arguments), this.removeEventListener(e, n);
                            };
                            this.addEventListener(e, c, Object.assign(Object.assign({}, n), {
                                once: !1
                            }));
                        } else Object(k["h"])(o) ? o.push(t) : this.__handlers[e] = [ t ];
                    }
                }, {
                    key: "removeEventListener",
                    value: function(e, t) {
                        if (e = e.toLowerCase(), null != t) {
                            var n = this.__handlers[e];
                            if (Object(k["h"])(n)) {
                                var r = n.indexOf(t);
                                n.splice(r, 1);
                            }
                        }
                    }
                }, {
                    key: "isAnyEventBinded",
                    value: function() {
                        var e = this.__handlers, t = Object.keys(e).find(function(t) {
                            return e[t].length;
                        });
                        return Boolean(t);
                    }
                } ]), e;
            }();
            function ye(e) {
                var t, n, r, i, o = e.nodeName;
                if (he(e)) return i = {}, Object(g["a"])(i, "v", e.nodeValue), Object(g["a"])(i, "nn", o), 
                i;
                var a = (t = {}, Object(g["a"])(t, "nn", o), Object(g["a"])(t, "uid", e.uid), t), c = e.props, u = e.hooks.getSpecialNodes();
                for (var s in !e.isAnyEventBinded() && u.indexOf(o) > -1 && (a["nn"] = "static-".concat(o), 
                o !== z || ve(e) || (a["nn"] = V)), c) {
                    var l = Object(k["t"])(s);
                    s.startsWith("data-") || s === $ || s === q || s === M || l === ue || (a[l] = c[s]), 
                    o === z && l === ue && !1 !== c[s] && (a["nn"] = se);
                }
                var d = e.childNodes;
                return d = d.filter(function(e) {
                    return !pe(e);
                }), d.length > 0 ? a["cn"] = d.map(ye) : a["cn"] = [], "" !== e.className && (a["cl"] = e.className), 
                "" !== e.cssText && "swiper-item" !== o && (a["st"] = e.cssText), null === (r = (n = e.hooks).modifyHydrateData) || void 0 === r || r.call(n, a), 
                a;
            }
            ge = E([ Object(w["d"])(), _(0, Object(w["c"])(S.Hooks)), T("design:paramtypes", [ Object ]) ], ge);
            var Oe, je = new Map();
            (function(e) {
                e["Element"] = "Element", e["Document"] = "Document", e["RootElement"] = "RootElement", 
                e["FormElement"] = "FormElement";
            })(Oe || (Oe = {}));
            var we = de(), ke = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r, i) {
                    var o;
                    return Object(y["a"])(this, n), o = t.call(this, i), o.parentNode = null, o.childNodes = [], 
                    o.hydrate = function(e) {
                        return function() {
                            return ye(e);
                        };
                    }, e.bind(Object(v["a"])(o)), o._getElement = r, o.uid = "_n_".concat(we()), je.set(o.uid, Object(v["a"])(o)), 
                    o;
                }
                return Object(O["a"])(n, [ {
                    key: "_empty",
                    value: function() {
                        while (this.childNodes.length > 0) {
                            var e = this.childNodes[0];
                            e.parentNode = null, je.delete(e.uid), this.childNodes.shift();
                        }
                    }
                }, {
                    key: "_root",
                    get: function() {
                        var e;
                        return (null === (e = this.parentNode) || void 0 === e ? void 0 : e._root) || null;
                    }
                }, {
                    key: "findIndex",
                    value: function(e) {
                        var t = this.childNodes.indexOf(e);
                        return Object(k["f"])(-1 !== t, "The node to be replaced is not a child of this node."), 
                        t;
                    }
                }, {
                    key: "_path",
                    get: function() {
                        var e = this.parentNode;
                        if (e) {
                            var t = e.childNodes.filter(function(e) {
                                return !pe(e);
                            }), n = t.indexOf(this), r = this.hooks.getPathIndex(n);
                            return "".concat(e._path, ".", "cn", ".").concat(r);
                        }
                        return "";
                    }
                }, {
                    key: "nextSibling",
                    get: function() {
                        var e = this.parentNode;
                        return (null === e || void 0 === e ? void 0 : e.childNodes[e.findIndex(this) + 1]) || null;
                    }
                }, {
                    key: "previousSibling",
                    get: function() {
                        var e = this.parentNode;
                        return (null === e || void 0 === e ? void 0 : e.childNodes[e.findIndex(this) - 1]) || null;
                    }
                }, {
                    key: "parentElement",
                    get: function() {
                        var e = this.parentNode;
                        return 1 === (null === e || void 0 === e ? void 0 : e.nodeType) ? e : null;
                    }
                }, {
                    key: "firstChild",
                    get: function() {
                        return this.childNodes[0] || null;
                    }
                }, {
                    key: "lastChild",
                    get: function() {
                        var e = this.childNodes;
                        return e[e.length - 1] || null;
                    }
                }, {
                    key: "textContent",
                    set: function(e) {
                        if (this._empty(), "" === e) this.enqueueUpdate({
                            path: "".concat(this._path, ".", "cn"),
                            value: function() {
                                return [];
                            }
                        }); else {
                            var t = this._getElement(Oe.Document)();
                            this.appendChild(t.createTextNode(e));
                        }
                    }
                }, {
                    key: "insertBefore",
                    value: function(e, t, n) {
                        var r, i = this;
                        if (e.nodeName === D) return e.childNodes.reduceRight(function(e, t) {
                            return i.insertBefore(t, e), t;
                        }, t), e;
                        if (e.remove(), e.parentNode = this, t) {
                            var o = this.findIndex(t);
                            this.childNodes.splice(o, 0, e), r = n ? {
                                path: e._path,
                                value: this.hydrate(e)
                            } : {
                                path: "".concat(this._path, ".", "cn"),
                                value: function() {
                                    var e = i.childNodes.filter(function(e) {
                                        return !pe(e);
                                    });
                                    return e.map(ye);
                                }
                            };
                        } else this.childNodes.push(e), r = {
                            path: e._path,
                            value: this.hydrate(e)
                        };
                        return this.enqueueUpdate(r), je.has(e.uid) || je.set(e.uid, e), e;
                    }
                }, {
                    key: "appendChild",
                    value: function(e) {
                        this.insertBefore(e);
                    }
                }, {
                    key: "replaceChild",
                    value: function(e, t) {
                        if (t.parentNode === this) return this.insertBefore(e, t, !0), t.remove(!0), t;
                    }
                }, {
                    key: "removeChild",
                    value: function(e, t) {
                        var n = this, r = this.findIndex(e);
                        return this.childNodes.splice(r, 1), t || this.enqueueUpdate({
                            path: "".concat(this._path, ".", "cn"),
                            value: function() {
                                var e = n.childNodes.filter(function(e) {
                                    return !pe(e);
                                });
                                return e.map(ye);
                            }
                        }), e.parentNode = null, je.delete(e.uid), e;
                    }
                }, {
                    key: "remove",
                    value: function(e) {
                        var t;
                        null === (t = this.parentNode) || void 0 === t || t.removeChild(this, e);
                    }
                }, {
                    key: "hasChildNodes",
                    value: function() {
                        return this.childNodes.length > 0;
                    }
                }, {
                    key: "enqueueUpdate",
                    value: function(e) {
                        var t;
                        null === (t = this._root) || void 0 === t || t.enqueueUpdate(e);
                    }
                }, {
                    key: "contains",
                    value: function(e) {
                        var t = !1;
                        return this.childNodes.some(function(n) {
                            var r = n.uid;
                            if (r === e.uid || r === e.id || n.contains(e)) return t = !0, !0;
                        }), t;
                    }
                }, {
                    key: "ownerDocument",
                    get: function() {
                        var e = this._getElement(Oe.Document)();
                        return e;
                    }
                } ]), n;
            }(ge);
            ke = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroNodeImpl)), _(1, Object(w["c"])(S.TaroElementFactory)), _(2, Object(w["c"])(S.Hooks)), T("design:paramtypes", [ Function, Function, Function ]) ], ke);
            var Ee = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r, i) {
                    var o;
                    return Object(y["a"])(this, n), o = t.call(this, e, r, i), o.nodeType = 3, o.nodeName = "#text", 
                    o;
                }
                return Object(O["a"])(n, [ {
                    key: "textContent",
                    get: function() {
                        return this._value;
                    },
                    set: function(e) {
                        this._value = e, this.enqueueUpdate({
                            path: "".concat(this._path, ".", "v"),
                            value: e
                        });
                    }
                }, {
                    key: "nodeValue",
                    get: function() {
                        return this._value;
                    },
                    set: function(e) {
                        this.textContent = e;
                    }
                } ]), n;
            }(ke);
            Ee = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroNodeImpl)), _(1, Object(w["c"])(S.TaroElementFactory)), _(2, Object(w["c"])(S.Hooks)), T("design:paramtypes", [ Function, Function, Function ]) ], Ee);
            var _e = [ "all", "appearance", "blockOverflow", "blockSize", "bottom", "clear", "contain", "content", "continue", "cursor", "direction", "display", "filter", "float", "gap", "height", "inset", "isolation", "left", "letterSpacing", "lightingColor", "markerSide", "mixBlendMode", "opacity", "order", "position", "quotes", "resize", "right", "rowGap", "tabSize", "tableLayout", "top", "userSelect", "verticalAlign", "visibility", "voiceFamily", "volume", "whiteSpace", "widows", "width", "zIndex", "pointerEvents" ];
            function Te(e, t, n) {
                !n && _e.push(e), t.forEach(function(t) {
                    _e.push(e + t);
                });
            }
            var Se = "Color", Ce = "Style", Pe = "Width", xe = "Image", Ae = "Size", Ie = [ Se, Ce, Pe ], Ne = [ "FitLength", "FitWidth", xe ], Le = [].concat(Ne, [ "Radius" ]), Re = [].concat(Ie, Ne), Be = [ "EndRadius", "StartRadius" ], Fe = [ "Bottom", "Left", "Right", "Top" ], De = [ "End", "Start" ], Me = [ "Content", "Items", "Self" ], Ue = [ "BlockSize", "Height", "InlineSize", Pe ], $e = [ "After", "Before" ];
            function qe(e, t) {
                var n = this[t];
                e && this._usedStyleProp.add(t), n !== e && (this._value[t] = e, this._element.enqueueUpdate({
                    path: "".concat(this._element._path, ".", "st"),
                    value: this.cssText
                }));
            }
            function He(e) {
                for (var t = {}, n = function(e) {
                    var n = _e[e];
                    t[n] = {
                        get: function() {
                            return this._value[n] || "";
                        },
                        set: function(e) {
                            qe.call(this, e, n);
                        }
                    };
                }, r = 0; r < _e.length; r++) n(r);
                Object.defineProperties(e.prototype, t);
            }
            function ze(e) {
                return /^--/.test(e);
            }
            Te("borderBlock", Ie), Te("borderBlockEnd", Ie), Te("borderBlockStart", Ie), Te("outline", [].concat(Ie, [ "Offset" ])), 
            Te("border", [].concat(Ie, [ "Boundary", "Break", "Collapse", "Radius", "Spacing" ])), 
            Te("borderFit", [ "Length", Pe ]), Te("borderInline", Ie), Te("borderInlineEnd", Ie), 
            Te("borderInlineStart", Ie), Te("borderLeft", Re), Te("borderRight", Re), Te("borderTop", Re), 
            Te("borderBottom", Re), Te("textDecoration", [ Se, Ce, "Line" ]), Te("textEmphasis", [ Se, Ce, "Position" ]), 
            Te("scrollMargin", Fe), Te("scrollPadding", Fe), Te("padding", Fe), Te("margin", [].concat(Fe, [ "Trim" ])), 
            Te("scrollMarginBlock", De), Te("scrollMarginInline", De), Te("scrollPaddingBlock", De), 
            Te("scrollPaddingInline", De), Te("gridColumn", De), Te("gridRow", De), Te("insetBlock", De), 
            Te("insetInline", De), Te("marginBlock", De), Te("marginInline", De), Te("paddingBlock", De), 
            Te("paddingInline", De), Te("pause", $e), Te("cue", $e), Te("mask", [ "Clip", "Composite", xe, "Mode", "Origin", "Position", "Repeat", Ae, "Type" ]), 
            Te("borderImage", [ "Outset", "Repeat", "Slice", "Source", "Transform", Pe ]), Te("maskBorder", [ "Mode", "Outset", "Repeat", "Slice", "Source", Pe ]), 
            Te("font", [ "Family", "FeatureSettings", "Kerning", "LanguageOverride", "MaxSize", "MinSize", "OpticalSizing", "Palette", Ae, "SizeAdjust", "Stretch", Ce, "Weight", "VariationSettings" ]), 
            Te("fontSynthesis", [ "SmallCaps", Ce, "Weight" ]), Te("transform", [ "Box", "Origin", Ce ]), 
            Te("background", [ Se, xe, "Attachment", "BlendMode", "Clip", "Origin", "Position", "Repeat", Ae ]), 
            Te("listStyle", [ xe, "Position", "Type" ]), Te("scrollSnap", [ "Align", "Stop", "Type" ]), 
            Te("grid", [ "Area", "AutoColumns", "AutoFlow", "AutoRows" ]), Te("gridTemplate", [ "Areas", "Columns", "Rows" ]), 
            Te("overflow", [ "Block", "Inline", "Wrap", "X", "Y" ]), Te("transition", [ "Delay", "Duration", "Property", "TimingFunction" ]), 
            Te("lineStacking", [ "Ruby", "Shift", "Strategy" ]), Te("color", [ "Adjust", "InterpolationFilters", "Scheme" ]), 
            Te("textAlign", [ "All", "Last" ]), Te("page", [ "BreakAfter", "BreakBefore", "BreakInside" ]), 
            Te("speak", [ "Header", "Numeral", "Punctuation" ]), Te("animation", [ "Delay", "Direction", "Duration", "FillMode", "IterationCount", "Name", "PlayState", "TimingFunction" ]), 
            Te("flex", [ "Basis", "Direction", "Flow", "Grow", "Shrink", "Wrap" ]), Te("offset", [].concat($e, De, [ "Anchor", "Distance", "Path", "Position", "Rotate" ])), 
            Te("fontVariant", [ "Alternates", "Caps", "EastAsian", "Emoji", "Ligatures", "Numeric", "Position" ]), 
            Te("perspective", [ "Origin" ]), Te("pitch", [ "Range" ]), Te("clip", [ "Path", "Rule" ]), 
            Te("flow", [ "From", "Into" ]), Te("align", [ "Content", "Items", "Self" ], !0), 
            Te("alignment", [ "Adjust", "Baseline" ], !0), Te("bookmark", [ "Label", "Level", "State" ], !0), 
            Te("borderStart", Be, !0), Te("borderEnd", Be, !0), Te("borderCorner", [ "Fit", xe, "ImageTransform" ], !0), 
            Te("borderTopLeft", Le, !0), Te("borderTopRight", Le, !0), Te("borderBottomLeft", Le, !0), 
            Te("borderBottomRight", Le, !0), Te("column", [ "s", "Count", "Fill", "Gap", "Rule", "RuleColor", "RuleStyle", "RuleWidth", "Span", Pe ], !0), 
            Te("break", [].concat($e, [ "Inside" ]), !0), Te("wrap", [].concat($e, [ "Flow", "Inside", "Through" ]), !0), 
            Te("justify", Me, !0), Te("place", Me, !0), Te("max", [].concat(Ue, [ "Lines" ]), !0), 
            Te("min", Ue, !0), Te("line", [ "Break", "Clamp", "Grid", "Height", "Padding", "Snap" ], !0), 
            Te("inline", [ "BoxAlign", Ae, "Sizing" ], !0), Te("text", [ "CombineUpright", "GroupAlign", "Height", "Indent", "Justify", "Orientation", "Overflow", "Shadow", "SpaceCollapse", "SpaceTrim", "Spacing", "Transform", "UnderlinePosition", "Wrap" ], !0), 
            Te("shape", [ "ImageThreshold", "Inside", "Margin", "Outside" ], !0), Te("word", [ "Break", "Spacing", "Wrap" ], !0), 
            Te("nav", [ "Down", "Left", "Right", "Up" ], !0), Te("object", [ "Fit", "Position" ], !0), 
            Te("box", [ "DecorationBreak", "Shadow", "Sizing", "Snap" ], !0);
            var We = function() {
                function e(t) {
                    Object(y["a"])(this, e), this._element = t, this._usedStyleProp = new Set(), this._value = {};
                }
                return Object(O["a"])(e, [ {
                    key: "setCssVariables",
                    value: function(e) {
                        var t = this;
                        this.hasOwnProperty(e) || Object.defineProperty(this, e, {
                            enumerable: !0,
                            configurable: !0,
                            get: function() {
                                return t._value[e] || "";
                            },
                            set: function(n) {
                                qe.call(t, n, e);
                            }
                        });
                    }
                }, {
                    key: "cssText",
                    get: function() {
                        var e = this, t = "";
                        return this._usedStyleProp.forEach(function(n) {
                            var r = e[n];
                            if (r) {
                                var i = ze(n) ? n : Object(k["u"])(n);
                                t += "".concat(i, ": ").concat(r, ";");
                            }
                        }), t;
                    },
                    set: function(e) {
                        var t = this;
                        if (null == e && (e = ""), this._usedStyleProp.forEach(function(e) {
                            t.removeProperty(e);
                        }), "" !== e) for (var n = e.split(";"), r = 0; r < n.length; r++) {
                            var i = n[r].trim();
                            if ("" !== i) {
                                var o = i.split(":"), a = Object(p["a"])(o), c = a[0], u = a.slice(1), s = u.join(":");
                                Object(k["n"])(s) || this.setProperty(c.trim(), s.trim());
                            }
                        }
                    }
                }, {
                    key: "setProperty",
                    value: function(e, t) {
                        "-" === e[0] ? this.setCssVariables(e) : e = Object(k["t"])(e), Object(k["n"])(t) || (null === t || "" === t ? this.removeProperty(e) : this[e] = t);
                    }
                }, {
                    key: "removeProperty",
                    value: function(e) {
                        if (e = Object(k["t"])(e), !this._usedStyleProp.has(e)) return "";
                        var t = this[e];
                        return this[e] = "", this._usedStyleProp.delete(e), t;
                    }
                }, {
                    key: "getPropertyValue",
                    value: function(e) {
                        e = Object(k["t"])(e);
                        var t = this[e];
                        return t || "";
                    }
                } ]), e;
            }();
            function Ve() {
                return !0;
            }
            function Ge(e, t) {
                var n = [], r = null !== t && void 0 !== t ? t : Ve, i = e;
                while (i) 1 === i.nodeType && r(i) && n.push(i), i = Ke(i, e);
                return n;
            }
            function Ke(e, t) {
                var n = e.firstChild;
                if (n) return n;
                var r = e;
                do {
                    if (r === t) return null;
                    var i = r.nextSibling;
                    if (i) return i;
                    r = r.parentElement;
                } while (r);
                return null;
            }
            He(We);
            var Je = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r) {
                    var i, o;
                    return Object(y["a"])(this, n), o = t.call(this), e.trim().split(/\s+/).forEach(Object(d["a"])((i = Object(v["a"])(o), 
                    Object(f["a"])(n.prototype)), "add", i).bind(Object(v["a"])(o))), o.el = r, o;
                }
                return Object(O["a"])(n, [ {
                    key: "value",
                    get: function() {
                        return Object(l["a"])(this).join(" ");
                    }
                }, {
                    key: "add",
                    value: function(e) {
                        return Object(d["a"])(Object(f["a"])(n.prototype), "add", this).call(this, e), this._update(), 
                        this;
                    }
                }, {
                    key: "length",
                    get: function() {
                        return this.size;
                    }
                }, {
                    key: "remove",
                    value: function(e) {
                        Object(d["a"])(Object(f["a"])(n.prototype), "delete", this).call(this, e), this._update();
                    }
                }, {
                    key: "toggle",
                    value: function(e) {
                        Object(d["a"])(Object(f["a"])(n.prototype), "has", this).call(this, e) ? Object(d["a"])(Object(f["a"])(n.prototype), "delete", this).call(this, e) : Object(d["a"])(Object(f["a"])(n.prototype), "add", this).call(this, e), 
                        this._update();
                    }
                }, {
                    key: "replace",
                    value: function(e, t) {
                        Object(d["a"])(Object(f["a"])(n.prototype), "delete", this).call(this, e), Object(d["a"])(Object(f["a"])(n.prototype), "add", this).call(this, t), 
                        this._update();
                    }
                }, {
                    key: "contains",
                    value: function(e) {
                        return Object(d["a"])(Object(f["a"])(n.prototype), "has", this).call(this, e);
                    }
                }, {
                    key: "toString",
                    value: function() {
                        return this.value;
                    }
                }, {
                    key: "_update",
                    value: function() {
                        this.el.className = this.value;
                    }
                } ]), n;
            }(Object(h["a"])(Set)), Ye = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r, i, o) {
                    var a;
                    return Object(y["a"])(this, n), a = t.call(this, e, r, i), a.props = {}, a.dataset = k["b"], 
                    o.bind(Object(v["a"])(a)), a.nodeType = 1, a.style = new We(Object(v["a"])(a)), 
                    i.patchElement(Object(v["a"])(a)), a;
                }
                return Object(O["a"])(n, [ {
                    key: "_stopPropagation",
                    value: function(e) {
                        var t = this;
                        while (t = t.parentNode) {
                            var n = t.__handlers[e.type];
                            if (Object(k["h"])(n)) for (var r = n.length; r--; ) {
                                var i = n[r];
                                i._stop = !0;
                            }
                        }
                    }
                }, {
                    key: "id",
                    get: function() {
                        return this.getAttribute(M);
                    },
                    set: function(e) {
                        this.setAttribute(M, e);
                    }
                }, {
                    key: "className",
                    get: function() {
                        return this.getAttribute($) || "";
                    },
                    set: function(e) {
                        this.setAttribute($, e);
                    }
                }, {
                    key: "cssText",
                    get: function() {
                        return this.getAttribute(q) || "";
                    }
                }, {
                    key: "classList",
                    get: function() {
                        return new Je(this.className, this);
                    }
                }, {
                    key: "children",
                    get: function() {
                        return this.childNodes.filter(fe);
                    }
                }, {
                    key: "attributes",
                    get: function() {
                        var e = this.props, t = Object.keys(e), n = this.style.cssText, r = t.map(function(t) {
                            return {
                                name: t,
                                value: e[t]
                            };
                        });
                        return r.concat(n ? {
                            name: q,
                            value: n
                        } : []);
                    }
                }, {
                    key: "textContent",
                    get: function() {
                        for (var e = "", t = this.childNodes, n = 0; n < t.length; n++) e += t[n].textContent;
                        return e;
                    },
                    set: function(e) {
                        Object(s["a"])(Object(f["a"])(n.prototype), "textContent", e, this, !0);
                    }
                }, {
                    key: "hasAttribute",
                    value: function(e) {
                        return !Object(k["n"])(this.props[e]);
                    }
                }, {
                    key: "hasAttributes",
                    value: function() {
                        return this.attributes.length > 0;
                    }
                }, {
                    key: "focus",
                    get: function() {
                        return function() {
                            this.setAttribute(H, !0);
                        };
                    },
                    set: function(e) {
                        this.setAttribute(H, e);
                    }
                }, {
                    key: "blur",
                    value: function() {
                        this.setAttribute(H, !1);
                    }
                }, {
                    key: "setAttribute",
                    value: function(e, t) {
                        var n, r, i = this.nodeName === z && !ve(this) && !this.isAnyEventBinded();
                        switch (e) {
                          case q:
                            this.style.cssText = t;
                            break;

                          case M:
                            je.delete(this.uid), t = String(t), this.props[e] = this.uid = t, je.set(t, this);
                            break;

                          default:
                            this.props[e] = t, e.startsWith("data-") && (this.dataset === k["b"] && (this.dataset = Object.create(null)), 
                            this.dataset[Object(k["t"])(e.replace(/^data-/, ""))] = t);
                            break;
                        }
                        e = me(e);
                        var o = {
                            path: "".concat(this._path, ".").concat(Object(k["t"])(e)),
                            value: t
                        };
                        null === (r = (n = this.hooks).modifySetAttrPayload) || void 0 === r || r.call(n, this, e, o), 
                        this.enqueueUpdate(o), this.nodeName === z && (Object(k["t"])(e) === ue ? this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: t ? se : this.isAnyEventBinded() ? z : W
                        }) : i && ve(this) && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: W
                        }));
                    }
                }, {
                    key: "removeAttribute",
                    value: function(e) {
                        var t, n, r, i, o = this.nodeName === z && ve(this) && !this.isAnyEventBinded();
                        if (e === q) this.style.cssText = ""; else {
                            var a = null === (n = (t = this.hooks).onRemoveAttribute) || void 0 === n ? void 0 : n.call(t, this, e);
                            if (a) return;
                            if (!this.props.hasOwnProperty(e)) return;
                            delete this.props[e];
                        }
                        e = me(e);
                        var c = {
                            path: "".concat(this._path, ".").concat(Object(k["t"])(e)),
                            value: ""
                        };
                        null === (i = (r = this.hooks).modifyRmAttrPayload) || void 0 === i || i.call(r, this, e, c), 
                        this.enqueueUpdate(c), this.nodeName === z && (Object(k["t"])(e) === ue ? this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: this.isAnyEventBinded() ? z : ve(this) ? W : V
                        }) : o && !ve(this) && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: V
                        }));
                    }
                }, {
                    key: "getAttribute",
                    value: function(e) {
                        var t = e === q ? this.style.cssText : this.props[e];
                        return null !== t && void 0 !== t ? t : "";
                    }
                }, {
                    key: "getElementsByTagName",
                    value: function(e) {
                        var t = this;
                        return Ge(this, function(n) {
                            return n.nodeName === e || "*" === e && t !== n;
                        });
                    }
                }, {
                    key: "getElementsByClassName",
                    value: function(e) {
                        return Ge(this, function(t) {
                            var n = t.classList, r = e.trim().split(/\s+/);
                            return r.every(function(e) {
                                return n.has(e);
                            });
                        });
                    }
                }, {
                    key: "dispatchEvent",
                    value: function(e) {
                        var t = e.cancelable, n = this.__handlers[e.type];
                        if (!Object(k["h"])(n)) return !1;
                        for (var r = n.length; r--; ) {
                            var i = n[r], o = void 0;
                            if (i._stop ? i._stop = !1 : o = i.call(this, e), (!1 === o || e._end) && t && (e.defaultPrevented = !0), 
                            e._end && e._stop) break;
                        }
                        return e._stop ? this._stopPropagation(e) : e._stop = !0, null != n;
                    }
                }, {
                    key: "addEventListener",
                    value: function(e, t, r) {
                        var i = this.nodeName, o = this.hooks.getSpecialNodes();
                        !this.isAnyEventBinded() && o.indexOf(i) > -1 && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: i
                        }), Object(d["a"])(Object(f["a"])(n.prototype), "addEventListener", this).call(this, e, t, r);
                    }
                }, {
                    key: "removeEventListener",
                    value: function(e, t) {
                        Object(d["a"])(Object(f["a"])(n.prototype), "removeEventListener", this).call(this, e, t);
                        var r = this.nodeName, i = this.hooks.getSpecialNodes();
                        !this.isAnyEventBinded() && i.indexOf(r) > -1 && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: ve(this) ? "static-".concat(r) : "pure-".concat(r)
                        });
                    }
                } ]), n;
            }(ke);
            Ye = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroNodeImpl)), _(1, Object(w["c"])(S.TaroElementFactory)), _(2, Object(w["c"])(S.Hooks)), _(3, Object(w["c"])(S.TaroElementImpl)), T("design:paramtypes", [ Function, Function, Function, Function ]) ], Ye);
            var Qe = Array.isArray, Ze = "object" == ("undefined" === typeof r ? "undefined" : Object(j["a"])(r)) && r && r.Object === Object && r, Xe = "object" == ("undefined" === typeof self ? "undefined" : Object(j["a"])(self)) && self && self.Object === Object && self, et = Ze || Xe || Function("return this")(), tt = et.Symbol, nt = Object.prototype, rt = nt.hasOwnProperty, it = nt.toString, ot = tt ? tt.toStringTag : void 0;
            function at(e) {
                var t = rt.call(e, ot), n = e[ot];
                try {
                    e[ot] = void 0;
                    var r = !0;
                } catch (e) {}
                var i = it.call(e);
                return r && (t ? e[ot] = n : delete e[ot]), i;
            }
            var ct = Object.prototype, ut = ct.toString;
            function st(e) {
                return ut.call(e);
            }
            var lt = "[object Null]", dt = "[object Undefined]", ft = tt ? tt.toStringTag : void 0;
            function ht(e) {
                return null == e ? void 0 === e ? dt : lt : ft && ft in Object(e) ? at(e) : st(e);
            }
            function pt(e) {
                return null != e && "object" == Object(j["a"])(e);
            }
            var vt = "[object Symbol]";
            function bt(e) {
                return "symbol" == Object(j["a"])(e) || pt(e) && ht(e) == vt;
            }
            var mt = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, gt = /^\w*$/;
            function yt(e, t) {
                if (Qe(e)) return !1;
                var n = Object(j["a"])(e);
                return !("number" != n && "symbol" != n && "boolean" != n && null != e && !bt(e)) || (gt.test(e) || !mt.test(e) || null != t && e in Object(t));
            }
            function Ot(e) {
                var t = Object(j["a"])(e);
                return null != e && ("object" == t || "function" == t);
            }
            var jt = "[object AsyncFunction]", wt = "[object Function]", kt = "[object GeneratorFunction]", Et = "[object Proxy]";
            function _t(e) {
                if (!Ot(e)) return !1;
                var t = ht(e);
                return t == wt || t == kt || t == jt || t == Et;
            }
            var Tt = et["__core-js_shared__"], St = function() {
                var e = /[^.]+$/.exec(Tt && Tt.keys && Tt.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : "";
            }();
            function Ct(e) {
                return !!St && St in e;
            }
            var Pt = Function.prototype, xt = Pt.toString;
            function At(e) {
                if (null != e) {
                    try {
                        return xt.call(e);
                    } catch (e) {}
                    try {
                        return e + "";
                    } catch (e) {}
                }
                return "";
            }
            var It = /[\\^$.*+?()[\]{}|]/g, Nt = /^\[object .+?Constructor\]$/, Lt = Function.prototype, Rt = Object.prototype, Bt = Lt.toString, Ft = Rt.hasOwnProperty, Dt = RegExp("^" + Bt.call(Ft).replace(It, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
            function Mt(e) {
                if (!Ot(e) || Ct(e)) return !1;
                var t = _t(e) ? Dt : Nt;
                return t.test(At(e));
            }
            function Ut(e, t) {
                return null == e ? void 0 : e[t];
            }
            function $t(e, t) {
                var n = Ut(e, t);
                return Mt(n) ? n : void 0;
            }
            var qt = $t(Object, "create");
            function Ht() {
                this.__data__ = qt ? qt(null) : {}, this.size = 0;
            }
            function zt(e) {
                var t = this.has(e) && delete this.__data__[e];
                return this.size -= t ? 1 : 0, t;
            }
            var Wt = "__lodash_hash_undefined__", Vt = Object.prototype, Gt = Vt.hasOwnProperty;
            function Kt(e) {
                var t = this.__data__;
                if (qt) {
                    var n = t[e];
                    return n === Wt ? void 0 : n;
                }
                return Gt.call(t, e) ? t[e] : void 0;
            }
            var Jt = Object.prototype, Yt = Jt.hasOwnProperty;
            function Qt(e) {
                var t = this.__data__;
                return qt ? void 0 !== t[e] : Yt.call(t, e);
            }
            var Zt = "__lodash_hash_undefined__";
            function Xt(e, t) {
                var n = this.__data__;
                return this.size += this.has(e) ? 0 : 1, n[e] = qt && void 0 === t ? Zt : t, this;
            }
            function en(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            function tn() {
                this.__data__ = [], this.size = 0;
            }
            function nn(e, t) {
                return e === t || e !== e && t !== t;
            }
            function rn(e, t) {
                var n = e.length;
                while (n--) if (nn(e[n][0], t)) return n;
                return -1;
            }
            en.prototype.clear = Ht, en.prototype["delete"] = zt, en.prototype.get = Kt, en.prototype.has = Qt, 
            en.prototype.set = Xt;
            var on = Array.prototype, an = on.splice;
            function cn(e) {
                var t = this.__data__, n = rn(t, e);
                if (n < 0) return !1;
                var r = t.length - 1;
                return n == r ? t.pop() : an.call(t, n, 1), --this.size, !0;
            }
            function un(e) {
                var t = this.__data__, n = rn(t, e);
                return n < 0 ? void 0 : t[n][1];
            }
            function sn(e) {
                return rn(this.__data__, e) > -1;
            }
            function ln(e, t) {
                var n = this.__data__, r = rn(n, e);
                return r < 0 ? (++this.size, n.push([ e, t ])) : n[r][1] = t, this;
            }
            function dn(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            dn.prototype.clear = tn, dn.prototype["delete"] = cn, dn.prototype.get = un, dn.prototype.has = sn, 
            dn.prototype.set = ln;
            var fn = $t(et, "Map");
            function hn() {
                this.size = 0, this.__data__ = {
                    hash: new en(),
                    map: new (fn || dn)(),
                    string: new en()
                };
            }
            function pn(e) {
                var t = Object(j["a"])(e);
                return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e;
            }
            function vn(e, t) {
                var n = e.__data__;
                return pn(t) ? n["string" == typeof t ? "string" : "hash"] : n.map;
            }
            function bn(e) {
                var t = vn(this, e)["delete"](e);
                return this.size -= t ? 1 : 0, t;
            }
            function mn(e) {
                return vn(this, e).get(e);
            }
            function gn(e) {
                return vn(this, e).has(e);
            }
            function yn(e, t) {
                var n = vn(this, e), r = n.size;
                return n.set(e, t), this.size += n.size == r ? 0 : 1, this;
            }
            function On(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            On.prototype.clear = hn, On.prototype["delete"] = bn, On.prototype.get = mn, On.prototype.has = gn, 
            On.prototype.set = yn;
            var jn = "Expected a function";
            function wn(e, t) {
                if ("function" != typeof e || null != t && "function" != typeof t) throw new TypeError(jn);
                var n = function n() {
                    var r = arguments, i = t ? t.apply(this, r) : r[0], o = n.cache;
                    if (o.has(i)) return o.get(i);
                    var a = e.apply(this, r);
                    return n.cache = o.set(i, a) || o, a;
                };
                return n.cache = new (wn.Cache || On)(), n;
            }
            wn.Cache = On;
            var kn = 500;
            function En(e) {
                var t = wn(e, function(e) {
                    return n.size === kn && n.clear(), e;
                }), n = t.cache;
                return t;
            }
            var _n = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, Tn = /\\(\\)?/g, Sn = En(function(e) {
                var t = [];
                return 46 === e.charCodeAt(0) && t.push(""), e.replace(_n, function(e, n, r, i) {
                    t.push(r ? i.replace(Tn, "$1") : n || e);
                }), t;
            });
            function Cn(e, t) {
                var n = -1, r = null == e ? 0 : e.length, i = Array(r);
                while (++n < r) i[n] = t(e[n], n, e);
                return i;
            }
            var Pn = 1 / 0, xn = tt ? tt.prototype : void 0, An = xn ? xn.toString : void 0;
            function In(e) {
                if ("string" == typeof e) return e;
                if (Qe(e)) return Cn(e, In) + "";
                if (bt(e)) return An ? An.call(e) : "";
                var t = e + "";
                return "0" == t && 1 / e == -Pn ? "-0" : t;
            }
            function Nn(e) {
                return null == e ? "" : In(e);
            }
            function Ln(e, t) {
                return Qe(e) ? e : yt(e, t) ? [ e ] : Sn(Nn(e));
            }
            var Rn = 1 / 0;
            function Bn(e) {
                if ("string" == typeof e || bt(e)) return e;
                var t = e + "";
                return "0" == t && 1 / e == -Rn ? "-0" : t;
            }
            function Fn(e, t) {
                t = Ln(t, e);
                var n = 0, r = t.length;
                while (null != e && n < r) e = e[Bn(t[n++])];
                return n && n == r ? e : void 0;
            }
            function Dn(e, t, n) {
                var r = null == e ? void 0 : Fn(e, t);
                return void 0 === r ? n : r;
            }
            var Mn = {
                prerender: !0,
                debug: !1
            }, Un = function() {
                function e() {
                    Object(y["a"])(this, e), this.recorder = new Map();
                }
                return Object(O["a"])(e, [ {
                    key: "start",
                    value: function(e) {
                        Mn.debug && this.recorder.set(e, Date.now());
                    }
                }, {
                    key: "stop",
                    value: function(e) {
                        if (Mn.debug) {
                            var t = Date.now(), n = this.recorder.get(e), r = t - n;
                            console.log("".concat(e, " 时长： ").concat(r, "ms"));
                        }
                    }
                } ]), e;
            }(), $n = new Un(), qn = de(), Hn = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r, i, o, a) {
                    var c;
                    return Object(y["a"])(this, n), c = t.call(this, e, r, i, o), c.pendingFlush = !1, 
                    c.updatePayloads = [], c.updateCallbacks = [], c.pendingUpdate = !1, c.ctx = null, 
                    c.nodeName = A, c.eventCenter = a, c;
                }
                return Object(O["a"])(n, [ {
                    key: "_path",
                    get: function() {
                        return A;
                    }
                }, {
                    key: "_root",
                    get: function() {
                        return this;
                    }
                }, {
                    key: "enqueueUpdate",
                    value: function(e) {
                        this.updatePayloads.push(e), this.pendingUpdate || null === this.ctx || this.performUpdate();
                    }
                }, {
                    key: "performUpdate",
                    value: function() {
                        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = arguments.length > 1 ? arguments[1] : void 0;
                        this.pendingUpdate = !0;
                        var r = this.ctx;
                        setTimeout(function() {
                            $n.start(P);
                            var i = Object.create(null), o = new Set(t ? [ "root.cn.[0]", "root.cn[0]" ] : []);
                            while (e.updatePayloads.length > 0) {
                                var a = e.updatePayloads.shift(), c = a.path, u = a.value;
                                c.endsWith("cn") && o.add(c), i[c] = u;
                            }
                            var s = function(e) {
                                o.forEach(function(t) {
                                    e.includes(t) && e !== t && delete i[e];
                                });
                                var t = i[e];
                                Object(k["j"])(t) && (i[e] = t());
                            };
                            for (var l in i) s(l);
                            if (Object(k["j"])(n)) n(i); else {
                                e.pendingUpdate = !1;
                                var d = [], f = new Map(), h = {};
                                if (!t) {
                                    for (var p in i) {
                                        for (var v = p.split("."), b = !1, m = v.length; m > 0; m--) {
                                            var y = v.slice(0, m).join("."), O = Dn(r.__data__ || r.data, y);
                                            if (O && O.nn && O.nn === X) {
                                                var j = O.uid, w = r.selectComponent("#".concat(j)), E = v.slice(m).join(".");
                                                w && (b = !0, f.set(w, Object.assign(Object.assign({}, f.get(w) || {}), Object(g["a"])({}, "i.".concat(E), i[p]))));
                                                break;
                                            }
                                        }
                                        b || (h[p] = i[p]);
                                    }
                                    f.size > 0 && f.forEach(function(e, t) {
                                        d.push({
                                            ctx: t,
                                            data: e
                                        });
                                    });
                                }
                                var _ = d.length;
                                if (_) {
                                    var T = "".concat(e._path, "_update_").concat(qn()), S = e.eventCenter, C = 0;
                                    S.once(T, function() {
                                        C++, C === _ + 1 && ($n.stop(P), e.pendingFlush || e.flushUpdateCallback(), t && $n.stop(x));
                                    }, S), d.forEach(function(e) {
                                        e.ctx.setData(e.data, function() {
                                            S.trigger(T);
                                        });
                                    }), Object.keys(h).length && r.setData(h, function() {
                                        S.trigger(T);
                                    });
                                } else r.setData(i, function() {
                                    $n.stop(P), e.pendingFlush || e.flushUpdateCallback(), t && $n.stop(x);
                                });
                            }
                        }, 0);
                    }
                }, {
                    key: "enqueueUpdateCallback",
                    value: function(e, t) {
                        this.updateCallbacks.push(function() {
                            t ? e.call(t) : e();
                        });
                    }
                }, {
                    key: "flushUpdateCallback",
                    value: function() {
                        this.pendingFlush = !1;
                        var e = this.updateCallbacks.slice(0);
                        this.updateCallbacks.length = 0;
                        for (var t = 0; t < e.length; t++) e[t]();
                    }
                } ]), n;
            }(Ye);
            Hn = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroNodeImpl)), _(1, Object(w["c"])(S.TaroElementFactory)), _(2, Object(w["c"])(S.Hooks)), _(3, Object(w["c"])(S.TaroElementImpl)), _(4, Object(w["c"])(S.eventCenter)), T("design:paramtypes", [ Function, Function, Function, Function, Function ]) ], Hn);
            var zn = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n() {
                    return Object(y["a"])(this, n), t.apply(this, arguments);
                }
                return Object(O["a"])(n, [ {
                    key: "value",
                    get: function() {
                        var e = this.props[Y];
                        return null == e ? "" : e;
                    },
                    set: function(e) {
                        this.setAttribute(Y, e);
                    }
                }, {
                    key: "dispatchEvent",
                    value: function(e) {
                        if (e.mpEvent) {
                            var t = e.mpEvent.detail.value;
                            e.type === Z ? this.props.value = t : e.type === Q && (this.value = t);
                        }
                        return Object(d["a"])(Object(f["a"])(n.prototype), "dispatchEvent", this).call(this, e);
                    }
                } ]), n;
            }(Ye), Wn = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n() {
                    return Object(y["a"])(this, n), t.apply(this, arguments);
                }
                return Object(O["a"])(n);
            }(Ye);
            function Vn() {
                return {
                    index: 0,
                    column: 0,
                    line: 0
                };
            }
            function Gn(e, t, n) {
                for (var r = e.index, i = e.index = r + n, o = r; o < i; o++) {
                    var a = t.charAt(o);
                    "\n" === a ? (e.line++, e.column = 0) : e.column++;
                }
            }
            function Kn(e, t, n) {
                var r = n - e.index;
                return Gn(e, t, r);
            }
            function Jn(e) {
                return {
                    index: e.index,
                    line: e.line,
                    column: e.column
                };
            }
            var Yn = /\s/;
            function Qn(e) {
                return Yn.test(e);
            }
            var Zn = /=/;
            function Xn(e) {
                return Zn.test(e);
            }
            function er(e) {
                var t = e.toLowerCase();
                return !!Mn.html.skipElements.has(t);
            }
            var tr = /[A-Za-z0-9]/;
            function nr(e, t) {
                while (1) {
                    var n = e.indexOf("<", t);
                    if (-1 === n) return n;
                    var r = e.charAt(n + 1);
                    if ("/" === r || "!" === r || tr.test(r)) return n;
                    t = n + 1;
                }
            }
            function rr(e, t, n) {
                if (!Qn(n.charAt(e))) return !1;
                for (var r = n.length, i = e - 1; i > t; i--) {
                    var o = n.charAt(i);
                    if (!Qn(o)) {
                        if (Xn(o)) return !1;
                        break;
                    }
                }
                for (var a = e + 1; a < r; a++) {
                    var c = n.charAt(a);
                    if (!Qn(c)) return !Xn(c);
                }
            }
            var ir = function() {
                function e(t) {
                    Object(y["a"])(this, e), this.tokens = [], this.position = Vn(), this.html = t;
                }
                return Object(O["a"])(e, [ {
                    key: "scan",
                    value: function() {
                        var e = this.html, t = this.position, n = e.length;
                        while (t.index < n) {
                            var r = t.index;
                            if (this.scanText(), t.index === r) {
                                var i = e.startsWith("!--", r + 1);
                                if (i) this.scanComment(); else {
                                    var o = this.scanTag();
                                    er(o) && this.scanSkipTag(o);
                                }
                            }
                        }
                        return this.tokens;
                    }
                }, {
                    key: "scanText",
                    value: function() {
                        var e = "text", t = this.html, n = this.position, r = nr(t, n.index);
                        if (r !== n.index) {
                            -1 === r && (r = t.length);
                            var i = Jn(n), o = t.slice(n.index, r);
                            Kn(n, t, r);
                            var a = Jn(n);
                            this.tokens.push({
                                type: e,
                                content: o,
                                position: {
                                    start: i,
                                    end: a
                                }
                            });
                        }
                    }
                }, {
                    key: "scanComment",
                    value: function() {
                        var e = "comment", t = this.html, n = this.position, r = Jn(n);
                        Gn(n, t, 4);
                        var i = t.indexOf("--\x3e", n.index), o = i + 3;
                        -1 === i && (i = o = t.length);
                        var a = t.slice(n.index, i);
                        Kn(n, t, o), this.tokens.push({
                            type: e,
                            content: a,
                            position: {
                                start: r,
                                end: Jn(n)
                            }
                        });
                    }
                }, {
                    key: "scanTag",
                    value: function() {
                        this.scanTagStart();
                        var e = this.scanTagName();
                        return this.scanAttrs(), this.scanTagEnd(), e;
                    }
                }, {
                    key: "scanTagStart",
                    value: function() {
                        var e = "tag-start", t = this.html, n = this.position, r = t.charAt(n.index + 1), i = "/" === r, o = Jn(n);
                        Gn(n, t, i ? 2 : 1), this.tokens.push({
                            type: e,
                            close: i,
                            position: {
                                start: o
                            }
                        });
                    }
                }, {
                    key: "scanTagEnd",
                    value: function() {
                        var e = "tag-end", t = this.html, n = this.position, r = t.charAt(n.index), i = "/" === r;
                        Gn(n, t, i ? 2 : 1);
                        var o = Jn(n);
                        this.tokens.push({
                            type: e,
                            close: i,
                            position: {
                                end: o
                            }
                        });
                    }
                }, {
                    key: "scanTagName",
                    value: function() {
                        var e = "tag", t = this.html, n = this.position, r = t.length, i = n.index;
                        while (i < r) {
                            var o = t.charAt(i), a = !(Qn(o) || "/" === o || ">" === o);
                            if (a) break;
                            i++;
                        }
                        var c = i + 1;
                        while (c < r) {
                            var u = t.charAt(c), s = !(Qn(u) || "/" === u || ">" === u);
                            if (!s) break;
                            c++;
                        }
                        Kn(n, t, c);
                        var l = t.slice(i, c);
                        return this.tokens.push({
                            type: e,
                            content: l
                        }), l;
                    }
                }, {
                    key: "scanAttrs",
                    value: function() {
                        var e = this.html, t = this.position, n = this.tokens, r = t.index, i = null, o = r, a = [], c = e.length;
                        while (r < c) {
                            var u = e.charAt(r);
                            if (i) {
                                var s = u === i;
                                s && (i = null), r++;
                            } else {
                                var l = "/" === u || ">" === u;
                                if (l) {
                                    r !== o && a.push(e.slice(o, r));
                                    break;
                                }
                                if (rr(r, o, e)) r !== o && a.push(e.slice(o, r)), o = r + 1, r++; else {
                                    var d = "'" === u || '"' === u;
                                    d ? (i = u, r++) : r++;
                                }
                            }
                        }
                        Kn(t, e, r);
                        for (var f = a.length, h = "attribute", p = 0; p < f; p++) {
                            var v = a[p], b = v.includes("=");
                            if (b) {
                                var m = a[p + 1];
                                if (m && m.startsWith("=")) {
                                    if (m.length > 1) {
                                        var g = v + m;
                                        n.push({
                                            type: h,
                                            content: g
                                        }), p += 1;
                                        continue;
                                    }
                                    var y = a[p + 2];
                                    if (p += 1, y) {
                                        var O = v + "=" + y;
                                        n.push({
                                            type: h,
                                            content: O
                                        }), p += 1;
                                        continue;
                                    }
                                }
                            }
                            if (v.endsWith("=")) {
                                var j = a[p + 1];
                                if (j && !j.includes("=")) {
                                    var w = v + j;
                                    n.push({
                                        type: h,
                                        content: w
                                    }), p += 1;
                                    continue;
                                }
                                var k = v.slice(0, -1);
                                n.push({
                                    type: h,
                                    content: k
                                });
                            } else n.push({
                                type: h,
                                content: v
                            });
                        }
                    }
                }, {
                    key: "scanSkipTag",
                    value: function(e) {
                        var t = this.html, n = this.position, r = e.toLowerCase(), i = t.length;
                        while (n.index < i) {
                            var o = t.indexOf("</", n.index);
                            if (-1 === o) {
                                this.scanText();
                                break;
                            }
                            Kn(n, t, o);
                            var a = this.scanTag();
                            if (r === a.toLowerCase()) break;
                        }
                    }
                } ]), e;
            }();
            function or(e, t) {
                for (var n = Object.create(null), r = e.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return t ? function(e) {
                    return !!n[e.toLowerCase()];
                } : function(e) {
                    return !!n[e];
                };
            }
            var ar = {
                img: "image",
                iframe: "web-view"
            }, cr = Object.keys(k["g"]).map(function(e) {
                return e.toLowerCase();
            }).join(","), ur = or(cr, !0), sr = or("a,i,abbr,iframe,select,acronym,slot,small,span,bdi,kbd,strong,big,map,sub,sup,br,mark,mark,meter,template,canvas,textarea,cite,object,time,code,output,u,data,picture,tt,datalist,var,dfn,del,q,em,s,embed,samp,b", !0), lr = or("address,fieldset,li,article,figcaption,main,aside,figure,nav,blockquote,footer,ol,details,form,p,dialog,h1,h2,h3,h4,h5,h6,pre,dd,header,section,div,hgroup,table,dl,hr,ul,dt", !0);
            function dr(e) {
                var t = e.charAt(0), n = e.length - 1, r = '"' === t || "'" === t;
                return r && t === e.charAt(n) ? e.slice(1, n) : e;
            }
            var fr = "{", hr = "}", pr = ".", vr = "#", br = ">", mr = "~", gr = "+", yr = function() {
                function e() {
                    Object(y["a"])(this, e), this.styles = [];
                }
                return Object(O["a"])(e, [ {
                    key: "extractStyle",
                    value: function(e) {
                        var t = this, n = /<style\s?[^>]*>((.|\n|\s)+?)<\/style>/g, r = e;
                        return r = r.replace(n, function(e, n) {
                            var r = n.trim();
                            return t.stringToSelector(r), "";
                        }), r.trim();
                    }
                }, {
                    key: "stringToSelector",
                    value: function(e) {
                        var t = this, n = e.indexOf(fr), r = function() {
                            var r = e.indexOf(hr), i = e.slice(0, n).trim(), o = e.slice(n + 1, r);
                            o = o.replace(/:(.*);/g, function(e, t) {
                                var n = t.trim().replace(/ +/g, "+++");
                                return ":".concat(n, ";");
                            }), o = o.replace(/ /g, ""), o = o.replace(/\+\+\+/g, " "), /;$/.test(o) || (o += ";"), 
                            i.split(",").forEach(function(e) {
                                var n = t.parseSelector(e);
                                t.styles.push({
                                    content: o,
                                    selectorList: n
                                });
                            }), e = e.slice(r + 1), n = e.indexOf(fr);
                        };
                        while (n > -1) r();
                    }
                }, {
                    key: "parseSelector",
                    value: function(e) {
                        var t = e.trim().replace(/ *([>~+]) */g, " $1").replace(/ +/g, " ").split(" "), n = t.map(function(e) {
                            var t = e.charAt(0), n = {
                                isChild: t === br,
                                isGeneralSibling: t === mr,
                                isAdjacentSibling: t === gr,
                                tag: null,
                                id: null,
                                class: [],
                                attrs: []
                            };
                            return e = e.replace(/^[>~+]/, ""), e = e.replace(/\[(.+?)\]/g, function(e, t) {
                                var r = t.split("="), i = Object(u["a"])(r, 2), o = i[0], a = i[1], c = -1 === t.indexOf("="), s = {
                                    all: c,
                                    key: o,
                                    value: c ? null : a
                                };
                                return n.attrs.push(s), "";
                            }), e = e.replace(/([.#][A-Za-z0-9-_]+)/g, function(e, t) {
                                return t[0] === vr ? n.id = t.substr(1) : t[0] === pr && n.class.push(t.substr(1)), 
                                "";
                            }), "" !== e && (n.tag = e), n;
                        });
                        return n;
                    }
                }, {
                    key: "matchStyle",
                    value: function(e, t, n) {
                        var r = this, i = jr(this.styles).reduce(function(i, o, a) {
                            var c = o.content, u = o.selectorList, s = n[a], l = u[s], d = u[s + 1];
                            ((null === d || void 0 === d ? void 0 : d.isGeneralSibling) || (null === d || void 0 === d ? void 0 : d.isAdjacentSibling)) && (l = d, 
                            s += 1, n[a] += 1);
                            var f = r.matchCurrent(e, t, l);
                            if (f && l.isGeneralSibling) {
                                var h = Or(t);
                                while (h) {
                                    if (h.h5tagName && r.matchCurrent(h.h5tagName, h, u[s - 1])) {
                                        f = !0;
                                        break;
                                    }
                                    h = Or(h), f = !1;
                                }
                            }
                            if (f && l.isAdjacentSibling) {
                                var p = Or(t);
                                if (p && p.h5tagName) {
                                    var v = r.matchCurrent(p.h5tagName, p, u[s - 1]);
                                    v || (f = !1);
                                } else f = !1;
                            }
                            if (f) {
                                if (s === u.length - 1) return i + c;
                                s < u.length - 1 && (n[a] += 1);
                            } else l.isChild && s > 0 && (n[a] -= 1, r.matchCurrent(e, t, u[n[a]]) && (n[a] += 1));
                            return i;
                        }, "");
                        return i;
                    }
                }, {
                    key: "matchCurrent",
                    value: function(e, t, n) {
                        if (n.tag && n.tag !== e) return !1;
                        if (n.id && n.id !== t.id) return !1;
                        if (n.class.length) for (var r = t.className.split(" "), i = 0; i < n.class.length; i++) {
                            var o = n.class[i];
                            if (-1 === r.indexOf(o)) return !1;
                        }
                        if (n.attrs.length) for (var a = 0; a < n.attrs.length; a++) {
                            var c = n.attrs[a], u = c.all, s = c.key, l = c.value;
                            if (u && !t.hasAttribute(s)) return !1;
                            var d = t.getAttribute(s);
                            if (d !== dr(l || "")) return !1;
                        }
                        return !0;
                    }
                } ]), e;
            }();
            function Or(e) {
                var t = e.parentElement;
                if (!t) return null;
                var n = e.previousSibling;
                return n ? 1 === n.nodeType ? n : Or(n) : null;
            }
            function jr(e) {
                return e.sort(function(e, t) {
                    var n = wr(e.selectorList), r = wr(t.selectorList);
                    if (n !== r) return n - r;
                    var i = kr(e.selectorList), o = kr(t.selectorList);
                    if (i !== o) return i - o;
                    var a = Er(e.selectorList), c = Er(t.selectorList);
                    return a - c;
                });
            }
            function wr(e) {
                return e.reduce(function(e, t) {
                    return e + (t.id ? 1 : 0);
                }, 0);
            }
            function kr(e) {
                return e.reduce(function(e, t) {
                    return e + t.class.length + t.attrs.length;
                }, 0);
            }
            function Er(e) {
                return e.reduce(function(e, t) {
                    return e + (t.tag ? 1 : 0);
                }, 0);
            }
            var _r = {
                li: [ "ul", "ol", "menu" ],
                dt: [ "dl" ],
                dd: [ "dl" ],
                tbody: [ "table" ],
                thead: [ "table" ],
                tfoot: [ "table" ],
                tr: [ "table" ],
                td: [ "table" ]
            };
            function Tr(e, t) {
                var n = _r[e];
                if (n) {
                    var r = t.length - 1;
                    while (r >= 0) {
                        var i = t[r].tagName;
                        if (i === e) break;
                        if (n && n.includes(i)) return !0;
                        r--;
                    }
                }
                return !1;
            }
            function Sr(e) {
                return Mn.html.renderHTMLTag ? e : ar[e] ? ar[e] : ur(e) ? e : lr(e) ? "view" : sr(e) ? "text" : "view";
            }
            function Cr(e) {
                var t = "=", n = e.indexOf(t);
                if (-1 === n) return [ e ];
                var r = e.slice(0, n).trim(), i = e.slice(n + t.length).trim();
                return [ r, i ];
            }
            function Pr(e, t, n, r) {
                return e.filter(function(e) {
                    return "comment" !== e.type && ("text" !== e.type || "" !== e.content);
                }).map(function(e) {
                    if ("text" === e.type) {
                        var i = t.createTextNode(e.content);
                        return Object(k["j"])(Mn.html.transformText) && (i = Mn.html.transformText(i, e)), 
                        null === r || void 0 === r || r.appendChild(i), i;
                    }
                    var o = t.createElement(Sr(e.tagName));
                    o.h5tagName = e.tagName, null === r || void 0 === r || r.appendChild(o), Mn.html.renderHTMLTag || (o.className = "h5-".concat(e.tagName));
                    for (var a = 0; a < e.attributes.length; a++) {
                        var c = e.attributes[a], s = Cr(c), l = Object(u["a"])(s, 2), d = l[0], f = l[1];
                        if ("class" === d) o.className += " " + dr(f); else {
                            if ("o" === d[0] && "n" === d[1]) continue;
                            o.setAttribute(d, null == f || dr(f));
                        }
                    }
                    var h = n.styleTagParser, p = n.descendantList, v = p.slice(), b = h.matchStyle(e.tagName, o, v);
                    return o.setAttribute("style", b + o.style.cssText), Pr(e.children, t, {
                        styleTagParser: h,
                        descendantList: v
                    }, o), Object(k["j"])(Mn.html.transformElement) ? Mn.html.transformElement(o, e) : o;
                });
            }
            function xr(e, t) {
                var n = new yr();
                e = n.extractStyle(e);
                var r = new ir(e).scan(), i = {
                    tagName: "",
                    children: [],
                    type: "element",
                    attributes: []
                }, o = {
                    tokens: r,
                    options: Mn,
                    cursor: 0,
                    stack: [ i ]
                };
                return Ar(o), Pr(i.children, t, {
                    styleTagParser: n,
                    descendantList: Array(n.styles.length).fill(0)
                });
            }
            function Ar(e) {
                var t = e.tokens, n = e.stack, r = e.cursor, i = t.length, o = n[n.length - 1].children;
                while (r < i) {
                    var a = t[r];
                    if ("tag-start" === a.type) {
                        var c = t[++r];
                        r++;
                        var u = c.content.toLowerCase();
                        if (a.close) {
                            var s = n.length, l = !1;
                            while (--s > -1) if (n[s].tagName === u) {
                                l = !0;
                                break;
                            }
                            while (r < i) {
                                var d = t[r];
                                if ("tag-end" !== d.type) break;
                                r++;
                            }
                            if (l) {
                                n.splice(s);
                                break;
                            }
                        } else {
                            var f = Mn.html.closingElements.has(u), h = f;
                            if (h && (h = !Tr(u, n)), h) {
                                var p = n.length - 1;
                                while (p > 0) {
                                    if (u === n[p].tagName) {
                                        n.splice(p);
                                        var v = p - 1;
                                        o = n[v].children;
                                        break;
                                    }
                                    p -= 1;
                                }
                            }
                            var b = [], m = void 0;
                            while (r < i) {
                                if (m = t[r], "tag-end" === m.type) break;
                                b.push(m.content), r++;
                            }
                            r++;
                            var g = [], y = {
                                type: "element",
                                tagName: c.content,
                                attributes: b,
                                children: g
                            };
                            o.push(y);
                            var O = !(m.close || Mn.html.voidElements.has(u));
                            if (O) {
                                n.push({
                                    tagName: u,
                                    children: g
                                });
                                var j = {
                                    tokens: t,
                                    cursor: r,
                                    stack: n
                                };
                                Ar(j), r = j.cursor;
                            }
                        }
                    } else o.push(a), r++;
                }
                e.cursor = r;
            }
            function Ir(e, t, n) {
                while (e.firstChild) e.removeChild(e.firstChild);
                for (var r = xr(t, n()), i = 0; i < r.length; i++) e.appendChild(r[i]);
            }
            function Nr(e, t, n) {
                for (var r, i, o = xr(t, n()), a = 0; a < o.length; a++) {
                    var c = o[a];
                    switch (e) {
                      case "beforebegin":
                        null === (r = this.parentNode) || void 0 === r || r.insertBefore(c, this);
                        break;

                      case "afterbegin":
                        this.hasChildNodes() ? this.insertBefore(c, this.childNodes[0]) : this.appendChild(c);
                        break;

                      case "beforeend":
                        this.appendChild(c);
                        break;

                      case "afterend":
                        null === (i = this.parentNode) || void 0 === i || i.appendChild(c);
                        break;
                    }
                }
            }
            function Lr(e, t) {
                var n, r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], i = t();
                for (var o in 1 === e.nodeType ? n = i.createElement(e.nodeName) : 3 === e.nodeType && (n = i.createTextNode("")), 
                this) {
                    var a = this[o];
                    [ G, K ].includes(o) && Object(j["a"])(a) === J ? n[o] = Object.assign({}, a) : "_value" === o ? n[o] = a : o === q && (n.style._value = Object.assign({}, a._value), 
                    n.style._usedStyleProp = new Set(Array.from(a._usedStyleProp)));
                }
                return r && (n.childNodes = e.childNodes.map(function(e) {
                    return e.cloneNode(!0);
                })), n;
            }
            Mn.html = {
                skipElements: new Set([ "style", "script" ]),
                voidElements: new Set([ "!doctype", "area", "base", "br", "col", "command", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr" ]),
                closingElements: new Set([ "html", "head", "body", "p", "dt", "dd", "li", "option", "thead", "th", "tbody", "tr", "td", "tfoot", "colgroup" ]),
                renderHTMLTag: !1
            };
            var Rr = function() {
                function e(t) {
                    Object(y["a"])(this, e), this.getDoc = function() {
                        return t(Oe.Document)();
                    };
                }
                return Object(O["a"])(e, [ {
                    key: "bind",
                    value: function(e) {
                        var t = this.getDoc;
                        Br(e, t), Fr(e, t), e.cloneNode = Lr.bind(e, e, t);
                    }
                } ]), e;
            }();
            function Br(e, t) {
                Object.defineProperty(e, "innerHTML", {
                    configurable: !0,
                    enumerable: !0,
                    set: function(n) {
                        Ir.call(e, e, n, t);
                    },
                    get: function() {
                        return "";
                    }
                });
            }
            function Fr(e, t) {
                e.insertAdjacentHTML = function(n, r) {
                    Nr.call(e, n, r, t);
                };
            }
            function Dr(e) {
                if ("template" === e.nodeName) {
                    var t = e._getElement(Oe.Element)(D);
                    return t.childNodes = e.childNodes, e.childNodes = [ t ], t.parentNode = e, t.childNodes.forEach(function(e) {
                        e.parentNode = t;
                    }), t;
                }
            }
            Rr = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroElementFactory)), T("design:paramtypes", [ Function ]) ], Rr);
            var Mr = function() {
                function e() {
                    Object(y["a"])(this, e);
                }
                return Object(O["a"])(e, [ {
                    key: "bind",
                    value: function(e) {
                        Ur(e);
                    }
                } ]), e;
            }();
            function Ur(e) {
                Object.defineProperty(e, "content", {
                    configurable: !0,
                    enumerable: !0,
                    get: function() {
                        return Dr(e);
                    }
                });
            }
            Mr = E([ Object(w["d"])() ], Mr);
            var $r = function(e) {
                Object(b["a"])(n, e);
                var t = Object(m["a"])(n);
                function n(e, r, i, o, a) {
                    var c;
                    return Object(y["a"])(this, n), c = t.call(this, e, r, i, o), c._getText = a, c.nodeType = 9, 
                    c.nodeName = F, c;
                }
                return Object(O["a"])(n, [ {
                    key: "createElement",
                    value: function(e) {
                        return e === A ? this._getElement(Oe.RootElement)() : k["d"].has(e) ? this._getElement(Oe.FormElement)(e) : this._getElement(Oe.Element)(e);
                    }
                }, {
                    key: "createElementNS",
                    value: function(e, t) {
                        return this.createElement(t);
                    }
                }, {
                    key: "createTextNode",
                    value: function(e) {
                        return this._getText(e);
                    }
                }, {
                    key: "getElementById",
                    value: function(e) {
                        var t = je.get(e);
                        return Object(k["n"])(t) ? null : t;
                    }
                }, {
                    key: "querySelector",
                    value: function(e) {
                        return /^#/.test(e) ? this.getElementById(e.slice(1)) : null;
                    }
                }, {
                    key: "querySelectorAll",
                    value: function() {
                        return [];
                    }
                }, {
                    key: "createComment",
                    value: function() {
                        var e = this._getText("");
                        return e.nodeName = le, e;
                    }
                } ]), n;
            }(Ye);
            $r = E([ Object(w["d"])(), _(0, Object(w["c"])(S.TaroNodeImpl)), _(1, Object(w["c"])(S.TaroElementFactory)), _(2, Object(w["c"])(S.Hooks)), _(3, Object(w["c"])(S.TaroElementImpl)), _(4, Object(w["c"])(S.TaroTextFactory)), T("design:paramtypes", [ Function, Function, Function, Function, Function ]) ], $r);
            var qr = function() {
                function e() {
                    Object(y["a"])(this, e);
                }
                return Object(O["a"])(e, [ {
                    key: "modifyMpEvent",
                    value: function(e) {
                        var t;
                        null === (t = this.modifyMpEventImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                }, {
                    key: "modifyTaroEvent",
                    value: function(e, t) {
                        var n;
                        null === (n = this.modifyTaroEventImpls) || void 0 === n || n.forEach(function(n) {
                            return n(e, t);
                        });
                    }
                }, {
                    key: "initNativeApi",
                    value: function(e) {
                        var t;
                        null === (t = this.initNativeApiImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                }, {
                    key: "patchElement",
                    value: function(e) {
                        var t;
                        null === (t = this.patchElementImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                } ]), e;
            }();
            E([ Object(w["c"])(S.getLifecycle), T("design:type", Function) ], qr.prototype, "getLifecycle", void 0), 
            E([ Object(w["c"])(S.getPathIndex), T("design:type", Function) ], qr.prototype, "getPathIndex", void 0), 
            E([ Object(w["c"])(S.getEventCenter), T("design:type", Function) ], qr.prototype, "getEventCenter", void 0), 
            E([ Object(w["c"])(S.isBubbleEvents), T("design:type", Function) ], qr.prototype, "isBubbleEvents", void 0), 
            E([ Object(w["c"])(S.getSpecialNodes), T("design:type", Function) ], qr.prototype, "getSpecialNodes", void 0), 
            E([ Object(w["c"])(S.onRemoveAttribute), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "onRemoveAttribute", void 0), 
            E([ Object(w["c"])(S.batchedEventUpdates), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "batchedEventUpdates", void 0), 
            E([ Object(w["c"])(S.mergePageInstance), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "mergePageInstance", void 0), 
            E([ Object(w["c"])(S.createPullDownComponent), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "createPullDownComponent", void 0), 
            E([ Object(w["c"])(S.getDOMNode), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "getDOMNode", void 0), 
            E([ Object(w["c"])(S.modifyHydrateData), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "modifyHydrateData", void 0), 
            E([ Object(w["c"])(S.modifySetAttrPayload), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "modifySetAttrPayload", void 0), 
            E([ Object(w["c"])(S.modifyRmAttrPayload), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "modifyRmAttrPayload", void 0), 
            E([ Object(w["c"])(S.onAddEvent), Object(w["f"])(), T("design:type", Function) ], qr.prototype, "onAddEvent", void 0), 
            E([ Object(w["e"])(S.modifyMpEvent), Object(w["f"])(), T("design:type", Array) ], qr.prototype, "modifyMpEventImpls", void 0), 
            E([ Object(w["e"])(S.modifyTaroEvent), Object(w["f"])(), T("design:type", Array) ], qr.prototype, "modifyTaroEventImpls", void 0), 
            E([ Object(w["e"])(S.initNativeApi), Object(w["f"])(), T("design:type", Array) ], qr.prototype, "initNativeApiImpls", void 0), 
            E([ Object(w["e"])(S.patchElement), Object(w["f"])(), T("design:type", Array) ], qr.prototype, "patchElementImpls", void 0), 
            qr = E([ Object(w["d"])() ], qr);
            var Hr = new Set([ "touchstart", "touchmove", "touchcancel", "touchend", "touchforcechange", "tap", "longpress", "longtap", "transitionend", "animationstart", "animationiteration", "animationend" ]), zr = function(e, t) {
                return e[t];
            }, Wr = function(e) {
                return "[".concat(e, "]");
            }, Vr = function(e) {
                return new e();
            }, Gr = function(e) {
                return Hr.has(e);
            }, Kr = function() {
                return [ "view", "text", "image" ];
            }, Jr = new w["b"](function(e) {
                e(S.getLifecycle).toFunction(zr), e(S.getPathIndex).toFunction(Wr), e(S.getEventCenter).toFunction(Vr), 
                e(S.isBubbleEvents).toFunction(Gr), e(S.getSpecialNodes).toFunction(Kr);
            });
            function Yr(e) {
                var t = Object.keys(k["e"]);
                t.forEach(function(t) {
                    if (t in S) {
                        var n = S[t], r = k["e"][t];
                        Object(k["h"])(r) ? r.forEach(function(t) {
                            return e.bind(n).toFunction(t);
                        }) : e.isBound(n) ? e.rebind(n).toFunction(r) : e.bind(n).toFunction(r);
                    }
                });
            }
            var Qr, Zr, Xr, ei = new w["a"]();
            ei.bind(S.TaroElement).to(Ye).whenTargetNamed(Oe.Element), ei.bind(S.TaroElement).to($r).inSingletonScope().whenTargetNamed(Oe.Document), 
            ei.bind(S.TaroElement).to(Hn).whenTargetNamed(Oe.RootElement), ei.bind(S.TaroElement).to(zn).whenTargetNamed(Oe.FormElement), 
            ei.bind(S.TaroElementFactory).toFactory(function(e) {
                return function(t) {
                    return function(n) {
                        var r = e.container.getNamed(S.TaroElement, t);
                        return n && (r.nodeName = n), r.tagName = r.nodeName.toUpperCase(), r;
                    };
                };
            }), ei.bind(S.TaroText).to(Ee), ei.bind(S.TaroTextFactory).toFactory(function(e) {
                return function(t) {
                    var n = e.container.get(S.TaroText);
                    return n._value = t, n;
                };
            }), ei.bind(S.TaroNodeImpl).to(Rr).inSingletonScope(), ei.bind(S.TaroElementImpl).to(Mr).inSingletonScope(), 
            ei.bind(S.Hooks).to(qr).inSingletonScope(), ei.load(Jr), Yr(ei), Qr = ei.get(S.Hooks), 
            Zr = ei.get(S.TaroElementFactory), Xr = Zr(Oe.Document)();
            var ti = function() {
                function e(t, n, r) {
                    Object(y["a"])(this, e), this._stop = !1, this._end = !1, this.defaultPrevented = !1, 
                    this.timeStamp = Date.now(), this.type = t.toLowerCase(), this.mpEvent = r, this.bubbles = Boolean(n && n.bubbles), 
                    this.cancelable = Boolean(n && n.cancelable);
                }
                return Object(O["a"])(e, [ {
                    key: "stopPropagation",
                    value: function() {
                        this._stop = !0;
                    }
                }, {
                    key: "stopImmediatePropagation",
                    value: function() {
                        this._end = this._stop = !0;
                    }
                }, {
                    key: "preventDefault",
                    value: function() {
                        this.defaultPrevented = !0;
                    }
                }, {
                    key: "target",
                    get: function() {
                        var e, t, n, r = Xr.getElementById(null === (e = this.mpEvent) || void 0 === e ? void 0 : e.target.id);
                        return Object.assign(Object.assign(Object.assign({}, null === (t = this.mpEvent) || void 0 === t ? void 0 : t.target), null === (n = this.mpEvent) || void 0 === n ? void 0 : n.detail), {
                            dataset: null !== r ? r.dataset : k["b"]
                        });
                    }
                }, {
                    key: "currentTarget",
                    get: function() {
                        var e, t, n, r = Xr.getElementById(null === (e = this.mpEvent) || void 0 === e ? void 0 : e.currentTarget.id);
                        return null === r ? this.target : Object.assign(Object.assign(Object.assign({}, null === (t = this.mpEvent) || void 0 === t ? void 0 : t.currentTarget), null === (n = this.mpEvent) || void 0 === n ? void 0 : n.detail), {
                            dataset: r.dataset
                        });
                    }
                } ]), e;
            }();
            function ni(e, t) {
                if ("string" === typeof e) return new ti(e, {
                    bubbles: !0,
                    cancelable: !0
                });
                var n = new ti(e.type, {
                    bubbles: !0,
                    cancelable: !0
                }, e);
                for (var r in e) r !== te && r !== ee && r !== ne && r !== ie && (n[r] = e[r]);
                return n.type === re && (null === t || void 0 === t ? void 0 : t.nodeName) === Q && (n[oe] = 13), 
                n;
            }
            var ri = {};
            function ii(e) {
                var t;
                null === (t = Qr.modifyMpEvent) || void 0 === t || t.call(Qr, e), null == e.currentTarget && (e.currentTarget = e.target);
                var n = Xr.getElementById(e.currentTarget.id);
                if (n) {
                    var r = function() {
                        var t, r = ni(e, n);
                        null === (t = Qr.modifyTaroEvent) || void 0 === t || t.call(Qr, r, n), n.dispatchEvent(r);
                    };
                    if ("function" === typeof Qr.batchedEventUpdates) {
                        var i = e.type;
                        !Qr.isBubbleEvents(i) || !be(n, i) || i === ae && n.props.catchMove ? Qr.batchedEventUpdates(function() {
                            ri[i] && (ri[i].forEach(function(e) {
                                return e();
                            }), delete ri[i]), r();
                        }) : (ri[i] || (ri[i] = [])).push(r);
                    } else r();
                }
            }
            var oi = "undefined" !== typeof i && !!i.scripts, ai = oi ? i : k["b"], ci = oi ? o : k["b"];
            function ui() {
                var e = ei.get(S.TaroElementFactory), t = e(Oe.Document)(), n = t.createElement.bind(t), r = n(I), i = n(N), o = n(L), a = n(R);
                a.id = R;
                var c = n(B);
                return t.appendChild(r), r.appendChild(i), r.appendChild(o), o.appendChild(c), c.appendChild(a), 
                t.documentElement = r, t.head = i, t.body = o, t.createEvent = ni, t;
            }
            var si, li = oi ? ai : ui(), di = "Macintosh", fi = "Intel Mac OS X 10_14_5", hi = "AppleWebKit/534.36 (KHTML, like Gecko) NodeJS/v4.1.0 Chrome/76.0.3809.132 Safari/534.36", pi = oi ? ci.navigator : {
                appCodeName: "Mozilla",
                appName: "Netscape",
                appVersion: "5.0 (" + di + "; " + fi + ") " + hi,
                cookieEnabled: !0,
                mimeTypes: [],
                onLine: !0,
                platform: "MacIntel",
                plugins: [],
                product: "Taro",
                productSub: "20030107",
                userAgent: "Mozilla/5.0 (" + di + "; " + fi + ") " + hi,
                vendor: "Joyent",
                vendorSub: ""
            };
            (function() {
                var e;
                "undefined" !== typeof performance && null !== performance && performance.now ? si = function() {
                    return performance.now();
                } : Date.now ? (si = function() {
                    return Date.now() - e;
                }, e = Date.now()) : (si = function() {
                    return new Date().getTime() - e;
                }, e = new Date().getTime());
            })();
            var vi = 0, bi = "undefined" !== typeof a && null !== a ? a : function(e) {
                var t = si(), n = Math.max(vi + 16, t);
                return setTimeout(function() {
                    e(vi = n);
                }, n - t);
            }, mi = "undefined" !== typeof c && null !== c ? c : function(e) {
                clearTimeout(e);
            };
            function gi(e) {
                return e.style;
            }
            var yi = oi ? ci : {
                navigator: pi,
                document: li
            };
            if (!oi) {
                var Oi = [].concat(Object(l["a"])(Object.getOwnPropertyNames(r || ci)), Object(l["a"])(Object.getOwnPropertySymbols(r || ci)));
                Oi.forEach(function(e) {
                    "atob" !== e && (Object.prototype.hasOwnProperty.call(yi, e) || (yi[e] = r[e]));
                }), li.defaultView = yi;
            }
            yi.requestAnimationFrame = bi, yi.cancelAnimationFrame = mi, yi.getComputedStyle = gi, 
            yi.addEventListener = function() {}, yi.removeEventListener = function() {}, ce in yi || (yi.Date = Date), 
            yi.setTimeout = function(e, t) {
                setTimeout(e, t);
            }, yi.clearTimeout = function(e) {
                clearTimeout(e);
            };
            var ji = {
                app: null,
                router: null,
                page: null
            }, wi = function() {
                return ji;
            }, ki = function() {
                function e(t) {
                    Object(y["a"])(this, e), "undefined" !== typeof t && t.callbacks ? this.callbacks = t.callbacks : this.callbacks = {};
                }
                return Object(O["a"])(e, [ {
                    key: "on",
                    value: function(t, n, r) {
                        var i, o, a, c;
                        if (!n) return this;
                        t = t.split(e.eventSplitter), this.callbacks || (this.callbacks = {});
                        var u = this.callbacks;
                        while (i = t.shift()) c = u[i], o = c ? c.tail : {}, o.next = a = {}, o.context = r, 
                        o.callback = n, u[i] = {
                            tail: a,
                            next: c ? c.next : o
                        };
                        return this;
                    }
                }, {
                    key: "once",
                    value: function(e, t, n) {
                        var r = this, i = function i() {
                            for (var o = arguments.length, a = new Array(o), c = 0; c < o; c++) a[c] = arguments[c];
                            t.apply(r, a), r.off(e, i, n);
                        };
                        return this.on(e, i, n), this;
                    }
                }, {
                    key: "off",
                    value: function(t, n, r) {
                        var i, o, a, c, u, s;
                        if (!(o = this.callbacks)) return this;
                        if (!(t || n || r)) return delete this.callbacks, this;
                        t = t ? t.split(e.eventSplitter) : Object.keys(o);
                        while (i = t.shift()) if (a = o[i], delete o[i], a && (n || r)) {
                            c = a.tail;
                            while ((a = a.next) !== c) u = a.callback, s = a.context, (n && u !== n || r && s !== r) && this.on(i, u, s);
                        }
                        return this;
                    }
                }, {
                    key: "trigger",
                    value: function(t) {
                        var n, r, i, o;
                        if (!(i = this.callbacks)) return this;
                        t = t.split(e.eventSplitter);
                        var a = [].slice.call(arguments, 1);
                        while (n = t.shift()) if (r = i[n]) {
                            o = r.tail;
                            while ((r = r.next) !== o) r.callback.apply(r.context || this, a);
                        }
                        return this;
                    }
                } ]), e;
            }();
            ki.eventSplitter = /\s+/;
            var Ei = ei.get(S.Hooks), _i = Ei.getEventCenter(ki);
            ei.bind(S.eventCenter).toConstantValue(_i);
            var Ti = new Map(), Si = de(), Ci = ei.get(S.Hooks);
            function Pi(e, t) {
                var n;
                null === (n = Ci.mergePageInstance) || void 0 === n || n.call(Ci, Ti.get(t), e), 
                Ti.set(t, e);
            }
            function xi(e) {
                return Ti.get(e);
            }
            function Ai(e) {
                return null == e ? "" : "/" === e.charAt(0) ? e : "/" + e;
            }
            function Ii(e, t) {
                for (var n = arguments.length, r = new Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                var o = Ti.get(e);
                if (null != o) {
                    var a = Ci.getLifecycle(o, t);
                    if (Object(k["h"])(a)) {
                        var c = a.map(function(e) {
                            return e.apply(o, r);
                        });
                        return c[0];
                    }
                    if (Object(k["j"])(a)) return a.apply(o, r);
                }
            }
            function Ni(e) {
                if (null == e) return "";
                var t = Object.keys(e).map(function(t) {
                    return t + "=" + e[t];
                }).join("&");
                return "" === t ? t : "?" + t;
            }
            function Li(e, t) {
                var n = e;
                return oi || (n = e + Ni(t)), n;
            }
            function Ri(e) {
                return e + ".onReady";
            }
            function Bi(e) {
                return e + ".onShow";
            }
            function Fi(e) {
                return e + ".onHide";
            }
            function Di(e, t, n, r) {
                var i, o, a, c, u = null !== t && void 0 !== t ? t : "taro_page_".concat(Si()), s = null, l = !1, d = [], f = {
                    onLoad: function(t, n) {
                        var i = this;
                        c = new Promise(function(e) {
                            a = e;
                        }), $n.start(x), ji.page = this, this.config = r || {}, t.$taroTimestamp = Date.now(), 
                        this.$taroPath = Li(u, t), null == this.$taroParams && (this.$taroParams = Object.assign({}, t));
                        var o = oi ? this.$taroPath : this.route || this.__route__;
                        ji.router = {
                            params: this.$taroParams,
                            path: Ai(o),
                            onReady: Ri(u),
                            onShow: Bi(u),
                            onHide: Fi(u)
                        };
                        var f = function() {
                            ji.app.mount(e, i.$taroPath, function() {
                                s = li.getElementById(i.$taroPath), Object(k["f"])(null !== s, "没有找到页面实例。"), Ii(i.$taroPath, "onLoad", i.$taroParams), 
                                a(), oi ? Object(k["j"])(n) && n() : (s.ctx = i, s.performUpdate(!0, n));
                            });
                        };
                        l ? d.push(f) : f();
                    },
                    onReady: function() {
                        bi(function() {
                            _i.trigger(Ri(u));
                        }), Ii(this.$taroPath, "onReady"), this.onReady.called = !0;
                    },
                    onUnload: function() {
                        var e = this;
                        l = !0, ji.app.unmount(this.$taroPath, function() {
                            l = !1, Ti.delete(e.$taroPath), s && (s.ctx = null), d.length && (d.forEach(function(e) {
                                return e();
                            }), d = []);
                        });
                    },
                    onShow: function() {
                        var e = this;
                        c.then(function() {
                            ji.page = e, e.config = r || {};
                            var t = oi ? e.$taroPath : e.route || e.__route__;
                            ji.router = {
                                params: e.$taroParams,
                                path: Ai(t),
                                onReady: Ri(u),
                                onShow: Bi(u),
                                onHide: Fi(u)
                            }, bi(function() {
                                _i.trigger(Bi(u));
                            }), Ii(e.$taroPath, "onShow");
                        });
                    },
                    onHide: function() {
                        ji.page = null, ji.router = null, Ii(this.$taroPath, "onHide"), _i.trigger(Fi(u));
                    },
                    onPullDownRefresh: function() {
                        return Ii(this.$taroPath, "onPullDownRefresh");
                    },
                    onReachBottom: function() {
                        return Ii(this.$taroPath, "onReachBottom");
                    },
                    onPageScroll: function(e) {
                        return Ii(this.$taroPath, "onPageScroll", e);
                    },
                    onResize: function(e) {
                        return Ii(this.$taroPath, "onResize", e);
                    },
                    onTabItemTap: function(e) {
                        return Ii(this.$taroPath, "onTabItemTap", e);
                    },
                    onTitleClick: function() {
                        return Ii(this.$taroPath, "onTitleClick");
                    },
                    onOptionMenuClick: function() {
                        return Ii(this.$taroPath, "onOptionMenuClick");
                    },
                    onPopMenuClick: function() {
                        return Ii(this.$taroPath, "onPopMenuClick");
                    },
                    onPullIntercept: function() {
                        return Ii(this.$taroPath, "onPullIntercept");
                    },
                    onAddToFavorites: function() {
                        return Ii(this.$taroPath, "onAddToFavorites");
                    }
                };
                return (e.onShareAppMessage || (null === (i = e.prototype) || void 0 === i ? void 0 : i.onShareAppMessage) || e.enableShareAppMessage) && (f.onShareAppMessage = function(e) {
                    var t = null === e || void 0 === e ? void 0 : e.target;
                    if (null != t) {
                        var n = t.id, r = li.getElementById(n);
                        null != r && (e.target.dataset = r.dataset);
                    }
                    return Ii(this.$taroPath, "onShareAppMessage", e);
                }), (e.onShareTimeline || (null === (o = e.prototype) || void 0 === o ? void 0 : o.onShareTimeline) || e.enableShareTimeline) && (f.onShareTimeline = function() {
                    return Ii(this.$taroPath, "onShareTimeline");
                }), f.eh = ii, Object(k["n"])(n) || (f.data = n), oi && (f.path = u), f;
            }
            function Mi(e, t, n) {
                var r, i, o, a = null !== t && void 0 !== t ? t : "taro_component_".concat(Si()), c = null, u = {
                    attached: function() {
                        var t, n = this;
                        $n.start(x);
                        var r = Li(a, {
                            id: (null === (t = this.getPageId) || void 0 === t ? void 0 : t.call(this)) || Si()
                        });
                        ji.app.mount(e, r, function() {
                            c = li.getElementById(r), Object(k["f"])(null !== c, "没有找到组件实例。"), Ii(r, "onLoad"), 
                            oi || (c.ctx = n, c.performUpdate(!0));
                        });
                    },
                    detached: function() {
                        var e = Li(a, {
                            id: this.getPageId()
                        });
                        ji.app.unmount(e, function() {
                            Ti.delete(e), c && (c.ctx = null);
                        });
                    },
                    methods: {
                        eh: ii
                    }
                };
                return Object(k["n"])(n) || (u.data = n), u["options"] = null !== (r = null === e || void 0 === e ? void 0 : e["options"]) && void 0 !== r ? r : k["b"], 
                u["externalClasses"] = null !== (i = null === e || void 0 === e ? void 0 : e["externalClasses"]) && void 0 !== i ? i : k["b"], 
                u["behaviors"] = null !== (o = null === e || void 0 === e ? void 0 : e["behaviors"]) && void 0 !== o ? o : k["b"], 
                u;
            }
            function Ui(e) {
                return {
                    properties: {
                        i: {
                            type: Object,
                            value: Object(g["a"])({}, "nn", "view")
                        },
                        l: {
                            type: String,
                            value: ""
                        }
                    },
                    options: {
                        addGlobalClass: !0,
                        virtualHost: "custom-wrapper" !== e
                    },
                    methods: {
                        eh: ii
                    }
                };
            }
            var $i = ei.get(S.Hooks);
            function qi(e, t) {
                var n;
                return Object(k["j"])(t.render) || !!(null === (n = t.prototype) || void 0 === n ? void 0 : n.isReactComponent) || t.prototype instanceof e.Component;
            }
            var Hi, zi = k["b"], Wi = k["b"];
            function Vi(e, t) {
                var n = e.createElement;
                return function(r) {
                    var i = qi(e, r), o = function(e) {
                        return e && Pi(e, t);
                    }, a = i ? {
                        ref: o
                    } : {
                        forwardedRef: o,
                        reactReduxForwardedRef: o
                    };
                    return Wi === k["b"] && (Wi = e.createContext("")), function(e) {
                        Object(b["a"])(o, e);
                        var i = Object(m["a"])(o);
                        function o() {
                            var e;
                            return Object(y["a"])(this, o), e = i.apply(this, arguments), e.state = {
                                hasError: !1
                            }, e;
                        }
                        return Object(O["a"])(o, [ {
                            key: "componentDidCatch",
                            value: function(e, t) {}
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.state.hasError ? [] : n(Wi.Provider, {
                                    value: t
                                }, n(r, Object.assign(Object.assign({}, this.props), a)));
                                return oi ? n("div", {
                                    id: t,
                                    className: "taro_page"
                                }, e) : n("root", {
                                    id: t
                                }, e);
                            }
                        } ], [ {
                            key: "getDerivedStateFromError",
                            value: function(e) {
                                return {
                                    hasError: !0
                                };
                            }
                        } ]), o;
                    }(e.Component);
                };
            }
            function Gi() {
                var e = function(e, t) {
                    return t = t.replace(/^on(Show|Hide)$/, "componentDid$1"), e[t];
                }, t = function(e) {
                    e.type = e.type.replace(/-/g, "");
                }, n = function(e) {
                    Hi.unstable_batchedUpdates(e);
                }, r = function(e, t) {
                    e && t && ("constructor" in e || Object.keys(e).forEach(function(n) {
                        Object(k["j"])(t[n]) ? t[n] = [ t[n] ].concat(Object(l["a"])(e[n])) : t[n] = [].concat(Object(l["a"])(t[n] || []), Object(l["a"])(e[n]));
                    }));
                };
                $i.getLifecycle = e, $i.modifyMpEvent = t, $i.batchedEventUpdates = n, $i.mergePageInstance = r;
            }
            var Ki = de();
            function Ji(e, t, n, r) {
                zi = t, Hi = n, Object(k["f"])(!!Hi, "构建 React/Nerv 项目请把 process.env.FRAMEWORK 设置为 'react'/'nerv' ");
                var i = zi.createRef(), o = qi(zi, e);
                Gi();
                var a, c = function(t) {
                    Object(b["a"])(r, t);
                    var n = Object(m["a"])(r);
                    function r() {
                        var e;
                        return Object(y["a"])(this, r), e = n.apply(this, arguments), e.pages = [], e.elements = [], 
                        e;
                    }
                    return Object(O["a"])(r, [ {
                        key: "mount",
                        value: function(e, t, n) {
                            var r = t + Ki(), i = function() {
                                return zi.createElement(e, {
                                    key: r,
                                    tid: t
                                });
                            };
                            this.pages.push(i), this.forceUpdate(n);
                        }
                    }, {
                        key: "unmount",
                        value: function(e, t) {
                            for (var n = 0; n < this.elements.length; n++) {
                                var r = this.elements[n];
                                if (r.props.tid === e) {
                                    this.elements.splice(n, 1);
                                    break;
                                }
                            }
                            this.forceUpdate(t);
                        }
                    }, {
                        key: "render",
                        value: function() {
                            while (this.pages.length > 0) {
                                var t = this.pages.pop();
                                this.elements.push(t());
                            }
                            var n = null;
                            return o && (n = {
                                ref: i
                            }), zi.createElement(e, n, oi ? zi.createElement("div", null, this.elements.slice()) : this.elements.slice());
                        }
                    } ]), r;
                }(zi.Component);
                oi || (a = Hi.render(zi.createElement(c), li.getElementById("app")));
                var u = Object.create({
                    render: function(e) {
                        a.forceUpdate(e);
                    },
                    mount: function(e, t, n) {
                        var r = Vi(zi, t)(e);
                        a.mount(r, t, n);
                    },
                    unmount: function(e, t) {
                        a.unmount(e, t);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: r
                    },
                    onLaunch: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = this;
                            ji.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), oi && (a = Hi.render(zi.createElement(c), li.getElementById("app")));
                            var n = i.current;
                            if (null === n || void 0 === n ? void 0 : n.taroGlobalData) {
                                var r = n.taroGlobalData, o = Object.keys(r), u = Object.getOwnPropertyDescriptors(r);
                                o.forEach(function(e) {
                                    Object.defineProperty(t, e, {
                                        configurable: !0,
                                        enumerable: !0,
                                        get: function() {
                                            return r[e];
                                        },
                                        set: function(t) {
                                            r[e] = t;
                                        }
                                    });
                                }), Object.defineProperties(this, u);
                            }
                            this.$app = n, null != n && Object(k["j"])(n.onLaunch) && n.onLaunch(e);
                        }
                    },
                    onShow: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            ji.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), null != t && Object(k["j"])(t.componentDidShow) && t.componentDidShow(e), 
                            s("onShow");
                        }
                    },
                    onHide: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            null != t && Object(k["j"])(t.componentDidHide) && t.componentDidHide(e), s("onHide");
                        }
                    },
                    onPageNotFound: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            null != t && Object(k["j"])(t.onPageNotFound) && t.onPageNotFound(e);
                        }
                    }
                });
                function s(e) {
                    var t = xi(C);
                    if (t) {
                        var n = i.current, r = $i.getLifecycle(t, e);
                        Array.isArray(r) && r.forEach(function(e) {
                            return e.apply(n);
                        });
                    }
                }
                return ji.app = u, ji.app;
            }
            var Yi, Qi = de();
            function Zi(e, t) {
                var n = function(t) {
                    Object(b["a"])(r, t);
                    var n = Object(m["a"])(r);
                    function r() {
                        var t;
                        return Object(y["a"])(this, r), t = n.apply(this, arguments), t.root = e.createRef(), 
                        t.ctx = t.props.getCtx(), t;
                    }
                    return Object(O["a"])(r, [ {
                        key: "componentDidMount",
                        value: function() {
                            this.ctx.component = this;
                            var e = this.root.current;
                            e.ctx = this.ctx, e.performUpdate(!0);
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return e.createElement("root", {
                                ref: this.root
                            }, this.props.renderComponent(this.ctx));
                        }
                    } ]), r;
                }(e.Component), r = function(t) {
                    Object(b["a"])(i, t);
                    var r = Object(m["a"])(i);
                    function i() {
                        var e;
                        return Object(y["a"])(this, i), e = r.apply(this, arguments), e.state = {
                            components: []
                        }, e;
                    }
                    return Object(O["a"])(i, [ {
                        key: "componentDidMount",
                        value: function() {
                            ji.app = this;
                        }
                    }, {
                        key: "mount",
                        value: function(t, r, i) {
                            var o = qi(e, t), a = function(e) {
                                return e && Pi(e, r);
                            }, c = o ? {
                                ref: a
                            } : {
                                forwardedRef: a,
                                reactReduxForwardedRef: a
                            }, u = {
                                compId: r,
                                element: e.createElement(n, {
                                    key: r,
                                    getCtx: i,
                                    renderComponent: function(n) {
                                        return e.createElement(t, Object.assign(Object.assign({}, (n.data || (n.data = {})).props), c));
                                    }
                                })
                            };
                            this.setState({
                                components: [].concat(Object(l["a"])(this.state.components), [ u ])
                            });
                        }
                    }, {
                        key: "unmount",
                        value: function(e) {
                            var t = this.state.components, n = t.findIndex(function(t) {
                                return t.compId === e;
                            }), r = [].concat(Object(l["a"])(t.slice(0, n)), Object(l["a"])(t.slice(n + 1)));
                            this.setState({
                                components: r
                            });
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.state.components;
                            return e.map(function(e) {
                                var t = e.element;
                                return t;
                            });
                        }
                    } ]), i;
                }(e.Component);
                Gi();
                var i = li.getElementById("app");
                t.render(e.createElement(r, {}), i);
            }
            function Xi(e, t, n, r) {
                zi = t, Hi = n, Gi();
                var i = {
                    properties: {
                        props: {
                            type: null,
                            value: null,
                            observer: function(e, t) {
                                t && this.component.forceUpdate();
                            }
                        }
                    },
                    created: function() {
                        ji.app || Zi(zi, Hi);
                    },
                    attached: function() {
                        var t = this;
                        o(), this.compId = Qi(), this.config = r, ji.app.mount(e, this.compId, function() {
                            return t;
                        });
                    },
                    ready: function() {
                        Ii(this.compId, "onReady");
                    },
                    detached: function() {
                        ji.app.unmount(this.compId);
                    },
                    pageLifetimes: {
                        show: function() {
                            Ii(this.compId, "onShow");
                        },
                        hide: function() {
                            Ii(this.compId, "onHide");
                        }
                    },
                    methods: {
                        eh: ii
                    }
                };
                function o() {
                    var e = getCurrentPages(), t = e[e.length - 1];
                    if (ji.page !== t) {
                        ji.page = t;
                        var n = t.route || t.__route__, r = {
                            params: t.options || {},
                            path: Ai(n),
                            onReady: "",
                            onHide: "",
                            onShow: ""
                        };
                        ji.router = r, t.options || Object.defineProperty(t, "options", {
                            enumerable: !0,
                            configurable: !0,
                            get: function() {
                                return this._optionsValue;
                            },
                            set: function(e) {
                                r.params = e, this._optionsValue = e;
                            }
                        });
                    }
                }
                return i;
            }
            function eo(e, t) {
                return function(n) {
                    var r = e.extend({
                        props: {
                            tid: String
                        },
                        mixins: [ n, {
                            created: function() {
                                Pi(this, t);
                            }
                        } ]
                    }), i = {
                        render: function(e) {
                            return e(oi ? "div" : "root", {
                                attrs: {
                                    id: t,
                                    class: oi ? "taro_page" : ""
                                }
                            }, [ e(r, {
                                props: {
                                    tid: t
                                }
                            }) ]);
                        }
                    };
                    return i;
                };
            }
            function to() {
                var e = ei.get(S.Hooks), t = function(e, t) {
                    var n = e.props;
                    if (!n.hasOwnProperty(t) || Object(k["i"])(n[t])) return e.setAttribute(t, !1), 
                    !0;
                }, n = function(e, t) {
                    return e.$options[t];
                };
                e.onRemoveAttribute = t, e.getLifecycle = n;
            }
            function no(e, t, n) {
                Yi = t, Object(k["f"])(!!Yi, "构建 Vue 项目请把 process.env.FRAMEWORK 设置为 'vue'"), to(), 
                Yi.config.getTagNamespace = k["q"];
                var r, i = [], o = [], a = new Yi({
                    render: function(t) {
                        while (o.length > 0) {
                            var n = o.pop();
                            i.push(n(t));
                        }
                        return t(e, {
                            ref: "app"
                        }, i.slice());
                    },
                    methods: {
                        mount: function(e, t, n) {
                            o.push(function(n) {
                                return n(e, {
                                    key: t
                                });
                            }), this.updateSync(n);
                        },
                        updateSync: function(e) {
                            this._update(this._render(), !1), this.$children.forEach(function(e) {
                                return e._update(e._render(), !1);
                            }), e();
                        },
                        unmount: function(e, t) {
                            for (var n = 0; n < i.length; n++) {
                                var r = i[n];
                                if (r.key === e) {
                                    i.splice(n, 1);
                                    break;
                                }
                            }
                            this.updateSync(t);
                        }
                    }
                });
                oi || a.$mount(li.getElementById("app"));
                var c = Object.create({
                    mount: function(e, t, n) {
                        var r = eo(Yi, t)(e);
                        a.mount(r, t, n);
                    },
                    unmount: function(e, t) {
                        a.unmount(e, t);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: n
                    },
                    onLaunch: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            ji.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), oi && a.$mount(li.getElementById("app")), r = a.$refs.app, null != r && Object(k["j"])(r.$options.onLaunch) && r.$options.onLaunch.call(r, e);
                        }
                    },
                    onShow: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            ji.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), null != r && Object(k["j"])(r.$options.onShow) && r.$options.onShow.call(r, e);
                        }
                    },
                    onHide: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            null != r && Object(k["j"])(r.$options.onHide) && r.$options.onHide.call(r, e);
                        }
                    }
                });
                return ji.app = c, ji.app;
            }
            function ro(e, t) {
                return function(n) {
                    var r, i = {
                        props: {
                            tid: String
                        },
                        created: function() {
                            Pi(this, t), this.$nextTick(function() {
                                Ii(t, "onShow");
                            });
                        }
                    };
                    if (Object(k["h"])(n.mixins)) {
                        var o = n.mixins, a = o.length - 1;
                        (null === (r = o[a].props) || void 0 === r ? void 0 : r.tid) ? n.mixins[a] = i : n.mixins.push(i);
                    } else n.mixins = [ i ];
                    return e(oi ? "div" : "root", {
                        key: t,
                        id: t,
                        class: oi ? "taro_page" : ""
                    }, [ e(Object.assign({}, n), {
                        tid: t
                    }) ]);
                };
            }
            function io() {
                var e = ei.get(S.Hooks), t = function(e, t) {
                    return e.$options[t];
                }, n = function(e) {
                    e.type = e.type.replace(/-/g, "");
                };
                e.getLifecycle = t, e.modifyMpEvent = n;
            }
            function oo(e, t, n) {
                var r, i = [];
                Object(k["f"])(!Object(k["j"])(e._component), "入口组件不支持使用函数式组件"), io(), e._component.render = function() {
                    return i.slice();
                }, oi || (r = e.mount("#app"));
                var o = Object.create({
                    mount: function(e, n, r) {
                        var o = ro(t, n)(e);
                        i.push(o), this.updateAppInstance(r);
                    },
                    unmount: function(e, t) {
                        i = i.filter(function(t) {
                            return t.key !== e;
                        }), this.updateAppInstance(t);
                    },
                    updateAppInstance: function(e) {
                        r.$forceUpdate(), r.$nextTick(e);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: n
                    },
                    onLaunch: {
                        writable: !0,
                        enumerable: !0,
                        value: function(t) {
                            var n, i = this;
                            if (ji.router = Object.assign({
                                params: null === t || void 0 === t ? void 0 : t.query
                            }, t), oi && (r = e.mount("#app")), e["taroGlobalData"]) {
                                var o = e["taroGlobalData"], a = Object.keys(o), c = Object.getOwnPropertyDescriptors(o);
                                a.forEach(function(e) {
                                    Object.defineProperty(i, e, {
                                        configurable: !0,
                                        enumerable: !0,
                                        get: function() {
                                            return o[e];
                                        },
                                        set: function(t) {
                                            o[e] = t;
                                        }
                                    });
                                }), Object.defineProperties(this, c);
                            }
                            var u = null === (n = null === r || void 0 === r ? void 0 : r.$options) || void 0 === n ? void 0 : n.onLaunch;
                            Object(k["j"])(u) && u.call(r, t);
                        }
                    },
                    onShow: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            var t;
                            ji.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e);
                            var n = null === (t = null === r || void 0 === r ? void 0 : r.$options) || void 0 === t ? void 0 : t.onShow;
                            Object(k["j"])(n) && n.call(r, e);
                        }
                    },
                    onHide: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            var t, n = null === (t = null === r || void 0 === r ? void 0 : r.$options) || void 0 === t ? void 0 : t.onHide;
                            Object(k["j"])(n) && n.call(r, e);
                        }
                    }
                });
                return ji.app = o, ji.app;
            }
            var ao = function(e) {
                return function(t) {
                    var n = zi.useContext(Wi) || C, r = zi.useRef(t);
                    r.current !== t && (r.current = t), zi.useLayoutEffect(function() {
                        var t = xi(n), i = !1;
                        null == t && (i = !0, t = Object.create(null)), t = t;
                        var o = function() {
                            return r.current.apply(r, arguments);
                        };
                        return Object(k["j"])(t[e]) ? t[e] = [ t[e], o ] : t[e] = [].concat(Object(l["a"])(t[e] || []), [ o ]), 
                        i && Pi(t, n), function() {
                            var t = xi(n), r = t[e];
                            r === o ? t[e] = void 0 : Object(k["h"])(r) && (t[e] = r.filter(function(e) {
                                return e !== o;
                            }));
                        };
                    }, []);
                };
            }, co = ao("componentDidShow"), uo = ao("componentDidHide"), so = ao("onPullDownRefresh"), lo = ao("onReachBottom"), fo = ao("onPageScroll"), ho = ao("onResize"), po = ao("onShareAppMessage"), vo = ao("onTabItemTap"), bo = ao("onTitleClick"), mo = ao("onOptionMenuClick"), go = ao("onPullIntercept"), yo = ao("onShareTimeline"), Oo = ao("onAddToFavorites"), jo = ao("onReady"), wo = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return e ? ji.router : zi.useMemo(function() {
                    return ji.router;
                }, []);
            }, ko = function() {};
            function Eo(e) {
                return null == e ? "" : "/" === e.charAt(0) ? e.slice(1) : e;
            }
            var _o = function(e, t) {
                var n, r, i, o = ji.router, a = function() {
                    setTimeout(function() {
                        t ? e.call(t) : e();
                    }, 1);
                };
                if (null !== o) {
                    var c = null, u = Li(Eo(o.path), o.params);
                    c = li.getElementById(u), (null === c || void 0 === c ? void 0 : c.pendingUpdate) ? oi ? null !== (i = null === (r = null === (n = c.firstChild) || void 0 === n ? void 0 : n["componentOnReady"]) || void 0 === r ? void 0 : r.call(n).then(function() {
                        a();
                    })) && void 0 !== i || a() : c.enqueueUpdateCallback(e, t) : a();
                } else a();
            };
        }.call(this, n(61), n(36), n(7)["document"], n(7)["window"], n(7)["requestAnimationFrame"], n(7)["cancelAnimationFrame"]);
    }
} ]);