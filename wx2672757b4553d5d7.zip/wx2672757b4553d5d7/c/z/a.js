var e = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/objectSpread2"), i = e(require("../../_/regenerator")), s = require("../../_/helpers/asyncToGenerator"), n = require("../../$page"), a = require("../../$app"), r = require("@ktt/ktt-wxapp-boundle").utils.isEmpty, c = "android" === (0, 
a.k5)().platform, u = (0, a.ke)(), o = getApp().store, p = void 0 === o ? {} : o, b = (p.getState && p.getState()).main.systemInfo, h = u.navBarHeight, l = {};

(0, n.afb)({
    properties: {
        imgSrc: {
            type: String,
            value: ""
        },
        templateName: {
            type: String,
            value: "",
            observer: function(e, t) {
                var n = this;
                return s(i.default.mark(function s() {
                    var r, c;
                    return i.default.wrap(function(i) {
                        for (;;) switch (i.prev = i.next) {
                          case 0:
                            if (e === t || "" === e || "0" !== n.data.useExternal) {
                                i.next = 10;
                                break;
                            }
                            return i.next = 3, a.gm.getInstance();

                          case 3:
                            if (i.t0 = i.sent, i.t0) {
                                i.next = 6;
                                break;
                            }
                            i.t0 = {};

                          case 6:
                            r = i.t0, c = (0, a.qh)(r, "templateVoMap.".concat(e)) || [], n.templateList = c, 
                            n.resetCanSubscribeInfo();

                          case 10:
                          case "end":
                            return i.stop();
                        }
                    }, s);
                }))();
            }
        },
        trigger: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {
                e !== t && this.subscribe();
            }
        },
        useExternal: {
            type: String,
            value: ""
        },
        scene: {
            type: String,
            value: ""
        },
        bizData: {
            type: Object,
            value: {}
        },
        onShowUpdateSettings: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: ""
        },
        followTemplateData: {
            type: Object,
            value: {},
            observer: function(e) {
                if (!r(e)) {
                    var i = e.subscribeInfo, s = void 0 === i ? {} : i, n = e.templateList, a = void 0 === n ? [] : n, c = e.templateName;
                    this.setData({
                        templateName: c
                    }), this.templateList = a;
                    var u = s.canUseRequestSubscribeFunc, o = s.mainSwitch, p = s.itemSettings;
                    this.canUseRequestSubscribeFunc = u, this.mainSwitch = o, this.triggerEvent("subscribeInfo", t(t({}, s), {}, {
                        templateList: this.templateList
                    })), this.calcGuideWH(this.templateList, p);
                }
            }
        }
    },
    templateList: [],
    showingSubscribeMessage: !1,
    canUseRequestSubscribeFunc: !1,
    mainSwitch: !1,
    isAppHide: !1,
    lifetimes: {
        created: function() {
            this.templateList = [], this.showingSubscribeMessage = !1, this.isAppHide = !1;
        },
        attached: function() {
            this.data.onShowUpdateSettings && (this.onAppHide = this.onAppHide.bind(this), wx.canIUse("onAppHide") && wx.onAppHide(this.onAppHide));
        },
        detached: function() {
            this.data.onShowUpdateSettings && wx.canIUse("offAppHide") && wx.offAppHide(this.onAppHide);
        }
    },
    pageLifetimes: {
        show: function() {
            this.isAppHide && this.data.onShowUpdateSettings && (this.resetCanSubscribeInfo(), 
            this.isAppHide = !1);
        }
    },
    data: {
        amountAlertHeight: 784,
        alertHeightRpx: 354,
        showSubscribeGuide: !1
    },
    methods: {
        onAppHide: function() {
            this.isAppHide = !0;
        },
        resetCanSubscribeInfo: function() {
            var e = this;
            return s(i.default.mark(function s() {
                var n, r, c, u, o, p, b;
                return i.default.wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        if (e.templateList.length) {
                            i.next = 3;
                            break;
                        }
                        return n = e.data, r = n.templateName, c = n.scene, i.abrupt("return", e.$infoByBatch({
                            msg: "resetCanSubscribeInfo templateList empty for ".concat(r, ",scene ").concat(c)
                        }));

                      case 3:
                        return i.next = 5, (0, a.e7)(e.templateList);

                      case 5:
                        u = i.sent, o = u.canUseRequestSubscribeFunc, p = u.mainSwitch, b = u.itemSettings, 
                        e.canUseRequestSubscribeFunc = o, e.mainSwitch = p, e.triggerEvent("subscribeInfo", t(t({}, u), {}, {
                            templateList: e.templateList
                        })), e.calcGuideWH(e.templateList, b);

                      case 11:
                      case "end":
                        return i.stop();
                    }
                }, s);
            }))();
        },
        calcGuideWH: function(e, t) {
            var i = e.filter(function(e) {
                return !t[e.templateId];
            }).length, s = 640 + (c ? 125 : 114) * i, n = (0, a.qf)(s), r = b.windowHeight - n - h, u = (0, 
            a.ov)(r);
            u = u > 333 ? 333 : u, this.setData({
                alertHeightRpx: u
            });
        },
        clickSubscribeGuide: function() {
            this.setData({
                showSubscribeGuide: !1
            }), this.triggerEvent("changeSubscribeGuide", {
                showSubscribeGuide: !1
            });
        },
        resetTemplateCnt: function() {
            this.templateList.length && this.templateList.forEach(function(e) {
                var t = e.templateId, i = void 0 === t ? "" : t;
                i && (l[i] = 0);
            });
        },
        subscribe: function() {
            var e = this, i = this.data, s = i.templateName, a = i.scene, r = i.bizData, c = void 0 === r ? {} : r, u = "", o = "";
            return 0 === this.templateList.length && (u = "subscribe empty templateList"), this.showingSubscribeMessage && (u = "subscribe showingSubscribeMessage"), 
            this.canUseRequestSubscribeFunc || (u = "not support canUseRequestSubscribeFunc"), 
            this.mainSwitch || (o = "mainSwitch off"), u ? (this.$infoByBatch({
                msg: "".concat(u, " for ").concat(s, ",scene ").concat(a)
            }), this.triggerEvent("subscribe", {
                action: "error"
            })) : o ? (this.$infoByBatch({
                msg: "".concat(o, " for ").concat(s, ",scene ").concat(a)
            }), this.triggerEvent("subscribe", {
                action: "error"
            })) : (this.showingSubscribeMessage = !0, this.templateList.forEach(function(e) {
                var t = e.templateId, i = void 0 === t ? "" : t;
                i && (l[i] = l[i] ? ++l[i] : 1);
            }), void (0, n.ame)(t(t({
                templateList: this.templateList,
                scene: a
            }, c), {}, {
                onCheckSubscribeAllow: function(t) {
                    var i = t.allAuth, s = e.templateList.filter(function(e) {
                        var t = e.templateId;
                        return 1 === l[void 0 === t ? "" : t];
                    }).length;
                    !i && s >= 1 && (e.setData({
                        showSubscribeGuide: !0
                    }), e.triggerEvent("changeSubscribeGuide", {
                        showSubscribeGuide: !0
                    })), i && e.triggerEvent("subscribe", {
                        action: "allAuth"
                    });
                },
                onBeforeCheckReject: function() {
                    e.triggerEvent("subscribe", {
                        action: "allAuthReject"
                    });
                },
                onAcceptSuccess: function() {
                    e.triggerEvent("subscribe", {
                        action: "allAccept"
                    });
                },
                onSuccess: function(i) {
                    e.triggerEvent("subscribe", t({
                        action: "success"
                    }, i));
                },
                onComplete: function() {
                    e.showingSubscribeMessage = !1, e.triggerEvent("subscribe", {
                        action: "complete"
                    }), e.data.showSubscribeGuide && (e.setData({
                        showSubscribeGuide: !1
                    }), e.triggerEvent("changeSubscribeGuide", {
                        showSubscribeGuide: !1
                    }));
                },
                onAbort: function() {
                    e.showingSubscribeMessage = !1, e.triggerEvent("subscribe", {
                        action: "abort"
                    });
                }
            })));
        }
    }
});