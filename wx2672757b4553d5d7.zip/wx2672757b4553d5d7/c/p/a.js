(0, require("../../$page").afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        switchNewcomerBenefitModal: function() {
            this.triggerEvent("close");
        },
        confirmCloseNewcomerBenefit: function() {
            this.triggerEvent("confirm");
        }
    }
});