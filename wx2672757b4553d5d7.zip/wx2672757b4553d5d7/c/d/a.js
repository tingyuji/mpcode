var a = require("../../$page"), e = require("../../$app");

(0, a.afb)({
    externalClasses: [ "wrap-class", "star-class", "text-class" ],
    properties: {
        value: {
            type: Number,
            value: 0
        },
        onlyLook: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        MAX_STAR_NUMBER: 5,
        COMMENTS_LEVEL_MAP: a.tz
    },
    methods: {
        handleTapStar: function(a) {
            if (!this.data.onlyLook) {
                var t = (0, e.jo)(a, "value");
                this.triggerEvent("onValueChange", t);
            }
        }
    }
});