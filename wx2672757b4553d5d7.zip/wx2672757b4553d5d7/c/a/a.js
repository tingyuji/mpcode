var e, a = require("../../_/helpers/defineProperty"), n = require("../../$page"), r = require("../../$app"), t = (a(e = {}, +n.wy.page_sn, n.ae4.activityBanner), 
a(e, +n.y_.page_sn, n.ae6.activityBanner), e);

(0, n.afb)({
    behaviors: [ n.abb ],
    externalClasses: [ "external-class" ],
    properties: {
        displayBanners: {
            type: Array,
            value: [],
            observer: function() {
                this.reset();
            }
        },
        isInHeader: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        current: 0,
        autoPlay: !0
    },
    pageLifetimes: {
        show: function() {
            this.setData({
                autoPlay: !1
            });
        },
        hide: function() {
            this.setData({
                autoPlay: !1
            });
        }
    },
    closedBannerIds: [],
    methods: {
        bannerImpr: function(e) {
            var a, i = (0, r.jo)(e), s = i.bannerId, o = i.idx, l = +((null === (a = this.$currentPage) || void 0 === a ? void 0 : a.pageProperties.page_sn) || n.wy.page_sn);
            this.$impr({
                page_el_sn: t[l],
                extParams: {
                    banner_id: s,
                    bidx: o
                }
            });
        },
        handleActivityBannerClick: function(e) {
            var a, i = (0, r.jo)(e), s = i.bannerInfo, o = i.idx, l = +((null === (a = this.$currentPage) || void 0 === a ? void 0 : a.pageProperties.page_sn) || n.wy.page_sn);
            if (this.$click({
                page_el_sn: t[l],
                extParams: {
                    banner_id: s.id,
                    bidx: o
                }
            }), s && s.jumpUrl && 0 === s.jumpUrl.indexOf("/")) {
                if (wx.canIUse("showRedPackage")) {
                    var c = (0, r.oa)(s.jumpUrl).rp_url || "";
                    if (c) return void wx.showRedPackage({
                        url: c
                    });
                }
                (0, r.n3)({
                    url: s.jumpUrl
                });
            }
        },
        reset: function() {
            var e = this.data, a = e.displayBanners, n = e.current;
            this.setData({
                displayBanners: a,
                current: n > a.length - 1 ? 0 : n,
                autoPlay: (null == a ? void 0 : a.length) > 1
            });
        },
        handleChange: function(e) {
            var a = (0, r.jo)(e).current;
            this.setData({
                current: a
            });
        },
        handleBannerClose: function(e) {
            var a = (0, r.jo)(e).bannerId;
            r.f9.trigger(r.f1.closeBanner, a);
            var n = (0, r.f2)(function() {
                return JSON.parse(r.f3.getStorageSync(r.ct.closedActivityBanners));
            }, []);
            r.f3.setStorageSync(r.ct.closedActivityBanners, JSON.stringify(n.concat([ a ])));
        }
    }
});