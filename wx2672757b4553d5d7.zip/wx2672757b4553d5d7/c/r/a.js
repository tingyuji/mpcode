var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), a = require("../../_/helpers/objectSpread2"), r = require("../../_/helpers/asyncToGenerator"), t = require("../../$app"), n = require("../../$page");

(0, n.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.$impr({
                    page_el_sn: n.y8.PAY_PANEL
                });
            }
        },
        realAmountYuan: {
            type: String,
            value: "",
            observer: function() {
                this.init();
            }
        }
    },
    data: {
        originAmountYuan: "288",
        realAmount: 0
    },
    paying: !1,
    methods: {
        init: function() {
            var e = this.data.realAmountYuan;
            this.setData({
                realAmount: 100 * (parseFloat(e) || 0)
            });
        },
        handleClose: function(e) {
            var a = (0, t.jo)(e).paySuccess;
            this.triggerEvent("close", {
                paySuccess: a
            }), this.$click({
                page_el_sn: n.y8.PAY_PANEL,
                extParams: {
                    pay_btn: 2
                }
            });
        },
        handlePay: function() {
            var s = this;
            return r(e.default.mark(function r() {
                var i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (s.data.realAmount && !s.paying) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        return s.paying = !0, s.$showLoading(), e.next = 7, s.$baseRequest(a(a({}, n.afx), {}, {
                            data: {
                                pageSn: (0, t.qh)(s.$currentPage, "pageProperties.page_sn")
                            }
                        })).catch(t.hm);

                      case 7:
                        if (i = e.sent, s.$hideLoading(), null == i ? void 0 : i.result) {
                            e.next = 12;
                            break;
                        }
                        return s.paying = !1, e.abrupt("return");

                      case 12:
                        return e.prev = 12, e.next = 15, new n.ach({
                            orderSn: (0, t.qh)(i, "result.paySn"),
                            createType: (0, t.qh)(i, "result.type")
                        }).start();

                      case 15:
                        s.paying = !1, s.triggerEvent("paySuccess"), s.handleClose({
                            detail: {
                                paySuccess: !0
                            }
                        }), s.$click({
                            page_el_sn: n.y8.PAY_PANEL,
                            extParams: {
                                pay_ntm: 1
                            }
                        }), e.next = 24;
                        break;

                      case 21:
                        e.prev = 21, e.t0 = e.catch(12), s.paying = !1;

                      case 24:
                      case "end":
                        return e.stop();
                    }
                }, r, null, [ [ 12, 21 ] ]);
            }))();
        }
    }
});