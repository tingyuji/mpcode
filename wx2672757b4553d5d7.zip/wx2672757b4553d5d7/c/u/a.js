var o = require("../../$page"), t = require("../../$app");

(0, o.afb)({
    properties: {
        showPublicPraisePopup: {
            type: Boolean,
            value: !1
        },
        publicPraiseInfo: {
            type: Object,
            value: {},
            observer: function(o) {
                this.dealFloatNumber(o);
            }
        }
    },
    data: {
        posEvalRto: 0,
        shpRto: 0,
        nickname: "",
        markInfo: {},
        crtAfsRto: 0
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        dealFloatNumber: function(e) {
            var a = e.posEvalRto, i = void 0 === a ? 0 : a, s = e.shpRto, r = void 0 === s ? 0 : s, n = e.crtAfsRto, p = void 0 === n ? 0 : n, l = e.isComputed, u = void 0 !== l && l, c = e.nickname, v = void 0 === c ? "" : c, d = e.markExtInfo, f = e.subType, h = ((0, 
            o.ais)(d) || {}).subType || f, m = (0, t.kt)(v, 12);
            this.setData({
                posEvalRto: u ? i : (100 * i).toFixed(1),
                shpRto: u ? r : (100 * r).toFixed(1),
                nickname: v.length === m.length ? m : m + "...",
                markInfo: o.xo[h] || {},
                crtAfsRto: u ? p : (100 * p).toFixed(1)
            });
        }
    }
});