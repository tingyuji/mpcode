var t = require("../../_/helpers/interopRequireDefault"), e = require("../../_/helpers/toConsumableArray"), a = t(require("../../_/regenerator")), n = require("../../_/helpers/objectSpread2"), o = require("../../_/helpers/asyncToGenerator"), s = require("../../$app"), r = require("../../$page"), c = {
    commentText: "",
    score: 0,
    commentImages: [],
    isAnonymous: !0
};

(0, r.afb)({
    behaviors: [ r.aay ],
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                var e = this;
                return o(a.default.mark(function o() {
                    return a.default.wrap(function(a) {
                        for (;;) switch (a.prev = a.next) {
                          case 0:
                            if (e.setData({
                                showPanel: t
                            }), !t) {
                                a.next = 13;
                                break;
                            }
                            return a.t0 = e, a.t1 = n, a.t2 = n({}, c), a.t3 = {}, a.next = 8, e.getLastCommentAnony();

                          case 8:
                            a.t4 = a.sent, a.t5 = {
                                isAnonymous: a.t4
                            }, a.t6 = (0, a.t1)(a.t2, a.t3, a.t5), a.t7 = {
                                commentData: a.t6
                            }, a.t0.setData.call(a.t0, a.t7);

                          case 13:
                          case "end":
                            return a.stop();
                        }
                    }, o);
                }))();
            }
        },
        params: {
            type: Object,
            value: {}
        },
        trackingData: {
            type: Object,
            value: {}
        },
        showBottomArea: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        COMMENT_MAX_PIC_NUM: 3,
        COMMENT_PHRASES: s.q,
        focusOn: !1,
        commentData: n({}, c)
    },
    methods: {
        hide: function() {
            this.triggerEvent("close");
        },
        focus: function() {
            this.setData({
                focusOn: !0
            });
            var t = this.data.trackingData.textarea;
            t && this.$click({
                page_el_sn: t
            });
        },
        blur: function() {
            this.setData({
                focusOn: !1
            });
        },
        changeCommentScore: function(t) {
            var e = t.detail;
            this.setData({
                "commentData.score": e
            });
            var a = this.data.commentData, n = a.commentText, o = a.commentImages;
            e <= 2 && !n && !o.length && this.setData({
                showAddDetailTip: !0
            });
        },
        hideAddDetailTip: function() {
            this.data.showAddDetailTip && this.setData({
                showAddDetailTip: !1
            });
        },
        changeCommentText: function(t) {
            var e = (0, s.jo)(t), a = e.value, n = e.from, o = this.data.commentData, r = (o = void 0 === o ? {} : o).commentText, c = void 0 === r ? "" : r;
            "option" === n && (a = "".concat(c).concat(c.trim() ? "，" : "").concat(a)), this.setData({
                "commentData.commentText": a
            }), this.hideAddDetailTip();
            var i = this.data.trackingData.options;
            "option" === n && i && i && this.$click({
                page_el_sn: i
            });
        },
        changeCommentAnonymous: function() {
            this.setData({
                "commentData.isAnonymous": !this.data.commentData.isAnonymous
            });
        },
        changeCommentImages: function(t) {
            var e = (0, s.jo)(t).galleryUrl;
            this.setData({
                "commentData.commentImages": e
            });
        },
        deleteCommentImage: function(t) {
            var e = (0, s.jo)(t).index, a = this.data.commentData.commentImages;
            a.splice(e, 1), this.setData({
                "commentData.commentImages": a
            });
        },
        addCommentImage: function() {
            var t = this;
            return o(a.default.mark(function n() {
                var o, c;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return o = t.data.commentData.commentImages, a.next = 3, wx.chooseImage({
                            count: 3 - o.length,
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ "album", "camera" ]
                        }).catch(s.hm);

                      case 3:
                        (c = a.sent) && (0, r.ai7)({
                            images: c,
                            onSizeChange: function(a) {
                                t.setData({
                                    "commentData.commentImages": [].concat(e(o), e(a))
                                }), t.hideAddDetailTip();
                            }
                        });

                      case 5:
                      case "end":
                        return a.stop();
                    }
                }, n);
            }))();
        },
        submitComment: function() {
            var t = this;
            return o(a.default.mark(function e() {
                var n, o, s, r, c, i, m, u, l, h, p, d;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ((n = t.data.trackingData.submitBtn) && t.$click({
                            page_el_sn: n
                        }), t.data.commentData.score) {
                            e.next = 4;
                            break;
                        }
                        return e.abrupt("return", t.$showToast({
                            title: "请添加服务评分"
                        }));

                      case 4:
                        if (!t.commentSubmitLock) {
                            e.next = 6;
                            break;
                        }
                        return e.abrupt("return");

                      case 6:
                        return t.commentSubmitLock = !0, o = t.data, s = o.params, r = s.activityNo, c = s.supplyActivityNo, 
                        i = s.supplyUserNo, m = o.commentData, u = m.score, l = m.commentText, h = m.isAnonymous, 
                        p = m.commentImages, t.$showLoading(), e.next = 11, t.$baseRequest({
                            url: "/api/supplier/score",
                            convertToCamel: !0,
                            convertRequestToSnake: !0,
                            noErrorToast: !0,
                            data: {
                                scoreActNo: r,
                                supplierActNo: c,
                                supplierActUin: i,
                                scoreText: l.trim(),
                                scoreUrl: p.map(function(t) {
                                    return t.url;
                                }),
                                totalScore: u,
                                afterSaleScore: u,
                                logisticsScore: u,
                                quaScore: u,
                                isAnonymous: +h || 0
                            }
                        }).catch(function(e) {
                            t.$hideLoading(), t.$showToast({
                                title: e.errorMsg || "网络异常，请稍后重试"
                            });
                        });

                      case 11:
                        (d = e.sent) && d.success && (t.$hideLoading(), t.$showToast({
                            title: "评价成功"
                        }), t.setLastCommentAnony(h), t.triggerEvent("commentSucceed", {
                            totalScore: u
                        })), t.commentSubmitLock = !1;

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        }
    }
});