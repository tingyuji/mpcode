var t = require("../../_/helpers/interopRequireDefault"), e = require("../../_/helpers/objectSpread2"), a = t(require("../../_/regenerator")), r = require("../../_/helpers/asyncToGenerator");

require("../../_/helpers/Arrayincludes");

var o = require("../../$app");

(0, require("../../$page").afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.loadGroupCategory();
            }
        },
        activityInfo: {
            type: Object,
            value: {},
            observer: function(t) {
                if (t) {
                    var e = t.activityCategory;
                    this.setData({
                        activityCategory: e
                    });
                }
            }
        }
    },
    data: {
        activityCategory: 0,
        categoryList: []
    },
    lifetimes: {
        attached: function() {
            this.listenChangeCate(), this.loadGroupCategory();
        },
        detached: function() {
            this.removeChangeCustomCategoryListener();
        }
    },
    methods: {
        removeChangeCustomCategoryListener: function() {},
        listenChangeCate: function() {
            var t = this;
            this.removeChangeCustomCategoryListener = o.f9.listen(o.f1.changeCustomCategory, function(e) {
                var a = e.type, r = e.activityCategory, o = void 0 === r ? {} : r;
                [ "add", "delete", "modify", "sort" ].includes(a) && t.loadGroupCategory().then(function() {
                    var e = o.activityCategoryId === t.data.activityCategory;
                    "delete" === a && e && t.setData({
                        activityCategory: 0
                    });
                });
            });
        },
        loadGroupCategory: function() {
            var t = this;
            return r(a.default.mark(function e() {
                var r, o, i, n;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, t.$baseRequest({
                            url: "/api/ktt_group/activity_category/query_category_list",
                            noErrorToast: !0,
                            convertToCamel: !0,
                            convertRequestToSnake: !0
                        }).catch(function() {});

                      case 2:
                        if ((r = e.sent) && r.result) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        o = r.result || {}, i = o.activityCategoryVolist, n = void 0 === i ? [] : i, t.setData({
                            categoryList: n.map(function(t) {
                                return {
                                    categoryId: t.activityCategoryId,
                                    categoryName: t.activityCategoryName,
                                    activityCount: t.activityCount
                                };
                            })
                        });

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        handleChangeGroupCategory: function(t) {
            var i = this;
            return r(a.default.mark(function r() {
                var n, c, s, u, y, g, v, C, f;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return n = (0, o.jo)(t), c = n.index, s = i.data, u = s.categoryList, y = s.activityInfo, 
                        g = u[c], v = g.categoryId, C = g.categoryName, a.next = 5, i.$baseRequest(e(e({}, o.fa), {}, {
                            data: {
                                collectionActivityNo: y.activityNo,
                                activityCategoryId: v
                            }
                        })).catch(function() {});

                      case 5:
                        if ((f = a.sent) && f.success) {
                            a.next = 8;
                            break;
                        }
                        return a.abrupt("return");

                      case 8:
                        i.$showToast({
                            title: "已移动至".concat(C, "分类")
                        }), i.triggerEvent("afterChangeCategory", {
                            categoryId: v
                        });

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        handleJump2CategoryManage: function() {
            (0, o.n3)({
                url: o.ob.groupCateShowSetting
            });
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});