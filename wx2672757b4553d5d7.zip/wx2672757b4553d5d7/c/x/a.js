var t = require("../../_/helpers/objectSpread2"), e = require("../../$page"), i = require("../../$app"), n = (0, 
i.k5)().windowHeight - 150;

(0, e.afb)({
    properties: {
        log: {
            type: String,
            value: ""
        }
    },
    data: {
        skuAmount: 0,
        initHeight: n
    },
    needRefresh: !1,
    isLoading: !1,
    created: function() {
        this.needRefresh = !1, this.isLoading = !1;
    },
    attached: function() {
        var e = this, n = (i.fv.getState && i.fv.getState()).biz.shopCartInfo;
        this.setData(t({}, n)), i.f9.listen(i.f1.signIn, function() {
            e.querySopCartCount();
        }), i.f9.listen(i.f1.refreshShopCartCount, function() {
            e.needRefresh = !0;
        });
    },
    pageLifetimes: {
        show: function() {
            this.needRefresh && (this.needRefresh = !1, this.querySopCartCount());
        }
    },
    methods: {
        querySopCartCount: function() {
            var t = this;
            this.isLoading || (this.isLoading = !0, (0, i.fy)({
                url: "/api/ktt_gateway/shopcart/sku/amount",
                convertRequestToSnake: !0,
                convertToCamel: !0,
                noErrorToast: !0
            }).then(function(e) {
                var n = e.result, o = void 0 === n ? {} : n;
                t.isLoading = !1;
                var s = (o || {}).skuAmount, a = void 0 === s ? 0 : s;
                (0, i.hk)((0, i.q4)({
                    skuAmount: a
                })), t.setData({
                    skuAmount: a
                });
            }).catch(function() {
                t.isLoading = !1;
            }));
        },
        goToShopCart: function() {
            this.needRefresh = !0, (0, i.n3)({
                url: i.ob.shoppingCart
            }), this.$click({
                page_el_sn: this.data.log
            });
        }
    }
});