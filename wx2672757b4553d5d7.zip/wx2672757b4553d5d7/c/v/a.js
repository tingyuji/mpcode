var t = require("../../$app"), e = require("@pdd/std-format"), s = require("../../$page"), a = 1;

(0, s.afb)({
    startY: -1,
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        message: {
            type: Object,
            value: {
                pushTitle: "",
                pushContent: "",
                pushImage: "",
                pushPath: "",
                pushType: 2,
                pushTimeMs: 0,
                noticeAccount: {
                    accountId: null
                },
                unreadCount: 0
            },
            observer: function(t) {
                if (t) {
                    var s, a = t.pushTimeMs;
                    if (a > 0) s = Date.now() - a <= 5e3 ? "现在" : (0, e.timeSpan)(a / 1e3, Date.now() / 1e3) + "前", 
                    this.setData({
                        formatTime: s
                    });
                }
            }
        }
    },
    lifetimes: {
        created: function() {
            this.startY = -1;
        }
    },
    observers: {
        show: function(t) {
            !0 === t && this.countDown();
        }
    },
    methods: {
        countDown: function() {
            setTimeout(function() {
                t.f9.triggerOnce(t.f1.dismissPopPush);
            }, 5e3);
        },
        onPushBannerClick: function() {
            var e = this.data.message, s = e.pushPath, n = e.pushType, i = e.noticeAccount, o = /^https?:\/\//.test(s);
            n === a && this.$baseRequest({
                url: "/api/ktt_gateway/message/notice/mark/all/read",
                noErrorToast: !0,
                data: {
                    assign_account_id_list: [ i.accountId ]
                }
            }).catch(t.hm), t.f9.triggerOnce(t.f1.dismissPopPush), o ? (0, t.n4)({
                path: s
            }) : (0, t.n3)({
                url: s
            });
        },
        onImgError: function() {
            this.setData({
                "message.pushImage": "https://commimg.pddpic.com/upload/ktt/cx.png.slim.png"
            });
        },
        handleTouchStart: function(t) {
            this.startY = t.changedTouches[0].pageY;
        },
        handleTouchMove: function(e) {
            var s = e.changedTouches[0].pageY;
            this.startY >= 0 && this.startY - s > 50 && (this.startY = -1, t.f9.triggerOnce(t.f1.dismissPopPush));
        },
        handleTouchEnd: function() {
            this.startY = -1;
        }
    }
});