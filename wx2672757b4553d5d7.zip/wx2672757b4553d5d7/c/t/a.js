var e = require("../../_/helpers/defineProperty"), t = require("../../$app"), a = require("../../$page");

(0, a.afb)({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        item: {
            type: Object,
            value: {}
        },
        index: {
            type: Number,
            value: 0
        },
        activityNo: {
            type: String,
            value: "",
            observer: function(a) {
                a && this.setData({
                    extParams: e({}, t.gf.activityNo, a)
                });
            }
        },
        isActive: {
            type: Boolean,
            value: !1
        },
        goodsInfo: {
            type: Object,
            value: {}
        },
        drawStatus: {
            type: Number,
            value: null
        },
        personalCenterShare: {
            type: Boolean,
            value: !1
        },
        isOver: {
            type: Boolean,
            value: !1
        },
        isDelete: {
            type: Boolean,
            value: !1
        },
        isPreview: {
            type: Boolean,
            value: !1
        },
        isShow: {
            type: Boolean,
            value: !0
        },
        showShare: {
            type: Boolean,
            value: !0
        },
        notStarted: {
            type: Boolean,
            value: !1
        },
        isShare: {
            type: Number,
            value: 1
        },
        isHelpSellActivity: {
            type: Boolean,
            value: !1
        },
        hasSell: {
            type: Boolean,
            value: !1
        },
        timeSpan: {
            type: String,
            value: ""
        },
        status: Number,
        participateCount: {
            type: String,
            value: ""
        },
        cancelCount: {
            type: String,
            value: ""
        },
        pageViewCount: {
            type: String,
            value: ""
        },
        actualIncome: {
            type: String,
            value: ""
        },
        totalRefundAmount: {
            type: String,
            value: ""
        },
        alreadyHelpSellCount: Number,
        actionRecords: {
            type: Array,
            value: []
        },
        discountInfoList: {
            type: Array,
            value: []
        },
        actionRecordExpended: {
            type: Boolean,
            value: !1
        },
        sort: {
            type: Number,
            value: 0
        },
        isMoveEditing: {
            type: Boolean,
            value: !1
        },
        isFeedsEditing: {
            type: Boolean,
            value: !1
        },
        showEditControl: {
            type: Boolean,
            value: !0
        },
        isFeedsSharing: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                if (e) {
                    var t = this.data.trackingData.batchShareCheckbox;
                    this.$impr({
                        page_el_sn: t
                    });
                }
            }
        },
        releaseListTopItemCount: {
            type: Number,
            value: 0
        },
        subActivityType: {
            type: Number,
            value: t.cp.NORMAL,
            observer: function(e) {
                e === t.cp.SIGN_UP ? this.setData({
                    activityTypeText: "报名"
                }) : e === t.cp.LOTTERY ? this.setData({
                    activityTypeText: "抽奖"
                }) : e === t.cp.TEST && this.setData({
                    activityTypeText: "测评"
                });
            }
        },
        redPacketGroup: {
            type: Boolean,
            value: !1
        },
        viewGroupbalance: {
            type: Boolean,
            value: !0
        },
        supplyUserNo: {
            type: String,
            value: ""
        },
        supplyAvatar: {
            type: String,
            value: ""
        },
        supplyNickname: {
            type: String,
            value: ""
        },
        supplyRemark: {
            type: String,
            value: ""
        },
        totalGoodsReplenishRemind: {
            type: Number,
            value: 0
        },
        viewSupplyInfo: {
            type: Boolean,
            value: !1
        },
        isFreePricing: {
            type: Boolean,
            value: !1
        },
        goodsCommissionAmount: {
            type: String,
            value: ""
        },
        goodsCommissionAmountFromHighestAct: {
            type: String,
            value: ""
        },
        parentSupplyActivityNo: {
            type: String,
            value: ""
        },
        commented: {
            type: Boolean,
            value: !1
        },
        showStarActivityTag: {
            type: Boolean,
            value: !1
        },
        starTagServicePromiseVolist: {
            type: Array,
            value: []
        },
        showGuideShareTips: {
            type: Boolean,
            value: !1
        },
        showRestore: {
            type: Number,
            value: !1
        },
        activityTagVo: {
            type: Object,
            value: {}
        },
        trackingData: {
            type: Object,
            value: {}
        },
        showMoreOperate: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        playIcon: (0, t.jm)("ktt/bw.png.slim.png"),
        ActivityStatus: t.h,
        ActivitySuggestStatus: t.i,
        SUB_ACTIVITY_TYPE: t.cp,
        feedsImgDisplayType: t.as,
        showAllCoupon: !1,
        shareBtnEle: a.ae2.shareBtnEle,
        createPosterEle: a.ae2.createPosterEle,
        activityTypeText: "跟团"
    },
    attached: function() {},
    methods: {
        changeCoupon: function() {
            this.setData({
                showAllCoupon: !this.data.showAllCoupon
            });
        },
        onRestore: function() {
            var e = this.data.index;
            this.triggerEvent("handleRestoreGroup", {
                index: e
            });
        },
        onShare: function(e) {
            var t = this.data.trackingData.shareBtn;
            t && this.$click({
                page_el_sn: t
            }), this.triggerEvent("handleShare", {
                activityNo: this.data.activityNo
            });
        },
        moreOperate: function() {
            var e = this.data.trackingData.moreBtn;
            e && this.$click({
                page_el_sn: e
            }), this.triggerEvent("moreOperate");
        },
        noAction: function() {},
        handleMoveUp: function() {
            var e = this.data.index;
            this.triggerEvent("onMoveFeedsItem", {
                isMoveUp: !0,
                index: e
            });
        },
        handleMoveDown: function() {
            var e = this.data.index;
            this.triggerEvent("onMoveFeedsItem", {
                isMoveUp: !1,
                index: e
            });
        },
        navToCaptain: (0, t.r2)(function() {
            var a = this.data.supplyUserNo;
            this.handleSupplyCaptainClick(), a && (0, t.n3)({
                url: t.ob.captain,
                params: e({}, t.gf.userNo, a)
            });
        }),
        handleQuickComment: function() {
            var a, i = this.data, o = i.supplyUserNo, n = i.activityNo, p = i.parentSupplyActivityNo, l = i.commented, r = i.index, s = this.data.trackingData.commentBtn;
            (s && this.$click({
                page_el_sn: s,
                extParams: {
                    commented: l
                }
            }), l) ? (0, t.n3)({
                url: t.ob.supplyCommentFeeds,
                params: (a = {}, e(a, t.gf.userNo, o), e(a, t.gf.collectionActivityNo, n), e(a, t.gf.supplyActivityId, p), 
                a)
            }) : this.triggerEvent("quickComment", {
                supplyUserNo: o,
                activityNo: n,
                parentSupplyActivityNo: p,
                index: r
            });
        },
        handleSupplyCaptainImpr: function() {
            this.$impr({
                page_el_sn: 4997911
            });
            var e = this.data, t = e.parentSupplyActivityNo, a = e.commented;
            t && this.$impr({
                page_el_sn: a ? 5385843 : 5385842
            });
        },
        handleSupplyCaptainClick: function() {
            this.$click({
                page_el_sn: 4997911
            });
        }
    }
});