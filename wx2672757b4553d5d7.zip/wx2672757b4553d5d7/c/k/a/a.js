var e = require("../../../$app");

Component({
    properties: {
        followerList: {
            type: Array,
            value: {}
        },
        isAdmin: {
            type: Number,
            value: 0
        },
        ownerUserNo: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        attached: function() {
            (0, e.mq)(this.data.ownerUserNo) && this.setData({
                isOwner: !0
            });
        }
    },
    data: {
        isOwner: !1
    },
    methods: {}
});