var e = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/objectSpread2"), a = require("../../_/helpers/defineProperty"), i = e(require("../../_/regenerator")), o = require("../../_/helpers/asyncToGenerator");

require("../../_/helpers/Arrayincludes"), require("../../_/helpers/Objectvalues");

var n = require("../../$app"), s = require("../../$page"), r = require("@ktt/ktt-wxapp-boundle").utils.getRandomArray, l = [ "https://t16img.yangkeduo.com/monica/2020-11-02/94fcfdd8-a998-49ef-a0ed-26405cf7853f_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/1c77dc22-4092-49f4-8fda-8467d415c728_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/b7109d3a-fc56-41f0-8c68-1a68a56ecc17_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/be1ab082-0a3a-4a70-960e-26bb0bfd5385_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/e5ec20d5-d460-45dc-a8bf-79fa84b8ccbb_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/ab4ecc1e-f8ef-45d4-a4b8-3d7f8737a928_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/101e86e4-6fab-41cf-ac00-b4bcaa450610_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/31b5ee50-2dc4-4d0f-86a8-43d63733b37a_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/d7f4b8c3-cc9c-4ddc-922a-3a4dce9784c1_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/7aa9622d-bc35-4737-a26e-2be9f579fec7_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/fc7a9b1c-1c72-4d34-b7af-19c2d063b456_suffix.png", "https://t16img.yangkeduo.com/monica/2020-11-02/853263fa-3edc-49f5-8607-7397718c7458_suffix.png" ];

(0, s.afb)({
    externalClasses: [ "external-class", "goods-list-class", "goods-item-class", "goods-bottom-bar-class" ],
    behaviors: [ s.acw, s.ag5, s.amy ],
    data: {
        playIcon: (0, n.jm)("ktt/bw.png.slim.png"),
        activityType: n.b,
        currentHelpSellStatus: n.s,
        feedsImgDisplayType: n.as,
        showAllCoupon: !1,
        activityTypeText: "跟团",
        oneCreateHelpSellText: "一键帮卖",
        LOTTERY_STATUS: {
            ING: 0,
            END: 1
        },
        SUB_ACTIVITY_TYPE: n.cp,
        MIN_ALREADY_HELPSELL_COUNT: 5,
        CAN_MULTI_COPY_HS: s.tk,
        MARK_OTHER_INFO: s.xo,
        left: 0,
        FEEDS_TYPE: n.at,
        showSubActivityTag: !1,
        showCountDown: !1,
        showPopover: !1,
        feedsCardSkinObj: {},
        feedsHpV1G2: !1,
        feedsHPV3: !1,
        isSelf: !1,
        showCanHelpSell: !1,
        followerAvatarList: [],
        pageShow: !0
    },
    properties: {
        index: {
            type: Number,
            value: 0
        },
        lockSubStatus: {
            type: Boolean,
            value: !1
        },
        showSearch: {
            type: Boolean,
            value: !1
        },
        longObserver: {
            type: Boolean,
            value: !1
        },
        locationSubscribeMessage: {
            type: Boolean,
            value: !1
        },
        rootTop: {
            type: Number,
            value: 0
        },
        item: {
            type: Object,
            value: null,
            observer: function(e) {
                var t = !1, a = this.data.activityTypeText, i = this.data.item || {}, o = i.subActivityType, c = i.prizeNos, u = void 0 === c ? [] : c, p = i.prizeDeco, d = void 0 === p ? {} : p, h = i.layoutInfo, v = void 0 === h ? [] : h, m = i.helpSellCopyActivity, f = void 0 === m ? {} : m, g = i.activityType, b = i.multiCopyHs, y = i.participantListV2, S = void 0 === y ? [] : y, w = i.ownerLiveInfo, _ = i.visitCount;
                o === n.cp.SIGN_UP ? (a = "报名", t = !0) : o === n.cp.LOTTERY ? (a = "抽奖", t = !0) : o === n.cp.TEST && (a = "测评", 
                t = !0);
                var T = 1 === (0, n.qh)(w, "status"), C = Object.values(d).filter(function(e) {
                    return "SKIN" === (0, n.qh)(e, "material.type");
                }).map(function(e) {
                    return e.material;
                }) || [];
                this.setData({
                    feedsCardSkinObj: C[0] || {}
                });
                var I = (0, n.qh)(d, "".concat(n.c.NEW_CAPTAIN_COURSES, ".level")), k = (0, n.qh)(d, "".concat(n.c.CARGO_GRADE, ".level")), E = v.includes("HP_V3"), P = (E ? S.length ? S : new Array(Math.min(_, 3)).fill("").map(function() {
                    return {
                        avatar: r(l)[0]
                    };
                }) : S).filter(function(e) {
                    return e.avatar;
                }).slice(0, 3).map(function(e) {
                    return {
                        avatar: e.avatar
                    };
                });
                this.setData({
                    showDoubleTwelveSkin: u.indexOf(n.c.DOUBLE_TWELVE_2021) >= 0,
                    showOctSkin: u.indexOf(n.c.OCT_2021) >= 0,
                    showAnni2021Skin: u.indexOf(n.c.ANNI_2021) >= 0,
                    showNewCaptainSkin: [ n.bo.RECEIVE_BOTH, n.bo.RECEIVE_FEEDS_SKIN ].includes(I),
                    showAvatarExplodeSysmbol: [ n.bo.RECEIVE_BOTH, n.bo.RECEIVE_FEEDS_SKIN ].includes(I),
                    showCargoGradeFour: n.o.FOUR.includes(k),
                    showCargoGradeSix: n.o.SIX.includes(k),
                    showSubActivityTag: t,
                    activityTypeText: a,
                    isSelf: (this.$getCurrentProxyUserNo() || (0, n.ln)()) === e.ownerUserNo,
                    feedsHpV1G2: v.includes("HP_V1_G2"),
                    feedsHPV3: E,
                    showCanHelpSell: f.status === this.data.HELP_SELL_STATUS.CAN_COPY && (n.b.DISTRIBUTION === g || s.tk.SECOND === b),
                    originFollowerAvatarList: P,
                    ownerIsLiving: T
                });
            }
        },
        trackingInfo: {
            type: Object,
            value: null
        },
        showTopIcon: {
            type: Boolean,
            value: !1
        },
        showVipTag: {
            type: Boolean,
            value: !1
        },
        showMoreOp: {
            type: Boolean,
            value: !1
        },
        showAuthor: {
            type: Boolean,
            value: !0
        },
        showSubscribe: {
            type: Boolean,
            value: !1
        },
        feedsItemStyle: {
            type: String,
            value: ""
        },
        hadPromiseTag: {
            type: Boolean,
            value: !1
        },
        showHelpSellPublicPraiseTips: {
            type: Boolean,
            value: !1
        },
        tab: {
            type: String,
            value: ""
        },
        cateId: {
            type: String,
            value: ""
        },
        noFollowerList: {
            type: Boolean,
            value: !1
        },
        noBottomBar: {
            type: Boolean,
            value: !1
        },
        noAvatarLink: {
            type: Boolean,
            value: !1
        },
        isFromCaptain: {
            type: Boolean,
            value: !1
        },
        isHelpSellTab: {
            type: Boolean,
            value: !1
        },
        showFeedsOp: {
            type: Boolean,
            value: !1
        },
        showCollectBtn: {
            type: Boolean,
            value: !1
        },
        showHelpSellSelfGroup: {
            type: Boolean,
            value: !1
        },
        showActivityBuyBtn: {
            type: Boolean,
            value: !1
        },
        showShareBtn: {
            type: Boolean,
            value: !0
        },
        hasDiscoverTab: {
            type: Boolean,
            value: !1
        },
        followTemplateData: {
            type: Object,
            value: {}
        },
        lockSubStatusInited: {
            type: Boolean,
            value: !1
        }
    },
    lifetimes: {
        ready: function() {
            var e = this;
            return o(i.default.mark(function t() {
                var a, o, r, l;
                return i.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, a = e.data, o = a.item, r = a.showHelpSellPublicPraiseTips, !(0, 
                        n.qh)(o, "showWordMouthTips") || !r) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 6, (0, s.alc)({
                            $this: e,
                            selector: ".promise-tag",
                            field: "left"
                        });

                      case 6:
                        l = t.sent, e.setData({
                            left: l - 51
                        });

                      case 8:
                        "一键帮卖", o.feedsType === n.at.COMBINATION && (e.swiperTimes = 0, e.getRandomSwiper()), 
                        e.setData({
                            oneCreateHelpSellText: "一键帮卖",
                            notShowLiveTag: ((e.$currentPage || {}).pageProperties || {}).page_sn === s.wy.page_sn
                        }), t.next = 16;
                        break;

                      case 13:
                        t.prev = 13, t.t0 = t.catch(0), e.$error({
                            e: t.t0,
                            msg: "feedsItem ready error",
                            data: {
                                list: (0, n.qh)(e.$currentPage, "data.listData")
                            }
                        });

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 0, 13 ] ]);
            }))();
        }
    },
    pageLifetimes: {
        show: function() {
            this.data.item.feedsType === n.at.COMBINATION && this.setData({
                pageShow: !0
            });
        },
        hide: function() {
            this.data.item.feedsType === n.at.COMBINATION && this.setData({
                pageShow: !1
            }), this.clearCombinationTimeout();
        }
    },
    methods: {
        swiperChange: function() {
            var e = this.swiperTimes;
            this.swiperTimes++, (e + 1) % 2 == 0 && this.getRandomSwiper();
        },
        getRandomSwiper: function() {
            var e = [ Math.floor(500 * Math.random() + 500), Math.floor(300 * Math.random() + 200), Math.floor(5 * Math.random() + 1) ], t = this.data.item.isBTab ? [ "".concat(e[0], "人在1秒前开团"), "".concat(e[1], "人在").concat(e[2], "秒前上新团购") ] : [ "".concat(e[0], "人正在一起逛"), "".concat(e[1], "人在").concat(e[2], "秒前下单"), "".concat(e[1], "人在").concat(e[2], "秒前付款") ];
            this.setData({
                helpSellSwiperList: t
            });
        },
        handleClick: function(e) {
            var t = this.data, a = t.item, i = t.HELP_SELL_STATUS, o = t.activityType;
            (0, n.qh)(this.$currentPage, "_needJumpActivity") && e.mark && (Object.assign(e.mark, {
                logpv_log_id: (0, n.qh)(this.$currentPage, "$pvLogID"),
                logis_activity_back: 1
            }), (0, n.ev)({
                type: n.u.PV,
                tags: {
                    cp: "".concat((0, n.qh)(this.$currentPage, "pageProperties.page_name"), "_pv_activity_click")
                }
            })), this.standardLogClick(e), this.triggerEvent("onClick", a), a && a.helpSellCopyActivity && a.helpSellCopyActivity.status === i.CAN_COPY && o.DISTRIBUTION === a.activityType && this.refreshNextShow();
        },
        handleImpr: function(e) {
            (0, n.qh)(this.$currentPage, "_needJumpActivity") && e.mark && (Object.assign(e.mark, {
                logpv_log_id: (0, n.qh)(this.$currentPage, "$pvLogID"),
                logis_activity_back: 1
            }), (0, n.ev)({
                type: n.u.PV,
                tags: {
                    cp: "".concat((0, n.qh)(this.$currentPage, "pageProperties.page_name"), "_pv_activity_impr")
                }
            })), this.addCombinationTimeout(), this.standardImpr(e);
        },
        handleCardLeave: function() {
            this.clearCombinationTimeout();
        },
        addCombinationTimeout: function() {
            var e = this;
            this.data.enableSimilarRec && (this.addCombinationTimeout = setTimeout(function() {
                e.addCombinationFeedsList(2);
            }, 5e3));
        },
        clearCombinationTimeout: function() {
            this.addCombinationTimeout && clearTimeout(this.addCombinationTimeout);
        },
        handleOwnerClick: function() {
            var e = this.data.item || {}, t = this.data, i = t.trackingInfo, o = t.noAvatarLink, r = t.ownerIsLiving, l = t.notShowLiveTag, c = t.hasDiscoverTab, u = r && l;
            if (!o) if (i && (0, n.g0)({
                page_el_sn: i.feedsOwnerEle,
                extParams: {
                    is_live: u
                }
            }), u) if (c) {
                var p, d, h = {
                    type: s.u8.live
                };
                h.liveInfo = (null == e ? void 0 : e.ownerLiveInfo) || {};
                var v = e.isAdmin, m = e.ownerNickName, f = e.ownerAvatar, g = e.isSubscribe, b = e.ownerUserNo;
                h.ownerInfo = {
                    isAdmin: v,
                    ownerNickName: m,
                    ownerAvatar: f,
                    isSubscribe: g,
                    ownerUserNo: b
                }, null === (p = this.$currentPage) || void 0 === p || p.$eventChannel.cancel(n.f1.setVideoSwiperFeedsParams), 
                null === (d = this.$currentPage) || void 0 === d || d.$eventChannel.emitPromise(n.f1.setVideoSwiperFeedsParams, h), 
                (0, n.n3)({
                    url: n.ob.videoSwiper
                });
            } else {
                var y, S = null == e || null === (y = e.ownerLiveInfo) || void 0 === y ? void 0 : y.roomId;
                S && (0, n.n3)({
                    url: n.ob.liveRoom,
                    params: a({}, n.gf.roomId, S)
                });
            } else e && e.ownerUserNo && (0, n.n3)({
                url: n.ob.captain,
                params: a({}, n.gf.userNo, e.ownerUserNo)
            });
        },
        handleSubscribeChange: function(e) {
            var t = (0, n.jo)(e).isFollow, a = this.data.item;
            a.isSubscribe = t, this.setData({
                item: a
            });
            var i = this.data.trackingInfo;
            i && (0, n.g0)({
                page_el_sn: i.feedsSubscribeEle,
                extParams: {
                    is_subscribe: !!t
                }
            });
        },
        doShare: function(e) {
            this.standardLogClick(e), this.triggerEvent("onShare", this.data.item);
        },
        moreOperate: function(e) {
            this.triggerEvent("moreOperate");
        },
        move: function() {},
        onSubscribeImpr: function() {
            var e = this.data, t = e.trackingInfo, a = e.item;
            t && !a.isSubscribe && (0, n.l6)({
                page_el_sn: t.feedsSubscribeEle
            });
        },
        onSubscribeShowImpr: function() {
            var e = this.data, t = e.trackingInfo, a = e.item, i = e.lockSubStatus;
            t && (!i || i && !a.isSubscribe) && (0, n.l6)({
                page_el_sn: t.feedsSubscribeEle,
                extParams: {
                    is_subscribe_msg_show: !0
                }
            });
        },
        showPublicPraise: function(e) {
            var t = (0, n.jo)(e).userNo;
            this.standardLogClick(e), this.triggerEvent("handleShowPublicPraise", {
                userNo: t
            });
        },
        onCollect: function() {
            var e = this.data, t = e.item, a = e.index;
            this.triggerEvent("onCollect", {
                item: t,
                index: a
            });
        },
        handleToHelpSellAct: function() {
            var e = this.data.item;
            (0, n.n3)({
                url: n.ob.chainDetail,
                params: a({}, n.gf.collectionActivityNo, e.helpSellCopyActivity.helpSellActivityNo)
            });
        },
        handleShowPopover: function() {
            this.setData({
                showPopover: !this.data.showPopover
            });
        },
        handleBlackGroup: function() {
            var e = this.data, t = e.item, a = e.index;
            this.triggerEvent("handleBlackGroup", {
                ownerUserNo: t.ownerUserNo,
                index: a
            });
        },
        handleBuyGoods: function(e) {
            this.standardLogClick(e), this.triggerEvent("onClick", t(t({}, this.data.item), {}, {
                jumpToGoods: !0
            }));
        },
        changeSubscribeGuide: function(e) {
            var t = (0, n.jo)(e).showSubscribeGuide;
            this.setData({
                showSubscribeGuide: t
            });
        },
        updateFeedsItemStart: function() {
            this.triggerEvent("updateFeedsItemEvent", {
                collectionActivityNo: this.data.item.activityNo,
                updateItemData: {
                    notStarted: !1
                }
            });
        }
    }
});