var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), r = require("../../$page"), a = require("../../$app");

(0, r.afb)({
    behaviors: [ r.afv, (0, r.afu)({
        mapState: {
            bUserInfo: a.er
        }
    }) ],
    code: "",
    properties: {
        isHelpSell: {
            type: Boolean,
            value: !0,
            observer: function(e) {
                this.setData({
                    checkItems: e ? a.b0 : a.bz
                });
            }
        },
        bigClass: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        checkItems: a.b0,
        kttIsAgree: !1,
        confirmOpenType: "getPhoneNumber",
        notAgreeToast: ""
    },
    lifetimes: {
        ready: function() {
            var a = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, r.anq)();

                      case 2:
                        a.code = e.sent;

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        checkboxChange: function(e) {
            var t = (0, a.jo)(e), r = t.value, n = t.notAgreeToast;
            this.setData({
                kttIsAgree: r,
                notAgreeToast: n,
                confirmOpenType: r ? "getPhoneNumber" : ""
            });
        },
        confirm: function() {
            var e = this.data, t = e.kttIsAgree, r = e.notAgreeToast;
            t || this.$showToast({
                title: r
            });
        },
        updateAndCreateCount: function(n) {
            var s = this;
            return t(e.default.mark(function t() {
                var o, c, u, i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s.reportGetPhoneNumberSuccess(n, r.v5.HS_ITEM), e.next = 3, s.updateAndCreateCountByAuth(n);

                      case 3:
                        if (e.sent) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        if (o = !s.$getCurrentProxyUserNo(), c = s.data, u = c.checkItems, i = c.bUserInfo, 
                        e.prev = 7, !((0, a.fj)(s.data.checkItems, i).length > 0)) {
                            e.next = 16;
                            break;
                        }
                        if (!o) {
                            e.next = 14;
                            break;
                        }
                        return e.next = 12, (0, a.rq)({
                            protocols: u
                        });

                      case 12:
                        e.next = 16;
                        break;

                      case 14:
                        return e.next = 16, (0, a.ea)({
                            protocols: u
                        });

                      case 16:
                        e.next = 20;
                        break;

                      case 18:
                        e.prev = 18, e.t0 = e.catch(7);

                      case 20:
                        s.triggerEvent("success");

                      case 21:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 7, 18 ] ]);
            }))();
        }
    }
});