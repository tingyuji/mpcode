var e = require("../../$page");

(0, e.afb)({
    options: {
        multipleSlots: !0
    },
    externalClasses: [ "item-class", "item-left-class", "item-right-class", "item-content-class" ],
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                var t = this.data.baseFontSize, a = (e.couponAmountYuan || "").length, s = Math.max(a - 3, 0), o = e.effectiveTimeEnd - Date.now() < 864e5;
                this.setData({
                    fontSize: t - 6 * s,
                    subFontSize: Math.ceil(.61 * t) - 4 * s,
                    showCountDown: o
                });
            }
        },
        baseFontSize: {
            type: Number,
            value: 60
        },
        style: {
            type: String,
            value: "white"
        },
        isPenaltyCoupon: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        COUPON_STATUS: e.t9,
        fontSize: 60,
        subFontSize: 40,
        showCountDown: !1
    },
    methods: {}
});