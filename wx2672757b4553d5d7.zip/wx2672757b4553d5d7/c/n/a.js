(0, require("../../$page").afb)({
    properties: {
        size: {
            type: Number,
            value: 72
        },
        showText: {
            type: Boolean,
            value: !0
        },
        noAnim: {
            type: Boolean,
            value: !1
        }
    }
});