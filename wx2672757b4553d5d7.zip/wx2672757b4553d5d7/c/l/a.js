var e = require("../../_/helpers/interopRequireDefault"), a = require("../../_/helpers/defineProperty"), t = require("../../$app"), r = e(require("@pdd/std-format")), s = require("../../$page");

(0, s.afb)({
    pageLifetimes: {
        show: function() {
            this.initData();
        }
    },
    behaviors: [ (0, s.afu)({
        mapState: {
            fifthGameRank: t.hx
        }
    }) ],
    data: {
        isIndex: !1
    },
    methods: {
        initData: function() {
            var e, a = (null === (e = this.$currentPage) || void 0 === e ? void 0 : e.pageProperties.page_name) === s.wy.page_name;
            this.setData({
                isIndex: a
            }), this.$baseRequest({
                url: "/api/ktt_gameplay/season/sales_rank/entry/query",
                convertToCamel: !0,
                noNeedProxy: !!a
            }).then(function(e) {
                var a = e.result, s = a.hasEntry, i = a.status, n = a.hasAdmissionTicket, u = a.leaderSalesData, o = (u = void 0 === u ? {} : u).currGmv, p = void 0 === o ? 0 : o, d = u.nextStageGmv, l = void 0 === d ? 0 : d, c = u.currBonus, f = u.nextStageBonus;
                (0, t.hk)((0, t.qu)({
                    fifthGameRank: {
                        hasEntry: s,
                        status: i,
                        hasAdmissionTicket: n,
                        leaderSalesData: {
                            diffGmvYuan: parseInt(r.default.price(l - p, 100), 10),
                            currGmvYuan: parseInt(r.default.price(p, 100), 10),
                            nextStageGmvYuan: parseInt(r.default.price(l, 100), 10),
                            currBonusYuan: parseInt(r.default.price(c, 100), 10),
                            nextStageBonusYuan: parseInt(r.default.price(f, 100), 10)
                        }
                    }
                }));
            });
        },
        handleToActivity: function() {
            var e = this.data.isIndex;
            this.$click({
                page_el_sn: e ? 7992841 : 7992889
            }), (0, t.n3)({
                url: t.fs.summerRankActivity,
                params: e ? a({}, t.gf.sceneUserNo, (0, t.ln)()) : {}
            });
        }
    }
});