var e = require("../../_/helpers/interopRequireDefault");

require("../../_/helpers/Objectvalues");

var t = e(require("../../_/regenerator")), a = require("../../_/helpers/asyncToGenerator"), r = require("../../$page"), n = require("../../$app");

(0, r.afb)({
    behaviors: [ r.afv ],
    properties: {
        checkItems: {
            type: Array,
            value: n.bz,
            observer: function(e, t) {
                e.length === t.length && (e || []).every(function(e) {
                    return (t || []).includes(e);
                }) || this.updateStatus();
            }
        },
        wrapStyle: {
            type: String,
            value: ""
        },
        checkboxStyle: {
            type: String,
            value: ""
        },
        agreementTextStyle: {
            type: String,
            value: ""
        },
        checked: {
            type: Boolean,
            value: !1
        },
        bigClass: {
            type: Boolean,
            value: !1
        },
        signProtocolToastMap: {
            type: Object,
            value: {}
        }
    },
    data: {
        protocolStaus: {},
        showStaus: !1,
        PROTOCOL_NAME: n.b2,
        toast: "",
        hasChecked: !1
    },
    lifetimes: {
        attached: function() {
            this.updateStatus();
        }
    },
    methods: {
        updateStatus: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var r, o, s, c, u, h, i, l;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.$currentPage) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return t.next = 4, e.getBUserDataInfo();

                      case 4:
                        if (e.bUserInfo = t.sent, r = e.data, o = r.checkItems, s = r.signProtocolToastMap, 
                        c = void 0 === s ? {} : s, u = "", o && 0 !== o.length && e.bUserInfo) {
                            t.next = 10;
                            break;
                        }
                        return e._checkboxChange(!0), t.abrupt("return");

                      case 10:
                        h = {}, i = (0, n.fj)(o, e.bUserInfo), o.forEach(function(t) {
                            var a = !!e.bUserInfo[n.os[t]], r = !a && c[t];
                            h[t] = a, !r || r.only && 1 !== i.length || (u = r.text);
                        }), l = Object.values(h).some(function(e) {
                            return !e;
                        }), e.setData({
                            protocolStaus: h,
                            showStaus: l,
                            toast: u
                        }), e._checkboxChange(!l);

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        read: function(e) {
            var t = (0, n.jo)(e).type;
            (0, n.p3)(t);
        },
        checkboxChange: function() {
            var e = !this.data.checked;
            this.setData({
                checked: e,
                hasChecked: !0
            }), this._checkboxChange(e);
        },
        _checkboxChange: function(e) {
            var t = this.data.checkItems, a = (0, n.fj)(t, this.bUserInfo);
            this.triggerEvent("checkboxChange", {
                value: e,
                notAgreeToast: "请阅读并同意".concat(n.b2[a[0]]).concat(a.length > 1 ? "等" : ""),
                needAgreeProtocols: a
            });
        }
    }
});