var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), r = require("../../$app"), a = require("../../$page"), s = 2;

(0, a.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.init();
            }
        },
        userList: {
            type: Array,
            value: []
        },
        hadSelectConvIdList: {
            type: Array,
            value: []
        }
    },
    data: {
        csUserNoList: [],
        selectIdx: -1
    },
    methods: {
        init: function() {
            var r = this;
            return t(e.default.mark(function t() {
                var a, n, c;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return r.setData({
                            selectIdx: -1
                        }), e.next = 3, r.$baseRequest({
                            url: "/api/ktt_chat/cs_manager/granted/role/list",
                            noErrorToast: !0,
                            convertToCamel: !0,
                            convertRequestToSnake: !0,
                            data: {
                                roleTypes: [ s ]
                            }
                        }).catch();

                      case 3:
                        a = e.sent, n = a.result, c = n && n.csManagerRoleMap ? n.csManagerRoleMap[s] : [], 
                        r.setData({
                            csUserNoList: c
                        });

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        selectUser: function(e) {
            var t = (0, r.jo)(e).idx;
            this.setData({
                selectIdx: t === this.data.selectIdx ? -1 : t
            });
        },
        confirm: function() {
            var s = this;
            return t(e.default.mark(function t() {
                var n, c, o, i, u, l, f, h;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = s.data, c = n.selectIdx, o = n.csUserNoList, i = n.userList, u = n.hadSelectConvIdList, 
                        !(c < 0)) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        if (l = o[c].userNo, !(0, r.mq)(l)) {
                            e.next = 6;
                            break;
                        }
                        return e.abrupt("return", s.$showToast({
                            title: "无法将会话转移给自己",
                            icon: "none"
                        }));

                      case 6:
                        return e.prev = 6, e.next = 9, s.$baseRequest({
                            url: "/api/ktt_chat/conv_transfer/manual_move_out_convs",
                            noErrorToast: !0,
                            convertToCamel: !0,
                            convertRequestToSnake: !0,
                            data: {
                                targetCsUserNo: l,
                                visitorUserNoList: i
                            }
                        });

                      case 9:
                        if (f = e.sent, !f.success) {
                            e.next = 16;
                            break;
                        }
                        return e.next = 14, (0, a.amv)({
                            title: "转移成功",
                            icon: "none"
                        });

                      case 14:
                        "ktt_chat_detail" === (h = (0, r.qh)(s.$currentPage, "pageProperties.page_name")) ? (s.triggerEvent("closePanel"), 
                        r.f9.cancel(r.f1.refreshChatCenterList), r.f9.listen(r.f1.refreshChatCenterList, function() {
                            s.triggerEvent("transferChatSuccess", {
                                hadSelectConvIdList: u
                            }), r.f9.cancel(r.f1.refreshChatCenterList);
                        }), (0, r.ny)()) : "ktt_chat_center" === h && (s.triggerEvent("closePanel"), s.triggerEvent("transferChatSuccess", {
                            hadSelectConvIdList: u
                        }));

                      case 16:
                        e.next = 21;
                        break;

                      case 18:
                        e.prev = 18, e.t0 = e.catch(6), s.$showToast({
                            title: "转移失败，请重试",
                            icon: "none"
                        });

                      case 21:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 6, 18 ] ]);
            }))();
        },
        handleClose: function() {
            this.triggerEvent("closePanel");
        }
    }
});