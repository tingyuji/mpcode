var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), t = require("../../../../_/helpers/asyncToGenerator");

Component({
    data: {},
    properties: {
        isCreate: {
            type: Boolean,
            value: !1
        },
        isRestart: {
            type: Boolean,
            value: !1
        },
        subsidyInfo: {
            type: Object,
            value: {}
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            this.clickSubsidy();
        },
        acceptAndCreate: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!r.data.isRestart) {
                            e.next = 4;
                            break;
                        }
                        return r.triggerEvent("create"), e.abrupt("return");

                      case 4:
                        r.triggerEvent("create", {
                            redpacket: !0
                        });

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        acceptSubsidy: function() {
            var r = this;
            return t(e.default.mark(function t() {
                var a, n, i;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        a = r.data, n = a.isCreate, i = a.isRestart, n || i ? r.triggerEvent("close") : r.triggerEvent("create", {
                            redpacket: !1
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    }
});