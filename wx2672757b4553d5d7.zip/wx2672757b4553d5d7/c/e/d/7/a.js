var t = require("@ktt/ktt-wxapp-boundle"), e = require("../../../../$app"), o = require("../../../../$page"), i = t.utils.emptyFunction;

(0, o.afb)({
    properties: {},
    data: {
        qrCode: "https://commimg.pddpic.com/upload/ktt/a0.png.slim.png"
    },
    lifetimes: {
        attached: function() {
            this.getLeoConfig(), this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        getLeoConfig: function() {
            var t = this;
            (0, e.gr)().getConfig().then(function(e) {
                var o = (e || {}).officeGoodsLibraryQrCode, i = ((void 0 === o ? {} : o) || {}).value;
                i && t.setData({
                    qrCode: i
                });
            }).catch(i);
        },
        handleSaveImage: function() {
            var t = this.data.qrCode, o = void 0 === t ? "" : t;
            (0, e.qk)(o).catch(i);
        },
        handleClose: function() {
            this.triggerEvent("close");
        }
    }
});