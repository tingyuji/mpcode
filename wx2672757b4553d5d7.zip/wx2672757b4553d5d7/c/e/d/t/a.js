var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), r = require("../../../../_/helpers/objectSpread2"), t = require("../../../../_/helpers/asyncToGenerator"), n = require("../../../../$page"), a = require("../../../../$app");

(0, n.afb)({
    properties: {},
    lifetimes: {
        ready: function() {
            var n = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n.triggerEvent("onConfirmCommonToast"), e.next = 3, n.$showModal({
                            title: "开启主动申请帮卖",
                            content: "您当前未开启主动申请帮卖，开启后可赚更多佣金，建议开启哦",
                            confirmText: "确认开启",
                            showCancel: !1,
                            id: "openHelpSellDialog"
                        });

                      case 3:
                        e.sent.confirm && n.$baseRequest(r(r({}, a.sk), {}, {
                            data: {
                                allow_apply_help_sell_enable: !0
                            }
                        })).catch(a.hm), n.triggerEvent("close");

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        }
    }
});