Component({
    properties: {
        invitor: {
            type: String,
            value: ""
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        move: function() {}
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    }
});