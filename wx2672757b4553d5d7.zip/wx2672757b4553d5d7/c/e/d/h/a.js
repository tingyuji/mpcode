var t = require("../../../../$app");

(0, require("../../../../$page").afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {}
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleToActivity: function() {
            (0, t.n3)({
                url: t.fs.summerRankActivity
            });
        }
    }
});