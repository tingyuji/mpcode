(0, require("../../../../$page").afb)({
    properties: {
        activityNo: {
            type: String,
            value: ""
        }
    },
    data: {
        show: !1,
        showNoticeModal: !0,
        hasMore: !0
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        toggleChangeDetail: function() {
            this.setData({
                show: !this.data.show,
                showNoticeModal: !1
            });
        }
    }
});