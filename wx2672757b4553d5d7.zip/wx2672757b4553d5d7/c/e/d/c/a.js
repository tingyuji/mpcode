var e = require("../../../../_/helpers/interopRequireDefault"), r = require("../../../../_/helpers/toConsumableArray"), t = e(require("../../../../_/regenerator")), n = require("../../../../_/helpers/defineProperty"), a = require("../../../../_/helpers/asyncToGenerator"), i = require("../../../../$page"), s = require("../../../../$app");

(0, i.afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {},
            observer: function(e) {
                e && this.initData(e);
            }
        },
        userNo: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        ready: function() {
            var e = this;
            return a(t.default.mark(function r() {
                var a, o, u;
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return e.triggerEvent("onConfirmCommonToast"), a = (0, s.qh)(e.$currentPage, "pageProperties.page_sn"), 
                        o = a === i.tl.page_sn || a === i.sz.page_sn, r.next = 5, e.$showModal({
                            title: "恭喜成为帮卖团长",
                            confirmText: o ? "知道了" : "立即帮卖",
                            showCancel: !1,
                            id: "beHelpSellDialog"
                        });

                      case 5:
                        if (!r.sent.confirm) {
                            r.next = 13;
                            break;
                        }
                        if (u = e.data.ownerInfoList, !o) {
                            r.next = 12;
                            break;
                        }
                        return r.abrupt("return");

                      case 12:
                        1 === u.length ? (0, s.n3)({
                            url: s.ob.captain,
                            params: n({}, s.gf.userNo, u[0].userNo)
                        }) : (0, s.n3)({
                            url: s.ob.helpSellActivity
                        });

                      case 13:
                        e.triggerEvent("close");

                      case 14:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        }
    },
    methods: {
        initData: function(e) {
            var t = this, n = (e || {}).ownerInfoList, a = void 0 === n ? [] : n, i = a.map(function(e) {
                return e.avatar;
            }).slice(0, 4), s = a.map(function(e) {
                return e.nickName;
            }), o = a.length, u = "以下".concat(o, "个团长"), c = a.findIndex(function(e) {
                return e.userNo === t.data.userNo;
            }), l = a[-1 === c ? 0 : c].nickName;
            if (l.length > 10 && (l = l.substr(0, 10) + "…"), 1 === a.length) u = l; else if (-1 !== c) {
                var p = s.splice(c, 1);
                s.unshift.apply(s, r(p));
                var f = i.splice(c, 1);
                i.push.apply(i, r(f)), u = "".concat(l, "等").concat(o, "个团长");
            }
            this.setData({
                prefix: u,
                avatars: i,
                nickNames: s.join("、"),
                ownerInfoList: a
            });
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});