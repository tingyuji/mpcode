var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), t = require("../../../../_/helpers/asyncToGenerator"), r = require("../../../../$page"), n = require("../../../../$app");

(0, r.afb)({
    properties: {},
    data: {},
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        handleRead: function() {
            (0, n.p3)(n.b3.ktt_star_panelty);
        },
        handleSign: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, n.rr)([ n.b3.ktt_star_panelty ]);

                      case 2:
                        e.sent ? r.cancel() : r.$showToast({
                            title: "签署协议失败，请重试"
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        cancel: function() {
            this.triggerEvent("close");
        }
    }
});