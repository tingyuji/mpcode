var t = require("../../../../$app");

(0, require("../../../../$page").afb)({
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        cancel: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            (0, t.n3)({
                url: t.ob.unAppointmentOrderList
            }), this.cancel();
        }
    }
});