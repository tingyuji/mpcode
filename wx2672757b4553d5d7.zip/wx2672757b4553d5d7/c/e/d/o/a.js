var e = require("../../../../$app");

(0, require("../../../../$page").afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {}
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        handleConfirm: function() {
            this.triggerEvent("close"), (0, e.n3)({
                url: e.fs.helpSellRewardList
            });
        },
        handleClose: function() {
            this.triggerEvent("close");
        }
    }
});