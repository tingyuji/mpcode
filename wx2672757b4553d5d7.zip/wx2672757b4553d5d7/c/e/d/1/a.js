var t = require("../../../../_/helpers/interopRequireDefault"), e = require("../../../../$page"), i = require("../../../../$app"), r = t(require("@pdd/std-format"));

(0, e.afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: [],
            observer: function(t) {
                t && this.setData({
                    list: (t || []).map(function(t) {
                        var e = t.goodsPicList, a = t.activityTitle, o = t.goodsMaxPrice, n = t.goodsMinPrice, s = r.default.price(n, 100);
                        return {
                            goodsPicUrl: (0, i.qh)(e || [], "0.picUrl") || (0, i.jx)(),
                            activityTitle: a,
                            priceYuan: n === o ? s : s + "起"
                        };
                    })
                });
            }
        }
    },
    data: {
        list: []
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        cancel: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            (0, i.n3)({
                url: i.ob.starApplyLanding
            }), this.cancel();
        }
    }
});