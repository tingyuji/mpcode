var t = require("../../../../$app"), e = require("../../../../$page"), a = 4631045, i = 4631050, s = 4631073, r = 6686427;

(0, e.afb)({
    properties: {
        imageUrl: {
            type: String,
            value: ""
        },
        forwardUrl: {
            type: String,
            value: ""
        },
        width: {
            type: Number,
            value: 900
        },
        height: {
            type: Number,
            value: 1200
        },
        type: {
            type: Number,
            value: 0
        },
        activityToastId: {
            type: String,
            value: ""
        },
        showDownload: {
            type: Boolean,
            value: !1
        },
        showClose: {
            type: Boolean,
            value: !0
        },
        isPressScan: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        loaded: !1
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast"), this.$impr({
                page_el_sn: a,
                extParams: this._getExtParams()
            });
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close"), this.$click({
                page_el_sn: s,
                extParams: this._getExtParams()
            });
        },
        imgLoaded: function(t) {
            var e = t.detail || {}, a = e.width, i = void 0 === a ? 900 : a, s = e.height, r = void 0 === s ? 1200 : s;
            i > 960 && (r *= 960 / i, i = 960), r > 1500 && (i *= 1500 / r, r = 1500), this.setData({
                loaded: !0,
                width: i / 3 * 2,
                height: r / 3 * 2
            });
        },
        download: function() {
            var e = this;
            (0, t.qk)(this.data.imageUrl).then(function() {
                e.triggerEvent("close"), e.$click({
                    page_el_sn: r,
                    extParams: e._getExtParams()
                });
            }).catch(t.hm);
        },
        imgTapped: function() {
            if (!this.data.showDownload && !this.data.isPressScan) {
                var e = this.data.forwardUrl, a = 0 === e.indexOf("https://");
                if (0 === e.indexOf("/no_jump_forward") || !e) this.triggerEvent("onTapCommonToast"); else if (a) (0, 
                t.n4)({
                    path: e
                }); else {
                    if (wx.canIUse("showRedPackage")) {
                        var s = (0, t.oa)(e).rp_url || "";
                        if (s) return void wx.showRedPackage({
                            url: s
                        });
                    }
                    (0, t.n3)({
                        url: e
                    });
                }
                this.triggerEvent("close"), this.$click({
                    page_el_sn: i,
                    extParams: this._getExtParams()
                });
            }
        },
        _getExtParams: function() {
            var t = this.data, e = t.type, a = t.activityToastId, i = {
                type: e
            };
            return a && (i.pop_id = a), i;
        },
        handleLongPress: function() {
            this.data.isPressScan && this.$click({
                page_el_sn: i,
                extParams: this._getExtParams()
            });
        }
    }
});