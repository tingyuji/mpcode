var e = require("../../../../$app");

(0, require("../../../../$page").afb)({
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        cancel: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            this.triggerEvent("close"), (0, e.n3)({
                url: e.ob.erpAuthManage
            });
        }
    }
});