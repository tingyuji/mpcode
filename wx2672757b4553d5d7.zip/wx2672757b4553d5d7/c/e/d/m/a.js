var e = require("../../../../_/helpers/defineProperty"), t = require("../../../../$app");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        pullNewDataDialog: {
            type: Object,
            value: {}
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        goToRed: function() {
            this.triggerEvent("close"), (0, t.n3)({
                url: t.ob.redPacket,
                params: e({
                    obtain: !0
                }, t.gf.fromPullNewSuccess, 1)
            });
        }
    }
});