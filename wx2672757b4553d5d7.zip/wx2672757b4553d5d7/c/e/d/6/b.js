var o = require("../../../../_/helpers/defineProperty"), t = require("../../../../$page"), n = require("../../../../$app"), e = "groupDetailCouponToast", i = "expiredCouponToast";

(0, t.afb)({
    behaviors: [ t.agl ],
    properties: {
        bizToastData: {
            type: Object,
            value: {},
            observer: function(o) {
                o && this.initData(o);
            }
        },
        isExpiredCoupon: {
            type: Boolean,
            value: !0
        },
        isPenaltyCoupon: {
            type: Boolean,
            value: !1
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    data: {
        couponList: [],
        backGroundClass: "",
        buttonText: "去使用",
        aboveButtonText: "优惠券已放入您的快团团账户，下单可自动扣减",
        couponNum: 0
    },
    methods: {
        initData: function(o) {
            var n = this, e = o.couponList, i = void 0 === e ? [] : e, a = o.couponInfo, s = void 0 === a ? [] : a, p = (i.length > 0 ? i : s.length > 0 ? s : []).map(function(o) {
                return n.formatCoupon(o, t.t9.UNUSED, n.properties.isPenaltyCoupon);
            }), u = p.length;
            this.handleImpr(u);
            var r = this.data.isExpiredCoupon, c = r ? "去使用" : (this.properties.isPenaltyCoupon, 
            "立即使用");
            (r || this.properties.isPenaltyCoupon) && (u = (p = p.slice(0, 3)).length, r && (c = this.formatCouponButtonText(u))), 
            this.setData({
                couponList: p,
                backGroundClass: u > 3 ? "massive" : "num-".concat(u),
                buttonText: c,
                couponNum: u,
                isPenaltyCoupon: this.properties.isPenaltyCoupon,
                aboveButtonText: this.properties.isPenaltyCoupon ? "共".concat(u, "张优惠券已放入【个人中心-优惠券】") : this.data.aboveButtonText
            });
        },
        closeDialog: function() {
            this.triggerEvent("close");
        },
        handleImpr: function(o) {
            this.$impr({
                page_el_sn: t.ac7.dialogImpr,
                extParams: {
                    coupon_num: o,
                    toast_name: this.data.isExpiredCoupon ? i : e
                }
            });
        },
        onUseCoupon: function() {
            var o = this.data, a = o.couponList, s = o.isExpiredCoupon, p = o.couponNum;
            this.$click({
                page_el_sn: t.ac7.useCoupon,
                extParams: {
                    toast_name: s ? i : e
                }
            }), s && (1 === p ? this.jumpToCouponPage(a[0]) : (0, n.n3)({
                url: n.ob.couponCenter
            })), this.properties.isPenaltyCoupon && (0, n.n3)({
                url: n.ob.couponCenter
            }), this.triggerEvent("onUseCoupon");
        },
        tabArrowIcon: function(o) {
            var t = this.data.couponList, e = (0, n.jo)(o).index;
            this.jumpToCouponPage(t[e]);
        },
        jumpToCouponPage: function(t) {
            var e, i = t || {}, a = i.activityNo, s = i.ownerUserNo, p = i.isPointMallPhysicalCoupon, u = void 0 !== p && p, r = i.prizeNo;
            u && r ? (0, n.n3)({
                url: n.ob.pointGoodsDetail,
                params: (e = {}, o(e, n.gf.prizeNo, r), o(e, n.gf.userNo, s), e)
            }) : a ? (0, n.n3)({
                url: n.ob.activity,
                params: o({}, n.gf.collectionActivityNo, a)
            }) : s && (0, n.n3)({
                url: n.ob.captain,
                params: o({}, n.gf.userNo, s)
            });
        },
        formatCouponButtonText: function(o) {
            return t.t7[o - 1];
        }
    }
});