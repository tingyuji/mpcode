var e = require("../../../../_/helpers/interopRequireDefault"), t = e(require("../../../../_/regenerator")), r = require("../../../../_/helpers/asyncToGenerator"), i = require("../../../../_/helpers/objectSpread2"), s = require("../../../../$page"), n = e(require("@pdd/std-format")), o = require("../../../../$app"), a = 6687013, p = 6687014, u = 8060062, c = function(e) {
    var t = e.skuNumber;
    return i(i({}, e), {}, {
        goodsNameDesc: t > 1 ? "".concat(e.goodsName, "等").concat(t, "个商品") : "",
        parentGoodsAmountStr: n.default.price(e.parentGoodsAmount, 100),
        isLocalLifeOrder: e.subActivityType === o.cp.LOCAL_LIFE
    });
};

(0, s.afb)({
    properties: {
        orderData: {
            type: Object,
            value: {},
            observer: function(e) {
                this.initData(e);
            }
        }
    },
    data: {
        show: !1,
        CONFIRM_TYPE: {
            RECEIVED: 1,
            NOT_RECEIVED: 2,
            REFUND: 3
        },
        orderGoodsList: []
    },
    popUpId: "",
    submiting: !1,
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleClose: function() {
            this.$click({
                page_el_sn: u
            }), this.close();
        },
        onImpr: function() {
            this.$impr({
                page_el_sn: a,
                extParams: {
                    pop_up_id: this.popUpId,
                    order_sn_list: JSON.stringify(this.data.orderGoodsList.map(function(e) {
                        return e.parentOrderSn;
                    }))
                }
            });
        },
        initData: function(e) {
            var t = e.orderGoodsList, r = void 0 === t ? [] : t;
            r.length > 0 && (this.setData({
                show: !0,
                orderGoodsList: r.map(c)
            }), this.popUpId = (0, o.fz)());
        },
        handleSelect: function(e) {
            var t = (0, o.jo)(e), r = t.item, i = t.index, s = t.type;
            r.selectType === s ? r.selectType = "" : r.selectType = s;
            var n = this.data.orderGoodsList;
            n[i] = r, this.setData({
                orderGoodsList: n
            });
        },
        handleSubmit: (0, o.my)(r(t.default.mark(function e() {
            var r, n, o, a;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = this.data, n = r.orderGoodsList, o = r.orderData, this.$click({
                        page_el_sn: p,
                        extParams: {
                            pop_up_id: this.popUpId,
                            order_list: JSON.stringify(n.map(function(e) {
                                return {
                                    order_sn: e.parentOrderSn,
                                    operate_type: e.selectType || 4
                                };
                            }))
                        }
                    }), n.some(function(e) {
                        return !!e.selectType;
                    })) {
                        e.next = 6;
                        break;
                    }
                    return this.close(), e.abrupt("return");

                  case 6:
                    if (!this.submiting) {
                        e.next = 8;
                        break;
                    }
                    return e.abrupt("return");

                  case 8:
                    return this.submiting = !0, this.$showLoading({
                        delay: 1e3
                    }), a = n.filter(function(e) {
                        return e.selectType;
                    }).map(function(e) {
                        return {
                            parentOrderSn: e.parentOrderSn,
                            evaluationResult: e.selectType
                        };
                    }), e.next = 13, this.$baseRequest(i(i({}, s.aft), {}, {
                        data: {
                            orderEvaluationList: a,
                            checkType: o.checkType
                        }
                    })).catch(function() {});

                  case 13:
                    return this.$hideLoading(), this.submiting = !1, e.next = 17, (0, s.amv)({
                        title: "提交成功"
                    });

                  case 17:
                    this.close();

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })))
    }
});