var e = require("../../../../_/helpers/interopRequireDefault"), r = require("../../../../_/helpers/defineProperty"), t = e(require("../../../../_/regenerator")), a = require("../../../../_/helpers/objectSpread2"), n = require("../../../../_/helpers/asyncToGenerator"), s = require("../../../../$app"), c = require("../../../../$page"), u = 4376660, i = 4376658;

(0, c.afb)({
    properties: {
        organizer: {
            type: Object,
            value: {}
        },
        hasFollow: {
            type: Boolean,
            value: !1
        },
        isAcceptedRecoHelpSell: {
            type: Number,
            value: null
        }
    },
    data: {
        subscribeStatus: !0,
        mpArticleUrl: "",
        RECOMMEND_HELP_SELL: c.zv
    },
    lifetimes: {
        attached: function() {
            this.getSubscribeInfo(), this.handleImpr();
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleImpr: function() {
            var e = (this.$currentPage || {}).route || "";
            "/".concat(e) === s.ob.activity ? this.track_page_el_sn = u : "/".concat(e) === s.ob.captain && (this.track_page_el_sn = i), 
            this.track_page_el_sn && this.$impr({
                page_el_sn: this.track_page_el_sn
            });
        },
        getSubscribeInfo: function() {
            var e = this;
            return n(t.default.mark(function r() {
                var n, c, u, i;
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, (0, s.fy)(a({}, s.px)).catch(s.hm);

                      case 2:
                        (n = r.sent) && n.success && (c = n.result || {}, u = !!c.subscribeStatus, i = c.mpArticleUrl, 
                        e.setData({
                            subscribeStatus: u,
                            mpArticleUrl: i
                        }));

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        handleSubscribe: function() {
            var e = this;
            return n(t.default.mark(function r() {
                var n;
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (n = e.data.organizer.userNo) {
                            r.next = 3;
                            break;
                        }
                        return r.abrupt("return");

                      case 3:
                        return r.abrupt("return", (0, s.fy)(a(a({}, s.rw), {}, {
                            data: {
                                user_no: n,
                                type: 1
                            }
                        })));

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        jumpArticle: function() {
            var e = this.data.mpArticleUrl;
            e && (0, s.n3)({
                url: s.ob.mpArticle,
                params: r({}, s.gf.mpSrc, e)
            });
        },
        subscribe: function() {
            var e = this;
            return n(t.default.mark(function r() {
                var a, n, s;
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (r.prev = 0, e.track_page_el_sn && e.$click({
                            page_el_sn: e.track_page_el_sn
                        }), a = e.data, n = a.hasFollow, s = a.subscribeStatus, n) {
                            r.next = 8;
                            break;
                        }
                        return r.next = 6, e.handleSubscribe();

                      case 6:
                        return r.next = 8, (0, c.amv)({
                            title: "订阅成功",
                            icon: "none"
                        });

                      case 8:
                        s || e.jumpArticle(), e.triggerEvent("close", {
                            hasFollow: !0
                        }), e.triggerEvent("changeFollowStatus"), r.next = 15;
                        break;

                      case 13:
                        r.prev = 13, r.t0 = r.catch(0);

                      case 15:
                      case "end":
                        return r.stop();
                    }
                }, r, null, [ [ 0, 13 ] ]);
            }))();
        }
    }
});