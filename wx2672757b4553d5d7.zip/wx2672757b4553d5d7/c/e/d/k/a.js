var e = require("../../../../$page"), t = require("../../../../$app");

(0, e.afb)({
    properties: {
        info: {
            type: Object,
            value: {}
        }
    },
    data: {
        MONTH: [ "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" ]
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        handleClose: function() {
            this.triggerEvent("close");
        },
        goToInviteToMakeMoney: function() {
            this.handleClose(), (0, t.n3)({
                url: t.ob.inviteToMakeMoneyV3
            });
        }
    }
});