(0, require("../../../../$page").afb)({
    properties: {
        qrCodeUrl: {
            type: String,
            value: ""
        },
        width: {
            type: Number,
            value: 900
        },
        height: {
            type: Number,
            value: 1200
        },
        type: {
            type: Number,
            value: 0
        },
        showClose: {
            type: Boolean,
            value: !0
        },
        isPressScan: {
            type: Boolean,
            value: !1
        },
        qrCodeContainer: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        loaded: !1,
        qrCodeContainerUrl: "https://commimg.pddpic.com/upload/ktt/414415a3-a6c9-4b62-a5a6-e9c8e8564041.png.slim.png"
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        imgLoaded: function() {
            this.setData({
                loaded: !0,
                width: 262,
                height: 260
            });
        }
    }
});