var e = require("../../../../$page"), t = require("../../../../$app");

(0, e.afb)({
    properties: {
        extendNum: {
            type: Number,
            value: 0
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        cancel: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            (0, t.n3)({
                url: t.ob.starManageCenter
            }), this.cancel();
        }
    }
});