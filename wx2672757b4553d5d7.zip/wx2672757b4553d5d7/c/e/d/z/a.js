var a = require("../../../../$page"), t = require("../../../../$app");

(0, a.afb)({
    data: {
        showEnterDialog: !0,
        showGuideDialog: !1
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        },
        detached: function() {
            t.f9.cancel(t.f1.backExperStarCaptain);
        }
    },
    methods: {
        gotoExperStarCaptain: function() {
            var a = this;
            this.setData({
                showEnterDialog: !1
            }), t.f9.cancel(t.f1.backExperStarCaptain), t.f9.listenOnce(t.f1.backExperStarCaptain, function() {
                a.setData({
                    showGuideDialog: !0
                });
            }), t.f9.trigger(t.f1.goExperStarCaptain), (0, t.n3)({
                url: t.ob.todayStarCaptains
            });
        },
        handleClose: function() {
            this.triggerEvent("close");
        }
    }
});