var t = require("../../../../$page");

(0, t.afb)({
    behaviors: [ t.afo ],
    properties: {
        bizToastData: {
            type: Object,
            value: {}
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleConfirm: function() {
            var e = this, s = this.data.bizToastData || {}, a = s.startTs, i = s.endTs, o = s.loopEndTs, n = s.title, r = s.desc;
            if (!(a && i && o && n && r)) return this.close(), this.$showToast({
                title: "缺少关键参数，请稍后重试"
            });
            (0, t.aap)({
                startTime: a / 1e3,
                endTime: i / 1e3,
                repeatEndTime: o / 1e3,
                title: n,
                description: r,
                success: function() {
                    e.close(), e.setCloudStorage({
                        scene: t.aew.supplyTrainStartClass,
                        data: "1"
                    });
                }
            });
        }
    }
});