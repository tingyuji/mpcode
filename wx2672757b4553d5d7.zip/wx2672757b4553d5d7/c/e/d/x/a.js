var e, t = require("../../../../_/helpers/defineProperty"), i = require("../../../../$page"), n = require("../../../../$app"), r = 5, o = (t(e = {}, 4, "您的店铺存在风险，请提交相关材料资质审核"), 
t(e, r, "您的资质审核被驳回，请修改后重新提交"), e);

(0, i.afb)({
    properties: {
        content: {
            type: String,
            value: ""
        },
        type: {
            type: Number,
            value: 0,
            observer: function(e) {
                this.initData(e);
            }
        }
    },
    methods: {
        initData: function(e) {
            this.setData({
                content: o[e]
            });
        },
        close: function() {
            this.triggerEvent("close");
        },
        handleConfirm: function() {
            this.close(), (0, n.n3)({
                url: n.ob.riskCaptainReview
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    }
});