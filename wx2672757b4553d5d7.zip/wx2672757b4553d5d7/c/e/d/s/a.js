var e = require("../../../../$page"), t = require("../../../../$app");

(0, e.afb)({
    behaviors: [ e.akc ],
    data: {
        visible: !1,
        newcomerFreeActivityList: []
    },
    lifetimes: {
        attached: function() {
            this.queryNewcomerFreeActivityList();
        }
    },
    methods: {
        queryNewcomerFreeActivityList: function() {
            var e = this;
            return this.loadNewcomerFreeActivities().then(function(t) {
                (t = t.filter(function(e) {
                    return !e.isCopyHelpSelled;
                }).slice(0, 2)).length > 0 && (e.setData({
                    newcomerFreeActivityList: t,
                    visible: !0
                }), e.triggerEvent("onConfirmCommonToast"), e.$impr({
                    page_el_sn: "6190979"
                }));
            }).catch(t.hm);
        },
        gotoNewcomerFreeCreate: function() {
            this.$click({
                page_el_sn: "6190980"
            }), this.close(), (0, t.n3)({
                url: t.ob.newcomerFreeCreate
            });
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});