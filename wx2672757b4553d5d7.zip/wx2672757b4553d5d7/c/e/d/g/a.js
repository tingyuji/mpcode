var e = require("../../../../$page"), t = require("../../../../$app");

(0, e.afb)({
    properties: {
        info: {
            type: Object,
            value: {}
        },
        title: {
            type: String,
            value: ""
        },
        tip: {
            type: String,
            value: ""
        }
    },
    methods: {
        goToFinance: function() {
            this.close(), (0, t.n3)({
                url: t.ob.finance
            });
        },
        close: function() {
            this.triggerEvent("close");
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    }
});