var e = require("../../../../$app");

(0, require("../../../../$page").afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {},
            observer: function(e) {
                var t = e && e.dataList || [];
                this.setData({
                    brandList: t.map(function(e) {
                        return {
                            resourceSn: e.resourceSn,
                            brandPicture: e.brandPicture,
                            hotSell: e.isMustSell
                        };
                    }).slice(0, 6)
                });
            }
        }
    },
    data: {
        brandList: []
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        forwardOfficeLibrary: function() {
            this.close(), (0, e.n3)({
                url: e.ob.officeGoodsLibrary
            });
        }
    }
});