var e = require("../../../../_/helpers/defineProperty"), t = require("../../../../_/helpers/toConsumableArray"), i = require("../../../../$page"), r = require("../../../../$app");

(0, i.afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {},
            observer: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = e.latestBindUsers, r = void 0 === i ? [] : i;
                this.setData({
                    showLatestBindUsers: t(r).slice(0, 4)
                });
            }
        }
    },
    data: {
        showLatestBindUsers: []
    },
    lifetimes: {
        attached: function() {
            this.$impr({
                page_el_sn: i.ac6.dialog
            }), this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        handleClose: function() {
            this.triggerEvent("close");
        },
        handleInviteMore: function() {
            if (this.$click({
                page_el_sn: i.ac6.inviteBtnEle
            }), this.$currentPage && this.$currentPage.pageProperties.page_name === i.y_.page_name) return this.triggerEvent("close"), 
            void (0, r.n3)({
                url: r.ob.inviteToMakeMoneyV3,
                params: e({}, r.gf.isFromInviteSuccess, 1)
            });
            this.triggerEvent("close"), this.triggerEvent("onInviteMore");
        }
    }
});