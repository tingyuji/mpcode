var e = require("../../../../$page");

(0, e.afb)({
    properties: {
        canShare: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        inviteAction: e.w3
    },
    methods: {
        handleClose: function() {
            this.triggerEvent("close");
        },
        handleTapInvite: function() {
            this.$click({
                page_el_sn: e.ac5.inviteBtnEle
            }), this.triggerEvent("invite");
        }
    },
    lifetimes: {
        attached: function() {
            this.$impr({
                page_el_sn: e.ac5.dialog
            }), this.triggerEvent("onConfirmCommonToast");
        }
    }
});