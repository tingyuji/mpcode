var e = require("../../../../_/helpers/interopRequireDefault"), t = require("../../../../_/helpers/defineProperty"), r = require("../../../../$page"), i = require("../../../../$app"), a = e(require("@pdd/std-format"));

(0, r.afb)({
    properties: {
        order: {
            type: Object,
            value: {},
            observer: function(e) {
                this.initData(e);
            }
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        initData: function(e) {
            var t = this, o = e || {}, s = o.parentOrderSn, n = o.activityNo, c = o.payTimeout, d = o.goodsNumber, l = o.receiverName, u = o.receiverMobile, p = o.selfPickUpSiteName, v = o.expressType, h = o.orderAmount, f = o.subOrderList, m = void 0 === f ? [] : f, g = e.receiverAddressProvince + e.receiverAddressCity + e.receiverAddressDistrict + e.receiverAddressDetail;
            v === i.aq.mention && (g = p), this.setData({
                payTimeout: c,
                subOrderList: m,
                orderAmount: a.default.price(h, 100),
                goodsNumber: d,
                isMention: v === i.aq.mention,
                receiverName: l,
                receiverMobile: u,
                address: g,
                parentOrderSn: s,
                collectionActivityNo: n
            }), s && this.$impr({
                page_el_sn: 4959375
            }), (0, r.alm)({
                data: {
                    collectionActivityNo: n
                }
            }).then(function(e) {
                var r = e.result || {}, i = r.defaultAvatarList, a = r.salesTip;
                t.setData({
                    defaultAvatarList: i,
                    salesTip: a
                });
            }).catch(i.hm);
        },
        handleClose: function() {
            this.triggerEvent("close");
        },
        handlePay: function() {
            this._gotoPay(1);
        },
        handleGoodsClick: function() {
            this._gotoPay();
        },
        _gotoPay: function(e) {
            var r;
            this.triggerEvent("close"), this.$click({
                page_el_sn: 4959375
            }), (0, i.n3)({
                url: i.ob.toPayOrderDetail,
                params: (r = {}, t(r, i.gf.orderSn, this.data.parentOrderSn), t(r, i.gf.pullUpPay, e), 
                r)
            });
        },
        end: function() {
            this.triggerEvent("close"), (0, i.ri)({
                title: "订单已过期，请重新下单"
            });
        }
    }
});