var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), r = require("../../../../_/helpers/asyncToGenerator"), t = require("../../../../$page"), n = require("../../../../$app");

(0, t.afb)({
    properties: {},
    lifetimes: {
        ready: function() {
            var t = this;
            return r(e.default.mark(function r() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t.triggerEvent("onConfirmCommonToast"), e.next = 3, t.$showModal({
                            title: "设置推荐团长佣金",
                            confirmText: "去设置",
                            showCancel: !1,
                            id: "recoHelpSellDialog"
                        });

                      case 3:
                        e.sent.confirm && (0, n.n3)({
                            url: n.ob.setRecoCommison
                        }), t.triggerEvent("close");

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, r);
            }))();
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        }
    }
});