var t = require("../../../../_/helpers/defineProperty"), i = require("../../../../$page"), e = require("../../../../$app"), s = require("@ktt/ktt-wxapp-boundle").navigate.nvForward, r = Math.ceil((0, 
e.qf)(70));

(0, i.afb)({
    properties: {
        pageSn: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.setData({
                    canShare: 32988 === t
                });
            }
        },
        bizToastData: {
            type: Object,
            value: {},
            observer: function(t) {
                this.formatUVisitInfo(t);
            }
        }
    },
    data: {
        scrollHeight: 0,
        userList: [],
        maxScrollCnt: 0,
        canShare: !1,
        visitUserCnt: 0,
        isRepeat: !1,
        needCicle: !0
    },
    scrollTimes: 0,
    timoutTimer: null,
    methods: {
        handleClose: function() {
            this.triggerEvent("close");
        },
        formatUVisitInfo: function(t) {
            var s = this, r = t.visitUserCnt, a = t.freshFansVisitVOList, n = t.visitCnt, o = [];
            (null == a ? void 0 : a.length) > 5 && this.data.needCicle && (o = a.slice(0, 5));
            var l = a.concat(o).map(function(t) {
                var s = t.avatar, r = t.nickname, a = t.visitTime, n = t.visitCnt, o = (0, i.agy)(a), l = (0, 
                e.kt)(r, 2);
                return {
                    avatar: s,
                    visitLog: "".concat(l, "...").concat(o, "查看了团购"),
                    visitCnt: n,
                    userName: l + "...",
                    timeSpan: o
                };
            }), c = (null == l ? void 0 : l.length) - 5;
            this.setData({
                visitUserCnt: r || n,
                userList: l,
                maxScrollCnt: c
            }, function() {
                c > 0 && s.scroll();
            });
        },
        scroll: function() {
            var t = this, i = this.data, e = i.maxScrollCnt, s = i.needCicle;
            this.timoutTimer && clearTimeout(this.timoutTimer);
            var a = 0, n = !1, o = 0;
            (this.scrollTimes < e || s) && (this.scrollTimes < e ? (this.scrollTimes += 1, a = this.scrollTimes * r, 
            o = 1e3) : (this.scrollTimes = 0, n = !0), this.timoutTimer = setTimeout(function() {
                t.setData({
                    scrollHeight: a,
                    isRepeat: n
                });
            }, o));
        },
        handleClick: function() {
            var i = this.data.canShare;
            this.handleClose(), this.$click({
                page_el_sn: 7934382
            }), i || s({
                url: e.fs.myGroupMember,
                params: t({}, e.gf.newVisitorDialog, 1)
            });
        }
    },
    lifetimes: {
        created: function() {
            this.scrollTimes = 0, this.timoutTimer = null;
        },
        attached: function() {
            this.$impr({
                page_el_sn: 7934381
            }), this.triggerEvent("onConfirmCommonToast");
        },
        detached: function() {
            this.timoutTimer && clearTimeout(this.timoutTimer);
        }
    }
});