var e = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/defineProperty"), a = e(require("../../_/regenerator")), o = require("../../_/helpers/asyncToGenerator"), i = require("../../_/helpers/objectSpread2"), r = require("../../$app"), n = require("../../$page"), s = -1;

(0, n.afb)({
    behaviors: [ n.aa8, n.afr, n.amh, n.aky, n.age, n.ai_, n.ai9, n.aja, n.ak7, n.ak8, n.abi, n.abk, n.aj4, n.amg, n.ai4 ],
    properties: {
        pageSn: {
            type: Number,
            value: 0
        },
        organizer: {
            type: Object,
            value: {}
        },
        activityNo: {
            type: String,
            value: ""
        },
        serverTime: {
            type: String,
            value: ""
        }
    },
    data: {
        showHelpSellModal: !1
    },
    lifetimes: {
        attached: function() {
            if (this.getNoticeType = this.getNoticeType.bind(this), -1 !== s) {
                var e = Date.now() - s;
                if (e > 0 && e < 6e4) return;
            }
            s = Date.now(), this.cancelSignInListener = r.f9.listenOnce(r.f1.signIn, this.getNoticeType.bind(this));
        },
        detached: function() {
            this.cancelSignInListener && this.cancelSignInListener();
        }
    },
    methods: {
        resetLock: function() {
            s = -1;
        },
        _addTask: function(e, t, a) {
            var o = this;
            this.addTask(e, t, a, function(e) {
                -1 !== s && ((0, r.hp)({
                    msg: "commontToast lock frontend",
                    data: {
                        lastLockTs: s,
                        diff: Date.now() - s,
                        priority: e
                    }
                }), o.resetLock());
            });
        },
        getNoticeType: function() {
            var e = this, t = this.data, n = t.pageSn, s = t.organizer, c = t.activityNo;
            if (n) {
                var u = {
                    pageSn: n,
                    businessContext: {}
                };
                s && s.userNo && (u.browsedUserNo = s.userNo, u.businessContext.userNo = s.userNo), 
                c && (u.businessContext.activityNo = c), this.addTaskDependency(function() {
                    return e.$baseRequest(i(i({}, r.o9), {}, {
                        data: u
                    })).then(function() {
                        var t = o(a.default.mark(function t(o) {
                            var i;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return i = o && o.result || {}, t.next = 3, e.initStatus(i);

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }()).catch(function(t) {
                        e.resetLock(), (0, r.hp)({
                            e: t,
                            msg: "common toast fail"
                        });
                    });
                });
            }
        },
        initStatus: function(e) {
            var i = this;
            return o(a.default.mark(function o() {
                var s, c, u, l, p, d, f, m, g, T, b, y, h, v, D, k, _, N, I, S, E, A, x, P, w, C, L, B, U, z;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        s = e.type, c = e.activityToastInfo, u = void 0 === c ? {} : c, l = e.commonToastInfo, 
                        p = void 0 === l ? {} : l, d = e.genericToastResult, f = void 0 === d ? {} : d, 
                        s && i.setData({
                            type: s
                        }), a.t0 = s, a.next = a.t0 === n.ye.BE_ADMIN ? 5 : a.t0 === n.ye.RISK_MALL ? 8 : a.t0 === n.ye.PLATFORM_SUBSIDEY ? 11 : a.t0 === n.ye.HELP_SELL_REC ? 16 : a.t0 === n.ye.INVITE_WHITE_LIST ? 19 : a.t0 === n.ye.FEE_BACK ? 21 : a.t0 === n.ye.INVITE_AMOUNT_ARRIVE ? 24 : a.t0 === n.ye.INVITE_NEW_GROUP ? 27 : a.t0 === n.ye.POINT_GUIDE ? 32 : a.t0 === n.ye.ACTIVITY_TOAST ? 34 : a.t0 === n.ye.BUSSINESS_TOAST ? 36 : a.t0 === n.ye.ONLINE_PAY_FEE_BACK || a.t0 === n.ye.OFFLINE_PAY_FEE_BACK || a.t0 === n.ye.COVID_SH_APRIL_PAY_FEE_BACK ? 39 : a.t0 === n.ye.MODIFY_REAL_NAME ? 42 : a.t0 === n.ye.MODIFY_NAME_FAIL ? 44 : a.t0 === n.ye.RISK_CAPTAIN ? 47 : 50;
                        break;

                      case 5:
                        return (m = p.commonToastBody) && m.operatorName && i._addTask("facePopup", n.aex.beAdminNoticeDialog, function() {
                            i.setData({
                                beAdminNoticeDialog: {
                                    visible: !0,
                                    invitor: m.operatorName || ""
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 8:
                        return g = p.content, T = p.title, g && i._addTask("facePopup", n.aex.riskToastDialog, function() {
                            i.setData({
                                riskToastDialog: {
                                    visible: !0,
                                    title: T,
                                    content: g
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 11:
                        if (!(b = p.commonToastBody) || !b.totalBudgetAmount) {
                            a.next = 15;
                            break;
                        }
                        return a.next = 15, i.queryPlatFormSubsidyInfo();

                      case 15:
                        return a.abrupt("break", 52);

                      case 16:
                        return (y = p.commonToastBody) && y.operatorName && i._addTask("facePopup", n.aex.showHelpSellModal, function() {
                            try {
                                var e = i.data.organizer;
                                if (e && e.userNo) i.setData({
                                    showHelpSellModal: !0
                                }); else {
                                    var t = y.operatorName, a = "恭喜你成为".concat(t, "的帮卖团长点击团购活动即可帮卖赚佣金");
                                    (0, r.ri)({
                                        title: a,
                                        icon: "none"
                                    });
                                }
                                i.handleConfirm();
                            } catch (e) {
                                (0, r.hp)({
                                    e: e,
                                    msg: "common toast error,type = ".concat(n.ye.HELP_SELL_REC)
                                });
                            }
                        }), a.abrupt("break", 52);

                      case 19:
                        return i._addTask("facePopup", n.aex.inviteDialog, function() {
                            i.setData({
                                inviteDialog: {
                                    visible: !0
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 21:
                        return (h = p.commonToastBody) && h.feeAmount && h.month && i._addTask("facePopup", n.aex.feeBackDialog, function() {
                            i.setData({
                                feeBackDialog: {
                                    visible: !0,
                                    info: h
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 24:
                        return (v = p.commonToastBody) && v.feeAmount && v.month && i._addTask("facePopup", n.aex.inviteAmountArriveDialog, function() {
                            i.setData({
                                inviteAmountArriveDialog: {
                                    visible: !0,
                                    info: v
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 27:
                        return D = p.commonToastBody, k = void 0 === D ? {} : D, _ = JSON.parse(k.pullNewPopUpsInfo) || {}, 
                        N = _.pullNewNum, I = _.totalSubsidyAmountDesc, S = _.detailList, N && i._addTask("facePopup", n.aex.pullNewDataDialog, function() {
                            i.setData({
                                pullNewDataDialog: {
                                    visible: !0,
                                    pullNewNum: N,
                                    totalSubsidyAmountDesc: I,
                                    detailList: S
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 32:
                        return i._addTask("facePopup", n.aex.bigImgTemplateDialog, function() {
                            i.setData({
                                bigImgTemplateDialog: {
                                    visible: !0
                                },
                                imageUrl: "https://commimg.pddpic.com/upload/ktt/e.png.slim.png",
                                forwardUrl: "https://mobile.yangkeduo.com/promotion_op.html?type=49&id=163316"
                            });
                        }), a.abrupt("break", 52);

                      case 34:
                        return i._addTask("facePopup", n.aex.bigImgTemplateDialog, function() {
                            var e = u.imageUrl, t = u.jumpUrl, a = u.activityToastId, o = u.showDownload, r = void 0 !== o && o, n = u.showClose, s = void 0 === n || n, c = u.isPressScan, l = void 0 !== c && c;
                            i.setData({
                                bigImgTemplateDialog: {
                                    visible: !0
                                },
                                imageUrl: e,
                                forwardUrl: t,
                                activityToastId: a,
                                showDownload: r,
                                showClose: s,
                                isPressScan: l
                            });
                        }), a.abrupt("break", 52);

                      case 36:
                        return E = f.toastName, A = f.data, x = void 0 === A ? {} : A, P = f.extraKey, E in n.te && ("ABANDONED" === n.te[E] ? (i.setData({
                            bizToastName: E,
                            bizExtraKey: P
                        }), i.handleConfirm(), i.$error({
                            name: "abandoned toast",
                            msg: "bizToastName: ".concat(E, "; bizExtraKey: ").concat(P)
                        })) : "KTT_IMG_MODAL" === n.te[E] ? (w = x.toastImg, C = x.jumpUrl, i._addTask("facePopup", n.aex.bigImgTemplateDialog, function() {
                            i.setData({
                                bigImgTemplateDialog: {
                                    visible: !0
                                },
                                imageUrl: w,
                                forwardUrl: C,
                                showClose: !0,
                                bizToastName: E,
                                bizExtraKey: P
                            });
                        })) : "KTT_QR_MODAL" === n.te[E] ? (L = x.qrCodeUrl || "", i._addTask("facePopup", n.aex.qrCodeConnectDialog, function() {
                            i.setData({
                                qrCodeConnectDialog: {
                                    visible: !0
                                },
                                qrCodeUrl: L,
                                showClose: !0,
                                bizToastName: E,
                                bizExtraKey: P,
                                isPressScan: !!L,
                                qrCodeContainer: !!L
                            });
                        })) : "helpSellProtocol" === n.te[E] ? i._addTask("facePopup", n.aex.bizToast, function() {
                            i.setData({
                                bizToastName: E,
                                bizExtraKey: P
                            }), i.signHelpSellProtocol();
                        }) : i._addTask("facePopup", n.aex.bizToast, function() {
                            var e;
                            i.setData((t(e = {}, n.te[E], !0), t(e, "bizToastData", x), t(e, "bizToastName", E), 
                            t(e, "bizExtraKey", P), e));
                        })), a.abrupt("break", 52);

                      case 39:
                        return (B = p.commonToastBody) && B.feeAmount && B.month && i._addTask("facePopup", n.aex.newFeeBackDialog, function() {
                            i.setData({
                                newFeeBackDialog: {
                                    visible: !0,
                                    online: s === n.ye.ONLINE_PAY_FEE_BACK,
                                    info: B
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 42:
                        return i._addTask("facePopup", n.aex.modifyRealName, function() {
                            i.handleNoticeModifyName(), i.handleConfirm();
                        }), a.abrupt("break", 52);

                      case 44:
                        return U = p.commonToastBody, i._addTask("facePopup", n.aex.modifyRealName, function() {
                            i.handleNoticeModifyFail(U), i.handleConfirm();
                        }), a.abrupt("break", 52);

                      case 47:
                        return (z = p.commonToastBody.riskTextType) && i._addTask("facePopup", n.aex.riskCaptainDialog, function() {
                            i.setData({
                                riskCaptainDialog: {
                                    visible: !0,
                                    riskTextType: z
                                }
                            });
                        }), a.abrupt("break", 52);

                      case 50:
                        return i.resetLock(), a.abrupt("break", 52);

                      case 52:
                      case "end":
                        return a.stop();
                    }
                }, o);
            }))();
        },
        queryPlatFormSubsidyInfo: function() {
            var e = this;
            return o(a.default.mark(function t() {
                var o, i, s, c;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, (0, r.pp)();

                      case 2:
                        o = t.sent, i = o.result || {}, s = i.popUps, c = i.packetPopUpsVo, s && e._addTask("facePopup", n.aex.subsideyStrategyDialog, function() {
                            e.setData({
                                subsideyStrategyDialog: {
                                    visible: s,
                                    info: c || {}
                                }
                            });
                        });

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleConfirm: function() {
            var e = this;
            return o(a.default.mark(function t() {
                var o, s, c, u, l, p;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return o = e.data, s = o.type, c = o.activityToastId, u = o.bizToastName, l = o.bizExtraKey, 
                        p = {
                            type: s
                        }, s === n.ye.ACTIVITY_TOAST && (p.activityToastId = c), s === n.ye.BUSSINESS_TOAST && (p.toastName = u, 
                        p.extraKey = l), t.next = 6, (0, r.fy)(i(i({}, r.qs), {}, {
                            data: p
                        })).catch(r.hm);

                      case 6:
                        e.resetLock();

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleConfirmPlus: function(e) {
            var t = this;
            return o(a.default.mark(function o() {
                var i, n;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, t.handleConfirm();

                      case 2:
                        i = (0, r.jo)(e), n = i.queries, t.triggerEvent("onTapCommonToast", n);

                      case 4:
                      case "end":
                        return a.stop();
                    }
                }, o);
            }))();
        },
        handleBigImgTemplateTap: function() {
            var e = this.data.forwardUrl, t = void 0 === e ? "" : e, a = (0, r.oa)(t);
            this.triggerEvent("onTapCommonToast", a);
        },
        closeHelpSellDialog: function(e) {
            (e.detail || {}).hasFollow && this.triggerEvent("changeFollowStatus"), this.setData({
                showHelpSellModal: !1
            });
        },
        toGoodsLocation: function() {
            this.hideBizDialog(), this.triggerEvent("toGoodsLocation");
        },
        receiveGlobalFirstCouponSuccess: function() {
            this.triggerEvent("globalReceiveSuccess"), this.hideBizDialog();
        },
        handleUse: function() {
            this.hideBizDialog(), this.triggerEvent("onUseCoupon");
        },
        go2EditActivity: function() {
            this.triggerEvent("go2EditActivity");
        }
    }
});