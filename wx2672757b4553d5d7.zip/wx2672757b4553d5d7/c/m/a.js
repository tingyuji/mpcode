var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), r = require("../../$page"), n = require("../../$app"), o = 8076676;

(0, r.afb)({
    properties: {
        oldCaptain: {
            type: Boolean,
            value: !1
        },
        log: {
            type: Boolean,
            value: !1
        }
    },
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast"), this.properties.log && this.$impr({
                page_el_sn: o
            });
        }
    },
    methods: {
        handleRead: function() {
            (0, n.p3)(n.b3.ktt_helpsell);
        },
        handleSign: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r.properties.log && r.$click({
                            page_el_sn: o
                        }), r.$showLoading(), r.$getCurrentProxyUserNo()) {
                            e.next = 7;
                            break;
                        }
                        return e.next = 5, (0, n.rq)({
                            protocols: [ n.b3.ktt_helpsell ]
                        });

                      case 5:
                        e.next = 9;
                        break;

                      case 7:
                        return e.next = 9, (0, n.ea)({
                            protocols: [ n.b3.ktt_helpsell ]
                        });

                      case 9:
                        r.$hideLoading(), r.$showToast({
                            title: "签署成功"
                        }), r.triggerEvent("success");

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});