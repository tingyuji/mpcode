var e = require("../../_/helpers/interopRequireDefault"), t = require("../../$page"), o = require("../../$app"), i = e(require("@pdd/std-format")), a = 3771189, n = 5960048;

(0, t.afb)({
    properties: {
        mallCouponVO: {
            type: Object,
            value: {}
        },
        mallCouponEventInfo: {
            type: Object,
            value: {}
        },
        organizer: {
            type: Object,
            value: {}
        },
        globalDiscountInfo: {
            type: Object,
            value: {}
        },
        bizToastData: {
            type: Object,
            value: {},
            observer: function(e) {
                if (e && e.globalFirstDiscountInfo) {
                    var t = (e || {}).globalFirstDiscountInfo, o = this.data.globalDiscountInfo, a = t || {}, n = a.couponAmount, s = a.period;
                    o.couponAmountDesc = i.default.price(n || 0, 100), o.duration = "有效期".concat(s, "天"), 
                    this.setData({
                        globalDiscountInfo: o,
                        isGlobalDiscount: !0
                    });
                }
            }
        },
        inActivity: {
            type: Boolean,
            value: !1
        },
        isGlobalDiscount: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isGlobalDiscount: !1
    },
    ready: function() {
        var e = this.data, t = e.inActivity, i = e.isGlobalDiscount;
        (0, o.ev)({
            type: o.u.NEWER_DISCOUNT,
            tags: {
                newerDiscount: "".concat(i ? "global" : "activity", "-total")
            }
        }), this.$impr({
            page_el_sn: t ? a : n,
            extParams: {
                newer_coupon_type: Number(i)
            }
        });
    },
    methods: {
        receivePacket: function() {
            this.triggerEvent("success"), (0, o.ev)({
                type: o.u.NEWER_DISCOUNT,
                tags: {
                    newerDiscount: "activity-receive"
                }
            }), this.$click({
                page_el_sn: this.data.inActivity ? a : n,
                extParams: {
                    newer_coupon_type: 0
                }
            });
        },
        closeDialog: function() {
            this.triggerEvent("close");
        },
        handleReceiveGlobalDiscountCoupon: function() {
            var e = this, t = (this.data.organizer || {}).userNo;
            t && (this.$baseRequest({
                url: "/api/ktt_group/platform_subsidy/v2/global_first_discount/send_coupon",
                convertRequestToSnake: !0,
                convertToCamel: !0,
                data: {
                    ownerUserNo: t
                }
            }).then(function(t) {
                (0, o.ri)({
                    title: "领取成功",
                    icon: "none"
                }), e.triggerEvent("receiveSuccess");
            }).catch(function(t) {
                e.$error({
                    e: t,
                    msg: "receive global first coupon fail"
                });
            }), (0, o.ev)({
                type: o.u.NEWER_DISCOUNT,
                tags: {
                    newerDiscount: "global-receive"
                }
            }), this.$click({
                page_el_sn: this.data.inActivity ? a : n,
                extParams: {
                    newer_coupon_type: 1
                }
            }));
        }
    }
});