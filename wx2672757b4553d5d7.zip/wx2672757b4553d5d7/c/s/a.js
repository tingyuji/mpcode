var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    behaviors: [ e.acw ],
    externalClasses: [ "item-class" ],
    properties: {
        item: {
            type: Object,
            value: {}
        },
        index: {
            type: Number,
            value: 0
        },
        withCreateBtn: {
            type: Boolean,
            value: !1
        },
        skinClass: {
            type: String,
            value: "landing-page",
            observer: function(e) {
                "promote-dialog" !== e && "keep-dialog" !== e || this.setData({
                    goodsPicSize: 176
                });
            }
        },
        recUniversalSrc: {
            type: String,
            value: t.b6.newcomerOfficialFree
        },
        noPhoneInput: {
            type: Boolean,
            value: !1
        },
        isNewComerBenefit: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        goodsPicSize: 208
    },
    methods: {
        handleItemTap: function() {
            var i = this.data, a = i.withCreateBtn, l = i.item, r = i.index, n = i.isNewComerBenefit;
            if (this.triggerEvent("itemTap"), this.$click({
                page_el_sn: "6190152",
                extParams: {
                    newgroup_id: l.activityNo
                }
            }), a) {
                var o = l.activityNo, s = l.isCopyHelpSelled, p = l.helpSellActivityNo;
                s ? (0, e.ag3)(p, {
                    isSelf: !0
                }) : (n ? this.$click({
                    page_el_sn: e.ae4.newComerBenefitActivated,
                    extParams: {
                        index_btn: 3
                    }
                }) : this.$click({
                    page_el_sn: "6190154",
                    extParams: {
                        newgroup_id: o
                    }
                }), this.handleCreateHelpSell({
                    detail: {
                        activityNo: o,
                        requestParams: {
                            is_newbie_official_help_sell: !0
                        },
                        logActivityNo: o,
                        logKttIdx: r
                    }
                }));
            } else (0, t.n3)({
                url: t.ob.newcomerFreeCreate
            });
        },
        handleItemImpr: function(e) {
            var i = (0, t.jo)(e).log;
            i && this.$impr({
                page_el_sn: i,
                extParams: {
                    newgroup_id: this.data.item.activityNo
                }
            });
        }
    }
});