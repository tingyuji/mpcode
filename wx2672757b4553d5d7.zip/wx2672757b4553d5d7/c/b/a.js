var e, t, i = require("../../_/helpers/interopRequireDefault"), r = require("../../_/helpers/defineProperty"), a = require("../../$app"), n = require("../../$page"), o = i(require("@pdd/std-format")), c = {
    IMAGE_AND_CONTENT: 1,
    GOODS_COMMISION: 2,
    SKU_PRICE: 3,
    ACTIVITY_TIME: 4,
    FULL_REDUCTION: 5,
    ADD_SKU: 6,
    DELETE_SKU: 9,
    OFF_SHELVE_BY_COMMISSION: 14,
    FREE_RESOURCE_PRICE_CHANGE: 15,
    OFF_SHELVE_BY_RESOURCE_CLOSE: 16,
    MIN_BUY: 17,
    SKU_CHANGE_BATCH: 19
}, s = (r(e = {}, c.IMAGE_AND_CONTENT, "商品图文"), r(e, c.GOODS_COMMISION, "商品佣金"), 
r(e, c.FULL_REDUCTION, "团优惠"), r(e, c.SKU_PRICE, "商品控价"), r(e, c.ACTIVITY_TIME, "团售卖时间"), 
r(e, c.ADD_SKU, "规格新增"), r(e, c.DELETE_SKU, "规格失效"), r(e, c.OFF_SHELVE_BY_COMMISSION, "商品下架"), 
r(e, c.FREE_RESOURCE_PRICE_CHANGE, "供货价调整"), r(e, c.OFF_SHELVE_BY_RESOURCE_CLOSE, "资源位关闭"), 
r(e, c.MIN_BUY, "团起购调整"), r(e, c.SKU_CHANGE_BATCH, "商品替换"), e), d = {
    ACTIVITY_CHANGE: 4,
    PLAY_MONEY: 9,
    PRICE_CHANGE: 11
}, u = (r(t = {}, d.ACTIVITY_CHANGE, "变更明细"), r(t, d.PLAY_MONEY, "小额打款详情"), r(t, d.PRICE_CHANGE, "变更明细"), 
t), p = {
    1: "仅首次跟团需达到",
    2: "每次跟团需达到"
};

(0, n.afb)({
    pageNumber: 1,
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.data.type === d.ACTIVITY_CHANGE && this.getChangeDetailInfo();
            }
        },
        activityNo: {
            type: String,
            value: ""
        },
        type: {
            type: Number,
            value: d.ACTIVITY_CHANGE
        },
        playMoneyMsg: {
            type: Object,
            value: {}
        },
        priceChangeMsg: {
            type: Object,
            value: {},
            observer: function(e) {
                if (e) {
                    var t = e.priceSkuChangeMsgVo || [];
                    e.tbHeaderList = [ "规格", "变更前", "变更后" ], e.skuPriceChangeArr = t.map(function(e) {
                        return [ (null == e ? void 0 : e.spec) && e.spec.split(",").join("/"), e.beforePrice = o.default.price(e.beforePrice, 100), e.afterPrice = o.default.price(e.afterPrice, 100) ];
                    }), e.splitLineList = [ "33.33", "66.67" ], this.setData({
                        priceChangeMsgData: [ e ]
                    });
                }
            }
        }
    },
    lifetimes: {
        created: function() {
            this.pageNumber = 1;
        }
    },
    data: {
        modifyRecordList: [],
        isLoading: !1,
        MODIFY_TYPE_MAP: c,
        PANEL_TITLE_MAP: u,
        SUPPLY_MESSAGE_TYPE: d,
        MoneyMsgList: [ {
            id: "playAmount",
            name: "打款金额(元):"
        }, {
            id: "resultDesc",
            name: "当前状态:"
        }, {
            id: "goodsName",
            name: "商品名称:"
        }, {
            id: "pddOrderSn",
            name: "订单编号:"
        }, {
            id: "playAt",
            name: "打款时间:"
        } ],
        priceChangeMsgData: []
    },
    methods: {
        hideChangeDetail: function() {
            this.triggerEvent("close");
        },
        getChangeDetailInfo: function() {
            var e = this, t = this.data, i = t.activityNo, r = t.modifyRecordList, n = t.isLoading;
            i && !n && ((0, a.rg)(), this.setData({
                isLoading: !0,
                loadMoreError: !1
            }), this.$baseRequest({
                url: "/api/ktt_group/supplychain/group/auto_sync_record",
                convertRequestToSnake: !0,
                convertToCamel: !0,
                data: {
                    collectionActivityNo: i,
                    pageNumber: this.pageNumber,
                    pageSize: 20
                }
            }).then(function(t) {
                var i = (0, a.qh)(t || {}, "result") || {}, n = i.recordList, o = void 0 === n ? [] : n, c = {
                    hasMore: i.hasMore,
                    isLoading: !1
                };
                if (o.length) {
                    var s = e.fmtRecordList(o);
                    c.modifyRecordList = 1 === e.pageNumber ? s : r.concat(s), e.pageNumber++;
                }
                e.setData(c), (0, a.l3)();
            }).catch(function(t) {
                e.setData({
                    loadMoreError: !0,
                    isLoading: !1
                }), (0, a.l3)(), e.$error({
                    e: t,
                    msg: "query change record fail"
                });
            }));
        },
        fmtRecordList: function(e) {
            var t = this;
            return (e || []).map(function(e) {
                var i = e.createdAt, r = e.scOperateTime, n = e.goodsImageAndTextContent, d = e.syncType, u = e.goodsCommissionRateContent, p = e.groupTimeContent, m = e.groupPromoContent, E = e.skuPriceContent, l = e.newSkuRecordList, _ = e.deleteSkuRecordList, C = e.goodsName, f = e.groupMinPieceContent;
                switch (e.createdAtStr = o.default.formatTime(i, "YYYY/MM/dd hh:mm:ss"), e.scOperateTimeStr = o.default.formatTime(r, "YYYY/MM/dd hh:mm:ss"), 
                e.modifyLabel = s[d], d) {
                  case c.IMAGE_AND_CONTENT:
                    e.modifyTypeContent = (n || []).join("、");
                    break;

                  case c.GOODS_COMMISION:
                    var h = u || {}, g = h.newCommissionRate, T = void 0 === g ? 0 : g, M = h.oldCommissionRate, S = void 0 === M ? 0 : M;
                    e.goodsCommissionChangeArr = [ [ "".concat(S / 1e3, "%"), "".concat(T / 1e3, "%") ] ];
                    break;

                  case c.ACTIVITY_TIME:
                    var L = p || {}, I = L.oldStartTime, A = L.newStartTime, v = L.oldEndTime, N = L.newEndTime;
                    e.groupTimeChangeArr = [ [ "".concat(o.default.formatTime(I, "YYYY/MM/dd hh:mm:ss"), "——\n                            ").concat(o.default.formatTime(v, "YYYY/MM/dd hh:mm:ss")), "".concat(o.default.formatTime(A, "YYYY/MM/dd hh:mm:ss"), "——\n                            ").concat(o.default.formatTime(N, "YYYY/MM/dd hh:mm:ss")) ] ];
                    break;

                  case c.FULL_REDUCTION:
                    var Y = m || {}, O = Y.oldPromoInfo, P = void 0 === O ? {} : O, R = Y.newPromoInfo, D = void 0 === R ? {} : R;
                    e.fullDiscountChangeArr = [ [ t.getFullDiscountStr((0, a.qh)(P, "discountInfoMap.".concat(13)) || []), t.getFullDiscountStr((0, 
                    a.qh)(D, "discountInfoMap.".concat(13)) || []) ] ];
                    break;

                  case c.FREE_RESOURCE_PRICE_CHANGE:
                  case c.SKU_PRICE:
                    var y = [], b = {};
                    e.skuPriceChangeArr = (E || []).map(function(e) {
                        var t = e.oldPrice, i = void 0 === t ? 0 : t, r = e.newPrice, a = void 0 === r ? 0 : r, n = e.specList, c = void 0 === n ? [] : n, s = o.default.price(i, 100), d = o.default.price(a, 100), u = [];
                        return c.forEach(function(e) {
                            var t = e || {}, i = t.name, r = void 0 === i ? "" : i, a = t.parentName, n = void 0 === a ? "" : a;
                            b[n] ? u[b[n]] = r : (b[n] = "".concat(y.length), y.push(n), u.push(r));
                        }), u.push(s, d), u;
                    }), e.tbHeaderList = y.concat("变更前", "变更后"), e.splitLineList = t.getSplitLineArr(e.tbHeaderList);
                    break;

                  case c.ADD_SKU:
                  case c.DELETE_SKU:
                    var U = [], H = {}, F = l, G = "新增";
                    d === c.DELETE_SKU && (F = _, G = "失效"), e.skuChangeArr = (F || []).map(function(e) {
                        var t = e.specList, i = [];
                        return t.forEach(function(e) {
                            var t = e || {}, r = t.name, a = void 0 === r ? "" : r, n = t.parentName, o = void 0 === n ? "" : n;
                            H[o] ? i[H[o]] = a : (H[o] = "".concat(U.length), U.push(o), i.push(a));
                        }), i.push(G), i;
                    }), e.tbHeaderList = U.concat("变更类型"), e.splitLineList = t.getSplitLineArr(e.tbHeaderList);
                    break;

                  case c.OFF_SHELVE_BY_COMMISSION:
                    e.modifyTypeContent = C;
                    break;

                  case c.MIN_BUY:
                    var k = f || {}, V = k.oldMinPiece, q = k.newMinPiece, w = k.oldMinPrice, K = k.newMinPrice, B = k.oldMinPriceType, x = k.newMinPriceType;
                    e.tbHeaderList = [ "变更类型", "变更前", "变更后" ], e.splitLineList = t.getSplitLineArr(e.tbHeaderList);
                    var j = [];
                    (V || q) && j.push([ "起购件数", V || "无限制", q || "无限制" ]), (w || K) && j.push([ "起购金额", t.minPriceText(w, B), t.minPriceText(K, x) ]), 
                    e.minChangedArr = j;
                }
                return e;
            });
        },
        minPriceText: function(e, t) {
            return e && t ? "".concat(p[t]).concat(o.default.price(e || 0, 100), "元") : "无限制";
        },
        minPriceTypeText: function(e) {
            return e ? p[e] : "无限制";
        },
        getFullDiscountStr: function(e) {
            return e.map(function(e) {
                var t = e.minAmount, i = e.discountAmount;
                return "满".concat(o.default.price(t, 100), "减").concat(o.default.price(i, 100));
            }).join("、") || "无满减";
        },
        getSplitLineArr: function(e) {
            var t = e.length;
            return e.reduce(function(e, i, r) {
                if (r < t - 1) {
                    var a = (++r / t * 100).toFixed(2);
                    e.push(a);
                }
                return e;
            }, []);
        },
        copyText: function() {
            var e;
            wx.setClipboardData({
                data: String(null === (e = this.data.playMoneyMsg) || void 0 === e ? void 0 : e.pddOrderSn)
            });
        }
    }
});