var e, t, a = require("../../_/helpers/interopRequireDefault"), r = require("../../_/helpers/slicedToArray"), n = a(require("../../_/regenerator")), i = require("../../_/helpers/asyncToGenerator"), o = require("../../_/helpers/defineProperty"), c = require("../../_/helpers/objectSpread2"), s = require("../../$app"), u = require("../../$page"), l = [ c({
    type: u.yk.DEFAULT,
    can: !0,
    desc: "创建普通团购"
}, u._8[u.yk.DEFAULT]) ], p = {
    ktt_index: (e = {}, o(e, u.yk.DEFAULT, u.ae4.createDialogCommon), o(e, u.yk.COPY, u.ae4.createDialogCopy), 
    o(e, u.yk.LIVE, u.ae4.createDialogLive), o(e, u.yk.OFFICIAL_HELP_SELL_ACTIVITY, u.ae4.createDialogSupply), 
    o(e, u.yk.SIGN_UP, u.ae4.createDialogSign), o(e, u.yk.LOTTERY, u.ae4.createDialogLottery), 
    o(e, u.yk.COMMUNITY_PUBLIC, u.ae4.createDialogCommunityPublic), o(e, u.yk.LOCAL_LIFE, u.ae4.createDialogLocalLife), 
    o(e, "createBlock", u.ae4.createBlock), e),
    luckywheel_landingpage: (t = {}, o(t, u.yk.DEFAULT, u.ae5.createActivityEle), o(t, u.yk.COPY, u.ae5.duplicateActivityEle), 
    o(t, u.yk.SELECT_CURRENT_ACTIVITY, u.ae5.modifyActivityEle), t)
};

(0, u.afb)({
    behaviors: [ u.amf, u.aev, u.aa9, u.aki, (0, u.aj1)(u.ab3), u.abm ],
    properties: {
        pageName: {
            type: String,
            value: ""
        }
    },
    data: {
        openTypeList: l,
        OPEN_TYPE: u.yk,
        withThreeSubTypes: !1,
        communitySupplyEntry: !1
    },
    lifetimes: {
        created: function() {
            this.lastCacheTimestamp = 0;
        },
        attached: function() {
            var e = this;
            this.queryMyAdminPerm(), this.getOpenPanelDataCache(), this.initData(), this.proxyListenerCancel = s.f9.listen(s.f1.onGlobalProxyChange, function() {
                return e.initData();
            });
        },
        detached: function() {
            this.cacheOpenPanelData(), this.proxyListenerCancel && this.proxyListenerCancel();
        }
    },
    pageLifetimes: {
        hide: function() {
            this.cacheOpenPanelData();
        }
    },
    methods: {
        initData: function() {
            var e = this;
            return i(n.default.mark(function t() {
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.fetchData();

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        fetchData: function() {
            var e = this;
            return i(n.default.mark(function t() {
                var a, i, o, c, u;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return e.$showLoading({
                            mask: !0
                        }), t.t0 = Promise, t.next = 4, e.getHomeOpenType().catch(s.hm);

                      case 4:
                        return t.t1 = t.sent, t.t2 = [ t.t1 ], t.next = 8, t.t0.all.call(t.t0, t.t2);

                      case 8:
                        a = t.sent, i = r(a, 1), o = i[0], c = (o = void 0 === o ? {} : o).openTypeList, 
                        u = o.hasCommunityPublicPlus, c ? e.setData({
                            openTypeList: c,
                            withThreeSubTypes: c.some(function(e) {
                                return e.subList && 3 === e.subList.length;
                            })
                        }) : e.setData({
                            openTypeList: l
                        }), e.checkHasEnsureSupplyPage(), e.triggerEvent("updateOpenList", {
                            openTypeListSize: c ? c.length : l.length
                        }), e.hasCommunityPublicPlus = u, e.$hideLoading();

                      case 18:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        checkHasEnsureSupplyPage: function() {
            var e = this;
            return i(n.default.mark(function t() {
                var a;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, (0, s.pi)();

                      case 2:
                        null != (a = t.sent) && a.result && e.setData({
                            communitySupplyEntry: !0
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleClick: function(e) {
            var t = this;
            return i(n.default.mark(function a() {
                var r, i, c;
                return n.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return (r = t.getTrackParams(e)) && t.$click(r), a.next = 4, t.checkPermAsync(u.zm.createModifyGroup, !0, !1);

                      case 4:
                        if (a.sent) {
                            a.next = 7;
                            break;
                        }
                        return a.abrupt("return", t.$showToast({
                            title: "无权限，请联系团长开通"
                        }));

                      case 7:
                        i = (0, s.jo)(e), (c = i.type) === u.yk.DEFAULT ? t.goToCreate() : c === u.yk.COPY ? t.goToCopy() : c === u.yk.LIVE ? t.openLive() : c === u.yk.OFFICE_LIBRARY ? t.goToCreatePddActivity() : c === u.yk.OFFICIAL_HELP_SELL_ACTIVITY ? t.goToOfficialHelpSellActivityList() : c === u.yk.SIGN_UP ? (0, 
                        s.n3)({
                            url: s.ob.createChain,
                            params: o({}, s.gf.subActivityType, s.cp.SIGN_UP)
                        }) : c === u.yk.LOTTERY ? (0, s.n3)({
                            url: s.ob.createChain,
                            params: o({}, s.gf.subActivityType, s.cp.LOTTERY)
                        }) : c === u.yk.COMMUNITY_PUBLIC || c === u.yk.COMMUNITY_PUBLIC_PLUS ? t.goToCreateCommunityPublic() : c === u.yk.SELECT_CURRENT_ACTIVITY ? t.goPersonalCenter() : c === u.yk.LOCAL_LIFE && (0, 
                        s.n3)({
                            url: s.ob.createChain,
                            params: o({}, s.gf.subActivityType, s.cp.LOCAL_LIFE)
                        }), (0, s.ev)({
                            type: s.u.ACTIVITY_CREATE,
                            tags: {
                                cp: "entryClick",
                                activityType: c
                            }
                        });

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }))();
        },
        move: function() {},
        goToCreate: function() {
            var e = this;
            return i(n.default.mark(function t() {
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!e.hasCommunityPublicPlus) {
                            t.next = 6;
                            break;
                        }
                        return t.next = 3, e.$showModal({
                            content: "是否创建小区团？支持按小区凑单，还可以批量退款、免费发短信",
                            confirmText: "创建小区团购",
                            cancelText: "仍然创建普通团"
                        });

                      case 3:
                        if (!t.sent.confirm) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return", e.goToCreateCommunityPublic());

                      case 6:
                        (0, s.n3)({
                            url: s.ob.createChain
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        goToCreateCommunityPublic: function() {
            var e = this;
            return i(n.default.mark(function t() {
                var a, r;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.$getCurrentUserInfo();

                      case 2:
                        a = t.sent, r = a.isStrictCaptain, void 0 !== r && r && e.data.communitySupplyEntry ? (0, 
                        s.n5)({
                            pageName: u.aiw.kttCommunitySupplyGroup,
                            params: o({}, s.gf.showCreateBtn, 1)
                        }) : (0, s.n3)({
                            url: s.ob.createChain,
                            params: o({}, s.gf.subActivityType, s.cp.COMMUNITY_PUBLIC)
                        });

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        goToCopy: function() {
            (0, s.n3)({
                url: s.ob.copyHistoryActivity,
                params: {
                    from_index: !0
                }
            });
        },
        goPersonalCenter: function() {
            (0, s.n3)({
                url: s.ob.personal,
                params: {
                    postion_to_activity_list: !0
                }
            });
        },
        goToCreatePddActivity: function() {
            (0, s.n3)({
                url: s.ob.createChain,
                params: o({}, s.gf.isSupplyChain, 1)
            });
        },
        goToOfficialHelpSellActivityList: function() {
            (0, s.n3)({
                url: s.ob.officialHelpSellActivityList
            });
        },
        openLive: function() {
            this.auth();
        },
        authPassed: function() {
            var e = this;
            return i(n.default.mark(function t() {
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        e.prepare();

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        prepare: function() {
            var e = this;
            return i(n.default.mark(function t() {
                var a, r, c;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), a = {}, t.prev = 2, t.next = 5, (0, u.ak0)();

                      case 5:
                        a = t.sent, t.next = 12;
                        break;

                      case 8:
                        return t.prev = 8, t.t0 = t.catch(2), e.retryTimeout = setTimeout(function() {
                            if (e.retry > 3) return e.$hideLoading(), void (0, s.ri)({
                                title: "系统繁忙，请稍后尝试开播",
                                icon: "none",
                                duration: 1500,
                                mask: !1
                            });
                            e.retry = e.retry || 0, e.retry += 1, e.prepare();
                        }, 1e3), t.abrupt("return");

                      case 12:
                        r = (a.info.showInfoNow || {}).image || e.properties.cover || (a.info.showInfo || {}).image || (0, 
                        s.jf)("mobile_live/2020-06-03/fa7e11a6-caef-4573-9291-4ac48ad9850e.png"), c = (a.info.showInfoNow || {}).title || e.properties.title || (a.info.showInfo || {}).title || "快来看我直播吧", 
                        e.$hideLoading(), a.info.showInfoNow ? wx.showModal({
                            title: "您有一场直播未结束，是否为您续播？",
                            content: "",
                            showCancel: !0,
                            cancelText: "重新开播",
                            cancelColor: "#000000",
                            confirmText: "续播",
                            confirmColor: "#3CC51F",
                            success: function() {
                                var t = i(n.default.mark(function t(i) {
                                    var l;
                                    return n.default.wrap(function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                          case 0:
                                            if (!i.confirm) {
                                                t.next = 5;
                                                break;
                                            }
                                            l = {
                                                image: r,
                                                title: c,
                                                showId: a.info.showInfoNow.showId,
                                                externalSourceId: a.info.showInfoNow.externalSourceId
                                            }, e.started(l, a.info.showInfoNow.externalSourceId, a.info.roomId, !0), t.next = 8;
                                            break;

                                          case 5:
                                            return t.next = 7, (0, u.agb)({
                                                showId: a.info.showInfoNow.showId
                                            });

                                          case 7:
                                            (0, s.n3)({
                                                url: s.ob.createChain,
                                                params: o({}, s.gf.isLivestream, 1)
                                            });

                                          case 8:
                                          case "end":
                                            return t.stop();
                                        }
                                    }, t);
                                }));
                                return function(e) {
                                    return t.apply(this, arguments);
                                };
                            }()
                        }) : (0, s.n3)({
                            url: s.ob.createChain,
                            params: o({}, s.gf.isLivestream, 1)
                        });

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 8 ] ]);
            }))();
        },
        started: function(e, t, a) {
            var r = arguments;
            return i(n.default.mark(function i() {
                var o, l, p;
                return n.default.wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        return o = r.length > 3 && void 0 !== r[3] && r[3], l = {}, n.prev = 2, n.next = 5, 
                        (0, u.am1)(e);

                      case 5:
                        l = n.sent, n.next = 11;
                        break;

                      case 8:
                        return n.prev = 8, n.t0 = n.catch(2), n.abrupt("return");

                      case 11:
                        p = e.image, (0, s.n3)({
                            url: s.ob.livePush,
                            success: function() {
                                s.f9.trigger(s.f1.live, {
                                    showInfo: c(c({}, l), {}, {
                                        roomId: a
                                    }),
                                    externalSourceId: t,
                                    liveImage: p,
                                    isContinue: o
                                });
                            }
                        });

                      case 13:
                      case "end":
                        return n.stop();
                    }
                }, i, null, [ [ 2, 8 ] ]);
            }))();
        },
        handleImpr: function(e) {
            var t = this.getTrackParams(e);
            t && this.$impr(t);
        },
        getTrackParams: function(e) {
            var t = (0, s.jo)(e).type, a = (0, s.qh)(p, "".concat(this.data.pageName, ".").concat(t));
            if (a) {
                var r = {
                    page_el_sn: a
                };
                return t === u.yk.DEFAULT && (r.extParams = {
                    redpacket_id: 0
                }), r;
            }
        },
        cacheOpenPanelData: function() {
            var e;
            this._setLocalCacheData(s.ct.createPanelData, [ "openTypeList", "withThreeSubTypes" ], {
                ownerUserNo: null === (e = this.$currentPage) || void 0 === e ? void 0 : e.$getCurrentUserNo()
            });
        },
        getOpenPanelDataCache: function() {
            var e = this._getLocalCacheData(s.ct.createPanelData);
            if (e) {
                var t, a = null === (t = this.$currentPage) || void 0 === t ? void 0 : t.$getCurrentUserNo();
                a && (null == e ? void 0 : e.ownerUserNo) === a ? this.setData(c({}, e.renderCache)) : this._removeStroage(s.ct.createPanelData);
            }
        }
    }
});