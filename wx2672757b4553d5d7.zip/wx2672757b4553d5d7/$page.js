var e = require("_/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.aa3 = exports.aa2 = exports.aa1 = exports.aa0 = exports._z = exports._y = exports._x = exports._w = exports._v = exports._u = exports._t = exports._s = exports._r = exports._q = exports._p = exports._o = exports._n = exports._m = exports._l = exports._k = exports._j = exports._i = exports._h = exports._g = exports._f = exports._e = exports._c = exports._b = exports._a = exports._9 = exports._8 = exports._7 = exports._6 = exports._5 = exports._4 = exports._3 = exports._2 = exports._1 = exports._0 = void 0, 
exports.aa4 = Ra, exports.aam = exports.aal = exports.aak = exports.aaj = exports.aai = exports.aah = exports.aag = exports.aaf = exports.aae = exports.aac = exports.aab = exports.aaa = exports.aa_ = exports.aa9 = exports.aa8 = exports.aa7 = exports.aa6 = exports.aa5 = void 0, 
exports.aan = jr, exports.aao = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y({
        url: "/api/ktt_group/activity_operate/up_or_down",
        convertRequestToSnake: !0,
        convertToCamel: !0
    }, e));
}, exports.aap = function(e) {
    var t = e.startTime, r = e.endTime, a = e.repeatEndTime, n = e.title, o = void 0 === n ? "" : n, i = e.description, s = void 0 === i ? "" : i, c = e.location, u = void 0 === c ? "" : c, p = e.repeatInterval, l = void 0 === p ? "day" : p, d = e.success, h = void 0 === d ? function() {} : d, f = e.fail, g = void 0 === f ? function() {
        (0, z.ri)({
            title: "提醒添加失败"
        });
    } : f;
    if ((0, z.g3)("2.15.0")) return z.f3.addPhoneRepeatCalendar({
        startTime: t,
        title: o,
        endTime: r + "",
        repeatEndTime: a,
        alarm: !0,
        alarmOffset: 0,
        description: s,
        location: u,
        repeatInterval: l,
        fail: g
    }).then(h).catch(function(e) {
        var t = (null == e ? void 0 : e.errMsg) || "";
        -1 === t.indexOf("auth den") ? (-1 !== t.indexOf("refuesed") && (t = "请去设置中开启日历权限"), 
        (0, z.ri)({
            title: "提醒添加失败"
        })) : (0, z.lw)("scope.addPhoneCalendar");
    });
    (0, z.ri)({
        title: "微信版本太低，请升级"
    });
}, exports.aaq = function(e) {
    return Vc.apply(this, arguments);
}, exports.abg = exports.abf = exports.abe = exports.abc = exports.abb = exports.aba = exports.ab_ = exports.ab9 = exports.ab8 = exports.ab7 = exports.ab6 = exports.ab5 = exports.ab4 = exports.ab3 = exports.ab2 = exports.ab1 = exports.ab0 = exports.aaz = exports.aay = exports.aax = exports.aaw = exports.aav = exports.aau = exports.aat = exports.aas = exports.aar = void 0, 
exports.abh = function(e) {
    var t = e.data, r = e.methods;
    return Y({
        data: t
    }, r);
}, exports.abn = exports.abm = exports.abl = exports.abk = exports.abj = exports.abi = void 0, 
exports.abo = Na, exports.abp = function(e) {
    return Ar.apply(this, arguments);
}, exports.abq = function(e) {
    var t = (e || {}).errorCode;
    35013 !== t && 35014 !== t || (0, z.hp)({
        msg: "api no admin perm",
        e: e,
        isBase: !1
    });
}, exports.abr = function(e) {
    return en.apply(this, arguments);
}, exports.abs = void 0, exports.abx = exports.abw = exports.abv = exports.abu = exports.abt = void 0, 
exports.aby = br, exports.abz = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.canUseRequestSubscribeFunc, r = void 0 === t || t, a = e.mainSwitch, n = void 0 === a || a;
    r ? n || (0, z.ri)({
        title: "操作失败，请先前往小程序设置开启订阅消息接收开关",
        icon: "none"
    }) : (0, z.ri)({
        title: "请升级微信版本",
        icon: "none"
    });
}, exports.ac0 = function(e) {
    var t = e.onSignIn;
    return Y({
        onSignIn: function() {
            for (var e = arguments.length, r = new Array(e), a = 0; a < e; a++) r[a] = arguments[a];
            this.$prePageProxyUserNo = this.$getCurrentProxyUserNo(), t && t.apply(this, r);
        }
    }, Bs);
}, exports.ac1 = void 0, exports.ac2 = qs, exports.ac3 = Fs, exports.ac4 = Hs, exports.acb = exports.aca = exports.ac_ = exports.ac9 = exports.ac8 = exports.ac7 = exports.ac6 = exports.ac5 = void 0, 
exports.acc = qp, exports.acm = exports.acl = exports.ack = exports.acj = exports.aci = exports.ach = exports.acg = exports.acf = exports.ace = void 0, 
exports.acn = As, exports.af2 = exports.af1 = exports.af0 = exports.aez = exports.aey = exports.aex = exports.aew = exports.aev = exports.aeu = exports.aet = exports.aes = exports.aer = exports.aeq = exports.aep = exports.aeo = exports.aen = exports.aem = exports.ael = exports.aek = exports.aej = exports.aei = exports.aeh = exports.aeg = exports.aef = exports.aee = exports.aec = exports.aeb = exports.aea = exports.ae_ = exports.ae9 = exports.ae8 = exports.ae7 = exports.ae6 = exports.ae5 = exports.ae4 = exports.ae3 = exports.ae2 = exports.ae1 = exports.ae0 = exports.acz = exports.acy = exports.acx = exports.acw = exports.acv = exports.acu = exports.act = exports.acs = exports.acr = exports.acq = exports.acp = exports.aco = void 0, 
exports.af3 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order/customer/after_sales/query"
    }, e), {}, {
        convertToCamel: !0,
        noErrorToast: !0
    }));
}, exports.af4 = void 0, exports.af5 = le, exports.afa = exports.af_ = exports.af9 = exports.af8 = exports.af7 = exports.af6 = void 0, 
exports.afb = function(e) {
    var t = e.data, r = void 0 === t ? {} : t, a = e.methods, n = O(e, re);
    ks(Y(Y({}, n), {}, {
        behaviors: [ Cs ].concat(V((null == n ? void 0 : n.behaviors) || [])),
        data: Y(Y({}, r), {}, {
            $appData: null == bs ? void 0 : bs.$appData
        }),
        methods: Y(Y(Y({}, a), xs), Ts)
    }));
}, exports.afc = dc, exports.afk = exports.afj = exports.afi = exports.afh = exports.afg = exports.aff = exports.afe = void 0, 
exports.afl = void 0, exports.afm = Da, exports.afx = exports.afw = exports.afv = exports.afu = exports.aft = exports.afs = exports.afr = exports.afq = exports.afp = exports.afo = exports.afn = void 0, 
exports.afy = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)({
        url: "/api/ktt_group/activity_topic/create",
        convertToCamel: !0,
        convertRequestToSnake: !0,
        noErrorToast: !1,
        data: e
    });
}, exports.ag1 = exports.ag0 = exports.afz = void 0, exports.ag2 = pe, exports.ag3 = Vt, 
exports.ag4 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : or;
    e && (0, z.n3)({
        url: z.ob.mpArticle,
        params: {
            mp_src: e
        }
    });
}, exports.ag7 = exports.ag6 = exports.ag5 = void 0, exports.ag8 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y({
        url: "/api/ktt_group/activity_query/list_activity",
        convertToCamel: !0,
        convertRequestToSnake: !0
    }, e));
}, exports.ag9 = void 0, exports.ag_ = kr, exports.aga = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)({
        url: "/api/ktt_group/activity_topic/delete",
        convertToCamel: !0,
        noErrorToast: !1,
        data: e
    });
}, exports.agl = exports.agk = exports.agj = exports.agi = exports.agh = exports.agg = exports.agf = exports.age = exports.agc = exports.agb = void 0, 
exports.agm = function(e, t) {
    var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], a = Date.now();
    t = t || a;
    var n = de(e = e || a), o = (de(t) - n) / 864e5;
    return 0 === o ? "今天" : 1 === o ? "昨天" : !r || o <= 30 ? "".concat(o, "天前") : "近期";
}, exports.agp = exports.ago = exports.agn = void 0, exports.agq = function(e) {
    if (!e) return {};
    var t = e.mallActivityNo, r = void 0 === t ? "" : t, a = e.mallEntranceEnable, n = void 0 !== a && a, o = e.mallEntranceLayout, i = void 0 === o ? 0 : o;
    return Y(Y({}, e), {}, {
        mallActivityNo: r,
        topShow: n && 0 === i,
        bottomShow: n && 1 === i
    });
}, exports.agr = void 0, exports.ags = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    return e.map(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.wechatInfo || {}, r = t.userName, a = t.avatar;
        return {
            time: pe(e.notifyTime),
            userName: r,
            avatar: a,
            goodsCount: e.goodsCount,
            participateNo: (e.participateNo || "") + "",
            orderGoodsSnapshotList: e.orderGoodsSnapshotList || [],
            isCancelFromB: e.isCancelFromB,
            parnetOrderNo: e.parnetOrderNo
        };
    });
}, exports.agu = exports.agt = void 0, exports.agv = Ki, exports.agx = exports.agw = void 0, 
exports.agy = fe, exports.agz = function(e) {
    var t = W.default.timeParams(e);
    return "".concat(t.month, "月").concat(t.date, "日").concat(t.hours, "点");
}, exports.ah0 = ns, exports.ah1 = ps, exports.ah2 = function() {
    return (0, z.fy)({
        url: "/api/ktt_chat/platform_cs/query_conv_id",
        noErrorToast: !0,
        convertToCamel: !0,
        convertRequestToSnake: !0
    }).catch(function(e) {
        return (0, z.hp)({
            e: e,
            msg: "fail BTokenExChange"
        }), e;
    });
}, exports.ah3 = function(e) {
    return (null == e ? void 0 : e.convId) ? (0, z.fy)({
        url: "/api/prairie/chat/conv/get_conv_info",
        noErrorToast: !0,
        convertToCamel: !0,
        header: {
            "user-type": 10,
            "Client-Type": 1
        },
        data: {
            convId: e.convId
        }
    }).catch(function(e) {
        return (0, z.hp)({
            e: e,
            msg: "fail BTokenExChange"
        }), e;
    }) : Promise.reject(new Error("缺少convId"));
}, exports.ah6 = exports.ah5 = exports.ah4 = void 0, exports.ah7 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_gameplay/order/group/detail/query"
    }, e), {}, {
        convertRequestToSnake: !0,
        noErrorToast: !0,
        convertToCamel: !0
    }));
}, exports.aha = exports.ah_ = exports.ah9 = exports.ah8 = void 0, exports.ahb = function(e) {
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order/business/query/after_sales_operation_log"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0,
        noErrorToast: !0
    }));
}, exports.ahc = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y({
        url: "/api/ktt_order/business/statistics/batch_activity_after_sales",
        convertToCamel: !0
    }, e));
}, exports.ahe = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_gateway/activity/feeds/one"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0
    }));
}, exports.ahf = function(e) {
    var t = e.supplyTypeList, r = e.activityType;
    return t.indexOf(ct.DISTRIBUTION_FREE_PRICING) > -1 ? st.FREE_PRICING : t.indexOf(ct.DISTRIBUTION_COMMISSION_RATE, ct.SHARE_COMMISSION_RATE) > -1 || [ z.b.DISTRIBUTION, z.b.DISTRIBUTION_HELPER, z.b.SHRAE_HELP_SELL ].indexOf(r) > -1 ? st.COMMISSION_RATE : st.UNSET;
}, exports.ahg = tn, exports.ahh = void 0, exports.ahi = function(e) {
    var t = (e ? new Date(e) : new Date()).getFullYear();
    return t % 4 == 0 && t % 100 != 0 || t % 400 == 0 ? 366 : 365;
}, exports.ahk = exports.ahj = void 0, exports.ahl = function(e) {
    var t = e.shopName, r = e.collectionActivityNo;
    return {
        title: lt(t),
        imageUrl: ut,
        path: z.ob.captainShop,
        params: q({}, z.gf.collectionActivityNo, r)
    };
}, exports.ahm = function(e) {
    var t = e.collectionActivityNo;
    return {
        title: We,
        imageUrl: pt,
        path: z.ob.index,
        params: q({}, z.gf.collectionActivityNo, t)
    };
}, exports.ahn = lt, exports.aho = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return z.fy.call(this, Y(Y({
        url: "/api/ktt_gateway/user/info/home_page"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0,
        noErrorToast: !0,
        logFilter: z.h4
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.result;
    });
}, exports.ahp = Ni, exports.aht = exports.ahs = exports.ahr = exports.ahq = void 0, 
exports.ahu = function() {
    return Bp.apply(this, arguments);
}, exports.ahv = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y({
        url: "/api/ktt_gameplay/leader_growth/mission_reward/claim",
        convertToCamel: !0,
        convertRequestToSnake: !0
    }, e)).then(function(e) {
        return (e || {}).result;
    });
}, exports.ahw = Lp, exports.ahx = void 0, exports.ahy = function() {
    return ur.apply(this, arguments);
}, exports.ai4 = exports.ai3 = exports.ai2 = exports.ai1 = exports.ai0 = exports.ahz = void 0, 
exports.ai5 = function() {
    z.f3.hideShareMenu().catch(Ta);
}, exports.ai6 = void 0, exports.ai7 = Hc, exports.aia = exports.ai_ = exports.ai9 = exports.ai8 = void 0, 
exports.aib = Nr, exports.aic = void 0, exports.aie = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = [ [], [], e.length ], r = t[0], a = t[1], n = t[2], o = 0, i = 0, s = 0; s < n; s++) "#" === e[s] && (r[o] ? r[o++][1] = s : r[o] = [ s ]);
    return r.length ? (r.forEach(function(t) {
        var r = L(t, 2), o = r[0], s = r[1];
        s ? (o > i && a.push({
            type: "text",
            text: e.slice(i, o)
        }), a.push({
            name: "span",
            attrs: {
                style: "font-weight: bold;"
            },
            children: [ {
                type: "text",
                text: e.slice(o + 1, s)
            } ]
        }), i = s + 1) : (a.push({
            type: "text",
            text: e.slice(i, n)
        }), i = n - 1);
    }), i < n - 1 && a.push({
        type: "text",
        text: e.slice(i, n)
    })) : a.push({
        type: "text",
        text: e
    }), [ {
        name: "span",
        attrs: {
            style: "white-space: pre-wrap"
        },
        children: a
    } ];
}, exports.aih = exports.aig = exports.aif = void 0, exports.aii = function(e) {
    var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : it, a = (q(t = {}, z.aq.express, 1), 
    q(t, z.aq.local, 2), q(t, z.aq.mention, 3), q(t, z.aq.noLogistics, 0), t);
    return e.forEach(function(e) {
        e.isDefault && (a[e.expressType] = -1);
    }), e.filter(function(e) {
        return 1 === e.expressStatus;
    }).sort(function(e, t) {
        return a[e.expressType] - a[t.expressType];
    }).map(function(e) {
        return (0, z.qh)(r, "[".concat(e.expressType, "].expressValue"));
    }).join("/") || "未设置";
}, exports.aij = void 0, exports.aik = gc, exports.ail = void 0, exports.aim = function(e) {
    var t = e % 60, r = Math.floor(e / 60) % 60, a = Math.floor(e / 3600) % 24, n = Math.floor(e / 86400);
    return {
        seconds: ge(t),
        minutes: ge(r),
        hours: ge(a),
        days: n
    };
}, exports.ain = void 0, exports.aio = Uc, exports.aiq = exports.aip = void 0, exports.air = Ft, 
exports.ais = void 0, exports.ait = function(e, t) {
    return Za.apply(this, arguments);
}, exports.aiy = exports.aix = exports.aiw = exports.aiv = exports.aiu = void 0, 
exports.aiz = _e, exports.aj0 = void 0, exports.aj1 = function(e) {
    var t = e.data, r = O(e, ie);
    return (0, z.gg)({
        data: t,
        methods: r
    });
}, exports.aj2 = void 0, exports.aj3 = wa, exports.aj6 = exports.aj5 = exports.aj4 = void 0, 
exports.aj7 = function(e, t) {
    return Array.from(e).slice(0, t - 1).join("") + "...";
}, exports.ajb = exports.aja = exports.aj_ = exports.aj9 = exports.aj8 = void 0, 
exports.ajc = function(e) {
    return parseInt(e, 10) === ot.mall;
}, exports.aje = function(e) {
    return parseInt(e, 10) === ot.pointMall;
}, exports.aji = exports.ajh = exports.ajg = exports.ajf = void 0, exports.ajj = ds, 
exports.ajk = function() {
    (0, z.n4)({
        path: "/wdrpplbr.html",
        params: {
            _ktt_frontend: "kttchat",
            page_redirect: "kttchat_chat_detail"
        }
    });
}, exports.ajl = cn, exports.ajm = void 0, exports.ajn = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.baseParam, r = void 0 === t ? {} : t, a = e.addCount, n = e.type, o = r.visitorUnreadCount, i = void 0 === o ? 0 : o, s = r.csUnreadCount, c = void 0 === s ? 0 : s, u = r.innerNoticeUnreadCount, p = void 0 === u ? 0 : u, l = {
        showCount: i + c + p > 999 ? "999+" : i + c + p,
        visitorUnreadCount: i,
        csUnreadCount: c,
        innerNoticeUnreadCount: p
    };
    10 === n ? l.visitorUnreadCount = i + a : 9 === n ? l.csUnreadCount = c + a : "isS" === n && (l.sysUnreadCount = p + a), 
    l.visitorUnreadCount || l.csUnreadCount || l.innerNoticeUnreadCount ? (0, z.hk)((0, 
    z.q0)(Y(Y({}, r), {}, {
        hasNewMsg: !0
    }, l))) : (0, z.hk)((0, z.q0)(Y(Y({}, r), {}, {
        hasNewMsg: !1
    }, l)));
}, exports.ajo = rs, exports.ajp = void 0, exports.ajq = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_gameplay/lucky_wheel/cus/rotate"
    }, e), {}, {
        convertToCamel: !0,
        noErrorToast: !0
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e;
    });
}, exports.ajs = exports.ajr = void 0, exports.ajt = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = {};
    return e && e.activityNo && Object.assign(t, {
        activityNo: e.activityNo
    }), (0, z.fy)(Y(Y({}, z.je), {}, {
        data: t
    })).then(function(t) {
        return e.activityNo && (e.textMessage || e.imageList) ? (0, z.qh)(t, "result.restChance") ? (0, 
        z.fy)(Y(Y({}, z.ez), {}, {
            data: Y({}, e)
        })) : Promise.reject(t) : t;
    });
}, exports.ak0 = exports.ajz = exports.ajy = exports.ajx = exports.ajw = exports.ajv = exports.aju = void 0, 
exports.ak1 = function(e) {
    var t = e.imageUrl, r = e.shareText, a = e.shopName, n = e.collectionActivityNo;
    this.$currentPage && this.$currentPage.$prepareShare({
        card: {
            title: r || lt(a),
            imageUrl: t || De,
            path: z.ob.captainShop,
            params: q({}, z.gf.collectionActivityNo, n)
        }
    }, z.cf.mall);
}, exports.ak2 = function(e) {
    var t, r = e.imageUrl, a = e.shareText, n = e.shopName, o = e.collectionActivityNo, i = e.shopUserNo, s = e.goodsId;
    r && this.$currentPage && this.$currentPage.$prepareShare({
        card: {
            title: a || lt(n),
            imageUrl: r,
            path: z.ob.captainShop,
            params: (t = {}, q(t, z.gf.collectionActivityNo, o), q(t, z.gf.userNo, i), q(t, z.gf.goodsId, s), 
            t)
        }
    }, z.cf.mall);
}, exports.ak3 = St, exports.ak4 = function(e) {
    var t, r = e.imageUrl, a = e.shareText, n = e.orderSn, o = e.userNo;
    r && this.$currentPage && this.$currentPage.$prepareShare({
        card: {
            title: a || lt(),
            imageUrl: r,
            path: z.ob.web,
            params: (t = {
                src: "wdrpplbr.html",
                ktt_alias: _t.pointGoodsLanding
            }, q(t, z.gf.orderSn, n), q(t, z.gf.userNo, o), t)
        }
    }, z.cr.POINT_GOODS_SHARE);
}, exports.ak5 = Ct, exports.ak8 = exports.ak7 = exports.ak6 = void 0, exports.ak9 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_group/activity_query/discount"
    }, e), {}, {
        noErrorToast: !0,
        convertToCamel: !0,
        logFilter: z.hy
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.result;
    });
}, exports.akc = exports.akb = exports.aka = exports.ak_ = void 0, exports.ake = zt, 
exports.akf = sn, exports.akg = nn, exports.akh = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    nn({
        toUserNo: e
    });
}, exports.akj = exports.aki = void 0, exports.akk = pn, exports.akp = exports.ako = exports.akn = exports.akm = exports.akl = void 0, 
exports.akq = Yr, exports.aks = exports.akr = void 0, exports.akt = yt, exports.aku = void 0, 
exports.akv = function(e) {
    var t = Y(Y({}, e), {}, {
        data: Y(Y({}, e.data || {}), {}, {
            $shareInfoMessageMap: {},
            $shareInfoPosterMap: {},
            $shareConfig: {
                type: "default",
                show: !1
            },
            $appData: null == ic ? void 0 : ic.$appData,
            $isGroupAdmin: !1
        }),
        isPageV2: !0,
        behaviors: [ Cs, oc, pc, Ns, Ds, lc, ys, Ls, Is, $s, uc ].concat(V((null == e ? void 0 : e.behaviors) || []))
    });
    return Component(t), t;
}, exports.akz = exports.aky = exports.akx = exports.akw = void 0, exports.al0 = function(e) {
    return It.apply(this, arguments);
}, exports.al3 = exports.al2 = exports.al1 = void 0, exports.al4 = function(e, t) {
    return jr({
        comp: e,
        selector: t,
        pageScrollTop: !0
    });
}, exports.al8 = exports.al7 = exports.al6 = exports.al5 = void 0, exports.al9 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order/customer/unpaid/order_detail"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0
    }));
}, exports.alb = exports.ala = exports.al_ = void 0, exports.alc = Vr, exports.alh = exports.alg = exports.alf = exports.ale = void 0, 
exports.ali = Mp, exports.all = exports.alk = exports.alj = void 0, exports.alm = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_group/group_query/pay_sales_tip"
    }, e), {}, {
        noErrorToast: !0,
        convertToCamel: !0,
        convertRequestToSnake: !0
    }));
}, exports.aln = function() {
    return (0, z.fy)({
        url: "/api/ktt_gameplay/leader_growth/entry/query",
        method: "GET",
        noErrorToast: !0,
        convertToCamel: !0,
        convertRequestToSnake: !0
    }).then(function(e) {
        return (e || {}).result;
    });
}, exports.alo = function(e, t) {
    return Vr({
        $this: e,
        selector: t,
        field: "height"
    });
}, exports.alr = exports.alq = exports.alp = void 0, exports.als = function(e) {
    return Et.apply(this, arguments);
}, exports.alt = void 0, exports.alu = function(e) {
    return Tt.apply(this, arguments);
}, exports.alv = function() {
    return jr({
        pageScrollTop: !0
    });
}, exports.aly = exports.alx = exports.alw = void 0, exports.alz = function() {
    return (0, z.fy)({
        url: "/api/ktt_rec/rec_feeds/query_personal_suggest_activity_feeds",
        method: "POST",
        convertToCamel: !0,
        noErrorToast: !0,
        timeout: 5e3
    });
}, exports.am2 = exports.am1 = exports.am0 = void 0, exports.am3 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_group/activity/subscribe/goods_spike_activity"
    }, e), {}, {
        convertRequestToSnake: !0,
        convertToCamel: !0,
        noErrorToast: !0
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.success;
    });
}, exports.am4 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_group/activity/subscribe/not_started_activity"
    }, e), {}, {
        noErrorToast: !0,
        convertToCamel: !0,
        convertRequestToSnake: !0
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.result;
    });
}, exports.am5 = void 0, exports.am6 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = arguments.length > 1 ? arguments[1] : void 0, r = (0, 
    z.k5)() || {}, a = r.SDKVersion;
    (0, z.g4)(a, "2.13.0") >= 0 && (e ? z.f3.updateShareMenu({
        withShareTicket: !0,
        isPrivateMessage: !0,
        activityId: t,
        isUpdatableMessage: !1,
        templateInfo: {}
    }).catch(Ta) : z.f3.updateShareMenu({
        withShareTicket: !1,
        isPrivateMessage: !1,
        isUpdatableMessage: !1,
        templateInfo: {}
    }).catch(Ta));
}, exports.am7 = void 0, exports.am8 = function(e) {
    var t = e.target, r = e.slideIn, a = e.slideOut, n = e.withHeader, o = void 0 === n || n, i = e.customHeight, s = void 0 === i ? 0 : i, c = e.ignoreHasOut, u = void 0 !== c && c, p = e.context, l = e.options, d = void 0 === l ? {} : l, h = p.createIntersectionObserver;
    if (!h) return;
    var f = o ? (0, z.ke)().navBarHeight : -0, g = h(d), m = !1;
    return g.relativeToViewport({
        top: -f + s
    }).observe(t, function(e) {
        var t = e.boundingClientRect, n = e.intersectionRatio, o = e.relativeRect, i = 0 === n;
        i && t.top < o.top ? (m = !0, a(e)) : !m && !u || i || (m = !1, r(e));
    }), function() {
        g && g.disconnect(), g = null;
    };
}, exports.amc = exports.amb = exports.ama = exports.am_ = exports.am9 = void 0, 
exports.ame = dr, exports.amp = exports.amo = exports.amn = exports.amm = exports.aml = exports.amk = exports.amj = exports.ami = exports.amh = exports.amg = exports.amf = void 0, 
exports.amq = function(e) {
    var t = function(e, t, r) {
        for (var a = Object.keys(e), n = Object.keys(t), o = {}, i = 0; i < a.length; i++) {
            var s = a[i], c = e[s], u = t[s];
            s && n.indexOf(s) > -1 && u !== c && dp(c, u, s, o, 2);
        }
        return Object.keys(o).length > 0 && o;
    }(this.data, e);
    t && this.setData(t);
}, exports.amr = void 0, exports.ams = xt, exports.amt = void 0, exports.amu = function() {
    z.f3.showShareMenu({}).catch(Ta);
}, exports.amv = Er, exports.anh = exports.ang = exports.anf = exports.ane = exports.anc = exports.anb = exports.ana = exports.amz = exports.amy = exports.amx = exports.amw = void 0, 
exports.ani = Pr, exports.anj = function() {
    return Yc.apply(this, arguments);
}, exports.ank = _c, exports.anl = void 0, exports.anm = function(e, t, r) {
    return _c(e, t, r);
}, exports.ann = $c, exports.anp = exports.ano = void 0, exports.anq = Ia, Object.defineProperty(exports, "isAuthDenyError", {
    enumerable: !0,
    get: function() {
        return z.mc;
    }
}), Object.defineProperty(exports, "isGetStorageNotFoundError", {
    enumerable: !0,
    get: function() {
        return z.mi;
    }
}), exports.sy = exports.sx = exports.sw = exports.sv = exports.s_ = exports.s9 = exports.s8 = exports.s7 = exports.s6 = exports.s5 = exports.s4 = exports.s3 = exports.s2 = exports.s1 = exports.s0 = void 0, 
exports.vq = exports.vp = exports.vo = exports.vn = exports.vm = exports.vl = exports.vk = exports.vj = exports.vi = exports.vh = exports.vg = exports.vf = exports.ve = exports.vc = exports.vb = exports.va = exports.v_ = exports.v9 = exports.v8 = exports.v7 = exports.v6 = exports.v5 = exports.v4 = exports.v3 = exports.v2 = exports.v1 = exports.v0 = exports.uz = exports.uy = exports.ux = exports.uw = exports.uv = exports.uu = exports.ut = exports.us = exports.ur = exports.uq = exports.up = exports.uo = exports.un = exports.um = exports.ul = exports.uk = exports.uj = exports.ui = exports.uh = exports.ug = exports.uf = exports.ue = exports.uc = exports.ub = exports.ua = exports.u_ = exports.u9 = exports.u8 = exports.u7 = exports.u6 = exports.u5 = exports.u4 = exports.u3 = exports.u2 = exports.u1 = exports.u0 = exports.tz = exports.ty = exports.tx = exports.tw = exports.tv = exports.tu = exports.tt = exports.ts = exports.tr = exports.tq = exports.tp = exports.to = exports.tn = exports.tm = exports.tl = exports.tk = exports.tj = exports.ti = exports.th = exports.tg = exports.tf = exports.te = exports.tc = exports.tb = exports.ta = exports.t_ = exports.t9 = exports.t8 = exports.t7 = exports.t6 = exports.t5 = exports.t4 = exports.t3 = exports.t2 = exports.t1 = exports.t0 = exports.sz = void 0, 
exports.yj = exports.yi = exports.yh = exports.yg = exports.yf = exports.ye = exports.yc = exports.yb = exports.ya = exports.y_ = exports.y9 = exports.y8 = exports.y7 = exports.y6 = exports.y5 = exports.y4 = exports.y3 = exports.y2 = exports.y1 = exports.y0 = exports.xz = exports.xy = exports.xx = exports.xw = exports.xv = exports.xu = exports.xt = exports.xs = exports.xr = exports.xq = exports.xp = exports.xo = exports.xn = exports.xm = exports.xl = exports.xk = exports.xj = exports.xi = exports.xh = exports.xg = exports.xf = exports.xe = exports.xc = exports.xb = exports.xa = exports.x_ = exports.x9 = exports.x8 = exports.x7 = exports.x6 = exports.x5 = exports.x4 = exports.x3 = exports.x2 = exports.x1 = exports.x0 = exports.wz = exports.wy = exports.ww = exports.wv = exports.wu = exports.wt = exports.ws = exports.wr = exports.wq = exports.wp = exports.wo = exports.wn = exports.wm = exports.wl = exports.wk = exports.wj = exports.wi = exports.wh = exports.wg = exports.wf = exports.we = exports.wc = exports.wb = exports.wa = exports.w_ = exports.w9 = exports.w8 = exports.w7 = exports.w6 = exports.w5 = exports.w4 = exports.w3 = exports.w2 = exports.w1 = exports.w0 = exports.vz = exports.vy = exports.vx = exports.vw = exports.vv = exports.vu = exports.vt = exports.vs = exports.vr = void 0, 
exports.zz = exports.zy = exports.zx = exports.zw = exports.zv = exports.zu = exports.zt = exports.zs = exports.zr = exports.zq = exports.zp = exports.zo = exports.zn = exports.zm = exports.zl = exports.zk = exports.zj = exports.zi = exports.zh = exports.zg = exports.zf = exports.ze = exports.zc = exports.zb = exports.za = exports.z_ = exports.z9 = exports.z8 = exports.z7 = exports.z6 = exports.z5 = exports.z4 = exports.z3 = exports.z2 = exports.z1 = exports.z0 = exports.yz = exports.yy = exports.yx = exports.yw = exports.yv = exports.yu = exports.yt = exports.ys = exports.yr = exports.yq = exports.yp = exports.yo = exports.yn = exports.ym = exports.yl = exports.yk = void 0, 
require("_/helpers/Arrayincludes");

var t = require("_/helpers/createForOfIteratorHelper");

require("_/helpers/Objectentries"), require("_/helpers/Objectvalues");

var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N, w, D = require("_/helpers/typeof"), O = require("_/helpers/objectWithoutProperties"), L = require("_/helpers/slicedToArray"), M = e(require("_/regenerator")), U = require("_/helpers/asyncToGenerator"), q = require("_/helpers/defineProperty"), G = require("_/helpers/classCallCheck"), B = require("_/helpers/createClass"), $ = require("_/helpers/get"), F = require("_/helpers/getPrototypeOf"), H = require("_/helpers/inherits"), j = require("_/helpers/createSuper"), V = require("_/helpers/toConsumableArray"), Y = require("_/helpers/objectSpread2"), z = require("$app"), W = e(require("@pdd/std-format")), K = require("@ktt/ktt-wxapp-boundle"), J = require("@ktt/redux-kit"), X = require("@ktt/titan-cli"), Q = [ "log" ], Z = [ "log" ], ee = [ "data" ], te = [ "data" ], re = [ "data", "methods" ], ae = [ "extra", "transparent_params" ], ne = [ "shareId", "baseShareInfo" ], oe = [ "scene" ], ie = [ "data" ], se = 6e4, ce = 1440;

function ue(e, t) {
    for (var r = (t = t || 2) - (e = (e || "").toString()).length, a = 0; a < r; a++) e = "0" + e;
    return e;
}

function pe(e) {
    if (!e) return e;
    var t = (Date.now() - e) / se || 0;
    if (t < 60) {
        var r = t < 0 ? 1 : t;
        return "".concat(Math.floor(r) || 1, "分钟前");
    }
    return t < ce ? "".concat(Math.floor(t / 60), "小时前") : "".concat(Math.floor(t / ce), "天前");
}

function le(e) {
    e = parseInt(e, 10) || 0;
    var t = new Date(e);
    return "".concat(ue(t.getFullYear()), "/").concat(ue(t.getMonth() + 1), "/").concat(ue(t.getDate()));
}

function de(e) {
    var t = le(e);
    return new Date(t).getTime();
}

var he = 518400;

function fe(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (!e) return "";
    var r = Date.now(), a = (r - e) / se || 0, n = new Date(r).setHours(0, 0, 0, 0);
    if (a < 60) {
        var o = a < 0 ? 1 : a;
        return "".concat(Math.floor(o) || 1, "分钟前");
    }
    if (e > n) return "".concat(Math.floor(a / 60), "小时前");
    if (a < 43200) {
        var i = Math.floor(a / ce), s = ce * se;
        return e > n - s ? "昨天" : e > n - 2 * s ? "前天" : "".concat(i, "天前");
    }
    return t ? "近期" : a < he ? "".concat(Math.floor(a / 43200), "个月前") : "".concat(Math.floor(a / he), "年前");
}

function ge(e) {
    return e < 10 ? "0".concat(e) : e;
}

var me = function(e) {
    return void 0 !== e && ![ z.h.STOPPED, z.h.DELETE ].includes(e);
}, ve = function(e) {
    return void 0 !== e && [ z.b.SHRAE_HELP_SELL, z.b.DISTRIBUTION_HELPER ].includes(e);
};

function _e() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    return !!(e && Array.isArray(e) && e.length) && e.some(function(e) {
        return e === z.j.STAR_ACTIVITY;
    });
}

var xe = function(e, t, r) {
    if (!e || !e.status) return !1;
    var a = e.status, n = t && [ z.b.DISTRIBUTION, z.b.DISTRIBUTION_HELPER ].includes(t) && a === z.s.HAS_SELL, o = ve(t) && a === z.s.HAS_SHARE_SELL;
    return me(r) && (n || o);
}, ye = function(e, t, r) {
    if (!e || !e.status) return !1;
    var a = e.status, n = z.b.DISTRIBUTION === t && a === z.s.CAN_SELL, o = ve(t) && a === z.s.CAN_SHARE_SELL;
    return me(r) && (n || o);
}, Se = function(e) {
    var t = e.promoInfo, r = e.mallCouponEventVo, a = (t || {}).discountInfoMap || {}, n = Object.keys(a).reduce(function(e, t) {
        var r = a[t] || [];
        return e.concat(r);
    }, []);
    return r && r.couponAmountDesc && n.unshift({
        discountDesc: "新人立减".concat(r.couponAmountDesc, "元"),
        isFirstRedPacket: !0
    }), n;
}, Ee = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = arguments.length > 1 ? arguments[1] : void 0;
    return e.find(function(e) {
        return e.markId === t;
    });
}, Te = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    return Ee(e, z.bc.WORD_MOUTH);
}, Ie = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    return !!Ee(e, z.bc.WHOLESALE);
}, Ce = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = Te(e);
    return t && 1 === t.status;
}, ke = function(e, t) {
    var r, a = e.tagIdList, n = e.participateCount, o = e.participantList, i = e.visitCount, s = e.activityStatus, c = e.supplyTypeList, u = e.createdAt, p = e.markExtInfo, l = e.helpSellCopyActivity, d = e.activityType, h = fe(+(u || 0), !l || !l.status), f = Y(Y({}, e), {}, {
        timeSpan: h,
        isHelpSelling: xe(l, d, s),
        participateCount: n ? W.default.sales(n) : "",
        visitCountStr: i ? W.default.sales(i) : "",
        isOver: s === z.h.STOPPED,
        isPreview: s === z.h.PREVIEW,
        notStarted: s === z.h.NOT_STARTED,
        isFreePricing: (c || []).includes(z.av),
        showStarActivityTag: _e(a || [])
    });
    (null == t ? void 0 : t.timeSpanAsAfterPriceLabel) && (null === (r = f.showLabelVo) || void 0 === r ? void 0 : r.afterPriceLabelList) && f.showLabelVo.afterPriceLabelList.push({
        labelType: 1,
        subLabelType: "custom",
        text: h + "发布",
        style: "flex-grow: 1;justify-content: flex-end;color: #9c9c9c;margin: 0;padding: 0;"
    }), (null == t ? void 0 : t.groupInfoSetToBottom) && (f.groupInfoSetToBottom = !0), 
    o && (f.followerList = o.map(function(e) {
        return Y(Y({}, e), {}, {
            timeSpan: fe(+(e.createdAt || 0))
        });
    }));
    var g = [];
    return f.showLabelVo && Object.values(f.showLabelVo).forEach(function(e) {
        e && e.forEach(function(e) {
            var t = e.labelId, r = e.text;
            void 0 !== t ? g.push(t) : g.push(r);
        });
    }), (null == p ? void 0 : p.length) && (f.showWordMouthTag = Ce(p), f.wordMouthTagInfo = Te(p), 
    f.showHighRepurchaseTag = !!Ee(p, z.bc.HIGH_REPURCHASE), f.showWholesaleTag = Ie(p), 
    f.showHighActivity = !!Ee(p, z.bc.HIGH_ACTIVITY), g.push.apply(g, V(p.map(function(e) {
        var t = e.markId;
        return "mark_id_".concat(t);
    })))), f.showLabelIds = g.join(","), f;
}, be = function(e, t) {
    var r = e.goodsMinCommissionPrice, a = e.goodsMaxCommissionPrice, n = e.goodsMinPrice, o = e.goodsMaxPrice, i = e.guaranteeModelList, s = e.feedsType, c = e.feedSubTypeCode, u = e.feedSn, p = e.combinationFeed;
    if (s === z.at.COMBINATION) return Y(Y({}, p), {}, {
        feedsType: s,
        feedSubTypeCode: c,
        feedSn: u
    });
    var l = Object.assign({}, e), d = a ? (0, z.i1)(r, a, 100) : "", h = W.default.price(n, 100), f = W.default.price(o, 100), g = h === f, m = (0, 
    z.p7)(e), v = m.promoInfo, _ = m.mallCouponEventVo, x = m.discount, y = void 0 === x ? 0 : x, S = m.helpSellCopyActivity, E = void 0 === S ? {} : S, T = m.activityType, I = m.activityStatus, C = m.quantityDiscountInfo, k = void 0 === C ? {} : C, b = m.activityTagVo, A = void 0 === b ? {} : b;
    if (A && A.tagShowVolist) {
        var P = !1;
        A.tagShowVolist = A.tagShowVolist.filter(function(e) {
            return e.typeId !== z.cw.COMMUNITY || (P = !0, !1);
        }), Object.assign(l, {
            activityTagVo: A,
            showCommunityGroupTag: P
        });
    }
    var R = Se({
        promoInfo: v,
        mallCouponEventVo: _
    }).concat(k.ruleList || []);
    return Y(Y({}, ke(l, t)), {}, {
        discount: y ? (y / 10).toFixed(1) : "",
        fmtPrice: g ? h : "".concat(h, "-").concat(f),
        isOpening: e.activityStatus === z.h.DOING,
        isDelete: e.activityStatus === z.h.DELETE,
        isOwner: (0, z.mq)(e.ownerUserNo),
        discountInfoList: R,
        canHelpSell: ye(E, T, I),
        goodsCommissionAmount: d,
        starTagServicePromiseVolist: (i || []).slice(0, 3)
    });
}, Ae = K.list.default, Pe = K.utils.safeGet;

exports.ae_ = be, exports.ago = ke, exports.ajf = Ce, exports.ai0 = Ie, exports.ais = Te, 
exports.agh = Ee, exports.agn = Se, exports.abn = ye, exports.ajb = xe;

var Re = function(e) {
    H(r, Ae);
    var t = j(r);
    function r() {
        var e;
        return G(this, r), (e = t.apply(this, arguments)).searchKeyword = "keyword", e.useSearch = !1, 
        e;
    }
    return B(r, [ {
        key: "request",
        value: function(e) {
            return (0, z.fy)(e);
        }
    }, {
        key: "afterFormatList",
        value: function(e) {
            var t = $(F(r.prototype), "afterFormatList", this).call(this, e);
            if (this.listId && Object.assign(t, {
                listId: this.listId
            }), this.useSearch) {
                var a = Pe(this.requestConfig, "data.".concat(this.searchKeyword));
                a && (t.trackingExtParams = Object.assign({}, t.trackingExtParams, {
                    search_key: a
                }));
            }
            return this.requestId && (t.trackingExtParams = Object.assign({}, t.trackingExtParams, {
                request_id: this.requestId
            })), t;
        }
    } ]), r;
}();

exports.ace = Re;

var Ne = (0, z.su)("1e557148-4a20-4602-ac17-71d5d7c5c409.png.slim.png"), we = (0, 
z.su)("ebe0e6a0-68d3-47aa-b551-9725f508764b.png.slim.png"), De = (0, z.su)("c8f40b29-7616-4cb9-bb8c-db033864e9d8.png.slim.png"), Oe = (0, 
z.jm)("ktt/gl.png.slim.png"), Le = (0, z.jm)("ktt/gn.png.slim.png"), Me = (0, z.jm)("ktt/gn.png.slim.png"), Ue = (0, 
z.jm)("ktt/go.png.slim.png"), qe = (0, z.jm)("ktt/gp.png.slim.png"), Ge = (0, z.jm)("ktt/gq.png.slim.png"), Be = (0, 
z.jm)("ktt/gr.png.slim.png"), $e = (0, z.jm)("ktt/gs.png.slim.png"), Fe = (0, z.jm)("ktt/gt.png.slim.png"), He = (0, 
z.jm)("ktt/gu.png.slim.png"), je = (0, z.su)("6a2c6ae9-dbae-48bb-8870-c49d87f98042.png.slim.png"), Ve = "给你推荐一个性价比超高的团购~", Ye = "快团团官方认证优质团长，快来加入我的团~", ze = "给你推荐超好用的社群团购小程序，快来使用吧~", We = "@团长，我在积分商城兑换了一个商品，记得发货哦", Ke = "你在转盘抽中的奖品未领取，填写物流信息立即领奖 ！", Je = "查收你的社群运营秘籍！", Xe = {
    title: Ve,
    path: z.ob.index,
    imageUrl: we
}, Qe = {
    title: Ye,
    path: z.ob.captain,
    imageUrl: Oe
}, Ze = {
    title: ze,
    path: z.ob.index,
    imageUrl: Le
}, et = {
    title: Ke,
    path: z.ob.lwLogisticsLanding,
    imageUrl: Be
}, tt = {
    title: Je,
    path: z.ob.groupTool,
    imageUrl: $e
}, rt = {
    LIST: 0,
    DEFAULT: 1,
    COPY: 2,
    LIVE: 3,
    OFFICE_LIBRARY: 4,
    OFFICIAL_HELP_SELL_ACTIVITY: 5,
    SIGN_UP: 6,
    LOTTERY: 7,
    COMMUNITY_PUBLIC: 9,
    COMMUNITY_PUBLIC_PLUS: 10,
    LOCAL_LIFE: 11,
    SELECT_CURRENT_ACTIVITY: 600
}, at = {
    VISIT: 0,
    FOLLOW: 1,
    SHARE: 2
}, nt = (q(r = {}, at.VISIT, "查看"), q(r, at.FOLLOW, "跟团"), q(r, at.SHARE, "分享"), 
r), ot = {
    normal: 0,
    wheel: 5,
    pointMall: 10,
    mall: 15,
    localLifeServer: 21
}, it = (q(a = {}, z.aq.express, {
    expressType: z.aq.express,
    expressValue: "快递"
}), q(a, z.aq.mention, {
    expressType: z.aq.mention,
    expressValue: "顾客自提"
}), q(a, z.aq.local, {
    expressType: z.aq.local,
    expressValue: "同城配送"
}), q(a, z.aq.noLogistics, {
    expressType: z.aq.noLogistics,
    expressValue: "无需物流"
}), a), st = {
    UNSET: -1,
    COMMISSION_RATE: 1,
    FREE_PRICING: 2
}, ct = {
    UNSET: -1,
    DISTRIBUTION_COMMISSION_RATE: 1,
    DISTRIBUTION_FREE_PRICING: 2,
    SHARE_COMMISSION_RATE: 3
};

exports._x = ct, exports.t4 = st, exports.vn = it, exports.s8 = {
    ALL: 0,
    NEW: 1
}, exports.u9 = ot, exports.wh = {
    normal: 1,
    mall: 2
}, exports.xt = nt, exports.xu = at, exports.xp = 5e5, exports.x1 = 20, exports.xr = 200, 
exports._v = 100, exports.yk = rt, exports.xq = 250, exports.u_ = {
    UNSET: 0,
    COPY_STATIC: 1,
    DIRECT_STATIC: 2
}, exports.we = tt, exports.xl = et, exports.uj = Ze, exports.u5 = Qe, exports.uz = Xe, 
exports.wf = Je, exports.xk = Ke, exports.x7 = "点击查看帮卖群发规则", exports.uv = We, exports.uw = ze, 
exports.u2 = Ye, exports.ux = "给你推荐一个性价比超高的商品~", exports.u3 = Ve, exports.us = je, 
exports.xh = He, exports.zo = Fe, exports.wc = $e, exports.xj = Be, exports.x6 = Ge, 
exports.u1 = qe, exports.un = Ue, exports.uo = Me, exports.ui = Le, exports.ur = Oe, 
exports.up = De, exports.uy = we, exports.u0 = Ne;

var ut = (0, z.jm)("ktt/fx.png.slim.png"), pt = (0, z.jm)("ktt/fy.png.slim.png");

function lt(e) {
    return e ? "我发现了".concat(e, "有超好的商品，推荐给你~") : Ve;
}

exports.uu = pt, exports.uq = ut, exports.ahq = function(e) {
    return !!(e || []).filter(function(e) {
        var t = e.expressStatus, r = e.expressType, a = e.shippingCostType;
        return t === z.ap.VALID && r === z.aq.express && a === z.ch.WEIGHT_CHARGE;
    }).length;
};

var dt = {
    wheel: 0,
    machine: 1
}, ht = (q(n = {}, dt.wheel, {
    name: "幸运大转盘",
    logo: (0, z.jm)("ktt/fz.png"),
    tip: "建议设置3-5个奖品活动效果最好",
    payPopIcon: (0, z.jm)("ktt/f0.png.slim.png")
}), q(n, dt.machine, {
    name: "幸运大抽奖",
    logo: (0, z.jm)("ktt/f1.png.slim.png"),
    tip: "建议至少设置2个奖品效果最好",
    payPopIcon: (0, z.jm)("ktt/f2.png.slim.png")
}), n), ft = (q(o = {}, rt.LIST, {}), q(o, rt.DEFAULT, {
    icon: "https://funimg.pddpic.com/wxappimg/58e60884-a237-492f-9700-5f0f6d2cef1a.png.slim.png",
    iconClass: "icon-image"
}), q(o, rt.LOCAL_LIFE, {
    icon: "https://funimg.pddpic.com/wxappimg/d3f8e5b6-8481-4a7b-94e2-65f308c608b2.png.slim.png",
    iconClass: "icon-image",
    desc: "创建本地生活团购",
    subInfo: "适合线上购买，到店核销的消费场景"
}), q(o, rt.COPY, {
    icon: "https://funimg.pddpic.com/wxappimg/d96af840-5487-4e0f-9644-71a9f86afa46.png.slim.png",
    iconClass: "icon-image"
}), q(o, rt.LIVE, {
    icon: "https://funimg.pddpic.com/wxappimg/8bfdef5e-0e4e-418d-9941-91d8c8a5ae68.png.slim.png",
    iconClass: "icon-image",
    subInfo: "直播带货"
}), q(o, rt.OFFICIAL_HELP_SELL_ACTIVITY, {
    icon: (0, z.jm)("ktt/f6.png.slim.png"),
    iconClass: "icon-image",
    desc: "官方团购，一键帮卖",
    subInfo: "高额佣金，优选货源，售后无忧"
}), q(o, rt.SIGN_UP, {
    icon: "https://funimg.pddpic.com/wxappimg/0dc6370b-b5c5-4689-8068-58ad4b2fc8d5.png.slim.png",
    iconClass: "icon-image",
    desc: "报名活动",
    subInfo: "活动报名统计"
}), q(o, rt.LOTTERY, {
    icon: (0, z.jm)("ktt/f8.png.slim.png"),
    iconClass: "icon-image",
    desc: "抽奖团购",
    subInfo: ""
}), q(o, rt.COMMUNITY_PUBLIC, {
    icon: "https://funimg.pddpic.com/wxappimg/c9abe0ed-685b-4151-914a-8c29abfab3a5.png.slim.png",
    iconClass: "icon-image",
    desc: "创建小区物资团购 (上海专用)",
    cornerTag: (0, z.jm)("ktt/f_.png")
}), q(o, rt.COMMUNITY_PUBLIC_PLUS, {
    icon: "https://funimg.pddpic.com/wxappimg/c9abe0ed-685b-4151-914a-8c29abfab3a5.png.slim.png",
    iconClass: "icon-image",
    desc: "创建小区团购"
}), q(o, rt.SELECT_CURRENT_ACTIVITY, {
    icon: (0, z.jm)("ktt/f-.png.slim.png"),
    iconClass: "icon-image",
    desc: "选择现有团购"
}), o), gt = {
    ALL: -122,
    SUPPLIER_GROUP: -1,
    NORMAL: 1,
    DISTRIBUTION: 2,
    DISTRIBUTION_HELPER: 3,
    SHARE_HELP_SELL: 4,
    MALL_GROUP: 21,
    POINT_GROUP: 22,
    WHEEL_GROUP: 23
}, mt = {
    NORMAL: 0,
    GOODS_GROUP: 1,
    NEW_GROUP: 2,
    STAR: 3,
    COMMUNITY: 4,
    ONE_FOR_DELIVERY: 5
}, vt = [ {
    type: gt.ALL,
    name: "全部",
    isActive: !0
}, {
    type: gt.SUPPLIER_GROUP,
    name: "我发布的",
    isActive: !1
}, {
    type: gt.DISTRIBUTION_HELPER,
    name: "我帮卖的",
    isActive: !1
} ], _t = {
    dataCenter: "ktt_data_center",
    kttHelpSell: "ktt_help_sell",
    kttAssistGuide: "ktt_assist_guide",
    kttOrderNote: "ktt_order_note",
    kttChatManager: "ktt_chat_manager",
    kttCreateChainBanRule: "ktt_create_chain_ban_rule",
    kttChatManagerNew: "ktt_chat_manager_new",
    supplyChainTutor: "ktt_supply_chain_tutor",
    kttExclusivePlanModify: "ktt_exclusive_plan_modify",
    createChainGuide: "ktt_chain_create_guide",
    kttRelateWechat: "ktt_relate_wechat",
    redPacketPromote: "ktt_red_packet_promote",
    inputCouponGuide: "ktt_input_coupon_guide",
    learningCenter: "ktt_learning_center",
    kttchatChooseRole: "kttchat_choose_role",
    kttchatChatDetail: "kttchat_chat_detail",
    kttchatChatDetailQA: "kttchat_chat_detail_QA",
    pointManage: "ktt_point_manage",
    kttExpressTeach: "ktt_express_teach",
    learingCreateChainGuide: "ktt_learning_center_landing",
    kttVipGuide: "ktt_vip_guide",
    supplyChainRecommend: "ktt_supply_chain_recommend",
    supplyChainHotSell: "ktt_supply_chain_hot_sell",
    supplyChainHelpCenter: "ktt_supply_chain_help_center",
    promotionDbTwelve: "ktt_promotion_db_twelve",
    pointMall: "ktt_point_mall",
    kttPointRule: "ktt_point_rule",
    promoGamesIntro: "ktt_discount_games_intro",
    pointGoodsLanding: "ktt_point_goods_landing",
    signActivityGuide: "ktt_sign_activity_guide",
    kttInviteToMakeMoneyRuleChange: "ktt_invite_to_make_money_rule_change",
    kttInviteToMakeMoneyRule: "ktt_invite_to_make_money_rule",
    shareOrderGuide: "ktt_share_order_guide",
    trafficDictionary: "ktt_traffic_dictionary",
    kttHelpsellPromotionRule: "ktt_helpsell_promotion_rule",
    kttHelpsellPromotionIntro: "ktt_helpsell_promotion_intro",
    kttHelpsellPromotionDetail: "ktt_helpsell_promotion_detail",
    kttHelpSellNewbieCourse: "ktt_help_sell_newbie_course",
    kttNovicesMustToSee: "ktt_novices_must_to_see",
    captainSalesGifts: "ktt_captain_sales_gifts",
    secondCaptainSalesGifts: "ktt_second_captain_sales_gifts",
    kttInputCouponGuide: "ktt_input_coupon_guide",
    kttHelpSellWordOfMouth: "ktt_help_sell_word_of_mouth",
    kttCouponPush: "ktt_coupon_push",
    kttFreeCharge: "ktt_free_charge",
    kttShareCouponGuide: "ktt_share_coupon_guide",
    kttCouponDescription: "ktt_coupon_description",
    kttNewTrainGuide: "ktt_new_train_guide",
    kttPullNewGuide: "ktt_pull_new_guide",
    kttDefaultMsgPreview: "ktt_default_msg_preview",
    kttPromoLinkTutor: "ktt_promo_link_tutor",
    kttCreateActivityGuide: "ktt_create_activity_guide",
    kttCommunitySupplyGroup: "ktt_community_supply_group",
    kttGroupOperationGuide: "ktt_group_operation_guide",
    kttGrowthPlan: "ktt_growth_plan",
    kttPromoLinkData: "ktt_promo_link_data",
    kttLuckyDrawGuide: "ktt_lucky_draw_guide",
    kttExclusivePlanCreate: "ktt_exclusive_plan_create",
    kttInviteIncomeCenter: "ktt_invite_income_center",
    kttInviteRelationship: "ktt_invite_relationship",
    kttGroupChatData: "ktt_group_chat_data",
    kttChannelSubscribeIntro: "ktt_channel_subscribe_intro",
    kttChannelSubscribeData: "ktt_channel_subscribe_data",
    kttSeptemberPromotion: "ktt_september_promotion",
    kttLogisticsAffectedAreas: "ktt_logistics_affected_areas",
    kttGetNewIntroduce: "ktt_get_new_introduce",
    kttInviteNewGetCodeIntroduce: "ktt_invite_new_get_code_introduce",
    kttOrderOperationLog: "ktt_order_operation_log",
    kttOctAutumn: "ktt_oct_autumn",
    kttUpdateAlbum: "ktt_update_album",
    kttLocalLifeVerifyLaunch: "ktt_local_life_verify_launch",
    kttCustomerServiceDataStatistics: "ktt_customer_service_data_statistics",
    kttInfringementComplaintReview: "ktt_infringement_complaint_review",
    kttSupplyChainFestival: "ktt_supply_chain_festival"
};

function xt(e) {
    var t = e.page_name, r = e.page_sn, a = e.share_id, n = e.scene, o = e.extParams, i = void 0 === o ? {} : o;
    r && (0, z.ho)({
        page_name: t,
        page_sn: r,
        op: "event",
        sub_op: "share",
        extParams: Y({
            code: n,
            share_channel: "message",
            share_form: "card",
            share_id: a
        }, i)
    });
}

function yt(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : z.cp.NORMAL, r = (0, 
    z.gc)().getStoreSync("firstJumpIndex", !1), a = (0, z.gc)().getStoreSync("firstJumpCommunityList", !1), n = (0, 
    z.gc)().getStoreSync("firstJumpLocalLiveList", !1);
    if (e === z.ob.activity) {
        if (a && t === z.cp.COMMUNITY_PUBLIC) return z.ob.communityShopGroup;
        if (r) return z.ob.index;
    } else if (n && e === z.ob.localLivingActivity) return z.ob.captainLocalLivingGoods;
    return e;
}

function St(e) {
    var t, r, a, n, o, i = (0, z.fz)();
    return e && (r = e.title || "", n = e.imageUrl || "", o = Y(Y({}, e.params || {}), {}, (q(t = {}, z.gf.refShareUserNo, (0, 
    z.ln)()), q(t, "ref_share_channel", "message"), q(t, "ref_share_id", i), t)), a = (0, 
    z.e4)(yt(e.path || z.ob.index, e.subActivityType), o)), {
        title: r,
        path: a,
        imageUrl: n,
        shareId: i,
        baseShareInfo: o
    };
}

function Et() {
    return (Et = U(M.default.mark(function e(t) {
        var r, a, n, o, i;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.collectionActivityNo, e.next = 3, this.$generalShareTicket({
                    data: {
                        shareScene: z.cr.MALL_SHARE,
                        collectionActivityNo: r
                    }
                }, !0, !1).catch(z.hm);

              case 3:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 6;
                    break;
                }
                e.t0 = {};

              case 6:
                return a = e.t0, n = a.result, o = (n = void 0 === n ? {} : n).imageUrl, i = n.shareText, 
                e.abrupt("return", {
                    imageUrl: o,
                    shareText: i
                });

              case 11:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

function Tt() {
    return (Tt = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.collectionActivityNo, a = t.parentOrderSn, e.next = 3, this.$generalShareTicket({
                    data: {
                        shareScene: z.cr.MALL_ORDER_HELP_SELL_SHARE,
                        collectionActivityNo: r,
                        parentOrderSn: a
                    }
                }, !0, !1).catch(z.hm);

              case 3:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 6;
                    break;
                }
                e.t0 = {};

              case 6:
                return n = e.t0, o = n.result, i = (o = void 0 === o ? {} : o).imageUrl, s = o.shareText, 
                e.abrupt("return", {
                    imageUrl: i,
                    shareText: s
                });

              case 11:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

function It() {
    return (It = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.collectionActivityNo, a = t.goodsId, e.next = 3, this.$generalShareTicket({
                    data: {
                        shareScene: z.cr.POINT_GOODS_SHARE,
                        collectionActivityNo: r,
                        goodsId: a
                    }
                }, !0, !1).catch(z.hm);

              case 3:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 6;
                    break;
                }
                e.t0 = {};

              case 6:
                return n = e.t0, o = n.result, i = (o = void 0 === o ? {} : o).imageUrl, s = o.shareText, 
                e.abrupt("return", {
                    imageUrl: i,
                    shareText: s
                });

              case 11:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

function Ct(e, t) {
    var r = ((0, z.ll)() || {}).userNo, a = this.pageProperties || {}, n = a.page_sn, o = a.page_name, i = (0, 
    z.fz)() || "", s = {
        params: {
            ref_share_channel: "message",
            ref_share_id: i,
            ref_share_user_no: r
        },
        path: z.ob.index
    }, c = (0, z.jo)(e, "shareinfo") || t.shareinfo || {}, u = Y(Y({}, s.params), c.params || {}), p = {
        path: (0, z.e4)(yt(c.path || s.path, c.subActivityType), u),
        title: c.title || Xe.title,
        imageUrl: c.imageUrl || Xe.imageUrl
    };
    this.leaveType = "share", this.share_id = i, this.share_url = p.path;
    var l = {
        page_name: o,
        page_sn: n,
        share_id: i
    };
    t.scene && (l.code = t.scene), function(e) {
        var t = e.page_name, r = e.page_sn, a = e.share_id, n = e.code;
        r && (0, z.ho)({
            page_name: t,
            page_sn: r,
            op: "event",
            sub_op: "share",
            extParams: {
                code: n,
                share_channel: "message",
                share_form: "card",
                share_id: a
            }
        });
    }(l);
    var d = getCurrentPages() || [], h = d[d.length - 1] || {};
    return (0, z.re)(Y(Y({}, p), {}, {
        shareRouter: t.shareinfo.trackShareRouter || "/".concat(h.route),
        shareRouterPosition: t.shareinfo.trackShareRouterPosition || "menu",
        shareStatus: t.shareinfo.trackShareStatus,
        shareType: "card",
        shareCardTime: t.shareinfo.trackShareCardTime || new Date().getTime() - (t.shareinfo.trackShareStartTime || 0)
    })), p;
}

exports.aix = {
    xcAddByActivity: "/promotion_op.html?type=49&id=177425",
    expressTeach: "/promotion_op.html?type=49&id=162731",
    orderCouponTeach: "/promotion_op.html?type=49&id=160074",
    chatSystemGuide: "/promotion_op.html?type=49&id=162846",
    helpSellIntroduceExample: "/promotion_op.html?type=49&id=162088",
    mallSpikeLanding: "/promotion_op.html?type=49&id=162946",
    mallDiscountLanding: "/promotion_op.html?type=49&id=163066",
    activityLeadGuide: "/promotion_op.html?type=49&id=163980",
    prizeWheelLanding: "/promotion_op.html?type=49&id=164331",
    ladderPriceTeach: "/promotion_op.html?type=49&id=164494",
    groupCategorySetting: "/promotion_op.html?type=49&id=171789",
    xcMaterialLibrary: "/promotion_op.html?type=49&id=173545",
    crmTeachLanding: "/promotion_op.html?type=49&id=174481"
}, exports.aku = {
    afterSaleApply: "/complaint.html",
    afterSaleDetail: "/complaint_detail.html",
    compensation: "/complaints_compensation.html?mode=description"
}, exports.aiw = _t, exports.yi = vt, exports.wm = mt, exports.yj = gt, exports._8 = ft, 
exports.aak = ht, exports.aaj = dt, exports.tk = {
    NOT: 0,
    FIRST: 1,
    SECOND: 2,
    THIRD: 3
}, exports._l = {
    HIDDEN: 0,
    LIMIT_20_SHOW: 1,
    SHOW: 2
};

var kt = function(e) {
    H(r, Re);
    var t = j(r);
    function r() {
        var e, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return G(this, r), (e = t.call(this, {
            requestConfig: Y({
                url: "/api/ktt_gateway/activity/feeds/home_page/v3",
                auth: !1,
                noErrorToast: !0,
                convertToCamel: !0,
                convertRequestToSnake: !0,
                logFilter: z.ib
            }, a),
            useListId: !0,
            pageSize: 10,
            key: "activityNo",
            name: "FeedHomePageModel"
        })).useSearch = !0, e.searchKeywordCorrection = "", e;
    }
    return B(r, [ {
        key: "formatList",
        value: function(e) {
            var t = e.list.map(function(e) {
                return be(e);
            });
            if (this.pageNumber === this.initialPageNumber && !t.length) {
                var r = this.requestConfig, a = r.url, n = r.data, o = void 0 === n ? {} : n;
                (0, z.ev)({
                    type: z.u.SEARCH_EMPTY,
                    tags: {
                        url: a,
                        tab: o.tab,
                        isSearch: !!o.keyword
                    }
                });
            }
            return this.searchKeywordCorrection = e.searchKeywordCorrection || "", t;
        }
    } ]), r;
}();

exports.ae0 = kt;

var bt = {
    page_sn: 32989,
    page_name: "ktt_activity"
}, At = {
    page_sn: "32988",
    page_name: "ktt_chaindetail"
}, Pt = {
    page_sn: 33879,
    page_name: "ktt_index"
}, Rt = {
    page_sn: "56745",
    page_name: "ktt_my_order_list_of_activity"
}, Nt = {
    page_sn: 32994,
    page_name: "ktt_orderdetail"
}, wt = {
    page_sn: 32984,
    page_name: "ktt_newpersonal"
}, Dt = {
    page_sn: 33348,
    page_name: "ktt_captain"
}, Ot = {
    page_sn: 33347,
    page_name: "ktt_finance"
}, Lt = {
    page_sn: 61720,
    page_name: "ktt_all_order_manage"
}, Mt = {
    page_sn: 53893,
    page_name: "ktt_order_manage"
}, Ut = {
    BAR: 0,
    DIALOG: 1
}, qt = 604800, Gt = {
    BAR: 0,
    DIALOG: 1,
    GROUP_BAR: 2,
    GROUP_DIALOG: 3,
    NONE: 4
}, Bt = {
    INDEX: {
        pageName: Pt.page_name,
        action: Ut.BAR,
        id: 4173642
    },
    INDEX_ORDER: {
        pageName: "".concat(Pt.page_name, "_order"),
        action: Ut.BAR,
        id: 2641752
    },
    INDEX_ORDER_DIALOG: {
        pageName: "".concat(Pt.page_name, "_order"),
        action: Ut.DIALOG,
        id: 4175788
    },
    INDEX_REFUND_DIALOG: {
        pageName: "".concat(Pt.page_name, "_refund"),
        action: Ut.DIALOG,
        id: 4175751
    },
    INDEX_COMMENT_DIALOG: {
        pageName: "".concat(Pt.page_name, "_comment"),
        action: Ut.DIALOG,
        id: 4175752,
        expectShowCd: qt
    },
    INDEX_ORDER_SUBSCRIBR: {
        pageName: "".concat(Pt.page_name, "_order_subscribe"),
        action: Ut.BAR,
        id: 4320015
    },
    COMPLEX_ORDER_SUBSCRIBE: {
        pageName: "ktt_complex_order_list_subscribe",
        action: Ut.BAR,
        id: 5307754
    },
    COMPLEX_ORDER_DIALOG: {
        pageName: "ktt_complex_order_list_subscribe",
        action: Ut.DIALOG,
        id: 111,
        expectShowCd: qt
    },
    ORDER_MANAGE: {
        pageName: Mt.page_name,
        action: Ut.BAR,
        id: 6463021,
        closePageElSn: 6463691
    },
    ORDER_MANAGE_DIALOG: {
        pageName: Mt.page_name,
        action: Ut.DIALOG,
        id: 4176410,
        expectShowCd: qt
    },
    PERSON_CENTER: {
        pageName: wt.page_name,
        action: Ut.BAR,
        id: 4173700
    },
    PERSON_CENTER_DIALOG: {
        pageName: wt.page_name,
        action: Ut.DIALOG,
        id: 4696816,
        expectShowCd: qt
    },
    CAPTAIN: {
        pageName: Dt.page_name,
        action: Ut.BAR,
        id: 6463021,
        closePageElSn: 6463691
    },
    CAPTAIN_2C: {
        pageName: "".concat(Dt.page_name, "_2c"),
        action: Ut.BAR,
        id: 4175466
    },
    CHAIN_DETAIL: {
        pageName: At.page_name,
        action: Ut.BAR,
        id: 4174641
    },
    ACTIVITY: {
        pageName: bt.page_name,
        action: Ut.BAR,
        id: 4174639
    },
    ACTIVITY_2C: {
        pageName: "".concat(bt.page_name, "_2c"),
        action: Ut.BAR
    },
    ALL_ORDER_MANAGE: {
        pageName: Lt.page_name,
        action: Ut.BAR,
        id: 6463021,
        closePageElSn: 6463691
    },
    ALL_ORDER_MANAGE_DIALOG: {
        pageName: Lt.page_name,
        action: Ut.DIALOG,
        id: 4176448,
        expectShowCd: qt
    },
    ORDER_DETAIL: {
        pageName: Nt.page_name,
        action: Ut.BAR,
        id: 2642106
    },
    ORDER_DETAIL_DIALOG: {
        pageName: Nt.page_name,
        action: Ut.DIALOG,
        id: 4175834,
        expectShowCd: qt
    },
    ORDER_DETAIL_REFUND_DIALOG: {
        pageName: "".concat(Pt.page_name, "_refund"),
        action: Ut.DIALOG,
        id: 4176371
    },
    ORDER_DETAIL_COMMENT_DIALOG: {
        pageName: "".concat(Pt.page_name, "_comment"),
        action: Ut.DIALOG,
        id: 4176372
    },
    ORDER_DETAIL_NORMAL_SUBSCRIBE: {
        pageName: "ktt_order_detail_normal_subscribe",
        action: Ut.BAR,
        id: 4320026
    },
    FINANCE: {
        pageName: Ot.page_name,
        action: Ut.BAR,
        id: 2641863
    },
    FINANCE_DIALOG: {
        pageName: Ot.page_name,
        action: Ut.DIALOG,
        id: 4176468
    },
    MY_ORDER_LIST_OF_ACTIVITY: {
        pageName: Rt.page_name,
        action: Ut.BAR,
        id: 4175658
    },
    MY_ORDER_LIST_OF_ACTIVITY_DIALOG: {
        pageName: Rt.page_name,
        action: Ut.DIALOG,
        id: 4213790
    },
    MY_ORDER_LIST_OF_ACTIVITY_REFUND_DIALOG: {
        pageName: "".concat(Pt.page_name, "_refund"),
        action: Ut.DIALOG,
        id: 4175789
    },
    MY_ORDER_LIST_OF_ACTIVITY_COMMENT_DIALOG: {
        pageName: "".concat(Pt.page_name, "_comment"),
        action: Ut.DIALOG,
        id: 4175790
    },
    OPERATE_ACTIVITY: {
        pageName: "ktt_operate_activity_after_share",
        action: Ut.DIALOG,
        id: ""
    },
    HELP_TO_SELL_DIALOG: {
        pageName: "ktt_help_to_sell",
        action: Ut.DIALOG,
        expectShowCd: 86400,
        id: ""
    },
    APPLY_TO_HELP_SELL_DIALOG: {
        pageName: "ktt_apply_to_help_sell",
        action: Ut.DIALOG,
        expectShowCd: 86400,
        id: 4579309
    },
    CHAT_CENTER: {
        pageName: "ktt_chat_center",
        action: Ut.BAR
    },
    PART_COMMISSION_MANAGER: {
        pageName: "ktt_supply_detail",
        action: Ut.BAR,
        id: 6463021,
        closePageElSn: 6463691
    },
    INDEX_FEEDS_ITEM: {
        pageName: "".concat(Pt.page_name, "_feeds_item"),
        action: Gt.NONE
    }
};

exports.sx = Bt, exports.sy = Gt, exports.sw = Ut, exports.s0 = {
    page_sn: "112335",
    page_name: "ktt_activity_featured_material"
}, exports.x9 = {
    page_sn: 86320,
    page_name: "my_group_order"
}, exports.yu = Mt, exports.s7 = Lt, exports.vw = Ot, exports.tl = Dt, exports.xc = {
    page_sn: 85010,
    page_name: "ktt_person_center_to_c"
}, exports.y_ = wt, exports.yq = Nt, exports._q = {
    page_sn: "104610",
    page_name: "sms_payment_result"
}, exports.x8 = {
    page_sn: 114245,
    page_name: "ktt_multi_order_checkout"
}, exports._o = {
    page_sn: "110797",
    page_name: "ktt_sign_up_checkout"
}, exports.yo = {
    page_sn: "32991",
    page_name: "ktt_orderCheckout"
}, exports.x_ = Rt, exports.x0 = {
    page_sn: 99356,
    page_name: "ktt_mid_share"
}, exports.wy = Pt, exports.tt = {
    page_sn: 76806,
    page_name: "ktt_chat_system_detail"
}, exports.aal = {
    page_sn: "107758",
    page_name: "ktt_xc_add_by_activity"
}, exports.tq = At, exports.sz = bt;

var $t = {
    url: "/api/ktt_group/activity_goods/query_goods_atmosphere",
    noErrorToast: !0,
    convertToCamel: !0,
    logFilter: z.h1
};

function Ft() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_gameplay/lucky_wheel/cus/get_wheel_activity_no"
    }, e), {}, {
        convertToCamel: !0
    }));
}

exports.alk = $t;

exports.ai6 = {
    url: "/api/ktt_rec/rec_feeds/ignore_activity_suggest",
    method: "POST",
    noErrorToast: !0,
    convertToCamel: !1,
    convertRequestToSnake: !0
}, exports.afq = {
    url: "/api/ktt_rec/rec_feeds/comment_goods_selection_keyword",
    method: "POST",
    noErrorToast: !0,
    convertToCamel: !1,
    convertRequestToSnake: !0
}, exports.all = {
    url: "/api/ktt_rec/rec_feeds/query_goods_selection_keyword",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.aly = {
    url: "/api/ktt_rec/rec_feeds/query_today_todo_list_detail",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.al8 = {
    url: "/api/ktt_rec/rec_feeds/query_today_todo_list_num",
    method: "POST",
    convertToCamel: !1,
    convertRequestToSnake: !0,
    noErrorToast: !0
};

var Ht = {
    modify: 1,
    oneClick: 2
}, jt = (q(i = {}, z.be.PRIMARY, {
    icon: "https://funimg.pddpic.com/wxappimg/a7bd544d-f0de-40b6-8e82-38b1d18d1a17.png.slim.png",
    rate: "91.87%"
}), q(i, z.be.MIDDLE, {
    icon: "https://funimg.pddpic.com/wxappimg/d5b074d3-455b-48ef-8cef-a1b73d2b42f3.png.slim.png",
    rate: "96.52%"
}), q(i, z.be.HIGH, {
    icon: "https://funimg.pddpic.com/wxappimg/dcfdcbaa-ae47-4b12-a173-7a69fd729475.png.slim.png",
    rate: "98.83%"
}), q(i, "defaultIcon", "https://funimg.pddpic.com/wxappimg/027434c1-7a54-4833-b57f-a68e85cb1e42.png.slim.png"), 
i);

function Vt() {
    var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, a = r.isSelf, n = void 0 !== a && a, o = r.activityParams, i = void 0 === o ? {} : o, s = r.isReload, c = void 0 !== s && s, u = r.ownerUserNo, p = void 0 === u ? "" : u, l = r.displayType, d = void 0 === l ? ot.normal : l, h = r.isCoronaGroup, f = void 0 !== h && h, g = "", m = (q(e = {}, z.gf.collectionActivityNo, t), 
    q(e, z.gf.sceneActivityNo, ""), e);
    if (d === ot.mall) g = n ? z.ob.mallHome : z.ob.captainShop; else {
        var v;
        if (d === ot.pointMall) return void ((0, z.mr)(p) || p === (0, z.kp)() || n ? (c ? z.n8 : z.n5)({
            pageName: _t.pointManage,
            params: q({}, z.gf.sceneActivityNo, "")
        }) : (c ? z.n8 : z.n5)({
            pageName: _t.pointMall,
            params: (v = {}, q(v, z.gf.ownerUserNo, p), q(v, z.gf.sceneActivityNo, ""), v)
        }));
        d === ot.normal ? f ? g = z.ob.signUpCheckout : n ? (g = z.ob.chainDetail, Object.assign(m, i), 
        delete m[z.gf.sceneActivityNo]) : (g = z.ob.activity, Object.assign(m, i)) : d === ot.localLifeServer ? (delete m[z.gf.collectionActivityNo], 
        g = z.ob.index) : g = z.ob.index;
    }
    t && (c ? z.n7 : z.n3)({
        url: g,
        params: m
    });
}

exports.v1 = {
    NONE: 0,
    HELP_SELL_RANKING: 1
}, exports.v2 = {
    ACTIVITY: 1,
    ACTIVITY_TOPIC: 2,
    SPRING_FESTIVAL_NO_CLOSE: 3,
    COMBINATION: 4
}, exports.xo = jt, exports.t5 = {
    HELP_SELL: 1,
    SITE_SELL: 2,
    REC_SELL: 3,
    CAPTAIN_SELL: 4,
    FREE_HELP_SELL: 5
}, exports.zv = {
    CAN_SELL: 2,
    FIRST_ACCEPT: 0,
    ACCEPTED: 1
}, exports.w4 = 1, exports.sv = {
    FIRST_ACCEPT: 0,
    ACCEPTED: 1,
    NOT_PART_HELP_SELL: 2,
    NEED_AUDIT: 3
}, exports.vp = {
    BLACK_HELPSELLER: 1,
    VIEW_DETAIL: 2,
    COLLECTION: 3
}, exports.aks = {
    ALL: 0,
    PART: 1
}, exports.akr = {
    ALL: "ALL",
    PART: "PART"
}, exports.wn = Ht, exports.va = .1, exports.aa5 = {
    url: "/api/ktt_group/activity_operate/batch_one_click_create_help_sell",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.al6 = {
    url: "/api/ktt_group/assistant/query_rec_sc_resource_info_list",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.al5 = {
    url: "/api/ktt_group/activity_feeds/query_smart_assistant_today_rec_feeds",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.al7 = {
    url: "/api/ktt_group/assistant/query_smart_recommend_type",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.al_ = {
    url: "/api/ktt_rec/rec_feeds/query_under_stock_goods",
    method: "POST",
    noErrorToast: !1,
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ale = {
    url: "/api/ktt_rec/rec_feeds/query_can_help_sell_star_activity_by_rec",
    convertToCamel: !0,
    convertRequestToSnake: !0
};

var Yt = function() {
    var e = U(M.default.mark(function e() {
        var t, r, a, n, o, i = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = i.length > 0 && void 0 !== i[0] ? i[0] : "", r = i.length > 1 && void 0 !== i[1] ? i[1] : {}, 
                void 0 === (a = r.displayType) || a !== ot.wheel) {
                    e.next = 9;
                    break;
                }
                return e.next = 6, Ft({
                    data: {
                        shadow_activity_no: t
                    },
                    noErrorToast: !0
                });

              case 6:
                return n = e.sent, o = n.result, e.abrupt("return", (o || {}).activityNo);

              case 9:
                return e.abrupt("return", t);

              case 10:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}();

function zt(e) {
    var t = e.activityNo, r = e.requestParams, a = void 0 === r ? {} : r, n = e.params, o = void 0 === n ? {} : n, i = e.beforeForward;
    (0, z.rg)({
        title: "创建中",
        mask: !0
    });
    var s = (0, z.ge)(), c = (0, z.j4)((0, z.p7)(o, {
        clearEmptyString: !0
    }));
    return (0, z.fy)(Y(Y({}, z.n_), {}, {
        data: Y(Y({
            supply_activity_no: t
        }, a), {}, {
            operate_channel_info: JSON.stringify({
                operateFirstChannel: c[z.gf.recChainSrc],
                operateSecondaryChannel: c[z.gf.subChainSrc],
                requestId: c[z.gf.requestId] || "",
                referPageId: null == s ? void 0 : s.$pageId
            })
        })
    })).then(function(e) {
        var t, r = e.result;
        (0, z.l3)();
        var a = r.activityNo;
        i && i(r), (0, z.n3)({
            url: z.ob.chainDetail,
            params: (0, z.p7)(Y(Y({}, o), {}, (t = {}, q(t, z.gf.collectionActivityNo, a), q(t, "is_create", 1), 
            q(t, z.gf.helpSellType, Ht.oneClick), t)), {
                clearEmptyString: !0
            })
        }), (0, z.ev)({
            type: z.u.ACTIVITY_CREATE,
            tags: {
                cp: "oneClick",
                activityType: z.b.DISTRIBUTION_HELPER,
                isModify: !1
            }
        });
    }).catch(function(e) {
        throw (0, z.l3)(), e;
    });
}

exports.aif = Yt;

var Wt = {}, Kt = {
    getNavInitData: function(e) {
        var t, r, a = {};
        return null === (t = this.$currentPage) || void 0 === t || t.$eventChannel.once(e, function(e) {
            a = e;
        }), null === (r = this.$currentPage) || void 0 === r || r.$eventChannel.cancel(e), 
        a;
    },
    setNavInitData: function(e, t) {
        var r, a;
        null === (r = this.$currentPage) || void 0 === r || r.$eventChannel.cancel(e), null === (a = this.$currentPage) || void 0 === a || a.$eventChannel.emitPromise(e, t);
    },
    setActivityInitData: function(e) {
        var t = e.displayType, r = void 0 === t ? ot.normal : t, a = e.isCoronaGroup, n = e.ownerUserNo, o = e.activityBgUrl;
        r !== ot.normal || a || (0, z.mq)(n) || (o && (e.imgPreloadPromise = (0, z.oo)(o + "?imageMogr2/strip%7CimageView2/1/w/375/h/200/q/50")), 
        this.setNavInitData(z.f1.setActivityInitData, e));
    }
}, Jt = Y({
    data: Wt
}, Kt), Xt = (0, z.gg)({
    data: Wt,
    methods: Kt
}), Qt = K.utils.FrontError;

exports.aj9 = Xt, exports.aen = Jt;

var Zt = {
    shareHelpSellLink: function(e) {
        var t, r = e.status, a = e.activityNo;
        return r === z.s.CAN_SHARE_SELL ? (t = U(M.default.mark(function e(t) {
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.t0 = !!t, !e.t0) {
                        e.next = 8;
                        break;
                    }
                    return e.next = 4, (0, z.fy)({
                        url: "/api/ktt_group/activity_operate/create_help_sell_share_activity",
                        convertToCamel: !0,
                        noErrorToast: !0,
                        noSignRetry: !0,
                        data: {
                            supply_activity_no: t
                        }
                    });

                  case 4:
                    if (e.t1 = e.sent, e.t1) {
                        e.next = 7;
                        break;
                    }
                    e.t1 = {};

                  case 7:
                    e.t0 = !!e.t1.success;

                  case 8:
                    return e.abrupt("return", e.t0);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function(e) {
            return t.apply(this, arguments);
        })(a) : Promise.resolve();
    },
    forwardGroupByEvent: function(e) {
        var t, r, a = (0, z.jo)(e), n = a.activityNo, o = a.topicNo, i = a.ownerUserNo, s = a.displayType, c = a.isCoronaGroup, u = a.mock, p = a.requestId, l = a.link, d = a.feedsType, h = a.feedSn, f = a.jumpToGoods, g = a.enablePreload;
        return l ? (0, z.n3)({
            url: l,
            params: d === z.at.COMBINATION ? (t = {}, q(t, z.gf.recChainSrc, z.b4.customThemeActivity), 
            q(t, z.gf.subChainSrc, h), t) : {}
        }) : o ? (0, z.n3)({
            url: z.ob.topicActivity,
            params: {
                activityTopicNo: o
            }
        }) : (g && this.setActivityInitData(a), void Vt(n, {
            isSelf: (0, z.mq)(i),
            displayType: s,
            isCoronaGroup: c,
            activityParams: (r = {}, q(r, z.gf.isMock, u ? 1 : 0), q(r, z.gf.requestId, p), 
            q(r, z.gf.scrollToGoodsOrOpenSku, f ? 1 : ""), r)
        }));
    },
    getParamsWithShareSell: function(e, t) {
        var r = arguments, a = this;
        return U(M.default.mark(function n() {
            var o, i, s, c;
            return M.default.wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (o = r.length > 2 && void 0 !== r[2] ? r[2] : {}, (i = t.status) !== z.s.CAN_SHARE_SELL) {
                        n.next = 9;
                        break;
                    }
                    return s = (0, z.jo)(e), c = s.activityNo, n.next = 6, a.shareHelpSellLink({
                        activityNo: c,
                        status: i
                    }).catch(z.hm);

                  case 6:
                    if (!n.sent) {
                        n.next = 8;
                        break;
                    }
                    return n.abrupt("return", (Object.assign(o, q({}, z.gf.groupUserNo, a.$getCurrentUserNo())), 
                    o));

                  case 8:
                    throw a.forwardGroupByEvent(e), new Qt({
                        errMsg: "中断分享，开始跳转"
                    });

                  case 9:
                    return n.abrupt("return", o);

                  case 10:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    }
}, er = Y({
    mixins: [ Jt ]
}, Zt), tr = (0, z.gg)({
    behaviors: [ Xt ],
    methods: Y({}, Zt)
}), rr = {
    CANCEL: 0,
    AUTHORIZED: 1,
    HAD_DELETED: -1
}, ar = {
    NONE: 0,
    ORDER_SN: 1,
    ACTIVITY_NO: 2,
    GROUP_PLAY_SN: 3,
    COMMANDER_USER_NO: 4
};

exports._u = ar, exports.y9 = rr, exports.ai2 = tr, exports.ai3 = er;

var nr = {
    wechatSubscribePanel: 7198823,
    accept: 7198824,
    cancel: 7198825
};

exports.ae7 = nr;

var or = "", ir = 0, sr = 1, cr = 2;

function ur() {
    return (ur = U(M.default.mark(function e() {
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (e.t0 = or, e.t0) {
                    e.next = 5;
                    break;
                }
                return e.next = 4, U(M.default.mark(function e() {
                    return M.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, (0, z.fy)(z.px).then(function(e) {
                                return e.result.mpArticleUrl;
                            });

                          case 2:
                            return or = e.sent, e.abrupt("return", or);

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }))().catch(z.hm);

              case 4:
                e.t0 = or;

              case 5:
                return e.abrupt("return", e.t0);

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function pr() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 ? arguments[1] : void 0, r = cr, a = e[t];
    return "accept" === a ? r = sr : "ban" === a ? r = void 0 : "reject" === a && (r = ir), 
    r;
}

function lr(e) {
    var t = e.itemSettings, r = e.templateList, a = e.bizTagMap;
    r.forEach(function(e) {
        z.gm.loggerSubscribeMsg({
            templateId: e.templateId,
            permission: "accept" === t[e.templateId] ? rr.AUTHORIZED : rr.CANCEL,
            bizTag: a[e.bizTagType],
            permissionStatus: pr(t, e.templateId)
        });
    });
}

function dr(e) {
    return hr.apply(this, arguments);
}

function hr() {
    return (hr = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = t.templateList, n = void 0 === a ? [] : a, o = t.scene, i = t.activityNo, 
                s = t.orderSn, c = t.gamePlaySn, u = t.someAceeptSuccess, p = t.directLog, l = t.groupUserNo, 
                d = t.onSuccess, h = t.onAcceptSuccess, f = t.onCheckSubscribeAllow, g = t.onComplete, 
                m = t.onAbort, v = t.onBeforeCheckReject, _ = t.onSomeAceeptSuccess, x = n.map(function(e) {
                    return e.templateId;
                }), y = ar.ACTIVITY_NO, S = ar.ORDER_SN, E = ar.GROUP_PLAY_SN, T = ar.COMMANDER_USER_NO, 
                q(r = {}, ar.NONE, ""), q(r, y, i), q(r, S, s), q(r, E, c), q(r, T, l), I = r, e.next = 10, 
                (0, z.e7)(n);

              case 10:
                if (C = e.sent, k = C.allReject, b = C.allAuth, A = C.itemSettings, P = C.allAccept, 
                f && f({
                    allReject: k,
                    allAuth: b,
                    itemSettings: A,
                    allAccept: P
                }), (0, z.l6)({
                    page_el_sn: nr.wechatSubscribePanel,
                    extParams: {
                        scene: o,
                        allAuth: b,
                        allReject: k,
                        allAccept: P,
                        templateLen: x.length
                    }
                }), (0, z.ev)({
                    type: z.u.REQUEST_SUBSCRIBE_MESSAGE_IMPR,
                    tags: {
                        type: o,
                        allAuth: b,
                        allReject: k,
                        allAccept: P
                    }
                }), R = Date.now(), !k) {
                    e.next = 19;
                    break;
                }
                return e.abrupt("return", (v && v(), m && m(), (0, z.g0)({
                    page_el_sn: nr.accept,
                    extParams: {
                        scene: o,
                        allAuth: !0,
                        allReject: k,
                        reject: x,
                        templateLen: x.length
                    }
                }), void lr({
                    itemSettings: A,
                    templateList: n,
                    bizTagMap: I
                })));

              case 19:
                if (!b || !p) {
                    e.next = 23;
                    break;
                }
                return lr({
                    itemSettings: A,
                    templateList: n,
                    bizTagMap: I
                }), P && h && h(), u && !P && _ && _(), m && m(), N = {}, e.abrupt("return", (x.forEach(function(e) {
                    var t = A[e];
                    N[t] = (N[t] || []).concat([ e ]);
                }), void (0, z.g0)({
                    page_el_sn: nr.accept,
                    extParams: Y({
                        scene: o,
                        allAuth: !0,
                        allReject: k,
                        allAccept: P,
                        templateLen: x.length
                    }, N)
                })));

              case 23:
                "function" == typeof z.f3.requestSubscribeMessage && z.f3.requestSubscribeMessage({
                    tmplIds: x,
                    complete: function(e) {
                        console.log("requestSubComplete", e), g && g();
                    },
                    success: function(e) {
                        console.log("requestSubsuccess", e);
                    },
                    fail: function(e) {
                        console.log("requestSubfail", e);
                    }
                }).then(function(e) {
                    var t = {}, r = 0, a = n.map(function(a) {
                        var n = rr.CANCEL;
                        "accept" === e[a.templateId] ? (n = rr.AUTHORIZED, r++) : "ban" === e[a.templateId] && (n = rr.HAD_DELETED), 
                        z.gm.loggerSubscribeMsg({
                            templateId: a.templateId,
                            permission: n,
                            bizTag: I[a.bizTagType],
                            permissionStatus: pr(A, a.templateId)
                        });
                        var o = e[a.templateId];
                        return o && (t[o] = (t[o] || []).concat([ a.templateId ])), n;
                    }).every(function(e) {
                        return e === rr.AUTHORIZED;
                    });
                    d && d({
                        acceptCnt: r,
                        statusMap: t,
                        allAuth: b
                    }), a && h && h(), (0, z.g0)({
                        page_el_sn: nr.accept,
                        extParams: Y({
                            scene: o,
                            allAuth: b,
                            allAccept: P,
                            templateLen: x.length
                        }, t)
                    }), (0, z.ev)({
                        type: z.u.REQUEST_SUBSCRIBE_MESSAGE_CLICK,
                        tags: {
                            type: o,
                            accept: (t.accept || []).length,
                            reject: (t.reject || []).length,
                            ban: (t.ban || []).length,
                            allAuth: b,
                            allReject: k,
                            allAccept: P
                        },
                        longFields: {
                            consumeTime: Date.now() - R
                        }
                    });
                }).catch(function(e) {
                    (0, z.hp)({
                        e: e,
                        msg: "".concat(o, " logger template failed")
                    });
                });

              case 24:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

var fr, gr = {
    ALL: 1,
    HELPSELL: 2,
    CANBUY: 3,
    NEWEST: 4,
    DISCOVER: 101,
    SUBSIDY: 1000003
};

exports.wu = gr;

var mr = {
    initSubscribePopupCntPerDay: function() {
        return U(M.default.mark(function e() {
            var t, r, a;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, z.gr)().getConfig();

                  case 2:
                    if (e.t0 = e.sent, e.t0) {
                        e.next = 5;
                        break;
                    }
                    e.t0 = {};

                  case 5:
                    t = e.t0, r = t.subscribeMiniProgramMsgPopupDayLimit, a = (r || {}).value, fr = void 0 === a ? 0 : a;

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    initItemSubscribeData: (0, z.my)(U(M.default.mark(function e() {
        var t, r, a, n, o, i;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, z.gm.getInstance();

              case 2:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 5;
                    break;
                }
                e.t0 = {};

              case 5:
                return t = e.t0, r = (0, z.qh)(t, "templateVoMap.feedsMinaSub") || [], e.next = 9, 
                (0, z.e7)(r);

              case 9:
                a = e.sent, n = a.canUseRequestSubscribeFunc, o = a.allAuth, i = a.mainSwitch, this.canUseRequestSubscribeFunc = n, 
                this.mainSwitch = i, this.setData({
                    itemSubscribeTemplateList: r,
                    hadShowAllAuthDialog: o
                });

              case 14:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))),
    handleItemClick: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (r.prev = 0, a = Bt.INDEX_FEEDS_ITEM, n = t.$currentPage || {}, o = n.pageProperties, 
                    i = (o = void 0 === o ? {} : o).page_name, s = void 0 === i ? "" : i, c = t.data.$gray, 
                    u = void 0 === c ? {} : c, (0 !== fr && void 0 !== fr || u.locationSubscribeMessage) && "ktt_index" === s) {
                        r.next = 6;
                        break;
                    }
                    return r.abrupt("return", t.forwardGroupByEvent(e));

                  case 6:
                    if (r.t0 = null === t.canUseRequestSubscribeFunc, !r.t0) {
                        r.next = 10;
                        break;
                    }
                    return r.next = 10, t.initItemSubscribeData();

                  case 10:
                    if (p = t.data, l = p.itemSubscribeTemplateList, d = p.hadShowAllAuthDialog, 0 !== l.length && t.canUseRequestSubscribeFunc && t.mainSwitch) {
                        r.next = 13;
                        break;
                    }
                    return r.abrupt("return", t.forwardGroupByEvent(e));

                  case 13:
                    if (!t.showingSubscribeMessage) {
                        r.next = 15;
                        break;
                    }
                    return r.abrupt("return");

                  case 15:
                    h = z.f3.getStorageSync(z.ct.popupCntPerDayHit) || {}, f = h.count, g = void 0 === f ? 0 : f, 
                    m = h.expireTime, (v = void 0 === m ? Date.now() + 864e5 : m) && Date.now() > v && (g = 0, 
                    v = Date.now() + 864e5), (g += 1) <= fr && !u.locationSubscribeMessage || u.locationSubscribeMessage && d ? (t.showingSubscribeMessage = !0, 
                    _ = (0, z.jo)(e), dr({
                        templateList: l,
                        scene: "".concat(a.pageName),
                        groupUserNo: _.ownerUserNo,
                        onCheckSubscribeAllow: function(r) {
                            r.allAuth && t.showingSubscribeMessage && (t.showingSubscribeMessage = !1, t.forwardGroupByEvent(e));
                        },
                        onComplete: function() {
                            t.showingSubscribeMessage && (t.showingSubscribeMessage = !1, t.onCompleteSbuscribe(), 
                            t.forwardGroupByEvent(e));
                        },
                        onAbort: function() {
                            t.showingSubscribeMessage && (t.showingSubscribeMessage = !1, t.onCompleteSbuscribe(), 
                            t.forwardGroupByEvent(e));
                        }
                    }), g <= fr && !u.locationSubscribeMessage && (t.clickSubscribeButton(), z.f3.setStorageSync(z.ct.popupCntPerDayHit, {
                        count: g,
                        expireTime: v
                    }))) : t.forwardGroupByEvent(e), r.next = 22;
                    break;

                  case 19:
                    r.prev = 19, r.t1 = r.catch(0), t.forwardGroupByEvent(e), t.showingSubscribeMessage = !1, 
                    t.$error({
                        e: r.t1,
                        msg: "requestSubscribeMessage error"
                    });

                  case 22:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 0, 19 ] ]);
        }))();
    },
    hiddenNewSubscribeGuide: function() {
        this.setData({
            touchAllGuideDialog: !1
        });
    },
    onCompleteSbuscribe: function() {
        this.setData({
            touchAllGuideDialog: !1
        });
    },
    clickSubscribeButton: function() {
        this.data.hadShowAllAuthDialog || this.setData({
            touchAllGuideDialog: !0,
            hadShowAllAuthDialog: !0
        });
    },
    closeRepeatSubscribe: function() {
        this.setData({
            repeatSubcribeShow: !1
        });
    },
    handleShare: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (o = e.detail || {}, i = t.$getCurrentProxyUserNo() || (0, z.ln)() || "", s = (0, 
                    z.qh)(o, "helpSellCopyActivity") || {}, c = (0, z.qh)(s, "status"), u = (0, z.qh)(o, "displayImageList[0].picUrl"), 
                    p = (0, z.qh)(o, "isCoronaGroup"), l = (0, z.qh)(o, "subActivityType"), t.setData({
                        selectedItem: o
                    }), d = {
                        showEntry: t.getFeedsActivityAuth(o),
                        activityNo: o.activityNo
                    }, h = Y(Y({}, t.$getNextSharePageQuery()), {}, (q(a = {}, z.gf.collectionActivityNo, o.activityNo || ""), 
                    q(a, z.gf.refShareSrc, "".concat((0, z.qh)(t, "$currentPage.pageProperties.page_sn"), "_sharepanel_poster")), 
                    a)), c !== z.s.HAS_SHARE_SELL && i !== o.ownerUserNo || (h[z.gf.groupUserNo] = i), 
                    !o.topicNo) {
                        r.next = 15;
                        break;
                    }
                    return r.prev = 4, r.next = 7, null === (n = t.$currentPage) || void 0 === n ? void 0 : n.$prepareShare({
                        cardMsgFromServer: {
                            shareScene: z.cr.TOPIC_ACTIVITY,
                            title: o.title || "今日好物火爆来袭",
                            path: z.ob.topicActivity,
                            ownerUserNo: o.ownerUserNo,
                            params: {
                                activityTopicNo: o.topicNo
                            }
                        },
                        poster: {
                            shareScene: z.cr.TOPIC_ACTIVITY,
                            transparentParams: {
                                activityTopicNo: o.topicNo
                            }
                        }
                    }, z.cr.TOPIC_ACTIVITY);

                  case 7:
                    t.setData({
                        showShare: !0,
                        sharePreLoad: !1,
                        shareServerRender: !0,
                        shareInfo: Y(Y({}, t.data.$shareInfoMessageMap[z.cr.TOPIC_ACTIVITY]), {}, {
                            path: z.ob.topicActivity,
                            shareScene: z.cr.TOPIC_ACTIVITY
                        }),
                        showExternalLink: i === o.ownerUserNo
                    }), t.scene = z.cr.TOPIC_ACTIVITY || t.scene, r.next = 13;
                    break;

                  case 11:
                    r.prev = 11, r.t0 = r.catch(4);

                  case 13:
                    r.next = 19;
                    break;

                  case 15:
                    return r.next = 17, t.getParamsWithShareSell(e, s, h);

                  case 17:
                    t.setData({
                        sharePreLoad: !0,
                        shareServerRender: !1,
                        showShare: !0,
                        sharePanelShareTrackingInfo: Y(Y({}, t.data.sharePanelShareTrackingInfo), {}, {
                            activityNo: o.activityNo
                        }),
                        shareRelateInfo: d,
                        shareInfo: {
                            shareScene: p ? z.cr.SIGN_UP_CHECK_OUT : z.cr.WITHOUT_ATMOSPHERE,
                            activityNo: o.activityNo,
                            title: o.title || Xe.title,
                            path: p ? z.ob.signUpCheckout : z.ob.activity,
                            imageUrl: u || Xe.imageUrl,
                            params: h,
                            subActivityType: l
                        },
                        showExternalLink: i === o.ownerUserNo
                    }), t.scene = z.cr.WITHOUT_ATMOSPHERE || t.scene;

                  case 19:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 4, 11 ] ]);
        }))();
    },
    _overWriteGetFeedHomePageModel: function() {
        return this.feedHomePageModel || (this.feedHomePageModel = new kt()), this.feedHomePageModel;
    },
    loadMoreListData: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data.listData, a = void 0 === r ? [] : r, e.setData({
                        isLoading: !0,
                        loadMoreError: !1
                    }), n = e._overWriteGetFeedHomePageModel(), t.next = 5, n.getNextPage().then(function(t) {
                        var r = t.abort, o = t.list, i = void 0 === o ? [] : o, s = t.pageNumber, c = t.hasMore;
                        if (!r) {
                            "ktt_index" === (0, z.qh)(e, "$currentPage.pageProperties.page_name") && e.feedsDealWithPublicPraise(i || []);
                            var u = 1 === s, p = {
                                listData: u || e.isPageV2 ? i : a.concat(i || []),
                                hasMore: c,
                                searchKeywordCorrection: n.searchKeywordCorrection
                            };
                            e.isPageV2 ? u ? e.setDiffData(p) : e.appendListData(p) : e.setData(p);
                        }
                    }).catch(function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        e.$error({
                            e: t,
                            msg: "home feeds fail"
                        }), e.$showToast({
                            title: "网络异常，请稍后重试",
                            icon: "none"
                        }), e.setData({
                            loadMoreError: !0,
                            hasMore: !1
                        });
                    });

                  case 5:
                    e.setData({
                        isLoading: !1
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    hideShare: function() {
        this.setData({
            showShare: !1,
            shareInfo: null,
            shareRelateInfo: {},
            selectedItem: {}
        });
    },
    getFeedsActivityAuth: function(e) {
        return !(!(0, z.mq)(e.ownerUserNo) && !e.isAdmin);
    },
    onFeedsShareAppMessage: function(e) {
        var t = (0, z.jo)(e, "info") || this.data.shareInfo || Ze, r = t.shareMissionSn, a = void 0 === r ? "" : r;
        a && (t.params[z.gf.shareMissionSn] = a);
        var n, o = (0, z.qh)(this, "$currentPage.pageProperties.page_sn");
        return n = "button" === (null == e ? void 0 : e.from) ? "".concat(o, "_sharepanel_card") : "menu" === (null == e ? void 0 : e.from) ? "".concat(o, "_menu_card") : "".concat(o, "_sharepanel_shortlink"), 
        this.shareExtParams = {
            _x_ref_share_src: n
        }, (0, z.qj)(t, "params._x_ref_share_src", n), Ct.call(this, {}, {
            scene: this.scene,
            shareinfo: Y(Y({}, this.data.shareInfo), t)
        });
    },
    feedsDealWithPublicPraise: function(e) {
        var t = this;
        e.forEach(function(e) {
            e.showWordMouthTag && !t.showPromiseTips && (e.showWordMouthTips = !0, t.showPromiseTips = !0);
        });
    }
}, vr = Y({
    mixins: [ er ],
    data: {
        showShare: !1,
        sharePreLoad: !0,
        shareServerRender: !1,
        shareInfo: null,
        tab: gr.ALL,
        HomeFeedsTabs: gr,
        hasMore: !1,
        isLoading: !0,
        loadMoreError: !1,
        listData: [],
        showExternalLink: !1,
        userInfo: {},
        selectedItem: {},
        shareRelateInfo: {},
        sharePanelShareTrackingInfo: {},
        searchKeywordCorrection: "",
        itemSubscribeTemplateList: []
    },
    canUseRequestSubscribeFunc: null,
    mainSwitch: null,
    showingSubscribeMessage: !1
}, mr);

exports.aeh = vr;

var _r = (0, z.gg)({
    data: {
        showShare: !1,
        sharePreLoad: !0,
        shareServerRender: !1,
        shareInfo: null,
        tab: gr.ALL,
        HomeFeedsTabs: gr,
        hasMore: !1,
        isLoading: !0,
        loadMoreError: !1,
        listData: [],
        showExternalLink: !1,
        userInfo: {},
        selectedItem: {},
        shareRelateInfo: {},
        sharePanelShareTrackingInfo: {},
        searchKeywordCorrection: "",
        itemSubscribeTemplateList: [],
        touchAllGuideDialog: !1
    },
    behaviors: [ tr ],
    initProperties: {
        canUseRequestSubscribeFunc: null,
        mainSwitch: null,
        showingSubscribeMessage: !1
    },
    methods: Y({}, mr)
}), xr = K.utils.safeGet, yr = Object.values(z.at);

exports.ai8 = _r;

var Sr = function(e) {
    H(r, Re);
    var t = j(r);
    function r() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return G(this, r), t.call(this, {
            requestConfig: Y({
                url: "/api/ktt_gateway/activity/feeds/home_page/v4",
                auth: !1,
                noErrorToast: !0,
                convertToCamel: !0,
                convertRequestToSnake: !0,
                logFilter: z.ib
            }, e),
            useListId: !0,
            pageSize: 10,
            key: "activityNo",
            name: "RecFeedsHomePageModel"
        });
    }
    return B(r, [ {
        key: "formatNextPage",
        value: function(e) {
            var t, a;
            $(F(r.prototype), "formatNextPage", this).call(this, e), null === (a = null === (t = this.requestConfig) || void 0 === t ? void 0 : t.data) || void 0 === a || delete a.msg_specify_activity_no;
        }
    }, {
        key: "filterList",
        value: function(e) {
            var t = this;
            return e.filter(function(e) {
                var r = xr(e, "activityNo") || xr(e, "topicNo") || xr(e, "title") || xr(e, "feedSn");
                return !t.listMap[r] && (t.listMap[r] = !0, !0);
            });
        }
    }, {
        key: "formatList",
        value: function(e) {
            var t, r, a = this, n = e.list.filter(function(e) {
                return yr.indexOf(e.feedsType) > -1;
            }).map(function(e) {
                return Y({
                    isBTab: xr(a.requestConfig, "data.tab") === gr.HELPSELL
                }, be(e));
            });
            return 1 === this.pageNumber && 0 === n.length && (0, z.ev)({
                type: z.u.FEEDS_EMPTY,
                tags: {
                    feedsEmpty: "homePage",
                    type: (null === (r = null === (t = this.requestConfig) || void 0 === t ? void 0 : t.data) || void 0 === r ? void 0 : r.tab) || "unknown"
                }
            }), n;
        }
    } ]), r;
}();

function Er(e) {
    var t = e.duration || 1500;
    return (0, z.ri)(Y({
        icon: "none",
        mask: !0,
        duration: t
    }, e)), (0, z.rt)(t);
}

exports.ab1 = Sr;

var Tr = K.utils.FrontError, Ir = {
    userNoKey: {}
}, Cr = {
    orderMgr: "order_management",
    goodsVerification: "goods_verification",
    cancelOrderRefund: "cancel_order_refund",
    viewBalance: "view_balance",
    bankWithdraw: "bank_withdraw",
    exportBill: "export_bill",
    bindMoney: "bind_money",
    pddGoods: "pdd_goods",
    kttRedpacket: "ktt_redpacket",
    serviceCharges: "service_charges",
    viewGroupbalance: "view_groupbalance",
    homepageSetting: "homepage_setting",
    viewDataToday: "view_data_today",
    viewMembers: "view_members",
    shopManagement: "shop_management",
    modifyHelpSell: "modify_helpsell",
    helpSellGroupOwnerInAct: "helpsellgroupwoner_in_act",
    viewSupplyCom: "view_supply_com",
    viewSupplyInfo: "jump_supply_act_in_act",
    vipManagement: "vip_management",
    helpSellGroup: "helpsellgroup",
    hiddenPersonalRankData: "hidden_personal_rank_data",
    helpSellGroupOwner: "helpsellgroupowner",
    crmCreatePlan: "crm_create_plan",
    createModifyGroup: "create_modify_group",
    endGroup: "end_group",
    deleteGroup: "delete_group",
    batchDeleteHelpSell: "batch_delete_help_sell",
    viewReputation: "view_reputation",
    mySupplier: "my_supplier",
    canClearGroupRecycleBin: "clear_group_recycle_bin",
    supplierSettlementOrder: "supplier_settlement_order",
    supplierFinancialReview: "supplier_financial_review",
    supplierSettlementOrderExport: "supplier_settlement_order_export",
    supplierPurchaseOrder: "supplier_purchase_order",
    supplierPurchaseOrderExport: "supplier_purchase_order_export",
    switchSupplier: "switch_supplier"
};

function kr(e) {
    return e.permissionVolist.reduce(function(e, t) {
        return t.selected ? e[0].push(t.permissionCode) : e[1].push(t.permissionCode), e;
    }, [ [], [] ]);
}

function br(e) {
    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], r = (0, 
    z.ge)();
    return !(!r || !r.checkPerm) && r.checkPerm(e, t);
}

function Ar() {
    return (Ar = U(M.default.mark(function e(t) {
        var r, a, n;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (a = (r = t || {}).errorCode, n = r.errorMsg, e.t0 = n, !e.t0) {
                    e.next = 5;
                    break;
                }
                return e.next = 5, Er({
                    title: n
                });

              case 5:
                35013 !== a && 35014 !== a || (0, z.ny)();

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Pr() {
    return Rr.apply(this, arguments);
}

function Rr() {
    return (Rr = U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c, u = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = u.length > 0 && void 0 !== u[0] ? u[0] : {}, r = t.userNo, a = t.key, n = t.reset, 
                r) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                return o = +new Date(), i = Ir[r] && (Ir[r] || {}).hasPermissionList, s = i && (Ir[r] || {}).lastUpdateTime + 6e4 < o, 
                c = !i || s || n, e.abrupt("return", c || a !== Ir[r].key ? (Ir[r] && Ir[r].loading || (Ir[r] || (Ir[r] = {}), 
                Ir[r].loading = (0, z.fy)({
                    url: "/api/ktt_gateway/user_permission/query_permission_after_proxy",
                    convertToCamel: !0,
                    convertRequestToSnake: !0,
                    noErrorToast: !0,
                    params: {
                        proxy_no: r
                    }
                }).then(function(e) {
                    var t = e.result;
                    (0, z.qj)(Ir, "".concat(r, ".key"), a), (0, z.qj)(Ir, "".concat(r, ".lastUpdateTime"), o);
                    var n = kr(t), i = L(n, 2), s = i[0], c = i[1];
                    Object.assign(Ir[r], {
                        hasPermissionList: s,
                        noPermissionList: c
                    }), Ir[r].loading = !1;
                }).catch(function() {
                    Ir[r].loading = !1;
                })), c ? Ir[r].loading : void 0) : void 0);

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Nr(e) {
    var t = e.permCode, r = void 0 === t ? "" : t, a = e.userNo, n = void 0 === a ? "" : a;
    if (Ir[n] && Ir[n].hasPermissionList) {
        var o = Ir[n], i = o.hasPermissionList, s = void 0 === i ? [] : i, c = o.noPermissionList, u = void 0 === c ? [] : c;
        if (s.includes(r)) return !0;
        if (u.includes(r)) return !1;
    }
    throw new Tr({
        errMsg: "permission unknow"
    });
}

exports.zm = Cr;

var wr = {
    checkPermAsync: function(e, t) {
        var r = arguments, a = this;
        return U(M.default.mark(function n() {
            var o;
            return M.default.wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return o = !(r.length > 2 && void 0 !== r[2]) || r[2], n.next = 3, Pr({
                        userNo: a.$getCurrentProxyUserNo(),
                        key: a.$getPageId()
                    }).catch(z.hm);

                  case 3:
                    return n.abrupt("return", a.checkPerm(e, o, t));

                  case 4:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    },
    queryMyAdminPerm: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = e.length > 0 && void 0 !== e[0] && e[0], n = e.length > 1 ? e[1] : void 0, 
                    !(o = t.$getCurrentProxyUserNo())) {
                        r.next = 9;
                        break;
                    }
                    return r.next = 6, Pr({
                        userNo: o,
                        key: t.$getPageId(),
                        reset: a
                    }).catch(z.hm);

                  case 6:
                    n && n(), r.next = 10;
                    break;

                  case 9:
                    n && n();

                  case 10:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    checkPerm: function(e) {
        var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], a = this.$getCurrentProxyUserNo(), n = r;
        if (!a) return !0;
        try {
            n = Nr({
                permCode: e,
                userNo: a
            });
        } catch (e) {}
        return n || t && this.$showToast({
            title: "无权限"
        }), n;
    }
}, Dr = Y({}, wr), Or = (0, z.gg)({
    methods: Y({}, wr)
}), Lr = {
    canCreateModifyGroup: !0,
    canEndGroup: !0,
    canDeleteGroup: !0
}, Mr = {
    queryAdminGroupPerms: function() {
        var e = this;
        this.queryMyAdminPerm(!1, function() {
            return e.checkAdminGroupPerms();
        });
    },
    checkAdminGroupPerms: function() {
        var e = this;
        this.setData({
            canCreateModifyGroup: this.checkPerm(Cr.createModifyGroup, !1, !0),
            canEndGroup: this.checkPerm(Cr.endGroup, !1, !0),
            canDeleteGroup: this.checkPerm(Cr.deleteGroup, !1, !0)
        }, function() {
            e.checkAdminGroupPermCallback && e.checkAdminGroupPermCallback();
        });
    }
}, Ur = Y({
    mixins: [ Dr ],
    data: Y({}, Lr)
}, Mr), qr = (0, z.gg)({
    behaviors: [ Or ],
    data: Y({}, Lr),
    methods: Y({}, Mr)
}), Gr = [ "iPhone 3", "iPhone 4", "iPhone 5", "iPad", "OPPO R7sm", "vivo Y71A", "PBAM00", "vivo Y71", "vivo Y66i A", "vivo X9", "OPPO R9s Plus" ], Br = function() {
    (0, z.ri)({
        title: "请授权摄像头与麦克风权限",
        icon: "none",
        image: "",
        duration: 3e3
    });
}, $r = {
    auth: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = (0, z.k5)(), a = r.SDKVersion, !((0, z.g4)(a, "2.9.1") < 0)) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", void (0, z.ri)({
                        title: "当前微信版本不支持直播推流",
                        icon: "none",
                        duration: 3e3,
                        mask: !0
                    }));

                  case 3:
                    if (function(e) {
                        return !Gr.find(function(t) {
                            return 0 === e.indexOf(t);
                        });
                    }(r.model)) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return", void (0, z.ri)({
                        title: "当前手机型号不支持直播推流",
                        icon: "none",
                        duration: 3e3,
                        mask: !0
                    }));

                  case 5:
                    n = e, wx.getSetting({
                        success: function(e) {
                            e.authSetting["scope.camera"] && e.authSetting["scope.record"] ? setTimeout(function() {
                                n.setData({
                                    liveStatus: "ready"
                                }), n.authPassed();
                            }, 50) : wx.authorize({
                                scope: "scope.camera",
                                success: function() {
                                    wx.authorize({
                                        scope: "scope.record",
                                        success: function() {
                                            n.setData({
                                                liveStatus: "ready"
                                            }, function() {
                                                n.authPassed();
                                            });
                                        },
                                        fail: function() {
                                            Br(), n.setData({
                                                liveStatus: "unauth"
                                            });
                                        }
                                    });
                                },
                                fail: function() {
                                    wx.authorize({
                                        scope: "scope.record",
                                        success: function() {
                                            Br();
                                        },
                                        fail: function() {
                                            Br(), n.setData({
                                                liveStatus: "unauth"
                                            });
                                        }
                                    });
                                }
                            });
                        },
                        fail: function() {
                            n.authPassed(), (0, z.ev)({
                                type: z.u.LIVE_AUTH_FAIL,
                                fields: {
                                    operate: "get-setting-fail"
                                }
                            });
                        }
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    authResult: function(e) {
        var t = this;
        e.detail && e.detail.authSetting && (e.detail.authSetting["scope.camera"] && e.detail.authSetting["scope.record"] ? this.setData({
            liveStatus: "ready"
        }, function() {
            t.authPassed();
        }) : (0, z.ri)({
            title: "请在新页面授权摄像头与录音功能",
            icon: "none",
            duration: 3e3
        }));
    }
}, Fr = Y({}, $r), Hr = (0, z.gg)({
    methods: $r
});

function jr(e) {
    var t = e.comp, r = e.selector, a = e.field, n = e.pageScrollTop;
    return new Promise(function(e) {
        try {
            var o = (t || wx).createSelectorQuery();
            n && o.selectViewport().scrollOffset(), r && o.select(r).boundingClientRect(), o.exec(function(t) {
                var o = r && (0, z.qh)(t.pop() || {}, "".concat(a || "top")) || 0, i = n && (0, 
                z.qh)(t.pop() || {}, "scrollTop") || 0;
                e(o + i);
            });
        } catch (t) {
            (0, z.hp)({
                msg: "_selectorQuery error",
                data: {
                    selector: r,
                    field: a,
                    pageScrollTop: n
                },
                e: t
            }), e(0);
        }
    });
}

function Vr(e) {
    return jr({
        comp: e.$this,
        selector: e.selector,
        field: e.field
    });
}

function Yr(e, t) {
    return zr.apply(this, arguments);
}

function zr() {
    return (zr = U(M.default.mark(function e(t, r) {
        var a, n, o, i, s, c, u, p, l, d, h, f, g = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (a = g.length > 2 && void 0 !== g[2] ? g[2] : {}, n = a.defaultTop, o = void 0 === n ? 0 : n, 
                i = a.duration, s = void 0 === i ? 300 : i, c = a.skipNavBar, u = void 0 !== c && c, 
                p = a.offsetTop, l = void 0 === p ? 0 : p, u || !(0, z.g3)("2.7.3")) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return", z.f3.pageScrollTo({
                    selector: r,
                    duration: s,
                    offsetTop: l || 0
                }));

              case 3:
                return e.next = 5, jr({
                    comp: t,
                    selector: r,
                    pageScrollTop: !0
                });

              case 5:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 8;
                    break;
                }
                e.t0 = o;

              case 8:
                return d = e.t0, u && (h = (0, z.ke)(), f = h.navBarHeight, d -= f), e.abrupt("return", (l && (d += l), 
                z.f3.pageScrollTo({
                    scrollTop: d,
                    duration: s
                })));

              case 11:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.aev = Hr, exports.aa0 = Fr, exports.aas = qr, exports.ab2 = Ur, exports.aa9 = Or, 
exports.aju = exports.aek = Dr;

var Wr = {
    _updateBlackGroup: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = e.length > 0 && void 0 !== e[0] ? e[0] : "", n = e.length > 1 && void 0 !== e[1] ? e[1] : 0, 
                    o = e.length > 2 && void 0 !== e[2] ? e[2] : 0, r.next = 5, t.$baseRequest({
                        url: "/api/ktt_gateway/help_sell/ban_activity",
                        noErrorToast: !0,
                        data: {
                            owner_user_no: a,
                            op: n
                        }
                    }).catch(z.hm);

                  case 5:
                    (i = r.sent) && i.success && (t.$showToast({
                        title: "操作成功"
                    }), t.handleAfterBlackGroup && t.handleAfterBlackGroup(a, o));

                  case 7:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    _filterListAfterBlack: function(e, t, r, a) {
        var n = this;
        if (r) {
            var o = "", i = 0, s = e.filter(function(e, t) {
                var n = e.ownerUserNo === r;
                return !o && a && t >= a && !n && (o = e.activityNo), !o && n && i++, !n;
            });
            this.setData(q({}, t, s), function() {
                o && i > 1 && Yr(n, "#feeds-".concat(o), {
                    skipNavBar: !0
                });
            });
        }
    }
}, Kr = Y({}, Wr), Jr = (0, z.gg)({
    methods: Wr
});

exports.aey = exports.aa_ = Jr, exports.abl = Kr;

var Xr = null, Qr = {
    _setLocalCacheData: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        try {
            var n = Date.now();
            Xr && clearTimeout(Xr);
            var o = Y(Y({}, a), {}, {
                _cacheTime: (0, z.js)(),
                _env: z.fu.env
            }), i = {};
            (r || []).forEach(function(t) {
                var r = e.data;
                i[t] = r[t];
            }), o.renderCache = i, this.lastCacheTimestamp = n, Xr = setTimeout(function() {
                z.f3.setStorage({
                    key: t,
                    data: o
                }), Xr = null;
            }, 0);
        } catch (t) {}
    },
    _getLocalCacheData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        try {
            var t, r = z.f3.getStorageSync(e);
            if (r) {
                var a = r._cacheTime, n = r._env;
                Math.abs(Date.now() - (a || 0)) < 2592e6 && n === z.fu.env ? t = r : z.f3.removeStorage({
                    key: e
                });
            }
            return t;
        } catch (e) {
            return "";
        }
    },
    _removeStroage: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        z.f3.removeStorage({
            key: e
        });
    }
}, Zr = Y({}, Qr), ea = (0, z.gg)({
    methods: Y({}, Qr)
}), ta = K.utils.safeSet, ra = {
    ktt_index: "6915630",
    ktt_community_shop_group: "6915531"
}, aa = {
    ktt_index: "firstJumpIndexPreload",
    ktt_community_shop_group: "firstJumpCommunityListPreload"
};

function na() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = e.split("&"), r = t.indexOf("_j=1");
    return {
        sceneTokens: t,
        jumpIdentityIdx: r
    };
}

exports.abm = ea, exports.aez = Zr;

var oa = {
    checkIsJump: function() {
        if (void 0 !== this._needJumpActivity) return this._needJumpActivity;
        var e = this.$query, t = e[z.gf.collectionActivityNo], r = e.collectionActivityNo, a = e[z.gf.scene], n = na(void 0 === a ? "" : a).jumpIdentityIdx;
        return this._needJumpActivity = !(!t && !r && -1 === n), this._needJumpActivity;
    },
    checkJumpActivity: function(e) {
        var t, r, a, n = this;
        if (!this.checkIsJump()) return this.setData({
            needJumpActivity: !1
        }), !1;
        this._canclePreloadActivityInfoListener = z.f9.listenOnce(z.f1.signIn, function() {
            (0, z.on)(n.$query);
        }), ta(this, "$currentPage.$showSwitchProxy", !1), this.setData({
            isJumpingActivity: !0
        });
        var o = function() {
            var t, r, a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (!n._haveInvokeInitCB) {
                n._haveInvokeInitCB = !0, n.clearActivityLoadedListener(), n.setData({
                    isJumpingActivity: !1
                });
                try {
                    e && e();
                } catch (e) {}
            }
            if (a) {
                var o = null === (r = null === (t = n.$currentPage) || void 0 === t ? void 0 : t.pageProperties) || void 0 === r ? void 0 : r.page_name;
                o && (n.$impr({
                    page_el_sn: ra[o],
                    extParams: {
                        pv_log_id: n.$pvLogID
                    }
                }), (0, z.ev)({
                    type: z.u.PV,
                    tags: {
                        cp: "".concat(o, "_pv_activity_back")
                    }
                }));
            }
        };
        this.$addNextShowCallback(function() {
            o(!0);
        }), this._cancelActivityLoadedListener = z.f9.listenOnce(z.f1.activityLoaded, function(e) {
            var t, r, a = e.referPageID, i = null === (r = null === (t = n.$currentPage) || void 0 === t ? void 0 : t.pageProperties) || void 0 === r ? void 0 : r.page_name;
            aa[i] && (0, z.gc)().getStoreSync(aa[i], !1) && (a === n.$pageId ? o() : n.$info({
                msg: "activityLoaded cb conflict",
                data: {
                    referPageID: a,
                    pageID: n.$pageId
                }
            }));
        });
        var i = this.$query[z.gf.scene], s = na(void 0 === i ? "" : i), c = s.sceneTokens, u = s.jumpIdentityIdx;
        u > -1 && (c.splice(u, 1), this.$query[z.gf.scene] = c.join("&")), (0, z.n3)({
            url: z.ob.activity,
            params: Y((t = {}, q(t, z.gf.firstJumpFrom, this.$pageId), q(t, z.gf.subUniversalSrc, this.$query[z.gf.sId] ? "sid" : "share"), 
            t), this.$query),
            success: function() {
                [ z.gf.collectionActivityNo, "collectionActivityNo", z.gf.scene ].forEach(function(e) {
                    n.$query[e] && delete n.$query[e];
                });
            }
        });
        var p = null === (a = null === (r = this.$currentPage) || void 0 === r ? void 0 : r.pageProperties) || void 0 === a ? void 0 : a.page_name;
        return p && (0, z.ev)({
            type: z.u.PV,
            tags: {
                cp: "".concat(p, "_pv_need_jump_activity")
            }
        }), !0;
    },
    reportOnPageClick: function() {
        this.reportOnPageScrollOrClick("click");
    },
    reportOnPageScrollOrClick: function() {
        var e, t, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "click";
        if (this._needJumpActivity && (this._haveReportInteract || (this._haveReportInteract = {}), 
        !this._haveReportInteract[r])) {
            this._haveReportInteract[r] = !0;
            var a = null === (t = null === (e = this.$currentPage) || void 0 === e ? void 0 : e.pageProperties) || void 0 === t ? void 0 : t.page_name;
            a && (this._haveReportInteract.interact || this.$click({
                page_el_sn: ra[a],
                extParams: {
                    pv_log_id: this.$pvLogID,
                    type: r
                }
            }), (0, z.ev)({
                type: z.u.PV,
                tags: {
                    cp: "".concat(a, "_pv_interact"),
                    type: r,
                    interact: !this._haveReportInteract.interact
                }
            })), this._haveReportInteract.interact = !0;
        }
    },
    reportFeedsLoaded: function() {
        var e, t, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (!this._haveReportFeedsLoaded && this._needJumpActivity) {
            this._haveReportFeedsLoaded = !0;
            var a = null === (t = null === (e = this.$currentPage) || void 0 === e ? void 0 : e.pageProperties) || void 0 === t ? void 0 : t.page_name;
            a && (0, z.ev)({
                type: z.u.PV,
                tags: Y({
                    cp: "".concat(a, "_pv_feeds_loaded"),
                    appHide: !getApp().$visible
                }, r)
            });
        }
    },
    clearActivityLoadedListener: function() {
        this._cancelActivityLoadedListener && this._cancelActivityLoadedListener();
    },
    clearPreloadActivityListener: function() {
        this._canclePreloadActivityInfoListener && this._canclePreloadActivityInfoListener();
    }
}, ia = Y({
    data: {
        needJumpActivity: !0,
        isJumpingActivity: !1
    },
    _needJumpActivity: void 0
}, oa), sa = (0, z.gg)({
    methods: oa
}), ca = K.time.getServerTimeSync, ua = {
    setCloudStorage: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.scene, r = e.data, a = e.extId, n = e.days;
        return this.$baseRequest(Y(Y({}, z.qr), {}, {
            data: {
                scene: t,
                ext_id: a,
                value: JSON.stringify(r),
                expire_at: n ? Math.floor(ca() / 1e3) + 24 * n * 60 * 60 : void 0
            }
        }));
    },
    getCloudStorage: function(e, t) {
        return this.$baseRequest(Y(Y({}, z.jh), {}, {
            data: {
                scene: e,
                ext_id: t
            }
        })).then(function(e) {
            var t = e.result;
            return JSON.parse(t);
        });
    },
    deleteCloudStorage: function(e, t) {
        return this.$baseRequest(Y(Y({}, z.hh), {}, {
            data: {
                scene: e,
                ext_id: t
            }
        }));
    }
}, pa = Y({}, ua), la = (0, z.gg)({
    methods: ua
}), da = "facePopup", ha = {
    addTaskDependency: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : da;
        if (this.$currentPage) {
            var r = (0, z.qh)(this.$currentPage, "$competitiveConsumer.".concat(t, ".dependencies"));
            r || (r = [], (0, z.qj)(this.$currentPage, "$competitiveConsumer.".concat(t, ".dependencies"), r)), 
            r.push("function" == typeof e ? e : function() {
                return e;
            });
        }
    },
    addTask: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : da, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : z.hm, a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : z.hm;
        if (this.$currentPage) {
            var n = (0, z.qh)(this.$currentPage, "$competitiveConsumer.".concat(e, ".popups"));
            n || (n = [], (0, z.qj)(this.$currentPage, "$competitiveConsumer.".concat(e, ".popups"), n)), 
            n.push({
                priority: t,
                showCallback: r,
                notShowCallback: a
            });
        }
    },
    runTask: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = e.length > 0 && void 0 !== e[0] ? e[0] : da, !t.$currentPage) {
                        r.next = 16;
                        break;
                    }
                    if (n = (0, z.qh)(t.$currentPage, "$competitiveConsumer.".concat(a))) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return");

                  case 5:
                    o = n.dependencies, i = void 0 === o ? [] : o, s = n.popups, c = void 0 === s ? [] : s;

                  case 6:
                    if (!i.length) {
                        r.next = 14;
                        break;
                    }
                    return n.dependencies = [], r.next = 10, Promise.all(i.map(function(e) {
                        return e();
                    })).catch(z.hm);

                  case 10:
                    c = c.concat(n.popups || []), i = n.dependencies;

                  case 12:
                    r.next = 6;
                    break;

                  case 14:
                    return u = c.sort(function(e, t) {
                        return e.priority - t.priority;
                    }).shift(), r.abrupt("return", (u && (u.showCallback(), c.forEach(function(e) {
                        return e.notShowCallback && e.notShowCallback(u.priority);
                    })), n.dependencies = [], n.popups = [], u));

                  case 16:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    }
}, fa = Y({}, ha), ga = (0, z.gg)({
    methods: ha
}), ma = 1e3, va = function(e) {
    return ma / Math.pow(10, e);
}, _a = function(e) {
    return e > 0 && z.cz <= va(e);
}, xa = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    return _a(e) ? ma / Math.pow(10, e) : ma;
}, ya = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 ? arguments[1] : void 0, r = arguments.length > 2 ? arguments[2] : void 0;
    return _a(e) ? Math.floor(((t || 0) - (r || 0) * ma) / va(e)) : 0;
}, Sa = function(e) {
    return e < 10 ? "0".concat(e) : e;
};

exports.ahr = ya, exports.ain = xa, exports.afr = ga, exports.afa = fa, exports.afo = la, 
exports.ae8 = pa, exports.abv = sa, exports.ae1 = ia;

var Ea = (0, z.gg)({
    properties: {
        serverTime: {
            type: Number,
            value: 0,
            observer: function(e) {
                (0, z.gk)({
                    serverTime: e
                });
            }
        },
        startTime: {
            type: Number,
            value: 0,
            observer: function() {
                this.addTimeListener();
            }
        },
        endTime: {
            type: Number,
            value: 0,
            observer: function() {
                this.addTimeListener();
            }
        }
    },
    data: {
        day: 0,
        hour: 0,
        allHour: 0,
        min: 0,
        sec: 0,
        seconds: 0,
        realSimpleDisplay: !1,
        secFraction: 0,
        secAccuracy: 0
    },
    pageLifetimes: {
        show: function() {
            this.addTimeListener();
        },
        hide: function() {
            this.removeTimeListener();
        }
    },
    lifetimes: {
        detached: function() {
            this.removeTimeListener();
        }
    },
    methods: {
        addTimeListener: function() {
            var e = this;
            this.removeTimeListener(), this.onCountDown && (0, z.k8)(function(t) {
                e.cancleTimeListenerList.push(t.addListener([ {
                    split: {
                        time: xa(e.data.secAccuracy),
                        callback: e.onCountDown.bind(e)
                    }
                }, {
                    endTime: {
                        time: e.data.endTime,
                        callback: e.onEndTimeEnd.bind(e)
                    }
                } ]));
            });
            var t = this.getTimeListenerConfigs && this.getTimeListenerConfigs();
            t && 0 !== t.length && (0, z.k8)(function(r) {
                e.cancleTimeListenerList.push(r.addListener(t));
            });
        },
        removeTimeListener: function() {
            (this.cancleTimeListenerList || []).map(function(e) {
                e && e();
            }), this.cancleTimeListenerList = [];
        },
        onCountDown: function(e) {
            var t = e.currentTime, r = this.data, a = r.endTime, n = r.startTime, o = r.notStart, i = r.secAccuracy, s = r.simpleDisplay, c = 0;
            c = o ? n - t : a - t, c = Math.max(0, c);
            var u = Math.floor(c / 1e3), p = Math.floor(u / 60), l = Math.floor(p / 60), d = Math.floor(l / 24), h = d, f = Sa(l % 24), g = Sa(p % 60), m = Sa(Math.floor(u % 60)), v = ya(i, c, u), _ = !!(d > 9 && s);
            this.setData({
                day: h,
                realSimpleDisplay: _,
                hour: f,
                allHour: Sa(24 * h + parseInt(f, 10)),
                min: g,
                sec: m,
                secFraction: v,
                seconds: u
            }), this.handleTimeChange && this.handleTimeChange({
                milliSeconds: c
            });
        },
        onEndTimeEnd: function() {
            this.triggerEvent("end");
        },
        getTimeListenerConfigs: function() {}
    }
});

exports.afe = Ea;

var Ta = K.utils.emptyFunction;

function Ia() {
    return Ca.apply(this, arguments);
}

function Ca() {
    return (Ca = U(M.default.mark(function e() {
        var t, r;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, z.f3.login().catch(Ta);

              case 2:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 5;
                    break;
                }
                e.t0 = {};

              case 5:
                return t = e.t0, r = t.code, e.abrupt("return", r);

              case 8:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

var ka = {
    UK: 0,
    DFA: 1,
    TK: 2,
    CREATE: 3,
    PC: 4,
    RISK: 5,
    SETTING: 7,
    QJL: 8,
    HS_ITEM: 9
}, ba = {
    preWXLogin: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, Ia();

                  case 2:
                    e.code = t.sent;

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    updateAndCreateCountByAuth: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (n = (0, z.jo)(e), o = n.encryptedData, i = n.iv, o && i || (a = (0, z.jo)(e.detail), 
                    o = a.encryptedData, i = a.iv), t.code && o && i) {
                        r.next = 5;
                        break;
                    }
                    return r.next = 4, Er({
                        title: "请授权手机号"
                    });

                  case 4:
                    return r.abrupt("return", void r.sent);

                  case 5:
                    return s = {
                        encryptedData: o,
                        iv: i,
                        code: t.code
                    }, r.prev = 6, r.next = 9, (0, z.g6)(s);

                  case 9:
                    c = r.sent, r.next = 16;
                    break;

                  case 12:
                    return r.prev = 12, r.t0 = r.catch(6), r.next = 16, Er({
                        title: "更新联系电话失败"
                    });

                  case 16:
                    return r.abrupt("return", c);

                  case 17:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 6, 12 ] ]);
        }))();
    },
    showPhoneRiskAuth: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.preWXLogin();

                  case 2:
                    e.setData({
                        showAuthPhonePage: !0
                    });

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    phoneRiskAuth: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return t.reportGetPhoneNumberSuccess(e, ka.RISK), r.next = 3, t.updateAndCreateCountByAuth(e);

                  case 3:
                    if (!r.sent) {
                        r.next = 7;
                        break;
                    }
                    t.setData({
                        showAuthPhonePage: !1
                    }), t.$eventChannel.emit("refresh"), r.next = 8;
                    break;

                  case 7:
                    (0, z.n0)();

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    getBUserDataInfo: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = {}, !e.$getCurrentProxyUserNo()) {
                        t.next = 10;
                        break;
                    }
                    return t.next = 4, (0, z.c_)();

                  case 4:
                    if (t.t1 = t.sent, t.t1) {
                        t.next = 7;
                        break;
                    }
                    t.t1 = {};

                  case 7:
                    t.t0 = t.t1, t.next = 11;
                    break;

                  case 10:
                    t.t0 = (0, z.ja)() || {};

                  case 11:
                    return r = t.t0, t.abrupt("return", r);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    checkHasAccount: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.getBUserDataInfo();

                  case 2:
                    return r = t.sent, a = r.hasAccount, n = r.needAuthContact, o = !e.$getCurrentProxyUserNo() && !0 === n, 
                    t.abrupt("return", (a && o && e.$info({
                        msg: "old captain self not contact"
                    }), !0 === a && !o));

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    reportGetPhoneNumberSuccess: function(e) {
        var t, r, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ka.UK, n = (0, 
        z.jo)(e), o = n.errMsg;
        o || (o = (0, z.jo)(e.detail).errMsg);
        var i = "getPhoneNumber:ok" === o;
        i || this.$error({
            e: o,
            msg: "getPhoneNumber fail"
        }), (0, z.ev)({
            type: z.u.GET_PHONE_NUMBER_TRACK,
            tags: {
                getPhoneNumberScene: [ a, (null === (r = null === (t = this.$currentPage) || void 0 === t ? void 0 : t.pageProperties) || void 0 === r ? void 0 : r.page_name) || "" ].join("-"),
                getPhoneNumberSuccess: i
            }
        });
    }
}, Aa = Y({
    data: {
        showAuthPhonePage: !1
    }
}, ba), Pa = (0, z.gg)({
    data: {
        showAuthPhonePage: !1
    },
    methods: Y({}, ba)
});

function Ra() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order/business/cancel/batch_cancel_sub_order"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0
    }));
}

function Na() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order/business/cancel/cancel_order"
    }, e), {}, {
        convertToCamel: !0
    }));
}

function wa() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/order_remark/user/modify_user_remark"
    }, e), {}, {
        convertToCamel: !0
    }));
}

function Da() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, z.fy)(Y(Y({
        url: "/api/ktt_order_core/customer/modify/close"
    }, e), {}, {
        convertToCamel: !0,
        convertRequestToSnake: !0
    }));
}

exports.afv = Pa, exports.ab3 = Aa, exports.v5 = ka;

var Oa, La, Ma = {
    url: "/api/order_remark/owner/modify_owner_remark",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, Ua = {
    url: "/api/ktt_order/customer/logistics/receipt",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, qa = {
    url: "/api/ktt_order/customer/modify/delete",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, Ga = {
    url: "/api/ktt_order/customer/after_sales/check_can_apply",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, Ba = {
    url: "/api/ktt_order_core/customer/ordering/check_buy_again",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    useModal: !0
}, $a = {
    url: "/api/ktt_order/business/search/search_star_order",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    logFilter: z.ik
}, Fa = {
    lastApplyHelpSellText: 6,
    copyOrderDefaultOption: 7,
    helpSellSearchHistory: 24,
    purchaseUseMaxOrderSn: 31,
    searchHistory: 38,
    cOrderContactCaptainPopover: 42,
    crmSmsGuide: 44,
    supplyChainBatchCreate: 45,
    lastCommentAnony: 47,
    copyAfterSalesDefaultOption: 48,
    newcomerFreeCreateIndexEntry: 49,
    newcomerFreeActivityTip: 50,
    supplyChainModify: 51,
    groupChatDataType: 57,
    lastCommunityId: 58,
    isSHCovidRiskReview: 59,
    updateKttAndXcAvatar: 62,
    communityActivitySubscribeGuide: 60,
    communitySearchHistory: 64,
    lastAddMaterial: 1002,
    hasInitMaterialInGroup: 65,
    supplyOrderManageHint: 66,
    goodsNewbieBubbleScene: 67,
    ifShowWarningBar: 68,
    kttHelpSellIntroduceQR: 71,
    openVerify: 72,
    helpSellRejectMark: 76,
    supplyTrainStartClass: 73,
    newVisitorGuideDialog: 87,
    captainChatStayDialog: 84,
    captainChatStepGuide: 85,
    supplyAfterSaleAutoFill: 86,
    dragonBoatFestival: 1007,
    supplyAfterSalePhone: 1005,
    localLivingSearchHistory: 90
}, Ha = K.utils.emptyFunction, ja = {
    showProfilePickDlg: !1,
    profileDialogIsModal: !1
};

exports.afp = exports.aew = Fa, exports.al3 = {
    url: "/api/ktt_order/business/query/query_receiver_info",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ami = {
    url: "/api/ktt_order/business/search/search_order_in_activity",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.amj = {
    url: "/api/ktt_order/business/search/search_all_order",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ala = {
    url: "/api/ktt_order/business/after_sales/list_in_activity",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ak_ = {
    url: "/api/ktt_order/business/after_sales/list",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.alw = {
    url: "/api/ktt_penalty/query/list",
    method: "POST",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.amo = $a, exports.aft = {
    url: "/api/ktt_order/customer/logistics/pop_up_receipt",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.al1 = {
    url: "/api/ktt_export/order/query_poll_preview_order_excel",
    noErrorToast: !0
}, exports.aaz = {
    url: "/api/ktt_export/order/async_preview_order_excel"
}, exports.akz = {
    url: "/api/purchase/order/sync_progress",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ab0 = {
    url: "/api/purchase/order/choose",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.abt = Ba, exports.abu = Ga, exports.af_ = qa, exports.afs = Ua, exports.aj2 = Ma, 
exports.aav = {
    url: "/api/ktt_order/customer/after_sales/detail_v2",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.aau = {
    url: "/api/ktt_order/business/after_sales/detail_v2",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.zg = Oa, (La = Oa || (exports.zg = Oa = {}))[La.SUCCESS = 0] = "SUCCESS", 
La[La.NOT_NEW_USER = 1] = "NOT_NEW_USER", La[La.DISABLE_DIALOG = 2] = "DISABLE_DIALOG", 
La[La.LOW_VERSION = 3] = "LOW_VERSION";

var Va = {
    checkShowProfileDialog: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h, f, g, m;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = e.profileScene, n = e.profileText, o = void 0 === n ? "" : n, i = e.isModal, 
                    s = void 0 !== i && i, c = e.profileTitle, u = void 0 === c ? "登录后可体验更多功能" : c, 
                    p = e.notCheckNew, l = void 0 !== p && p, d = e.closeOnFail, h = void 0 !== d && d, 
                    f = e.onClose, l || (0, z.mj)()) {
                        r.next = 3;
                        break;
                    }
                    return r.abrupt("return", Oa.NOT_NEW_USER);

                  case 3:
                    return r.next = 5, (0, z.gc)().getStore().catch(Ha);

                  case 5:
                    if (r.t0 = r.sent, r.t0) {
                        r.next = 8;
                        break;
                    }
                    r.t0 = {};

                  case 8:
                    return g = r.t0, m = g.enableProfileDialog, r.abrupt("return", m ? (0, z.g3)("2.21.2") ? (t.setData({
                        showProfilePickDlg: !0,
                        profileScene: a,
                        profileText: o,
                        profileTitle: u,
                        profileDialogIsModal: s
                    }), (0, z.ev)({
                        type: z.u.PROFILE_DIALOG,
                        tags: {
                            profileScene: a,
                            pickUserInfo: !0
                        }
                    }), t.onProfileDialogClose = function() {
                        return null == f ? void 0 : f();
                    }, t._closeOnFail = h, Oa.SUCCESS) : (null == f || f(), Oa.LOW_VERSION) : Oa.DISABLE_DIALOG);

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    closeProfileDialog: function() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this.setData({
            showProfilePickDlg: !1
        }), t || (0, z.ev)({
            type: z.u.PROFILE_DIALOG,
            tags: {
                profileResult: "cancel",
                pickUserInfo: !0
            }
        }), null === (e = this.onProfileDialogClose) || void 0 === e || e.call(this);
    },
    profileSuccess: function() {
        this.closeProfileDialog(!0), (0, z.ev)({
            type: z.u.PROFILE_DIALOG,
            tags: {
                profileResult: "success",
                pickUserInfo: !0
            }
        });
    },
    profileFail: function() {
        this._closeOnFail && this.closeProfileDialog(!1), (0, z.ev)({
            type: z.u.PROFILE_DIALOG,
            tags: {
                profileResult: "fail",
                pickUserInfo: !0
            }
        });
    }
}, Ya = Y({
    data: ja
}, Va);

exports.ab9 = Ya;

var za = (0, z.gg)({
    data: ja,
    methods: Va
}), Wa = ((0, z.k5)() || {}).platform, Ka = "windows" === Wa || "mac" === Wa, Ja = {
    KTT_CHAT: 0,
    ENTERPRISE_WECHAT: 1
}, Xa = "https://work.weixin.qq.com", Qa = new Map();

function Za() {
    return (Za = U(M.default.mark(function e(t, r) {
        var a;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (this.$switchGlobalUserNo) {
                    e.next = 2;
                    break;
                }
                throw new Error("请调用callThis");

              case 2:
                if (a = (0, z.kp)(), e.t0 = a && a !== t || !a && t !== r, !e.t0) {
                    e.next = 8;
                    break;
                }
                return this.$switchGlobalUserNo(t), e.next = 8, Er({
                    title: "已为您切换为当前团长的身份",
                    icon: "none",
                    image: "",
                    duration: 2e3
                });

              case 8:
                (0, z.n3)({
                    url: z.ob.chatCenter
                });

              case 9:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

function en() {
    return (en = U(M.default.mark(function e(t) {
        var r, a, n, o;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = t.otherIsB, a = void 0 === r || r, n = t.userNo, o = void 0 === n ? "" : n) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                return e.abrupt("return", (0, z.fy)(Y(Y({}, z.lc), {}, {
                    data: {
                        specified_user_no: o,
                        specified_user_type: a ? 9 : 10
                    }
                })).then(function(e) {
                    return e.result;
                }));

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function tn(e) {
    return rn.apply(this, arguments);
}

function rn() {
    return (rn = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = Qa.get(t) || {}, a = r.contactUrl, n = void 0 === a ? "" : a) {
                    e.next = 10;
                    break;
                }
                return e.next = 4, (0, z.fy)(Y(Y({}, z.jn), {}, {
                    data: {
                        owner_user_no: t
                    }
                })).catch(z.hm);

              case 4:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 7;
                    break;
                }
                e.t0 = {};

              case 7:
                o = e.t0, (i = o.result) && (s = i.url, n = s, (c = Qa.get(t) || {}).contactUrl = n, 
                Qa.set(t, c));

              case 10:
                return e.abrupt("return", n);

              case 11:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.tu = Ja, exports.ak6 = za;

var an = [ "TAP", "user cancel" ];

function nn() {
    return on.apply(this, arguments);
}

function on() {
    return (on = U(M.default.mark(function e() {
        var r, a, n, o, i, s, c, u, p, l, d, h, f = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = f.length > 0 && void 0 !== f[0] ? f[0] : {}, e.t0 = this && this.checkShowProfileDialog, 
                !e.t0) {
                    e.next = 8;
                    break;
                }
                return e.next = 5, this.checkShowProfileDialog({
                    profileScene: "openChatCtoB"
                });

              case 5:
                e.t1 = e.sent, e.t2 = Oa.SUCCESS, e.t0 = e.t1 === e.t2;

              case 8:
                if (!e.t0) {
                    e.next = 10;
                    break;
                }
                return e.abrupt("return");

              case 10:
                if (a = r.toUserNo, n = r.contactUrl, o = r.contactUrlParams, i = void 0 === o ? {} : o, 
                s = r.enterpriseExtParams, c = void 0 === s ? {} : s, u = r.type, p = void 0 === u ? Ja.KTT_CHAT : u, 
                n && (p = Ja.ENTERPRISE_WECHAT), l = !1, e.t3 = p === Ja.ENTERPRISE_WECHAT, !e.t3) {
                    e.next = 19;
                    break;
                }
                return e.next = 18, U(M.default.mark(function e() {
                    var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x = arguments;
                    return M.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (r = x.length > 0 && void 0 !== x[0] ? x[0] : {}, a = r.contactUrl, n = r.toUserNo, 
                            o = r.urlParams, i = r.extParams, s = void 0 === i ? {} : i, e.t0 = !a && n, !e.t0) {
                                e.next = 6;
                                break;
                            }
                            return e.next = 5, tn(n);

                          case 5:
                            a = e.sent;

                          case 6:
                            if (wx.canIUse("openCustomerServiceChat")) {
                                e.next = 9;
                                break;
                            }
                            return c = "微信版本过低，请升级版本后重试", u = "openCustomerServiceChat needed wechat version too low", 
                            e.abrupt("return", (Ka && (c = "暂不支持PC，请使用手机微信小程序重试", u = "openCustomerServiceChat not support PC wechat"), 
                            (0, z.ri)({
                                icon: "none",
                                title: c
                            }), (0, z.hp)({
                                msg: u
                            }), !1));

                          case 9:
                            if (a) {
                                e.next = 11;
                                break;
                            }
                            return e.abrupt("return", ((0, z.hp)({
                                msg: "openCustomerServiceChat lack contaccUrl"
                            }), !1));

                          case 11:
                            return /^https?:\/\//.test(a) || (a = Xa + a), p = (0, z.ge)(), l = (0, z.qh)(p || {}, "pageProperties.page_sn"), 
                            d = {
                                u: (0, z.lj)(),
                                s: l
                            }, Object.assign(d, o), a = (0, z.e4)(a, {
                                scene_param: JSON.stringify((0, z.p7)(d, {
                                    clearEmptyString: !0
                                }))
                            }), e.prev = 14, e.next = 17, z.f3.openCustomerServiceChat(Y({
                                extInfo: {
                                    url: a
                                },
                                corpId: z.fu.corpId
                            }, s));

                          case 17:
                            e.next = 40;
                            break;

                          case 19:
                            e.prev = 19, e.t1 = e.catch(14), h = e.t1 || {}, f = h.errMsg, g = void 0 === f ? "" : f, 
                            m = t(an), e.prev = 23, m.s();

                          case 25:
                            if ((v = m.n()).done) {
                                e.next = 31;
                                break;
                            }
                            if (_ = v.value, !g.includes(_)) {
                                e.next = 29;
                                break;
                            }
                            return e.abrupt("return", !0);

                          case 29:
                            e.next = 25;
                            break;

                          case 31:
                            e.next = 36;
                            break;

                          case 33:
                            e.prev = 33, e.t2 = e.catch(23), m.e(e.t2);

                          case 36:
                            return e.prev = 36, m.f(), e.finish(36);

                          case 39:
                            return e.abrupt("return", !1);

                          case 40:
                            return e.abrupt("return", !0);

                          case 41:
                          case "end":
                            return e.stop();
                        }
                    }, e, null, [ [ 14, 19 ], [ 23, 33, 36, 39 ] ]);
                }))({
                    contactUrl: n,
                    toUserNo: a,
                    urlParams: i,
                    extParams: c
                });

              case 18:
                l = e.sent;

              case 19:
                !l && a && (0, z.n3)({
                    url: z.ob.chatDetail,
                    params: Y({
                        convId: r.convId,
                        toUserNo: r.toUserNo
                    }, r.extraParams || {})
                }), d = (0, z.ge)(), (h = (0, z.qh)(d || {}, "pageProperties.page_name")) && (0, 
                z.ev)({
                    type: z.u.OPEN_CHAT_C_TO_B_FROM,
                    tags: {
                        openChatCtoBFrom: h,
                        type: p
                    }
                });

              case 22:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

function sn() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.toUserNo, r = e.convId;
    (0, z.n3)({
        url: z.ob.chatDetail,
        params: {
            isB: 1,
            convId: r,
            toUserNo: t
        }
    });
}

function cn(e) {
    return un.apply(this, arguments);
}

function un() {
    return (un = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = {
                    visitorUnreadCount: 0,
                    csUnreadCount: 0,
                    innerNoticeUnreadCount: 0,
                    hasLeaderConversation: !0,
                    hasMemberConversation: !0
                }, t) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return", r);

              case 3:
                return a = Y(Y({}, z.r8), {}, {
                    data: {
                        hostUserNo: t
                    },
                    params: {
                        proxy_no: t
                    }
                }), e.next = 6, (0, z.fy)(a).catch(function() {});

              case 6:
                if (!(n = e.sent)) {
                    e.next = 10;
                    break;
                }
                return o = (0, z.qh)(n, "result") || {}, i = o.visitorUnreadCount, s = void 0 === i ? 0 : i, 
                c = o.csUnreadCount, u = void 0 === c ? 0 : c, p = o.innerNoticeUnreadCount, l = void 0 === p ? 0 : p, 
                d = o.hasLeaderConversation, h = void 0 === d || d, f = o.hasMemberConversation, 
                g = {
                    showCount: s + u + l > 999 ? "999+" : s + u + l,
                    visitorUnreadCount: s,
                    csUnreadCount: u,
                    innerNoticeUnreadCount: l,
                    hasLeaderConversation: h,
                    hasMemberConversation: void 0 === f || f
                }, e.abrupt("return", ((0, z.hk)((0, z.q0)(g)), g));

              case 10:
                return e.abrupt("return", r);

              case 11:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function pn() {
    var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.orderSn, a = t.orderAmountStr, n = t.thumbUrl, o = t.activityTitle;
    return {
        showMessageCard: !0,
        sendMessageTitle: "订单金额:￥".concat(a, "。").concat(o, " "),
        sendMessagePath: (0, z.e4)(z.ob.chatOrderList, (e = {}, q(e, z.gf.orderSn, r), q(e, z.gf.chatOrderUserNo, this.$getCurrentUserNo && this.$getCurrentUserNo() || ""), 
        e)),
        sendMessageImg: n
    };
}

var ln = K.utils.safeGet, dn = {
    remarkDialogVisible: !1,
    orderCloseReasonPanelVisible: !1
}, hn = {
    _showRemarkDialog: function() {
        this.setData({
            remarkDialogVisible: !0
        });
    },
    _submitRemark: function(e) {
        var t = this, r = e.parentOrderSn, a = e.remark;
        return (0, z.rg)(), wa({
            data: {
                parent_order_sn: r,
                remark_content: a
            }
        }).then(function(e) {
            return (0, z.l3)(), !!e && ((0, z.ri)({
                title: "修改备注成功"
            }), t._hideRemarkDialog(), !0);
        }).catch(function(e) {
            return (0, z.l3)(), (0, z.ri)({
                title: e.errorMsg || "修改备注失败"
            }), !1;
        });
    },
    _hideRemarkDialog: function() {
        this.setData({
            remarkDialogVisible: !1
        });
    },
    showOrderCloseReasonPanel: function() {
        this.setData({
            orderCloseReasonPanelVisible: !0
        });
    },
    hideOrderCloseReasonPanel: function() {
        this.setData({
            orderCloseReasonPanelVisible: !1
        });
    },
    _closeCustomerOrder: function(e) {
        if (e) return Da({
            data: {
                parentOrderSn: e
            }
        }).then(function(e) {
            return !!e.success && ((0, z.ri)({
                title: "订单已关闭"
            }), !0);
        });
    },
    _getOrderNoteMessage: function(e) {
        if (!e) return null;
        var t = e.digest, r = e.digestTitle;
        return "【".concat(void 0 === r ? "" : r, "】：").concat(t);
    },
    _forwardOrderExpressDetail: function(e, t) {
        var r;
        (0, z.n3)({
            url: z.ob.orderExpressDetail,
            params: (r = {}, q(r, z.gf.orderSn, e), q(r, z.gf.collectionActivityNo, t), r)
        });
    },
    _forwardOrderNotePage: function(e) {
        (0, z.n5)({
            pageName: _t.kttOrderNote,
            params: {
                order_sn: e
            }
        });
    },
    _generateCustomerCode: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = "") {
                        r.next = 12;
                        break;
                    }
                    return r.prev = 2, r.next = 5, t.$generalShareTicket({
                        data: {
                            shareType: z.cs.TIMELINE,
                            shareScene: z.cr.VERIFY_SITE_CODE,
                            parentOrderSn: e
                        }
                    }, !1);

                  case 5:
                    (n = r.sent) && n.result && (a = n.result.imageUrl), r.next = 12;
                    break;

                  case 9:
                    r.prev = 9, r.t0 = r.catch(2), t.$error({
                        msg: "showCustomerCode error",
                        e: r.t0
                    });

                  case 12:
                    return r.abrupt("return", a);

                  case 13:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 2, 9 ] ]);
        }))();
    },
    _doBuyOneMore: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = e.order, n = void 0 === a ? {} : a, o = e.ocScene, r.next = 3, t.$baseRequest(Y(Y({}, Ba), {}, {
                        data: {
                            parentOrderSn: n.parentOrderSn
                        }
                    })).catch(function(e) {
                        return e;
                    });

                  case 3:
                    if (r.sent.success) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return");

                  case 5:
                    i = n.subOrderList, s = void 0 === i ? [] : i, c = n.activityNo, u = s.map(function(e) {
                        var t = e.goodsId, r = e.goodsNumber;
                        return {
                            skuId: e.skuId,
                            goodsId: t,
                            goodsNum: r
                        };
                    }), t.$setNextPageQuery(q({}, z.gf.recUniversalSrc, o)), (0, z.n3)({
                        url: z.ob.orderCheckout,
                        params: {
                            collection_activity_no: c
                        },
                        success: function() {
                            z.f9.trigger("acceptSkus", u, {});
                        }
                    });

                  case 7:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    _confirmReceiveGoods: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        return this.$baseRequest(Y(Y({}, Ua), {}, {
            data: {
                parentOrderSn: e,
                receiptChannel: t
            }
        })).then(function(e) {
            return e && e.success;
        }).catch(function() {
            return !1;
        });
    },
    _removeOrder: function(e) {
        return this.$baseRequest(Y(Y({}, qa), {}, {
            data: {
                parentOrderSn: e
            }
        })).then(function(e) {
            return e && e.success;
        }).catch(function() {
            return !1;
        });
    },
    _getHasClickCallCaptain: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, e.getCloudStorage(Fa.cOrderContactCaptainPopover);

                  case 3:
                    return t.abrupt("return", t.sent);

                  case 6:
                    return t.prev = 6, t.t0 = t.catch(0), t.abrupt("return", null);

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 6 ] ]);
        }))();
    },
    _setHasClickCallCaptain: function() {
        this.setCloudStorage({
            scene: Fa.cOrderContactCaptainPopover,
            data: {
                click: !0
            }
        });
    },
    selectRefund: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, t.$baseRequest(Y(Y({}, Ga), {}, {
                        data: {
                            parentOrderSn: e.parentOrderSn
                        }
                    })).catch(function(e) {
                        return e;
                    });

                  case 2:
                    if (!(a = r.sent).success) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return", ((0, z.n3)({
                        url: z.ob.orderRefundToC,
                        params: q({}, z.gf.orderSn, e.parentOrderSn)
                    }), !0));

                  case 5:
                    return r.next = 7, t.$showModal({
                        isInPage: !0,
                        title: "无法申请售后",
                        content: a.errorMsg,
                        cancelText: "取消",
                        confirmText: "联系团长"
                    });

                  case 7:
                    if (r.t0 = r.sent.confirm, !r.t0) {
                        r.next = 10;
                        break;
                    }
                    t.goChatToB(e, !0);

                  case 10:
                    return r.abrupt("return", !1);

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    goChatToB: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = e.ownerUserNo, a = e.ownerContactCode, n = e.parentOrderSn, o = e.orderAmountStr, i = e.subOrderList, s = e.activityTitle, c = {
            orderItem: e
        };
        z.f9.trigger(z.f1.setOrderDetailCardData, c);
        var u = {
            o: n
        };
        t ? nn.call(this, {
            toUserNo: r,
            contactUrl: a,
            contactUrlParams: u,
            enterpriseExtParams: pn.call(this, {
                orderSn: n,
                orderAmountStr: o,
                thumbUrl: ln(i, "0.thumbUrl") || z.y[0],
                activityTitle: s
            }),
            extraParams: q({}, z.gf.isNeedAutoSend, 1)
        }) : nn.call(this, {
            toUserNo: r,
            contactUrl: a,
            contactUrlParams: u
        });
    }
}, fn = Y({
    data: dn,
    mixins: [ pa ]
}, hn), gn = (0, z.gg)({
    data: dn,
    behaviors: [ la ],
    methods: hn
}), mn = {
    CLOSED: -1,
    TO_PAY: 0,
    PAY: 1,
    SHIP: 2,
    PICK: 3,
    PART_PICK: 4,
    CANCEL: 5,
    PART_SHIP: 6,
    RECEIVED: 7
}, vn = (q(s = {}, mn.CLOSED, "已关闭"), q(s, mn.TO_PAY, "待支付"), q(s, mn.PAY, "待发货"), 
q(s, mn.SHIP, "已发货"), q(s, mn.PICK, "已提货"), q(s, mn.PART_PICK, "部分提货"), q(s, mn.CANCEL, "已取消"), 
q(s, mn.PART_SHIP, "部分发货"), s), _n = (q(c = {}, mn.CLOSED, {
    value: "已关闭",
    key: "cancel"
}), q(c, mn.TO_PAY, {
    value: "待支付",
    key: "to-pay"
}), q(c, mn.PAY, {
    value: "已支付",
    key: "pay"
}), q(c, mn.SHIP, {
    value: "已发货",
    key: "ship"
}), q(c, mn.PICK, {
    value: "已提货",
    key: "pick"
}), q(c, mn.PART_PICK, {
    value: "部分提货",
    key: "part-pick"
}), q(c, mn.CANCEL, {
    value: "已取消",
    key: "cancel"
}), q(c, mn.PART_SHIP, {
    value: "部分发货",
    key: "part-ship"
}), q(c, mn.RECEIVED, {
    value: "已收货",
    key: "received"
}), c), xn = {
    ALL: 0,
    TO_REFUND: 1,
    REFUNDED: 2,
    CANCEL: 3,
    BUYER_REMARK: 4,
    BUSINESS_REMARK: 5,
    PRIVATE_REMARK: 6,
    GROUP_BUY: 50
}, yn = {
    TO_SHIP: 1,
    SHIP: 2,
    TO_PICK: 3,
    PART_PICK: 4,
    PICK: 5,
    PART_SHIP: 6,
    RECEIVED: 7
}, Sn = {
    NONE: 0,
    REFUNDING: 1,
    REFUND_SUCCESS: 2,
    TO_REFUND: 3,
    REFUSE: 4,
    HELP_SELL_AGREE: 5,
    RETURN_GOODS_WAITING: 6,
    RETURN_GOODS_ACK_WAITING: 7,
    REVOKED: 8,
    CLOSED: 9
}, En = (q(u = {}, Sn.NONE, ""), q(u, Sn.REFUNDING, ""), q(u, Sn.REFUND_SUCCESS, ""), 
q(u, Sn.TO_REFUND, "待团长处理"), q(u, Sn.REFUSE, "已拒绝"), q(u, Sn.HELP_SELL_AGREE, "帮卖团长已同意，待供货团长处理"), 
q(u, Sn.RETURN_GOODS_WAITING, "待团员退货"), q(u, Sn.RETURN_GOODS_ACK_WAITING, "团员已退货，待退款"), 
q(u, Sn.REVOKED, "团员已撤销"), q(u, Sn.CLOSED, "团员逾期未处理，售后关闭"), u), Tn = {
    NONE: 0,
    SEND: 1,
    PART_SEND: 2,
    RECEIVED: 3
}, In = {
    ORDER: 1,
    EXPRESS: 2,
    ORDER_RECEIPT: 3,
    MENTION_ORDER: 4,
    GOODS: 5,
    MENTION_GOODS: 6,
    GOODS_LOGISTICS_TEMPLATE: 14
}, Cn = {
    ORDER: 12,
    ORDER_FLOW: 13,
    RECEIPT: 14,
    MENTION_ORDER: 21,
    LOGISTICS_TEMPLATE: 16,
    GOODS_SUMMARY: 17,
    SITE_QR_CODE: 19,
    MENTION_GOODS_SUMMARY: 20,
    PENALTY_ORDER: 48
}, kn = (q(p = {}, In.ORDER, Cn.ORDER), q(p, In.EXPRESS, Cn.LOGISTICS_TEMPLATE), 
q(p, In.ORDER_RECEIPT, Cn.RECEIPT), q(p, In.MENTION_ORDER, Cn.MENTION_ORDER), q(p, In.GOODS, Cn.GOODS_SUMMARY), 
q(p, In.MENTION_GOODS, Cn.MENTION_GOODS_SUMMARY), q(p, In.GOODS_LOGISTICS_TEMPLATE, Cn.LOGISTICS_TEMPLATE), 
p), bn = {
    CANCELLED: 1,
    PRESERVED: 0
}, An = {
    CANCELLED: 1,
    PRESERVED: 0
}, Pn = {
    NONE: -1,
    OWNER: 1,
    SHARE_OWNER: 2,
    ROOT_SUPPLY_OWNER: 4,
    PARENT_SUPPLY_OWNER: 5
}, Rn = {
    AFTER_SALE_TIME_24_HOURS: 100201,
    AFTER_SALE_TIME_48_HOURS: 100202,
    AFTER_SALE_TIME_72_HOURS: 100203
}, Nn = (q(l = {}, Rn.AFTER_SALE_TIME_24_HOURS, "24小时"), q(l, Rn.AFTER_SALE_TIME_48_HOURS, "48小时"), 
q(l, Rn.AFTER_SALE_TIME_72_HOURS, "72小时"), l), wn = {
    NOT_SUPPLY_ORDER: -1,
    NOT_PURCHASED: 0,
    PURCHASED: 1
}, Dn = {
    NONE: -1,
    NOT_PURCHASED: 0,
    PURCHASED: 1,
    CANCEL: 2
}, On = function(e) {
    var t = e.cancelStatus === An.CANCELLED;
    return Y(Y({}, e), {}, {
        isCancel: t,
        goodsAmountStr: W.default.price(e.goodsAmount, 100),
        realGoodsAmountStr: W.default.price(e.realGoodsAmount, 100),
        orderAmountStr: W.default.price(e.orderAmount, 100)
    });
}, Ln = function(e) {
    var t = e.cancelStatus === bn.CANCELLED, r = e.orderAmount, a = void 0 === r ? 0 : r, n = e.goodsAmount, o = void 0 === n ? 0 : n, i = e.refundAmount, s = void 0 === i ? 0 : i, c = e.refundingAmount, u = void 0 === c ? 0 : c, p = e.refundPlatformDiscountAmount, l = void 0 === p ? 0 : p, d = e.refundingPlatformDiscountAmount, h = void 0 === d ? 0 : d, f = e.receiptTime, g = void 0 === f ? 0 : f, m = e.receiverAddressProvince, v = void 0 === m ? "" : m, _ = e.receiverAddressCity, x = void 0 === _ ? "" : _, y = e.receiverAddressDistrict, S = void 0 === y ? "" : y, E = e.receiverAddressDetail, T = void 0 === E ? "" : E;
    return Y(Y({}, e), {}, {
        isOrderCancel: t,
        orderAmountStr: W.default.price(a, 100),
        refundAmountStr: W.default.price(s + l, 100),
        refundingAmountStr: W.default.price(u + (h || 0), 100),
        refundPlatformDiscountAmountStr: W.default.price(l, 100),
        refundingPlatformDiscountAmountStr: W.default.price(h, 100),
        goodsAmountStr: W.default.price(o, 100),
        receiveAddress: v + x + S + T,
        subOrderList: (e.subOrderList || []).map(On),
        confirmAtStr: e.confirmAt ? W.default.formatTime(e.confirmAt / 1e3, "YYYY/M/d hh:mm") : "",
        receiptTimeStr: g ? W.default.formatTime(g / 1e3, "YYYY/M/d hh:mm") : "",
        logisticsList: (e.logisticsList || []).filter(function(e) {
            return e.shippingNo;
        })
    });
}, Mn = function(e) {
    var t = "";
    if (e.isFullRefund) t = "全额退款"; else {
        var r = "", a = "";
        e.refundAmount && (r = "已退".concat(e.refundAmountStr || "", "元"), e.refundPlatformDiscountAmount && (r += "（含平台红包".concat(e.refundPlatformDiscountAmountStr, "元）"))), 
        e.refundingAmount && (a = "".concat(e.refundingAmountStr, "元退款中"), e.refundingPlatformDiscountAmount && (a += "（含平台红包".concat(e.refundingPlatformDiscountAmountStr, "元）"))), 
        t = "".concat(r).concat(r && a ? "，" : "").concat(a);
    }
    return t;
}, Un = (q(d = {}, Sn.NONE, ""), q(d, Sn.REFUNDING, ""), q(d, Sn.REFUND_SUCCESS, ""), 
q(d, Sn.TO_REFUND, "已申请退款"), q(d, Sn.REFUSE, "团长已拒绝退款"), q(d, Sn.HELP_SELL_AGREE, "已申请退款"), 
q(d, Sn.RETURN_GOODS_WAITING, "团长已同意，请填写物流单号"), q(d, Sn.RETURN_GOODS_ACK_WAITING, "已填写物流单号，待团长退款"), 
q(d, Sn.REVOKED, "已撤销申请"), q(d, Sn.CLOSED, "逾期未处理，售后关闭"), d), qn = /[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/gi, Gn = {}, Bn = {
    updateOrderListItem: function(e) {
        var t = (0, z.jo)(e).parentOrderSn;
        t && this.updateListItemByFetch({
            parentOrderSn: t
        });
    },
    updateListItem: function(e) {
        var t = e.index, r = e.parentOrderSn, a = e.payload, n = this.data.orderList, o = -1, i = n.find(function(e, a) {
            if (t === a || e.parentOrderSn === r) return o = a, !0;
        });
        if (i) {
            var s = Y(Y({}, i), a);
            this.setData(q({}, "orderList[".concat(o, "]"), s));
        }
    },
    updateListItemByFetch: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = e.parentOrderSn, r.next = 3, t.$baseRequest(Y(Y({}, z.pb), {}, {
                        data: {
                            parent_order_sn: a
                        }
                    })).catch(z.hm);

                  case 3:
                    if (n = r.sent, (o = (0, z.qh)(n, "result.order") || {}).parentOrderSn) {
                        r.next = 7;
                        break;
                    }
                    return r.abrupt("return");

                  case 7:
                    i = t.data.orderList, s = -1, (c = i.find(function(e, t) {
                        if (e.parentOrderSn === a) return s = t, !0;
                    })) && (u = Y(Y({}, c), Ln(o)), t.setData(q({}, "orderList[".concat(s, "]"), u)));

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    onPublishShareOrder: function(e) {
        var t = this, r = e.detail || {}, a = r.item, n = r.params, o = void 0 === n ? {} : n;
        (0, z.n3)({
            url: z.ob.publishShareOrder,
            params: Y(q({}, z.gf.orderSn, a.parentOrderSn), o)
        }), this.$addNextShowCallback(function() {
            t.updateListItemByFetch({
                parentOrderSn: a.parentOrderSn
            });
        });
    }
};

exports.agi = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    return (e || "").replace(qn, function(e) {
        return t ? "" : "‌" + e + "‌";
    }) || e;
}, exports.aha = function(e) {
    var t = "";
    t = Un[e.afterSalesStatus || 0];
    var r = Mn(e);
    return r && (t = r), t;
}, exports.aih = Mn, exports.agr = Ln, exports.aag = {
    WAITING: 0,
    PART: 2,
    END: 1
}, exports.zl = Dn, exports._w = wn, exports.zj = Nn, exports.zi = Rn, exports.zh = {
    DELIVERY_TIME: 200001,
    AFTER_SALE_TIME: 200002
}, exports.yr = Pn, exports.v6 = {
    DOING: 1,
    SUCCESS: 2,
    FAIL: 3
}, exports.yn = {
    APPLY_FOR_AFTER_SALES: 1,
    OWNER_APPROVE: 2,
    OWNER_REJECT: 3,
    VOLUNTARY_REFUND: 4,
    CANCEL_ORDER: 5,
    CANCEL_SUB_ORDER: 6,
    BATCH_PARTIAL_CANCEL_SUB_ORDER: 7,
    DELETE_TRACK_NO: 8,
    CUSTOMER_MODIFY_AFTER_SALES: 9
}, exports.xn = {
    SUCCESS: 1,
    FAIL: 2
}, exports.xm = {
    BALANCE_NOT_ENOUGH: 6,
    NO_BANK_CARD: 4
}, exports.y7 = {
    WECHAT: "WEXIN",
    MALL_BALANCE: "MALL_BALANCE_PAY",
    FRIEND_PAY: "FRIEND_PAY"
}, exports._p = {
    ONLY_REFUND: 0,
    REFUND_AND_CANCEL: 1,
    ONLY_CANCEL: 2
}, exports._t = An, exports.y5 = bn, exports.zx = {
    FROM_CANCEL_ORDER: 0,
    FROM_CANCEL_SINGLE_ORDER: 1,
    OTHER: 10
}, exports.vm = {
    EXCEL: 0,
    EMAIL: 1
}, exports._e = {
    RUNNING: 0,
    SUCCEED: 1,
    FAILED: 2,
    TIME_OUT: 3
}, exports.ve = kn, exports._c = Cn, exports.vk = In, exports.wl = {
    WAITING_AUDIT: 0,
    HELP_SELLER_APPROVE: 1,
    HELP_SELLER_REJECT: 2,
    SUPPLIER_APPROVE: 3,
    SUPPLIER_REJECT: 4
}, exports.aah = {
    NONE: 0,
    VERIFY: 1,
    PART_VERIFY: 2
}, exports._j = Tn, exports.y6 = {
    PAYED: 2
}, exports.ym = {
    MODIFY_APPLY: 1,
    ADD_EXPRESS: 2,
    MODIFY_EXPRESS: 3,
    CAN_APPROVE_REFUND: 4,
    CAN_VOLUNTARY_REFUND: 5,
    CAN_REVOKE_APPLY: 6,
    CAN_REJECT: 7
}, exports.s3 = En, exports.s4 = Sn, exports.zw = {
    REFUND: 0,
    RETURN_GOODS: 1
}, exports.yy = yn, exports.y0 = xn, exports.xg = _n, exports.za = vn, exports.yz = mn, 
exports.aba = gn, exports.ajv = fn;

var $n = (0, z.gg)({
    data: Y({}, Gn),
    methods: Y({}, Bn)
});

exports.acb = $n;

var Fn = Y({
    data: Gn
}, Bn), Hn = {
    UNUSED: 1,
    EXPIRED: 2,
    USED: 3
}, jn = [ {
    status: Hn.UNUSED,
    statusDesc: "未使用"
}, {
    status: Hn.USED,
    statusDesc: "已使用"
}, {
    status: Hn.EXPIRED,
    statusDesc: "已过期"
} ], Vn = {
    formatCoupon: function(e, t, r) {
        var a = e;
        return r ? (a.couponTitle = "无门槛", a.couponSubTitle = "全场通用", a.timeRangeStr = "".concat(W.default.formatTime(e.expireTime, "YYYY/M/d"), " 之前有效"), 
        a.couponAmountYuan = e.couponAmount / 100, a.status = Hn.UNUSED, Y({}, a)) : Y(Y({}, e), {}, {
            couponId: e.couponId,
            couponAmountYuan: W.default.price(e.couponAmount, 100),
            couponTitle: e.couponTitle,
            couponSubTitle: e.couponSubTitle,
            timeRangeStr: "".concat(W.default.formatTime(e.effectiveTimeEnd, "YYYY/M/d hh:mm"), " 前有效"),
            couponDesc: e.couponThreshold && e.couponThreshold > e.couponAmount ? "满".concat(W.default.price(e.couponThreshold, 100), "减").concat(W.default.price(e.couponAmount, 100)) : "无门槛",
            status: t,
            activityNo: e.activityNo || ""
        });
    }
}, Yn = Y({}, Vn), zn = (0, z.gg)({
    methods: Vn
});

function Wn(e) {
    return "[object Object]" === Object.prototype.toString.call(e);
}

exports.agl = zn, exports.acf = Yn, exports.ua = {
    PENALTY_COUPON: 0
}, exports.vi = {
    normal: 0,
    chat: 1,
    member: 2
}, exports.vj = {
    normal: 17,
    reduce: 18
}, exports.t7 = [ "去使用", "去查看", "查看更多" ], exports.t8 = {
    ALL: "all",
    PART: "part"
}, exports.t_ = jn, exports.t9 = Hn, exports.ajw = Fn;

var Kn = {
    freqShowStore: {}
}, Jn = {
    getFrequencyShow: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if (this._frequencyShowManager) return this._frequencyShowManager;
        var t = this.data.freqShowStore, r = void 0 === t ? {} : t, a = Object.keys(r).map(function(e) {
            var t = {
                key: e
            };
            return Wn(r[e]) && Object.assign(t, r[e]), t;
        });
        return this._frequencyShowManager = new z.ga(Y({
            elements: a
        }, e)), this._frequencyShowManager;
    },
    checkFrequencyShow: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, (a = t.getFrequencyShow()).checkShow.apply(a, V(e));

                  case 2:
                    n = t.getFrequencyShow().getShowStore(), t._setMultiShow(n);

                  case 4:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    checkFrequencyOneTimeShow: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.getFrequencyShow().checkOneTimeShow();

                  case 2:
                    r = e.getFrequencyShow().getOneTimeShowStore(), e._setMultiShow(r);

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    checkFrequencyQueueShow: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.getFrequencyShow().checkQueueShow();

                  case 2:
                    (r = e.getFrequencyShow().getQueueShowOne()) && (a = r.key, n = r.show, e._setOneShow(a, n));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    hideFrequencyShow: function(e, t) {
        var r = this;
        return U(M.default.mark(function a() {
            var n;
            return M.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, r.getFrequencyShow().hide(e, t);

                  case 2:
                    n = r.getFrequencyShow().isShow(e), r._setOneShow(e, n);

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    handleFrequencyShowHide: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = (0, z.jo)(e), n = a.key, o = a.config, r.next = 3, t.hideFrequencyShow(n, o);

                  case 3:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    getFrequencyStorage: function(e) {
        return this.getFrequencyShow().getStorage(e);
    },
    _setOneShow: function(e, t) {
        var r = this.data.freqShowStore;
        Wn((void 0 === r ? {} : r)[e]) ? this.setData(q({}, "freqShowStore.".concat(e, ".show"), !!t)) : this.setData(q({}, "freqShowStore.".concat(e), !!t));
    },
    _setMultiShow: function(e) {
        var t = this.data.freqShowStore, r = void 0 === t ? {} : t;
        Object.keys(r).forEach(function(t) {
            Wn(r[t]) ? Object.assign(r[t], {
                show: !!e[t]
            }) : r[t] = !!e[t];
        }), this.setData({
            freqShowStore: r
        });
    }
}, Xn = Y({
    data: Y({}, Kn),
    _frequencyShowManager: void 0
}, Jn), Qn = (0, z.gg)({
    data: Y({}, Kn),
    methods: Y({}, Jn)
}), Zn = {}, eo = {
    handleScrollWord: function(e, t) {
        var r = (0, z.g1)(e), a = r.splice(0, t);
        return r.concat(a) || [];
    }
}, to = Y({
    data: Y({}, Zn)
}, eo), ro = (0, z.gg)({
    data: Y({}, Zn),
    methods: Y({}, eo)
});

function ao(e) {
    var t = e.trackingExtParams || {};
    return Object.keys(e).forEach(function(r) {
        0 === "".concat(r).indexOf("log") && (t[r.slice(3).toLowerCase()] = e[r]);
    }), t;
}

exports.aiy = ro, exports.aco = to, exports.ag5 = Qn, exports.acl = Xn;

var no = {
    standardImpr: function(e) {
        var t = (0, z.jp)(e), r = t.log, a = O(t, Q);
        r && this.$impr({
            page_el_sn: r,
            extParams: ao(a)
        });
    },
    standardLogClick: function(e) {
        var t = (0, z.jp)(e), r = t.log, a = O(t, Z);
        r && this.$click({
            page_el_sn: r,
            extParams: ao(a)
        });
    }
}, oo = Y({}, no), io = (0, z.gg)({
    methods: no
}), so = {
    showHelpSellProtocolDialog: !1
}, co = {
    helpSellProtocolNotSigned: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.getBUserDataInfo();

                  case 2:
                    return r = t.sent, t.abrupt("return", r.hasAccount && (0, z.fj)([ z.b3.ktt_helpsell ], r).length > 0);

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    signHelpSellProtocol: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, t.helpSellProtocolNotSigned();

                  case 2:
                    if (r.sent) {
                        r.next = 4;
                        break;
                    }
                    return r.abrupt("return", (null == e || e(), Promise.resolve({
                        success: !0
                    })));

                  case 4:
                    return a = new z.ar(), r.abrupt("return", (t._helpSellEventListener = a, t.setData({
                        showHelpSellProtocolDialog: !0
                    }), new Promise(function(e) {
                        a.listenOnce("close", function() {
                            t.hideDialog(), e({});
                        }), a.listen("success", function() {
                            t.hideDialog(), setTimeout(function() {
                                e({
                                    success: !0
                                });
                            }, 1e3);
                        });
                    })));

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    hideDialog: function() {
        this.setData({
            showHelpSellProtocolDialog: !1
        });
    },
    hideHelpSellProtocolDialog: function() {
        var e;
        null === (e = this._helpSellEventListener) || void 0 === e || e.trigger("close");
    },
    onSignHelpSellProtocolSuccess: function() {
        var e;
        null === (e = this._helpSellEventListener) || void 0 === e || e.trigger("success");
    }
}, uo = Y({
    mixins: [ Aa ],
    data: Y({}, so)
}, co), po = (0, z.gg)({
    behaviors: [ Pa ],
    data: Y({}, so),
    methods: Y({}, co)
}), lo = (0, z.gg)({
    behaviors: [ io, Pa, po ],
    properties: {
        canCreateModifyGroup: {
            type: Boolean,
            value: !0
        },
        subUniversalSrc: {
            type: String,
            value: ""
        },
        recUniversalSrc: {
            type: String,
            value: ""
        },
        recChainSrc: {
            type: String,
            value: ""
        },
        subChainSrc: {
            type: String,
            value: ""
        },
        enableSimilarRec: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showInputPhone: !1,
        HELP_SELL_STATUS: {
            NONE: 0,
            CAN_COPY: 1,
            COPIED: 2,
            CAN_SHARE: 3,
            SHARED: 4
        }
    },
    methods: {
        refreshNextShow: function() {
            var e = this;
            this.$addNextShowCallback(function() {
                e.updateFeedsItem();
            });
        },
        getExNextPageParams: function(e) {
            var t, r = ((0, z.jp)(e) || {}).logRequest_id, a = this.data, n = a.subUniversalSrc, o = a.recUniversalSrc, i = a.recChainSrc, s = a.subChainSrc;
            return (0, z.p7)((q(t = {}, z.gf.recUniversalSrc, o), q(t, z.gf.subUniversalSrc, n), 
            q(t, z.gf.recChainSrc, i), q(t, z.gf.subChainSrc, s), q(t, z.gf.requestId, r), t), {
                clearEmptyString: !0
            });
        },
        asyncUpdateFeedsItem: function(e) {
            var t = this, r = (0, z.jo)(e).time;
            setTimeout(function() {
                t.updateFeedsItem();
            }, void 0 === r ? 1e3 : r);
        },
        updateFeedsItem: function() {
            var e = this, t = this.data, r = t.item, a = t.enableSimilarRec;
            return (0, z.fy)(Y(Y({}, z.o0), {}, {
                data: {
                    activityNo: r.activityNo,
                    isNewbieOfficialHelpSell: r.isNewbieOfficialHelpSell
                }
            })).then(function(t) {
                var n = t.result || {}, o = n.helpSellStatus, i = void 0 === o ? z.s.NO_CAN_SELL : o, s = n.helpSellActivityNo, c = r.helpSellCopyActivity || {};
                c.status = i, c.helpSellActivityNo = s, e.setData({
                    "item.helpSellCopyActivity": c
                }), e.triggerEvent("updateFeedsItemEvent", {
                    collectionActivityNo: r.activityNo,
                    helpSellCopyActivity: c,
                    updateItemData: {
                        helpSellCopyActivity: c
                    }
                }), a && i === z.s.CAN_SELL && Date.now() - e.$currentPage.$preOnHideTime > 12e3 && e.addCombinationFeedsList();
            }).catch(z.hm);
        },
        addCombinationFeedsList: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, r = this.data.item;
            r.activityNo && (0, z.fy)({
                url: "/api/ktt_rec/help_sell/rec_feeds/list_similar_activity_feeds",
                convertToCamel: !0,
                noErrorToast: !0,
                data: {
                    activity_no: r.activityNo,
                    scene: 1,
                    previous_request_id: r.requestId,
                    list_id: r.listId,
                    trigger_method: t
                }
            }).then(function(t) {
                var a = t.result;
                if (a) {
                    var n = a.activityCombinationFeedDto, o = a.requestId;
                    if (n) {
                        var i = n.list.map(function(e) {
                            return Y(Y({}, e), {}, {
                                requestId: o
                            });
                        });
                        e.setData({
                            "item.combinationFeedsList": i
                        }), e.triggerEvent("updateFeedsItemEvent", {
                            collectionActivityNo: r.activityNo,
                            helpSellCopyActivity: e.data.helpSellCopyActivity,
                            updateItemData: {
                                combinationFeedsList: i
                            }
                        });
                    }
                }
            });
        },
        handleCombinationClick: function(e) {
            var t = (0, z.jo)(e).index, r = this.data.item.combinationFeedsList[t].sn;
            this.standardLogClick(e), Vt(r, {
                activityParams: Y(Y({}, this.getExNextPageParams(e)), {}, q({}, z.gf.subChainSrc, "activityCombinationFeed"))
            });
        },
        navToActivity: function(e) {
            var t = (0, z.jp)(e) || {}, r = t.activityNo, a = t.displayType;
            this.standardLogClick(e), Vt(r, {
                displayType: a,
                activityParams: this.getExNextPageParams(e)
            });
        },
        navToCreate: function(e) {
            var t, r = ((0, z.jp)(e) || {}).activityNo;
            if (this.standardLogClick(e), this.createInterceptor()) {
                this.needReload = !0;
                var a = this.data, n = a.isFromCaptain, o = void 0 !== n && n, i = a.isHelpSellTab, s = void 0 !== i && i;
                (0, z.n3)({
                    url: z.ob.createChain,
                    params: Y((t = {}, q(t, z.gf.collectionActivityNo, r), q(t, z.gf.isCopy, 1), q(t, z.gf.feedsEditHelpSellPage, (0, 
                    z.qh)(this, "$currentPage.pageProperties.page_name")), q(t, z.gf.captainHelpSellTab, o && s ? 1 : 0), 
                    t), this.getExNextPageParams(e))
                }), this.refreshNextShow();
            }
        },
        handleCreateHelpSell: (0, z.my)(U(M.default.mark(function e() {
            var t, r, a, n, o, i, s, c, u, p, l, d, h = this, f = arguments;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = f.length > 0 && void 0 !== f[0] ? f[0] : {}, r = (0, z.jp)(t) || {}, a = r.activityNo, 
                    n = r.requestParams, o = r.helpSellActivityNo, i = r.activitySrc, s = r.helpSellRelationType, 
                    c = (0, z.ja)(), u = (0, z.ll)(), this.helpEvent = t, (0, z.l7)({
                        msg: "goods recommend create help sell",
                        data: {
                            activityNo: a,
                            helpSellActivityNo: o,
                            bUserInfo: c,
                            userInfo: u
                        }
                    }), this.createInterceptor()) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    return this.standardLogClick(t), e.next = 7, this.checkHasAccount();

                  case 7:
                    if (e.sent) {
                        e.next = 9;
                        break;
                    }
                    return e.abrupt("return", (this.triggerEvent("showInputPhone", {
                        helpEvent: t
                    }), void this.setData({
                        showInputPhone: !0
                    })));

                  case 9:
                    return p = n || {}, s >= 0 && (p.help_sell_relation_type = s), e.next = 13, this.signHelpSellProtocol();

                  case 13:
                    return l = e.sent, d = l.success, e.abrupt("return", d ? zt({
                        activityNo: a || o,
                        requestParams: p,
                        params: (0, z.p7)(Y(Y({}, this.getExNextPageParams(t)), {}, {
                            activity_src: i
                        })),
                        beforeForward: function(e) {
                            h.needReload = !0, (0, z.l7)({
                                msg: "goods recommend create activity success",
                                data: {
                                    supplyActivityNo: a || o,
                                    result: e
                                }
                            });
                        }
                    }).then(function() {
                        h.data.item.isNewbieOfficialHelpSell && z.f9.trigger(z.f1.newcomerFreeHelpSelled, {
                            activityNo: a || o
                        }), h.refreshNextShow();
                    }).catch(z.hm) : void 0);

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }))),
        closeInputPhone: function() {
            this.setData({
                showInputPhone: !1
            });
        },
        createAccountSuccess: function(e) {
            var t = (0, z.jo)(e).helpEvent;
            this.setData({
                showInputPhone: !1
            }), this.handleCreateHelpSell(t || this.helpEvent);
        },
        forwardMain: function(e) {
            var t = (0, z.jo)(e).userNo;
            (0, z.n3)({
                url: z.ob.goodsRecommendDetail,
                params: q({}, z.gf.supplyUserNo, t)
            });
        },
        createInterceptor: function() {
            var e = this.data.canCreateModifyGroup;
            return !e && this.$showToast({
                title: "无权限，请联系团长开通"
            }), e;
        }
    }
}), ho = (0, z.ke)(), fo = {
    data: {
        kttHeader: Y(Y({}, ho), {}, {
            navBarHeightRpx: (0, z.ov)(ho.navBarHeight)
        })
    }
}, go = (0, z.gg)(fo), mo = {
    tipsSwiperInterval: 5e3,
    tipsSwiperCurrent: 0,
    tipsVos: [],
    tipsSwiperMarqueeFontSize: 24,
    tipsSwiperMarqueeMaxWidth: 610
}, vo = {
    initTipsSwiperMarqueeConfig: function(e) {
        var t = e.fontSize, r = e.maxWidth;
        this.setData(Y(Y({}, e), {}, {
            tipsSwiperMarqueeFontSize: t,
            tipsSwiperMarqueeMaxWidth: r
        }));
    },
    handleTipsSwiperChange: function(e) {
        var t = (0, z.jo)(e), r = t.current, a = t.source, n = this.data.tipsSwiperMarqueeFontSize || 24, o = this.data.tipsSwiperMarqueeMaxWidth || 610, i = (0, 
        z.nm)((this.data.tipsVos[r] || {}).content, n), s = i > o ? i / 75 * 1e3 : 1e3;
        "autoplay" === a && this.setData({
            tipsSwiperCurrent: r
        }), this.setData({
            tipsSwiperInterval: s + 4e3
        });
    },
    arrayDedupe: function(e, t) {
        var r = {};
        return e.filter(function(e) {
            return !r[e[t]] && (r[e[t]] = !0, !0);
        });
    },
    touchEmptyFunction: function() {},
    handleTapTipsSwiperItem: function(e) {
        var t = (0, z.jo)(e, "item") || {}, r = t.permCode, a = t.url, n = t.params, o = void 0 === n ? {} : n;
        a && (r && this.checkPerm && !this.checkPerm(r) || (/^(\/\w+)+/.test(a) ? (0, z.n3)({
            url: a,
            params: o
        }) : /^\w+$/.test(a) ? (0, z.n5)({
            pageName: a,
            params: o
        }) : /^https?:\/\/(.*?)/.test(a) && (0, z.n4)({
            path: a,
            params: o
        })));
    }
}, _o = Y({
    data: Y({}, mo)
}, vo), xo = (0, z.gg)({
    data: Y({}, mo),
    methods: Y({}, vo)
});

exports.ajs = xo, exports.aem = _o, exports.abb = go, exports.ael = fo, exports.ai1 = exports.acw = lo, 
exports.ai4 = po, exports.ac_ = uo, exports.amy = io, exports.aet = oo;

var yo = (0, z.gg)({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                this.data.enableShowObserver && this.$popupVisibleChange(e);
            }
        },
        enableShowObserver: {
            type: Boolean,
            value: !0
        }
    },
    lifetimes: {
        attached: function() {
            this.$popupVisible && this.$popupVisibleChange(this.$popupVisible);
        },
        detached: function() {
            this.$popupVisible && this.$popupVisibleChange(!1);
        }
    }
});

exports.aeo = yo;

var So = {
    PERSON_CENTER: 1,
    CAPTAIN: 2
}, Eo = {
    categoryName: "全部分类",
    activityCategoryStatList: [],
    activityCategory: -1,
    showGroupCatePanel: !1,
    showCategory: !1
}, To = {
    onLoad: function() {
        this.listenEditCate();
    },
    getGroupCateInfo: function(e) {
        var t = e.showCategory, r = e.onlyDefaultCategory, a = e.activityCategoryStatList;
        if (t && r && 1 === a.length) a = [ {
            categoryId: -1,
            categoryName: "全部分类",
            activityNum: a[0].activityNum
        } ]; else if (t) {
            var n = a.reduce(function(e, t) {
                return e + t.activityNum;
            }, 0);
            a.unshift({
                categoryId: -1,
                categoryName: "全部分类",
                activityNum: n
            });
        }
        this.setData({
            showCategory: t,
            activityCategoryStatList: a
        }, this.stickySearchObserve);
    },
    toggleShowGroupCatePanel: function() {
        this.setData({
            showGroupCatePanel: !this.data.showGroupCatePanel
        });
    },
    handleSelectCate: function(e) {
        var t = this, r = e.detail, a = r.id, n = r.name;
        this.setData({
            categoryName: n,
            activityCategory: a,
            helpSellTabType: "all"
        }, function() {
            t.pageNumber = 1, t.helpSellPageNumber = 1, t.requestChannel === So.PERSON_CENTER ? t.initRelease && t.initRelease() : t.loadMoreActivity && t.loadMoreActivity();
        });
    },
    listenEditCate: function() {
        var e = this;
        this.$eventChannel.on(z.f1.changeCustomCategory, function(t) {
            var r = t.type, a = t.activityCategory, n = void 0 === a ? {} : a, o = n.activityCategoryName, i = n.activityCategoryId, s = n.activityCount;
            return [ "delete" ].includes(r) && s ? (e.setData({
                categoryName: "未分类",
                activityCategory: 0
            }), void (e.data.activityCategory === i ? e.initCateAndFeeds() : e.requestChannel === So.PERSON_CENTER ? e.getPersonData && e.getPersonData() : e.getCaptainData && e.getCaptainData())) : [ "modify" ].includes(r) && s ? (e.data.activityCategory === i && e.setData({
                categoryName: o,
                activityCategory: i
            }), void e.initCateAndFeeds()) : void ([ "sort" ].includes(r) && (e.requestChannel === So.PERSON_CENTER ? e.getPersonData && e.getPersonData() : e.getCaptainData && e.getCaptainData()));
        });
    },
    initCateAndFeeds: function() {
        this.requestChannel === So.PERSON_CENTER ? (this.getPersonData && this.getPersonData(), 
        this.initRelease && this.initRelease()) : (this.getCaptainData && this.getCaptainData(), 
        this.pageNumber = 1, this.setData({
            hasMore: !0
        }), this.loadMoreActivity && this.loadMoreActivity());
    }
}, Io = Y({
    data: Y({}, Eo)
}, To), Co = O(To, [ "onLoad" ]), ko = (0, z.gg)({
    data: Y({}, Eo),
    methods: Y({
        onSign: function() {
            this.listenEditCate();
        }
    }, Co)
}), bo = {
    INDEX: "ktt_index",
    CHAIN_DETAIL: "ktt_chaindetail",
    PERSON_CENTER: "ktt_newpersonal",
    CAPTAIN: "ktt_captain",
    INDEX_SEARCH: "ktt_index_search",
    INDEX_SEARCH_RESULT: "ktt_index_search_result",
    SIGN_UP_CHECKOUT: "ktt_sign_up_checkout",
    PART_COMMISSION_MANAGE: "ktt_part_commission_manage",
    HELP_SELL_ACTIVITY: "ktt_help_sell_activity",
    TODAY_STAR_CAPTAINS: "ktt_today_star_captains"
}, Ao = {
    index: "index",
    captain: "captain",
    helpSellActivity: "helpSellActivity",
    newPersonal: "newPersonal",
    todayStarCaptains: "todayStarCaptains",
    partCommissionManage: "partCommissionManage"
}, Po = {
    ELE_SN_MAP: {
        INPUT: 5306240,
        HISTORY: 5306242,
        DELETE: 5337214
    },
    searchRecords: []
}, Ro = (q(h = {}, bo.PART_COMMISSION_MANAGE, z.fs.partCommissionManage), q(h, bo.HELP_SELL_ACTIVITY, z.fs.helpSellActivity), 
q(h, bo.PERSON_CENTER, z.fs.personal), q(h, bo.TODAY_STAR_CAPTAINS, z.fs.todayStarCaptains), 
h), No = (q(f = {}, bo.PART_COMMISSION_MANAGE, Ao.partCommissionManage), q(f, bo.HELP_SELL_ACTIVITY, Ao.helpSellActivity), 
q(f, bo.PERSON_CENTER, Ao.newPersonal), q(f, bo.TODAY_STAR_CAPTAINS, Ao.todayStarCaptains), 
f), wo = {
    showSearchArea: function(e) {
        var t, r, a, n, o = (0, z.jo)(e), i = o.value, s = void 0 === i ? "" : i, c = o.userNo, u = void 0 === c ? "" : c, p = o.log, l = void 0 === p ? "" : p;
        if (l && this.$click({
            page_el_sn: l
        }), "ktt_index_search" === (null === (r = null === (t = this.$referPage) || void 0 === t ? void 0 : t.pageProperties) || void 0 === r ? void 0 : r.page_name)) return this.$eventChannel.emit(z.f1.searchValueChange, {
            value: s
        }), (0, z.ny)();
        var d, h = (null === (n = null === (a = this.$currentPage) || void 0 === a ? void 0 : a.pageProperties) || void 0 === n ? void 0 : n.page_name) || bo.PERSON_CENTER;
        (0, z.n3)({
            url: z.fs.indexSearch,
            params: (d = {}, q(d, z.gf.searchPageFrom, No[h]), q(d, z.gf.searchValue, s), q(d, z.gf.jumpUrl, Ro[h]), 
            q(d, z.gf.userNo, u), d)
        });
    },
    getSearchHistory: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest(Y(Y({}, z.jh), {}, {
                        data: {
                            scene: Fa.helpSellSearchHistory
                        }
                    })).catch(z.hm);

                  case 2:
                    if ((r = t.sent) && r.result) try {
                        a = JSON.parse(r.result), Array.isArray(a) && a.length && (e.setData({
                            searchRecords: a.reverse()
                        }), e.$impr({
                            page_el_sn: e.data.ELE_SN_MAP.HISTORY
                        }));
                    } catch (t) {
                        e.$error({
                            e: t,
                            msg: "helpsell activity search history parse error",
                            data: r
                        });
                    }

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    setSearchHistory: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = t.data.searchRecords, (n = (n = void 0 === a ? [] : a).filter(function(t) {
                        return t !== e;
                    })).unshift(e), n = n.slice(0, 20), r.next = 6, t.$baseRequest(Y(Y({}, z.qr), {}, {
                        data: {
                            scene: Fa.helpSellSearchHistory,
                            value: JSON.stringify(n.concat().reverse())
                        }
                    })).catch(z.hm);

                  case 6:
                    t.setData({
                        searchRecords: n
                    });

                  case 7:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    clearSearchHistory: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.$click({
                        page_el_sn: e.data.ELE_SN_MAP.DELETE
                    }), t.prev = 1, t.next = 4, e.$showModal({
                        content: "确认删除全部历史记录吗？",
                        showCancel: !0,
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 4:
                    if (t.t0 = t.sent.confirm, !t.t0) {
                        t.next = 7;
                        break;
                    }
                    e.$baseRequest(Y(Y({}, z.hh), {}, {
                        data: {
                            scene: Fa.helpSellSearchHistory
                        }
                    })).then(function() {
                        e.setData({
                            searchRecords: []
                        });
                    }).catch(z.hm);

                  case 7:
                    t.next = 11;
                    break;

                  case 9:
                    t.prev = 9, t.t1 = t.catch(1);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 9 ] ]);
        }))();
    }
};

exports.ajm = {
    localLivingGoodsLibrary: "localLivingGoodsLibrary",
    captainLocalLivingGoods: "captainLocalLivingGoods"
}, exports.amn = Ao, exports.akp = bo, exports.aiu = ko, exports.aep = Io, exports.z0 = So, 
exports.wa = {
    NO_SHOW: 0,
    SHOW_CATE: 1
};

var Do = Y({
    data: Po
}, wo);

exports.aeq = Do;

var Oo = (0, z.gg)({
    data: Y({}, Po),
    methods: Y({}, wo)
}), Lo = {
    onLoad: function() {
        this.showQueryToast();
    },
    showQueryToast: function() {
        var e = this.$query[z.gf.toastTitle];
        e && this.$showToast({
            title: e,
            icon: "none"
        });
    }
}, Mo = O(Lo, [ "onLoad" ]), Uo = (0, z.gg)({
    methods: Y({
        onSign: function() {
            this.showQueryToast();
        }
    }, Mo)
}), qo = {
    ACTIVITY_DETAIL_ORDER_PUSH: "activity_detail_order_push_v2",
    ACTIVITY_DETAIL_ORDER_USER_INCOME_PUSH: "activity_detail_order_user_income_push",
    INNER_NOTICE_PUSH: "inner_notice_push",
    LIVE_SHOW_BILLBOARD_INFO_PUSH: "live_show_billboard_info_push",
    INNER_NOTICE_POP_PUSH: "inner_notice_pop_push"
}, Go = {
    onLoad: function() {
        var e = this;
        this.socketListener = z.f9.listen(z.f1.onSocketPush, function() {
            e.handleSocketPush.apply(e, arguments);
        }), this.popDismissListener = z.f9.listen(z.f1.dismissPopPush, function() {
            e.dismissPop.apply(e, arguments);
        });
    },
    onUnload: function() {
        this.socketListener && this.socketListener(), this.popDismissListener && this.popDismissListener();
    },
    handleSocketPush: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.bizData, r = void 0 === t ? {} : t, a = e.bizScene;
        a === qo.INNER_NOTICE_POP_PUSH && this.setData({
            showPushNoticePop: !0,
            pushMessage: r
        });
    },
    dismissPop: function() {
        this.setData({
            showPushNoticePop: !1,
            pushMessage: null
        });
    }
};

exports._r = qo, exports.amt = Uo, exports.aer = Lo, exports.aml = Oo;

var Bo = Y({
    data: {
        showPushNoticePop: !1,
        pushMessage: null
    }
}, Go);

exports.aes = Bo;

var $o = O(Go, [ "onLoad", "onUnload" ]), Fo = (0, z.gg)({
    data: {
        showPushNoticePop: !1,
        pushMessage: null
    },
    onSign: function() {
        this.socketListener = z.f9.listen(z.f1.onSocketPush, this.handleSocketPush.bind(this)), 
        this.popDismissListener = z.f9.listen(z.f1.dismissPopPush, this.dismissPop.bind(this));
    },
    detached: function() {
        this.socketListener && this.socketListener(), this.popDismissListener && this.popDismissListener();
    },
    methods: Y({}, $o)
}), Ho = {
    handleUpdateFeedsItemEvent: function(e) {
        var t = (0, z.jo)(e), r = t.listName, a = void 0 === r ? "" : r, n = t.updateItemData, o = void 0 === n ? {} : n, i = t.collectionActivityNo, s = (0, 
        z.qh)(this.data, a) || [], c = (s || []).findIndex(function(e) {
            return e.activityNo === i;
        });
        c >= 0 && this.setData(q({}, "".concat(a, "[").concat(c, "]"), Y(Y({}, s[c]), o)));
    }
}, jo = Y({}, Ho), Vo = (0, z.gg)({
    methods: Ho
}), Yo = {
    FAIR: 0,
    UP: 1,
    DOWN: 2
}, zo = {
    NONE: 0,
    COUNTRY: 1,
    PROVINCE: 2,
    CITY: 4
}, Wo = (q(g = {}, zo.COUNTRY, "全国"), q(g, zo.PROVINCE, "全省"), q(g, zo.CITY, "全市"), 
g), Ko = {
    ALL: "all",
    LOGISTICS: "logistics",
    VERIFICATION: "verification",
    AFTER_SALES: "afterSales",
    REMARK: "remark",
    GROUP_BUY: "groupBuy",
    TO_SHIP: "toShip",
    PART_SHIP: "partShip",
    SHIP: "ship",
    RECEIVED: "received",
    TO_PICK: "toPick",
    PART_PICK: "partpick",
    PICK: "pick",
    TO_REFUND: "toRefund",
    REFUND: "refund",
    CANCEL: "cancel",
    CUSTOMER_REMARK: "customerRemark",
    BUSINESS_REMARK: "businessRemark",
    PRIVATE_REMARK: "privateRemark",
    GROUP_BUY_ONGOING: "groupBuyOngoing",
    GROUP_BUY_SUCCESS: "groupBuySuccess",
    GROUP_BUY_FAIL: "groupBuyFail",
    AFTER_SALES_LIST: "afterSalesList"
}, Jo = [ {
    id: Ko.ALL,
    title: "全部",
    isDefault: !0,
    subTabList: [],
    fetchParams: {}
}, {
    id: Ko.LOGISTICS,
    title: "发货",
    subTabList: [ {
        subId: Ko.TO_SHIP,
        id: Ko.LOGISTICS,
        title: "待发货",
        count: 0,
        showShipTips: !0,
        fetchParams: {
            shippingAggregateStatus: yn.TO_SHIP,
            sortOrder: !0
        }
    }, {
        subId: Ko.PART_SHIP,
        id: Ko.LOGISTICS,
        title: "部分发货",
        count: 0,
        fetchParams: {
            shippingAggregateStatus: yn.PART_SHIP,
            sortOrder: !0
        }
    }, {
        subId: Ko.SHIP,
        id: Ko.LOGISTICS,
        title: "已发货",
        count: 0,
        showShipTips: !0,
        fetchParams: {
            shippingAggregateStatus: yn.SHIP,
            sortOrder: !0
        }
    }, {
        subId: Ko.RECEIVED,
        id: Ko.LOGISTICS,
        title: "已收货",
        count: 0,
        fetchParams: {
            shippingAggregateStatus: yn.RECEIVED
        }
    } ]
}, {
    id: Ko.VERIFICATION,
    title: "核销",
    subTabList: [ {
        subId: Ko.TO_PICK,
        id: Ko.VERIFICATION,
        title: "待提货",
        count: 0,
        fetchParams: {
            shippingAggregateStatus: yn.TO_PICK,
            sortOrder: !0
        }
    }, {
        subId: Ko.PART_PICK,
        id: Ko.VERIFICATION,
        title: "部分提货",
        count: 0,
        fetchParams: {
            shippingAggregateStatus: yn.PART_PICK,
            sortOrder: !0
        }
    }, {
        subId: Ko.PICK,
        id: Ko.VERIFICATION,
        title: "已提货",
        count: 0,
        fetchParams: {
            shippingAggregateStatus: yn.PICK,
            sortOrder: !0
        }
    } ]
}, {
    id: Ko.AFTER_SALES,
    title: "售后",
    subTabList: []
} ], Xo = {
    id: Ko.GROUP_BUY,
    title: "拼团",
    isGroupBuy: !0,
    subTabList: [ {
        subId: Ko.GROUP_BUY_ONGOING,
        id: Ko.GROUP_BUY,
        title: "拼团中",
        count: 0,
        isGroupBuy: !0,
        fetchParams: {
            groupStatus: z.a0.ONGOING
        }
    }, {
        subId: Ko.GROUP_BUY_SUCCESS,
        id: Ko.GROUP_BUY,
        title: "拼团成功",
        count: 0,
        isGroupBuy: !0,
        fetchParams: {
            groupStatus: z.a0.COMPLETED
        }
    }, {
        subId: Ko.GROUP_BUY_FAIL,
        id: Ko.GROUP_BUY,
        title: "拼团失败",
        count: 0,
        isGroupBuy: !0,
        fetchParams: {
            groupStatus: z.a0.EXPIRED
        }
    } ]
}, Qo = Jo[0], Zo = (q(m = {}, Ko.ALL, 5470374), q(m, Ko.LOGISTICS, 5470375), q(m, Ko.VERIFICATION, 5470376), 
q(m, Ko.AFTER_SALES, 5470377), q(m, Ko.REMARK, 5470378), q(m, Ko.TO_SHIP, 5470388), 
q(m, Ko.PART_SHIP, 5470389), q(m, Ko.SHIP, 5470390), q(m, Ko.TO_PICK, 5470385), 
q(m, Ko.PART_PICK, 5470386), q(m, Ko.PICK, 5470387), q(m, Ko.TO_REFUND, 5470381), 
q(m, Ko.REFUND, 5470382), q(m, Ko.CANCEL, 5470383), q(m, Ko.CUSTOMER_REMARK, 5470379), 
q(m, Ko.BUSINESS_REMARK, 5470380), q(m, Ko.PRIVATE_REMARK, 7816170), q(m, Ko.AFTER_SALES_LIST, 5470384), 
m), ei = {
    DEFAULT: 1,
    ORDER: 2,
    REVERSE_ORDER: 3
}, ti = (q(v = {}, ei.DEFAULT, "恢复默认状态"), q(v, ei.ORDER, "按照待核销数量升序排序"), q(v, ei.REVERSE_ORDER, "按照待核销数量降序排序"), 
v), ri = {
    PUBLIC: 0,
    PRIVATE: 1
}, ai = {
    ALL: "all",
    TO_PAY: "to_pay",
    LOGISTICS: "logistics",
    TO_SHIP: "to_ship",
    PART_SHIP: "part_ship",
    SHIP: "ship",
    RECEIVED: "received",
    AFTER_SALES: "after_sales",
    TO_REFUND: "to_refund",
    REFUND: "refund"
}, ni = (q(_ = {}, ai.ALL, {}), q(_, ai.TO_PAY, {}), q(_, ai.TO_SHIP, {
    shippingAggregateStatus: yn.TO_SHIP
}), q(_, ai.PART_SHIP, {
    shippingAggregateStatus: yn.PART_SHIP
}), q(_, ai.SHIP, {
    shippingAggregateStatus: yn.SHIP
}), q(_, ai.RECEIVED, {
    shippingAggregateStatus: yn.RECEIVED
}), q(_, ai.TO_REFUND, {
    orderStatus: xn.TO_REFUND
}), q(_, ai.REFUND, {
    orderStatus: xn.REFUNDED
}), _), oi = [ {
    id: ai.ALL,
    title: "全部",
    fetchParams: {}
}, {
    id: ai.TO_PAY,
    title: "待支付",
    fetchParams: {}
}, {
    id: ai.LOGISTICS,
    title: "发货",
    hasSubTab: !0,
    subTabList: [ {
        subId: ai.TO_SHIP,
        id: ai.LOGISTICS,
        title: "待发货",
        fetchParams: {}
    }, {
        subId: ai.PART_SHIP,
        id: ai.LOGISTICS,
        title: "部分发货",
        fetchParams: {}
    }, {
        subId: ai.SHIP,
        id: ai.LOGISTICS,
        title: "已发货",
        fetchParams: {}
    }, {
        subId: ai.RECEIVED,
        id: ai.LOGISTICS,
        title: "已收货",
        fetchParams: {}
    } ]
}, {
    id: ai.AFTER_SALES,
    title: "售后",
    hasSubTab: !0,
    subTabList: [ {
        subId: ai.TO_REFUND,
        id: ai.AFTER_SALES,
        title: "待退款",
        toRefund: !0,
        fetchParams: {}
    }, {
        subId: ai.REFUND,
        id: ai.AFTER_SALES,
        title: "已退款",
        fetchParams: {}
    } ]
} ], ii = oi[0];

exports.uc = ii, exports.ue = oi, exports._0 = ni, exports.uf = ai, exports.zy = {
    ALLOW: 0,
    BAN: 1,
    BAN_AFTER_OVER: 2,
    BAN_AFTER_RECEIVE: 3
}, exports.zf = {
    ONLINE: 1,
    COPY: 2
}, exports.vl = {
    ONGOING: 0,
    SUCCESS: 1,
    FAIL: 2,
    TIME_OUT: 3,
    NONE: 100
}, exports.zp = 200, exports.vo = "您上传的物流单号含字母和数字之外的字符，可能导致物流轨迹查询失败", exports.ti = ri, 
exports.u4 = {
    displayName: "全部物流方式",
    siteName: "全部自提点",
    siteNo: "",
    expressType: ""
}, exports.v9 = ti, exports.v8 = ei, exports.y3 = Zo, exports.ail = function(e, t) {
    var r = q({}, z.gf.orderShipTab, "shippingAggregateStatus")[t];
    return r && Jo.reduce(function(e, t) {
        var r;
        return (null === (r = t.subTabList) || void 0 === r ? void 0 : r.length) ? e.concat(t.subTabList) : e;
    }, []).find(function(t) {
        return t.fetchParams[r] === e;
    }) || null;
}, exports.ut = Qo, exports.v_ = Xo, exports.zz = [ {
    title: "备注",
    filterDisplayTitle: "不限",
    fetchParams: {}
}, {
    title: "团员备注",
    fetchParams: {
        noteType: 1,
        sortOrder: !0
    }
}, {
    title: "团长备注",
    fetchParams: {
        noteType: 2,
        sortOrder: !0
    }
}, {
    title: "私密备注",
    fetchParams: {
        noteType: 3,
        sortOrder: !0
    }
} ], exports.y1 = Jo, exports.y2 = Ko, exports.yv = {
    ALL: 1,
    NO: 2,
    PHONE: 3,
    WECHAT_NAME: 4,
    NAME: 5,
    GOODS: 6
}, exports.wo = {
    amountUp: 1,
    amountDown: 2,
    orderUp: 3,
    orderDown: 4
}, exports.um = "全部团长订单", exports.zr = {
    NO: 0,
    YES: 1
}, exports.zs = Wo, exports.zu = zo, exports.zt = Yo, exports.anh = Vo, exports.aeu = jo, 
exports.amw = Fo;

exports.aex = {
    redPacket: 1,
    helpSellDialog: 1,
    inviteMentionManagerPopup: 1,
    inviteAdminPopup: 1,
    exHelpSellModal: 1,
    inviteRecHelpSellPopup: 1,
    assistHelpPopup: 1,
    riskCaptainDialog: 1,
    supplyLimitDialog: 1,
    beAdminNoticeDialog: 10,
    riskToastDialog: 10,
    showHelpSellModal: 10,
    inviteDialog: 10,
    feeBackDialog: 10,
    inviteAmountArriveDialog: 10,
    pullNewDataDialog: 10,
    bigImgTemplateDialog: 10,
    qrCodeConnectDialog: 10,
    bizToast: 10,
    newFeeBackDialog: 10,
    modifyRealName: 10,
    subsideyStrategyDialog: 10
};

var si = function(e) {
    if (e) switch (e) {
      case 1007:
      case 1008:
      case 1044:
      case 1158:
      case 1073:
      case 1074:
      case 1185:
        return z.b6["scene-card"];

      case 1047:
      case 1048:
      case 1049:
        return z.b6["scene-qrcode"];

      case 1065:
        return z.b6["scene-scheme"];

      case 1014:
      case 1043:
      case 1107:
        return z.b6["scene-push"];

      case 1160:
        return z.b6["scene-todo"];

      case 1179:
        return z.b6["scene-short-link"];

      default:
        return 0;
    }
    return 0;
}, ci = {
    FIRST: 1,
    SECOND: 2,
    THIRD: 3,
    FOURTH: 4
}, ui = {
    LOCK: 0,
    CAN_RECEIVE: 1,
    RECEIVED: 2,
    ISSUING: 3
}, pi = {
    OFFICAL_HELP_SELL: 0,
    STAR_HELP_SELL: 1,
    RECEIVE_RED_POCKET: 2,
    OFFICAL_HELP_SELL_GROUP: 3,
    CITY_MANAGER_SERVICE: 4,
    TAKE_GOODS_LABEL: 5,
    COMMUNITY_GOODS_LABEL: 6,
    GOODS_LIBRARY: 7
}, li = {
    SALES: 1,
    CREATE_GROUP: 2,
    CREATE_GROUP_COUNT: 3,
    GROUP_UV: 4
}, di = (q(x = {}, li.SALES, "销售额"), q(x, li.CREATE_GROUP, "每日开团"), q(x, li.CREATE_GROUP_COUNT, "开团次数"), 
q(x, li.GROUP_UV, "团浏览量"), x), hi = (q(y = {}, pi.RECEIVE_RED_POCKET, "开团红包"), q(y, pi.OFFICAL_HELP_SELL_GROUP, "官方帮卖群"), 
q(y, pi.GOODS_LIBRARY, "多多商品库"), q(y, pi.COMMUNITY_GOODS_LABEL, "好物达人标"), y), fi = {
    AUDIT: 0,
    ACCEPT: 1,
    REJECT: 2
}, gi = (q(S = {}, fi.AUDIT, "待审核"), q(S, fi.ACCEPT, "已采纳"), q(S, fi.REJECT, "未采纳"), 
S), mi = (q(E = {}, fi.AUDIT, "奖励团长审核中，请耐心等待"), q(E, fi.ACCEPT, "感谢您的晒单，晒单奖励已发放至您的账户（红包有效期15天）"), 
E), vi = {
    PREVIEW: -10,
    NOT_STARTED: -5,
    OPENING: 1,
    CLOSING: 20,
    DELETE: 30
}, _i = (q(T = {}, vi.PREVIEW, "预览中"), q(T, vi.NOT_STARTED, "未开始"), q(T, vi.OPENING, "开启中"), 
q(T, vi.CLOSING, "已结束"), q(T, vi.DELETE, "已删除"), T), xi = [ {
    picUrl: (0, z.jm)("ktt/gv.png.slim.png"),
    text: "邀请团员晒单"
}, {
    picUrl: (0, z.jm)("ktt/gw.png.slim.png"),
    text: "团员分享晒单到群"
}, {
    picUrl: (0, z.jm)("ktt/gx.png.slim.png"),
    text: "群成员跟团购买"
} ], yi = {
    NO_LIMIT: 1,
    OVER_10: 5,
    OVER_15: 2,
    OVER_30: 3,
    OVER_50: 4
}, Si = [ {
    type: yi.NO_LIMIT,
    text: "不限制字数",
    value: 0
}, {
    type: yi.OVER_10,
    text: "10字以上",
    value: 10
}, {
    type: yi.OVER_15,
    text: "15字以上",
    value: 15
}, {
    type: yi.OVER_30,
    text: "30字以上",
    value: 30
}, {
    type: yi.OVER_50,
    text: "50字以上",
    value: 50
} ], Ei = {
    NO_LIMIT: 1,
    OVER_1: 2,
    OVER_2: 5,
    OVER_3: 3,
    OVER_6: 4
}, Ti = [ {
    type: Ei.NO_LIMIT,
    text: "不限制张数",
    value: 0
}, {
    type: Ei.OVER_1,
    text: "1张以上",
    value: 1
}, {
    type: Ei.OVER_2,
    text: "2张以上",
    value: 2
}, {
    type: Ei.OVER_3,
    text: "3张以上",
    value: 3
}, {
    type: Ei.OVER_6,
    text: "6张以上",
    value: 6
} ], Ii = {
    ALL: -1,
    WILL_AUDIT: 0,
    ACCEPTED: 1,
    REJECTED: 2
}, Ci = (q(I = {}, Ii.ALL, "全部"), q(I, Ii.WILL_AUDIT, "待审核"), q(I, Ii.ACCEPTED, "已采纳"), 
q(I, Ii.REJECTED, "未采纳"), I), ki = [ {
    type: Ii.ALL,
    label: Ci[Ii.ALL],
    active: !0
}, {
    type: Ii.WILL_AUDIT,
    label: Ci[Ii.WILL_AUDIT],
    active: !1
}, {
    type: Ii.ACCEPTED,
    label: Ci[Ii.ACCEPTED],
    active: !1
}, {
    type: Ii.REJECTED,
    label: Ci[Ii.REJECTED],
    active: !1
} ], bi = {
    ACCEPT: 1,
    REJECT: 2,
    DELETE: 3,
    SHARE: 4,
    ACCEPT_AND_REPLY: 5,
    EDIT_REPLY: 6
}, Ai = [ {
    type: bi.REJECT,
    value: "不采纳"
}, {
    type: bi.ACCEPT,
    value: "采纳",
    useGreenTheme: !0
}, {
    type: bi.ACCEPT_AND_REPLY,
    value: "采纳并回复",
    useGreenTheme: !0
}, {
    type: bi.EDIT_REPLY,
    value: "编辑回复"
}, {
    type: bi.DELETE,
    value: "删除"
} ], Pi = {
    finance: 1001,
    detail: 1002,
    card: 2001,
    modify: 2002,
    bill: 4001,
    invoice: 5001,
    logout: 9001
}, Ri = z.fu.cashierDomain + "/mobile-site/auth.html";

function Ni() {
    return (0, z.fy)({
        url: "/api/ktt_group/activity_config/support_open_type",
        convertToCamel: !0,
        noErrorToast: !0
    }).then(function(e) {
        var t = (e.result || {}).supportOpenTypeVolist;
        return {
            list: t,
            flatList: (t || []).reduce(function(e, t) {
                return t.type === rt.LIST ? e.concat((null == t ? void 0 : t.subList) || []) : e.concat(t);
            }, [])
        };
    });
}

exports.vy = Ri, exports.vx = Pi, exports.zk = {
    SHARE: "share",
    RECEIVE: "receive",
    REC_LIST: "rec_list"
}, exports.yx = {
    SHARE: 1,
    INVITE: 2
}, exports.yw = {
    LIMIT: "limit",
    AWARDS: "awards"
}, exports.t2 = Ai, exports.t3 = bi, exports.vb = {
    IMAGE: 0,
    VIDEO: 1
}, exports._m = {
    IS_CLOSED: 0,
    IS_OPEN: 1
}, exports._g = {
    IS_CLOSED: 0,
    IS_OPEN: 1
}, exports.vr = ki, exports.vs = Ci, exports.vv = Ii, exports._i = {
    NO_PRIZE: 0,
    HAS_PRIZE: 1
}, exports.zb = Ti, exports.zc = Ei, exports.t0 = Si, exports.t1 = yi, exports._h = xi, 
exports.yp = {
    ABLE: 0,
    UNABLE: 1,
    ALREADY: 2
}, exports.s2 = _i, exports.s1 = vi, exports.vc = {
    IMAGE: 0,
    AUDIO: 1
}, exports._s = mi, exports.ta = gi, exports.s9 = {
    ADOPT: 1,
    REFUSE: 2
}, exports.s_ = fi, exports.z5 = {
    CAPTAIN: 0,
    SELF: 1,
    COMMON: 2
}, exports._n = {
    SINGLE: "0",
    MULTIPLE: "1",
    ALL: "2"
}, exports.x2 = 30, exports.z2 = hi, exports.x3 = di, exports.x4 = li, exports.z3 = pi, 
exports.v7 = ui, exports.tj = ci, exports.ahx = si, exports.w3 = {
    INVITE: "invite",
    INDEX: "index",
    INVITE_MEMBER: "invite_member",
    INVITE_HELP_SELL: "invite_help_sell"
}, exports.u8 = {
    activity: 1,
    goods: 2,
    live: 3,
    playback: 5
};

var wi = (0, z.jf)("mobile_live/2020-06-03/fa7e11a6-caef-4573-9291-4ac48ad9850e.png"), Di = function() {
    var e = U(M.default.mark(function e() {
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, z.fy)({
                    method: "GET",
                    url: "/sprite/mms/kuaituantuan/info",
                    type: "b",
                    noErrorToast: !0
                });

              case 2:
                return e.t0 = e.sent, e.abrupt("return", {
                    info: e.t0
                });

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), Oi = function() {
    var e = U(M.default.mark(function e() {
        var t, r = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = r.length > 0 && void 0 !== r[0] ? r[0] : {}, e.abrupt("return", (0, z.fy)({
                    url: "/sprite/mms/kuaituantuan/startV2",
                    type: "b"
                }, Y(Y({}, t), {}, {
                    image: t.image || (0, z.ll)().avatar || wi
                })));

              case 2:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), Li = {
    url: "/api/ktt_gameplay/owner/course/get/user/course",
    noErrorToast: !0,
    convertToCamel: !0,
    convertRequestToSnake: !0
}, Mi = {
    url: "/api/origenes/analyze_address",
    noErrorToast: !0,
    convertToCamel: !0
}, Ui = K.utils.emptyFunction, qi = K.wxappUtils.compareSDKVersion, Gi = K.wxappUtils.getPageId;

function Bi(e, t, r) {
    return 2 === e.length ? e(r || z.fv.getState(), t) : e(r || z.fv.getState());
}

exports.akm = {
    url: "/api/origenes/address/delete/{address_id}"
}, exports.akn = {
    url: "/api/origenes/address_info/{address_id}"
}, exports.akl = {
    url: "/api/origenes/address"
}, exports.aaw = Mi, exports.ag9 = {
    url: "/api/origenes/address/{address_id}",
    method: "GET",
    noErrorToast: !0
}, exports.af7 = {
    url: "/api/origenes/addresses/default",
    noErrorToast: !0
}, exports.aar = {
    url: "/api/origenes/addresses"
}, exports.afx = {
    url: "/api/ktt_gameplay/owner/course/create/course/ticket/order",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.amc = {
    url: "/api/ktt_gameplay/owner/course/redeem/course/mission/reward",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.aip = Li, exports.ama = {
    url: "/api/ktt_group/live_show/query_user_live_show",
    convertToCamel: !0
}, exports.agb = function(e) {
    return (0, z.fy)({
        method: "GET",
        url: "/sprite/mms/show/end",
        type: "b",
        noErrorToast: !0
    }, e);
}, exports.am1 = Oi, exports.ak0 = Di;

var $i = qi("2.6.1");

function Fi(e, t, r, a) {
    var n = "timer_" + (0, J.nanoid)(), o = (null == t ? void 0 : t.properties) || {};
    if (2 === e.length) {
        var i = function(t, r) {
            var o = this;
            t !== r && (this.wxPageId || (this.wxPageId = "function" == typeof this.getPageId ? this.getPageId() : this.__wxWebviewId__), 
            this.timerKeys || (this.timerKeys = new Set()), this.timerKeys.has(n) || this.timerKeys.add(n), 
            this[n] && clearTimeout(this[n]), this[n] = setTimeout(function() {
                var t = e((null == a ? void 0 : a.page) ? z.fv.getState()[o.wxPageId] : z.fv.getState(), o.properties);
                o.setDiffData(t);
            }, 0));
        }, s = (null == t ? void 0 : t.observers) || {}, c = "";
        if (Object.keys(o).forEach(function(e, t) {
            if ($i) c = 0 === t ? e : c + "," + e; else {
                var r = o[e];
                if (null == r ? void 0 : r.type) {
                    var a = o[e];
                    o[e] = Y(Y({}, a), {}, {
                        observer: function() {
                            for (var e, t = arguments.length, r = new Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                            "function" == typeof (null == a ? void 0 : a.observer) && (null == a || (e = a.observer).call.apply(e, [ this ].concat(r))), 
                            null == i || i.call.apply(i, [ this ].concat(r));
                        }
                    });
                } else {
                    var n = o[e];
                    o[e] = {
                        type: n,
                        observer: i
                    };
                }
            }
        }), $i) {
            var u = s[c];
            s[c] = function() {
                for (var t = this, r = arguments.length, o = new Array(r), i = 0; i < r; i++) o[i] = arguments[i];
                "function" == typeof u && u.call.apply(u, [ this ].concat(o)), this.timerKeys || (this.timerKeys = new Set()), 
                this.timerKeys.has(n) || this.timerKeys.add(n), this[n] && clearTimeout(this[n]), 
                this[n] = setTimeout(function() {
                    var r = z.fv.getState();
                    t.wxPageId || (t.wxPageId = "function" == typeof t.getPageId ? t.getPageId() : t.__wxWebviewId__);
                    var n = e((null == a ? void 0 : a.page) ? r[t.wxPageId] : r, t.properties);
                    t.setDiffData(n);
                }, 0);
            }, t.observers = s;
        }
        return e(null == a ? void 0 : a.state, r);
    }
    return e((null == a ? void 0 : a.state) || z.fv.getState());
}

var Hi = function(e) {
    return {};
}, ji = function(e, t, r) {
    var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Hi, n = function() {
        if (null !== (null == e ? void 0 : e.pendingSetData)) {
            var t = null == e ? void 0 : e.pendingSetData;
            e.pendingSetData = null, e.setData(t);
        }
    }, o = "function" == typeof r, i = e.wxPageId, s = o ? function(t) {
        return Y(Y({}, Bi(r, null == e ? void 0 : e.properties, t)), Bi(a, null == e ? void 0 : e.properties, t[i]));
    } : function(t) {
        return Y(Y({}, Object.keys(r || {}).reduce(function(a, n) {
            return a[n] = r[n](t, null == e ? void 0 : e.properties), a;
        }, {})), Bi(a, null == e ? void 0 : e.properties, t[i]));
    }, c = function() {
        var r = z.fv.getState(), a = s(r);
        (0, z.mn)(a, e.pendingSetData) || (e.pendingSetData || (e.pendingSetData = {}), 
        (0, z.nn)(e.pendingSetData, a, t, {
            deep: !0,
            updateOrigin: !0
        }) && e.pendingSetData && wx.nextTick(n));
    }, u = {
        updateData: n,
        unsubscribe: Ui,
        subscribe: Ui,
        subscribed: !1
    }, p = function() {
        c(), u.unsubscribe();
        var e = z.fv.subscribe(c);
        u.unsubscribe = function() {
            e(), u.subscribed = !1;
        }, u.subscribed = !0;
    };
    return u.subscribe = p, p(), u;
}, Vi = function(e) {
    var t = e || {}, r = t.mapState, a = t.mapDispatch, n = t.mapPageState, o = (0, 
    z.gg)({
        definitionFilter: function(e) {
            var t, i = e;
            if (i.methods || (i.methods = {}), a) {
                var s = {};
                if ((0, z.mm)(a)) {
                    s = Object.create(null);
                    var c = function(t) {
                        if (a[t].isPageAction) {
                            if (e.methods && t in e.methods) throw new Error("映射方法存在覆盖 " + t);
                            s[t] = function() {
                                var e = this.wxPageId, r = a[t](e);
                                return (0, z.hk)(r.apply(void 0, arguments));
                            };
                        } else {
                            if (e.methods && t in e.methods) throw new Error("映射方法存在覆盖 " + t);
                            s[t] = function(e) {
                                var r = this.wxPageId, n = a[t];
                                return "function" == typeof (null == n ? void 0 : n.pending) ? (0, z.hk)(n(Y(Y({}, e), {}, {
                                    pageId: r
                                }))) : (0, z.hk)(n(e));
                            };
                        }
                    };
                    for (var u in a) c(u);
                }
                e.methods = Y(Y({}, e.methods), s);
            }
            i.methods.dispatch = z.hk;
            var p = e.data || {}, l = {}, d = e.properties || {}, h = Object.keys(d).reduce(function(e, t) {
                var r;
                return d[t] && "value" in d[t] && (e[t] = null === (r = d[t]) || void 0 === r ? void 0 : r.value), 
                e;
            }, {});
            if (r || n) {
                if (r) {
                    var f = z.fv.getState();
                    l = "function" == typeof r ? Fi(r, e, h) : Object.keys(r).reduce(function(e, t) {
                        return e[t] = r[t](f), e;
                    }, {});
                }
                var g = Y(Y({}, l), n ? Fi(n, e, h, {
                    page: !0,
                    state: e.initialState || {}
                }) : {});
                if (Object.keys(g).length) {
                    e.methods || (e.methods = {});
                    var m = (null === (t = e.lifetimes) || void 0 === t ? void 0 : t.created) || e.created;
                    e.lifetimes || (e.lifetimes = {}), e.lifetimes.created = function() {
                        "function" == typeof m && m.call(this), this.shouldConnectMap[o] = !0;
                    }, e.methods.shouldConnect = function(e) {
                        return this.shouldConnectMap[e];
                    };
                }
                e.data = Y(Y({}, p), g);
            }
        },
        initProperties: {
            prevState: {},
            wxPageId: "",
            shouldConnectMap: {},
            _reduxConnectionMap: {}
        },
        pageLifetimes: {
            show: function() {
                var e, t = this._reduxConnectionMap[o];
                t && "subscribed" !== (null == t ? void 0 : t.status) && (null === (e = null == t ? void 0 : t.connections) || void 0 === e || e.forEach(function(e) {
                    e && !e.subscribed && e.subscribe();
                }), t.status = "subscribed");
            },
            hide: function() {
                var e, t = this._reduxConnectionMap[o];
                t && "unsubscribed" !== (null == t ? void 0 : t.status) && (null === (e = null == t ? void 0 : t.connections) || void 0 === e || e.forEach(function(e) {
                    e && e.subscribed && e.unsubscribe();
                }), t.status = "unsubscribed");
            }
        },
        lifetimes: {
            created: function() {
                this.wxPageId = Gi.call(this);
            },
            attached: function() {
                var e, t, a;
                if (this._reduxConnectionMap || (this._reduxConnectionMap = {}), void 0 === this.pendingSetData && (this.pendingSetData = null), 
                this.prevState[o] || (this.prevState[o] = {}), this.shouldConnect(o)) {
                    var i = ji(this, this.prevState[o], r, n);
                    if ((null === (e = this.is) || void 0 === e ? void 0 : e.indexOf("publicNumberGuide")) > -1 && console.log("===this.data", this.data, "is", this.is), 
                    this.updateData === Ui && (this.updateData = i.updateData), o in this._reduxConnectionMap) throw null === (t = this._reduxConnectionMap[o]) || void 0 === t || t.connections.push(i), 
                    new Error("同一个组件/页面寄生环境存在重复的订阅 ".concat(this.is, " ").concat(null === (a = this.$currentPage) || void 0 === a ? void 0 : a.route));
                    this._reduxConnectionMap[o] = {
                        connections: [ i ],
                        status: "inited"
                    }, i.updateData();
                }
            },
            detached: function() {
                var e = this;
                this._reduxConnectionMap && (Object.keys(this._reduxConnectionMap).forEach(function(t) {
                    var r, a = e._reduxConnectionMap[t];
                    null === (r = null == a ? void 0 : a.connections) || void 0 === r || r.forEach(function(e) {
                        e && e.subscribed && e.unsubscribe();
                    });
                }), this.timerKeys && (this.timerKeys.forEach(function(t) {
                    e[t] = null;
                }), this.timerKeys = null), this._reduxConnectionMap = {});
            }
        },
        methods: {
            updateData: Ui
        }
    });
    return o;
};

exports.afu = Vi, exports.afw = ji;

var Yi, zi = {
    createChainEle: 1393728,
    feedsItemEle: 5988494,
    feedsShareEle: 2532856,
    feedsOwnerEle: 2532852,
    feedsSubscribeEle: 5011696,
    followOrderEle: 2531875,
    personCenterEle: 2531869,
    doubleWelfareEle: 2577575,
    assistWelfareEle: 2577576,
    followBtnEle: 3411612,
    subscribeGuideBtn: 2641752,
    actionShareEle: 2641435,
    actionSharePosterEle: 2641436,
    inviteToMakeMoneySharePoster: 2949116,
    inviteToMakeMoneyShareCard: 2949115,
    createChainBubble: 3121606,
    redPoint: 3121607,
    createLiveBubble: 3323264,
    createBlock: 5474805,
    createDialogCopy: 5474806,
    createDialogCommon: 5474807,
    createDialogLive: 5474809,
    createDialogSupply: 5474808,
    createDialogSign: 5474810,
    createDialogLottery: 5474811,
    createDialogCommunityPublic: 6674387,
    createDialogLocalLife: 7470540,
    activityBanner: 3584175,
    groupBuyOrder: 4283175,
    editHelpSell: 4961655,
    directHelpSell: 4961654,
    publicPraise: 5489094,
    newComerBenefitNotActive: 7067106,
    newComerBenefitActivated: 7067108,
    tabTrackMap: {
        1: 6420145,
        2: 6420146,
        3: 7349008,
        4: 7349009,
        101: 7348103,
        1000004: 7573991
    },
    tabBarBlock: 6420144
};

exports.ae5 = {
    modifyActivityEle: 4394795,
    createActivityEle: 4394794,
    duplicateActivityEle: 4394793,
    lwWidgetEle: 4394792,
    lwSettingEle: 4394791
}, exports.ae4 = zi, exports.ae3 = {
    chainCopyBtnEle: 2533368,
    chainEditBtnEle: 1341871,
    chainEndBtnEle: 1341870,
    subscribeGuide: 2641751,
    callServiceBtnEle: 4996730,
    createPosterEle: 1481235,
    shareBtnEle: 1481234,
    topShareStyle: 5913530,
    lwWidgetBEle: 4092975,
    postOrderBtnEle: 4863538,
    chainStatisticBtnEle: 2533615,
    chainManageBtnEle: 2533614,
    chainOrderBtnEle: 2533613,
    chainShareBtnEle: 2533612,
    actionShareBtnEle: 2624390,
    actionPosterBtnEle: 2624392,
    helpSellInviteEle: 7342723,
    helpSellInvitePopEle: 4033646,
    createSuccssDialogEle: 2533370,
    modifySuccssDialogEle: 4027570,
    createSuccssDialogShareEle: 2533511,
    modifySuccssDialogShareEle: 4027708,
    chainShareGoodPosterBtnEle: 3137949,
    chainShareGoodAppBtnEle: 3137948,
    createRedPacketDialog: 4481222,
    createRedPacketRecieve: 4481223,
    createRedPacketClose: 4481224,
    videoEle: 3250528,
    startLiveIconEle: 3444437,
    confirmStartLiveBtnEle: 3444442,
    cancleStartLiveBtnEle: 3444443,
    groupBuyShare: 4282731,
    VIP_ENTRY: 4422088,
    POINT_MALL_ENTRY: 4422087,
    GROUP_VIP_ENTRY: 4422086,
    GROUP_POINT_MALL_ENTRY: 4422085,
    SKU_SELECTOR_BLOCK: 4350318,
    SKU_SELECTOR_COUNTER: 4350365,
    SKU_SELECTOR_MUTI: 4350364,
    SKU_SELECTOR_SUBMIT: 4350363,
    showSubsidyStrategyDialog: 4415374,
    useRedpacketToStartActivity: 4415375,
    closeSubscribeDialog: 4415376,
    mallEntranceAddGoods: 4544820,
    mallEntranceOptions: 4544819,
    mallEntranceComeIn: 4544818,
    CANCEL_BTN_STAY_DIALOG: 4679504,
    CONFIRM_BTN_STAY_DIALOG: 4679503,
    COUNT_CHANGE_IN_SHOPPING_CART: 4679493,
    GOODS_DETAIL_IN_SHOPPING_CART: 4679492,
    VIEW_GOODS_LIST_BY_TOP_SELECT: 4678932,
    VIEW_GOODS_BY_TOP_SELECT: 4678931,
    VIEW_RECOMMEND_ACTIVITY: 4698597,
    QUICK_CHECKOUT_PANEL: 4974405,
    CHECKOUT_SUBMIT_BTN: 4974406,
    REMIND_NUM: 5048660,
    GOODS_POSITIONER: 5545347,
    transMomentsLink: 5601460,
    transMomentsTips: 5601483,
    BUY_FOR_RELATIVE_ADDRESS: 5588551,
    pendingPayBtn: 5705996,
    POSTER_EDIT_XC_MATERIAL: 6081826,
    POSTER_GENERATE_XC_MATERIAL: 6081827,
    orderSuccessDialogEle: 1339921,
    orderSuccessDialogShareEle: 1339927,
    bottomShareTipsShareBtn: 7187456,
    bottomShareTipsclose: 7187465,
    shareMomentsGuide: 7430461,
    wxGroupStatistic: 7812949,
    banActivityModal: 7900212,
    chainDetailGroupImpr: 7977561
}, exports.ae2 = {
    pageImprEle: 3543357,
    callServiceBtnEle: 2544659,
    createPosterEle: 2544657,
    shareBtnEle: 2544658,
    followBtnEle: 3411539,
    postOrderBtnEle: 4863540,
    lwImprEle: 4092977,
    lwOrderImprEle: 4608798,
    lwPrizeBtnEle: 4092979,
    lwFeedbackImprEle: 4092978,
    lwWidgetEle: 4092976,
    lwNoChanceEle: 4123690,
    lwNoPrizeEle: 4123688,
    lwCouponPrizeEle: 4123627,
    lwCustomPrizeEle: 4123608,
    lwPhysicalPrizeEle: 4633531,
    lwPhysicalPrizeSuccessEle: 4633682,
    riskAlertEle: 6860459,
    riskArticleEntrance: 6862632,
    buyBtnEle: 2544664,
    shoppingCartEle: 2544663,
    videoEle: 3250526,
    thinking: 7323605,
    subscribeNow: 7323604,
    classReminder: 7323602,
    reportBtnEle: 3316431,
    firstRedPacketEle: 3771189,
    recommendHelpSellEle: 3959191,
    recommendHelpSellCardEle: 4579324,
    recommendHelpSellPosterEle: 4579325,
    recommendHelpSellDialogClickEle: 4579310,
    recommendHelpSellDialogCloseEle: 4579322,
    oneCreateHelpSell: 3965796,
    helpSellWithCreate: 3965795,
    applyHelpSell: 4383338,
    inviteFriend: 4282564,
    immediateJoin: 4282729,
    participateGroup: 4282730,
    dialogJoin: 4282734,
    dialogImmediate: 4282733,
    dialogIndividual: 4282732,
    mallEntranceEle: 4369917,
    VIP_ENTRY: 4415456,
    POINT_MALL_ENTRY: 4415457,
    GROUP_VIP_ENTRY: 4415458,
    GROUP_POINT_MALL_ENTRY: 4415459,
    GOODS_ITEM_BLOCK: 4350306,
    GOODS_ITEM_COUNTER: 4350308,
    SKU_SELECTOR_BLOCK: 4350310,
    SKU_SELECTOR_COUNTER: 4350311,
    SKU_SELECTOR_MUTI: 4350312,
    SKU_SELECTOR_SUBMIT: 4350313,
    OFFICE_CERTIFICATION_GOODS: 4653223,
    goodsStepPriceShow: 4671669,
    showAllBtnClick: 4671668,
    shareStepPriceClick: 4684458,
    CANCEL_BTN_STAY_DIALOG: 4679442,
    CONFIRM_BTN_STAY_DIALOG: 4679441,
    COUNT_CHANGE_IN_SHOPPING_CART: 4679439,
    GOODS_DETAIL_IN_SHOPPING_CART: 4679438,
    VIEW_GOODS_LIST_BY_TOP_SELECT: 4678733,
    VIEW_GOODS_BY_TOP_SELECT: 4678732,
    VIEW_RECOMMEND_ACTIVITY: 4698594,
    QUICK_CHECKOUT_PANEL: 4974325,
    CHECKOUT_SUBMIT_BTN: 4974365,
    REMIND_CAPTAIN_IN_SKU: 5049027,
    REMIND_CAPTAIN_IN_GOODS_ITEM: 5048658,
    SHARE_REBATE_ICON: 5498789,
    SHARE_REBATE_BACK: 5499490,
    SHARE_REBATE_FINISH: 5499491,
    imprVirtualGoodsBlock: 5494615,
    GOODS_POSITIONER: 5545345,
    deliverCommision: 5536672,
    lookLhb: 5536673,
    BUY_FOR_RELATIVE_ADDRESS: 5588351,
    liveWindow: 5715246,
    receiveNewDiscountBtn: 5960072,
    lotteryInviteFromBanner: 6158072,
    lotteryInviteFromDialog: 6158070,
    appHelpSellCard: 6906337,
    appActivity: 6906336,
    orderSuccessDialogEle: 1339921,
    orderSuccessDialogShareEle: 1339927,
    submitFeedback: 6570250,
    attendTraining: 7353168,
    receiveBenefits: 7353167,
    skuVideoEle: 7448064,
    skuVideoPlayTime: 7448065,
    activityVideoPlayTime: 7447779,
    activityStop: 7560873,
    superiseReceive: 7617083,
    unCountCouponTips: 7617084,
    couponTips: 7617090,
    couponDetailPanel: 7617085,
    banActivityToast: 7900215,
    activityGroupImpr: 7977589
}, exports.y8 = Yi, function(e) {
    e[e.PAY_BTN = 7067781] = "PAY_BTN", e[e.PAY_PANEL = 7067782] = "PAY_PANEL";
}(Yi || (exports.y8 = Yi = {}));

var Wi = {
    customerServiceBtnEle: 2534839,
    personalSettingBtnEle: 2534836,
    mentionAddressBtnEle: 2534724,
    withdrawBtnEle: 2534618,
    subscribeGuide: 2641707,
    officialLibrary: 3606018,
    vipManage: 4641705,
    pointManage: 4641703,
    joinedGroupEle: 2531872,
    personCenterPosterBtnEle: 3137838,
    personCentershareBtnEle: 3137837,
    personHelpSellActBtnEle: 4375164,
    personCenterHelpSellPromoBtnEle: 4890856,
    activityBanner: 3584168,
    learningCenter: 3817621,
    showSubsidyStrategyDialog: 4415618,
    useRedpacketToStartActivity: 4415619,
    closeSubscribeDialog: 4415620,
    redPacketTypeEle: 4607430,
    inviteToMakeMoneyBenEle: 4552266,
    shareOrderEntrance: 4882491,
    growthBenefitEntry: 4482164,
    dataCenterEntrance: 4590216,
    dataCenterEntranceImpr: 4590213,
    mallEntryImpr: 4676649,
    mallEntryClick: 4676650,
    headerInfoImpr: 4676642,
    syncUserInfoClick: 4676643,
    showProxyPanelClick: 4676644,
    jumpToCaptainHomeClick: 4676645,
    jumpToWithdrawClick: 4676646,
    myGroupMemberClick: 4676647,
    goToChatClick: 4676648,
    newGrowTrain: 5083410,
    captainRank: 5085e3,
    captainRankRefreshBtn: 5085003,
    rankDataHint: 5264471,
    grouperManageEntrance: 5144511,
    helpSellEle: 5144510,
    identitySelectPanel: 7067608,
    identityGroupCommander: 7067640,
    identityGroupMember: 7067641,
    newcomerBenefitBar: 7067652
};

exports.ae6 = Wi;

function Ki(e) {
    var t = e.activityFeedVo || {}, r = t.activityTitle, a = t.goodsPicList, n = t.goodsMinCommissionPrice, o = t.goodsMaxCommissionPrice, i = void 0 === o ? 0 : o, s = t.supplyTypeList, c = t.activityTagVo || {}, u = c.explosiveGoodsTagVo, p = c.hotSaleTagVo, l = W.default.price(n, 100), d = W.default.price(i, 100), h = l;
    n !== i ? h = "".concat(l, "~").concat(d) : i <= 0 && (h = "");
    var f = {
        activityTitle: r,
        isFreePricing: Array.isArray(s) && s.includes(ct.DISTRIBUTION_FREE_PRICING),
        goodsPicUrl: (0, z.qh)(a || [], "0.picUrl") || "",
        goodsCommissionPriceYuan: h,
        goodsMaxCommissionPriceYuan: d
    };
    return u && Object.assign(f, {
        explosiveGoodsValue: Math.floor(u.purchaseRate / 1e3)
    }), p && Object.assign(f, {
        hotSaleValue: p.saleCount
    }), f;
}

exports.aiq = function(e) {
    var t = e || {}, r = t.waterMarkText, a = t.waterMarkEnable, n = t.waterMarkType;
    if (a && r) {
        var o = Y(Y({
            text: ""
        }, z.n), {}, {
            batch: 0,
            gravity: "center",
            degree: 0
        });
        return o.text = r, n === z.c6.BATCH_RATATE && (o.dissolve = 16, o.batch = 1, o.degree = 325), 
        o;
    }
    return {};
};

var Ji = K.utils.emptyFunction, Xi = K.wxappUtils.getAuthCacheSetting, Qi = {
    url: "/api/ptolemeaus/location/report",
    noErrorToast: !0,
    convertToCamel: !0
}, Zi = {
    url: "/api/galen/huygens/location/decode/reduced",
    noErrorToast: !0,
    convertToCamel: !0
}, es = {
    url: "/api/ptolemeaus/poi_location/nearby/poi_location_list",
    noErrorToast: !0
}, ts = function() {
    var e = U(M.default.mark(function e(t) {
        var r, a, n, o;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.lat, a = t.lng, n = t.coord_type, e.next = 3, (0, z.fy)(Y(Y({}, Qi), {}, {
                    data: {
                        payload: {
                            scene: "ktt"
                        },
                        location: {
                            lat: "".concat(r),
                            lng: "".concat(a),
                            coordinate_type: n || 5
                        }
                    }
                }));

              case 3:
                return o = e.sent, e.abrupt("return", (0, z.qh)(o, "result.locationId"));

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}();

function rs(e) {
    return (0, z.fy)(Y(Y({}, Zi), {}, {
        data: {
            scene: "ktt",
            location_id: e
        }
    })).then(function(e) {
        return e.result;
    });
}

exports.ahs = ts;

var as = function() {
    var e = U(M.default.mark(function e(t) {
        var r, a, n, o;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.lat, a = t.lng, n = t.coord_type, e.next = 3, ts({
                    lat: r,
                    lng: a,
                    coord_type: n
                }).catch(Ji);

              case 3:
                return o = e.sent, e.abrupt("return", o ? rs(o).catch(Ji) : null);

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}();

function ns(e) {
    return os.apply(this, arguments);
}

function os() {
    return (os = U(M.default.mark(function e(t) {
        var r, a;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, z.fy)(Y(Y({}, es), {}, {
                    data: {
                        payload: {
                            scene: "ktt_address"
                        },
                        anchor_location_id: t,
                        user_location_id: t
                    }
                }));

              case 2:
                if (r = e.sent, !((a = (0, z.qh)(r, "result.data")) && a.length > 0)) {
                    e.next = 6;
                    break;
                }
                return e.abrupt("return", a.map(function(e) {
                    return Y(Y({}, e.poi_info), e.location);
                }));

              case 6:
                return e.abrupt("return", null);

              case 7:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.aax = function(e) {
    var t, r = (null === (t = e.match("(?<province>[^省]+自治区|.*?省|.*?行政区|.*?市)(?<city>[^市]+自治州|.*?地区|.*?行政单位|.+盟|市辖区|.*?市|.*?县)?(?<district>[^县]+县|.+区|.+市|.+旗|.+海域|.+岛)?(?<other>.*)")) || void 0 === t ? void 0 : t.groups) || {};
    return r.city || (r.city = r.province), r.other || (r.other = e), r;
}, exports.aig = as;

var is = function() {
    var e = U(M.default.mark(function e(t) {
        var r, a, n, o;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.lat, a = t.lng, n = t.coord_type, e.next = 3, ts({
                    lat: r,
                    lng: a,
                    coord_type: n
                });

              case 3:
                if (!(o = e.sent)) {
                    e.next = 6;
                    break;
                }
                return e.abrupt("return", ns(o));

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}(), ss = function() {
    var e = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = 25, a = 321, e.t1 = !1, e.next = 4, Xi("scope.userLocation");

              case 4:
                if (e.t2 = e.sent, e.t0 = e.t1 === e.t2, e.t0) {
                    e.next = 8;
                    break;
                }
                e.t0 = null == t ? void 0 : t.notShowAuth;

              case 8:
                if (!e.t0) {
                    e.next = 27;
                    break;
                }
                return e.next = 11, (0, z.o7)().catch(Ji);

              case 11:
                if (e.t3 = e.sent, e.t3) {
                    e.next = 14;
                    break;
                }
                e.t3 = {};

              case 14:
                u = e.t3, p = u.result, d = (l = void 0 === p ? {} : p).cityName, h = void 0 === d ? "" : d, 
                f = l.hasResult, g = l.provinceId, m = void 0 === g ? "" : g, v = l.cityId, _ = void 0 === v ? "" : v, 
                f && (o = h, i = _, s = m), e.next = 52;
                break;

              case 27:
                return e.next = 29, z.f3.getLocation({}).catch(Ji);

              case 29:
                if (n = e.sent, y = (x = n || {}).latitude, S = x.longitude, void 0 === y || void 0 === S) {
                    e.next = 52;
                    break;
                }
                return E = {
                    lat: y,
                    lng: S,
                    coord_type: 1
                }, e.next = 35, ts(E).catch(Ji);

              case 35:
                if (e.t4 = e.sent, e.t4) {
                    e.next = 38;
                    break;
                }
                e.t4 = "";

              case 38:
                return c = e.t4, e.next = 41, rs(c).catch(Ji);

              case 41:
                if (e.t5 = e.sent, e.t5) {
                    e.next = 44;
                    break;
                }
                e.t5 = {};

              case 44:
                T = e.t5, I = T.city, C = void 0 === I ? "" : I, k = T.cityId, b = void 0 === k ? a : k, 
                A = T.provinceId, o = C, i = b, s = void 0 === A ? r : A;

              case 52:
                return e.abrupt("return", {
                    cityId: i || a,
                    cityName: o,
                    provinceId: s
                });

              case 53:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}(), cs = {
    regionsDatas: null,
    getRegionsData: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, r = z.f3.getStorageSync(z.ct.regionsStorage) || {}, a = r.regionsUpdateTime, 
                    n = {
                        method: "GET",
                        url: "/regions_json/".concat(null == a ? 0 : a),
                        noErrorToast: !0
                    }, t.next = 6, (0, z.fy)(n).catch(function(e) {
                        throw (0, z.hp)({
                            e: e,
                            msg: "getRegionsData fail"
                        }), e;
                    });

                  case 6:
                    return o = t.sent, t.abrupt("return", (e.regionsDatas = r.regions, o && o.regions && o.regions.length && z.f3.setStorageSync(z.ct.regionsStorage, {
                        regionsUpdateTime: o.regions_update_time,
                        regions: o.regions[0] && o.regions[0].children || []
                    }), o));

                  case 10:
                    throw t.prev = 10, t.t0 = t.catch(0), (0, z.hp)({
                        e: t.t0,
                        msg: "getRegionsData fail"
                    }), t.t0;

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 10 ] ]);
        }))();
    },
    getRegions: function() {
        return this.regionsDatas || (this.regionsDatas = (z.f3.getStorageSync(z.ct.regionsStorage) || {}).regions), 
        this.regionsDatas;
    },
    analyzeAddress: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        return (0, z.fy)(Y(Y({}, Mi), {}, {
            data: {
                request_id: "ktt_address_".concat(Date.now()),
                address_info: e
            }
        }));
    }
};

exports.ae9 = cs, exports.aht = ss, exports.ahz = is;

var us = function(e) {
    return [ z.t.ADDRESS, z.t.PHONE, z.t.USER_NAME ].includes(e);
};

function ps(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
    e = parseInt(e, 10);
    var r = Date.now();
    e = e || r, r.toString().length - e.toString().length == 3 && (e = parseInt("" + 1e3 * e, 10));
    var a = new Date(e);
    return (t = parseInt(t, 10)) > 0 ? new Date(a.getFullYear(), a.getMonth(), t) : new Date(a.getFullYear(), a.getMonth() + 1, t + 1);
}

exports.ajh = function(e) {
    return V(new Set(Object.values(z.t || {}))).includes(e);
}, exports.ajg = us;

var ls = 1;

function ds() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.successBack, r = e.failBack, a = e.scope;
    1 === ls && (0, z.rg)({
        title: "跳转中..."
    }), (0, z.fy)(Y(Y({}, z.pe), {}, {
        data: {
            scope: a || Pi.finance,
            platform: 1
        }
    })).then(function(e) {
        var r = (0, z.qh)(e || {}, "result") || "";
        (0, z.l3)(), t && t(), (0, z.n3)({
            url: z.ob.web,
            params: {
                src: r
            }
        }), (0, z.l7)({
            msg: "getTicket success",
            data: e
        }), ls = 1;
    }).catch(function(t) {
        ls > 2 ? (ls = 1, (0, z.l3)(), (0, z.ri)({
            title: "请稍后重试~"
        }), r && r()) : (ls++, ds(e)), (0, z.hp)({
            name: "jumpToFinance",
            msg: JSON.stringify(t)
        });
    });
}

var hs = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Date.now(), t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "YYYY年MM月dd日";
    return W.default.formatTime(e / 1e3, t);
}, fs = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.goodsAmount || 0;
    return Y(Y({}, e), {}, {
        orderAmountStr: W.default.price(e.orderAmount, 100),
        goodsAmountYuan: W.default.price(t, 100),
        shippingAmountYuan: W.default.price(e.shippingAmount, 100),
        merchantDiscountYuan: W.default.price(e.merchantDiscount, 100),
        platformDiscountYuan: W.default.price(e.platformDiscount, 100),
        realPayAmount: t - (e.merchantDiscount || 0),
        realPayAmountYuan: W.default.price(t - (e.merchantDiscount || 0), 100),
        toVerificationAmountStr: W.default.price(e.toVerificationAmount, 100),
        goodsPriceExcludeMerchantDiscountYuan: W.default.price(e.goodsPriceExcludeMerchantDiscount, 100)
    });
}, gs = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return e.shippingNo;
}, ms = function(e) {
    return e === Dn.CANCEL ? "取消采购" : e === Dn.PURCHASED ? "已采购" : e === Dn.NOT_PURCHASED ? "待采购" : "";
}, vs = function(e, t) {
    return ms(e) ? ms(e) : t === wn.NOT_PURCHASED ? "待进货" : t === wn.PURCHASED ? "已进货" : "";
}, _s = {
    isRealReceiveInfo: !1,
    privateInfo: {}
}, xs = {
    $getPageStackLog: function() {
        return (getCurrentPages() || []).map(function(e) {
            var t = e.route, r = e.$query;
            return (0, z.e4)(t, r);
        }).join(",   ");
    },
    $infoByBatch: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = this.$currentPage;
        if (r) {
            var a = r.$logInfoList;
            a && (a.push(Y(Y({}, (0, z.g1)(e)), {}, {
                time: Date.now()
            })), (a.length >= 20 || t) && this.$_doBatchInfo());
        }
    },
    $_doBatchInfo: function() {
        var e = this.$currentPage;
        if (e) {
            var t = e.$logInfoList;
            t && t.length && ((0, z.l7)(Y({
                msg: "$info",
                data: {
                    infos: t
                }
            }, this.$getBaseLogParams())), e.$logInfoList = []);
        }
    },
    $info: function(e) {
        (0, z.l7)(Y(Y({}, e), this.$getBaseLogParams()));
    },
    $error: function(e) {
        (0, z.hp)(Y(Y({}, e), this.$getBaseLogParams()));
    }
}, ys = (0, z.gg)({
    methods: xs
}), Ss = K.utils.getUnique, Es = [ z.gf.groupUserNo ], Ts = {
    $showKttLoading: function(e) {
        var t = e || {}, r = t.title, a = void 0 === r ? "加载中" : r, n = t.delay, o = void 0 === n ? 1e3 : n, i = t.id, s = void 0 === i ? "_kttLoading" : i, c = this.selectComponent("#".concat(s));
        c && c.showLoading({
            title: a,
            delay: o
        });
    },
    $hideKttLoading: function(e) {
        var t = (e || {}).id, r = void 0 === t ? "_kttLoading" : t, a = this.selectComponent("#".concat(r));
        a && a.hideLoading();
    },
    $showModal: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = e.title, n = void 0 === a ? "" : a, o = e.content, i = void 0 === o ? "" : o, 
                    s = e.showCancel, c = void 0 === s || s, u = e.cancelText, p = void 0 === u ? "取消" : u, 
                    l = e.confirmText, d = void 0 === l ? "确定" : l, h = e.success, f = e.fail, g = e.complete, 
                    m = e.id, v = void 0 === m ? "_wxModal" : m, _ = e.isInPage, !(void 0 !== _ && _) || !t.$currentPage) {
                        r.next = 7;
                        break;
                    }
                    return t.$popupVisibleChange(!0), r.next = 5, t.$currentPage.$showModal({
                        title: n,
                        content: i,
                        showCancel: c,
                        cancelText: p,
                        confirmText: d,
                        success: h,
                        fail: f,
                        complete: g,
                        id: v
                    });

                  case 5:
                    return x = r.sent, r.abrupt("return", (t.$popupVisibleChange(!1), x));

                  case 7:
                    if (y = t.selectComponent("#".concat(v))) {
                        r.next = 10;
                        break;
                    }
                    return r.abrupt("return", (f && f(), g && g(), Promise.reject()));

                  case 10:
                    return t.$popupVisibleChange(!0), r.next = 13, y.showModal({
                        title: n,
                        content: i,
                        cancelText: c ? p : "",
                        confirmText: d,
                        success: h,
                        fail: f,
                        complete: g
                    });

                  case 13:
                    return S = r.sent, r.abrupt("return", (t.$popupVisibleChange(!1), S));

                  case 15:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    $baseRequest: function() {
        for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
        return z.fy.apply(this, t);
    },
    $getCurrentProxyUserInfo: function() {
        var e = this, t = this.$getCurrentProxyUserNo();
        return t ? t !== (0, z.kp)() ? (this.$currentProxyUserInfo && this.$currentProxyUserInfo.userNo === t || (this.$currentProxyUserInfo = (0, 
        z.k6)(t).then(function(r) {
            return e.$currentProxyUserInfo = Y({
                userNo: t
            }, r), e.$currentProxyUserInfo;
        }).catch(function() {
            return e.$currentProxyUserInfo = null, {};
        }), this.$currentProxyUserInfo.userNo = t), Promise.resolve(this.$currentProxyUserInfo)) : Promise.resolve((0, 
        z.j6)()) : Promise.resolve({});
    },
    $getCurrentProxyUserNo: function() {
        if ((0, z.qh)(this.$currentPage, "noNeedProxy")) return "";
        var e = (0, z.kp)(), t = (0, z.qh)(this.$currentPage, "$scene_user_no") || e;
        return (0, z.mr)(t) ? "" : t;
    },
    $getCurrentUserInfo: function() {
        return this.$getCurrentProxyUserNo() ? this.$getCurrentProxyUserInfo() : Promise.resolve((0, 
        z.lm)());
    },
    $getCurrentUserNo: function() {
        return this.$getCurrentProxyUserNo() || (0, z.lo)() || "";
    },
    $popupVisibleChange: function(e) {
        var t = this.$currentPage;
        if (t) {
            var r = t.$_popupVisibleMap;
            r && (0, z.qh)(r, "".concat(this.$id)) !== e && ((0, z.qj)(r, "".concat(this.$id), e), 
            t.setData({
                $popupVisible: Object.values(r).some(function(e) {
                    return e;
                })
            }));
        } else this.$popupVisible = e;
    },
    $setNextPageQuery: function(e) {
        var t = this.$currentPage;
        t && Object.assign(t.$nextPageQuery, e);
    },
    $setNextSharePageQuery: function(e) {
        var t = this.$currentPage;
        t && Object.assign(t.$nextSharePageQuery || {}, e);
    },
    $getNextSharePageQuery: function() {
        var e = this.$currentPage;
        if (e) {
            var t = e.$query, r = e.$nextPageQuery, a = e.$nextSharePageQuery, n = Y(Y(Y({}, (0, 
            z.j1)(t)), r), a), o = (0, z.j1)(n);
            return Object.keys(o).forEach(function(e) {
                -1 === Es.indexOf(e) && delete n[e];
            }), n;
        }
        return {};
    },
    $generalShareTicket: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], r = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], a = this.$currentPage || (0, 
        z.ge)(), n = e.data, o = void 0 === n ? {} : n, i = O(e, ee), s = o.params, c = void 0 === s ? {} : s;
        return this.$baseRequest(Y(Y(Y({}, z.i4), {}, {
            noErrorToast: !0
        }, i), {}, {
            data: Y(Y({
                shareType: z.cs.SESSION
            }, o), {}, {
                transparentParams: Y(Y({}, a && a.$getNextSharePageQuery() || {}), c)
            })
        })).then(function(e) {
            var a = (0, z.qh)(e, "result.imageUrl");
            return t && a && r ? (0, z.hl)(a).then(function(t) {
                return e.result.imageUrl = t.tempFilePath, e;
            }, function() {
                return e;
            }) : e;
        }).catch(function(t) {
            (0, z.hp)({
                name: "$generalShareTicket",
                e: t,
                msg: "$generalShareTicket下载分享图片失败！",
                query: e
            });
        });
    },
    $generalShareCard: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return this.$generalShareTicket({
            data: e
        }, t, !0);
    },
    $generalSharePoster: function() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.data, a = O(t, te), n = Ss(), o = (q(e = {}, z.gf.refShareUserNo, (0, 
        z.lo)() || ""), q(e, z.gf.refShareId, n), e);
        return this.$generalShareTicket(Y(Y({
            noErrorToast: !1
        }, a), {}, {
            data: Y(Y({}, r), {}, {
                params: Y(Y(Y({}, o), null == r ? void 0 : r.transparentParams), null == r ? void 0 : r.params),
                shareType: z.cs.TIMELINE
            })
        }), !1);
    },
    $forceUpdateGray: function() {
        this.$injectGray(!0);
    },
    $getGroupStore: function(e) {
        var t = e.collectionActivityNo, r = e.keyList, a = e.userNo;
        return z.gc.call(this, {
            key: t || a,
            isGroupGray: !0
        }).getStore({
            data: {
                key_list: r,
                activity_no: t,
                user_no: a
            }
        });
    },
    $groupStoreInject: function(e) {
        var t = this, r = e.data, a = e.collectionActivityNo, n = e.keyList, o = e.onChange;
        return z.gc.call(this, {
            key: a,
            isGroupGray: !0
        }).storeInject({
            data: r,
            pageId: this.$getPageId(),
            callback: function(e) {
                var r = Y(Y({}, t.data.$groupGray), e);
                t.setData({
                    $groupGray: r
                }), o && o();
            },
            requestData: {
                key_list: n,
                activity_no: a
            }
        });
    }
}, Is = (0, z.gg)({
    methods: Ts
}), Cs = (0, z.gg)({
    initProperties: {
        pendingData: null
    },
    methods: {
        appendListData: function(e) {
            for (var t = {}, r = Object.keys(e), a = 0; a < r.length; a++) if (Array.isArray(e[r[a]])) for (var n = e[r[a]], o = this.data[r[a]].length, i = 0; i < n.length; i++) t["".concat(r[a], "[").concat(o + i, "]")] = n[i]; else t[r[a]] = e[r[a]];
            this.setDiffData(t);
        },
        setDiffData: function(e, t) {
            (0, z.mn)(e, this.pendingData) || (this.pendingData || (this.pendingData = {}), 
            (0, z.nn)(this.pendingData, e, this.data, {
                comparer: t,
                updateOrigin: !0
            }) && this.addSetData());
        },
        commitSetData: function() {
            if (null !== this.pendingData) {
                var e = this.pendingData;
                this.pendingData = null, this.setData(e);
            }
        },
        addSetData: function() {
            var e = this;
            wx.nextTick(function() {
                e.commitSetData();
            });
        }
    }
}), ks = K.wxapp.pddComponent, bs = getApp();

function As() {
    var e = this && this.$currentPage || (0, z.ge)();
    if (!e) return !1;
    var t = e.$query[z.gf.refShareChannel] || "";
    return [ "message", "qy_message" ].indexOf(t) > -1 && ![ 1007, 1010, 1044, 1049, 1096 ].includes(getApp().$scene);
}

exports.amr = Cs, exports.aa2 = Is, exports.aci = Ts, exports.ajp = ys, exports.ack = xs, 
exports.agt = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.penaltySuccessTime ? hs(+e.penaltySuccessTime, "YYYY/MM/dd") : e.penaltySuccessTime, r = (e.orderInfo || {}).promiseShippingTime ? hs(+((e.orderInfo || {}).promiseShippingTime || 0), "YYYY/MM/dd hh:mm:ss") : (e.orderInfo || {}).promiseShippingTime, a = (e.orderInfo || {}).shippingTime ? hs(+((e.orderInfo || {}).shippingTime || 0), "YYYY/MM/dd hh:mm:ss") : "仍未发货", n = hs(+(e.penaltySuccessTime || 0), "YYYY/MM/dd hh:mm:ss");
    return Y(Y({}, e), {}, {
        penaltySuccessTimeStr: t,
        promiseShippingTimeStr: r,
        shippingTimeStr: a,
        deductionTimeStr: n
    });
}, exports.ag0 = function(e) {
    var t, r, a, n;
    return Y(Y({}, e), {}, {
        supplyAndPurchaseStatus: vs(e.supplierGoodsPurchaseStatus, null === (t = e.supplyChainInfo) || void 0 === t ? void 0 : t.replenishStatus),
        buyerMemo: (null === (r = null == e ? void 0 : e.remark) || void 0 === r ? void 0 : r.buyerMemo) || "",
        businessNote: (null === (a = null == e ? void 0 : e.remark) || void 0 === a ? void 0 : a.businessNote) || "",
        secretRemark: (null === (n = null == e ? void 0 : e.remark) || void 0 === n ? void 0 : n.secretRemark) || "",
        payTimeStr: e.payTime ? W.default.formatTime(+(null == e ? void 0 : e.payTime) / 1e3, "YYYY/M/d hh:mm:ss") : ""
    });
}, exports.ag1 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.payAmount || 0, r = e.refundAmount || 0, a = e.refundingAmount || 0, n = t + (e.platformDiscount || 0) - r - (e.refundDiscount || 0);
    return Y(Y({}, e), {}, {
        orderAmount: W.default.price(t + (e.platformDiscount || 0), 100),
        payAmountStr: W.default.price(e.payAmount, 100),
        refundAmountStr: W.default.price(r + (e.refundDiscount || 0), 100),
        refundDiscountStr: W.default.price(e.refundDiscount, 100),
        refundingDiscountStr: W.default.price(e.refundingDiscount, 100),
        platformTakeBackAmountStr: W.default.price(e.platformTakeBackAmount, 100),
        refundingAmountStr: W.default.price(a + (e.refundingDiscount || 0), 100),
        canRefundAmount: +n || 0,
        canRefundAmountStr: W.default.price(n, 100),
        helpSellerSuggestRefundAmount: W.default.price(e.helpSellerSuggestRefundAmount, 100) || 0,
        theoreticalRefundAmountStr: W.default.price(e.theoreticalRefundAmount, 100),
        receiveAddress: (e.receiverAddressProvince || "") + (e.receiverAddressCity || "") + (e.receiverAddressDistrict || "") + (e.receiverAddressDetail || ""),
        payTimeStr: e.payTime ? W.default.formatTime(+e.payTime / 1e3, "YYYY/M/d hh:mm") : "",
        subOrderList: (e.subOrderList || []).map(fs),
        shippingAmountYuan: W.default.price(e.shippingAmount, 100),
        merchantDiscountYuan: W.default.price(e.merchantDiscount, 100),
        merchantFullReductionDiscountYuan: W.default.price(e.merchantFullReductionDiscount, 100),
        merchantMultiDiscountYuan: W.default.price(e.merchantMultiDiscount, 100),
        merchantMemberDiscountYuan: W.default.price(e.merchantMemberDiscount, 100),
        merchantFirstOrderDiscountYuan: W.default.price(e.merchantFirstOrderDiscount, 100),
        merchantAssistOrderDiscountYuan: W.default.price(e.merchantAssistOrderDiscount, 100),
        merchantNoThresholdCouponYuan: W.default.price(e.merchantNoThresholdCoupon, 100),
        merchantGoodsCouponYuan: W.default.price(e.merchantGoodsCoupon, 100),
        merchantFullReductionCouponYuan: W.default.price(e.merchantFullReductionCoupon, 100),
        platformDiscountYuan: W.default.price(e.platformDiscount, 100),
        discountAmountStr: W.default.price(e.discountAmount, 100),
        goodsAmount: W.default.price(e.goodsAmount, 100),
        serviceAmountStr: W.default.price(e.serviceAmount, 100),
        orderLogistics: (e.orderLogistics || []).filter(gs),
        isReceiver: !!(e.receiverAddressCityId && e.receiverAddressDistrictId && e.receiverAddressProvinceId),
        isLogistics: e.expressType === z.aq.express,
        isLocalExpress: e.expressType === z.aq.local,
        vipTagImg: (0, z.lq)(e.vipLevel),
        supplyAndPurchaseStatus: vs(e.supplierGoodsPurchaseStatus, e.supplyPurchaseStatus)
    }, _s);
}, exports.agx = vs, exports.agu = ms;

var Ps = {
    removeTransWxOpenGid: function() {},
    onLoad: function() {
        var e = this;
        (this.$isColdLaunch || this.$isHotLaunch) && this.checkGroupId(), (0, z.qh)(this, "$currentPage.pageProperties.page_name") === At.page_name && (this.removeTransWxOpenGid = z.f9.listenOnce(z.f1.transWxOpenGid, function(t) {
            var r, a = t.wxOpenGid, n = getCurrentPages() || [];
            (!(null === (r = null == e ? void 0 : e.$referPage) || void 0 === r ? void 0 : r.$currentPage) || e.$query[z.gf.firstJumpFrom] && 2 === n.length) && (e.setData({
                wxOpenGid: a
            }), z.f9.cancel(z.f1.transWxOpenGid), e.$impr({
                page_el_sn: 6871693
            }), e.checkHaveWxGroupAuth(a));
        }));
    },
    onUnload: function() {
        this.removeTransWxOpenGid && this.removeTransWxOpenGid();
    },
    checkHaveWxGroupAuth: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (e) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return");

                  case 2:
                    return r.next = 4, t.$baseRequest({
                        url: "/api/ktt_gateway/wx_group/check_have_wx_group_auth",
                        noErrorToast: !0,
                        convertToCamel: !0,
                        convertRequestToSnake: !0,
                        data: {
                            wxOpenGid: e
                        }
                    });

                  case 4:
                    a = r.sent, t.setData({
                        hasWxGroupAuth: !!(null == a ? void 0 : a.result)
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    checkGroupId: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = getApp(), delete (a = r.$globalPageQuery)[z.gf.exOpenGId], z.f9.cancel(z.f1.transWxOpenGid), 
                    (0, z.g3)("2.17.3") && As.call(e)) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return t.next = 5, Ia();

                  case 5:
                    (n = t.sent) && e.$pvLogID && z.f3.getGroupEnterInfo().then(function(t) {
                        var r = t.encryptedData, o = t.iv;
                        e.$baseRequest({
                            url: "/api/ktt_extopen/wx/mini/program/biz/wx_open_gid_report",
                            noErrorToast: !0,
                            noRequestLog: !0,
                            convertToCamel: !0,
                            convertRequestToSnake: !0,
                            data: {
                                wx_encrypted_param: {
                                    encryptedData: r,
                                    iv: o,
                                    code: n
                                },
                                reportLogId: e.$pvLogID,
                                path: e.$originUrl
                            }
                        }).then(function(e) {
                            var t = e.result, r = void 0 === t ? {} : t;
                            z.f9.trigger(z.f1.transWxOpenGid, {
                                wxOpenGid: r.wxOpenGid
                            }), a[z.gf.exOpenGId] = r.wxOpenGid;
                        });
                    }).catch(z.hm);

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    }
}, Rs = O(Ps, [ "onLoad" ]), Ns = (0, z.gg)({
    methods: Rs,
    onSign: function() {
        var e = this;
        (this.$isColdLaunch || this.$isHotLaunch) && this.checkGroupId(), (0, z.qh)(this, "$currentPage.pageProperties.page_name") === At.page_name && (this.removeTransWxOpenGid = z.f9.listenOnce(z.f1.transWxOpenGid, function(t) {
            var r, a = t.wxOpenGid, n = getCurrentPages() || [];
            (!(null === (r = null == e ? void 0 : e.$referPage) || void 0 === r ? void 0 : r.$currentPage) || e.$query[z.gf.firstJumpFrom] && 2 === n.length) && (e.setData({
                wxOpenGid: a
            }), z.f9.cancel(z.f1.transWxOpenGid), e.$impr({
                page_el_sn: 6871693
            }), e.checkHaveWxGroupAuth(a));
        }));
    },
    detached: function() {
        this.removeTransWxOpenGid && this.removeTransWxOpenGid();
    }
}), ws = {
    _overWriteFormatTicketResult: function(e) {
        var t = e.extra, r = void 0 === t ? {} : t, a = e.transparent_params, n = void 0 === a ? {} : a, o = O(e, ae), i = Y(Y(Y({}, (0, 
        z.p7)(n)), (0, z.p7)(r)), (0, z.p7)(o));
        return Object.keys(i).forEach(function(e) {
            (0, z.ml)(i[e]) && delete i[e];
        }), i;
    }
}, Ds = (0, z.gg)({
    methods: ws
}), Os = {
    $setBizSn: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        this.$socketBizSn = e, z.f9.triggerOnce(z.f1.onSocketHeartbeat, {
            page: this.pageProperties.page_name,
            bizSn: this.$socketBizSn
        });
    }
}, Ls = (0, z.gg)({
    methods: Os
}), Ms = K.utils.emptyFunction, Us = getApp();

function qs() {
    return Gs.apply(this, arguments);
}

function Gs() {
    return (Gs = U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N, w, D = this, O = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = O.length > 0 && void 0 !== O[0] ? O[0] : {}, r = t.onLoad, a = t.withTicket, 
                n = void 0 !== a && a, o = t.withTicketToast, i = t.noNeedProxy, s = void 0 !== i && i, 
                c = t.globalProxySync, u = void 0 !== c && c, p = t.noNeedProxyUpdate, l = void 0 !== p && p, 
                d = this.pageProperties.page_name, Us && (Us.$needRefreshOnShow = !1), (s || l || [ z.ob.personal ].indexOf("/".concat(this.route)) > -1) && (delete this.$query[z.gf.sceneUserNo], 
                delete this.$query[z.gf.sceneActivityNo]), (0, z.m7)(this), this.$scene_user_no = (0, 
                z.jw)(this.$query[z.gf.sceneUserNo] || ""), this.$scene_activity_no = decodeURIComponent(this.$query[z.gf.sceneActivityNo] || ""), 
                this.$scene_activity_no && this.setData({
                    $isGroupAdmin: !0
                }), e.t0 = n, !e.t0) {
                    e.next = 12;
                    break;
                }
                return e.next = 12, this.$getQueryWidthTicket(this.$query, o).then(function(e) {
                    var t = e.query, r = e.sceneTicket;
                    D.$query = t, D.$sceneTicket = r;
                }).catch(Ms);

              case 12:
                (h = this.$getCurrentProxyUserNo()) && h !== (0, z.kp)() && this.$getCurrentProxyUserInfo(), 
                (this.$isColdLaunch || this.$isHotLaunch) && (g = (f = Us || {}).$scene, m = void 0 === g ? "" : g, 
                v = f.$referrerInfo, (_ = si(m) || "0") === z.b6["scene-push"] && v && v.appId && -1 === [ "wx5cbd018a2bc1c6e0", "wx67252b464b11ae13" ].indexOf(v.appId) && (_ = z.b6["scene-push-external"]), 
                _ && (this.$query[z.gf.recUniversalSrc] = _, z.b5[_] && (this.$query[z.gf.recChainSrc] = z.b5[_]), 
                this.$setNextPageQuery(q({}, z.gf.recUniversalSrc, _)))), d in z.b6 && (x = z.b6[d], 
                this.$setNextPageQuery((0, z.p7)(q({}, z.gf.recUniversalSrc, x)))), (this.$isColdLaunch || this.$isHotLaunch) && this.$query._x_wx_scheme_sn && (y = z.b6["scene-promo-link"], 
                this.$setNextPageQuery(q({}, z.gf.recUniversalSrc, y)), this.$query[z.gf.recUniversalSrc] = y, 
                z.b5[y] && (this.$query[z.gf.recChainSrc] = z.b5[y])), E = function() {
                    var e, t;
                    null === (e = D.onCurrentProxyChange) || void 0 === e || e.call(D), D.onSignIn.apply(D, arguments), 
                    D.onSignInComplete(), r && r.call(D, D.$query), null === (t = D.$pageEventsListener) || void 0 === t || t.trigger(z.f1.onPddPageLoad);
                }, this.$cancelOnGlobalProxyChange = z.f9.listen(z.f1.onGlobalProxyChange, function() {
                    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    if (D.$checkProxyChangeNeedUpdate()) {
                        if (u) return E.apply(void 0, t);
                        if (D.$prePageProxyUserNo !== D.$getCurrentProxyUserNo() || !D.$hasOnloadFinished) return D.$prePageProxyUserNo = D.$getCurrentProxyUserNo(), 
                        S && S(), void (S = D.$addPageShowCallback(function() {
                            E.apply(void 0, t);
                        }));
                    }
                    D.$abortProxyChangeUpdate = !1;
                }), T = this.$query || {}, I = T.share_user_no, C = T.ref_share_user_no, k = T.pid, 
                b = T.cps_sign, A = T.duoduo_type, P = T.ref_cps_sign, R = T.ref_duoduo_type, N = T.ref_pid, 
                (I || C) && Us && (Us.latestReferShareUserNo = I || decodeURIComponent(C) || ""), 
                k && Us && (Us.ref_duoduo = {
                    pid: k,
                    duoduo_type: A,
                    cps_sign: b
                }), N && Us && (Us.ref_duoduo = {
                    pid: N,
                    duoduo_type: R,
                    cps_sign: P
                }), this.$setBizSnManully || (w = "", this.$getBizSn && (w = this.$getBizSn()), 
                this.$setBizSn(w));

              case 20:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))).apply(this, arguments);
}

exports.amx = Ls, exports.acm = Os, exports.af8 = Ds, exports.acz = ws, exports.wj = Ns, 
exports.ac1 = Ps;

var Bs = {
    $switchGlobalUserNo: function(e) {
        var t = e || this.$scene_user_no || this.$query[z.gf.sceneUserNo];
        if (t) return delete this.$query[z.gf.sceneUserNo], this.$scene_user_no = "", (0, 
        z.ry)(t);
    },
    $switchUserNo: function() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", r = (0, 
        z.ln)();
        t = (0, z.jv)(t) || r;
        var a = (this.$getCurrentProxyUserNo() || r) !== t;
        this.$scene_user_no = t, a && (this.$forceUpdateGray(), null === (e = this.onCurrentProxyChange) || void 0 === e || e.call(this));
    },
    $isShareInfoMessageExist: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "default", t = this.data.$shareInfoMessageMap, r = void 0 === t ? {} : t;
        return !!(0, z.qh)(r, "".concat(e, ".path"));
    },
    $prepareShare: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N, w, D, O, U, G, B;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (n = e.length > 0 && void 0 !== e[0] ? e[0] : {}, o = e.length > 1 && void 0 !== e[1] ? e[1] : "default", 
                    i = n.cardMsgFromServer, s = void 0 === i ? {} : i, c = n.posterMsgFromServer, u = void 0 === c ? {} : c, 
                    p = n.poster, l = void 0 === p ? {} : p, d = n.card, h = void 0 === d ? {} : d, 
                    f = n.config, g = void 0 === f ? {
                        noTimeline: !1
                    } : f, m = t.data, v = m.$shareInfoMessageMap, _ = void 0 === v ? {} : v, x = m.$shareInfoPosterMap, 
                    y = void 0 === x ? {} : x, S = m.$shareConfig, E = {}, T = {}, (0, z.mg)(s) && (0, 
                    z.mg)(u)) {
                        r.next = 29;
                        break;
                    }
                    return r.prev = 5, I = [], (0, z.mg)(s) ? I.push(Promise.resolve({})) : (C = Ts.$generalShareCard(s).catch(function(e) {
                        (0, z.hp)({
                            e: e,
                            msg: "cardMsgFromServer fail"
                        });
                    }), I.push(C)), (0, z.mg)(u) ? I.push(Promise.resolve({})) : (u.transparentParams = u.params, 
                    k = Ts.$generalSharePoster({
                        data: Y({
                            dataOnly: 0
                        }, u)
                    }), I.push(k)), r.next = 11, Promise.all(I);

                  case 11:
                    b = r.sent, A = L(b, 2), P = A[0], R = void 0 === P ? {} : P, N = A[1], w = void 0 === N ? {} : N, 
                    E.imageUrl = (0, z.qh)(R, "result.imageUrl"), E.title = (0, z.qh)(R, "result.shareText"), 
                    E.wxActivityId = (0, z.qh)(R, "result.wxActivityId"), E.path = s.path, (D = (0, 
                    z.qh)(R, "result.shareImages")) && (E.shareImages = D, E.imageUrls = (0, z.qh)(R, "result.imageUrls")), 
                    E.params = (0, z.g1)(s.params || {}), T.imageUrl = (0, z.qh)(w, "result.imageUrl"), 
                    T.imageUrls = (0, z.qh)(w, "result.imageUrls"), T.momentsForWxVolist = (0, z.qh)(w, "result.momentsForWxVolist"), 
                    T.params = (0, z.g1)(u.params || {}), (O = (0, z.qh)(s, "params.paramsFromServer")) && O.forEach(function(e) {
                        "string" == typeof e ? E.params[e] = (0, z.qh)(R, "result." + e) : e && 1 === Object.keys(e).length && Object.keys(e).forEach(function(t) {
                            E.params[t] = (0, z.qh)(R, "result." + e[t]);
                        });
                    }), (U = (0, z.qh)(u, "params.paramsFromServer")) && U.forEach(function(e) {
                        T.params[e] = (0, z.qh)(w, "result." + e);
                    }), (0, z.hi)(E), (0, z.hi)(T), r.next = 29;
                    break;

                  case 26:
                    r.prev = 26, r.t0 = r.catch(5), E = {}, T = {}, console.warn(r.t0);

                  case 29:
                    return G = Y(Y(Y({}, _[o] || {}), h), E), B = Y(Y(Y(Y({}, y[o] || {}), l), T), {}, {
                        transparentParams: Y(Y(Y(Y({}, (y[o] || {}).params || {}), T.params), G.params || {}), (0, 
                        z.qh)(l, "transparentParams") || {})
                    }), r.abrupt("return", (t.setData((q(a = {}, "$shareInfoMessageMap.".concat(o), G), 
                    q(a, "$shareInfoPosterMap.".concat(o), B), q(a, "$shareConfig", Y(Y({}, S), g)), 
                    a)), (0, z.mg)(s) || t.hystereticDownloadCardImage(G.imageUrl, o), {
                        nextMessage: G,
                        nextPoster: B
                    }));

                  case 31:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 5, 26 ] ]);
        }))();
    },
    hystereticDownloadCardImage: function(e, t) {
        var r = this;
        try {
            if (e.indexOf("http://tmp") > -1 || !e) return;
            (0, z.hl)(e).then(function(e) {
                e && r.setData(q({}, "$shareInfoMessageMap.".concat(t, ".imageUrl"), e.tempFilePath));
            }, function() {});
        } catch (e) {}
    },
    $showShare: function(e) {
        e = e || this.data.$shareConfig.type;
        var t, r = this.data.$shareConfig;
        t = "string" == typeof e ? e : (0, z.jo)(e, "type") || r.type, this.setData({
            $shareConfig: Y(Y({}, r), {}, {
                type: t,
                show: !0
            })
        });
    },
    $hideShare: function() {
        this.setData({
            "$shareConfig.show": !1
        });
    },
    $share: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.type, a = void 0 === r ? "default" : r, n = t.position, o = void 0 === n ? "menu" : n, i = t.scene, s = t.currentIndex, c = void 0 === s ? null : s, u = t.defaultShareInfo, p = t.logExtParams, l = void 0 === p ? {} : p, d = t.extUrlParams, h = void 0 === d ? {} : d, f = Y(Y(Y({}, u || {}), this.data.$shareInfoMessageMap.default || {}), this.data.$shareInfoMessageMap[a] || {});
        null != c && (f.imageUrl = (0, z.qh)(f, "imageUrls.".concat(c)) || f.imageUrl);
        var g = (0, z.qh)(f, "params"), m = this.pageProperties || {}, v = m.page_sn, _ = m.page_name, x = St(Y(Y({}, f), {}, {
            params: Y(Y(Y({}, this.$getNextSharePageQuery()), g || {}), h)
        })), y = x.shareId, S = (x.baseShareInfo, O(x, ne));
        this.$addNextShowCallback(function() {
            z.ho.call(e, {
                page_sn: v,
                page_name: _,
                op: "event",
                sub_op: "share_result",
                extParams: Y(Y({
                    share_id: y,
                    share_channel: "message",
                    share_form: "card",
                    share_url: S.path,
                    share_result: "complete",
                    share_method: "manual"
                }, l), h)
            });
        }), xt({
            page_name: _,
            page_sn: v,
            share_id: y,
            scene: i,
            extParams: l
        });
        var E = getCurrentPages() || [], T = E[E.length - 1] || {};
        return (0, z.re)(Y(Y({}, S), {}, {
            shareRouter: "/".concat(T.route),
            shareRouterPosition: o,
            shareStatus: f.trackShareStatus,
            shareType: "card",
            shareCardTime: 0
        })), S;
    },
    $getTicketResult: function(e, t) {
        var r = this;
        return this.$baseRequest({
            url: "/api/ktt/general/share/ticket/info",
            method: "GET",
            auth: !1,
            noErrorToast: !t,
            data: {
                ticket: e
            }
        }).then(function(t) {
            var a;
            return null === (a = r._overWriteFormatTicketResult) || void 0 === a ? void 0 : a.call(r, t, e);
        });
    },
    $getQueryWidthTicket: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = e.length > 0 && void 0 !== e[0] ? e[0] : {}, n = e.length > 1 && void 0 !== e[1] && e[1], 
                    o = a.scene, i = O(a, oe), !o || "t=" !== o.slice(0, 2)) {
                        r.next = 24;
                        break;
                    }
                    return o.endsWith("&_j=1") && (o = o.replace("&_j=1", "")), s = o.slice(2), r.t0 = Y, 
                    r.t1 = Y, r.t2 = Y, r.t3 = {}, r.next = 12, t.$getTicketResult(s, n).catch(function(e) {
                        t.$queryTicketErrMsg = e && e.errorCode && e.errorMsg || "网络请求异常";
                    });

                  case 12:
                    if (r.t4 = r.sent, r.t4) {
                        r.next = 15;
                        break;
                    }
                    r.t4 = {};

                  case 15:
                    return r.t5 = r.t4, r.t6 = (0, r.t2)(r.t3, r.t5), r.t7 = i, r.t8 = (0, r.t1)(r.t6, r.t7), 
                    r.t9 = {}, r.t10 = q({
                        origin_scene: s
                    }, z.gf.refShareChannel, "poster"), r.t11 = (0, r.t0)(r.t8, r.t9, r.t10), r.t12 = s, 
                    r.abrupt("return", {
                        query: r.t11,
                        sceneTicket: r.t12
                    });

                  case 24:
                    return r.abrupt("return", {
                        query: a,
                        sceneTicket: ""
                    });

                  case 25:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    $onPageViewTouchEnd: function() {
        try {
            this.$eventChannel.emit(z.f1.onPageViewTouchEnd, {});
        } catch (e) {
            (0, z.hp)({
                msg: "$onPageViewTouchEnd error",
                e: e
            });
        }
    }
};

var $s = (0, z.gg)({
    methods: Bs
});

function Fs() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.onShow;
    this.$visible = !0, this.$hasShow && this.$setBizSn(this.$socketBizSn || "");
    var r = getApp();
    if (r.$needRefreshOnShow) return r.$needRefreshOnShow = !1, void (0, z.n7)({
        url: "/".concat(this.route),
        params: this.$query
    });
    "function" == typeof t && t.call(this), this.$hasShow = !0;
}

function Hs() {
    this.$cancelOnGlobalProxyChange && this.$cancelOnGlobalProxyChange(), this.$_doBatchInfo && this.$_doBatchInfo();
}

exports.ako = $s;

var js = K.wxapp.EventChannel, Vs = K.wxapp.baseMethods, Ys = K.wxapp.getPageId, zs = K.utils.FrontError, Ws = K.utils.getLogID, Ks = K.utils.safeGet, Js = K.utils.tryDo, Xs = K.navigate.amendPageStack, Qs = K.log.logger, Zs = K.log.pv, ec = K.url.buildQuery, tc = K.url.getQuery, rc = K.wxappUtils.getRefer, ac = K.wxappUtils.getPageId, nc = K.event.globalEvent, oc = (0, 
z.gg)({
    created: function() {
        this.$unLoad = !1, this.$visible = !0, this.$hasShow = !1, this.$performance = {
            onLoadTime: 0
        }, this.$isHotLaunch = !1, this.$isColdLaunch = !1, this.$hasOnloadFinished = !1, 
        this.$referPage = null, this.$query = {}, this.$nextPageQuery = {}, this.$nextShowCallback = {
            all: []
        }, this.$nextHideCallback = {
            all: []
        }, this.pageProperties = {
            page_sn: 0,
            page_name: ""
        }, this.$logInfoList = [], this.$nextSharePageQuery = {}, this.$showSwitchProxy = !0, 
        this.$currentPage = this, this.$eventChannel = new js(this), this.$pageEventsListener = new z.ar(), 
        this.isPageV2 = !0;
    }
}), ic = getApp(), sc = [ "_p_landing" ], cc = [ "msgid" ], uc = (0, z.gg)({
    definitionFilter: function(e) {
        var t = (null == e ? void 0 : e.methods) || {}, r = e.globalProxySync, a = e.noNeedProxy, n = e.noNeedProxyUpdate, o = null == e ? void 0 : e.methods, i = o.onSignIn, s = o.onSign, c = o.onLoad, u = o.onUnload, p = o.onLoadNoLogin, l = o.onLoadBefore, d = o.onShow, h = o.onHide, f = o.onSignInFail, g = o.onSignInComplete, m = o.onPullDownRefresh, v = o.onCurrentProxyChange, _ = s;
        e.methods = Y(Y({}, t), {}, {
            $getBizLog: function() {
                var e = this.$query, t = this.route;
                return Object.assign({
                    page_key: t || ""
                }, sc.reduce(function(t, r) {
                    var a = Ks(e || {}, "".concat(r));
                    return a && (t[r] = a), t;
                }, {}), cc.reduce(function(t, r) {
                    var a = Ks(e || {}, "".concat(r));
                    return a && (t["_x_".concat(r)] = a), t;
                }, {}));
            },
            changeData: function(e) {
                var t = (0, z.jo)(e) || {}, r = t.path, a = t.value;
                if (r) {
                    var n = {};
                    n[r] = a, this.setData(n);
                }
            },
            $checkProxyChangeNeedUpdate: function() {
                return !!r || !(a || n || this.$abortProxyChangeUpdate);
            },
            onLoadBefore: function() {
                return (0, z.m6)(this), qs.call(this, {
                    onLoad: _,
                    withTicket: null == e ? void 0 : e.withTicket,
                    withTicketToast: null == e ? void 0 : e.withTicketToast,
                    noNeedProxy: null == e ? void 0 : e.noNeedProxy,
                    globalProxySync: null == e ? void 0 : e.globalProxySync,
                    noNeedProxyUpdate: null == e ? void 0 : e.noNeedProxyUpdate
                }).catch(z.hm);
            },
            onLoad: function(e) {
                var t = this;
                return U(M.default.mark(function r() {
                    var a, n, o, i, s, u, d, h, f, g, m, v, x, y, S, E, T, I;
                    return M.default.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            if ("test" === z.fu.env && global.pageSet.add(t), t.$originUrl = "".concat(t.route, "?").concat(ec(e)), 
                            Xs(!0), !(a = getApp()).$blockPageOnLoad) {
                                r.next = 4;
                                break;
                            }
                            return r.abrupt("return", void (a.$blockPageOnLoad = !1));

                          case 4:
                            return t.$performance.onLoadTime = Date.now(), a.$coldLaunchFlag && (t.$isColdLaunch = !0, 
                            a.$coldLaunchFlag = !1), a.$hotLaunchFlag && (t.$isHotLaunch = !0, a.$hotLaunchFlag = !1), 
                            t.$referPage = rc(), t.$query = tc(Y(Y({}, a.$globalPageQuery), e)), t.$pvLogID = Ws(), 
                            n = t.pageProperties, o = n.page_sn, i = n.page_name, t.$nextPageRefer = {
                                refer_page_sn: o,
                                refer_page_name: i,
                                refer_page_id: t.$pageId
                            }, r.next = 9, t.onLoadBefore();

                          case 9:
                            if (t.$cancelOnSignIn = nc.listen("signIn", t.onSignIn.bind(t)), t.$cancelOnSignInFail = nc.listen("signInFail", t.onSignInFail.bind(t)), 
                            t.$cancelOnSignInComplete = nc.listen("signInComplete", t.onSignInComplete.bind(t)), 
                            t.$injectGray(), s = t.$query || {}, u = s.ref_share_user_no, d = s.ref_share_id, 
                            h = s.ref_share_channel, u && Qs.setBasicParams({
                                refer_share_user_no: u,
                                refer_share_id: d
                            }), h && Qs.setBasicParams({
                                refer_share_channel: h
                            }), o && (f = {
                                log_id: t.$pvLogID
                            }, t.$isColdLaunch ? Object.assign(f, {
                                launch_type: "cold"
                            }) : t.$isHotLaunch && Object.assign(f, {
                                launch_type: "hot"
                            }), Zs.call(t, {
                                extParams: f
                            })), p && p.call(t, t.$query), !(g = t.$query[z.gf.replaceUserNo]) || !t.$showSwitchProxy) {
                                r.next = 43;
                                break;
                            }
                            return r.next = 20, (0, z.lp)().catch(z.hm);

                          case 20:
                            if (!(m = r.sent)) {
                                r.next = 43;
                                break;
                            }
                            return r.next = 24, Promise.all([ (0, z.kp)() ? (0, z.j6)() : m, g === m.userNo ? m : (0, 
                            z.k6)(g) ]).catch(z.hm);

                          case 24:
                            if (r.t0 = r.sent, r.t0) {
                                r.next = 27;
                                break;
                            }
                            r.t0 = [];

                          case 27:
                            if (v = r.t0, x = L(v, 2), y = x[0], S = void 0 === y ? {} : y, E = x[1], T = void 0 === E ? {} : E, 
                            !(I = S.userNo) || I === T.userNo) {
                                r.next = 43;
                                break;
                            }
                            return t.$switchGlobalUserNo(I), r.next = 38, z.f3.showModal({
                                title: "切换账号为: ".concat((0, z.ku)(T.nickName, 5), "-").concat(T.isProxy ? "管理员" : "创建者", "？"),
                                content: "小程序与App登录账号不一致(当前小程序登录账号为: ".concat(S.nickName, "-").concat(S.isProxy ? "管理员" : "创建者", ")"),
                                cancelText: "不切换",
                                confirmText: "切换",
                                cancelColor: "#9c9c9c",
                                confirmColor: "#07c160"
                            });

                          case 38:
                            if (r.t1 = r.sent.confirm, !r.t1) {
                                r.next = 41;
                                break;
                            }
                            r.t1 = (t.$switchGlobalUserNo(g), t.$checkProxyChangeNeedUpdate());

                          case 41:
                            if (!r.t1) {
                                r.next = 43;
                                break;
                            }
                            throw new zs({
                                errMsg: "切换账号"
                            });

                          case 43:
                            if (r.t2 = l, !r.t2) {
                                r.next = 47;
                                break;
                            }
                            return r.next = 47, l.call(t, t.$query);

                          case 47:
                            t.$eventChannel.on("quietSignInComplete", function() {
                                _ && _.call(t, t.$query), t.$pageEventsListener.trigger(z.f1.onPddPageLoad);
                            }), c && c.call(t, t.$query), t.$hasOnloadFinished = !0;

                          case 50:
                          case "end":
                            return r.stop();
                        }
                    }, r);
                }))();
            },
            onUnload: function() {
                this.$unLoad = !0;
                var e = this.pageProperties.page_sn;
                this.$visible && e && z.ho.call(this, {
                    sub_op: "leave",
                    extParams: {
                        enter_time: this.$performance.onLoadTime
                    }
                }), this.$unSubscribeStore(), this.$unjectGray(), this.$cancelOnSignIn && this.$cancelOnSignIn(), 
                this.$cancelOnSignInFail && this.$cancelOnSignInFail(), this.$cancelOnSignInComplete && this.$cancelOnSignInComplete(), 
                (0, z.m9)(this), "function" == typeof u && u.call(this), Hs.apply(this), this.$eventChannel && this.$eventChannel.clear();
            },
            onShow: function() {
                if (getApp().$hotLaunchFlag = !1, this.$hasShow) {
                    var e = this.pageProperties.page_sn;
                    Xs(), e && z.ho.call(this, {
                        sub_op: "back",
                        extParams: {
                            enter_time: this.$performance.onLoadTime
                        }
                    });
                }
                this.$visible = !0, Object.values(this.$nextShowCallback).map(function(e) {
                    e && e.map(function(e) {
                        Js(function() {
                            e();
                        });
                    });
                }), this.$hasShow && this.$injectGray(), Fs.call(this, {
                    onShow: d
                });
                var t = this.pageProperties, r = t.page_sn, a = t.page_name;
                if ("share" === this.leaveType) {
                    this.leaveType = null, z.ho.call(this, {
                        page_sn: r,
                        page_name: a,
                        op: "event",
                        sub_op: "share_result",
                        extParams: Y({
                            share_id: this.share_id,
                            share_channel: "message",
                            share_form: "card",
                            share_url: this.share_url,
                            share_result: "complete",
                            share_method: "manual"
                        }, this.shareExtParams || {})
                    });
                    try {
                        (0, z.ev)({
                            tags: {
                                shareResultSuccess: "true"
                            }
                        });
                    } catch (r) {}
                }
                this.hasShow = !0;
            },
            onHide: function() {
                this.$preOnHideTime = Date.now(), this.$visible = !1, Object.values(this.$nextHideCallback).map(function(e) {
                    e && e.map(function(e) {
                        Js(function() {
                            e && e();
                        });
                    });
                }), this.pageProperties.page_sn && z.ho.call(this, {
                    sub_op: "leave",
                    extParams: {
                        enter_time: this.$performance.onLoadTime
                    }
                }), this.$unSubscribeStore(), this.$unjectGray(), "function" == typeof h && h.call(this);
            },
            _onSignInWrapped: function() {
                for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                this.$prePageProxyUserNo = this.$getCurrentProxyUserNo(), i && i.apply(this, t);
            },
            onSignIn: function() {
                for (var e = this, t = arguments.length, r = new Array(t), a = 0; a < t; a++) r[a] = arguments[a];
                var n = function() {
                    e._onSignInWrapped && e._onSignInWrapped.apply(e, r), e.$nextShowCallback.signIn = [], 
                    e.$hasSignInTrigger = !0;
                };
                this.$visible || this.$signImmediately ? n() : this.$nextShowCallback.signIn = [ n ];
            },
            onSignInFail: function() {
                (this.$visible || this.$signImmediately) && f && f.apply(this);
            },
            onSignInComplete: function() {
                var e = this, t = function() {
                    g && g.apply(e), e.$nextShowCallback.signInComplete = [];
                };
                this.$visible || this.$signImmediately ? t() : this.$nextShowCallback.signInComplete = [ t ], 
                this.$hasSignInCompleteTrigger = !0;
            },
            onPullDownRefresh: function() {
                (0, z.m8)(this), "function" == typeof m && m.call(this);
            },
            onCurrentProxyChange: function() {
                this.$injectGray(), v && v.call(this);
            },
            $getGrayCenter: function() {
                return z.gc.call(this);
            },
            getStaticPageInstance: function() {
                return JSON.stringify(this, function() {
                    var e = new WeakSet();
                    return function(t, r) {
                        if ("object" == D(r) && null !== r) {
                            if (e.has(r)) return;
                            e.add(r);
                        }
                        return r;
                    };
                }());
            }
        });
    }
}), pc = (0, z.gg)({
    definitionFilter: function(e) {
        var t, r = (null === (t = null == e ? void 0 : e.lifetimes) || void 0 === t ? void 0 : t.created) || e.created, a = e.initProperties;
        e.lifetimes || (e.lifetimes = {}), e.lifetimes.created = function() {
            var t;
            if (a) for (var n = 0, o = Object.keys(a); n < o.length; n++) {
                var i = o[n];
                this[i] = (0, z.g1)(a[i]);
            }
            this.pageProperties = e.pageProperties, this.$pageId = Ys(this), this.wxPageId = ac.call(this) || this.$pageId, 
            (null == e ? void 0 : e.MAIN_TAB) && (null === (t = getApp()) || void 0 === t || t.mainTabPageCreated(this.wxPageId, this)), 
            r && r.call(this);
        };
    }
}), lc = (0, z.gg)({
    definitionFilter: function(e) {
        var t = e.methods || {};
        e.methods = Y(Y({}, t), Vs({
            store: z.fv
        }));
    }
});

exports.am2 = oc;

function dc(e, t) {
    var r, a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, n = 0;
    return function() {
        for (var o = this, i = arguments.length, s = new Array(i), c = 0; c < i; c++) s[c] = arguments[c];
        Date.now() - n > t ? (r && clearTimeout(r), n = Date.now(), e.apply(this, s)) : a.trailing && (r && clearTimeout(r), 
        r = setTimeout(function() {
            n = Date.now(), e.apply(o, s);
        }, t));
    };
}

exports.agw = function(e) {
    var t = e, r = t.supplyTypeList;
    return t.goodsInfo.displayImageList = t.goodsPicList || [], t.isFreePricing = Array.isArray(r) && r.includes(ct.DISTRIBUTION_FREE_PRICING), 
    t.status = t.activityStatus, t.title = t.activityTitle, t;
}, exports.agj = function(e) {
    var t = ke(Y(Y({}, e), {}, {
        activityStatus: e.status || e.activityStatus
    })), r = t.goodsMaxPrice, a = t.goodsMinPrice, n = t.promoInfo, o = t.mallCouponEventVo, i = t.redPacketGroup, s = t.goodsMaxCommissionPrice, c = t.goodsMinCommissionPrice, u = t.goodsMaxCommissionPriceFromHighestAct, p = t.goodsMinCommissionPriceFromHighestAct, l = t.quantityDiscountInfo, d = void 0 === l ? {} : l, h = W.default.price(a, 100), f = W.default.price(r, 100);
    t.goodsInfo = t.goodsInfo || {}, t.goodsInfo.fmtPrice = h === f ? h : "".concat(h, "-").concat(f), 
    t.goodsInfo.displayImageList = t.displayImageList || [], t.cancelCount = W.default.sales(t.cancelCount), 
    t.pageViewCount = W.default.sales(t.pageViewCount), t.amount = W.default.price(t.amount, 100), 
    t.totalAmount = W.default.price(t.totalAmount, 100), t.totalRefundAmount = W.default.price(t.totalRefundAmount, 100), 
    t.isHelpSellActivity = t.activityType === z.b.DISTRIBUTION || t.activityType === z.b.SHRAE_HELP_SELL, 
    t.hasSell = t.activityType === z.b.DISTRIBUTION_HELPER, t.isSupplyChain = t.activityType === z.b.SUPPLY_CHAIN, 
    t.timeSpan = (0, z.is)(t.createdAt || 0), t.actionRecords = (t.modifyLogPageVo && t.modifyLogPageVo.modifyLogItemVos || [] || []).map(function(e) {
        return {
            updateDate: e.updateDate,
            timeStr: W.default.formatTime(+(e.updateDate || 0) / 1e3, "YYYY-MM-dd hh:mm:ss"),
            userName: e.name || "",
            action: e.operateType || "",
            copyWriting: e.copyWriting || ""
        };
    }).slice(0, 5), t.actionRecordExpended = !1;
    var g = (n || {}).discountInfoMap || {}, m = Object.keys(g).reduce(function(e, t) {
        var r = g[t] || [];
        return e.concat(r);
    }, []);
    return o && o.couponAmountDesc && m.unshift({
        discountDesc: "新人立减".concat(o.couponAmountDesc),
        isFirstRedPacket: !0
    }), t.discountInfoList = m.concat(d.ruleList || []), t.redPacketGroup = i, t.goodsCommissionAmount = s ? (0, 
    z.i1)(c, s, 100) : "", t.goodsCommissionAmountFromHighestAct = u ? (0, z.i1)(p, u, 100) : "", 
    t;
};

var hc = K.request.FileRequest, fc = function(e) {
    H(r, hc);
    var t = j(r);
    function r() {
        return G(this, r), t.apply(this, arguments);
    }
    return B(r, [ {
        key: "setRequestInterceptors",
        value: function() {
            return [ (0, z.lx)(), (0, z.ek)(), (0, z.ef)(), (0, z.ej)() ];
        }
    }, {
        key: "setResponseInterceptors",
        value: function() {
            return [ (0, z.g2)(), (0, z.qa)((0, z.nf)(z.BaseRequest)), (0, z.hr)(), (0, z.qe)((0, 
            z.nf)(z.BaseRequest)), (0, z.eo)((0, z.nf)(z.BaseRequest)) ];
        }
    } ]), r;
}();

function gc() {
    return mc.apply(this, arguments);
}

function mc() {
    return (mc = U(M.default.mark(function e() {
        var t, r, a, n = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = n.length > 0 && void 0 !== n[0] ? n[0] : "monica", r = n.length > 1 && void 0 !== n[1] && n[1], 
                e.next = 4, (0, z.fy)(r ? z.lf : z.le, {
                    bucket_tag: t
                });

              case 4:
                return a = e.sent, e.abrupt("return", a && a.signature);

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.v3 = fc;

var vc = function(e) {
    var t = {
        url: e.url,
        imageInfo: {
            width: e.width,
            height: e.height
        }
    };
    return e.etag && (t.imageInfo.etag = e.etag), e.processed_urls && 0 !== e.processed_urls.length && (t.processedUrls = e.processed_urls.map(function(e) {
        return {
            url: e
        };
    })), t;
};

function _c(e, t) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    return new fc().request({
        url: z.fu.fileDomain + "/v2/general_file",
        filePath: t,
        name: "file",
        enableTitanHttp: !1,
        formData: Y({
            bucket_tag: e,
            url_sign: 0
        }, r)
    }).catch(function(e) {
        return (0, z.hp)({
            msg: "uploadFile fail",
            e: e
        }), {};
    });
}

exports.agp = vc;

var xc = function() {
    function e() {
        G(this, e), this.rules = [], this.suffix = "";
    }
    return B(e, [ {
        key: "add",
        value: function(e) {
            return this.rules.push(e.getRule()), this;
        }
    }, {
        key: "getRule",
        value: function() {
            var e = {
                rule: this.rules.join("|")
            };
            return this.suffix && (e.suffix = this.suffix), e;
        }
    }, {
        key: "setSuffix",
        value: function(e) {
            return this.suffix = e, this;
        }
    } ]), e;
}();

exports.w8 = xc;

var yc = function() {
    function e() {
        G(this, e), this.pipe = [], this.prefix = "imageMogr2";
    }
    return B(e, [ {
        key: "getRule",
        value: function() {
            return this.prefix ? this.prefix + this.pipe.join("") : this.pipe.join("");
        }
    } ]), e;
}();

exports.w6 = yc;

var Sc = function(e) {
    H(r, yc);
    var t = j(r);
    function r() {
        var e;
        return G(this, r), (e = t.apply(this, arguments))._prefix = "".concat(e.prefix, "/thumbnail"), 
        e;
    }
    return B(r, [ {
        key: "getRule",
        value: function() {
            return this.pipe.join("|");
        }
    }, {
        key: "limitMinWidthAndHeight",
        value: function(e) {
            var t = e.width, r = e.height;
            return this.pipe.push("".concat(this._prefix, "/!").concat(t, "x").concat(r, "r")), 
            this;
        }
    } ]), r;
}();

exports._9 = Sc;

var Ec = function(e) {
    H(r, yc);
    var t = j(r);
    function r() {
        return G(this, r), t.apply(this, arguments);
    }
    return B(r, [ {
        key: "crop",
        value: function(e) {
            var t = e.width, r = e.height, a = e.gravity, n = "";
            return n = r ? t ? "/crop/".concat(t, "x").concat(r) : "/crop/x".concat(r) : "/crop/".concat(t, "x"), 
            a && (n += "/gravity/".concat(a)), this.pipe.push(n), this;
        }
    } ]), r;
}();

exports.ug = Ec;

var Tc = function(e) {
    H(r, yc);
    var t = j(r);
    function r() {
        return G(this, r), t.apply(this, arguments);
    }
    return B(r, [ {
        key: "autoOrient",
        value: function() {
            return this.pipe.push("/auto-orient"), this;
        }
    } ]), r;
}();

exports.z7 = Tc;

var Ic = function(e) {
    H(r, yc);
    var t = j(r);
    function r() {
        return G(this, r), t.apply(this, arguments);
    }
    return B(r, [ {
        key: "getRule",
        value: function() {
            return this.prefix ? this.prefix + this.pipe.join("") : this.pipe.join("");
        }
    }, {
        key: "format",
        value: function(e) {
            return this.pipe.push("/format/".concat(e)), this;
        }
    }, {
        key: "cgif",
        value: function(e) {
            return this.pipe.push("/cgif/".concat(e)), this;
        }
    } ]), r;
}();

exports.v4 = Ic;

var Cc = function(e) {
    H(r, yc);
    var t = j(r);
    function r() {
        return G(this, r), t.apply(this, arguments);
    }
    return B(r, [ {
        key: "quality",
        value: function(e) {
            if ("number" == typeof e) this.pipe.push("/quality/".concat(e)); else {
                var t = e.quality, r = e.force, a = void 0 !== r && r;
                this.pipe.push("/quality/".concat(t).concat(a ? "!" : ""));
            }
            return this;
        }
    } ]), r;
}();

exports.zq = Cc;

var kc = function() {
    function e() {
        G(this, e);
    }
    return B(e, [ {
        key: "thumbnailConfig",
        value: function() {
            return new Sc();
        }
    }, {
        key: "cutConfig",
        value: function() {
            return new Ec();
        }
    }, {
        key: "rotateConfig",
        value: function() {
            return new Tc();
        }
    }, {
        key: "formatConfig",
        value: function() {
            return new Ic();
        }
    }, {
        key: "qualityConfig",
        value: function() {
            return new Cc();
        }
    } ]), e;
}();

exports.aam = kc;

var bc, Ac, Pc = function() {
    return new kc();
};

exports.w7 = Pc, exports.wi = Ac, exports.w9 = bc, function(e) {
    e.JPG = "jpg", e.BMP = "bmp", e.GIF = "gif", e.PNG = "png", e.WEBP = "webp";
}(bc || (exports.w9 = bc = {})), function(e) {
    e.North = "north", e.Northeast = "northeast", e.West = "west", e.Center = "center", 
    e.East = "east", e.Southwest = "southwest", e.South = "south", e.Southeast = "southeast";
}(Ac || (exports.wi = Ac = {}));

var Rc = K.utils.emptyFunction, Nc = K.utils.sleep, wc = 500, Dc = 1e3, Oc = {
    ONLY_IMG: 1,
    WITH_ACT: 2,
    WITH_CODE: 3,
    ADD_FANS: 4
};

function Lc() {
    return Mc.apply(this, arguments);
}

function Mc() {
    return (Mc = U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c, u, p, l, d, h, f = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = f.length > 0 && void 0 !== f[0] ? f[0] : "", r = f.length > 1 && void 0 !== f[1] ? f[1] : {}, 
                a = r.routeType || Oc.ONLY_IMG, n = [ Oc.ONLY_IMG, Oc.ADD_FANS ].indexOf(a) > -1 ? "imageUrls" : "urlList", 
                e.next = 6, (0, z.fy)({
                    url: "/api/ktt/safe/picture_check_base",
                    timeout: 6e3,
                    noErrorToast: !0,
                    convertToCamel: !0,
                    convertRequestToSnake: !0,
                    data: Y(q({
                        routeType: a
                    }, n, [ t ]), r)
                }).catch(Rc);

              case 6:
                if (o = e.sent, !(i = (0, z.qh)(o, "resultList")) || !i[0]) {
                    e.next = 24;
                    break;
                }
                if (s = i[0], c = s.url, u = s.pass, p = s.hide, l = s.hideMsg, !u || !c) {
                    e.next = 12;
                    break;
                }
                return e.abrupt("return", c);

              case 12:
                if (!p || !l) {
                    e.next = 16;
                    break;
                }
                return e.next = 15, Er({
                    title: l || "上传的图片中存在二维码，建议删除该图",
                    duration: 2500
                });

              case 15:
                return e.abrupt("return", c);

              case 16:
                if (d = r.hideToast, h = r.errorToast, e.t0 = d, e.t0) {
                    e.next = 23;
                    break;
                }
                return (0, z.ri)({
                    title: h || (a === Oc.ADD_FANS ? "微信二维码不合规，请重新上传" : "部分图片含有敏感信息，系统已自动隐藏"),
                    icon: "none"
                }), e.next = 22, Nc(1e3);

              case 22:
                e.t0 = e.sent;

              case 23:
                return e.abrupt("return", void e.t0);

              case 24:
                return e.abrupt("return", t);

              case 25:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Uc(e) {
    return qc.apply(this, arguments);
}

function qc() {
    return (qc = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.filePath, a = t.imageProcess, n = t.anti, o = void 0 === n || n, i = t.antiOptions, 
                s = void 0 === i ? {} : i, c = t.bucketTag, e.next = 3, gc(c);

              case 3:
                return e.t0 = e.sent, e.t1 = JSON.stringify({
                    rules: [ null == a ? void 0 : a.getRule() ],
                    original_needed: !0
                }), u = {
                    upload_sign: e.t0,
                    pic_operations: e.t1
                }, e.next = 8, z.f3.uploadFile({
                    url: z.fu.fileDomain + z.so.url,
                    filePath: r,
                    timeout: 3e4,
                    name: "image",
                    formData: u
                }).then(function(e) {
                    var t = e.data;
                    return vc(JSON.parse(t));
                });

              case 8:
                if (p = e.sent, l = p.processedUrls, d = void 0 === l ? [] : l, h = p.url, f = (0, 
                z.qh)(d, "0.url") || h, g = h, f) {
                    e.next = 15;
                    break;
                }
                throw new Error("no url");

              case 15:
                if (!o || !g) {
                    e.next = 20;
                    break;
                }
                return e.next = 18, Lc(g, s).catch(Rc);

              case 18:
                (m = e.sent) !== g && (f = m, g = m);

              case 20:
                return e.abrupt("return", {
                    url: f,
                    originUrl: g
                });

              case 21:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Gc(e) {
    return 100 * Math.floor(e / 100);
}

function Bc(e, t) {
    var r = new xc();
    return t < e ? (r.add(Pc().thumbnailConfig().limitMinWidthAndHeight({
        width: e,
        height: e
    })), r.add(Pc().cutConfig().crop({
        width: e,
        height: e,
        gravity: Ac.Center
    }))) : r.add(Pc().cutConfig().crop({
        width: e,
        height: e,
        gravity: Ac.Center
    })), r;
}

function $c(e) {
    return Fc.apply(this, arguments);
}

function Fc() {
    return (Fc = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N, w, D, O, L, q, G, B, $, F, H, j;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = t.path, a = t.bucketTag, n = t.maxImageSize, o = void 0 === n ? Dc : n, 
                i = t.minImageSize, s = void 0 === i ? wc : i, c = t.area, u = t.size, p = t.anti, 
                l = t.antiOptions, d = t.q, h = void 0 === d ? 80 : d, f = t.gifEnable, g = void 0 !== f && f, 
                m = t.hasFrameNumberChecked, v = void 0 !== m && m, _ = t.count, x = void 0 === _ ? 1 : _, 
                y = t.isLocalPath, S = h, e.next = 22, (0, z.gc)().getStore().catch(Rc);

              case 22:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 25;
                    break;
                }
                e.t0 = {};

              case 25:
                return E = e.t0, T = E.autoOrientation, I = E.goodsGifEnable, C = (I = void 0 === I ? {
                    enable: !1,
                    frameNumber: 56
                } : I).enable, k = I.frameNumber, b = C && g, e.next = 34, function() {
                    var e = U(M.default.mark(function e(t) {
                        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I, C, k, b, A, P, R, N, w, D, O, L, U, q, G;
                        return M.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return r = t.path, a = t.isLocalPath, n = void 0 === a || a, o = t.maxImageSize, 
                                i = void 0 === o ? 1e3 : o, s = t.minImageSize, c = void 0 === s ? 500 : s, u = t.area, 
                                p = void 0 === u ? 1048576 : u, l = t.size, d = void 0 === l ? 0 : l, h = t.frameNumber, 
                                f = void 0 === h ? 56 : h, g = t.gifReCheck, m = void 0 === g || g, v = t.q, _ = void 0 === v ? 80 : v, 
                                x = t.autoOrientation, y = void 0 !== x && x, e.next = 3, wx.getImageInfo({
                                    src: r
                                }).then(function(e) {
                                    return n = !0, e;
                                }).catch(Rc);

                              case 3:
                                if (S = e.sent, e.t0 = n || S, e.t0) {
                                    e.next = 9;
                                    break;
                                }
                                return e.next = 8, wx.getImageInfo({
                                    src: (0, z.or)(r, {
                                        resizeWidth: c
                                    })
                                }).then(function(e) {
                                    return n = !0, e;
                                }).catch(Rc);

                              case 8:
                                S = e.sent;

                              case 9:
                                if (n) {
                                    e.next = 11;
                                    break;
                                }
                                throw new Error("获取图片信息失败");

                              case 11:
                                if (E = !1, I = (T = S || {}).path, C = T.width, k = void 0 === C ? i : C, b = T.height, 
                                A = void 0 === b ? i : b, P = T.type, R = void 0 === P ? "png" : P, N = Math.min(k, A), 
                                w = Gc(N), D = I || r, N > i && (w = Gc(i)), N < c && (w = Gc(c)), O = Bc(w, N), 
                                !(U = (!(L = "gif" === R) || m) && d && p && (d > p || w > N))) {
                                    e.next = 37;
                                    break;
                                }
                                if (_ = Math.min(Math.floor(100 * p / d * (k * A / (w * w)) * .8), _) || _, !([ "jpg", "jpeg" ].indexOf(R) > -1)) {
                                    e.next = 29;
                                    break;
                                }
                                if (!wx.canIUse("compressImage")) {
                                    e.next = 26;
                                    break;
                                }
                                return e.next = 22, z.f3.compressImage({
                                    src: D,
                                    quality: _
                                });

                              case 22:
                                (q = e.sent) ? D = q.tempFilePath : O.add(Pc().qualityConfig().quality(_)), e.next = 27;
                                break;

                              case 26:
                                O.add(Pc().qualityConfig().quality(_));

                              case 27:
                                e.next = 37;
                                break;

                              case 29:
                                if (!((G = Math.floor(w * Math.sqrt(_ / 100))) >= c || w > c)) {
                                    e.next = 34;
                                    break;
                                }
                                w = Gc(Math.max(G, c)), O = Bc(w, N), e.next = 37;
                                break;

                              case 34:
                                if (!L) {
                                    e.next = 36;
                                    break;
                                }
                                throw new Error("图片尺寸过大");

                              case 36:
                                O.add(Pc().formatConfig().format(bc.JPG)), O.add(Pc().qualityConfig().quality(_)), 
                                E = !0;

                              case 37:
                                return e.abrupt("return", (R.indexOf("gif") > -1 && O.add(Pc().formatConfig().cgif(f)), 
                                y && O.add(Pc().rotateConfig().autoOrient()), {
                                    targetSize: w,
                                    targetPath: D,
                                    isNeedRecheck: U,
                                    isGif: L,
                                    type: R,
                                    imageInfo: S,
                                    minImageLength: N,
                                    imageOpParams: O,
                                    forceTransformType: E
                                }));

                              case 38:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }));
                    return function(t) {
                        return e.apply(this, arguments);
                    };
                }()({
                    path: r,
                    isLocalPath: y,
                    maxImageSize: o,
                    minImageSize: s,
                    area: c,
                    size: u,
                    frameNumber: k,
                    gifReCheck: v,
                    q: h,
                    autoOrientation: T
                });

              case 34:
                if (A = e.sent, P = A.imageOpParams, R = A.isNeedRecheck, N = A.minImageLength, 
                w = A.targetPath, D = A.isGif, O = A.imageInfo, L = A.type, !A.forceTransformType || -1 !== [ "jpg", "jpeg", "png" ].concat(V(b ? [ "gif" ] : [])).indexOf(L)) {
                    e.next = 45;
                    break;
                }
                return e.abrupt("return", {
                    msg: "当前图片暂不支持".concat(L, "，上传格式应为jpg/png").concat(b ? "/gif" : ""),
                    success: !1
                });

              case 45:
                return e.next = 47, Uc({
                    filePath: w,
                    size: u,
                    imageProcess: P.setSuffix("suffix"),
                    anti: !1,
                    bucketTag: a
                }).catch(function(e) {
                    (0, z.hp)({
                        e: e,
                        msg: "getUploadImg fail",
                        data: {
                            params: t,
                            imageInfo: O
                        }
                    });
                });

              case 47:
                if (!(q = e.sent) || !q.url) {
                    e.next = 66;
                    break;
                }
                if (G = q.url, B = q.originUrl, !R) {
                    e.next = 60;
                    break;
                }
                return e.next = 54, z.f3.request({
                    url: "".concat(G, "?imageInfo"),
                    timeout: 1e3
                }).catch(Rc);

              case 54:
                if (!($ = e.sent)) {
                    e.next = 60;
                    break;
                }
                if (!((F = $.data) && c && F.size > c)) {
                    e.next = 60;
                    break;
                }
                return H = Math.max(0, c / F.size * (D && !v ? 100 : S) * .8), e.abrupt("return", H > 0 && x < 5 ? $c({
                    path: r,
                    maxImageSize: o,
                    minImageSize: s,
                    bucketTag: a,
                    area: c,
                    size: u,
                    anti: p,
                    q: H,
                    gifEnable: g,
                    hasFrameNumberChecked: !0,
                    count: x + 1
                }) : {
                    msg: "注意图片大小应为1M以内",
                    success: !1
                });

              case 60:
                if (!p) {
                    e.next = 65;
                    break;
                }
                return e.next = 63, Lc(B, l).catch(Rc);

              case 63:
                (j = e.sent) !== B && (G = j);

              case 65:
                return e.abrupt("return", {
                    url: G,
                    minImageSize: N,
                    success: !0
                });

              case 66:
                return e.abrupt("return", {
                    success: !1,
                    msg: "上传失败，请稍后重试"
                });

              case 67:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Hc(e) {
    return jc.apply(this, arguments);
}

function jc() {
    return (jc = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r = t.images, a = t.maxSize, n = void 0 === a ? Dc : a, o = t.minSize, i = void 0 === o ? wc : o, 
                s = t.area, c = t.isRect, u = void 0 === c || c, p = t.onSizeChange, l = t.onFileUploadStart, 
                d = t.onItemChange, h = t.anti, f = void 0 !== h && h, g = t.antiOptions, m = t.bucketTag, 
                v = t.gifEnable, _ = t.needShowLoading, x = void 0 === _ || _, y = [], !r) {
                    e.next = 13;
                    break;
                }
                return S = r.tempFiles.map(function(e, t) {
                    var r = e.path, a = e.size, n = e.tempFilePath;
                    return {
                        path: r || n,
                        size: a,
                        unique: (0, z.fz)(),
                        index: t
                    };
                }) || r.tempFilePaths.map(function(e, t) {
                    return {
                        path: e,
                        size: 0,
                        unique: (0, z.fz)(),
                        index: t
                    };
                }), E = "", T = function(e) {
                    var t = e.index;
                    return (u ? $c(Y(Y({}, e), {}, {
                        minImageSize: i,
                        maxImageSize: n,
                        area: s,
                        anti: f,
                        antiOptions: g,
                        bucketTag: m,
                        gifEnable: v
                    })) : Uc(Y(Y({}, e), {}, {
                        filePath: e.path,
                        anti: f,
                        antiOptions: g,
                        bucketTag: m
                    })).then(function(e) {
                        return Y({
                            success: !0
                        }, e);
                    })).then(function(r) {
                        if (r && r.success) {
                            var a = r.url, n = r.minImageSize;
                            Object.assign(y[t], {
                                url: a,
                                filePath: e.path,
                                showChangeHint: n && n < i,
                                finished: !0
                            });
                        } else r && r.msg ? (E = r.msg, Object.assign(y[t], {
                            url: "",
                            finished: !0
                        })) : Object.assign(y[t], {
                            url: "",
                            finished: !0
                        });
                        d && d(y[t]), p && p(y.filter(function(e) {
                            return e.finished && e.url;
                        }));
                    }).catch(function(e) {
                        Object.assign(y[t], {
                            url: "",
                            finished: !0
                        }), d && d(y[t]), (0, z.hp)({
                            e: e,
                            msg: "addImage uploadRectImage fail"
                        });
                    });
                }, y = S, l && l(y), x && (0, z.rg)({
                    title: "上传中"
                }), e.next = 11, Promise.all(S.slice(0, 9).map(T)).catch(Rc);

              case 11:
                x && (0, z.l3)(), E && (0, z.ri)({
                    title: E,
                    icon: "none"
                });

              case 13:
                return e.abrupt("return", y);

              case 14:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Vc() {
    return (Vc = U(M.default.mark(function e(t) {
        var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y, S, E, T, I = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = I.length > 1 && void 0 !== I[1] ? I[1] : {}, a = r.maxSize, n = void 0 === a ? Dc : a, 
                o = r.minSize, i = void 0 === o ? wc : o, s = r.sizeType, c = void 0 === s ? [ "original", "compressed" ] : s, 
                u = r.sourceType, p = void 0 === u ? [ "album", "camera" ] : u, l = r.isRect, d = void 0 === l || l, 
                h = r.area, f = r.onSizeChange, g = r.onFileUploadStart, m = r.onItemChange, v = r.anti, 
                _ = void 0 !== v && v, x = r.antiOptions, y = r.bucketTag, S = r.gifEnable, E = r.needShowLoading, 
                T = void 0 === E || E, e.t0 = Hc, e.t1 = n, e.t2 = i, e.t3 = h, e.t4 = d, e.t5 = f, 
                e.t6 = g, e.t7 = m, e.next = 11, z.f3.chooseImage({
                    count: t || 9,
                    sizeType: c,
                    sourceType: p
                }).catch(Rc);

              case 11:
                return e.t8 = e.sent, e.t9 = _, e.t10 = x, e.t11 = y, e.t12 = S, e.t13 = T, e.t14 = {
                    maxSize: e.t1,
                    minSize: e.t2,
                    area: e.t3,
                    isRect: e.t4,
                    onSizeChange: e.t5,
                    onFileUploadStart: e.t6,
                    onItemChange: e.t7,
                    images: e.t8,
                    anti: e.t9,
                    antiOptions: e.t10,
                    bucketTag: e.t11,
                    gifEnable: e.t12,
                    needShowLoading: e.t13
                }, e.abrupt("return", (0, e.t0)(e.t14));

              case 19:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Yc() {
    return (Yc = U(M.default.mark(function e() {
        var t, r, a = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = a.length > 0 && void 0 !== a[0] ? a[0] : {}, r = a.length > 1 ? a[1] : void 0, 
                t.avatar = t.avatarUrl, t.nickname = t.nickName, !t.avatarUrl && !t.nickName) {
                    e.next = 12;
                    break;
                }
                return e.next = 7, (0, z.fy)(Y(Y({}, z.rz), {}, {
                    data: Y({}, t)
                })).catch(function(e) {
                    throw (0, z.hp)({
                        name: "updateWXInfo",
                        msg: "updateWXInfo fail ".concat(r),
                        e: e
                    }), e;
                });

              case 7:
                return e.next = 9, (0, z.fy)(Y(Y({}, z.r0), {}, {
                    data: {
                        wxInfo: Y({}, t)
                    }
                })).catch(function(e) {
                    throw (0, z.hp)({
                        name: "updateWXInfoToKtt",
                        msg: "updateWXInfoToKtt fail ".concat(r),
                        e: e
                    }), e;
                });

              case 9:
                (0, z.sn)().catch(z.hm), e.next = 13;
                break;

              case 12:
                (0, z.hp)({
                    name: "updateUserData",
                    msg: "updateUserData info",
                    data: Y({}, t)
                });

              case 13:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.z6 = Oc;

var zc = {
    recordCurrentRole: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = e.length > 0 && void 0 !== e[0] ? e[0] : {}, n = a.role, o = a.newBeeScene, 
                    i = a.isShowNewcomerBar, s = a.isShowNewcomerIndex, c = !(e.length > 1 && void 0 !== e[1]) || e[1], 
                    r.prev = 2, r.next = 5, t.$baseRequest(Y(Y({}, z.nx), {}, {
                        data: {
                            role: n,
                            scene: o,
                            biz_helper_pcenter_ent_enable: i,
                            biz_helper_entrance_enable: s
                        }
                    }));

                  case 5:
                    return r.abrupt("return", r.sent.success);

                  case 8:
                    r.prev = 8, r.t0 = r.catch(2), c && (t.$showToast({
                        title: "请稍后重试",
                        icon: "none"
                    }), t.$error({
                        e: r.t0,
                        msg: "record new user role fail"
                    }));

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 2, 8 ] ]);
        }))();
    }
}, Wc = (0, z.gg)({
    methods: zc
}), Kc = {
    showNewcomerBenefitRetainModal: !1,
    hasPermission: !1,
    hasJoinCommunity: !1,
    unlockNewcomerPrice: 0,
    newcomerBenefitActivated: !1,
    showNewComerPayPanel: !1,
    showNewcomerBenefitEntryDialog: !1,
    showNewComerBenefitActivityList: !1
}, Jc = [ "ktt_newcomer_benefit", "ktt_index" ], Xc = {
    initBenefitBaseInfo: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l, d, h;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest(Y({}, Li)).catch(z.hm);

                  case 2:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 5;
                        break;
                    }
                    t.t0 = {};

                  case 5:
                    return r = t.t0, a = r.result, o = (n = void 0 === a ? {} : a).hasPermission, i = void 0 !== o && o, 
                    s = n.hasJoinCommunity, c = void 0 !== s && s, u = n.ownerCourse, p = (u = void 0 === u ? {} : u).courseAmount, 
                    l = void 0 === p ? 0 : p, d = u.hasActivated, h = void 0 !== d && d, t.abrupt("return", (e.setData({
                        hasPermission: i,
                        hasJoinCommunity: c,
                        unlockNewcomerPrice: W.default.price(l || 0, 100),
                        newcomerBenefitActivated: h
                    }), n));

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    initBenefitBaseInfoWithEvent: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.initBenefitBaseInfo();

                  case 2:
                    return r = t.sent, a = e.data, n = a.hasPermission, o = a.newcomerBenefitActivated, 
                    t.abrupt("return", (n && !o && (e.$eventChannel.off(z.f1.refreshBenefitBaseInfo), 
                    e.$eventChannel.on(z.f1.refreshBenefitBaseInfo, function() {
                        var t = (0, z.ge)(), r = (0, z.qh)(t || {}, "pageProperties.page_name");
                        r === e.pageProperties.page_name ? Jc.includes(r) ? e._initBenefitBaseInfo && e._initBenefitBaseInfo() : e.initBenefitBaseInfo() : e.$addNextShowCallback(function() {
                            Jc.includes(e.pageProperties.page_name) ? e._initBenefitBaseInfo && e._initBenefitBaseInfo() : e.initBenefitBaseInfo();
                        });
                    })), r));

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {
        this.$eventChannel.off(z.f1.refreshBenefitBaseInfo);
    },
    switchNewcomerBenefitModal: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.setData({
                        showNewcomerBenefitRetainModal: !e.data.showNewcomerBenefitRetainModal
                    });

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    confirmCloseNewcomerBenefit: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.switchNewcomerBenefitModal(), e.setData({
                        showNewComerPayPanel: !1
                    });

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    closeNewcomerBenefitEntryDialog: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        showNewcomerBenefitEntryDialog: !1
                    }), t.next = 3, e.recordCurrentRole({
                        isShowNewcomerIndex: !1
                    });

                  case 3:
                    e.queryHomeInfoV2 && e.queryHomeInfoV2();

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    closeNewcomerBenefit: function() {
        this.setData({
            showNewcomerBenefitEntryDialog: !0
        }), this.$click({
            page_el_sn: zi.newComerBenefitNotActive,
            extParams: {
                index_btn: 2
            }
        });
    },
    openNewComerPayPanel: function() {
        this.setData({
            showNewComerPayPanel: !0
        }), this.$click({
            page_el_sn: Yi.PAY_BTN
        });
    },
    closeNewComerPayPanel: function(e) {
        (0, z.jo)(e).paySuccess ? this.setData({
            showNewComerPayPanel: !1
        }) : this.switchNewcomerBenefitModal();
    },
    handleNewComerUnlockSuccess: function() {
        this.$eventChannel.emit(z.f1.refreshBenefitBaseInfo);
    },
    goToNewcomerbenefit: function(e) {
        var t = (0, z.jo)(e).track;
        (0, z.n3)({
            url: z.ob.newcomerBenefit
        }), this.$click({
            page_el_sn: t,
            extParams: {
                index_btn: 1
            }
        });
    },
    loadNewcomerBenefitActivities: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data, a = r.showNewcomerFreeActivities, n = r.newcomerBenefitActivated, 
                    o = r.hasJoinCommunity, a || o || !n || !e.queryNewcomerFreeActivities) {
                        t.next = 7;
                        break;
                    }
                    return t.next = 4, e.queryNewcomerFreeActivities();

                  case 4:
                    i = t.sent, s = i.rawList, e.setData({
                        rawNewcomerFreeActivityList: s,
                        showNewComerBenefitActivityList: s.length > 0
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    }
}, Qc = Y({
    mixins: [ zc ],
    data: Kc
}, Xc), Zc = O(Xc, [ "onUnload" ]), eu = (0, z.gg)({
    behaviors: [ Wc ],
    detached: function() {
        this.$eventChannel && this.$eventChannel.off(z.f1.refreshBenefitBaseInfo);
    },
    data: Kc,
    methods: Zc
}), tu = {
    getHomeOpenType: function() {
        var e = this;
        return Ni().catch(z.hm).then(function(t) {
            if (t) {
                var r = t.list;
                if (r) {
                    var a = r.map(function(t) {
                        return e.handleOpenType(t);
                    }).filter(function(e) {
                        return !!ft[e.type || 0] && e.can;
                    });
                    return {
                        openTypeList: a,
                        hasCommunityPublicPlus: a.some(function(e) {
                            return e.type === rt.COMMUNITY_PUBLIC_PLUS;
                        })
                    };
                }
            }
        });
    },
    handleOpenType: function(e) {
        var t, r = this;
        return e.type === rt.LIST ? Y(Y({}, e), {}, {
            subList: null === (t = e.subList) || void 0 === t ? void 0 : t.map(function(e) {
                return r.handleOpenType(e);
            }).filter(function(e) {
                return !!ft[e.type || 0] && e.can;
            })
        }) : Y(Y({}, ft[e.type || 0]), e);
    }
}, ru = (0, z.gg)({
    methods: tu
}), au = Y({}, tu), nu = {
    starActivityList: [],
    starTotalNewNum: 0
}, ou = {
    loadStarActivityList: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest({
                        url: "/api/ktt_rec/rec_feeds/query_can_help_sell_star_activity_by_rec",
                        convertToCamel: !0,
                        convertRequestToSnake: !0,
                        noErrorToast: !0,
                        data: {
                            scene: 0,
                            pageSize: 20,
                            listId: ""
                        }
                    }).catch(z.hm);

                  case 2:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 5;
                        break;
                    }
                    t.t0 = {};

                  case 5:
                    r = t.t0, a = (0, z.qh)(r, "result.starLeaderActivityFeedList") || [], n = (0, z.qh)(r, "result.totalNewNum") || 0, 
                    e.setData({
                        starActivityList: a.map(Ki),
                        starTotalNewNum: n
                    });

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    }
}, iu = (0, z.gg)({
    data: Y({}, nu),
    methods: Y({}, ou)
});

exports.amz = iu, exports.akj = au, exports.aki = ru, exports.aj_ = eu, exports.aff = Qc, 
exports.anp = Wc, exports.afh = zc;

var su = Y({
    data: Y({}, nu)
}, ou);

exports.afg = su;

var cu = {
    needShowGroupGuide: !1,
    showGroupGuideDialog: !1,
    groupGuideShareInfo: null
}, uu = {
    getGroupToolGuideKey: function() {
        var e = (0, z.f2)(function() {
            return wx.getStorageSync(z.ct.groupToolGuideDialogKey);
        }, {});
        this.setData({
            needShowGroupGuide: "" === e
        });
    },
    confirmGroupGuideDialog: function(e) {
        var t = (0, z.jo)(e, "customShareInfo") || null;
        (0, z.f2)(function() {
            wx.setStorage({
                key: z.ct.groupToolGuideDialogKey,
                data: !0
            });
        }, void 0), this.setData({
            showGroupGuideDialog: !0,
            needShowGroupGuide: !1,
            groupGuideShareInfo: t
        });
    },
    handleGroupToolConfirm: function() {
        this.setData({
            showGroupGuideDialog: !1
        });
    },
    handleGroupToolClose: function() {
        this.setData({
            showGroupGuideDialog: !1
        });
    }
}, pu = Y({
    data: Y({}, cu),
    onLoad: function() {
        this.getGroupToolGuideKey();
    }
}, uu);

exports.afi = pu;

var lu = (0, z.gg)({
    data: Y({}, cu),
    methods: Y({
        onSign: function() {
            this.getGroupToolGuideKey();
        }
    }, uu)
}), du = {
    moreOpBtn: 4723232,
    top: 4723244,
    cancleTop: 4727691,
    show: 4727687,
    hide: 4723243,
    delete: 4723242,
    copy: 4723241,
    end: 4723240,
    modify: 4723239,
    realDelete: 4727692,
    contactSupply: 4727690,
    gotoSupplyActivity: 4727689,
    reopen: 4727688,
    opLog: 4723246,
    helpSellMgr: 4723245,
    savePoster: 7339468,
    xcAddByActivity: 5896563
}, hu = K.utils.safeGet, fu = K.utils.safeSet, gu = {
    url: "/api/ktt_group/activity_operate/top",
    convertRequestToSnake: !0,
    convertToCamel: !0
}, mu = {
    handleMoreOperate: function(e) {
        var t, r = (0, z.jo)(e), a = r.item, n = void 0 === a ? {} : a, o = r.index, i = this.getBaseOperateList(n), s = n.sort || 0;
        (this._checkPage(bo.PERSON_CENTER) || this._checkPage(bo.CAPTAIN) || this._checkPage(bo.INDEX_SEARCH) || this._checkPage(bo.INDEX_SEARCH_RESULT) && (null === (t = this.$currentPage) || void 0 === t ? void 0 : t.$query[z.gf.searchPageFrom]) === Ao.captain) && i.push(s ? "取消置顶" : "设置为置顶"), 
        this.setData({
            chooseMaskVisible: !0,
            operatePanelType: z.bq.NORMAL,
            operateActivityInfo: n,
            operateList: i,
            operateIndex: o
        });
    },
    onChooseChange: function(e) {
        var t = e.detail.type;
        switch (this.closeChooseMask(), t) {
          case "修改团信息":
            this._checkOperatePerm(t) && this.modifyCurActivity();
            break;

          case "结束团":
            this._checkOperatePerm(t) && this.showEndConfirmModal();
            break;

          case "开启团购":
            this._checkOperatePerm(t) && this.restartActivityWithNoteSendCheck(this.restartActivity.bind(this));
            break;

          case "复制团":
            this._checkOperatePerm(t) && this.copyActivity();
            break;

          case "删除团":
            this._checkOperatePerm(t) && this.showDeleteConfirmModal();
            break;

          case "展示团":
            this.showOrHideActivityConfirmModal(!0);
            break;

          case "隐藏团":
            this.showOrHideActivityConfirmModal(!1);
            break;

          case "设置为置顶":
            this.topOperation(!0);
            break;

          case "取消置顶":
            this.topOperation(!1);
            break;

          case "恢复团":
            this.recoverActivity();
            break;

          case "永久删除":
            this._checkOperatePerm(t) && this.doRealDeleteActivity && this.doRealDeleteActivity();
            break;

          case "移动分类":
            this._checkOperatePerm(t) && this.handleChangeCategory();
            break;

          case "生成素材":
            this.goToXCAddByActivity();
            break;

          case "取消标记":
            this.markActivity && this.markActivity(0);
            break;

          case "标记团":
            this.markActivity && this.markActivity(1);
        }
    },
    queryFeedsActivityLabel: function(e, t) {
        var r = this;
        return U(M.default.mark(function a() {
            var n, o, i, s, c, u, p, l;
            return M.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, r.$baseRequest({
                        url: "/api/ktt_group/activity_feeds/query_feeds_label",
                        convertToCamel: !0,
                        data: {
                            activity_no: e,
                            scene: 10001
                        }
                    }).catch(z.hm);

                  case 2:
                    o = a.sent, i = r._getField(), s = i.listName, c = r.data[s], (p = (u = void 0 === c ? [] : c).findIndex(function(t) {
                        return t.activityNo === e;
                    })) >= 0 && (l = Y(Y({}, u[p]), t), (null === (n = null == o ? void 0 : o.result) || void 0 === n ? void 0 : n.showLabelVo) && (l.showLabelVo = o.result.showLabelVo), 
                    r.setData(q({}, "".concat(s, "[").concat(p, "]"), l)));

                  case 9:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    topOrderAdjust: function() {
        var e = this;
        this.$eventChannel.onceOnShow(z.f1.topGroupOrderAdjust, function() {
            e.afterTopOperation && e.afterTopOperation(1, 1);
        }), (0, z.n3)({
            url: z.ob.groupOrderAdjust
        });
    },
    goToXCAddByActivity: function() {
        var e = this;
        this.$click({
            page_el_sn: du.xcAddByActivity
        });
        var t = this.data.operateActivityInfo, r = (void 0 === t ? {} : t).activityNo;
        this.$eventChannel.cancel(z.f1.addXcMaterialFromFeeds), this.$eventChannel.onOnShow(z.f1.addXcMaterialFromFeeds, function(t) {
            var a = t.momentsId, n = e._getField().listName, o = e.data[n], i = void 0 === o ? [] : o, s = i.findIndex(function(e) {
                return e.activityNo === r;
            });
            if (s >= 0) {
                var c = i[s].activityTagVo;
                e.setData(q({}, "".concat(n, "[").concat(s, "].activityTagVo"), Y(Y({}, c), {}, {
                    relatedMmpMoments: {
                        typeId: a
                    }
                })));
            }
        }), r && (0, z.n3)({
            url: z.ob.xcAddByActivity,
            params: {
                collection_activity_no: r
            }
        });
    },
    deleteActivity: function() {
        var e = this, t = this.data.operateActivityInfo, r = (void 0 === t ? {} : t).activityNo;
        this.doDeleteActivity(r).then(function(t) {
            t && e._filterSetData(r);
        });
    },
    afterChangeCategory: function(e) {
        var t = this, r = (0, z.jo)(e).categoryId, a = this.data.operateActivityInfo, n = void 0 === a ? {} : a, o = n.activityNo;
        this.hideChangeCategoryPanel(), void 0 !== this.data.activityCategory && -1 !== this.data.activityCategory && r !== n.activityCategory && this._filterSetData(o);
        var i = this._getField().listName, s = this.data[i], c = void 0 === s ? [] : s;
        this._checkPage(bo.PERSON_CENTER) ? setTimeout(function() {
            t.getPersonData && t.getPersonData();
        }, 300) : this._checkPage(bo.CAPTAIN) && setTimeout(function() {
            t.getCaptainData && t.getCaptainData();
        }, 300), this.setData(q({}, i, c.map(function(e) {
            return e.activityNo === o && (e.activityCategory = r), e;
        })));
    },
    forwardCreateChain: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p, l, d, h;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (n = e.length > 0 && void 0 !== e[0] && e[0], t.$click({
                        page_el_sn: du.contactSupply
                    }), o = t.data.operateActivityInfo, s = (i = void 0 === o ? {} : o).activityNo, 
                    c = void 0 === s ? "" : s, u = i.subActivityType, p = i.activityType, q(a = {}, z.gf.collectionActivityNo, c), 
                    q(a, z.gf.isCreateNew, n ? 1 : ""), q(a, z.gf.copyMyChain, n ? 1 : 0), l = a, !n || u !== z.cp.NORMAL || p !== z.b.NORMAL) {
                        r.next = 16;
                        break;
                    }
                    return r.next = 6, t.getHomeOpenType().catch(z.hm);

                  case 6:
                    if (r.t0 = r.sent, r.t0) {
                        r.next = 9;
                        break;
                    }
                    r.t0 = {};

                  case 9:
                    if (d = r.t0, !d.hasCommunityPublicPlus) {
                        r.next = 16;
                        break;
                    }
                    return r.next = 14, t.$showModal({
                        content: "是否复制为小区团？支持按小区凑单，还可以批量退款、免费发短信",
                        cancelText: "仍然复制为普通团",
                        confirmText: "复制为小区团"
                    }).catch(z.hm);

                  case 14:
                    (h = r.sent) && h.confirm && Object.assign(l, q({}, z.gf.subActivityType, z.cp.COMMUNITY_PUBLIC));

                  case 16:
                    (0, z.n3)({
                        url: z.ob.createChain,
                        params: l
                    });

                  case 17:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    stopActivity: function() {
        var e = this, t = this.data.operateActivityInfo, r = (void 0 === t ? {} : t).activityNo, a = void 0 === r ? "" : r;
        (0, z.rv)({
            data: {
                collectionActivityNo: a
            }
        }).then(function() {
            e._checkPage(bo.PERSON_CENTER) && 1 === e.activityTabType ? e._filterSetData(a) : e._setStatusData(a, z.h.STOPPED);
        });
    },
    restartActivity: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], r = this.data.operateActivityInfo, a = void 0 === r ? {} : r, n = a.activityNo, o = void 0 === n ? "" : n;
        this.doRestartActivity(o, t).then(function() {
            e._checkPage(bo.PERSON_CENTER) && 4 === e.activityTabType ? e._filterSetData(o) : e._setStatusData(o, z.h.DOING);
        });
    },
    topOperation: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return t.$click({
                        page_el_sn: e ? du.top : du.cancleTop
                    }), a = t.data.operateActivityInfo, n = (void 0 === a ? {} : a).activityNo, r.next = 6, 
                    (0, z.fy)(Y(Y({}, gu), {}, {
                        data: {
                            activityNo: n,
                            isTop: +e
                        }
                    })).catch(function() {
                        var e = U(M.default.mark(function e(r) {
                            var a;
                            return M.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (!r || 5211 !== r.errorCode) {
                                        e.next = 5;
                                        break;
                                    }
                                    return e.next = 3, t.$showModal({
                                        content: "当前置顶团购数量已超上限，请前往调整",
                                        cancelText: "暂不置顶",
                                        confirmText: "去管理设置"
                                    });

                                  case 3:
                                    (a = e.sent) && a.confirm && t.topOrderAdjust();

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }());

                  case 6:
                    if (r.t0 = r.sent, r.t0) {
                        r.next = 9;
                        break;
                    }
                    r.t0 = {};

                  case 9:
                    (o = r.t0) && o.success ? (i = t.data, s = i.releaseList, c = void 0 === s ? [] : s, 
                    u = i.operateIndex, p = i.operateActivityInfo, e ? ((0, z.ri)({
                        title: "置顶成功"
                    }), c && (p.sort = hu(c, "0.sort") + 1, c.splice(u || 0, 1), c.unshift(p), t.setData({
                        releaseList: c
                    }))) : (fu(c, "".concat(u, ".sort"), 0), t.setData({
                        releaseList: c
                    }), (0, z.ri)({
                        title: "已取消置顶"
                    }))) : (0, z.ri)({
                        title: "置顶失败"
                    });

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    _filterSetData: function(e) {
        var t = this._getField().listName, r = this.data[t], a = void 0 === r ? [] : r;
        this.setData(q({}, t, (a || []).filter(function(t) {
            return t.activityNo !== e;
        })));
    },
    _batchFilterSetData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = this._getField(), r = t.listName, a = this.data[r], n = void 0 === a ? [] : a;
        this.setData(q({}, r, (n || []).filter(function(t) {
            return !e.includes(t.activityNo);
        })));
    },
    _checkOperatePerm: function(e) {
        var t = (this.data.groupOptDisabledMap || {})[e];
        return t && this.$showToast({
            title: "无权限，请联系团长开通"
        }), !t;
    },
    _setStatusData: function(e, t) {
        var r = this, a = this._getField().listName, n = this.data[a], o = void 0 === n ? [] : n;
        this.setData(q({}, a, (o || []).map(function(a) {
            return a.activityNo === e && (a[r._getField().statusName] = t, a.isOver = t === z.h.STOPPED), 
            a;
        })));
    }
};

exports.am7 = gu, exports.ana = du, exports.aiv = lu;

var vu = Y({
    mixins: [ au ],
    data: {
        operateActivityInfo: {}
    }
}, mu);

exports.afj = vu;

var _u = (0, z.gg)({
    behaviors: [ ru ],
    data: {
        operateActivityInfo: {}
    },
    methods: Y({}, mu)
}), xu = {
    ktt_index: "listData",
    ktt_newpersonal: "releaseList",
    ktt_captain: "userActivityList",
    ktt_index_search: "listData",
    ktt_star_manage_center: "listData"
}, yu = {
    ktt_index: "activityStatus",
    ktt_newpersonal: "status",
    ktt_captain: "activityStatus",
    ktt_index_search: "activityStatus",
    ktt_star_manage_center: "activityStatus"
}, Su = {
    getBaseOperateList: function(e) {
        var t;
        this.$impr({
            page_el_sn: du.moreOpBtn
        });
        var r = e.status, a = e.isShow, n = e.activityType, o = e.isSupplyChainActivity, i = e.participateCount, s = e.groupMark, c = void 0 !== e.isOver ? e.isOver : r === z.h.STOPPED, u = r === z.h.PREVIEW, p = r === z.h.DELETE, l = void 0 !== e.allowCopy ? e.allowCopy : !o && n !== z.b.SUPPLY_CHAIN && n !== z.b.DISTRIBUTION_HELPER, d = [];
        if (p) d = [ "恢复团" ], l && d.push("复制团"), this._checkPage(bo.PERSON_CENTER) && 0 == +(i || 0) && d.push("永久删除"); else if (u) d = [ "修改团信息", "删除团", "移动分类" ]; else {
            var h = !(n === z.b.SUPPLY_CHAIN && c);
            d = c ? n === z.b.SUPPLY_CHAIN ? [ h ? "修改团信息" : "", l ? "复制团" : "", "删除团" ].filter(function(e) {
                return !!e;
            }) : [ h ? "修改团信息" : "", "开启团购", l ? "复制团" : "", "删除团" ].filter(function(e) {
                return !!e;
            }) : [ h ? "修改团信息" : "", "结束团", l ? "复制团" : "", "删除团" ].filter(function(e) {
                return !!e;
            }), (this._checkPage(bo.PERSON_CENTER) || this._checkPage(bo.CHAIN_DETAIL) || this._checkPage(bo.SIGN_UP_CHECKOUT)) && (a ? d.push("隐藏团") : d.push("展示团")), 
            (this._checkPage(bo.PERSON_CENTER) && h || this._checkPage(bo.CAPTAIN) && (this.data.isSelf || this.data.isAdmin) || this._checkPage(bo.INDEX_SEARCH) || this._checkPage(bo.INDEX_SEARCH_RESULT) && (null === (t = this.$currentPage) || void 0 === t ? void 0 : t.$query[z.gf.searchPageFrom]) === Ao.captain) && d.push("移动分类");
        }
        return this._checkPage(bo.PERSON_CENTER) && d.push(s ? "取消标记" : "标记团"), d.push("生成素材"), 
        d;
    },
    closeChooseMask: function() {
        this.setData({
            chooseMaskVisible: !1
        });
    },
    showDeleteConfirmModal: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.$click({
                        page_el_sn: du.delete
                    }), t.next = 3, (0, z.rh)({
                        content: "确定删除该团购活动？",
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 3:
                    if (t.t0 = t.sent.confirm, !t.t0) {
                        t.next = 6;
                        break;
                    }
                    e.deleteActivity();

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    doDeleteActivity: function(e) {
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, z.fy)(Y(Y({}, z.hg), {}, {
                        data: {
                            activityNo: e
                        }
                    })).catch(z.hm);

                  case 2:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 5;
                        break;
                    }
                    t.t0 = {};

                  case 5:
                    if (r = t.t0, t.t1 = r.success, !t.t1) {
                        t.next = 10;
                        break;
                    }
                    return t.next = 10, Er({
                        title: "删除成功"
                    });

                  case 10:
                    return t.abrupt("return", r.success && 35013 !== r.errorCode);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    modifyCurActivity: function() {
        this.$click({
            page_el_sn: du.modify
        });
        var e = !1;
        if (!this._checkPage(bo.SIGN_UP_CHECKOUT)) if (this._checkPage(bo.CHAIN_DETAIL)) e = this.isStepPriceActivity() && this.data.status === z.h.STOPPED; else {
            var t = this.data.operateActivityInfo || {}, r = t.status;
            e = !!t.hasStepPriceGoods && r === z.h.STOPPED;
        }
        e ? (0, z.ri)({
            title: "暂不支持修改已结束的阶梯价商品团"
        }) : this.forwardCreateChain();
    },
    copyActivity: function() {
        this.$click({
            page_el_sn: du.copy
        }), this.forwardCreateChain(!0);
    },
    showEndConfirmModal: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.$click({
                        page_el_sn: du.end
                    }), r = "确定结束该团购活动？", a = "", e._checkPage(bo.SIGN_UP_CHECKOUT) || (n = e.data.activityType, 
                    !1, o = e._checkPage(bo.CHAIN_DETAIL) ? e.isStepPriceActivity() : e.data.operateActivityInfo.hasStepPriceGoods, 
                    e._checkPage(bo.CHAIN_DETAIL) || (n = e.data.operateActivityInfo.activityType), 
                    n === z.b.SUPPLY_CHAIN ? r = "多多精选团暂不支持重新开启，确定结束该团购活动？" : o ? (a = "确定提前结束团吗", r = "本团含有阶梯价商品，提前结束团将直接进行差价退款，是否继续") : n === z.b.DISTRIBUTION ? r = "结束团购后，所有帮卖团长的团购同时结束，是否结束？" : n === z.b.DISTRIBUTION_HELPER && (r = "确定结束该团购活动？")), 
                    t.next = 5, (0, z.rh)({
                        title: a,
                        content: r,
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 5:
                    if (t.t0 = t.sent.confirm, !t.t0) {
                        t.next = 8;
                        break;
                    }
                    e.stopActivity();

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    restartActivityWithNoteSendCheck: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (t.$click({
                        page_el_sn: du.reopen
                    }), n = t.data, o = n.operateList, i = n.operateActivityInfo, s = n.informType, 
                    !o.includes("展示团")) {
                        r.next = 4;
                        break;
                    }
                    return r.abrupt("return", void e.call(t));

                  case 4:
                    if (q(a = {}, z.a.INFORM_ALL, "向全部订阅用户"), q(a, z.a.INFORM_HELPSELLER, "仅向帮卖团长"), 
                    q(a, z.a.INFORM_NORMAL_MEMBER, "仅向普通团员"), q(a, z.a.NO_INFORM, ""), c = a, u = i && c[i.informType] || c[s] || "") {
                        r.next = 7;
                        break;
                    }
                    return r.abrupt("return", void e.call(t));

                  case 7:
                    return r.next = 9, t.preCheckrestart();

                  case 9:
                    if (r.sent) {
                        r.next = 11;
                        break;
                    }
                    return r.abrupt("return");

                  case 11:
                    return r.next = 13, t.$showModal({
                        title: "已为您重启该团购",
                        content: "是否".concat(u, "发送开团通知"),
                        cancelText: "不了",
                        confirmText: "确定"
                    }).catch(z.hm);

                  case 13:
                    p = r.sent, e.call(t, p && p.confirm);

                  case 15:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    preCheckrestart: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e._checkPage(bo.CHAIN_DETAIL) || e._checkPage(bo.SIGN_UP_CHECKOUT) ? e.data.collectionActivityNo : e.data.operateActivityInfo.activityNo, 
                    t.next = 3, e.doRestartActivity(r, !1, !0);

                  case 3:
                    return t.abrupt("return", !!t.sent);

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    doRestartActivity: function(e, t, r) {
        return U(M.default.mark(function a() {
            var n, o;
            return M.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.prev = 0, a.next = 3, (0, z.qb)({
                        data: {
                            activity_no: e,
                            send_notice: t,
                            pre_check: r
                        }
                    });

                  case 3:
                    return n = a.sent, a.abrupt("return", (r || (0, z.ri)({
                        title: "团购已开启"
                    }), n));

                  case 7:
                    return a.prev = 7, a.t0 = a.catch(0), o = a.t0.errorMsg, a.abrupt("return", ((0, 
                    z.ri)({
                        title: o || "当前网络有问题，请稍后重试"
                    }), Promise.reject()));

                  case 11:
                  case "end":
                    return a.stop();
                }
            }, a, null, [ [ 0, 7 ] ]);
        }))();
    },
    showOrHideActivityConfirmModal: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return t.$click({
                        page_el_sn: e ? du.show : du.hide
                    }), a = e ? "确定展示该团购活动" : "确定隐藏该团购活动", r.next = 4, (0, z.rh)({
                        content: a,
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 4:
                    if (r.t0 = r.sent.confirm, !r.t0) {
                        r.next = 7;
                        break;
                    }
                    t.showOrHideActivity(e);

                  case 7:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    doShowOrHideActivity: function(e, t, r) {
        return U(M.default.mark(function a() {
            return M.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, (0, z.fy)(Y(Y({}, e), {}, {
                        data: {
                            activityNo: t,
                            isShow: +r
                        }
                    }));

                  case 2:
                    if (a.t0 = a.sent.success, !a.t0) {
                        a.next = 5;
                        break;
                    }
                    (0, z.ri)({
                        title: r ? "显示完成" : "隐藏完成"
                    });

                  case 5:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    handleChangeCategory: function() {
        this.showChangeCategoryPanel();
    },
    showChangeCategoryPanel: function() {
        this.setData({
            changeGroupCateVisible: !0
        });
    },
    hideChangeCategoryPanel: function() {
        this.setData({
            changeGroupCateVisible: !1
        });
    },
    checkAdminGroupPermCallback: function() {
        var e = this.data, t = e.canCreateModifyGroup, r = e.canEndGroup, a = e.canDeleteGroup;
        this.setData({
            groupOptDisabledMap: {
                "修改团信息": !t,
                "开启团购": !t,
                "复制团": !t,
                "结束团": !r,
                "删除团": !a,
                "永久删除": !a,
                "移动分类": !t
            }
        });
    },
    _checkPage: function(e) {
        return this.pageProperties.page_name === e;
    },
    _getField: function() {
        var e = this.pageProperties.page_name;
        return {
            listName: xu[e],
            statusName: yu[e]
        };
    }
};

exports.aj6 = _u;

var Eu = Y({
    data: {
        chooseMaskVisible: !1,
        operateList: []
    }
}, Su);

exports.afk = Eu;

var Tu = (0, z.gg)({
    data: {
        chooseMaskVisible: !1,
        operateList: []
    },
    methods: Y({}, Su)
}), Iu = {
    showStarOrderTip: void 0,
    topTipsFixed: !1,
    topTipsHeight: 0
}, Cu = {
    updateTopTipsOnScroll: function(e) {
        var t = e.scrollTop;
        if (!this.data.$appData.isAndroid) {
            var r = t <= 1;
            r !== this.data.topTipsFixed && this.data.topTipsHeight && this.setData({
                topTipsFixed: r
            });
        }
    },
    updateTopTipsHeight: function() {
        var e = this;
        if (!this.data.$appData.isAndroid) {
            var t = this.createSelectorQuery();
            t.select("#top-tips-container").boundingClientRect(), t.selectViewport().scrollOffset(), 
            t.exec(function(t) {
                var r, a;
                if (null == t ? void 0 : t[0]) {
                    var n = null === (r = null == t ? void 0 : t[0]) || void 0 === r ? void 0 : r.height, o = (null === (a = null == t ? void 0 : t[1]) || void 0 === a ? void 0 : a.scrollTop) <= 0;
                    n === e.data.topTipsHeight && o === e.data.topTipsFixed || e.setData({
                        topTipsHeight: n,
                        topTipsFixed: o
                    });
                }
            });
        }
    },
    checkStarOrder: function() {
        var e = this;
        this.$baseRequest(Y(Y({}, $a), {}, {
            data: {
                pageNumber: 1,
                pageSize: 1,
                onlyRedDot: !0
            }
        })).catch(z.hm).then(function(t) {
            var r;
            e.setData({
                showStarOrderTip: ((null === (r = null == t ? void 0 : t.result) || void 0 === r ? void 0 : r.total) || 0) > 0
            }, function() {
                e.updateTopTipsHeight();
            });
        });
    },
    goUnAppointmentOrders: function() {
        var e = this;
        this.$addNextShowCallback(function() {
            return e.checkStarOrder();
        }), (0, z.n3)({
            url: z.ob.unAppointmentOrderList
        });
    }
}, ku = Y({
    data: Iu
}, Cu), bu = (0, z.gg)({
    data: Iu,
    methods: Cu
}), Au = {
    NORMAL: "normal",
    COPY_HELP_SELL: "copy_help_sell",
    SHARE_HELP_SELL: "share_help_sell",
    SITE_COMMISSION: "site_commission",
    MIDDLE_HELP_SELL: "middle_help_sell"
}, Pu = (q(C = {}, Au.NORMAL, {
    refundDescInteractive: !0,
    handleReturnGoods: !0,
    handleAfterSales: !0,
    afterSalesDetail: !0,
    showOperationLog: !0,
    showCopy: !0,
    showRefuse: !0,
    showRefund: !0,
    showDriveRefund: !0,
    showDirectRefund: !0,
    showCancel: !0,
    showSupplyPurchaseOrder: !0,
    canEditAddressInfo: !0,
    canEditMentionAddress: !0,
    canEditRemark: !0,
    canEditPrivateRemark: !0,
    canCallPhone: !0
}), q(C, Au.COPY_HELP_SELL, {
    refundDescInteractive: !0,
    handleAfterSales: !0,
    afterSalesDetail: !0,
    showOperationLog: !0,
    showCopy: !0,
    showSuggestRefund: !0,
    showRefuse: !0,
    canCallPhone: !0,
    canEditRemark: !0
}), q(C, Au.MIDDLE_HELP_SELL, {
    refundDescInteractive: !0,
    afterSalesDetail: !0,
    showOperationLog: !0,
    showCopy: !0
}), q(C, Au.SHARE_HELP_SELL, {
    showOperationLog: !0,
    showCopy: !0,
    canCallPhone: !0
}), q(C, Au.SITE_COMMISSION, {
    showCopy: !0,
    canCallPhone: !0
}), C), Ru = function(e) {
    var t = e.isFullRefund, r = e.refundAmount, a = e.refundAmountStr, n = e.refundingAmount, o = e.refundingAmountStr, i = e.refundDiscount, s = e.refundDiscountStr, c = e.refundingDiscount, u = e.refundingDiscountStr, p = "";
    return t ? p = "全额退款" : (r && (p = "已退".concat(a, "元") + (i ? "（包含".concat(s, "元平台补贴）") : "")), 
    r && n && (p += ","), n && (p = p + "".concat(o, "元退款中") + (c ? "（包含".concat(u, "元平台补贴）") : ""))), 
    p;
}, Nu = function(e) {
    if (e.aggregateStatus === mn.CANCEL) return "已取消订单";
    var t = 0, r = e.subOrderList;
    return (void 0 === r ? [] : r).forEach(function(e) {
        t += e.alreadyCancelNumber || 0;
    }), t ? "已取消".concat(t, "件商品") : "";
}, wu = function(e) {
    return ![ Sn.NONE, Sn.REFUSE, Sn.REFUND_SUCCESS, Sn.REFUNDING, Sn.REVOKED, Sn.CLOSED ].includes(e);
}, Du = function(e) {
    var t = e.item, r = e.isSiteCommission, a = void 0 !== r && r, n = e.control, o = void 0 === n ? {} : n, i = t.requesterIdentity, s = t.isCopyHelpSellOrder, c = t.afterSalesStatusV2, u = t.canRefundAmount, p = void 0 === u ? 0 : u, l = t.isCancelFromB, d = i === Pn.SHARE_OWNER, h = {};
    s ? i === Pn.OWNER ? (h = Pu[Au.COPY_HELP_SELL], c !== Sn.TO_REFUND && (h = Y(Y({}, h), {}, {
        handleAfterSales: !1
    }))) : i === Pn.ROOT_SUPPLY_OWNER ? h = Pu[Au.NORMAL] : i === Pn.PARENT_SUPPLY_OWNER && (h = Pu[Au.MIDDLE_HELP_SELL]) : h = Pu[Au.NORMAL], 
    d && (h = Pu[Au.SHARE_HELP_SELL]), a && (h = Pu[Au.SITE_COMMISSION]);
    var f = wu(c), g = {
        showDriveRefund: p > 0 && !f,
        showCancel: !l,
        handleAfterSales: f,
        afterSalesDetail: c !== Sn.NONE,
        showSupplyPurchaseOrder: t.supplyPurchaseStatus && t.supplyPurchaseStatus > 0
    };
    return h = Y(Y({}, h), o), Object.keys(g).forEach(function(e) {
        h[e] = h[e] && g[e];
    }), h;
}, Ou = {
    operationControl: {},
    isSelectPrivateRemark: !1,
    remarkDialogVisible: !1,
    showEditAddressDialog: !1,
    mentionAddressDialogVisible: !1,
    cancelOrderDialogVisible: !1,
    cancelOrderDialogIsAfterFullRefund: !1,
    confirmRefundDialogVisible: !1,
    chooseCancelDialogVisible: !1,
    chooseRefundDialogVisible: !1,
    singleCancelDialogVisible: !1,
    suborderCancelStatus: An
}, Lu = {
    updateListItem: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = this.data.index;
        this.triggerEvent("updateListItem", {
            index: t,
            payload: e
        });
    },
    updateListItemWithData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = this.data.index;
        this.triggerEvent("updateListItemWithData", {
            index: t,
            updateInfo: e
        });
    },
    getOrderItem: function() {
        var e = this.data, t = e.item, r = e.info;
        return t || r;
    },
    addUpdateListenerAfterBackOnShow: function() {
        var e = this;
        this.$addNextShowCallback && this.$addNextShowCallback(function() {
            e.updateListItem({});
        });
    },
    doClickLog: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        try {
            if (!e || !this.$click) return;
            this.$click(Y({
                page_el_sn: e
            }, t));
        } catch (e) {}
    },
    showToast: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        (0, z.ri)({
            title: e,
            icon: "none"
        });
    },
    call: function(e) {
        var t = e.target.dataset.phone;
        t && wx.makePhoneCall({
            phoneNumber: t
        });
    },
    goToActivity: function() {
        var e = this.data.item;
        Vt(e.activityNo, {
            displayType: e.displayType
        });
    },
    showRemarkDialog: function(e) {
        var t = e.detail.isPrivate;
        this.setData({
            remarkDialogVisible: !0,
            isSelectPrivateRemark: t
        });
    },
    submitRemark: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u, p;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return (0, z.rg)(), a = t.data.item, n = e.detail, o = n.remark, i = n.privateRemark, 
                    s = n.canEditPrivateRemark, c = a.parentOrderSn, (u = []).push({
                        remarkType: ri.PUBLIC,
                        remarkContent: o
                    }), s && u.push({
                        remarkType: ri.PRIVATE,
                        remarkContent: i
                    }), p = (0, z.fy)(Y(Y({}, Ma), {}, {
                        data: {
                            parentOrderSn: c,
                            modifyInfoList: u
                        }
                    })), r.next = 6, p.then(function() {
                        (0, z.l3)(), t.updateListItem({}), (0, z.ri)({
                            title: "修改备注成功"
                        }), t.hideRemarkDialog();
                    }).catch(function(e) {
                        (0, z.l3)(), (0, z.ri)({
                            title: e.errorMsg || "修改备注失败"
                        });
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    hideRemarkDialog: function() {
        this.setData({
            remarkDialogVisible: !1,
            isSelectPrivateRemark: !1
        });
    },
    showMentionAddressDialog: function() {
        this.setData({
            mentionAddressDialogVisible: !0
        });
    },
    submitSite: function(e) {
        var t = e.detail;
        this.updateListItem(t);
    },
    closeMentionAddressDialog: function() {
        this.setData({
            mentionAddressDialogVisible: !1
        });
    },
    handleUpdateLogistics: (0, z.r2)(function(e) {
        var t = (0, z.jo)(e).logisticsIndex, r = this.data.item, a = void 0 === t ? -1 : t, n = {
            activityNo: r.activityNo,
            shippingNo: "",
            shippingCompany: "",
            isModify: !1,
            logisticsBizSn: ""
        };
        if (-1 !== a && r.orderLogistics) {
            var o = r.orderLogistics[a];
            n.isModify = !0, n.logisticsBizSn = o.logisticsBizSn, n.shippingNo = o.shippingNo, 
            n.shippingCompany = o.shippingCompany;
        }
        return z.f9.trigger("onForwardAddExpress", n), (0, z.n3)({
            url: z.ob.addExpress,
            params: {
                order_sn: r.parentOrderSn
            }
        }), this.addUpdateListenerAfterBackOnShow(), null;
    }, 1e3),
    handleViewExpress: function() {
        var e = this.data, t = e.trackingData, r = e.item;
        this.doClickLog((t || {}).viewExpressBtn), (0, z.n3)({
            url: z.ob.orderExpressDetail,
            params: {
                order_sn: r.parentOrderSn,
                is_b: 1
            }
        }), this.addUpdateListenerAfterBackOnShow();
    },
    toggleEditAddressDialog: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data, a = r.showEditAddressDialog, !(n = r.item).canModifyReceiverInfo) {
                        t.next = 11;
                        break;
                    }
                    if (!n.isSupplyChainActivity || a) {
                        t.next = 8;
                        break;
                    }
                    return t.next = 5, e.$showModal({
                        title: "该订单已进货，修改地址无法同步至进货订单，建议团员退款后重拍",
                        cancelText: "仍然修改",
                        confirmText: "暂不修改",
                        isInPage: !0
                    });

                  case 5:
                    if (!t.sent.confirm) {
                        t.next = 7;
                        break;
                    }
                    return t.abrupt("return");

                  case 7:
                    e.$infoByBatch({
                        msg: "supplyChainActivity modify address",
                        data: {
                            orderSn: n.parentOrderSn
                        }
                    });

                  case 8:
                    e.setData({
                        showEditAddressDialog: !a
                    }), t.next = 12;
                    break;

                  case 11:
                    (0, z.ri)({
                        title: "下单时间太久不支持修改",
                        icon: "none"
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    editSuccess: function() {
        this.data.item.isSupplierGroup && z.f3.showModal({
            title: "本订单若已生成采购订单，将自动同步最新的收货信息，请及时通知供货商，确保正常发货",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07C160"
        }), this.updateListItem({});
    },
    handleForwardOrderDetail: function(e) {
        var t = (0, z.jo)(e, "params") || {};
        this.forwardOrderDetail({
            params: t
        });
    },
    forwardOrderDetail: function(e) {
        var t = this, r = (e || {}).params, a = void 0 === r ? {} : r, n = this.data.item.parentOrderSn;
        (0, z.n3)({
            url: z.ob.orderDetailB,
            params: Y(q({}, z.gf.orderSn, n), a)
        }), this.$addNextShowCallback && this.$addNextShowCallback(function() {
            t.updateListItem({});
        });
    },
    forwardOrderAfterSales: function() {
        var e, t = this, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = this.getOrderItem(), n = a.parentOrderSn;
        (0, z.n3)({
            url: z.ob.orderAfterSales,
            params: Y((e = {}, q(e, z.gf.orderSn, n), q(e, z.gf.isB, 1), e), r)
        }), this.$addNextShowCallback && this.$addNextShowCallback(function() {
            t.updateListItem({});
        });
    },
    setOperationControl: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = this.data.isSiteCommission, r = this.data.item || this.data.info, a = Du({
            item: r,
            control: e,
            isSiteCommission: t
        });
        this.setData({
            operationControl: a
        });
    },
    showChooseCancelDialog: function() {
        br(Cr.cancelOrderRefund) && this.setData({
            chooseCancelDialogVisible: !0
        });
    },
    hideChooseCancelDialog: function() {
        this.setData({
            chooseCancelDialogVisible: !1
        });
    },
    showChooseRefundDialog: function() {
        if (br(Cr.cancelOrderRefund)) {
            var e = this.getOrderItem(), t = e.refundingAmount, r = e.refundingDiscount;
            t || r ? (0, z.ri)({
                title: "订单有退款中资金，请待退款完成后再继续操作",
                icon: "none"
            }) : this.setData({
                chooseRefundDialogVisible: !0
            });
        }
    },
    hideChooseRefundDialog: function() {
        this.setData({
            chooseRefundDialogVisible: !1
        });
    },
    showSingleCancelDialog: function() {
        this.setData({
            singleCancelDialogVisible: !0
        });
    },
    hideSingleCancelDialog: function() {
        this.setData({
            singleCancelDialogVisible: !1
        });
    },
    onCancelSingle: function() {
        var e = this.data.trackingData;
        this.doClickLog((e || {}).cancelSingleBtn), this.showSingleCancelDialog(), this.hideChooseCancelDialog();
    },
    onCancelAll: function() {
        var e = this.data.trackingData;
        this.doClickLog((e || {}).cancelAllBtn), this.showCancelOrderDialog(), this.hideChooseCancelDialog();
    },
    onRefund: function() {
        var e = this.data.trackingData;
        this.doClickLog((e || {}).onlyRefundBtn), this.showDriveRefundDialog(), this.hideChooseRefundDialog();
    },
    onRefundAndCancel: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data.trackingData, e.doClickLog((r || {}).refundAndCancelBtn), a = e.getOrderItem(), 
                    n = a.isCancelFromB, o = a.subOrderList, i = void 0 === o ? [] : o, e.hideChooseRefundDialog(), 
                    s = i.reduce(function(e, t) {
                        return e + (t.availableCancelNumber || 0);
                    }, 0), !n && s) {
                        t.next = 9;
                        break;
                    }
                    return t.next = 8, Er({
                        duration: 2e3,
                        title: "暂无可取消的商品，将为您跳转仅退款处理退款"
                    });

                  case 8:
                    return t.abrupt("return", void e.showDriveRefundDialog());

                  case 9:
                    e.forwardSingleRefundGoods(!0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    showConfirmRefundDialogWithInvokeStatus: function() {
        this.showConfirmRefundDialog();
    },
    showConfirmRefundDialog: function() {
        this.getOrderItem().isFullRefund || this.setData({
            confirmRefundDialogVisible: !0
        });
    },
    closeConfirmRefundDialog: function() {
        this.setData({
            confirmRefundDialogVisible: !1
        });
    },
    hideConfirmRefundDialog: function() {
        this.setData({
            confirmRefundDialogVisible: !1
        });
    },
    handleSingleCancelSuccess: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    setTimeout(function() {
                        e.hideSingleCancelDialog();
                    }, 0), r = e.getOrderItem(), r.isFullRefund || setTimeout(function() {
                        e.showConfirmRefundDialogWithInvokeStatus();
                    }, 300);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    confirmRefund: function() {
        this.hideConfirmRefundDialog(), this.showRefundDialogAfterCancelOrder();
    },
    showRefundDialogAfterCancelOrder: function() {
        this.showDriveRefundDialog();
    },
    checkNeedShowRefundAfterCancelOrder: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    r = e.getOrderItem(), r.isFullRefund || setTimeout(function() {
                        e.showConfirmRefundDialogWithInvokeStatus();
                    }, 300);

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    showDriveRefundDialog: function() {
        this.getOrderItem().isFullRefund || this.forwardSingleRefundGoods();
    },
    forwardSingleRefundGoods: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], r = this.getOrderItem(), a = r.parentOrderSn;
        (0, z.n3)({
            url: z.ob.orderRefund,
            params: {
                order_sn: a,
                can_cancel: t ? 1 : ""
            }
        }), this.$addNextShowCallback && this.$addNextShowCallback(function() {
            e.updateListItem({});
        });
    },
    handleSubmitSingleCancel: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = (0, z.jo)(e), n = a.selectedCancelSubOrder, r.prev = 1, o = t.getOrderItem().parentOrderSn, 
                    i = n.map(function(e) {
                        var t = {
                            cancelNumber: 0,
                            alreadyCancelNumber: 0,
                            orderSn: ""
                        };
                        return t.cancelNumber = e.operateCancelNumber, t.alreadyCancelNumber = e.alreadyCancelNumber, 
                        t.orderSn = e.subOrderSn, t;
                    }), r.next = 6, Ra({
                        data: {
                            parentOrderSn: o,
                            cancelList: i
                        }
                    });

                  case 6:
                    if (s = r.sent, !0 === s.success) {
                        r.next = 10;
                        break;
                    }
                    return r.abrupt("return");

                  case 10:
                    t.updateListItem({}), t.handleSingleCancelSuccess(), r.next = 16;
                    break;

                  case 13:
                    r.prev = 13, r.t0 = r.catch(1), (0, z.hp)({
                        e: r.t0,
                        msg: "handleSubmitSingleCancel: batchCancelSingleOrder fail"
                    });

                  case 16:
                  case "end":
                    return r.stop();
                }
            }, r, null, [ [ 1, 13 ] ]);
        }))();
    },
    showAfterSalesDetail: function() {
        var e = this.data.trackingData;
        this.doClickLog((e || {}).afterSalesDetailBtn), this.forwardOrderAfterSales();
    },
    showAfterSalesRefund: function() {
        this.forwardOrderAfterSales();
    },
    showCancelOrderDialog: function(e) {
        this.setData({
            cancelOrderDialogVisible: !0,
            cancelOrderDialogIsAfterFullRefund: !!e
        });
    },
    closeCancelOrderDialog: function() {
        this.setData({
            cancelOrderDialogVisible: !1,
            cancelOrderDialogIsAfterFullRefund: !1
        });
    },
    handleCancelOrder: function() {
        var e = this, t = this.getOrderItem().parentOrderSn;
        Na({
            data: {
                parent_order_sn: void 0 === t ? "" : t
            }
        }).then(function(t) {
            t && (e.updateListItem({
                isCancelFromB: !0
            }), e.closeCancelOrderDialog(), (0, z.ri)({
                title: "订单已取消",
                icon: "none"
            }), e.checkNeedShowRefundAfterCancelOrder());
        }).catch(function() {});
    },
    handleConfirmRefundDialogCancel: function() {
        this.closeConfirmRefundDialog();
    },
    toggleRealReceiveInfo: function(e) {
        var t = (0, z.jo)(e), r = t.isRealReceiveInfo, a = t.realInfo, n = t.privateInfo;
        r ? this.updateListItemWithData(Y({
            isRealReceiveInfo: r,
            privateInfo: n
        }, a)) : this.updateListItemWithData(Y({
            isRealReceiveInfo: r
        }, n));
    }
};

exports.abw = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = e.expressType, a = e.shippingStatus, n = e.cancelStatus, o = e.subActivityType, i = e.isFullRefund;
    if ([ z.aq.logistics, z.aq.local ].includes(r)) {
        if (t ? a !== Tn.RECEIVED : a === Tn.SEND && !n && !i) return !0;
        if (z.aq.local === r && a !== Tn.RECEIVED && !n && !i) return !0;
    } else if ([ z.aq.mention, z.aq.noLogistics ].includes(r) && o !== z.cp.LOCAL_LIFE && a !== Tn.RECEIVED && !n && !i) return !0;
    return !1;
}, exports.abs = function(e) {
    var t = e.isCopyHelpSellOrder, r = e.requesterIdentity, a = e.displayType;
    return e.subActivityType !== z.cp.LOCAL_LIFE || a !== ot.localLifeServer || !t || r === Pn.OWNER;
}, exports.ah8 = function(e) {
    var t = e.item, r = t.isCopyHelpSellOrder, a = t.isShareHelpSellOrder, n = t.requesterIdentity, o = t.helpSellNickname, i = void 0 === o ? "" : o, s = t.displayType, c = t.subActivityType === z.cp.LOCAL_LIFE && s === ot.localLifeServer ? "" : i;
    return r && (n !== Pn.OWNER || a || (c = "我的")), c;
}, exports.ah9 = Du, exports.abx = wu, exports.aij = function(e) {
    return (e.orderLogistics || []).map(function(e) {
        return "".concat(e.shippingCompany || "无配送方", "：").concat(e.shippingNo);
    }).join("，");
}, exports.ah4 = function(e) {
    var t = [ e.receiverName || "", e.receiverMobile || "", e.receiveAddress || "" ];
    return e.customList && (t = t.concat(V(e.customList.map(function(e) {
        return e.type === z.t.PICTURE ? "".concat(e.name, ":[图片]") : "".concat(us(e.type) ? "" : e.name + ":").concat(e.value);
    })))), t.join(" ").trim();
}, exports.aia = function(e) {
    return vn[e];
}, exports.ah5 = function(e) {
    if (!e || !e.parentOrderSn) return "";
    var t = En[e.afterSalesStatusV2 || 0];
    return t || (t = Ru(e)), t || (t = Nu(e)), t;
}, exports.ah6 = Nu, exports.ah_ = Ru, exports.yl = Pu, exports.wv = Au, exports.am9 = bu, 
exports.am_ = ku, exports.aj5 = Tu;

var Mu = (0, z.gg)({
    behaviors: [],
    data: Y({}, Ou),
    methods: Lu
});

exports.afl = Mu;

var Uu = {
    handleOrderToChat: function() {
        var e = this.data.item, t = e.userNo, r = e.requesterIdentity, a = e.isCopyHelpSellOrder;
        if (r !== Pn.OWNER && a) (0, z.ri)({
            title: "该聊天暂不对复制帮卖小团订单开放",
            icon: "none"
        }); else {
            var n = {
                orderItem: e
            };
            z.f9.trigger(z.f1.setOrderDetailCardData, n), sn({
                toUserNo: t,
                convId: ""
            });
        }
    }
}, qu = (0, z.gg)({
    methods: Uu
});

exports.ab4 = qu;

var Gu = Y({}, Uu), Bu = {
    wait_pay_order_toast: "toPayNoticeDialog",
    guide_open_help_sell_toast: "openHelpSellDialog",
    guide_set_rec_comm_rate_toast: "recoHelpSellDialog",
    be_help_sell_toast: "beHelpSellDialog",
    group_detail_coupon_toast: "groupDetailCouponToast",
    expired_coupon_toast: "expiredCouponToast",
    penalty_coupon_toast: "penaltyCouponToast",
    latest_bind_user_toast: "latestBindUserToast",
    star_leader_entrance_toast: "starCaptainExperDialog",
    new_owner_online_toast: "ABANDONED",
    rec_star_toast: "ABANDONED",
    assisted_success_toast: "ABANDONED",
    owner_fission_budget_toast: "ABANDONED",
    remind_bind_pop: "ABANDONED",
    bind_suc_pop: "ABANDONED",
    remind_redeem_pop: "ABANDONED",
    lhb_simulate_toast: "lhbSimulateToast",
    lhb_award_toast: "lhbAwardToast",
    train_progress_toast: "ABANDONED",
    train_task_complete_toast: "ABANDONED",
    invite_score_toast: "ABANDONED",
    draw_assist_pop_up_toast: "ABANDONED",
    p_m_zero_stock_toast: "ABANDONED",
    share_marketing_coupon_toast: "ABANDONED",
    campaign_four_toast: "ABANDONED",
    final_rank_pop: "ABANDONED",
    oct_supply_chain_group_toast: "ABANDONED",
    province_qr_code_toast: "ABANDONED",
    province_20w_qr_code_toast: "KTT_QR_MODAL",
    promotion_level_update_toast: "ABANDONED",
    promotion_first_order_toast: "ABANDONED",
    promotion_first_withdraw_toast: "ABANDONED",
    sub_ktt_service_guide_tst: "subKttServiceGuideTst",
    promotion_owner_toast: "ABANDONED",
    trial_mission_toast: "ABANDONED",
    free_train_time_toast: "ABANDONED",
    free_train_advance_toast: "ABANDONED",
    global_first_discount_toast: "globalFirstDiscountToast",
    receive_goods_toast: "receiveGoodsDialog",
    query_campaign_five_toast: "ABANDONED",
    year_goods_lottery_toast: "ABANDONED",
    year_goods_no_order_toast: "ABANDONED",
    year_goods_order_again_toast: "ABANDONED",
    year_goods_red_envelope_toast: "ABANDONED",
    new_year_happy_pop_toast: "ABANDONED",
    junior_captain_push_actToast: "juniorCaptainPushActToast",
    supply_activity_change_toast: "supplyActivityChangeToast",
    new_resource_brand_toast: "newResourceBrandToast",
    query_leader_vip_toast: "ABANDONED",
    query_leader_thank_toast: "ABANDONED",
    ktt_supply_repu_lvl_change_tst: "KTT_IMG_MODAL",
    ktt_star_capt_sign_protocol_tst: "kttStarCaptSignProtocolTst",
    apply_to_star_act_generic_tst_wkd: "applyToStarActGenericTstWkd",
    delay_offline_star_act_tst: "delayOfflineStarActTst",
    multi_authorized_erp: "multiAuthorizedErp",
    official_goods_new_user_tst: "official_goods_new_user_tst",
    unshipped_star_order_toast: "unshippedStarOrderToast",
    supply_train_subscribe_class_toast: "supplyTrainSubscribeClassToast",
    invalid_capt_visit_toast: "invalidCaptVisitToast",
    resc_goods_change_tst: "rescGoodsChangeTst",
    season_gameplay_bonus_23_05: "seasonGameplayBonus2305",
    season_gameplay_remain_day_23_05: "seasonGameplayRemainDay2305",
    usr_sign_hsell_remind_tst: "helpSellProtocol"
}, $u = Behavior({
    data: {
        beAdminNoticeDialog: {
            visible: !1,
            invitor: ""
        }
    },
    methods: {
        closeBeAdminNotice: function() {
            this.setData({
                beAdminNoticeDialog: {
                    visible: !1,
                    invitor: ""
                }
            });
        }
    }
}), Fu = Behavior({
    data: {
        riskToastDialog: {
            visible: !1,
            content: ""
        }
    },
    methods: {
        closeRiskToast: function() {
            this.setData({
                riskToastDialog: {
                    visible: !1,
                    content: ""
                }
            });
        }
    }
}), Hu = Behavior({
    data: {
        subsideyStrategyDialog: {
            visible: !1,
            info: {}
        }
    },
    methods: {
        hideSubsideyStrategyDialog: function() {
            this.setData({
                "subsideyStrategyDialog.visible": !1
            });
        },
        handleSubsideyStrategyDialogCreate: function(e) {
            if ((0, z.jo)(e).redpacket) {
                var t = this.data.subsideyStrategyDialog;
                z.f9.cancel(z.f1.setSuperiseRedpacketToCreateChain), z.f9.trigger(z.f1.setSuperiseRedpacketToCreateChain, {
                    totalBudgetAmountDesc: t.info.spendAmountDesc,
                    totalNum: t.info.packetNum,
                    eventNo: t.info.eventNo
                });
            }
            (0, z.n3)({
                url: z.ob.createChain
            }), this.hideSubsideyStrategyDialog();
        }
    }
}), ju = Behavior({
    data: {
        feeBackDialog: {
            visible: !1,
            info: {}
        },
        newFeeBackDialog: {
            visible: !1,
            info: {}
        }
    },
    methods: {
        hideFeeBackDialog: function(e) {
            var t = (0, z.jo)(e).dialogName;
            this.setData(q({}, t, {
                visible: !1,
                info: {}
            }));
        }
    }
}), Vu = Behavior({
    data: {
        inviteDialog: {
            visible: !1
        }
    },
    methods: {
        hideInviteDialog: function() {
            this.setData({
                inviteDialog: {
                    visible: !1
                }
            });
        },
        handleInviteDialogInvite: function() {
            (0, z.n3)({
                url: z.ob.inviteToMakeMoneyV3
            }), this.hideInviteDialog();
        }
    }
}), Yu = Behavior({
    data: {
        inviteAmountArriveDialog: {
            visible: !1,
            info: {}
        }
    },
    methods: {
        hideInviteAmountArriveDialog: function() {
            this.setData({
                inviteAmountArriveDialog: {
                    visible: !1,
                    info: {}
                }
            });
        }
    }
}), zu = Behavior({
    data: {
        pullNewDataDialog: {
            visible: !1
        }
    },
    methods: {
        hideInvitePanel: function() {
            this.setData({
                pullNewDataDialog: {
                    visible: !1
                }
            });
        }
    }
}), Wu = Behavior({
    data: {
        bigImgTemplateDialog: {
            visible: !1
        }
    },
    methods: {
        hideBigImgTemplateDialog: function() {
            this.setData({
                bigImgTemplateDialog: {
                    visible: !1
                }
            });
        }
    }
}), Ku = Behavior({
    data: {
        qrCodeConnectDialog: {
            visible: !1
        }
    },
    methods: {
        hideQrCodeConnectDialog: function() {
            this.setData({
                qrCodeConnectDialog: {
                    visible: !1
                }
            });
        }
    }
}), Ju = Behavior({
    methods: {
        hideBizDialog: function() {
            var e = this.data.bizToastName;
            e in Bu && this.setData(q({}, Bu[e], !1));
        }
    }
}), Xu = Behavior({
    methods: {
        closePublicNumberGuide: function() {
            this.setData({
                subKttServiceGuideTst: !1
            });
        }
    }
}), Qu = Behavior({
    methods: {
        handleNoticeModifyName: function() {
            var e = this;
            return U(M.default.mark(function t() {
                return M.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.$showModal({
                            content: "实名变更已完成，请尽快提交下一步申请哦，过期需要重新申请",
                            confirmText: "立即申请",
                            showCancel: !1
                        });

                      case 2:
                        if (t.t0 = t.sent.confirm, !t.t0) {
                            t.next = 5;
                            break;
                        }
                        ds({
                            scope: Pi.card
                        });

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleNoticeModifyFail: function(e) {
            var t = this;
            return U(M.default.mark(function r() {
                var a, n, o, i;
                return M.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return a = (e || {}).extMap, o = (n = a || {}).changeType, i = n.tips, r.next = 3, 
                        t.$showModal({
                            content: "实名变更失败，原因: " + i.join("；"),
                            confirmText: "重新申请",
                            showCancel: !1
                        });

                      case 3:
                        if (r.t0 = r.sent.confirm, !r.t0) {
                            r.next = 6;
                            break;
                        }
                        (0, z.n3)({
                            url: z.ob.modifyRealName,
                            params: q({}, z.gf.modifyType, o)
                        });

                      case 6:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        }
    }
}), Zu = Behavior({
    data: {
        riskCaptainDialog: {
            visible: !1,
            type: 0
        }
    },
    methods: {
        closeRiskCaptainDialog: function() {
            this.setData({
                riskCaptainDialog: {
                    visible: !1
                }
            });
        }
    }
}), ep = {
    banNoticeList: []
}, tp = {
    handleViewBanRule: function() {
        (0, z.n5)({
            pageName: _t.kttCreateChainBanRule
        });
    },
    handleShowCustomBanNotice: function(e, t) {
        return this.setData({
            banNoticeList: e
        }), this.$showModal(Y({
            id: "customBanNotice",
            title: "温馨提示"
        }, t));
    }
}, rp = Y({
    data: ep
}, tp), ap = (0, z.gg)({
    data: ep,
    methods: tp
}), np = {
    ALL: "all",
    ALL_OWN: "all_own",
    ALL_HELP_SELL: "all_help_sell",
    LOCAL_LIFE_SERVER: "local_life_server"
}, op = {
    activityTitle: "全部团购",
    tagName: "全部团购",
    id: np.ALL,
    fetchParams: {
        activityNo: ""
    }
}, ip = {
    activityTitle: "本地生活",
    tagName: "本地生活",
    id: np.LOCAL_LIFE_SERVER,
    fetchParams: {}
}, sp = {
    ALL: "all",
    OWN: "own",
    HELP_SELL: "helpSell"
}, cp = [ {
    id: sp.ALL,
    text: "全部",
    fetchParams: {}
}, {
    id: sp.OWN,
    text: "我发布的",
    fetchParams: {
        queryType: -1
    }
}, {
    id: sp.HELP_SELL,
    text: "我帮卖的",
    fetchParams: {
        queryType: 3
    }
} ], up = (q(k = {}, sp.ALL, op), q(k, sp.OWN, {
    activityTitle: "全部团购",
    tagName: "我发布的",
    id: np.ALL_OWN,
    fetchParams: {
        character: 1
    }
}), q(k, sp.HELP_SELL, {
    activityTitle: "全部团购",
    tagName: "我帮卖的",
    id: np.ALL_HELP_SELL,
    fetchParams: {
        character: 2
    }
}), k), pp = [ {
    url: (0, z.jm)("ktt/c_.png.slim.png"),
    bottom: 0,
    height: 1125
}, {
    url: (0, z.jm)("ktt/c-.png.slim.png"),
    bottom: 0,
    height: 1125
}, {
    url: (0, z.jm)("ktt/da.png.slim.png"),
    bottom: 0,
    height: 1125
}, {
    url: (0, z.jm)("ktt/db.png.slim.png"),
    bottom: 0,
    height: 1125
} ];

function lp(e) {
    return Object.prototype.toString.call(e);
}

function dp(e, t, r, a, n) {
    var o = lp(e);
    if (o === lp(t)) {
        if (e !== t) if (1 === n || [ "[object Object]", "[object Array]" ].indexOf(o) < 0 || "[object Object]" === o && Object.keys(t).length < 1 || "[object Array]" === o && t.length < 1) a[r] = t; else if ("[object Object]" === o) for (var i = Object.keys(t), s = 0; s < i.length; s++) {
            var c = i[s];
            c && dp(e[c], t[c], "".concat(r, ".").concat(c), a, n - 1);
        } else if ("[object Array]" === o) {
            if (t.length < e.length) return void (a[r] = t);
            for (var u = 0; u < e.length; u++) dp(e[u], t[u], "".concat(r, "[").concat(u, "]"), a, n - 1);
            for (;u < t.length; u++) a["".concat(r, "[").concat(u, "]")] = t[u];
        }
    } else a[r] = t;
}

exports._k = pp, exports.al2 = {
    url: "/api/ktt_order/business/config/enable_send_receivable_order",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.alq = {
    url: "/api/ktt_order/business/search/search_local_life_service_order",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.alr = {
    url: "/api/ktt_gateway/user/local_life/query_user_role",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.alt = {
    url: "/api/ktt_order/business/query/order_detail",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.amk = {
    url: "/api/ktt_order/business/search/search_all_order",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.s6 = up, exports.vt = cp, exports.vu = sp, exports.xi = ip, exports._b = op, 
exports._a = np, exports.amf = ap, exports.ab5 = rp, exports.amg = Zu, exports.aj4 = Qu, 
exports.ak7 = Xu, exports.abk = Ju, exports.ak8 = Ku, exports.abi = Wu, exports.aja = zu, 
exports.ai9 = Yu, exports.ai_ = Vu, exports.age = ju, exports.aky = Hu, exports.amh = Fu, 
exports.aa8 = $u, exports.te = Bu, exports.ye = {
    BE_ADMIN: 1,
    RISK_MALL: 2,
    PLATFORM_SUBSIDEY: 3,
    HELP_SELL_REC: 4,
    INVITE_WHITE_LIST: 5,
    FEE_BACK: 7,
    INVITE_AMOUNT_ARRIVE: 8,
    INVITE_NEW_GROUP: 6,
    POINT_GUIDE: 11,
    ACTIVITY_TOAST: 1000001,
    BUSSINESS_TOAST: 2000001,
    ONLINE_PAY_FEE_BACK: 12,
    OFFLINE_PAY_FEE_BACK: 13,
    MODIFY_REAL_NAME: 14,
    COVID_SH_APRIL_PAY_FEE_BACK: 16,
    RISK_CAPTAIN: 17,
    MODIFY_NAME_FAIL: 18
}, exports.tz = {
    0: "",
    1: "非常差",
    2: "很差",
    3: "一般",
    4: "很好",
    5: "非常好"
}, exports.ajx = Gu;

var hp = {
    SHARE_ORDER: "share_order",
    SHARE_ORDER_DETAIL: "share_order_detail",
    AFTER_SALES_DETAIL: "after_sales_detail",
    APPLY_AFTER_SALES: "apply_after_sales",
    BUY_MORE: "buy_more",
    CALL_CAPTAIN: "call_captain",
    RECEIVE: "receive",
    REMOVE: "remove"
}, fp = (q(b = {}, hp.REMOVE, {
    title: "删除订单",
    sort: 0,
    isLast: !1
}), q(b, hp.SHARE_ORDER_DETAIL, {
    title: "晒单详情",
    sort: 1,
    impr: !0,
    log: 5307760
}), q(b, hp.AFTER_SALES_DETAIL, {
    title: "售后详情",
    sort: 2
}), q(b, hp.APPLY_AFTER_SALES, {
    title: "申请退款",
    sort: 3
}), q(b, hp.CALL_CAPTAIN, {
    title: "联系团长",
    sort: 4
}), q(b, hp.BUY_MORE, {
    title: "再来一单",
    sort: 4,
    active: !0
}), q(b, hp.RECEIVE, {
    title: "确认收货",
    sort: 5,
    impr: !0,
    log: 5715259,
    active: !0
}), q(b, hp.SHARE_ORDER, {
    title: "立即晒单",
    specialTitle: "立即评价",
    sort: 6,
    impr: !0,
    active: !0,
    log: 5307759,
    isShare: !1
}), b);

exports.ys = fp, exports.yt = hp, exports.alp = {
    url: "/api/ktt_rec/customer/recommend/query_order_list_rec_card_list",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, exports.alg = {
    url: "/api/ktt_order/customer/query/order_number",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.ang = {
    url: "/api/ktt_order/customer/unpaid/statistics",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.anf = {
    url: "/api/ktt_order/customer/unpaid/order_list",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.aj8 = {
    url: "/api/ktt_order/customer/query/order_list",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, exports.afn = {
    url: "/api/ktt_order_core/customer/modify/close",
    convertToCamel: !0
};

var gp = (0, z.gg)({
    externalClasses: [ "body-class", "picker-panel-class" ],
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        slow: {
            type: Boolean,
            value: !1
        },
        maskBgColor: {
            type: String,
            value: "rgba(0, 0, 0, .5)"
        },
        title: {
            type: String,
            value: ""
        },
        showGrayBottomLine: {
            type: Boolean,
            value: !0
        },
        disableScroll: {
            type: Boolean,
            value: !0
        }
    },
    methods: {
        handleClosePanel: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.isSelected, a = t.value, n = t.option, o = this.data.slow;
            this.triggerEvent("beforeClose"), this.data.showConfirm || this.setData({
                show: !1
            }, function() {
                setTimeout(function() {
                    e.data.show || e.triggerEvent("close", {
                        closeData: {
                            isSelected: r,
                            value: a,
                            option: n
                        }
                    });
                }, o ? 420 : 220);
            });
        }
    }
}), mp = (0, z.gg)({
    behaviors: [ gp ],
    properties: {
        options: {
            type: Array,
            value: [],
            observer: function(e) {
                this.setData({
                    list: e.map(function(e) {
                        return "object" != D(e) ? {
                            title: e,
                            key: e
                        } : e;
                    })
                });
            }
        },
        value: {
            type: String,
            value: ""
        }
    },
    data: {
        list: []
    },
    methods: {
        handleSelected: function(e) {
            var t = (0, z.jo)(e).idx, r = this.data.list[t], a = r.key;
            this.setData({
                value: a
            }), this.triggerEvent("onValueChange", {
                value: a,
                option: r,
                idx: t
            }), this.handleClosePanel({
                isSelected: !0,
                value: a,
                option: r
            });
        }
    }
});

exports.ab7 = mp, exports.ab6 = gp;

var vp = K.utils.lockASync, _p = {
    isModal: {
        type: Boolean,
        value: !1
    },
    text: {
        type: String,
        value: ""
    },
    scene: {
        type: String,
        value: "unknow"
    },
    title: {
        type: String,
        value: "登录后可体验更多功能"
    }
}, xp = {
    closeDialog: function() {
        this.data.isModal || (this.triggerEvent("close"), this.$info({
            msg: "profileDialog close",
            data: this._getLogData()
        }));
    },
    handleSuccess: function(e) {
        this.$info({
            msg: "profileDialog handleSuccess",
            data: this._getLogData(e)
        }), this.$click({
            page_el_sn: 2834174
        }), this.triggerEvent("success");
    },
    handleFail: function(e) {
        this.$error({
            msg: "profileDialog handleFail",
            data: this._getLogData(e)
        }), this.$click({
            page_el_sn: 2834175
        }), this.triggerEvent("fail", {
            isModal: this.data.isModal
        });
    },
    submit: function() {
        this.data.lockFunc || (this._submit = this._submit.bind(this), this.data.lockFunc = vp(this._submit)), 
        this.data.lockFunc();
    },
    _getLogData: function(e) {
        return {
            scene: this.data.scene,
            type: this.data.type,
            data: e || {}
        };
    }
}, yp = (0, z.gg)({
    properties: _p,
    lifetimes: {
        attached: function() {
            this.$impr({
                page_el_sn: 2834173
            }), this.$info({
                msg: "profileDialog show",
                data: this._getLogData()
            });
        }
    },
    data: {
        lockFunc: void 0
    },
    methods: xp
});

exports.aca = {
    shortLinkPageElSn: 5452692,
    cardSharePageElSn: 5452690,
    insertPublicAcountPageElSn: 5452714,
    posterSharePageElSn: 5452691,
    activityMaterialElsn: 7430765
}, exports.ab_ = {
    multiCards: 7128517,
    shareBtn: 7126252
}, exports.ab8 = yp;

var Sp = {
    MINI: "mini",
    PERM: "perm",
    H5: "h5",
    READ_FILE: "readFile"
}, Ep = Sp, Tp = {
    LIBRARY: 1,
    OFFICE_GOODS_LIBRARY: 2,
    ALL_ORDER_MANAGE: 3,
    ORDER_MANAGE_BY_SEARCH: 4,
    VIP_MANAGE: 5,
    DATA_CENTER: 6,
    HELP_SELL_MANAGE: 7,
    MENTION_ADDRESS_MANAGE: 8,
    INVITE_TO_MAKE_MONEY: 10,
    FREE_CHARGE: 11,
    CUSTOMER_SERVICE: 12,
    SETTING: 13,
    LEARNING_CENTER: 14,
    POINT_MANAGE: 15,
    HELP_SELL_ACTIVITY: 16,
    SHARE_ORDER: 17,
    HELP_SELL_PROMO: 19,
    MY_PURCHASE_SUPPLIER: 20,
    PAY_CODE: 21,
    WXC_MATERIAL_LIBRARY: 22,
    DRAW_INFO_LIST: 23,
    ADDRESS: 24,
    ALL_VIP_CARDS: 25,
    FEED_BACK: 26,
    CUSTOMER_ORDER: 27,
    VIEW_HISTORY: 28,
    GROUP_COUPON: 29,
    LUCKY_DRAW: 30,
    LIVE_TOOL: 31,
    TK_INVITE_CODE: 32,
    TK_CENTER: 33,
    TK_ACTIVITY_MANAGE: 34,
    KTT_INPUT: 35,
    PROMO_LINK: 36,
    BUSINESS_COLLEGA: 37,
    TK_PROTOCOL_V2: 38,
    CHANNEL_SUBSCRIBE: 39,
    NEWCOMER_BENEFIT: 41,
    STAR_MANAGE: 42,
    OLD_FRIENDS: 43,
    CREATE_VIDEO: 44,
    NEW_TOOL: 46,
    LOCAL_LIVING: 45,
    NEW_STRATEGY: 47,
    CODE_VERIFY: 48,
    EXCLUSIVE_CONSULTANT: 50
}, Ip = (q(A = {}, Tp.LIBRARY, {
    menuId: Tp.LIBRARY,
    icon: "https://commimg.pddpic.com/upload/ktt/mf.png.slim.png",
    title: "商品库",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: "".concat(z.ob.goodsLibrary, "?from_person=true")
    } ]
}), q(A, Tp.NEWCOMER_BENEFIT, {
    menuId: Tp.NEWCOMER_BENEFIT,
    icon: "https://commimg.pddpic.com/upload/ktt/mg.png.slim.png",
    title: "新团长福利",
    elsn: 7067653,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.newcomerBenefit
    } ]
}), q(A, Tp.OFFICE_GOODS_LIBRARY, {
    menuId: Tp.OFFICE_GOODS_LIBRARY,
    icon: "https://commimg.pddpic.com/upload/ktt/mh.png.slim.png",
    title: "多多商品库",
    elsn: Wi.officialLibrary,
    actions: [ {
        type: Sp.PERM,
        code: Cr.pddGoods
    }, {
        type: Sp.MINI,
        jumpUrl: z.ob.officeGoodsLibrary
    } ]
}), q(A, Tp.ALL_ORDER_MANAGE, {
    menuId: Tp.ALL_ORDER_MANAGE,
    elsn: 7083932,
    icon: "https://commimg.pddpic.com/upload/ktt/mi.png.slim.png",
    title: "订单管理",
    actions: [ {
        type: Sp.PERM,
        code: Cr.orderMgr
    }, {
        type: Sp.MINI,
        jumpUrl: z.ob.allOrderManage
    } ]
}), q(A, Tp.DRAW_INFO_LIST, {
    menuId: Tp.DRAW_INFO_LIST,
    icon: "https://commimg.pddpic.com/upload/ktt/mj.png.slim.png",
    title: "我的抽奖",
    elsn: 5520097,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.drawList
    } ]
}), q(A, Tp.ORDER_MANAGE_BY_SEARCH, {
    menuId: Tp.ORDER_MANAGE_BY_SEARCH,
    elsn: 7083931,
    icon: "https://commimg.pddpic.com/upload/ktt/mk.png.slim.png",
    title: "商品核销",
    actions: [ {
        type: Sp.PERM,
        code: Cr.goodsVerification
    }, {
        type: Sp.MINI,
        jumpUrl: z.ob.orderManagerBySearch
    } ]
}), q(A, Tp.VIP_MANAGE, {
    menuId: Tp.VIP_MANAGE,
    icon: "https://commimg.pddpic.com/upload/ktt/ml.png.slim.png",
    title: "会员管理",
    elsn: Wi.vipManage,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.memberDistributionList
    } ]
}), q(A, Tp.HELP_SELL_MANAGE, {
    menuId: Tp.HELP_SELL_MANAGE,
    icon: "https://commimg.pddpic.com/upload/ktt/mm.png.slim.png",
    title: "团长管理",
    elsn: Wi.grouperManageEntrance,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.helpSellerManage
    } ]
}), q(A, Tp.MENTION_ADDRESS_MANAGE, {
    menuId: Tp.MENTION_ADDRESS_MANAGE,
    icon: "https://commimg.pddpic.com/upload/ktt/mn.png.slim.png",
    title: "自提点管理",
    elsn: Wi.mentionAddressBtnEle,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.mentionAddressManage
    } ]
}), q(A, Tp.INVITE_TO_MAKE_MONEY, {
    menuId: Tp.INVITE_TO_MAKE_MONEY,
    icon: "https://commimg.pddpic.com/upload/ktt/mo.gif.slim.gif",
    title: "绑新赚钱",
    elsn: Wi.inviteToMakeMoneyBenEle,
    actions: [ {
        type: Sp.PERM,
        code: Cr.bindMoney
    }, {
        type: Sp.MINI,
        jumpUrl: z.ob.inviteToMakeMoneyV3
    } ]
}), q(A, Tp.OLD_FRIENDS, {
    menuId: Tp.OLD_FRIENDS,
    elsn: 7475891,
    icon: "https://commimg.pddpic.com/upload/ktt/03178fa3-e018-4fe1-b62c-471dd6fa7273.png.slim.png",
    title: "老友召回",
    actions: [ {
        type: Sp.PERM,
        code: Cr.bindMoney
    }, {
        type: Sp.MINI,
        jumpUrl: z.ob.inviteToMakeMoneyOldFriends
    } ]
}), q(A, Tp.FREE_CHARGE, {
    menuId: Tp.FREE_CHARGE,
    elsn: 7083934,
    icon: "https://commimg.pddpic.com/upload/ktt/mp.png.slim.png",
    title: "服务费返还",
    actions: [ {
        type: Sp.PERM,
        code: Cr.serviceCharges
    }, {
        type: Sp.H5,
        pageName: _t.kttFreeCharge
    } ]
}), q(A, Tp.CUSTOMER_SERVICE, {
    menuId: Tp.CUSTOMER_SERVICE,
    icon: "https://commimg.pddpic.com/upload/ktt/mr.png.slim.png",
    title: "官方客服",
    elsn: Wi.customerServiceBtnEle,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.chatDetail,
        pageName: _t.kttchatChooseRole,
        project: "kttchat",
        params: {
            _ktt_frontend: "kttchat",
            page_redirect: "kttchat_chat_detail_QA"
        }
    } ]
}), q(A, Tp.SETTING, {
    menuId: Tp.SETTING,
    icon: "https://commimg.pddpic.com/upload/ktt/ms.png.slim.png",
    title: "设置",
    elsn: Wi.personalSettingBtnEle,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.settingPage
    } ]
}), q(A, Tp.LEARNING_CENTER, {
    menuId: Tp.LEARNING_CENTER,
    icon: "https://commimg.pddpic.com/upload/ktt/mt.png.slim.png",
    title: "团团学堂",
    elsn: Wi.learningCenter,
    actions: [ {
        type: Sp.H5,
        pageName: _t.learningCenter
    } ]
}), q(A, Tp.POINT_MANAGE, {
    menuId: Tp.POINT_MANAGE,
    icon: "https://commimg.pddpic.com/upload/ktt/mv.png.slim.png",
    title: "积分商城",
    elsn: Wi.pointManage,
    actions: [ {
        type: Sp.H5,
        pageName: _t.pointManage
    } ]
}), q(A, Tp.HELP_SELL_ACTIVITY, {
    menuId: Tp.HELP_SELL_ACTIVITY,
    icon: "https://commimg.pddpic.com/upload/ktt/mw.png.slim.png",
    title: "可帮卖的团",
    elsn: Wi.personHelpSellActBtnEle,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.helpSellActivity
    } ]
}), q(A, Tp.SHARE_ORDER, {
    menuId: Tp.SHARE_ORDER,
    icon: "https://commimg.pddpic.com/upload/ktt/mx.png.slim.png",
    title: "团员晒单",
    elsn: Wi.shareOrderEntrance,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.shareOrderManage
    } ]
}), q(A, Tp.HELP_SELL_PROMO, {
    menuId: Tp.HELP_SELL_PROMO,
    icon: "https://commimg.pddpic.com/upload/ktt/mz.png.slim.png",
    title: "推荐赚佣金",
    elsn: Wi.personCenterHelpSellPromoBtnEle,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.helpSellerPromotion
    } ]
}), q(A, Tp.MY_PURCHASE_SUPPLIER, {
    menuId: Tp.MY_PURCHASE_SUPPLIER,
    elsn: 7083933,
    icon: "https://commimg.pddpic.com/upload/ktt/m0.png.slim.png",
    title: "我的供货商",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.myPurchaseSupplier
    } ]
}), q(A, Tp.PAY_CODE, {
    menuId: Tp.PAY_CODE,
    icon: "https://commimg.pddpic.com/upload/ktt/m1.png.slim.png",
    title: "线下收款",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.payScanInit
    } ]
}), q(A, Tp.WXC_MATERIAL_LIBRARY, {
    menuId: Tp.WXC_MATERIAL_LIBRARY,
    icon: "https://commimg.pddpic.com/upload/ktt/m2.png.slim.png",
    title: "相册素材库",
    elsn: 5395748,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.xcMaterialLibrary
    } ]
}), q(A, Tp.ADDRESS, {
    menuId: Tp.ADDRESS,
    icon: "https://commimg.pddpic.com/upload/ktt/m3.png.slim.png",
    title: "收货地址",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.address
    } ]
}), q(A, Tp.ALL_VIP_CARDS, {
    menuId: Tp.ALL_VIP_CARDS,
    icon: "https://commimg.pddpic.com/upload/ktt/m4.png.slim.png",
    title: "会员卡",
    elsn: 5520096,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.allVipCards
    } ]
}), q(A, Tp.FEED_BACK, {
    menuId: Tp.FEED_BACK,
    elsn: 5502227,
    icon: "https://commimg.pddpic.com/upload/ktt/m5.png.slim.png",
    title: "反馈与建议",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.feedBack
    } ]
}), q(A, Tp.CUSTOMER_ORDER, {
    menuId: Tp.CUSTOMER_ORDER,
    icon: "https://commimg.pddpic.com/upload/ktt/m6.png.slim.png",
    title: "我的订单",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.complexOrderList
    } ]
}), q(A, Tp.VIEW_HISTORY, {
    menuId: Tp.VIEW_HISTORY,
    icon: "https://commimg.pddpic.com/upload/ktt/m7.png.slim.png",
    title: "收藏与浏览",
    elsn: 5502226,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.viewHistory
    } ]
}), q(A, Tp.GROUP_COUPON, {
    menuId: Tp.GROUP_COUPON,
    icon: "https://commimg.pddpic.com/upload/ktt/m8.png.slim.png",
    title: "优惠券",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.couponCenter
    } ]
}), q(A, Tp.LUCKY_DRAW, {
    menuId: Tp.LUCKY_DRAW,
    icon: "https://commimg.pddpic.com/upload/ktt/m9.png.slim.png",
    title: "幸运抽奖",
    elsn: 5591601,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.luckyDrawManage
    } ]
}), q(A, Tp.LIVE_TOOL, {
    menuId: Tp.LIVE_TOOL,
    elsn: 7083935,
    icon: "https://commimg.pddpic.com/upload/ktt/m_.png.slim.png",
    title: "直播工具",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.liveTool
    } ]
}), q(A, Tp.KTT_INPUT, {
    menuId: Tp.KTT_INPUT,
    elsn: 7083936,
    icon: "https://commimg.pddpic.com/upload/ktt/m-.png.slim.png",
    title: "输入法",
    actions: [ {
        type: Sp.H5,
        pageName: _t.kttInputCouponGuide
    } ]
}), q(A, Tp.CHANNEL_SUBSCRIBE, {
    menuId: Tp.CHANNEL_SUBSCRIBE,
    elsn: 7083939,
    icon: "https://commimg.pddpic.com/upload/ktt/na.png.slim.png",
    title: "渠道订阅码",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.channelSubscribe
    } ]
}), q(A, Tp.TK_INVITE_CODE, {
    menuId: Tp.TK_INVITE_CODE,
    icon: "https://commimg.pddpic.com/upload/ktt/nb.png.slim.png",
    title: "推客邀请码",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.tkInviteFriends
    } ]
}), q(A, Tp.TK_CENTER, {
    menuId: Tp.TK_CENTER,
    icon: "https://commimg.pddpic.com/upload/ktt/nc.png.slim.png",
    title: "推客中心",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.tkHome
    } ]
}), q(A, Tp.TK_PROTOCOL_V2, {
    menuId: Tp.TK_PROTOCOL_V2,
    icon: "https://commimg.pddpic.com/upload/ktt/nd.png.slim.png",
    title: "推广协议",
    actions: [ {
        type: Sp.READ_FILE,
        jumpUrl: z.b3.KTT_TK_V2_PROTOCOL
    } ]
}), q(A, Tp.TK_ACTIVITY_MANAGE, {
    menuId: Tp.TK_ACTIVITY_MANAGE,
    icon: "https://commimg.pddpic.com/upload/ktt/ne.png.slim.png",
    title: "活动管理",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.tkActivityManage
    } ]
}), q(A, Tp.PROMO_LINK, {
    menuId: Tp.PROMO_LINK,
    elsn: 7083938,
    icon: "https://commimg.pddpic.com/upload/ktt/nf.png.slim.png",
    title: "推广链接",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.promoLinkPreview
    } ]
}), q(A, Tp.BUSINESS_COLLEGA, {
    menuId: Tp.BUSINESS_COLLEGA,
    icon: "https://commimg.pddpic.com/upload/ktt/ng.png.slim.png",
    title: "团团商学院",
    actions: [ {
        type: Sp.H5,
        pageName: _t.kttHelpSellNewbieCourse
    } ]
}), q(A, Tp.STAR_MANAGE, {
    menuId: Tp.STAR_MANAGE,
    icon: "https://funimg.pddpic.com/wxappimg/e004c829-807a-492d-99cb-1dec153b2694.png.slim.png",
    title: "明星团管理",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.starManageCenter
    } ]
}), q(A, Tp.CREATE_VIDEO, {
    menuId: Tp.CREATE_VIDEO,
    elsn: 7555863,
    icon: "https://funimg.pddpic.com/wxappimg/05bed8b6-b397-4353-844a-db002e0d11d2.png.slim.png",
    title: "视频创作",
    actions: [ {
        type: Ep.MINI,
        jumpUrl: z.ob.createVideo
    } ]
}), q(A, Tp.NEW_TOOL, {
    menuId: Tp.NEW_TOOL,
    icon: "https://funimg.pddpic.com/wxappimg/2005173c-0c89-465b-b62d-a26c7f5605f8.png.slim.png",
    title: "流量神器",
    elsn: 7715849,
    actions: [ {
        type: Ep.H5,
        pageName: _t.kttGetNewIntroduce
    } ]
}), q(A, Tp.LOCAL_LIVING, {
    menuId: Tp.LOCAL_LIVING,
    icon: "https://funimg.pddpic.com/wxappimg/fb20b10f-d452-4363-93aa-59c0e66f5bed.png",
    title: "本地生活",
    elsn: 7668594,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.localLivingGoodsLibrary
    } ]
}), q(A, Tp.NEW_STRATEGY, {
    menuId: Tp.NEW_STRATEGY,
    icon: "https://funimg.pddpic.com/wxappimg/136f49b8-83e7-484d-8ed6-b350390a43f6.png",
    title: "新人攻略",
    elsn: 7690683,
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.newcomerStrategy
    } ]
}), q(A, Tp.CODE_VERIFY, {
    menuId: Tp.CODE_VERIFY,
    icon: "https://commimg.pddpic.com/upload/ktt/3db73c47-9b66-452f-88d3-ef4785d8819f.png.slim.png",
    title: "券码核销",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.localLifeScan
    } ]
}), q(A, Tp.EXCLUSIVE_CONSULTANT, {
    menuId: Tp.EXCLUSIVE_CONSULTANT,
    icon: "https://commimg.pddpic.com/upload/ktt/7ff91133-70a8-4222-aaf5-901bb9563eb6.png.slim.png",
    title: "专属顾问",
    actions: [ {
        type: Sp.MINI,
        jumpUrl: z.ob.officialConsultant
    } ]
}), A), Cp = [ {
    menuId: Tp.ADDRESS
}, {
    menuId: Tp.ALL_VIP_CARDS
}, {
    menuId: Tp.GROUP_COUPON
}, {
    menuId: Tp.DRAW_INFO_LIST
}, {
    menuId: Tp.CUSTOMER_ORDER
}, {
    menuId: Tp.CUSTOMER_SERVICE
}, {
    menuId: Tp.FEED_BACK
}, {
    menuId: Tp.VIEW_HISTORY
}, {
    menuId: Tp.SETTING
} ], kp = {
    url: "/api/ktt_chat/conv_transfer/auto_move_in_unresolved_convs",
    noErrorToast: !0
}, bp = {
    url: "/api/ktt_chat/conv_transfer/takeover_move_in_busy_conv",
    noErrorToast: !0
}, Ap = {
    url: "/api/ktt_chat/conversation_record/cs_page_unread_conv",
    convertToCamel: !0,
    noErrorToast: !0,
    convertRequestToSnake: !0
}, Pp = {
    url: "/api/ktt_chat/conv_transfer/get_transfer_preference",
    convertToCamel: !0,
    noErrorToast: !0
}, Rp = {
    url: "/api/ktt_chat/chat_tag/query"
};

exports.af9 = {
    url: "/api/ktt_chat/conversation/delete_conv",
    convertToCamel: !0
}, exports.alb = Rp, exports.alf = {
    url: "/api/ktt_chat/conversation/get_info",
    convertToCamel: !0
}, exports.anc = Pp, exports.af0 = {
    url: "/api/ktt_chat/favorite_conv/cs_list_all",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.afz = {
    url: "/api/ktt_chat/favorite_conv/cs_mark",
    convertToCamel: !0
}, exports.am5 = {
    url: "/api/ktt_gateway/message/notice/all/conv",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.ajr = {
    url: "/api/prairie/chat/conv/mark_unread",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.af1 = Ap, exports.ane = bp, exports.anb = kp, exports.ul = Cp, exports.vg = Ip, 
exports.vf = Tp, exports.xv = Sp;

var Np = {
    url: "/api/ktt/papeete/personal/real_data",
    method: "GET",
    convertToCamel: !0
}, wp = {
    url: "/api/ktt_gateway/user/personal/rank_monitor",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, Dp = {
    url: "/api/ktt_group/activity/group/batch_delete",
    convertToCamel: !0,
    convertRequestToSnake: !0
}, Op = {
    url: "/api/ktt_group/activity/group/batch_real_delete",
    convertToCamel: !0,
    convertRequestToSnake: !0
};

function Lp() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.exclusiveGrowthRightsRestDays, r = void 0 === t ? 1 : t, a = e.todayMission, n = void 0 === a ? [] : a, o = e.sales, i = void 0 === o ? 0 : o, s = e.targetSales, c = void 0 === s ? 0 : s, u = "";
    if (r / 30 <= i / c) u = "计划进展顺利，请继续加油！"; else {
        var p = {}, l = {};
        n.forEach(function(e) {
            e.missionType === li.CREATE_GROUP && (p = e), e.missionType === li.GROUP_UV && (l = e);
        });
        var d = (0, z.qh)(p || {}, "doneValue"), h = (0, z.qh)(p || {}, "targetValue"), f = (0, 
        z.qh)(l || {}, "doneValue"), g = (0, z.qh)(l || {}, "targetValue");
        d < h && f < g ? u = "还差一点达到目标喔～再多学一些大咖经验吧～" : d < h ? u = "还差一点达到目标喔～再多开两个团吧～" : f < g && (u = "还差一点达到目标喔～再多分享团购到朋友圈吧～");
    }
    return u;
}

function Mp() {
    return Up.apply(this, arguments);
}

function Up() {
    return (Up = U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _, x, y;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, (0, z.fy)({
                    url: "/api/ktt_gameplay/leader_rights/query",
                    convertToCamel: !0
                });

              case 3:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 6;
                    break;
                }
                e.t0 = {};

              case 6:
                return t = e.t0, r = (0, z.qh)(t, "result.isShowed"), a = (0, z.qh)(t, "result.campaignType") || -1, 
                n = Math.ceil(W.default.price((0, z.qh)(t, "result.sales"), 100)), o = Math.ceil(W.default.price((0, 
                z.qh)(t, "result.targetSales"), 100)), i = (0, z.qh)(t, "result.todayMission") || [], 
                s = (0, z.qh)(t, "result.leaderSalesRightsInfoVolist") || [], c = s.filter(function(e) {
                    return e.rightsStatus === ui.CAN_RECEIVE;
                }), u = (0, z.qh)(c || [], "[0].rightsType") || -1, p = r && a === ci.FOURTH, l = (0, 
                z.qh)(t, "result.endTime"), e.next = 19, (0, z.gi)();

              case 19:
                return d = e.sent, h = Math.floor((l - d) / 864e5) || 1, f = 30 - h, g = d - l >= 0, 
                m = s.filter(function(e) {
                    return e.rightsStatus === ui.LOCK;
                }), v = W.default.price((0, z.qh)(m || [], "[0].salesTarget"), 100), _ = Math.ceil(v - n), 
                x = (0, z.qh)(t, "result.missionCount") || 0, y = (0, z.qh)(t, "result.missionTarget") || 0, 
                e.abrupt("return", {
                    sales: n,
                    targetSales: o,
                    todayMission: i,
                    currentUnreceiveType: u,
                    isShowExclusiveGrowthEntry: p,
                    exclusiveGrowthRightsRestDays: f,
                    leaderSalesRightsInfoVolist: s,
                    nextLevelGmvDiff: _ >= 0 ? _ : 0,
                    hadLockRights: m.length > 0,
                    missionCount: x,
                    missionTarget: y,
                    hadActivityEnd: g,
                    encourageText: Lp({
                        exclusiveGrowthRightsRestDays: f,
                        todayMission: i,
                        sales: n,
                        targetSales: o
                    })
                });

              case 31:
                return e.prev = 31, e.t1 = e.catch(0), e.abrupt("return", ((0, z.hp)({
                    e: e.t1,
                    msg: "query exclusive growth rights failed"
                }), {
                    sales: 0,
                    targetSales: 0,
                    todayMission: [],
                    currentUnreceiveType: -1,
                    isShowExclusiveGrowthEntry: !1,
                    exclusiveGrowthRightsRestDays: 1,
                    leaderSalesRightsInfoVolist: [],
                    nextLevelGmvDiff: 0,
                    hadLockRights: !1,
                    missionCount: 0,
                    missionTarget: 0,
                    hadActivityEnd: !1,
                    encourageText: "请继续加油！"
                }));

              case 34:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 0, 31 ] ]);
    }))).apply(this, arguments);
}

function qp(e) {
    return Gp.apply(this, arguments);
}

function Gp() {
    return (Gp = U(M.default.mark(function e(t) {
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, z.fy)({
                    url: "/api/ktt_gateway/business/statistics/supply_reputation/data/v2",
                    convertToCamel: !0,
                    noErrorToast: !0,
                    data: {
                        user_no: t
                    }
                });

              case 2:
                if (e.t0 = e.sent, e.t0) {
                    e.next = 5;
                    break;
                }
                e.t0 = {};

              case 5:
                return e.abrupt("return", e.t0);

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Bp() {
    return (Bp = U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = c.length > 0 && void 0 !== c[0] ? c[0] : "") {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                return e.next = 5, (0, z.fy)(Y(Y({}, z.kz), {}, {
                    data: {
                        site_no: t
                    }
                }));

              case 5:
                (r = e.sent) && r.result ? (a = r.result, n = a.lat, o = void 0 === n ? "" : n, 
                i = a.lng, s = void 0 === i ? "" : i, o && s ? wx.openLocation({
                    latitude: +o,
                    longitude: +s,
                    fail: function() {
                        (0, z.ri)({
                            title: "请稍后重试",
                            icon: "none"
                        }), (0, z.hp)({
                            msg: "wx openLoaction fail"
                        });
                    }
                }) : (0, z.ri)({
                    title: "暂未查到相关地址",
                    icon: "none"
                })) : ((0, z.ri)({
                    title: "请稍后重试",
                    icon: "none"
                }), (0, z.hp)({
                    msg: "get openLoaction lat and lng fail"
                }));

              case 7:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.tr = {
    page_sn: 70183,
    page_name: "ktt_chat_center"
}, exports.ub = {
    page_sn: 100728,
    page_name: "ktt_create_group"
}, exports.t6 = {
    page_sn: 100668,
    page_name: "ktt_complex_order_list"
}, exports.ahh = {
    url: "/api/ktt_gateway/user/biz/train/course/query",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.aa7 = Op, exports.aa6 = Dp, exports.akw = wp, exports.akx = Np, exports.am0 = {
    url: "/api/ktt_gameplay/star/leader/query/schedule/detail",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.alx = {
    url: "/api/ktt_group/activity/tab/query",
    convertToCamel: !0,
    noErrorToast: !0
}, exports.aat = {
    url: "/api/ktt/business/follower/admin/proxy",
    method: "GET"
}, exports.alj = {
    url: "/api/ktt/fee_back/status/v2",
    method: "GET",
    convertToCamel: !0,
    noErrorToast: !0
};

var $p = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = e || {}, a = r.error_payload, n = r.errorCode, o = r.errorMsg;
    return t[n] || a && a.view_object && a.view_object.title || (!n && o ? "请求异常，请重试" : null) || z.hq[n] || o || "系统错误";
};

exports.aic = $p;

var Fp = function() {
    function e(t) {
        G(this, e), this.appId = "", this.orderSn = "", this.createType = "", this.prepayRes = null, 
        this.prepayErrorCodeMap = {}, this.customPrepayErrHandle = !1, this.init(t);
    }
    var t, r, a;
    return B(e, [ {
        key: "init",
        value: function(e) {
            var t = e.orderSn, r = e.createType, a = e.prepayErrorCodeMap, n = e.customPrepayErrHandle;
            this.orderSn = t, this.createType = r, this.prepayErrorCodeMap = a || {}, this.customPrepayErrHandle = !!n;
        }
    }, {
        key: "prepayRequest",
        value: function() {
            return (0, z.fy)({
                url: this.createType === z.bu.MULTI ? z.e9.url : z.op.url,
                method: z.op.method,
                noErrorToast: !0,
                params: {
                    pay_app_id: this.appId,
                    order_sn: this.orderSn,
                    parent_order_sn: this.orderSn,
                    version: 3
                }
            });
        }
    }, {
        key: "prePay",
        value: (a = U(M.default.mark(function e() {
            var t, r;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return this.prepayRes = null, e.prev = 1, e.next = 4, this.prepayRequest();

                  case 4:
                    return t = e.sent, e.abrupt("return", (t.timeStamp = t.timeStamp + "", Promise.resolve(t)));

                  case 8:
                    return e.prev = 8, e.t0 = e.catch(1), r = $p(e.t0, this.prepayErrorCodeMap), e.abrupt("return", ((0, 
                    z.hp)({
                        msg: "prepay fail",
                        e: e.t0
                    }), (0, z.l3)(), !this.customPrepayErrHandle && (0, z.ri)({
                        title: r
                    }), e.t0.prePayErrMsg = r, Promise.reject(e.t0)));

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 1, 8 ] ]);
        })), function() {
            return a.apply(this, arguments);
        })
    }, {
        key: "pay",
        value: (r = U(M.default.mark(function e() {
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return r.apply(this, arguments);
        })
    }, {
        key: "start",
        value: (t = U(M.default.mark(function e() {
            var t;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return (0, z.rg)({
                        title: "处理中"
                    }), e.prev = 1, e.next = 4, this.prePay();

                  case 4:
                    return this.prepayRes = e.sent, e.next = 7, this.pay();

                  case 7:
                    return t = e.sent, e.abrupt("return", ((0, z.l3)(), Promise.resolve(t)));

                  case 11:
                    return e.prev = 11, e.t0 = e.catch(1), e.abrupt("return", ((0, z.hp)({
                        msg: "pay fail finally",
                        e: e.t0
                    }), Promise.reject(e.t0)));

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 1, 11 ] ]);
        })), function() {
            return t.apply(this, arguments);
        })
    } ]), e;
}();

exports.acg = Fp;

var Hp = K.utils.sleep, jp = function(e) {
    H(a, Fp);
    var t, r = j(a);
    function a() {
        return G(this, a), r.apply(this, arguments);
    }
    return B(a, [ {
        key: "init",
        value: function(e) {
            $(F(a.prototype), "init", this).call(this, e);
            var t = e.useNewPay, r = void 0 === t || t, n = e.appId, o = void 0 === n ? "" : n;
            this.appId = o || (r ? z.fu.newPayAppId : z.fu.payAppId);
        }
    }, {
        key: "pay",
        value: (t = U(M.default.mark(function e() {
            var t = this;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", ((0, z.l3)(), new Promise(function(e, r) {
                        var a = null;
                        wx.requestPayment(Y(Y({}, t.prepayRes), {}, {
                            success: function(t) {
                                a = "success", e(t);
                            },
                            fail: function(e) {
                                a = "fail", (0, z.hp)({
                                    name: "requestPayment fail",
                                    msg: JSON.stringify(e)
                                }), "requestPayment:fail cancel" !== e.errMsg && (0, z.ri)({
                                    title: "支付失败，请稍后重试",
                                    icon: "none"
                                }), r(e);
                            },
                            complete: function(e) {
                                Hp(200).then(function(t) {
                                    a || ((0, z.hp)({
                                        name: "requestPayment complete",
                                        msg: JSON.stringify(e)
                                    }), (0, z.ri)({
                                        title: "支付失败，请稍后重试",
                                        icon: "none"
                                    }), r(e));
                                });
                            }
                        }));
                    })));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return t.apply(this, arguments);
        })
    } ]), a;
}();

exports.ach = jp;

var Vp = function() {
    function e(t) {
        G(this, e), this.uniqueKey = t.uniqueKey, this.listMaps = {};
    }
    return B(e, [ {
        key: "reset",
        value: function() {
            this.listMaps = {};
        }
    }, {
        key: "formatListData",
        value: function(e) {
            var t = this, r = e;
            return this.uniqueKey && (r = r.reduce(function(e, r) {
                return t.listMaps[r[t.uniqueKey]] || (t.listMaps[r[t.uniqueKey]] = !0, e.push(r)), 
                e;
            }, [])), r;
        }
    } ]), e;
}();

exports.acj = Vp;

var Yp = {
    getLastCommentAnony: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.getCloudStorage(Fa.lastCommentAnony).catch(z.hm);

                  case 2:
                    return r = t.sent, t.abrupt("return", (e.lastCommentAnony = !r || !("lastCommentAnony" in r) || !!r.lastCommentAnony, 
                    e.lastCommentAnony));

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    setLastCommentAnony: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (e === t.lastCommentAnony) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return", t.setCloudStorage({
                        scene: Fa.lastCommentAnony,
                        data: {
                            lastCommentAnony: e
                        }
                    }).then(function(r) {
                        return t.lastCommentAnony = e, r;
                    }).catch(z.hm));

                  case 2:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    }
}, zp = Y({
    mixins: [ pa ]
}, Yp), Wp = (0, z.gg)({
    behaviors: [ la ],
    methods: Yp
}), Kp = (q(P = {}, Pt.page_sn, 1), q(P, wt.page_sn, 2), P), Jp = {
    queryActivityBanner: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l, d, h, f, g;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = +((null === (r = e.$currentPage) || void 0 === r ? void 0 : r.pageProperties.page_sn) || Pt.page_sn), 
                    t.next = 3, e.$baseRequest(Y(Y({}, z.oy), {}, {
                        data: {
                            location_id: Kp[o]
                        }
                    })).catch(z.hm);

                  case 3:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 6;
                        break;
                    }
                    t.t0 = {};

                  case 6:
                    if (i = t.t0, !(0, z.ff)()) {
                        t.next = 9;
                        break;
                    }
                    return t.abrupt("return");

                  case 9:
                    s = (null === (a = e.data.$gray) || void 0 === a ? void 0 : a.newBannerStyle) || {}, 
                    c = s.hit2, u = s.bannerOnly, p = void 0 !== u && u, l = s.banner, d = l || (null === (n = i.result) || void 0 === n ? void 0 : n.bannerVolist) || [], 
                    h = !(o !== Pt.page_sn || !c), f = (0, z.f2)(function() {
                        return JSON.parse(z.f3.getStorageSync(z.ct.closedActivityBanners));
                    }, []), g = d.filter(function(e) {
                        return -1 === f.indexOf(e.id);
                    }), e.setData({
                        activityBanners: g,
                        isHitNewStyle: h,
                        isHitBannerOnly: p,
                        isBannerInHeader: (h || p) && g.length > 0
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    }
}, Xp = Y(Y({
    data: {
        activityBanners: [],
        isHitNewStyle: !1,
        isHitBannerOnly: !1,
        isBannerInHeader: !1,
        $gray: {
            newBannerStyle: {
                hit2: !1,
                bannerOnly: !1,
                banner: null
            }
        }
    }
}, Jp), {}, {
    onLoad: function() {
        var e = this;
        z.f9.listen(z.f1.closeBanner, function(t) {
            var r = e.data, a = r.activityBanners, n = r.isHitNewStyle, o = r.isHitBannerOnly, i = a.filter(function(e) {
                return e.id !== t;
            });
            e.setData({
                activityBanners: i,
                isBannerInHeader: (n || o) && i.length > 0
            });
        });
    }
}), Qp = (0, z.gg)({
    methods: Y({
        onSign: function() {
            var e = this;
            z.f9.listen(z.f1.closeBanner, function(t) {
                var r = e.data, a = r.activityBanners, n = r.isHitNewStyle, o = r.isHitBannerOnly, i = a.filter(function(e) {
                    return e.id !== t;
                });
                e.setData({
                    activityBanners: i,
                    isBannerInHeader: (n || o) && i.length > 0
                });
            });
        }
    }, Jp)
}), Zp = {
    isPullNewNeedLanding: function() {
        return this.$query[z.gf.provinceId] && !this.$query[z.gf.noLanding];
    },
    checkJump: function() {
        var e = this.$query[z.gf.provinceId];
        return !(!e || this.$query[z.gf.noLanding] || !this.pageProperties || this.pageProperties.page_sn !== Pt.page_sn || ((0, 
        z.n7)({
            url: z.ob.pullNewLanding,
            params: q({}, z.gf.provinceId, e)
        }), 0));
    },
    bindAmsProvince: function() {
        var e = this.$query[z.gf.provinceId];
        e && (this.checkJump() || (0, z.fy)(Y(Y({}, z.qn), {}, {
            data: {
                provinceId: e
            }
        })).catch(z.hm));
    }
}, el = (0, z.gg)({
    methods: Zp
}), tl = {
    showPublicPraise: !1,
    publicPraiseInfo: {}
}, rl = {
    onLoad: function() {
        var e;
        (null === (e = this.pageProperties) || void 0 === e ? void 0 : e.page_name) === Pt.page_name && this.checkIsJump && this.checkIsJump() || this.onHelpSellPublicPraiseLoadLogic();
    },
    onHelpSellPublicPraiseLoadLogic: function() {
        this.checkFrequencyShow([ z.aw.showHelpSellPublicPraiseTips, z.aw.showPublicPraisePopup ]);
    },
    onUnload: function() {
        this.timer && clearTimeout(this.timer), this.data.freqShowStore && this.data.freqShowStore[z.aw.showHelpSellPublicPraiseTips] && this.hideFrequencyShow(z.aw.showHelpSellPublicPraiseTips);
    },
    togglePublicPraiseDialog: function(e) {
        var t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s, c, u;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (a = t.data, n = a.showPublicPraise, o = a.freqShowStore, i = void 0 === o ? {} : o, 
                    s = {}, t.standardLogClick(e), n || i[z.aw.showPublicPraisePopup]) {
                        r.next = 7;
                        break;
                    }
                    return c = (0, z.jo)(e), u = c.userNo, r.next = 6, qp(u);

                  case 6:
                    s = r.sent;

                  case 7:
                    Object.hasOwnProperty.call(s, "success") && !s.success || (i[z.aw.showPublicPraisePopup] && n && t.hideFrequencyShow(z.aw.showPublicPraisePopup), 
                    i[z.aw.showHelpSellPublicPraiseTips] && n && t.hideFrequencyShow(z.aw.showHelpSellPublicPraiseTips), 
                    t.setData({
                        showPublicPraise: !n,
                        publicPraiseInfo: s.result || {}
                    }));

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    }
}, al = Y({
    mixins: [ oo, Xn ],
    data: Y({}, tl)
}, rl), nl = O(rl, [ "onLoad", "onUnload" ]), ol = (0, z.gg)({
    behaviors: [ io, Qn ],
    onSign: function() {
        var e;
        (null === (e = this.pageProperties) || void 0 === e ? void 0 : e.page_name) === Pt.page_name && this.checkIsJump && this.checkIsJump() || this.onHelpSellPublicPraiseLoadLogic();
    },
    detached: function() {
        this.timer && clearTimeout(this.timer), this.data.freqShowStore && this.data.freqShowStore[z.aw.showHelpSellPublicPraiseTips] && this.hideFrequencyShow(z.aw.showHelpSellPublicPraiseTips);
    },
    data: Y({}, tl),
    methods: Y({}, nl)
}), il = {
    queryNewcomerFreeActivityEntrance: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type, r = void 0 === t ? Fa.newcomerFreeActivityTip : t, a = e.needKeepToast, n = void 0 !== a && a;
        return this.$baseRequest({
            url: "/api/ktt_gateway/help_sell/query_junior_cap_act_entrance",
            convertToCamel: !0,
            convertRequestToSnake: !0,
            noErrorToast: !0,
            logFilter: z.ig,
            data: {
                type: r,
                needKeepToast: n
            }
        }).catch(z.hm).then(function(e) {
            return (e || {}).result || {};
        });
    },
    closeNewcomerFreeActivityEntrance: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.type, r = void 0 === t ? Fa.newcomerFreeActivityTip : t;
        return this.setCloudStorage({
            scene: r,
            data: 1
        }).catch(z.hm);
    }
}, sl = (0, z.gg)({
    behaviors: [ la ],
    methods: il
}), cl = Y({
    mixins: [ pa ]
}, il), ul = {
    loadNewcomerFreeActivities: function() {
        var e = this;
        return this.$baseRequest({
            url: "/api/ktt_group/activity_feeds/query_newbie_official_help_sell_feeds",
            convertToCamel: !0,
            convertRequestToSnake: !0,
            noErrorToast: !0
        }).then(function(t) {
            return ((0, z.qh)(t || {}, "result.activityFeedList") || []).map(e.formatNewcomerFreeActivity).sort(function(e, t) {
                return +!t.isCopyHelpSelled - +!e.isCopyHelpSelled;
            });
        });
    },
    formatNewcomerFreeActivity: function(e) {
        var t, r, a = e.activityNo, n = e.activityTitle, o = e.goodsPicList, i = e.goodsMaxPrice, s = e.goodsMinPrice, c = e.goodsMaxCommissionPrice, u = e.participateCount, p = e.helpSellCopyActivity || {}, l = p.status, d = p.helpSellActivityNo;
        return {
            activityNo: a,
            activityTitle: n,
            goodsPic: (0, z.qh)(o || [], "0.picUrl") || (0, z.jx)(),
            goodsPricesRangeYuan: (t = s, r = i, r === t ? W.default.price(r, 100) : "".concat(W.default.price(t, 100), "~").concat(W.default.price(r, 100))),
            participateCount: +(u || 0),
            maxGoodsCommissionYuan: W.default.price(c, 100),
            isCopyHelpSelled: l === z.s.HAS_SELL,
            helpSellActivityNo: d,
            isNewbieOfficialHelpSell: !0,
            helpSellRelationType: mt.NEW_GROUP
        };
    }
}, pl = (0, z.gg)({
    methods: ul
});

exports.akc = pl, exports.act = cl, exports.akb = sl, exports.abc = ol, exports.ajy = exports.acs = al, 
exports.abj = el, exports.acr = Zp, exports.aa1 = Qp, exports.acq = Xp, exports.aay = Wp, 
exports.acp = zp;

var ll = Y({}, ul);

exports.acu = ll;

var dl = {
    ALL: 0,
    LAST_THREE_MONTH: 4,
    LAST_SIX_MONTH: 5,
    LAST_ONE_YEAR: 6,
    TODAY: 1,
    YESTERDAY: 2,
    THIS_WEEK: 3
}, hl = {
    ALL: 1,
    LAST_THREE_MONTH: 2,
    LAST_SIX_MONTH: 3,
    LAST_ONE_YEAR: 4
}, fl = (q(R = {}, hl.ALL, dl.ALL), q(R, hl.LAST_THREE_MONTH, dl.LAST_THREE_MONTH), 
q(R, hl.LAST_SIX_MONTH, dl.LAST_SIX_MONTH), q(R, hl.LAST_ONE_YEAR, dl.LAST_ONE_YEAR), 
R), gl = [ {
    title: "全部",
    displayLabel: "全部日期",
    type: dl.ALL
}, {
    title: "近3个月",
    displayLabel: "近3个月",
    type: dl.LAST_THREE_MONTH
}, {
    title: "近6个月",
    displayLabel: "近6个月",
    type: dl.LAST_SIX_MONTH
}, {
    title: "近1年",
    displayLabel: "近1年",
    type: dl.LAST_ONE_YEAR
}, {
    title: "本日",
    displayLabel: "本日",
    type: dl.TODAY
}, {
    title: "昨日",
    displayLabel: "昨日",
    type: dl.YESTERDAY
}, {
    title: "本周",
    displayLabel: "本周",
    type: dl.THIS_WEEK
} ], ml = "2019/01/01 00:00:00", vl = 864e5, _l = {
    url: "/api/ktt_order/business/search/search_order_date_range",
    convertToCamel: !0,
    convertRequestToSnake: !0,
    noErrorToast: !0
}, xl = function() {
    return new Date(new Date().setHours(0, 0, 0, 0)).getTime();
}, yl = function(e) {
    var t = xl(), r = xl();
    switch (e) {
      case dl.ALL:
        return {
            startDate: t = new Date(ml).getTime(),
            endDate: r = xl() + vl
        };

      case dl.LAST_THREE_MONTH:
        return {
            startDate: t = xl() - 7776e6,
            endDate: r = xl() + vl - 1
        };

      case dl.LAST_SIX_MONTH:
        return {
            startDate: t = xl() - 15552e6,
            endDate: r = xl() + vl - 1
        };

      case dl.LAST_ONE_YEAR:
        return {
            startDate: t = xl() - 31536e6,
            endDate: r = xl() + vl - 1
        };

      case dl.TODAY:
        return {
            startDate: t = xl(),
            endDate: r = t + vl - 1
        };

      case dl.YESTERDAY:
        return {
            startDate: t = xl() - vl,
            endDate: r = t + vl - 1
        };

      case dl.THIS_WEEK:
        return {
            startDate: t - ((new Date().getDay() || 7) - 1) * vl,
            endDate: t + (7 - (new Date().getDay() || 7)) * vl + vl - 1
        };

      default:
        return {
            startDate: t,
            endDate: r
        };
    }
}, Sl = function(e) {
    var t;
    return "number" == typeof e ? Y(Y({
        timeLabel: (null === (t = gl.find(function(t) {
            return t.type === e;
        })) || void 0 === t ? void 0 : t.displayLabel) || ""
    }, yl(e)), {}, {
        startDateStr: "",
        endDateStr: ""
    }) : {
        timeLabel: "",
        startDate: null,
        endDate: null,
        startDateStr: "",
        endDateStr: ""
    };
}, El = Y({
    changeTimePanelVisible: !1
}, Sl()), Tl = {
    changeTimePanel: null
}, Il = {
    resetDefaultDate: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest(Y({}, _l)).catch(z.hm);

                  case 2:
                    o = t.sent, i = (null === (r = null == o ? void 0 : o.result) || void 0 === r ? void 0 : r.dateRange) && fl[null === (a = null == o ? void 0 : o.result) || void 0 === a ? void 0 : a.dateRange] || dl.LAST_THREE_MONTH, 
                    e.setData(Sl(i)), e.changeTimePanel || (e.changeTimePanel = e.selectComponent("#change-time-panel") || null), 
                    null === (n = e.changeTimePanel) || void 0 === n || n.resetData(i);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getDateParams: function() {
        var e = this.data;
        return {
            startDate: e.startDate,
            endDate: e.endDate
        };
    },
    showTimePanel: function() {
        this.setData({
            changeTimePanelVisible: !0
        });
    },
    closeTimePanel: function() {
        this.setData({
            changeTimePanelVisible: !1
        });
    },
    onTimeChange: function(e) {
        var t = (0, z.jo)(e) || {}, r = t.displayLabel, a = t.startDate, n = t.endDate, o = t.startDateStr, i = void 0 === o ? "" : o, s = t.endDateStr, c = void 0 === s ? "" : s;
        this.setData({
            timeLabel: r || "",
            startDate: a,
            endDate: n,
            startDateStr: i,
            endDateStr: c
        });
    }
}, Cl = Y(Y({
    data: El
}, Tl), Il);

exports.ajz = Cl, exports.ahj = Sl, exports.ahk = yl, exports.alh = _l, exports.yh = vl, 
exports.xe = ml, exports.uh = gl, exports.v0 = fl, exports.vz = hl, exports.uk = dl;

var kl = (0, z.gg)({
    data: El,
    initProperties: Tl,
    methods: Il
});

exports.acv = kl;

exports._5 = {
    orderCard: {
        addExpressBtn: 5308112,
        foldAmountBtn: 5308121,
        orderDetailBtn: 4725680,
        moreOperationBtn: 5308122,
        copyWholeOrderBtn: 5308123,
        copyOrderFilterCancelBtn: 5308124,
        orderCardEle: 5308044,
        supplyPurchaseOrderBtn: 6165822
    },
    shipGuide: {
        learnBtn: 5307754
    },
    pushReceiveBtn: 7884930
}, exports._6 = {
    submitRefundBtn: 5307763,
    callOwnerBtn: 5307762,
    groupBuyShareBtn: 5307761,
    shareOrderDetailBtn: 5307760,
    publishShareOrderBtn: 5307759,
    closeOrderBtn: 5307758,
    goPayBtn: 5307757,
    closeOrderReason: 5307756,
    buyOneMoreOrder: 5489513,
    orderCardEle: 5307753,
    orderAreaEle: 7479756,
    confirmReceiveBtn: 5715259,
    removeOrderBtn: 5978065
}, exports.ts = {
    isB: 4820826,
    isC: 4820827,
    isS: 4820828
};

var bl = function(e) {
    H(r, Re);
    var t = j(r);
    function r() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return G(this, r), t.call(this, {
            requestConfig: Y({
                url: "/api/ktt_rec/rec_feeds/query_homepage_video_feeds",
                auth: !1,
                noErrorToast: !0,
                convertToCamel: !0,
                convertRequestToSnake: !0
            }, e),
            useListId: !0,
            pageSize: 20,
            name: "RecFeedsHomePageModel"
        });
    }
    return B(r, [ {
        key: "formatList",
        value: function(e) {
            var t = e.videoFeedsList || [];
            return 1 === this.pageNumber && 0 === t.length && (0, z.ev)({
                type: z.u.FEEDS_EMPTY,
                tags: {
                    feedsEmpty: "discover"
                }
            }), t;
        }
    } ]), r;
}();

exports.acx = bl;

var Al = {
    imgUrl: (0, z.jm)("ktt/nv.png.slim.png"),
    title: "超值专享团",
    linkUrl: z.ob.newcomerFreeCreate,
    pageElSn: 6190393,
    needImpr: !0
}, Pl = [ {
    imgUrl: (0, z.jm)("ktt/nw.png.slim.png"),
    needHideVisitorType: 3,
    title: "100元启动金",
    linkUrl: z.ob.growthBenefit,
    pageElSn: 4978397
}, {
    imgUrl: (0, z.jm)("ktt/nx.png.slim.png"),
    title: "团长必修课",
    linkUrl: z.ob.captainRequireCourses,
    pageElSn: 6114979,
    needImpr: !0,
    params: q({}, z.gf.autoPlay, 1)
}, {
    imgUrl: (0, z.jm)("ktt/ny.png.slim.png"),
    title: "专属经营方案",
    linkUrl: z.ob.exclusivePlan,
    pageElSn: 4978395
}, {
    imgUrl: (0, z.jm)("ktt/nz.png.slim.png"),
    title: "大牛生意经",
    linkUrl: z.ob.topBusinessExperience,
    pageElSn: 4978396
} ], Rl = {
    showNewcomerFreeActivities: !1,
    newcomerFreeActivityList: []
}, Nl = {
    onLoad: function(e) {
        var t = this;
        z.f9.listen(z.f1.newcomerFreeHelpSelled, function() {
            setTimeout(t.queryNewcomerFreeCreateEntrance, 600), t.loadNewcomerBenefitActivities && t.loadNewcomerBenefitActivities();
        });
    },
    onUnload: function() {
        z.f9.cancel(z.f1.newcomerFreeHelpSelled);
    },
    queryNewcomerFreeCreateEntrance: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.queryNewcomerFreeActivityEntrance({
                        type: Fa.newcomerFreeCreateIndexEntry
                    });

                  case 2:
                    if (r = t.sent, a = r.show, n = r.hasCommunity, o = [], !a || n) {
                        t.next = 15;
                        break;
                    }
                    return t.next = 9, e.queryNewcomerFreeActivities();

                  case 9:
                    i = t.sent, s = i.noCopyHelpSelledList, c = i.rawList, o = s, u = a && !n && o.length > 0, 
                    e.setData({
                        newcomerFreeActivityList: u ? o : [],
                        showNewcomerFreeActivities: u,
                        rawNewcomerFreeActivityList: c,
                        businessEntries: a && n ? [ Al ].concat(Pl) : Pl
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    queryNewcomerFreeActivities: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.loadNewcomerFreeActivities().catch(z.hm);

                  case 2:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 5;
                        break;
                    }
                    t.t0 = [];

                  case 5:
                    return r = t.t0, t.abrupt("return", {
                        noCopyHelpSelledList: r.filter(function(e) {
                            return !e.isCopyHelpSelled;
                        }),
                        rawList: r
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    closeNewcomerFreeEntrance: function() {
        this.closeNewcomerFreeActivityEntrance({
            type: Fa.newcomerFreeCreateIndexEntry
        }), this.setData({
            showNewcomerFreeActivities: !1
        });
    }
};

exports.yc = {
    NONE: 0,
    NEW_USER: 1,
    SHOW_BUSINESS_MODULE: 2,
    SHOW_BUSINESS_MODULE_NO_NEW: 3,
    SHOW_NEWCOMER_BENEFIT: 4
}, exports.th = Pl, exports.yf = Al, exports._4 = "/api/ktt_gateway/activity/feeds/promoter/home_page";

var wl = Y({
    mixins: [ cl, ll ],
    data: Rl
}, Nl);

exports.acy = wl;

var Dl = O(Nl, [ "onLoad", "onUnload" ]), Ol = (0, z.gg)({
    behaviors: [ sl, pl ],
    data: Rl,
    detached: function() {
        z.f9.cancel(z.f1.newcomerFreeHelpSelled);
    },
    methods: Y({
        onSign: function() {
            var e = this;
            z.f9.listen(z.f1.newcomerFreeHelpSelled, function() {
                setTimeout(function() {
                    e.queryNewcomerFreeCreateEntrance();
                }, 600), e.loadNewcomerBenefitActivities && e.loadNewcomerBenefitActivities();
            });
        }
    }, Dl)
}), Ll = {
    CAPTAIN: 1,
    CUSTOMER: 0
}, Ml = {
    CAPTAIN: 1,
    CUSTOMER: 2
};

exports.xb = {
    1: "https://funimg.pddpic.com/wxappimg/548c39f6-a7f2-4b1f-a92b-980ad936d7a6.png.slim.png",
    2: "https://funimg.pddpic.com/wxappimg/cae4e9a5-6fad-4d5e-a4a0-7d165f1cfd39.png.slim.png",
    3: "https://funimg.pddpic.com/wxappimg/d47600ab-e952-43c1-9f7a-83579d8000fc.png.slim.png"
}, exports.aaf = {
    NONE: 0,
    HAS_OPENED: 1
}, exports.to = Ml, exports.tp = Ll, exports.aka = Ol;

exports.ac7 = {
    dialogImpr: 5239146,
    useCoupon: 5239148
}, exports.ac6 = {
    dialog: 4552259,
    inviteBtnEle: 4552260
}, exports.ac5 = {
    dialog: 4552168,
    inviteBtnEle: 4552169
};

var Ul = {
    MORE_OPERATION: "more_operation",
    SUPPLY_ORDER: "supply_order",
    COPY_ORDER: "copy_order",
    CANCEL_ORDER: "cancel_order",
    REFUND: "refund",
    PROCESS_REFUND: "process_refund",
    REFUND_DETAIL: "refund_detail",
    ORDER_DETAIL: "order_detail",
    OPERATION_LOG: "operation_log"
}, ql = (q(N = {}, Ul.MORE_OPERATION, {
    title: "更多操作",
    sort: 0
}), q(N, Ul.ORDER_DETAIL, {
    title: "订单详情",
    sort: 1
}), q(N, Ul.OPERATION_LOG, {
    title: "操作记录",
    sort: 2
}), q(N, Ul.SUPPLY_ORDER, {
    title: "进货单",
    sort: 3,
    icon: z.oc,
    preIcon: {
        src: z.oc,
        width: 32,
        height: 32,
        marginRight: 4
    }
}), q(N, Ul.COPY_ORDER, {
    title: "复制订单",
    sort: 4
}), q(N, Ul.CANCEL_ORDER, {
    title: "取消订单",
    sort: 5
}), q(N, Ul.REFUND, {
    title: "退款",
    sort: 6
}), q(N, Ul.PROCESS_REFUND, {
    title: "处理售后",
    sort: 7,
    class: "green"
}), q(N, Ul.REFUND_DETAIL, {
    title: "售后详情",
    sort: 8
}), N), Gl = {
    appId: 23,
    bizType: 230002,
    clientType: 4,
    chatTypeId: 13,
    serviceUrl: z.fu.domain
}, Bl = {
    LIVE: 1,
    HELP_PROMOTION: 2
}, $l = (q(w = {}, Bl.LIVE, {
    showRole: "isC"
}), q(w, Bl.HELP_PROMOTION, {
    showRole: "isB"
}), w), Fl = {
    msgQueue: [],
    getNowTime: function() {
        return Date.now();
    },
    getZeroTime: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, a = new Date(this.getNowTime()), n = a.getFullYear(), o = a.getMonth(), i = a.getDate(), s = new Date(n, o, i, e, t, r);
        return Number(s);
    },
    formateDate: function(e, t) {
        var r = this.getZeroTime() / 1e3, a = r - 86400, n = r - 172800, o = r - 604800;
        if (e) {
            if (e > r) return this.getFormateDate(1e3 * e, "hh:mm");
            if (e > a) return "昨天";
            if (e > n) return "前天";
            if (e > o) {
                var i = new Date(1e3 * e).getDay();
                return "星期" + "天一二三四五六".charAt(i);
            }
            return this.getFormateDate(1e3 * e, t);
        }
        return "";
    },
    getFormateDate: function(e, t) {
        e || (e = this.getNowTime());
        var r = new Date(e), a = r.getFullYear().toString(), n = ("0" + (r.getMonth() + 1)).slice(-2), o = ("0" + r.getDate()).slice(-2), i = ("0" + r.getHours()).slice(-2), s = ("0" + r.getMinutes()).slice(-2), c = ("0" + r.getSeconds()).slice(-2);
        return t ? t.replace(/(Y+)/g, function(e) {
            var t = e.length;
            return t ? a.slice(-t) : "";
        }).replace(/(M+)/g, function(e) {
            var t = e.length;
            return t ? n.slice(-t) : "";
        }).replace(/(D+)/g, function(e) {
            var t = e.length;
            return t ? o.slice(-t) : "";
        }).replace(/(h+)/g, function(e) {
            var t = e.length;
            return t ? i.slice(-t) : "";
        }).replace(/(m+)/g, function(e) {
            var t = e.length;
            return t ? s.slice(-t) : "";
        }).replace(/(s+)/g, function(e) {
            var t = e.length;
            return t ? c.slice(-t) : "";
        }) : [ a, n, o ].join("/") + " " + i + ":" + s;
    },
    getTimeStamp: function(e, t) {
        this.msgQueue = t || [];
        for (var r = (0, z.g1)(e), a = 0, n = 0; n < e.length; n++) {
            var o = this.exceedTime(e, n);
            o && (r.splice(n + a, 0, {
                content: this.formateDate(o),
                type: 20,
                direction: !0,
                ts: o,
                id: "t".concat(o)
            }), a++), this.msgQueue.push(e[n]);
        }
        return r;
    },
    handleNewMsgImgSize: function(e) {
        var t = 280;
        if (e && 1 === e.type) if (e.info.height > e.info.width) {
            if (e.info && e.info.height > t) {
                var r = t / e.info.height * e.info.width;
                e.info.height = t, e.info.width = r;
            }
        } else if (e.info && e.info.width > t) {
            var a = t / e.info.width * e.info.height;
            e.info.height = a, e.info.width = t;
        }
        return e;
    },
    exceedTime: function(e, t) {
        if (0 === this.msgQueue.length) {
            var r = e[t].message || e[t];
            return r.ts ? parseInt(r.ts) : new Date().getTime() / 1e3;
        }
        var a = this.msgQueue[this.msgQueue.length - 1], n = a.message || a, o = e[t].message || e[t], i = 0 === t ? n : e[t - 1].message || e[t - 1], s = parseInt(o.ts);
        return s - parseInt(i.ts) > 180 && s;
    },
    getMinutes: function(e) {
        var t = new Date(1e3 * e), r = t.getHours(), a = t.getMinutes();
        return (r < 10 ? "0".concat(r) : r) + ":" + (a < 10 ? "0".concat(a) : a);
    }
}, Hl = {
    userTagsMap: {}
}, jl = {
    batchJudgeUserTag: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n, o, i, s;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (0 !== (a = e.length > 0 && void 0 !== e[0] ? e[0] : []).length) {
                        r.next = 3;
                        break;
                    }
                    return r.abrupt("return");

                  case 3:
                    return r.next = 5, t.$baseRequest(Y(Y({}, Rp), {}, {
                        data: {
                            user_no_list: a
                        }
                    })).catch(z.hm);

                  case 5:
                    if (r.t0 = r.sent, r.t0) {
                        r.next = 8;
                        break;
                    }
                    r.t0 = {};

                  case 8:
                    n = r.t0, o = n.result, i = (o = void 0 === o ? {} : o).user_no_tags_map, s = void 0 === i ? {} : i, 
                    t.setData({
                        userTagsMap: Y(Y({}, t.data.userTagsMap), s)
                    });

                  case 13:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    }
}, Vl = Y({
    data: Y({}, Hl)
}, jl), Yl = (0, z.gg)({
    data: Y({}, Hl),
    methods: Y({}, jl)
}), zl = {
    recordScrollTop: (0, z.g9)(function(e) {
        this.setData({
            showScrollToTop: e >= 1800
        });
    }, 100),
    scrollToTop: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
}, Wl = (0, z.gg)({
    data: {
        showScrollToTop: !1
    },
    methods: Y({}, zl)
}), Kl = {
    isFetching: !1,
    pageNumber: void 0,
    handleSearch: dc(function(e) {
        var t = (0, z.jo)(e).value;
        if (t) this.pageNumber = 1, this.setData({
            searchValue: t,
            conversations: [],
            isLoadingLeaderGroup: !1,
            hasMoreLeaderGroup: !0
        }), this.loadMoreGroup(); else {
            var r = this.data.isB;
            this.pageNumber = 1, this.setData({
                conversations: [],
                hasMoreLeaderGroup: !0,
                isLoadingLeaderGroup: !1,
                searchValue: ""
            });
            var a = r ? "isB" : "isC";
            this._handleTabChange(a);
        }
    }, 1e3, {
        trailing: !0
    }),
    loadMoreGroup: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data, a = r.isB, n = r.searchValue, o = r.isLoadingLeaderGroup, i = r.hasMoreLeaderGroup, 
                    s = {
                        url: "/api/ktt_gateway/business/follow/common_search",
                        convertRequestToSnake: !0,
                        convertToCamel: !0,
                        noErrorToast: !0,
                        data: {
                            pageNumber: e.pageNumber,
                            pageSize: 10,
                            keyword: n,
                            searchType: 2
                        }
                    }, c = Y(Y({}, z.mw), {}, {
                        noNeedProxy: !0,
                        data: {
                            pageNumber: e.pageNumber,
                            pageSize: 10,
                            keyword: n
                        }
                    }), t.prev = 1, !o && i) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return");

                  case 4:
                    return e.setData({
                        isLoadingLeaderGroup: !0
                    }), t.next = 7, e.$baseRequest(a ? s : c);

                  case 7:
                    u = t.sent, p = a ? (0, z.qh)(u, "result.followers") : u.result, l = e.formatGroupList(p), 
                    e.pageNumber++, e.setData({
                        isLoadingLeaderGroup: !1,
                        hasMoreLeaderGroup: 10 === p.length,
                        conversations: 1 === e.pageNumber ? l : e.data.conversations.concat(l),
                        noConversations: 1 === e.pageNumber && !l.length
                    }), t.next = 16;
                    break;

                  case 13:
                    t.prev = 13, t.t0 = t.catch(1), e.setData({
                        isLoadingLeaderGroup: !1
                    });

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 13 ] ]);
        }))();
    },
    formatGroupList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = arguments.length > 1 ? arguments[1] : void 0;
        return e.map(function(e) {
            return {
                convUid: e.userNo,
                message: {
                    convUserType: "isB" === t ? 10 : 9
                },
                convInfo: {
                    name: e.nickName || e.nickname,
                    avatar: e.avatar,
                    unreadCount: 0
                }
            };
        });
    }
}, Jl = O(Kl, [ "isFetching", "pageNumber" ]), Xl = (0, z.gg)({
    data: {
        isLoadingLeaderGroup: !1,
        hasMoreLeaderGroup: !0,
        searchValue: ""
    },
    methods: Jl,
    initProperties: {
        isFetching: !1,
        pageNumber: void 0
    }
}), Ql = {
    HANDLE: 1,
    AUTO: 2
}, Zl = (0, z.k5)(), ed = Zl.windowHeight, td = Zl.screenHeight, rd = {
    TRANSFER_MODE: Ql,
    transferMode: Ql.HANDLE,
    showTransferChatPanel: !1,
    transferChatSelected: [],
    transferSize: 50,
    hadSelectConvIdList: [],
    selectedChatStatus: "all",
    fetchSign: "",
    pageNum: 1,
    unreadHasMore: !1,
    tabBarHeight: td - ed
}, ad = {
    showSlideview: function(e) {
        var t = (0, z.jo)(e).productIndex, r = this.data.conversations[t] || {};
        r.show = !0, this.setData(q({}, "conversations[".concat(t, "]"), r));
    },
    hideSlideview: function(e) {
        var t = (0, z.jo)(e).productIndex, r = this.data.conversations[t] || {};
        r.show = !1, this.setData(q({}, "conversations[".concat(t, "]"), r));
    },
    hideAllSliderview: function() {
        var e = this.data.conversations;
        e.forEach(function(e) {
            e.show = !1;
        }), this.setData({
            conversations: e
        });
    },
    switchReadUnRead: function(e) {
        var t = (0, z.jo)(e).selected;
        this.setData({
            selectedChatStatus: t
        }), this.hideAllSliderview(), this.data.manualTransferring && this.handleTransferChat(), 
        "unread" === t && this.resetUnReadRequest();
    },
    resetUnReadRequest: function() {
        this.setData({
            unreadHasMore: !1,
            pageNum: 1,
            fetchSign: "",
            hasUnreadList: !1,
            initLoadFinish: !1
        }), Object.values(this.conversationsMap).forEach(function(e) {
            e.isUnreadListItem = !1;
        }), this.fetchUnReadMsg(!0);
    },
    fetchUnReadMsg: (0, z.my)(U(M.default.mark(function e() {
        var t, r, a, n, o, i, s, c, u, p = arguments;
        return M.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = p.length > 0 && void 0 !== p[0] && p[0], e.prev = 1, r = this.data, a = r.pageNum, 
                n = r.fetchSign, o = r.unreadHasMore, t || o) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return");

              case 5:
                return e.next = 7, this.$baseRequest(Y(Y({}, Ap), {}, {
                    data: {
                        pageNum: a,
                        fetchSign: n,
                        pageSize: 20
                    }
                }));

              case 7:
                i = e.sent, s = (0, z.qh)(i, "result.fetchSign"), c = (0, z.qh)(i, "result.hasMore"), 
                (u = (0, z.qh)(i, "result.convList") || []).length && t && this.setData({
                    hasUnreadList: !0
                }), this.setData({
                    fetchSign: s,
                    pageNum: a + 1,
                    unreadHasMore: c,
                    initLoadFinish: !0
                }), this.handleNewConversation(u, {
                    isUnreadListItem: !0
                }), e.next = 17;
                break;

              case 14:
                e.prev = 14, e.t0 = e.catch(1), this.setData({
                    unreadHasMore: !1,
                    pageNum: 1,
                    fetchSign: "",
                    initLoadFinish: !0
                });

              case 17:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 1, 14 ] ]);
    }))),
    queryTransferChatSetting: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, e.$baseRequest(Y({}, Pp));

                  case 3:
                    if (!(r = t.sent).success) {
                        t.next = 8;
                        break;
                    }
                    return a = r.result.transferMode, n = {}, t.abrupt("return", (a === Ql.AUTO ? (n = {
                        manualTransferring: !1,
                        transferChatSelected: []
                    }, e.transferChatSelectedMap = {}, e.autoTransfer = !0) : e.autoTransfer = !1, e.setData(Y({
                        transferMode: a
                    }, n)), r.result));

                  case 8:
                    t.next = 12;
                    break;

                  case 10:
                    t.prev = 10, t.t0 = t.catch(0);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 10 ] ]);
        }))();
    },
    transferChatFilterConvList: function() {
        var e = this;
        z.f9.cancel(z.f1.transferChatConvId), z.f9.listen(z.f1.transferChatConvId, function(t) {
            t.hadSelectConvIdList.forEach(function(t) {
                delete e.conversationsMap[t], e.imsdk && e.imsdk.deleteConvId(t);
            });
            var r = Object.values(e.conversationsMap);
            cn(e.data.$bigCommanderUserNo), e.setData({
                conversations: r,
                noConversations: 0 === r.length
            });
        });
    },
    handleSelectTransfer: function(e) {
        var t = (0, z.jo)(e).productIndex, r = this.data.conversations[t];
        if (Object.hasOwnProperty.call(this.transferChatSelectedMap, r.convUid)) delete this.transferChatSelectedMap[r.convUid]; else {
            var a = this.data, n = a.transferChatSelected, o = a.transferSize;
            if (n.length + 1 > o) return this.$showToast({
                title: "超过可选人数上限",
                icon: "none"
            });
            this.transferChatSelectedMap[r.convUid] = r;
        }
        this.setData({
            transferChatSelected: Object.keys(this.transferChatSelectedMap),
            hadSelectConvIdList: Object.values(this.transferChatSelectedMap).map(function(e) {
                return e.convId;
            })
        });
    },
    showTransferChatPanel: function() {
        this.setData({
            showTransferChatPanel: !this.data.showTransferChatPanel
        });
    },
    handleTransferChat: function() {
        var e = {
            manualTransferring: !this.data.manualTransferring
        };
        !1 === this.data.manualTransferring && (e.transferChatSelected = [], this.transferChatSelectedMap = {}), 
        this.setData(e), this.hideFrequencyShow(z.aw.showChatTransferTips);
    },
    transferChatSuccess: function(e) {
        var t = (0, z.jo)(e).hadSelectConvIdList;
        z.f9.trigger(z.f1.transferChatConvId, {
            hadSelectConvIdList: t
        }), this.handleTransferChat();
    },
    autoTransFormChat: function() {
        this.autoTransfer && this.$baseRequest(Y({}, kp));
    },
    perConversationTransfer: function(e) {
        var t = this;
        return this.$baseRequest(Y(Y({}, bp), {}, {
            data: {
                conv_id: e
            }
        })).catch(function(e) {
            t.$error({
                e: e,
                msg: "fail: transfer conversion chatCenter"
            });
        });
    }
}, nd = (0, z.gg)({
    data: Y({}, rd),
    methods: Y({}, ad)
}), od = "MM/dd hh:mm", id = {
    RANK_TREND: Yo,
    rankTime: W.default.formatTime(Date.now(), od)
}, sd = {
    handleRefreshCaptainRank: function() {
        var e = this;
        return U(M.default.mark(function t() {
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.$click({
                        page_el_sn: Wi.captainRankRefreshBtn
                    }), !e.data.viewCaptainRank) {
                        t.next = 8;
                        break;
                    }
                    return t.next = 3, Promise.all([ e.loadRankMonitor(), e.queryPersonalRealData() ]);

                  case 3:
                    if (t.t0 = t.sent.every(function(e) {
                        return e;
                    }), !t.t0) {
                        t.next = 6;
                        break;
                    }
                    e.$showToast({
                        title: "更新成功"
                    });

                  case 6:
                    t.next = 13;
                    break;

                  case 8:
                    return t.next = 10, e.queryPersonalRealData();

                  case 10:
                    if (t.t1 = t.sent, !t.t1) {
                        t.next = 13;
                        break;
                    }
                    e.$showToast({
                        title: "更新成功"
                    });

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    queryPersonalRealData: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest(Y({}, Np)).catch(function(t) {
                        e.$error({
                            e: t,
                            msg: "queryPersonalRealData: personalRealData error"
                        });
                    });

                  case 2:
                    if (r = t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return a = r.amount, n = void 0 === a ? 0 : a, o = r.orderUserCnt, i = void 0 === o ? 0 : o, 
                    s = r.orderCnt, c = void 0 === s ? 0 : s, t.abrupt("return", (e.setData({
                        realTimeData: {
                            amountYuan: W.default.price(n, 100),
                            orderUserCnt: i,
                            orderCnt: c
                        }
                    }), !0));

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    loadRankMonitor: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l, d, h, f, g;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.$baseRequest(Y(Y({}, wp), {}, {
                        data: {}
                    })).catch(function(t) {
                        e.$error({
                            e: t,
                            msg: "loadRankMonitor: personalRankMonitor error"
                        });
                    });

                  case 2:
                    if ((n = t.sent) && n.success) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return o = n.result || {}, i = o.rankResultStr, s = void 0 === i ? "" : i, c = o.differenceCompareToLastMonthStr, 
                    p = s, l = "", d = u = void 0 === c ? "" : c, h = "", (f = new RegExp(/万\+/, "g")).test(s) && (p = s.replace(f, ""), 
                    l = (null === (r = s.match(f)) || void 0 === r ? void 0 : r.join("")) || ""), f.test(u) && (d = u.replace(f, ""), 
                    h = (null === (a = u.match(f)) || void 0 === a ? void 0 : a.join("")) || ""), g = Number(ps(o.serverTime, 0)) - 72e5, 
                    t.abrupt("return", (e.setData({
                        hasCaptainRankInit: !0,
                        captainRankVisible: o.showRank || !1,
                        rankResultNo: p,
                        rankResultStr: l,
                        trendType: o.trendType || null,
                        differenceCompareToLastMonthNo: d,
                        differenceCompareToLastMonthStr: h,
                        rankTime: W.default.formatTime(o.serverTime || Date.now(), od),
                        prevGmvDiff: o.prevGmvDiff || "",
                        gmv: o.gmv || "",
                        gmvNumber: parseFloat(String(o.gmv)) || 0,
                        nextGmvDiff: o.nextGmvDiff || "",
                        locationPrefix: o.locationPrefix || "",
                        serverTime: o.serverTime || 0,
                        isLast2HoursOfThisMonth: !o.serverTime || o.serverTime >= g
                    }), !0));

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    onImprDataCenter: function() {
        this.$impr({
            page_el_sn: Wi.dataCenterEntranceImpr
        });
    },
    onImprCaptainRank: function() {
        this.$impr({
            page_el_sn: Wi.captainRank
        });
    },
    showDataRankRules: function() {
        this.$click({
            page_el_sn: Wi.rankDataHint
        }), this.setData({
            dataRankRulesVisible: !0
        });
    },
    hideDataRankRules: function() {
        this.setData({
            dataRankRulesVisible: !1
        });
    }
}, cd = Y({
    data: Y({}, id)
}, sd), ud = (0, z.gg)({
    data: Y({}, id),
    methods: Y({}, sd)
}), pd = {
    userStatisticData: {},
    menuList: [],
    welfareMenuList: [],
    starActivityList: [],
    starTotalNewNum: 0
}, ld = {
    updateMenu: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l, d, h, f;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = Cp, a = [], t.prev = 1, n = e.data.userStatisticData || {}, o = n.centerMenuMod, 
                    i = o === Ll.CAPTAIN ? Ml.CAPTAIN : Ml.CUSTOMER, t.next = 7, (0, z.pm)({
                        data: {
                            displayType: i
                        }
                    });

                  case 7:
                    s = t.sent, c = (0, z.qh)(s, "result.menuList") || [], a = (0, z.qh)(s, "result.welfareMenuList") || [], 
                    c.length > 0 && (r = c), t.next = 14;
                    break;

                  case 12:
                    t.prev = 12, t.t0 = t.catch(1);

                  case 14:
                    u = r.concat(a), p = u.some(function(e) {
                        return e.menuId === Tp.HELP_SELL_ACTIVITY && e.showAsTopBanner;
                    }), l = u.some(function(e) {
                        return e.menuId === Tp.HELP_SELL_MANAGE && e.showAsTopBanner;
                    }), d = u.some(function(e) {
                        return e.menuId === Tp.OFFICE_GOODS_LIBRARY && e.showAsTopBanner;
                    }), r.length > 0 && (h = r.filter(function(e) {
                        return !e.showAsTopBanner && Ip[e.menuId];
                    }), f = a.filter(function(e) {
                        return !e.showAsTopBanner && Ip[e.menuId];
                    }), e.setData({
                        menuList: h,
                        welfareMenuList: f,
                        hasHelpSellActEnter: p,
                        hasHelpSellManager: l,
                        hasOfficeGoodsLibrary: d
                    }), e.updateRedPoint(h.concat(f)));

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 12 ] ]);
        }))();
    },
    updateRedPoint: function() {
        var e = arguments, t = this;
        return U(M.default.mark(function r() {
            var a, n;
            return M.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = (a = e.length > 0 && void 0 !== e[0] ? e[0] : []).map(function(e) {
                        return Y(Y({}, Ip[e.menuId]), e);
                    }), r.next = 4, t.checkBadgeShow((0, z.kk)(a));

                  case 4:
                    n = r.sent, t.setData({
                        redPointMap: n
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    onLoadBehaviorEntrance: function() {},
    onShowBehaviorEntrance: function() {},
    onImprOperateItem: function(e) {
        var t = (0, z.jo)(e).operateObj.menuId, r = ((null == Ip ? void 0 : Ip[t]) || {}).elsn;
        r && this.$impr({
            page_el_sn: r
        });
    },
    onClickOperateItem: function(e) {
        var t = this, r = (0, z.jo)(e).menuId, a = this.data.menuList, n = a.findIndex(function(e) {
            return "".concat(e.menuId) == "".concat(r);
        }), o = n < 0 ? Ip[r] : a[n];
        if (o) {
            this._onClickOperateItem(o);
            var i = (0, z.jo)(e).userNo, s = o.menuId;
            Ip[s].menuId === Tp.CUSTOMER_SERVICE && (i = this.data.$gray.kttOfficalCustomerServiceUserNo), 
            Ip[s].actions.reduce(function(e, r) {
                if (!e) return !1;
                switch (r.type) {
                  case Sp.MINI:
                  case Sp.H5:
                    if (/^https?:\/\//.test(o.jumpUrl)) {
                        var a = (0, z.oa)(o.jumpUrl);
                        if (a.ktt_alias) {
                            var n = a.ktt_alias;
                            return n === _t.learningCenter && t.$addNextShowCallback(function() {
                                t.getPersonData();
                            }), delete a.ktt_alias, (0, z.n5)({
                                pageName: n,
                                params: a
                            }), !0;
                        }
                        (0, z.n5)({
                            pageName: r.pageName
                        });
                    } else if (r.pageName) "kttchat" === r.project ? (0, z.n4)({
                        path: "/wdrpplbr.html",
                        params: r.params || {}
                    }) : (0, z.n5)({
                        pageName: r.pageName
                    }); else {
                        var c = {
                            userNo: i
                        };
                        if (s === Tp.HELP_SELL_ACTIVITY) {
                            var u = t.data, p = u.starTotalNewNum, l = u.starActivityList;
                            z.f9.cancel(z.f1.preloadStarActivityList), z.f9.trigger(z.f1.preloadStarActivityList, {
                                starTotalNewNum: p,
                                starActivityList: l
                            });
                        }
                        if (s === Tp.CUSTOMER_ORDER && z.f9.trigger(z.f1.personalCenterSwitchToOrderList, {
                            pageType: "c"
                        }), s === Tp.SETTING) {
                            var d = (t.data.userStatisticData || {}).centerMenuMod;
                            Object.assign(c, q({}, z.gf.centerMenuMod, d));
                        }
                        (0, z.n3)({
                            url: o.jumpUrl || r.jumpUrl,
                            params: c
                        });
                    }
                    break;

                  case Sp.PERM:
                    if (!t.checkPerm(r.code)) return !1;
                    break;

                  case Sp.READ_FILE:
                    (0, z.p2)(o.jumpUrl || r.jumpUrl);
                }
                return !0;
            }, !0);
        }
    },
    _onClickOperateItem: function(e) {
        this._onTrackOperateItem(e), this.hideBadge(e.menuId);
    },
    _onTrackOperateItem: function() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.menuId, a = Ip[r] || {}, n = a.elsn;
        if (n) if (r === Tp.INVITE_TO_MAKE_MONEY) {
            var o = !!(null === (e = null == t ? void 0 : t.icon) || void 0 === e ? void 0 : e.match(/.gif$/));
            this.$click({
                page_el_sn: n,
                extParams: {
                    state_id: o ? 2 : 1
                }
            });
        } else this.$click({
            page_el_sn: n
        });
    }
}, dd = Y({
    mixins: [ pa ],
    data: Y({}, pd)
}, ld), hd = (0, z.gg)({
    behaviors: [ la ],
    data: Y({}, pd),
    methods: Y({}, ld)
}), fd = "创建专题团(批量分享)", gd = [ 20, 30, 50 ], md = gd[gd.length - 1], vd = {
    batchDeleteChecked: !1,
    groupNoList: [],
    openedActivityTabsConfigs: (0, z.g1)(vt),
    isFeedsEditing: !1,
    activityNoListCacheMap: {},
    activityNoListCacheLength: 0,
    editOptions: [ "管理置顶团购", fd, "批量编辑", "前往回收站" ],
    BATCH_DELETE_CONF: gd,
    curBatchDeleteAmount: gd[0]
}, _d = {
    handleEnterFeedsEdit: function() {
        var e = this;
        this.setData({
            isFeedsEditing: !0
        }, function() {
            e.searchStickyObserverCancel && e.searchStickyObserverCancel();
        }), wx.pageScrollTo({
            duration: 0,
            scrollTop: 0
        });
    },
    handleEnterFeedsShare: function() {
        this.$click({
            page_el_sn: 7025417
        }), (0, z.n3)({
            url: z.ob.topicActivitySelect,
            params: {
                fromPersonCenter: "1"
            }
        });
    },
    handleExitFeedsEdit: function() {
        var e = this;
        this.setData({
            isFeedsEditing: !1,
            batchDeleteChecked: !1
        }, function() {
            Yr(e, ".search-view-placeholder", {
                skipNavBar: !0,
                duration: 100
            }), e.stickySearchObserve();
        }), this.handleResetActivityNoListCacheMap(), this.$showToast({
            title: "编辑完成"
        });
    },
    handleResetActivityNoListCacheMap: function() {
        this.setData({
            activityNoListCacheMap: {},
            activityNoListCacheLength: 0
        });
    },
    resetBatchSelect: function() {
        this.handleResetActivityNoListCacheMap(), this.setData({
            batchDeleteChecked: !1
        });
    },
    handleSelectActivity: function(e) {
        var t = e.activityNo, r = this.data.activityNoListCacheMap, a = void 0 === r ? {} : r;
        a[t] ? delete a[t] : a[t] = !0, this.setData({
            batchDeleteChecked: !1,
            activityNoListCacheMap: a,
            activityNoListCacheLength: Object.values(a).length
        });
    },
    handleImprBatchDeleteBtn: function() {
        this.$impr({
            page_el_sn: 5593503
        });
    },
    handleBatchDeleteGroup: function() {
        var e = this;
        return U(M.default.mark(function t() {
            var r, a, n, o, i, s, c, u, p, l, d, h;
            return M.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data, a = r.activityTabType, n = r.activityNoListCacheMap, o = void 0 === n ? {} : n, 
                    i = r.activityNoListCacheLength, s = void 0 === i ? 0 : i) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    if (e.$click({
                        page_el_sn: 5593503,
                        extParams: {
                            batch_delete_amount: s
                        }
                    }), u = (c = 5 === a) ? Op : Dp, !c) {
                        t.next = 16;
                        break;
                    }
                    if (!(s > 20)) {
                        t.next = 8;
                        break;
                    }
                    return t.abrupt("return", void e.$showToast({
                        title: "单次最多永久删除20个团购，请修改后重试"
                    }));

                  case 8:
                    return t.next = 10, e.$showModal({
                        content: "永久删除后不可恢复，是否确定删除？",
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 10:
                    if (p = t.sent, p.confirm) {
                        t.next = 14;
                        break;
                    }
                    return t.abrupt("return");

                  case 14:
                    t.next = 24;
                    break;

                  case 16:
                    if (!(s > md)) {
                        t.next = 18;
                        break;
                    }
                    return t.abrupt("return", void e.$showToast({
                        title: "单次最多删除".concat(md, "个团购，请修改后重试")
                    }));

                  case 18:
                    return t.next = 20, e.$showModal({
                        content: "确定删除已选中的团购活动？",
                        cancelText: "取消",
                        confirmText: "确定"
                    });

                  case 20:
                    if (l = t.sent, l.confirm) {
                        t.next = 24;
                        break;
                    }
                    return t.abrupt("return");

                  case 24:
                    return d = Object.entries(o).filter(function(e) {
                        return L(e, 2)[1];
                    }).map(function(e) {
                        return L(e, 1)[0];
                    }), t.next = 27, e.$baseRequest(Y(Y({}, u), {}, {
                        data: {
                            activityNoList: d
                        }
                    })).catch(z.hm);

                  case 27:
                    if (h = t.sent, t.t0 = h && !0 === h.result, !t.t0) {
                        t.next = 40;
                        break;
                    }
                    return e.handleResetActivityNoListCacheMap(), e.$showLoading(), t.next = 34, (0, 
                    z.rt)(1500);

                  case 34:
                    e.$hideLoading(), e._batchFilterSetData(d), e.pageNumber = 1, e.loadRelease({
                        needResetBatchSelect: !0
                    }), e.setData({
                        batchDeleteChecked: !1
                    }), e.$showToast({
                        title: "删除成功"
                    });

                  case 40:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleSwitchHeaderOpenedActivityTabs: function(e) {
        this.handleSwitchOpenedActivityTabs(e), wx.pageScrollTo({
            duration: 0,
            scrollTop: 0
        });
    },
    handleSwitchOpenedActivityTabs: function(e) {
        var t = (0, z.jo)(e).type, r = this.data.openedActivityTabsConfigs, a = void 0 === r ? [] : r, n = {};
        a.forEach(function(e) {
            e.isActive = e.type === t, e.type === t && Object.assign(n, {
                openedActivityType: t
            });
        }), this.setData(Y({
            openedActivityTabsConfigs: a
        }, n)), this.onTabSelect && this.onTabSelect();
    },
    updateOpenedActivityTabsConfigs: function(e) {
        var t = (0, z.jo)(e).type, r = this.data.openedActivityTabsConfigs, a = void 0 === r ? [] : r;
        a.forEach(function(e) {
            e.isActive = e.type === t;
        }), this.setData({
            openedActivityTabsConfigs: a
        });
    },
    handleShowEditOptionsPanel: function() {
        this.$click({
            page_el_sn: 7025685
        }), this.$impr({
            page_el_sn: 7025417
        }), this._onClickOperateItem({
            menuId: z.l.SEARCH_BAR_MENU_ICON
        }), this.showEditOptionsPanel();
    },
    showEditOptionsPanel: function() {
        this.editOptionsPanelHasImpred || (this.$impr({
            page_el_sn: 5591660
        }), this.editOptionsPanelHasImpred = !0), this.setData({
            editOptionsPanelVisible: !0
        });
    },
    hideEditOptionsPanel: function() {
        this.setData({
            editOptionsPanelVisible: !1
        });
    },
    handleChooseEditOptions: function(e) {
        var t = this;
        switch ((0, z.jo)(e).type) {
          case fd:
            this.handleEnterFeedsShare();
            break;

          case "批量编辑":
            this.$click({
                page_el_sn: 5591653
            }), this.handleEnterFeedsEdit();
            break;

          case "管理置顶团购":
            this.$eventChannel.onceOnShow(z.f1.topGroupOrderAdjust, function() {
                t.afterTopOperation && t.afterTopOperation(1, 1);
            }), (0, z.n3)({
                url: z.ob.groupOrderAdjust
            });
            break;

          case "前往回收站":
            this.$click({
                page_el_sn: 5591660
            }), (0, z.n3)({
                url: z.ob.recycleBin
            });
        }
    },
    handleGoBack: function() {
        this.data.isFeedsEditing && this.handleExitFeedsEdit();
    },
    showBatchDelete: function() {
        this.setData({
            batchDeleteVisible: !0
        });
    },
    hideBatchDelete: function() {
        this.setData({
            batchDeleteVisible: !1
        });
    },
    handleSelectBatchDeleteOption: function(e) {
        var t = this, r = (0, z.jo)(e).index;
        this.setData({
            curBatchDeleteAmount: gd[r]
        }), this.checkBatchDelete({
            nextCheckStatus: !0
        }), setTimeout(function() {
            t.hideBatchDelete();
        }, 150);
    },
    handleCheckBatchDelete: function() {
        this.checkBatchDelete(), this.data.batchDeleteChecked && this.$click({
            page_el_sn: 5591677,
            extParams: {
                batch_delete_amount: this.data.curBatchDeleteAmount
            }
        });
    },
    checkBatchDelete: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.nextCheckStatus;
        this.setData({
            batchDeleteChecked: void 0 !== r ? r : !this.data.batchDeleteChecked
        }), this.data.batchDeleteChecked ? this.loadRelease({
            onlyActivityNo: !0
        }).then(function() {
            var t = e.data.groupNoList, r = void 0 === t ? [] : t, a = {};
            r.forEach(function(e) {
                a[e] = !0;
            }), e.setData({
                activityNoListCacheMap: a,
                activityNoListCacheLength: r.length
            });
        }) : this.resetBatchSelect();
    }
};

exports.agc = hd, exports.aeb = dd, exports.af4 = ud, exports.aea = cd, exports.abg = nd, 
exports._7 = Ql, exports.amm = Xl, exports.abf = Wl, exports.abe = Yl, exports.aj0 = exports.ac9 = Vl, 
exports.ac8 = Fl, exports.z9 = $l, exports.z8 = Bl, exports._y = {
    NO_RECEIVE_GROUP: 0,
    NO_DISTURB: 1
}, exports.tm = {
    CS_SEND_ORDER_CARD: "cs_send_order_card",
    CS_SEND_GROUP_CARD: "cs_send_group_card",
    KTT_VISITOR_CLICK_RECOMMEND_GROUP: "ktt_visitor_click_recommend_group",
    VISITOR_SEND_ORDER_CARD: "visitor_send_order_card",
    VISITOR_SEND_GROUP_CARD: "visitor_send_group_card",
    VISITOR_ENTER_CONV_AUTO_SEND_ORDER: "visitor_enter_conv_auto_send_order",
    VISITOR_ENTER_CONV_AUTO_SEND_GROUP: "visitor_enter_conv_auto_send_group",
    KTT_CS_INVITE_HELP_SELL_CARD: "ktt_cs_invite_help_sell_card",
    KTT_CS_SEND_EXCLUSIVE_COUPON_CARD: "ktt_cs_send_exclusive_coupon_card",
    KTT_CS_INVITE_BIND_NEW_CARD: "ktt_cs_invite_bind_new_card",
    KTT_CS_REMIND_ADD_MATERIAL: "ktt_cs_remind_add_material",
    KTT_CS_LOCAL_LIFE_CUSTOMER_SERVICE: "ktt_cs_local_life_customer_service",
    KTT_INFO_TEXT_RISK_TIP_CARD: "ktt_info_text_risk_tip_card"
}, exports.tn = {
    ORDER: 0,
    ACTIVITY: 1
}, exports.z4 = [ {
    text: "我是团长",
    type: "isB"
}, {
    text: "我是团员",
    type: "isC"
}, {
    text: "通知",
    type: "isS"
} ], exports.xz = {
    TEXT: 0,
    IMAGE: 1,
    CARD: 48,
    FLOOR_CARD: 52,
    LEGO: 64,
    RICH_TEXT: 56,
    WITHDRAW_MSG: 72,
    ENTERPRISE_WECHAT: -1024
}, exports.tb = Gl, exports.yg = 17, exports.z_ = 1002, exports.z1 = 4587175, exports.aai = 42, 
exports.wg = 10, exports.wb = 9, exports.xy = 3, exports.yb = 99, exports.tv = 10, 
exports.w_ = 1, exports.w5 = 300, exports.wq = 10, exports.xx = 20, exports.agk = function(e) {
    return Object.keys(e).filter(function(t) {
        return e[t];
    }).map(function(e) {
        return Y({
            key: e
        }, ql[e]);
    }).sort(function(e, t) {
        return e.sort - t.sort;
    });
}, exports.tf = ql, exports.tg = Ul, exports.s5 = {
    AFTER_SALES_DETAIL: 5189063,
    HANDLE_AFTER_SALES: 5189062
}, exports.x5 = {
    CANCEL: "取消订单",
    DETAIL: "订单详情",
    LOG: "备注操作日志"
};

var xd = Y({
    data: Y({}, vd)
}, _d);

exports.aec = xd;

var yd = (0, z.gg)({
    data: Y({}, vd),
    methods: Y({}, _d)
}), Sd = {
    panelBlock: "5890796",
    textarea: "5890804",
    options: "5890803",
    submitBtn: "5890798"
}, Ed = {
    commentTrackingData: Sd,
    showCommentPanel: !1,
    activeCommentConfig: {}
}, Td = {
    showQuickCommentPanel: function(e) {
        var t = (0, z.jo)(e), r = t.supplyUserNo, a = t.activityNo, n = t.parentSupplyActivityNo, o = t.index;
        this.setData({
            activeCommentConfig: {
                supplyUserNo: r,
                activityNo: a,
                supplyActivityNo: n,
                index: o
            },
            showCommentPanel: !0
        }), this.$impr({
            page_el_sn: Sd.panelBlock
        });
    },
    hideQuickCommentPanel: function() {
        this.setData({
            showCommentPanel: !1
        });
    },
    handleQuickCommentSucceed: function() {
        var e = this.data.activeCommentConfig.index;
        this.setData(q({}, "releaseList[".concat(e, "].commented"), !0)), this.hideQuickCommentPanel();
    }
};

exports.agf = yd;

var Id = Y({
    data: Y({}, Ed)
}, Td);

exports.aee = Id;

var Cd = (0, z.gg)({
    data: Y({}, Ed),
    methods: Y({}, Td)
}), kd = (0, z.g3)("2.6.1"), bd = (0, z.gg)({
    behaviors: [ Vi({
        mapState: {
            userInfo: z.sq,
            proxyUserInfo: z.ot
        }
    }) ],
    options: kd ? {
        pureDataPattern: /^(userInfo|proxyUserInfo)$/
    } : {},
    observers: kd ? {
        "userInfo, proxyUserInfo": function() {
            this.effect.apply(this, arguments);
        }
    } : {},
    properties: kd ? {} : {
        userInfo: {
            type: Object,
            value: {
                avatar: "",
                userName: "",
                userNo: ""
            },
            observer: function(e) {
                this.effect(e, this.data.proxyUserInfo);
            }
        },
        proxyUserInfo: {
            type: Object,
            value: {},
            observer: function(e) {
                this.effect(this.data.userInfo, e);
            }
        }
    },
    methods: {
        effect: (0, z.r2)(function(e, t) {
            if (t || e) {
                var r = !(0, z.qh)(t, "userNo"), a = (0, z.qh)(t, "avatar") || (0, z.qh)(e, "avatar"), n = (0, 
                z.qh)(t, "nickName") || (0, z.qh)(e, "nickName"), o = {
                    userStatisticData: Y(Y({}, this.data.userStatisticData), {}, {
                        avatar: a,
                        nickName: n
                    }),
                    isMySelf: r
                };
                this.setData(o);
            }
        })
    }
});

exports.ano = bd, exports.amb = Cd;

var Ad = (0, z.gg)({
    data: {
        sales: 0,
        targetSales: 0,
        todayMission: [],
        currentUnreceiveType: -1,
        isShowExclusiveGrowthEntry: !1,
        exclusiveGrowthRightsRestDays: 0,
        hadActivityEnd: !1,
        encourageText: "请继续加油！"
    },
    methods: {
        queryExclusiveGrowthRights: function() {
            var e = this;
            return U(M.default.mark(function t() {
                var r;
                return M.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, Mp();

                      case 2:
                        r = t.sent, e.setData(r), e.triggerEvent("getExclusiveGrowthRightsInfo", r);

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        goExclusiveGrowthProgress: function() {
            (0, z.n3)({
                url: z.ob.exclusiveGrowthProgress
            });
        }
    }
});

exports.aef = Ad;

var Pd = (0, z.gg)({
    data: {
        showFreeChargeEntry: !1,
        freeChargeInfo: {}
    },
    methods: {
        queryFreeChargeV2: function() {
            var e = this;
            return U(M.default.mark(function t() {
                var r, a, n, o, i, s, c, u, p, l, d, h, f, g, m, v, _;
                return M.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.$baseRequest({
                            url: "/api/ktt_gameplay/query/subsidy/rights/mission/v2",
                            noErrorToast: !0,
                            convertToCamel: !0,
                            convertRequestToSnake: !0
                        }).catch(z.hm);

                      case 2:
                        (r = t.sent) && r.result && (a = r.result, n = a.curMissionDigest, o = a.serverTimeTs, 
                        i = a.serverTime, s = a.isRisk, u = (c = n || {}).curSalesAmount, p = void 0 === u ? 0 : u, 
                        l = c.targetSalesAmount, d = void 0 === l ? 0 : l, h = c.expiredAt, f = void 0 === h ? 0 : h, 
                        g = c.missionStatus, m = Math.max(d - p, 0), v = parseInt(String(f / 1e3)), _ = o - v, 
                        e.setData({
                            showFreeChargeEntry: d > 0 && 3 !== g && !s,
                            freeChargeInfo: {
                                inDay: _ > 0 && _ < 864e5,
                                serverTime: i,
                                expiredAt: f,
                                leftTimeStr: W.default.timeSpan(o, v),
                                curSalesAmount: p,
                                leftSaleAmount: m,
                                targetSalesAmount: d,
                                curSalesAmountYuan: W.default.price(p, 100),
                                leftSaleAmountYuan: W.default.price(m, 100),
                                targetSalesAmountYuan: W.default.price(d, 100)
                            }
                        }));

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        goFreeCharge: function() {
            this.$click({
                page_el_sn: 7797819
            }), (0, z.n5)({
                pageName: _t.kttFreeCharge
            });
        },
        handleFreeChargeEnd: function() {
            this.queryFreeChargeV2();
        }
    }
});

exports.aeg = Pd;

var Rd, Nd, wd, Dd = 3e3, Od = "wss://titan-ws.hutaojie.com", Ld = "wss://titan-ws.pinduoduo.com", Md = {
    TEXT: 0,
    IMAGE: 1,
    EMOJI: 5,
    PAY_CARD: 13,
    VIDEO: 14,
    FILE: 16,
    SENSITIVE_WORD: 20,
    LINK_HINT: 31,
    COMMON_CARD: 48,
    EVALUATE_CARD: 50,
    TEMPLATE_CARD: 52,
    RICH_TEXT: 56
}, Ud = "http://prairie-api.chat.a.test.yiran.com";

exports.wr = 2, exports.ws = 500, exports.tw = 45e3, exports._3 = "titan_ws_token_client", 
exports._1 = 5, exports.wp = 20, exports.y4 = 10086, exports.tx = 1, exports.tc = Ud, 
exports.wk = 6e5, exports.vh = Md, exports._z = 500, exports.xs = 2, exports.w1 = -1, 
exports.xw = 1, exports._f = 10, exports._2 = Ld, exports.u6 = Od, exports.aae = 1e4, 
exports.wt = Dd, exports.vq = wd, exports.ze = Nd, exports.ty = Rd, function(e) {
    e[e.WEB = 1] = "WEB", e[e.IOS = 2] = "IOS", e[e.ANDROID = 3] = "ANDROID", e[e.MINIAPP = 4] = "MINIAPP", 
    e[e.WIN = 5] = "WIN", e[e.MAC = 6] = "MAC";
}(Rd || (exports.ty = Rd = {})), function(e) {
    e.CAPP = "CAPP", e.BAPP = "BAPP";
}(Nd || (exports.ze = Nd = {})), function(e) {
    e[e.IMAGE = 1] = "IMAGE", e[e.AUDIO = 2] = "AUDIO", e[e.VIDEO = 3] = "VIDEO", e[e.FILE = 4] = "FILE";
}(wd || (exports.vq = wd = {}));

var qd = "/api/prairie", Gd = {
    FILE: "/general_file",
    IMAGE: "/v3/store_image",
    UPLOAD_INIT: "/api/galerie/cos_large_file/upload_init",
    UPLOAD_PART: "/api/galerie/cos_large_file/upload_part",
    UPLOAD_COMPLETE: "/api/galerie/cos_large_file/upload_complete"
}, Bd = "INIT_CONVERSATION_FLAG", $d = "development", Fd = function(e) {
    var t = function() {
        return (65536 * (1 + Math.random()) || 0).toString(16).substring(1);
    };
    return "".concat(e, "-").concat(+new Date(), "-", "".concat(t(), "-").concat(t(), "-").concat(t(), "-").concat(t()));
}, Hd = function(e, t) {
    return (e || []).findIndex(t);
}, jd = function(e, t) {
    return "string" == typeof t && (t = t.split(".").filter(function(e) {
        return e.length;
    })), t.reduce(function(e, t) {
        return e && e[t];
    }, e);
}, Vd = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        retry: 1,
        timeout: 1e3
    }, r = function r(a) {
        return e().catch(function(e) {
            return a < t.retry ? (a += 1, new Promise(function(e) {
                return setTimeout(function() {
                    return e(r(a));
                }, a * t.timeout);
            })) : Promise.reject(e);
        });
    };
    return r(0);
}, Yd = function(e, t) {
    var r = Fd(e.convId), a = e.convId, n = {
        to: {},
        from: {
            uid: t.userNo,
            user_type: t.userType
        },
        chat_type_id: t.chatTypeId,
        conv_id: a,
        type: e.type,
        client_msg_id: r
    };
    return t.hostId && (n.from.host_id = t.hostId), delete e.convId, {
        convId: a,
        chatTypeId: t.chatTypeId,
        clientMsgId: r,
        message: Object.assign(n, e)
    };
}, zd = function(e) {
    return function(t) {
        var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "POST", n = e.headers, o = e.defaultData, i = void 0 === o ? {} : o, s = e.onError, c = void 0 === s ? function() {} : s, u = "".concat(e.baseUrl).concat(t), p = Y(Y({}, i), r);
        return new Promise(function(e, t) {
            wx.request({
                url: u,
                timeout: Dd,
                data: p,
                method: a,
                header: n,
                success: function(r) {
                    var a = r.data || {};
                    !0 === a.success ? e(a.result) : (t(a), c(Y(Y({}, a), {}, {
                        url: u,
                        request: p
                    }), "httperror"));
                },
                fail: function(e) {
                    t(e), e.url = u, e.reqeust = p, c(e, "httperror");
                }
            });
        });
    };
}, Wd = function(e, t) {
    return new Promise(function(r, a) {
        wx.uploadFile({
            url: e,
            filePath: t.filePath,
            timeout: 1e4,
            name: "image",
            formData: {
                upload_sign: t.uploadSignature
            },
            success: function(n) {
                if (n.url = e, n.params = t, n.data) try {
                    var o = JSON.parse(n.data) || {};
                    o.url ? r(o) : a(n);
                } catch (r) {
                    r.url = e, r.params = t, a(r);
                } else a(n);
            },
            fail: function(r) {
                r.url = e, r.params = t, a(r);
            }
        });
    });
};

exports.amp = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 ? arguments[2] : void 0, a = r.headers, n = void 0 === a ? {} : a, o = r.method, i = void 0 === o ? "POST" : o;
    wx.request({
        url: e,
        timeout: Dd,
        data: t,
        method: i,
        header: n
    });
}, exports.anl = Wd, exports.af2 = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = arguments.length > 2 ? arguments[2] : void 0;
    return new Promise(function(a, n) {
        var o = r.baseUrl, i = r.headers, s = void 0 === i ? {} : i, c = r.method, u = void 0 === c ? "POST" : c, p = "".concat(o).concat(e);
        wx.request({
            url: p,
            timeout: Dd,
            data: t,
            method: u,
            header: s,
            success: function(e) {
                var t = e.data || {};
                !0 === t.success ? a(t.result) : n(t);
            },
            fail: function(e) {
                n(e);
            }
        });
    });
}, exports.aa3 = zd, exports.af6 = Yd, exports.zn = Vd, exports.aji = function(e) {
    var t = {}, r = [ "stack" ];
    Object.getOwnPropertyNames(e).forEach(function(a) {
        r.indexOf(a) > -1 && "string" == typeof e[a] ? t[a] = (e[a] || "").substr(0, 400) : t[a] = e[a];
    });
    try {
        return JSON.stringify(t);
    } catch (e) {
        return "{}";
    }
}, exports.ag7 = jd, exports.agg = Hd, exports.ag6 = Fd, exports.aab = "image", 
exports.wz = "init", exports.ya = "new", exports.xa = "https://tne.yangkeduo.com", 
exports.xf = "kuaituantuan", exports.ww = $d, exports.w0 = Bd, exports.u7 = "https://file.hutaojie.com", 
exports.aaa = "https://file.pinduoduo.com", exports.aac = Gd, exports.w2 = qd;

var Kd = function() {
    function e(t) {
        G(this, e), this.headers = {}, this.options = Y({}, t), this.init(t);
    }
    var t;
    return B(e, [ {
        key: "init",
        value: function(e) {
            var t = {
                accesstoken: e.accessToken,
                "User-Type": e.userType,
                "Client-Type": e.clientType || Rd.MINIAPP
            };
            e.hostId && (t["Host-Id"] = e.hostId), this.headers = t, this.request = zd({
                onError: e.onError,
                baseUrl: e.serviceUrl || Ud,
                headers: t
            });
        }
    }, {
        key: "updateBaseRequest",
        value: function(e) {
            this.request = zd({
                onError: this.options.onError,
                baseUrl: this.options.serviceUrl || Ud,
                headers: Y(Y({}, this.headers), e)
            });
        }
    }, {
        key: "getConvList",
        value: function(e) {
            return this.request("".concat(qd, "/chat/conv/get_conv_list"), e);
        }
    }, {
        key: "getHistoryMessage",
        value: function(e) {
            return this.request("".concat(qd, "/chat/message/get_history_message"), Y({
                size: 20,
                chatTypeId: this.options.chatTypeId
            }, e));
        }
    }, {
        key: "sendMessage",
        value: function(e) {
            return this.request("".concat(qd, "/chat/message/send_message"), e);
        }
    }, {
        key: "getBoxSync",
        value: function(e) {
            return this.request("".concat(qd, "/chat/inbox/sync"), {
                syncKey: [ e ]
            });
        }
    }, {
        key: "getInitState",
        value: function() {
            return this.request("".concat(qd, "/chat/inbox/get_init_state")).then(function(e) {
                return {
                    initSyncStateList: jd(e, "initSyncValue"),
                    serverTime: jd(e, "serverTime")
                };
            });
        }
    }, {
        key: "getConversation",
        value: function(e) {
            return this.request("".concat(qd, "/chat/conv/get_conv_info"), e);
        }
    }, {
        key: "getFileUploadAssign",
        value: function(e) {
            return this.request("".concat(qd, "/supply/file/pre_upload"), e);
        }
    }, {
        key: "enterConversation",
        value: function(e) {
            return this.request("".concat(qd, "/chat/conv/enter_conv"), e);
        }
    }, {
        key: "leaveConversation",
        value: function(e) {
            return this.request("".concat(qd, "/chat/conv/leave_conv"), e);
        }
    }, {
        key: "messageCallback",
        value: function(e) {
            return this.request("".concat(qd, "/chat/message/callback"), e);
        }
    }, {
        key: "markRead",
        value: function(e) {
            return this.request("".concat(qd, "/chat/conv/mark_read"), e);
        }
    }, {
        key: "uploadImage",
        value: (t = U(M.default.mark(function e(t) {
            var r, a, n, o, i;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = t.info, a = {
                        convId: t.convId,
                        filename: r.filename,
                        fileUsage: wd.IMAGE
                    }, e.next = 4, this.getFileUploadAssign(a);

                  case 4:
                    return n = e.sent, o = n.uploadHost, i = n.uploadSignature, e.abrupt("return", Wd("".concat(o).concat(Gd.IMAGE), {
                        uploadSignature: i,
                        filePath: r.filePath
                    }));

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return t.apply(this, arguments);
        })
    } ]), e;
}();

exports.aej = Kd, X.Titan.usePlugin(X.Unicast);

var Jd = function() {
    function e(t) {
        var r = this;
        G(this, e), this.conversationSyncMessages = {}, this.conversationSyncMarkReadMessages = {}, 
        this.conversations = {}, this.lastState = {}, this.isDevelopment = !0, this.onSync = function(e) {
            var t = +e.actionId, a = jd(e, "payload.push_data") || {}, n = r.lastState[a.seq_type], o = a.data || [];
            return n && -1 !== r.options.bizType.indexOf(t) ? (a.base_seq_id > n.seqId && -1 !== n.seqId ? r.getSyncBoxMessages(n.seqId, n.seqType) : (a.seq_id > n.seqId || -1 === n.seqId) && (-1 !== n.seqId && (o = o.slice(n.seqId - n.base_seq_id)), 
            1 === a.seq_type ? o.forEach(function(e) {
                r.pretreatSyncMessage(e.message);
            }) : 10 === a.seq_type && o.forEach(function(e) {
                r.pretreatSyncSystemMessage(e, a.seq_type);
            }), r.lastState[a.seq_type] = {
                seqId: a.seq_id,
                seqType: a.seq_type
            }, r.getSyncBoxMessages(a.seq_id, a.seq_type)), null) : null;
        }, this.onLogin = function(e) {
            r.options.onlogin(e), (0, z.l7)({
                msg: "onlogin",
                data: e
            });
        }, this.onReconnecting = function(e) {
            r.options.onreconnect && r.options.onreconnect(e);
        }, this.onClose = function(e) {
            r.options.onclose(e), (0, z.l7)({
                msg: "onclose",
                data: e
            });
        }, this.onError = function(e, t) {
            r.options.onerror(e), (0, z.hp)({
                msg: t || "onclose",
                data: {
                    error: e
                }
            });
        }, this.options = Object.assign({
            mode: $d,
            onreconnect: function() {},
            onclose: function() {},
            onlogin: function() {},
            onmsg: function() {},
            onsystem: function() {},
            onconversations: function() {},
            onerror: function() {},
            httpRetry: 2
        }, t), "number" == typeof t.bizType && (this.options.bizType = [ t.bizType ]), this.service = new Kd(Y(Y({}, t), {}, {
            onError: this.onError
        })), this.isDevelopment = "production" !== t.mode, this.lastState = {
            1: {
                seqType: 1,
                seqId: -1
            }
        }, this.init(t);
    }
    var t, r;
    return B(e, [ {
        key: "init",
        value: (r = U(M.default.mark(function e(t) {
            var r, a, n, o, i, s, c, u = this;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, this.service.getInitState();

                  case 3:
                    return r = e.sent, a = r.initSyncStateList, e.next = 7, this.getConversationList({
                        offset: 0,
                        size: 20,
                        chatTypeId: this.options.chatTypeId
                    }, !0);

                  case 7:
                    n = e.sent, o = n.data, i = void 0 === o ? [] : o, s = n.hasMore, c = n.offset, 
                    a.forEach(function(e) {
                        u.lastState[e.seqType] = {
                            seqId: e.seqId,
                            seqType: e.seqType
                        };
                    }), this.initSocket(t), this.options.onconversations(i, {
                        hasMore: s,
                        offset: c,
                        type: "init"
                    }), e.next = 18;
                    break;

                  case 15:
                    e.prev = 15, e.t0 = e.catch(0), this.onError({
                        message: e.t0.message || "",
                        stack: (e.t0.stack || "").substr(0, 200)
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 0, 15 ] ]);
        })), function(e) {
            return r.apply(this, arguments);
        })
    }, {
        key: "initSocket",
        value: function(e) {
            e.titanInstance ? this.socket = e.titanInstance : (this.socket = new X.Titan({
                projectName: e.projectName || z.cl,
                appId: e.appId,
                accesstoken: e.accessToken,
                uid: e.uid,
                maxReconnectTimes: 5,
                url: this.isDevelopment ? Od : Ld,
                isWxApp: !0,
                cancelLog: !0
            }), this.socket.connect()), this.socket.on("open", this.onLogin), this.socket.on("message", this.onSync), 
            this.socket.on("error", this.onError), this.socket.on("closed", this.onClose), this.socket.on("reconnecting", this.onReconnecting);
        }
    }, {
        key: "removeTitanListener",
        value: function() {
            this.socket.removeListener("open", this.onLogin), this.socket.removeListener("message", this.onSync), 
            this.socket.removeListener("error", this.onError), this.socket.removeListener("closed", this.onClose), 
            this.socket.removeListener("reconnecting", this.onReconnecting);
        }
    }, {
        key: "getSyncBoxMessages",
        value: function(e, t) {
            var r = this, a = 0, n = {
                seqId: e,
                seqType: t,
                hasMore: !0
            }, o = function(e) {
                return r.service.getBoxSync({
                    seqId: e.seqId,
                    seqType: e.seqType
                }).then(function(e) {
                    var t = (jd(e, "syncData") || [])[0] || {}, a = t.data || [];
                    return 1 === t.seqType ? a.forEach(function(e) {
                        r.pretreatSyncMessage(e.message || e);
                    }) : 10 === t.seqType && a.forEach(function(e) {
                        r.pretreatSyncSystemMessage(e, 10);
                    }), r.lastState[t.seqType] = {
                        seqId: t.seqId,
                        seqType: t.seqType
                    }, {
                        seqId: t.seqId,
                        seqType: t.seqType,
                        hasMore: t.hasMore
                    };
                });
            }, i = function() {
                var e = U(M.default.mark(function e(t) {
                    return M.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, o(t);

                          case 2:
                            return n = e.sent, e.abrupt("return", n.hasMore ? (a += 1, new Promise(function(e) {
                                return setTimeout(function() {
                                    return e(i(n));
                                }, 500 * a * 2);
                            })) : n);

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }();
            return Vd(function() {
                return i(n);
            }, {
                retry: this.options.httpRetry,
                timeout: 500
            }).catch(function(e) {
                r.onError(e, "syncMessageError");
            });
        }
    }, {
        key: "getSyncConversationInfo",
        value: function(e) {
            var t = this;
            return this.conversations[e] = {
                convId: Bd
            }, this.service.getConversation({
                convId: e
            }).then(function(e) {
                var r = t.conversationSyncMessages[e.convId];
                t.conversations[e.convId] = e;
                var a = {
                    type: "new"
                };
                if (r.length) {
                    var n = r[r.length - 1];
                    1001 != n.type && (e = Y(Y({}, e), {}, {
                        message: n
                    })), t.options.onconversations([ e ], a);
                } else t.options.onconversations([ e ], a);
            });
        }
    }, {
        key: "pretreatSyncMessage",
        value: function(e) {
            var t = this, r = e.type, a = e.info;
            if (1001 === r && a) {
                if (a.target_uin && !(0, z.mq)(a.target_uin)) return;
                if (a.target_id && a.target_id !== (0, z.lj)()) return;
            }
            var n = String(jd(e, "conv_id") || ""), o = Y(Y({}, e), {}, {
                content: (e && e.content || "").substr(0, 2)
            });
            if (n) {
                var i = this.conversations[n];
                this.conversationSyncMessages[n] = this.conversationSyncMessages[n] || [], Hd(this.conversationSyncMessages[n], function(t) {
                    return t.msg_id === e.msg_id;
                }) > -1 || (this.conversationSyncMessages[n].push(e), void 0 === i && "" !== n || i && !i.message ? Vd(function() {
                    return t.getSyncConversationInfo(n);
                }, {
                    retry: this.options.httpRetry,
                    timeout: 500
                }).catch(function(e) {
                    t.onError(e, "syncConversationError");
                }) : i && this.options.onmsg(e));
            } else (0, z.hp)({
                msg: "convIdNullSync",
                data: o
            });
        }
    }, {
        key: "pretreatSyncSystemMessage",
        value: function(e, t) {
            var r = jd(e, "state_data.op_msg_id");
            this.conversationSyncMarkReadMessages[e.conv_id] = this.conversationSyncMarkReadMessages[e.conv_id] || [], 
            Hd(this.conversationSyncMarkReadMessages[e.conv_id], function(e) {
                return e.msg_id === r;
            }) > -1 || (this.conversationSyncMarkReadMessages[e.conv_id].push(e), this.options.onsystem && this.options.onsystem(e, t));
        }
    }, {
        key: "getAllConversationList",
        value: (t = U(M.default.mark(function e() {
            var t, r, a, n = this, o = arguments;
            return M.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = o.length > 0 && void 0 !== o[0] ? o[0] : {
                        offset: 0,
                        size: 20
                    }, r = [], a = function() {
                        var e = U(M.default.mark(function e(o) {
                            var i, s, c;
                            return M.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, n.getConversationList({
                                        offset: o,
                                        size: t.size
                                    }, !0);

                                  case 2:
                                    if (i = e.sent, s = i.data, c = i.hasMore, s.forEach(function(e) {
                                        var t = Hd(r, function(t) {
                                            return t.convId === e.convId;
                                        });
                                        -1 === t ? r.push(e) : r.splice(t, 1, e);
                                    }), e.t0 = c, !e.t0) {
                                        e.next = 10;
                                        break;
                                    }
                                    return e.next = 10, a(o + 1);

                                  case 10:
                                    return e.abrupt("return", r);

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }(), e.abrupt("return", a(t.offset));

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return t.apply(this, arguments);
        })
    }, {
        key: "getConversationList",
        value: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                offset: 0,
                size: 20
            }, r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return r ? t.offset *= t.size : t.offset = t.offset * (t.size || 20), this.service.getConvList(Y({
                chatTypeId: this.options.chatTypeId
            }, t)).then(function(r) {
                return r.offset = t.offset, r.size = t.size, (r.data || []).forEach(function(t) {
                    e.conversations[t.convId] = t;
                }), r;
            });
        }
    }, {
        key: "getHistoryMessage",
        value: function(e) {
            return e.convId ? this.service.getHistoryMessage(Y(Y({}, e), {}, {
                convId: e.convId
            })).then(function(e) {
                var t = [].concat(jd(e, "data") || []);
                return delete e.data, Y(Y({}, e), {}, {
                    list: t
                });
            }) : Promise.reject(new Error("getHistoryMessage get conversation is null ".concat(JSON.stringify(e))));
        }
    }, {
        key: "sendMsg",
        value: function(e) {
            var t = this;
            if (void 0 === e.type || !e.convId) return Promise.reject(new Error("sendMsg is error ".concat(JSON.stringify(e))));
            var r = Yd(e, this.options);
            return this.service.sendMessage(r).then(function(e) {
                var a = Y(Y(Y({}, r.message), e), {}, {
                    msg_id: e.msgId
                });
                return t.conversationSyncMessages[r.convId] = t.conversationSyncMessages[r.convId] || [], 
                t.conversationSyncMessages[r.convId].push(a), a;
            });
        }
    }, {
        key: "sendImage",
        value: function(e) {
            var t, r = this, a = e.info;
            return e.convId ? this.service.uploadImage(e).then(function(n) {
                var o = n.url, i = n.height, s = n.width, c = {
                    convId: e.convId,
                    content: o,
                    type: Md.IMAGE,
                    info: {
                        thumb_data: o,
                        width: s || a.width,
                        height: i || a.height
                    }
                };
                return t = o, r.sendMsg(c);
            }).catch(function(a) {
                throw a.imageData = e, a.uploadImageUrl = t, r.onError(a, "sendImageError"), a;
            }) : Promise.reject(new Error("sendImage convId is null"));
        }
    }, {
        key: "leaveConversation",
        value: function(e) {
            return e.convId ? this.service.leaveConversation({
                convId: e.convId
            }) : Promise.reject(new Error("leave conversation is null ".concat(e.convId)));
        }
    }, {
        key: "enterConversation",
        value: function(e) {
            return e.convId ? this.service.enterConversation({
                referPageSn: e.referPageSn,
                referPageName: e.referPageName,
                convId: e.convId,
                referPageExtraInfo: e.referPageExtraInfo || {}
            }) : Promise.reject(new Error("enter conversation is null ".concat(JSON.stringify(e))));
        }
    }, {
        key: "messageCallback",
        value: function(e) {
            return e.convId && e.msgId && e.buttonId ? this.service.messageCallback({
                convId: e.convId,
                buttonId: e.buttonId,
                msgId: e.msgId,
                subState: e.subState || ""
            }) : Promise.reject(new Error("messageCallback conversation is null ".concat(JSON.stringify(e))));
        }
    }, {
        key: "getConversation",
        value: function(e) {
            var t = this;
            return e.convId ? this.service.getConversation(e).then(function(e) {
                return t.conversations[e.convId] = e, e;
            }) : Promise.reject(new Error("getConversation convId is null ".concat(JSON.stringify(e))));
        }
    }, {
        key: "removeConversation",
        value: function(e) {
            return e ? (delete this.conversations[e], delete this.conversationSyncMessages[e], 
            !0) : Promise.reject(new Error("removeConversation convId is null "));
        }
    }, {
        key: "updateToken",
        value: function(e) {
            this.service.updateBaseRequest({
                accesstoken: e
            });
        }
    }, {
        key: "setMarkRead",
        value: function(e) {
            return e.msgId && e.convId ? this.service.markRead(e) : Promise.reject(new Error("setMarkRead convId OR msgId is null "));
        }
    }, {
        key: "setConversation",
        value: function(e, t) {
            if (!e) return Promise.reject(new Error("setConversation convId is null "));
            var r = this.options, a = r.chatTypeId, n = r.userType;
            return this.conversations[e] = {
                chatTypeId: a,
                convUserType: n,
                convId: e,
                convInfo: t
            }, this.conversations[e];
        }
    }, {
        key: "close",
        value: function(e) {
            this.socket.close(e);
        }
    }, {
        key: "login",
        value: function(e) {
            this.socket && this.socket.updateInfo({
                uid: e.uid,
                accesstoken: e.accessToken
            }), this.updateToken(e.accessToken);
        }
    }, {
        key: "deleteConvId",
        value: function(e) {
            this.conversationSyncMessages[e] && delete this.conversationSyncMessages[e], this.conversations[e] && delete this.conversations[e];
        }
    }, {
        key: "getConversationSyncMessages",
        value: function(e) {
            return this.conversationSyncMessages[e] || [];
        }
    } ]), e;
}();

exports.aei = Jd;