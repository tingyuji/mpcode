var _typeof2 = require("../_/helpers/typeof");

module.exports = function(t) {
    var e = {};
    function n(a) {
        if (e[a]) return e[a].exports;
        var r = e[a] = {
            i: a,
            l: !1,
            exports: {}
        };
        return t[a].call(r.exports, r, r.exports, n), r.l = !0, r.exports;
    }
    return n.m = t, n.c = e, n.d = function(t, e, a) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: a
        });
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, n.t = function(t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == _typeof2(t) && t && t.__esModule) return t;
        var a = Object.create(null);
        if (n.r(a), Object.defineProperty(a, "default", {
            enumerable: !0,
            value: t
        }), 2 & e && "string" != typeof t) for (var r in t) n.d(a, r, function(e) {
            return t[e];
        }.bind(null, r));
        return a;
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return n.d(e, "a", e), e;
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, n.p = "", n(n.s = 7);
}([ function(t, e) {
    t.exports = function(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }, t.exports.default = t.exports, t.exports.__esModule = !0;
}, function(t, e, n) {
    var a = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
    function r(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }
    e.assign = function(t) {
        for (var e = Array.prototype.slice.call(arguments, 1); e.length; ) {
            var n = e.shift();
            if (n) {
                if ("object" != _typeof2(n)) throw new TypeError(n + "must be non-object");
                for (var a in n) r(n, a) && (t[a] = n[a]);
            }
        }
        return t;
    }, e.shrinkBuf = function(t, e) {
        return t.length === e ? t : t.subarray ? t.subarray(0, e) : (t.length = e, t);
    };
    var i = {
        arraySet: function(t, e, n, a, r) {
            if (e.subarray && t.subarray) t.set(e.subarray(n, n + a), r); else for (var i = 0; i < a; i++) t[r + i] = e[n + i];
        },
        flattenChunks: function(t) {
            var e, n, a, r, i, o;
            for (a = 0, e = 0, n = t.length; e < n; e++) a += t[e].length;
            for (o = new Uint8Array(a), r = 0, e = 0, n = t.length; e < n; e++) i = t[e], o.set(i, r), 
            r += i.length;
            return o;
        }
    }, o = {
        arraySet: function(t, e, n, a, r) {
            for (var i = 0; i < a; i++) t[r + i] = e[n + i];
        },
        flattenChunks: function(t) {
            return [].concat.apply([], t);
        }
    };
    e.setTyped = function(t) {
        t ? (e.Buf8 = Uint8Array, e.Buf16 = Uint16Array, e.Buf32 = Int32Array, e.assign(e, i)) : (e.Buf8 = Array, 
        e.Buf16 = Array, e.Buf32 = Array, e.assign(e, o));
    }, e.setTyped(a);
}, function(t, e, n) {
    function a() {
        this.data = {}, this.status = !1;
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = Promise, i = wx.getSystemInfo, o = wx.getBatteryInfo, s = wx.getClipboardData, h = wx.getNetworkType, u = wx.getLaunchOptionsSync;
    a.prototype.compareVersion = function(t, e) {
        t = t.split("."), e = e.split(".");
        for (var n = Math.max(t.length, e.length); t.length < n; ) t.push("0");
        for (;e.length < n; ) e.push("0");
        for (var a = 0; a < n; a++) {
            var r = parseInt(t[a]), i = parseInt(e[a]);
            if (r > i) return 1;
            if (r < i) return -1;
        }
        return 0;
    }, a.prototype.getSysInfo = function() {
        var t = this;
        return new r(function(e, n) {
            t.getSysInfoCache && e(t.getSysInfoCache), i({
                success: function(n) {
                    var a = n.brand, r = n.model, i = n.pixelRatio, o = n.screenWidth, s = n.screenHeight, h = n.windowWidth, u = n.windowHeight, l = n.statusBarHeight, f = n.language, c = n.version, d = n.system, _ = n.platform, p = n.fontSizeSetting, g = n.SDKVersion, v = n.benchmarkLevel, b = n.albumAuthorized, y = n.cameraAuthorized, w = n.locationAuthorized, m = n.microphoneAuthorized, k = n.notificationAuthorized, S = n.notificationAlertAuthorized, A = n.notificationBadgeAuthorized, x = n.notificationSoundAuthorized, C = n.bluetoothEnabled, z = n.locationEnabled, H = n.wifiEnabled, E = n.safeArea, T = n.theme, N = {
                        brand: a,
                        model: r,
                        pixelRatio: i,
                        screenWidth: o,
                        screenHeight: s,
                        windowWidth: h,
                        windowHeight: u,
                        statusBarHeight: l,
                        language: f,
                        version: c,
                        system: d,
                        platform: _,
                        fontSizeSetting: p,
                        SDKVersion: g,
                        benchmarkLevel: v,
                        albumAuthorized: b,
                        cameraAuthorized: y,
                        locationAuthorized: w,
                        microphoneAuthorized: m,
                        notificationAuthorized: k,
                        notificationAlertAuthorized: S,
                        notificationBadgeAuthorized: A,
                        notificationSoundAuthorized: x,
                        bluetoothEnabled: C,
                        locationEnabled: z,
                        wifiEnabled: H,
                        safeAreaStr: JSON.stringify(E),
                        theme: T
                    };
                    t.getSysInfoCache = N, e(N);
                },
                fail: function(t) {
                    e({});
                },
                complete: function() {}
            });
        }).catch(function(t) {
            return {};
        });
    }, a.prototype.getBatteryInfo = function() {
        var t = this;
        return new r(function(e, n) {
            t.getBatteryInfoCache && e(t.getBatteryInfoCache);
            var a = {};
            o({
                success: function(n) {
                    var r = n.level, i = n.isCharging;
                    r && (a = {
                        level: r
                    }), i && (a = Object.assign({}, a, {
                        isCharging: i
                    })), t.getBatteryInfoCache = a, e(a);
                },
                fail: function(t) {
                    e(a);
                }
            });
        }).catch(function(t) {
            return {};
        });
    }, a.prototype.getClipboardData = function(t) {
        var e = {}, n = this;
        return t && a.compareVersion(t, "1.1.0") >= 0 ? new r(function(t, a) {
            n.getClipboardDataCache && t(n.getClipboardDataCache);
            try {
                s({
                    success: function(a) {
                        var r = a.data;
                        e = r ? {
                            clipboardData: r
                        } : {
                            clipboardData: r = ""
                        }, n.getClipboardDataCache = e, t(e);
                    },
                    fail: function(n) {
                        t(e);
                    }
                });
            } catch (n) {
                t(e);
            }
        }).catch(function(t) {
            return {};
        }) : new r(function(t) {
            t(e);
        });
    }, a.prototype.getNetworkType = function() {
        var t = {}, e = this;
        return new r(function(n) {
            e.getNetworkTypeCache && n(e.getNetworkTypeCache), h({
                success: function(a) {
                    var r = a.networkType;
                    t = {
                        data: r
                    }, e.getNetworkTypeCache = t, n(t);
                },
                fail: function() {
                    n(t);
                }
            });
        }).catch(function(t) {
            return {};
        });
    }, a.prototype.getSceneAndTicket = function() {
        try {
            if (this.getSceneAndTicketCache) return this.getSceneAndTicketCache;
            var t = u(), e = (t.path, t.scene), n = void 0 === e ? "" : e, a = (t.query, t.shareTicket), r = void 0 === a ? "" : a, i = (t.referrerInfo, 
            {
                scene: n += "",
                shareTicket: r
            });
            return this.getSceneAndTicketCache = i, i;
        } catch (t) {
            return {
                scene: "",
                shareTicket: ""
            };
        }
    }, a.prototype.init = function(t, e, n, a, i, o) {
        var s = this;
        n || (n = ""), a || (a = ""), i || (i = ""), o || (o = ""), s.getSysInfo().then(function(t) {
            var e = {};
            if (0 != Object.keys(t).length) for (var n = 0, a = Object.keys(t); n < a.length; n++) {
                var i = a[n];
                t[i] && (e[i] = t[i]);
            }
            return new r(function(t) {
                t({
                    sys: e
                });
            });
        }).then(function(t) {
            var e;
            return t.sys.version || (e = "1.1.0"), s.getClipboardData(e).then(function(e) {
                return e.clipboardData && (t = Object.assign({}, t, {
                    clipboard: e.clipboardData
                })), new r(function(e) {
                    e(t);
                });
            });
        }).then(function(h) {
            r.all([ s.getBatteryInfo(), s.getNetworkType() ]).then(function(r) {
                var u = r[0], l = r[1], f = s.getSceneAndTicket(), c = Object.assign({}, h, {
                    batteryInfo: u,
                    networkType: l
                }, f, {
                    app: e,
                    isvPageCode: n,
                    isvScene: a,
                    loginFlag: i,
                    apiLoginFlag: o
                });
                s.data = c, s.status = !0, t && t();
            });
        });
    };
    var l = new a();
    e.default = l;
}, function(t, e) {
    var n, a, r = t.exports = {};
    function i() {
        throw new Error("setTimeout has not been defined");
    }
    function o() {
        throw new Error("clearTimeout has not been defined");
    }
    function s(t) {
        if (n === setTimeout) return setTimeout(t, 0);
        if ((n === i || !n) && setTimeout) return n = setTimeout, setTimeout(t, 0);
        try {
            return n(t, 0);
        } catch (e) {
            try {
                return n.call(null, t, 0);
            } catch (e) {
                return n.call(this, t, 0);
            }
        }
    }
    !function() {
        try {
            n = "function" == typeof setTimeout ? setTimeout : i;
        } catch (t) {
            n = i;
        }
        try {
            a = "function" == typeof clearTimeout ? clearTimeout : o;
        } catch (t) {
            a = o;
        }
    }();
    var h, u = [], l = !1, f = -1;
    function c() {
        l && h && (l = !1, h.length ? u = h.concat(u) : f = -1, u.length && d());
    }
    function d() {
        if (!l) {
            var t = s(c);
            l = !0;
            for (var e = u.length; e; ) {
                for (h = u, u = []; ++f < e; ) h && h[f].run();
                f = -1, e = u.length;
            }
            h = null, l = !1, function(t) {
                if (a === clearTimeout) return clearTimeout(t);
                if ((a === o || !a) && clearTimeout) return a = clearTimeout, clearTimeout(t);
                try {
                    a(t);
                } catch (e) {
                    try {
                        return a.call(null, t);
                    } catch (e) {
                        return a.call(this, t);
                    }
                }
            }(t);
        }
    }
    function _(t, e) {
        this.fun = t, this.array = e;
    }
    function p() {}
    r.nextTick = function(t) {
        var e = new Array(arguments.length - 1);
        if (arguments.length > 1) for (var n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
        u.push(new _(t, e)), 1 !== u.length || l || s(d);
    }, _.prototype.run = function() {
        this.fun.apply(null, this.array);
    }, r.title = "browser", r.browser = !0, r.env = {}, r.argv = [], r.version = "", 
    r.versions = {}, r.on = p, r.addListener = p, r.once = p, r.off = p, r.removeListener = p, 
    r.removeAllListeners = p, r.emit = p, r.prependListener = p, r.prependOnceListener = p, 
    r.listeners = function(t) {
        return [];
    }, r.binding = function(t) {
        throw new Error("process.binding is not supported");
    }, r.cwd = function() {
        return "/";
    }, r.chdir = function(t) {
        throw new Error("process.chdir is not supported");
    }, r.umask = function() {
        return 0;
    };
}, function(t, e, n) {
    var a = n(10), r = n(1), i = n(14), o = n(5), s = n(15), h = Object.prototype.toString;
    function u(t) {
        if (!(this instanceof u)) return new u(t);
        this.options = r.assign({
            level: -1,
            method: 8,
            chunkSize: 16384,
            windowBits: 15,
            memLevel: 8,
            strategy: 0,
            to: ""
        }, t || {});
        var e = this.options;
        e.raw && e.windowBits > 0 ? e.windowBits = -e.windowBits : e.gzip && e.windowBits > 0 && e.windowBits < 16 && (e.windowBits += 16), 
        this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new s(), 
        this.strm.avail_out = 0;
        var n = a.deflateInit2(this.strm, e.level, e.method, e.windowBits, e.memLevel, e.strategy);
        if (0 !== n) throw new Error(o[n]);
        if (e.header && a.deflateSetHeader(this.strm, e.header), e.dictionary) {
            var l;
            if (l = "string" == typeof e.dictionary ? i.string2buf(e.dictionary) : "[object ArrayBuffer]" === h.call(e.dictionary) ? new Uint8Array(e.dictionary) : e.dictionary, 
            0 !== (n = a.deflateSetDictionary(this.strm, l))) throw new Error(o[n]);
            this._dict_set = !0;
        }
    }
    function l(t, e) {
        var n = new u(e);
        if (n.push(t, !0), n.err) throw n.msg || o[n.err];
        return n.result;
    }
    u.prototype.push = function(t, e) {
        var n, o, s = this.strm, u = this.options.chunkSize;
        if (this.ended) return !1;
        o = e === ~~e ? e : !0 === e ? 4 : 0, "string" == typeof t ? s.input = i.string2buf(t) : "[object ArrayBuffer]" === h.call(t) ? s.input = new Uint8Array(t) : s.input = t, 
        s.next_in = 0, s.avail_in = s.input.length;
        do {
            if (0 === s.avail_out && (s.output = new r.Buf8(u), s.next_out = 0, s.avail_out = u), 
            1 !== (n = a.deflate(s, o)) && 0 !== n) return this.onEnd(n), this.ended = !0, !1;
            0 !== s.avail_out && (0 !== s.avail_in || 4 !== o && 2 !== o) || ("string" === this.options.to ? this.onData(i.buf2binstring(r.shrinkBuf(s.output, s.next_out))) : this.onData(r.shrinkBuf(s.output, s.next_out)));
        } while ((s.avail_in > 0 || 0 === s.avail_out) && 1 !== n);
        return 4 === o ? (n = a.deflateEnd(this.strm), this.onEnd(n), this.ended = !0, 0 === n) : 2 !== o || (this.onEnd(0), 
        s.avail_out = 0, !0);
    }, u.prototype.onData = function(t) {
        this.chunks.push(t);
    }, u.prototype.onEnd = function(t) {
        0 === t && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = r.flattenChunks(this.chunks)), 
        this.chunks = [], this.err = t, this.msg = this.strm.msg;
    }, e.Deflate = u, e.deflate = l, e.deflateRaw = function(t, e) {
        return (e = e || {}).raw = !0, l(t, e);
    }, e.gzip = function(t, e) {
        return (e = e || {}).gzip = !0, l(t, e);
    };
}, function(t, e, n) {
    t.exports = {
        2: "need dictionary",
        1: "stream end",
        0: "",
        "-1": "file error",
        "-2": "stream error",
        "-3": "data error",
        "-4": "insufficient memory",
        "-5": "buffer error",
        "-6": "incompatible version"
    };
}, function(t, e, n) {
    var a = n(0);
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = a(n(16)), i = a(n(17)), o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), s = {
        "+": "-",
        "/": "_",
        "=": ""
    };
    "undefined" != typeof window && window;
    var h = "undefined" != typeof window && window.parseInt ? window.parseInt : parseInt, u = {
        base64: function(t) {
            for (var e, n, a, r = "", i = t.length, h = 0, u = 3 * parseInt(i / 3); h < u; ) e = t[h++], 
            n = t[h++], a = t[h++], r += o[e >>> 2] + o[63 & (e << 4 | n >>> 4)] + o[63 & (n << 2 | a >>> 6)] + o[63 & a];
            var l = i - u;
            return 1 === l ? (e = t[h], r += o[e >>> 2] + o[e << 4 & 63] + "==") : 2 === l && (e = t[h++], 
            n = t[h], r += o[e >>> 2] + o[63 & (e << 4 | n >>> 4)] + o[n << 2 & 63] + "="), 
            r.replace(/[+\/=]/g, function(t) {
                return s[t];
            });
        },
        charCode: function(t) {
            for (var e = [], n = 0, a = 0; a < t.length; a += 1) {
                var r = t.charCodeAt(a);
                r >= 0 && r <= 127 ? (e.push(r), n += 1) : (r >= 2048 && r <= 55295 || r >= 57344 && r <= 65535) && (n += 3, 
                e.push(224 | 15 & r >> 12), e.push(128 | 63 & r >> 6), e.push(128 | 63 & r));
            }
            for (var i = 0; i < e.length; i += 1) e[i] &= 255;
            return n <= 255 ? [ 0, n ].concat(e) : [ n >> 8, 255 & n ].concat(e);
        },
        es: function(t) {
            t || (t = "undefined");
            var e = this.charCode(t).slice(2), n = this.enn(e.length);
            return [].concat(this.enn(241), n, e);
        },
        enn: function(t) {
            t || (t = 0);
            for (var e = parseInt(t), n = e << 1 ^ e >> 31, a = n.toString(2), i = [], o = (a = (0, 
            r.default)(a, 7 * Math.ceil(a.length / 7), "0")).length; o >= 0; o -= 7) {
                var s = a.substring(o - 7, o);
                if (0 == (-128 & n)) {
                    i.push("0" + s);
                    break;
                }
                i.push("1" + s), n >>>= 7;
            }
            return i.map(function(t) {
                return parseInt(t, 2);
            });
        },
        nc: function(t) {
            t || (t = 0);
            var e = Math.abs(h(t)).toString(2), n = Math.ceil(e.length / 8);
            e = (0, r.default)(e, 8 * n, "0");
            for (var a = [], i = 0; i < n; i += 1) {
                var o = e.substring(8 * i, 8 * (i + 1));
                a.push(h(o, 2));
            }
            return a;
        },
        ek: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            if (!t) return [];
            var n = [], a = 0;
            "" !== e && ("[object Array]" === Object.prototype.toString.call(e) && (a = e.length), 
            "string" == typeof e && (a = (n = u.scAnti(e)).length), "number" == typeof e && (a = (n = u.nc(e)).length));
            var i = Math.abs(t).toString(2), o = "";
            o = a > 0 && a <= 7 ? i + (0, r.default)(a.toString(2), 3, "0") : i + "000";
            var s = [ h(o.slice(Math.max(o.length - 8, 0)), 2) ];
            return a > 7 ? s.concat(u.va(a), n) : s.concat(n);
        },
        va: function(t) {
            t || (t = 0);
            for (var e = Math.abs(h(t)), n = e.toString(2), a = [], i = (n = (0, r.default)(n, 7 * Math.ceil(n.length / 7), "0")).length; i >= 0; i -= 7) {
                var o = n.substring(i - 7, i);
                if (0 == (-128 & e)) {
                    a.push("0" + o);
                    break;
                }
                a.push("1" + o), e >>>= 7;
            }
            return a.map(function(t) {
                return h(t, 2);
            });
        },
        scAnti: function(t) {
            t || (t = "");
            var e = t.length > 255 ? t.substring(0, 255) : t;
            return this.charCode(e).slice(2);
        },
        pbc: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = [], n = u.nc((0, 
            i.default)(t.replace(/\s/g, "")));
            if (n.length < 4) for (var a = 0; a < 4 - n.length; a++) e.push(0);
            return e.concat(n);
        },
        encode: function(t, e) {
            for (var n, a, r, i, o = {
                "_bÇ": t = t,
                _bK: 0,
                _bf: function() {
                    return t.charCodeAt(o._bK++);
                }
            }, s = {
                "_ê": [],
                "_bÌ": -1,
                "_á": function(t) {
                    s._bÌ++, s._ê[s._bÌ] = t;
                },
                "_bÝ": function(t) {
                    function e() {
                        return t.apply(this, arguments);
                    }
                    return e.toString = function() {
                        return t.toString();
                    }, e;
                }(function() {
                    return _bÝ._bÌ--, _bÝ._bÌ < 0 && (_bÝ._bÌ = 0), _bÝ._ê[_bÝ._bÌ];
                })
            }, h = "", u = "9240gsB6PftGXnlQTw_pdvz7EekDmuAWCVZ5UF-MSK1IHOchoaxqYyj8Jb3LrNiR", l = 0; l < u.length; l++) s._á(u.charAt(l));
            s._á("=");
            var f = void 0 !== e ? Math.floor(64 * Math.random()) : -1;
            for (l = 0; l < t.length; l = o._bK) s._á(o._bf()), s._á(o._bf()), s._á(o._bf()), 
            n = s._ê[s._bÌ - 2] >> 2, a = (3 & s._ê[s._bÌ - 2]) << 4 | s._ê[s._bÌ - 1] >> 4, 
            r = (15 & s._ê[s._bÌ - 1]) << 2 | s._ê[s._bÌ] >> 6, i = 63 & s._ê[s._bÌ], isNaN(s._ê[s._bÌ - 1]) ? r = i = 64 : isNaN(s._ê[s._bÌ]) && (i = 64), 
            void 0 !== e && (n = e(n, f), a = e(a, f), r = e(r, f), i = e(i, f)), s._bÌ -= 3, 
            h = h + s._ê[n] + s._ê[a] + s._ê[r] + s._ê[i];
            return h.replace(/=/g, "") + (u[f] || "");
        },
        budget: function(t, e) {
            return 64 === t ? 64 : 63 === t ? e : t >= e ? t + 1 : t;
        }
    }, l = u;
    e.default = l;
}, function(t, e, n) {
    var a = n(0), r = a(n(2)), i = a(n(8)), o = a(n(9)), s = a(n(6)), h = a(n(4)), u = a(n(18)), l = i.default.f_s, f = i.default.f_b, c = i.default.f_n, d = i.default.f_j, _ = i.default.f_F, p = i.default.f_c, g = i.default.f_r, v = i.default.f_u, b = i.default.f_re, y = i.default.f_se, w = i.default.f_sh, m = i.default.f_jk, k = i.default.f_hk, S = i.default.f_ak, A = i.default.f_acc, x = i.default.f_dev, C = i.default.f_gyr, z = "";
    function H(t) {
        var e = t.sys, n = void 0 === e ? {} : e, a = t.batteryInfo, r = void 0 === a ? {} : a, i = t.networkType, o = void 0 === i ? {} : i, u = t.jsCode, z = void 0 === u ? {} : u, H = t.FKGJ, E = void 0 === H ? "" : H, T = t.cookie, N = void 0 === T ? "" : T, D = t.reportVersion, O = void 0 === D ? "" : D, I = t.uid, M = void 0 === I ? "" : I, B = t.reportTimestamp, R = void 0 === B ? "" : B, j = t.scene, F = void 0 === j ? "" : j, X = t.shareTicket, P = void 0 === X ? "" : X, L = t.app, J = void 0 === L ? "" : L, U = t.loginFlag, K = void 0 === U ? "" : U, W = t.apiLoginFlag, V = void 0 === W ? "" : W, q = t.accelerometerData, G = void 0 === q ? [] : q, Y = t.deviceMotionData, Q = void 0 === Y ? [] : Y, Z = t.gyroscopeData, $ = void 0 === Z ? [] : Z, tt = [].concat(s.default.es(l), s.default.es(JSON.stringify(n)), s.default.es(f), s.default.es(JSON.stringify(r)), s.default.es(c), s.default.es(JSON.stringify(o)), s.default.es(d), s.default.es(JSON.stringify(z)), s.default.es(_), s.default.es(E + ""), s.default.es(p), s.default.es(N), s.default.es(g), s.default.es(O), s.default.es(v), s.default.es(M), s.default.es(b), s.default.es(R), s.default.es(y), s.default.es(F), s.default.es(w), s.default.es(P), s.default.es(m), s.default.es(J), s.default.es(k), s.default.es(K), s.default.es(S), s.default.es(V), s.default.es(A), s.default.es(JSON.stringify(G)), s.default.es(x), s.default.es(JSON.stringify(Q)), s.default.es(C), s.default.es(JSON.stringify($)));
        return "0a" + s.default.base64(h.default.deflate(tt));
    }
    function E() {
        return new Promise(function(t) {
            wx && wx.getStorage || t(""), wx.getStorage({
                key: "e488cb9fe650282",
                success: function(e) {
                    if (!e || !e.data) return "";
                    var n = JSON.parse(e.data), a = n && n.a || "";
                    a && (z = a), t(a);
                },
                fail: function(e) {
                    t("");
                }
            });
        }).catch(function(t) {
            return "";
        });
    }
    function T(t, e, n, a, o) {
        t = t ? "" + t : "", e || (e = "wx-app"), n || (n = ""), a || (a = "");
        var s = Date.now();
        r.default.init(function() {
            var e = r.default.data;
            i.default.FingerIns.compositeAndEncrypt(e, function(t) {
                var e = i.default.FingerIns.data.reportTimestamp;
                (0, u.default)(t, e).then(function(t) {
                    z = t;
                });
            }, t, s, H, o);
        }, e, "", "", n, a), E();
    }
    function N() {
        this.uid = "", this.app = "", this.loginFlag = "", this.apiLoginFlag = "", this.intervalOn = !1, 
        E();
    }
    N.prototype.getFinger = function(t) {
        return !this.uid && t && (this.uid = t, T(this.uid, this.app, this.loginFlag, this.apiLoginFlag, !1)), 
        E(), z;
    }, N.prototype.setApp = function(t) {
        this.app = t;
    }, N.prototype.setIntervalOn = function(t) {
        this.intervalOn = t;
    }, N.prototype.setUid = function(t) {
        this.uid = t, T(this.uid, this.app, this.loginFlag, this.apiLoginFlag, !1);
    }, N.prototype.setLoginFlag = function(t) {
        void 0 !== t && (t || (t + "").trim()) && (this.loginFlag = t + "", T(this.uid, this.app, this.loginFlag, this.apiLoginFlag, !1));
    }, N.prototype.setApiLoginFlag = function(t) {
        void 0 !== t && (t || (t + "").trim()) && (this.apiLoginFlag = t + "", T(this.uid, this.app, this.loginFlag, this.apiLoginFlag, !1));
    };
    var D = new N();
    t.exports = {
        turtlemirror: o.default,
        dragonmirror: function(t, e, n) {
            return void 0 === n && (n = !1), n && !D.intervalOn && D.setIntervalOn(!0), T(t, e, void 0, void 0, D.intervalOn), 
            D.setApp(e), D.uid = t, D;
        }
    };
}, function(t, e, n) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var a = wx.startAccelerometer, r = wx.onAccelerometerChange, i = wx.startDeviceMotionListening, o = wx.onDeviceMotionChange, s = wx.startGyroscope, h = wx.onGyroscopeChange, u = function(t, e) {
        var n, a, r;
        return function() {
            var i = this, o = arguments;
            n ? (clearTimeout(a), a = setTimeout(function() {
                Date.now() - r >= e && (t.apply(i, o), r = Date.now());
            }, Math.max(e - (Date.now() - r), 0))) : (t.apply(i, o), r = Date.now(), n = !0);
        };
    };
    function l() {
        this.data = {
            senorOn: !1,
            senorCheck: !1,
            accelerometerData: [],
            deviceMotionData: [],
            gyroscopeData: []
        };
    }
    l.prototype.setParams = function(t) {
        this.data = Object.assign({}, this.data, t);
    }, l.prototype.compareVersion = function(t, e) {
        t = t.split("."), e = e.split(".");
        for (var n = Math.max(t.length, e.length); t.length < n; ) t.push("0");
        for (;e.length < n; ) e.push("0");
        for (var a = 0; a < n; a++) {
            var r = parseInt(t[a]), i = parseInt(e[a]);
            if (r > i) return 1;
            if (r < i) return -1;
        }
        return 0;
    }, l.prototype.setLocal = function(t, e) {
        try {
            wx.setStorage({
                key: t,
                data: e
            });
        } catch (t) {}
    }, l.prototype.getLocal = function(t, e) {
        var n = this;
        if (n.fingerANDfkgjKeyCache) e(n.fingerANDfkgjKeyCache); else try {
            wx.getStorage({
                key: t,
                success: function(t) {
                    if (!t || !t.data) return e("");
                    n.fingerANDfkgjKeyCache = t.data, e(t.data);
                },
                fail: function(t) {
                    e("");
                }
            });
        } catch (t) {
            e("");
        }
    }, l.prototype.getCookieANDfkgj = function(t, e) {
        var n = this;
        this.getLocal("e488cb9fe650282", function(a) {
            if (a) {
                var r = JSON.parse(a);
                if (r) {
                    var i = r.a, o = void 0 === i ? "" : i, s = r.b;
                    return (h = void 0 === s ? "" : s) || (h = parseInt(Math.random() * (Math.pow(2, 52) + 1), 10) + parseInt(String(Math.random() * (Math.pow(2, 30) + 1)), 10) + e), 
                    n.setLocal("e488cb9fe650282", JSON.stringify({
                        a: o,
                        b: h
                    })), void t({
                        a: o,
                        b: h
                    });
                }
            }
            var h = parseInt(Math.random() * (Math.pow(2, 52) + 1), 10) + parseInt(String(Math.random() * (Math.pow(2, 30) + 1)), 10) + e;
            o = "";
            n.setLocal("e488cb9fe650282", JSON.stringify({
                a: o,
                b: h
            })), t({
                a: o,
                b: h
            });
        });
    }, l.prototype.accelerometer = function() {
        var t = this;
        a({
            success: function(e) {
                r(u(function(e) {
                    if (e) {
                        var n = e.x, a = e.y, r = e.z;
                        t.data.accelerometerData.length <= 10 && t.data.accelerometerData.push({
                            x: n,
                            y: a,
                            z: r,
                            ts: Date.now()
                        });
                    }
                }, 2e3));
            },
            fail: function(t) {}
        });
    }, l.prototype.deviceMotion = function() {
        var t = this;
        i({
            success: function(e) {
                o(u(function(e) {
                    var n = e.alpha, a = e.beta, r = e.gamma;
                    t.data.deviceMotionData.length <= 10 && t.data.deviceMotionData.push({
                        a: n,
                        b: a,
                        g: r,
                        ts: Date.now()
                    });
                }, 2e3));
            },
            fail: function(t) {}
        });
    }, l.prototype.gyroscope = function() {
        var t = this;
        s({
            success: function(e) {
                h(u(function(e) {
                    var n = e.x, a = e.y, r = e.z;
                    t.data.gyroscopeData.length <= 10 && t.data.gyroscopeData.push({
                        x: n,
                        y: a,
                        z: r,
                        ts: Date.now()
                    });
                }, 2e3));
            },
            fail: function(t) {}
        });
    }, l.prototype.composite = function(t) {
        var e = this, n = {};
        e.getFKGJ(function(a) {
            var r = a;
            e.getCookie(function(a) {
                var i = Object.assign({}, t, {
                    jsCode: n,
                    FKGJ: r,
                    cookie: a,
                    reportVersion: "1.1.1",
                    reportTimestamp: new Date().getTime() + ""
                });
                e.setParams(i);
            });
        });
    }, l.prototype.compositeAndEncrypt = function(t, e, n, a, r, i) {
        var o = this;
        i && !o.data.senorOn && (o.accelerometer(), o.deviceMotion(), o.gyroscope(), o.data.senorOn = !0);
        try {
            var s = {}, h = function() {
                o.getCookieANDfkgj(function(a) {
                    var i = a.a, h = a.b, u = Object.assign({}, t, {
                        jsCode: s,
                        FKGJ: h,
                        cookie: i,
                        reportVersion: "1.1.1",
                        uid: n,
                        reportTimestamp: new Date().getTime() + ""
                    });
                    o.setParams(u), o.getMessagePack(function(t) {
                        e(t), o.data.accelerometerData = [], o.data.deviceMotionData = [], o.data.gyroscopeData = [];
                    }, r);
                }, a);
            };
            i && !o.data.senorCheck && (o.data.senorCheck = !0, setInterval(function() {
                (o.data.accelerometerData.length >= 10 || o.data.deviceMotionData.length >= 10 || o.data.gyroscopeData.length >= 10) && h();
            }, 5)), h();
        } catch (t) {
            e("");
        }
    }, l.prototype.getMessagePack = function(t, e) {
        t(e(this.data));
    };
    var f = {
        f_s: "sys",
        f_b: "batteryInfo",
        f_n: "networkType",
        f_j: "jsCode",
        f_F: "FKGJ",
        f_c: "cookie",
        f_r: "reportVersion",
        f_u: "uid",
        f_re: "reportTimestamp",
        f_se: "scene",
        f_sh: "shareTicket",
        f_jk: "app",
        FingerIns: new l(),
        f_om: "isvPageCode",
        f_yk: "isvScene",
        f_hk: "loginFlag",
        f_ak: "apiLoginFlag",
        f_acc: "accelerometerData",
        f_dev: "deviceMotionData",
        f_gyr: "gyroscopeData"
    };
    e.default = f;
}, function(t, e, n) {
    (function(t) {
        var a = n(0);
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = function(t) {
            return t.serverTime && M.updateServerTime(t.serverTime), M;
        };
        var r, i, o = a(n(4)), s = a(n(6)), h = a(n(2)), u = 0, l = "", f = Math, c = Date, d = getCurrentPages;
        function _() {
            return new Promise(function(t) {
                wx && wx.getStorage || t(""), wx.getStorage({
                    key: "e488cb9fe650282",
                    success: function(e) {
                        if (!e || !e.data) return "";
                        var n = JSON.parse(e.data);
                        l = n && n.a || "", t(l);
                    },
                    fail: function(e) {
                        t("");
                    }
                });
            }).catch(function(t) {
                return "";
            });
        }
        function p() {
            var e = void 0 === t ? null : t, n = [];
            n[0] = e && e.versions && e.versions.modules ? 1 : 0;
            for (var a = 0, r = 0; r < n.length; r++) a += n[r] << r;
            return a;
        }
        function g(t) {
            for (var e = t || {}, n = e.systemInfoAsync, a = e.fingerprintAsync, r = n || function() {
                try {
                    return wx && wx.getSystemInfoSync ? wx.getSystemInfoSync() : {};
                } catch (t) {
                    return {};
                }
            }(), i = a || function() {
                try {
                    if (!wx || !wx.getStorageSync) return "";
                    var t = wx.getStorageSync("e488cb9fe650282");
                    if (!t || !t.data) return "";
                    var e = JSON.parse(t.data);
                    return e && e.a || "";
                } catch (t) {
                    return "";
                }
            }() || l, h = r.model, u = r.pixelRatio, f = r.version, c = r.system, d = r.platform, _ = r.fontSizeSetting, p = r.SDKVersion, g = [].concat(v.packN(), x.packN(h), b.packN(), y.packN(), O.packN(), w.packN(), k.packN(), S.packN(), m.packN(), A.packN(), C.packN(u), z.packN(f), H.packN(c), E.packN(d), T.packN(_), N.packN(p), D.packN(i)), I = g.length.toString(2).split(""), M = 0; I.length < 16; M += 1) I.unshift("0");
            I = I.join("");
            var B = [];
            0 === g.length ? B.push(0, 0) : g.length > 0 && g.length <= 255 ? B.push(0, g.length) : g.length > 255 && B.push(parseInt(I.substring(0, 8), 2), parseInt(I.substring(8, 16), 2)), 
            g = [].concat([ 3 ], [ 3, 0, 0 ], B, g);
            var R = o.default.deflate(g), j = [].map.call(R, function(t) {
                return String.fromCharCode(t);
            });
            return "3ak" + s.default.encode(j.join(""), s.default.budget);
        }
        var v = {
            init: function() {
                v.data = p();
            },
            packN: function() {
                return [].concat(s.default.ek(1), s.default.va(v.data));
            }
        }, b = {
            init: function() {
                b.data = function() {
                    try {
                        return (("function" == typeof d ? d() : []) || []).map(function(t) {
                            return t && t.route || "";
                        }).slice(-3);
                    } catch (t) {
                        return [];
                    }
                }() || [];
            },
            packN: function() {
                if (b.init(), 0 === b.data.length) return [];
                var t = [].concat(s.default.ek(3, b.data));
                return b.data.forEach(function(e) {
                    var n = s.default.scAnti(e);
                    t = t.concat(s.default.va(n.length), n);
                }), t;
            }
        }, y = {
            init: function() {
                y.data = 0;
            },
            packN: function() {
                return [].concat(s.default.ek(4, y.data));
            }
        }, w = {
            init: function() {
                w.data = "".concat(parseInt(f.random() * (f.pow(2, 52) + 1), 10) + parseInt(String(f.random() * (f.pow(2, 30) + 1)), 10), "-").concat(r);
            },
            packN: function() {
                return w.init(), [].concat(s.default.ek(6, w.data));
            }
        }, m = {
            init: function(t) {
                m.data = t;
            },
            packN: function() {
                return [].concat(s.default.ek(9, m.data));
            }
        }, k = {
            init: function(t) {
                k.data = String(t);
            },
            packN: function() {
                return 0 === (k.data || "").length ? [] : [].concat(s.default.ek(7, k.data));
            }
        }, S = {
            init: function(t) {
                S.data = String(t);
            },
            packN: function() {
                return 0 === (S.data || "").length ? [] : [].concat(s.default.ek(8, S.data));
            }
        }, A = {
            init: function() {
                A.data = c.now() - i;
            },
            packN: function() {
                return A.init(), [].concat(s.default.ek(10, A.data));
            }
        }, x = {
            init: function(t) {
                x.data = t;
            },
            packN: function(t) {
                return x.init(t), 0 === (x.data || "").length ? [] : [].concat(s.default.ek(2, x.data));
            }
        }, C = {
            init: function(t) {
                C.data = t;
            },
            packN: function(t) {
                return C.init(t), 0 === (C.data || "").length ? [] : [].concat(s.default.ek(11), s.default.va(C.data));
            }
        }, z = {
            init: function(t) {
                z.data = t;
            },
            packN: function(t) {
                return z.init(t), 0 === (z.data || "").length ? [] : [].concat(s.default.ek(12, z.data));
            }
        }, H = {
            init: function(t) {
                H.data = t;
            },
            packN: function(t) {
                return H.init(t), 0 === (H.data || "").length ? [] : [].concat(s.default.ek(13, H.data));
            }
        }, E = {
            init: function(t) {
                E.data = t;
            },
            packN: function(t) {
                return E.init(t), 0 === (E.data || "").length ? [] : [].concat(s.default.ek(14, E.data));
            }
        }, T = {
            init: function(t) {
                T.data = t;
            },
            packN: function(t) {
                return T.init(t), 0 === (T.data || "").length ? [] : [].concat(s.default.ek(15), s.default.va(T.data));
            }
        }, N = {
            init: function(t) {
                N.data = t;
            },
            packN: function(t) {
                return N.init(t), 0 === (N.data || "").length ? [] : [].concat(s.default.ek(16, N.data));
            }
        }, D = {
            init: function(t) {
                D.data = t;
            },
            packN: function(t) {
                return D.init(t), 0 === (D.data || "").length ? [] : [].concat(s.default.ek(17, D.data));
            }
        }, O = {
            init: function() {
                O.data = s.default.pbc(p.toString() + h.default.getSysInfo.toString() + g.toString());
            },
            packN: function() {
                return [].concat(s.default.ek(5), O.data);
            }
        };
        function I() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.updateServerTime(t.serverTime || 879609302220), u = c.now(), h.default.getSysInfo(), 
            _().then(function(t) {
                l = t;
            }), function(t) {
                [ v, m, y, O ].forEach(function(e) {
                    e.init(t);
                });
                var e = h.default.getSceneAndTicket() || {}, n = e.scene, a = e.shareTicket;
                k.init(n), S.init(a);
            }(u);
        }
        I.prototype.updateServerTime = function(t) {
            i = c.now(), r = t;
        }, I.prototype.messageDepacketize = function() {
            return _(), y.data++, g();
        };
        var M = new I();
    }).call(this, n(3));
}, function(t, e, n) {
    var a, r = n(1), i = n(11), o = n(12), s = n(13), h = n(5), u = -2, l = 258, f = 262, c = 103, d = 113, _ = 666;
    function p(t, e) {
        return t.msg = h[e], e;
    }
    function g(t) {
        return (t << 1) - (t > 4 ? 9 : 0);
    }
    function v(t) {
        for (var e = t.length; --e >= 0; ) t[e] = 0;
    }
    function b(t) {
        var e = t.state, n = e.pending;
        n > t.avail_out && (n = t.avail_out), 0 !== n && (r.arraySet(t.output, e.pending_buf, e.pending_out, n, t.next_out), 
        t.next_out += n, e.pending_out += n, t.total_out += n, t.avail_out -= n, e.pending -= n, 
        0 === e.pending && (e.pending_out = 0));
    }
    function y(t, e) {
        i._tr_flush_block(t, t.block_start >= 0 ? t.block_start : -1, t.strstart - t.block_start, e), 
        t.block_start = t.strstart, b(t.strm);
    }
    function w(t, e) {
        t.pending_buf[t.pending++] = e;
    }
    function m(t, e) {
        t.pending_buf[t.pending++] = e >>> 8 & 255, t.pending_buf[t.pending++] = 255 & e;
    }
    function k(t, e) {
        var n, a, r = t.max_chain_length, i = t.strstart, o = t.prev_length, s = t.nice_match, h = t.strstart > t.w_size - f ? t.strstart - (t.w_size - f) : 0, u = t.window, c = t.w_mask, d = t.prev, _ = t.strstart + l, p = u[i + o - 1], g = u[i + o];
        t.prev_length >= t.good_match && (r >>= 2), s > t.lookahead && (s = t.lookahead);
        do {
            if (u[(n = e) + o] === g && u[n + o - 1] === p && u[n] === u[i] && u[++n] === u[i + 1]) {
                i += 2, n++;
                do {} while (u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && u[++i] === u[++n] && i < _);
                if (a = l - (_ - i), i = _ - l, a > o) {
                    if (t.match_start = e, o = a, a >= s) break;
                    p = u[i + o - 1], g = u[i + o];
                }
            }
        } while ((e = d[e & c]) > h && 0 != --r);
        return o <= t.lookahead ? o : t.lookahead;
    }
    function S(t) {
        var e, n, a, i, h, u, l, c, d, _, p = t.w_size;
        do {
            if (i = t.window_size - t.lookahead - t.strstart, t.strstart >= p + (p - f)) {
                r.arraySet(t.window, t.window, p, p, 0), t.match_start -= p, t.strstart -= p, t.block_start -= p, 
                e = n = t.hash_size;
                do {
                    a = t.head[--e], t.head[e] = a >= p ? a - p : 0;
                } while (--n);
                e = n = p;
                do {
                    a = t.prev[--e], t.prev[e] = a >= p ? a - p : 0;
                } while (--n);
                i += p;
            }
            if (0 === t.strm.avail_in) break;
            if (u = t.strm, l = t.window, c = t.strstart + t.lookahead, d = i, _ = void 0, (_ = u.avail_in) > d && (_ = d), 
            n = 0 === _ ? 0 : (u.avail_in -= _, r.arraySet(l, u.input, u.next_in, _, c), 1 === u.state.wrap ? u.adler = o(u.adler, l, _, c) : 2 === u.state.wrap && (u.adler = s(u.adler, l, _, c)), 
            u.next_in += _, u.total_in += _, _), t.lookahead += n, t.lookahead + t.insert >= 3) for (h = t.strstart - t.insert, 
            t.ins_h = t.window[h], t.ins_h = (t.ins_h << t.hash_shift ^ t.window[h + 1]) & t.hash_mask; t.insert && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[h + 3 - 1]) & t.hash_mask, 
            t.prev[h & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = h, h++, t.insert--, !(t.lookahead + t.insert < 3)); ) ;
        } while (t.lookahead < f && 0 !== t.strm.avail_in);
    }
    function A(t, e) {
        for (var n, a; ;) {
            if (t.lookahead < f) {
                if (S(t), t.lookahead < f && 0 === e) return 1;
                if (0 === t.lookahead) break;
            }
            if (n = 0, t.lookahead >= 3 && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 3 - 1]) & t.hash_mask, 
            n = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), 
            0 !== n && t.strstart - n <= t.w_size - f && (t.match_length = k(t, n)), t.match_length >= 3) if (a = i._tr_tally(t, t.strstart - t.match_start, t.match_length - 3), 
            t.lookahead -= t.match_length, t.match_length <= t.max_lazy_match && t.lookahead >= 3) {
                t.match_length--;
                do {
                    t.strstart++, t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 3 - 1]) & t.hash_mask, 
                    n = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart;
                } while (0 != --t.match_length);
                t.strstart++;
            } else t.strstart += t.match_length, t.match_length = 0, t.ins_h = t.window[t.strstart], 
            t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 1]) & t.hash_mask; else a = i._tr_tally(t, 0, t.window[t.strstart]), 
            t.lookahead--, t.strstart++;
            if (a && (y(t, !1), 0 === t.strm.avail_out)) return 1;
        }
        return t.insert = t.strstart < 2 ? t.strstart : 2, 4 === e ? (y(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (y(t, !1), 
        0 === t.strm.avail_out) ? 1 : 2;
    }
    function x(t, e) {
        for (var n, a, r; ;) {
            if (t.lookahead < f) {
                if (S(t), t.lookahead < f && 0 === e) return 1;
                if (0 === t.lookahead) break;
            }
            if (n = 0, t.lookahead >= 3 && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 3 - 1]) & t.hash_mask, 
            n = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart), 
            t.prev_length = t.match_length, t.prev_match = t.match_start, t.match_length = 2, 
            0 !== n && t.prev_length < t.max_lazy_match && t.strstart - n <= t.w_size - f && (t.match_length = k(t, n), 
            t.match_length <= 5 && (1 === t.strategy || 3 === t.match_length && t.strstart - t.match_start > 4096) && (t.match_length = 2)), 
            t.prev_length >= 3 && t.match_length <= t.prev_length) {
                r = t.strstart + t.lookahead - 3, a = i._tr_tally(t, t.strstart - 1 - t.prev_match, t.prev_length - 3), 
                t.lookahead -= t.prev_length - 1, t.prev_length -= 2;
                do {
                    ++t.strstart <= r && (t.ins_h = (t.ins_h << t.hash_shift ^ t.window[t.strstart + 3 - 1]) & t.hash_mask, 
                    n = t.prev[t.strstart & t.w_mask] = t.head[t.ins_h], t.head[t.ins_h] = t.strstart);
                } while (0 != --t.prev_length);
                if (t.match_available = 0, t.match_length = 2, t.strstart++, a && (y(t, !1), 0 === t.strm.avail_out)) return 1;
            } else if (t.match_available) {
                if ((a = i._tr_tally(t, 0, t.window[t.strstart - 1])) && y(t, !1), t.strstart++, 
                t.lookahead--, 0 === t.strm.avail_out) return 1;
            } else t.match_available = 1, t.strstart++, t.lookahead--;
        }
        return t.match_available && (a = i._tr_tally(t, 0, t.window[t.strstart - 1]), t.match_available = 0), 
        t.insert = t.strstart < 2 ? t.strstart : 2, 4 === e ? (y(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (y(t, !1), 
        0 === t.strm.avail_out) ? 1 : 2;
    }
    function C(t, e, n, a, r) {
        this.good_length = t, this.max_lazy = e, this.nice_length = n, this.max_chain = a, 
        this.func = r;
    }
    function z(t) {
        var e;
        return t && t.state ? (t.total_in = t.total_out = 0, t.data_type = 2, (e = t.state).pending = 0, 
        e.pending_out = 0, e.wrap < 0 && (e.wrap = -e.wrap), e.status = e.wrap ? 42 : d, 
        t.adler = 2 === e.wrap ? 0 : 1, e.last_flush = 0, i._tr_init(e), 0) : p(t, u);
    }
    function H(t) {
        var e, n = z(t);
        return 0 === n && ((e = t.state).window_size = 2 * e.w_size, v(e.head), e.max_lazy_match = a[e.level].max_lazy, 
        e.good_match = a[e.level].good_length, e.nice_match = a[e.level].nice_length, e.max_chain_length = a[e.level].max_chain, 
        e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = 2, 
        e.match_available = 0, e.ins_h = 0), n;
    }
    function E(t, e, n, a, i, o) {
        if (!t) return u;
        var s = 1;
        if (-1 === e && (e = 6), a < 0 ? (s = 0, a = -a) : a > 15 && (s = 2, a -= 16), i < 1 || i > 9 || 8 !== n || a < 8 || a > 15 || e < 0 || e > 9 || o < 0 || o > 4) return p(t, u);
        8 === a && (a = 9);
        var h = new function() {
            this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, 
            this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, 
            this.method = 8, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, 
            this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, 
            this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, 
            this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, 
            this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, 
            this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, 
            this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new r.Buf16(1146), this.dyn_dtree = new r.Buf16(122), 
            this.bl_tree = new r.Buf16(78), v(this.dyn_ltree), v(this.dyn_dtree), v(this.bl_tree), 
            this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new r.Buf16(16), 
            this.heap = new r.Buf16(573), v(this.heap), this.heap_len = 0, this.heap_max = 0, 
            this.depth = new r.Buf16(573), v(this.depth), this.l_buf = 0, this.lit_bufsize = 0, 
            this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, 
            this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
        }();
        return t.state = h, h.strm = t, h.wrap = s, h.gzhead = null, h.w_bits = a, h.w_size = 1 << h.w_bits, 
        h.w_mask = h.w_size - 1, h.hash_bits = i + 7, h.hash_size = 1 << h.hash_bits, h.hash_mask = h.hash_size - 1, 
        h.hash_shift = ~~((h.hash_bits + 3 - 1) / 3), h.window = new r.Buf8(2 * h.w_size), 
        h.head = new r.Buf16(h.hash_size), h.prev = new r.Buf16(h.w_size), h.lit_bufsize = 1 << i + 6, 
        h.pending_buf_size = 4 * h.lit_bufsize, h.pending_buf = new r.Buf8(h.pending_buf_size), 
        h.d_buf = 1 * h.lit_bufsize, h.l_buf = 3 * h.lit_bufsize, h.level = e, h.strategy = o, 
        h.method = n, H(t);
    }
    a = [ new C(0, 0, 0, 0, function(t, e) {
        var n = 65535;
        for (n > t.pending_buf_size - 5 && (n = t.pending_buf_size - 5); ;) {
            if (t.lookahead <= 1) {
                if (S(t), 0 === t.lookahead && 0 === e) return 1;
                if (0 === t.lookahead) break;
            }
            t.strstart += t.lookahead, t.lookahead = 0;
            var a = t.block_start + n;
            if ((0 === t.strstart || t.strstart >= a) && (t.lookahead = t.strstart - a, t.strstart = a, 
            y(t, !1), 0 === t.strm.avail_out)) return 1;
            if (t.strstart - t.block_start >= t.w_size - f && (y(t, !1), 0 === t.strm.avail_out)) return 1;
        }
        return t.insert = 0, 4 === e ? (y(t, !0), 0 === t.strm.avail_out ? 3 : 4) : (t.strstart > t.block_start && (y(t, !1), 
        t.strm.avail_out), 1);
    }), new C(4, 4, 8, 4, A), new C(4, 5, 16, 8, A), new C(4, 6, 32, 32, A), new C(4, 4, 16, 16, x), new C(8, 16, 32, 32, x), new C(8, 16, 128, 128, x), new C(8, 32, 128, 256, x), new C(32, 128, 258, 1024, x), new C(32, 258, 258, 4096, x) ], 
    e.deflateInit = function(t, e) {
        return E(t, e, 8, 15, 8, 0);
    }, e.deflateInit2 = E, e.deflateReset = H, e.deflateResetKeep = z, e.deflateSetHeader = function(t, e) {
        return t && t.state ? 2 !== t.state.wrap ? u : (t.state.gzhead = e, 0) : u;
    }, e.deflate = function(t, e) {
        var n, r, o, h;
        if (!t || !t.state || e > 5 || e < 0) return t ? p(t, u) : u;
        if (r = t.state, !t.output || !t.input && 0 !== t.avail_in || r.status === _ && 4 !== e) return p(t, 0 === t.avail_out ? -5 : u);
        if (r.strm = t, n = r.last_flush, r.last_flush = e, 42 === r.status) if (2 === r.wrap) t.adler = 0, 
        w(r, 31), w(r, 139), w(r, 8), r.gzhead ? (w(r, (r.gzhead.text ? 1 : 0) + (r.gzhead.hcrc ? 2 : 0) + (r.gzhead.extra ? 4 : 0) + (r.gzhead.name ? 8 : 0) + (r.gzhead.comment ? 16 : 0)), 
        w(r, 255 & r.gzhead.time), w(r, r.gzhead.time >> 8 & 255), w(r, r.gzhead.time >> 16 & 255), 
        w(r, r.gzhead.time >> 24 & 255), w(r, 9 === r.level ? 2 : r.strategy >= 2 || r.level < 2 ? 4 : 0), 
        w(r, 255 & r.gzhead.os), r.gzhead.extra && r.gzhead.extra.length && (w(r, 255 & r.gzhead.extra.length), 
        w(r, r.gzhead.extra.length >> 8 & 255)), r.gzhead.hcrc && (t.adler = s(t.adler, r.pending_buf, r.pending, 0)), 
        r.gzindex = 0, r.status = 69) : (w(r, 0), w(r, 0), w(r, 0), w(r, 0), w(r, 0), w(r, 9 === r.level ? 2 : r.strategy >= 2 || r.level < 2 ? 4 : 0), 
        w(r, 3), r.status = d); else {
            var f = 8 + (r.w_bits - 8 << 4) << 8;
            f |= (r.strategy >= 2 || r.level < 2 ? 0 : r.level < 6 ? 1 : 6 === r.level ? 2 : 3) << 6, 
            0 !== r.strstart && (f |= 32), f += 31 - f % 31, r.status = d, m(r, f), 0 !== r.strstart && (m(r, t.adler >>> 16), 
            m(r, 65535 & t.adler)), t.adler = 1;
        }
        if (69 === r.status) if (r.gzhead.extra) {
            for (o = r.pending; r.gzindex < (65535 & r.gzhead.extra.length) && (r.pending !== r.pending_buf_size || (r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
            b(t), o = r.pending, r.pending !== r.pending_buf_size)); ) w(r, 255 & r.gzhead.extra[r.gzindex]), 
            r.gzindex++;
            r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
            r.gzindex === r.gzhead.extra.length && (r.gzindex = 0, r.status = 73);
        } else r.status = 73;
        if (73 === r.status) if (r.gzhead.name) {
            o = r.pending;
            do {
                if (r.pending === r.pending_buf_size && (r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
                b(t), o = r.pending, r.pending === r.pending_buf_size)) {
                    h = 1;
                    break;
                }
                h = r.gzindex < r.gzhead.name.length ? 255 & r.gzhead.name.charCodeAt(r.gzindex++) : 0, 
                w(r, h);
            } while (0 !== h);
            r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
            0 === h && (r.gzindex = 0, r.status = 91);
        } else r.status = 91;
        if (91 === r.status) if (r.gzhead.comment) {
            o = r.pending;
            do {
                if (r.pending === r.pending_buf_size && (r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
                b(t), o = r.pending, r.pending === r.pending_buf_size)) {
                    h = 1;
                    break;
                }
                h = r.gzindex < r.gzhead.comment.length ? 255 & r.gzhead.comment.charCodeAt(r.gzindex++) : 0, 
                w(r, h);
            } while (0 !== h);
            r.gzhead.hcrc && r.pending > o && (t.adler = s(t.adler, r.pending_buf, r.pending - o, o)), 
            0 === h && (r.status = c);
        } else r.status = c;
        if (r.status === c && (r.gzhead.hcrc ? (r.pending + 2 > r.pending_buf_size && b(t), 
        r.pending + 2 <= r.pending_buf_size && (w(r, 255 & t.adler), w(r, t.adler >> 8 & 255), 
        t.adler = 0, r.status = d)) : r.status = d), 0 !== r.pending) {
            if (b(t), 0 === t.avail_out) return r.last_flush = -1, 0;
        } else if (0 === t.avail_in && g(e) <= g(n) && 4 !== e) return p(t, -5);
        if (r.status === _ && 0 !== t.avail_in) return p(t, -5);
        if (0 !== t.avail_in || 0 !== r.lookahead || 0 !== e && r.status !== _) {
            var k = 2 === r.strategy ? function(t, e) {
                for (var n; ;) {
                    if (0 === t.lookahead && (S(t), 0 === t.lookahead)) {
                        if (0 === e) return 1;
                        break;
                    }
                    if (t.match_length = 0, n = i._tr_tally(t, 0, t.window[t.strstart]), t.lookahead--, 
                    t.strstart++, n && (y(t, !1), 0 === t.strm.avail_out)) return 1;
                }
                return t.insert = 0, 4 === e ? (y(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (y(t, !1), 
                0 === t.strm.avail_out) ? 1 : 2;
            }(r, e) : 3 === r.strategy ? function(t, e) {
                for (var n, a, r, o, s = t.window; ;) {
                    if (t.lookahead <= l) {
                        if (S(t), t.lookahead <= l && 0 === e) return 1;
                        if (0 === t.lookahead) break;
                    }
                    if (t.match_length = 0, t.lookahead >= 3 && t.strstart > 0 && (a = s[r = t.strstart - 1]) === s[++r] && a === s[++r] && a === s[++r]) {
                        o = t.strstart + l;
                        do {} while (a === s[++r] && a === s[++r] && a === s[++r] && a === s[++r] && a === s[++r] && a === s[++r] && a === s[++r] && a === s[++r] && r < o);
                        t.match_length = l - (o - r), t.match_length > t.lookahead && (t.match_length = t.lookahead);
                    }
                    if (t.match_length >= 3 ? (n = i._tr_tally(t, 1, t.match_length - 3), t.lookahead -= t.match_length, 
                    t.strstart += t.match_length, t.match_length = 0) : (n = i._tr_tally(t, 0, t.window[t.strstart]), 
                    t.lookahead--, t.strstart++), n && (y(t, !1), 0 === t.strm.avail_out)) return 1;
                }
                return t.insert = 0, 4 === e ? (y(t, !0), 0 === t.strm.avail_out ? 3 : 4) : t.last_lit && (y(t, !1), 
                0 === t.strm.avail_out) ? 1 : 2;
            }(r, e) : a[r.level].func(r, e);
            if (3 !== k && 4 !== k || (r.status = _), 1 === k || 3 === k) return 0 === t.avail_out && (r.last_flush = -1), 
            0;
            if (2 === k && (1 === e ? i._tr_align(r) : 5 !== e && (i._tr_stored_block(r, 0, 0, !1), 
            3 === e && (v(r.head), 0 === r.lookahead && (r.strstart = 0, r.block_start = 0, 
            r.insert = 0))), b(t), 0 === t.avail_out)) return r.last_flush = -1, 0;
        }
        return 4 !== e ? 0 : r.wrap <= 0 ? 1 : (2 === r.wrap ? (w(r, 255 & t.adler), w(r, t.adler >> 8 & 255), 
        w(r, t.adler >> 16 & 255), w(r, t.adler >> 24 & 255), w(r, 255 & t.total_in), w(r, t.total_in >> 8 & 255), 
        w(r, t.total_in >> 16 & 255), w(r, t.total_in >> 24 & 255)) : (m(r, t.adler >>> 16), 
        m(r, 65535 & t.adler)), b(t), r.wrap > 0 && (r.wrap = -r.wrap), 0 !== r.pending ? 0 : 1);
    }, e.deflateEnd = function(t) {
        var e;
        return t && t.state ? 42 !== (e = t.state.status) && 69 !== e && 73 !== e && 91 !== e && e !== c && e !== d && e !== _ ? p(t, u) : (t.state = null, 
        e === d ? p(t, -3) : 0) : u;
    }, e.deflateSetDictionary = function(t, e) {
        var n, a, i, s, h, l, f, c, d = e.length;
        if (!t || !t.state) return u;
        if (2 === (s = (n = t.state).wrap) || 1 === s && 42 !== n.status || n.lookahead) return u;
        for (1 === s && (t.adler = o(t.adler, e, d, 0)), n.wrap = 0, d >= n.w_size && (0 === s && (v(n.head), 
        n.strstart = 0, n.block_start = 0, n.insert = 0), c = new r.Buf8(n.w_size), r.arraySet(c, e, d - n.w_size, n.w_size, 0), 
        e = c, d = n.w_size), h = t.avail_in, l = t.next_in, f = t.input, t.avail_in = d, 
        t.next_in = 0, t.input = e, S(n); n.lookahead >= 3; ) {
            a = n.strstart, i = n.lookahead - 2;
            do {
                n.ins_h = (n.ins_h << n.hash_shift ^ n.window[a + 3 - 1]) & n.hash_mask, n.prev[a & n.w_mask] = n.head[n.ins_h], 
                n.head[n.ins_h] = a, a++;
            } while (--i);
            n.strstart = a, n.lookahead = 2, S(n);
        }
        return n.strstart += n.lookahead, n.block_start = n.strstart, n.insert = n.lookahead, 
        n.lookahead = 0, n.match_length = n.prev_length = 2, n.match_available = 0, t.next_in = l, 
        t.input = f, t.avail_in = h, n.wrap = s, 0;
    }, e.deflateInfo = "pako deflate (from Nodeca project)";
}, function(t, e, n) {
    var a = n(1);
    function r(t) {
        for (var e = t.length; --e >= 0; ) t[e] = 0;
    }
    var i = 256, o = 286, s = 30, h = 15, u = [ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 ], l = [ 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 ], f = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7 ], c = [ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ], d = new Array(576);
    r(d);
    var _ = new Array(60);
    r(_);
    var p = new Array(512);
    r(p);
    var g = new Array(256);
    r(g);
    var v = new Array(29);
    r(v);
    var b, y, w, m = new Array(s);
    function k(t, e, n, a, r) {
        this.static_tree = t, this.extra_bits = e, this.extra_base = n, this.elems = a, 
        this.max_length = r, this.has_stree = t && t.length;
    }
    function S(t, e) {
        this.dyn_tree = t, this.max_code = 0, this.stat_desc = e;
    }
    function A(t) {
        return t < 256 ? p[t] : p[256 + (t >>> 7)];
    }
    function x(t, e) {
        t.pending_buf[t.pending++] = 255 & e, t.pending_buf[t.pending++] = e >>> 8 & 255;
    }
    function C(t, e, n) {
        t.bi_valid > 16 - n ? (t.bi_buf |= e << t.bi_valid & 65535, x(t, t.bi_buf), t.bi_buf = e >> 16 - t.bi_valid, 
        t.bi_valid += n - 16) : (t.bi_buf |= e << t.bi_valid & 65535, t.bi_valid += n);
    }
    function z(t, e, n) {
        C(t, n[2 * e], n[2 * e + 1]);
    }
    function H(t, e) {
        var n = 0;
        do {
            n |= 1 & t, t >>>= 1, n <<= 1;
        } while (--e > 0);
        return n >>> 1;
    }
    function E(t, e, n) {
        var a, r, i = new Array(16), o = 0;
        for (a = 1; a <= h; a++) i[a] = o = o + n[a - 1] << 1;
        for (r = 0; r <= e; r++) {
            var s = t[2 * r + 1];
            0 !== s && (t[2 * r] = H(i[s]++, s));
        }
    }
    function T(t) {
        var e;
        for (e = 0; e < o; e++) t.dyn_ltree[2 * e] = 0;
        for (e = 0; e < s; e++) t.dyn_dtree[2 * e] = 0;
        for (e = 0; e < 19; e++) t.bl_tree[2 * e] = 0;
        t.dyn_ltree[512] = 1, t.opt_len = t.static_len = 0, t.last_lit = t.matches = 0;
    }
    function N(t) {
        t.bi_valid > 8 ? x(t, t.bi_buf) : t.bi_valid > 0 && (t.pending_buf[t.pending++] = t.bi_buf), 
        t.bi_buf = 0, t.bi_valid = 0;
    }
    function D(t, e, n, a) {
        var r = 2 * e, i = 2 * n;
        return t[r] < t[i] || t[r] === t[i] && a[e] <= a[n];
    }
    function O(t, e, n) {
        for (var a = t.heap[n], r = n << 1; r <= t.heap_len && (r < t.heap_len && D(e, t.heap[r + 1], t.heap[r], t.depth) && r++, 
        !D(e, a, t.heap[r], t.depth)); ) t.heap[n] = t.heap[r], n = r, r <<= 1;
        t.heap[n] = a;
    }
    function I(t, e, n) {
        var a, r, o, s, h = 0;
        if (0 !== t.last_lit) do {
            a = t.pending_buf[t.d_buf + 2 * h] << 8 | t.pending_buf[t.d_buf + 2 * h + 1], r = t.pending_buf[t.l_buf + h], 
            h++, 0 === a ? z(t, r, e) : (z(t, (o = g[r]) + i + 1, e), 0 !== (s = u[o]) && C(t, r -= v[o], s), 
            z(t, o = A(--a), n), 0 !== (s = l[o]) && C(t, a -= m[o], s));
        } while (h < t.last_lit);
        z(t, 256, e);
    }
    function M(t, e) {
        var n, a, r, i = e.dyn_tree, o = e.stat_desc.static_tree, s = e.stat_desc.has_stree, u = e.stat_desc.elems, l = -1;
        for (t.heap_len = 0, t.heap_max = 573, n = 0; n < u; n++) 0 !== i[2 * n] ? (t.heap[++t.heap_len] = l = n, 
        t.depth[n] = 0) : i[2 * n + 1] = 0;
        for (;t.heap_len < 2; ) i[2 * (r = t.heap[++t.heap_len] = l < 2 ? ++l : 0)] = 1, 
        t.depth[r] = 0, t.opt_len--, s && (t.static_len -= o[2 * r + 1]);
        for (e.max_code = l, n = t.heap_len >> 1; n >= 1; n--) O(t, i, n);
        r = u;
        do {
            n = t.heap[1], t.heap[1] = t.heap[t.heap_len--], O(t, i, 1), a = t.heap[1], t.heap[--t.heap_max] = n, 
            t.heap[--t.heap_max] = a, i[2 * r] = i[2 * n] + i[2 * a], t.depth[r] = (t.depth[n] >= t.depth[a] ? t.depth[n] : t.depth[a]) + 1, 
            i[2 * n + 1] = i[2 * a + 1] = r, t.heap[1] = r++, O(t, i, 1);
        } while (t.heap_len >= 2);
        t.heap[--t.heap_max] = t.heap[1], function(t, e) {
            var n, a, r, i, o, s, u = e.dyn_tree, l = e.max_code, f = e.stat_desc.static_tree, c = e.stat_desc.has_stree, d = e.stat_desc.extra_bits, _ = e.stat_desc.extra_base, p = e.stat_desc.max_length, g = 0;
            for (i = 0; i <= h; i++) t.bl_count[i] = 0;
            for (u[2 * t.heap[t.heap_max] + 1] = 0, n = t.heap_max + 1; n < 573; n++) (i = u[2 * u[2 * (a = t.heap[n]) + 1] + 1] + 1) > p && (i = p, 
            g++), u[2 * a + 1] = i, a > l || (t.bl_count[i]++, o = 0, a >= _ && (o = d[a - _]), 
            s = u[2 * a], t.opt_len += s * (i + o), c && (t.static_len += s * (f[2 * a + 1] + o)));
            if (0 !== g) {
                do {
                    for (i = p - 1; 0 === t.bl_count[i]; ) i--;
                    t.bl_count[i]--, t.bl_count[i + 1] += 2, t.bl_count[p]--, g -= 2;
                } while (g > 0);
                for (i = p; 0 !== i; i--) for (a = t.bl_count[i]; 0 !== a; ) (r = t.heap[--n]) > l || (u[2 * r + 1] !== i && (t.opt_len += (i - u[2 * r + 1]) * u[2 * r], 
                u[2 * r + 1] = i), a--);
            }
        }(t, e), E(i, l, t.bl_count);
    }
    function B(t, e, n) {
        var a, r, i = -1, o = e[1], s = 0, h = 7, u = 4;
        for (0 === o && (h = 138, u = 3), e[2 * (n + 1) + 1] = 65535, a = 0; a <= n; a++) r = o, 
        o = e[2 * (a + 1) + 1], ++s < h && r === o || (s < u ? t.bl_tree[2 * r] += s : 0 !== r ? (r !== i && t.bl_tree[2 * r]++, 
        t.bl_tree[32]++) : s <= 10 ? t.bl_tree[34]++ : t.bl_tree[36]++, s = 0, i = r, 0 === o ? (h = 138, 
        u = 3) : r === o ? (h = 6, u = 3) : (h = 7, u = 4));
    }
    function R(t, e, n) {
        var a, r, i = -1, o = e[1], s = 0, h = 7, u = 4;
        for (0 === o && (h = 138, u = 3), a = 0; a <= n; a++) if (r = o, o = e[2 * (a + 1) + 1], 
        !(++s < h && r === o)) {
            if (s < u) do {
                z(t, r, t.bl_tree);
            } while (0 != --s); else 0 !== r ? (r !== i && (z(t, r, t.bl_tree), s--), z(t, 16, t.bl_tree), 
            C(t, s - 3, 2)) : s <= 10 ? (z(t, 17, t.bl_tree), C(t, s - 3, 3)) : (z(t, 18, t.bl_tree), 
            C(t, s - 11, 7));
            s = 0, i = r, 0 === o ? (h = 138, u = 3) : r === o ? (h = 6, u = 3) : (h = 7, u = 4);
        }
    }
    r(m);
    var j = !1;
    function F(t, e, n, r) {
        C(t, 0 + (r ? 1 : 0), 3), function(t, e, n, r) {
            N(t), x(t, n), x(t, ~n), a.arraySet(t.pending_buf, t.window, e, n, t.pending), t.pending += n;
        }(t, e, n);
    }
    e._tr_init = function(t) {
        j || (function() {
            var t, e, n, a, r, i = new Array(16);
            for (n = 0, a = 0; a < 28; a++) for (v[a] = n, t = 0; t < 1 << u[a]; t++) g[n++] = a;
            for (g[n - 1] = a, r = 0, a = 0; a < 16; a++) for (m[a] = r, t = 0; t < 1 << l[a]; t++) p[r++] = a;
            for (r >>= 7; a < s; a++) for (m[a] = r << 7, t = 0; t < 1 << l[a] - 7; t++) p[256 + r++] = a;
            for (e = 0; e <= h; e++) i[e] = 0;
            for (t = 0; t <= 143; ) d[2 * t + 1] = 8, t++, i[8]++;
            for (;t <= 255; ) d[2 * t + 1] = 9, t++, i[9]++;
            for (;t <= 279; ) d[2 * t + 1] = 7, t++, i[7]++;
            for (;t <= 287; ) d[2 * t + 1] = 8, t++, i[8]++;
            for (E(d, 287, i), t = 0; t < s; t++) _[2 * t + 1] = 5, _[2 * t] = H(t, 5);
            b = new k(d, u, 257, o, h), y = new k(_, l, 0, s, h), w = new k(new Array(0), f, 0, 19, 7);
        }(), j = !0), t.l_desc = new S(t.dyn_ltree, b), t.d_desc = new S(t.dyn_dtree, y), 
        t.bl_desc = new S(t.bl_tree, w), t.bi_buf = 0, t.bi_valid = 0, T(t);
    }, e._tr_stored_block = F, e._tr_flush_block = function(t, e, n, a) {
        var r, o, s = 0;
        t.level > 0 ? (2 === t.strm.data_type && (t.strm.data_type = function(t) {
            var e, n = 4093624447;
            for (e = 0; e <= 31; e++, n >>>= 1) if (1 & n && 0 !== t.dyn_ltree[2 * e]) return 0;
            if (0 !== t.dyn_ltree[18] || 0 !== t.dyn_ltree[20] || 0 !== t.dyn_ltree[26]) return 1;
            for (e = 32; e < i; e++) if (0 !== t.dyn_ltree[2 * e]) return 1;
            return 0;
        }(t)), M(t, t.l_desc), M(t, t.d_desc), s = function(t) {
            var e;
            for (B(t, t.dyn_ltree, t.l_desc.max_code), B(t, t.dyn_dtree, t.d_desc.max_code), 
            M(t, t.bl_desc), e = 18; e >= 3 && 0 === t.bl_tree[2 * c[e] + 1]; e--) ;
            return t.opt_len += 3 * (e + 1) + 5 + 5 + 4, e;
        }(t), r = t.opt_len + 3 + 7 >>> 3, (o = t.static_len + 3 + 7 >>> 3) <= r && (r = o)) : r = o = n + 5, 
        n + 4 <= r && -1 !== e ? F(t, e, n, a) : 4 === t.strategy || o === r ? (C(t, 2 + (a ? 1 : 0), 3), 
        I(t, d, _)) : (C(t, 4 + (a ? 1 : 0), 3), function(t, e, n, a) {
            var r;
            for (C(t, e - 257, 5), C(t, n - 1, 5), C(t, a - 4, 4), r = 0; r < a; r++) C(t, t.bl_tree[2 * c[r] + 1], 3);
            R(t, t.dyn_ltree, e - 1), R(t, t.dyn_dtree, n - 1);
        }(t, t.l_desc.max_code + 1, t.d_desc.max_code + 1, s + 1), I(t, t.dyn_ltree, t.dyn_dtree)), 
        T(t), a && N(t);
    }, e._tr_tally = function(t, e, n) {
        return t.pending_buf[t.d_buf + 2 * t.last_lit] = e >>> 8 & 255, t.pending_buf[t.d_buf + 2 * t.last_lit + 1] = 255 & e, 
        t.pending_buf[t.l_buf + t.last_lit] = 255 & n, t.last_lit++, 0 === e ? t.dyn_ltree[2 * n]++ : (t.matches++, 
        e--, t.dyn_ltree[2 * (g[n] + i + 1)]++, t.dyn_dtree[2 * A(e)]++), t.last_lit === t.lit_bufsize - 1;
    }, e._tr_align = function(t) {
        C(t, 2, 3), z(t, 256, d), function(t) {
            16 === t.bi_valid ? (x(t, t.bi_buf), t.bi_buf = 0, t.bi_valid = 0) : t.bi_valid >= 8 && (t.pending_buf[t.pending++] = 255 & t.bi_buf, 
            t.bi_buf >>= 8, t.bi_valid -= 8);
        }(t);
    };
}, function(t, e, n) {
    t.exports = function(t, e, n, a) {
        for (var r = 65535 & t | 0, i = t >>> 16 & 65535 | 0, o = 0; 0 !== n; ) {
            n -= o = n > 2e3 ? 2e3 : n;
            do {
                i = i + (r = r + e[a++] | 0) | 0;
            } while (--o);
            r %= 65521, i %= 65521;
        }
        return r | i << 16 | 0;
    };
}, function(t, e, n) {
    var a = function() {
        for (var t, e = [], n = 0; n < 256; n++) {
            t = n;
            for (var a = 0; a < 8; a++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
            e[n] = t;
        }
        return e;
    }();
    t.exports = function(t, e, n, r) {
        var i = a, o = r + n;
        t ^= -1;
        for (var s = r; s < o; s++) t = t >>> 8 ^ i[255 & (t ^ e[s])];
        return -1 ^ t;
    };
}, function(t, e, n) {
    var a = n(1), r = !0, i = !0;
    try {
        String.fromCharCode.apply(null, [ 0 ]);
    } catch (t) {
        r = !1;
    }
    try {
        String.fromCharCode.apply(null, new Uint8Array(1));
    } catch (t) {
        i = !1;
    }
    for (var o = new a.Buf8(256), s = 0; s < 256; s++) o[s] = s >= 252 ? 6 : s >= 248 ? 5 : s >= 240 ? 4 : s >= 224 ? 3 : s >= 192 ? 2 : 1;
    function h(t, e) {
        if (e < 65534 && (t.subarray && i || !t.subarray && r)) return String.fromCharCode.apply(null, a.shrinkBuf(t, e));
        for (var n = "", o = 0; o < e; o++) n += String.fromCharCode(t[o]);
        return n;
    }
    o[254] = o[254] = 1, e.string2buf = function(t) {
        var e, n, r, i, o, s = t.length, h = 0;
        for (i = 0; i < s; i++) 55296 == (64512 & (n = t.charCodeAt(i))) && i + 1 < s && 56320 == (64512 & (r = t.charCodeAt(i + 1))) && (n = 65536 + (n - 55296 << 10) + (r - 56320), 
        i++), h += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
        for (e = new a.Buf8(h), o = 0, i = 0; o < h; i++) 55296 == (64512 & (n = t.charCodeAt(i))) && i + 1 < s && 56320 == (64512 & (r = t.charCodeAt(i + 1))) && (n = 65536 + (n - 55296 << 10) + (r - 56320), 
        i++), n < 128 ? e[o++] = n : n < 2048 ? (e[o++] = 192 | n >>> 6, e[o++] = 128 | 63 & n) : n < 65536 ? (e[o++] = 224 | n >>> 12, 
        e[o++] = 128 | n >>> 6 & 63, e[o++] = 128 | 63 & n) : (e[o++] = 240 | n >>> 18, 
        e[o++] = 128 | n >>> 12 & 63, e[o++] = 128 | n >>> 6 & 63, e[o++] = 128 | 63 & n);
        return e;
    }, e.buf2binstring = function(t) {
        return h(t, t.length);
    }, e.binstring2buf = function(t) {
        for (var e = new a.Buf8(t.length), n = 0, r = e.length; n < r; n++) e[n] = t.charCodeAt(n);
        return e;
    }, e.buf2string = function(t, e) {
        var n, a, r, i, s = e || t.length, u = new Array(2 * s);
        for (a = 0, n = 0; n < s; ) if ((r = t[n++]) < 128) u[a++] = r; else if ((i = o[r]) > 4) u[a++] = 65533, 
        n += i - 1; else {
            for (r &= 2 === i ? 31 : 3 === i ? 15 : 7; i > 1 && n < s; ) r = r << 6 | 63 & t[n++], 
            i--;
            i > 1 ? u[a++] = 65533 : r < 65536 ? u[a++] = r : (r -= 65536, u[a++] = 55296 | r >> 10 & 1023, 
            u[a++] = 56320 | 1023 & r);
        }
        return h(u, a);
    }, e.utf8border = function(t, e) {
        var n;
        for ((e = e || t.length) > t.length && (e = t.length), n = e - 1; n >= 0 && 128 == (192 & t[n]); ) n--;
        return n < 0 || 0 === n ? e : n + o[t[n]] > e ? n : e;
    };
}, function(t, e, n) {
    t.exports = function() {
        this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, 
        this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, 
        this.data_type = 2, this.adler = 0;
    };
}, function(t, e, n) {
    t.exports = function(t, e, n) {
        if ((e -= (t += "").length) <= 0) return t;
        if (n || 0 === n || (n = " "), " " == (n += "") && e < 10) return a[e] + t;
        for (var r = ""; 1 & e && (r += n), e >>= 1; ) n += n;
        return r + t;
    };
    var a = [ "", " ", "  ", "   ", "    ", "     ", "      ", "       ", "        ", "         " ];
}, function(t, e, n) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        t = function(t) {
            for (var e = "", n = 0; n < t.length; n++) {
                var a = t.charCodeAt(n);
                a < 128 ? e += String.fromCharCode(a) : a < 2048 ? e += String.fromCharCode(192 | a >> 6) + String.fromCharCode(128 | 63 & a) : a < 55296 || a >= 57344 ? e += String.fromCharCode(224 | a >> 12) + String.fromCharCode(128 | a >> 6 & 63) + String.fromCharCode(128 | 63 & a) : (a = 65536 + ((1023 & a) << 10 | 1023 & t.charCodeAt(++n)), 
                e += String.fromCharCode(240 | a >> 18) + String.fromCharCode(128 | a >> 12 & 63) + String.fromCharCode(128 | a >> 6 & 63) + String.fromCharCode(128 | 63 & a));
            }
            return e;
        }(t), e ^= -1;
        for (var n = 0; n < t.length; n++) e = e >>> 8 ^ a[255 & (e ^ t.charCodeAt(n))];
        return (-1 ^ e) >>> 0;
    };
    var a = function() {
        for (var t, e = [], n = 0; n < 256; n++) {
            t = n;
            for (var a = 0; a < 8; a++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
            e[n] = t;
        }
        return e;
    }();
}, function(t, e, n) {
    var a = n(0);
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = a(n(19));
    e.default = function(t, e) {
        var n = {
            data: t,
            timestamp: e,
            appKey: "fe",
            sign: (0, r.default)("feJDRTPWEGD5623DSL" + e.toString() + t)
        };
        return new Promise(function(t) {
            wx.request({
                url: "".concat("https://xg.pinduoduo.com").concat("/xg/pfb/wxapp"),
                data: JSON.stringify(n),
                method: "POST",
                success: function(e) {
                    if (200 === e.statusCode) {
                        var n = e.data;
                        if (n.success) {
                            var a = n.result, r = a.a, i = void 0 === r ? "" : r, o = a.b, s = void 0 === o ? "" : o;
                            try {
                                i && s && wx.setStorage({
                                    key: "e488cb9fe650282",
                                    data: JSON.stringify({
                                        a: i,
                                        b: s
                                    })
                                });
                            } catch (t) {} finally {
                                t(i);
                            }
                        } else t("");
                    } else t("");
                },
                fail: function(e) {
                    t("");
                }
            });
        }).catch(function(t) {
            return "";
        });
    };
}, function(module, exports, __webpack_require__) {
    (function(process, global) {
        var __WEBPACK_AMD_DEFINE_RESULT__;
        !function() {
            var root = "object" == ("undefined" == typeof window ? "undefined" : _typeof2(window)) ? window : {}, NODE_JS = !root.JS_SHA1_NO_NODE_JS && "object" == _typeof2(process) && process.versions && process.versions.node;
            NODE_JS && (root = global);
            var COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && "object" == _typeof2(module) && module.exports, AMD = __webpack_require__(21), HEX_CHARS = "0123456789abcdef".split(""), EXTRA = [ -2147483648, 8388608, 32768, 128 ], SHIFT = [ 24, 16, 8, 0 ], OUTPUT_TYPES = [ "hex", "array", "digest", "arrayBuffer" ], blocks = [], createOutputMethod = function(t) {
                return function(e) {
                    return new Sha1(!0).update(e)[t]();
                };
            }, createMethod = function() {
                var t = createOutputMethod("hex");
                NODE_JS && (t = nodeWrap(t)), t.create = function() {
                    return new Sha1();
                }, t.update = function(e) {
                    return t.create().update(e);
                };
                for (var e = 0; e < OUTPUT_TYPES.length; ++e) {
                    var n = OUTPUT_TYPES[e];
                    t[n] = createOutputMethod(n);
                }
                return t;
            }, nodeWrap = function nodeWrap(method) {
                var crypto = eval("require('crypto')"), Buffer = eval("require('buffer').Buffer"), nodeMethod = function(t) {
                    if ("string" == typeof t) return crypto.createHash("sha1").update(t, "utf8").digest("hex");
                    if (t.constructor === ArrayBuffer) t = new Uint8Array(t); else if (void 0 === t.length) return method(t);
                    return crypto.createHash("sha1").update(new Buffer(t)).digest("hex");
                };
                return nodeMethod;
            };
            function Sha1(t) {
                t ? (blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0, 
                this.blocks = blocks) : this.blocks = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ], 
                this.h0 = 1732584193, this.h1 = 4023233417, this.h2 = 2562383102, this.h3 = 271733878, 
                this.h4 = 3285377520, this.block = this.start = this.bytes = this.hBytes = 0, this.finalized = this.hashed = !1, 
                this.first = !0;
            }
            Sha1.prototype.update = function(t) {
                if (!this.finalized) {
                    var e = "string" != typeof t;
                    e && t.constructor === root.ArrayBuffer && (t = new Uint8Array(t));
                    for (var n, a, r = 0, i = t.length || 0, o = this.blocks; r < i; ) {
                        if (this.hashed && (this.hashed = !1, o[0] = this.block, o[16] = o[1] = o[2] = o[3] = o[4] = o[5] = o[6] = o[7] = o[8] = o[9] = o[10] = o[11] = o[12] = o[13] = o[14] = o[15] = 0), 
                        e) for (a = this.start; r < i && a < 64; ++r) o[a >> 2] |= t[r] << SHIFT[3 & a++]; else for (a = this.start; r < i && a < 64; ++r) (n = t.charCodeAt(r)) < 128 ? o[a >> 2] |= n << SHIFT[3 & a++] : n < 2048 ? (o[a >> 2] |= (192 | n >> 6) << SHIFT[3 & a++], 
                        o[a >> 2] |= (128 | 63 & n) << SHIFT[3 & a++]) : n < 55296 || n >= 57344 ? (o[a >> 2] |= (224 | n >> 12) << SHIFT[3 & a++], 
                        o[a >> 2] |= (128 | n >> 6 & 63) << SHIFT[3 & a++], o[a >> 2] |= (128 | 63 & n) << SHIFT[3 & a++]) : (n = 65536 + ((1023 & n) << 10 | 1023 & t.charCodeAt(++r)), 
                        o[a >> 2] |= (240 | n >> 18) << SHIFT[3 & a++], o[a >> 2] |= (128 | n >> 12 & 63) << SHIFT[3 & a++], 
                        o[a >> 2] |= (128 | n >> 6 & 63) << SHIFT[3 & a++], o[a >> 2] |= (128 | 63 & n) << SHIFT[3 & a++]);
                        this.lastByteIndex = a, this.bytes += a - this.start, a >= 64 ? (this.block = o[16], 
                        this.start = a - 64, this.hash(), this.hashed = !0) : this.start = a;
                    }
                    return this.bytes > 4294967295 && (this.hBytes += this.bytes / 4294967296 << 0, 
                    this.bytes = this.bytes % 4294967296), this;
                }
            }, Sha1.prototype.finalize = function() {
                if (!this.finalized) {
                    this.finalized = !0;
                    var t = this.blocks, e = this.lastByteIndex;
                    t[16] = this.block, t[e >> 2] |= EXTRA[3 & e], this.block = t[16], e >= 56 && (this.hashed || this.hash(), 
                    t[0] = this.block, t[16] = t[1] = t[2] = t[3] = t[4] = t[5] = t[6] = t[7] = t[8] = t[9] = t[10] = t[11] = t[12] = t[13] = t[14] = t[15] = 0), 
                    t[14] = this.hBytes << 3 | this.bytes >>> 29, t[15] = this.bytes << 3, this.hash();
                }
            }, Sha1.prototype.hash = function() {
                var t, e, n = this.h0, a = this.h1, r = this.h2, i = this.h3, o = this.h4, s = this.blocks;
                for (t = 16; t < 80; ++t) e = s[t - 3] ^ s[t - 8] ^ s[t - 14] ^ s[t - 16], s[t] = e << 1 | e >>> 31;
                for (t = 0; t < 20; t += 5) n = (e = (a = (e = (r = (e = (i = (e = (o = (e = n << 5 | n >>> 27) + (a & r | ~a & i) + o + 1518500249 + s[t] << 0) << 5 | o >>> 27) + (n & (a = a << 30 | a >>> 2) | ~n & r) + i + 1518500249 + s[t + 1] << 0) << 5 | i >>> 27) + (o & (n = n << 30 | n >>> 2) | ~o & a) + r + 1518500249 + s[t + 2] << 0) << 5 | r >>> 27) + (i & (o = o << 30 | o >>> 2) | ~i & n) + a + 1518500249 + s[t + 3] << 0) << 5 | a >>> 27) + (r & (i = i << 30 | i >>> 2) | ~r & o) + n + 1518500249 + s[t + 4] << 0, 
                r = r << 30 | r >>> 2;
                for (;t < 40; t += 5) n = (e = (a = (e = (r = (e = (i = (e = (o = (e = n << 5 | n >>> 27) + (a ^ r ^ i) + o + 1859775393 + s[t] << 0) << 5 | o >>> 27) + (n ^ (a = a << 30 | a >>> 2) ^ r) + i + 1859775393 + s[t + 1] << 0) << 5 | i >>> 27) + (o ^ (n = n << 30 | n >>> 2) ^ a) + r + 1859775393 + s[t + 2] << 0) << 5 | r >>> 27) + (i ^ (o = o << 30 | o >>> 2) ^ n) + a + 1859775393 + s[t + 3] << 0) << 5 | a >>> 27) + (r ^ (i = i << 30 | i >>> 2) ^ o) + n + 1859775393 + s[t + 4] << 0, 
                r = r << 30 | r >>> 2;
                for (;t < 60; t += 5) n = (e = (a = (e = (r = (e = (i = (e = (o = (e = n << 5 | n >>> 27) + (a & r | a & i | r & i) + o - 1894007588 + s[t] << 0) << 5 | o >>> 27) + (n & (a = a << 30 | a >>> 2) | n & r | a & r) + i - 1894007588 + s[t + 1] << 0) << 5 | i >>> 27) + (o & (n = n << 30 | n >>> 2) | o & a | n & a) + r - 1894007588 + s[t + 2] << 0) << 5 | r >>> 27) + (i & (o = o << 30 | o >>> 2) | i & n | o & n) + a - 1894007588 + s[t + 3] << 0) << 5 | a >>> 27) + (r & (i = i << 30 | i >>> 2) | r & o | i & o) + n - 1894007588 + s[t + 4] << 0, 
                r = r << 30 | r >>> 2;
                for (;t < 80; t += 5) n = (e = (a = (e = (r = (e = (i = (e = (o = (e = n << 5 | n >>> 27) + (a ^ r ^ i) + o - 899497514 + s[t] << 0) << 5 | o >>> 27) + (n ^ (a = a << 30 | a >>> 2) ^ r) + i - 899497514 + s[t + 1] << 0) << 5 | i >>> 27) + (o ^ (n = n << 30 | n >>> 2) ^ a) + r - 899497514 + s[t + 2] << 0) << 5 | r >>> 27) + (i ^ (o = o << 30 | o >>> 2) ^ n) + a - 899497514 + s[t + 3] << 0) << 5 | a >>> 27) + (r ^ (i = i << 30 | i >>> 2) ^ o) + n - 899497514 + s[t + 4] << 0, 
                r = r << 30 | r >>> 2;
                this.h0 = this.h0 + n << 0, this.h1 = this.h1 + a << 0, this.h2 = this.h2 + r << 0, 
                this.h3 = this.h3 + i << 0, this.h4 = this.h4 + o << 0;
            }, Sha1.prototype.hex = function() {
                this.finalize();
                var t = this.h0, e = this.h1, n = this.h2, a = this.h3, r = this.h4;
                return HEX_CHARS[t >> 28 & 15] + HEX_CHARS[t >> 24 & 15] + HEX_CHARS[t >> 20 & 15] + HEX_CHARS[t >> 16 & 15] + HEX_CHARS[t >> 12 & 15] + HEX_CHARS[t >> 8 & 15] + HEX_CHARS[t >> 4 & 15] + HEX_CHARS[15 & t] + HEX_CHARS[e >> 28 & 15] + HEX_CHARS[e >> 24 & 15] + HEX_CHARS[e >> 20 & 15] + HEX_CHARS[e >> 16 & 15] + HEX_CHARS[e >> 12 & 15] + HEX_CHARS[e >> 8 & 15] + HEX_CHARS[e >> 4 & 15] + HEX_CHARS[15 & e] + HEX_CHARS[n >> 28 & 15] + HEX_CHARS[n >> 24 & 15] + HEX_CHARS[n >> 20 & 15] + HEX_CHARS[n >> 16 & 15] + HEX_CHARS[n >> 12 & 15] + HEX_CHARS[n >> 8 & 15] + HEX_CHARS[n >> 4 & 15] + HEX_CHARS[15 & n] + HEX_CHARS[a >> 28 & 15] + HEX_CHARS[a >> 24 & 15] + HEX_CHARS[a >> 20 & 15] + HEX_CHARS[a >> 16 & 15] + HEX_CHARS[a >> 12 & 15] + HEX_CHARS[a >> 8 & 15] + HEX_CHARS[a >> 4 & 15] + HEX_CHARS[15 & a] + HEX_CHARS[r >> 28 & 15] + HEX_CHARS[r >> 24 & 15] + HEX_CHARS[r >> 20 & 15] + HEX_CHARS[r >> 16 & 15] + HEX_CHARS[r >> 12 & 15] + HEX_CHARS[r >> 8 & 15] + HEX_CHARS[r >> 4 & 15] + HEX_CHARS[15 & r];
            }, Sha1.prototype.toString = Sha1.prototype.hex, Sha1.prototype.digest = function() {
                this.finalize();
                var t = this.h0, e = this.h1, n = this.h2, a = this.h3, r = this.h4;
                return [ t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, 255 & t, e >> 24 & 255, e >> 16 & 255, e >> 8 & 255, 255 & e, n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, 255 & n, a >> 24 & 255, a >> 16 & 255, a >> 8 & 255, 255 & a, r >> 24 & 255, r >> 16 & 255, r >> 8 & 255, 255 & r ];
            }, Sha1.prototype.array = Sha1.prototype.digest, Sha1.prototype.arrayBuffer = function() {
                this.finalize();
                var t = new ArrayBuffer(20), e = new DataView(t);
                return e.setUint32(0, this.h0), e.setUint32(4, this.h1), e.setUint32(8, this.h2), 
                e.setUint32(12, this.h3), e.setUint32(16, this.h4), t;
            };
            var exports = createMethod();
            COMMON_JS ? module.exports = exports : (root.sha1 = exports, AMD && (__WEBPACK_AMD_DEFINE_RESULT__ = function() {
                return exports;
            }.call(exports, __webpack_require__, exports, module), void 0 === __WEBPACK_AMD_DEFINE_RESULT__ || (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)));
        }();
    }).call(this, __webpack_require__(3), __webpack_require__(20));
}, function(t, e) {
    var n;
    n = function() {
        return this;
    }();
    try {
        n = n || new Function("return this")();
    } catch (t) {
        "object" == ("undefined" == typeof window ? "undefined" : _typeof2(window)) && (n = window);
    }
    t.exports = n;
}, function(t, e) {
    (function(e) {
        t.exports = e;
    }).call(this, {});
} ]);