var e = require("_/helpers/interopRequireDefault");

require("_/helpers/Objectvalues");

var a, n = require("_/helpers/defineProperty"), t = require("_/helpers/objectSpread2"), r = require("$app"), i = require("@ktt/ktt-wxapp-boundle"), o = e(require("a/a")), s = i.time.getServerTimeSync, p = i.wxappUtils.getNetworkType, u = i.wxappUtils.subscribeNetworkChange, c = i.wxapp.pddApp, d = null, h = function() {
    var e = (0, r.k5)(), n = e.brand, t = e.model, i = e.language, o = e.system;
    a && a(), a = u(function(e) {
        var a = e.networkType;
        (0, r.fy)({
            url: "/api/ktt_rec/rec_feeds/set_user_env_info",
            noErrorToast: !0,
            data: {
                user_env_info: {
                    manufacture: n,
                    model: t,
                    language: i,
                    system: o,
                    network: a
                }
            },
            noRequestLog: !0
        }).catch(r.hm);
    }), p();
};

c({
    store: r.fv,
    getServerTimeSync: s,
    $CMT_AMPLIFY_RATE: 10,
    $appData: {},
    $ENV: "test" === r.fu.env ? "hutaojie" : "production",
    env: wx.getAccountInfoSync().miniProgram.envVersion || "release",
    $apiCategory: "default",
    $onLaunchOptions: {},
    onLaunch: function(e) {
        var a = this;
        r.m4.call(this);
        var n = e || {}, t = n.scene, i = n.referrerInfo, s = n.apiCategory;
        this.$onLaunchOptions = e, this.$referrerInfo = i, this.$apiCategory = s || "default", 
        r.na.setBasicParams({
            apiCategory: this.$apiCategory,
            referAppId: i && (0, r.qh)(i, "appid") || "unknow"
        }), (0, r.f0)(), (0, r.l_)(), this.$fingerSdk = o.default.dragonmirror("", "ktt-wxapp"), 
        this.$antiSdk = o.default.turtlemirror({
            serverTime: Date.now()
        }), (0, r.gi)().then(function(e) {
            (0, r.gk)({
                serverTime: e
            }), a.updateAntiSkdServerTime(e);
        }), (0, r.gl)().init(), r.f9.listenOnce(r.f1.onSocketOpen, function() {
            (0, r.r5)();
        }), 1154 !== t && ((0, r.rj)({
            success: function(e) {
                (0, r.eh)(e), (0, r.si)(!0, !0);
            },
            fail: function() {
                r.f9.trigger("quietSignInComplete");
            }
        }), r.f9.listen("bSignIn", function(e) {
            var a = e.hasMall, n = e.token, t = e.mallId, i = e.callback;
            (0, r.qp)({
                token: n,
                hasMall: a,
                mallId: t
            }), (0, r.pl)(), i && i();
        }), (0, r.qx)(), (0, r.qy)()), this.addBasePerformanceLog(), this.getBaseInfo(), 
        (0, r.fo)().then(function(e) {
            var n = e.data;
            a.$titanHttpLocalDisable = n;
        }).catch(function() {}), (0, r.m1)();
    },
    updateAntiSkdServerTime: function(e) {
        var a = this;
        d && clearTimeout(d), e || (e = s() || Date.now()), this.$antiSdk && this.$antiSdk.updateServerTime(e), 
        d = setTimeout(function() {
            a.updateAntiSkdServerTime();
        }, 36e5);
    },
    getBaseInfo: function() {
        var e = (0, r.k5)();
        if (e) {
            (0, r.hk)((0, r.q5)(e)), (0, r.hk)((0, r.qt)((0, r.e6)()));
            var a = e.platform && "ios" === e.platform.toLowerCase(), n = e.platform && "android" === e.platform.toLowerCase(), t = a || n, i = e.model && -1 !== e.model.toLowerCase().indexOf("ipad"), o = e.screenHeight >= 812, s = a && !i && o ? (0, 
            r.ov)(34) : 0, p = (0, r.ke)();
            Object.assign(this.$appData, {
                areaBottom: s,
                isIOS: a,
                isAndroid: n,
                isMobile: t,
                isIpad: i,
                headerInfo: p
            });
        }
    },
    addBasePerformanceLog: function() {
        var e = this;
        if ((0, r.ev)({
            onceAppOnLaunch: !0,
            type: r.u.APP_LAUNCH
        }), wx.canIUse("getPerformance")) {
            var a = wx.getPerformance();
            if (!a.createObserver) return;
            var n = new r.gp();
            this.perf = a.createObserver(function(a) {
                var t = a.getEntries(), r = a.getEntriesByType("render"), i = a.getEntriesByType("navigation");
                (r.length || i.length) && n.listenPerformanceEntryChange(a.getEntries()), e.reportBatch(t);
            });
            var t = (0, r.g3)("2.24.0");
            this.perf.observe({
                entryTypes: t ? [ "render", "navigation", "script", "loadPackage" ] : [ "render", "navigation", "script" ]
            });
        }
    },
    reportBatch: function(e) {
        var a = {
            hasEval: !1,
            moduleName: ""
        }, n = {
            evaluateDuration: 0
        }, i = {
            hasFirstRender: !1,
            firstRenderPath: ""
        }, o = {
            firstRenderDuration: 0
        }, s = {
            hasRoute: !1,
            routePath: "",
            routeNavigationType: ""
        }, p = {
            routeDuration: 0
        }, u = {
            hasAppLaunch: !1,
            appLaunchPath: "",
            appLaunchNavigationType: ""
        }, c = {
            appLaunchDuration: 0
        }, d = {
            hasDownloadPackage: !1,
            downloadPackageName: ""
        }, h = {
            downloadPackageDuration: 0
        };
        e.forEach(function(e) {
            var t = e.name, r = e.duration, f = e.path, g = e.moduleName, l = e.navigationType, m = e.packageName;
            if (r) switch (t) {
              case "appLaunch":
                u.hasAppLaunch = !0, u.appLaunchPath = f, u.appLaunchNavigationType = l, c.appLaunchDuration = r;
                break;

              case "firstRender":
                i.hasFirstRender = !0, i.firstRenderPath = f, o.firstRenderDuration = r;
                break;

              case "route":
                s.hasRoute = !0, s.routePath = f, s.routeNavigationType = l, p.routeDuration = r;
                break;

              case "evaluateScript":
                a.hasEval = !0, a.moduleName && g === a.moduleName ? n.evaluateDuration += r : a.moduleName || (a.moduleName = g, 
                n.evaluateDuration += r);
                break;

              case "downloadPackage":
                d.hasDownloadPackage = !0, d.downloadPackageName = m, h.downloadPackageDuration = r;
            }
        });
        var f = {
            type: r.u.PERF_BATCH_REPORT,
            tags: t(t(t(t(t(t({}, a), i), s), u), d), {}, {
                env: this.env
            }),
            longFields: t(t(t(t(t({}, n), o), p), c), h)
        };
        (0, r.ev)(f);
    },
    onSign: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.uid, n = e.uin;
        (0, r.n9)(this.$onLaunchOptions), (0, r.sl)(e), r.na.setBasicParams({
            uin: n,
            user_id: a,
            hash: new Date().getTime()
        }), (0, r.l9)({
            user_id: a
        }), (0, r.lp)({
            forceUpdate: !0
        }).catch(r.hm), (0, r.sg)().catch(r.hm), (0, r.sb)(), h(), (0, r.gr)().getConfig({
            forceUpdate: !0
        }).then(function(e) {
            (0, r.l8)((0, r.qh)(e, "pmmErrFilter"));
        });
    },
    onSignInComplete: function() {
        (0, r.m2)();
    },
    judgePrivateMessage: function(e) {
        wx.authPrivateMessage && "function" == typeof wx.authPrivateMessage && wx.authPrivateMessage({
            shareTicket: e,
            success: function(a) {
                (0, r.l7)({
                    name: "app authPrivateMessage success",
                    e: a,
                    msg: "".concat(e, " app authPrivateMessage success")
                });
            },
            fail: function(a) {
                (0, r.l7)({
                    name: "app authPrivateMessage fail",
                    e: a,
                    msg: "".concat(e, " app authPrivateMessage fail")
                });
            }
        });
    },
    onShow: function(e) {
        (0, r.gy)();
        var a = e.path, t = e.scene, i = e.shareTicket, o = void 0 === i ? "" : i, s = e.referrerInfo, p = e.apiCategory, u = (0, 
        r.qh)(s || {}, "appId") || "unknown";
        (this.$referrerInfo = s, this.$apiCategory = p || "default", r.na.setBasicParams({
            apiCategory: this.$apiCategory,
            referAppId: u
        }), 1167 != +t && 1037 != +t || "wx57849631bb367f52" === u || (0, r.gr)().getConfig().then(function(a) {
            var t = (0, r.qh)(a, "ban1167Appid.value") || [], i = t.find(function(e) {
                return e.appid === u;
            });
            !!t.find(function(e) {
                return e.white_appid === u;
            }) || (i && (null == i ? void 0 : i.no_log) || (0, r.hp)({
                msg: "app_onshow_ban_".concat(u),
                data: {
                    options: e,
                    ban1167Appid: t,
                    referAppId: u,
                    isBan: i ? "baned" : ""
                }
            }), i && (0, r.n6)({
                url: r.ob.index,
                params: n({}, r.gf.showBanWarning, 1)
            }));
        }).catch(r.hm), 1043 === t && -1 === [ "wx5cbd018a2bc1c6e0", "wx67252b464b11ae13" ].indexOf(u) && (0, 
        r.gr)().getConfig().then(function(e) {
            var a = (0, r.qh)(e, "pass1043Appid.enable") || !1, n = (0, r.qh)(e, "pass1043Appid.value") || [], t = (0, 
            r.qh)(e, "pass1043Appid.type") || 0, i = -1 === n.indexOf(u);
            a && i && (0 === t ? (0, r.n6)({
                url: r.ob.index,
                params: {}
            }) : (0, r.n6)({
                url: r.ob.forbiddenVisit,
                params: {
                    text: " "
                }
            }));
        }).catch(r.hm), o && this.judgePrivateMessage(o), (0, r.m5)(e), "embedded" === this.$apiCategory && (getCurrentPages() || []).length <= 1) && (("/" !== a.slice(0, 1) ? "/" + a : a) !== r.ob.captain && (this.$blockPageOnLoad = !0, 
        (0, r.n6)({
            url: r.ob.forbiddenVisit
        })));
    },
    onHide: function() {
        (0, r.m3)(), (0, r.gt)();
    },
    onError: function(e) {
        (0, r.hp)({
            errorCode: r.aj.APP_ERROR,
            name: "app.onError",
            msg: e
        });
    },
    onUnhandledRejection: function(e) {
        try {
            var a = e.reason, n = a && a.errMsg || "unknow";
            if ("hideLoading:fail:toast can't be found" === n) return;
            (0, r.hp)({
                name: "app.onUnhandledRejection",
                e: a,
                msg: "app.onUnhandledRejection:" + n,
                errorCode: r.aj.UNHANDLED_REJECTION
            });
        } catch (e) {}
    },
    onPageNotFound: function(e) {
        (0, r.hp)({
            name: "app.onPageNotFound",
            e: e,
            msg: "app.onPageNotFound",
            errorCode: r.aj.PAGE_NOT_FOUND
        });
        var a = (0, r.qh)(e, "query") || {}, n = (0, r.qh)(e, "path") || "";
        "/" !== n.slice(0, 1) && (n = "/" + n), Object.values(r.ob).includes(n) ? (0, r.n6)({
            url: n,
            params: a
        }) : (0, r.n6)({
            url: r.ob.index
        });
    },
    error: r.hp
});