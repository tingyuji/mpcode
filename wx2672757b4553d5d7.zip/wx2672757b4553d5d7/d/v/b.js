Component({
    externalClasses: [ "external-class", "mask-class" ],
    properties: {
        src: {
            type: String,
            value: ""
        },
        mode: {
            type: String,
            value: "scaleToFill"
        }
    },
    methods: {}
});