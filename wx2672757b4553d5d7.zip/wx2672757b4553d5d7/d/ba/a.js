var e = require("../../$app");

(0, require("../../$page").afb)({
    properties: {
        isModify: {
            type: Boolean,
            value: !1
        },
        remark: {
            type: String,
            value: ""
        }
    },
    data: {
        keyboardHeight: 0
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleKeyboardHeightChange: function(t) {
            var a = (0, e.jo)(t).height;
            this.data.keyboardHeight !== a && this.setData({
                keyboardHeight: a
            });
        },
        changeValue: function(t) {
            var a = t.detail.value;
            this.setData({
                remark: t.detail.value
            }), a.length > 100 && (0, e.ri)({
                title: "备注最多可输入100个字",
                icon: "none"
            });
        },
        submit: (0, e.r2)(function() {
            var t = this;
            setTimeout(function() {
                var a = t.data.remark;
                a && a.length > 100 ? (0, e.ri)({
                    title: "备注已超过100个字",
                    icon: "none"
                }) : t.triggerEvent("submit", {
                    remark: a
                });
            }, 300);
        }, 2e3)
    }
});