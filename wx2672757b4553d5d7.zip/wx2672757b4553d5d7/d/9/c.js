var a = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), e = require("../../$app"), r = require("../../$page");

(0, r.afb)({
    behaviors: [ r.ab8 ],
    data: {
        type: "pick",
        avatarUrl: "",
        nickName: "",
        isEdit: !1,
        isSync: !1,
        showConfirm: !1
    },
    avatarChanged: !1,
    lifetimes: {
        attached: function() {
            if ("personCenterSync" === this.data.scene) {
                var a = (0, e.ll)(), t = a.avatar, r = a.nickName;
                this.setData({
                    avatarUrl: t,
                    nickName: r,
                    isSync: !0
                });
            }
        }
    },
    methods: {
        onChooseAvatar: function(a) {
            var t = (0, e.jo)(a).avatarUrl;
            this.setData({
                avatarUrl: t
            }), this.avatarChanged = !0;
        },
        avatarClick: function() {
            this.$showToast({
                title: '请选择"用微信头像"',
                duration: 2e3
            });
        },
        nameFocus: function() {
            this.setData({
                isEdit: !0
            }), this.$showToast({
                title: '请选择键盘上方的"用微信昵称"',
                duration: 2e3
            });
        },
        nameChange: function(a) {
            var t = (0, e.jo)(a).value;
            this.setData({
                nickName: t
            });
        },
        confirm: function() {
            var a = this.data, t = a.nickName;
            a.avatarUrl ? (null == t ? void 0 : t.trim()) ? this.setData({
                showConfirm: !0
            }) : this.$showToast({
                title: "请填写昵称"
            }) : this.$showToast({
                title: "请选择头像上传"
            });
        },
        toEdit: function() {
            this.setData({
                showConfirm: !1
            });
        },
        _submit: function() {
            var i = this;
            return t(a.default.mark(function t() {
                var n, s, o, c, h, u, l, f;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = i.data, s = n.nickName, o = n.avatarUrl, c = n.isSync, h = o, !i.avatarChanged) {
                            a.next = 15;
                            break;
                        }
                        return a.next = 5, (0, r.aio)({
                            filePath: o
                        }).catch(e.hm);

                      case 5:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 8;
                            break;
                        }
                        a.t0 = {};

                      case 8:
                        if (u = a.t0, l = u.url) {
                            a.next = 14;
                            break;
                        }
                        return i.$showToast({
                            title: "头像上传失败，请重试"
                        }), i.handleFail({
                            e: "upload pick avatar error"
                        }), a.abrupt("return");

                      case 14:
                        h = l;

                      case 15:
                        f = {
                            nickName: s,
                            avatarUrl: h
                        }, (0, r.anj)(f).then(function() {
                            i.$showToast({
                                title: "".concat(c ? "更新" : "登录", "成功")
                            }), i.handleSuccess(f);
                        }).catch(function(a) {
                            a.errorMsg && i.$showToast({
                                title: a.errorMsg
                            }), i.handleFail({
                                e: a
                            });
                        });

                      case 17:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        }
    }
});