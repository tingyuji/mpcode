var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    properties: {
        showGroupCatePanel: {
            value: !1,
            type: Boolean
        },
        noShowNum: {
            value: !1,
            type: Boolean
        },
        activityCategoryStatList: {
            value: [],
            type: Array
        },
        activityCategory: {
            value: 0,
            type: Number
        },
        isB: {
            value: !0,
            type: Boolean
        }
    },
    data: {
        categoryName: "全部分类"
    },
    methods: {
        handleClose: function() {
            this.triggerEvent("close");
        },
        handleSelect: function(e) {
            var a = (0, t.jo)(e), i = a.id, n = a.name;
            this.setData({
                activityCategory: i,
                categoryName: n
            }), this.handleConfirm();
        },
        handleReset: function() {
            this.triggerEvent("close"), this.triggerEvent("handleSelectCate", {
                id: -1,
                name: "全部分类"
            });
        },
        handleConfirm: function() {
            var e = this.data, t = e.activityCategory, a = e.categoryName;
            this.triggerEvent("handleSelectCate", {
                id: t,
                name: a
            }), this.triggerEvent("close");
        },
        handleJump2CategoryManage: function() {
            (0, t.n3)({
                url: t.ob.groupCateShowSetting
            });
        }
    }
});