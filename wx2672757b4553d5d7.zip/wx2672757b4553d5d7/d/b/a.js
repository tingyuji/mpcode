var e = require("../../_/helpers/interopRequireDefault"), t = e(require("../../_/regenerator")), a = require("../../_/helpers/asyncToGenerator"), r = require("../../_/helpers/objectSpread2"), n = require("../../$page"), o = require("../../$app"), s = e(require("@pdd/std-format")), i = function(e) {
    return e.map(function(e) {
        return r(r({}, e), {}, {
            operateTimeStr: s.default.formatTime(e.operateTime / 1e3, "YYYY/MM/dd hh:mm:ss")
        });
    });
};

(0, n.afb)({
    externalClasses: [ "wrap-class" ],
    options: {
        addGlobalClass: !0
    },
    properties: {
        isB: {
            type: Boolean,
            value: !1
        },
        canFold: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.setData({
                    isFold: !0
                });
            }
        },
        hasDividingLine: {
            type: Boolean,
            value: !1
        },
        parentOrderSn: {
            type: String,
            value: ""
        },
        isRefund: {
            type: Boolean,
            value: !1
        },
        item: {
            type: Object,
            value: {},
            observer: function() {
                this.computeHelpSellSuggest();
            }
        }
    },
    data: {
        operationList: [],
        computedHelpSellSuggest: null,
        isFold: !0
    },
    loadMoreMethod: null,
    loadMoreParams: {},
    lifetimes: {
        attached: function() {
            this.data.isRefund ? this.getRefundList() : this.getOperationList();
        }
    },
    methods: {
        getRefundList: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var u, l, p, c, d, f, m, h, g, S, v, L;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return u = e.data, l = u.parentOrderSn, p = u.computedHelpSellSuggest, c = u.item, 
                        d = p ? [ p ] : [], t.next = 4, e.$baseRequest(r(r({}, n.aau), {}, {
                            data: {
                                parentOrderSn: l,
                                afterSalesBizSn: l
                            }
                        })).catch(o.hm);

                      case 4:
                        (f = t.sent) && f.result && (m = f.result, h = m.applyExtension || {}, g = [], S = ((0, 
                        o.qh)(h, "subExtensions.length") || 0) > 0, h.refundAmount && !S && g.push({
                            operation: "退款金额：￥".concat(h.refundAmount / 100)
                        }), S && h.subExtensions.forEach(function(e) {
                            g.push({
                                operation: "".concat(e.goodsName).concat(e.spec ? "(".concat(e.spec, ")") : "", "，退款").concat(s.default.price(e.refundGoodsAmount, 100), "元")
                            });
                        }), h.refundShippingAmount && (v = h.refundShippingAmount, g.push({
                            operation: "运费，退款".concat(s.default.price(v, 100), "元")
                        })), h.reason && g.push({
                            operation: "退款原因：".concat(h.reason)
                        }), h.description && g.push({
                            operation: "申请说明：".concat(h.description)
                        }), L = i([ {
                            operateTime: m.applyTime,
                            operation: "申请退款",
                            operatorNickName: c.nickName,
                            imageList: h.imageList,
                            subOperationList: g
                        } ]), d = d.concat(L)), e.setData({
                            operationList: d
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        getOperationList: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var r;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = e.data.isB, e.loadMoreMethod = r ? n.ahb : n.af3, e.loadMoreParams = r ? {
                            page_size: 50,
                            page_number: 1
                        } : {}, t.next = 5, e.loadMoreList().catch(o.hm);

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        loadMoreList: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var n, s;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = e.data.parentOrderSn, (0, o.rg)(), t.prev = 2, t.next = 5, e.loadMoreMethod({
                            data: r({
                                parent_order_sn: n
                            }, e.loadMoreParams)
                        });

                      case 5:
                        s = t.sent, (0, o.l3)(), s && s.result && e.setData({
                            operationList: i(s.result)
                        }), t.next = 15;
                        break;

                      case 10:
                        t.prev = 10, t.t0 = t.catch(2), (0, o.l3)(), (0, o.ri)({
                            title: t.t0.errorMsg || "系统错误"
                        }), e.$error({
                            e: t.t0,
                            msg: "load more operation list fail"
                        });

                      case 15:
                      case "end":
                        return t.stop();
                    }
                }, a, null, [ [ 2, 10 ] ]);
            }))();
        },
        handleTapImg: function(e) {
            var t = (0, o.jo)(e), a = t.url, r = t.urlList;
            o.f3.previewImage({
                current: a,
                urls: r
            });
        },
        computeHelpSellSuggest: function() {
            var e = this.data.item;
            if (e && e.helpSellerSuggestRefundAmount && parseFloat(e.helpSellerSuggestRefundAmount) > 0) {
                var t = {
                    operateTime: 0,
                    operation: "建议退款".concat(e.helpSellerSuggestRefundAmount, "元"),
                    operatorNickName: e.helpSellNickname,
                    imageList: [],
                    subOperationList: []
                };
                this.setData({
                    computedHelpSellSuggest: t
                });
            }
        },
        handleTapFoldAngle: function() {
            var e = this.data, t = e.isFold;
            e.canFold && this.setData({
                isFold: !t
            });
        }
    }
});