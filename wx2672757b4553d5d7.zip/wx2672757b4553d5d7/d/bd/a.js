var e = require("../../$app");

(0, require("../../$page").afb)({
    externalClasses: [ "external-class" ],
    placeholder: "",
    properties: {
        customClass: {
            type: String,
            value: ""
        },
        inputClass: {
            type: String,
            value: ""
        },
        searchValue: {
            type: String,
            value: "",
            observer: function(e) {
                this.setData({
                    inputValue: e
                });
            }
        },
        placeholder: {
            type: String,
            value: ""
        },
        placeholderStyle: {
            type: String,
            value: ""
        },
        showCancel: {
            type: Boolean,
            value: !1
        },
        showBorder: {
            type: Boolean,
            value: !1
        },
        backStyle: {
            type: String,
            value: ""
        },
        btnSlot: {
            type: Boolean,
            value: !1
        },
        smallSize: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        focus: !1,
        inputValue: ""
    },
    methods: {
        doNothing: function() {},
        handleFocus: function() {
            this.placeholder || (this.placeholder = this.data.placeholder), this.setData({
                focus: !0,
                placeholder: ""
            }), this.triggerEvent("onFocus");
        },
        handleBlur: function() {
            var e = this, t = this.placeholder || "";
            this.setData({
                focus: !1,
                placeholder: t
            }, function() {
                e.triggerSearch();
            });
        },
        handleTap: function() {
            this.placeholder || (this.placeholder = this.data.placeholder), this.setData({
                focus: !0,
                placeholder: ""
            });
        },
        handleSearch: function() {
            var e = this, t = this.placeholder || "";
            this.setData({
                focus: !1,
                placeholder: t
            }, function() {
                e.triggerSearch();
            });
        },
        handleClear: function() {
            var e = this, t = this.placeholder || "";
            this.setData({
                inputValue: "",
                focus: !1,
                placeholder: t
            }, function() {
                e.triggerSearch();
            });
        },
        handleInput: function(t) {
            var a = (0, e.jo)(t, "value");
            this.setData({
                inputValue: a
            });
        },
        cancelUseSearch: function() {
            this.triggerEvent("cancelUseSearch");
        },
        triggerSearch: (0, e.g9)(function() {
            var t = this.data.inputValue, a = void 0 === t ? "" : t, l = (0, e.j2)(a.trim());
            this.triggerEvent("onSearch", {
                value: l
            }), this.setData({
                inputValue: l
            });
        }, 200)
    }
});