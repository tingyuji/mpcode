var e = require("../../$page"), a = require("../../$app");

(0, e.afb)({
    behaviors: [ e.ab7 ],
    options: {
        multipleSlots: !0
    },
    externalClasses: [ "items-class" ],
    data: {
        tipsKey: "生成素材"
    },
    lifetimes: {
        attached: function() {
            var e = wx.getStorageSync(a.ct.operatePanelTipsKey);
            !1 !== e && "false" !== e || this.setData({
                tipsKey: ""
            });
        }
    },
    properties: {
        showCancel: {
            type: Boolean,
            value: !0
        },
        showConfirm: {
            type: Boolean,
            value: !1
        },
        showSelectIcon: {
            type: Boolean,
            value: !1
        },
        showGrayBottomLine: {
            type: Boolean,
            value: !1
        },
        slow: {
            type: Boolean,
            value: !0
        },
        tips: {
            type: Array,
            value: []
        },
        haveBefore: {
            type: Boolean,
            value: !1
        },
        haveBeforeBorder: {
            type: Boolean,
            value: !0
        },
        disabledMap: {
            type: Object,
            value: {}
        },
        showBottomArea: {
            type: Boolean,
            value: !0
        }
    },
    methods: {
        onOptionsTap: function(e) {
            var t = this.data.disabledMap, o = e.currentTarget.dataset, i = o.disable, s = o.key, l = o.type, n = o.idx;
            if (i) {
                var r = (t[s] || {}).disableClickMsg;
                r && (0, a.ri)({
                    title: r,
                    icon: "none",
                    image: "",
                    duration: 1500
                });
            } else this.handleSelected(e), this.triggerEvent("chooseChange", {
                idx: n,
                type: l,
                key: s,
                disable: i
            });
        },
        cancel: function(e) {
            this.handleClosePanel(e), this.triggerEvent("cancel"), this.setData({
                tipsKey: ""
            }), wx.setStorage({
                key: a.ct.operatePanelTipsKey,
                data: "false"
            });
        },
        confirm: function() {
            this.triggerEvent("confirm", {
                keyValue: this.data.value
            });
        }
    }
});