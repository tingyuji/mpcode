var e = require("../../$page"), t = require("../../$app"), i = (0, t.k5)().platform, a = (0, 
t.ke)(), r = "android" === i, n = getApp().store, s = void 0 === n ? {} : n, h = (s.getState && s.getState()).main.systemInfo, o = a.navBarHeight;

(0, e.afb)({
    properties: {
        title: {
            type: String,
            value: "两步操作，物流、优惠不错过"
        },
        limitsLineNumber: {
            type: Number,
            value: 0,
            observer: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                this.formateHeight(e);
            }
        }
    },
    lifetimes: {
        attached: function() {
            this.formateHeight(this.data.limitsLineNumber);
        }
    },
    data: {
        alertHeightRpx: 354
    },
    methods: {
        formateHeight: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            if (e) {
                var i = 640, a = r ? 125 : 114, n = i + a * (e || 1), s = (0, t.qf)(n), d = h.windowHeight - s - o, g = (0, 
                t.ov)(d);
                g = g > 333 ? 333 : g, this.setData({
                    alertHeightRpx: g
                });
            }
        },
        clickSubscribeGuide: function() {
            this.triggerEvent("hiddenNewSubscribeGuide"), this.setData({
                hidden: !0
            });
        }
    }
});