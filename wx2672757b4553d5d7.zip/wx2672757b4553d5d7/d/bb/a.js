var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/objectSpread2"), r = require("../../_/helpers/defineProperty"), a = require("../../_/helpers/asyncToGenerator"), i = require("../../$page"), n = require("../../$app"), c = require("@ktt/ktt-wxapp-boundle").utils.emptyFunction;

(0, i.afb)({
    properties: {
        organizer: {
            type: Object,
            value: {}
        },
        supplyInfo: {
            type: Object,
            value: {}
        },
        collectionActivityNo: {
            type: String,
            value: ""
        },
        showBottomArea: {
            type: Boolean,
            value: !0
        },
        track: {
            type: String,
            value: ""
        }
    },
    data: {
        reminded: !1
    },
    lifetimes: {
        attached: function() {
            this.checkReminded(), this.$impr({
                page_el_sn: this.data.track
            });
        }
    },
    methods: {
        checkReminded: function() {
            try {
                var e = (n.f3.getStorageSync(n.ct.remindSupplyMap) || {})[this.data.collectionActivityNo];
                this.setData({
                    reminded: Date.now() < e
                });
            } catch (e) {
                this.$error({
                    e: e,
                    msg: "remindCaptainAddMoments checkReminded error"
                });
            }
        },
        handleBtnClick: function() {
            var i = this;
            return a(e.default.mark(function a() {
                var o, s, d, l, p, u, y, h, m, f, v;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (o = i.data, s = o.collectionActivityNo, d = o.supplyInfo, l = (d = void 0 === d ? {} : d).supplyUserNo, 
                        p = void 0 === l ? "" : l, u = d.supplyActivityNo, y = void 0 === u ? "" : u, p) {
                            e.next = 11;
                            break;
                        }
                        i.triggerEvent("forwardCreateMaterial"), (h = (0, n.ge)()) && h.addMaterialShowcallback && h.addMaterialShowcallback(), 
                        i.close(), (0, n.n3)({
                            url: n.ob.addActivityFeaturedMaterial,
                            params: r({}, n.gf.collectionActivityNo, s)
                        }), e.next = 21;
                        break;

                      case 11:
                        if (!i.data.reminded) {
                            e.next = 13;
                            break;
                        }
                        return e.abrupt("return");

                      case 13:
                        return e.next = 15, i.$baseRequest(t(t({}, n.qm), {}, {
                            data: {
                                methodName: "visitor_remind_add_material",
                                additionalParams: {
                                    activityNo: y,
                                    hostUserNo: p
                                }
                            }
                        })).catch(c);

                      case 15:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 18;
                            break;
                        }
                        e.t0 = {};

                      case 18:
                        if (m = e.t0, m.success) {
                            i.setData({
                                reminded: !0
                            });
                            try {
                                f = n.f3.getStorageSync(n.ct.remindSupplyMap) || {}, v = Date.now(), Object.keys(f).forEach(function(e) {
                                    f[e] < v && delete f[e];
                                }), f[s] = v + 864e5, n.f3.setStorageSync(n.ct.remindSupplyMap, f);
                            } catch (e) {
                                i.$error({
                                    e: e,
                                    msg: "setStorageSync remindSupplyMap error"
                                });
                            }
                        }

                      case 21:
                        i.$click({
                            page_el_sn: i.data.track
                        });

                      case 22:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        close: function() {
            this.triggerEvent("close");
        }
    }
});