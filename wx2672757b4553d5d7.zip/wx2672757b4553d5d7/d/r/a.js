var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/slicedToArray"), a = require("../../_/helpers/asyncToGenerator"), r = require("../../$app"), n = require("../../$page");

Component({
    externalClasses: [ "close-class", "img-class" ],
    properties: {
        data: {
            type: Object,
            value: {}
        },
        hideAddBtn: {
            type: Boolean,
            value: !0
        },
        canEdit: {
            type: Boolean,
            value: !0
        },
        itemHeight: {
            type: Number,
            value: 200
        },
        itemWidth: {
            type: Number,
            value: 200
        },
        itemBorderRadius: {
            type: Number,
            value: 0
        },
        useDefaultUpload: {
            type: Boolean,
            value: !0
        },
        noPreview: {
            type: Boolean,
            value: !1
        },
        addTitle: {
            type: String,
            value: "添加图片"
        },
        addBgImg: {
            type: String,
            value: ""
        },
        markInfo: {
            type: Object,
            value: {}
        },
        isRect: {
            type: Boolean,
            value: !1
        },
        bucketTag: {
            type: String,
            value: "monica"
        },
        noProcessUrl: {
            type: Boolean,
            value: !1
        },
        anti: {
            type: Boolean,
            value: !1
        },
        antiOptions: {
            type: Object,
            value: {}
        },
        noGrayBg: {
            type: Boolean,
            value: !1
        },
        showAddBtn: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        uploadImg: function() {
            var r = this;
            return a(e.default.mark(function a() {
                var i, l, u, o, s, g, d, p, c, v;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return i = r.data, l = i.isRect, u = i.bucketTag, o = i.anti, s = i.antiOptions, 
                        e.next = 3, (0, n.aaq)(1, {
                            isRect: l,
                            bucketTag: u,
                            anti: o,
                            antiOptions: s
                        });

                      case 3:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 6;
                            break;
                        }
                        e.t0 = [ {} ];

                      case 6:
                        (g = e.t0) && g.length && (d = t(g, 1), p = d[0], c = p.url, v = p.filePath, c && r.triggerEvent("onImgChange", {
                            url: c,
                            filePath: v
                        }));

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        addImage: function() {
            var e = this.data, t = e.useDefaultUpload, a = e.canEdit, r = e.showAddBtn;
            a || !r ? a && (t && this.uploadImg(), this.triggerEvent("addImage")) : this.triggerEvent("canNotEditAddClick");
        },
        previewGalleries: function() {
            var e = this.data, t = e.data, a = t.url, n = t.showChangeHint, i = e.noPreview, l = (0, 
            r.iu)(a);
            if (n) return this.changeImage();
            i || r.f3.previewImage({
                current: l,
                urls: [ l ]
            }), this.triggerEvent("onImgClick");
        },
        changeImage: function() {
            this.data.useDefaultUpload && this.uploadImg(), this.triggerEvent("changeImage");
        },
        deleteGallery: function() {
            this.data.useDefaultUpload && this.triggerEvent("onImgChange", {
                url: ""
            }), this.triggerEvent("deleteGallery");
        }
    }
});