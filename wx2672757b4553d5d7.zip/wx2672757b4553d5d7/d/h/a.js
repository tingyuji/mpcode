var e = require("../../$page"), a = require("../../$app");

(0, e.afb)({
    behaviors: [ e.afe ],
    externalClasses: [ "external-class", "time-wrapper-class", "other-wrapper-class" ],
    properties: {
        showDay: {
            type: Boolean,
            value: !1
        },
        showHour: {
            type: Boolean,
            value: !0
        },
        customTexts: {
            type: Array,
            value: []
        }
    },
    data: {
        showTime: !0,
        preText: "",
        afterText: "",
        customMax: 1 / 0
    },
    methods: {
        handleTimeChange: function(t) {
            var o = t.milliSeconds, r = this.data, i = r.customTexts, s = r.customMax;
            if (i && i.length) {
                for (var l = 0, m = i.length; l < m; l++) {
                    var n = i[l], c = n.min, h = void 0 === c ? 0 : c, x = n.max, T = void 0 === x ? 1 / 0 : x, p = n.preText, v = void 0 === p ? "" : p, u = n.afterText, d = void 0 === u ? "" : u, f = n.showTime, w = void 0 !== f && f, g = n.formatTime, y = void 0 === g ? "" : g;
                    if (o >= h && o < T) return s !== T && this.triggerEvent("onCustomTimeChange", {
                        milliSeconds: o
                    }), void e.amq.call(this, {
                        preText: "".concat(v).concat((0, a.ix)(o / 1e3, y)),
                        afterText: d,
                        showTime: w,
                        customMax: T
                    });
                }
                e.amq.call(this, {
                    preText: "",
                    afterText: "",
                    showTime: !0
                });
            }
        }
    }
});