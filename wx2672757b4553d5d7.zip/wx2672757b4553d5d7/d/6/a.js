var e = require("../../$page");

Component({
    properties: {
        status: {
            type: null,
            value: 1
        }
    },
    externalClasses: [ "external-class" ],
    data: {
        labelInfo: e.xg
    }
});