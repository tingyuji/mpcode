var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    externalClasses: [ "popover-class", "arrow-class" ],
    eventHandler: void 0,
    properties: {
        showArrow: {
            type: Boolean,
            value: !0
        },
        bgClickable: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            var e = this;
            this.eventHandler = t.f9.listenOnce(t.f1.onPageViewTouchEnd, function() {
                setTimeout(function() {
                    e.hide();
                }, 0);
            });
        },
        detached: function() {
            this.eventHandler && this.eventHandler();
        }
    },
    methods: {
        hide: function() {
            this.triggerEvent("close");
        },
        handleBgClick: function() {
            this.triggerEvent("bgClick");
        }
    }
});