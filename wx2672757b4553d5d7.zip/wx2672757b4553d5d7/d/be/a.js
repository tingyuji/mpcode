var t = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), e = require("../../_/helpers/asyncToGenerator"), a = require("../../$page"), i = require("../../$app"), s = getApp().store, r = void 0 === s ? {} : s, o = (r.getState && r.getState()).main.systemInfo, n = (0, 
i.k5)().windowHeight, l = o.screenHeight / o.screenWidth > 2, h = o.model && -1 !== o.model.toLowerCase().indexOf("ipad") ? .56 : .75, u = (0, 
i.ov)(n - 270 - 45), d = {
    IMG: 0,
    VIDEO: 1,
    POSTER: 2
};

(0, a.afb)({
    externalClasses: [ "download-btn-class" ],
    properties: {
        show: {
            type: Boolean,
            value: !0
        },
        shareRouterPosition: {
            type: String,
            value: ""
        },
        shareImage: {
            type: Object,
            value: {},
            observer: function(t, e) {
                var a = this.data.width;
                if (this.data.show && (t && t.url) !== (e && e.url)) {
                    var i, s = l ? 520 : (t.width || a) * h;
                    this.setData({
                        autoFixWidth: s
                    }), this.data.momentsForWxVolist.length ? this.fmtMomentsInfo() : null !== (i = this.data.multiShareImages) && void 0 !== i && i.length || this.setData({
                        momentsVolist: []
                    });
                }
            }
        },
        showClose: {
            type: Boolean,
            value: !1
        },
        width: {
            type: Number,
            value: 630
        },
        height: {
            type: Number,
            value: 890
        },
        hasEditBtn: {
            type: Boolean,
            value: !1
        },
        multiShareImages: {
            type: Array,
            value: [],
            observer: function(t) {
                ((0, i.qh)(t || [], "length") || this.data.alwaysFmtMomentsInfo) && this.fmtMomentsInfo();
            }
        },
        momentsForWxVolist: {
            type: Array,
            value: []
        },
        downloadText: {
            type: String,
            value: "保存图片"
        },
        defaultLocation: {
            type: Number,
            value: 0
        },
        supportPreview: {
            type: Boolean,
            value: !1
        },
        showNumIndicator: {
            type: Boolean,
            value: !1
        },
        showXCMaterialEntry: {
            type: Boolean,
            value: !1
        },
        curActBindMoments: {
            type: Boolean,
            value: !1
        },
        alwaysFmtMomentsInfo: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        loadFinish: !1,
        swiperHeight: u,
        autoFixWidth: 520,
        currentIndex: 0,
        RESOURCE_TYPE: d,
        momentsVolist: [],
        margin: 95,
        alphaDepth: .4,
        depth: .15,
        scaleRate: 0
    },
    attached: function() {
        this.$impr({
            page_el_sn: 5452693
        });
    },
    methods: {
        closeDialog: function(t) {
            this.setData({
                show: !1,
                currentIndex: 0
            }), this.triggerEvent("closeShareImage", t);
        },
        downloadImage: function() {
            var t = this.data, e = t.multiShareImages, a = t.momentsForWxVolist;
            if (e.length || a.length) {
                var s = (0, i.qh)(this.data.momentsVolist, ".".concat(this.data.currentIndex, ".imgUrlList.0.url"));
                this.triggerEvent("save", {
                    imgUrl: s
                });
            } else {
                var r;
                this.triggerEvent("save", {
                    imgUrl: null === (r = this.data.shareImage) || void 0 === r ? void 0 : r.url
                });
            }
            this.$click({
                page_el_sn: 5452693
            }), this.addSharePosterCmtvLog();
        },
        addSharePosterCmtvLog: function() {
            var t;
            (0, i.re)({
                shareRouter: "/".concat(null === (t = this.$currentPage) || void 0 === t ? void 0 : t.route),
                shareRouterPosition: this.data.shareRouterPosition || "others",
                shareStatus: "success",
                shareType: "poster"
            });
        },
        bindEditPoster: function() {
            this.triggerEvent("editPoster");
        },
        onTouchMove: function() {
            return !1;
        },
        onSwiperTransition: function(t) {
            var e = (0, i.jo)(t).dx, a = ((e = Math.abs(e)) / 290).toFixed(2);
            this.setData({
                scaleRate: a
            });
        },
        onAnimationFinish: function(t) {
            var e = (0, i.jo)(t).current;
            this.setData({
                currentIndex: e,
                scaleRate: 0
            });
        },
        handleSwiperChange: function(t) {
            var e = (0, i.jo)(t), a = e.current, s = e.source;
            a && this.$impr({
                page_el_sn: 5519067
            }), "touch" === s && this.setData({
                currentIndex: a
            });
        },
        saveFriendMoments: function() {
            var t = this.data, e = t.currentIndex;
            (t.momentsVolist[e] || {}).type === d.POSTER ? this.downloadImage() : (this.$click({
                page_el_sn: 5519067
            }), this.downloadMoments());
        },
        fmtMomentsInfo: function() {
            var t = this.data, e = t.autoFixWidth, a = t.momentsForWxVolist, s = t.multiShareImages, r = t.showXCMaterialEntry, o = a.reduce(function(t, a) {
                var s = a.desc, r = (a.fileResourceList || []).filter(function(t) {
                    return t.type === d.IMG;
                });
                if (s || r.length) {
                    var o = 0;
                    s && (o = Math.min(Math.ceil((0, i.nm)(s, 28) / e), 3)), t.push({
                        desc: s,
                        imgUrlList: r,
                        descLines: o,
                        type: d.IMG
                    });
                }
                return t;
            }, []);
            (r && o.length > 1 && (o = o.slice(0, 1)), s && s.length) ? o = s.reduce(function(t, e) {
                return t.push({
                    imgUrlList: [ {
                        url: e
                    } ],
                    type: d.POSTER
                }), t;
            }, []).concat(o) : (0, i.qh)(this.data.shareImage, "url") && o.unshift({
                imgUrlList: [ {
                    url: this.data.shareImage.url
                } ],
                type: d.POSTER
            });
            this.setData({
                currentIndex: this.data.defaultLocation,
                momentsVolist: o
            });
        },
        downloadMoments: function() {
            var a = this;
            return e(t.default.mark(function e() {
                var s, r, o, n, l, h, u, d;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (s = a.data, r = s.currentIndex, o = s.momentsVolist, n = o[r] || {}, l = n.desc, 
                        h = void 0 === l ? "" : l, u = n.imgUrlList, d = void 0 === u ? [] : u, h && i.f3.setClipboardData({
                            data: h
                        }), d.length) {
                            t.next = 7;
                            break;
                        }
                        return (0, i.ri)({
                            title: "文案已复制，图片保存成功，可以去朋友圈分享啦",
                            icon: "none"
                        }), a.triggerEvent("closeShareImage"), t.abrupt("return");

                      case 7:
                        return (0, i.rg)({
                            title: "保存中",
                            mask: !0
                        }), t.next = 10, (0, i.ey)({
                            list: d,
                            successToast: "文案已复制，图片保存成功，可以去朋友圈分享啦!"
                        });

                      case 10:
                        (0, i.l3)(), a.closeDialog();

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        onImgLoad: function(t) {
            var e = this.data, a = e.autoFixWidth, s = e.supportPreview, r = e.swiperHeight, o = e.momentsVolist, n = (0, 
            i.qh)(t, "detail.e"), l = (0, i.jo)(n || t), h = l.height, d = l.width;
            if (d && h) {
                var c = a * (h / d);
                c > u && s && (c = u), o.length > 1 && r !== u && c >= r ? this.setData({
                    loadFinish: !0
                }) : this.setData({
                    swiperHeight: c,
                    loadFinish: !0
                });
            }
        },
        goToXCMaterial: function(t) {
            var e = (0, i.jo)(t).trackingKey;
            this.$click({
                page_el_sn: a.ae3[e]
            }), this.triggerEvent("goToXCMaterial"), this.closeDialog();
        }
    }
});