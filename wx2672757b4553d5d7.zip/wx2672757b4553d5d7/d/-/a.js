var e = require("../../_/helpers/defineProperty"), t = require("../../$page"), r = require("../../$app");

(0, t.afb)({
    properties: {
        bizToastData: {
            type: Object,
            value: {}
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            this.triggerEvent("onConfirmCommonToast");
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        subscribe: function() {
            var t = (0, r.qh)(this.data.bizToastData, "jumpUrl");
            (0, r.n3)({
                url: r.ob.mpArticle,
                params: e({}, r.gf.mpSrc, t)
            }), this.triggerEvent("close");
        }
    }
});