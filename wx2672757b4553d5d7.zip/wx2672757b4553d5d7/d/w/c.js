var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    externalClasses: [ "body-class", "title-class" ],
    behaviors: [ e.aeo ],
    options: {
        multipleSlots: !0
    },
    properties: {
        slow: {
            type: Boolean,
            value: !1
        },
        overHeader: {
            type: Boolean,
            value: !1
        },
        maskBgColor: {
            type: String,
            value: "rgba(0, 0, 0, .5)"
        },
        customIndex: {
            type: Object,
            value: null
        },
        title: {
            type: String,
            value: ""
        },
        showGrayBottomLine: {
            type: Boolean,
            value: !0
        },
        useCustomClose: {
            type: Boolean,
            value: !1
        },
        showClose: {
            type: Boolean,
            value: !0
        }
    },
    lifetimes: {
        attached: function() {
            this.setData({
                hasTabBar: (0, t.ly)()
            });
        }
    },
    methods: {
        close: function(e) {
            var o = this, s = this.data, a = s.slow, l = s.useCustomClose, i = (0, t.jo)(e, "closeType");
            l ? this.triggerEvent("close", {
                closeType: i
            }) : (this.triggerEvent("beforeClose"), this.setData({
                show: !1
            }, function() {
                setTimeout(function() {
                    o.triggerEvent("close");
                }, a ? 420 : 220);
            }));
        },
        move: function() {}
    }
});