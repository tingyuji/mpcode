var e = require("../../_/helpers/defineProperty"), r = require("../../$page"), a = require("../../$app");

(0, r.afb)({
    externalClasses: [ "external-class" ],
    properties: {
        avatarUrl: {
            type: String,
            value: ""
        },
        userNo: {
            type: String,
            value: ""
        },
        disable: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        goToFollowerDetail: function() {
            var r = this.data, t = r.userNo, l = r.disable;
            t && !l && (0, a.n3)({
                url: a.ob.memberPortrait,
                params: e({}, a.gf.followerUserNo, t)
            });
        }
    }
});