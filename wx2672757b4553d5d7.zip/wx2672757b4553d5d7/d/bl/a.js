var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), r = require("../../$page"), a = require("../../$app");

(0, r.afb)({
    data: {},
    timer: void 0,
    properties: {
        elementName: {
            type: String,
            value: ""
        },
        checkElementHeight: {
            type: Number,
            value: 0
        },
        extraReportData: {
            type: Object,
            value: {}
        },
        needDisappear: {
            type: Boolean,
            value: !1
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            this.timer = setTimeout(function() {
                e.checkElement();
            }, 5e3);
        },
        detached: function() {
            this.timer && clearTimeout(this.timer);
        }
    },
    methods: {
        checkElement: function() {
            var a = this;
            return t(e.default.mark(function t() {
                var n, i, c, o;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = a.data, i = n.needDisappear, c = n.checkElementHeight, e.next = 3, (0, 
                        r.alo)(a, "#check-main");

                      case 3:
                        o = e.sent, (i && o > 0 || !i && o <= c) && a.loggerWhiteScreenError();

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        loggerWhiteScreenError: function() {
            var e = this.data, t = e.elementName, r = e.extraReportData;
            this.$error({
                data: r,
                msg: "".concat(t, "_").concat(5e3, " white screen"),
                errorCode: a.aj.PERM_MONITOR
            }), (0, a.ev)({
                type: a.u.WHITE_SCREEN,
                tags: {
                    whiteScreenElementName: "".concat(t, "_").concat(5e3)
                }
            });
        }
    }
});