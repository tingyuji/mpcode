var t = require("../../../_/helpers/defineProperty"), e = require("../../../$page"), i = require("../../../$app");

(0, e.afb)({
    properties: {
        activityList: {
            type: Array,
            value: []
        },
        hotSellRecommendSn: {
            type: String,
            value: ""
        },
        hotSellRefresh: {
            type: Boolean,
            value: !1
        },
        hotSellRequestId: {
            type: String,
            value: "",
            observer: function(t) {
                t && this.onImpr();
            }
        },
        hotSellListId: {
            type: String,
            value: ""
        }
    },
    data: {
        HOT_SELL_CARD_EL_SN: 7790450
    },
    lifetimes: {},
    methods: {
        onImpr: function() {
            this.$impr({
                page_el_sn: 7790450,
                extParams: {
                    activity_no_list: this.data.activityList.map(function(t) {
                        return t.activityNo;
                    }),
                    request_id: this.data.hotSellRequestId,
                    list_id: this.data.hotSellListId
                }
            });
        },
        goToHotSellActPage: function(e) {
            var a, l = this, s = (0, i.jo)(e).activityNo, o = this.data, r = o.hotSellRequestId, n = o.hotSellListId;
            this.$click({
                page_el_sn: 7790450,
                extParams: s ? {
                    hot_activity_no: s,
                    request_id: r,
                    list_id: n
                } : {
                    request_id: r,
                    list_id: n
                }
            }), this.data.hotSellRefresh && this.$addNextShowCallback(function() {
                l.triggerEvent("reload");
            }), (0, i.n3)({
                url: i.ob.hotSellActivityList,
                params: (a = {}, t(a, i.gf.hotSellRecommendSn, this.data.hotSellRecommendSn || ""), 
                t(a, i.gf.activityNo, s || ""), t(a, i.gf.requestId, r || ""), a)
            });
        }
    }
});