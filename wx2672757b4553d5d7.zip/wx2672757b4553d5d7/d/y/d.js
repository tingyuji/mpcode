var e = require("../../_/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.LIST_SCENE_MAP = exports.LIST_SCENE = void 0;

var t, a = e(require("../../_/regenerator")), r = require("../../_/helpers/asyncToGenerator"), i = require("../../_/helpers/objectSpread2"), n = require("../../_/helpers/defineProperty"), s = require("../../$page"), o = require("../../$app"), d = e(require("@pdd/std-format")), u = {
    DEFAULT: "default",
    LOCAL_LIFE_SERVER: "local_life_server"
};

exports.LIST_SCENE = u;

var c = (n(t = {}, u.LOCAL_LIFE_SERVER, {
    pageTitle: "本地生活订单",
    hideUnPaidTab: !0,
    fetchParams: {
        searchLocalLifeServiceOrder: 1
    }
}), n(t, u.DEFAULT, {
    pageTitle: "我购买的订单",
    hideUnPaidTab: !1,
    fetchParams: {}
}), t);

exports.LIST_SCENE_MAP = c, (0, s.afb)({
    behaviors: [ (0, s.afu)({
        mapState: {
            userInfo: o.sq
        }
    }), s.acb, s.aba, s.abb ],
    properties: {
        query: {
            type: Object,
            value: {}
        },
        trackingData: {
            type: Object,
            value: {}
        },
        canUpdatePublicNumber: Boolean,
        showHotSell: {
            type: Boolean,
            value: !1
        },
        topTipsHeight: {
            type: Number,
            value: 0
        }
    },
    listScene: u.DEFAULT,
    pageNumber: 1,
    hotSellLoaded: !1,
    hotSellParams: {},
    attachedTime: 0,
    data: {
        headerBlockFixed: !1,
        headerBlockHeight: 0,
        orderList: [],
        isLoading: !1,
        hasMore: !1,
        hidePanel: !1,
        selectIndex: 0,
        firstLoaded: !1,
        currentTab: s.uc,
        toRefundCount: 0,
        unPaidCount: 0,
        publicNumber: {},
        publicNumberDialogShow: !1,
        showSkeletonImg: !0,
        hideUnPaidTab: !1,
        C_ORDER_TAB_MAP: s.uf,
        hotSellActicityList: [],
        hotSellRecommendSn: "",
        hotSellRequestId: "",
        hotSellListId: "",
        $gray: {
            orderListIgnoreEmoji: !1
        }
    },
    lifetimes: {
        attached: function() {
            var e = this.data.query || {}, t = e.page_tab, a = e.list_scene_to_c;
            this.listScene = a || u.DEFAULT;
            var r = this.getListSceneInfo().hideUnPaidTab, n = void 0 !== r && r, o = {
                hideUnPaidTab: n
            };
            n || "to_pay" !== t || (o.currentTab = i({}, s.ue[1])), this.attachedTime = Date.now(), 
            this.setData(o), this.initData(), this.loadHotSellAct();
        }
    },
    methods: {
        onPullDownRefresh: function() {
            this.initData(), this.loadHotSellAct();
        },
        onPageScroll: function(e) {
            var t = e.scrollTop;
            if (!this.data.$appData.isAndroid) {
                var a = t <= 1;
                a !== this.data.headerBlockFixed && this.data.headerBlockHeight && this.setData({
                    headerBlockFixed: a
                });
            }
        },
        initData: function() {
            this.loadFirstPage(), this.getToRefundNumber(), this.getUnPaidNumber();
        },
        getListSceneInfo: function() {
            return c[this.listScene] || c[u.DEFAULT];
        },
        getListParams: function() {
            var e = this.data, t = e.searchValue, a = e.currentTab;
            return i(i({
                keyword: t
            }, a.fetchParams), this.getListSceneInfo().fetchParams);
        },
        getQueryApi: function() {
            return this.data.currentTab.id === s.uf.TO_PAY ? s.anf : s.aj8;
        },
        loadFirstPage: function() {
            var e = this;
            this.$showLoading({
                delay: 1e3
            }), this.pageNumber = 1;
            var t = {
                hasMore: !1,
                isFinishLoading: !0,
                firstLoaded: !0,
                orderList: []
            }, a = !this.data.firstLoaded;
            this.$baseRequest(i(i({}, this.getQueryApi()), {}, {
                data: i(i({}, this.getListParams()), {}, {
                    pageSize: 10,
                    pageNumber: 1
                })
            })).then(function(r) {
                e.$hideLoading();
                var i = (0, o.qh)(r, "result.list") || [];
                if ((0, o.qh)(r, "result.hasNext") || i.length > 0) {
                    var n = i.map(s.agr);
                    e.pageNumber++, t.hasMore = !0, t.orderList = n;
                }
                e.setData(t, function() {
                    a && e.onFirstLoaded();
                });
            }).catch(function() {
                e.$hideLoading(), e.setData(t, function() {
                    a && e.onFirstLoaded();
                });
            });
        },
        onFirstLoaded: function() {
            this.checkWhiteScreen(), this.logFirstScreenTime(), this.getHeaderBlockHeight();
        },
        getHeaderBlockHeight: function() {
            var e = this;
            if (!this.data.$appData.isAndroid) {
                var t = this.createSelectorQuery();
                t.select("#header-block").boundingClientRect(), t.selectViewport().scrollOffset(), 
                t.exec(function(t) {
                    var a, r, i = null === (a = null == t ? void 0 : t[0]) || void 0 === a ? void 0 : a.height;
                    if (i) {
                        var n = (null === (r = null == t ? void 0 : t[1]) || void 0 === r ? void 0 : r.scrollTop) <= 0;
                        i === e.data.headerBlockHeight && n === e.data.headerBlockFixed || e.setData({
                            headerBlockHeight: i,
                            headerBlockFixed: n
                        });
                    }
                });
            }
        },
        checkWhiteScreen: function() {
            var e = this, t = this.createSelectorQuery();
            t.select("#skeleton_to_c").boundingClientRect(), t.exec(function(t) {
                var a;
                (null === (a = null == t ? void 0 : t[0]) || void 0 === a ? void 0 : a.height) && e.$error({
                    msg: "order_white_screen",
                    data: {
                        role: "c",
                        rect: t[0]
                    }
                });
            });
        },
        logFirstScreenTime: function() {
            var e, t, a = (null === (e = this.$currentPage) || void 0 === e ? void 0 : e.$performance.onLoadTime) || 0, r = this.$getPageId(), i = o.f3.getStorageSync(o.ct.orderReportFirstScreen) === r;
            i || o.f3.setStorageSync(o.ct.orderReportFirstScreen, r), (0, o.ev)({
                type: o.u.ORDER_FIRST_SCREEN,
                tags: {
                    orderRole: "c",
                    orderPageName: null === (t = this.$currentPage) || void 0 === t ? void 0 : t.pageProperties.page_name,
                    withPageFirstScreenData: !i
                },
                longFields: Object.assign({
                    componentFirstScreenDuration: Date.now() - this.attachedTime
                }, i ? {} : {
                    pageFirstScreenDuration: Date.now() - a
                })
            });
        },
        getToRefundNumber: function() {
            var e = this;
            return r(a.default.mark(function t() {
                var r, n, d;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return (r = e.getListParams()).shippingAggregateStatus = null, r.orderStatus = s.y0.TO_REFUND, 
                        t.prev = 3, t.next = 6, e.$baseRequest(i(i({}, s.alg), {}, {
                            data: i(i({}, r), {}, {
                                pageSize: 1,
                                pageNumber: 1
                            })
                        }));

                      case 6:
                        n = t.sent, d = (0, o.qh)(n, "result.orderNumber") || 0, e.setData({
                            toRefundCount: d
                        }), t.next = 14;
                        break;

                      case 11:
                        t.prev = 11, t.t0 = t.catch(3), e.$error({
                            e: t.t0,
                            msg: "getToRefundNumber fail"
                        });

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 11 ] ]);
            }))();
        },
        getUnPaidNumber: function() {
            var e = this;
            return r(a.default.mark(function t() {
                var r, n;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.data.hideUnPaidTab) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return t.prev = 2, t.next = 5, e.$baseRequest(i(i({}, s.ang), {}, {
                            data: {
                                pageSize: 1,
                                pageNumber: 1
                            }
                        }));

                      case 5:
                        r = t.sent, n = (0, o.qh)(r, "result.unPaidCount") || 0, e.setData({
                            unPaidCount: n
                        }), t.next = 13;
                        break;

                      case 10:
                        t.prev = 10, t.t0 = t.catch(2), e.$error({
                            e: t.t0,
                            msg: "getUnPaidNumber fail"
                        });

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 2, 10 ] ]);
            }))();
        },
        handleForwardOrder: function(e) {
            var t = e.currentTarget.dataset.index, a = (this.data.orderList[t] || {}).parentOrderSn;
            (0, o.n3)({
                url: o.ob.orderDetail,
                params: n({}, o.gf.orderSn, a)
            });
        },
        loadMoreOrder: function() {
            var e = this;
            this.data.isLoading || (this.setData({
                isLoading: !0,
                loadMoreError: !1
            }), this.$baseRequest(i(i({}, this.getQueryApi()), {}, {
                data: i(i({}, this.getListParams()), {}, {
                    pageSize: 10,
                    pageNumber: this.pageNumber
                })
            })).then(function(t) {
                var a = (0, o.qh)(t, "result.list") || [];
                if ((0, o.qh)(t, "result.hasNext") || a.length > 0) {
                    var r = a.map(s.agr), i = {
                        hasMore: !0,
                        isLoading: !1
                    };
                    e.pageNumber++, r.length && (i.orderList = e.data.orderList.concat(r)), e.setData(i);
                } else e.setData({
                    hasMore: !1,
                    isLoading: !1
                });
            }).catch(function() {
                e.setData({
                    hasMore: !1,
                    loadMoreError: !0,
                    isLoading: !1
                });
            }));
        },
        selectEditRemark: function(e) {
            var t = (0, o.jo)(e), a = t.index, r = t.item;
            this.setData({
                selectIndex: a,
                selectItem: r
            }), this._showRemarkDialog();
        },
        submitRemark: function(e) {
            var t = this;
            return r(a.default.mark(function r() {
                var i, n, o, d, u, c;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return i = e.detail.remark, n = t.data, o = n.selectIndex, d = n.orderList, u = d[o], 
                        c = u.parentOrderSn, a.next = 6, t._submitRemark({
                            remark: i,
                            parentOrderSn: c
                        });

                      case 6:
                        a.sent && (t.updateListItem({
                            index: o,
                            payload: {
                                buyerMemo: i
                            }
                        }), t.toggleUpdatePublicNumber({
                            publicNumber: s.sx.INDEX_COMMENT_DIALOG
                        }));

                      case 8:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        handleSearch: function(e) {
            var t = (0, o.jo)(e).value;
            t !== this.data.searchValue && (this.setData({
                searchValue: t
            }), this.initData());
        },
        hideRemarkDialog: function() {
            this._hideRemarkDialog();
        },
        handleTabChange: function(e) {
            var t = this, a = e.detail;
            this.setData({
                currentTab: a
            }, function() {
                t.getHeaderBlockHeight();
            }), this.initData();
        },
        removeOrderItem: function(e) {
            var t = this, a = (0, o.jo)(e).index, r = this.data.orderList;
            r.splice(a, 1), this.setData({
                orderList: r
            }, function() {
                t.getUnPaidNumber();
            });
        },
        toggleUpdatePublicNumber: function(e) {
            var t = e.publicNumber;
            this.setData({
                publicNumberDialogShow: !0,
                publicNumber: t
            });
        },
        closePublicNumberGuide: function() {
            this.setData({
                publicNumberDialogShow: !1
            });
        },
        loadHotSellAct: function() {
            var e = this;
            return r(a.default.mark(function t() {
                var r, n, u, c, l, h, g, p, f, m, b;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.data.showHotSell) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return t.next = 4, e.$baseRequest(i(i({}, s.alp), {}, {
                            data: {
                                listId: (null === (r = e.hotSellParams) || void 0 === r ? void 0 : r.listId) || null,
                                previousRequestId: (null === (n = e.hotSellParams) || void 0 === n ? void 0 : n.requestId) || null
                            }
                        })).catch(o.hm);

                      case 4:
                        if (null == (u = t.sent) ? void 0 : u.result) {
                            t.next = 7;
                            break;
                        }
                        return t.abrupt("return");

                      case 7:
                        c = u.result, l = c.activityFeeds, h = void 0 === l ? [] : l, g = c.recommendSn, 
                        p = c.requestId, f = void 0 === p ? "" : p, m = c.listId, b = void 0 === m ? "" : m, 
                        h.length > 0 && g && (e.setData({
                            hotSellActicityList: u.result.activityFeeds.slice(0, 4).map(function(e) {
                                return i(i({}, e), {}, {
                                    goodsPic: (0, o.qh)(e.goodsPicList || [], "0.picUrl") || (0, o.jx)(),
                                    priceRangeYuan: e.goodsMinPrice === e.goodsMaxPrice ? d.default.price(e.goodsMinPrice, 100) : "".concat(d.default.price(e.goodsMinPrice, 100), "-").concat(d.default.price(e.goodsMaxPrice, 100))
                                });
                            }),
                            hotSellRecommendSn: u.result.recommendSn,
                            hotSellRefresh: u.result.refresh,
                            hotSellRequestId: f,
                            hotSellListId: b
                        }), e.hotSellParams = {
                            requestId: f,
                            listId: b
                        });

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        }
    }
});