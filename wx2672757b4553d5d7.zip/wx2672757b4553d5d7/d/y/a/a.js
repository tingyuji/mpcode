var e, t = require("../../../_/helpers/objectSpread2"), u = require("../../../_/helpers/toConsumableArray"), a = require("../../../_/helpers/defineProperty"), r = require("../../../$page"), n = require("../../../$app"), i = (a(e = {}, r.uf.ALL, 5470374), 
a(e, r.uf.TO_PAY, 5476043), a(e, r.uf.LOGISTICS, 5476044), a(e, r.uf.TO_SHIP, 5476045), 
a(e, r.uf.PART_SHIP, 5476046), a(e, r.uf.SHIP, 5476044), a(e, r.uf.RECEIVED, 5715260), 
a(e, r.uf.AFTER_SALES, 5476047), a(e, r.uf.TO_REFUND, 5476048), a(e, r.uf.REFUND, 5476049), 
e), s = function(e) {
    return e <= 0 ? "" : e <= 99 ? e + "" : "99+";
};

(0, r.afb)({
    behaviors: [ r.abb ],
    properties: {
        currentTab: {
            type: Object,
            value: r.uc
        },
        toRefundCount: {
            type: Number,
            value: 0,
            observer: function(e) {
                this.setData({
                    toRefundCountStr: s(e)
                });
            }
        },
        hideUnPaidTab: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                this.setData({
                    orderTabList: e ? u(r.ue).filter(function(e) {
                        return e.id !== r.uf.TO_PAY;
                    }) : u(r.ue)
                });
            }
        },
        unPaidCount: {
            type: Number,
            value: 0,
            observer: function(e) {
                this.setData({
                    unPaidCountStr: s(e)
                });
            }
        }
    },
    data: {
        orderTabList: u(r.ue),
        C_ORDER_TAB_MAP: r.uf,
        unPaidCountStr: "",
        toRefundCountStr: ""
    },
    lifetimes: {},
    methods: {
        handleTapTab: function(e) {
            var u = {}, a = (0, n.jo)(e, "tab");
            Object.assign(u, a), a.hasSubTab && a.subTabList && (u.subId = a.subTabList[0].subId), 
            this.$click({
                page_el_sn: i[u.id]
            });
            var s = r._0[u.subId || u.id];
            this.triggerEvent("onTabChange", t(t({}, u), {}, {
                fetchParams: s
            }));
        },
        handleTapSubTab: function(e) {
            var u = (0, n.jo)(e, "tab"), a = r.ue.find(function(e) {
                return e.id === u.id;
            });
            a.subId = u.subId, this.$click({
                page_el_sn: i[a.subId]
            });
            var s = r._0[a.subId];
            this.triggerEvent("onTabChange", t(t({}, a), {}, {
                fetchParams: s
            }));
        },
        checkUnPayTab: function() {
            var e = r.ue.find(function(e) {
                return e.id === r.uf.TO_PAY;
            });
            if (e) {
                var u = r._0[e.id];
                this.triggerEvent("onTabChange", t(t({}, e), {}, {
                    fetchParams: u
                }));
            }
        }
    }
});