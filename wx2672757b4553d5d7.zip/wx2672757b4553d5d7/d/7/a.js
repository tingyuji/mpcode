var e = require("../../$page");

(0, e.afb)({
    behaviors: [ e.ab6, e.aeo ],
    options: {
        multipleSlots: !0
    },
    methods: {
        move: function() {}
    }
});