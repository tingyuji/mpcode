var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    properties: {
        imgList: {
            type: Array,
            value: []
        },
        visible: {
            type: Boolean,
            value: !1
        },
        isTransparentBg: {
            type: Boolean,
            value: !1
        },
        marginGap: {
            type: Number,
            value: 24
        },
        tabBarPage: {
            type: Boolean,
            value: !1
        },
        overHeader: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        step: 0,
        windowHeight: (0, t.ov)((0, t.qh)((0, t.k5)() || {}, "windowHeight") || 1136),
        useSmall: (0, t.ov)((0, t.qh)((0, t.k5)() || {}, "windowHeight") || 1136) < 1334
    },
    methods: {
        handleClose: function() {
            this.setData({
                visible: !1
            });
        },
        handleStepOn: function() {
            var e = this.data, t = e.imgList, a = e.step;
            t.length - 1 > a ? (this.setData({
                step: a + 1
            }), this.triggerEvent("change", a + 1)) : (this.triggerEvent("end"), this.handleClose());
        }
    }
});