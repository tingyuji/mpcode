var e = require("../../_/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getOrderDetailToB = u, exports.getOrderDetailToC = p;

var t, r = e(require("../../_/regenerator")), a = require("../../_/helpers/asyncToGenerator"), n = require("../../_/helpers/defineProperty"), i = require("../../_/helpers/objectSpread2"), o = require("../../$app"), s = require("../../$page"), c = require("@ktt/ktt-wxapp-boundle").utils.emptyFunction;

function u() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, o.fy)(i({
        url: "/api/ktt_order/business/query/order_detail",
        convertToCamel: !0,
        convertRequestToSnake: !0
    }, e)).then(function(e) {
        return (e || {}).result || {};
    });
}

function p() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return (0, o.fy)(i({
        url: "/api/ktt_order/customer/query/order",
        convertToCamel: !0,
        convertRequestToSnake: !0
    }, e)).then(function(e) {
        return (e || {}).result || {};
    });
}

var l = {
    NO: 1,
    ORDER_SN: 2,
    ORDER_STATUS: 3,
    NICKNAME: 4,
    GOODS: 5,
    SHIPPING_INFO: 11,
    RECEIVE_INFO: 6,
    BUYER_MEMO: 7,
    BUSINESS_NOTE: 8,
    SECRET_REMARK: 9,
    FILTER_CANCEL: 10
}, O = [ {
    type: l.NO,
    name: "跟团号"
}, {
    type: l.ORDER_SN,
    name: "订单编号"
}, {
    type: l.ORDER_STATUS,
    name: "订单状态"
}, {
    type: l.NICKNAME,
    name: "团员微信昵称"
}, {
    type: l.GOODS,
    name: "商品信息"
}, {
    type: l.SHIPPING_INFO,
    name: "快递单号"
}, {
    type: l.RECEIVE_INFO,
    name: "收货信息"
}, {
    type: l.BUYER_MEMO,
    name: "团员备注"
}, {
    type: l.BUSINESS_NOTE,
    name: "团长备注"
}, {
    type: l.SECRET_REMARK,
    name: "团长私密备注"
} ], d = [ l.NO, l.SHIPPING_INFO ], f = (n(t = {}, l.NO, !1), n(t, l.ORDER_SN, !1), 
n(t, l.ORDER_STATUS, !1), n(t, l.NICKNAME, !1), n(t, l.GOODS, !0), n(t, l.SHIPPING_INFO, !1), 
n(t, l.RECEIVE_INFO, !0), n(t, l.BUYER_MEMO, !1), n(t, l.BUSINESS_NOTE, !1), n(t, l.SECRET_REMARK, !1), 
t);

(0, s.afb)({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        orderSn: {
            type: String,
            value: "",
            observer: function(e) {
                e && this.searchOrderDetail(e);
            }
        },
        isB: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        show: !1,
        OPTION_TYPES: l,
        optionsList: [],
        selectOptionsMap: {}
    },
    cloudStorageOptions: {},
    attached: function() {
        this.setData({
            show: !0
        }), this.initOptionsList(), this.initSelectOptions();
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        initOptionsList: function() {
            var e = this.data.item, t = [];
            e.displayType === s.u9.localLifeServer && (t = d), this.setData({
                optionsList: O.filter(function(e) {
                    var r = e.type;
                    return -1 === t.indexOf(r);
                })
            });
        },
        initSelectOptions: function() {
            var e = this;
            return a(r.default.mark(function t() {
                var a, n;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.$baseRequest(i(i({}, o.jh), {}, {
                            data: {
                                scene: s.aew.copyOrderDefaultOption
                            }
                        })).catch(c);

                      case 2:
                        a = t.sent, n = {}, (null == a ? void 0 : a.result) && (e.cloudStorageOptions = a.result, 
                        n = JSON.parse(e.cloudStorageOptions)), e.setData({
                            selectOptionsMap: Object.assign({}, f, n)
                        });

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        selectOption: function(e) {
            var t = this.data.selectOptionsMap, r = (0, o.jo)(e).option;
            t[r.type] = !t[r.type], this.setData({
                selectOptionsMap: t
            });
        },
        onSwitchChange: function(e) {
            var t = this.data.selectOptionsMap, r = (0, o.jo)(e).type;
            t[r] = !t[r], this.setData({
                selectOptionsMap: t
            });
        },
        searchOrderDetail: function(e) {
            var t = this;
            return a(r.default.mark(function a() {
                var n;
                return r.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (r.prev = 0, !t.data.isB) {
                            r.next = 7;
                            break;
                        }
                        return r.next = 4, u({
                            noErrorToast: !0,
                            data: {
                                parentOrderSn: e
                            }
                        });

                      case 4:
                        n = r.sent, r.next = 11;
                        break;

                      case 7:
                        return r.next = 9, p({
                            noErrorToast: !0,
                            data: {
                                parentOrderSn: e
                            }
                        });

                      case 9:
                        n = (n = r.sent) && n.order;

                      case 11:
                        n && n.activityNo && t.setData({
                            item: n
                        }), r.next = 16;
                        break;

                      case 14:
                        r.prev = 14, r.t0 = r.catch(0);

                      case 16:
                      case "end":
                        return r.stop();
                    }
                }, a, null, [ [ 0, 14 ] ]);
            }))();
        },
        getSelectOrderInfo: function() {
            var e = this.data, t = e.item, r = e.optionsList, a = e.selectOptionsMap, n = void 0 === a ? {} : a, i = n[l.FILTER_CANCEL];
            return r.filter(function(e) {
                return n[e.type];
            }).map(function(e) {
                var r = "";
                switch (e.type) {
                  case l.NO:
                    r = "跟团号：" + t.participateNo;
                    break;

                  case l.ORDER_SN:
                    r = "订单编号：" + t.parentOrderSn;
                    break;

                  case l.ORDER_STATUS:
                    r = "订单状态：" + (0, s.aia)(t.aggregateStatus);
                    break;

                  case l.NICKNAME:
                    r = "团员微信昵称：" + t.nickName;
                    break;

                  case l.GOODS:
                    r = function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = t.filterCancel, a = void 0 !== r && r, n = (e.subOrderList || []).map(function(e) {
                            if (a && e.cancelStatus === s._t.CANCELLED) return "";
                            var t = e.goodsSpecification ? "(".concat(e.goodsSpecification, ")") : "", r = !a && e.alreadyCancelNumber ? "已取消".concat(e.alreadyCancelNumber, "件") : "", n = e.verificationNumber ? "已核销".concat(e.verificationNumber, "件") : "", i = a ? (e.goodsNumber || 0) - (e.alreadyCancelNumber || 0) : e.goodsNumber, o = [ r, n ].filter(function(e) {
                                return !!e;
                            }).join(",");
                            return o = o ? "(含".concat(o, ")") : "", "".concat(e.goodsName).concat(t, " +").concat(i).concat(o);
                        }).filter(function(e) {
                            return !!e;
                        });
                        return "商品信息：\n" + n.join(",\n");
                    }(t, {
                        filterCancel: i
                    });
                    break;

                  case l.SHIPPING_INFO:
                    r = "快递信息：" + ((0, s.aij)(t) || "暂无");
                    break;

                  case l.RECEIVE_INFO:
                    r = "收货信息：" + (0, s.ah4)(t);
                    break;

                  case l.BUYER_MEMO:
                    r = "团员备注：" + (t.buyerMemo || "暂无");
                    break;

                  case l.BUSINESS_NOTE:
                    r = "团长备注：" + (t.businessNote || "暂无");
                    break;

                  case l.SECRET_REMARK:
                    r = "团长私密备注：" + (t.secretRemark || "暂无");
                }
                return r;
            });
        },
        copyOrder: function() {
            var e = this, t = this.getSelectOrderInfo();
            if (t && t.length) {
                var r = t.reduce(function(e, t) {
                    return t && (e = "".concat(e + "\n").concat(t)), e;
                });
                this.updateDefaultOptions(), o.f3.setClipboardData({
                    data: r
                }).then(function() {
                    e.close();
                });
            }
        },
        updateDefaultOptions: function() {
            var e = this.data.selectOptionsMap, t = JSON.stringify(e);
            t !== this.cloudStorageOptions && this.$baseRequest(i(i({}, o.qr), {}, {
                data: {
                    scene: s.aew.copyOrderDefaultOption,
                    value: t
                }
            }));
        }
    }
});