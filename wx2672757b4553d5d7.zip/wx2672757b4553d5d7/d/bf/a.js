var e = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/defineProperty"), a = e(require("../../_/regenerator")), r = require("../../_/helpers/asyncToGenerator"), n = require("../../$app"), s = require("../../$page"), i = getApp().store, h = void 0 === i ? {} : i, o = (h.getState && h.getState()).main.systemInfo.screenWidth;

(0, s.afb)({
    properties: {
        type: {
            type: String,
            value: ""
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {
                if (e && e !== t) {
                    var a = this.data.shareCard, r = void 0 === a ? {} : a, i = (0, n.qh)(r, "sharePosition") || "shareMultiCards", h = (0, 
                    n.qh)(r, "shareImages[0]") || {};
                    this.$impr({
                        page_el_sn: s.ab_.multiCards,
                        extParams: {
                            sharePosition: i,
                            ktt_share_style: h.name,
                            recent_share_style: this.recentName || ""
                        }
                    });
                }
            }
        },
        shareCard: {
            type: Object,
            value: {},
            observer: function(e) {
                e && (!e.imageUrl || null != e && e.imageUrls || (e.imageUrls = [ e.imageUrl ], 
                e.shareImages = [ {
                    name: "default",
                    url: e.imageUrl
                } ])), (0, n.qh)(e, "shareImages.length") && (this.setSequence(e.shareImages), this.setRecommendCard(e)), 
                e ? this.setData({
                    shareCard: e
                }) : this.setData({
                    currentIndex: 0,
                    imageUrlsIndex: 0
                });
            }
        }
    },
    data: {
        currentIndex: 0,
        pieceWidth: 375,
        previousmargin: 100,
        scaleRate: 0,
        depth: .15,
        imageUrlsIndex: 0,
        alphaDepth: .8
    },
    attached: function() {
        var e = this.data.previousmargin, t = o - 2 * (0, n.qf)(e);
        this.setData({
            pieceWidth: t
        });
    },
    methods: {
        setSequence: function() {
            var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            if (this.lastLocation = wx.getStorageSync(n.ct.multiShareLocationV2), this.lastLocation) {
                var a = t.findIndex(function(t) {
                    return e.lastLocation === t.name;
                });
                if (a > -1) {
                    var r = t[a];
                    r.lastUse = !0, t.splice(a, 1), t.unshift(r), this.triggerEvent("currentIndex", {
                        currentIndex: a,
                        name: r.name,
                        recentName: r.name
                    }), this.recentName = r.name;
                } else this.triggerEvent("currentIndex", {
                    currentIndex: 0,
                    name: t[0].name
                }), a = 0;
                this.setData({
                    imageUrlsIndex: a
                });
            } else this.triggerEvent("currentIndex", {
                currentIndex: 0,
                name: t[0].name
            }), this.setData({
                imageUrlsIndex: 0
            });
        },
        setRecommendCard: function() {
            var e = arguments, t = this;
            return r(a.default.mark(function r() {
                var s, i, h, o, c, u, d, l;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return s = e.length > 0 && void 0 !== e[0] ? e[0] : {}, a.next = 3, (0, n.gr)().getConfig();

                      case 3:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 6;
                            break;
                        }
                        a.t0 = {};

                      case 6:
                        if (i = a.t0, h = i.sharePanelCardRecommend, o = (h = void 0 === h ? {} : h).name, 
                        c = void 0 === o ? "" : o, u = s.shareImages, d = void 0 === u ? [] : u, c) {
                            a.next = 13;
                            break;
                        }
                        return a.abrupt("return");

                      case 13:
                        (l = d.find(function(e) {
                            return e.name === c;
                        })) && !l.lastUse && (l.recommandUse = !0, t.setData({
                            shareCard: s
                        }));

                      case 15:
                      case "end":
                        return a.stop();
                    }
                }, r);
            }))();
        },
        closeDialog: function() {
            this.triggerEvent("closeShareImage");
        },
        handleSwiperChangePosition: function(e) {
            var t = (0, n.jo)(e).dx, a = this.data.pieceWidth, r = ((t = Math.abs(t)) / a).toFixed(2);
            this.setData({
                scaleRate: r
            });
        },
        tapSharebtn: function(e) {
            var t = this.data, a = t.shareCard, r = t.currentIndex;
            this.triggerEvent("onTapShare", e);
            var i = (0, n.qh)(a, "sharePosition") || "shareMultiCards", h = (0, n.qh)(a, "shareImages[".concat(r, "]")) || {}, o = (0, 
            n.jo)(e).multiSharePosition;
            this.$click({
                page_el_sn: s.ab_.multiCards,
                extParams: {
                    sharePosition: i,
                    ktt_share_style: h.name,
                    recent_share_style: this.recentName || ""
                }
            }), o && this.$click({
                page_el_sn: s.ab_.shareBtn
            });
        },
        animationfinish: function(e) {
            var t = (0, n.jo)(e).current, a = this.data.shareCard;
            (0, n.ev)({
                type: n.u.SHARE_MULTI_CARD,
                tags: {
                    multiShare: "scroll"
                }
            });
            var r = (0, n.qh)(a, "shareImages[".concat(t, "]")) || {}, i = (0, n.qh)(a, "imageUrls") || [], h = (0, 
            n.qh)(a, "sharePosition") || "shareMultiCards";
            wx.setStorage({
                key: n.ct.multiShareLocationV2,
                data: r.name
            });
            var o = i.findIndex(function(e) {
                return e === r.url;
            });
            this.setData({
                currentIndex: t,
                scaleRate: 0,
                imageUrlsIndex: o
            }), this.triggerEvent("currentIndex", {
                currentIndex: o,
                name: r.name
            }), this.$impr({
                page_el_sn: s.ab_.multiCards,
                extParams: {
                    sharePosition: h,
                    ktt_share_style: r.name,
                    recent_share_style: this.recentName || ""
                }
            });
        },
        imageLoadError: function(e) {
            (0, n.ev)({
                type: n.u.SHARE_IMAGE_PRELOAD,
                tags: t({}, n.u.TYPE, "fail")
            });
        }
    }
});