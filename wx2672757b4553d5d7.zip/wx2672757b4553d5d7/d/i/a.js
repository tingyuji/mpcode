var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), a = require("../../_/helpers/objectSpread2"), s = require("../../$app"), r = require("../../$page");

(0, r.afb)({
    properties: {
        isFollow: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e !== this.data.hasFollow && this.setData({
                    hasFollow: e
                });
            }
        },
        userNo: {
            type: String,
            value: "",
            observer: function(e) {
                e && (this.data.autoFollow && this._afterInitFunc(), this.setData({
                    subscribeBizData: {
                        groupUserNo: e
                    }
                }));
            }
        },
        followTrackingEle: {
            type: Number,
            value: 0
        },
        onlyOnce: {
            type: Boolean,
            value: !1
        },
        autoFollow: {
            type: Boolean,
            value: !1
        },
        needPendingAfterFollow: {
            type: Boolean,
            value: !1
        },
        activityNo: {
            type: String,
            value: ""
        },
        isFromIndex: {
            type: Boolean,
            value: !1
        },
        refSubCodeNo: {
            type: String,
            value: ""
        },
        locationSubscribeMessage: {
            type: Boolean,
            value: !1
        },
        followTemplateData: {
            type: Object,
            value: {}
        },
        useExternal: {
            type: String,
            value: ""
        }
    },
    data: {
        hasFollow: !1,
        triggerSubscribe: !1,
        $gray: {
            alwaysGetSetting: !1
        },
        subscribeScene: "follow"
    },
    subscribeComp: null,
    templateList: [],
    requestSubscribeCnt: 1,
    lifetimes: {
        created: function() {
            this.requestSubscribeCnt = 1;
        }
    },
    methods: {
        handleFollow: function() {
            var e = this.data, t = e.onlyOnce, a = e.locationSubscribeMessage, r = e.triggerSubscribe, i = (s.fv.getState && s.fv.getState()).biz.lockSubStatus, o = this.data.hasFollow;
            a && (o = o && !!i), o && t || (o ? this.handleCancelSubscribe() : a ? this.setData({
                triggerSubscribe: !r
            }) : this.handleAddSubscribe());
        },
        _afterInitFunc: function() {
            this.data.autoFollow && !this.data.hasFollow && this.handleAddSubscribe();
        },
        handleAddSubscribe: function() {
            var e = this, t = this.data, r = t.userNo, i = t.followTrackingEle, o = t.refSubCodeNo;
            if (i && (0, s.g0)({
                page_el_sn: i
            }), r) {
                var n = {
                    user_no: r,
                    type: 1
                };
                o && (n.refSubCodeNo = o), (0, s.fy)(a(a({}, s.rw), {}, {
                    data: n
                })).then(function() {
                    e.setData({
                        hasFollow: !0
                    }), e.showToast("订阅成功"), e.triggerEvent("onSubscribeChange", {
                        isFollow: !0
                    });
                }).catch(function(e) {
                    (0, s.hp)({
                        e: e,
                        msg: "subscribeLeaderBusiness fail"
                    });
                });
            }
        },
        handleCancelSubscribe: function() {
            var e = this, t = this.data.userNo;
            t && (0, s.fy)(a(a({}, s.rw), {}, {
                data: {
                    user_no: t,
                    type: 2
                }
            })).then(function() {
                e.setData({
                    hasFollow: !1
                }), e.triggerEvent("onSubscribeChange", {
                    isFollow: !1
                }), e.showToast("已退订");
            }).catch(function(e) {
                (0, s.hp)({
                    e: e,
                    msg: "subscribeLeaderBusiness fail"
                });
            });
        },
        showToast: function(e) {
            (0, s.ri)({
                title: e,
                icon: "none"
            });
        },
        handleSubscribeMsg: function(i) {
            var o = this;
            return t(e.default.mark(function t() {
                var n, u, l, c, b, h, d, p, g, S, f, v, w;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = (0, s.jo)(i), u = n.action, l = n.statusMap, c = n.allAuth, b = s.fv.getState && s.fv.getState(), 
                        h = b.biz.lockSubStatus, "error" !== u && "allAuthReject" !== u && "allAuth" !== u) {
                            e.next = 6;
                            break;
                        }
                        return "error" !== u || h || (s.fv.dispatch((0, s.qz)(!0)), o.triggerEvent("updateLockSubStatus", {
                            action: u
                        })), o.data.isFollow || o.handleAddSubscribe(), e.abrupt("return");

                      case 6:
                        if ("success" !== u || c) {
                            e.next = 38;
                            break;
                        }
                        if (!(o.requestSubscribeCnt > 1) || o.data.$gray.alwaysGetSetting) {
                            e.next = 13;
                            break;
                        }
                        return s.fv.dispatch((0, s.qz)(!0)), d = o.data.isFollow, o.triggerEvent("updateLockSubStatus", {
                            isFollow: d
                        }), d || o.handleAddSubscribe(), e.abrupt("return");

                      case 13:
                        if (h) {
                            e.next = 37;
                            break;
                        }
                        if ((0, s.gt)(), o.templateList) {
                            e.next = 17;
                            break;
                        }
                        return e.abrupt("return");

                      case 17:
                        return e.next = 19, (0, s.e7)(o.templateList);

                      case 19:
                        if (p = e.sent, g = p.allAuth, S = p.allAccept, f = p.allReject, o.$click({
                            page_el_sn: r.ae7.accept,
                            extParams: a({
                                scene: o.data.subscribeScene,
                                is_show: !0,
                                all_auth: g,
                                all_accept: S,
                                all_reject: f,
                                templateLen: o.templateList.length
                            }, l)
                        }), g) {
                            e.next = 31;
                            break;
                        }
                        return o.requestSubscribeCnt++, (v = o.getSubscribeMsgComp()) && v.resetTemplateCnt(), 
                        e.abrupt("return", o.$showToast({
                            title: "订阅失败"
                        }));

                      case 31:
                        w = o.data.isFollow, s.fv.dispatch((0, s.qz)(!0)), o.triggerEvent("updateLockSubStatus", {
                            isFollow: w
                        }), w || o.handleAddSubscribe();

                      case 35:
                        e.next = 38;
                        break;

                      case 37:
                        o.handleAddSubscribe();

                      case 38:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        handleSubscribeInfo: function(e) {
            var t = (0, s.jo)(e).templateList;
            this.templateList = t;
        },
        getSubscribeMsgComp: function() {
            return this.subscribeComp || (this.subscribeComp = this.selectComponent("#subscribeGuideV2")), 
            this.subscribeComp;
        },
        changeSubscribeGuide: function(e) {
            var t = (0, s.jo)(e).showSubscribeGuide;
            this.triggerEvent("changeSubscribeGuide", {
                showSubscribeGuide: t
            });
        },
        triggerSubscribe: function() {
            this.setData({
                triggerSubscribe: !this.data.triggerSubscribe
            });
        }
    }
});