var e = require("../../_/helpers/objectSpread2");

(0, require("../../$page").afb)({
    methods: {
        showModal: function(r) {
            return this.$showModal(e(e({}, r), {}, {
                id: "_inner_wx_modal"
            }));
        }
    }
});