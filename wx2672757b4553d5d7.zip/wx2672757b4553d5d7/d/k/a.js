var e = require("../../_/helpers/createForOfIteratorHelper"), t = require("../../$app");

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        imageData: {
            type: Object,
            value: {},
            observer: function(e) {
                e && e.images && this.batchReplaceUrl(e);
            }
        },
        trackShareType: {
            type: String,
            value: "topShare"
        },
        width: {
            type: Number,
            value: 630
        },
        height: {
            type: Number,
            value: 1156
        }
    },
    data: {
        showCanvas: !1
    },
    startTime: 0,
    downLoadTime: 0,
    methods: {
        fillText: function(e, t, a, i, n) {
            i = i > 566 ? i + n : i, e.fillText(t, a, i);
        },
        calculateImage: function(e, a, i, n) {
            var r = a.width / a.height, l = (0, t.qh)(i, "action[0].width") || a.width, o = l / r;
            e.drawImage(a.path, i.x || 0, i.y > 566 ? i.y + n : i.y || 0, l, o);
        },
        lineFeed: function(t, a, i, n, r, l) {
            var o, s = this, h = "", c = [], g = 0, u = "", p = e(i);
            try {
                for (p.s(); !(o = p.n()).done; ) {
                    var d = o.value;
                    g += d.length, t.measureText(h + d).width < n ? (u = d, h += d) : (c.length && (h = h.substring(0, h.length - u.length) + "…"), 
                    c.push(h), h = d), g === i.length && c.push(h);
                }
            } catch (e) {
                p.e(e);
            } finally {
                p.f();
            }
            c.forEach(function(e, i) {
                i > 1 || s.fillText(t, e, a.x, a.y + 10 * i + (i + 1) * Number(r), l);
            });
        },
        setTextStyle: function(e, t) {
            var a = t.str.split('"')[1].split(" "), i = a.pop();
            return wx.canIUse("CanvasContext.font") ? e.font = "".concat(i, "px ").concat(a.join(" ")) : e.setFontSize(i), 
            e.setFillStyle(t.color), e.setTextAlign(t.align), i;
        },
        escapedCharacter: function(e) {
            return e.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"');
        },
        drawText: function(e, t, a) {
            var i = this;
            t.forEach(function(t) {
                var n = t.str.split('">')[1].split("</")[0];
                n = i.escapedCharacter(n), e.save();
                var r = i.setTextStyle(e, t);
                "center" === t.lineAlign && (t.x = (t.lineAlignRightEdge + t.lineAlignLeftEdge) / 2, 
                e.setTextAlign("center")), t.width ? i.lineFeed(e, t, n, t.width, r, a) : i.fillText(e, n, t.x, t.y + Number(r), a), 
                e.restore();
            });
        },
        drawPoster: function(e, a) {
            var i = this;
            e.draw(!1, function() {
                setTimeout(function() {
                    wx.canvasToTempFilePath({
                        canvasId: "hidePoster",
                        fileType: "jpg",
                        quality: 1,
                        success: function(e) {
                            i.triggerEvent("generatePoster", {
                                url: e.tempFilePath,
                                width: i.data.width,
                                height: i.data.height
                            });
                        },
                        fail: function(a) {
                            (0, t.hp)({
                                name: "generate_poster_fe",
                                e: a,
                                msg: "wx.canvasToTempFilePath生成海报失败！",
                                context: e,
                                imageData: i.data.imageData
                            }), i.triggerEvent("generatePosterFail");
                        },
                        complete: function(t) {
                            e.clearRect(0, 0, i.data.width, i.data.height), i.setData({
                                showCanvas: !1
                            });
                        }
                    }, i);
                }, 200);
            });
        },
        batchReplaceUrl: function(e) {
            var a = this;
            this.startTime = new Date().getTime(), this.adaptiveIndex = -1;
            var i = (e.images || []).map(function(e, i) {
                return 1 === e.kttAdaptive && (a.adaptiveIndex = i, e.url = e.url.split("?")[0] + "?imageMogr2/auto-orient/thumbnail/!566xr/quality/100|imageMogr2/crop/x623/rradius/8/format/png/quality/100"), 
                (0, t.j_)((0, t.qi)(e.url), 7e3);
            });
            Promise.all(i).then(function(i) {
                a.downLoadTime = new Date().getTime();
                var n = a.adaptiveIndex > -1 ? i[a.adaptiveIndex].height - 566 : 0, r = (0, t.qh)(i, "[0].width") || 630, l = (0, 
                t.qh)(i, "[0].height") || 1156;
                a.setData({
                    width: r,
                    height: l + n,
                    showCanvas: !0
                }, function() {
                    var t = wx.createCanvasContext("hidePoster", a);
                    t.setFillStyle("white"), t.fillRect(0, 0, r, l + n), i.forEach(function(i, r) {
                        a.calculateImage(t, i, e.images[r], n);
                    }), a.drawText(t, e.text || [], n), a.drawPoster(t, n);
                });
            }).catch(function(i) {
                a.setData({
                    showCanvas: !1
                }), (0, t.hp)({
                    name: "generate_poster_fe",
                    e: i,
                    msg: "wx.getImageInfo下载图片失败！",
                    images: e.images
                }), a.triggerEvent("generatePosterFail");
            });
        }
    }
});