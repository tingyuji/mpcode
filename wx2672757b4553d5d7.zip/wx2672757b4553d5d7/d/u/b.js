var e = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), t = require("../../_/helpers/asyncToGenerator"), a = require("../../$app"), o = require("../../$page"), r = getApp(), i = r.store, s = void 0 === i ? {} : i, l = r.$apiCategory, n = (s.getState && s.getState()).main.isCustom, h = (0, 
a.ke)(), u = h.statusBarHeight, d = h.titleBarHeight, v = h.navBarHeight, p = "windows" === ((0, 
a.k5)() || {}).platform;

(0, o.afb)({
    lastClickTime: void 0,
    observer: void 0,
    properties: {
        v2: {
            type: Boolean,
            value: !1
        },
        noHideTitleWithTop: {
            type: Boolean,
            value: !1
        },
        notFixed: {
            type: Boolean,
            value: !1
        },
        useTitleLogo: {
            type: Boolean,
            value: !1
        },
        showHeader: {
            type: Boolean,
            value: !0,
            observer: function(e) {
                e || this.data.hideHeader || this.resetObserver();
            }
        },
        hideHeader: {
            type: Boolean,
            value: !1
        },
        usePlace: {
            type: Boolean,
            value: !1
        },
        isFixedTop: {
            type: Boolean,
            value: !0
        },
        back: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: ""
        },
        hideHome: {
            type: Boolean,
            value: !1
        },
        avatar: {
            type: String,
            value: ""
        },
        customBackHandle: {
            type: Boolean,
            value: !1
        },
        customHomeHandle: {
            type: Boolean,
            value: !1
        },
        customHomeText: {
            type: String,
            value: ""
        },
        hideBack: {
            type: Boolean,
            value: !1
        },
        useBottomHomeTip: {
            type: Boolean,
            value: !1
        },
        showHomeTip: {
            type: Boolean,
            value: !0
        },
        hiddenBorder: {
            type: Boolean,
            value: !1
        },
        titleColor: {
            type: String,
            value: "#151516"
        },
        enableScrollTop: {
            type: Boolean,
            value: !1
        },
        needResetOnShow: {
            type: Boolean,
            value: !1
        },
        setHeaderPointerEventNone: {
            type: Boolean,
            value: !1
        },
        immersiveBack: {
            type: Boolean,
            value: !1
        },
        showNvHomeButton: {
            type: Boolean,
            value: !1
        },
        backgroundColor: {
            type: String,
            value: ""
        },
        showHeaderTitleColor: {
            type: String,
            value: ""
        }
    },
    data: {
        show: n || p,
        statusBarHeight: u,
        titleBarHeight: d,
        navBarHeight: v,
        hasLastUrl: !1,
        noHomeBtn: !1,
        $gray: {
            panduoduo: !1
        },
        _showHeader: !1
    },
    pageLifetimes: {
        show: function() {
            this.data.needResetOnShow && this.resetObserver();
        }
    },
    attached: function() {
        this.lastClickTime = null;
        var e = ((0, a.ki)() || {}).lastUrl;
        (void 0 === e ? "" : e) && this.setData({
            hasLastUrl: !0
        }), "embedded" === l && this.setData({
            hideHome: !0
        }), this.setData({
            _showHeader: this.data.showHeader
        }), this.data.showHeader || this.data.hideHeader || this.resetObserver();
    },
    detached: function() {
        this.lastClickTime = null, this.observer && this.observer.disconnect();
    },
    methods: {
        resetObserver: function() {
            var e = this;
            this.observer = this.createIntersectionObserver({}), this.observer.relativeToViewport({
                top: 0
            }).observe(".observer-line", function(t) {
                0 === (t || {}).intersectionRatio ? e.toggleHeaderBg(!0) : e.toggleHeaderBg(!1);
            });
        },
        toggleHeaderBg: function(e) {
            var t = this.data, a = t._showHeader, o = t.showHeader, r = t.hideHeader;
            o && !r || a === e || (this.setData({
                _showHeader: e
            }), this.triggerEvent("showHeaderChange", {
                show: e
            }));
        },
        onUserPage: function() {
            this.data.customHomeHandle ? this.triggerEvent("home") : (0, a.n7)({
                url: a.ob.index
            });
        },
        backHandle: (0, a.my)(t(e.default.mark(function t() {
            var o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.data.customBackHandle) {
                        e.next = 3;
                        break;
                    }
                    return this.triggerEvent("back"), e.abrupt("return");

                  case 3:
                    if (o = (0, a.ki)(), !o.lastUrl) {
                        e.next = 8;
                        break;
                    }
                    return e.abrupt("return", (0, a.ny)());

                  case 8:
                    (0, a.n7)({
                        url: a.ob.index
                    });

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t, this);
        }))),
        handleHeadClick: function() {
            if (this.data.enableScrollTop) if (this.lastClickTime) {
                var e = Date.now();
                e - this.lastClickTime < 300 && this.handleScrollTop(), this.lastClickTime = e;
            } else this.lastClickTime = Date.now();
        },
        handleScrollTop: function() {
            this.data._showHeader && wx.pageScrollTo({
                scrollTop: 0
            });
        }
    }
});