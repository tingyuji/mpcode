var e = require("../../$page"), i = require("../../$app");

(0, e.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        reasonList: [ {
            id: 1,
            desc: "收货地址或手机号码填错了"
        }, {
            id: 2,
            desc: "忘记支付密码/余额不足"
        }, {
            id: 3,
            desc: "无法正常支付"
        }, {
            id: 4,
            desc: "买错了/不想买了"
        }, {
            id: 5,
            desc: "其他原因"
        } ],
        selectedReason: {
            id: ""
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        handleReasonClick: function(e) {
            var s = (0, i.jo)(e).item;
            this.setData({
                selectedReason: s
            });
        },
        handleConfirm: function() {
            var e = this.data.selectedReason;
            e.id ? this.triggerEvent("confirm", {
                reason: e
            }) : (0, i.ri)({
                title: "请选择原因"
            });
        }
    }
});