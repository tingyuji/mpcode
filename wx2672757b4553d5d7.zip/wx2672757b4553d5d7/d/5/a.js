var t = require("../../_/helpers/interopRequireDefault"), e = require("../../_/helpers/defineProperty"), n = t(require("../../_/regenerator")), i = require("../../_/helpers/asyncToGenerator"), o = require("../../$page"), r = require("../../$app"), a = t(require("@pdd/std-format"));

(0, o.afb)({
    properties: {
        applicationInfoList: {
            type: Array,
            value: [],
            observer: function(t) {
                this.formatApplicationInfoList(t);
            }
        },
        enableShowAll: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        SIGN_UP_INFO_TYPE: r.cj,
        itemList: [],
        isAudioPlaying: !1
    },
    lifetimes: {
        attached: function() {},
        detached: function() {
            this.innerAudioContext && this.innerAudioContext.destroy();
        }
    },
    methods: {
        formatApplicationInfoList: function(t) {
            var e = this, n = t.filter(function(t) {
                return null !== t;
            });
            n.forEach(function(t) {
                switch (t.type) {
                  case r.cj.MUL_RADIO:
                    try {
                        t.formatValue = JSON.parse(t.value);
                    } catch (n) {
                        t.formatValue = [], e.$error({
                            e: n,
                            msg: "format mulRadio fail"
                        });
                    }
                    break;

                  case r.cj.POSITION:
                    try {
                        var n = JSON.parse(t.value), i = n.name, o = void 0 === i ? "" : i, u = n.address, s = void 0 === u ? "" : u, c = n.latitude, l = void 0 === c ? "" : c, d = n.longitude, f = void 0 === d ? "" : d;
                        t.formatValue = {
                            name: o,
                            address: s,
                            latitude: parseFloat(l),
                            longitude: parseFloat(f)
                        };
                    } catch (n) {
                        t.formatValue = {}, e.$error({
                            e: n,
                            msg: "format position fail"
                        });
                    }
                    break;

                  case r.cj.AUDIO:
                    e.initInnerAudioContext(), t.formatValue = Math.ceil((0, r.qh)(t, "audio.duration") / 1e3);
                    break;

                  case r.cj.DATE:
                    t.value = a.default.formatTime(t.value, "YYYY-MM-dd");
                }
            }), this.setData({
                itemList: n
            });
        },
        initInnerAudioContext: function() {
            var t = this;
            this.innerAudioContext || (this.innerAudioContext = r.f3.createInnerAudioContext(), 
            this.innerAudioContext.onError(function(e) {
                t.$error({
                    msg: "InnerAudioContext error",
                    e: e
                }), t.onPlayStop();
            }), this.innerAudioContext.onPlay(function() {
                t.setData({
                    isAudioPlaying: !0
                });
            }), this.innerAudioContext.onStop(function() {
                t.onPlayStop();
            }), this.innerAudioContext.onPause(function() {
                t.onPlayStop();
            }), this.innerAudioContext.onEnded(function(e) {
                t.onPlayStop();
            }));
        },
        onPlayStop: function() {
            this.setData({
                isAudioPlaying: !1
            });
        },
        playAudio: (0, r.r2)(function() {
            var t = i(n.default.mark(function t(e) {
                var i, o = this;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (i = (0, r.jo)(e, "src"), !this.innerAudioContext.src || this.innerAudioContext.src !== i) {
                            t.next = 8;
                            break;
                        }
                        if (this.innerAudioContextCanplay) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return");

                      case 4:
                        this.innerAudioContext.stop(), this.innerAudioContext.play(), t.next = 10;
                        break;

                      case 8:
                        this.innerAudioContext.src = i, this.innerAudioContext.onCanplay(function() {
                            o.innerAudioContextCanplay = !0, o.innerAudioContext.play();
                        });

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(), 500),
        openLocation: function(t) {
            var e = this, n = (0, r.jo)(t, "location");
            r.f3.openLocation(n).catch(function(t) {
                e.$error({
                    e: t,
                    msg: "openLocation fail"
                });
            });
        },
        handlePreviewImg: function(t) {
            var e = (0, r.jo)(t), n = e.previewCurrent, i = e.previewUrls;
            r.f3.previewImage({
                current: (0, r.iu)(n),
                urls: i.map(r.iu)
            });
        },
        handleShowAll: function(t) {
            var n = (0, r.jo)(t).path;
            this.setData(e({}, n, !0));
        }
    }
});