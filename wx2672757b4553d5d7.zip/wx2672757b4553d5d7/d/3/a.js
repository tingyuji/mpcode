var e = require("../../$page"), r = require("../../$app");

(0, e.afb)({
    properties: {
        item: {
            type: Object,
            value: {}
        }
    },
    data: {
        ORDER_STATUS: e.yz,
        ACTIVITY_TYPE: r.b
    }
});