var e = require("../../$page"), r = require("../../$app");

(0, e.afb)({
    properties: {
        modalId: {
            type: String,
            value: "_receiveModal"
        }
    },
    data: {
        total: 0,
        reveiveModalOrderList: []
    },
    methods: {
        showReceiveModal: function(e) {
            var t = e.map(function(e) {
                var t, i;
                return {
                    thumbUrl: (null === (i = null === (t = e.subOrderList) || void 0 === t ? void 0 : t[0]) || void 0 === i ? void 0 : i.thumbUrl) || (0, 
                    r.jx)(),
                    goodsNumber: e.goodsNumber
                };
            }), i = [];
            if (4 === t.length) i.push(t.slice(0, 2)), i.push(t.slice(2)); else if (i.push(t.slice(0, 3)), 
            t.length > 3) for (var l = 3; l < t.length; l += 3) i.push(t.slice(l, l + 3));
            return this.setData({
                total: e.length,
                reveiveModalOrderList: i
            }), this.$showModal({
                id: this.data.modalId
            });
        }
    }
});