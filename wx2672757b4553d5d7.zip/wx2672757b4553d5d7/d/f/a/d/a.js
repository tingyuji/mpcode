Component({
    properties: {},
    data: {},
    methods: {
        cancel: function() {
            this.triggerEvent("cancel");
        },
        confirm: function() {
            this.triggerEvent("confirm");
        }
    }
});