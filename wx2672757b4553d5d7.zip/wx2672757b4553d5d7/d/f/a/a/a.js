Component({
    properties: {
        afterFullRefund: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        cancel: function() {
            this.triggerEvent("cancel");
        },
        confirm: function() {
            this.triggerEvent("confirm");
        }
    }
});