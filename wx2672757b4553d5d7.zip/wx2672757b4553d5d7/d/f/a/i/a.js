var e = require("../../../../_/helpers/defineProperty"), t = require("../../../../_/helpers/objectSpread2"), i = require("../../../../$app"), a = require("../../../../$page");

(0, a.afb)({
    behaviors: [],
    properties: {
        item: {
            type: Object,
            value: {}
        },
        operationList: {
            type: Array,
            value: []
        }
    },
    data: {
        show: !1,
        supplyInfo: {},
        showOperateBefore: !1
    },
    attached: function() {
        var e = this, s = this.data.item;
        s.isCopyHelpSellOrder && s.displayType !== a.u9.localLifeServer && (0, a.aby)(a.zm.viewSupplyInfo, !1) ? this.$baseRequest(t(t({}, i.rx), {}, {
            data: {
                activityNo: s.activityNo
            }
        })).then(function(t) {
            var i = t && t.result;
            (null == i ? void 0 : i.visitUidSupplyUserNo) && e.setData({
                showOperateBefore: !0,
                supplyInfo: {
                    supplyUserNo: i.visitUidSupplyUserNo,
                    supplyUserName: i.visitUidSupplyNickName,
                    supplyAvatar: i.visitUidSupplyAvatar
                }
            }), e.show();
        }).catch(function() {
            e.show();
        }) : this.show();
    },
    methods: {
        cancel: function() {
            this.triggerEvent("cancel");
        },
        show: function() {
            this.setData({
                show: !0
            });
        },
        onGotoSupplyTap: function() {
            var t = this.data.supplyInfo;
            (0, i.n3)({
                url: i.ob.captain,
                params: e({}, i.gf.userNo, t.supplyUserNo)
            }), this.cancel();
        },
        onChooseChange: function(e) {
            var t = (0, i.jo)(e);
            this.triggerEvent("choose", t), this.cancel();
        }
    }
});