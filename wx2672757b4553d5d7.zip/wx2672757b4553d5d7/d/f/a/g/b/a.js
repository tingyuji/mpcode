var t = require("../../../../../_/helpers/objectSpread2");

require("../../../../../_/helpers/Objectvalues");

var e = require("../../../../../$page");

(0, e.afb)({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(t) {
                (null == t ? void 0 : t.parentOrderSn) && this.updateSubOrderList();
            }
        },
        tracking: {
            type: Object,
            value: {}
        },
        ignoreEmoji: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        suborderCancelStatus: e._t,
        DISPLAY_TYPE: e.u9,
        ORDER_STATUS: e.yz,
        SHIPPING_STATUS: e._j,
        isFold: !0,
        subOrderList: []
    },
    methods: {
        handleTapWrap: function() {
            this.triggerEvent("onTapWrap");
        },
        handleTapFold: function() {
            var t = this.data, e = t.isFold, i = t.tracking, a = void 0 === i ? {} : i;
            a && a.foldAmountBtn && this.$click({
                page_el_sn: a.foldAmountBtn
            }), this.setData({
                isFold: !e
            });
        },
        updateSubOrderList: function() {
            var i = this, a = this.data.item, r = a.hasGift, o = a.giftOrderMap, s = void 0 === o ? {} : o, n = a.subOrderList, d = void 0 === n ? [] : n, u = r ? Object.values(s).map(function(e) {
                return t(t({}, e), {}, {
                    isGift: !0
                });
            }) : [];
            this.setData({
                subOrderList: d.concat(u).map(function(a) {
                    return t(t({}, a), {}, {
                        goodsName: (0, e.agi)(a.goodsName, i.data.ignoreEmoji),
                        goodsSpecification: (0, e.agi)(a.goodsSpecification, i.data.ignoreEmoji)
                    });
                })
            });
        }
    }
});