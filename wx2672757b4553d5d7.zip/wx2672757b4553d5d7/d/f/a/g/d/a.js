var e = require("../../../../../_/helpers/interopRequireDefault"), t = e(require("../../../../../_/regenerator")), a = require("../../../../../_/helpers/objectSpread2"), i = require("../../../../../_/helpers/asyncToGenerator"), r = require("../../../../../$app"), n = require("../../../../../$page"), s = e(require("@pdd/std-format")), o = {
    ktt_complex_order_list: 10001,
    ktt_order_manage: 10002,
    ktt_order_manger_search: 10003,
    order_details_page: 10004,
    ktt_member_order_list: 10005,
    ktt_order_scan_confirm: 10006,
    ktt_after_sales_list: 10007,
    ktt_all_order_manage: 10008,
    ktt_un_appointment_order_list: 10009
};

(0, n.afb)({
    options: {
        multipleSlots: !0
    },
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function() {
                this.updateShippingPromise(), this.updatePrivateBtn();
            }
        },
        showLogisticInfo: {
            type: Boolean,
            value: !1
        },
        canCallPhone: {
            type: Boolean,
            value: !1
        },
        canCopyAddress: {
            type: Boolean,
            value: !1
        },
        canEditAddressInfo: {
            type: Boolean,
            value: !1
        },
        showMentionDetail: {
            type: Boolean,
            value: !1
        },
        canCallMentionPhone: {
            type: Boolean,
            value: !1
        },
        canEditMentionAddress: {
            type: Boolean,
            value: !1
        },
        canEditRemark: {
            type: Boolean,
            value: !1
        },
        canCopyRemark: {
            type: Boolean,
            value: !1
        },
        showSecretRemark: {
            type: Boolean,
            value: !1
        },
        showPurchaseCancelRemark: {
            type: Boolean,
            value: !1
        },
        customHeader: {
            type: Boolean,
            value: !1
        },
        trackingData: {
            type: Object,
            value: {}
        }
    },
    data: {
        CUSTOM_TYPE: r.t,
        isPromiseTimeout: !1,
        showPrivateBtn: !1
    },
    realLoading: !1,
    methods: {
        closePromise: function() {
            this.setData({
                isPromiseTimeout: !0
            });
        },
        updateShippingPromise: function() {
            var e = this.data.item;
            if (!e.shippingStatus && e.isLogistics) {
                var t = ((0, r.qh)(e, "servicePromise.promiseTagList") || []).find(function(e) {
                    return e.key === n.zh.DELIVERY_TIME;
                });
                if (t) {
                    var a = t.deadLine < Date.now(), i = t.deadLine > Date.now() + 2592e5 ? "承诺在".concat(s.default.formatTime(t.deadLine, "YYYY/MM/dd hh:mm"), "前发货") : "";
                    this.setData({
                        hasShippingPromise: !0,
                        isPromiseTimeout: a,
                        shippingPromise: t,
                        promiseDeadLine: i
                    });
                } else this.setData({
                    hasShippingPromise: !1
                });
            }
        },
        handleUpdateLogistics: (0, r.r2)(function(e) {
            var t = (0, r.jo)(e).logisticsIndex, a = this.data.trackingData;
            a.updateExpressBtn && this.$click({
                page_el_sn: a.updateExpressBtn
            }), this.triggerEvent("updateLogistics", {
                logisticsIndex: t
            });
        }),
        handleAddLogistics: (0, r.r2)(function() {
            var e = this.data.trackingData;
            e.addExpressBtn && this.$click({
                page_el_sn: e.addExpressBtn
            }), this.triggerEvent("updateLogistics", {});
        }),
        clickExpressEntry: function() {
            this.triggerEvent("viewExpress");
        },
        call: function(e) {
            var t = e.target.dataset.phone;
            t && wx.makePhoneCall({
                phoneNumber: t
            });
        },
        previewCustomPicture: function(e) {
            var t = (0, r.jo)(e).attachmentList, a = void 0 === t ? [] : t;
            a.length > 0 && wx.previewImage({
                current: a[0],
                urls: a
            });
        },
        toggleRealReceiveInfo: function() {
            var e = this;
            return i(t.default.mark(function i() {
                var s, l, d, c, u, p, v, m, h, g, f, _, k, y, E, R, D;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (l = e.data.item, d = l.parentOrderSn, c = l.isRealReceiveInfo, d && !e.realLoading) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return");

                      case 3:
                        if (!c) {
                            t.next = 6;
                            break;
                        }
                        return e.triggerEvent("toggleRealReceiveInfo", {
                            isRealReceiveInfo: !1,
                            privateInfo: e.data.item.privateInfo
                        }), t.abrupt("return", !0);

                      case 6:
                        return e.realLoading = !0, u = (0, r.ge)(), t.next = 10, (0, r.fy)(a(a({}, n.al3), {}, {
                            data: {
                                parentOrderSn: d,
                                bizCode: 1,
                                sceneCode: o[null === (s = null == u ? void 0 : u.pageProperties) || void 0 === s ? void 0 : s.page_name] || null
                            }
                        })).catch(function() {});

                      case 10:
                        if (p = t.sent, e.realLoading = !1, null == p ? void 0 : p.result) {
                            t.next = 14;
                            break;
                        }
                        return t.abrupt("return");

                      case 14:
                        return v = p.result, m = v.isCustom, h = v.receiverName, g = void 0 === h ? "" : h, 
                        f = v.receiverMobile, _ = void 0 === f ? "" : f, k = v.receiverAddressDetail, y = void 0 === k ? "" : k, 
                        E = v.receiverAddress, R = void 0 === E ? "" : E, D = m ? {
                            customList: (e.data.item.customList || []).map(function(e) {
                                var t = e.value;
                                return e.type === r.t.PHONE ? t = _ : e.type === r.t.ADDRESS ? t = R : e.type === r.t.USER_NAME && (t = g), 
                                a(a({}, e), {}, {
                                    value: t
                                });
                            })
                        } : {
                            receiverName: g,
                            receiverMobile: _,
                            receiverAddressDetail: y,
                            receiveAddress: R
                        }, e.triggerEvent("toggleRealReceiveInfo", {
                            isRealReceiveInfo: !0,
                            realInfo: D,
                            privateInfo: {
                                customList: e.data.item.customList,
                                receiverName: e.data.item.receiverName,
                                receiverMobile: e.data.item.receiverMobile,
                                receiverAddressDetail: e.data.item.receiverAddressDetail,
                                receiveAddress: e.data.item.receiveAddress
                            }
                        }), t.abrupt("return", !0);

                      case 18:
                      case "end":
                        return t.stop();
                    }
                }, i);
            }))();
        },
        handleCopyAddressInfo: function() {
            var e = this.data, t = e.item, a = e.trackingData;
            (null == a ? void 0 : a.copyAddressInfoBtn) && this.$click({
                page_el_sn: a.copyAddressInfoBtn
            }), wx.setClipboardData({
                data: (0, n.ah4)(t)
            });
        },
        handleCopyPurchaseCancelRemark: function() {
            var e = this, t = this.data.item;
            (null == t ? void 0 : t.purchaseCancelRemark) && wx.setClipboardData({
                data: t.purchaseCancelRemark,
                success: function() {
                    e.$showToast({
                        title: "已复制到剪贴板"
                    });
                }
            });
        },
        toggleEditAddressDialog: function() {
            var e = this;
            return i(t.default.mark(function a() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.t0 = !e.data.item.isRealReceiveInfo, !t.t0) {
                            t.next = 5;
                            break;
                        }
                        return t.next = 4, e.toggleRealReceiveInfo();

                      case 4:
                        t.t0 = !t.sent;

                      case 5:
                        if (!t.t0) {
                            t.next = 7;
                            break;
                        }
                        return t.abrupt("return");

                      case 7:
                        e.triggerEvent("onToggleEditAddressDialog");

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        previewMentionCover: function(e) {
            var t = (0, r.jo)(e), a = t.urlIndex, i = void 0 === a ? 0 : a, n = t.urlList, s = void 0 === n ? [] : n;
            wx.previewImage({
                current: s[i],
                urls: s
            });
        },
        handleModifySite: function() {
            this.triggerEvent("onModifySite");
        },
        handleCopyCustomerRemark: function() {
            var e = this, t = this.data, a = t.item, i = t.trackingData;
            (null == i ? void 0 : i.copyCustomerRemarkBtn) && this.$click({
                page_el_sn: i.copyCustomerRemarkBtn
            }), (null == a ? void 0 : a.buyerMemo) && wx.setClipboardData({
                data: a && a.buyerMemo,
                success: function() {
                    e.$showToast({
                        title: "团员备注已复制到剪贴板"
                    });
                }
            });
        },
        showRemarkDialog: function(e) {
            var t = (0, r.jo)(e).isPrivate;
            this.data.canEditRemark && this.triggerEvent("showRemarkDialog", {
                isPrivate: t
            });
        },
        showIllegality: function() {
            this.setData({
                showIllegalityExplain: !0
            });
        },
        hideIllegality: function() {
            this.setData({
                showIllegalityExplain: !1
            });
        },
        doNothing: function() {},
        updatePrivateBtn: function() {
            var e = this.data.item, t = e.receiverName, a = e.receiverMobile, i = e.receiveAddress, n = e.customList, s = !!(t || a || i || (void 0 === n ? [] : n).find(function(e) {
                return [ r.t.USER_NAME, r.t.PHONE, r.t.ADDRESS ].indexOf(e.type) > -1;
            }));
            s !== this.data.showPrivateBtn && this.setData({
                showPrivateBtn: s
            });
        }
    }
});