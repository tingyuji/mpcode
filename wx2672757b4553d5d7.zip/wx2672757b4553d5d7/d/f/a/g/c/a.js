var t = require("../../../../../$page"), a = require("../../../../../$app");

(0, t.afb)({
    behaviors: [ t.ab4 ],
    properties: {
        item: {
            value: {},
            type: Object,
            observer: function(t) {
                (null == t ? void 0 : t.parentOrderSn) && (this.updateChatBtn(), this.updateDisplayInfo());
            }
        },
        showActivity: {
            value: !1,
            type: Boolean
        },
        ignoreEmoji: {
            type: Boolean,
            value: !1
        },
        index: {
            type: Number,
            value: 0
        }
    },
    data: {
        SUB_ACTIVITY_TYPE: a.cp,
        DISPLAY_TYPE: t.u9,
        helpSellName: "",
        showChatBtn: !1,
        displayActivityTitle: "",
        displayNickName: ""
    },
    methods: {
        handleTapWrap: function() {
            this.triggerEvent("onTapWrap");
        },
        handleToChat: function() {
            this.handleOrderToChat();
        },
        handleToActivity: function() {
            var a = this.data.item, e = a.activityNo, i = a.ownerUserNo, n = a.displayType;
            n !== t.u9.wheel && (0, t.ag3)(e, {
                ownerUserNo: i,
                displayType: n
            });
        },
        updateDisplayInfo: function() {
            var a = this.data.item || {}, e = a.activityTitle, i = a.nickName, n = (0, t.ah8)({
                item: this.data.item
            });
            this.setData({
                displayActivityTitle: (0, t.agi)(e, this.data.ignoreEmoji),
                displayNickName: (0, t.agi)(i),
                helpSellName: (0, t.agi)(n)
            });
        },
        updateChatBtn: function() {
            var a = this.data.item;
            this.setData({
                showChatBtn: (0, t.abs)(a)
            });
        }
    }
});