var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), t = require("../../../../_/helpers/objectSpread2"), i = require("../../../../_/helpers/asyncToGenerator"), s = require("../../../../$app"), r = require("../../../../$page"), a = "选择省份";

(0, r.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        item: {
            type: Object,
            value: {}
        }
    },
    data: {
        editAddressWindowVisible: !1,
        regionsSelectVisible: !1,
        becomeFocus: !1,
        addressSelectVisible: !1,
        alreadyChooseDistrict: !1,
        disabled: !1,
        nearbyPOIs: [],
        showLocationAuth: !1,
        isNameError: !1,
        isMobileError: !1,
        isAddressDetailError: !1,
        curAddress: {},
        provinces: [],
        cities: [],
        districts: [],
        CUSTOM_TYPE: s.t,
        districtAddress: {},
        isCustomList: !1,
        customList: []
    },
    addAddressLock: !1,
    regionsDatas: null,
    inputData: {},
    curAddress: {},
    hideDistrictLock: !1,
    hasLocationAuth: !1,
    imprTime: 0,
    lifetimes: {
        attached: function() {
            this.addAddressLock = !1, this.regionsDatas = null, this.inputData = {};
        },
        ready: function() {
            var e = this, t = this.data.item;
            this.curAddress = this.formatAddress(t), this.setData({
                isCustomList: !(!t.customList || !t.customList.length),
                customList: t.customList
            }, function() {
                t.isReceiver && e.show();
            });
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        changeCustomValue: function(e) {
            if (e.detail.value && e.detail.value.length >= 100) {
                var t = (0, s.jo)(e, "name");
                (0, s.ri)({
                    title: "".concat(t, "内容最多填写100字"),
                    icon: "none"
                });
            }
            var i = (0, s.jo)(e, "index"), r = this.data.customList;
            r && r[i] && (r[i].value = e.detail.value), this.setData({
                customList: r
            });
        },
        preventTouchMove: function() {},
        formatAddress: function(e) {
            return e.receiverAddressCityId && e.receiverAddressDistrictId && e.receiverAddressProvinceId ? {
                address: e.receiverAddressDetail,
                city: e.receiverAddressCity,
                cityId: e.receiverAddressCityId,
                district: e.receiverAddressDistrict,
                districtId: e.receiverAddressDistrictId,
                mobile: e.receiverMobile,
                name: e.receiverName,
                province: e.receiverAddressProvince,
                provinceId: e.receiverAddressProvinceId
            } : null;
        },
        show: function() {
            var a = this;
            return i(e.default.mark(function i() {
                var n, d, c;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (a.$showLoading(), a.regionsDatas) {
                            e.next = 13;
                            break;
                        }
                        return e.next = 4, r.ae9.getRegionsData().catch(function(e) {
                            a.$error({
                                e: e,
                                msg: "AddressesControl getRegionsData fail"
                            });
                        });

                      case 4:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 7;
                            break;
                        }
                        e.t0 = {};

                      case 7:
                        if ((n = e.t0).error_msg && (0, s.ri)({
                            title: n.error_msg,
                            icon: "none"
                        }), a.regionsDatas = r.ae9.getRegions(), a.regionsDatas) {
                            e.next = 13;
                            break;
                        }
                        return (0, s.ri)({
                            title: "获取地址失败，请稍后重试",
                            icon: "none"
                        }), e.abrupt("return");

                      case 13:
                        return d = {
                            isNameError: !1,
                            isMobileError: !1,
                            isAddressDetailError: !1,
                            disabled: !0,
                            districtAddress: {},
                            alreadyChooseDistrict: !1,
                            becomeFocus: !1
                        }, a.hideDistrictLock = !1, a.setData(t(t({}, d), {}, {
                            curAddress: a.curAddress,
                            alreadyChooseDistrict: !0
                        })), a.inputData = t(t({}, a.curAddress), {}, {
                            alreadyChooseDistrict: !0
                        }), e.next = 19, (0, s.i_)("scope.userLocation").then(function() {
                            return !0;
                        }).catch(function(e) {
                            return a.$error({
                                e: e,
                                msg: "getAuth scope.userLocation fail"
                            }), !1;
                        });

                      case 19:
                        c = e.sent, a.hasLocationAuth = c, a.locateUser(function() {
                            a.showEditModule();
                        });

                      case 22:
                      case "end":
                        return e.stop();
                    }
                }, i);
            }))();
        },
        showEditModule: function() {
            var e = {};
            this.curAddress && (e = this.updateRegionsPicker("111", {
                saveIndex: !0
            }));
            var i = this.setDisableIfNeed(), r = this.setDistrictAddress(), a = t(t(t(t({}, e), i), r), {}, {
                editAddressWindowVisible: !0
            });
            this.setData(a), this.addAddressLock = !1, this.imprTime = Date.now();
            this.curAddress && this.curAddress.addressId, this.checkAddressText(), (0, s.l3)();
        },
        showRegionsPicker: function() {
            var e = this;
            if (!this.data.regionsSelectVisible) {
                var i = this.updateRegionsPicker("111"), s = this.setDisableIfNeed(), r = i.updateAddrIndex;
                if (this.setData(t(t({
                    regionsSelectVisible: !0,
                    becomeFocus: !1,
                    addressSelectVisible: !1
                }, i), s)), r) {
                    var a = this.data.curAddress;
                    setTimeout(function() {
                        e.setData({
                            curAddress: t(t({}, a), r)
                        });
                    }, 300);
                }
                this.hideDistrictLock = !1;
            }
        },
        locateUser: function(t) {
            var a = this;
            if (this.hasLocationAuth) {
                var n, d = this.data.nearbyPOIs;
                d && d.length > 0 ? this.setNearbyPOIs(t, d) : s.f3.getLocation({
                    complete: (n = i(e.default.mark(function i(s) {
                        var n, d, c, o, u;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (e.prev = 0, d = (n = s || {}).latitude, c = n.longitude, !d || !c) {
                                    e.next = 17;
                                    break;
                                }
                                return o = {
                                    lat: d,
                                    lng: c,
                                    coord_type: 1
                                }, e.prev = 4, e.next = 7, (0, r.ahz)(o);

                              case 7:
                                u = e.sent, a.processNearbyPOIs(t, u), e.next = 15;
                                break;

                              case 11:
                                throw e.prev = 11, e.t0 = e.catch(4), a.$error({
                                    e: e.t0,
                                    msg: "locateUser nearby poi fail"
                                }), e.t0;

                              case 15:
                                e.next = 18;
                                break;

                              case 17:
                                t && "function" == typeof t && t();

                              case 18:
                                e.next = 24;
                                break;

                              case 20:
                                e.prev = 20, e.t1 = e.catch(0), a.$error({
                                    e: e.t1,
                                    msg: "locateUser decoder fail"
                                }), t && "function" == typeof t && t();

                              case 24:
                              case "end":
                                return e.stop();
                            }
                        }, i, null, [ [ 0, 20 ], [ 4, 11 ] ]);
                    })), function(e) {
                        return n.apply(this, arguments);
                    })
                });
            } else t && "function" == typeof t && t();
        },
        processNearbyPOIs: function(e, t) {
            if (!t || t.length <= 0) e && "function" == typeof e && e(); else {
                for (var i = [], s = 0; s < t.length; s++) {
                    var r = t[s];
                    r.thumb_address && r.address ? i.push(r) : r.thumb_address && !r.address ? (r.address = r.thumb_address, 
                    i.push(r)) : !r.thumb_address && r.address && (r.thumb_address = r.address, i.push(r));
                }
                this.setNearbyPOIs(e, i);
            }
        },
        setNearbyPOIs: function(e, t) {
            var i = {
                nearbyPOIs: t
            };
            this.setData(i), e && "function" == typeof e && e();
        },
        handleCloseLocation: function() {
            this.setData(this.hideAddressPicker());
        },
        didChoosePOI: function(e) {
            if (e && e.currentTarget && e.currentTarget.dataset) {
                var i = e.currentTarget.dataset.index, r = this.data.nearbyPOIs, a = r && r[i];
                if (a) {
                    var n = this.inputData, d = n.provinceId, c = n.cityId, o = n.districtId;
                    Number(a.province_id) === Number(d) && Number(a.city_id) === Number(c) && Number(a.district_id) === Number(o) || (0, 
                    s.ri)({
                        title: "省市区信息已同步修改",
                        icon: "none"
                    });
                    var u = {
                        provinceId: a.province_id,
                        cityId: a.city_id,
                        districtId: a.district_id,
                        address: a.thumb_address,
                        province: a.province,
                        city: a.city,
                        district: a.district
                    };
                    Object.assign(this.inputData, t(t({}, u), {}, {
                        alreadyChooseDistrict: !0
                    }));
                    var h = this.updateRegionsPicker("111", {
                        saveIndex: !0
                    }), l = this.setDisableIfNeed(), v = this.hideAddressPicker();
                    this.setData(t(t(t({}, h), l), v));
                }
            }
        },
        didClickLocationBtn: function() {
            this.hasLocationAuth ? this.processLocations() : this.setData({
                showLocationAuth: !0
            });
        },
        processLocations: function() {
            var e = this.data.nearbyPOIs;
            if (e && !(e.length <= 0)) {
                var i = this.hideRegionsPicker();
                this.setData(t(t({}, i), {}, {
                    addressSelectVisible: !0,
                    becomeFocus: !1
                }));
            }
        },
        updateRegionsPicker: function(e) {
            var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = "111" === e, r = e ? e.split("") : [ 1, 1, 1 ], n = this.data, d = n.provinces, c = n.cities, o = n.districts, u = this.data.curAddress, h = this.inputData, l = h.alreadyChooseDistrict, v = h.provinceId, f = h.cityId, D = h.districtId, I = h.name, p = h.mobile, g = h.address, m = u.provinceIndex, b = u.cityIndex, A = u.districtIndex, y = i.setProvinceIndex, x = i.setCityIndex, k = i.setDistrictIndex, N = i.saveIndex;
            isNaN(y) || (m = y), isNaN(x) || (b = x), isNaN(k) || (A = k);
            var C = {};
            if ("1" === String(r[0]) && (d.length <= 0 && (d = [ {
                regionName: a
            } ].concat(this.formatRegions(this.regionsDatas))), v && s && (m = this.regionIdInRegionsIndex(v, d)), 
            C.provinces = d), "1" === String(r[1])) {
                if (c = [ {
                    regionName: "选择城市"
                } ], this.regionsDatas.length >= m && m >= 1) {
                    var P = this.regionsDatas[m - 1].children;
                    c = c.concat(this.formatRegions(P || []));
                }
                f && s && (b = this.regionIdInRegionsIndex(f, c)), C.cities = c;
            }
            if ("1" === String(r[2])) {
                if (o = [ {
                    regionName: "选择地区"
                } ], this.regionsDatas.length >= m && m >= 1 && b >= 1) {
                    var L = (this.regionsDatas[m - 1].children[b - 1] || {}).children;
                    o = o.concat(this.formatRegions(L || []));
                }
                D && s && (A = this.regionIdInRegionsIndex(D, o)), C.districts = o;
            }
            var V = {
                provinceIndex: m,
                cityIndex: b,
                districtIndex: A
            };
            Object.assign(C, {
                curAddress: t(t(t({}, u), V), {}, {
                    name: I,
                    mobile: p,
                    address: g
                })
            }), this.setData(C);
            var O = {
                provinceId: (d[m] || {}).regionId,
                cityId: (c[b] || {}).regionId,
                districtId: (o[A] || {}).regionId
            };
            N && Object.assign(O, {
                lastValidProviceIndex: m,
                lastValidCityIndex: b,
                lastValidDistrictIndex: A,
                lastValidProvinceId: O.provinceId,
                lastValidCityId: O.cityId,
                lastValidDistrictId: O.districtId
            }), Object.assign(this.inputData, O);
            var R = {}, w = this.setDistrictAddress();
            return Object.assign(R, t({
                alreadyChooseDistrict: l,
                updateAddrIndex: V
            }, w)), R;
        },
        clearLocation: function() {
            Object.assign(this.inputData, {
                address: ""
            });
            var e = this.inputData, i = e.name, s = e.mobile, r = e.address, a = this.setDisableIfNeed(), n = this.data.curAddress;
            this.setData(t(t({}, a), {}, {
                curAddress: t(t({}, n), {}, {
                    address: r,
                    name: i,
                    mobile: s
                }),
                showClearBtn: !1,
                becomeFocus: !0
            }));
        },
        setDistrictAddress: function() {
            var e = {}, t = this.data, i = t.provinces, s = t.cities, r = t.districts, a = t.curAddress, n = a.provinceIndex, d = a.cityIndex, c = a.districtIndex;
            if (n > 0 && d > 0 && c > 0) {
                var o = i[n].regionName, u = s[d].regionName, h = r[c].regionName;
                Object.assign(e, {
                    districtAddress: {
                        provinceName: o,
                        cityName: u,
                        districtName: h,
                        hasSelectedDistrict: !0
                    }
                });
            } else Object.assign(e, {
                districtAddress: {
                    hasSelectedDistrict: !1,
                    selectTitle: "请选择所在位置"
                }
            });
            return e;
        },
        cancelRegionsPicker: function() {
            var e = this.setBackAddressInfo();
            this.setData(t({
                regionsSelectVisible: !1
            }, e));
        },
        setBackAddressInfo: function() {
            var e = this.inputData, i = e.lastValidProviceIndex, s = e.lastValidCityIndex, r = e.lastValidDistrictIndex, a = e.lastValidProvinceId, n = e.lastValidCityId, d = e.lastValidDistrictId, c = this.data.curAddress, o = {
                curAddress: t(t({}, c), {}, {
                    provinceIndex: i,
                    cityIndex: s,
                    districtIndex: r
                })
            };
            return Object.assign(this.inputData, {
                provinceId: a,
                cityId: n,
                districtId: d
            }), o;
        },
        confirmRegionsPicker: function() {
            if (this.verfiyAddress(!0)) {
                var e = this.hideAllPicker(), i = this.setDisableIfNeed(), s = e.districtAddress || {}, r = s.provinceName, a = s.cityName, n = s.districtName;
                s.hasSelectedDistrict && (this.inputData = t(t({}, this.inputData), {}, {
                    province: r || this.inputData.province,
                    city: a || this.inputData.city,
                    district: n || this.inputData.district
                })), this.setData(t(t({}, e), i));
            }
        },
        formatRegions: function(e) {
            var t = [];
            return e.forEach(function(e) {
                t.push({
                    regionId: e.id,
                    regionName: e.region_name
                });
            }), t;
        },
        closeLocationAuth: function() {
            this.hideLocationAuth();
        },
        openLocationAuth: function() {
            var e = this;
            wx.openSetting({
                success: function(t) {
                    t && t.authSetting && t.authSetting["scope.userLocation"] && (e.hasLocationAuth = !0, 
                    e.locateUser(function() {
                        e.processLocations();
                    }));
                }
            }), setTimeout(function() {
                e.hideLocationAuth();
            }, 100);
        },
        hideLocationAuth: function() {
            this.setData({
                showLocationAuth: !1
            });
        },
        removeEditModuleError: function(e) {
            var i = e.currentTarget.id, s = this.hideAllPicker(), r = this.data.isNameError, a = t({}, s);
            switch (i) {
              case "name":
                r && Object.assign(a, {
                    isNameError: !1
                });
                break;

              case "mobile":
                Object.assign(a, {
                    isMobileError: !1
                });
                break;

              case "addressDetail":
                Object.assign(a, {
                    isAddressDetailError: !1
                });
            }
            this.setData(a);
        },
        regionIdInRegionsIndex: function(e, t) {
            if (null == t) return -1;
            for (var i = 0; i < t.length; ++i) {
                var s = t[i];
                if (parseInt(s.regionId, 10) === parseInt(e, 10)) return i;
            }
            return -1;
        },
        bindNameChange: function(e) {
            var t = e.detail.value;
            this.inputData.name = t, this.setDisableIfNeed(!0);
        },
        bindMobileChange: function(e) {
            var t = e.detail.value;
            this.inputData.mobile = t, this.setDisableIfNeed(!0);
        },
        bindAddressChange: function(e) {
            var t = e.detail.value, i = !!t;
            this.inputData.address = t, this.setData({
                showClearBtn: i
            }), this.setDisableIfNeed(!0), this.checkAddressDetail(e);
        },
        setDisableIfNeed: function(e) {
            var t = this.inputData, i = t.name, s = t.mobile, r = t.address, a = t.alreadyChooseDistrict, n = !(i && s && r && a);
            return e && this.setData({
                disabled: n
            }), {
                disabled: n
            };
        },
        bindAddressBlurCheck: function(e) {
            this.checkAddressDetail(e);
        },
        checkAddressDetail: function(e) {
            var t = e.detail.value;
            return t && t.length > 100 ? (this.setData({
                isAddressDetailError: !0
            }), !1) : (this.setData({
                isAddressDetailError: !1
            }), !0);
        },
        bindChange: function(e) {
            if (!this.hideDistrictLock) {
                var t = e.detail.value || [], i = Number(t[0]), s = Number(t[1]), r = Number(t[2]), a = this.data.curAddress, n = a.provinceIndex, d = a.cityIndex, c = a.districtIndex;
                i !== n ? this.updateRegionsPicker("011", {
                    setProvinceIndex: i,
                    setCityIndex: 0,
                    setDistrictIndex: 0
                }) : s !== d ? this.updateRegionsPicker("001", {
                    setProvinceIndex: i,
                    setCityIndex: s,
                    setDistrictIndex: 0
                }) : r !== c && this.updateRegionsPicker("000", {
                    setProvinceIndex: i,
                    setCityIndex: s,
                    setDistrictIndex: r
                });
            }
        },
        saveEditModuleAddress: function() {
            var e = this;
            if (!this.addAddressLock) {
                var i = this.inputData, r = i.name, a = i.mobile, n = i.address, d = i.provinceId, c = i.cityId, o = i.districtId, u = i.province, h = i.city, l = i.district, v = this.data, f = v.isCustomList, D = v.item, I = D.activityNo, p = D.customList, g = D.parentOrderSn;
                if (!D.isReceiver || this.verifyAddressInfoValid()) {
                    this.setData({
                        becomeFocus: !1
                    });
                    var m = {
                        receiverName: r,
                        receiverMobile: a,
                        receiverAddressDetail: n,
                        receiverAddressProvinceId: d,
                        receiverAddressProvince: u,
                        receiverAddressCityId: c,
                        receiverAddressCity: h,
                        receiverAddressDistrictId: o,
                        receiverAddressDistrict: l,
                        activityNo: I,
                        customList: (p || []).filter(function(e) {
                            return e.type !== s.t.PICTURE;
                        }),
                        selfDefinedAddress: f,
                        parentOrderSn: g
                    };
                    (0, s.fy)(t(t({}, s.nq), {}, {
                        data: m
                    })).then(function() {
                        (0, s.ri)({
                            title: "收货信息修改成功",
                            icon: "none"
                        }), setTimeout(function() {
                            e.triggerEvent("editSuccess"), e.addAddressLock = !0, e.close();
                        }, 500);
                    }).catch(function(t) {
                        (0, s.ri)({
                            title: t.errorMsg || "修改失败，请稍后重试",
                            icon: "none"
                        }), e.$error({
                            e: t,
                            msg: "submit fail"
                        });
                    });
                }
            }
        },
        hideAllPicker: function(e) {
            var i = this.hideRegionsPicker(), s = this.hideAddressPicker(), r = t(t({}, i), s);
            return e && this.setData(r), r;
        },
        hideRegionsPicker: function() {
            this.hideDistrictLock = !0;
            var e = this.data, t = e.curAddress;
            if (e.regionsSelectVisible) {
                var i = t.provinceIndex, s = t.cityIndex, r = t.districtIndex, a = this.inputData, n = a.provinceId, d = a.cityId, c = a.districtId, o = {
                    regionsSelectVisible: !1
                };
                if (i > 0 && s > 0 && r > 0) {
                    Object.assign(this.inputData, {
                        lastValidProviceIndex: i,
                        lastValidCityIndex: s,
                        lastValidDistrictIndex: r,
                        lastValidProvinceId: n,
                        lastValidCityId: d,
                        lastValidDistrictId: c,
                        alreadyChooseDistrict: !0
                    });
                    var u = this.setDistrictAddress();
                    Object.assign(o, {
                        alreadyChooseDistrict: !0
                    }, u);
                } else {
                    var h = this.setBackAddressInfo();
                    Object.assign(o, h);
                }
                return o;
            }
            return {};
        },
        hideAddressPicker: function() {
            return {
                addressSelectVisible: !1
            };
        },
        verifyAddressInfoValid: function() {
            return this.verifyName() && this.verifyMobile() && this.verfiyAddress(!1);
        },
        verifyName: function() {
            var e = this.inputData.name;
            return !e || e.length <= 0 ? ((0, s.ri)({
                title: "收货人的名字不能为空",
                icon: "none"
            }), !1) : !(e && e.length > 20) || ((0, s.ri)({
                title: "名字不能超过20个字",
                icon: "none"
            }), this.setData({
                isNameError: !0
            }), !1);
        },
        verifyMobile: function() {
            var e = this.inputData.mobile;
            return !e || e.length <= 0 ? ((0, s.ri)({
                title: "收货人的电话不能为空",
                icon: "none"
            }), !1) : !!/1\d{10}/.test(e) || ((0, s.ri)({
                title: "请输入正确的手机号",
                icon: "none"
            }), this.setData({
                isMobileError: !0
            }), !1);
        },
        verfiyAddress: function(e) {
            var t = this.inputData, i = t.provinceId, r = t.cityId, a = t.districtId, n = t.address;
            if (!i) return (0, s.ri)({
                title: "请先选择省份",
                icon: "none"
            }), !1;
            if (!r) return (0, s.ri)({
                title: "请先选择城市",
                icon: "none"
            }), !1;
            if (!a) return (0, s.ri)({
                title: "请选择地区",
                icon: "none"
            }), !1;
            if (!e) {
                if (n.length <= 0) return (0, s.ri)({
                    title: "详细地址不能为空",
                    icon: "none"
                }), !1;
                if (n.match(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g)) return (0, s.ri)({
                    title: "详细地址中不能包含表情符",
                    icon: "none"
                }), !1;
                if (n && n.length > 100) return (0, s.ri)({
                    title: "地址填写过长",
                    icon: "none"
                }), this.setData({
                    isAddressDetailError: !0
                }), !1;
                if (/^[0-9]*$/.test(n)) return (0, s.ri)({
                    title: "详细地址不能全为数字",
                    icon: "none"
                }), this.setData({
                    isAddressDetailError: !0
                }), !1;
            }
            return !0;
        },
        updateCurAddress: function(e) {
            var i = this.data.curAddress;
            i && i.addressId && (e.addressId = i.addressId), this.setData({
                curAddress: e,
                alreadyChooseDistrict: !0
            }), this.inputData = t(t({}, e), {}, {
                alreadyChooseDistrict: !0
            });
            var s = {};
            e && (s = this.updateRegionsPicker("111", {
                saveIndex: !0
            }));
            var r = this.setDisableIfNeed(!0), a = this.setDistrictAddress(), n = t(t(t(t({}, s), r), a), {}, {
                editAddressWindowVisible: !0
            });
            this.setData(n);
        },
        checkAddressText: function() {
            var t, s = this;
            wx.getClipboardData({
                success: (t = i(e.default.mark(function t(i) {
                    var a, n, d, c;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (s.$infoByBatch({
                                msg: "autoCheckAddressText",
                                data: i
                            }), !(a = i.data)) {
                                e.next = 20;
                                break;
                            }
                            return n = a, e.prev = 4, e.next = 7, r.ae9.analyzeAddress(n);

                          case 7:
                            if (!(d = e.sent) || !d.province) {
                                e.next = 15;
                                break;
                            }
                            return d.addressDetail = (d.province || "") + (d.city || "") + (d.district || "") + (d.address || ""), 
                            c = d, e.next = 13, s.$showModal({
                                isInPage: !0,
                                title: "是否使用剪切板中的地址",
                                cancelText: "取消",
                                confirmText: "确定",
                                content: "".concat(d.name, " ").concat(d.mobile, " ").concat(d.addressDetail)
                            });

                          case 13:
                            e.sent.confirm && s.updateCurAddress(c);

                          case 15:
                            e.next = 20;
                            break;

                          case 17:
                            e.prev = 17, e.t0 = e.catch(4), s.$error({
                                msg: "analyzeAddress error",
                                e: e.t0
                            });

                          case 20:
                          case "end":
                            return e.stop();
                        }
                    }, t, null, [ [ 4, 17 ] ]);
                })), function(e) {
                    return t.apply(this, arguments);
                })
            });
        }
    },
    move: function() {}
});