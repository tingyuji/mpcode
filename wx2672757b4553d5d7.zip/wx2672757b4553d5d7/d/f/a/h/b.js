var e = require("../../../../$app"), t = require("../../../../$page");

(0, t.afb)({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                e.parentOrderSn && this.update();
            }
        },
        operationControl: {
            type: Object,
            value: {},
            observer: function() {
                this.updateBtn();
            }
        },
        showCancelFirstLevel: {
            type: Boolean,
            value: !1
        },
        showDetail: {
            type: Boolean,
            value: !0
        },
        showAfterSalesDetailBtn: {
            type: Boolean,
            value: !1
        },
        trackingData: {
            type: Object,
            value: {}
        }
    },
    data: {
        orderDescText: "",
        moreOperationPanelVisible: !1,
        moreOperationList: [],
        copyOrderPanelVisible: !1
    },
    methods: {
        updateBtn: function() {
            var e = this.data, a = e.operationControl, r = e.showCancelFirstLevel, i = e.showDetail, n = e.orderDescText, s = {}, o = {};
            a.handleAfterSales ? s[t.tg.PROCESS_REFUND] = !0 : n && a.afterSalesDetail && (s[t.tg.REFUND_DETAIL] = !0), 
            a.showDriveRefund && (s[t.tg.REFUND] = !0), a.showCancel && (r ? s[t.tg.CANCEL_ORDER] = !0 : o[t.tg.CANCEL_ORDER] = !0), 
            a.showCopy && (s[t.tg.COPY_ORDER] = !0), i && (o[t.tg.ORDER_DETAIL] = !0), a.showOperationLog && (o[t.tg.OPERATION_LOG] = !0), 
            a.showSupplyPurchaseOrder && (s[t.tg.SUPPLY_ORDER] = !0);
            var c = (0, t.agk)(s), l = (0, t.agk)(o);
            c.length > 3 && (l = l.concat(c.splice(0, c.length - 3))), this.setData({
                btnList: c,
                moreOperationList: l
            });
        },
        updateOrderDesc: function() {
            var e = this.data.item, a = (0, t.ah5)(e);
            this.setData({
                orderDescText: a
            });
        },
        updatePromise: function() {
            var a = this.data.item;
            if (a.isLogistics) {
                var r = ((0, e.qh)(a, "servicePromise.promiseTagList") || []).find(function(e) {
                    return e.key === t.zh.AFTER_SALE_TIME;
                });
                r && t.zj[r.value] && this.setData({
                    promiseAfterSaleText: t.zj[r.value] + "售后"
                });
            }
        },
        update: function() {
            this.updateOrderDesc(), this.updatePromise();
        },
        handleTapOrderDesc: function() {
            this.data.operationControl.refundDescInteractive && (this.$click({
                page_el_sn: t.s5.AFTER_SALES_DETAIL
            }), this.triggerEvent("showAfterSalesDetail"));
        },
        copyOrder: function() {
            var e = this.data.trackingData;
            e.copyOrderInfoBtn && this.$click({
                page_el_sn: e.copyOrderInfoBtn
            }), this.showCopyOrderPanel();
        },
        showMoreOperationPanel: function() {
            var e = this.data.trackingData;
            e.moreOperationBtn && this.$click({
                page_el_sn: e.moreOperationBtn
            }), this.setData({
                moreOperationPanelVisible: !0
            });
        },
        hideMoreOperationPanel: function() {
            this.setData({
                moreOperationPanelVisible: !1
            });
        },
        handleSelectOperation: function() {
            var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = (0, 
            e.jo)(a), i = r.idx, n = this.data, s = n.trackingData, o = n.moreOperationList, c = o[i];
            switch (c.key) {
              case t.tg.CANCEL_ORDER:
                break;

              case t.tg.ORDER_DETAIL:
                s.orderDetailBtn && this.$click({
                    page_el_sn: s.orderDetailBtn
                });
                break;

              case t.tg.OPERATION_LOG:
            }
            this.doOperation(c.key || "");
        },
        processRefund: function() {
            this.$click({
                page_el_sn: t.s5.HANDLE_AFTER_SALES
            }), this.triggerEvent("processRefund");
        },
        doOperation: function(e) {
            switch (e) {
              case t.tg.COPY_ORDER:
                this.copyOrder();
                break;

              case t.tg.CANCEL_ORDER:
                this.cancel();
                break;

              case t.tg.REFUND:
                this.refund();
                break;

              case t.tg.PROCESS_REFUND:
                this.processRefund();
                break;

              case t.tg.REFUND_DETAIL:
                this.handleTapOrderDesc();
                break;

              case t.tg.SUPPLY_ORDER:
                this.forwardSupplyOrder();
                break;

              case t.tg.ORDER_DETAIL:
                this.toDetail();
                break;

              case t.tg.OPERATION_LOG:
                this.forwardOperationLog();
            }
        },
        handleBtnClick: function(t) {
            var a = (0, e.jo)(t).btn;
            if (a) {
                var r = a.key;
                this.doOperation(r);
            }
        },
        forwardSupplyOrder: function() {
            var t = this.data, a = t.item, r = t.trackingData;
            r.supplyPurchaseOrderBtn && this.$click({
                page_el_sn: r.supplyPurchaseOrderBtn
            }), (0, e.n3)({
                url: e.ob.supplyPurchaseOrder,
                params: {
                    parent_order_sn: a.parentOrderSn
                }
            });
        },
        refund: function() {
            (0, t.aby)(t.zm.cancelOrderRefund) && this.triggerEvent("refund");
        },
        cancel: function() {
            (0, t.aby)(t.zm.cancelOrderRefund) && this.triggerEvent("cancel");
        },
        toDetail: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.triggerEvent("toDetail", e);
        },
        emptyFunction: function() {},
        showCopyOrderPanel: function() {
            this.setData({
                copyOrderPanelVisible: !0
            });
        },
        hideCopyOrderPanel: function() {
            this.setData({
                copyOrderPanelVisible: !1
            });
        },
        forwardOperationLog: function() {
            var a = this.data.item;
            (0, e.n5)({
                pageName: t.aiw.kttOrderOperationLog,
                params: {
                    order_sn: a.parentOrderSn
                }
            });
        }
    }
});