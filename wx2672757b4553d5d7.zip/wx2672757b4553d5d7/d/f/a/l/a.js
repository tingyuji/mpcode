var e = require("../../../../_/helpers/toConsumableArray"), t = require("../../../../$app"), a = require("../../../../$page"), i = (0, 
t.ke)().navBarHeight, n = [ {
    name: "全部",
    type: a.yv.ALL
}, {
    name: "跟团号",
    type: a.yv.NO,
    onlyNumber: !0
}, {
    name: "手机号",
    type: a.yv.PHONE,
    onlyNumber: !0
}, {
    name: "微信名",
    type: a.yv.WECHAT_NAME
}, {
    name: "姓名",
    type: a.yv.NAME
}, {
    name: "商品",
    type: a.yv.GOODS
} ], s = /^[0-9]*$/;

(0, a.afb)({
    externalClasses: [ "search-class", "search-area-class" ],
    properties: {
        noBtn: {
            type: Boolean,
            value: !1
        },
        inputClass: {
            type: String,
            value: ""
        },
        searchValue: {
            type: String,
            value: "",
            observer: function(e) {
                this.setData({
                    inputValue: e
                });
            }
        },
        supportGoods: {
            type: Boolean,
            value: !0
        },
        placeholder: {
            type: String,
            value: "跟团号/手机号/微信名/姓名/商品"
        },
        placeholderStyle: {
            type: String,
            value: "color: #9C9C9C"
        }
    },
    data: {
        focus: !1,
        inputValue: "",
        showSuggestion: !1,
        navBarHeight: i || 64,
        suggestionList: [],
        selectType: {
            name: "全部",
            type: a.yv.ALL
        }
    },
    suggestionList: [],
    lifetimes: {
        attached: function() {
            var e = this.data.supportGoods, t = [].concat(n);
            e || (t = t.filter(function(e) {
                return e.type !== a.yv.GOODS;
            })), this.suggestionList = t, this.setData({
                suggestionList: t
            });
        }
    },
    methods: {
        ignoreTap: function() {},
        handleBlur: function() {
            var e = this;
            this.data.showSuggestion || this.setData({
                focus: !1
            }, function() {
                e.hideSuggestion(), e.triggerSearch();
            });
        },
        handleClear: function() {
            var e = this;
            this.setData({
                inputValue: "",
                focus: !1
            }, function() {
                e.hideSuggestion(), e.triggerSearch();
            });
        },
        handleFocus: function() {
            this.setData({
                focus: !0
            });
        },
        handleTap: function() {
            var e = this, t = function() {
                var t = e.data.inputValue;
                e.setData({
                    focus: !0
                }), t && e.updateSearchSuggestion(t);
            };
            try {
                var a = this.createSelectorQuery().select("#search-anchor-point");
                this.createSelectorQuery().selectViewport().scrollOffset(function(e) {
                    var i = e.scrollTop;
                    a.boundingClientRect(function(e) {
                        wx.pageScrollTo({
                            scrollTop: i + e.top,
                            duration: 300,
                            complete: function() {
                                setTimeout(function() {
                                    t();
                                }, 200);
                            }
                        });
                    }).exec();
                }).exec();
            } catch (e) {
                t();
            }
        },
        handleSearch: function() {
            var e = this;
            this.setData({
                focus: !1
            }, function() {
                e.hideSuggestion(), e.triggerSearch();
            });
        },
        handleInput: function(e) {
            var a = this, i = (0, t.jo)(e, "value");
            i && i.length > 50 && (0, t.ri)({
                title: "字数超出限制",
                icon: "none"
            }), i = i.slice(0, 50), this.setData({
                inputValue: i
            }, function() {
                a.updateSearchSuggestion(i);
            });
        },
        hideSuggestion: function() {
            this.setData({
                showSuggestion: !1
            });
        },
        handleSuggestionClick: function(e) {
            var a = this, i = (0, t.jo)(e).item;
            this.setData({
                focus: !1,
                selectType: i,
                showSuggestion: !1
            }, function() {
                a.triggerSearch();
            });
        },
        updateSearchSuggestion: function(t) {
            if (t) {
                var a = e(this.suggestionList), i = this.data.selectType;
                s.test(t) || (a = a.filter(function(e) {
                    return !e.onlyNumber;
                }), i.onlyNumber && (i = n[0])), this.setData({
                    suggestionList: a,
                    selectType: i,
                    showSuggestion: !0
                });
            } else this.hideSuggestion();
        },
        triggerSearch: (0, t.g9)(function() {
            var e = this.data, t = e.inputValue, a = void 0 === t ? "" : t, i = e.selectType, n = a.trim();
            this.triggerEvent("onSearch", {
                value: n,
                type: i.type
            }), this.setData({
                inputValue: n
            });
        }, 300)
    }
});