var e = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), t = require("../../../../_/helpers/asyncToGenerator"), a = require("../../../../_/helpers/objectSpread2"), i = require("../../../../$app");

function s(e) {
    return (0, i.fy)(a(a(a({}, i.oh), e), {}, {
        noErrorToast: !0,
        convertRequestToSnake: !0,
        convertToCamel: !0
    })).then(function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return e.result;
    }).catch(function() {
        return [];
    });
}

(0, require("../../../../$page").afb)({
    properties: {
        orderSn: String,
        activityNo: String,
        itemActivityNo: String,
        isHelpSellOrder: {
            type: Boolean,
            value: !1
        },
        selfPickSiteNo: {
            type: String,
            value: ""
        }
    },
    data: {
        show: !1,
        selectSiteNo: "",
        searchValue: "",
        showList: [],
        isLoading: !1,
        selectedSiteHasSiteManager: !1
    },
    isLock: !1,
    pageNumber: 1,
    attached: function() {
        this.pageNumber = 1, this.loadFirstData(), this.loadSelectedSiteData();
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        getListParams: function() {
            var e = this.data, t = e.activityNo, a = e.itemActivityNo, i = e.isHelpSellOrder;
            return {
                keyword: e.searchValue,
                collectionActivityNo: t,
                helpSellActivityNo: a,
                queryAllHelpSellSite: i
            };
        },
        loadFirstData: function() {
            var e = this, t = this.data.selfPickSiteNo;
            this.pageNumber = 1, s({
                data: a(a({}, this.getListParams()), {}, {
                    pageNo: 1,
                    pageSize: 10
                })
            }).then(function(a) {
                var i = (a || {}).addressInfoVos || [];
                e.pageNumber++, e.setData({
                    show: !0,
                    hasMore: !0,
                    selectSiteNo: t,
                    showList: i
                });
            }).catch(function() {
                e.$showToast({
                    title: "无自提点可修改"
                });
            });
        },
        loadSelectedSiteData: function() {
            var s = this;
            return t(e.default.mark(function t() {
                var o, r;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return o = s.data.selfPickSiteNo, e.next = 3, s.$baseRequest(a(a({}, i.ky), {}, {
                            data: {
                                collectionSiteNos: [ o ]
                            }
                        }));

                      case 3:
                        r = e.sent, (0, i.qh)(r, "result.addressInfoVos.0.siteManagerUserNo") && s.setData({
                            selectedSiteHasSiteManager: !0
                        });

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        handleSearch: (0, i.g9)(function(e) {
            var t = this, a = (0, i.jo)(e).value;
            a !== this.data.searchValue && this.setData({
                searchValue: a
            }, function() {
                t.pageNumber = 1, t.loadFirstData();
            });
        }, 600),
        loadSiteList: function() {
            var e = this;
            if (!this.data.isLoading) {
                this.setData({
                    isLoading: !0
                });
                var t = this.data.showList, i = void 0 === t ? [] : t;
                s({
                    data: a(a({}, this.getListParams()), {}, {
                        pageNo: this.pageNumber,
                        pageSize: 10
                    })
                }).then(function(t) {
                    var a = (t || {}).addressInfoVos || [];
                    if (a && a.length > 0) e.pageNumber++, e.setData({
                        showList: i.concat(a),
                        hasMore: !0
                    }); else {
                        var s = {
                            hasMore: !1
                        };
                        1 === e.pageNumber && (s.showList = []), e.setData(s);
                    }
                    e.setData({
                        isLoading: !1
                    });
                }).catch(function() {
                    e.setData({
                        isLoading: !1,
                        hasMore: !1
                    });
                });
            }
        },
        handleClick: function(e) {
            var t = this;
            if (!this.isLock) {
                this.isLock = !0;
                var a = this.data.selectSiteNo, s = (0, i.jo)(e).item;
                s.siteNo !== a ? this.data.selectedSiteHasSiteManager ? i.f3.showModal({
                    title: "确认要更换自提点吗？",
                    content: "若该自提点已设置佣金，则佣金仍给原自提点管理员。",
                    confirmText: "确认更换",
                    confirmColor: "#07c160"
                }).then(function(e) {
                    t.isLock = !1, e && e.confirm && t.handleModify(s);
                }) : this.handleModify(s) : this.isLock = !1;
            }
        },
        handleModify: function(e) {
            var t = this;
            (function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, i.fy)(a(a({}, i.np), e));
            })({
                data: {
                    parentOrderSn: this.data.orderSn,
                    selfSiteNo: e.siteNo
                }
            }).then(function(a) {
                t.isLock = !1, a && a.success ? (t.setData({
                    selectSiteNo: e.siteNo
                }), t.$showToast({
                    title: "修改自提点成功"
                }), t.updateNewSite(e), t.close()) : t.$showToast({
                    title: "修改自提点失败"
                });
            }).catch(function() {
                t.isLock = !1;
            });
        },
        updateNewSite: function(e) {
            var t = e.mobile, a = e.receiveName, i = e.shippingAddress, s = e.siteName, o = e.siteNo;
            this.triggerEvent("submit", {
                selfPickSiteNo: o,
                selfPickUpAddress: i,
                selfPickUpContactMobile: t,
                selfPickUpContactName: a,
                selfPickUpSiteName: s
            });
        }
    }
});