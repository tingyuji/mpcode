var e = require("../../../../$page"), a = require("../../../../$app");

(0, e.afb)({
    properties: {
        isModify: Boolean,
        remark: {
            type: String,
            value: ""
        },
        privateRemark: {
            type: String,
            value: "",
            observer: function(e) {
                e && this.setData({
                    showPrivate: !0
                });
            }
        },
        canEditPrivateRemark: Boolean,
        isSelectPrivateRemark: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        remark: "",
        privateRemark: "",
        showPrivate: !1,
        MAX_INPUT_LENGTH: 200,
        remarkFocus: !1,
        privateRemarkFocus: !1,
        keyboardHeight: 0
    },
    lifetimes: {
        attached: function() {
            var e = {};
            this.data.isSelectPrivateRemark ? e.privateRemarkFocus = !0 : e.remarkFocus = !0, 
            this.setData(e);
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        submit: (0, a.r2)(function() {
            var e = this.data, a = e.remark, t = e.privateRemark, r = e.canEditPrivateRemark;
            this.triggerEvent("submit", {
                remark: a,
                privateRemark: t,
                canEditPrivateRemark: r
            });
        }, 1500),
        handlePublicInput: function(e) {
            var a = e.detail.value;
            this.setData({
                remark: a.slice(0, 200)
            });
        },
        handlePublicBlur: function(e) {
            var a = e.detail.value;
            this.setData({
                remark: a.slice(0, 200),
                remarkFocus: !1,
                keyboardHeight: 0
            });
        },
        handlePublicFocus: function(e) {
            this.setData({
                remarkFocus: !0,
                keyboardHeight: e.detail.height
            });
        },
        handlePrivateInput: function(e) {
            var a = e.detail.value;
            this.setData({
                privateRemark: a.slice(0, 200)
            });
        },
        handlePrivateBlur: function(e) {
            var a = e.detail.value;
            this.setData({
                privateRemark: a.slice(0, 200),
                privateRemarkFocus: !1
            });
        },
        handlePrivateFocus: function() {
            this.setData({
                privateRemarkFocus: !0
            });
        },
        handleOpenPrivate: function() {
            this.setData({
                showPrivate: !0
            });
        }
    }
});