var t = require("../../../../_/helpers/interopRequireDefault")(require("../../../../_/regenerator")), a = require("../../../../_/helpers/asyncToGenerator"), e = require("../../../../_/helpers/objectSpread2"), r = require("../../../../$page"), s = require("../../../../$app");

(0, r.afb)({
    behaviors: [ r.abb ],
    properties: {
        isJoinOrderRecordExist: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.initGroupBuyTab();
            }
        },
        activityNo: String,
        canAfterSales: {
            type: Boolean,
            value: !0
        },
        showCount: {
            type: Boolean,
            value: !0
        },
        currentTab: {
            type: Object,
            value: {}
        },
        canToShipSort: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        ORDER_TAB_MAP: r.y2,
        orderTabList: [],
        afterSalesTotalCount: 0
    },
    hasInitGroupBuy: !1,
    lifetimes: {
        attached: function() {
            var t = this.data.canToShipSort, a = (0, s.g1)(r.y1);
            t && a.forEach(function(t) {
                t.id === r.y2.LOGISTICS && t.subTabList.forEach(function(t) {
                    t.subId === r.y2.TO_SHIP && Object.assign(t, {
                        canSort: !0
                    });
                });
            }), this.setData({
                orderTabList: a
            }), this.loadAfterSalesRedPoint();
        }
    },
    methods: {
        initGroupBuyTab: function() {
            if (!this.hasInitGroupBuy) {
                this.hasInitGroupBuy = !0;
                var t = this.data.orderTabList;
                t.splice(1, 0, r.v_), this.setData({
                    orderTabList: t
                });
            }
        },
        handleAfterSalesEntry: function() {
            var t, a = this, e = this.data.activityNo;
            this.$click({
                page_el_sn: r.y3[r.y2.AFTER_SALES_LIST]
            }), null === (t = this.$currentPage) || void 0 === t || t.$addNextShowCallback(function() {
                a.loadAfterSalesRedPoint();
            }), (0, s.n3)({
                url: s.ob.afterSalesList,
                params: {
                    activity_no: e
                }
            });
        },
        handleTapTab: function(t) {
            var a = this.data.currentTab, e = (0, s.jo)(t).tab, i = {};
            Object.assign(i, e), this.$click({
                page_el_sn: r.y3[e.id]
            }), i.id !== r.y2.AFTER_SALES ? a.id !== i.id && (e.subTabList && e.subTabList.length > 0 && (i = e.subTabList[0]), 
            this.triggerEvent("onTabChange", {
                tab: i
            })) : this.handleAfterSalesEntry();
        },
        handleTapSubTab: (0, r.afc)(function(t) {
            var a = this.data.currentTab, e = (0, s.jo)(t).subTab;
            if (e.subId !== a.subId || e.canSort) {
                this.$click({
                    page_el_sn: r.y3[e.subId]
                });
                var i = !1, n = !1;
                e.subId === a.subId && e.canSort && (n = !(0, s.qh)(e, "fetchParams.sortOrder"), 
                i = !0, (0, s.qj)(e, "fetchParams.sortOrder", n), this._updateSubTab(e), this.$showToast({
                    title: "按时间".concat(n ? "从近到远" : "从远到近", "排序"),
                    mask: !0
                })), this.triggerEvent("onTabChange", {
                    tab: e,
                    hasToast: i
                });
            }
        }, 800),
        _updateSubTab: function(t) {
            var a = this.data.orderTabList.map(function(a) {
                return a.id === t.id && (a.subTabList = (a.subTabList || []).map(function(a) {
                    return a.subId === t.subId && (a = e(e({}, a), t)), a;
                })), a;
            });
            this.setData({
                orderTabList: a
            });
        },
        _setTabCount: function(t, a) {
            var e = this.data.orderTabList;
            e.forEach(function(e) {
                e.subTabList.forEach(function(e) {
                    e.subId === t && (e.count = a);
                });
            }), this.setData({
                orderTabList: e
            });
        },
        loadAfterSalesRedPoint: function() {
            var i = this;
            return a(t.default.mark(function a() {
                var n, o, u;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (n = i.data, o = n.activityNo, n.canAfterSales) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return");

                      case 3:
                        return t.next = 5, i.$baseRequest(e(e({}, o ? r.ala : r.ak_), {}, {
                            noErrorToast: !0,
                            data: {
                                pageSize: 1,
                                pageNumber: 1,
                                onlyRedDot: !0,
                                activityNo: o || null,
                                queryRole: 4,
                                applyTimeDescend: !1
                            }
                        })).catch(s.hm);

                      case 5:
                        (null == (u = t.sent) ? void 0 : u.result) && i.setData({
                            afterSalesTotalCount: u.result.total || 0
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        }
    }
});