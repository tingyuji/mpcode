var t = require("../../../../$app"), e = {
    ALL: "取消整个订单",
    SINGLE: "取消单品"
};

Component({
    data: {
        options: Object.keys(e).map(function(t) {
            return e[t];
        }),
        show: !1
    },
    ready: function() {
        this.setData({
            show: !0
        });
    },
    methods: {
        onChooseChange: function(n) {
            var i = (0, t.jo)(n).type;
            i && (i === e.ALL ? this.triggerEvent("cancelAll") : i === e.SINGLE && this.triggerEvent("cancelSingle"));
        },
        hide: function() {
            this.triggerEvent("hide");
        }
    }
});