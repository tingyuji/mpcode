var t = require("../../../../$app"), e = {
    REFUND: "仅退款",
    REFUND_AND_CANCEL: "取消商品并退款"
};

Component({
    data: {
        options: Object.keys(e).map(function(t) {
            return e[t];
        }),
        show: !1
    },
    ready: function() {
        this.setData({
            show: !0
        });
    },
    methods: {
        onChooseChange: function(n) {
            var i = (0, t.jo)(n).type;
            i && (i === e.REFUND ? this.triggerEvent("refund") : i === e.REFUND_AND_CANCEL && this.triggerEvent("refundAndCancel"));
        },
        hide: function() {
            this.triggerEvent("hide");
        }
    }
});