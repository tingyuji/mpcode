var e = require("../../../../$app"), t = require("../../../../$page"), a = function(e) {
    return e.isSelected = !1, e.operateCancelNumber = e.availableCancelNumber || 0, 
    e;
}, i = {
    PLUS: "plus",
    MINUS: "minus"
};

(0, t.afb)({
    behaviors: [],
    properties: {
        item: {
            type: Object,
            value: {}
        }
    },
    data: {
        OPERATION_TYPE: i,
        SUBORDER_CANCEL_STATUS: t._t,
        show: !1,
        subOrderMapList: [],
        selectSubOrderMap: [],
        isSelectedAll: !1,
        isSelectedAllDisable: !1,
        disableConfirm: !0,
        selectedCancelNumber: 0,
        suggestText: "",
        selectedCancelSubOrder: [],
        confirmDialogVisible: !1
    },
    attached: function() {
        var e = this.data.item.subOrderList, t = void 0 === e ? [] : e;
        this.setData({
            subOrderMapList: (t || []).map(a),
            isSelectedAllDisable: t.every(function(e) {
                return e.availableCancelNumber <= 0;
            })
        });
    },
    ready: function() {
        this.setData({
            show: !0
        });
    },
    methods: {
        hide: function() {
            this.triggerEvent("close");
        },
        confirm: function() {
            var e = this.data.subOrderMapList, t = (void 0 === e ? [] : e).filter(function(e) {
                return e.isSelected && e.availableCancelNumber > 0;
            });
            this.setData({
                selectedCancelSubOrder: t,
                confirmDialogVisible: !0
            });
        },
        submitConfirm: function() {
            var e = this.data, t = e.selectedCancelSubOrder, a = e.selectedCancelNumber;
            this.triggerEvent("confirm", {
                selectedCancelSubOrder: t,
                selectedCancelNumber: a
            });
        },
        closeConfirmDialog: function() {
            this.setData({
                confirmDialogVisible: !1
            });
        },
        selectSubOrder: function(t) {
            var a = (0, e.jo)(t).index, i = this.data.subOrderMapList, r = void 0 === i ? [] : i;
            if (!(r[a].availableCancelNumber <= 0)) {
                r[a].isSelected = !r[a].isSelected;
                var l = {};
                l.subOrderMapList = r, this.setData(l), this.updateSelectAllStatus(), this.updateSelectedCancelNumber(), 
                this.updateConfirmBtnStatus();
            }
        },
        updateSelectAllStatus: function() {
            var e = this.data.subOrderMapList, t = (void 0 === e ? [] : e).filter(function(e) {
                return e.availableCancelNumber > 0;
            }).every(function(e) {
                return e.isSelected;
            });
            this.setData({
                isSelectedAll: t
            });
        },
        updateSelectedCancelNumber: function() {
            var e = this.data.subOrderMapList, t = 0;
            (void 0 === e ? [] : e).filter(function(e) {
                return e.isSelected && e.availableCancelNumber > 0;
            }).forEach(function(e) {
                t += e.operateCancelNumber || 0;
            }), this.setData({
                selectedCancelNumber: t
            });
        },
        handleSelectAll: function() {
            var e = this.data, t = e.subOrderMapList, a = void 0 === t ? [] : t, i = e.isSelectedAll;
            e.isSelectedAllDisable || (a.forEach(function(e) {
                e.availableCancelNumber <= 0 || (e.isSelected = !i);
            }), this.setData({
                isSelectedAll: !i,
                subOrderMapList: a
            }), this.updateConfirmBtnStatus(), this.updateSelectedCancelNumber());
        },
        updateConfirmBtnStatus: function() {
            var e = !this.data.subOrderMapList.some(function(e) {
                return !(e.availableCancelNumber <= 0) && (!!e.isSelected || void 0);
            });
            this.setData({
                disableConfirm: e
            });
        },
        handleOperateCancelNumber: function(t) {
            var a = (0, e.jo)(t), r = a.index, l = a.type, s = this.data.subOrderMapList, n = void 0 === s ? [] : s;
            n[r].availableCancelNumber <= 0 || (n[r].isSelected = !0, l === i.PLUS ? n[r].operateCancelNumber <= n[r].availableCancelNumber && n[r].operateCancelNumber++ : l === i.MINUS && n[r].operateCancelNumber >= 1 && n[r].operateCancelNumber--, 
            this.setData({
                subOrderMapList: n
            }), this.updateSelectAllStatus(), this.updateSelectedCancelNumber(), this.updateConfirmBtnStatus());
        }
    }
});