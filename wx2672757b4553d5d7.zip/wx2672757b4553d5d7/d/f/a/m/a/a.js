(0, require("../../../../../$page").afb)({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        selectedCancelSubOrder: {
            type: Array,
            value: []
        }
    },
    data: {
        selectedCancelNumber: 0
    },
    lifetimes: {
        attached: function() {
            this.updateSelectedCancelNumber();
        }
    },
    methods: {
        updateSelectedCancelNumber: function() {
            var e = this.data.selectedCancelSubOrder, t = 0;
            (void 0 === e ? [] : e).forEach(function(e) {
                t += e.operateCancelNumber || 0;
            }), this.setData({
                selectedCancelNumber: t
            });
        },
        close: function() {
            this.triggerEvent("close");
        },
        submit: function() {
            this.triggerEvent("submit");
        }
    }
});