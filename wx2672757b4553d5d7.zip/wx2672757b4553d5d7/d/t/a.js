var e = require("../../_/helpers/objectSpread2"), t = require("../../$app");

(0, require("../../$page").afb)({
    externalClasses: [ "observer-class" ],
    retachListener: void 0,
    hasObserve: !1,
    observer: void 0,
    properties: {
        rootBottom: {
            type: Number,
            value: 0
        },
        rootTop: {
            type: Number,
            value: 0
        },
        log: {
            type: String,
            value: ""
        },
        intersectionRatio: {
            type: Number,
            value: .7
        },
        extParams: {
            type: Object,
            value: {}
        },
        useNew: {
            type: Boolean,
            value: !1
        },
        needObserve: {
            type: Boolean,
            value: !0
        },
        longObserver: {
            type: Boolean,
            value: !1
        },
        leaveObserver: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        info: {}
    },
    impr: !1,
    methods: {
        singleTracking: function(t) {
            if (this.isItemIn(t)) {
                if (!this.impr) {
                    var r = this.data, s = r.log, i = r.longObserver, a = r.leaveObserver;
                    s ? this.$impr({
                        page_el_sn: s,
                        extParams: this.data.extParams
                    }) : this.triggerEvent("onImpr", e(e({}, this.data.info), this.data.extParams)), 
                    this.impr = !0, !this.observer || i || a || this.observer.disconnect();
                }
                this.triggerEvent("onEnter");
            } else this.impr && this.data.leaveObserver && this.observer && this.observer.disconnect(), 
            this.triggerEvent("onLeave");
        },
        isItemIn: function(e) {
            return e.intersectionRatio >= this.data.intersectionRatio;
        },
        retachObserver: function() {
            var e = this;
            this.detachObserver();
            var r = this.data.intersectionRatio;
            this.observer = this.createIntersectionObserver({
                thresholds: [ r ]
            }), this.observer.relativeToViewport({
                bottom: (0, t.qf)(this.data.rootBottom),
                top: (0, t.qf)(this.data.rootTop)
            }).observe(".observer", function(t) {
                return e.singleTracking(t);
            });
        },
        detachObserver: function() {
            this.observer && (this.observer.disconnect(), this.observer = null, this.impr = !1);
        }
    },
    attached: function() {
        var e = this;
        this.$currentPage && (0, t.ly)("/" + this.$currentPage.route) && (this.retachListener = t.f9.listen(t.f1.retachImprObserver, function() {
            e.data.needObserve && e.$currentPage && e.$currentPage.$visible && (e.retachObserver(), 
            e.hasObserve = !0);
        })), this.data.needObserve && !this.hasObserve && this.retachObserver();
    },
    detached: function() {
        this.detachObserver(), this.retachListener && this.retachListener();
    }
});