var t = require("../../_/helpers/interopRequireDefault"), e = t(require("../../_/regenerator")), a = require("../../_/helpers/asyncToGenerator"), i = require("../../_/helpers/objectSpread2"), r = t(require("@pdd/std-format")), n = require("../../$app"), o = require("../../$page"), s = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return i(i({}, t), {}, {
        id: t.activityNo,
        tagName: t.activityTitle,
        createAt: r.default.formatTime(t.activityCreatedAt / 1e3, "YYYY/MM/dd hh:mm"),
        fetchParams: {
            activityNo: t.activityNo
        }
    });
}, c = function() {
    return {
        activityList: [],
        hasMore: !1,
        isLoading: !1,
        toRefundMap: {},
        selectedTab: o.vu.ALL
    };
};

(0, o.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.imprShow();
            }
        },
        selectActivity: {
            type: Object,
            value: {}
        },
        trackingData: {
            type: Object,
            value: {}
        },
        showLocalLifeServerOption: {
            type: Boolean,
            value: !1
        }
    },
    data: i({
        DISPLAY_TYPE: o.u9,
        defaultActivity: {
            activityNo: "",
            activityTitle: "全部团购"
        },
        FILTER_TAB_LIST: o.vt,
        FILTER_TAB_MAP: o.vu
    }, c()),
    pageNumber: 1,
    attached: function() {
        this.initData();
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        _refresh: function() {
            this.setData(i({}, c())), this.initData();
        },
        imprShow: function() {
            var t = this.data.trackingData;
            t && t.panelShowEle && this.$impr({
                page_el_sn: t.panelShowEle
            });
        },
        clickTabLog: function(t) {
            var e = this.data.trackingData;
            if (e) {
                var a = e.allTabBtn;
                t === o.vu.OWN ? a = e.myPublishTabBtn : t === o.vu.HELP_SELL && (a = e.myHelpSellTabBtn), 
                a && this.$click({
                    page_el_sn: a
                });
            }
        },
        handleTapTab: function(t) {
            var e = (0, n.jo)(t, "item");
            this.setData({
                selectedTab: e.id
            }), this.clickTabLog(e.id), this.initData({
                loading: !0
            });
        },
        getListParams: function() {
            var t = this.data, e = t.FILTER_TAB_LIST, a = t.selectedTab, r = e.find(function(t) {
                return t.id === a;
            }) || {
                fetchParams: {}
            };
            return i({
                pageNumber: this.pageNumber,
                pageSize: 10
            }, r.fetchParams);
        },
        initData: function() {
            var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.loading, i = void 0 !== a && a;
            this.pageNumber = 1, this.setData({
                isLoading: !0
            }), i && this.$showLoading(), (0, o.ag8)({
                data: this.getListParams(),
                noErrorToast: !0
            }).then(function(e) {
                i && t.$hideLoading();
                var a = e && e.result, r = (null == a ? void 0 : a.map(s)) || [], n = {
                    isLoading: !1,
                    activityList: [ t.getFirstAllItem(), t.getLocalLifeServerItem() ].filter(function(t) {
                        return !!t;
                    }).concat(r)
                };
                a && a.length > 0 ? (t.pageNumber++, n.hasMore = !0, t.getToRefundNumber(r || [])) : n.hasMore = !1, 
                t.setData(n);
            }).catch(function(e) {
                i && t.$hideLoading(), t.$showToast({
                    title: e.erroMsg
                }), t.setData({
                    isLoading: !1,
                    hasMore: !1
                });
            });
        },
        getFirstAllItem: function() {
            var t = this.data.selectedTab;
            return o.s6[t];
        },
        getLocalLifeServerItem: function() {
            var t = this.data, e = t.showLocalLifeServerOption, a = t.selectedTab;
            return e && a === o.vu.ALL ? o.xi : null;
        },
        loadMore: function() {
            var t = this;
            this.data.isLoading || (this.setData({
                isLoading: !0
            }), (0, o.ag8)({
                data: this.getListParams()
            }).then(function(e) {
                var a = e && e.result, i = t.data.activityList, r = void 0 === i ? [] : i, n = {
                    isLoading: !1
                };
                if (a && a.length > 0) {
                    t.pageNumber++;
                    var o = a.map(s) || [];
                    n.activityList = r.concat(o), n.hasMore = !0, t.getToRefundNumber(o);
                } else n.hasMore = !1;
                t.setData(n);
            }).catch(function() {
                t.setData({
                    isLoading: !1,
                    hasMore: !1
                });
            }));
        },
        getToRefundNumber: function(t) {
            var i = this;
            return a(e.default.mark(function a() {
                var r, s, c, u;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 !== (r = t.map(function(t) {
                            return t.activityNo;
                        }).filter(function(t) {
                            return !!t;
                        })).length) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        return e.next = 5, (0, o.ahc)({
                            data: {
                                activity_no_list: r
                            },
                            noErrorToast: !0
                        }).catch(n.hm);

                      case 5:
                        s = e.sent, c = i.data.toRefundMap, u = (0, n.qh)(s, "result.items") || [], r.forEach(function(t) {
                            var e = u.find(function(e) {
                                return e.activityNo === t;
                            });
                            c[t] = e ? e.refundOrderNumber : 0;
                        }), i.setData({
                            toRefundMap: c
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        handleClickActivity: function(t) {
            var e = (0, n.jo)(t).item;
            this.triggerEvent("changeActivity", {
                activity: e
            }), this.close();
        }
    }
});