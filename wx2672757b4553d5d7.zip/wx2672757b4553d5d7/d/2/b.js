var e = require("../../_/helpers/interopRequireDefault");

require("../../_/helpers/Arrayincludes"), require("../../_/helpers/Objectvalues");

var t = require("../../_/helpers/defineProperty"), r = require("../../_/helpers/objectSpread2"), a = e(require("../../_/regenerator")), n = require("../../_/helpers/asyncToGenerator"), i = require("../../$page"), o = e(require("@pdd/std-format")), s = require("../../$app"), d = {
    TITLE: "title"
};

(0, i.afb)({
    behaviors: [ i.aba, i.ak6 ],
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                var t = e || {}, r = t.latestMessage, a = t.gameplayOrderGroupInfo, n = void 0 === a ? {} : a;
                t.payStatus ? this.updateOrderBtn(e) : this.updateToPayStatus(), this.updateNoteInfo(r), 
                this.calcCaptainInfoStyle(e), this.updateAfterSaleDesc(), n.groupStatus === s.a0.ONGOING && (this.loadShareImageUrl(e), 
                this.setData({
                    showGroupBuyCountDown: !0
                })), this.resetShareOrderTimeTip(e), this.updateServicePromise(e), this.updateDisplayInfo();
            }
        },
        index: Number,
        showActivity: {
            type: Boolean,
            value: !0
        },
        fromMyOrderList: {
            type: Boolean,
            value: !1
        },
        tracking: {
            type: Object,
            value: {}
        },
        needAutoSendCard: {
            type: Boolean,
            value: !1
        },
        toReceiveView: {
            type: Boolean,
            value: !1
        },
        selected: {
            type: Boolean,
            value: !1
        },
        ignoreEmoji: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        SUB_ACTIVITY_TYPE: s.cp,
        FORWARD_SOURCE: d,
        DISPLAY_TYPE: i.u9,
        DEFAULT_GOODS_IMG: (0, s.jx)(),
        AFTER_SALES_STATUS: i.s4,
        SHIPPING_STATUS: i._j,
        BTN_TYPE: i.yt,
        showGroupBuyCountDown: !1,
        GROUP_BUY_ORDER_STATUS: s.a0,
        dataShareInfo: null,
        captainInfoStyle: {
            titleMaxWidth: "",
            nameMaxWidth: ""
        },
        afterSaleDesc: "",
        giftOrder: null,
        subOrderList: [],
        ORDER_COMMENTS_STATUS: i.yp,
        isToPay: !1,
        showShareOrderTimeTip: !1,
        shareOrderLeftDays: 0,
        displayActivityTitle: ""
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return n(a.default.mark(function t() {
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.goToActivityDetail = (0, i.afc)(e.goToActivityDetail, 500), 0 !== e.data.index) {
                            t.next = 7;
                            break;
                        }
                        return t.next = 5, e._getHasClickCallCaptain();

                      case 5:
                        t.sent || e.setData({
                            callHintVisible: !0
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        }
    },
    pageLifetimes: {},
    methods: {
        doNothing: function() {},
        onOrderImpr: function() {
            var e = this.data, t = e.tracking, r = e.item, a = (0, s.qh)(t, "orderCardEle");
            a && this.$impr({
                page_el_sn: a,
                extParams: {
                    pay_status: r.payStatus
                }
            });
        },
        handleCloseCallHint: function() {
            this.data.callHintVisible && (this._setHasClickCallCaptain(), this.setData({
                callHintVisible: !1
            }));
        },
        calcCaptainInfoStyle: function(e) {
            var t = (0, s.nm)(e.activityTitle, 28) + 20;
            e.subActivityType && (t += 64), t > 370 && (t = 370), this.setData({
                captainInfoStyle: {
                    titleMaxWidth: "max-width: ".concat(t, "rpx;"),
                    nameMaxWidth: "max-width: ".concat(490 - t, "rpx;")
                }
            });
        },
        loadShareImageUrl: function(e) {
            var o = this;
            return n(a.default.mark(function n() {
                var d, u, c, l, h, p, f, S, g;
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return h = (0, s.qh)(e, "subOrderList[0].goodsId"), p = (0, s.ll)(), o.setData({
                            dataShareInfo: {
                                imageUrl: i.uy,
                                title: i.ux,
                                path: s.ob.activity,
                                params: r(r({}, o.$getNextSharePageQuery()), {}, (d = {}, t(d, s.gf.collectionActivityNo, e.activityNo), 
                                t(d, s.gf.orderGroupSn, null === (u = e.gameplayOrderGroupInfo) || void 0 === u ? void 0 : u.orderGroupSn), 
                                t(d, s.gf.goodsId, h), t(d, s.gf.groupAvatar, p.avatar), d))
                            }
                        }), a.prev = 3, a.next = 6, o.$generalShareTicket({
                            data: t({
                                shareScene: s.cr.GROUP_BUY,
                                collectionActivityNo: e.activityNo,
                                goodsId: h
                            }, s.gf.orderGroupSn, null === (c = e.gameplayOrderGroupInfo) || void 0 === c ? void 0 : c.orderGroupSn)
                        });

                      case 6:
                        S = a.sent, g = (S || {}).result, o.setData({
                            dataShareInfo: {
                                imageUrl: null == g ? void 0 : g.imageUrl,
                                title: null == g ? void 0 : g.shareText,
                                path: s.ob.activity,
                                params: r(r({}, o.$getNextSharePageQuery()), {}, (f = {}, t(f, s.gf.collectionActivityNo, e.activityNo), 
                                t(f, s.gf.orderGroupSn, null === (l = e.gameplayOrderGroupInfo) || void 0 === l ? void 0 : l.orderGroupSn), 
                                t(f, s.gf.goodsId, h), t(f, s.gf.groupAvatar, p.avatar), f))
                            }
                        }), a.next = 14;
                        break;

                      case 11:
                        a.prev = 11, a.t0 = a.catch(3), o.$error({
                            msg: "loadShareImageUrl fail",
                            e: a.t0
                        });

                      case 14:
                      case "end":
                        return a.stop();
                    }
                }, n, null, [ [ 3, 11 ] ]);
            }))();
        },
        clickExpressEntry: function() {
            var e = this.data, t = e.item, r = e.noteMessage, a = t.parentOrderSn;
            t.logisticsList && t.logisticsList.length > 0 ? this._forwardOrderExpressDetail(a, t.activityNo) : r && this._forwardOrderNotePage(a);
        },
        handleForwardOrder: function(e) {
            var r = this, a = this.data, n = a.isToPay, o = a.tracking, u = this.data.item, c = u.parentOrderSn, l = u.ownerUserNo, h = u.displayType, p = (0, 
            s.jo)(e).source, f = void 0 === p ? "" : p;
            if ((null == o ? void 0 : o.orderAreaEle) && this.$click({
                page_el_sn: o.orderAreaEle
            }), n) this.handleForwardUnPaidOrder(); else if ((0, i.aje)(h) && f === d.TITLE) {
                if (!l) return;
                (0, s.n5)({
                    pageName: i.aiw.pointMall,
                    params: t({}, s.gf.ownerUserNo, l)
                });
            } else this.$addNextShowCallback && this.$addNextShowCallback(function() {
                r.triggerEvent("update", {
                    parentOrderSn: c
                });
            }), (0, s.n3)({
                url: s.ob.orderDetail,
                params: t({}, s.gf.orderSn, c)
            });
        },
        handleForwardUnPaidOrder: function() {
            var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = this.data, o = n.isClosed, d = n.index, u = this.data.item.parentOrderSn;
            o || (this.$addNextShowCallback && this.$addNextShowCallback(function() {
                (0, i.al9)({
                    data: {
                        parentOrderSn: u
                    },
                    noErrorToast: !0
                }).catch(function() {
                    e.triggerEvent("remove", {
                        index: d
                    });
                });
            }), (0, s.n3)({
                url: s.ob.toPayOrderDetail,
                params: r(t({}, s.gf.orderSn, u), a)
            }));
        },
        goToActivityDetail: function() {
            var e = this.data.item, t = e.activityNo, r = e.displayType;
            return (0, i.aif)(t, {
                displayType: r
            }).then(function(e) {
                (0, i.ag3)(e, {
                    displayType: r
                });
            }).catch(s.hm);
        },
        showRemarkDialog: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, o;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.checkShowProfileDialog({
                            profileScene: "order-remark"
                        });

                      case 2:
                        if (t.t0 = t.sent, t.t1 = i.zg.SUCCESS, t.t0 !== t.t1) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return");

                      case 6:
                        if (r = e.data, n = r.index, (o = r.item).shippingStatus !== i._j.SEND && o.shippingStatus !== i._j.PART_SEND) {
                            t.next = 10;
                            break;
                        }
                        return (0, s.ri)({
                            icon: "none",
                            title: "发货后无法修改备注，请联系团长解决"
                        }), t.abrupt("return");

                      case 10:
                        e.triggerEvent("remark", {
                            index: n,
                            item: o
                        });

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleClickRefundBtn: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.checkShowProfileDialog({
                            profileScene: "order-refund"
                        });

                      case 2:
                        if (t.t0 = t.sent, t.t1 = i.zg.SUCCESS, t.t0 !== t.t1) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return");

                      case 6:
                        (r = e.data.tracking) && r.submitRefundBtn && e.$click({
                            page_el_sn: r.submitRefundBtn
                        }), e.toRefund();

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        toRefund: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = e.data.item, t.next = 3, e.selectRefund(r);

                      case 3:
                        t.sent && e.$addNextShowCallback(function() {
                            e.triggerEvent("update", {
                                parentOrderSn: r.parentOrderSn
                            });
                        });

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        showAfterSalesDetail: function() {
            var e = this, r = this.data.item;
            this.$addNextShowCallback(function() {
                e.triggerEvent("update", {
                    parentOrderSn: r.parentOrderSn
                });
            }), (0, s.n3)({
                url: s.ob.orderAfterSales,
                params: t({}, s.gf.orderSn, r.parentOrderSn)
            });
        },
        handleClickCallOwner: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, o, s;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.checkShowProfileDialog({
                            profileScene: "order-CallOwner"
                        });

                      case 2:
                        if (t.t0 = t.sent, t.t1 = i.zg.SUCCESS, t.t0 !== t.t1) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return");

                      case 6:
                        (r = e.data.tracking) && r.callOwnerBtn && e.$click({
                            page_el_sn: r.callOwnerBtn
                        }), e.handleCloseCallHint(), n = e.data, o = n.item, s = n.needAutoSendCard, e.goChatToB(o, s);

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        call: function(e) {
            var t = (0, s.jo)(e).phone;
            t && wx.makePhoneCall({
                phoneNumber: t
            });
        },
        getLocation: function(e) {
            var t = (0, s.jo)(e).siteNo;
            (0, i.ahu)(t);
        },
        previewCustomPicture: function(e) {
            var t = (0, s.jo)(e).attachmentList, r = void 0 === t ? [] : t;
            r.length > 0 && wx.previewImage({
                current: r[0],
                urls: r
            });
        },
        updateNoteInfo: function(e) {
            var t = this._getOrderNoteMessage(e);
            t && this.setData({
                noteMessage: t
            });
        },
        handleCountDownEnd: function() {
            var e = this;
            setTimeout(function() {
                e.updateGroupBuyStatus();
            }, 2e3);
        },
        groupBuyShare: function() {
            var e = this.data.tracking;
            e && e.groupBuyShareBtn && this.$click({
                page_el_sn: e.groupBuyShareBtn
            });
        },
        updateGroupBuyStatus: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, o, s, d, u, c, l, h, p, f, S, g;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = e.data.item, n = r.gameplayOrderGroupInfo, o = void 0 === n ? {} : n, 
                        t.next = 4, (0, i.ah7)({
                            data: {
                                orderGroupSn: o.orderGroupSn || ""
                            }
                        }).catch(function(t) {
                            return e.setData({
                                showGroupBuyCountDown: !1
                            }), e.$error({
                                e: t,
                                msg: "updateGroupBuyStatus fail"
                            }), {};
                        });

                      case 4:
                        if (s = t.sent, d = s.result) {
                            t.next = 8;
                            break;
                        }
                        return t.abrupt("return");

                      case 8:
                        u = d.orderGroupInfo, l = (c = void 0 === u ? {} : u).groupStatus, h = c.remainGroupNum, 
                        p = void 0 === h ? 0 : h, f = c.expireTime, S = c.joinGroupUsers, g = void 0 === S ? [] : S, 
                        Object.assign(o, {
                            joinGroupUsers: g,
                            groupStatus: l,
                            remainGroupNum: p,
                            expireTime: f
                        }), e.setData({
                            "item.gameplayOrderGroupInfo": o
                        });

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        updateAfterSaleDesc: function() {
            var e = this.data.item, t = void 0 === e ? {} : e;
            this.setData({
                afterSaleDesc: (0, i.aha)(t)
            });
        },
        updateSubOrderList: function() {
            var e = this, t = this.data.item, a = t.hasGift, n = t.giftOrderMap, o = void 0 === n ? {} : n, s = t.subOrderList, d = a ? Object.values(o).map(function(e) {
                return r(r({}, e), {}, {
                    isGift: !0
                });
            }) : [];
            this.setData({
                subOrderList: null == s ? void 0 : s.concat(d).map(function(t) {
                    return r(r({}, t), {}, {
                        goodsName: (0, i.agi)(t.goodsName, e.data.ignoreEmoji),
                        goodsSpecification: (0, i.agi)(t.goodsSpecification, e.data.ignoreEmoji)
                    });
                })
            });
        },
        forwardShareOrder: function() {
            var e = arguments, t = this;
            return n(a.default.mark(function r() {
                var n, o;
                return a.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return n = e.length > 0 && void 0 !== e[0] ? e[0] : {
                            publish_share_channel: i.zk.SHARE
                        }, r.next = 3, t.checkShowProfileDialog({
                            profileScene: "order-CallOwner"
                        });

                      case 3:
                        if (r.t0 = r.sent, r.t1 = i.zg.SUCCESS, r.t0 !== r.t1) {
                            r.next = 7;
                            break;
                        }
                        return r.abrupt("return");

                      case 7:
                        o = t.data.item, t.triggerEvent("onPublishShareOrder", {
                            item: o,
                            params: n
                        });

                      case 9:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        handleTapShareOrder: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                publish_share_channel: i.zk.SHARE
            }, t = this.data.tracking;
            t.publishShareOrderBtn && this.$click({
                page_el_sn: t.publishShareOrderBtn
            }), this.forwardShareOrder(e);
        },
        handleTapShareOrderDetail: function() {
            var e, r = this.data.item;
            (0, s.n3)({
                url: s.ob.postOrder,
                params: (e = {}, t(e, s.gf.orderPostShowType, i._n.SINGLE), t(e, s.gf.orderSn, r.parentOrderSn), 
                e)
            });
            var a = this.data.tracking;
            a.shareOrderDetailBtn && this.$click({
                page_el_sn: a.shareOrderDetailBtn
            });
        },
        autoCloseOrder: function() {
            this.setData({
                isClosed: !0
            });
        },
        handleSelectReason: function(e) {
            var t = (0, s.jo)(e).reason;
            this.handleCloseOrder(t), this.hideOrderCloseReasonPanel();
        },
        handleClickCloseOrder: function() {
            var e = this.data.tracking;
            e && e.closeOrderBtn && this.$click({
                page_el_sn: e.closeOrderBtn
            }), this.showOrderCloseReasonPanel();
        },
        handleCloseOrder: function(e) {
            var t = this;
            return n(a.default.mark(function r() {
                var n, i, o;
                return a.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return n = t.data.item.parentOrderSn, r.next = 3, t._closeCustomerOrder(n);

                      case 3:
                        r.sent && (i = t.data.tracking, o = {
                            reason_type: e.id || 0,
                            reason_desc: e.desc || ""
                        }, i && i.closeOrderReason && t.$click({
                            page_el_sn: i.closeOrderReason,
                            extParams: o
                        }), t.autoCloseOrder());

                      case 5:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        handlePay: function() {
            var e = this.data.tracking;
            e && e.goPayBtn && this.$click({
                page_el_sn: e.goPayBtn
            }), this.handleForwardUnPaidOrder(t({}, s.gf.pullUpPay, 1));
        },
        updateToPayStatus: function() {
            this.setData({
                isToPay: !0
            });
        },
        closeOrderImpr: function() {
            var e = this.data.tracking;
            e && e.closeOrderBtn && this.$impr({
                page_el_sn: e.closeOrderBtn
            });
        },
        updateOrderBtn: function(e) {
            var t = this.data, a = t.toReceiveView, n = t.tracking, o = e.cancelStatus, d = e.commentsStatus, u = e.afterSalesStatus, c = e.hasCommentsReward, l = e.shippingStatus, h = {}, p = [], f = [ i.s4.NONE, i.s4.REFUSE, i.s4.REVOKED, i.s4.CLOSED ].includes(u), S = e.subActivityType === s.cp.LOCAL_LIFE && e.shippingStatus === i._j.RECEIVED;
            a ? ((0, i.abw)(e, !0) && (h[i.yt.RECEIVE] = !0), f && !S && (h[i.yt.APPLY_AFTER_SALES] = !0), 
            f || (h[i.yt.AFTER_SALES_DETAIL] = !0)) : (d === i.yp.ABLE && l === i._j.RECEIVED ? h[i.yt.SHARE_ORDER] = !0 : d === i.yp.ALREADY && (h[i.yt.SHARE_ORDER_DETAIL] = !0), 
            f && !S && (h[i.yt.APPLY_AFTER_SALES] = !0), f || (h[i.yt.AFTER_SALES_DETAIL] = !0), 
            h[i.yt.BUY_MORE] = !0, (0, i.abw)(e) && (h[i.yt.RECEIVE] = !0, h[i.yt.SHARE_ORDER_DETAIL] && Object.keys(h).filter(function(e) {
                return h[e];
            }).length > 3 && (h[i.yt.SHARE_ORDER_DETAIL] = !1, p.push(r({
                key: i.yt.SHARE_ORDER_DETAIL
            }, i.ys[i.yt.SHARE_ORDER_DETAIL])))), o === i.y5.CANCELLED && p.push(r({
                key: i.yt.REMOVE
            }, i.ys[i.yt.REMOVE])));
            var g = Object.keys(h).filter(function(e) {
                return h[e];
            }).map(function(e) {
                var t = r({}, i.ys[e]);
                return e === i.yt.RECEIVE && t.impr && (t.log = (null == n ? void 0 : n.confirmReceiveBtn) || t.log), 
                e !== i.yt.RECEIVE && e !== i.yt.SHARE_ORDER || d !== i.yp.ABLE || !c ? r({
                    key: e
                }, t) : r(r({
                    key: e
                }, t), {}, {
                    isShare: !0
                });
            }).sort(function(e, t) {
                return e.sort - t.sort;
            }), v = g.findIndex(function(e) {
                return e.key === i.yt.AFTER_SALES_DETAIL || e.key === i.yt.APPLY_AFTER_SALES;
            }), m = v >= 0 ? g.length - v : -1, y = g.findIndex(function(e) {
                return e.key === i.yt.BUY_MORE;
            }), O = y >= 0 ? g.length - y : -1;
            g.length > 0 && (g[g.length - 1].isLast = !0), this.setData({
                btnList: g,
                moreBtnList: p,
                afterSalesRightOffset: m,
                buyMoreRightOffset: O
            });
        },
        handleBuyOneMore: function() {
            var e = this.data, t = e.item, r = e.tracking;
            r && r.buyOneMoreOrder && this.$click({
                page_el_sn: r.buyOneMoreOrder
            }), this._doBuyOneMore({
                order: t,
                ocScene: s.b6["ktt_order_list-again"]
            });
        },
        handleReceiveGoods: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, o, s, d, u, c, l, h, p;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return o = e.data, s = o.tracking, d = o.toReceiveView, u = o.item, c = o.index, 
                        e.setData({
                            showOrderReceiveModal: !0
                        }), t.next = 4, null === (n = null === (r = e.selectComponent("#orderReceiveModal-".concat(u.parentOrderSn))) || void 0 === r ? void 0 : r.showReceiveModal) || void 0 === n ? void 0 : n.call(r, [ u ]);

                      case 4:
                        if (l = t.sent, e.setData({
                            showOrderReceiveModal: !1
                        }), null == l ? void 0 : l.confirm) {
                            t.next = 8;
                            break;
                        }
                        return t.abrupt("return");

                      case 8:
                        return h = u.commentsStatus, p = h === i.yp.ABLE && !d, s && s.confirmReceiveBtn && e.$click({
                            page_el_sn: s.confirmReceiveBtn,
                            can_share_order: p ? 1 : 0
                        }), t.next = 13, e._confirmReceiveGoods(u.parentOrderSn, d ? 1 : 0);

                      case 13:
                        t.sent && (p ? (e.$showToast({
                            title: "已确认收货，正在前往晒单..."
                        }), setTimeout(function() {
                            e.forwardShareOrder({
                                publish_share_channel: i.zk.RECEIVE
                            });
                        }, 800)) : e.$showToast({
                            title: "收货成功"
                        }), setTimeout(function() {
                            d ? e.triggerEvent("remove", {
                                index: c
                            }) : e.triggerEvent("update", {
                                parentOrderSn: u.parentOrderSn
                            });
                        }, 500));

                      case 15:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        handleRemoveOrder: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var r, n, i, o;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = e.data, n = r.item, i = r.index, t.next = 3, e.$showModal({
                            title: "确定删除订单？",
                            content: "删除之后订单无法恢复，无法处理您的售后问题，请谨慎考虑",
                            confirmText: "确定",
                            cancelText: "取消",
                            isInPage: !0
                        });

                      case 3:
                        if (t.sent.confirm) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return");

                      case 6:
                        return (o = e.data.tracking) && o.removeOrderBtn && e.$click({
                            page_el_sn: o.removeOrderBtn
                        }), t.next = 10, e._removeOrder(n.parentOrderSn);

                      case 10:
                        t.sent && (e.$showToast({
                            title: "删除成功"
                        }), e.triggerEvent("remove", {
                            index: i
                        }));

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        hideMoreBtn: function() {
            this.setData({
                showMoreBtnList: !1
            });
        },
        toggleMoreBtn: function() {
            this.data.showMoreBtnList || this.setData({
                showMoreBtnList: !0
            });
        },
        handleBtnClick: function(e) {
            var t = (0, s.jo)(e).btn;
            if (t) switch (t.key) {
              case i.yt.SHARE_ORDER:
                this.handleTapShareOrder();
                break;

              case i.yt.SHARE_ORDER_DETAIL:
                this.handleTapShareOrderDetail();
                break;

              case i.yt.AFTER_SALES_DETAIL:
                this.showAfterSalesDetail();
                break;

              case i.yt.APPLY_AFTER_SALES:
                this.handleClickRefundBtn();
                break;

              case i.yt.CALL_CAPTAIN:
                this.handleClickCallOwner();
                break;

              case i.yt.BUY_MORE:
                this.handleBuyOneMore();
                break;

              case i.yt.RECEIVE:
                this.handleReceiveGoods();
                break;

              case i.yt.REMOVE:
                this.handleRemoveOrder();
            }
        },
        resetShareOrderTimeTip: function(e) {
            var t = e.commentsExpireTime, r = this.data.btnList, a = !!(null == r ? void 0 : r.find(function(e) {
                return e.key === i.yt.SHARE_ORDER;
            })), n = (0, s.gj)(), o = a && t && t > n;
            this.setData({
                showShareOrderTimeTip: o,
                shareOrderLeftDays: o ? Math.floor((t - n) / 24 / 60 / 60 / 1e3) : 0
            });
        },
        onShareOrderLimitTimeEnd: function() {
            var e = this.data.item;
            this.setData({
                showShareOrderTimeTip: !1,
                shareOrderLeftDays: 0
            }), this.triggerEvent("update", {
                parentOrderSn: e.parentOrderSn
            });
        },
        toggleSelect: function() {
            var e = this.data.item.parentOrderSn;
            this.triggerEvent("toggleSelect", {
                parentOrderSn: e
            });
        },
        updateServicePromise: function(e) {
            var t = "", r = e.shippingStatus, a = e.expressType, n = e.servicePromise, d = (n = void 0 === n ? {} : n).promiseTagList, u = void 0 === d ? [] : d;
            if (!r && a === s.aq.express) {
                var c = u.find(function(e) {
                    return e.key === i.zh.DELIVERY_TIME;
                });
                c && (t = c.deadLine > Date.now() + 2592e5 ? "此订单预计在".concat(o.default.formatTime(c.deadLine, "YYYY/MM/dd hh:mm"), "前发货") : "");
            }
            this.setData({
                promiseDeadLine: t
            });
        },
        updateDisplayInfo: function() {
            var e = (this.data.item || {}).activityTitle;
            this.setData({
                displayActivityTitle: (0, i.agi)(e, this.data.ignoreEmoji)
            }), this.updateSubOrderList();
        }
    }
});