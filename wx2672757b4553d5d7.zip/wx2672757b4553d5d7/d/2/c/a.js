var e = require("../../../$page");

(0, e.afb)({
    behaviors: [ e.afe ],
    externalClasses: [ "external-class" ],
    properties: {},
    data: {
        secAccuracy: 1
    },
    methods: {}
});