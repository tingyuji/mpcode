var e = require("../../$page"), o = require("../../$app");

(0, e.afb)({
    properties: {
        groupGuideShareInfo: {
            type: Object,
            value: null
        },
        type: {
            type: String,
            value: ""
        }
    },
    methods: {
        goGroupTool: function() {
            (0, o.n3)({
                url: o.ob.groupTool
            });
        },
        onClose: function() {
            this.triggerEvent("close");
        },
        onConfirm: function() {
            this.triggerEvent("confirm");
        }
    },
    lifetimes: {}
});