require("../../../_/helpers/Arrayincludes");

var t = require("../../../$app"), e = require("../../../$page"), a = function(t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    return t.replace(/-/g, "/") + (e ? " 00:00:00" : "");
};

(0, e.afb)({
    properties: {
        show: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        defaultDateOptions: [],
        selectedDefaultDateItem: null,
        isCustomTime: !1,
        startDate: "",
        startDateStamp: -1 / 0,
        endDate: "",
        endDateStamp: 1 / 0,
        hasTabBar: !1
    },
    lifetimes: {
        attached: function() {
            this.setData({
                hasTabBar: (0, t.ly)()
            });
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        resetData: function(t) {
            this.setData({
                defaultDateOptions: e.uh.filter(function(a) {
                    return [ t, e.uk.TODAY, e.uk.YESTERDAY, e.uk.THIS_WEEK ].includes(a.type);
                }),
                selectedDefaultDateItem: e.uh.find(function(e) {
                    return e.type === t;
                }),
                isCustomTime: !1,
                startDate: "",
                startDateStamp: -1 / 0,
                endDate: "",
                endDateStamp: 1 / 0
            });
        },
        showToast: function(t) {
            this.$showToast({
                title: t
            });
        },
        cancelDefaultOptionsSelect: function() {
            this.setData({
                selectedDefaultDateItem: null
            });
        },
        changeStartDate: function(s) {
            var i = (0, t.jo)(s).value, n = {}, D = new Date(a(i, !0)).getTime();
            D > this.data.endDateStamp && (n.endDateStamp = D + e.yh - 1, n.endDate = i), n.startDate = i, 
            n.startDateStamp = D, n.isCustomTime = !0, this.data.endDateStamp === 1 / 0 && (n.endDateStamp = D + e.yh - 1, 
            n.endDate = i), this.setData(n), this.cancelDefaultOptionsSelect();
        },
        changeEndDate: function(s) {
            var i = (0, t.jo)(s).value, n = {}, D = new Date(a(i, !0)).getTime();
            D < this.data.startDateStamp && (n.startDateStamp = D, n.startDate = i), n.endDate = i, 
            n.endDateStamp = D + e.yh - 1, n.isCustomTime = !0, this.data.startDateStamp === -1 / 0 && (n.startDateStamp = D, 
            n.startDate = i), this.setData(n), this.cancelDefaultOptionsSelect();
        },
        selectDefaultTime: function(e) {
            var a = (0, t.jo)(e).index;
            this.setData({
                isCustomTime: !1,
                selectedDefaultDateItem: this.data.defaultDateOptions[a]
            });
        },
        checkCustomDate: function() {
            var t = this.data, a = t.startDate, s = t.endDate, i = t.startDateStamp, n = t.endDateStamp;
            return a ? s ? !(n - i > 31 * e.yh) || (this.showToast("日期范围不应大于一个月"), !1) : (this.showToast("结束日期不得为空"), 
            !1) : (this.showToast("开始日期不得为空"), !1);
        },
        submitDate: function() {
            if (this.data.isCustomTime) {
                var t = this.data, a = t.startDate, s = t.endDate, i = t.startDateStamp, n = t.endDateStamp;
                if (!this.checkCustomDate()) return;
                this.triggerEvent("changeTime", {
                    startDate: i,
                    endDate: n,
                    startDateStr: a,
                    endDateStr: s
                }), this.close();
            } else {
                var D = this.data.selectedDefaultDateItem, r = D.type, u = void 0 === r ? e.uk.LAST_THREE_MONTH : r, h = (0, 
                e.ahk)(u), o = h.startDate, l = h.endDate;
                this.triggerEvent("changeTime", {
                    displayLabel: D.displayLabel,
                    startDate: o,
                    endDate: l
                }), this.close();
            }
        }
    }
});