var e = require("../../../$app"), r = require("../../../$page");

(0, r.afb)({
    behaviors: [ r.afl ],
    externalClasses: [ "item-wrap-class" ],
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function() {
                this.setOperationControl();
            }
        },
        index: Number,
        trackingInfo: {
            type: Object,
            value: {},
            observer: function(e) {
                e.orderCard && this.setData({
                    trackingData: e.orderCard
                });
            }
        },
        ignoreEmoji: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        DISPLAY_TYPE: r.u9,
        trackingData: {}
    },
    isRefunded: !1,
    isCanceled: !1,
    pageLifetimes: {},
    methods: {
        emptyFunction: function() {},
        onOrderImpr: function() {
            var r = this.data.trackingInfo, a = (0, e.qh)(r, "orderCard.orderCardEle");
            a && this.$impr({
                page_el_sn: a
            });
        }
    }
});