var e = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/defineProperty"), r = require("../../_/helpers/objectWithoutProperties"), a = require("../../_/helpers/objectSpread2"), i = e(require("../../_/regenerator")), n = require("../../_/helpers/asyncToGenerator"), s = require("../../$page"), o = require("../../$app"), c = [ "sortOrder" ];

(0, s.afb)({
    behaviors: [ s.acv, s.abb ],
    properties: {
        query: {
            type: Object,
            value: {}
        },
        trackingData: {
            type: Object,
            value: {}
        },
        noTips: {
            type: Boolean,
            value: !1,
            observer: function() {
                this.firstLoaded && this.getHeaderBlockHeight();
            }
        },
        topTipsHeight: {
            type: Number,
            value: 0
        }
    },
    pageNumber: 1,
    listHelper: null,
    activitySelectPanelComp: null,
    attachedTime: 0,
    data: {
        DISPLAY_TYPE: s.u9,
        ORDER_TAB_MAP: s.y2,
        headerBlockFixed: !1,
        headerBlockHeight: 0,
        currentTab: s.ut,
        searchValue: "",
        keywordType: s.yv.ALL,
        selectActivityInited: !1,
        selectActivity: {},
        showLocalLifeServerOption: !1,
        changeActivityPanelVisible: !1,
        firstLoaded: !1,
        isFetching: !1,
        orderMap: {},
        orderIdList: [],
        shipGuideImgList: s._k,
        shipGuideVisible: !1,
        showPushReceiveTip: !1,
        pushReveiveShareInfo: null,
        showRemarkPopover: !1,
        selectedRemarkFilter: s.zz[0],
        REMARK_FILTER_LIST: s.zz,
        $gray: {
            orderListIgnoreEmoji: !1
        }
    },
    lifetimes: {
        ready: function() {
            this.attachedTime = Date.now();
            var e = this.data.query[o.gf.orderTab];
            parseInt(e, 10) === s.y0.TO_REFUND && this.forwardAfterSaleList(), this.initData();
        },
        detached: function() {
            this.listHelper = null;
        }
    },
    methods: {
        onPullDownRefresh: function() {
            var e = this;
            return n(i.default.mark(function t() {
                return i.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.reloadOrderList();

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        onPageScroll: function(e) {
            var t = e.scrollTop;
            if (!this.data.$appData.isAndroid) {
                var r = t <= 1;
                r !== this.data.headerBlockFixed && this.data.headerBlockHeight && this.setData({
                    headerBlockFixed: r
                });
            }
        },
        initData: function() {
            var e = this;
            return n(i.default.mark(function t() {
                var r;
                return i.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, Promise.all([ e.initTab(), e.initSelectActivity(), null === (r = e.resetDefaultDate) || void 0 === r ? void 0 : r.call(e) ]);

                      case 2:
                        e.reloadOrderList(), e.loadPushReceiveTip();

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        initTab: function() {
            var e = this.data.query[o.gf.orderShipTab], t = parseInt(e, 10);
            if (!Number.isNaN(t)) {
                var r = (0, s.ail)(t, o.gf.orderShipTab);
                r && this.setData({
                    currentTab: r
                });
            }
        },
        initSelectActivity: function() {
            var e = this;
            return n(i.default.mark(function t() {
                var r, c;
                return i.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (r = e.data.query[o.gf.localLifeServerToB], c = function() {
                            var t = n(i.default.mark(function t() {
                                var n, c;
                                return i.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, e.$baseRequest(a({}, s.alr)).catch(o.hm);

                                      case 2:
                                        n = t.sent, c = !1, (null == n ? void 0 : n.result) && [ 0, 1, 2 ].indexOf(n.result.userType) > -1 && (c = !0), 
                                        e.setData({
                                            selectActivityInited: !0,
                                            showLocalLifeServerOption: c,
                                            selectActivity: r && c ? s.xi : s._b
                                        }, function() {
                                            e.activitySelectPanelComp || (e.activitySelectPanelComp = e.selectComponent("#activitySelectPanel") || null);
                                        });

                                      case 6:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }));
                            return function() {
                                return t.apply(this, arguments);
                            };
                        }(), r) {
                            t.next = 7;
                            break;
                        }
                        e.setData({
                            selectActivity: s._b
                        }), c(), t.next = 9;
                        break;

                      case 7:
                        return t.next = 9, c();

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        getListHelper: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            return this.listHelper && !e || (this.listHelper = new s.acj({
                uniqueKey: "parentOrderSn"
            })), this.listHelper;
        },
        getListParams: function() {
            var e, t = this.data, i = t.currentTab, n = t.selectActivity, o = t.searchValue, d = t.keywordType, u = t.selectedRemarkFilter, l = i.fetchParams || {}, h = (l.sortOrder, 
            r(l, c));
            return a(a(a(a(a({}, n.id === s.xi.id ? h : i.fetchParams || {}), n.fetchParams), u.fetchParams), null === (e = this.getDateParams) || void 0 === e ? void 0 : e.call(this)), {}, {
                keyWord: o,
                keywordType: d
            });
        },
        reloadOrderList: function() {
            var e = arguments, t = this;
            return n(i.default.mark(function r() {
                var a;
                return i.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return a = e.length > 0 && void 0 !== e[0] && e[0], t.pageNumber = 1, r.next = 4, 
                        t.loadMoreOrderList({
                            showLoading: a
                        });

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        loadMoreOrderList: function(e) {
            var t = this;
            return n(i.default.mark(function r() {
                var n, c, d, u, l, h, p, f, v, g, m, b;
                return i.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (n = e.showLoading, c = void 0 !== n && n, d = t.data, u = d.selectActivity, 
                        l = d.firstLoaded, h = 1 === t.pageNumber, p = !l, h || !t.data.isFetching) {
                            r.next = 6;
                            break;
                        }
                        return r.abrupt("return");

                      case 6:
                        return t.setData({
                            isFetching: !0,
                            loadMoreError: !1
                        }), c && t.$showLoading(), r.next = 10, t.$baseRequest(a(a({}, u.id === s.xi.id ? s.alq : s.amk), {}, {
                            data: a(a({}, t.getListParams()), {}, {
                                pageNumber: t.pageNumber,
                                pageSize: 10
                            })
                        })).catch(o.hm);

                      case 10:
                        if (f = r.sent) {
                            r.next = 14;
                            break;
                        }
                        return c && t.$hideLoading(), r.abrupt("return", t.setData({
                            firstLoaded: !0,
                            isFetching: !1,
                            hasMore: !1,
                            loadMoreError: !0
                        }, function() {
                            p && t.onFirstLoaded();
                        }));

                      case 14:
                        c && t.$hideLoading(), t.pageNumber++, v = (0, o.qh)(f, "result.list") || [], g = (0, 
                        o.qh)(f, "result.hasNext"), m = t.getListHelper(h).formatListData(v.map(s.ag1)), 
                        b = (h && m.length > 3 ? [ m.slice(0, 3), m.slice(3) ] : [ m ]).map(function(e) {
                            return {
                                idList: e.map(function(e) {
                                    return e.parentOrderSn;
                                }),
                                orderMapData: e.reduce(function(e, t) {
                                    return e["orderMap.".concat(t.parentOrderSn)] = t, e;
                                }, {})
                            };
                        }), t.setData(a({
                            firstLoaded: !0,
                            isFetching: !1,
                            hasMore: g || v.length > 0,
                            orderIdList: (h ? [] : t.data.orderIdList).concat(b[0].idList)
                        }, b[0].orderMapData), function() {
                            p && t.onFirstLoaded(), b.length > 1 && t.setData(a({
                                orderIdList: t.data.orderIdList.concat(b[1].idList)
                            }, b[1].orderMapData));
                        });

                      case 21:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        onFirstLoaded: function() {
            this.checkWhiteScreen(), this.logFirstScreenTime(), this.getHeaderBlockHeight();
        },
        getHeaderBlockHeight: function() {
            var e = this;
            if (!this.data.$appData.isAndroid) {
                var t = this.createSelectorQuery();
                t.select("#header-block").boundingClientRect(), t.selectViewport().scrollOffset(), 
                t.exec(function(t) {
                    var r, a, i;
                    if (null === (r = null == t ? void 0 : t[0]) || void 0 === r ? void 0 : r.height) {
                        var n = null === (a = null == t ? void 0 : t[0]) || void 0 === a ? void 0 : a.height, s = (null === (i = null == t ? void 0 : t[1]) || void 0 === i ? void 0 : i.scrollTop) <= 0;
                        n === e.data.headerBlockHeight && s === e.data.headerBlockFixed || e.setData({
                            headerBlockHeight: n,
                            headerBlockFixed: s
                        });
                    }
                });
            }
        },
        checkWhiteScreen: function() {
            var e = this, t = this.createSelectorQuery();
            t.select("#skeleton_to_b").boundingClientRect(), t.exec(function(t) {
                var r;
                (null === (r = null == t ? void 0 : t[0]) || void 0 === r ? void 0 : r.height) && e.$error({
                    msg: "order_white_screen",
                    data: {
                        role: "b",
                        rect: t[0]
                    }
                });
            });
        },
        logFirstScreenTime: function() {
            var e, t, r = (null === (e = this.$currentPage) || void 0 === e ? void 0 : e.$performance.onLoadTime) || 0, a = this.$getPageId(), i = o.f3.getStorageSync(o.ct.orderReportFirstScreen) === a;
            i || o.f3.setStorageSync(o.ct.orderReportFirstScreen, a), (0, o.ev)({
                type: o.u.ORDER_FIRST_SCREEN,
                tags: {
                    orderRole: "b",
                    orderPageName: null === (t = this.$currentPage) || void 0 === t ? void 0 : t.pageProperties.page_name,
                    withPageFirstScreenData: !i
                },
                longFields: Object.assign({
                    componentFirstScreenDuration: Date.now() - this.attachedTime
                }, i ? {} : {
                    pageFirstScreenDuration: Date.now() - r
                })
            });
        },
        handleTabChange: function(e) {
            var t = this, r = e.detail.tab;
            this.setData({
                currentTab: r
            }, function() {
                t.getHeaderBlockHeight();
            }), this.reloadOrderList();
        },
        handleChangeTime: function(e) {
            var t, r;
            null === (t = this.onTimeChange) || void 0 === t || t.call(this, e), null === (r = this.afterTimeChange) || void 0 === r || r.call(this);
        },
        afterTimeChange: function() {
            this.reloadOrderList(!0);
        },
        showActivityPanel: function() {
            this.setData({
                changeActivityPanelVisible: !0
            });
        },
        handleChangeActivity: function(e) {
            var t = (0, o.jo)(e).activity;
            this.setData({
                selectActivity: t
            }), this.reloadOrderList();
        },
        closeActivityPanel: function() {
            this.setData({
                changeActivityPanelVisible: !1
            });
        },
        handleSearch: (0, o.r2)(function(e) {
            var t = (0, o.jo)(e), r = t.value, a = t.type;
            this.setData({
                searchValue: r,
                keywordType: a
            }), this.reloadOrderList();
        }),
        fetchSingleOrderItem: function(e) {
            var t = this;
            return n(i.default.mark(function r() {
                var n, o, c;
                return i.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return n = e.parentOrderSn, r.prev = 1, r.next = 4, t.$baseRequest(a(a({}, s.alt), {}, {
                            data: {
                                parentOrderSn: n
                            }
                        }));

                      case 4:
                        if (o = r.sent, !(c = null == o ? void 0 : o.result)) {
                            r.next = 8;
                            break;
                        }
                        return r.abrupt("return", (0, s.ag1)(c));

                      case 8:
                        r.next = 12;
                        break;

                      case 10:
                        r.prev = 10, r.t0 = r.catch(1);

                      case 12:
                        return r.abrupt("return", {});

                      case 13:
                      case "end":
                        return r.stop();
                    }
                }, r, null, [ [ 1, 10 ] ]);
            }))();
        },
        updateListItem: function(e) {
            var r = this;
            return n(i.default.mark(function a() {
                var n, s, c, d, u, l;
                return i.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = e.detail.index, s = r.data, c = s.orderIdList, d = s.orderMap, u = d[c[n]]) {
                            a.next = 5;
                            break;
                        }
                        return a.abrupt("return");

                      case 5:
                        return a.next = 7, r.fetchSingleOrderItem(u).catch(o.hm);

                      case 7:
                        if (null == (l = a.sent) ? void 0 : l.parentOrderSn) {
                            a.next = 10;
                            break;
                        }
                        return a.abrupt("return");

                      case 10:
                        r.setData(t({}, "orderMap.".concat(l.parentOrderSn), l));

                      case 11:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }))();
        },
        updateListItemWithData: function(e) {
            var r = (0, o.jo)(e), i = r.index, n = r.updateInfo, s = this.data, c = s.orderIdList, d = s.orderMap[c[i]];
            d && this.setData(t({}, "orderMap.".concat(d.parentOrderSn), a(a({}, d), n)));
        },
        handleShowShipGuide: function() {
            var e = (0, o.qh)(this.data.trackingData, "shipGuide.learnBtn");
            this.$click({
                page_el_sn: e
            }), this.setData({
                shipGuideVisible: !0
            });
        },
        handleShipGuideEnd: function() {
            this.setData({
                shipGuideVisible: !1
            });
        },
        handleCopyPcLink: function() {
            wx.setClipboardData({
                data: "https://ktt.pinduoduo.com"
            });
        },
        handleCopyPcRefundLink: function() {
            wx.setClipboardData({
                data: "https://ktt.pinduoduo.com/orders/batch_refund"
            });
        },
        loadPushReceiveTip: function() {
            var e = this;
            return n(i.default.mark(function r() {
                var n, c, d, u;
                return i.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, e.$baseRequest(a({}, s.al2)).catch(o.hm);

                      case 2:
                        c = r.sent, d = e.$getCurrentUserNo(), u = !!(null === (n = null == c ? void 0 : c.result) || void 0 === n ? void 0 : n.enable), 
                        e.setData({
                            showPushReceiveTip: u,
                            pushReveiveShareInfo: u && d ? {
                                title: "大家都收到货了吗？没问题的话记得确认收货～",
                                imageUrl: "https://commimg.pddpic.com/upload/ktt/ffedd31f-4dca-4c8d-b2e6-5de26e14e316.png.slim.png",
                                path: o.ob.myToReceiveOrderList,
                                params: t({}, o.gf.ownerUserNo, e.$getCurrentUserNo())
                            } : null
                        });

                      case 6:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        handlePushReceiveShare: function() {
            var e;
            (null === (e = this.data.trackingData) || void 0 === e ? void 0 : e.pushReceiveBtn) && this.$click({
                page_el_sn: this.data.trackingData.pushReceiveBtn
            });
        },
        handleRemarkFilterChange: function(e) {
            var t = (0, o.jo)(e).item;
            t.title !== this.data.selectedRemarkFilter.title && (this.setData({
                selectedRemarkFilter: t
            }), this.reloadOrderList());
        },
        forwardAfterSaleList: function() {
            (0, o.n3)({
                url: o.ob.afterSalesList
            });
        }
    }
});