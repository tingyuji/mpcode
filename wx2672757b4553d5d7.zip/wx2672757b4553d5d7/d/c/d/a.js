var e = require("../../../$app"), t = require("../../../$page"), a = {
    ACTIVITY: "ACTIVITY",
    TIME: "TIME",
    REMARK: "REMARK"
};

(0, t.afb)({
    properties: {
        filterList: {
            type: Array,
            value: [ a.ACTIVITY, a.TIME, a.REMARK ]
        },
        selectActivity: {
            type: Object,
            value: {}
        },
        changeActivityPanelVisible: {
            type: Boolean,
            value: !1
        },
        changeTimePanelVisible: {
            type: Boolean,
            value: !1
        },
        timeLabel: {
            type: String,
            value: ""
        },
        startDateStr: {
            type: String,
            value: ""
        },
        endDateStr: {
            type: String,
            value: ""
        },
        selectedRemarkFilter: {
            type: Object,
            value: {}
        }
    },
    data: {
        REMARK_FILTER_LIST: t.zz,
        showRemarkPopover: !1,
        DISPLAY_TYPE: t.u9,
        FILTER_TYPE: a
    },
    methods: {
        showActivityPanel: function() {
            this.triggerEvent("showActivityPanel");
        },
        showTimePanel: function() {
            this.triggerEvent("showTimePanel");
        },
        openRemarkPopover: function() {
            this.setData({
                showRemarkPopover: !0
            });
        },
        handleCloseRemarkPopover: function() {
            this.setData({
                showRemarkPopover: !1
            });
        },
        handleRemarkFilterChange: function(t) {
            var a = (0, e.jo)(t).item;
            this.handleCloseRemarkPopover(), this.triggerEvent("handleRemarkFilterChange", {
                item: a
            });
        }
    }
});