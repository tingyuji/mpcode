var t = require("../../_/helpers/objectSpread2"), e = require("../../_/helpers/objectWithoutProperties"), r = require("../../$page"), a = require("../../$app"), i = [ "markStyle", "imgWidthRpx" ], n = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.markStyle, a = void 0 === r ? "" : r, n = t.imgWidthRpx, o = e(t, i), c = a.split(";").reduce(function(t, e) {
        var r = e.split(":").map(function(t) {
            return t.trim();
        });
        return 2 === r.length && (t[r[0]] = r[1]), t;
    }, o || {});
    if (n && 160 !== n) {
        var l = n / 160;
        c.transform = (c.transform || "") + " scale(".concat(l, ", ").concat(l, ")");
    }
    return Object.keys(c).reduce(function(t, e) {
        return c[e] ? t + "".concat(e, ":").concat(c[e], ";") : t;
    }, "");
};

(0, r.afb)({
    properties: {
        imgWidthRpx: {
            type: Number,
            value: 184
        },
        markInfo: {
            type: Object,
            value: {},
            observer: function() {
                this.init();
            }
        },
        defaultMarkInfo: {
            type: Object,
            value: {}
        },
        defaultThemeInfo: {
            type: Object,
            value: {}
        }
    },
    data: {
        markText: "",
        markStyle: ""
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e, r, i = this.data, o = i.imgWidthRpx, c = i.markInfo, l = i.defaultMarkInfo, m = i.defaultThemeInfo, u = t(t(t({}, l), m), c), f = u.markType, p = u.markText, d = u.defaultText, s = u.markStyle, k = u.fontColor, h = u.bgColor, g = u.markImg;
            f === a.bf.OFFICIAL ? this.setData({
                markStyle: n({
                    markStyle: s,
                    imgWidthRpx: o,
                    "background-image": g ? "url(".concat((0, a.jf)(g), ")") : ""
                }),
                markText: ""
            }) : this.setData({
                markStyle: n({
                    markStyle: s,
                    imgWidthRpx: o,
                    color: k || "",
                    "background-image": g ? (e = g, r = h, 'url("'.concat(e && r ? e.replace("fill=''", "fill='".concat(encodeURIComponent(r), "'")) : e, '")')) : ""
                }),
                markText: p || d || ""
            });
        }
    }
});