var e = require("../../$page");

(0, e.afb)({
    behaviors: [ e.afe ],
    externalClasses: [ "wrap-style" ],
    options: {
        addGlobalClass: !0
    },
    properties: {},
    data: {
        secAccuracy: 1
    },
    methods: {
        getTimeListenerConfigs: function() {
            var e = this;
            return [ {
                endTime: {
                    time: this.data.endTime,
                    callback: function() {
                        e.triggerEvent("onTimeEnd");
                    }
                }
            } ];
        }
    }
});