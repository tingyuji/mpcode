var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    properties: {
        COPY_LINK_ITEM: {
            type: Object,
            value: {}
        }
    },
    data: {
        pieceWidth: 375,
        currentIndex: 0,
        scaleRate: 0,
        previousmargin: 100,
        depth: .15,
        alphaDepth: .8
    },
    lifetimes: {},
    methods: {
        closeDialog: function() {
            this.triggerEvent("closeShareShortLink");
        },
        confirmCopyLinkPanel: function(e) {
            var t;
            this.triggerEvent("confirmCopyLinkPanel", null === (t = null == e ? void 0 : e.currentTarget) || void 0 === t ? void 0 : t.dataset);
        },
        handleSwiperChangePosition: function(e) {
            var i = (0, t.jo)(e).dx, a = this.data.pieceWidth, n = ((i = Math.abs(i)) / a).toFixed(2);
            this.setData({
                scaleRate: +n
            });
        },
        animationfinish: function(e) {
            var i = (0, t.jo)(e).current;
            this.setData({
                currentIndex: i,
                scaleRate: 0
            });
        }
    }
});