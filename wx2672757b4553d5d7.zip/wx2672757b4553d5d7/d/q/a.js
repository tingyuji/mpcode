var t = require("../../_/helpers/interopRequireDefault")(require("../../_/regenerator")), e = require("../../_/helpers/asyncToGenerator"), i = require("../../_/helpers/toConsumableArray"), a = require("../../_/helpers/objectSpread2"), r = require("../../$app"), n = require("../../$page");

(0, n.afb)({
    externalClasses: [ "item-class", "close-class", "img-class" ],
    originList: [],
    properties: {
        galleryUrl: {
            type: Array,
            value: [],
            observer: function(t) {
                var e = this.data, i = e.length, a = e.canEdit, n = e.hideAddBtn, l = e.countOneLine, s = e.showAddBtn;
                t.length < i && (a || !n || s) && (t = t.concat({
                    type: "add"
                }));
                var d = Math.ceil(t.length / l);
                this.originList = this.getSortList(t), this.setData({
                    lineCount: d,
                    list: (0, r.g1)(this.originList)
                });
            }
        },
        length: {
            type: Number,
            value: 9
        },
        hideAddBtn: {
            type: Boolean,
            value: !0
        },
        canEdit: {
            type: Boolean,
            value: !0
        },
        showAddBtn: {
            type: Boolean,
            value: !1
        },
        itemHeight: {
            type: Number,
            value: 200
        },
        itemWidth: {
            type: Number,
            value: 200
        },
        itemBorderRadius: {
            type: Number,
            value: 0
        },
        antiOptions: {
            type: Object,
            value: {}
        },
        grap: {
            type: Number,
            value: 14
        },
        noPreview: {
            type: Boolean,
            value: !1
        },
        countOneLine: {
            type: Number,
            value: 3
        },
        markInfo: {
            type: Object,
            value: {}
        },
        useDefaultUpload: {
            type: Boolean,
            value: !1
        },
        isRect: {
            type: Boolean,
            value: !0
        },
        addTitle: {
            type: String,
            value: "添加图片"
        },
        addBgImg: {
            type: String,
            value: ""
        },
        noGrayBg: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        list: [],
        ADD_TYPE: "add",
        lineCount: 1,
        draging: !1,
        targetUrl: "",
        lastIndex: 0,
        targetIndex: void 0
    },
    methods: {
        getSortList: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, i = e.keepIndex, n = void 0 !== i && i, l = this.data, s = l.itemHeight, d = l.itemWidth, o = l.grap, g = l.countOneLine;
            return t.map(function(t, e) {
                var i = Math.ceil((e + 1) % g) || g, l = Math.ceil((e + 1) / g);
                return a(a({}, t), {}, {
                    index: n ? t.index : e,
                    x: (0, r.qf)((i - 1) * (d + o)),
                    y: (0, r.qf)((l - 1) * s + Math.max(0, l - 1) * o)
                });
            });
        },
        handleTouchEnd: function() {
            this.data.draging && (this.originList = this.getSortList(this.data.list), this.setData({
                draging: !1,
                targetUrl: "",
                list: (0, r.g1)(this.originList)
            }), this.triggerEvent("onGalleryUrlChange", {
                galleryUrl: (0, r.g1)(this.originList).filter(function(t) {
                    return "add" !== t.type;
                })
            }));
        },
        handleDragStart: function(t) {
            var e = (0, r.jo)(t), i = e.index, a = e.url;
            this.data.draging || this.setData({
                targetUrl: a,
                targetIndex: i,
                lastIndex: i,
                draging: !0
            });
        },
        getOriginList: function() {
            return this.getSortList(this.data.list).filter(function(t) {
                return "add" !== t.type;
            });
        },
        handleCanNotEditAddClick: function() {
            var t = this.data, e = t.showAddBtn;
            t.canEdit || !e || this.triggerEvent("canNotEditAddClick");
        },
        addImage: function() {
            var t = this, e = this.data, a = e.draging, l = e.useDefaultUpload, s = e.length, d = e.galleryUrl, o = e.antiOptions, g = e.isRect, u = e.showAddBtn;
            if (e.canEdit || !u) {
                if (!a) {
                    var h = this.getOriginList();
                    l ? (0, n.aaq)(s - d.length, {
                        anti: !0,
                        isRect: g,
                        antiOptions: o,
                        onSizeChange: function(e) {
                            t.triggerEvent("onGalleryUrlChange", {
                                galleryUrl: [].concat(i(h), i(e))
                            });
                        }
                    }).catch(r.hm) : this.triggerEvent("addImage");
                }
            } else this.triggerEvent("canNotEditAddClick");
        },
        previewGalleries: function(t) {
            var e = this.data, i = e.list, a = e.noPreview, n = (0, r.jo)(t).index, l = i;
            if (l[n].showChangeHint) return this.changeImage(t);
            a || r.f3.previewImage({
                current: (0, r.iu)(l[n].url),
                urls: l.map(function(t) {
                    return (0, r.iu)(t.url);
                })
            }), this.triggerEvent("onImgClick", t.target.dataset);
        },
        changeImage: function(i) {
            var a = this;
            return e(t.default.mark(function e() {
                var l, s, d, o, g, u, h, c, v, p;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (l = a.data, s = l.useDefaultUpload, d = l.antiOptions, o = l.isRect, g = l.showAddBtn, 
                        u = l.canEdit, h = (0, r.jo)(i), c = h.index, u || !g) {
                            t.next = 5;
                            break;
                        }
                        return a.triggerEvent("canNotEditAddClick"), t.abrupt("return");

                      case 5:
                        if (!s) {
                            t.next = 16;
                            break;
                        }
                        return v = a.getOriginList(), t.next = 9, (0, n.aaq)(1, {
                            anti: !0,
                            isRect: o,
                            antiOptions: d
                        }).catch(r.hm);

                      case 9:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 12;
                            break;
                        }
                        t.t0 = [];

                      case 12:
                        (p = t.t0) && p[0] && (v.splice(c, 1, p[0]), a.triggerEvent("onGalleryUrlChange", {
                            galleryUrl: v
                        })), t.next = 17;
                        break;

                      case 16:
                        a.triggerEvent("changeImage", i.target.dataset);

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        },
        deleteGallery: function(t) {
            var e = this.data, i = e.useDefaultUpload, a = e.showAddBtn;
            if (e.canEdit || !a) if (i) {
                var n = (0, r.jo)(t).index, l = this.getOriginList();
                l.splice(n, 1), this.triggerEvent("onGalleryUrlChange", {
                    galleryUrl: l
                });
            } else this.triggerEvent("deleteGallery", t.target.dataset); else this.triggerEvent("canNotEditAddClick");
        },
        handleChange: function(t) {
            var e = (0, r.jo)(t), i = e.x, n = e.y, l = e.source, s = this.data, d = s.draging, o = s.grap, g = s.itemWidth, u = s.itemHeight, h = s.countOneLine, c = s.list, v = s.targetIndex, p = s.lastIndex;
            if ("touch" === l && d) {
                var f = Math.floor(((0, r.ov)(i) + g / 2) / (g + o)), y = Math.floor(((0, r.ov)(n) + u / 2) / (u + o)), m = Math.min(y * h + f, c.filter(function(t) {
                    return "add" !== t.type;
                }).length - 1);
                if (m !== p) {
                    var x = (0, r.g1)(this.originList);
                    if (v !== m) {
                        var E = x.splice(v, 1)[0];
                        x.splice(m, 0, E);
                    }
                    var L = this.getSortList(x, {
                        keepIndex: !0
                    });
                    this.setData(a({
                        lastIndex: m
                    }, L.reduce(function(t, e, i) {
                        return i !== m ? (t["list[".concat(i, "]")] = e, t) : (t["list[".concat(i, "].url")] = e.url, 
                        t);
                    }, {})));
                }
            }
        }
    }
});