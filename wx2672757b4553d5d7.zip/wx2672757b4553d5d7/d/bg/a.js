var e, a = require("../../_/helpers/interopRequireDefault"), t = require("../../_/helpers/defineProperty"), r = require("../../_/helpers/objectSpread2"), n = a(require("../../_/regenerator")), s = require("../../_/helpers/asyncToGenerator"), i = require("../../$app"), o = require("../../$page"), h = (0, 
i.k5)().windowWidth, c = (0, i.kj)().isMac, l = 0, u = 1, p = 0, d = 1, m = [ {
    id: p,
    title: "微信内部链接",
    desc: "（会话、朋友圈等）",
    examImg: (0, i.jm)("ktt/fn.png.slim.png"),
    selected: !0
}, {
    id: d,
    title: "微信外部链接",
    desc: "（短信、网页、邮件等场景）",
    examImg: (0, i.jm)("ktt/fo.png.slim.png")
} ];

!function(e) {
    e[e.shareCard = 0] = "shareCard", e[e.sharePoster = 1] = "sharePoster", e[e.shortLink = 2] = "shortLink", 
    e[e.officialAccount = 3] = "officialAccount", e[e.material = 4] = "material";
}(e || (e = {})), (0, o.afb)({
    externalClasses: [ "share-items-class", "offset-item-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        shareTrackingInfo: {
            type: Object,
            value: null
        },
        showShareCard: {
            type: Boolean,
            value: !0
        },
        type: {
            type: String,
            value: ""
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(a) {
                a ? (this.getPosterGray(), this.setData({
                    currentIndex: 0,
                    currentPanelItem: e.shareCard
                }), this.$currentPage && this.data.newVersion ? this.newSharePanelMethodsReq() : this.generateCard(), 
                this.checkShortLink(), this.sharePanelImpr(), this.handlePanelImpr(), this.data.externalLink && this.initStorageSet(), 
                this.calcClipPath()) : this.data.showShareImage && this.setData({
                    showShareImage: !1
                });
            }
        },
        canShowShortLink: {
            type: Boolean,
            value: !1
        },
        supportPreview: {
            type: Boolean,
            value: !1
        },
        shareInfo: {
            type: Object,
            value: {}
        },
        sharePosition: {
            type: String,
            value: "sharepanel"
        },
        shareParams: {
            type: Object,
            value: {}
        },
        relateInfo: {
            type: Object,
            value: {
                showEntry: !1,
                activityNo: "",
                userNo: ""
            },
            observer: function(e) {
                e && (null == e ? void 0 : e.showEntry) && this.calcClipPath();
            }
        },
        showPreviewImg: {
            type: Boolean,
            value: !1
        },
        noTimeline: {
            type: Boolean,
            value: !1
        },
        customMessageShare: {
            type: Boolean,
            value: !1
        },
        isServerRender: {
            type: Boolean,
            value: !0
        },
        preLoad: {
            type: Boolean,
            value: !0
        },
        newVersion: {
            type: Boolean,
            value: !1
        },
        showMmpMoments: {
            type: Boolean,
            value: !1
        },
        externalLink: {
            type: Boolean,
            value: !1
        },
        showActivityMaterial: {
            type: Boolean,
            value: !1
        },
        relatedMmpMoments: {
            type: Boolean,
            value: !1
        },
        collectionActivityNo: {
            type: String,
            value: ""
        },
        organizer: {
            type: Object,
            value: {}
        },
        supplyInfo: {
            type: Object,
            value: {}
        },
        alwaysFmtMomentsInfo: {
            type: Boolean,
            value: !1
        },
        resetShareImage: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showShareImage: !1,
        width: 630,
        height: 1156,
        isFrontendRender: !1,
        imageData: {},
        showCanvas: !1,
        dataShareInfo: null,
        name: "",
        imageUrl: "",
        generateFail: !1,
        currentPanelItem: e.shareCard,
        PanelItem: {
            shareCard: 0,
            sharePoster: 1,
            shortLink: 2,
            officialAccount: 3,
            material: 4
        },
        requestParams: {},
        currentIndex: 0,
        TRACKING: o.aca,
        COPY_LINK_ITEM: m,
        shareImage: null,
        showCopyLinkPanel: !1,
        showNewExternalTip: !1,
        copyLinkPanelZindex: {
            "z-index": 9999
        },
        recentName: "",
        showShortLink: !1,
        clipPathMap: {}
    },
    lifetimes: {
        attached: function() {
            this.setData({
                hasTabBar: (0, i.ly)()
            });
        }
    },
    methods: {
        initStorageSet: function() {
            try {
                var e = i.f3.getStorageSync(i.ct.sharePanelExternalLinkTip);
                e && this.setData({
                    showNewExternalTip: e
                });
            } catch (e) {}
        },
        newSharePanelMethodsReq: function() {
            var e = this;
            return s(n.default.mark(function a() {
                var t, r, s, i, o, h, c, l;
                return n.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (s = e.data, i = s.shareParams, o = s.type, s.supportPreview || null === (t = e.$currentPage) || void 0 === t || t.$prepareShare({
                            cardMsgFromServer: i
                        }, o || i.shareScene), !e.data.noTimeline) {
                            a.next = 4;
                            break;
                        }
                        return a.abrupt("return");

                      case 4:
                        return a.next = 6, null === (r = e.$currentPage) || void 0 === r ? void 0 : r.$prepareShare({
                            posterMsgFromServer: i
                        }, o || i.shareScene);

                      case 6:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 9;
                            break;
                        }
                        a.t0 = {};

                      case 9:
                        h = a.t0, c = h.nextPoster, l = void 0 === c ? {} : c, e.setData({
                            shareImage: {
                                url: l.imageUrl,
                                width: 630,
                                height: 878
                            }
                        });

                      case 13:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }))();
        },
        getActivityNo: function() {
            var e = this.data.shareInfo || {}, a = this.data.shareParams || {};
            return e.activityNo || a.collectionActivityNo || a.activityNo;
        },
        generateCard: function() {
            var e = this;
            return s(n.default.mark(function a() {
                var t, s, o, h, c, l, u, p;
                return n.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (e.data.preLoad) {
                            a.next = 3;
                            break;
                        }
                        return e.setData({
                            dataShareInfo: null
                        }), a.abrupt("return");

                      case 3:
                        return t = e.data.shareInfo || {}, s = e.data.shareParams || {}, o = e.getActivityNo(), 
                        h = s.path || t.path, c = r(r({}, t), {}, {
                            title: t.title || s.title,
                            imageUrl: t.imageUrl || s.imageUrl,
                            activityNo: o,
                            path: h,
                            trackShareRouterPosition: "sharePanel",
                            trackShareStatus: "failure",
                            trackShareStartTime: new Date().getTime(),
                            subActivityType: t.subActivityType || s.subActivityType
                        }), e.setData({
                            dataShareInfo: c
                        }), a.next = 11, e.$generalShareTicket({
                            noSignRetry: !0,
                            data: {
                                shareType: i.cs.SESSION,
                                shareScene: t.shareScene || s.shareScene || i.cr.CHAIN,
                                collectionActivityNo: o,
                                ownerUserNo: s && s.ownerUserNo,
                                parentOrderSn: s && s.parentOrderSn,
                                goodsId: s && s.goodsId,
                                orderGroupSn: s && s.orderGroupSn
                            }
                        }, !1).catch(i.hm);

                      case 11:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 14;
                            break;
                        }
                        a.t0 = {};

                      case 14:
                        l = a.t0, u = l.result, p = void 0 === u ? {} : u, c = r(r({}, c), {}, {
                            title: p && p.shareText,
                            imageUrl: p && p.imageUrl,
                            wxActivityId: p && p.wxActivityId || "",
                            shareResult: p,
                            trackShareStatus: "success",
                            shareMissionSn: p && p.gamePlaySn
                        }), e.setData({
                            dataShareInfo: c
                        });

                      case 19:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }))();
        },
        getPosterGray: function() {
            this.setData({
                isFrontendRender: !this.data.isServerRender && !c
            });
        },
        hide: function(e) {
            var a = this, t = (0, i.jo)((0, i.qh)(e, "detail") || {}, "closeType");
            setTimeout(function() {
                a.triggerEvent("close", {
                    closeType: t
                });
            }, 200);
        },
        handleCustomMessageShare: function(e) {
            var a = (0, i.jo)(e, "info"), t = this.data, r = t.supportPreview, n = t.customMessageShare, s = t.currentPanelItem, h = t.PanelItem;
            n ? ((0, i.g0)({
                page_el_sn: o.aca.cardSharePageElSn,
                extParams: {
                    ktt_share_style: this.data.name
                }
            }), this.triggerEvent("onCustomMessageShare", {
                customShareInfo: a
            })) : r && s !== h.shareCard && this.setData({
                currentPanelItem: h.shareCard,
                showShareImage: !1
            });
        },
        onTapScrollMultiCard: function() {
            this.hide();
        },
        onTapShare: function() {
            var e = this.data, a = e.shareTrackingInfo, t = e.name, r = e.recentName;
            a && (0, i.g0)({
                page_el_sn: a.share,
                extParams: {
                    activity_no: a.activityNo,
                    ktt_share_style: t,
                    recent_share_style: r
                }
            }), (0, i.g0)({
                page_el_sn: o.aca.cardSharePageElSn,
                extParams: {
                    ktt_share_style: t,
                    recent_share_style: r
                }
            }), this.hide();
        },
        closeShareImage: function(e) {
            this.setData({
                showShareImage: !1,
                shareImage: {}
            }), this.hide(e);
        },
        generatePoster: function(e) {
            this.setData({
                shareImage: e.detail,
                showShareImage: !0,
                showCanvas: !1,
                generateFail: !1
            });
        },
        generatePosterFail: function() {
            var e = this;
            return s(n.default.mark(function a() {
                var t, s;
                return n.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, e.$generalSharePoster({
                            data: r({
                                dataOnly: l
                            }, e.data.requestParams)
                        }).catch(i.hm);

                      case 2:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 5;
                            break;
                        }
                        a.t0 = {};

                      case 5:
                        if (t = a.t0, s = t.result, (0, i.l3)(), s) {
                            a.next = 10;
                            break;
                        }
                        return a.abrupt("return");

                      case 10:
                        e.setData({
                            showCanvas: !1,
                            showShareImage: !0,
                            generateFail: !0,
                            requestParams: {},
                            shareImage: {
                                url: s.imageUrl,
                                width: 630,
                                height: 878
                            }
                        });

                      case 11:
                      case "end":
                        return a.stop();
                    }
                }, a);
            }))();
        },
        createPoster: function() {
            var a = this.data, t = a.shareInfo, r = a.shareTrackingInfo, n = a.shareParams;
            this.setData({
                currentPanelItem: e.sharePoster
            }), r && (0, i.g0)({
                page_el_sn: r.poster || o.aca.posterSharePageElSn,
                extParams: {
                    activity_no: r.activityNo
                }
            }), (0, i.mg)(n || {}) && (0, i.mg)(t || {}) ? (0, i.ri)({
                title: "生成图片失败，请稍后再试",
                icon: "none"
            }) : this.data.newVersion ? this.setData({
                showShareImage: !0
            }) : (0, i.qh)(n, "multiShareParams") ? (this.triggerEvent("sharePosterbtnAction"), 
            this.setData({
                showShareImage: !0,
                shareImage: {
                    url: (0, i.qh)(n, "multiShareParams.sharePoster.imageUrl"),
                    width: 630,
                    height: 878
                }
            })) : this.reqShareComponent();
        },
        reqShareComponent: function() {
            var e = this;
            return s(n.default.mark(function a() {
                var s, o, h, c, p, d, m, g, f, v, S;
                return n.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return i.f3.showLoading({
                            title: "图片生成中..."
                        }), s = e.data, o = s.shareInfo, h = s.shareParams, c = s.sharePosition, (0, i.mg)(h) ? o.userNo ? (d = o.shareScene, 
                        e.setData({
                            shareImage: null
                        }), p = {
                            shareScene: d || (o.isSelf ? i.cr.CAPTAIN_SELF : i.cr.CAPTAIN),
                            ownerUserNo: o.isSelf ? "" : o.userNo,
                            params: o.params || {}
                        }) : p = {
                            shareScene: o.shareScene || i.cr.CHAIN,
                            collectionActivityNo: o.activityNo,
                            params: o.params || {}
                        } : p = h, m = r(r({
                            dataOnly: e.data.isFrontendRender ? u : l
                        }, p), {}, {
                            shareType: i.cs.TIMELINE
                        }), g = "".concat((0, i.qh)(e, "$currentPage.pageProperties.page_sn"), "_").concat(c || "sharepanel", "_poster"), 
                        m.transparentParams = r(r({}, m.transparentParams || {}), {}, t({}, i.gf.refShareSrc, g)), 
                        a.prev = 6, a.next = 9, e.$generalSharePoster({
                            data: m
                        });

                      case 9:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 12;
                            break;
                        }
                        a.t0 = {};

                      case 12:
                        f = a.t0, v = f.result, (0, i.l3)(), S = e.data.showMmpMoments && (null == v ? void 0 : v.momentsForWxVolist) || [], 
                        m.dataOnly === u ? e.setData({
                            showCanvas: !0,
                            imageData: v && v.imageData || {},
                            requestParams: p,
                            momentsForWxVolist: S
                        }) : e.setData({
                            showShareImage: !0,
                            shareImage: {
                                url: v && v.imageUrl,
                                width: 630,
                                height: 878
                            },
                            momentsForWxVolist: S
                        }), a.next = 24;
                        break;

                      case 19:
                        a.prev = 19, a.t1 = a.catch(6), (0, i.l3)(), (0, i.ri)({
                            title: "生成海报失败，请稍后再试",
                            icon: "none"
                        }), e.$error({
                            msg: "fail: $generalSharePoster",
                            e: a.t1
                        });

                      case 24:
                      case "end":
                        return a.stop();
                    }
                }, a, null, [ [ 6, 19 ] ]);
            }))();
        },
        currentIndexChange: function(e) {
            var a = (0, i.jo)(e), t = a.currentIndex, r = a.name, n = a.recentName;
            this.setData({
                currentIndex: t,
                name: r,
                recentName: n
            });
        },
        forwardRelateWechatPage: function() {
            var a = this.data.relateInfo;
            (0, i.g0)({
                page_el_sn: o.aca.insertPublicAcountPageElSn
            }), this.setData({
                currentPanelItem: e.officialAccount
            });
            var r = a || {}, n = r.activityNo, s = r.userNo, h = ((0, i.ll)() || {}).userNo, c = void 0 === h ? "" : h;
            this.$infoByBatch({
                msg: "forwardRelateWechatPage",
                data: {
                    relateInfo: a,
                    activity_no: n || "",
                    user_no: s || ""
                }
            }), (0, i.n5)({
                pageName: o.aiw.kttRelateWechat,
                params: t({
                    activity_no: n || "",
                    user_no: s || ""
                }, i.gf.refShareUserNo, c)
            }), this.data.supportPreview && this.hide();
        },
        saveImage: function(e) {
            var a = this, t = (0, i.jo)(e).imgUrl, r = this.data, n = r.shareImage, s = r.imageUrl, o = r.generateFail, h = t || s || (null == n ? void 0 : n.url), c = !1, l = /(\w+):\/\/tmp/.test(h), u = /https?:\/\/.*?\.com/.test(h);
            c = !!l || !u, (0, i.qk)(h, {
                needDownload: !c,
                successToast: "图片保存成功，可以去朋友圈分享啦"
            }).then(function() {
                a.setData({
                    generateFail: !1,
                    showShareImage: !1
                }), a.hide();
            }).catch(function(e) {
                a.$error({
                    name: "保存海报到相册失败: sharePanel",
                    data: {
                        imageUrl: h,
                        needDownload: !c || o
                    },
                    msg: e
                });
            });
        },
        checkShortLink: function() {
            var e = this;
            this.data.canShowShortLink && (0, i.fk)().then(function() {
                var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = a.result, r = void 0 === t ? {} : t, n = r.hasEntrance;
                e.setData({
                    showShortLink: !!n
                }), n && e.calcClipPath();
            }).catch(i.hm);
        },
        getShortLinkInfo: function() {
            var e, a, t = this.data, r = t.newVersion, n = t.type, s = t.dataShareInfo, i = t.shareParams, o = void 0 === i ? {} : i, h = t.sharePosition;
            return r ? null === (e = this.$currentPage) || void 0 === e ? void 0 : e.$share({
                type: n || o.shareScene
            }) : null === (a = this.$currentPage) || void 0 === a ? void 0 : a.onShareAppMessage({
                from: "",
                target: {
                    dataset: {
                        shareType: "custom",
                        type: n,
                        info: s,
                        currentIndex: this.data.currentIndex,
                        sharePosition: h,
                        shareWay: "shortLink"
                    }
                }
            });
        },
        handleCopyLink: function() {
            var a = this.data, t = a.externalLink, r = a.showNewExternalTip;
            if (this.setData({
                currentPanelItem: e.shortLink
            }), t) {
                var n = {
                    showCopyLinkPanel: !0,
                    showNewExternalTip: r
                };
                r || (i.f3.setStorageSync(i.ct.sharePanelExternalLinkTip, !0), n.showNewExternalTip = !0), 
                this.setData(n);
            } else this.genShortLink();
        },
        handleActivityMaterial: function() {
            var e = this.getActivityNo();
            (0, i.n3)({
                url: i.ob.activityFeaturedMaterial,
                params: t({}, i.gf.collectionActivityNo, e)
            });
        },
        genShortLink: function() {
            var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "复制成功，快去分享吧";
            (0, i.g0)({
                page_el_sn: o.aca.shortLinkPageElSn
            });
            var t = this.getShortLinkInfo();
            if (t && t.path) {
                var r = t.path.substr(1);
                return r = r.replace("ref_share_channel=message", "ref_share_channel=shortLink"), 
                (0, i.i3)({
                    data: {
                        pageUrl: r,
                        pageTitle: t.title || ""
                    }
                }).then(function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.result, n = void 0 === r ? {} : r, s = n.shortLink;
                    s ? i.f3.setClipboardData({
                        data: s
                    }).then(function() {
                        e.$showToast({
                            title: a
                        });
                    }).catch(i.hm) : e.$showToast({
                        title: "生成链接失败，请稍后重试"
                    });
                }).catch(function() {
                    e.$showToast({
                        title: "复制失败，请稍后重试"
                    });
                });
            }
            this.$showToast({
                title: "生成路径失败，请稍后重试"
            });
        },
        sharePanelImpr: function() {
            (0, i.l6)({
                page_el_sn: o.aca.cardSharePageElSn
            });
        },
        handlePanelImpr: function() {
            var e = this.data.shareTrackingInfo;
            e && e.share && this.$impr({
                page_el_sn: e.share,
                extParams: {
                    activity_no: e.activityNo
                }
            });
        },
        closeCopyLinkPanel: function() {
            this.setData({
                showCopyLinkPanel: !1
            });
        },
        handleLinkTypeSelect: function(e) {
            var a = (0, i.jo)(e).idx, t = this.data.COPY_LINK_ITEM, r = t[a];
            t.forEach(function(e) {
                e.selected = !1;
            }), r.selected = !0, this.setData({
                COPY_LINK_ITEM: t
            });
        },
        confirmCopyLinkPanel: function(e) {
            var a = this;
            return s(n.default.mark(function s() {
                var o, h, c, l, u, m, g, f, v, S, y, P, w, I;
                return n.default.wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (h = a.data, c = h.COPY_LINK_ITEM, l = h.sharePosition, u = (0, i.jo)(e), m = u.shareId, 
                        g = null === (o = c.find(function(e) {
                            return e.selected;
                        })) || void 0 === o ? void 0 : o.id, (m || g) !== p) {
                            n.next = 9;
                            break;
                        }
                        return n.next = 6, a.genShortLink("微信内部链接已复制成功");

                      case 6:
                        a.data.supportPreview && a.hide(e), n.next = 26;
                        break;

                      case 9:
                        if ((m || g) !== d) {
                            n.next = 26;
                            break;
                        }
                        if (v = a.getActivityNo(), S = (0, i.ll)() || {}, y = S.userNo, v) {
                            n.next = 15;
                            break;
                        }
                        return a.$showToast({
                            title: "缺少团号，请稍后重试"
                        }), n.abrupt("return");

                      case 15:
                        return P = "".concat((0, i.qh)(a, "$currentPage.pageProperties.page_sn"), "_").concat(l || "sharepanel", "_outshortlink"), 
                        n.next = 18, a.$baseRequest(r(r({}, i.i6), {}, {
                            data: {
                                scene: 6,
                                params: (f = {
                                    activity_no: v
                                }, t(f, i.gf.refShareSrc, P), t(f, i.gf.refShareUserNo, y), f)
                            }
                        }));

                      case 18:
                        if (w = n.sent, !(I = (0, i.qh)(w, "result.scheme") || "")) {
                            n.next = 24;
                            break;
                        }
                        i.f3.setClipboardData({
                            data: I
                        }).then(function() {
                            a.$showToast({
                                title: "微信外部链接复制成功，可在个人中心-推广链接查看数据"
                            }), a.data.supportPreview && a.hide(e);
                        }).catch(i.hm), n.next = 26;
                        break;

                      case 24:
                        return a.$showToast({
                            title: "生成链接失败，请稍后重试"
                        }), n.abrupt("return");

                      case 26:
                        a.setData({
                            showCopyLinkPanel: !1
                        });

                      case 27:
                      case "end":
                        return n.stop();
                    }
                }, s);
            }))();
        },
        calcClipPath: function() {
            var e = this.data, a = e.showShareCard, t = e.noTimeline, r = e.canShowShortLink, n = e.showShortLink, s = e.relateInfo, o = e.PanelItem, c = e.showActivityMaterial;
            if (e.supportPreview) {
                var l = [ {
                    type: o.shareCard,
                    show: a
                }, {
                    type: o.sharePoster,
                    show: !t
                }, {
                    type: o.shortLink,
                    show: r && n
                }, {
                    type: o.material,
                    show: c
                }, {
                    type: o.officialAccount,
                    show: null == s ? void 0 : s.showEntry
                } ];
                l = l.filter(function(e) {
                    return e.show;
                });
                var u = (0, i.qf)(96), p = l.length, d = (h - u * p) / (2 * p), m = Math.ceil((0, 
                i.qf)(270)), g = l.reduce(function(e, a, t) {
                    var r = (2 * t + 1) * d + (t + .5) * u - 10;
                    return e[a.type] = "0px 0px, ".concat(r, "px 0px, ").concat(r + 10, "px 10px, ").concat(r + 20, "px 0px, ").concat(h, "px 0px, ").concat(h, "px ").concat(m, "px,  0 ").concat(m, "px"), 
                    e;
                }, {});
                this.setData({
                    clipPathMap: g
                });
            }
        },
        handleMaterialClick: function() {
            var a = this.data.relatedMmpMoments;
            this.setData({
                currentPanelItem: e.material
            }), this.$click({
                page_el_sn: o.aca.activityMaterialElsn
            }), a && (this.hide(), this.triggerEvent("onGo2Material"));
        }
    }
});