var e = require("../../_/helpers/interopRequireDefault");

require("../../_/helpers/Arrayincludes");

var t = e(require("../../_/regenerator")), r = require("../../_/helpers/objectSpread2"), a = require("../../_/helpers/asyncToGenerator"), s = require("../../_/helpers/defineProperty"), n = require("../../$page"), i = require("../../$app"), c = [ n.sx.INDEX_ORDER_SUBSCRIBR.pageName, n.sx.ORDER_DETAIL_NORMAL_SUBSCRIBE.pageName ], u = [ n.sx.CAPTAIN.pageName, n.sx.ORDER_MANAGE.pageName, n.sx.ALL_ORDER_MANAGE.pageName, n.sx.PART_COMMISSION_MANAGER.pageName ], o = s({}, n.sx.ORDER_DETAIL_NORMAL_SUBSCRIBE.pageName, "permanentBarOrderDetail");

(0, n.afb)({
    externalClasses: [ "external-class", "public-bg", "container-class", "text-class", "delete-class", "button-class" ],
    behaviors: [ (0, n.afu)({
        mapState: {
            hasSubscribed: i.l1
        }
    }), n.amy ],
    showBarTimeMap: {},
    cancelOnSignIn: void 0,
    properties: {
        publicNumber: {
            type: Object,
            value: {
                pageName: "",
                userNo: "",
                action: 0,
                expectShowCd: ""
            }
        },
        refresh: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e && this.getSubscribeInfo();
            }
        },
        userNo: {
            type: String,
            value: "",
            observer: function(e) {
                e && this.getSubscribeInfo();
            }
        },
        collectionActivityNo: {
            type: String,
            value: ""
        },
        orderSn: {
            type: String,
            value: ""
        },
        notClose: {
            type: Boolean,
            value: !1
        },
        trackingData: {
            type: Object,
            value: null
        },
        subscribeScene: {
            type: Object,
            value: {}
        },
        isBrandHeader: {
            type: Boolean,
            value: !1
        },
        guideContainerStyle: {
            type: String,
            value: ""
        },
        onShowRefresh: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        ACTION: n.sw,
        ACTION_TYPE: n.sy,
        subscribeInfo: {},
        isSubscribed: !0,
        showBar: !0,
        showBarLimited: !1,
        publicNumber: void 0,
        templateList: []
    },
    currentPageName: "",
    pageLifetimes: {
        show: function() {
            var e = this;
            this.cancelOnSignIn && this.cancelOnSignIn(), this.cancelOnSignIn = i.f9.listen(i.f1.signIn, function() {
                e.data.onShowRefresh && e.getSubscribeInfo();
            });
        },
        hide: function() {
            this.cancelOnSignIn && this.cancelOnSignIn();
        }
    },
    lifetimes: {
        ready: function() {
            this.currentPageName = (0, i.qh)(this, "$currentPage.pageProperties.page_name") || "";
        },
        detached: function() {
            this.cancelOnSignIn && this.cancelOnSignIn();
        }
    },
    methods: {
        getSubscribeInfo: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var s, c, u, o, l, p;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return s = e.data, c = s.publicNumber, u = s.userNo, t.prev = 1, t.next = 4, e.$baseRequest(r(r({}, i.px), {}, {
                            data: r(r({}, c), {}, {
                                userNo: u
                            })
                        }));

                      case 4:
                        o = t.sent, l = o.result, (p = (null == l ? void 0 : l.action) === n.sy.NONE) && e.triggerEvent("closeDialog"), 
                        e.setData({
                            subscribeInfo: l,
                            isSubscribed: 1 === l.subscribeStatus,
                            showBarLimited: e.barFreezeStatus()
                        }), (0, i.hk)((0, i.qw)(p)), e.triggerEvent("update"), t.next = 16;
                        break;

                      case 13:
                        t.prev = 13, t.t0 = t.catch(1), e.$error({
                            e: t.t0,
                            msg: "getSubscribeInfo fail publicNumberGuide"
                        });

                      case 16:
                        e.getSubscribeData();

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, a, null, [ [ 1, 13 ] ]);
            }))();
        },
        handleAddSubscribe: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var s, n, c;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (s = e.data.userNo) {
                            t.next = 5;
                            break;
                        }
                        return (0, i.ri)({
                            title: "订阅失败，请稍后再试",
                            icon: "none"
                        }), e.close({
                            isSuccess: !1
                        }), t.abrupt("return");

                      case 5:
                        return t.prev = 5, t.next = 8, e.$baseRequest(r(r({}, i.rw), {}, {
                            data: {
                                user_no: s,
                                type: 1
                            }
                        }));

                      case 8:
                        if ((0, i.ri)({
                            title: "订阅成功",
                            icon: "none"
                        }), n = e.data.subscribeInfo, c = n.mpArticleUrl, 0 !== n.subscribeStatus) {
                            t.next = 13;
                            break;
                        }
                        return t.next = 13, e.jumpArticle(c);

                      case 13:
                        e.close(), t.next = 19;
                        break;

                      case 16:
                        t.prev = 16, t.t0 = t.catch(5), e.$error({
                            e: t.t0,
                            msg: "subscribe fail"
                        });

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, a, null, [ [ 5, 16 ] ]);
            }))();
        },
        subscribeBtnImpr: function() {
            var e = this.data.publicNumber.id;
            e && this.$impr({
                page_el_sn: e,
                extParams: {
                    popid: 1
                }
            });
        },
        barCloseBtnImpr: function() {
            var e = this.data.publicNumber.closePageElSn;
            e && this.$impr({
                page_el_sn: e,
                extParams: {
                    popid: 1
                }
            });
        },
        handleClose: function(e) {
            this.standardLogClick(e), this.close({
                isSuccess: !1
            });
        },
        close: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.isSuccess, r = void 0 === t || t, a = this.data, o = a.subscribeInfo, l = a.notClose, p = a.publicNumber, b = p.pageName, f = p.action, d = p.closePageElSn;
            if (o.action = n.sy.NONE, this.setData({
                subscribeInfo: o,
                showBar: !1,
                showBarLimited: !1
            }), l || (0, i.hk)((0, i.qw)(!0)), this.triggerEvent("closeDialog"), r && f === n.sy.BAR && (d && this.$click({
                page_el_sn: d,
                extParams: {
                    popid: 1
                }
            }), c.concat(u).includes(b))) {
                var g = c.includes(b) ? 2592e5 : 2592e6;
                Object.assign(this.showBarTimeMap || {}, s({}, b, (0, i.js)() + g)), i.f3.setStorageSync(i.ct.subscibeBarFreezeTimeMap, this.showBarTimeMap);
            }
        },
        subscribe: (0, n.afc)(function(e) {
            var t = this.data, r = t.subscribeInfo, a = r.mpArticleUrl, s = r.action, c = t.isSubscribed, u = (0, 
            i.jo)(e).subscribeType;
            this.$click({
                page_el_sn: this.data.publicNumber.id,
                extParams: {
                    popid: s === n.sy.DIALOG || s === n.sy.BAR ? 1 : 0
                }
            }), s === n.sy.BAR && c ? this.guideSubscribe() : s === n.sy.GROUP_BAR || s === n.sy.GROUP_DIALOG ? this.handleAddSubscribe() : this.jumpArticle(a), 
            this.doClickLog(), u && this.triggerEvent("closeDialog", {
                subscribe: !0
            });
        }, 1e3),
        move: function() {},
        doClickLog: function() {
            var e = this.data.trackingData;
            e && this.$click({
                page_el_sn: e.subscribeMessageBtn
            });
        },
        jumpArticle: function(e) {
            var r = this;
            return a(t.default.mark(function a() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, r.goOfficialAccountsTrack();

                      case 2:
                        (0, i.n3)({
                            url: i.ob.mpArticle,
                            params: s({}, i.gf.mpSrc, e)
                        });

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        guideSubscribe: function() {
            var e = this;
            return a(t.default.mark(function r() {
                var a, s, c, u, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (a = e.data.templateList, (s = void 0 === a ? [] : a).length) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return", e.$infoByBatch({
                            msg: "publicNumberGuide guideSubscribe templateList empty"
                        }));

                      case 3:
                        return t.next = 5, (0, i.e7)(s);

                      case 5:
                        if (c = t.sent, u = c.canUseRequestSubscribeFunc, o = c.mainSwitch, (0, n.abz)({
                            canUseRequestSubscribeFunc: u,
                            mainSwitch: o
                        }), u && o) {
                            t.next = 11;
                            break;
                        }
                        return t.abrupt("return");

                      case 11:
                        (0, n.ame)({
                            templateList: e.data.templateList,
                            scene: "subscribeBar ".concat(e.data.publicNumber.pageName),
                            someAceeptSuccess: !0,
                            directLog: !0,
                            onCheckSubscribeAllow: function(t) {
                                t.allAuth || e.triggerEvent("clickSubscribeButton");
                            },
                            onComplete: function() {
                                e.triggerEvent("onCompleteSbuscribe");
                            },
                            onAcceptSuccess: function() {
                                (0, i.ri)({
                                    title: "订阅成功",
                                    icon: "none"
                                }), e.close(), e.triggerEvent("subscribeSuccess", {
                                    success: !0
                                });
                            },
                            onSomeAceeptSuccess: function() {
                                (0, i.ri)({
                                    title: "部分订阅成功，可前往小程序设置查看消息订阅详情",
                                    icon: "none"
                                }), e.close(), e.triggerEvent("subscribeSuccess", {
                                    success: !0
                                });
                            },
                            onBeforeCheckReject: function() {
                                e.triggerEvent("subscribeSuccess", {
                                    success: !1
                                }), (0, i.ri)({
                                    title: "操作失败，请前往小程序设置勾选消息类型",
                                    icon: "none"
                                });
                            }
                        });

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        goOfficialAccountsTrack: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var s, n, i, c;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return s = e.data, n = s.collectionActivityNo, i = s.userNo, c = s.orderSn, t.prev = 1, 
                        t.next = 4, e.$baseRequest({
                            url: "/api/ktt_extopen/wx/official/account/prepare_subscribe",
                            convertRequestToSnake: !0,
                            convertToCamel: !0,
                            data: r(r({}, e.data.publicNumber), {}, {
                                userNo: i,
                                activityNo: n,
                                parentOrderSn: c,
                                pageName: e.currentPageName
                            })
                        });

                      case 4:
                        t.next = 9;
                        break;

                      case 6:
                        t.prev = 6, t.t0 = t.catch(1), e.$error({
                            e: t.t0,
                            msg: "official account track fail"
                        });

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, a, null, [ [ 1, 6 ] ]);
            }))();
        },
        getSubscribeData: function() {
            var e = this;
            return a(t.default.mark(function r() {
                var a, s, n, c, u;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, i.gm.getInstance();

                      case 2:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 5;
                            break;
                        }
                        t.t0 = {};

                      case 5:
                        a = t.t0, s = e.data.publicNumber, c = o[null == (n = void 0 === s ? {} : s) ? void 0 : n.pageName] || "permanentBar", 
                        u = (0, i.qh)(a, "templateVoMap.".concat(c)) || [], e.setData({
                            templateList: u
                        });

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        barFreezeStatus: function() {
            var e = this, t = !0, r = this.data.publicNumber, a = Date.now();
            if (this.showBarTimeMap = wx.getStorageSync(i.ct.subscibeBarFreezeTimeMap) || {}, 
            c.includes(r.pageName)) t = (this.showBarTimeMap[r.pageName] || a) <= a; else if (u.includes(r.pageName)) {
                t = u.reduce(function(t, r) {
                    var a = e.showBarTimeMap[r];
                    return a && a >= t && (t = a), t;
                }, a) <= a;
            }
            return t;
        }
    }
});