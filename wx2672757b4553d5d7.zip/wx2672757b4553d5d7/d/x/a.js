var e = require("../../$app");

(0, require("../../$page").afb)({
    externalClasses: [ "content-class", "wrap-class", "cancel-class", "modal-opts-class" ],
    _wxModalEventId: "",
    properties: {
        cancelText: String,
        confirmText: String,
        confirmOpenType: {
            type: String,
            value: ""
        },
        cancelOpenType: {
            type: String,
            value: ""
        },
        overHeader: {
            type: Boolean,
            value: !1
        },
        canBgClose: {
            type: Boolean,
            value: !1
        },
        overDialog: {
            type: Boolean,
            value: !1
        },
        wxModal: {
            type: Boolean,
            value: !1
        },
        title: {
            type: String,
            value: ""
        },
        content: {
            type: String,
            value: ""
        },
        customWXTitleSlot: {
            type: Boolean,
            value: !1
        },
        customWXContentSlot: {
            type: Boolean,
            value: !1
        },
        showClose: {
            type: Boolean,
            value: !1
        },
        show: {
            type: Boolean,
            value: !1
        },
        highlightBtn: {
            type: Boolean,
            value: !1
        },
        lighterMask: {
            type: Boolean,
            value: !1
        },
        buttonNoWrap: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        move: function() {},
        onClose: function(t) {
            var o = (0, e.jo)(t).fromBg;
            o && !this.data.canBgClose || (this._wxModalAction("close"), this.triggerEvent("close", {
                fromBg: o
            }));
        },
        onCancel: function() {
            this._wxModalAction("cancel"), this.triggerEvent("cancel");
        },
        onConfirm: function() {
            this._wxModalAction("confirm"), this.triggerEvent("confirm");
        },
        showModal: function(t) {
            var o = this, n = t.title, a = t.content, l = t.cancelText, c = t.confirmText, i = t.success, s = t.complete;
            return this.setData({
                show: !0,
                title: n,
                content: a,
                cancelText: l,
                confirmText: c
            }), this._wxModalEventId = "_wxModal_".concat((0, e.fz)()), new Promise(function(t) {
                e.f9.listenOnce(o._wxModalEventId, function(e) {
                    o._wxModalEventId = "", o.setData({
                        show: !1
                    }), i && i(), s && s(), t({
                        confirm: "confirm" === e,
                        cancel: "cancel" === e,
                        close: "close" === e
                    });
                });
            });
        },
        _wxModalAction: function(t) {
            this._wxModalEventId && e.f9.triggerOnce(this._wxModalEventId, t);
        },
        getPhoneNumber: function(e) {
            this.triggerEvent("getPhoneNumber", e);
        }
    }
});