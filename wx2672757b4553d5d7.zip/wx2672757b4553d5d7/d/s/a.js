var e = require("../../$page"), t = require("../../$app");

(0, e.afb)({
    externalClasses: [ "external-class" ],
    properties: {
        useOrigin: {
            type: Boolean,
            value: !1
        },
        externalStyle: {
            type: String,
            value: ""
        },
        noProcessUrl: {
            type: Boolean,
            value: !1
        },
        src: {
            type: String,
            observer: function(e, a) {
                var r = e, i = this.data, s = i.quality, l = i.resizeWidth, o = i.resizeMaxWidth, n = i.webp, u = i.optimize, h = i.useOrigin, p = i.watermark, d = i.noProcessUrl, v = (0, 
                t.kc)(), y = r.match(/\.webp$/);
                if (d || r.indexOf("http://tmp") > -1) this.setData({
                    url: e,
                    webpEnable: !(!v || !y)
                }); else {
                    var m = v && n && (!l || l > 335);
                    h && (r = (0, t.iu)(r), m = !1);
                    var b = v && (m || y);
                    u ? this.setData({
                        url: (0, t.or)(r, {
                            resizeWidth: l,
                            resizeMaxWidth: o,
                            webpEnable: m,
                            quality: s,
                            watermark: p
                        }),
                        webpEnable: !!b
                    }) : this.setData({
                        url: (0, t.l5)(r),
                        webpEnable: !!b
                    }), e !== a && this.setData({
                        loaded: !1
                    });
                }
            },
            value: ""
        },
        errorSrc: {
            type: String,
            value: ""
        },
        lazyLoad: {
            type: Boolean,
            value: !1
        },
        quality: {
            type: Number,
            value: 80
        },
        mode: {
            type: String,
            value: "scaleToFill"
        },
        optimize: {
            type: Boolean,
            value: !0
        },
        resizeWidth: {
            type: Number,
            value: 0
        },
        resizeMaxWidth: {
            type: Number,
            value: 0
        },
        webp: {
            type: Boolean,
            value: !0
        },
        watermark: {
            type: Object,
            value: {}
        },
        showImgLoading: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        url: "",
        webpEnable: !1,
        retryTimes: 0,
        loaded: !1
    },
    methods: {
        imgLoadFinish: function(e) {
            this.setData({
                loaded: !0
            }), this.triggerEvent("imgLoadFinish", {
                e: e
            }), this.data.retryTimes && this.$info({
                msg: "图片加载重试成功".concat((0, t.lg)(this.data.url))
            });
        },
        handleError: function(e) {
            var a = this.data, r = a.url, i = a.errorSrc;
            if (this.setData({
                loaded: !0
            }), t._ > this.data.retryTimes) {
                ++this.data.retryTimes;
                var s = (0, t.ec)(r);
                s && this.setData({
                    url: s
                });
            } else i && r !== i && this.setData({
                url: i
            });
            this.$info({
                msg: "图片加载失败，需要重试 ".concat(r)
            }), this.triggerEvent("onError", {
                error: e
            });
        }
    }
});