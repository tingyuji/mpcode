var e, o, t = require("../../_/helpers/typeof");

module.exports = (e = {}, o = function(o, s) {
    if (!e[o]) return require(s);
    if (!e[o].status) {
        var r = e[o].m;
        r._exports = r._tempexports;
        var n = Object.getOwnPropertyDescriptor(r, "exports");
        n && n.configurable && Object.defineProperty(r, "exports", {
            set: function(e) {
                "object" === t(e) && e !== r._exports && (r._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(o) {
                    r._exports[o] = e[o];
                })), r._tempexports = e;
            },
            get: function() {
                return r._tempexports;
            }
        }), e[o].status = 1, e[o].func(e[o].req, r, r.exports);
    }
    return e[o].m.exports;
}, function(o, t, s) {
    e[o] = {
        status: 0,
        func: t,
        req: s,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1688393929386, function(e, o, s) {
    var r = e("requires-port"), n = e("querystringify"), a = /^[\x00-\x20\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+/, p = /[\n\r\t]/g, c = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//, i = /:\d+$/, l = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i, u = /^[a-zA-Z]:/;
    function h(e) {
        return (e || "").toString().replace(a, "");
    }
    var f = [ [ "#", "hash" ], [ "?", "query" ], function(e, o) {
        return w(o.protocol) ? e.replace(/\\/g, "/") : e;
    }, [ "/", "pathname" ], [ "@", "auth", 1 ], [ NaN, "host", void 0, 1, 1 ], [ /:(\d*)$/, "port", void 0, 1 ], [ NaN, "hostname", void 0, 1, 1 ] ], m = {
        hash: 1,
        query: 1
    };
    function d(e) {
        var o, s = ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}).location || {}, r = {}, n = t(e = e || s);
        if ("blob:" === e.protocol) r = new x(unescape(e.pathname), {}); else if ("string" === n) for (o in r = new x(e, {}), 
        m) delete r[o]; else if ("object" === n) {
            for (o in e) o in m || (r[o] = e[o]);
            void 0 === r.slashes && (r.slashes = c.test(e.href));
        }
        return r;
    }
    function w(e) {
        return "file:" === e || "ftp:" === e || "http:" === e || "https:" === e || "ws:" === e || "wss:" === e;
    }
    function g(e, o) {
        e = (e = h(e)).replace(p, ""), o = o || {};
        var t, s = l.exec(e), r = s[1] ? s[1].toLowerCase() : "", n = !!s[2], a = !!s[3], c = 0;
        return n ? a ? (t = s[2] + s[3] + s[4], c = s[2].length + s[3].length) : (t = s[2] + s[4], 
        c = s[2].length) : a ? (t = s[3] + s[4], c = s[3].length) : t = s[4], "file:" === r ? c >= 2 && (t = t.slice(2)) : w(r) ? t = s[4] : r ? n && (t = t.slice(2)) : c >= 2 && w(o.protocol) && (t = s[4]), 
        {
            protocol: r,
            slashes: n || w(r),
            slashesCount: c,
            rest: t
        };
    }
    function x(e, o, s) {
        if (e = (e = h(e)).replace(p, ""), !(this instanceof x)) return new x(e, o, s);
        var a, c, i, l, m, y, b = f.slice(), v = t(o), C = this, _ = 0;
        for ("object" !== v && "string" !== v && (s = o, o = null), s && "function" != typeof s && (s = n.parse), 
        a = !(c = g(e || "", o = d(o))).protocol && !c.slashes, C.slashes = c.slashes || a && o.slashes, 
        C.protocol = c.protocol || o.protocol || "", e = c.rest, ("file:" === c.protocol && (2 !== c.slashesCount || u.test(e)) || !c.slashes && (c.protocol || c.slashesCount < 2 || !w(C.protocol))) && (b[3] = [ /(.*)/, "pathname" ]); _ < b.length; _++) "function" != typeof (l = b[_]) ? (i = l[0], 
        y = l[1], i != i ? C[y] = e : "string" == typeof i ? ~(m = "@" === i ? e.lastIndexOf(i) : e.indexOf(i)) && ("number" == typeof l[2] ? (C[y] = e.slice(0, m), 
        e = e.slice(m + l[2])) : (C[y] = e.slice(m), e = e.slice(0, m))) : (m = i.exec(e)) && (C[y] = m[1], 
        e = e.slice(0, m.index)), C[y] = C[y] || a && l[3] && o[y] || "", l[4] && (C[y] = C[y].toLowerCase())) : e = l(e, C);
        s && (C.query = s(C.query)), a && o.slashes && "/" !== C.pathname.charAt(0) && ("" !== C.pathname || "" !== o.pathname) && (C.pathname = function(e, o) {
            if ("" === e) return o;
            for (var t = (o || "/").split("/").slice(0, -1).concat(e.split("/")), s = t.length, r = t[s - 1], n = !1, a = 0; s--; ) "." === t[s] ? t.splice(s, 1) : ".." === t[s] ? (t.splice(s, 1), 
            a++) : a && (0 === s && (n = !0), t.splice(s, 1), a--);
            return n && t.unshift(""), "." !== r && ".." !== r || t.push(""), t.join("/");
        }(C.pathname, o.pathname)), "/" !== C.pathname.charAt(0) && w(C.protocol) && (C.pathname = "/" + C.pathname), 
        r(C.port, C.protocol) || (C.host = C.hostname, C.port = ""), C.username = C.password = "", 
        C.auth && (~(m = C.auth.indexOf(":")) ? (C.username = C.auth.slice(0, m), C.username = encodeURIComponent(decodeURIComponent(C.username)), 
        C.password = C.auth.slice(m + 1), C.password = encodeURIComponent(decodeURIComponent(C.password))) : C.username = encodeURIComponent(decodeURIComponent(C.auth)), 
        C.auth = C.password ? C.username + ":" + C.password : C.username), C.origin = "file:" !== C.protocol && w(C.protocol) && C.host ? C.protocol + "//" + C.host : "null", 
        C.href = C.toString();
    }
    x.prototype = {
        set: function(e, o, t) {
            var s = this;
            switch (e) {
              case "query":
                "string" == typeof o && o.length && (o = (t || n.parse)(o)), s[e] = o;
                break;

              case "port":
                s[e] = o, r(o, s.protocol) ? o && (s.host = s.hostname + ":" + o) : (s.host = s.hostname, 
                s[e] = "");
                break;

              case "hostname":
                s[e] = o, s.port && (o += ":" + s.port), s.host = o;
                break;

              case "host":
                s[e] = o, i.test(o) ? (o = o.split(":"), s.port = o.pop(), s.hostname = o.join(":")) : (s.hostname = o, 
                s.port = "");
                break;

              case "protocol":
                s.protocol = o.toLowerCase(), s.slashes = !t;
                break;

              case "pathname":
              case "hash":
                if (o) {
                    var a = "pathname" === e ? "/" : "#";
                    s[e] = o.charAt(0) !== a ? a + o : o;
                } else s[e] = o;
                break;

              case "username":
              case "password":
                s[e] = encodeURIComponent(o);
                break;

              case "auth":
                var p = o.indexOf(":");
                ~p ? (s.username = o.slice(0, p), s.username = encodeURIComponent(decodeURIComponent(s.username)), 
                s.password = o.slice(p + 1), s.password = encodeURIComponent(decodeURIComponent(s.password))) : s.username = encodeURIComponent(decodeURIComponent(o));
            }
            for (var c = 0; c < f.length; c++) {
                var l = f[c];
                l[4] && (s[l[1]] = s[l[1]].toLowerCase());
            }
            return s.auth = s.password ? s.username + ":" + s.password : s.username, s.origin = "file:" !== s.protocol && w(s.protocol) && s.host ? s.protocol + "//" + s.host : "null", 
            s.href = s.toString(), s;
        },
        toString: function(e) {
            e && "function" == typeof e || (e = n.stringify);
            var o, s = this, r = s.host, a = s.protocol;
            a && ":" !== a.charAt(a.length - 1) && (a += ":");
            var p = a + (s.protocol && s.slashes || w(s.protocol) ? "//" : "");
            return s.username ? (p += s.username, s.password && (p += ":" + s.password), p += "@") : s.password ? (p += ":" + s.password, 
            p += "@") : "file:" !== s.protocol && w(s.protocol) && !r && "/" !== s.pathname && (p += "@"), 
            (":" === r[r.length - 1] || i.test(s.hostname) && !s.port) && (r += ":"), p += r + s.pathname, 
            (o = "object" === t(s.query) ? e(s.query) : s.query) && (p += "?" !== o.charAt(0) ? "?" + o : o), 
            s.hash && (p += s.hash), p;
        }
    }, x.extractProtocol = g, x.location = d, x.trimLeft = h, x.qs = n, o.exports = x;
}, function(e) {
    return o({}[e], e);
}), o(1688393929386));