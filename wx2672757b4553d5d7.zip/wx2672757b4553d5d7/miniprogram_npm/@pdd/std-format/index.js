var e, t, o = require("../../../_/helpers/typeof");

module.exports = (e = {}, t = function(t, n) {
    if (!e[t]) return require(n);
    if (!e[t].status) {
        var r = e[t].m;
        r._exports = r._tempexports;
        var i = Object.getOwnPropertyDescriptor(r, "exports");
        i && i.configurable && Object.defineProperty(r, "exports", {
            set: function(e) {
                "object" === o(e) && e !== r._exports && (r._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    r._exports[t] = e[t];
                })), r._tempexports = e;
            },
            get: function() {
                return r._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, r, r.exports);
    }
    return e[t].m.exports;
}, function(t, o, n) {
    e[t] = {
        status: 0,
        func: o,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1688393929383, function(e, t, o) {
    var n = e("@pdd/emoji").stringWithEmoji, r = 100, i = 1;
    function s(e, t) {
        for (var o = (t = t || 2) - (e = (e || "").toString()).length, n = 0; n < o; n++) e = "0" + e;
        return e;
    }
    o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.leftPad = s, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    });
    var u = o.leftPadZero = s;
    function a(e, t) {
        e = parseFloat(e, 10) || 0, (t = t || i) === r && (e /= 100);
        var o = (e = e.toString()).indexOf(".");
        if (o >= 0) {
            for (var n = (e = e.slice(0, o + 3)).length - 1; "0" === e.charAt(n) && n > 0; ) n--;
            "." === (e = e.slice(0, n + 1)).charAt(e.length - 1) && (e = e.slice(0, e.length - 1));
        }
        return e;
    }
    function d(e) {
        if ((e = parseInt(e, 10) || 0) < 9999) return e.toString();
        if (e <= 99999) {
            var t = parseInt(e / 1e3, 10);
            return parseInt(t / 10, 10) + "." + t % 10 + "万";
        }
        return parseInt(e / 1e4, 10).toString() + "万";
    }
    function h(e) {
        return "0.0" === (e = (e = parseFloat(e, 10) || 0).toFixed(1)) && (e = "0.1"), e;
    }
    function l(e) {
        e = parseInt(e, 10) || 0;
        var t = new Date(1e3 * e);
        return {
            year: t.getFullYear().toString(),
            month: (t.getMonth() + 1).toString(),
            date: t.getDate().toString(),
            hours: t.getHours().toString(),
            minutes: t.getMinutes().toString(),
            seconds: t.getSeconds().toString(),
            day: t.getDay().toString()
        };
    }
    function m(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "YYYY-MM-dd hh:mm:ss";
        e = parseInt(e, 10);
        var o = parseInt(Date.now() / 1e3, 10);
        e || (e = o), e.toString().length - o.toString().length == 3 && (e = parseInt(e / 1e3, 10));
        var n = l(e), r = {
            "Y+": n.year,
            "M+": n.month,
            "d+": n.date,
            "h+": n.hours,
            "m+": n.minutes,
            "s+": n.seconds
        };
        for (var i in r) if (new RegExp("(".concat(i, ")")).test(t)) {
            var s = "".concat(r[i]);
            RegExp.$1 && ("Y+" === i ? s = s.substr(s.length - RegExp.$1.length) : RegExp.$1.length > 1 && 1 === s.length && (s = "0".concat(s)), 
            t = t.replace(RegExp.$1, s));
        }
        return t;
    }
    function _(e, t) {
        e || (e = parseInt(Date.now() / 1e3, 10)), t = t || "YYYY-M-d h:m";
        var o = l(e);
        return "YYYY-MM-dd" === t ? [ o.year, s(o.month), s(o.date) ].join("-") : "YYYY.M.d" === t ? [ o.year, o.month, o.date ].join(".") : "YYYY.MM.dd" === t ? [ o.year, s(o.month), s(o.date) ].join(".") : "hh:mm" === t ? [ s(o.hours), s(o.minutes) ].join(":") : "hh" === t ? s(o.hours) : "MM-dd hh:mm" === t ? [ [ s(o.month), s(o.date) ].join("-"), [ s(o.hours), s(o.minutes) ].join(":") ].join(" ") : "M.d hh:mm" === t ? [ [ o.month, o.date ].join("."), [ s(o.hours), s(o.minutes) ].join(":") ].join(" ") : "M月d日" === t ? o.month + "月" + o.date + "日" : "M月d日 hh:mm" === t ? [ s(o.month) + "月" + s(o.date) + "日", [ s(o.hours), s(o.minutes) ].join(":") ].join(" ") : "Y年M月d日 hh:mm" === t ? [ o.year + "年" + s(o.month) + "月" + s(o.date) + "日", [ s(o.hours), s(o.minutes) ].join(":") ].join(" ") : "YYYY-MM-dd hh:mm" === t ? [ [ o.year, s(o.month), s(o.date) ].join("-"), [ s(o.hours), s(o.minutes) ].join(":") ].join(" ") : "YYYY-MM-dd hh:mm:ss" === t ? [ [ o.year, s(o.month), s(o.date) ].join("-"), [ s(o.hours), s(o.minutes), s(o.seconds) ].join(":") ].join(" ") : "YYYY-M-d" === t ? [ o.year, s(o.month), s(o.date) ].join("-") : "hh:mm:ss" === t ? [ s(o.hours), s(o.minutes), s(o.seconds) ].join(":") : "YYYY/M/d" === t ? [ o.year, s(o.month), s(o.date) ].join("/") : "MM.dd" === t ? [ s(o.month), s(o.date) ].join(".") : "Y年M月d日" === t ? [ o.year + "年" + o.month + "月" + o.date + "日" ].join("") : "MM月dd日" === t ? s(o.month) + "月" + s(o.date) + "日" : "YYYY年MM月dd日" === t ? o.year + "年" + s(o.month) + "月" + s(o.date) + "日" : "MM月dd日hh:mm:ss" === t ? s(o.month) + "月" + s(o.date) + "日" + [ s(o.hours), s(o.minutes), s(o.seconds) ].join(":") : [ [ o.year, o.month, o.date ].join("-"), [ o.hours, s(o.minutes) ].join(":") ].join(" ");
    }
    function c(e, t) {
        var o = Math.max(parseInt(t, 10) - parseInt(e, 10), 0);
        return o >= 86400 ? Math.floor(o / 86400) + "天" : o >= 3600 ? Math.floor(o / 3600) + "小时" : o >= 60 ? Math.floor(o / 60) + "分钟" : o + "秒";
    }
    function p(e, t, o) {
        return o ? e : t + "元 " + e;
    }
    function f(e, t, o) {
        e = e || {}, t = t || Object.keys(e);
        var n = "function" == typeof o;
        return (t || []).forEach(function(t) {
            if (e.hasOwnProperty(t)) {
                var r = e[t], i = t.replace(/\_./g, function(e) {
                    return e.replace(/\_/g, "").toUpperCase();
                });
                i !== t && (e[i] = n ? o(r) : r, delete e[t]);
            }
        }), e;
    }
    function M(e, t) {
        return void 0 === t || 0 == +t ? Math.round(e) : (e = +e, t = +t, isNaN(e) || "number" != typeof t || t % 1 != 0 ? NaN : (e = e.toString().split("e"), 
        +((e = (e = Math.round(+(e[0] + "e" + (e[1] ? +e[1] + t : t)))).toString().split("e"))[0] + "e" + (e[1] ? +e[1] - t : -t))));
    }
    function j(e, t) {
        return M(e, t).toFixed(t);
    }
    o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.price = a, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.sales = d, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.discount = h, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.timeParams = l, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.formatTime = m, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.time = _, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.timeSpan = c, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.goodsNameWithPrice = p, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.toCamel = f, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.round = M, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.roundToFixed = j, o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), Object.defineProperty(o, "stringWithEmoji", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return n;
        }
    }), o.__esModule || Object.defineProperty(o, "__esModule", {
        value: !0
    }), o.default = {
        leftPad: s,
        leftPadZero: u,
        price: a,
        sales: d,
        discount: h,
        timeParams: l,
        formatTime: m,
        time: _,
        timeSpan: c,
        goodsNameWithPrice: p,
        toCamel: f,
        round: M,
        roundToFixed: j,
        stringWithEmoji: n
    };
}, function(e) {
    return t({}[e], e);
}), t(1688393929383));