var e = require("../../../_/helpers/typeof");

module.exports = function(r) {
    var t = {};
    function n(e) {
        if (t[e]) return t[e].exports;
        var o = t[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return r[e].call(o.exports, o, o.exports, n), o.l = !0, o.exports;
    }
    return n.m = r, n.c = t, n.d = function(e, r, t) {
        n.o(e, r) || Object.defineProperty(e, r, {
            enumerable: !0,
            get: t
        });
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, n.t = function(r, t) {
        if (1 & t && (r = n(r)), 8 & t) return r;
        if (4 & t && "object" === e(r) && r && r.__esModule) return r;
        var o = Object.create(null);
        if (n.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: r
        }), 2 & t && "string" != typeof r) for (var u in r) n.d(o, u, function(e) {
            return r[e];
        }.bind(null, u));
        return o;
    }, n.n = function(e) {
        var r = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return n.d(r, "a", r), r;
    }, n.o = function(e, r) {
        return Object.prototype.hasOwnProperty.call(e, r);
    }, n.p = "", n(n.s = 0);
}([ function(e, r, t) {
    e.exports = {
        getPayMethodInfo: function() {
            return JSON.stringify({
                version: "0.0.2"
            });
        },
        getVersion: function() {
            return "0.0.2";
        }
    };
} ]);