var t = require("../../../../../_/helpers/typeof");

module.exports = function(e) {
    var n = {};
    function r(t) {
        if (n[t]) return n[t].exports;
        var a = n[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(a.exports, a, a.exports, r), a.l = !0, a.exports;
    }
    return r.m = e, r.c = n, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        });
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, r.t = function(e, n) {
        if (1 & n && (e = r(e)), 8 & n) return e;
        if (4 & n && "object" === t(e) && e && e.__esModule) return e;
        var a = Object.create(null);
        if (r.r(a), Object.defineProperty(a, "default", {
            enumerable: !0,
            value: e
        }), 2 & n && "string" != typeof e) for (var o in e) r.d(a, o, function(t) {
            return e[t];
        }.bind(null, o));
        return a;
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return r.d(e, "a", e), e;
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, r.p = "", r(r.s = 3);
}([ function(t, e, n) {
    t.exports = {
        getPayMethodInfo: function() {
            return JSON.stringify({
                version: "0.0.2"
            });
        },
        getVersion: function() {
            return "0.0.2";
        }
    };
}, , , function(t, e, n) {
    var r = function(t, e) {
        var n = {};
        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
        if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
            var a = 0;
            for (r = Object.getOwnPropertySymbols(t); a < r.length; a++) e.indexOf(r[a]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[a]) && (n[r[a]] = t[r[a]]);
        }
        return n;
    }, a = n(0), o = {
        MALL_BALANCE_PAY: "货款可用余额",
        WEIXIN: "微信支付",
        DUODUOPAY_ACS: "银行转账"
    };
    Component({
        properties: {
            hideLabel: {
                type: Boolean,
                value: !1
            },
            themeColor: {
                type: String,
                value: ""
            },
            payMethodInfo: {
                type: String,
                value: ""
            }
        },
        data: {
            notice: "",
            cashierInfo: {
                payChannelParamsList: []
            },
            currentPayMethodInfo: "NA",
            currentPayMethod: -1
        },
        observers: {
            payMethodInfo: function(t) {
                "NA" !== this.data.currentPayMethodInfo && t !== this.data.currentPayMethodInfo && this.getPaymentList(t);
            }
        },
        lifetimes: {
            ready: function() {
                this.getPaymentList(this.data.payMethodInfo);
            }
        },
        methods: {
            getPaymentList: function(t) {
                var e = t;
                this.setData({
                    currentPayMethodInfo: t
                });
                try {
                    "[object String]" === Object.prototype.toString.call(e) && (e = JSON.parse(e));
                } catch (t) {
                    this.triggerEvent("error", t);
                }
                if (e && e.data) {
                    e.data.payChannelParamsList = this.getPayMethodUrl(e.data.payChannelParamsList), 
                    this.setData({
                        cashierInfo: e.data,
                        notice: e.data.notice || ""
                    });
                    var n = e.data.defaultPayMethod;
                    (0 === n || n > 0) && this.handlePayMethodChange({
                        detail: n
                    });
                }
            },
            handlePayMethodChange: function(t) {
                var e = t.detail;
                this.setData({
                    currentPayMethod: e
                });
                var n = this.data.cashierInfo.payChannelParamsList[e];
                this.triggerEvent("change", {
                    payMethod: n.payMethod,
                    appId: n.appId,
                    payTicket: this.data.cashierInfo.payTicket,
                    payMethodInfo: JSON.stringify({
                        payMethod: n.payMethod,
                        version: a.getVersion()
                    })
                });
            },
            getPayMethodUrl: function(t) {
                var e = this, n = JSON.parse(JSON.stringify(t));
                return n.forEach(function(t, n) {
                    var a = t.payMethod, i = t.iconUrl, c = r(t, [ "payMethod", "iconUrl" ]);
                    t.imgUrl = e.getImgUrl(a, i, n), t.type = o[a], t.extra = c;
                }), n;
            },
            getImgUrl: function(t, e, n) {
                return "MALL_BALANCE_PAY" === t ? "https://commimg.pddpic.com/mms_static/2019-09-01/705e937b-133c-445c-b34f-28bb6a3aae44.png" : "WEIXIN" === t ? "https://commimg.pddpic.com/mms_static/2019-09-01/5b74e593-d09e-483b-85c8-4c6921857865.png" : "EBANK" === t ? "https://commimg.pddpic.com/mms_static/2019-08-21/6b17996a-ae1f-430a-93b3-a3d64bd4a5f6.png" : "DUODUOPAY_ACS" === t ? "https://funimg.pddpic.com/2021-01-07/e4fdf49b-4d44-4045-9f2c-dca487819fec.png" : "DUODUOPAY" === t ? this.httpsSafeUrl(e) || "https://funimg.pddpic.com/2020-07-06/1d2940e1-1859-4cc6-a4df-db97a5ca0e83.png" : "";
            },
            httpsSafeUrl: function(t) {
                return t ? t.replace(/^http(s*)/, "") : "";
            },
            handleBindCard: function() {
                this.triggerEvent("bindcard");
            }
        }
    });
} ]);