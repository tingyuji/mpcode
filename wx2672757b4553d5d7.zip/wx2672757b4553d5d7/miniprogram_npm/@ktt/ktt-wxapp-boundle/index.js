var e = require("../../../_/helpers/interopRequireDefault"), t = require("../../../_/helpers/toConsumableArray"), n = require("../../../_/helpers/get"), r = require("../../../_/helpers/getPrototypeOf");

require("../../../_/helpers/Objectentries");

var i, a, o = require("../../../_/helpers/defineProperty"), s = require("../../../_/helpers/inherits"), u = require("../../../_/helpers/createSuper"), c = e(require("../../../_/regenerator")), l = require("../../../_/helpers/asyncToGenerator"), f = require("../../../_/helpers/slicedToArray"), h = require("../../../_/helpers/createClass"), g = require("../../../_/helpers/classCallCheck"), d = require("../../../_/helpers/typeof");

module.exports = (i = {}, a = function(e, t) {
    if (!i[e]) return require(t);
    if (!i[e].status) {
        var n = i[e].m;
        n._exports = n._tempexports;
        var r = Object.getOwnPropertyDescriptor(n, "exports");
        r && r.configurable && Object.defineProperty(n, "exports", {
            set: function(e) {
                "object" === d(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    n._exports[t] = e[t];
                })), n._tempexports = e;
            },
            get: function() {
                return n._tempexports;
            }
        }), i[e].status = 1, i[e].func(i[e].req, n, n.exports);
    }
    return i[e].m.exports;
}, function(e, t, n) {
    i[e] = {
        status: 0,
        func: t,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1688393929378, function(e, i, a) {
    var p = {
        wifi: 1,
        "2g": 2,
        "3g": 3,
        "4g": 4,
        "5g": 6,
        unknown: 0,
        none: -1
    }, v = {
        SOCKET_URL: "wss://titan-ws.pinduoduo.com",
        domain: "https://api.pinduoduo.com",
        bizLogURL: "https://th.yangkeduo.com/t.gif",
        pmmDomain: "https://apm.pinduoduo.com"
    }, m = Object.freeze({
        __proto__: null,
        NETWORK_TYPE: p,
        default: v
    });
    function b() {}
    function y(e, t) {
        return Math.floor(Math.random() * (t - e + 1)) + e;
    }
    b.maxFromBits = function(e) {
        return Math.pow(2, e);
    }, b.limitUI06 = b.maxFromBits(6), b.limitUI08 = b.maxFromBits(8), b.limitUI12 = b.maxFromBits(12), 
    b.limitUI16 = b.maxFromBits(16), b.limitUI32 = b.maxFromBits(32), b.randomUI06 = function() {
        return y(0, b.limitUI06 - 1);
    }, b.randomUI08 = function() {
        return y(0, b.limitUI08 - 1);
    }, b.randomUI12 = function() {
        return y(0, b.limitUI12 - 1);
    }, b.randomUI16 = function() {
        return y(0, b.limitUI16 - 1);
    }, b.randomUI32 = function() {
        return y(0, b.limitUI32 - 1);
    }, b.randomUI48 = function() {
        return (0 | Math.random() * (1 << 30)) + (0 | Math.random() * (1 << 18)) * (1 << 30);
    }, b.paddedString = function(e, t, n) {
        n = n || "0";
        for (var r = t - (e = String(e)).length; r > 0; r >>>= 1, n += n) 1 & r && (e = n + e);
        return e;
    }, b.prototype.fromParts = function(e, t, n, r, i, a) {
        return this.version = n >> 12 & 15, this.hex = b.paddedString(e.toString(16), 8) + "-" + b.paddedString(t.toString(16), 4) + "-" + b.paddedString(n.toString(16), 4) + "-" + b.paddedString(r.toString(16), 2) + b.paddedString(i.toString(16), 2) + "-" + b.paddedString(a.toString(16), 12), 
        this;
    }, b.prototype.toString = function() {
        return this.hex;
    }, b._create4 = function() {
        return new b().fromParts(b.randomUI32(), b.randomUI16(), 16384 | b.randomUI12(), 128 | b.randomUI06(), b.randomUI08(), b.randomUI48());
    };
    var O, k, w, P, _ = function() {
        for (var e = [], t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = 0, r = t.length; n < r; n++) e[t.charCodeAt(n)] = n;
        return {
            encode: function(e) {
                var n, r, i = [], a = e.length, o = a % 3;
                a -= o;
                for (var s = 0; s < a; s += 3) i.push((n = (e[s] << 16) + (e[s + 1] << 8) + e[s + 2], 
                t[n >> 18 & 63] + t[n >> 12 & 63] + t[n >> 6 & 63] + t[63 & n]));
                return a = e.length, 1 === o ? (r = e[a - 1], i.push(t[r >> 2]), i.push(t[r << 4 & 63]), 
                i.push("==")) : 2 === o && (r = (e[a - 2] << 8) + e[a - 1], i.push(t[r >> 10]), 
                i.push(t[r >> 4 & 63]), i.push(t[r << 2 & 63]), i.push("=")), i.join("");
            },
            decode: function(t) {
                var n = t.length, r = 0;
                "=" === t[n - 2] ? r = 2 : "=" === t[n - 1] && (r = 1);
                var i, a, o, s, u, c, l, f = new Array(3 * n / 4 - r);
                for (n = r > 0 ? n - 4 : n, i = 0, a = 0; i < n; i += 4) {
                    var h = (o = t[i], s = t[i + 1], u = t[i + 2], c = t[i + 3], e[o.charCodeAt(0)] << 18 | e[s.charCodeAt(0)] << 12 | e[u.charCodeAt(0)] << 6 | e[c.charCodeAt(0)]);
                    f[a++] = h >> 16 & 255, f[a++] = h >> 8 & 255, f[a++] = 255 & h;
                }
                return 2 === r ? (l = e[t.charCodeAt(i)] << 2 | e[t.charCodeAt(i + 1)] >> 4, f[a++] = 255 & l) : 1 === r && (l = e[t.charCodeAt(i)] << 10 | e[t.charCodeAt(i + 1)] << 4 | e[t.charCodeAt(i + 2)] >> 2, 
                f[a++] = l >> 8 & 255, f[a++] = 255 & l), f;
            }
        };
    }(), S = (O = /([A-Z])/g, k = /[_.\- ]+/g, w = /(^-)|(-$)/g, function(e) {
        return (e = e.replace(O, "-$1").toLowerCase().replace(k, "-").replace(w, "")).split("-");
    }), j = function() {
        function e(e, t) {
            this[t] = e.replace(/\w/, function(e) {
                return e.toUpperCase();
            });
        }
        return function(t) {
            var n = S(t), r = n[0];
            return n.shift(), n.forEach(e, n), r + n.join("");
        };
    }(), C = (P = Object.prototype.hasOwnProperty, function(e, t) {
        return P.call(e, t);
    });
    function T(e) {
        var t = d(e);
        return !!e && ("function" === t || "object" === t);
    }
    function I(e) {
        return void 0 === e;
    }
    var x = Object.keys ? Object.keys : function(e) {
        var t = [];
        for (var n in e) C(e, n) && t.push(n);
        return t;
    };
    function L(e, t, n) {
        if (I(t)) return e;
        switch (null == n ? 3 : n) {
          case 1:
            return function(n) {
                return e.call(t, n);
            };

          case 3:
            return function(n, r, i) {
                return e.call(t, n, r, i);
            };

          case 4:
            return function(n, r, i, a) {
                return e.call(t, n, r, i, a);
            };
        }
        return function() {
            return e.apply(t, arguments);
        };
    }
    var E, A, R, D = (E = Object.prototype.toString, function(e) {
        return E.call(e);
    }), q = Array.isArray ? Array.isArray : function(e) {
        return "[object Array]" === D(e);
    }, U = (A = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, 
    R = /\\(\\)?/g, function(e, t) {
        return q(e) ? e.map(function(e) {
            return {
                path: e,
                isArray: !1
            };
        }) : t && C(t, e) ? [ e ].map(function(e) {
            return {
                path: e,
                isArray: !1
            };
        }) : function(e) {
            var t = [];
            return e.replace(A, function(e, n, r, i) {
                var a = r ? i.replace(R, "$1") : n || e, o = !r && void 0 !== n;
                return t.push({
                    path: a,
                    isArray: o
                }), "";
            }), t;
        }(e);
    });
    function M(e) {
        var t = D(e);
        return "[object Function]" === t || "[object GeneratorFunction]" === t || "[object AsyncFunction]" === t;
    }
    function $(e) {
        return "[object Number]" === D(e);
    }
    var N, F = (N = Math.pow(2, 53) - 1, function(e) {
        if (!e) return !1;
        var t = e.length;
        return $(t) && t >= 0 && t <= N && !M(e);
    });
    function B(e, t, n) {
        var r, i;
        if (t = L(t, n), F(e)) for (r = 0, i = e.length; r < i; r++) t(e[r], r, e); else {
            var a = x(e);
            for (r = 0, i = a.length; r < i; r++) t(e[a[r]], a[r], e);
        }
        return e;
    }
    var z, G = (z = x, function(e) {
        return B(arguments, function(t, n) {
            0 !== n && B(z(t), function(n) {
                e[n] = t[n];
            });
        }), e;
    });
    function V(e) {
        return "[object String]" === D(e);
    }
    function H(e, t) {
        if (null == e) return e;
        for (var n = U(t, e), r = n.shift(); !I(r); ) {
            if (null == (e = e[r.path])) return;
            r = n.shift();
        }
        return e;
    }
    function W(e, t, n) {
        return null == e ? e : M(e) ? L(e, t, n) : T(e) && !q(e) ? function(e) {
            return e = G({}, e), function(t) {
                return function(e, t) {
                    var n = x(t), r = n.length;
                    if (null == e) return !r;
                    e = Object(e);
                    for (var i = 0; i < r; i++) {
                        var a = n[i];
                        if (t[a] !== e[a] || !(a in e)) return !1;
                    }
                    return !0;
                }(t, e);
            };
        }(e) : function(e) {
            return q(e) ? function(t) {
                return H(t, e);
            } : (t = e, function(e) {
                return null == e ? void 0 : e[t];
            });
            var t;
        }(e);
    }
    function K(e, t, n) {
        t = W(t, n);
        for (var r = !F(e) && x(e), i = (r || e).length, a = Array(i), o = 0; o < i; o++) {
            var s = r ? r[o] : o;
            a[o] = t(e[s], s, e);
        }
        return a;
    }
    function Q(e) {
        return q(e) ? e.map(function(e) {
            return Q(e);
        }) : T(e) && !M(e) ? function(e, t, n) {
            t = W(t, void 0);
            for (var r = x(e), i = r.length, a = {}, o = 0; o < i; o++) {
                var s = r[o];
                a[s] = t(e[s], s, e);
            }
            return a;
        }(e, function(e) {
            return Q(e);
        }) : e;
    }
    function Y(e, t, n) {
        for (var r = U(t, e), i = r.pop().path, a = (r.shift() || {}).path; !I(a); ) {
            if ("__proto__" === a || "constructor" === a || "prototype" === a) return;
            e[a] || (e[a] = H(r, "0.isArray") ? [] : {}), e = e[a], a = (r.shift() || {}).path;
        }
        e[i] = n;
    }
    var J, X = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}, Z = {
        exports: {}
    };
    J = Z, function(t, n) {
        J.exports = function(t) {
            var n, r = t.Base64;
            if (J.exports) try {
                n = e("buffer").Buffer;
            } catch (t) {}
            var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", a = function(e) {
                for (var t = {}, n = 0, r = e.length; n < r; n++) t[e.charAt(n)] = n;
                return t;
            }(i), o = String.fromCharCode, s = function(e) {
                if (e.length < 2) return (t = e.charCodeAt(0)) < 128 ? e : t < 2048 ? o(192 | t >>> 6) + o(128 | 63 & t) : o(224 | t >>> 12 & 15) + o(128 | t >>> 6 & 63) + o(128 | 63 & t);
                var t = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
                return o(240 | t >>> 18 & 7) + o(128 | t >>> 12 & 63) + o(128 | t >>> 6 & 63) + o(128 | 63 & t);
            }, u = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, c = function(e) {
                return e.replace(u, s);
            }, l = function(e) {
                var t = [ 0, 2, 1 ][e.length % 3], n = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0);
                return [ i.charAt(n >>> 18), i.charAt(n >>> 12 & 63), t >= 2 ? "=" : i.charAt(n >>> 6 & 63), t >= 1 ? "=" : i.charAt(63 & n) ].join("");
            }, f = t.btoa ? function(e) {
                return t.btoa(e);
            } : function(e) {
                return e.replace(/[\s\S]{1,3}/g, l);
            }, h = n ? n.from && Uint8Array && n.from !== Uint8Array.from ? function(e) {
                return (e.constructor === n.constructor ? e : n.from(e)).toString("base64");
            } : function(e) {
                return (e.constructor === n.constructor ? e : new n(e)).toString("base64");
            } : function(e) {
                return f(c(e));
            }, g = function(e, t) {
                return t ? h(String(e)).replace(/[+\/]/g, function(e) {
                    return "+" == e ? "-" : "_";
                }).replace(/=/g, "") : h(String(e));
            }, d = new RegExp([ "[À-ß][-¿]", "[à-ï][-¿]{2}", "[ð-÷][-¿]{3}" ].join("|"), "g"), p = function(e) {
                switch (e.length) {
                  case 4:
                    var t = ((7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3)) - 65536;
                    return o(55296 + (t >>> 10)) + o(56320 + (1023 & t));

                  case 3:
                    return o((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));

                  default:
                    return o((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1));
                }
            }, v = function(e) {
                return e.replace(d, p);
            }, m = function(e) {
                var t = e.length, n = t % 4, r = (t > 0 ? a[e.charAt(0)] << 18 : 0) | (t > 1 ? a[e.charAt(1)] << 12 : 0) | (t > 2 ? a[e.charAt(2)] << 6 : 0) | (t > 3 ? a[e.charAt(3)] : 0), i = [ o(r >>> 16), o(r >>> 8 & 255), o(255 & r) ];
                return i.length -= [ 0, 0, 2, 1 ][n], i.join("");
            }, b = t.atob ? function(e) {
                return t.atob(e);
            } : function(e) {
                return e.replace(/[\s\S]{1,4}/g, m);
            }, y = n ? n.from && Uint8Array && n.from !== Uint8Array.from ? function(e) {
                return (e.constructor === n.constructor ? e : n.from(e, "base64")).toString();
            } : function(e) {
                return (e.constructor === n.constructor ? e : new n(e, "base64")).toString();
            } : function(e) {
                return v(b(e));
            }, O = function(e) {
                return y(String(e).replace(/[-_]/g, function(e) {
                    return "-" == e ? "+" : "/";
                }).replace(/[^A-Za-z0-9\+\/]/g, ""));
            };
            if (t.Base64 = {
                VERSION: "2.4.5",
                atob: b,
                btoa: f,
                fromBase64: O,
                toBase64: g,
                utob: c,
                encode: g,
                encodeURI: function(e) {
                    return g(e, !0);
                },
                btou: v,
                decode: O,
                noConflict: function() {
                    var e = t.Base64;
                    return t.Base64 = r, e;
                }
            }, "function" == typeof Object.defineProperty) {
                var k = function(e) {
                    return {
                        value: e,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    };
                };
                t.Base64.extendString = function() {
                    Object.defineProperty(String.prototype, "fromBase64", k(function() {
                        return O(this);
                    })), Object.defineProperty(String.prototype, "toBase64", k(function(e) {
                        return g(this, e);
                    })), Object.defineProperty(String.prototype, "toBase64URI", k(function() {
                        return g(this, !0);
                    }));
                };
            }
            return t.Meteor && (Base64 = t.Base64), J.exports && (J.exports.Base64 = t.Base64), 
            {
                Base64: t.Base64
            };
        }(t);
    }("undefined" != typeof self ? self : "undefined" != typeof window ? window : X);
    var ee = [ "pddtestimg.yangkeduo.com", "omsproductionimg.yangkeduo.com", "img-cn-shanghai.aliyuncs.com", "avatar.yangkeduo.com" ], te = [ "commimg.pddpic.com", "images.pinduoduo.com", "pinduoduoimg.yangkeduo.com", "funimg.pddpic.com", "testimg.yangkeduo.com", "img1.yangkeduo.com", "img-test.pddpic.com", "img.pddpic.com", "img.pddugc.com", "video-snapshot.pddpic.com", "t16img.yangkeduo.com" ], ne = {
        DEFAULT: 0,
        ALI: 1,
        TENCENT: 2
    };
    function re() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        return e ? e.replace("http://", "https://") : e;
    }
    function ie(e) {
        return e ? Z.exports.Base64.encode(e).replace(/\+/g, "-").replace(/\//g, "_") : "";
    }
    function ae(e) {
        var t = e.text, n = void 0 === t ? "" : t, r = e.fontsize, i = void 0 === r ? 13 : r, a = e.fill, o = void 0 === a ? "#3D3D3D" : a, s = e.dissolve, u = void 0 === s ? 90 : s, c = e.gravity, l = void 0 === c ? "SouthEast" : c, f = e.dx, h = void 0 === f ? 0 : f, g = e.dy, d = void 0 === g ? 0 : g, p = e.batch, v = void 0 === p ? 0 : p, m = e.degree, b = void 0 === m ? 0 : m;
        if (e.image, !n) return "";
        var y = [ "watermark/2" ];
        return n && y.push("/text/".concat(ie(n))), o && y.push("/fill/".concat(ie(o))), 
        i && y.push("/fontsize/".concat(i)), u && y.push("/dissolve/".concat(u)), l && y.push("/gravity/".concat(l)), 
        h && y.push("/dx/".concat(h)), d && y.push("/dy/".concat(d)), v && y.push("/batch/".concat(v)), 
        b && y.push("/degree/".concat(b)), y.join("");
    }
    function oe() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = ((e || "").match(/\/\/([^/]+)\//) || [])[1] || "";
        return ee.indexOf(t) >= 0 ? ne.ALI : te.indexOf(t) >= 0 || t.match(/t\d+img\.yangkeduo\.com/) ? ne.TENCENT : t.match(/a\d+img\.yangkeduo\.com/) ? ne.ALI : ne.DEFAULT;
    }
    var se = function(e) {
        var t = e.watermark, n = e.prefitWidth;
        if (!n) return t;
        var r = /\/image\/(.+?)\//, i = r.exec(t);
        if (!i || !i[1]) return t;
        var a = Z.exports.Base64.decode(i[1]);
        return a += "?imageMogr2/thumbnail/".concat(n, "x"), t.replace(r, "/image/".concat(Z.exports.Base64.encode(a), "/"));
    };
    function ue() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
        return e ? t ? e.indexOf("?") >= 0 ? e + "|" + t : t.indexOf("?") >= 0 ? e + t : e + "?" + t : e : "";
    }
    var ce = function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.webpEnable, r = t.quality, i = t.blur, a = t.watermark, o = t.plainWatermark, s = t.sharpen, u = t.resizeWidth, c = t.resizeMaxWidth, l = t.strip, f = t.prefitWidth, h = [], g = [], p = [], v = "";
        if (T(i)) {
            var m = i.radius, b = i.sigma;
            m && !b ? i.sigma = 1 : !m && b && (i.radius = 1);
        }
        var y = "";
        if (e === ne.TENCENT) {
            var O = [];
            if (u && g.push("/1/w/".concat(u)), c && g.push("/2/w/".concat(c)), r && g.push("/q/".concat(r)), 
            n && g.push("/format/webp"), s && h.push("/sharpen/1"), l && h.push("/strip"), "boolean" == typeof f && f && (f = 400), 
            f && O.push("imageMogr2/thumbnail/".concat(f, "x")), T(i)) {
                var k = i.radius, w = i.sigma;
                h.push("/blur/".concat(k, "x").concat(w));
            }
            if (V(a)) p.push("/image/".concat(a)); else if ("object" == d(a) && a.image) {
                var P = a.image, _ = a.gravity, S = a.dy, j = a.dx;
                p.push("/image/".concat(P)), _ && p.push("/gravity/".concat(_)), S && p.push("/dy/".concat(S)), 
                j && p.push("/dy/".concat(j));
            } else "object" == d(a) && a.text && (v = ae(a));
            if (p.length && !o) {
                var C = "watermark/1/blogo/2" + p.join("");
                O.push(se({
                    watermark: C,
                    prefitWidth: f
                }));
            }
            o && O.push(se({
                watermark: o,
                prefitWidth: f
            })), h.length && O.push("imageMogr2" + h.join("")), g.length && O.push("imageView2" + g.join("")), 
            y = "?" + O.join("%7C"), v && (y = ue(y, v));
        } else if (e === ne.ALI) if (o && function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            return V(e) || q(e) ? e.indexOf(t) >= 0 : !(!T(e) || !Object.keys(e)) && Object.keys(e).indexOf(t) >= 0;
        }(o, "watermark")) {
            var I = [ "x-oss-process=image", o, "/resize,w_".concat(u) ];
            r && I.push("/quality,q_".concat(r)), n && I.push("/format,webp"), y = "?" + I.join("");
        } else {
            var x = [];
            if (x.push("".concat(u, "w_1l")), r && x.push("_".concat(r, "Q")), s) {
                var L = 50;
                $(s) && (L = s), x.push("_".concat(L, "sh"));
            }
            if (T(i)) {
                var E = i.radius, A = i.sigma;
                x.push("_".concat(E, "-").concat(A, "bl"));
            }
            n && x.push(".webp"), y = "@" + x.join("");
        }
        return y;
    }, le = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.webpEnable, r = void 0 === n || n, i = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.webpEnable, n = e.width, r = e.resizeWidth, i = e.sharpen, a = e.strip, o = e.quality;
            return n && !r && (e.resizeWidth = n), t ? (o || (e.quality = 70), i || (e.sharpen = 50)) : (o || (e.quality = 80), 
            void 0 === a && (e.strip = !0)), e;
        }(Object.assign(Object.assign({}, t), {
            webpEnable: r
        }));
        return re(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, n = oe(e);
            return n === ne.DEFAULT || e.indexOf(".gif") >= 0 ? e : (e.indexOf(".gif") >= 0 && (t.sharpen = !1), 
            function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return e.indexOf("@") >= 0 ? e.split("@")[0] : e.indexOf("?") >= 0 ? e.split("?")[0] : e;
            }(e) + ce(n, t));
        }(e, i));
    }, fe = h(function e(t) {
        var n = t.errorCode, r = void 0 === n ? -1 : n, i = t.data, a = void 0 === i ? {} : i, o = t.errMsg;
        g(this, e), this.errMsg = o, this.errorCode = r, this.data = a;
    }), he = function e(t, n) {
        if (!t || "object" != d(t) || !Object.keys(t).length) return t;
        if (Array.isArray(t)) return t.map(function(t) {
            return e(t, n);
        });
        var r = {};
        return Object.keys(t).forEach(function(i) {
            var a = n(i), o = t[i];
            r[a] = e(o, n);
        }), r;
    }, ge = function() {
        var e = /([A-Z])/g, t = /[_.\- ]+/g, n = /(^-)|(-$)/g;
        function r(e, t) {
            this[t] = e.replace(/\w/, function(e) {
                return e.toUpperCase();
            });
        }
        return function(i) {
            var a = function(r) {
                return (r = r.replace(e, "-$1").toLowerCase().replace(t, "-").replace(n, "")).split("-");
            }(i), o = a[0];
            return a.shift(), a.forEach(r, a), o += a.join("");
        };
    }(), de = function(e, t) {
        return (parseInt(e) || 0) - (parseInt(t) || 0);
    }, pe = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", n = e.split("."), r = f(n, 3), i = r[0], a = r[1], o = r[2], s = t.split("."), u = f(s, 3), c = u[0], l = u[1], h = u[2];
        return de(i, c) || de(a, l) || de(o, h);
    }, ve = function(e) {
        return e.replace(/[A-Z]/g, function(e) {
            return "_" + e.toLowerCase();
        });
    }, me = function(e) {
        return he(e, ve);
    }, be = function(e) {
        return he(e, ge);
    }, ye = function() {};
    function Oe() {
        return b._create4().toString();
    }
    function ke(e, t) {
        try {
            return e(t);
        } catch (e) {
            return t;
        }
    }
    function we() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 21, t = ""; t.length < e; ) t += Math.random().toString(36).slice(2);
        return t.slice(0, e);
    }
    function Pe() {
        return [ Date.now(), we(16) ].join("");
    }
    function _e(e, t) {
        for (var n = 1, r = function t(r) {
            for (var i = arguments.length, a = new Array(i > 1 ? i - 1 : 0), o = 1; o < i; o++) a[o - 1] = arguments[o];
            return new Promise(function(i, o) {
                r.apply(void 0, a).then(i).catch(function(s) {
                    n >= e ? o(s) : (n++, t.apply(void 0, [ r ].concat(a)).then(i).catch(o));
                });
            });
        }, i = arguments.length, a = new Array(i > 2 ? i - 2 : 0), o = 2; o < i; o++) a[o - 2] = arguments[o];
        return r.apply(void 0, [ t ].concat(a));
    }
    var Se = Z.exports.Base64, je = Object.freeze({
        __proto__: null,
        Base64: Se,
        FrontError: fe,
        ImageCDNType: ne,
        atob: function(e) {
            return K(_.decode(e), function(e) {
                return String.fromCharCode(e);
            }).join("");
        },
        btoa: function(e) {
            return _.encode(K(e, function(e) {
                return e.charCodeAt(0);
            }));
        },
        buildTencentCDNTextWaterMarkParams: ae,
        camelCase: j,
        cloneDeep: Q,
        compareVersion: pe,
        debounce: function(e, t) {
            var n, r;
            return function() {
                for (var i = this, a = arguments.length, o = new Array(a), s = 0; s < a; s++) o[s] = arguments[s];
                return n && clearTimeout(n), n = setTimeout(function() {
                    r = e.apply(i, o), n = null;
                }, t || 50), r;
            };
        },
        emptyFunction: ye,
        getImageCDNType: oe,
        getLogID: Pe,
        getRandomArray: function(e) {
            if ("[object Array]" !== Object.prototype.toString.call(e)) return [];
            for (var t = e, n = t.length - 1; n >= 0; n--) {
                var r = Math.floor(Math.random() * (n + 1)), i = e[r];
                t[r] = e[n], t[n] = i;
            }
            return t;
        },
        getUnique: Oe,
        httpsSafe: re,
        isArr: q,
        isEmpty: function(e) {
            return null == e || (F(e) && (q(e) || V(e) || function(e) {
                return "[object Arguments]" === D(e);
            }(e)) ? 0 === e.length : 0 === x(e).length);
        },
        isNum: $,
        isObj: T,
        isStr: V,
        lockASync: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = !1;
            return l(c.default.mark(function r() {
                var i, a, o, s = arguments;
                return c.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        for (i = s.length, a = new Array(i), o = 0; o < i; o++) a[o] = s[o];
                        return r.abrupt("return", n ? t ? Promise.reject("") : void 0 : (n = !0, e.apply(this, a).then(function(e) {
                            return n = !1, e;
                        }).catch(function(e) {
                            throw n = !1, e;
                        })));

                      case 2:
                      case "end":
                        return r.stop();
                    }
                }, r, this);
            }));
        },
        nanoid: we,
        pipeProcessParams: ue,
        processUrlBase: le,
        safeGet: H,
        safeSet: Y,
        sleep: function(e) {
            return new Promise(function(t) {
                return setTimeout(t, e);
            });
        },
        snakeCase: ve,
        throttle: function(e, t) {
            var n, r;
            return function() {
                for (var i = arguments.length, a = new Array(i), o = 0; o < i; o++) a[o] = arguments[o];
                return n || (r = e.apply(this, a), n = setTimeout(function() {
                    n = null;
                }, t || 500)), r;
            };
        },
        toCamelCase: be,
        toSnakeCase: me,
        tryDo: ke,
        tryPromiseChain: _e
    }), Ce = function() {
        function e() {
            g(this, e), this.eventListMap = {}, this.eventTriggerMap = {};
        }
        return h(e, [ {
            key: "applyCallback",
            value: function(e, t) {
                try {
                    Function.prototype.apply.call(e, this, t);
                } catch (e) {}
            }
        }, {
            key: "_triggerEvent",
            value: function(e, t) {
                var n = this.eventTriggerMap[e];
                n && this.applyCallback(t, n);
            }
        }, {
            key: "onceWrap",
            value: function(e, t) {
                return function n() {
                    for (var r = arguments.length, i = new Array(r), a = 0; a < r; a++) i[a] = arguments[a];
                    this.remove(e, n), this.applyCallback(t, i);
                };
            }
        }, {
            key: "listen",
            value: function(e, t) {
                var n = this;
                if (!e) throw new Error("eventName is required");
                if (!t) return ye;
                var r = this.eventListMap;
                return r[e] ? r[e].push(t) : r[e] = [ t ], this._triggerEvent(e, t), function() {
                    n.remove(e, t);
                };
            }
        }, {
            key: "remove",
            value: function(e, t) {
                if (!e) throw new Error("eventName is required");
                if (!t) throw new Error("callback is required");
                var n = this.eventListMap[e];
                n && n.length && (this.eventListMap[e] = n.filter(function(e) {
                    return e !== t;
                }));
            }
        }, {
            key: "trigger",
            value: function(e) {
                for (var t = this, n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) r[i - 1] = arguments[i];
                var a = this.eventListMap[e];
                this.eventTriggerMap[e] = r, a && a.length && a.forEach(function(e) {
                    t.applyCallback(e, r);
                });
            }
        }, {
            key: "triggerOnce",
            value: function(e) {
                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                this.trigger.apply(this, [ e ].concat(n)), this.cancelEvent(e);
            }
        }, {
            key: "listenOnce",
            value: function(e, t) {
                return this.listen(e, this.onceWrap(e, t));
            }
        }, {
            key: "cancelEvent",
            value: function(e) {
                delete this.eventTriggerMap[e];
            }
        }, {
            key: "cancel",
            value: function(e) {
                this.cancelEvent(e), this.eventListMap[e] = [];
            }
        } ]), e;
    }(), Te = new Ce(), Ie = Object.freeze({
        __proto__: null,
        default: Ce,
        globalEvent: Te
    }), xe = function() {
        function e(t) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            g(this, e), this.diffData = {}, this.preData = n, this.callback = t;
        }
        return h(e, [ {
            key: "initDep",
            value: function() {
                this.diffData = {};
            }
        }, {
            key: "collectDep",
            value: function(e) {
                Object.assign(this.diffData, e);
            }
        }, {
            key: "updateDep",
            value: function() {
                var e = !1, t = this.diffData, n = this.preData, r = {};
                Object.keys(t).forEach(function(i) {
                    var a = t[i];
                    a !== n[i] && (e = !0, r[i] = a);
                }), e && this.callback(r), Object.assign(n, t);
            }
        } ]), e;
    }(), Le = 6e4, Ee = Object.freeze({
        __proto__: null,
        GrayBase: function(e) {
            s(r, e);
            var t, n = u(r);
            function r() {
                var e;
                return g(this, r), (e = n.apply(this, arguments)).isInit = !1, e.lastUpdateTs = 0, 
                e.updating = !1, e.updatingPromise = Promise.resolve(), e;
            }
            return h(r, [ {
                key: "getStoreSync",
                value: function(e, t) {
                    var n = this.store;
                    return n && e in n ? n[e] : t;
                }
            }, {
                key: "getStore",
                value: (t = l(c.default.mark(function e() {
                    var t, n, r, i, a = arguments;
                    return c.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t = a.length > 0 && void 0 !== a[0] ? a[0] : {}, n = t.data, r = t.forceUpdate, 
                            e.t0 = !this.isInit || (i = this.lastUpdateTs, Date.now() - i >= Le) || n || r, 
                            !e.t0) {
                                e.next = 5;
                                break;
                            }
                            return e.next = 5, this.updateStore({
                                data: n,
                                forceUpdate: r
                            }).catch(ye);

                          case 5:
                            return e.abrupt("return", this.store);

                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function() {
                    return t.apply(this, arguments);
                })
            }, {
                key: "updateStore",
                value: function(e) {
                    var t = this, n = e.data, r = e.forceUpdate;
                    return n ? this.fetchStoreWrap({
                        data: n
                    }) : (this.updating && !r || (this.updating = !0, this.lastUpdateTs = Date.now(), 
                    this.updatingPromise = this.fetchStoreWrap({
                        data: n
                    }).then(function() {
                        t.isInit = !0, t.updating = !1;
                    }).catch(function(e) {
                        t.updating = !1;
                    })), this.updatingPromise);
                }
            }, {
                key: "fetchStoreWrap",
                value: function(e) {
                    var t = this, n = e.data;
                    return this.fetchStore({
                        data: n
                    }).then(function(e) {
                        e && t.updateData(e);
                    });
                }
            }, {
                key: "fetchStore",
                value: function(e) {
                    return e.data, Promise.resolve({});
                }
            }, {
                key: "storeInject",
                value: function(e) {
                    var t = e.data, n = e.callback, r = e.requestData, i = e.forceUpdate;
                    return this.getStore({
                        data: r,
                        forceUpdate: i
                    }), this.observer({
                        data: t,
                        callback: n
                    });
                }
            } ]), r;
        }(function() {
            function e(t) {
                g(this, e), this.store = {}, this.depList = [], this.keyDepMap = {}, this.updateData(t);
            }
            return h(e, [ {
                key: "updateData",
                value: function(e) {
                    if (e) {
                        var t = this, n = Object.assign({}, this.store, e);
                        this.store = n, this.depList && this.depList.forEach(function(e) {
                            return e.initDep();
                        }), Object.keys(n).forEach(function(e) {
                            var r = n[e];
                            Object.defineProperty(n, e, {
                                configurable: !0,
                                enumerable: !0,
                                get: function() {
                                    return r;
                                },
                                set: function(n) {
                                    var i = t.keyDepMap[e];
                                    i && i.forEach(function(t) {
                                        return t.collectDep(o({}, e, r));
                                    }), r = n;
                                }
                            }), n[e] = r;
                        }), this.depList && this.depList.forEach(function(e) {
                            return e.updateDep();
                        });
                    }
                }
            }, {
                key: "observer",
                value: function(e) {
                    var t = this, n = e.data, r = e.callback, i = Object.keys(n), a = new xe(r, n);
                    this.depList.push(a), i.forEach(function(e) {
                        t.keyDepMap[e] ? t.keyDepMap[e].push(a) : t.keyDepMap[e] = [ a ];
                    });
                    var o = i.filter(function(e) {
                        var r = t.store[e];
                        return void 0 !== r && r !== n[e];
                    });
                    return o.length && r(o.reduce(function(e, n) {
                        return e[n] = t.store[n], e;
                    }, {})), function() {
                        t.depList = t.depList.filter(function(e) {
                            return e !== a;
                        }), i.forEach(function(e) {
                            t.keyDepMap[e] = t.keyDepMap[e].filter(function(e) {
                                return e !== a;
                            });
                        });
                    };
                }
            } ]), e;
        }()),
        updateExpireTime: function(e) {
            Le = e;
        }
    }), Ae = Object.freeze({
        __proto__: null,
        default: function() {
            function e(t) {
                var n = t.requestConfig, r = t.pageSize, i = void 0 === r ? 20 : r, a = t.pageNumberKey, o = void 0 === a ? "pageNumber" : a, s = t.pageSizeKey, u = void 0 === s ? "pageSize" : s, c = t.listIdKey, l = void 0 === c ? "listId" : c, f = t.listId, h = void 0 === f ? "" : f, d = t.key, p = t.allowEmptyKey, v = void 0 !== p && p, m = t.name, b = void 0 === m ? "baseModel" : m, y = t.useListId, O = void 0 !== y && y, k = t.initialPageNumber, w = void 0 === k ? 1 : k;
                g(this, e), this.isAbort = !1, this.fetching = !1, this.hasMore = !0, this.pageNumber = 1, 
                this.lastFetchPage = -1, this.lastFetchId = -1, this.listMap = {}, this.listId = "", 
                this.initialPageNumber = 1, this.initialListId = h, this.listIdKey = l, this.useListId = O, 
                this.requestConfig = n, this.pageSize = i, this.pageNumberKey = o, this.pageSizeKey = u, 
                this.key = d, this.allowEmptyKey = v, this.name = b, this.fetchKey = 0, this.fetchId = 0, 
                this.initialPageNumber = w, this.reset();
            }
            var t;
            return h(e, [ {
                key: "abort",
                value: function() {
                    this.isAbort = !0;
                }
            }, {
                key: "reset",
                value: function() {
                    return this.pageNumber = this.initialPageNumber, this.fetchId++, this.listMap = {}, 
                    this.listId = this.initialListId, this.requestId = void 0, this;
                }
            }, {
                key: "updateListId",
                value: function(e) {
                    this.listId = e;
                }
            }, {
                key: "updateHasMore",
                value: function(e) {
                    this.hasMore = e;
                }
            }, {
                key: "updateRequestId",
                value: function(e) {
                    this.requestId = e;
                }
            }, {
                key: "setListId",
                value: function(e) {
                    var t = e.listId;
                    void 0 !== t && this.updateListId(t);
                }
            }, {
                key: "setHasMore",
                value: function(e) {
                    var t = e.hasMore;
                    void 0 !== t && this.updateHasMore(t);
                }
            }, {
                key: "setRequestId",
                value: function(e) {
                    var t = e.requestId;
                    void 0 !== t && this.updateRequestId(t);
                }
            }, {
                key: "formatList",
                value: function(e) {
                    return e.list || [];
                }
            }, {
                key: "afterFormatList",
                value: function(e) {
                    return this.requestId && Object.assign(e, {
                        requestId: this.requestId
                    }), e;
                }
            }, {
                key: "formatData",
                value: function(e) {
                    var t = this;
                    if (e.result) {
                        var n = e.result;
                        return this.setListId(n), this.setHasMore(n), this.setRequestId(n), this.formatList(n).map(function(e) {
                            return t.afterFormatList(e);
                        });
                    }
                    return [];
                }
            }, {
                key: "formatNextPage",
                value: function() {
                    this.pageNumber++;
                }
            }, {
                key: "updateRequestConfig",
                value: function(e) {
                    this.requestConfig = e;
                }
            }, {
                key: "updateRequestParams",
                value: function(e) {
                    return this.updateRequestConfig(Object.assign(Object.assign(Object.assign({}, this.requestConfig), e), {
                        data: Object.assign(Object.assign({}, this.requestConfig.data), e.data)
                    })), this;
                }
            }, {
                key: "request",
                value: function(e) {
                    return Promise.resolve({});
                }
            }, {
                key: "getNextPage",
                value: (t = l(c.default.mark(function e() {
                    var t, n, r, i, a, s, u, l, f, h, g, d, p, v, m, b = this, y = arguments;
                    return c.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (n = y.length > 0 && void 0 !== y[0] ? y[0] : {}, r = n.data, i = void 0 === r ? {} : r, 
                            a = this.requestConfig, s = this.pageSizeKey, u = this.pageSize, l = this.pageNumberKey, 
                            f = this.pageNumber, h = this.listIdKey, g = this.useListId, this.lastFetchPage !== f || this.lastFetchId !== this.fetchId || !this.fetching) {
                                e.next = 4;
                                break;
                            }
                            return e.abrupt("return", {
                                isFetching: !0,
                                abort: !0
                            });

                          case 4:
                            if (!this.isAbort) {
                                e.next = 6;
                                break;
                            }
                            return e.abrupt("return", {
                                abort: !0
                            });

                          case 6:
                            return d = ++this.fetchKey, p = this.fetchId, v = f === this.initialPageNumber, 
                            this.lastFetchPage = f, this.lastFetchId = p, this.fetching = !0, e.next = 10, this.request(Object.assign(Object.assign({}, a), {
                                data: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, g ? o({}, h, this.listId || "") : {}), {
                                    previous_request_id: this.requestId
                                }), a.data), (t = {}, o(t, s, u), o(t, l, f), t)), i)
                            })).then(function(e) {
                                if (d === b.fetchKey) {
                                    var t = b.formatData(e);
                                    return b.formatNextPage(e), b.fetching = !1, t;
                                }
                                throw new fe({
                                    errMsg: "request abort"
                                });
                            }).catch(function(e) {
                                if (b.fetching = !1, !(e && e instanceof fe)) throw e;
                            });

                          case 10:
                            return m = e.sent, e.abrupt("return", this.isAbort || p !== this.fetchId ? {
                                abort: !0
                            } : m ? (v && this.initListMapByFirstPage(), {
                                originList: m,
                                list: this.filterList(m),
                                pageNumber: f,
                                isFirstPage: v,
                                pageSize: u,
                                hasMore: this.hasMore
                            }) : {
                                abort: !0
                            });

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function() {
                    return t.apply(this, arguments);
                })
            }, {
                key: "initListMapByFirstPage",
                value: function() {
                    this.listMap = {};
                }
            }, {
                key: "filterList",
                value: function(e) {
                    var t = this;
                    return void 0 === this.key ? e : e.filter(function(e) {
                        var n = H(e, "".concat(t.key));
                        return !n && t.allowEmptyKey ? (t.key && Y(e, "".concat(t.key), Oe()), !0) : !t.listMap[n] && (t.listMap[n] = !0, 
                        !0);
                    });
                }
            } ]), e;
        }()
    });
    function Re(e) {
        return ke(decodeURIComponent, e);
    }
    function De(e) {
        return ke(encodeURIComponent, e);
    }
    function qe() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = e.split("?")[1];
        if (!t) return {};
        var n = {};
        return t.split("&").forEach(function(e) {
            var t = e.split("="), r = f(t, 2), i = r[0], a = r[1];
            void 0 !== i && void 0 !== a && i.length > 0 && a.length > 0 && (n[Re(i)] = Re(a));
        }), n;
    }
    function Ue(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], n = Object.keys(e), r = t.length;
        return n.filter(function(t) {
            return null != t && null != e[t];
        }).map(function(e, n) {
            var i = t.indexOf(e);
            return {
                key: e,
                sortIndex: -1 === i ? r + n : i
            };
        }).sort(function(e, t) {
            return e.sortIndex - t.sortIndex;
        }).map(function(e) {
            return e.key;
        }).reduce(function(t, n) {
            return t.push("".concat(De(n), "=").concat(De(e[n]))), t;
        }, []).join("&");
    }
    function Me() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 ? arguments[2] : void 0, r = e.split("?")[0] || "", i = qe(e), a = Ue(t = Object.assign(Object.assign({}, i), t), n);
        return r + (a.length > 0 ? "?" + a : "");
    }
    var $e, Ne = Object.freeze({
        __proto__: null,
        buildQuery: Ue,
        buildURL: Me,
        getQuery: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return Object.entries(e).reduce(function(e, t) {
                var n = f(t, 2), r = n[0], i = n[1];
                return e[Re(r)] = Re(i), e;
            }, {});
        },
        parseQuery: qe
    });
    function Fe() {
        if (!$e) try {
            $e = wx.getAccountInfoSync();
        } catch (e) {}
        return $e;
    }
    var Be, ze, Ge = {
        chooseLocation: "scope.userLocation",
        getRecorderManager: "scope.record",
        saveVideoToPhotosAlbum: "scope.writePhotosAlbum",
        saveImageToPhotosAlbum: "scope.writePhotosAlbum"
    };
    function Ve() {
        return (ot("2.10.1") ? Je.getSetting({
            withSubscriptions: !0
        }) : Je.getSetting()).then(function(e) {
            Be = (e || {}).authSetting, ze = (e || {}).subscriptionsSetting;
        });
    }
    function He(e) {
        return We.apply(this, arguments);
    }
    function We() {
        return (We = l(c.default.mark(function e(t) {
            return c.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.t0 = Be, e.t0) {
                        e.next = 4;
                        break;
                    }
                    return e.next = 4, Ve();

                  case 4:
                    if (!Be) {
                        e.next = 9;
                        break;
                    }
                    if (!Be[t]) {
                        e.next = 7;
                        break;
                    }
                    return e.abrupt("return", !0);

                  case 7:
                    if (void 0 !== Be[t]) {
                        e.next = 9;
                        break;
                    }
                    return e.abrupt("return", Je.authorize({
                        scope: t
                    }));

                  case 9:
                    return e.abrupt("return", Promise.reject("需要您的授权"));

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))).apply(this, arguments);
    }
    function Ke() {
        Be = null, ze = void 0;
    }
    function Qe(e) {
        return Je.showModal(function(e) {
            switch (e) {
              case "scope.userLocation":
                return {
                    title: "信息授权提示",
                    content: "需要访问您当前的位置，请到小程序的设置中打开位置信息"
                };

              case "scope.record":
                return {
                    title: "授权提示",
                    content: "需要调用您的麦克风，请到小程序的设置中授权"
                };

              case "scope.writePhotosAlbum":
                return {
                    title: "信息授权提示",
                    content: "需要访问您的相册，请到小程序的设置中授权"
                };

              case "scope.addPhoneCalendar":
                return {
                    title: "信息授权提示",
                    content: "需要添加到您的日历，请到小程序的设置中授权"
                };

              default:
                return {
                    title: "授权提示",
                    content: "需要访问您的权限，请到小程序的设置中授权"
                };
            }
        }(e)).then(function(e) {
            e.confirm ? (Ke(), Je.openSetting()) : vt({
                title: "需要您的授权"
            });
        });
    }
    var Ye = {
        stopRecord: !0,
        getRecorderManager: !0,
        pauseVoice: !0,
        stopVoice: !0,
        pauseBackgroundAudio: !0,
        stopBackgroundAudio: !0,
        getBackgroundAudioManager: !0,
        createAudioContext: !0,
        createInnerAudioContext: !0,
        createVideoContext: !0,
        createCameraContext: !0,
        createMapContext: !0,
        canIUse: !0,
        startAccelerometer: !0,
        stopAccelerometer: !0,
        startCompass: !0,
        stopCompass: !0,
        onBLECharacteristicValueChange: !0,
        onBLEConnectionStateChange: !0,
        hideToast: !0,
        hideLoading: !0,
        showNavigationBarLoading: !0,
        hideNavigationBarLoading: !0,
        createAnimation: !0,
        pageScrollTo: !0,
        createSelectorQuery: !0,
        createCanvasContext: !0,
        hideKeyboard: !0,
        stopPullDownRefresh: !0,
        arrayBufferToBase64: !0,
        base64ToArrayBuffer: !0,
        createWorker: !0,
        createLivePlayerContext: !0,
        createLivePusherContext: !0
    }, Je = {};
    Object.keys(wx).forEach(function(e) {
        Ye[e] || "on" === e.substring(0, 2) || /\w+Sync/.test(e) ? Object.defineProperty(Je, e, {
            get: function() {
                return function() {
                    var t;
                    return (t = wx)[e].apply(t, arguments);
                };
            }
        }) : Object.defineProperty(Je, e, {
            get: function() {
                var t = wx[e];
                return function() {
                    var n, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    if ("string" == typeof r) return t(r);
                    var i = new Promise(function(i, a) {
                        n = t(Object.assign(Object.assign({}, r), {
                            success: function(e) {
                                i(e), r.success && r.success(e);
                            },
                            fail: function(t) {
                                var n, i, o;
                                return -1 !== (null === (n = null == t ? void 0 : t.errMsg) || void 0 === n ? void 0 : n.indexOf("navigateTo:fail")) && -1 !== (null === (i = null == t ? void 0 : t.errMsg) || void 0 === i ? void 0 : i.indexOf("limit exceed")) ? wx.showToast({
                                    title: "访问页面数已超过上限，请回退",
                                    icon: "none"
                                }) : Ge[e] && -1 !== (null === (o = null == t ? void 0 : t.errMsg) || void 0 === o ? void 0 : o.indexOf("auth deny")) && Qe(Ge[e]), 
                                r.fail && r.fail(t), a(t);
                            },
                            complete: function() {
                                r.complete && r.complete.apply(r, arguments);
                            }
                        }));
                    });
                    return "uploadFile" !== e && "downloadFile" !== e || (i.onProgressUpdate = function(e) {
                        return n.onProgressUpdate(e), i;
                    }, i.abort = function(e) {
                        return e && e(), i.abort(), i;
                    }), i;
                };
            }
        });
    });
    var Xe, Ze, et, tt = null, nt = !1;
    function rt() {
        return new Promise(function(e, t) {
            tt ? e(tt) : nt ? Xe.then(e).catch(t) : (nt = !0, Xe = wx.getSystemInfo().then(function(e) {
                return tt = e, nt = !1, e;
            }).catch(function(e) {
                throw nt = !1, e;
            }), Xe).then(e).catch(t);
        });
    }
    function it() {
        if (!tt) try {
            tt = Je.getSystemInfoSync();
        } catch (e) {}
        return tt || {};
    }
    function at() {
        if (Ze) return Ze;
        var e = it();
        return e && (Ze = function(e) {
            var t = e.platform, n = e.SDKVersion;
            return {
                canUseChooseMedia: pe(n, "2.10.0") >= 0 && ("ios" === t || "android" === t),
                canUsePreviewMedia: pe(n, "2.12.0") >= 0,
                isMac: "mac" === t
            };
        }(e)), Ze || {};
    }
    function ot(e) {
        var t = it();
        return pe(t.SDKVersion, e) >= 0;
    }
    function st() {
        var e = getCurrentPages();
        return e[e.length - 1] || null;
    }
    function ut() {
        var e, t;
        try {
            var n = "function" == typeof this.getPageId ? this.getPageId() : this.__wxWebviewId__;
            return n || null === (e = getApp()) || void 0 === e || e.delayReport({
                type: "error",
                msg: "getPageId and __wxWebviewId__ not valid",
                data: {
                    pageId: n
                }
            }), n;
        } catch (e) {
            return null === (t = getApp()) || void 0 === t || t.delayReport({
                type: "error",
                e: e,
                msg: "getPageId and __wxWebviewId__ error"
            }), "";
        }
    }
    function ct(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
        try {
            return wx.setStorageSync(e, t);
        } catch (r) {
            if (n < 3) return ct(e, t, ++n);
        }
    }
    function lt() {
        var e = ke(function() {
            return wx.getStorageSync("xcx_trace_id");
        }, "");
        return e || ct("xcx_trace_id", e = we(32)), e;
    }
    var ft, ht = !1;
    function gt(e) {
        clearTimeout(et), et = setTimeout(function() {
            Je.hideLoading();
        }, e || 1500);
    }
    function dt(e) {
        clearTimeout(et), ht ? gt(e) : Je.hideLoading();
    }
    function pt() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.page, n = void 0 === t ? st() : t, r = function(e, t) {
            var n = {};
            for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
            if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                var i = 0;
                for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
            }
            return n;
        }(e, [ "page" ]);
        clearTimeout(ft), ht = !1, clearTimeout(et), et = setTimeout(function() {
            n && !n.$visible || Je.showLoading(Object.assign({
                title: ""
            }, r));
        }, r.delay || 200);
    }
    function vt(e) {
        clearTimeout(et), clearTimeout(ft);
        var t = e.duration, n = void 0 === t ? 1500 : t, r = e.title;
        return ht = !0, ft = setTimeout(function() {
            ht = !1;
        }, n), r && Je.showToast(Object.assign({
            icon: "none"
        }, e));
    }
    var mt, bt = new Ce(), yt = !1;
    function Ot(e) {
        return mt !== e.networkType && bt.trigger("onNetworkStatusChange", e), mt = e.networkType, 
        yt = !0, e;
    }
    function kt() {
        return wt.apply(this, arguments);
    }
    function wt() {
        return (wt = l(c.default.mark(function e() {
            return c.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", yt ? {
                        networkType: mt
                    } : wx.getNetworkType().then(Ot));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))).apply(this, arguments);
    }
    wx.onNetworkStatusChange(Ot);
    var Pt, _t, St = function() {
        var e = !1, t = it();
        if (t) {
            var n = t.SDKVersion, r = t.platform;
            e = "android" === r || "ios" === r && pe(n, "2.9.0") >= 0;
        } else e = !1;
        return St = function() {
            return e;
        }, e;
    }, jt = Object.freeze({
        __proto__: null,
        WX_AUTH_API: Ge,
        canUseChooseMedia: function() {
            return at().canUseChooseMedia;
        },
        clearCache: Ke,
        compareSDKVersion: ot,
        getAccountInfo: Fe,
        getAuthCacheSetting: (_t = l(c.default.mark(function e(t) {
            return c.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.t0 = Be, e.t0) {
                        e.next = 4;
                        break;
                    }
                    return e.next = 4, Ve().catch(ye);

                  case 4:
                    return e.abrupt("return", (Be || {})[t]);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function(e) {
            return _t.apply(this, arguments);
        }),
        getAuthCacheWithAuthorize: He,
        getAuthWithDialog: function(e) {
            return He(e).catch(function() {
                var t = l(c.default.mark(function t(n) {
                    return c.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return dt(), t.next = 3, Qe(e);

                          case 3:
                            throw n;

                          case 4:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }));
                return function(e) {
                    return t.apply(this, arguments);
                };
            }());
        },
        getCurrentPage: st,
        getDataByEvent: function(e, t) {
            var n = e || {}, r = n.currentTarget, i = n.target, a = n.mark, o = void 0 === a ? {} : a, s = n.detail, u = void 0 === s ? {} : s, c = Object.assign({}, u, o, (r || {}).dataset || {}, (i || {}).dataset || {});
            return t ? c[t] : c;
        },
        getNetworkType: kt,
        getPageId: ut,
        getPddSystemInfo: at,
        getRefer: function() {
            var e = getCurrentPages();
            return e[e.length - 2] || null;
        },
        getSubscriptionsSetting: (Pt = l(c.default.mark(function e() {
            return c.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.t0 = ze, e.t0) {
                        e.next = 5;
                        break;
                    }
                    return e.next = 4, Ve().catch(ye);

                  case 4:
                    e.t0 = ze;

                  case 5:
                    return e.abrupt("return", e.t0);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return Pt.apply(this, arguments);
        }),
        getSystemInfo: rt,
        getSystemInfoSync: it,
        getXcxTraceId: lt,
        guideToSetting: Qe,
        hideLoading: dt,
        hideLoadingAsync: gt,
        isProd: function() {
            var e = Fe();
            if (!e) return !0;
            var t = e.miniProgram.envVersion;
            return !t || "release" === t;
        },
        processUrl: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.webpEnable, r = void 0 === n || n;
            return le(e, Object.assign(Object.assign({}, t), {
                webpEnable: r && St()
            }));
        },
        setStorageSync: ct,
        showLoading: pt,
        showToast: vt,
        subscribeNetworkChange: function(e) {
            return bt.listen("onNetworkStatusChange", function(t) {
                e(t);
            });
        },
        wxp: Je
    }), Ct = {
        API: "api",
        INFO: "info",
        LOG: "log",
        ERROR: "error",
        default: "default"
    }, Tt = [ {
        size: 1,
        maxSize: 1,
        scene: Ct.INFO
    }, {
        size: 1,
        maxSize: 2,
        scene: Ct.LOG
    }, {
        size: 1,
        maxSize: 3,
        scene: Ct.ERROR
    }, {
        size: 10,
        maxSize: 10,
        scene: Ct.API
    } ], It = new (function() {
        function e(t) {
            var n = t.size, r = void 0 === n ? 10 : n, i = t.laneQueue;
            g(this, e), this.maxSize = r, this.laneConfig = i.reduce(function(e, t) {
                return e[t.scene] = t, e;
            }, {}), this.laneInfo = {}, this.priorityList = i.map(function(e) {
                return e.scene;
            }), this.runningSet = new Set();
        }
        var t, n;
        return h(e, [ {
            key: "_consume",
            value: (n = l(c.default.mark(function e(t, n) {
                var r, i;
                return c.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return r = function() {
                            for (var e = "0123456789ABCDEF", t = "", n = 0; n < e.length; n++) t += e[Math.floor(16 * Math.random())];
                            return t;
                        }(), this.runningSet.add(r), n.add(r), e.prev = 2, e.next = 5, t();

                      case 5:
                        return i = e.sent, e.abrupt("return", (this.runningSet.delete(r), n.delete(r), this.next(), 
                        i));

                      case 9:
                        throw e.prev = 9, e.t0 = e.catch(2), this.runningSet.delete(r), n.delete(r), this.next(), 
                        e.t0;

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 2, 9 ] ]);
            })), function(e, t) {
                return n.apply(this, arguments);
            })
        }, {
            key: "consume",
            value: (t = l(c.default.mark(function e(t, n) {
                var r, i, a, o, s = this;
                return c.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r = n.scene, i = this._getLaneInfo(r), a = i.list, o = i.runningSet, !this.checkLaneEmpty(r)) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return", this._consume(t, o));

                      case 3:
                        return e.abrupt("return", new Promise(function(e, n) {
                            a.push(function() {
                                return s._consume(t, o).then(e, n);
                            });
                        }));

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function(e, n) {
                return t.apply(this, arguments);
            })
        }, {
            key: "next",
            value: function() {
                for (var e = [ Ct.default ].concat(this.priorityList), t = e.shift(); void 0 !== t; ) {
                    if (this.checkLaneEmpty(t, "maxSize")) {
                        var n = this._getLaneInfo(t).list.shift();
                        if (n) return n();
                    }
                    t = e.shift();
                }
            }
        }, {
            key: "_getLaneConfig",
            value: function(e) {
                var t = this.laneConfig[e];
                return t ? Object.assign({
                    maxSize: this.maxSize
                }, t) : {
                    size: this.maxSize,
                    maxSize: this.maxSize
                };
            }
        }, {
            key: "_getLaneInfo",
            value: function(e) {
                var t = this.laneInfo[e];
                return t || (t = {
                    runningSet: new Set(),
                    list: []
                }, this.laneInfo[e] = t), t;
            }
        }, {
            key: "checkLaneEmpty",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ct.default, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "size", n = this.runningSet.size;
                return n < this.maxSize && n < this._getLaneConfig(e)[t];
            }
        } ]), e;
    }())({
        laneQueue: Tt
    }), xt = {
        HTTP: "http",
        SOCKET: "socket"
    }, Lt = function() {
        function e() {
            g(this, e), this.handlers = [];
        }
        return h(e, [ {
            key: "use",
            value: function(e, t) {
                this.handlers.push({
                    onFullFilled: e,
                    onRejected: t
                });
            }
        }, {
            key: "forEach",
            value: function(e) {
                this.handlers.forEach(function(t) {
                    return t && e(t);
                });
            }
        } ]), e;
    }(), Et = function() {
        function e() {
            g(this, e), this.interceptors = {
                request: new Lt(),
                response: new Lt()
            }, this.config = {}, this.useRequestPlugin(this.setRequestInterceptors()), this.useResponsePlugin([ {
                response: function(e) {
                    return e.config.requestEndTime = +new Date(), e;
                },
                responseError: function(e) {
                    return e.config.requestEndTime = +new Date(), Promise.reject(e);
                }
            } ]), this.useResponsePlugin(this.setResponseInterceptors()), this.useRequestPlugin([ {
                request: function(e) {
                    return e.url.indexOf("://") < 1 && (e.url = (e.domain || v.domain) + e.url), e;
                }
            }, {
                request: function(e) {
                    var t = e.url, n = e.params;
                    return n && (e.url = Me(t, n)), e;
                }
            }, {
                request: function(e) {
                    var t = e.convertRequestToSnake, n = e.data;
                    return t && n && (e.data = me(e.data)), e;
                }
            }, {
                request: function(e) {
                    return e.requestStartTime || (e.requestStartTime = +new Date()), e;
                }
            } ]), this.useResponsePlugin([ {
                response: function(e) {
                    var t = e.config, n = e.data;
                    return t.convertToCamel && n && (e.data = be(n)), e;
                }
            } ]);
        }
        return h(e, [ {
            key: "setRequestInterceptors",
            value: function() {
                return [];
            }
        }, {
            key: "setResponseInterceptors",
            value: function() {
                return [];
            }
        }, {
            key: "socket",
            value: function(e) {
                return this.socketInstance ? this.socketInstance.request(e) : Promise.resolve({});
            }
        }, {
            key: "fetch",
            value: function(e) {
                return Promise.resolve({});
            }
        }, {
            key: "handleRequest",
            value: function(e) {
                return e.enableTitanHttp && this.socketInstance && this.socketInstance.valid() ? (e.tunnel = xt.SOCKET, 
                this.socket(e).then(function(t) {
                    return {
                        data: t,
                        config: e
                    };
                }).catch(function(t) {
                    return Promise.reject({
                        error: t,
                        config: e
                    });
                })) : (e.tunnel = xt.HTTP, this.fetch(e).then(function(t) {
                    return {
                        data: t,
                        config: e
                    };
                }).catch(function(t) {
                    return Promise.reject({
                        error: t,
                        config: e
                    });
                }));
            }
        }, {
            key: "setHeader",
            value: function(e) {
                return Object.assign(this.config, {
                    header: e
                }), this;
            }
        }, {
            key: "useMethod",
            value: function(e) {
                return Object.assign(this.config, {
                    method: e
                }), this;
            }
        }, {
            key: "request",
            value: function(e) {
                var t, n, r = Promise.resolve(Object.assign({
                    header: {},
                    data: {},
                    params: {},
                    requestEndTime: 0,
                    requestStartTime: 0,
                    tunnel: xt.HTTP
                }, this.config, e)), i = [];
                for (this.interceptors.request.forEach(function(e) {
                    var t = e.onFullFilled, n = e.onRejected;
                    return i.push(t, n);
                }), i.push(this.handleRequest, void 0), this.interceptors.response.forEach(function(e) {
                    var t = e.onFullFilled, n = e.onRejected;
                    return i.push(t, n);
                }); i.length; ) r = r.then(null === (t = i.shift()) || void 0 === t ? void 0 : t.bind(this), null === (n = i.shift()) || void 0 === n ? void 0 : n.bind(this));
                return r.then(function(e) {
                    return e.data;
                }, function(e) {
                    var t = e.error;
                    return Promise.reject(t);
                });
            }
        }, {
            key: "useRequestPlugin",
            value: function(e) {
                var t = this;
                return e.forEach(function(e) {
                    var n = e.request, r = e.requestError;
                    return t.interceptors.request.use(n, r);
                }), this;
            }
        }, {
            key: "useResponsePlugin",
            value: function(e) {
                var t = this;
                return e.forEach(function(e) {
                    var n = e.response, r = e.responseError;
                    return t.interceptors.response.use(n, r);
                }), this;
            }
        }, {
            key: "useSocket",
            value: function(e) {
                return this.socketInstance = e, this;
            }
        } ]), e;
    }(), At = function(e) {
        s(i, e);
        var t = u(i);
        function i(e) {
            var n;
            return g(this, i), (n = t.call(this)).$currentPage = e || st(), n.useRequestPlugin([ {
                request: function(e) {
                    return e.timeout || (e.timeout = function(e) {
                        return [ Ct.INFO, Ct.LOG ].indexOf(e.scene) > -1 ? 5e3 : 3e4;
                    }(e)), e;
                }
            } ]), n;
        }
        return h(i, [ {
            key: "request",
            value: function(e) {
                var t = this, a = e.enableTitanHttp, o = Object.assign({
                    scene: Ct.API,
                    requestQueueTime: 0
                }, e);
                return a && this.socketInstance && this.socketInstance.valid() || o.requestQueueTime ? n(r(i.prototype), "request", this).call(this, o) : (o.requestQueueTime = +new Date(), 
                It.consume(function() {
                    return n(r(i.prototype), "request", t).call(t, o);
                }, o));
            }
        } ]), i;
    }(function(e) {
        s(n, e);
        var t = u(n);
        function n() {
            return g(this, n), t.apply(this, arguments);
        }
        return h(n, [ {
            key: "fetch",
            value: function(e) {
                return new Promise(function(t, n) {
                    wx.request(Object.assign(Object.assign({}, e), {
                        success: function(e) {
                            var r = e.data;
                            if (e.statusCode >= 400) return n(r);
                            t(r);
                        },
                        fail: function(e) {
                            n(e);
                        }
                    }));
                });
            }
        } ]), n;
    }(Et)), Rt = function(e) {
        s(i, e);
        var t = u(i);
        function i() {
            return g(this, i), t.apply(this, arguments);
        }
        return h(i, [ {
            key: "request",
            value: function(e) {
                return n(r(i.prototype), "request", this).call(this, Object.assign({
                    scene: Ct.INFO
                }, e));
            }
        } ]), i;
    }(At), Dt = Object.freeze({
        __proto__: null,
        BaseRequest: Et,
        FileRequest: function(e) {
            s(i, e);
            var t = u(i);
            function i() {
                var e;
                return g(this, i), (e = t.call(this)).useRequestPlugin([ {
                    request: function(e) {
                        return e.header && delete e.header["Content-Type"], e;
                    }
                } ]), e;
            }
            return h(i, [ {
                key: "handleRequest",
                value: function(e) {
                    return new Promise(function(t, n) {
                        wx.uploadFile(Object.assign(Object.assign({}, e), {
                            success: function(n) {
                                var r = {};
                                try {
                                    r = JSON.parse(n.data) || {};
                                } catch (e) {}
                                t({
                                    data: r,
                                    config: e
                                });
                            },
                            fail: function(t) {
                                return n({
                                    error: t,
                                    config: e
                                });
                            }
                        }));
                    });
                }
            }, {
                key: "request",
                value: function(e) {
                    var t = this, a = Object.assign({
                        scene: Ct.API,
                        requestQueueTime: 0
                    }, e);
                    return a.requestQueueTime = +new Date(), It.consume(function() {
                        return n(r(i.prototype), "request", t).call(t, a);
                    }, a);
                }
            } ]), i;
        }(Et),
        LogRequest: Rt,
        REQUEST_TYPE: Ct,
        REQUEST_TYPES: Tt,
        TUNNEL: xt,
        WxappRequest: At,
        requestQueue: It
    });
    function qt(e, t) {
        var n = {};
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
            var i = 0;
            for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
        }
        return n;
    }
    var Ut = {}, Mt = [], $t = [ "from" ], Nt = [ "src", "campaign", "cid", "sid", "msgid", "scene" ], Ft = !1, Bt = !1, zt = new (function() {
        function e(t) {
            var n = this;
            g(this, e), this.uploadUrl = "", this.initConfig(t), Te.listenOnce("signInComplete", function() {
                Bt = !0, Ft && n.uploadBizLog();
            });
        }
        return h(e, [ {
            key: "initConfig",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.url, n = void 0 === t ? v.bizLogURL : t;
                this.uploadUrl = n;
            }
        }, {
            key: "setBasicParams",
            value: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                Object.assign(Ut, e), Ft = Ft || t, t && Bt && this.uploadBizLog();
            }
        }, {
            key: "upload",
            value: function(e, t) {
                if (Bt && Ft) {
                    var n = Object.assign(t, Ut, function(e) {
                        var t = {};
                        return [ "pv", "click", "impr" ].indexOf(e.op) >= 0 && ($t.forEach(function(n) {
                            var r = e[n];
                            r && (t["refer_channel_".concat(n)] = r);
                        }), Nt.forEach(function(n) {
                            var r = e[n];
                            r && (t["refer_".concat(n)] = r);
                        })), "pv" === e.op && (t.event = "page_show"), t;
                    }(t));
                    e.request({
                        url: this.uploadUrl,
                        data: Ue(n)
                    }).catch(ye);
                } else Mt.push({
                    request: e,
                    params: t
                });
            }
        }, {
            key: "uploadBizLog",
            value: function() {
                for (var e = Mt.shift(); e; ) {
                    var t = e, n = t.request, r = t.params;
                    this.upload(n, r), e = Mt.shift();
                }
            }
        } ]), e;
    }())();
    zt.setBasicParams({
        platform: "wxapp",
        wxapp_type: "xcx",
        xcx_trace_id: lt()
    });
    var Gt = {
        "Content-Type": "text/plain;charset=UTF-8"
    }, Vt = !1;
    function Ht(e) {
        var t = this && this.$currentPage || st(), n = Object.assign(Object.assign(Object.assign({}, e), null == t ? void 0 : t.$getBaseLogParams()), null == t ? void 0 : t.$getBizLog()), r = n.extParams, i = void 0 === r ? {} : r, a = qt(n, [ "extParams" ]);
        return Object.assign(Object.assign({}, i), a);
    }
    function Wt(e) {
        var t = Ht.call(this, Object.assign(Object.assign({}, e), {
            xcx_x_scene: getApp().$scene || "",
            time: new Date().getTime()
        }));
        if (t.page_sn) {
            t.log_id || Object.assign(t, {
                log_id: Pe()
            });
            var n = new Rt().useMethod("POST").setHeader(Gt);
            zt.upload(n, t), !Vt && rt().then(function(e) {
                var t = {};
                t.dpr = e.pixelRatio, t.windowWidth = e.windowWidth, t.windowHeight = e.windowHeight, 
                t.statusBarHeight = e.statusBarHeight, t.language = e.language, t.system = e.system, 
                t.fontSizeSetting = e.fontSizeSetting, t.screen_width = e.screenWidth, t.screen_height = e.screenHeight, 
                t.manufacture = e.brand, t.model = e.model, t.wxVersion = e.version, t.sdk_version = e.SDKVersion, 
                zt.setBasicParams(t), kt().then(function(e) {
                    zt.setBasicParams({
                        network: p[e.networkType] || p.unknown
                    }, !0);
                }, function() {
                    zt.setBasicParams({
                        network: p.unknown
                    }, !0);
                }), Vt = !0;
            });
        }
    }
    function Kt(e) {
        Wt.call(this, Object.assign(Object.assign({}, e), {
            op: "click"
        }));
    }
    function Qt(e) {
        Wt.call(this, Object.assign(Object.assign({}, e), {
            op: "impr"
        }));
    }
    var Yt = Object.freeze({
        __proto__: null,
        click: Kt,
        epv: function(e) {
            var t = e.op, n = void 0 === t ? "epv" : t, r = qt(e, [ "op" ]);
            Wt.call(this, Object.assign(Object.assign({}, r), {
                op: n
            }));
        },
        impr: Qt,
        logger: zt,
        pv: function(e) {
            Wt.call(this, Object.assign(Object.assign({}, e), {
                op: "pv"
            }));
        },
        req: Wt
    }), Jt = {}, Xt = [], Zt = {};
    function en() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (Xt = getCurrentPages().map(function(e) {
            return "/" + e.route;
        }), e && Xt.length > 0) {
            var t = Xt[Xt.length - 1];
            clearTimeout(Zt[t]), Jt[t] = "";
        }
    }
    function tn(e, t) {
        var n = function(e) {
            return Object.assign(Object.assign({}, e), {
                url: Me(e.url, e.params)
            });
        }(e), r = (n.url || "").split("?")[0], i = Jt[r], a = st(), o = ut.call(a);
        if (!i || i !== o) {
            Jt[r] = o;
            var s = setTimeout(function() {
                var e = Jt[r];
                e && e === o && (Jt[r] = "", en());
            }, 1e4);
            Zt[r] = s, t(n);
        }
    }
    function nn(e) {
        tn(e, function(e) {
            Je.navigateTo(e), Xt.push(e.url);
        });
    }
    function rn(e) {
        tn(e, function(e) {
            Je.redirectTo(e), Xt.pop(), Xt.push(e.url);
        });
    }
    function an() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.success, n = e.fail, r = e.delta, i = void 0 === r ? 1 : r;
        return Xt.splice(Math.max(Xt.length - i, 1)), Je.navigateBack({
            delta: i,
            success: t,
            fail: n
        });
    }
    var on = Object.freeze({
        __proto__: null,
        amendPageStack: en,
        isTopPage: function(e) {
            return 0 === (Xt[Xt.length - 1] || "").indexOf(e);
        },
        navigateToMiniProgram: function(e) {
            var t = e.appId, n = e.url, r = e.params, i = e.extraData;
            return Je.navigateToMiniProgram({
                appId: t,
                envVersion: "trial",
                path: Me(n, r),
                extraData: i
            });
        },
        nvBack: an,
        nvBackOrForward2Target: function(e) {
            var t = getCurrentPages() || [], n = e || {}, r = n.params, i = void 0 === r ? {} : r, a = n.url, o = n.requireParams, s = void 0 === o ? [] : o, u = {
                isInRouteStack: !1,
                delta: 0
            };
            try {
                var c = "string" == typeof a ? "/" === a.charAt(0) ? a.substring(1) : a : "";
                u = t.reduce(function(e, n, r) {
                    if (!e.isInRouteStack) {
                        var a = n || {}, o = a.route, u = a.options, l = void 0 === u ? {} : u;
                        o === c && (e.isInRouteStack = (s || []).every(function(e) {
                            return decodeURIComponent(i[e]) === decodeURIComponent(l[e] || "");
                        }), e.delta = t.length - (r + 1));
                    }
                    return e;
                }, u);
            } catch (e) {}
            u.isInRouteStack ? an({
                delta: u.delta
            }) : nn(e);
        },
        nvBackOrReloadToTarget: function(e) {
            var t = getCurrentPages() || [], n = t.findIndex(function(t) {
                return t.route === e.url.substring(1);
            });
            n >= 0 ? an(Object.assign(Object.assign({}, e), {
                delta: t.length - (n + 1)
            })) : rn(e);
        },
        nvBackToTarget: function(e) {
            var t = e.success, n = e.fail, r = e.target, i = getCurrentPages() || [], a = i.findIndex(function(e) {
                return e.route === r.substring(1);
            });
            an({
                success: t,
                fail: n,
                delta: a < 0 ? 1 : i.length - (a + 1)
            });
        },
        nvForward: nn,
        nvReLaunch: function(e) {
            tn(e, function(e) {
                Je.reLaunch(e), Xt = [ e.url ];
            });
        },
        nvReload: rn,
        nvSwitchTab: function(e) {
            Xt = [ e.url ], Je.switchTab(e);
        }
    }), sn = {
        API_LOG_TYPE: 100,
        PAGE_LOG_TYPE: 200,
        CUSTOM_LOG_TYPE: 400,
        FRONT_ERR_API: 500,
        FRONT_ERR_STATIC: 501,
        FRONT_ERR_CUSTOM: 502,
        FRONT_LOG_COMMON: 600
    }, un = {
        API_LOG: 1,
        PAGE_LOG: 2,
        CUSTOM_LOG: 4,
        FRONT_ERR: 5,
        FRONT_LOG: 6
    }, cn = {
        DEFAULT: "10000",
        API_INFO_MODULE: "100009"
    }, ln = {
        DEFAULT: "10000100",
        API_DEFAULT: "10000101"
    }, fn = function() {
        for (var e, t = [], n = 0; n < 256; n++) {
            e = n;
            for (var r = 0; r < 8; r++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
            t[n] = e;
        }
        return t;
    }(), hn = function(e, t) {
        e = function(e) {
            e = e.replace(/\r\n/g, "\n");
            for (var t = "", n = 0; n < e.length; n++) {
                var r = e.charCodeAt(n);
                r < 128 ? t += String.fromCharCode(r) : r > 127 && r < 2048 ? (t += String.fromCharCode(r >> 6 | 192), 
                t += String.fromCharCode(63 & r | 128)) : (t += String.fromCharCode(r >> 12 | 224), 
                t += String.fromCharCode(r >> 6 & 63 | 128), t += String.fromCharCode(63 & r | 128));
            }
            return t;
        }(e.toString()), "undefined" !== t && null !== t || (t = 0), t ^= -1;
        for (var n = 0; n < e.length; n++) t = t >>> 8 ^ fn[255 & (t ^ e.charCodeAt(n))];
        return (-1 ^ t) >>> 0;
    }, gn = {
        d: "",
        m: "",
        osV: "",
        version: 0
    }, dn = {
        wxVersion: "",
        sdkVersion: "",
        network: p.unknown
    }, pn = 0, vn = 0, mn = new (function(e) {
        s(n, e);
        var t = u(n);
        function n() {
            return g(this, n), t.apply(this, arguments);
        }
        return h(n, [ {
            key: "initPmmParams",
            value: function(e) {
                var t = this;
                return this.setPmmBasicParams(e), rt().then(function(e) {
                    var n = {};
                    return n.osV = e.system, n.d = e.brand, n.m = e.model, dn.wxVersion = e.version, 
                    dn.sdkVersion = e.SDKVersion, t.setPmmBasicParams(Object.assign(n, dn)), new Promise(function(e, n) {
                        wx.getNetworkType({
                            success: function(e) {
                                var n = p[e.networkType] || p.unknown;
                                dn.network = n, t.setPmmBasicParams({
                                    network: n
                                });
                            },
                            complete: function() {
                                e();
                            }
                        });
                    });
                });
            }
        }, {
            key: "checkValidRate",
            value: function(e) {
                return "number" == typeof e && e >= 0 && e <= 1;
            }
        }, {
            key: "initPmmFilterConfig",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e || {}, n = t.api_rate, r = t.page_rate;
                this.checkValidRate(n) && (pn = n), this.checkValidRate(r) && (vn = r);
            }
        }, {
            key: "req",
            value: function(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Ct.ERROR, r = Q(e);
                try {
                    var i = r.datas[0].tags;
                    Object.keys(i).forEach(function(e) {
                        i[e] = String(i[e]);
                    });
                } catch (e) {}
                new Rt().request({
                    url: t,
                    method: "POST",
                    data: r,
                    header: {
                        "Content-Type": "application/json;charset=UTF-8"
                    },
                    scene: n
                }).catch(ye);
            }
        }, {
            key: "sendLogReq",
            value: function(e, t) {
                if (e) {
                    var n = e.payload, r = e.url;
                    this.req(n, r, t);
                }
            }
        }, {
            key: "getVersionParams",
            value: function() {
                return {
                    network: String(dn.network || 0),
                    wxVersion: dn.wxVersion,
                    sdkVersion: dn.sdkVersion
                };
            }
        }, {
            key: "apiLog",
            value: function(e) {
                var t = e.resTimeConsume, n = e.reqData, r = e.resData, i = e.apiUrl, a = e.statusCode, o = e.pageSn, s = e.tunnel, u = e.extras;
                if (0 !== pn && !(Math.random() > pn)) try {
                    var c = 0, l = 0;
                    n && (c = JSON.stringify(n).length), r && (l = JSON.stringify(r).length);
                    var f = i.split("?")[0], h = this.pmmApi({
                        apiUrl: f,
                        apiRatio: 1 / pn,
                        tags: {
                            network: String(dn.network || 0),
                            code: a + "",
                            conn: s === xt.SOCKET ? "4" : "1",
                            method: n.method || "POST"
                        },
                        extras: Object.assign(Object.assign({
                            pageSn: o
                        }, this.getVersionParams()), u),
                        values: {
                            reqP: {
                                values: [ c ]
                            },
                            rspP: {
                                values: [ l ]
                            },
                            rspT: {
                                values: [ t ]
                            }
                        }
                    });
                    this.sendLogReq(h, Ct.INFO);
                } catch (t) {}
            }
        }, {
            key: "pmmPageLog",
            value: function(e) {
                var t = e.pageSn, n = e.extras, r = e.phaseValues;
                if (0 !== vn && !(Math.random() > vn)) try {
                    var i = this.pmmPage({
                        pageSn: t,
                        apiRatio: 1 / vn,
                        tags: {
                            network: String(dn.network || 0)
                        },
                        extras: Object.assign(Object.assign({}, this.getVersionParams()), n),
                        values: {
                            phases_array: {
                                values: r
                            }
                        }
                    });
                    this.sendLogReq(i, Ct.INFO);
                } catch (t) {}
            }
        }, {
            key: "pmmCustomLog",
            value: function(e) {
                var t = e.groupId, n = e.tags, r = e.extras, i = e.longFields;
                if (t) try {
                    var a = Object.keys(i).reduce(function(e, t) {
                        var n = i[t];
                        return e[t] = {
                            values: [ n ]
                        }, e;
                    }, {}), o = Object.keys(n).reduce(function(e, t) {
                        return e["custom_".concat(t)] = n[t], e;
                    }, {}), s = this.pmmCustom({
                        groupId: t,
                        tags: Object.assign({
                            network: String(dn.network || 0)
                        }, o),
                        extras: r || {},
                        longValues: a
                    });
                    this.sendLogReq(s, Ct.INFO);
                } catch (t) {}
            }
        }, {
            key: "info",
            value: function(e) {
                var t = e.tags, n = e.extras;
                try {
                    var r = this.pmmInfo({
                        tags: Object.assign(Object.assign(Object.assign({}, this.getVersionParams()), {
                            module: cn.DEFAULT,
                            errorCode: ln.DEFAULT
                        }), t),
                        extras: n
                    });
                    this.sendLogReq(r, Ct.INFO);
                } catch (t) {}
            }
        }, {
            key: "error",
            value: function(e) {
                var t = e.type, n = e.tags, r = e.extras, i = {
                    module: cn.DEFAULT
                };
                t === sn.FRONT_ERR_API ? Object.assign(i, {
                    errorCode: ln.API_DEFAULT
                }) : Object.assign(i, {
                    errorCode: ln.DEFAULT
                });
                try {
                    var a = this.pmmError({
                        type: t,
                        tags: Object.assign(Object.assign(Object.assign({}, i), this.getVersionParams()), n),
                        extras: r
                    });
                    this.sendLogReq(a);
                } catch (t) {}
            }
        } ]), n;
    }(function() {
        function e(t) {
            g(this, e), this.apiLogUrl = "", this.pageLogUrl = "", this.customLogUrl = "", this.errLogUrl = "", 
            this.infoLogUrl = "", this.initConfig(t);
        }
        return h(e, [ {
            key: "initConfig",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.domain, n = void 0 === t ? v.pmmDomain : t;
                this.apiLogUrl = n + "/api/pmm/api", this.pageLogUrl = n + "/api/pmm/page", this.customLogUrl = n + "/api/pmm/defined", 
                this.errLogUrl = n + "/api/pmm/front_err", this.infoLogUrl = n + "/api/pmm/front_log";
            }
        }, {
            key: "getBasePmmParams",
            value: function() {
                return {
                    biz_side: gn.bizSide,
                    app: gn.app,
                    level: 2,
                    version: gn.version,
                    report_time_ms: Date.now(),
                    rand_num: Math.floor(1e5 * Math.random() + 1e5),
                    crc32: hn(Date.now() + "-123456"),
                    common_tags: {
                        d: gn.d,
                        m: gn.m,
                        osV: gn.osV,
                        releaseVersion: gn.appVersion,
                        uid: String(gn.user_id)
                    }
                };
            }
        }, {
            key: "formatStringObject",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return Object.keys(e).reduce(function(t, n) {
                    return t[n] = String(e[n]) || "", t;
                }, {});
            }
        }, {
            key: "generateMmrId",
            value: function(e) {
                var t = e.category, n = e.type;
                return "mmr-".concat(t, "-").concat(n, "-").concat(Date.now(), "-").concat(Math.floor(1e4 * Math.random()));
            }
        }, {
            key: "pmmInfo",
            value: function(e) {
                var t = e.tags, n = void 0 === t ? {} : t, r = e.extras;
                try {
                    var i = sn.FRONT_LOG_COMMON, a = un.FRONT_LOG;
                    return {
                        payload: Object.assign(Object.assign({}, this.getBasePmmParams()), {
                            datas: [ Object.assign({
                                category: a,
                                type: i,
                                timestamp: Date.now(),
                                tags: Object.assign({
                                    mmrId: this.generateMmrId({
                                        category: a,
                                        type: i
                                    })
                                }, n),
                                lvalues: {
                                    clientTime: {
                                        values: [ Date.now() ]
                                    }
                                }
                            }, r ? {
                                extras: {
                                    data: JSON.stringify(r)
                                }
                            } : {}) ]
                        }),
                        url: this.infoLogUrl
                    };
                } catch (n) {
                    return null;
                }
            }
        }, {
            key: "setPmmBasicParams",
            value: function(e) {
                Object.assign(gn, e);
            }
        }, {
            key: "pmmError",
            value: function(e) {
                var t = e.type, n = void 0 === t ? sn.FRONT_ERR_CUSTOM : t, r = e.tags, i = void 0 === r ? {} : r, a = e.extras;
                try {
                    var o = un.FRONT_ERR;
                    return {
                        payload: Object.assign(Object.assign({}, this.getBasePmmParams()), {
                            datas: [ Object.assign({
                                category: o,
                                type: n,
                                timestamp: Date.now(),
                                tags: Object.assign({
                                    mmrId: this.generateMmrId({
                                        category: o,
                                        type: n
                                    })
                                }, i),
                                lvalues: {
                                    clientTime: {
                                        values: [ Date.now() ]
                                    }
                                }
                            }, a ? {
                                extras: {
                                    data: JSON.stringify(a)
                                }
                            } : {}) ]
                        }),
                        url: this.errLogUrl
                    };
                } catch (n) {
                    return null;
                }
            }
        }, {
            key: "pmmApi",
            value: function(e) {
                var t = e.tags, n = e.values, r = e.apiUrl, i = e.apiRatio, a = e.extras;
                try {
                    var o = un.API_LOG, s = sn.API_LOG_TYPE;
                    return {
                        payload: Object.assign(Object.assign({}, this.getBasePmmParams()), {
                            datas: [ Object.assign({
                                category: o,
                                type: s,
                                id_raw_value: r,
                                timestamp: Date.now(),
                                api_ratio: i,
                                tags: Object.assign({}, t),
                                lvalues: n
                            }, a ? {
                                extras: {
                                    data: JSON.stringify(a)
                                }
                            } : {}) ]
                        }),
                        url: this.apiLogUrl
                    };
                } catch (t) {
                    return null;
                }
            }
        }, {
            key: "pmmPage",
            value: function(e) {
                var t = e.pageSn, n = e.apiRatio, r = e.tags, i = void 0 === r ? {} : r, a = e.extras, o = e.values;
                try {
                    return {
                        payload: Object.assign(Object.assign({}, this.getBasePmmParams()), {
                            datas: [ Object.assign({
                                category: un.PAGE_LOG,
                                type: sn.PAGE_LOG_TYPE,
                                id_raw_value: t + "",
                                timestamp: Date.now(),
                                api_ratio: n,
                                tags: Object.assign({}, i),
                                lvalues: o
                            }, a ? {
                                extras: {
                                    data: JSON.stringify(a)
                                }
                            } : {}) ]
                        }),
                        url: this.pageLogUrl
                    };
                } catch (t) {
                    return null;
                }
            }
        }, {
            key: "pmmCustom",
            value: function(e) {
                var t = e.groupId, n = void 0 === t ? "10475" : t, r = e.tags, i = void 0 === r ? {} : r, a = e.extras, o = e.longValues, s = e.apiRatio, u = void 0 === s ? 1 : s;
                try {
                    return {
                        payload: Object.assign(Object.assign({}, this.getBasePmmParams()), {
                            datas: [ Object.assign({
                                category: un.CUSTOM_LOG,
                                type: sn.CUSTOM_LOG_TYPE,
                                id_raw_value: n,
                                timestamp: Date.now(),
                                api_ratio: u,
                                tags: Object.assign({}, i),
                                lvalues: o
                            }, a ? {
                                extras: this.formatStringObject(a)
                            } : {}) ]
                        }),
                        url: this.customLogUrl
                    };
                } catch (n) {
                    return null;
                }
            }
        } ]), e;
    }()))(), bn = {
        LAUNCH: "appLaunch",
        ROUTE: "route",
        FIRST_RENDER: "firstRender"
    }, yn = Object.freeze({
        __proto__: null,
        ENTRY_NAME: bn,
        PMM_CATEGORY: un,
        PMM_ERROR_CODE: ln,
        PMM_ERROR_MODULE: cn,
        PMM_LOG_TYPE: sn,
        PerformanceManagerBase: function() {
            function e(t) {
                g(this, e), this.LAUNCH_PAGE = 0, this.LAUNCH_PAGE = t, this.cacheData = {};
            }
            return h(e, [ {
                key: "listenPerformanceEntryChange",
                value: function() {
                    var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                    t.forEach(function(t) {
                        t && e.addPerformanceEntry(t);
                    });
                }
            }, {
                key: "addPerformanceEntry",
                value: function(e) {
                    e.name === bn.LAUNCH && this.trackLaunchPage(e);
                    var t = function() {
                        var e = st();
                        return null == e ? void 0 : e.pageProperties;
                    }();
                    if (t) {
                        var n = t.page_name, r = t.page_sn;
                        this.cacheData.pageName !== n && (this.cacheData = {
                            pageName: n,
                            pageSn: r
                        }), "navigation" === e.entryType && "navigateBack" !== e.navigationType && (this.cacheData.navigateStartTime = e.startTime, 
                        this.cacheData.navigateDuration = e.duration, e.name === bn.LAUNCH && (this.cacheData.isLaunch = !0)), 
                        e.name === bn.FIRST_RENDER && (this.cacheData.renderStartTime = e.startTime, this.cacheData.renderDuration = e.duration, 
                        this.trackPagePerformance(n));
                    }
                }
            }, {
                key: "trackLaunchPage",
                value: function(e) {
                    this.track({
                        pageSn: this.LAUNCH_PAGE,
                        extras: {},
                        phaseValues: [ e.startTime, e.duration ]
                    });
                }
            }, {
                key: "track",
                value: function(e) {
                    return mn.pmmPageLog(e);
                }
            }, {
                key: "trackPagePerformance",
                value: function(e) {
                    var t = this.cacheData, n = t.pageSn, r = t.pageName, i = t.isLaunch, a = t.navigateStartTime, o = void 0 === a ? 0 : a, s = t.navigateDuration, u = void 0 === s ? 0 : s, c = t.renderStartTime, l = void 0 === c ? 0 : c, f = t.renderDuration, h = void 0 === f ? 0 : f, g = l + h, d = i ? l - o : u;
                    r === e && (this.track({
                        pageSn: n,
                        extras: {},
                        phaseValues: [ o, d, l, h, g ]
                    }), this.cacheData = {});
                }
            } ]), e;
        }(),
        default: mn
    }), On = function() {
        function e() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            g(this, e), this.splits = [], this.lastSplitMap = {}, this.splitsCallback = {}, 
            this.endtimes = [], this.endTimesCallback = {}, this.passedTime = 0, this.currentTime = 0, 
            this.serverTime = 0;
            var n = t.serverTime, r = t.currentTime;
            this.updateServerTime({
                serverTime: n,
                currentTime: r
            }), this.init();
        }
        return h(e, [ {
            key: "init",
            value: function() {
                this.splits = [], this.lastSplitMap = {}, this.splitsCallback = {}, this.endtimes = [], 
                this.endTimesCallback = {}, this.passedTime = 0, this.startCountTime();
            }
        }, {
            key: "startCountTime",
            value: function() {
                var e = this;
                setTimeout(function() {
                    e.passedTime = Date.now() - e.currentTime, e.updateListener(), e.startCountTime();
                }, 100);
            }
        }, {
            key: "getCurrentTime",
            value: function() {
                return this.serverTime + Date.now() - this.currentTime;
            }
        }, {
            key: "updateServerTime",
            value: function(e) {
                var t = e.serverTime, n = e.currentTime;
                t !== this.serverTime && (this.serverTime = t, this.currentTime = n, this.passedTime = 0);
            }
        }, {
            key: "_addListener",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.split, n = e.endTime, r = this.serverTime + this.passedTime;
                if (t) {
                    var i = t.time, a = t.callback;
                    -1 === this.splits.indexOf(i) && this.splits.push(i), this.splitsCallback[i] || (this.splitsCallback[i] = []), 
                    a && a.call(this, {
                        currentTime: r
                    }), this.splitsCallback[i].push(a);
                }
                if (n) {
                    var o = n.time, s = n.callback;
                    o && s && (s.config = e, -1 === this.endtimes.indexOf(o) && this.endtimes.push(o), 
                    this.endTimesCallback[o] || (this.endTimesCallback[o] = []), this.endTimesCallback[o].push(s));
                }
            }
        }, {
            key: "addListener",
            value: function(e) {
                var t = this;
                return Array.isArray(e) ? e.map(function(e) {
                    t._addListener(e);
                }) : this._addListener(e), function() {
                    t.removeListener(e);
                };
            }
        }, {
            key: "removeListener",
            value: function(e) {
                var t = this;
                Array.isArray(e) ? e.map(function(e) {
                    t._removeListener(e);
                }) : this._removeListener(e);
            }
        }, {
            key: "_removeListener",
            value: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.split, n = e.endTime;
                if (t) {
                    var r = t.time, i = t.callback;
                    this.splitsCallback[r] && (this.splitsCallback[r] = this.splitsCallback[r].filter(function(e) {
                        return e !== i;
                    })), this.splitsCallback[r] && this.splitsCallback[r].length || !this.splits || (this.splits = this.splits.filter(function(e) {
                        return e !== r;
                    }));
                }
                if (n) {
                    var a = n.time, o = n.callback;
                    this.serverTime + this.passedTime >= a ? (this.endtimes && (this.endtimes = this.endtimes.filter(function(e) {
                        return e !== a;
                    })), delete this.endTimesCallback[a], o && o.config && o.config.split && this.removeListener({
                        split: o.config.split
                    })) : (this.endTimesCallback[a] && (this.endTimesCallback[a] = this.endTimesCallback[a].filter(function(e) {
                        return e !== o;
                    }), this.endTimesCallback[a].length || delete this.endTimesCallback[a]), this.endTimesCallback[a] && this.endTimesCallback[a].length || !this.endtimes || (this.endtimes = this.endtimes.filter(function(e) {
                        return e !== a;
                    })));
                }
            }
        }, {
            key: "updateListener",
            value: function() {
                var e = this, n = this.serverTime + this.passedTime;
                this.splits.map(function(r) {
                    var i = Math.floor(n / r);
                    e.lastSplitMap[r] !== i && (e.lastSplitMap[r] = i, t(e.splitsCallback[r]).map(function(t) {
                        setTimeout(function() {
                            t && t.call(e, {
                                currentTime: n
                            });
                        }, 0);
                    }));
                }), this.endtimes.map(function(r) {
                    r <= n && t(e.endTimesCallback[r]).map(function(t) {
                        setTimeout(function() {
                            t && t.call(e, {
                                currentTime: n
                            });
                        }, 0), e.removeListener({
                            endTime: {
                                time: r,
                                callback: t
                            }
                        });
                    });
                });
            }
        } ]), e;
    }(), kn = Date.now(), wn = new On({
        serverTime: kn,
        currentTime: kn
    });
    function Pn(e) {
        return 13 === "".concat(e).length ? e : 1e3 * e;
    }
    function _n() {
        return wn.getCurrentTime();
    }
    function Sn(e) {
        return 13 === "".concat(e).length;
    }
    var jn = Object.freeze({
        __proto__: null,
        TimeControl: On,
        getServerTimeSync: _n,
        timeControl: wn,
        updateServerTime: function(e) {
            var t = e.serverTime, n = e.clientTime, r = void 0 === n ? Date.now() : n;
            if (t) {
                var i = Pn(t), a = Pn(r);
                Sn(a) && Sn(i) && wn.updateServerTime({
                    serverTime: i,
                    currentTime: a
                });
            }
        }
    }), Cn = [], Tn = [], In = "", xn = !1, Ln = {
        "Content-Type": "application/json;charset=UTF-8",
        "Cache-Control": "no-cache"
    }, En = {
        WX_LOGIN_ERR: {
            type: 10001,
            msg: "wx.login接口调用失败"
        },
        PDD_QUIET_LOGIN_FAIL: {
            type: 10002,
            msg: "静默登录调用login接口失败"
        },
        PDD_LOGIN_ERR: {
            type: 10003,
            msg: "主动登录调用login接口失败"
        },
        CONFIG_ERR: {
            type: 10004,
            msg: "未通过config参数检查"
        },
        NETWORK_ERR: {
            type: 10005,
            msg: "调用wx.request失败"
        }
    };
    function An(e) {
        var t = e.success, n = e.fail, r = e.signIn;
        Cn.push(t), n && Tn.push(n), "begin" !== In && (In = "begin", Te.cancelEvent("signIn"), 
        xn = !1, r && r().then(function(e) {
            Cn.forEach(function(t) {
                ke(function() {
                    t(e);
                });
            });
        }, function(e) {
            Tn.forEach(function(t) {
                try {
                    t && t(e);
                } catch (e) {}
            });
        }).then(function() {
            In = "end", Cn = [], Tn = [];
        }));
    }
    function Rn(e, t) {
        xn = !0, Te.cancelEvent("signInFail"), Te.trigger("signIn", e, t);
    }
    function Dn(e, t) {
        xn = !1, Te.cancelEvent("signIn"), Te.trigger("signInFail", e, t);
    }
    function qn(e, t, n, r, i, a) {
        return new Promise(function(o, s) {
            try {
                wx.login({
                    timeout: 5e3,
                    success: function(u) {
                        if (!u || !u.code) return s(Object.assign(Object.assign({}, En.WX_LOGIN_ERR), {
                            detail: u
                        }));
                        var c = function(e, t, n, r, i, a) {
                            var o = {
                                code: e,
                                app_id: t,
                                has_auth: !1
                            };
                            return i && Object.assign(o, {
                                encrypted_data: n,
                                iv: r,
                                raw_data: i,
                                signature: a,
                                has_auth: !0
                            }), o;
                        }(u.code, e, n, r, t, i);
                        (function(e, t, n) {
                            return new Promise(function(r, i) {
                                try {
                                    wx.request({
                                        url: e,
                                        method: "POST",
                                        data: t,
                                        header: Ln,
                                        success: function(a) {
                                            if (!a || !a.data || !a.data.uid) {
                                                var o = {
                                                    detail: {
                                                        url: e,
                                                        data: t,
                                                        header: Ln,
                                                        res: a
                                                    }
                                                };
                                                return Object.assign(o, n ? En.PDD_LOGIN_ERR : En.PDD_QUIET_LOGIN_FAIL), i(o);
                                            }
                                            r(Object.assign({
                                                code: t.code
                                            }, a.data));
                                        },
                                        fail: function(e) {
                                            i(Object.assign(Object.assign({}, En.NETWORK_ERR), {
                                                detail: e
                                            }));
                                        }
                                    });
                                } catch (e) {
                                    i(Object.assign(Object.assign({}, En.NETWORK_ERR), {
                                        detail: e
                                    }));
                                }
                            });
                        })(a, c, t).then(o, s);
                    }
                });
            } catch (e) {
                s(Object.assign(Object.assign({}, En.WX_LOGIN_ERR), {
                    detail: e
                }));
            }
        });
    }
    function Un(e) {
        var t = e.config, n = e.userInfo;
        return new Promise(function(e, r) {
            ct("userinfo", null);
            var i = function(e) {
                return e && e.domain && e.loginAppId ? {
                    APPID: e.loginAppId,
                    LOGIN_URL: e.domain + "/login"
                } : null;
            }(t);
            if (i) {
                var a = i.APPID, o = i.LOGIN_URL, s = n || {}, u = s.encryptedData, c = s.iv;
                _e(2, qn, a, s.rawData, u, c, s.signature, o).then(function(t) {
                    if (t) return wx.setStorage({
                        key: "userinfo",
                        data: Object.assign(Object.assign({}, t), {
                            expire_stoarge: new Date().getTime() + 864e6
                        })
                    }).catch(ye), e(t);
                    r(t);
                }, r);
            } else r(Object.assign(Object.assign({}, En.CONFIG_ERR), {
                detail: t
            }));
        });
    }
    var Mn = Object.freeze({
        __proto__: null,
        getIsSigned: function() {
            return xn;
        },
        pddSignIn: function(e) {
            var t = e.config, n = e.userInfo;
            An({
                success: e.success,
                fail: e.fail,
                signIn: function() {
                    return new Promise(function(e, r) {
                        !function(e) {
                            var t = e.config, n = e.success, r = e.fail, i = e.userInfo, a = void 0 === i ? {} : i;
                            wx.getStorage({
                                key: "userinfo"
                            }).then(function(e) {
                                return e.data;
                            }, ye).then(function(e) {
                                return e || Un({
                                    config: t,
                                    userInfo: a
                                });
                            }).then(function(e) {
                                "function" == typeof n && n(e);
                            }).catch(function(e) {
                                "function" == typeof r && r(e);
                            });
                        }({
                            config: t,
                            userInfo: n,
                            success: function(t) {
                                Rn(t, "pddSignIn"), Te.trigger("signInComplete"), e(t);
                            },
                            fail: function(e) {
                                Dn(e, "pddSignIn"), Te.trigger("signInComplete"), r(e);
                            }
                        });
                    });
                }
            });
        },
        signInBase: An,
        signInReq: function(e) {
            var t = e.config, n = e.userInfo;
            An({
                success: e.success,
                fail: e.fail,
                signIn: function() {
                    return Un({
                        config: t,
                        userInfo: n
                    }).then(function(e) {
                        return Rn(e, "signInReq"), e;
                    }, function(e) {
                        throw Dn(e, "signInReq"), e;
                    });
                }
            });
        }
    });
    function $n(e, t) {
        var n = {};
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
            var i = 0;
            for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
        }
        return n;
    }
    var Nn = {
        1007: "singlemessage",
        1008: "groupmessage",
        1044: "groupmessage"
    };
    function Fn(e, t) {
        var n = this, r = e.getState(), i = {}, a = !1;
        Object.keys(r).forEach(function(e) {
            var t = r[e];
            Object.keys(t).forEach(function(e) {
                Object.prototype.hasOwnProperty.call(n.data, e) && (Object.assign(i, o({}, e, t[e])), 
                a || void 0 === t[e] || t[e] === n.data[e] || (a = !0));
            });
        }), a && function(e) {
            t && Object.assign(e, t.call(n, e)), n.setData(e);
        }(i);
    }
    function Bn(e) {
        var t, n, r = e.onGrayChange, i = e.store, a = e.dataObservers;
        return {
            $getBaseLogParams: function() {
                var e = this.$currentPage;
                if (e) {
                    var t = e.pageProperties, n = e.route, r = void 0 === n ? "" : n, i = e.$query, a = e.$pageId, o = t || {}, s = o.page_sn, u = void 0 === s ? "" : s, c = o.page_name, l = void 0 === c ? "" : c;
                    return {
                        page_url: Me(r, i),
                        page_id: a,
                        page_sn: "".concat(u),
                        page_name: l
                    };
                }
                return {};
            },
            $impr: function(e) {
                Qt.call(this, e);
            },
            $click: function(e) {
                Kt.call(this, e);
            },
            $getPageId: function() {
                var e = this.$currentPage;
                if (e) return e.$pageId;
            },
            $showLoading: function(e) {
                pt(Object.assign(Object.assign({}, e), {
                    page: this.$currentPage
                }));
            },
            $hideLoading: function() {
                dt.apply(void 0, arguments);
            },
            $showToast: function(e) {
                var t = e.title, n = void 0 === t ? "" : t, r = e.icon, i = void 0 === r ? "none" : r, a = e.duration, o = void 0 === a ? 2e3 : a;
                this.$currentPage && !this.$currentPage.$visible || vt({
                    title: n,
                    icon: i,
                    duration: o
                });
            },
            $setDataAsync: function(e) {
                var t = this;
                return new Promise(function(n) {
                    t.setData(e, function() {
                        n();
                    });
                });
            },
            $removePageShowCallback: function(e) {
                var t = this.$currentPage;
                t && (t.$nextShowCallback.all = t.$nextShowCallback.all.filter(function(t) {
                    return t !== e;
                }));
            },
            $onPageShowCallback: function(e) {
                var t = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = this.$currentPage;
                return r && (r.$nextShowCallback.all.push(e), r.$visible && r.$hasShow && !n.abortCurrentVisible && e.call(this)), 
                function() {
                    t.$removePageShowCallback(e);
                };
            },
            $addPageShowCallback: function(e, t) {
                var n = this;
                return this.$onPageShowCallback(function t() {
                    for (var r = arguments.length, i = new Array(r), a = 0; a < r; a++) i[a] = arguments[a];
                    n.$removePageShowCallback(t), e.apply(n, i);
                }, t);
            },
            $addNextShowCallback: function(e) {
                var t = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = function n() {
                    for (var r = arguments.length, i = new Array(r), a = 0; a < r; a++) i[a] = arguments[a];
                    t.$removePageShowCallback(n), e.apply(t, i);
                };
                return this.$onPageShowCallback(r, Object.assign(Object.assign({}, n), {
                    abortCurrentVisible: !0
                }));
            },
            $addNextHideCallback: function(e, t) {
                var n = this;
                return this.$onNextHideCallback(function t() {
                    for (var r = arguments.length, i = new Array(r), a = 0; a < r; a++) i[a] = arguments[a];
                    n.$removeNextHideCallback(t), e.apply(n, i);
                }, t);
            },
            $onNextHideCallback: function(e) {
                var t = this, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = this.$currentPage;
                return r && (r.$nextHideCallback.all.push(e), r.$visible || n.abortCurrentVisible || e.call(this)), 
                function() {
                    t.$removeNextHideCallback(e);
                };
            },
            $removeNextHideCallback: function(e) {
                var t = this.$currentPage;
                t && (t.$nextHideCallback.all = t.$nextHideCallback.all.filter(function(t) {
                    return t !== e;
                }));
            },
            $injectGray: function() {
                var e = this, n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i = this.$currentPage;
                if (i) {
                    var a = i.$getGrayCenter(), o = this.data.$gray;
                    o && a && (this.$unjectGray(), t = a.storeInject({
                        forceUpdate: n,
                        data: o,
                        callback: function(t) {
                            var n = Object.assign(Object.assign({}, e.data.$gray), t);
                            e.setData({
                                $gray: n,
                                $grayInit: !0
                            }), r && r.call(e, n);
                        }
                    }));
                }
            },
            $unjectGray: function() {
                t && t(), t = null;
            },
            $subscribeStore: function() {
                var e = this;
                i && (this.$unSubscribeStore(), Fn.call(this, i, a), n = i.subscribe(function() {
                    Fn.call(e, i, a);
                }));
            },
            $unSubscribeStore: function() {
                n && n(), n = null;
            }
        };
    }
    function zn(e, t) {
        if (t && e) {
            var n = e.getState();
            Object.keys(n).some(function(e) {
                return Object.keys(n[e]).some(function(e) {
                    return Object.prototype.hasOwnProperty.call(t, e);
                });
            }) && this.$subscribeStore();
        }
    }
    function Gn(e) {
        var t = e.store, n = e.enableStore;
        return Behavior({
            pageLifetimes: {
                show: function() {
                    n && t && zn.call(this, t, this.data);
                },
                hide: function() {
                    n && this.$unSubscribeStore();
                }
            },
            lifetimes: {
                attached: function() {
                    n && t && zn.call(this, t, this.data);
                },
                detached: function() {
                    n && this.$unSubscribeStore();
                }
            }
        });
    }
    function Vn() {
        for (var e = getCurrentPages() || [], t = e.length - 1; t >= 0; t--) {
            var n = e[t], r = n.$unLoad, i = n.$visible;
            if (!r && i) return n;
        }
        return e[0];
    }
    function Hn(e) {
        var t, n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r = getCurrentPages();
        if (e = e || ut.call(this)) {
            var i = null === (t = getApp()) || void 0 === t ? void 0 : t.getMainTabPage(e);
            if (i) return i;
            for (;r.length; ) {
                var a = r.pop();
                if (ut.call(a) === e) return a;
            }
        } else "function" == typeof this.$error && this.$error({
            msg: "get Page not found, use current visible or null"
        });
        return n ? null : Vn();
    }
    var Wn = Behavior({
        lifetimes: {
            created: function() {
                this.wxPageId = ut.call(this);
            },
            attached: function() {
                this.$currentPage = Hn.call(this);
            },
            detached: function() {
                this.$currentPage = null;
            }
        }
    }), Kn = Behavior({
        lifetimes: {
            attached: function() {
                var e, t, n = this, r = this.data && this.data.$gray;
                r && (this.cancelPageShows || (this.cancelPageShows = new Set()), this.cancelPageHides || (this.cancelPageHides = new Set()), 
                this.$injectGray(), null === (e = this.cancelPageShows) || void 0 === e || e.add(this.$onPageShowCallback(function() {
                    n.$currentPage && n.$injectGray();
                }, {
                    abortCurrentVisible: !0
                })), null === (t = this.cancelPageHides) || void 0 === t || t.add(this.$onNextHideCallback(function() {
                    n.$currentPage && r && n.$unjectGray();
                })));
            },
            detached: function() {
                this.$unjectGray(), this.cancelPageShows && this.cancelPageShows.forEach(function(e) {
                    e && e();
                }), this.cancelPageShows = null, this.cancelPageHides && this.cancelPageHides.forEach(function(e) {
                    e && e();
                }), this.cancelPageHides = null;
            }
        }
    }), Qn = Object.freeze({
        __proto__: null,
        EventChannel: function() {
            function e(t) {
                g(this, e), this.emitEvents = [], this.listenEvents = [], this.$page = t;
            }
            return h(e, [ {
                key: "emit",
                value: function(e, t) {
                    Te.triggerOnce(e, t);
                }
            }, {
                key: "emitPromise",
                value: function(e, t) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    Te.trigger(e, t), n && this.emitEvents.push(e);
                }
            }, {
                key: "once",
                value: function(e, t) {
                    this._on(e, t, !0);
                }
            }, {
                key: "onOnShow",
                value: function(e, t) {
                    var n = this;
                    this.on(e, function() {
                        for (var e = arguments.length, r = new Array(e), i = 0; i < e; i++) r[i] = arguments[i];
                        n.$page.$addNextShowCallback(function() {
                            t.apply(n, r);
                        }, r);
                    });
                }
            }, {
                key: "onceOnShow",
                value: function(e, t) {
                    var n = this;
                    this.once(e, function() {
                        for (var e = arguments.length, r = new Array(e), i = 0; i < e; i++) r[i] = arguments[i];
                        n.$page.$addNextShowCallback(function() {
                            t.apply(n, r);
                        }, r);
                    });
                }
            }, {
                key: "on",
                value: function(e, t) {
                    this._on(e, t, !1);
                }
            }, {
                key: "_on",
                value: function(e, t, n) {
                    var r = n ? Te.listenOnce(e, t) : Te.listen(e, t);
                    this.listenEvents.push({
                        event: e,
                        cancelCB: r
                    });
                }
            }, {
                key: "off",
                value: function(e, t) {
                    var n = this.listenEvents.filter(function(n) {
                        var r = n.event, i = n.cancelCB;
                        return !(r === e && (!t || t === i));
                    });
                    this.listenEvents.forEach(function(n) {
                        var r = n.event, i = n.cancelCB;
                        r !== e || t && t !== i || i && i();
                    }), this.listenEvents = n;
                }
            }, {
                key: "clear",
                value: function() {
                    this.emitEvents.forEach(function(e) {
                        Te.cancelEvent(e);
                    }), this.listenEvents.forEach(function(e) {
                        var t = e.cancelCB;
                        t && t();
                    });
                }
            }, {
                key: "cancel",
                value: function(e) {
                    Te.cancel(e);
                }
            } ]), e;
        }(),
        baseMethods: Bn,
        getCurrentVisiblePage: Vn,
        getPage: Hn,
        getPageId: function(e) {
            var t = e.pageProperties, n = (t = void 0 === t ? {} : t).page_sn;
            return [ void 0 === n ? "0" : n, _n(), Oe().substring(0, 10) ].join("_");
        },
        injectStore: zn,
        pddApp: function(e) {
            var t = e.onLaunch, n = e.onShow, r = e.onHide;
            App(Object.assign(Object.assign({
                error: function(e) {}
            }, e), {
                $hotLaunchFlag: !1,
                $coldLaunchFlag: !1,
                $visible: !1,
                $globalPageQuery: {},
                $blockPageOnLoad: !1,
                $scene: 0,
                $sessionId: "",
                $performance: {
                    appShowTime: 0,
                    appLaunchTime: 0,
                    appHideTime: 0
                },
                onLaunch: function(e) {
                    var n, r = this;
                    this.$performance.appLaunchTime = Date.now(), this.$coldLaunchFlag = !0, this.$hotLaunchFlag = !0, 
                    this.$sessionId = Oe(), Te.listen("signIn", null === (n = this.onSign) || void 0 === n ? void 0 : n.bind(this)), 
                    Te.listenOnce("signInComplete", function() {
                        r.onSignInComplete && r.onSignInComplete(e);
                    });
                    var i = e.scene;
                    this.$scene = i, t && t.call(this, e);
                },
                onShow: function(e) {
                    this.$performance.appShowTime = Date.now(), this.$visible = !0, this.$hotLaunchFlag = !0, 
                    this.$sessionId = Oe();
                    var t = e.scene, r = e.referrerInfo;
                    this.$scene = t, mn.setPmmBasicParams({
                        scene_id: t,
                        refer_share_from: Nn[t] || t,
                        referrer_app_id: (null == r ? void 0 : r.appId) || ""
                    }), n && n.call(this, e);
                },
                onHide: function() {
                    this.$visible = !1, this.$performance.appHideTime = Date.now(), r && r.call(this);
                },
                mainPages: {},
                getMainTabPage: function(e) {
                    return this.mainPages[e];
                },
                mainTabPageCreated: function(e, t) {
                    e && (this.mainPages[e] = t);
                },
                delayReport: function(e) {
                    try {
                        if ("error" === (null == e ? void 0 : e.type)) {
                            e.type;
                            var t = $n(e, [ "type" ]);
                            this.error(Object.assign({}, t));
                        }
                    } catch (t) {
                        this.error({
                            msg: "delay report failed",
                            data: e
                        });
                    }
                }
            }));
        },
        pddBehavior: function(e) {
            return Behavior(Object.assign(Object.assign({}, e), {
                behaviors: e.behaviors
            }));
        },
        pddComponent: function(e) {
            var n = e.methods, r = e.behaviors, i = void 0 === r ? [] : r, a = $n(e, [ "methods", "behaviors" ]);
            Component(Object.assign(Object.assign({}, a), {
                behaviors: [ Wn, Gn(a), Kn ].concat(t(i)),
                methods: Object.assign(Object.assign({}, n), Bn(a))
            }));
        },
        updateStoreData: Fn
    });
    a.__esModule || Object.defineProperty(a, "__esModule", {
        value: !0
    }), Object.defineProperty(a, "constants", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return m;
        }
    }), Object.defineProperty(a, "event", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Ie;
        }
    }), Object.defineProperty(a, "gray", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Ee;
        }
    }), Object.defineProperty(a, "list", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Ae;
        }
    }), Object.defineProperty(a, "log", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Yt;
        }
    }), Object.defineProperty(a, "navigate", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return on;
        }
    }), Object.defineProperty(a, "pmm", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return yn;
        }
    }), Object.defineProperty(a, "request", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Dt;
        }
    }), Object.defineProperty(a, "time", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return jn;
        }
    }), Object.defineProperty(a, "url", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Ne;
        }
    }), Object.defineProperty(a, "user", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Mn;
        }
    }), Object.defineProperty(a, "utils", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return je;
        }
    }), Object.defineProperty(a, "wxapp", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return Qn;
        }
    }), Object.defineProperty(a, "wxappUtils", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return jt;
        }
    });
}, function(e) {
    return a({}[e], e);
}), a(1688393929378));