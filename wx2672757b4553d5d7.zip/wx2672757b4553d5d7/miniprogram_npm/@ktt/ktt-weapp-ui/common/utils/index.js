Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.measureStringWidth = exports.getSystemInfoSync = exports.px2rpx = void 0;

var t = require("@ktt/ktt-wxapp-boundle");

exports.px2rpx = function(e) {
    return e * (750 / (t.utils.safeGet(t.wxappUtils.getSystemInfoSync() || {}, "windowWidth") || 375));
}, exports.getSystemInfoSync = t.wxappUtils.getSystemInfoSync, exports.measureStringWidth = function(t, e) {
    if (!t) return 0;
    var r = t.match(/[\x00-\x7F]/g), n = r ? r.length : 0;
    return (t.length - n / 2) * e;
};