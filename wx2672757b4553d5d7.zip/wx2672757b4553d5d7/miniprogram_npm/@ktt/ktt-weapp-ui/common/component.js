var t = function() {
    return (t = Object.assign || function(t) {
        for (var e, s = 1, o = arguments.length; s < o; s++) for (var n in e = arguments[s]) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
        return t;
    }).apply(this, arguments);
};

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.KttComponent = void 0, exports.KttComponent = function(e) {
    var s = t({}, e);
    s.externalClasses = s.externalClasses || [], s.externalClasses.push("custom-class"), 
    s.behaviors = s.behaviors || [], s.options = t({
        multipleSlots: !0,
        addGlobalClass: !0
    }, s.options || {}), Component(s);
};