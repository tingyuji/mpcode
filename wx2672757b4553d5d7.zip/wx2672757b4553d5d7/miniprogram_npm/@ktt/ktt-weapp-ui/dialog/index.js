Object.defineProperty(exports, "__esModule", {
    value: !0
});

(0, require("../common/component").KttComponent)({
    options: {
        styleIsolation: "apply-shared"
    },
    externalClasses: [ "ex-cls-bg-class", "ex-cls-close-icon-style" ],
    properties: {
        styles: {
            type: String,
            value: ""
        },
        showClose: {
            type: Boolean,
            value: !0
        },
        closeType: {
            type: String,
            value: "default"
        },
        disableScroll: {
            type: Boolean,
            value: !0
        },
        canBgClose: {
            type: Boolean,
            value: !0
        },
        useDefaultBg: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        CLOSE_TYPES: {
            DEFAULT: "default",
            INNER: "inner",
            ACT: "act"
        }
    },
    methods: {
        closeDialog: function() {
            this.triggerEvent("close");
        },
        move: function() {}
    }
});