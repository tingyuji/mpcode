Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../common/utils/index"), t = require("../common/component"), i = (0, 
e.getSystemInfoSync)(), o = i.screenHeight, n = i.screenWidth, s = o ? "".concat(((0, 
e.px2rpx)(o || 0) / 2).toFixed(0), "rpx") : "50vh", a = n ? "".concat(((0, e.px2rpx)(n || 0) / 2).toFixed(0), "rpx") : "50vw";

(0, t.KttComponent)({
    properties: {},
    data: {
        title: "加载中",
        screenHeightHf: s,
        screenWidthHf: a,
        showLoadingToast: !1
    },
    showLoadingTimer: null,
    created: function() {
        this.showLoadingTimer = null;
    },
    methods: {
        showLoading: function(e) {
            var t = this, i = e.title, o = void 0 === i ? "加载中" : i, n = e.delay, s = void 0 === n ? 1e3 : n;
            this.showLoadingTimer = setTimeout(function() {
                t.setData({
                    showLoadingToast: !0
                });
            }, s), this.setData({
                title: o
            });
        },
        hideLoading: function() {
            this.showLoadingTimer && clearTimeout(this.showLoadingTimer), this.showLoadingTimer = null, 
            this.setData({
                showLoadingToast: !1
            });
        }
    }
});