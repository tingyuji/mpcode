Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("@ktt/ktt-wxapp-boundle"), t = require("./behaviors/unicodeFix"), a = e.utils.debounce;

Component({
    behaviors: [ t.unicodeFixBehaviors ],
    externalClasses: [ "ex-cls-search-class", "ex-cls-search-area-class", "ex-cls-search-input-class" ],
    properties: {
        showScrollPlaceholder: {
            type: Boolean,
            value: !1
        },
        noBtn: {
            type: Boolean,
            value: !1
        },
        inputClass: {
            type: String,
            value: ""
        },
        searchValue: {
            type: String,
            value: "",
            observer: function(e) {
                this.setData({
                    inputValue: e
                });
            }
        },
        placeholder: {
            type: String,
            value: ""
        },
        placeholderStyle: {
            type: String,
            value: ""
        },
        doesLiveSearch: {
            type: Boolean,
            value: !1
        },
        onBlurSearch: {
            type: Boolean,
            value: !0
        },
        cursorSpacing: {
            type: Number,
            value: 40
        },
        focus: {
            type: Boolean,
            value: !1
        },
        isPlaceHolderAlignLeft: {
            type: Boolean,
            value: !1
        },
        wordList: {
            type: Array,
            value: [],
            observer: function(e) {
                if (this.data.showScrollPlaceholder) {
                    var t = e.map(this.getWordText);
                    this.setData({
                        scrollList: t,
                        scrollPlaceholder: t[0] || ""
                    });
                }
            }
        }
    },
    data: {
        inputValue: "",
        current: 0,
        scrollPlaceholder: ""
    },
    methods: {
        getWordText: function(e) {
            return "string" == typeof e ? e : e.value;
        },
        changeIndex: function(e) {
            "autoplay" === e.detail.source && this.setData({
                current: e.detail.current,
                scrollPlaceholder: this.getWordText(this.data.wordList[e.detail.current])
            });
        },
        ignoreTap: function() {},
        handleBlur: function() {
            var e = this;
            this.setData({
                focus: !1
            }, function() {
                e.data.onBlurSearch && e.triggerSearch();
            }), this.triggerEvent("blur");
        },
        handleClear: function() {
            var e = this;
            this.triggerEvent("input", {
                value: ""
            }), this.setData({
                inputValue: "",
                focus: !1
            }, function() {
                e.data.showScrollPlaceholder || e.triggerSearch();
            });
        },
        handleFocus: function() {
            this.setData({
                focus: !0
            }), this.triggerEvent("focus");
        },
        handleTap: function() {
            this.setData({
                focus: !0
            });
        },
        handleSearch: function() {
            var e = this, t = this.data, a = t.showScrollPlaceholder, r = t.inputValue, i = t.current, l = t.wordList, n = {
                focus: !1
            }, o = a && "" === r;
            o && (n.inputValue = this.getWordText(l[i])), this.setData(n, function() {
                e.triggerSearch(o ? l[i] : null);
            });
        },
        handleInput: function(e) {
            var t = this, a = e.detail.value;
            this.triggerEvent("input", {
                value: a
            }), this.setData({
                inputValue: a
            }, function() {
                t.data.doesLiveSearch && t.triggerSearch();
            });
        },
        triggerSearch: a(function(e) {
            var t = this.data.inputValue, a = void 0 === t ? "" : t, r = this.handleFixUnicode(a.trim());
            this.triggerEvent("onSearch", {
                value: r,
                ext: e
            }), this.setData({
                inputValue: r
            });
        })
    }
});