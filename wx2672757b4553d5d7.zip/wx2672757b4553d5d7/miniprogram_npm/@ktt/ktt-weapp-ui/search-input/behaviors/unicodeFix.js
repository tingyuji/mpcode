Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.unicodeFixBehaviors = void 0;

var e = {
    handleFixUnicode: function(e) {
        try {
            var r = e.length, t = JSON.stringify(e);
            if (r + 2 === t.length) return e;
            var i = JSON.parse(t.replace(/((?:[^\\]|^)(?:\\\\)*)(\\u.{4})+/g, "$1"));
            return i.length, i;
        } catch (r) {
            return e;
        }
    }
};

exports.unicodeFixBehaviors = Behavior({
    methods: e
});