Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../common/component");

(0, e.KttComponent)({
    externalClasses: [ "ex-cls-no-more-class" ],
    options: {
        virtualHost: !0
    },
    properties: {
        rootMargin: {
            type: Number,
            value: 0
        },
        styles: {
            type: String,
            value: ""
        },
        topLoadMore: {
            type: Boolean,
            value: !1
        },
        hasMore: {
            type: Boolean,
            value: !0,
            observer: function(e) {
                this.sameComponentHeightAppearCnt = 0, this.checkInfiniteContentHeight(), e || this.setData({
                    triggerLock: !1
                });
            }
        },
        loading: {
            type: Boolean,
            value: !1
        },
        reload: {
            type: Boolean,
            value: !1
        },
        noMoreText: {
            type: String,
            value: "已经没有更多了"
        },
        noMoreBgColor: {
            type: String,
            value: "#f0f0f0"
        },
        observerBgColor: {
            type: String,
            value: "transparent"
        },
        loadMoreError: {
            type: Boolean,
            value: !1
        },
        useNewObserver: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        triggerLock: !1
    },
    pageLifetimes: {
        show: function() {
            if (this.data.reload) try {
                this.observer.disconnect(), this.observer = null, this.resetObserver();
            } catch (e) {}
        }
    },
    lifetimes: {
        ready: function() {
            this.currentHeight = 0, this.sameComponentHeightAppearCnt = 0, this.setTimeoutHandler = null, 
            this.sampleRate = 3, this.isCheckingHeight = !1, this.resetObserver();
        },
        detached: function() {
            this.observer && this.observer.disconnect(), this.setTimeoutHandler && clearTimeout(this.setTimeoutHandler);
        }
    },
    methods: {
        onEnter: function() {
            var e = this.data, t = e.hasMore, r = e.loading, i = e.triggerLock, o = e.loadMoreError;
            !t || r || o || (i || this.triggerEvent("loadMore"), this.isCheckingHeight || (this.sampleRate--, 
            this.sampleRate = Math.max(0, this.sampleRate), this.sampleRate || this.checkInfiniteContentHeight()));
        },
        queryHeight: function(e) {
            var t = this;
            return new Promise(function(r) {
                try {
                    var i = t.createSelectorQuery();
                    e && i.select(e).boundingClientRect(), i.exec(function(e) {
                        var t = (e.pop() || {}).height || 0;
                        r(t);
                    });
                } catch (e) {
                    r(0);
                }
            });
        },
        checkInfiniteContentHeight: function() {
            var e = this, t = this.data, r = t.hasMore, i = t.triggerLock;
            this.sampleRate = 3, !this.isCheckingHeight && r && (this.isCheckingHeight = !0, 
            this.queryHeight("#infinite-content").then(function(t) {
                e.isCheckingHeight = !1;
                var r = Math.floor(t);
                r !== e.currentHeight ? (e.currentHeight = r, e.sameComponentHeightAppearCnt = 0, 
                e.setData({
                    triggerLock: !1
                })) : e.data.hasMore && !e.data.loading && (e.sameComponentHeightAppearCnt++, e.sameComponentHeightAppearCnt >= 2 && !i && (e.setData({
                    triggerLock: !0
                }), e.triggerEvent("onDetactLoadError", {
                    height: e.currentHeight
                })));
            }));
        },
        resetObserver: function() {
            var e = this, t = this.data, r = t.topLoadMore, i = t.rootMargin;
            this.observer = this.createIntersectionObserver({});
            var o = r ? {
                top: i
            } : {
                bottom: i
            };
            this.observer.relativeToViewport(o).observe(".infiniteList-observer", function(t) {
                (t || {}).intersectionRatio > 0 && (e.onEnter(), e.observer.disconnect(), e.observer = null, 
                e.setTimeoutHandler = setTimeout(function() {
                    return e.resetObserver();
                }, 300));
            });
        },
        handleReloadList: function() {
            this.triggerEvent("loadMore"), this.sampleRate = 3, this.sameComponentHeightAppearCnt = 0, 
            this.setData({
                triggerLock: !1,
                loadMoreError: !1
            });
        }
    }
});