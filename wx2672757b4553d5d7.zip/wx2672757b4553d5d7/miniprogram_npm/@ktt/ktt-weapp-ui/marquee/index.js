Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../common/component"), t = require("../common/utils/index");

(0, e.KttComponent)({
    properties: {
        content: {
            type: String,
            value: "",
            observer: function(e) {
                var a = (0, t.measureStringWidth)(e, this.data.fontSize);
                this.setData({
                    width: a,
                    duration: a / this.data.speed
                });
            }
        },
        fontSize: {
            type: Number,
            value: 24
        },
        maxWidth: {
            type: Number,
            value: 600
        },
        speed: {
            type: Number,
            value: 75
        },
        isActive: {
            type: Boolean,
            value: !1
        },
        delay: {
            type: Number,
            value: 2
        }
    },
    data: {},
    methods: {}
});