Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("../common/component"), e = require("../common/utils/index");

(0, t.KttComponent)({
    externalClasses: [ "ex-cls-button-class" ],
    properties: {
        type: {
            type: String,
            value: "confirm"
        },
        text: {
            type: String,
            value: ""
        }
    },
    data: {
        platform: {}
    },
    lifetimes: {
        attached: function() {
            var t = (0, e.getSystemInfoSync)(), o = {
                isIOS: t.platform && "ios" === t.platform.toLowerCase(),
                isAndroid: t.platform && "android" === t.platform.toLowerCase()
            };
            this.setData({
                platform: o
            });
        }
    }
});