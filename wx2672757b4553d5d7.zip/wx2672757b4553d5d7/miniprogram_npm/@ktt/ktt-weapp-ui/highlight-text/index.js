Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = require("../common/component");

(0, t.KttComponent)({
    externalClasses: [ "ex-cls-highlight" ],
    properties: {
        text: {
            type: String,
            observer: "textChanged"
        },
        keyword: {
            type: String,
            observer: "keywordChanged"
        }
    },
    data: {
        textArr: [],
        skeyword: "",
        stext: ""
    },
    lifetimes: {},
    methods: {
        keywordChanged: function(t) {
            this.skeyword = t, this.manage();
        },
        textChanged: function(t) {
            this.stext = t, this.manage();
        },
        manage: function() {
            this.stext && this.manageText(this.stext, this.skeyword || "");
        },
        manageText: function(t, e) {
            if (e) {
                var n = t.split("%%").map(function(t) {
                    return function(t, e) {
                        return t.replace(new RegExp("".concat(e), "g"), "".concat("%%").concat(e).concat("%%")).split("%%").filter(function(t) {
                            return "" !== t;
                        });
                    }(t, e);
                }), r = [];
                n.forEach(function(t, e) {
                    r = 0 === e ? r.concat(t) : r.concat("%%", t);
                }), this.setData({
                    textArr: r
                });
            } else this.setData({
                textArr: [ t ]
            });
        }
    }
});