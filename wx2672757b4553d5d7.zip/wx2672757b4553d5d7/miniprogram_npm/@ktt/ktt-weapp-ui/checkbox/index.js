Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").KttComponent)({
    externalClasses: [ "ex-cls-unselected-icon-class", "ex-cls-selected-icon-class", "ex-cls-unselected-icon-disabled-class" ],
    properties: {
        disabled: {
            type: Boolean,
            value: !1
        },
        select: {
            type: Boolean,
            value: !1
        },
        width: {
            type: String,
            value: "36"
        },
        height: {
            type: String,
            value: "36"
        }
    },
    data: {},
    lifetimes: {
        attached: function() {}
    },
    methods: {
        handleClick: function() {
            this.data.disabled ? this.triggerEvent("clickDisabled") : this.triggerEvent("onClick");
        }
    }
});