Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.iconUrlMap = void 0, exports.iconUrlMap = {
    default: "https://funimg.pddpic.com/wxappimg/bd6f1abd-a01b-4df5-a1a7-bcc375039c59.png.slim.png",
    network: "https://funimg.pddpic.com/wxappimg/012cd227-eff2-4839-947a-de4bed44ae22.png.slim.png",
    search: "https://funimg.pddpic.com/wxappimg/28f4df14-0da0-44c8-ae81-b923106bfa47.png.slim.png",
    order: "https://funimg.pddpic.com/wxappimg/e0241791-d63b-4588-99c7-20d6691cd16e.png.slim.png",
    shoppingCard: "https://funimg.pddpic.com/wxappimg/2b6876cd-b270-4282-952b-30681fcea343.png.slim.png",
    goods: "https://funimg.pddpic.com/wxappimg/927525f4-1890-497f-b39a-31f04a332211.png.slim.png",
    message: "https://funimg.pddpic.com/wxappimg/9401c4ba-6ced-4894-a49b-b4bfc331a5e0.png.slim.png",
    remove: "https://funimg.pddpic.com/wxappimg/d77c973d-1019-42be-924e-9dcf2f2e1c4e.png.slim.png"
}, Component({
    externalClasses: [ "ex-cls-external-class" ],
    properties: {
        url: {
            type: String,
            value: ""
        },
        type: {
            type: String,
            value: "default"
        },
        hintText: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        content: {
            type: String,
            value: ""
        },
        topMarginRatio: {
            type: Number,
            value: 1
        },
        bottomMarginRatio: {
            type: Number,
            value: 2
        }
    },
    data: {
        iconUrlMap: exports.iconUrlMap
    },
    methods: {}
});