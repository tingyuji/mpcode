var _interopRequireDefault = require("../../../_/helpers/interopRequireDefault"), _classCallCheck2 = require("../../../_/helpers/classCallCheck"), _createClass2 = require("../../../_/helpers/createClass"), _possibleConstructorReturn2 = require("../../../_/helpers/possibleConstructorReturn"), _inherits2 = require("../../../_/helpers/inherits"), _createSuper2 = require("../../../_/helpers/createSuper"), _regenerator = _interopRequireDefault(require("../../../_/regenerator")), _objectSpread2 = require("../../../_/helpers/objectSpread2"), _asyncToGenerator2 = require("../../../_/helpers/asyncToGenerator");

require("../../../_/helpers/Objectvalues");

var _typeof3 = require("../../../_/helpers/typeof");

module.exports = function() {
    var __MODS__ = {}, __DEFINE__ = function(t, e, n) {
        __MODS__[t] = {
            status: 0,
            func: e,
            req: n,
            m: {
                exports: {},
                _tempexports: {}
            }
        };
    }, __REQUIRE__ = function(t, e) {
        if (!__MODS__[t]) return require(e);
        if (!__MODS__[t].status) {
            var n = __MODS__[t].m;
            n._exports = n._tempexports;
            var i = Object.getOwnPropertyDescriptor(n, "exports");
            i && i.configurable && Object.defineProperty(n, "exports", {
                set: function(t) {
                    "object" === _typeof3(t) && t !== n._exports && (n._exports.__proto__ = t.__proto__, 
                    Object.keys(t).forEach(function(e) {
                        n._exports[e] = t[e];
                    })), n._tempexports = t;
                },
                get: function() {
                    return n._tempexports;
                }
            }), __MODS__[t].status = 1, __MODS__[t].func(__MODS__[t].req, n, n.exports);
        }
        return __MODS__[t].m.exports;
    }, __REQUIRE_WILDCARD__ = function(t) {
        if (t && t.__esModule) return t;
        var e = {};
        if (null != t) for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
        return e.default = t, e;
    }, __REQUIRE_DEFAULT__ = function(t) {
        return t && t.__esModule ? t.default : t;
    };
    return __DEFINE__(1688393929381, function(require, module, exports) {
        Object.defineProperty(exports, "__esModule", {
            value: !0
        });
        var UrlParse = require("url-parse"), commonjsGlobal = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
        function getDefaultExportFromCjs(t) {
            return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
        }
        function commonjsRequire(t) {
            throw new Error('Could not dynamically require "' + t + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
        }
        var eventemitter3_min = {
            exports: {}
        }, t, e;
        t = eventemitter3_min, e = eventemitter3_min.exports, function(n) {
            var i;
            "object" == (i = e, "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? _typeof3(i) : i && "function" == typeof Symbol && i.constructor === Symbol && i !== Symbol.prototype ? "symbol" : _typeof3(i)) ? t.exports = n() : ("undefined" != typeof window ? window : void 0 !== commonjsGlobal ? commonjsGlobal : "undefined" != typeof self ? self : this).EventEmitter3 = n();
        }(function() {
            return function t(e, n, i) {
                function r(s, a) {
                    if (!n[s]) {
                        if (!e[s]) {
                            var u = "function" == typeof commonjsRequire && commonjsRequire;
                            if (!a && u) return u(s, !0);
                            if (o) return o(s, !0);
                            var c = new Error("Cannot find module '" + s + "'");
                            throw c.code = "MODULE_NOT_FOUND", c;
                        }
                        var f = n[s] = {
                            exports: {}
                        };
                        e[s][0].call(f.exports, function(t) {
                            return r(e[s][1][t] || t);
                        }, f, f.exports, t, e, n, i);
                    }
                    return n[s].exports;
                }
                for (var o = "function" == typeof commonjsRequire && commonjsRequire, s = 0; s < i.length; s++) r(i[s]);
                return r;
            }({
                1: [ function(t, e, n) {
                    var i = Object.prototype.hasOwnProperty, r = "~";
                    function o() {}
                    function s(t, e, n) {
                        this.fn = t, this.context = e, this.once = n || !1;
                    }
                    function a(t, e, n, i, o) {
                        if ("function" != typeof n) throw new TypeError("The listener must be a function");
                        var a = new s(n, i || t, o), u = r ? r + e : e;
                        return t._events[u] ? t._events[u].fn ? t._events[u] = [ t._events[u], a ] : t._events[u].push(a) : (t._events[u] = a, 
                        t._eventsCount++), t;
                    }
                    function u(t, e) {
                        0 == --t._eventsCount ? t._events = new o() : delete t._events[e];
                    }
                    function c() {
                        this._events = new o(), this._eventsCount = 0;
                    }
                    Object.create && (o.prototype = Object.create(null), new o().__proto__ || (r = !1)), 
                    c.prototype.eventNames = function() {
                        var t, e, n = [];
                        if (0 === this._eventsCount) return n;
                        for (e in t = this._events) i.call(t, e) && n.push(r ? e.slice(1) : e);
                        return Object.getOwnPropertySymbols ? n.concat(Object.getOwnPropertySymbols(t)) : n;
                    }, c.prototype.listeners = function(t) {
                        var e = r ? r + t : t, n = this._events[e];
                        if (!n) return [];
                        if (n.fn) return [ n.fn ];
                        for (var i = 0, o = n.length, s = new Array(o); i < o; i++) s[i] = n[i].fn;
                        return s;
                    }, c.prototype.listenerCount = function(t) {
                        var e = r ? r + t : t, n = this._events[e];
                        return n ? n.fn ? 1 : n.length : 0;
                    }, c.prototype.emit = function(t, e, n, i, o, s) {
                        var a = r ? r + t : t;
                        if (!this._events[a]) return !1;
                        var u, c, f = this._events[a], l = arguments.length;
                        if (f.fn) {
                            switch (f.once && this.removeListener(t, f.fn, void 0, !0), l) {
                              case 1:
                                return f.fn.call(f.context), !0;

                              case 2:
                                return f.fn.call(f.context, e), !0;

                              case 3:
                                return f.fn.call(f.context, e, n), !0;

                              case 4:
                                return f.fn.call(f.context, e, n, i), !0;

                              case 5:
                                return f.fn.call(f.context, e, n, i, o), !0;

                              case 6:
                                return f.fn.call(f.context, e, n, i, o, s), !0;
                            }
                            for (c = 1, u = new Array(l - 1); c < l; c++) u[c - 1] = arguments[c];
                            f.fn.apply(f.context, u);
                        } else {
                            var h, d = f.length;
                            for (c = 0; c < d; c++) switch (f[c].once && this.removeListener(t, f[c].fn, void 0, !0), 
                            l) {
                              case 1:
                                f[c].fn.call(f[c].context);
                                break;

                              case 2:
                                f[c].fn.call(f[c].context, e);
                                break;

                              case 3:
                                f[c].fn.call(f[c].context, e, n);
                                break;

                              case 4:
                                f[c].fn.call(f[c].context, e, n, i);
                                break;

                              default:
                                if (!u) for (h = 1, u = new Array(l - 1); h < l; h++) u[h - 1] = arguments[h];
                                f[c].fn.apply(f[c].context, u);
                            }
                        }
                        return !0;
                    }, c.prototype.on = function(t, e, n) {
                        return a(this, t, e, n, !1);
                    }, c.prototype.once = function(t, e, n) {
                        return a(this, t, e, n, !0);
                    }, c.prototype.removeListener = function(t, e, n, i) {
                        var o = r ? r + t : t;
                        if (!this._events[o]) return this;
                        if (!e) return u(this, o), this;
                        var s = this._events[o];
                        if (s.fn) s.fn !== e || i && !s.once || n && s.context !== n || u(this, o); else {
                            for (var a = 0, c = [], f = s.length; a < f; a++) (s[a].fn !== e || i && !s[a].once || n && s[a].context !== n) && c.push(s[a]);
                            c.length ? this._events[o] = 1 === c.length ? c[0] : c : u(this, o);
                        }
                        return this;
                    }, c.prototype.removeAllListeners = function(t) {
                        var e;
                        return t ? (e = r ? r + t : t, this._events[e] && u(this, e)) : (this._events = new o(), 
                        this._eventsCount = 0), this;
                    }, c.prototype.off = c.prototype.removeListener, c.prototype.addListener = c.prototype.on, 
                    c.prefixed = r, c.EventEmitter = c, void 0 !== e && (e.exports = c);
                }, {} ]
            }, {}, [ 1 ])(1);
        });
        var eventemitter3_minExports = eventemitter3_min.exports, EventEmitter = getDefaultExportFromCjs(eventemitter3_minExports), protobuf_min = {
            exports: {}
        }, long_min = {
            exports: {}
        };
        "undefined" != typeof self && self, long_min.exports = function(t) {
            function e(i) {
                if (n[i]) return n[i].exports;
                var r = n[i] = {
                    i: i,
                    l: !1,
                    exports: {}
                };
                return t[i].call(r.exports, r, r.exports, e), r.l = !0, r.exports;
            }
            var n = {};
            return e.m = t, e.c = n, e.d = function(t, n, i) {
                e.o(t, n) || Object.defineProperty(t, n, {
                    configurable: !1,
                    enumerable: !0,
                    get: i
                });
            }, e.n = function(t) {
                var n = t && t.__esModule ? function() {
                    return t.default;
                } : function() {
                    return t;
                };
                return e.d(n, "a", n), n;
            }, e.o = function(t, e) {
                return Object.prototype.hasOwnProperty.call(t, e);
            }, e.p = "", e(e.s = 0);
        }([ function(t, e) {
            function n(t, e, n) {
                this.low = 0 | t, this.high = 0 | e, this.unsigned = !!n;
            }
            function i(t) {
                return !0 === (t && t.__isLong__);
            }
            function r(t, e) {
                var n, i, r;
                return e ? (r = 0 <= (t >>>= 0) && t < 256) && (i = l[t]) ? i : (n = s(t, (0 | t) < 0 ? -1 : 0, !0), 
                r && (l[t] = n), n) : (r = -128 <= (t |= 0) && t < 128) && (i = f[t]) ? i : (n = s(t, t < 0 ? -1 : 0, !1), 
                r && (f[t] = n), n);
            }
            function o(t, e) {
                if (isNaN(t)) return e ? b : y;
                if (e) {
                    if (t < 0) return b;
                    if (t >= p) return k;
                } else {
                    if (t <= -m) return S;
                    if (t + 1 >= m) return T;
                }
                return t < 0 ? o(-t, e).neg() : s(t % d | 0, t / d | 0, e);
            }
            function s(t, e, i) {
                return new n(t, e, i);
            }
            function a(t, e, n) {
                if (0 === t.length) throw Error("empty string");
                if ("NaN" === t || "Infinity" === t || "+Infinity" === t || "-Infinity" === t) return y;
                if ("number" == typeof e ? (n = e, e = !1) : e = !!e, (n = n || 10) < 2 || 36 < n) throw RangeError("radix");
                var i;
                if ((i = t.indexOf("-")) > 0) throw Error("interior hyphen");
                if (0 === i) return a(t.substring(1), e, n).neg();
                for (var r = o(h(n, 8)), s = y, u = 0; u < t.length; u += 8) {
                    var c = Math.min(8, t.length - u), f = parseInt(t.substring(u, u + c), n);
                    if (c < 8) {
                        var l = o(h(n, c));
                        s = s.mul(l).add(o(f));
                    } else s = (s = s.mul(r)).add(o(f));
                }
                return s.unsigned = e, s;
            }
            function u(t, e) {
                return "number" == typeof t ? o(t, e) : "string" == typeof t ? a(t, e) : s(t.low, t.high, "boolean" == typeof e ? e : t.unsigned);
            }
            t.exports = n;
            var c = null;
            try {
                c = new WebAssembly.Instance(new WebAssembly.Module(new Uint8Array([ 0, 97, 115, 109, 1, 0, 0, 0, 1, 13, 2, 96, 0, 1, 127, 96, 4, 127, 127, 127, 127, 1, 127, 3, 7, 6, 0, 1, 1, 1, 1, 1, 6, 6, 1, 127, 1, 65, 0, 11, 7, 50, 6, 3, 109, 117, 108, 0, 1, 5, 100, 105, 118, 95, 115, 0, 2, 5, 100, 105, 118, 95, 117, 0, 3, 5, 114, 101, 109, 95, 115, 0, 4, 5, 114, 101, 109, 95, 117, 0, 5, 8, 103, 101, 116, 95, 104, 105, 103, 104, 0, 0, 10, 191, 1, 6, 4, 0, 35, 0, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 126, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 127, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 128, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 129, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11, 36, 1, 1, 126, 32, 0, 173, 32, 1, 173, 66, 32, 134, 132, 32, 2, 173, 32, 3, 173, 66, 32, 134, 132, 130, 34, 4, 66, 32, 135, 167, 36, 0, 32, 4, 167, 11 ])), {}).exports;
            } catch (t) {}
            n.prototype.__isLong__, Object.defineProperty(n.prototype, "__isLong__", {
                value: !0
            }), n.isLong = i;
            var f = {}, l = {};
            n.fromInt = r, n.fromNumber = o, n.fromBits = s;
            var h = Math.pow;
            n.fromString = a, n.fromValue = u;
            var d = 4294967296, p = d * d, m = p / 2, g = r(1 << 24), y = r(0);
            n.ZERO = y;
            var b = r(0, !0);
            n.UZERO = b;
            var v = r(1);
            n.ONE = v;
            var _ = r(1, !0);
            n.UONE = _;
            var w = r(-1);
            n.NEG_ONE = w;
            var T = s(-1, 2147483647, !1);
            n.MAX_VALUE = T;
            var k = s(-1, -1, !0);
            n.MAX_UNSIGNED_VALUE = k;
            var S = s(0, -2147483648, !1);
            n.MIN_VALUE = S;
            var A = n.prototype;
            A.toInt = function() {
                return this.unsigned ? this.low >>> 0 : this.low;
            }, A.toNumber = function() {
                return this.unsigned ? (this.high >>> 0) * d + (this.low >>> 0) : this.high * d + (this.low >>> 0);
            }, A.toString = function(t) {
                if ((t = t || 10) < 2 || 36 < t) throw RangeError("radix");
                if (this.isZero()) return "0";
                if (this.isNegative()) {
                    if (this.eq(S)) {
                        var e = o(t), n = this.div(e), i = n.mul(e).sub(this);
                        return n.toString(t) + i.toInt().toString(t);
                    }
                    return "-" + this.neg().toString(t);
                }
                for (var r = o(h(t, 6), this.unsigned), s = this, a = ""; ;) {
                    var u = s.div(r), c = (s.sub(u.mul(r)).toInt() >>> 0).toString(t);
                    if ((s = u).isZero()) return c + a;
                    for (;c.length < 6; ) c = "0" + c;
                    a = "" + c + a;
                }
            }, A.getHighBits = function() {
                return this.high;
            }, A.getHighBitsUnsigned = function() {
                return this.high >>> 0;
            }, A.getLowBits = function() {
                return this.low;
            }, A.getLowBitsUnsigned = function() {
                return this.low >>> 0;
            }, A.getNumBitsAbs = function() {
                if (this.isNegative()) return this.eq(S) ? 64 : this.neg().getNumBitsAbs();
                for (var t = 0 != this.high ? this.high : this.low, e = 31; e > 0 && 0 == (t & 1 << e); e--) ;
                return 0 != this.high ? e + 33 : e + 1;
            }, A.isZero = function() {
                return 0 === this.high && 0 === this.low;
            }, A.eqz = A.isZero, A.isNegative = function() {
                return !this.unsigned && this.high < 0;
            }, A.isPositive = function() {
                return this.unsigned || this.high >= 0;
            }, A.isOdd = function() {
                return 1 == (1 & this.low);
            }, A.isEven = function() {
                return 0 == (1 & this.low);
            }, A.equals = function(t) {
                return i(t) || (t = u(t)), (this.unsigned === t.unsigned || this.high >>> 31 != 1 || t.high >>> 31 != 1) && this.high === t.high && this.low === t.low;
            }, A.eq = A.equals, A.notEquals = function(t) {
                return !this.eq(t);
            }, A.neq = A.notEquals, A.ne = A.notEquals, A.lessThan = function(t) {
                return this.comp(t) < 0;
            }, A.lt = A.lessThan, A.lessThanOrEqual = function(t) {
                return this.comp(t) <= 0;
            }, A.lte = A.lessThanOrEqual, A.le = A.lessThanOrEqual, A.greaterThan = function(t) {
                return this.comp(t) > 0;
            }, A.gt = A.greaterThan, A.greaterThanOrEqual = function(t) {
                return this.comp(t) >= 0;
            }, A.gte = A.greaterThanOrEqual, A.ge = A.greaterThanOrEqual, A.compare = function(t) {
                if (i(t) || (t = u(t)), this.eq(t)) return 0;
                var e = this.isNegative(), n = t.isNegative();
                return e && !n ? -1 : !e && n ? 1 : this.unsigned ? t.high >>> 0 > this.high >>> 0 || t.high === this.high && t.low >>> 0 > this.low >>> 0 ? -1 : 1 : this.sub(t).isNegative() ? -1 : 1;
            }, A.comp = A.compare, A.negate = function() {
                return !this.unsigned && this.eq(S) ? S : this.not().add(v);
            }, A.neg = A.negate, A.add = function(t) {
                i(t) || (t = u(t));
                var e = this.high >>> 16, n = 65535 & this.high, r = this.low >>> 16, o = 65535 & this.low, a = t.high >>> 16, c = 65535 & t.high, f = t.low >>> 16, l = 0, h = 0, d = 0, p = 0;
                return d += (p += o + (65535 & t.low)) >>> 16, h += (d += r + f) >>> 16, l += (h += n + c) >>> 16, 
                l += e + a, s((d &= 65535) << 16 | (p &= 65535), (l &= 65535) << 16 | (h &= 65535), this.unsigned);
            }, A.subtract = function(t) {
                return i(t) || (t = u(t)), this.add(t.neg());
            }, A.sub = A.subtract, A.multiply = function(t) {
                if (this.isZero()) return y;
                if (i(t) || (t = u(t)), c) return s(c.mul(this.low, this.high, t.low, t.high), c.get_high(), this.unsigned);
                if (t.isZero()) return y;
                if (this.eq(S)) return t.isOdd() ? S : y;
                if (t.eq(S)) return this.isOdd() ? S : y;
                if (this.isNegative()) return t.isNegative() ? this.neg().mul(t.neg()) : this.neg().mul(t).neg();
                if (t.isNegative()) return this.mul(t.neg()).neg();
                if (this.lt(g) && t.lt(g)) return o(this.toNumber() * t.toNumber(), this.unsigned);
                var e = this.high >>> 16, n = 65535 & this.high, r = this.low >>> 16, a = 65535 & this.low, f = t.high >>> 16, l = 65535 & t.high, h = t.low >>> 16, d = 65535 & t.low, p = 0, m = 0, b = 0, v = 0;
                return b += (v += a * d) >>> 16, m += (b += r * d) >>> 16, b &= 65535, m += (b += a * h) >>> 16, 
                p += (m += n * d) >>> 16, m &= 65535, p += (m += r * h) >>> 16, m &= 65535, p += (m += a * l) >>> 16, 
                p += e * d + n * h + r * l + a * f, s((b &= 65535) << 16 | (v &= 65535), (p &= 65535) << 16 | (m &= 65535), this.unsigned);
            }, A.mul = A.multiply, A.divide = function(t) {
                if (i(t) || (t = u(t)), t.isZero()) throw Error("division by zero");
                if (c) return this.unsigned || -2147483648 !== this.high || -1 !== t.low || -1 !== t.high ? s((this.unsigned ? c.div_u : c.div_s)(this.low, this.high, t.low, t.high), c.get_high(), this.unsigned) : this;
                if (this.isZero()) return this.unsigned ? b : y;
                var e, n, r;
                if (this.unsigned) {
                    if (t.unsigned || (t = t.toUnsigned()), t.gt(this)) return b;
                    if (t.gt(this.shru(1))) return _;
                    r = b;
                } else {
                    if (this.eq(S)) return t.eq(v) || t.eq(w) ? S : t.eq(S) ? v : (e = this.shr(1).div(t).shl(1)).eq(y) ? t.isNegative() ? v : w : (n = this.sub(t.mul(e)), 
                    r = e.add(n.div(t)));
                    if (t.eq(S)) return this.unsigned ? b : y;
                    if (this.isNegative()) return t.isNegative() ? this.neg().div(t.neg()) : this.neg().div(t).neg();
                    if (t.isNegative()) return this.div(t.neg()).neg();
                    r = y;
                }
                for (n = this; n.gte(t); ) {
                    e = Math.max(1, Math.floor(n.toNumber() / t.toNumber()));
                    for (var a = Math.ceil(Math.log(e) / Math.LN2), f = a <= 48 ? 1 : h(2, a - 48), l = o(e), d = l.mul(t); d.isNegative() || d.gt(n); ) d = (l = o(e -= f, this.unsigned)).mul(t);
                    l.isZero() && (l = v), r = r.add(l), n = n.sub(d);
                }
                return r;
            }, A.div = A.divide, A.modulo = function(t) {
                return i(t) || (t = u(t)), c ? s((this.unsigned ? c.rem_u : c.rem_s)(this.low, this.high, t.low, t.high), c.get_high(), this.unsigned) : this.sub(this.div(t).mul(t));
            }, A.mod = A.modulo, A.rem = A.modulo, A.not = function() {
                return s(~this.low, ~this.high, this.unsigned);
            }, A.and = function(t) {
                return i(t) || (t = u(t)), s(this.low & t.low, this.high & t.high, this.unsigned);
            }, A.or = function(t) {
                return i(t) || (t = u(t)), s(this.low | t.low, this.high | t.high, this.unsigned);
            }, A.xor = function(t) {
                return i(t) || (t = u(t)), s(this.low ^ t.low, this.high ^ t.high, this.unsigned);
            }, A.shiftLeft = function(t) {
                return i(t) && (t = t.toInt()), 0 == (t &= 63) ? this : t < 32 ? s(this.low << t, this.high << t | this.low >>> 32 - t, this.unsigned) : s(0, this.low << t - 32, this.unsigned);
            }, A.shl = A.shiftLeft, A.shiftRight = function(t) {
                return i(t) && (t = t.toInt()), 0 == (t &= 63) ? this : t < 32 ? s(this.low >>> t | this.high << 32 - t, this.high >> t, this.unsigned) : s(this.high >> t - 32, this.high >= 0 ? 0 : -1, this.unsigned);
            }, A.shr = A.shiftRight, A.shiftRightUnsigned = function(t) {
                if (i(t) && (t = t.toInt()), 0 == (t &= 63)) return this;
                var e = this.high;
                return t < 32 ? s(this.low >>> t | e << 32 - t, e >>> t, this.unsigned) : s(32 === t ? e : e >>> t - 32, 0, this.unsigned);
            }, A.shru = A.shiftRightUnsigned, A.shr_u = A.shiftRightUnsigned, A.toSigned = function() {
                return this.unsigned ? s(this.low, this.high, !1) : this;
            }, A.toUnsigned = function() {
                return this.unsigned ? this : s(this.low, this.high, !0);
            }, A.toBytes = function(t) {
                return t ? this.toBytesLE() : this.toBytesBE();
            }, A.toBytesLE = function() {
                var t = this.high, e = this.low;
                return [ 255 & e, e >>> 8 & 255, e >>> 16 & 255, e >>> 24, 255 & t, t >>> 8 & 255, t >>> 16 & 255, t >>> 24 ];
            }, A.toBytesBE = function() {
                var t = this.high, e = this.low;
                return [ t >>> 24, t >>> 16 & 255, t >>> 8 & 255, 255 & t, e >>> 24, e >>> 16 & 255, e >>> 8 & 255, 255 & e ];
            }, n.fromBytes = function(t, e, i) {
                return i ? n.fromBytesLE(t, e) : n.fromBytesBE(t, e);
            }, n.fromBytesLE = function(t, e) {
                return new n(t[0] | t[1] << 8 | t[2] << 16 | t[3] << 24, t[4] | t[5] << 8 | t[6] << 16 | t[7] << 24, e);
            }, n.fromBytesBE = function(t, e) {
                return new n(t[4] << 24 | t[5] << 16 | t[6] << 8 | t[7], t[0] << 24 | t[1] << 16 | t[2] << 8 | t[3], e);
            };
        } ]), protobuf_min.exports, function(module) {
            function _typeof(t) {
                return "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? _typeof3(t) : t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof3(t);
            }
            !function(b) {
                var r, u, t, n;
                r = {
                    1: [ function(t, e) {
                        e.exports = function(t, e) {
                            for (var n = Array(arguments.length - 1), i = 0, r = 2, o = !0; r < arguments.length; ) n[i++] = arguments[r++];
                            return new Promise(function(r, s) {
                                n[i] = function(t) {
                                    if (o) if (o = !1, t) s(t); else {
                                        for (var e = Array(arguments.length - 1), n = 0; n < e.length; ) e[n++] = arguments[n];
                                        r.apply(null, e);
                                    }
                                };
                                try {
                                    t.apply(e || null, n);
                                } catch (t) {
                                    o && (o = !1, s(t));
                                }
                            });
                        };
                    }, {} ],
                    2: [ function(t, e, n) {
                        var i = n;
                        i.length = function(t) {
                            var e = t.length;
                            if (!e) return 0;
                            for (var n = 0; 1 < --e % 4 && "=" === t.charAt(e); ) ++n;
                            return Math.ceil(3 * t.length) / 4 - n;
                        };
                        for (var r = Array(64), o = Array(123), s = 0; s < 64; ) o[r[s] = s < 26 ? s + 65 : s < 52 ? s + 71 : s < 62 ? s - 4 : s - 59 | 43] = s++;
                        i.encode = function(t, e, n) {
                            for (var i, o = null, s = [], a = 0, u = 0; e < n; ) {
                                var c = t[e++];
                                switch (u) {
                                  case 0:
                                    s[a++] = r[c >> 2], i = (3 & c) << 4, u = 1;
                                    break;

                                  case 1:
                                    s[a++] = r[i | c >> 4], i = (15 & c) << 2, u = 2;
                                    break;

                                  case 2:
                                    s[a++] = r[i | c >> 6], s[a++] = r[63 & c], u = 0;
                                }
                                8191 < a && ((o || (o = [])).push(String.fromCharCode.apply(String, s)), a = 0);
                            }
                            return u && (s[a++] = r[i], s[a++] = 61, 1 === u && (s[a++] = 61)), o ? (a && o.push(String.fromCharCode.apply(String, s.slice(0, a))), 
                            o.join("")) : String.fromCharCode.apply(String, s.slice(0, a));
                        };
                        var a = "invalid encoding";
                        i.decode = function(t, e, n) {
                            for (var i, r = n, s = 0, u = 0; u < t.length; ) {
                                var c = t.charCodeAt(u++);
                                if (61 === c && 1 < s) break;
                                if ((c = o[c]) === b) throw Error(a);
                                switch (s) {
                                  case 0:
                                    i = c, s = 1;
                                    break;

                                  case 1:
                                    e[n++] = i << 2 | (48 & c) >> 4, i = c, s = 2;
                                    break;

                                  case 2:
                                    e[n++] = (15 & i) << 4 | (60 & c) >> 2, i = c, s = 3;
                                    break;

                                  case 3:
                                    e[n++] = (3 & i) << 6 | c, s = 0;
                                }
                            }
                            if (1 === s) throw Error(a);
                            return n - r;
                        }, i.test = function(t) {
                            return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(t);
                        };
                    }, {} ],
                    3: [ function(t, e) {
                        function n() {
                            this.t = {};
                        }
                        (e.exports = n).prototype.on = function(t, e, n) {
                            return (this.t[t] || (this.t[t] = [])).push({
                                fn: e,
                                ctx: n || this
                            }), this;
                        }, n.prototype.off = function(t, e) {
                            if (t === b) this.t = {}; else if (e === b) this.t[t] = []; else for (var n = this.t[t], i = 0; i < n.length; ) n[i].fn === e ? n.splice(i, 1) : ++i;
                            return this;
                        }, n.prototype.emit = function(t) {
                            var e = this.t[t];
                            if (e) {
                                for (var n = [], i = 1; i < arguments.length; ) n.push(arguments[i++]);
                                for (i = 0; i < e.length; ) e[i].fn.apply(e[i++].ctx, n);
                            }
                            return this;
                        };
                    }, {} ],
                    4: [ function(t, e) {
                        function n(t) {
                            return "undefined" != typeof Float32Array ? function() {
                                var e = new Float32Array([ -0 ]), n = new Uint8Array(e.buffer), i = 128 === n[3];
                                function r(t, i, r) {
                                    e[0] = t, i[r] = n[0], i[r + 1] = n[1], i[r + 2] = n[2], i[r + 3] = n[3];
                                }
                                function o(t, i, r) {
                                    e[0] = t, i[r] = n[3], i[r + 1] = n[2], i[r + 2] = n[1], i[r + 3] = n[0];
                                }
                                function s(t, i) {
                                    return n[0] = t[i], n[1] = t[i + 1], n[2] = t[i + 2], n[3] = t[i + 3], e[0];
                                }
                                function a(t, i) {
                                    return n[3] = t[i], n[2] = t[i + 1], n[1] = t[i + 2], n[0] = t[i + 3], e[0];
                                }
                                t.writeFloatLE = i ? r : o, t.writeFloatBE = i ? o : r, t.readFloatLE = i ? s : a, 
                                t.readFloatBE = i ? a : s;
                            }() : function() {
                                function e(t, e, n, i) {
                                    var r = e < 0 ? 1 : 0;
                                    if (r && (e = -e), 0 === e) t(0 < 1 / e ? 0 : 2147483648, n, i); else if (isNaN(e)) t(2143289344, n, i); else if (3.4028234663852886e38 < e) t((r << 31 | 2139095040) >>> 0, n, i); else if (e < 1.1754943508222875e-38) t((r << 31 | Math.round(e / 1.401298464324817e-45)) >>> 0, n, i); else {
                                        var o = Math.floor(Math.log(e) / Math.LN2);
                                        t((r << 31 | o + 127 << 23 | 8388607 & Math.round(e * Math.pow(2, -o) * 8388608)) >>> 0, n, i);
                                    }
                                }
                                function n(t, e, n) {
                                    var i = t(e, n), r = 2 * (i >> 31) + 1, o = i >>> 23 & 255, s = 8388607 & i;
                                    return 255 === o ? s ? NaN : r * (1 / 0) : 0 === o ? 1.401298464324817e-45 * r * s : r * Math.pow(2, o - 150) * (s + 8388608);
                                }
                                t.writeFloatLE = e.bind(null, i), t.writeFloatBE = e.bind(null, r), t.readFloatLE = n.bind(null, o), 
                                t.readFloatBE = n.bind(null, s);
                            }(), "undefined" != typeof Float64Array ? function() {
                                var e = new Float64Array([ -0 ]), n = new Uint8Array(e.buffer), i = 128 === n[7];
                                function r(t, i, r) {
                                    e[0] = t, i[r] = n[0], i[r + 1] = n[1], i[r + 2] = n[2], i[r + 3] = n[3], i[r + 4] = n[4], 
                                    i[r + 5] = n[5], i[r + 6] = n[6], i[r + 7] = n[7];
                                }
                                function o(t, i, r) {
                                    e[0] = t, i[r] = n[7], i[r + 1] = n[6], i[r + 2] = n[5], i[r + 3] = n[4], i[r + 4] = n[3], 
                                    i[r + 5] = n[2], i[r + 6] = n[1], i[r + 7] = n[0];
                                }
                                function s(t, i) {
                                    return n[0] = t[i], n[1] = t[i + 1], n[2] = t[i + 2], n[3] = t[i + 3], n[4] = t[i + 4], 
                                    n[5] = t[i + 5], n[6] = t[i + 6], n[7] = t[i + 7], e[0];
                                }
                                function a(t, i) {
                                    return n[7] = t[i], n[6] = t[i + 1], n[5] = t[i + 2], n[4] = t[i + 3], n[3] = t[i + 4], 
                                    n[2] = t[i + 5], n[1] = t[i + 6], n[0] = t[i + 7], e[0];
                                }
                                t.writeDoubleLE = i ? r : o, t.writeDoubleBE = i ? o : r, t.readDoubleLE = i ? s : a, 
                                t.readDoubleBE = i ? a : s;
                            }() : function() {
                                function e(t, e, n, i, r, o) {
                                    var s = i < 0 ? 1 : 0;
                                    if (s && (i = -i), 0 === i) t(0, r, o + e), t(0 < 1 / i ? 0 : 2147483648, r, o + n); else if (isNaN(i)) t(0, r, o + e), 
                                    t(2146959360, r, o + n); else if (1.7976931348623157e308 < i) t(0, r, o + e), t((s << 31 | 2146435072) >>> 0, r, o + n); else {
                                        var a;
                                        if (i < 2.2250738585072014e-308) t((a = i / 5e-324) >>> 0, r, o + e), t((s << 31 | a / 4294967296) >>> 0, r, o + n); else {
                                            var u = Math.floor(Math.log(i) / Math.LN2);
                                            1024 === u && (u = 1023), t(4503599627370496 * (a = i * Math.pow(2, -u)) >>> 0, r, o + e), 
                                            t((s << 31 | u + 1023 << 20 | 1048576 * a & 1048575) >>> 0, r, o + n);
                                        }
                                    }
                                }
                                function n(t, e, n, i, r) {
                                    var o = t(i, r + e), s = t(i, r + n), a = 2 * (s >> 31) + 1, u = s >>> 20 & 2047, c = 4294967296 * (1048575 & s) + o;
                                    return 2047 === u ? c ? NaN : a * (1 / 0) : 0 === u ? 5e-324 * a * c : a * Math.pow(2, u - 1075) * (c + 4503599627370496);
                                }
                                t.writeDoubleLE = e.bind(null, i, 0, 4), t.writeDoubleBE = e.bind(null, r, 4, 0), 
                                t.readDoubleLE = n.bind(null, o, 0, 4), t.readDoubleBE = n.bind(null, s, 4, 0);
                            }(), t;
                        }
                        function i(t, e, n) {
                            e[n] = 255 & t, e[n + 1] = t >>> 8 & 255, e[n + 2] = t >>> 16 & 255, e[n + 3] = t >>> 24;
                        }
                        function r(t, e, n) {
                            e[n] = t >>> 24, e[n + 1] = t >>> 16 & 255, e[n + 2] = t >>> 8 & 255, e[n + 3] = 255 & t;
                        }
                        function o(t, e) {
                            return (t[e] | t[e + 1] << 8 | t[e + 2] << 16 | t[e + 3] << 24) >>> 0;
                        }
                        function s(t, e) {
                            return (t[e] << 24 | t[e + 1] << 16 | t[e + 2] << 8 | t[e + 3]) >>> 0;
                        }
                        e.exports = n(n);
                    }, {} ],
                    5: [ function(t, n, i) {
                        function r(t) {
                            try {
                                var n = eval("require")(t);
                                if (n && (n.length || Object.keys(n).length)) return n;
                            } catch (t) {}
                            return null;
                        }
                        n.exports = r;
                    }, {} ],
                    6: [ function(t, e) {
                        e.exports = function(t, e, n) {
                            var i = n || 8192, r = i >>> 1, o = null, s = i;
                            return function(n) {
                                if (n < 1 || r < n) return t(n);
                                i < s + n && (o = t(i), s = 0);
                                var a = e.call(o, s, s += n);
                                return 7 & s && (s = 1 + (7 | s)), a;
                            };
                        };
                    }, {} ],
                    7: [ function(t, e, n) {
                        var i = n;
                        i.length = function(t) {
                            for (var e = 0, n = 0, i = 0; i < t.length; ++i) (n = t.charCodeAt(i)) < 128 ? e += 1 : n < 2048 ? e += 2 : 55296 == (64512 & n) && 56320 == (64512 & t.charCodeAt(i + 1)) ? (++i, 
                            e += 4) : e += 3;
                            return e;
                        }, i.read = function(t, e, n) {
                            if (n - e < 1) return "";
                            for (var i, r = null, o = [], s = 0; e < n; ) (i = t[e++]) < 128 ? o[s++] = i : 191 < i && i < 224 ? o[s++] = (31 & i) << 6 | 63 & t[e++] : 239 < i && i < 365 ? (i = ((7 & i) << 18 | (63 & t[e++]) << 12 | (63 & t[e++]) << 6 | 63 & t[e++]) - 65536, 
                            o[s++] = 55296 + (i >> 10), o[s++] = 56320 + (1023 & i)) : o[s++] = (15 & i) << 12 | (63 & t[e++]) << 6 | 63 & t[e++], 
                            8191 < s && ((r || (r = [])).push(String.fromCharCode.apply(String, o)), s = 0);
                            return r ? (s && r.push(String.fromCharCode.apply(String, o.slice(0, s))), r.join("")) : String.fromCharCode.apply(String, o.slice(0, s));
                        }, i.write = function(t, e, n) {
                            for (var i, r, o = n, s = 0; s < t.length; ++s) (i = t.charCodeAt(s)) < 128 ? e[n++] = i : (i < 2048 ? e[n++] = i >> 6 | 192 : (55296 == (64512 & i) && 56320 == (64512 & (r = t.charCodeAt(s + 1))) ? (i = 65536 + ((1023 & i) << 10) + (1023 & r), 
                            ++s, e[n++] = i >> 18 | 240, e[n++] = i >> 12 & 63 | 128) : e[n++] = i >> 12 | 224, 
                            e[n++] = i >> 6 & 63 | 128), e[n++] = 63 & i | 128);
                            return n - o;
                        };
                    }, {} ],
                    8: [ function(t, e, n) {
                        var i = n;
                        function r() {
                            i.Reader.n(i.BufferReader), i.util.n();
                        }
                        i.build = "minimal", i.Writer = t(16), i.BufferWriter = t(17), i.Reader = t(9), 
                        i.BufferReader = t(10), i.util = t(15), i.rpc = t(12), i.roots = t(11), i.configure = r, 
                        i.Writer.n(i.BufferWriter), r();
                    }, {
                        10: 10,
                        11: 11,
                        12: 12,
                        15: 15,
                        16: 16,
                        17: 17,
                        9: 9
                    } ],
                    9: [ function(t, e) {
                        e.exports = a;
                        var n, i = t(15), r = i.LongBits, o = i.utf8;
                        function s(t, e) {
                            return RangeError("index out of range: " + t.pos + " + " + (e || 1) + " > " + t.len);
                        }
                        function a(t) {
                            this.buf = t, this.pos = 0, this.len = t.length;
                        }
                        var u, c = "undefined" != typeof Uint8Array ? function(t) {
                            if (t instanceof Uint8Array || Array.isArray(t)) return new a(t);
                            throw Error("illegal buffer");
                        } : function(t) {
                            if (Array.isArray(t)) return new a(t);
                            throw Error("illegal buffer");
                        };
                        function f() {
                            var t = new r(0, 0), e = 0;
                            if (!(4 < this.len - this.pos)) {
                                for (;e < 3; ++e) {
                                    if (this.pos >= this.len) throw s(this);
                                    if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * e) >>> 0, this.buf[this.pos++] < 128) return t;
                                }
                                return t.lo = (t.lo | (127 & this.buf[this.pos++]) << 7 * e) >>> 0, t;
                            }
                            for (;e < 4; ++e) if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * e) >>> 0, 
                            this.buf[this.pos++] < 128) return t;
                            if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 28) >>> 0, t.hi = (t.hi | (127 & this.buf[this.pos]) >> 4) >>> 0, 
                            this.buf[this.pos++] < 128) return t;
                            if (e = 0, 4 < this.len - this.pos) {
                                for (;e < 5; ++e) if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * e + 3) >>> 0, 
                                this.buf[this.pos++] < 128) return t;
                            } else for (;e < 5; ++e) {
                                if (this.pos >= this.len) throw s(this);
                                if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * e + 3) >>> 0, this.buf[this.pos++] < 128) return t;
                            }
                            throw Error("invalid varint encoding");
                        }
                        function l(t, e) {
                            return (t[e - 4] | t[e - 3] << 8 | t[e - 2] << 16 | t[e - 1] << 24) >>> 0;
                        }
                        function h() {
                            if (this.pos + 8 > this.len) throw s(this, 8);
                            return new r(l(this.buf, this.pos += 4), l(this.buf, this.pos += 4));
                        }
                        a.create = i.Buffer ? function(t) {
                            return (a.create = function(t) {
                                return i.Buffer.isBuffer(t) ? new n(t) : c(t);
                            })(t);
                        } : c, a.prototype.i = i.Array.prototype.subarray || i.Array.prototype.slice, a.prototype.uint32 = (u = 4294967295, 
                        function() {
                            if (u = (127 & this.buf[this.pos]) >>> 0, this.buf[this.pos++] < 128) return u;
                            if (u = (u | (127 & this.buf[this.pos]) << 7) >>> 0, this.buf[this.pos++] < 128) return u;
                            if (u = (u | (127 & this.buf[this.pos]) << 14) >>> 0, this.buf[this.pos++] < 128) return u;
                            if (u = (u | (127 & this.buf[this.pos]) << 21) >>> 0, this.buf[this.pos++] < 128) return u;
                            if (u = (u | (15 & this.buf[this.pos]) << 28) >>> 0, this.buf[this.pos++] < 128) return u;
                            if ((this.pos += 5) > this.len) throw this.pos = this.len, s(this, 10);
                            return u;
                        }), a.prototype.int32 = function() {
                            return 0 | this.uint32();
                        }, a.prototype.sint32 = function() {
                            var t = this.uint32();
                            return t >>> 1 ^ -(1 & t) | 0;
                        }, a.prototype.bool = function() {
                            return 0 !== this.uint32();
                        }, a.prototype.fixed32 = function() {
                            if (this.pos + 4 > this.len) throw s(this, 4);
                            return l(this.buf, this.pos += 4);
                        }, a.prototype.sfixed32 = function() {
                            if (this.pos + 4 > this.len) throw s(this, 4);
                            return 0 | l(this.buf, this.pos += 4);
                        }, a.prototype.float = function() {
                            if (this.pos + 4 > this.len) throw s(this, 4);
                            var t = i.float.readFloatLE(this.buf, this.pos);
                            return this.pos += 4, t;
                        }, a.prototype.double = function() {
                            if (this.pos + 8 > this.len) throw s(this, 4);
                            var t = i.float.readDoubleLE(this.buf, this.pos);
                            return this.pos += 8, t;
                        }, a.prototype.bytes = function() {
                            var t = this.uint32(), e = this.pos, n = this.pos + t;
                            if (n > this.len) throw s(this, t);
                            return this.pos += t, Array.isArray(this.buf) ? this.buf.slice(e, n) : e === n ? new this.buf.constructor(0) : this.i.call(this.buf, e, n);
                        }, a.prototype.string = function() {
                            var t = this.bytes();
                            return o.read(t, 0, t.length);
                        }, a.prototype.skip = function(t) {
                            if ("number" == typeof t) {
                                if (this.pos + t > this.len) throw s(this, t);
                                this.pos += t;
                            } else do {
                                if (this.pos >= this.len) throw s(this);
                            } while (128 & this.buf[this.pos++]);
                            return this;
                        }, a.prototype.skipType = function(t) {
                            switch (t) {
                              case 0:
                                this.skip();
                                break;

                              case 1:
                                this.skip(8);
                                break;

                              case 2:
                                this.skip(this.uint32());
                                break;

                              case 3:
                                for (;4 != (t = 7 & this.uint32()); ) this.skipType(t);
                                break;

                              case 5:
                                this.skip(4);
                                break;

                              default:
                                throw Error("invalid wire type " + t + " at offset " + this.pos);
                            }
                            return this;
                        }, a.n = function(t) {
                            n = t;
                            var e = i.Long ? "toLong" : "toNumber";
                            i.merge(a.prototype, {
                                int64: function() {
                                    return f.call(this)[e](!1);
                                },
                                uint64: function() {
                                    return f.call(this)[e](!0);
                                },
                                sint64: function() {
                                    return f.call(this).zzDecode()[e](!1);
                                },
                                fixed64: function() {
                                    return h.call(this)[e](!0);
                                },
                                sfixed64: function() {
                                    return h.call(this)[e](!1);
                                }
                            });
                        };
                    }, {
                        15: 15
                    } ],
                    10: [ function(t, e) {
                        e.exports = r;
                        var n = t(9);
                        (r.prototype = Object.create(n.prototype)).constructor = r;
                        var i = t(15);
                        function r(t) {
                            n.call(this, t);
                        }
                        i.Buffer && (r.prototype.i = i.Buffer.prototype.slice), r.prototype.string = function() {
                            var t = this.uint32();
                            return this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + t, this.len));
                        };
                    }, {
                        15: 15,
                        9: 9
                    } ],
                    11: [ function(t, e) {
                        e.exports = {};
                    }, {} ],
                    12: [ function(t, e, n) {
                        n.Service = t(13);
                    }, {
                        13: 13
                    } ],
                    13: [ function(t, e) {
                        e.exports = i;
                        var n = t(15);
                        function i(t, e, i) {
                            if ("function" != typeof t) throw TypeError("rpcImpl must be a function");
                            n.EventEmitter.call(this), this.rpcImpl = t, this.requestDelimited = !!e, this.responseDelimited = !!i;
                        }
                        ((i.prototype = Object.create(n.EventEmitter.prototype)).constructor = i).prototype.rpcCall = function t(e, i, r, o, s) {
                            if (!o) throw TypeError("request must be specified");
                            var a = this;
                            if (!s) return n.asPromise(t, a, e, i, r, o);
                            if (!a.rpcImpl) return setTimeout(function() {
                                s(Error("already ended"));
                            }, 0), b;
                            try {
                                return a.rpcImpl(e, i[a.requestDelimited ? "encodeDelimited" : "encode"](o).finish(), function(t, n) {
                                    if (t) return a.emit("error", t, e), s(t);
                                    if (null === n) return a.end(!0), b;
                                    if (!(n instanceof r)) try {
                                        n = r[a.responseDelimited ? "decodeDelimited" : "decode"](n);
                                    } catch (t) {
                                        return a.emit("error", t, e), s(t);
                                    }
                                    return a.emit("data", n, e), s(null, n);
                                });
                            } catch (t) {
                                return a.emit("error", t, e), setTimeout(function() {
                                    s(t);
                                }, 0), b;
                            }
                        }, i.prototype.end = function(t) {
                            return this.rpcImpl && (t || this.rpcImpl(null, null, null), this.rpcImpl = null, 
                            this.emit("end").off()), this;
                        };
                    }, {
                        15: 15
                    } ],
                    14: [ function(t, e) {
                        e.exports = i;
                        var n = t(15);
                        function i(t, e) {
                            this.lo = t >>> 0, this.hi = e >>> 0;
                        }
                        var r = i.zero = new i(0, 0);
                        r.toNumber = function() {
                            return 0;
                        }, r.zzEncode = r.zzDecode = function() {
                            return this;
                        }, r.length = function() {
                            return 1;
                        };
                        var o = i.zeroHash = "\0\0\0\0\0\0\0\0";
                        i.fromNumber = function(t) {
                            if (0 === t) return r;
                            var e = t < 0;
                            e && (t = -t);
                            var n = t >>> 0, o = (t - n) / 4294967296 >>> 0;
                            return e && (o = ~o >>> 0, n = ~n >>> 0, 4294967295 < ++n && (n = 0, 4294967295 < ++o && (o = 0))), 
                            new i(n, o);
                        }, i.from = function(t) {
                            if ("number" == typeof t) return i.fromNumber(t);
                            if (n.isString(t)) {
                                if (!n.Long) return i.fromNumber(parseInt(t, 10));
                                t = n.Long.fromString(t);
                            }
                            return t.low || t.high ? new i(t.low >>> 0, t.high >>> 0) : r;
                        }, i.prototype.toNumber = function(t) {
                            if (!t && this.hi >>> 31) {
                                var e = 1 + ~this.lo >>> 0, n = ~this.hi >>> 0;
                                return e || (n = n + 1 >>> 0), -(e + 4294967296 * n);
                            }
                            return this.lo + 4294967296 * this.hi;
                        }, i.prototype.toLong = function(t) {
                            return n.Long ? new n.Long(0 | this.lo, 0 | this.hi, !!t) : {
                                low: 0 | this.lo,
                                high: 0 | this.hi,
                                unsigned: !!t
                            };
                        };
                        var s = String.prototype.charCodeAt;
                        i.fromHash = function(t) {
                            return t === o ? r : new i((s.call(t, 0) | s.call(t, 1) << 8 | s.call(t, 2) << 16 | s.call(t, 3) << 24) >>> 0, (s.call(t, 4) | s.call(t, 5) << 8 | s.call(t, 6) << 16 | s.call(t, 7) << 24) >>> 0);
                        }, i.prototype.toHash = function() {
                            return String.fromCharCode(255 & this.lo, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, 255 & this.hi, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
                        }, i.prototype.zzEncode = function() {
                            var t = this.hi >> 31;
                            return this.hi = ((this.hi << 1 | this.lo >>> 31) ^ t) >>> 0, this.lo = (this.lo << 1 ^ t) >>> 0, 
                            this;
                        }, i.prototype.zzDecode = function() {
                            var t = -(1 & this.lo);
                            return this.lo = ((this.lo >>> 1 | this.hi << 31) ^ t) >>> 0, this.hi = (this.hi >>> 1 ^ t) >>> 0, 
                            this;
                        }, i.prototype.length = function() {
                            var t = this.lo, e = (this.lo >>> 28 | this.hi << 4) >>> 0, n = this.hi >>> 24;
                            return 0 === n ? 0 === e ? t < 16384 ? t < 128 ? 1 : 2 : t < 2097152 ? 3 : 4 : e < 16384 ? e < 128 ? 5 : 6 : e < 2097152 ? 7 : 8 : n < 128 ? 9 : 10;
                        };
                    }, {
                        15: 15
                    } ],
                    15: [ function(t, e, n) {
                        var i = n;
                        function r(t, e, n) {
                            for (var i = Object.keys(e), r = 0; r < i.length; ++r) t[i[r]] !== b && n || (t[i[r]] = e[i[r]]);
                            return t;
                        }
                        function o(t) {
                            function e(t, n) {
                                if (!(this instanceof e)) return new e(t, n);
                                Object.defineProperty(this, "message", {
                                    get: function() {
                                        return t;
                                    }
                                }), Error.captureStackTrace ? Error.captureStackTrace(this, e) : Object.defineProperty(this, "stack", {
                                    value: Error().stack || ""
                                }), n && r(this, n);
                            }
                            return (e.prototype = Object.create(Error.prototype)).constructor = e, Object.defineProperty(e.prototype, "name", {
                                get: function() {
                                    return t;
                                }
                            }), e.prototype.toString = function() {
                                return this.name + ": " + this.message;
                            }, e;
                        }
                        i.asPromise = t(1), i.base64 = t(2), i.EventEmitter = t(3), i.float = t(4), i.inquire = t(5), 
                        i.utf8 = t(7), i.pool = t(6), i.LongBits = t(14), i.global = "undefined" != typeof window && window || void 0 !== commonjsGlobal && commonjsGlobal || "undefined" != typeof self && self || this, 
                        i.emptyArray = Object.freeze ? Object.freeze([]) : [], i.emptyObject = Object.freeze ? Object.freeze({}) : {}, 
                        i.isNode = !!(i.global.process && i.global.process.versions && i.global.process.versions.node), 
                        i.isInteger = Number.isInteger || function(t) {
                            return "number" == typeof t && isFinite(t) && Math.floor(t) === t;
                        }, i.isString = function(t) {
                            return "string" == typeof t || t instanceof String;
                        }, i.isObject = function(t) {
                            return t && "object" == _typeof(t);
                        }, i.isset = i.isSet = function(t, e) {
                            var n = t[e];
                            return !(null == n || !t.hasOwnProperty(e)) && ("object" != _typeof(n) || 0 < (Array.isArray(n) ? n.length : Object.keys(n).length));
                        }, i.Buffer = function() {
                            try {
                                var t = i.inquire("buffer").Buffer;
                                return t.prototype.utf8Write ? t : null;
                            } catch (t) {
                                return null;
                            }
                        }(), i.r = null, i.u = null, i.newBuffer = function(t) {
                            return "number" == typeof t ? i.Buffer ? i.u(t) : new i.Array(t) : i.Buffer ? i.r(t) : "undefined" == typeof Uint8Array ? t : new Uint8Array(t);
                        }, i.Array = "undefined" != typeof Uint8Array ? Uint8Array : Array, i.Long = i.global.dcodeIO && i.global.dcodeIO.Long || i.global.Long || i.inquire("long"), 
                        i.key2Re = /^true|false|0|1$/, i.key32Re = /^-?(?:0|[1-9][0-9]*)$/, i.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/, 
                        i.longToHash = function(t) {
                            return t ? i.LongBits.from(t).toHash() : i.LongBits.zeroHash;
                        }, i.longFromHash = function(t, e) {
                            var n = i.LongBits.fromHash(t);
                            return i.Long ? i.Long.fromBits(n.lo, n.hi, e) : n.toNumber(!!e);
                        }, i.merge = r, i.lcFirst = function(t) {
                            return t.charAt(0).toLowerCase() + t.substring(1);
                        }, i.newError = o, i.ProtocolError = o("ProtocolError"), i.oneOfGetter = function(t) {
                            for (var e = {}, n = 0; n < t.length; ++n) e[t[n]] = 1;
                            return function() {
                                for (var t = Object.keys(this), n = t.length - 1; -1 < n; --n) if (1 === e[t[n]] && this[t[n]] !== b && null !== this[t[n]]) return t[n];
                            };
                        }, i.oneOfSetter = function(t) {
                            return function(e) {
                                for (var n = 0; n < t.length; ++n) t[n] !== e && delete this[t[n]];
                            };
                        }, i.toJSONOptions = {
                            longs: String,
                            enums: String,
                            bytes: String,
                            json: !0
                        }, i.n = function() {
                            var t = i.Buffer;
                            t ? (i.r = t.from !== Uint8Array.from && t.from || function(e, n) {
                                return new t(e, n);
                            }, i.u = t.allocUnsafe || function(e) {
                                return new t(e);
                            }) : i.r = i.u = null;
                        };
                    }, {
                        1: 1,
                        14: 14,
                        2: 2,
                        3: 3,
                        4: 4,
                        5: 5,
                        6: 6,
                        7: 7
                    } ],
                    16: [ function(t, e) {
                        e.exports = f;
                        var n, i = t(15), r = i.LongBits, o = i.base64, s = i.utf8;
                        function a(t, e, n) {
                            this.fn = t, this.len = e, this.next = b, this.val = n;
                        }
                        function u() {}
                        function c(t) {
                            this.head = t.head, this.tail = t.tail, this.len = t.len, this.next = t.states;
                        }
                        function f() {
                            this.len = 0, this.head = new a(u, 0, 0), this.tail = this.head, this.states = null;
                        }
                        function l(t, e, n) {
                            e[n] = 255 & t;
                        }
                        function h(t, e) {
                            this.len = t, this.next = b, this.val = e;
                        }
                        function d(t, e, n) {
                            for (;t.hi; ) e[n++] = 127 & t.lo | 128, t.lo = (t.lo >>> 7 | t.hi << 25) >>> 0, 
                            t.hi >>>= 7;
                            for (;127 < t.lo; ) e[n++] = 127 & t.lo | 128, t.lo = t.lo >>> 7;
                            e[n++] = t.lo;
                        }
                        function p(t, e, n) {
                            e[n] = 255 & t, e[n + 1] = t >>> 8 & 255, e[n + 2] = t >>> 16 & 255, e[n + 3] = t >>> 24;
                        }
                        f.create = i.Buffer ? function() {
                            return (f.create = function() {
                                return new n();
                            })();
                        } : function() {
                            return new f();
                        }, f.alloc = function(t) {
                            return new i.Array(t);
                        }, i.Array !== Array && (f.alloc = i.pool(f.alloc, i.Array.prototype.subarray)), 
                        f.prototype.e = function(t, e, n) {
                            return this.tail = this.tail.next = new a(t, e, n), this.len += e, this;
                        }, (h.prototype = Object.create(a.prototype)).fn = function(t, e, n) {
                            for (;127 < t; ) e[n++] = 127 & t | 128, t >>>= 7;
                            e[n] = t;
                        }, f.prototype.uint32 = function(t) {
                            return this.len += (this.tail = this.tail.next = new h((t >>>= 0) < 128 ? 1 : t < 16384 ? 2 : t < 2097152 ? 3 : t < 268435456 ? 4 : 5, t)).len, 
                            this;
                        }, f.prototype.int32 = function(t) {
                            return t < 0 ? this.e(d, 10, r.fromNumber(t)) : this.uint32(t);
                        }, f.prototype.sint32 = function(t) {
                            return this.uint32((t << 1 ^ t >> 31) >>> 0);
                        }, f.prototype.int64 = f.prototype.uint64 = function(t) {
                            var e = r.from(t);
                            return this.e(d, e.length(), e);
                        }, f.prototype.sint64 = function(t) {
                            var e = r.from(t).zzEncode();
                            return this.e(d, e.length(), e);
                        }, f.prototype.bool = function(t) {
                            return this.e(l, 1, t ? 1 : 0);
                        }, f.prototype.sfixed32 = f.prototype.fixed32 = function(t) {
                            return this.e(p, 4, t >>> 0);
                        }, f.prototype.sfixed64 = f.prototype.fixed64 = function(t) {
                            var e = r.from(t);
                            return this.e(p, 4, e.lo).e(p, 4, e.hi);
                        }, f.prototype.float = function(t) {
                            return this.e(i.float.writeFloatLE, 4, t);
                        }, f.prototype.double = function(t) {
                            return this.e(i.float.writeDoubleLE, 8, t);
                        };
                        var m = i.Array.prototype.set ? function(t, e, n) {
                            e.set(t, n);
                        } : function(t, e, n) {
                            for (var i = 0; i < t.length; ++i) e[n + i] = t[i];
                        };
                        f.prototype.bytes = function(t) {
                            var e = t.length >>> 0;
                            if (!e) return this.e(l, 1, 0);
                            if (i.isString(t)) {
                                var n = f.alloc(e = o.length(t));
                                o.decode(t, n, 0), t = n;
                            }
                            return this.uint32(e).e(m, e, t);
                        }, f.prototype.string = function(t) {
                            var e = s.length(t);
                            return e ? this.uint32(e).e(s.write, e, t) : this.e(l, 1, 0);
                        }, f.prototype.fork = function() {
                            return this.states = new c(this), this.head = this.tail = new a(u, 0, 0), this.len = 0, 
                            this;
                        }, f.prototype.reset = function() {
                            return this.states ? (this.head = this.states.head, this.tail = this.states.tail, 
                            this.len = this.states.len, this.states = this.states.next) : (this.head = this.tail = new a(u, 0, 0), 
                            this.len = 0), this;
                        }, f.prototype.ldelim = function() {
                            var t = this.head, e = this.tail, n = this.len;
                            return this.reset().uint32(n), n && (this.tail.next = t.next, this.tail = e, this.len += n), 
                            this;
                        }, f.prototype.finish = function() {
                            for (var t = this.head.next, e = this.constructor.alloc(this.len), n = 0; t; ) t.fn(t.val, e, n), 
                            n += t.len, t = t.next;
                            return e;
                        }, f.n = function(t) {
                            n = t;
                        };
                    }, {
                        15: 15
                    } ],
                    17: [ function(t, e) {
                        e.exports = o;
                        var n = t(16);
                        (o.prototype = Object.create(n.prototype)).constructor = o;
                        var i = t(15), r = i.Buffer;
                        function o() {
                            n.call(this);
                        }
                        o.alloc = function(t) {
                            return (o.alloc = i.u)(t);
                        };
                        var s = r && r.prototype instanceof Uint8Array && "set" === r.prototype.set.name ? function(t, e, n) {
                            e.set(t, n);
                        } : function(t, e, n) {
                            if (t.copy) t.copy(e, n, 0, t.length); else for (var i = 0; i < t.length; ) e[n++] = t[i++];
                        };
                        function a(t, e, n) {
                            t.length < 40 ? i.utf8.write(t, e, n) : e.utf8Write(t, n);
                        }
                        o.prototype.bytes = function(t) {
                            i.isString(t) && (t = i.r(t, "base64"));
                            var e = t.length >>> 0;
                            return this.uint32(e), e && this.e(s, e, t), this;
                        }, o.prototype.string = function(t) {
                            var e = r.byteLength(t);
                            return this.uint32(e), e && this.e(a, e, t), this;
                        };
                    }, {
                        15: 15,
                        16: 16
                    } ]
                }, u = {}, t = [ 8 ], n = function t(e) {
                    var n = u[e];
                    return n || r[e][0].call(n = u[e] = {
                        exports: {}
                    }, t, n, n.exports), n.exports;
                }(t[0]), n.util.global.protobuf = n, "object" == _typeof(module) && module && module.exports && (module.exports = n);
            }();
        }(protobuf_min);
        var protobuf_minExports = protobuf_min.exports, $root = protobuf_minExports.roots, $wires = protobuf_minExports.types ? protobuf_minExports.types.basic : {
            double: 1,
            float: 5,
            int32: 0,
            uint32: 0,
            sint32: 0,
            fixed32: 5,
            sfixed32: 5,
            int64: 0,
            uint64: 0,
            sint64: 0,
            fixed64: 1,
            sfixed64: 1,
            bool: 0,
            string: 2,
            bytes: 2
        }, $packed = protobuf_minExports.types ? protobuf_minExports.types.packed : {
            double: 1,
            float: 5,
            int32: 0,
            uint32: 0,
            sint32: 0,
            fixed32: 5,
            sfixed32: 5,
            int64: 0,
            uint64: 0,
            sint64: 0,
            fixed64: 1,
            sfixed64: 1,
            bool: 0
        }, $types = Object.keys($wires);
        function invalid(t, e) {
            var n = t.name, i = t.repeated, r = t.map, o = t.keyType;
            return n + ": " + e + (i && "array" !== e ? "[]" : r && "object" !== e ? "{k:" + o + "}" : "") + " expected";
        }
        var keyVerifyMap = {
            int32: "key32Re",
            uint32: "key32Re",
            sint32: "key32Re",
            fixed32: "key32Re",
            sfixed32: "key32Re",
            int64: "key64Re",
            uint64: "key64Re",
            sint64: "key64Re",
            fixed64: "key64Re",
            sfixed64: "key64Re",
            bool: "key2Re"
        };
        function verifyKey(t, e, n) {
            return !keyVerifyMap[t] || protobuf_minExports.util[keyVerifyMap[t]].test(e) ? null : (n.keyType = t, 
            invalid(n, "key"));
        }
        for (var type32Map = {
            int32: 1,
            uint32: 1,
            sint32: 1,
            fixed32: 1,
            sfixed32: 1
        }, type64Map = {
            int64: 1,
            uint64: 1,
            sint64: 1,
            fixed64: 1,
            sfixed64: 1
        }, floatOrDoubleMap = {
            float: 1,
            double: 1
        }, util = protobuf_minExports.util, $verifier = {
            $: function(t, e, n, i) {
                if ("$1" === i) return n.map = !0, verifyKey(t, e, n);
                if (void 0 === $wires[t]) return $root[t].resolvedType ? $root[t].resolvedType[e] ? null : invalid(n, "enum value") : $root[t].verify(e);
                if (type32Map[t]) {
                    if ("number" != typeof e) return invalid(n, "number");
                } else if (type64Map[t]) {
                    if (!(util.isInteger(e) || e && util.isInteger(e.low) && util.isInteger(e.high))) return invalid(n, "integer|Long");
                } else if (floatOrDoubleMap[t]) {
                    if ("number" != typeof e) return invalid(n, "float|double");
                } else if ("bool" === t) {
                    if ("boolean" != typeof e) return invalid(n, "boolean");
                } else if ("string" === t) {
                    if (!util.isString(e)) return invalid(n, "string");
                } else if ("bytes" === t && !(e && "number" == typeof e.length || util.isString(e))) return invalid(n, "invalid bytes");
                return null;
            }
        }, $reader = {
            $: function(t) {
                return $reader[t] ? $reader[t].call(this) : $root[t].decode(this, this.uint32());
            }
        }, $writer = {
            $: function(t, e, n) {
                var i = $wires[t];
                return void 0 === i ? (this.uint32((n << 3 | 2) >> 0).fork(), $root[t].encode(e, this).ldelim()) : $writer[t].call(this.uint32(n << 3 | i), e);
            }
        }, i = 0; i < $types.length; i++) $reader[$types[i]] = protobuf_minExports.Reader.prototype[$types[i]], 
        $writer[$types[i]] = protobuf_minExports.Writer.prototype[$types[i]];
        !function t(e, n, i, r) {
            for (var o = 0, s = Object.keys(e); o < s.length; o++) {
                var a = s[o];
                if (e[a].$ && Object.keys(e[a].$).every(function(t) {
                    return Number(t);
                })) {
                    if (i[a]) throw Error("field " + n + "." + a + " has already existed");
                    i[a] = function(e, r) {
                        function o(t) {
                            for (var n in e) "{" === (n = e[n])[1].charAt(0) ? this[n[0]] = {} : "[" !== n[1].charAt(0) && "<" !== n[1].charAt(0) || (this[n[0]] = []);
                            if (t) for (var i = Object.keys(t), r = 0; r < i.length; ++r) null != t[i[r]] && (this[i[r]] = t[i[r]]);
                        }
                        var s, a = {};
                        for (s in e) {
                            var u = e[s], c = u[1];
                            "{" === c.charAt(0) ? (o.prototype[u[0]] = protobuf_minExports.util.emptyObject, 
                            a[c] = {
                                $: c.substring(1).split(",").map(function(t, e) {
                                    return [ "$" + (e + 1), t, null ];
                                }).reduce(function(t, e, n) {
                                    return t[n + 1] = e, t;
                                }, {})
                            }) : "[" === c.charAt(0) || "<" === c.charAt(0) ? o.prototype[u[0]] = protobuf_minExports.util.emptyArray : "bytes" === c ? o.prototype[u[0]] = protobuf_minExports.util.newBuffer([]) : u[2] && u[2].hasOwnProperty("low") && u[2].hasOwnProperty("high") ? o.prototype[u[0]] = protobuf_minExports.util.Long.fromBits(u[2].low, u[2].high, u[2].unsigned) : o.prototype[u[0]] = u[2];
                        }
                        return o.create = function(t) {
                            return new i[r](t);
                        }, o.decode = function(t, n) {
                            t instanceof protobuf_minExports.Reader || (t = protobuf_minExports.Reader.create(t));
                            for (var o = void 0 === n ? t.len : t.pos + n, s = new i[r](); t.pos < o; ) {
                                var a = t.uint32(), u = a >>> 3;
                                if (0 < u && e[u]) {
                                    var c = e[u][0], f = e[u][1];
                                    if ("{" === f.charAt(0)) s[c] === protobuf_minExports.util.emptyObject && (s[c] = {}), 
                                    u = i[r].$namespace[f].decode(t, t.uint32()), s[c][u.$1] = u.$2; else if ("[" === f.charAt(0) || "<" === f.charAt(0)) if (f = f.substring(1), 
                                    s[c] && s[c].length || (s[c] = []), void 0 !== $packed[f] && 2 == (7 & a)) for (var l = t.uint32() + t.pos; t.pos < l; ) s[c].push($reader.$.call(t, f)); else s[c].push($reader.$.call(t, f)); else s[c] = $reader.$.call(t, f);
                                } else t.skipType(7 & a);
                            }
                            return s;
                        }, o.encode = function(t, n) {
                            for (var o in n = n || protobuf_minExports.Writer.create(), e) {
                                var s = e[o][0];
                                if ("{" === (f = e[o][1]).charAt(0)) {
                                    if (null != t[s] && t.hasOwnProperty(s)) for (var a = 0, u = Object.keys(t[s]); a < u.length; ++a) n.uint32((o << 3 | 2) >> 0).fork(), 
                                    i[r].$namespace[f].encode({
                                        $1: u[a],
                                        $2: t[s][u[a]]
                                    }, n).ldelim();
                                } else if ("[" === f.charAt(0) || "<" === f.charAt(0)) {
                                    var c = "<" === f.charAt(0), f = f.substring(1), l = t[s];
                                    if (null != l && l.length) if (c && void 0 !== $packed[f]) {
                                        for (n.uint32((o << 3 | 2) >> 0).fork(), a = 0; a < l.length; a++) $writer[f].call(n, l[a]);
                                        n.ldelim();
                                    } else for (a = 0; a < l.length; a++) $writer.$.call(n, f, l[a], o);
                                } else null != t[s] && t.hasOwnProperty(s) && $writer.$.call(n, f, t[s], o);
                            }
                            return n;
                        }, o.verify = function(t) {
                            if ("object" != _typeof3(t) || null === t) return "object expected";
                            for (var o in e) {
                                var s = e[o][0], a = e[o][1], u = n + "." + r + "." + s;
                                if ("{" === a.charAt(0)) {
                                    if (null != t[s] && t.hasOwnProperty(s)) {
                                        if (!protobuf_minExports.util.isObject(t[s])) return invalid({
                                            name: u,
                                            map: !0
                                        }, "object");
                                        for (var c = Object.keys(t[s]), f = 0; f < c.length; ++f) if (i[r].$namespace[a].$fieldName = u, 
                                        l = i[r].$namespace[a].verify({
                                            $1: c[f],
                                            $2: t[s][c[f]]
                                        })) return l;
                                    }
                                } else if ("[" === a.charAt(0) || "<" === a.charAt(0)) {
                                    a = a.substring(1);
                                    var l, h = t[s];
                                    if (!Array.isArray(h)) return invalid({
                                        name: u,
                                        repeated: !0
                                    }, "array");
                                    for (f = 0; f < h.length; f++) if (l = $verifier.$(a, h[f], {
                                        name: u + "[" + f + "]",
                                        repeated: !0
                                    })) return l;
                                } else if ("$1" !== s && "$2" !== s || (u = this.$fieldName), null != t[s] && t.hasOwnProperty(s) && (l = $verifier.$(a, t[s], {
                                    name: u
                                }, s))) return l;
                            }
                            return null;
                        }, Object.keys(a).length && (o.$namespace = t(a, n + "." + r, o.$namespace || {}, !0)), 
                        o;
                    }(e[a].$, a), r || ($root[n + "." + a] = i[a]);
                } else e[a]["@"] && Object.values(e[a]["@"]).every(function(t) {
                    return Number(t) === t;
                }) && (i[a] = function(t) {
                    for (var e = Object.keys(t), n = {}, i = 0; i < e.length; i++) n[n[e[i]] = t[e[i]]] = e[i];
                    var r = {};
                    return e.forEach(function(t) {
                        r[n[t]] = 1;
                    }), n.resolvedType = r, n;
                }(e[a]["@"]), r || ($root[n + "." + a] = i[a]));
                delete e[a].$, delete e[a]["@"], i[a] = t(e[a], n ? n + "." + a : a, i[a] || {});
            }
            return i;
        }({
            default: {
                base: {
                    msg: {
                        $: {},
                        AppInfo: {
                            $: {
                                1: [ "titanid", "string", "" ],
                                3: [ "ua", "string", "" ],
                                4: [ "os", "uint32", 0 ],
                                5: [ "uid", "string", "" ],
                                11: [ "repackage", "bool", !1 ],
                                12: [ "accesstoken", "string", "" ],
                                13: [ "customPayload", "{string,bytes", null ],
                                17: [ "authType", "uint32", 0 ],
                                19: [ "sceneType", "uint32", 0 ]
                            }
                        },
                        ExtensionMap: {
                            $: {
                                1: [ "info", "{string,bytes", null ]
                            }
                        },
                        MulticastGroupKeyInfo: {
                            $: {
                                1: [ "appId", "uint32", 0 ],
                                2: [ "bizType", "uint32", 0 ],
                                3: [ "groupId", "string", "" ]
                            }
                        },
                        ReconnectInfo: {
                            $: {
                                1: [ "version", "uint32", 0 ],
                                2: [ "delaySecond", "uint32", 0 ]
                            }
                        },
                        TitanDownstream: {
                            $: {
                                1: [ "command", "string", "" ],
                                2: [ "protocol", "uint32", 0 ],
                                3: [ "errorCode", "uint32", 0 ],
                                4: [ "bizCode", "uint32", 0 ],
                                5: [ "bizErrorMsg", "string", "" ],
                                6: [ "compress", "uint32", 0 ],
                                9: [ "extension", "bytes", [] ],
                                10: [ "body", "bytes", [] ],
                                11: [ "downstreamSeq", "uint64", 0 ],
                                12: [ "conId", "uint64", 0 ],
                                13: [ "ctxId", "uint64", 0 ]
                            }
                        },
                        TitanSessionRequest: {
                            $: {
                                7: [ "encryptedAppInfo", "bytes", [] ],
                                10: [ "requestType", "uint32", 0 ],
                                11: [ "protocolVersion", "uint32", 0 ],
                                12: [ "isPushConn", "bool", !1 ]
                            }
                        },
                        TitanUpstream: {
                            $: {
                                1: [ "appId", "uint32", 0 ],
                                2: [ "command", "string", "" ],
                                3: [ "protocol", "uint32", 0 ],
                                4: [ "compress", "uint32", 0 ],
                                6: [ "host", "string", "" ],
                                7: [ "appinfo", "bytes", [] ],
                                8: [ "sessionResumptionReq", "bytes", [] ],
                                9: [ "body", "bytes", [] ],
                                11: [ "upstreamSeq", "uint64", 0 ],
                                12: [ "conId", "uint64", 0 ],
                                13: [ "ctxId", "uint64", 0 ],
                                14: [ "keyInfo", "default.base.msg.MulticastGroupKeyInfo", null ]
                            }
                        },
                        UpdateAppInfoRequest: {
                            $: {
                                1: [ "appInfo", "bytes", [] ]
                            }
                        }
                    }
                },
                multicast: {
                    msg: {
                        $: {},
                        MulticastBindGroupReq: {
                            $: {
                                1: [ "groupList", "<default.multicast.msg.MulticastGroupItem", null ]
                            }
                        },
                        MulticastGroupItem: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ]
                            }
                        },
                        MulticastHttpSyncReq: {
                            $: {
                                1: [ "appId", "uint32", 0 ],
                                2: [ "req", "default.multicast.msg.MulticastSyncReq", null ]
                            }
                        },
                        MulticastLite: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "msgId", "string", "" ],
                                4: [ "payload", "bytes", [] ],
                                5: [ "needAck", "bool", !1 ]
                            }
                        },
                        MulticastLiteAck: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "msgId", "string", "" ],
                                4: [ "errCode", "uint32", 0 ]
                            }
                        },
                        MulticastNotify: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "offset", "uint64", 0 ],
                                4: [ "ts", "uint64", 0 ],
                                5: [ "minInterval", "uint32", 0 ],
                                6: [ "maxInterval", "uint32", 0 ],
                                7: [ "payload", "bytes", [] ],
                                8: [ "needAck", "bool", !1 ]
                            }
                        },
                        MulticastNotifyAck: {
                            $: {
                                1: [ "ackInfo", "default.multicast.msg.MulticastSyncAckItem", null ]
                            }
                        },
                        MulticastSyncAck: {
                            $: {
                                1: [ "ackList", "<default.multicast.msg.MulticastSyncAckItem", null ]
                            }
                        },
                        MulticastSyncAckItem: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "offset", "uint64", 0 ],
                                4: [ "ts", "uint64", 0 ],
                                5: [ "errCode", "uint32", 0 ]
                            }
                        },
                        MulticastSyncReq: {
                            $: {
                                1: [ "syncList", "<default.multicast.msg.MulticastSyncReqItem", null ]
                            }
                        },
                        MulticastSyncReqItem: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "offset", "uint64", 0 ]
                            }
                        },
                        MulticastSyncResp: {
                            $: {
                                1: [ "resList", "<default.multicast.msg.MulticastSyncRespItem", null ],
                                2: [ "minInterval", "uint32", 0 ],
                                3: [ "maxInterval", "uint32", 0 ],
                                4: [ "needAck", "bool", !1 ]
                            }
                        },
                        MulticastSyncRespItem: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "groupId", "string", "" ],
                                3: [ "forceUpdate", "bool", !1 ],
                                4: [ "payList", "<default.multicast.msg.MulticastSyncRespMsg", null ]
                            }
                        },
                        MulticastSyncRespMsg: {
                            $: {
                                1: [ "offset", "uint64", 0 ],
                                2: [ "payload", "bytes", [] ],
                                3: [ "ts", "uint64", 0 ]
                            }
                        },
                        MulticastUnBindGroupReq: {
                            $: {
                                1: [ "groupList", "<default.multicast.msg.MulticastGroupItem", null ]
                            }
                        }
                    }
                },
                unicast: {
                    msg: {
                        $: {},
                        Ack: {
                            $: {
                                1: [ "uidMap", "{uint32,default.unicast.msg.AckGroupItem", null ],
                                2: [ "titanidMap", "{uint32,default.unicast.msg.AckGroupItem", null ],
                                3: [ "additionalMap", "{string,string", null ]
                            }
                        },
                        AckGroupItem: {
                            $: {
                                1: [ "clientOffset", "uint64", 0 ],
                                2: [ "msgMap", "{uint64,uint32", null ],
                                3: [ "msgDetailMap", "{uint64,default.unicast.msg.AckItemDetailInfo", null ]
                            }
                        },
                        AckItemDetailInfo: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "subType", "uint32", 0 ],
                                3: [ "msgId", "string", "" ],
                                4: [ "timestamp", "uint64", 0 ]
                            }
                        },
                        Notify: {
                            $: {
                                1: [ "uid", "string", "" ],
                                2: [ "titanid", "string", "" ],
                                3: [ "os", "uint32", 0 ],
                                4: [ "uidGroupList", "<uint32", null ],
                                5: [ "titanidGroupList", "<uint32", null ]
                            }
                        },
                        NotifyData: {
                            $: {
                                1: [ "uid", "string", "" ],
                                2: [ "titanid", "string", "" ],
                                3: [ "os", "uint32", 0 ],
                                4: [ "uidMap", "{uint32,default.unicast.msg.NotifyGroupMsgList", null ],
                                5: [ "titanidMap", "{uint32,default.unicast.msg.NotifyGroupMsgList", null ],
                                6: [ "additionalMap", "{string,string", null ]
                            }
                        },
                        NotifyDataLite: {
                            $: {
                                1: [ "uid", "string", "" ],
                                2: [ "titanid", "string", "" ],
                                3: [ "os", "uint32", 0 ],
                                4: [ "bizType", "uint32", 0 ],
                                5: [ "msgId", "string", "" ],
                                6: [ "payload", "bytes", [] ],
                                7: [ "additionalMap", "{string,string", null ],
                                8: [ "subType", "uint32", 0 ],
                                9: [ "timestamp", "uint64", 0 ]
                            }
                        },
                        NotifyDataLiteAck: {
                            $: {
                                1: [ "msgId", "string", "" ],
                                2: [ "bizType", "uint32", 0 ],
                                3: [ "additionalMap", "{string,string", null ],
                                4: [ "subType", "uint32", 0 ],
                                5: [ "timestamp", "uint64", 0 ]
                            }
                        },
                        NotifyGroupMsgList: {
                            $: {
                                1: [ "msgList", "<default.unicast.msg.NotifyMsg", null ]
                            }
                        },
                        NotifyInner: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "body", "bytes", [] ]
                            }
                        },
                        NotifyMsg: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "isExpired", "bool", !1 ],
                                3: [ "offset", "uint64", 0 ],
                                4: [ "startOffset", "uint64", 0 ],
                                5: [ "endOffset", "uint64", 0 ],
                                6: [ "payload", "bytes", [] ],
                                7: [ "msgId", "string", "" ],
                                8: [ "subType", "uint32", 0 ],
                                9: [ "timestamp", "uint64", 0 ],
                                10: [ "expiredTs", "uint64", 0 ]
                            }
                        },
                        Sync: {
                            $: {
                                1: [ "uidOffsetMap", "{uint32,uint64", null ],
                                2: [ "titanidOffsetMap", "{uint32,uint64", null ],
                                3: [ "syncAll", "bool", !1 ],
                                4: [ "accept", "uint32", 0 ]
                            }
                        },
                        SyncGroupMsgList: {
                            $: {
                                1: [ "msgList", "<default.unicast.msg.SyncMsg", null ],
                                2: [ "forceUpdate", "bool", !1 ],
                                3: [ "hasMore", "uint32", 0 ]
                            }
                        },
                        SyncMsg: {
                            $: {
                                1: [ "bizType", "uint32", 0 ],
                                2: [ "isExpired", "bool", !1 ],
                                3: [ "offset", "uint64", 0 ],
                                4: [ "startOffset", "uint64", 0 ],
                                5: [ "endOffset", "uint64", 0 ],
                                6: [ "payload", "bytes", [] ],
                                7: [ "msgId", "string", "" ],
                                8: [ "subType", "uint32", 0 ],
                                9: [ "timestamp", "uint64", 0 ],
                                10: [ "expiredTs", "uint64", 0 ]
                            }
                        },
                        SyncResponse: {
                            $: {
                                1: [ "uid", "string", "" ],
                                2: [ "titanid", "string", "" ],
                                3: [ "os", "uint32", 0 ],
                                4: [ "uidMap", "{uint32,default.unicast.msg.SyncGroupMsgList", null ],
                                5: [ "titanidMap", "{uint32,default.unicast.msg.SyncGroupMsgList", null ],
                                6: [ "additionalMap", "{string,string", null ],
                                7: [ "needAck", "bool", !1 ],
                                8: [ "interval", "uint32", 0 ]
                            }
                        },
                        TokenFail: {
                            $: {
                                1: [ "errCode", "uint32", 0 ],
                                2: [ "accesstoken", "bytes", [] ]
                            }
                        }
                    }
                }
            }
        }, "", $root, !1);
        var pb = $root.default, utf8$1 = {};
        !function(t) {
            var e, n, i, r = String.fromCharCode;
            function o(t) {
                for (var e, n, i = [], r = 0, o = t.length; r < o; ) (e = t.charCodeAt(r++)) >= 55296 && e <= 56319 && r < o ? 56320 == (64512 & (n = t.charCodeAt(r++))) ? i.push(((1023 & e) << 10) + (1023 & n) + 65536) : (i.push(e), 
                r--) : i.push(e);
                return i;
            }
            function s(t) {
                if (t >= 55296 && t <= 57343) throw Error("Lone surrogate U+" + t.toString(16).toUpperCase() + " is not a scalar value");
            }
            function a(t, e) {
                return r(t >> e & 63 | 128);
            }
            function u(t) {
                if (0 == (4294967168 & t)) return r(t);
                var e = "";
                return 0 == (4294965248 & t) ? e = r(t >> 6 & 31 | 192) : 0 == (4294901760 & t) ? (s(t), 
                e = r(t >> 12 & 15 | 224), e += a(t, 6)) : 0 == (4292870144 & t) && (e = r(t >> 18 & 7 | 240), 
                e += a(t, 12), e += a(t, 6)), e + r(63 & t | 128);
            }
            function c() {
                if (i >= n) throw Error("Invalid byte index");
                var t = 255 & e[i];
                if (i++, 128 == (192 & t)) return 63 & t;
                throw Error("Invalid continuation byte");
            }
            function f() {
                var t, r;
                if (i > n) throw Error("Invalid byte index");
                if (i == n) return !1;
                if (t = 255 & e[i], i++, 0 == (128 & t)) return t;
                if (192 == (224 & t)) {
                    if ((r = (31 & t) << 6 | c()) >= 128) return r;
                    throw Error("Invalid continuation byte");
                }
                if (224 == (240 & t)) {
                    if ((r = (15 & t) << 12 | c() << 6 | c()) >= 2048) return s(r), r;
                    throw Error("Invalid continuation byte");
                }
                if (240 == (248 & t) && (r = (7 & t) << 18 | c() << 12 | c() << 6 | c()) >= 65536 && r <= 1114111) return r;
                throw Error("Invalid UTF-8 detected");
            }
            t.version = "3.0.0", t.encode = function(t) {
                for (var e = o(t), n = e.length, i = -1, r = ""; ++i < n; ) r += u(e[i]);
                return r;
            }, t.decode = function(t) {
                e = o(t), n = e.length, i = 0;
                for (var s, a = []; !1 !== (s = f()); ) a.push(s);
                return function(t) {
                    for (var e, n = t.length, i = -1, o = ""; ++i < n; ) (e = t[i]) > 65535 && (o += r((e -= 65536) >>> 10 & 1023 | 55296), 
                    e = 56320 | 1023 & e), o += r(e);
                    return o;
                }(a);
            };
        }(utf8$1);
        var utf8 = getDefaultExportFromCjs(utf8$1), pako_inflate_min = {
            exports: {}
        };
        !function(t, e) {
            function n(t) {
                return "function" == typeof Symbol && "symbol" == _typeof3(Symbol.iterator) ? _typeof3(t) : t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof3(t);
            }
            !function(i) {
                "object" == n(e) ? t.exports = i() : ("undefined" != typeof window ? window : void 0 !== commonjsGlobal ? commonjsGlobal : "undefined" != typeof self ? self : this).pako = i();
            }(function() {
                return function t(e, n, i) {
                    function r(s, a) {
                        if (!n[s]) {
                            if (!e[s]) {
                                var u = "function" == typeof commonjsRequire && commonjsRequire;
                                if (!a && u) return u(s, !0);
                                if (o) return o(s, !0);
                                var c = new Error("Cannot find module '" + s + "'");
                                throw c.code = "MODULE_NOT_FOUND", c;
                            }
                            var f = n[s] = {
                                exports: {}
                            };
                            e[s][0].call(f.exports, function(t) {
                                return r(e[s][1][t] || t);
                            }, f, f.exports, t, e, n, i);
                        }
                        return n[s].exports;
                    }
                    for (var o = "function" == typeof commonjsRequire && commonjsRequire, s = 0; s < i.length; s++) r(i[s]);
                    return r;
                }({
                    1: [ function(t, e, i) {
                        function r(t, e) {
                            return Object.prototype.hasOwnProperty.call(t, e);
                        }
                        var o = "undefined" != typeof Uint8Array && "undefined" != typeof Uint16Array && "undefined" != typeof Int32Array;
                        i.assign = function(t) {
                            for (var e = Array.prototype.slice.call(arguments, 1); e.length; ) {
                                var i = e.shift();
                                if (i) {
                                    if ("object" != n(i)) throw new TypeError(i + "must be non-object");
                                    for (var o in i) r(i, o) && (t[o] = i[o]);
                                }
                            }
                            return t;
                        }, i.shrinkBuf = function(t, e) {
                            return t.length === e ? t : t.subarray ? t.subarray(0, e) : (t.length = e, t);
                        };
                        var s = {
                            arraySet: function(t, e, n, i, r) {
                                if (e.subarray && t.subarray) t.set(e.subarray(n, n + i), r); else for (var o = 0; o < i; o++) t[r + o] = e[n + o];
                            },
                            flattenChunks: function(t) {
                                var e, n, i, r, o, s;
                                for (i = 0, e = 0, n = t.length; e < n; e++) i += t[e].length;
                                for (s = new Uint8Array(i), r = 0, e = 0, n = t.length; e < n; e++) o = t[e], s.set(o, r), 
                                r += o.length;
                                return s;
                            }
                        }, a = {
                            arraySet: function(t, e, n, i, r) {
                                for (var o = 0; o < i; o++) t[r + o] = e[n + o];
                            },
                            flattenChunks: function(t) {
                                return [].concat.apply([], t);
                            }
                        };
                        i.setTyped = function(t) {
                            t ? (i.Buf8 = Uint8Array, i.Buf16 = Uint16Array, i.Buf32 = Int32Array, i.assign(i, s)) : (i.Buf8 = Array, 
                            i.Buf16 = Array, i.Buf32 = Array, i.assign(i, a));
                        }, i.setTyped(o);
                    }, {} ],
                    2: [ function(t, e, n) {
                        function i(t, e) {
                            if (e < 65537 && (t.subarray && s || !t.subarray && o)) return String.fromCharCode.apply(null, r.shrinkBuf(t, e));
                            for (var n = "", i = 0; i < e; i++) n += String.fromCharCode(t[i]);
                            return n;
                        }
                        var r = t("./common"), o = !0, s = !0;
                        try {
                            String.fromCharCode.apply(null, [ 0 ]);
                        } catch (t) {
                            o = !1;
                        }
                        try {
                            String.fromCharCode.apply(null, new Uint8Array(1));
                        } catch (t) {
                            s = !1;
                        }
                        for (var a = new r.Buf8(256), u = 0; u < 256; u++) a[u] = u >= 252 ? 6 : u >= 248 ? 5 : u >= 240 ? 4 : u >= 224 ? 3 : u >= 192 ? 2 : 1;
                        a[254] = a[254] = 1, n.string2buf = function(t) {
                            var e, n, i, o, s, a = t.length, u = 0;
                            for (o = 0; o < a; o++) 55296 == (64512 & (n = t.charCodeAt(o))) && o + 1 < a && 56320 == (64512 & (i = t.charCodeAt(o + 1))) && (n = 65536 + (n - 55296 << 10) + (i - 56320), 
                            o++), u += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
                            for (e = new r.Buf8(u), s = 0, o = 0; s < u; o++) 55296 == (64512 & (n = t.charCodeAt(o))) && o + 1 < a && 56320 == (64512 & (i = t.charCodeAt(o + 1))) && (n = 65536 + (n - 55296 << 10) + (i - 56320), 
                            o++), n < 128 ? e[s++] = n : n < 2048 ? (e[s++] = 192 | n >>> 6, e[s++] = 128 | 63 & n) : n < 65536 ? (e[s++] = 224 | n >>> 12, 
                            e[s++] = 128 | n >>> 6 & 63, e[s++] = 128 | 63 & n) : (e[s++] = 240 | n >>> 18, 
                            e[s++] = 128 | n >>> 12 & 63, e[s++] = 128 | n >>> 6 & 63, e[s++] = 128 | 63 & n);
                            return e;
                        }, n.buf2binstring = function(t) {
                            return i(t, t.length);
                        }, n.binstring2buf = function(t) {
                            for (var e = new r.Buf8(t.length), n = 0, i = e.length; n < i; n++) e[n] = t.charCodeAt(n);
                            return e;
                        }, n.buf2string = function(t, e) {
                            var n, r, o, s, u = e || t.length, c = new Array(2 * u);
                            for (r = 0, n = 0; n < u; ) if ((o = t[n++]) < 128) c[r++] = o; else if ((s = a[o]) > 4) c[r++] = 65533, 
                            n += s - 1; else {
                                for (o &= 2 === s ? 31 : 3 === s ? 15 : 7; s > 1 && n < u; ) o = o << 6 | 63 & t[n++], 
                                s--;
                                s > 1 ? c[r++] = 65533 : o < 65536 ? c[r++] = o : (o -= 65536, c[r++] = 55296 | o >> 10 & 1023, 
                                c[r++] = 56320 | 1023 & o);
                            }
                            return i(c, r);
                        }, n.utf8border = function(t, e) {
                            var n;
                            for ((e = e || t.length) > t.length && (e = t.length), n = e - 1; n >= 0 && 128 == (192 & t[n]); ) n--;
                            return n < 0 || 0 === n ? e : n + a[t[n]] > e ? n : e;
                        };
                    }, {
                        "./common": 1
                    } ],
                    3: [ function(t, e, n) {
                        e.exports = function(t, e, n, i) {
                            for (var r = 65535 & t | 0, o = t >>> 16 & 65535 | 0, s = 0; 0 !== n; ) {
                                n -= s = n > 2e3 ? 2e3 : n;
                                do {
                                    o = o + (r = r + e[i++] | 0) | 0;
                                } while (--s);
                                r %= 65521, o %= 65521;
                            }
                            return r | o << 16 | 0;
                        };
                    }, {} ],
                    4: [ function(t, e, n) {
                        e.exports = {
                            Z_NO_FLUSH: 0,
                            Z_PARTIAL_FLUSH: 1,
                            Z_SYNC_FLUSH: 2,
                            Z_FULL_FLUSH: 3,
                            Z_FINISH: 4,
                            Z_BLOCK: 5,
                            Z_TREES: 6,
                            Z_OK: 0,
                            Z_STREAM_END: 1,
                            Z_NEED_DICT: 2,
                            Z_ERRNO: -1,
                            Z_STREAM_ERROR: -2,
                            Z_DATA_ERROR: -3,
                            Z_BUF_ERROR: -5,
                            Z_NO_COMPRESSION: 0,
                            Z_BEST_SPEED: 1,
                            Z_BEST_COMPRESSION: 9,
                            Z_DEFAULT_COMPRESSION: -1,
                            Z_FILTERED: 1,
                            Z_HUFFMAN_ONLY: 2,
                            Z_RLE: 3,
                            Z_FIXED: 4,
                            Z_DEFAULT_STRATEGY: 0,
                            Z_BINARY: 0,
                            Z_TEXT: 1,
                            Z_UNKNOWN: 2,
                            Z_DEFLATED: 8
                        };
                    }, {} ],
                    5: [ function(t, e, n) {
                        var i = function() {
                            for (var t, e = [], n = 0; n < 256; n++) {
                                t = n;
                                for (var i = 0; i < 8; i++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
                                e[n] = t;
                            }
                            return e;
                        }();
                        e.exports = function(t, e, n, r) {
                            var o = i, s = r + n;
                            t ^= -1;
                            for (var a = r; a < s; a++) t = t >>> 8 ^ o[255 & (t ^ e[a])];
                            return -1 ^ t;
                        };
                    }, {} ],
                    6: [ function(t, e, n) {
                        e.exports = function() {
                            this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, 
                            this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
                        };
                    }, {} ],
                    7: [ function(t, e, n) {
                        e.exports = function(t, e) {
                            var n, i, r, o, s, a, u, c, f, l, h, d, p, m, g, y, b, v, _, w, T, k, S, A, x;
                            n = t.state, i = t.next_in, A = t.input, r = i + (t.avail_in - 5), o = t.next_out, 
                            x = t.output, s = o - (e - t.avail_out), a = o + (t.avail_out - 257), u = n.dmax, 
                            c = n.wsize, f = n.whave, l = n.wnext, h = n.window, d = n.hold, p = n.bits, m = n.lencode, 
                            g = n.distcode, y = (1 << n.lenbits) - 1, b = (1 << n.distbits) - 1;
                            t: do {
                                p < 15 && (d += A[i++] << p, p += 8, d += A[i++] << p, p += 8), v = m[d & y];
                                e: for (;;) {
                                    if (d >>>= _ = v >>> 24, p -= _, 0 == (_ = v >>> 16 & 255)) x[o++] = 65535 & v; else {
                                        if (!(16 & _)) {
                                            if (0 == (64 & _)) {
                                                v = m[(65535 & v) + (d & (1 << _) - 1)];
                                                continue e;
                                            }
                                            if (32 & _) {
                                                n.mode = 12;
                                                break t;
                                            }
                                            t.msg = "invalid literal/length code", n.mode = 30;
                                            break t;
                                        }
                                        w = 65535 & v, (_ &= 15) && (p < _ && (d += A[i++] << p, p += 8), w += d & (1 << _) - 1, 
                                        d >>>= _, p -= _), p < 15 && (d += A[i++] << p, p += 8, d += A[i++] << p, p += 8), 
                                        v = g[d & b];
                                        n: for (;;) {
                                            if (d >>>= _ = v >>> 24, p -= _, !(16 & (_ = v >>> 16 & 255))) {
                                                if (0 == (64 & _)) {
                                                    v = g[(65535 & v) + (d & (1 << _) - 1)];
                                                    continue n;
                                                }
                                                t.msg = "invalid distance code", n.mode = 30;
                                                break t;
                                            }
                                            if (T = 65535 & v, p < (_ &= 15) && (d += A[i++] << p, (p += 8) < _ && (d += A[i++] << p, 
                                            p += 8)), (T += d & (1 << _) - 1) > u) {
                                                t.msg = "invalid distance too far back", n.mode = 30;
                                                break t;
                                            }
                                            if (d >>>= _, p -= _, T > (_ = o - s)) {
                                                if ((_ = T - _) > f && n.sane) {
                                                    t.msg = "invalid distance too far back", n.mode = 30;
                                                    break t;
                                                }
                                                if (k = 0, S = h, 0 === l) {
                                                    if (k += c - _, _ < w) {
                                                        w -= _;
                                                        do {
                                                            x[o++] = h[k++];
                                                        } while (--_);
                                                        k = o - T, S = x;
                                                    }
                                                } else if (l < _) {
                                                    if (k += c + l - _, (_ -= l) < w) {
                                                        w -= _;
                                                        do {
                                                            x[o++] = h[k++];
                                                        } while (--_);
                                                        if (k = 0, l < w) {
                                                            w -= _ = l;
                                                            do {
                                                                x[o++] = h[k++];
                                                            } while (--_);
                                                            k = o - T, S = x;
                                                        }
                                                    }
                                                } else if (k += l - _, _ < w) {
                                                    w -= _;
                                                    do {
                                                        x[o++] = h[k++];
                                                    } while (--_);
                                                    k = o - T, S = x;
                                                }
                                                for (;w > 2; ) x[o++] = S[k++], x[o++] = S[k++], x[o++] = S[k++], w -= 3;
                                                w && (x[o++] = S[k++], w > 1 && (x[o++] = S[k++]));
                                            } else {
                                                k = o - T;
                                                do {
                                                    x[o++] = x[k++], x[o++] = x[k++], x[o++] = x[k++], w -= 3;
                                                } while (w > 2);
                                                w && (x[o++] = x[k++], w > 1 && (x[o++] = x[k++]));
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
                            } while (i < r && o < a);
                            i -= w = p >> 3, d &= (1 << (p -= w << 3)) - 1, t.next_in = i, t.next_out = o, t.avail_in = i < r ? r - i + 5 : 5 - (i - r), 
                            t.avail_out = o < a ? a - o + 257 : 257 - (o - a), n.hold = d, n.bits = p;
                        };
                    }, {} ],
                    8: [ function(t, e, n) {
                        function i(t) {
                            return (t >>> 24 & 255) + (t >>> 8 & 65280) + ((65280 & t) << 8) + ((255 & t) << 24);
                        }
                        function r() {
                            this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, 
                            this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, 
                            this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, 
                            this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, 
                            this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, 
                            this.ndist = 0, this.have = 0, this.next = null, this.lens = new d.Buf16(320), this.work = new d.Buf16(288), 
                            this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
                        }
                        function o(t) {
                            var e;
                            return t && t.state ? (e = t.state, t.total_in = t.total_out = e.total = 0, t.msg = "", 
                            e.wrap && (t.adler = 1 & e.wrap), e.mode = T, e.last = 0, e.havedict = 0, e.dmax = 32768, 
                            e.head = null, e.hold = 0, e.bits = 0, e.lencode = e.lendyn = new d.Buf32(A), e.distcode = e.distdyn = new d.Buf32(x), 
                            e.sane = 1, e.back = -1, _) : w;
                        }
                        function s(t) {
                            var e;
                            return t && t.state ? ((e = t.state).wsize = 0, e.whave = 0, e.wnext = 0, o(t)) : w;
                        }
                        function a(t, e) {
                            var n, i;
                            return t && t.state ? (i = t.state, e < 0 ? (n = 0, e = -e) : (n = 1 + (e >> 4), 
                            e < 48 && (e &= 15)), e && (e < 8 || e > 15) ? w : (null !== i.window && i.wbits !== e && (i.window = null), 
                            i.wrap = n, i.wbits = e, s(t))) : w;
                        }
                        function u(t, e) {
                            var n, i;
                            return t ? (i = new r(), t.state = i, i.window = null, (n = a(t, e)) !== _ && (t.state = null), 
                            n) : w;
                        }
                        function c(t) {
                            if (O) {
                                var e;
                                for (l = new d.Buf32(512), h = new d.Buf32(32), e = 0; e < 144; ) t.lens[e++] = 8;
                                for (;e < 256; ) t.lens[e++] = 9;
                                for (;e < 280; ) t.lens[e++] = 7;
                                for (;e < 288; ) t.lens[e++] = 8;
                                for (y(b, t.lens, 0, 288, l, 0, t.work, {
                                    bits: 9
                                }), e = 0; e < 32; ) t.lens[e++] = 5;
                                y(v, t.lens, 0, 32, h, 0, t.work, {
                                    bits: 5
                                }), O = !1;
                            }
                            t.lencode = l, t.lenbits = 9, t.distcode = h, t.distbits = 5;
                        }
                        function f(t, e, n, i) {
                            var r, o = t.state;
                            return null === o.window && (o.wsize = 1 << o.wbits, o.wnext = 0, o.whave = 0, o.window = new d.Buf8(o.wsize)), 
                            i >= o.wsize ? (d.arraySet(o.window, e, n - o.wsize, o.wsize, 0), o.wnext = 0, o.whave = o.wsize) : ((r = o.wsize - o.wnext) > i && (r = i), 
                            d.arraySet(o.window, e, n - i, r, o.wnext), (i -= r) ? (d.arraySet(o.window, e, n - i, i, 0), 
                            o.wnext = i, o.whave = o.wsize) : (o.wnext += r, o.wnext === o.wsize && (o.wnext = 0), 
                            o.whave < o.wsize && (o.whave += r))), 0;
                        }
                        var l, h, d = t("../utils/common"), p = t("./adler32"), m = t("./crc32"), g = t("./inffast"), y = t("./inftrees"), b = 1, v = 2, _ = 0, w = -2, T = 1, k = 12, S = 30, A = 852, x = 592, O = !0;
                        n.inflateReset = s, n.inflateReset2 = a, n.inflateResetKeep = o, n.inflateInit = function(t) {
                            return u(t, 15);
                        }, n.inflateInit2 = u, n.inflate = function(t, e) {
                            var n, r, o, s, a, u, l, h, A, x, O, M, E, I, C, N, R, L, $, D, j, B, U, P, q = 0, z = new d.Buf8(4), F = [ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ];
                            if (!t || !t.state || !t.output || !t.input && 0 !== t.avail_in) return w;
                            (n = t.state).mode === k && (n.mode = 13), a = t.next_out, o = t.output, l = t.avail_out, 
                            s = t.next_in, r = t.input, u = t.avail_in, h = n.hold, A = n.bits, x = u, O = l, 
                            B = _;
                            t: for (;;) switch (n.mode) {
                              case T:
                                if (0 === n.wrap) {
                                    n.mode = 13;
                                    break;
                                }
                                for (;A < 16; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if (2 & n.wrap && 35615 === h) {
                                    n.check = 0, z[0] = 255 & h, z[1] = h >>> 8 & 255, n.check = m(n.check, z, 2, 0), 
                                    h = 0, A = 0, n.mode = 2;
                                    break;
                                }
                                if (n.flags = 0, n.head && (n.head.done = !1), !(1 & n.wrap) || (((255 & h) << 8) + (h >> 8)) % 31) {
                                    t.msg = "incorrect header check", n.mode = S;
                                    break;
                                }
                                if (8 != (15 & h)) {
                                    t.msg = "unknown compression method", n.mode = S;
                                    break;
                                }
                                if (A -= 4, j = 8 + (15 & (h >>>= 4)), 0 === n.wbits) n.wbits = j; else if (j > n.wbits) {
                                    t.msg = "invalid window size", n.mode = S;
                                    break;
                                }
                                n.dmax = 1 << j, t.adler = n.check = 1, n.mode = 512 & h ? 10 : k, h = 0, A = 0;
                                break;

                              case 2:
                                for (;A < 16; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if (n.flags = h, 8 != (255 & n.flags)) {
                                    t.msg = "unknown compression method", n.mode = S;
                                    break;
                                }
                                if (57344 & n.flags) {
                                    t.msg = "unknown header flags set", n.mode = S;
                                    break;
                                }
                                n.head && (n.head.text = h >> 8 & 1), 512 & n.flags && (z[0] = 255 & h, z[1] = h >>> 8 & 255, 
                                n.check = m(n.check, z, 2, 0)), h = 0, A = 0, n.mode = 3;

                              case 3:
                                for (;A < 32; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                n.head && (n.head.time = h), 512 & n.flags && (z[0] = 255 & h, z[1] = h >>> 8 & 255, 
                                z[2] = h >>> 16 & 255, z[3] = h >>> 24 & 255, n.check = m(n.check, z, 4, 0)), h = 0, 
                                A = 0, n.mode = 4;

                              case 4:
                                for (;A < 16; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                n.head && (n.head.xflags = 255 & h, n.head.os = h >> 8), 512 & n.flags && (z[0] = 255 & h, 
                                z[1] = h >>> 8 & 255, n.check = m(n.check, z, 2, 0)), h = 0, A = 0, n.mode = 5;

                              case 5:
                                if (1024 & n.flags) {
                                    for (;A < 16; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    n.length = h, n.head && (n.head.extra_len = h), 512 & n.flags && (z[0] = 255 & h, 
                                    z[1] = h >>> 8 & 255, n.check = m(n.check, z, 2, 0)), h = 0, A = 0;
                                } else n.head && (n.head.extra = null);
                                n.mode = 6;

                              case 6:
                                if (1024 & n.flags && ((M = n.length) > u && (M = u), M && (n.head && (j = n.head.extra_len - n.length, 
                                n.head.extra || (n.head.extra = new Array(n.head.extra_len)), d.arraySet(n.head.extra, r, s, M, j)), 
                                512 & n.flags && (n.check = m(n.check, r, M, s)), u -= M, s += M, n.length -= M), 
                                n.length)) break t;
                                n.length = 0, n.mode = 7;

                              case 7:
                                if (2048 & n.flags) {
                                    if (0 === u) break t;
                                    M = 0;
                                    do {
                                        j = r[s + M++], n.head && j && n.length < 65536 && (n.head.name += String.fromCharCode(j));
                                    } while (j && M < u);
                                    if (512 & n.flags && (n.check = m(n.check, r, M, s)), u -= M, s += M, j) break t;
                                } else n.head && (n.head.name = null);
                                n.length = 0, n.mode = 8;

                              case 8:
                                if (4096 & n.flags) {
                                    if (0 === u) break t;
                                    M = 0;
                                    do {
                                        j = r[s + M++], n.head && j && n.length < 65536 && (n.head.comment += String.fromCharCode(j));
                                    } while (j && M < u);
                                    if (512 & n.flags && (n.check = m(n.check, r, M, s)), u -= M, s += M, j) break t;
                                } else n.head && (n.head.comment = null);
                                n.mode = 9;

                              case 9:
                                if (512 & n.flags) {
                                    for (;A < 16; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    if (h !== (65535 & n.check)) {
                                        t.msg = "header crc mismatch", n.mode = S;
                                        break;
                                    }
                                    h = 0, A = 0;
                                }
                                n.head && (n.head.hcrc = n.flags >> 9 & 1, n.head.done = !0), t.adler = n.check = 0, 
                                n.mode = k;
                                break;

                              case 10:
                                for (;A < 32; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                t.adler = n.check = i(h), h = 0, A = 0, n.mode = 11;

                              case 11:
                                if (0 === n.havedict) return t.next_out = a, t.avail_out = l, t.next_in = s, t.avail_in = u, 
                                n.hold = h, n.bits = A, 2;
                                t.adler = n.check = 1, n.mode = k;

                              case k:
                                if (5 === e || 6 === e) break t;

                              case 13:
                                if (n.last) {
                                    h >>>= 7 & A, A -= 7 & A, n.mode = 27;
                                    break;
                                }
                                for (;A < 3; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                switch (n.last = 1 & h, A -= 1, 3 & (h >>>= 1)) {
                                  case 0:
                                    n.mode = 14;
                                    break;

                                  case 1:
                                    if (c(n), n.mode = 20, 6 === e) {
                                        h >>>= 2, A -= 2;
                                        break t;
                                    }
                                    break;

                                  case 2:
                                    n.mode = 17;
                                    break;

                                  case 3:
                                    t.msg = "invalid block type", n.mode = S;
                                }
                                h >>>= 2, A -= 2;
                                break;

                              case 14:
                                for (h >>>= 7 & A, A -= 7 & A; A < 32; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if ((65535 & h) != (h >>> 16 ^ 65535)) {
                                    t.msg = "invalid stored block lengths", n.mode = S;
                                    break;
                                }
                                if (n.length = 65535 & h, h = 0, A = 0, n.mode = 15, 6 === e) break t;

                              case 15:
                                n.mode = 16;

                              case 16:
                                if (M = n.length) {
                                    if (M > u && (M = u), M > l && (M = l), 0 === M) break t;
                                    d.arraySet(o, r, s, M, a), u -= M, s += M, l -= M, a += M, n.length -= M;
                                    break;
                                }
                                n.mode = k;
                                break;

                              case 17:
                                for (;A < 14; ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if (n.nlen = 257 + (31 & h), h >>>= 5, A -= 5, n.ndist = 1 + (31 & h), h >>>= 5, 
                                A -= 5, n.ncode = 4 + (15 & h), h >>>= 4, A -= 4, n.nlen > 286 || n.ndist > 30) {
                                    t.msg = "too many length or distance symbols", n.mode = S;
                                    break;
                                }
                                n.have = 0, n.mode = 18;

                              case 18:
                                for (;n.have < n.ncode; ) {
                                    for (;A < 3; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    n.lens[F[n.have++]] = 7 & h, h >>>= 3, A -= 3;
                                }
                                for (;n.have < 19; ) n.lens[F[n.have++]] = 0;
                                if (n.lencode = n.lendyn, n.lenbits = 7, U = {
                                    bits: n.lenbits
                                }, B = y(0, n.lens, 0, 19, n.lencode, 0, n.work, U), n.lenbits = U.bits, B) {
                                    t.msg = "invalid code lengths set", n.mode = S;
                                    break;
                                }
                                n.have = 0, n.mode = 19;

                              case 19:
                                for (;n.have < n.nlen + n.ndist; ) {
                                    for (;N = (q = n.lencode[h & (1 << n.lenbits) - 1]) >>> 16 & 255, R = 65535 & q, 
                                    !((C = q >>> 24) <= A); ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    if (R < 16) h >>>= C, A -= C, n.lens[n.have++] = R; else {
                                        if (16 === R) {
                                            for (P = C + 2; A < P; ) {
                                                if (0 === u) break t;
                                                u--, h += r[s++] << A, A += 8;
                                            }
                                            if (h >>>= C, A -= C, 0 === n.have) {
                                                t.msg = "invalid bit length repeat", n.mode = S;
                                                break;
                                            }
                                            j = n.lens[n.have - 1], M = 3 + (3 & h), h >>>= 2, A -= 2;
                                        } else if (17 === R) {
                                            for (P = C + 3; A < P; ) {
                                                if (0 === u) break t;
                                                u--, h += r[s++] << A, A += 8;
                                            }
                                            A -= C, j = 0, M = 3 + (7 & (h >>>= C)), h >>>= 3, A -= 3;
                                        } else {
                                            for (P = C + 7; A < P; ) {
                                                if (0 === u) break t;
                                                u--, h += r[s++] << A, A += 8;
                                            }
                                            A -= C, j = 0, M = 11 + (127 & (h >>>= C)), h >>>= 7, A -= 7;
                                        }
                                        if (n.have + M > n.nlen + n.ndist) {
                                            t.msg = "invalid bit length repeat", n.mode = S;
                                            break;
                                        }
                                        for (;M--; ) n.lens[n.have++] = j;
                                    }
                                }
                                if (n.mode === S) break;
                                if (0 === n.lens[256]) {
                                    t.msg = "invalid code -- missing end-of-block", n.mode = S;
                                    break;
                                }
                                if (n.lenbits = 9, U = {
                                    bits: n.lenbits
                                }, B = y(b, n.lens, 0, n.nlen, n.lencode, 0, n.work, U), n.lenbits = U.bits, B) {
                                    t.msg = "invalid literal/lengths set", n.mode = S;
                                    break;
                                }
                                if (n.distbits = 6, n.distcode = n.distdyn, U = {
                                    bits: n.distbits
                                }, B = y(v, n.lens, n.nlen, n.ndist, n.distcode, 0, n.work, U), n.distbits = U.bits, 
                                B) {
                                    t.msg = "invalid distances set", n.mode = S;
                                    break;
                                }
                                if (n.mode = 20, 6 === e) break t;

                              case 20:
                                n.mode = 21;

                              case 21:
                                if (u >= 6 && l >= 258) {
                                    t.next_out = a, t.avail_out = l, t.next_in = s, t.avail_in = u, n.hold = h, n.bits = A, 
                                    g(t, O), a = t.next_out, o = t.output, l = t.avail_out, s = t.next_in, r = t.input, 
                                    u = t.avail_in, h = n.hold, A = n.bits, n.mode === k && (n.back = -1);
                                    break;
                                }
                                for (n.back = 0; N = (q = n.lencode[h & (1 << n.lenbits) - 1]) >>> 16 & 255, R = 65535 & q, 
                                !((C = q >>> 24) <= A); ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if (N && 0 == (240 & N)) {
                                    for (L = C, $ = N, D = R; N = (q = n.lencode[D + ((h & (1 << L + $) - 1) >> L)]) >>> 16 & 255, 
                                    R = 65535 & q, !(L + (C = q >>> 24) <= A); ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    h >>>= L, A -= L, n.back += L;
                                }
                                if (h >>>= C, A -= C, n.back += C, n.length = R, 0 === N) {
                                    n.mode = 26;
                                    break;
                                }
                                if (32 & N) {
                                    n.back = -1, n.mode = k;
                                    break;
                                }
                                if (64 & N) {
                                    t.msg = "invalid literal/length code", n.mode = S;
                                    break;
                                }
                                n.extra = 15 & N, n.mode = 22;

                              case 22:
                                if (n.extra) {
                                    for (P = n.extra; A < P; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    n.length += h & (1 << n.extra) - 1, h >>>= n.extra, A -= n.extra, n.back += n.extra;
                                }
                                n.was = n.length, n.mode = 23;

                              case 23:
                                for (;N = (q = n.distcode[h & (1 << n.distbits) - 1]) >>> 16 & 255, R = 65535 & q, 
                                !((C = q >>> 24) <= A); ) {
                                    if (0 === u) break t;
                                    u--, h += r[s++] << A, A += 8;
                                }
                                if (0 == (240 & N)) {
                                    for (L = C, $ = N, D = R; N = (q = n.distcode[D + ((h & (1 << L + $) - 1) >> L)]) >>> 16 & 255, 
                                    R = 65535 & q, !(L + (C = q >>> 24) <= A); ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    h >>>= L, A -= L, n.back += L;
                                }
                                if (h >>>= C, A -= C, n.back += C, 64 & N) {
                                    t.msg = "invalid distance code", n.mode = S;
                                    break;
                                }
                                n.offset = R, n.extra = 15 & N, n.mode = 24;

                              case 24:
                                if (n.extra) {
                                    for (P = n.extra; A < P; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    n.offset += h & (1 << n.extra) - 1, h >>>= n.extra, A -= n.extra, n.back += n.extra;
                                }
                                if (n.offset > n.dmax) {
                                    t.msg = "invalid distance too far back", n.mode = S;
                                    break;
                                }
                                n.mode = 25;

                              case 25:
                                if (0 === l) break t;
                                if (M = O - l, n.offset > M) {
                                    if ((M = n.offset - M) > n.whave && n.sane) {
                                        t.msg = "invalid distance too far back", n.mode = S;
                                        break;
                                    }
                                    M > n.wnext ? (M -= n.wnext, E = n.wsize - M) : E = n.wnext - M, M > n.length && (M = n.length), 
                                    I = n.window;
                                } else I = o, E = a - n.offset, M = n.length;
                                M > l && (M = l), l -= M, n.length -= M;
                                do {
                                    o[a++] = I[E++];
                                } while (--M);
                                0 === n.length && (n.mode = 21);
                                break;

                              case 26:
                                if (0 === l) break t;
                                o[a++] = n.length, l--, n.mode = 21;
                                break;

                              case 27:
                                if (n.wrap) {
                                    for (;A < 32; ) {
                                        if (0 === u) break t;
                                        u--, h |= r[s++] << A, A += 8;
                                    }
                                    if (O -= l, t.total_out += O, n.total += O, O && (t.adler = n.check = n.flags ? m(n.check, o, O, a - O) : p(n.check, o, O, a - O)), 
                                    O = l, (n.flags ? h : i(h)) !== n.check) {
                                        t.msg = "incorrect data check", n.mode = S;
                                        break;
                                    }
                                    h = 0, A = 0;
                                }
                                n.mode = 28;

                              case 28:
                                if (n.wrap && n.flags) {
                                    for (;A < 32; ) {
                                        if (0 === u) break t;
                                        u--, h += r[s++] << A, A += 8;
                                    }
                                    if (h !== (4294967295 & n.total)) {
                                        t.msg = "incorrect length check", n.mode = S;
                                        break;
                                    }
                                    h = 0, A = 0;
                                }
                                n.mode = 29;

                              case 29:
                                B = 1;
                                break t;

                              case S:
                                B = -3;
                                break t;

                              case 31:
                                return -4;

                              default:
                                return w;
                            }
                            return t.next_out = a, t.avail_out = l, t.next_in = s, t.avail_in = u, n.hold = h, 
                            n.bits = A, (n.wsize || O !== t.avail_out && n.mode < S && (n.mode < 27 || 4 !== e)) && f(t, t.output, t.next_out, O - t.avail_out) ? (n.mode = 31, 
                            -4) : (x -= t.avail_in, O -= t.avail_out, t.total_in += x, t.total_out += O, n.total += O, 
                            n.wrap && O && (t.adler = n.check = n.flags ? m(n.check, o, O, t.next_out - O) : p(n.check, o, O, t.next_out - O)), 
                            t.data_type = n.bits + (n.last ? 64 : 0) + (n.mode === k ? 128 : 0) + (20 === n.mode || 15 === n.mode ? 256 : 0), 
                            (0 === x && 0 === O || 4 === e) && B === _ && (B = -5), B);
                        }, n.inflateEnd = function(t) {
                            if (!t || !t.state) return w;
                            var e = t.state;
                            return e.window && (e.window = null), t.state = null, _;
                        }, n.inflateGetHeader = function(t, e) {
                            var n;
                            return t && t.state ? 0 == (2 & (n = t.state).wrap) ? w : (n.head = e, e.done = !1, 
                            _) : w;
                        }, n.inflateSetDictionary = function(t, e) {
                            var n, i = e.length;
                            return t && t.state ? 0 !== (n = t.state).wrap && 11 !== n.mode ? w : 11 === n.mode && p(1, e, i, 0) !== n.check ? -3 : f(t, e, i, i) ? (n.mode = 31, 
                            -4) : (n.havedict = 1, _) : w;
                        }, n.inflateInfo = "pako inflate (from Nodeca project)";
                    }, {
                        "../utils/common": 1,
                        "./adler32": 3,
                        "./crc32": 5,
                        "./inffast": 7,
                        "./inftrees": 9
                    } ],
                    9: [ function(t, e, n) {
                        var i = t("../utils/common"), r = [ 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0 ], o = [ 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78 ], s = [ 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0 ], a = [ 16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64 ];
                        e.exports = function(t, e, n, u, c, f, l, h) {
                            var d, p, m, g, y, b, v, _, w, T = h.bits, k = 0, S = 0, A = 0, x = 0, O = 0, M = 0, E = 0, I = 0, C = 0, N = 0, R = null, L = 0, $ = new i.Buf16(16), D = new i.Buf16(16), j = null, B = 0;
                            for (k = 0; k <= 15; k++) $[k] = 0;
                            for (S = 0; S < u; S++) $[e[n + S]]++;
                            for (O = T, x = 15; x >= 1 && 0 === $[x]; x--) ;
                            if (O > x && (O = x), 0 === x) return c[f++] = 20971520, c[f++] = 20971520, h.bits = 1, 
                            0;
                            for (A = 1; A < x && 0 === $[A]; A++) ;
                            for (O < A && (O = A), I = 1, k = 1; k <= 15; k++) if (I <<= 1, (I -= $[k]) < 0) return -1;
                            if (I > 0 && (0 === t || 1 !== x)) return -1;
                            for (D[1] = 0, k = 1; k < 15; k++) D[k + 1] = D[k] + $[k];
                            for (S = 0; S < u; S++) 0 !== e[n + S] && (l[D[e[n + S]]++] = S);
                            if (0 === t ? (R = j = l, b = 19) : 1 === t ? (R = r, L -= 257, j = o, B -= 257, 
                            b = 256) : (R = s, j = a, b = -1), N = 0, S = 0, k = A, y = f, M = O, E = 0, m = -1, 
                            g = (C = 1 << O) - 1, 1 === t && C > 852 || 2 === t && C > 592) return 1;
                            for (;;) {
                                v = k - E, l[S] < b ? (_ = 0, w = l[S]) : l[S] > b ? (_ = j[B + l[S]], w = R[L + l[S]]) : (_ = 96, 
                                w = 0), d = 1 << k - E, A = p = 1 << M;
                                do {
                                    c[y + (N >> E) + (p -= d)] = v << 24 | _ << 16 | w | 0;
                                } while (0 !== p);
                                for (d = 1 << k - 1; N & d; ) d >>= 1;
                                if (0 !== d ? (N &= d - 1, N += d) : N = 0, S++, 0 == --$[k]) {
                                    if (k === x) break;
                                    k = e[n + l[S]];
                                }
                                if (k > O && (N & g) !== m) {
                                    for (0 === E && (E = O), y += A, I = 1 << (M = k - E); M + E < x && !((I -= $[M + E]) <= 0); ) M++, 
                                    I <<= 1;
                                    if (C += 1 << M, 1 === t && C > 852 || 2 === t && C > 592) return 1;
                                    c[m = N & g] = O << 24 | M << 16 | y - f | 0;
                                }
                            }
                            return 0 !== N && (c[y + N] = k - E << 24 | 64 << 16 | 0), h.bits = O, 0;
                        };
                    }, {
                        "../utils/common": 1
                    } ],
                    10: [ function(t, e, n) {
                        e.exports = {
                            2: "need dictionary",
                            1: "stream end",
                            0: "",
                            "-1": "file error",
                            "-2": "stream error",
                            "-3": "data error",
                            "-4": "insufficient memory",
                            "-5": "buffer error",
                            "-6": "incompatible version"
                        };
                    }, {} ],
                    11: [ function(t, e, n) {
                        e.exports = function() {
                            this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, 
                            this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, 
                            this.data_type = 2, this.adler = 0;
                        };
                    }, {} ],
                    "/lib/inflate.js": [ function(t, e, n) {
                        function i(t) {
                            if (!(this instanceof i)) return new i(t);
                            this.options = s.assign({
                                chunkSize: 16384,
                                windowBits: 0,
                                to: ""
                            }, t || {});
                            var e = this.options;
                            e.raw && e.windowBits >= 0 && e.windowBits < 16 && (e.windowBits = -e.windowBits, 
                            0 === e.windowBits && (e.windowBits = -15)), !(e.windowBits >= 0 && e.windowBits < 16) || t && t.windowBits || (e.windowBits += 32), 
                            e.windowBits > 15 && e.windowBits < 48 && 0 == (15 & e.windowBits) && (e.windowBits |= 15), 
                            this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new f(), 
                            this.strm.avail_out = 0;
                            var n = o.inflateInit2(this.strm, e.windowBits);
                            if (n !== u.Z_OK) throw new Error(c[n]);
                            this.header = new l(), o.inflateGetHeader(this.strm, this.header);
                        }
                        function r(t, e) {
                            var n = new i(e);
                            if (n.push(t, !0), n.err) throw n.msg || c[n.err];
                            return n.result;
                        }
                        var o = t("./zlib/inflate"), s = t("./utils/common"), a = t("./utils/strings"), u = t("./zlib/constants"), c = t("./zlib/messages"), f = t("./zlib/zstream"), l = t("./zlib/gzheader"), h = Object.prototype.toString;
                        i.prototype.push = function(t, e) {
                            var n, i, r, c, f, l, d = this.strm, p = this.options.chunkSize, m = this.options.dictionary, g = !1;
                            if (this.ended) return !1;
                            i = e === ~~e ? e : !0 === e ? u.Z_FINISH : u.Z_NO_FLUSH, "string" == typeof t ? d.input = a.binstring2buf(t) : "[object ArrayBuffer]" === h.call(t) ? d.input = new Uint8Array(t) : d.input = t, 
                            d.next_in = 0, d.avail_in = d.input.length;
                            do {
                                if (0 === d.avail_out && (d.output = new s.Buf8(p), d.next_out = 0, d.avail_out = p), 
                                (n = o.inflate(d, u.Z_NO_FLUSH)) === u.Z_NEED_DICT && m && (l = "string" == typeof m ? a.string2buf(m) : "[object ArrayBuffer]" === h.call(m) ? new Uint8Array(m) : m, 
                                n = o.inflateSetDictionary(this.strm, l)), n === u.Z_BUF_ERROR && !0 === g && (n = u.Z_OK, 
                                g = !1), n !== u.Z_STREAM_END && n !== u.Z_OK) return this.onEnd(n), this.ended = !0, 
                                !1;
                                d.next_out && (0 !== d.avail_out && n !== u.Z_STREAM_END && (0 !== d.avail_in || i !== u.Z_FINISH && i !== u.Z_SYNC_FLUSH) || ("string" === this.options.to ? (r = a.utf8border(d.output, d.next_out), 
                                c = d.next_out - r, f = a.buf2string(d.output, r), d.next_out = c, d.avail_out = p - c, 
                                c && s.arraySet(d.output, d.output, r, c, 0), this.onData(f)) : this.onData(s.shrinkBuf(d.output, d.next_out)))), 
                                0 === d.avail_in && 0 === d.avail_out && (g = !0);
                            } while ((d.avail_in > 0 || 0 === d.avail_out) && n !== u.Z_STREAM_END);
                            return n === u.Z_STREAM_END && (i = u.Z_FINISH), i === u.Z_FINISH ? (n = o.inflateEnd(this.strm), 
                            this.onEnd(n), this.ended = !0, n === u.Z_OK) : i !== u.Z_SYNC_FLUSH || (this.onEnd(u.Z_OK), 
                            d.avail_out = 0, !0);
                        }, i.prototype.onData = function(t) {
                            this.chunks.push(t);
                        }, i.prototype.onEnd = function(t) {
                            t === u.Z_OK && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = s.flattenChunks(this.chunks)), 
                            this.chunks = [], this.err = t, this.msg = this.strm.msg;
                        }, n.Inflate = i, n.inflate = r, n.inflateRaw = function(t, e) {
                            return (e = e || {}).raw = !0, r(t, e);
                        }, n.ungzip = r;
                    }, {
                        "./utils/common": 1,
                        "./utils/strings": 2,
                        "./zlib/constants": 4,
                        "./zlib/gzheader": 6,
                        "./zlib/inflate": 8,
                        "./zlib/messages": 10,
                        "./zlib/zstream": 11
                    } ]
                }, {}, [])("/lib/inflate.js");
            });
        }(pako_inflate_min, pako_inflate_min.exports);
        var pako_inflate_minExports = pako_inflate_min.exports, pako = getDefaultExportFromCjs(pako_inflate_minExports), STATUS = {
            WAIT_RECONNECT: "wait_reconnect",
            CLOSED: "closed",
            CONNECTING: "connecting",
            RECONNECTING: "reconnecting",
            OPEN: "open"
        }, MAX_RECONNECT_TIMES = 5, MAX_TIMEOUT_COMBO = 3, MAX_SESSION_RETRY_TIMES = 1, TIMEOUT = 5e3, HEARTBEAT_RATE = 45e3, MAGIC = {
            HEARTBEAT: 0,
            TITAN: 10
        }, CMD = {
            HEARTBEAT: 0,
            TITAN: 102,
            API: 101
        }, RESERVE = 1, COMMAND$2 = {
            SESSION: "titan.session"
        }, PROTOCOL$3 = {
            SESSION: 1,
            API: 2
        }, COMPRESS = {
            GZIP: 1,
            UNGZIP: 0
        }, TOKEN_ERROR_CODE = [ 622, 623, 624, 626, 627, 716 ], TitanDownstream = pb.base.msg.TitanDownstream, url = "bjectSymhasOwnProp-0123456789ABCDEFGHIJKLMNQRTUVWXYZ_dfgiklquvxz", encodeContent = function(t) {
            var e = t.magic, n = t.cmd, i = t.ctx, r = t.reserve, o = t.payload, s = o && o.byteLength || 0, a = new ArrayBuffer(16 + s), u = new DataView(a);
            u.setInt16(0, e, !1), u.setInt16(2, n, !1), u.setInt32(4, i, !1), u.setInt32(8, r, !1), 
            u.setInt32(12, s, !1);
            for (var c = 0; c < s; c++) u.setUint8(16 + c, o[c], !1);
            return a;
        }, decodeContent = function(t) {
            var e = new DataView(t, 0, t.byteLength), n = e.getInt16(0, !1), i = e.getInt16(2, !1), r = e.getInt32(4, !1), o = e.getInt32(8, !1), s = e.getInt32(12, !1), a = new Uint8Array(t, 16);
            try {
                var u = a = TitanDownstream.decode(a), c = u.compress, f = u.body, l = u.extension;
                c === COMPRESS.GZIP && (f instanceof Uint8Array && f.byteLength && (a.body = pako.ungzip(f)), 
                l instanceof Uint8Array && l.byteLength && (a.extension = pako.ungzip(l)));
            } catch (t) {
                throw t;
            }
            return {
                magic: n,
                cmd: i,
                ctx: r,
                reserve: o,
                bodyLen: s,
                payload: a
            };
        }, getTitanStorage = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            return {
                deviceId: "".concat(t).concat(Date.now(), "_").concat(nanoid())
            };
        }, tryDo = function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            try {
                var n = t();
                return null == n ? e : n;
            } catch (t) {
                return e;
            }
        }, jsonParse = function(t, e) {
            if ("string" != typeof t) return e;
            var n;
            try {
                n = JSON.parse(t) || e;
            } catch (t) {
                n = e;
            }
            return n;
        }, nanoid = function(t) {
            t = t || 21;
            for (var e = ""; t-- > 0; ) e += url[64 * Math.random() | 0];
            return e;
        }, escapeValue = function(t) {
            return (t = (t = (t = t.replace(/\n/g, "\\\\n")).replace(/\r/g, "\\\\r")).replace(/\t/g, "\\\\t")).replace(/\u2028/g, "");
        }, parsePayload = function(t) {
            for (var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = t.byteLength, i = "", r = 0; r < n; r++) i += String.fromCharCode(t[r]);
            return e && (i = utf8.decode(i), i = escapeValue(i)), jsonParse(i, i);
        }, getProtoData = function(t, e) {
            return t.encode(t.create(e)).finish();
        }, mixin = function(t, e) {
            var n;
            for (n in e) Array.isArray(t[n]) ? t[n].push(e[n]) : t[n] = [ e[n] ];
        }, noReport = function() {
            var t = {
                1: 1,
                2: .5,
                4: .25,
                5: .2,
                10: .1
            }, e = 1;
            if (window.__CMT_AMPLIFY_RATE__) {
                var n = window.__CMT_AMPLIFY_RATE__;
                t[n] && (e = t[n]);
            }
            return Math.random() > e;
        }, hasWindow = "undefined" != typeof window, cmtvLog = function() {
            var t = _asyncToGenerator2(_regenerator.default.mark(function t(e) {
                var n, i, r, o, s, a, u, c, f;
                return _regenerator.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (n = e.fields || {}, i = n.isWxApp, !n.cancelLog) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return");

                      case 3:
                        if (r = "https://cmtw.pinduoduo.com/api/cmt/cmtc_h5", i || !hasWindow || (location.hostname.indexOf("hutaojie.com") >= 0 && (r = "https://cmtw.hutaojie.com/api/cmt/cmtc_h5"), 
                        !noReport())) {
                            t.next = 6;
                            break;
                        }
                        return t.abrupt("return");

                      case 6:
                        o = e.type, s = e.fields, a = e.longFields, u = {
                            mutipleKvList: [ {
                                tags: {
                                    type: o,
                                    groupId: "10257",
                                    version: "0.2.4-rc.1"
                                },
                                fields: s,
                                longFields: a
                            } ]
                        }, c = JSON.stringify(u), f = {
                            method: "POST",
                            body: c,
                            data: c,
                            headers: {
                                "Content-Type": "application/json;charset=UTF-8"
                            },
                            credentials: "include"
                        }, i ? wx.request(_objectSpread2({
                            url: r
                        }, f)) : hasWindow && fetch(r, f).catch(function(t) {});

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(), encode = function(t) {
            for (var e = t.length, n = -1, i = "undefined" == typeof Uint8Array ? new Array(1.5 * e) : new Uint8Array(3 * e), r = 0, o = 0, s = 0; s !== e; ) {
                if (r = t.charCodeAt(s), s += 1, r >= 55296 && r <= 56319) {
                    if (s === e) {
                        i[n += 1] = 239, i[n += 1] = 191, i[n += 1] = 189;
                        break;
                    }
                    if (!((o = t.charCodeAt(s)) >= 56320 && o <= 57343)) {
                        i[n += 1] = 239, i[n += 1] = 191, i[n += 1] = 189;
                        continue;
                    }
                    if (s += 1, (r = 1024 * (r - 55296) + o - 56320 + 65536) > 65535) {
                        i[n += 1] = 240 | r >>> 18, i[n += 1] = 128 | r >>> 12 & 63, i[n += 1] = 128 | r >>> 6 & 63, 
                        i[n += 1] = 128 | 63 & r;
                        continue;
                    }
                }
                r <= 127 ? i[n += 1] = 0 | r : r <= 2047 ? (i[n += 1] = 192 | r >>> 6, i[n += 1] = 128 | 63 & r) : (i[n += 1] = 224 | r >>> 12, 
                i[n += 1] = 128 | r >>> 6 & 63, i[n += 1] = 128 | 63 & r);
            }
            return "undefined" != typeof Uint8Array ? i.subarray(0, n + 1) : (i.length = n + 1, 
            i);
        };
        function byteToStr(t) {
            for (var e = "", n = 0; n < t.length; ) {
                var i = t[n], r = 0;
                i >>> 7 == 0 ? (e += String.fromCharCode(t[n]), n += 1) : 252 == (252 & i) ? (r = (3 & t[n]) << 30, 
                r |= (63 & t[n + 1]) << 24, r |= (63 & t[n + 2]) << 18, r |= (63 & t[n + 3]) << 12, 
                r |= (63 & t[n + 4]) << 6, r |= 63 & t[n + 5], e += String.fromCharCode(r), n += 6) : 248 == (248 & i) ? (r = (7 & t[n]) << 24, 
                r |= (63 & t[n + 1]) << 18, r |= (63 & t[n + 2]) << 12, r |= (63 & t[n + 3]) << 6, 
                r |= 63 & t[n + 4], e += String.fromCharCode(r), n += 5) : 240 == (240 & i) ? (r = (15 & t[n]) << 18, 
                r |= (63 & t[n + 1]) << 12, r |= (63 & t[n + 2]) << 6, r |= 63 & t[n + 3], e += String.fromCharCode(r), 
                n += 4) : 224 == (224 & i) ? (r = (31 & t[n]) << 12, r |= (63 & t[n + 1]) << 6, 
                r |= 63 & t[n + 2], e += String.fromCharCode(r), n += 3) : 192 == (192 & i) ? (r = (63 & t[n]) << 6, 
                r |= 63 & t[n + 1], e += String.fromCharCode(r), n += 2) : (e += String.fromCharCode(t[n]), 
                n += 1);
            }
            return e;
        }
        var convertHeaders = function(t) {
            var e = [];
            for (var n in t) e.push(n + ": " + t[n]);
            return e;
        }, _pb$base$msg = pb.base.msg, TitanUpstream = _pb$base$msg.TitanUpstream, AppInfo = _pb$base$msg.AppInfo, UpdateAppInfoRequest = _pb$base$msg.UpdateAppInfoRequest, TitanSessionRequest = _pb$base$msg.TitanSessionRequest, ExtensionMap = _pb$base$msg.ExtensionMap, ReconnectInfo = _pb$base$msg.ReconnectInfo, Titan = function(t) {
            _inherits2(n, t);
            var e = _createSuper2(n);
            function n(t) {
                var i;
                if (_classCallCheck2(this, n), i = e.call(this, t), !t.projectName) throw new Error("projectName参数不能为空");
                if (i.isWxApp = !!t.isWxApp, i.isSupportUnbind = !!t.isWxApp || !!t.isSupportUnbind, 
                i.os = t.os || (i.isWxApp ? 6 : 5), i.url = t.url, i.appId = t.appId, i.maxReconnectTimes = void 0 !== t.maxReconnectTimes ? t.maxReconnectTimes : MAX_RECONNECT_TIMES, 
                i.status = STATUS.CLOSED, i.sendMsgList = [], i.toSendMsgList = [], i.socket = null, 
                i.ctx = 100, i.uid = t.uid || "", i.accesstoken = t.accesstoken || "", i.needAuth = !!t.needAuth, 
                i.host = !i.isWxApp && hasWindow ? window.location.hostname : "", i.ua = !i.isWxApp && hasWindow ? window.navigator.userAgent : "", 
                i.customPayload = t.customPayload, i.titanId = t.titanId || getTitanStorage(t.titanIdPrefix).deviceId, 
                i.appOriginInfo = {
                    titanid: i.titanId,
                    ua: i.ua,
                    os: i.os,
                    uid: i.uid + "",
                    repackage: !1,
                    accesstoken: i.accesstoken
                }, i.customPayload) {
                    for (var r in i.customPayload) i.customPayload[r] = encode(i.customPayload[r] + "");
                    i.appOriginInfo.customPayload = i.customPayload;
                }
                return t.authType && (i.appOriginInfo.authType = t.authType), t.sceneType && (i.appOriginInfo.sceneType = t.sceneType), 
                i.appInfo = getProtoData(AppInfo, i.appOriginInfo), i.reconnectCount = -1, i.apiTimeout = t.apiTimeout || 3e3, 
                i.maxTimeoutCombo = t.maxTimeoutCombo || MAX_TIMEOUT_COMBO, i.responseTimeoutCount = 0, 
                i.checkTimeoutMsgTimer = null, i.heartBeatTimer = null, i.sessionRetryCount = 0, 
                i.retrySessionTimer = null, i.needRestart = !0, i.commonHeaders = t.headers, i.baseOptions = _objectSpread2(_objectSpread2(_objectSpread2({}, t), t.logParams || {}), {}, {
                    logParams: void 0,
                    accesstoken: void 0,
                    titanId: i.titanId
                }), i._hooks = i.constructor.hooks, i.callHooks("init", t), _possibleConstructorReturn2(i);
            }
            return _createClass2(n, [ {
                key: "callHooks",
                value: function(t, e) {
                    var n = this, i = this._hooks[t];
                    Array.isArray(i) && i.forEach(function(t) {
                        "function" == typeof t && t(n, e);
                    });
                }
            }, {
                key: "connect",
                value: function() {
                    var t = this;
                    this.reconnectCount++, this.changeStatus(this.reconnectCount < 1 ? STATUS.CONNECTING : STATUS.RECONNECTING), 
                    this.checkTimeoutMsg(), this.isWxApp ? this.socket = wx.connectSocket({
                        header: {
                            "content-type": "application/json"
                        },
                        protocols: [],
                        method: "POST",
                        tcpNoDelay: !1,
                        url: this.url,
                        timeout: 1e4
                    }) : this.socket = new WebSocket(this.url);
                    var e = this.socket;
                    e.binaryType = "arraybuffer";
                    var n = Date.now(), i = function(e) {
                        t.isWxApp && (t.ua = e && e.header && e.header["User-Agent"] || ""), cmtvLog({
                            type: "connect",
                            fields: t.baseOptions,
                            longFields: {
                                code: 0,
                                delayTime: t.delayTime,
                                reconnectCount: t.reconnectCount,
                                timeCost: Date.now() - n
                            }
                        }), t.sendSession();
                    }, r = function(e) {
                        try {
                            if (!e.data) return void cmtvLog({
                                type: "error",
                                fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                    event: JSON.stringify(e)
                                }),
                                longFields: {
                                    connectTime: Date.now() - n
                                }
                            });
                            var i = decodeContent(e.data);
                            t.responseTimeoutCount = 0, t.handleSystemMsg(i), t.handleResponse(i), t.callHooks("onMessage", i);
                        } catch (e) {
                            throw cmtvLog({
                                type: "error",
                                fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                    err: e.stack || "socket.onmessage error"
                                }),
                                longFields: {
                                    code: -1,
                                    connectTime: Date.now() - n,
                                    responseTimeoutCount: t.responseTimeoutCount
                                }
                            }), e;
                        }
                    }, o = function(e) {
                        t.status === STATUS.CONNECTING ? (cmtvLog({
                            type: "connect",
                            fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                err: JSON.stringify(e)
                            }),
                            longFields: {
                                code: -1,
                                delayTime: t.delayTime,
                                reconnectCount: t.reconnectCount,
                                timeCost: Date.now() - n,
                                responseTimeoutCount: t.responseTimeoutCount
                            }
                        }), t.close(), t.handleClose()) : (cmtvLog({
                            type: "error",
                            fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                err: JSON.stringify(e)
                            }),
                            longFields: {
                                connectTime: Date.now() - n,
                                responseTimeoutCount: t.responseTimeoutCount
                            }
                        }), t.close());
                    }, s = function(e) {
                        cmtvLog({
                            type: "close",
                            fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                err: JSON.stringify(e)
                            }),
                            longFields: {
                                connectTime: Date.now() - n,
                                responseTimeoutCount: t.responseTimeoutCount
                            }
                        }), t.handleClose();
                    };
                    this.isWxApp ? (e.onOpen(i), e.onMessage(r), e.onError(o), e.onClose(s)) : (e.onopen = i, 
                    e.onmessage = r, e.onerror = o, e.onclose = s);
                }
            }, {
                key: "handleSystemMsg",
                value: function(t) {
                    var e = this;
                    if (t.cmd === CMD.TITAN) {
                        var n = t.payload, i = n.command, r = n.extension;
                        if ("titan.ping" === i) {
                            var o = this.buildTitanData({
                                command: "titan.pong",
                                protocol: 1
                            });
                            this.send(o);
                        }
                        if (r && r.byteLength) {
                            var s = ExtensionMap.decode(r), a = s && s.info && s.info.reconnection;
                            if (a) {
                                var u = ReconnectInfo.decode(a), c = u.delaySecond, f = void 0 === c ? 0 : c, l = u.version;
                                this.version && this.version === l || (this.version = l, this.forceReconnectTimer || (this.forceReconnectTimer = setTimeout(function() {
                                    e.forceReconnectTimer = null, e.close();
                                }, 1e3 * f)));
                            }
                        }
                    }
                }
            }, {
                key: "handleClose",
                value: function() {
                    var t = this;
                    if (this.wxOnClosed = !0, !this.handleClosing) {
                        this.handleClosing = !0, this.responseTimeoutCount = 0, this.sessionRetryCount = 0, 
                        this.socket = null, this.sendMsgList = [];
                        var e = this.reconnectCount >= this.maxReconnectTimes, n = this.needRestart && !e;
                        if (n ? this.changeStatus(STATUS.WAIT_RECONNECT, this.closeErrorMsg) : this.changeStatus(STATUS.CLOSED, this.closeErrorMsg), 
                        n) {
                            var i = Math.floor(5 * Math.random()) + 2 * this.reconnectCount;
                            this.delayTime = i > 15 ? 15 : i, this.reconnectTimer = setTimeout(function() {
                                t.handleClosing = !1, t.connect();
                            }, 1e3 * this.delayTime);
                        }
                    }
                }
            }, {
                key: "handleResponse",
                value: function(t) {
                    for (var e = Object.assign({}, t), n = 0; n < this.sendMsgList.length; n++) {
                        var i = this.sendMsgList[n].msg;
                        if ("".concat(i.ctx) == "".concat(e.ctx)) {
                            if (this.sendMsgList.splice(n, 1), e.payload) {
                                var r = e.payload.errorCode;
                                try {
                                    i.complete && i.complete({
                                        statusCode: r,
                                        data: e.payload
                                    });
                                } catch (t) {
                                    i.complete && i.complete({
                                        errMsg: "socket response:fail - ".concat(t)
                                    });
                                }
                            } else i.complete && i.complete({
                                errMsg: "socket response:fail - no payload"
                            });
                            break;
                        }
                    }
                }
            }, {
                key: "send",
                value: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = arguments.length > 1 ? arguments[1] : void 0, n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3], r = t.ctx, o = {
                        ctx: r,
                        ts: Date.now(),
                        data: t,
                        complete: e,
                        isApi: i
                    };
                    if (this.socket) if (this.status === STATUS.OPEN || n) {
                        var s = encodeContent(t);
                        this.isWxApp ? this.socket.send({
                            data: s
                        }) : this.socket.send(s), e && this.sendMsgList.push({
                            msg: o
                        }), this.refreshHeartBeatTimer();
                    } else i ? e({
                        errCode: -5e4,
                        errMsg: "socket is closed"
                    }) : this.toSendMsgList.push({
                        msg: o
                    }); else this.toSendMsgList.push({
                        msg: o
                    }), this.cleanLists("socket request:fail without task");
                }
            }, {
                key: "buildTitanData",
                value: function(t) {
                    var e = t.body, n = t.sessionResumptionReq, i = t.command, r = t.protocol, o = t.MessageType, s = t.isApi, a = t.host;
                    this.ctx++;
                    var u = {
                        command: i,
                        protocol: r,
                        appId: this.appId,
                        compress: COMPRESS.UNGZIP,
                        host: a || this.host,
                        upstreamSeq: this.ctx
                    };
                    return n && (u.sessionResumptionReq = getProtoData(o, n)), e && (u.body = s ? encode(e) : getProtoData(o, e)), 
                    {
                        magic: MAGIC.TITAN,
                        cmd: CMD.TITAN,
                        ctx: this.ctx,
                        reserve: RESERVE,
                        payload: getProtoData(TitanUpstream, u)
                    };
                }
            }, {
                key: "refreshHeartBeatTimer",
                value: function() {
                    var t = this;
                    this.heartBeatTimer && clearTimeout(this.heartBeatTimer), this.heartBeatTimer = setTimeout(function() {
                        t.ctx++, t.send({
                            magic: MAGIC.HEARTBEAT,
                            cmd: CMD.HEARTBEAT,
                            ctx: t.ctx,
                            reserve: RESERVE,
                            payload: null
                        }, function() {});
                    }, HEARTBEAT_RATE);
                }
            }, {
                key: "sendSession",
                value: function() {
                    var t = {
                        requestType: 4,
                        protocolVersion: 1,
                        isPushConn: !0,
                        encryptedAppInfo: this.appInfo
                    }, e = this.buildTitanData({
                        sessionResumptionReq: t,
                        MessageType: TitanSessionRequest,
                        command: COMMAND$2.SESSION,
                        protocol: PROTOCOL$3.SESSION
                    });
                    this.sendSessionStart = Date.now(), this.send(e, this.handleSessionResponse.bind(this), !0);
                }
            }, {
                key: "updateInfo",
                value: function(t) {
                    var e = this;
                    if (t.uid && t.accesstoken) {
                        this.uid = t.uid || "", this.accesstoken = t.accesstoken || "", this.appOriginInfo.uid = this.uid + "", 
                        this.appOriginInfo.accesstoken = this.accesstoken, this.appInfo = getProtoData(AppInfo, this.appOriginInfo);
                        var n = this.buildTitanData({
                            MessageType: UpdateAppInfoRequest,
                            command: "titan.updateAppInfo",
                            protocol: 1,
                            body: {
                                appInfo: this.appInfo
                            }
                        });
                        this.send(n, function(t) {
                            e.handleUpdateRes(t);
                        });
                    }
                }
            }, {
                key: "handleUpdateRes",
                value: function(t) {
                    cmtvLog({
                        type: "updateInfo",
                        fields: _objectSpread2(_objectSpread2({}, this.baseOptions), {}, {
                            newId: this.uid,
                            newToken: this.accesstoken
                        }),
                        longFields: {
                            code: t.statusCode
                        }
                    }), 0 !== t.statusCode ? this.emit("error", {
                        error_code: 1002,
                        error_msg: "更新token信息失败"
                    }) : this.callHooks("onUpdateInfo");
                }
            }, {
                key: "handleSessionResponse",
                value: function(t) {
                    var e = this, n = t.statusCode;
                    if (cmtvLog({
                        type: "sendSession",
                        fields: this.baseOptions,
                        longFields: {
                            code: n,
                            retryCount: this.sessionRetryCount,
                            timeCost: Date.now() - this.sendSessionStart
                        }
                    }), 0 === n) this.sessionRetryCount = 0, this.reconnectCount = -1, this.changeStatus(STATUS.OPEN, _objectSpread2(_objectSpread2({}, this.appOriginInfo), {}, {
                        sessionData: t.data
                    })), this.toSendMsgList.forEach(function(t) {
                        var n = t.msg;
                        e.send(n.data, n.complete);
                    }), this.toSendMsgList = [], this.refreshHeartBeatTimer(), this.callHooks("onSessionSuccess"); else if (-1 !== TOKEN_ERROR_CODE.indexOf(n)) {
                        var i = {
                            error_code: 1001,
                            error_msg: "token过期或异常"
                        };
                        this.needAuth ? (this.closeErrorMsg = i, this.close(!0)) : (this.emit("error", i), 
                        this.appInfo = getProtoData(AppInfo, {
                            titanid: this.titanId,
                            ua: this.ua,
                            os: this.os,
                            uid: "",
                            repackage: !1,
                            accesstoken: "",
                            customPayload: this.customPayload
                        }), this.sendSession());
                    } else this.sessionRetryCount >= MAX_SESSION_RETRY_TIMES ? this.close() : this.retrySendSession();
                }
            }, {
                key: "retrySendSession",
                value: function() {
                    var t = this;
                    this.sessionRetryCount++;
                    var e = Math.floor(5 * Math.random() * 1e3);
                    this.retrySessionTimer = setTimeout(function() {
                        t.sendSession(), t.retrySessionTimer = null;
                    }, e);
                }
            }, {
                key: "checkTimeoutMsg",
                value: function() {
                    var t = this;
                    this.checkTimeoutMsgTimer = setInterval(function() {
                        t.cleanLists("socket request:fail timeout"), t.responseTimeoutCount >= t.maxTimeoutCombo && t.close();
                    }, 1e3);
                }
            }, {
                key: "close",
                value: function(t) {
                    var e = this;
                    this.status !== STATUS.CLOSED ? (this.needRestart = !t, this.retrySessionTimer && clearTimeout(this.retrySessionTimer), 
                    this.retrySessionTimer = null, this.heartBeatTimer && clearTimeout(this.heartBeatTimer), 
                    this.heartBeatTimer = null, this.checkTimeoutMsgTimer && clearInterval(this.checkTimeoutMsgTimer), 
                    this.checkTimeoutMsgTimer = null, this.socket && this.socket.close(), this.isWxApp && (this.wxOnClosed = !1, 
                    setTimeout(function() {
                        e.wxOnClosed || (cmtvLog({
                            type: "forceClose",
                            fields: e.baseOptions
                        }), e.handleClose());
                    }, 5e3))) : t && this.reconnectTimer && clearTimeout(this.reconnectTimer);
                }
            }, {
                key: "cleanLists",
                value: function(t) {
                    var e = this, n = function(n) {
                        for (var i = 0; i < n.length; i++) {
                            var r = n[i].msg, o = Math.abs(Date.now() - r.ts);
                            (r.isApi ? o > e.apiTimeout : o > TIMEOUT) && (n.splice(i, 1), r.complete && r.complete({
                                errMsg: t
                            }), e.responseTimeoutCount++, i--);
                        }
                    };
                    n(this.sendMsgList), n(this.toSendMsgList);
                }
            }, {
                key: "changeStatus",
                value: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    t !== this.status && (this.status = t, this.baseOptions.status = t, this.emit(t.toLowerCase(), e));
                }
            } ]), n;
        }(EventEmitter);
        Titan.hooks = {}, Titan.installedPlugins = [], Titan.usePlugin = function(t) {
            this.installedPlugins.indexOf(t) > -1 || (t && "function" == typeof t.install && t.install(this), 
            this.installedPlugins.push(t));
        };
        var BackOff = function() {
            function t(e) {
                _classCallCheck2(this, t), e = e || {}, this.ms = e.min || 100, this.max = e.max || 1e4, 
                this.factor = e.factor || 2, this.jitter = e.jitter > 0 && e.jitter <= 1 ? e.jitter : 0, 
                this.attempts = 0;
            }
            return _createClass2(t, [ {
                key: "duration",
                value: function() {
                    var t = this.ms * Math.pow(this.factor, this.attempts++);
                    if (this.jitter) {
                        var e = Math.random(), n = Math.floor(e * this.jitter * t);
                        t = 0 == (1 & Math.floor(10 * e)) ? t - n : t + n;
                    }
                    return (t = 0 | Math.min(t, this.max)) > 1 ? 1e3 * t : 1e3;
                }
            }, {
                key: "reset",
                value: function(t, e) {
                    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                    n && (this.attempts = 0), this.ms = t || this.ms, this.max = e || this.max;
                }
            }, {
                key: "setMin",
                value: function(t) {
                    this.ms = t;
                }
            }, {
                key: "setMax",
                value: function(t) {
                    this.max = t;
                }
            }, {
                key: "setJitter",
                value: function(t) {
                    this.jitter = t;
                }
            } ]), t;
        }(), COMMAND$1 = {
            BIND_GROUP: "titan.bdgrp",
            UNBIND_BIND_GROUP: "titan.unbdgrp",
            SYNC: "titan.mSync",
            SYNC_ACK: "titan.mSyncAck",
            LITE: "titan.mLite",
            LITE_ACK: "titan.mLiteAck",
            NOTIFY: "titan.mNotify",
            NOTIFY_ACK: "titan.mNotifyAck"
        }, PROTOCOL$2 = {
            SYNC: 1,
            SYNC_ACK: 1,
            TITAN: 1
        }, MAX_BIND_RETRY_NUM = 2, _pb$multicast$msg = pb.multicast.msg, MulticastSyncReq = _pb$multicast$msg.MulticastSyncReq, MulticastSyncResp = _pb$multicast$msg.MulticastSyncResp, MulticastSyncAck = _pb$multicast$msg.MulticastSyncAck, MulticastBindGroupReq = _pb$multicast$msg.MulticastBindGroupReq, MulticastLite = _pb$multicast$msg.MulticastLite, MulticastLiteAck = _pb$multicast$msg.MulticastLiteAck, MulticastNotify = _pb$multicast$msg.MulticastNotify, MulticastNotifyAck = _pb$multicast$msg.MulticastNotifyAck, MulticastUnBindGroupReq = _pb$multicast$msg.MulticastUnBindGroupReq, offsetList = {}, init$1 = function(t, e) {
            initOptions(t, e), initFunction(t);
        }, initOptions = function(t, e) {
            var n = t.groupList, i = offsetList[e.groupId] || 0;
            e.bizType && e.groupId && (n ? n.push({
                bizType: e.bizType,
                groupId: e.groupId,
                offset: i
            }) : t.groupList = [ {
                bizType: e.bizType,
                groupId: e.groupId,
                offset: i
            } ]), t.groupBinded = !1, t.disableMulticastSync = e.disableMulticastSync, t.bindRetryNum = 0, 
            t.unbindRetryNum = 0, t.backoff = new BackOff({
                min: 1,
                max: 16
            });
        }, initFunction = function(t) {
            t.unbindGroup = function(e) {
                unbindGroup(t, e);
            }, t.bindGroup = function(e) {
                initOptions(t, e), bindGroup(t);
            };
        }, unbindGroup = function t(e, n) {
            var i = e.groupList, r = i.findIndex(function(t) {
                return t.bizType === n.bizType && t.groupId === n.groupId;
            });
            if (-1 !== r) {
                var o = (i.splice(r, 1) || [])[0], s = e.buildTitanData({
                    body: {
                        groupList: [ {
                            bizType: n.bizType,
                            groupId: n.groupId
                        } ]
                    },
                    MessageType: MulticastUnBindGroupReq,
                    command: COMMAND$1.UNBIND_BIND_GROUP,
                    protocol: PROTOCOL$2.TITAN
                });
                e.send(s, function(r) {
                    cmtvLog({
                        type: "unbindGroup",
                        fields: _objectSpread2(_objectSpread2({}, e.baseOptions), {}, {
                            res: JSON.stringify(r)
                        }),
                        longFields: {
                            code: r.statusCode
                        }
                    }), 0 !== r.statusCode ? e.unbindRetryNum <= MAX_BIND_RETRY_NUM && (e.unbindRetryNum++, 
                    i.unshift(o), t(e, n)) : e.unbindRetryNum = 0;
                });
            } else cmtvLog({
                type: "log",
                fields: _objectSpread2(_objectSpread2({}, e.baseOptions), {}, {
                    logMsg: "unbind findIndex error"
                })
            });
        }, bindGroup = function t(e) {
            if (e.groupList && 0 !== e.groupList.length) {
                var n = e.buildTitanData({
                    body: {
                        groupList: e.groupList
                    },
                    MessageType: MulticastBindGroupReq,
                    command: COMMAND$1.BIND_GROUP,
                    protocol: PROTOCOL$2.TITAN
                });
                e.bindStart = Date.now();
                var i = e.groupList.map(function(t) {
                    return t.groupId;
                });
                e.send(n, function(n) {
                    0 === n.statusCode ? (e.sendTimer && (clearTimeout(e.sendTimer), e.sendTimer = null), 
                    cmtvLog({
                        type: "bindGroup",
                        fields: _objectSpread2(_objectSpread2({}, e.baseOptions), {}, {
                            groupList: JSON.stringify(i),
                            res: JSON.stringify(n)
                        }),
                        longFields: {
                            code: 0,
                            timeCost: Date.now() - e.bindStart,
                            bindRetryNum: e.bindRetryNum,
                            lastCode: e.lastCode
                        }
                    }), sendSync$1(e)) : e.bindRetryNum > MAX_BIND_RETRY_NUM ? cmtvLog({
                        type: "bindGroup",
                        fields: _objectSpread2(_objectSpread2({}, e.baseOptions), {}, {
                            groupList: JSON.stringify(i),
                            res: JSON.stringify(n)
                        }),
                        longFields: {
                            code: n.statusCode,
                            timeCost: Date.now() - e.bindStart,
                            bindRetryNum: e.bindRetryNum,
                            lastCode: e.lastCode
                        }
                    }) : (e.lastCode = n.statusCode, e.bindRetryNum++, t(e));
                });
            }
        }, getGroupInfo = function(t, e) {
            return t.groupList.find(function(t) {
                return t.groupId === e.groupId && t.bizType === e.bizType;
            });
        }, getMessageEventName = function(t, e) {
            return t ? "message_" + e.bizType + e.groupId : "message";
        }, getHistoryEventName = function(t, e) {
            return t ? "history_" + e.bizType + e.groupId : "history";
        }, onMessage$1 = function(t, e) {
            var n = tryDo(function() {
                return e.payload.body;
            });
            n && (e.payload.command === COMMAND$1.LITE ? handleLite(t, n) : e.payload.command === COMMAND$1.NOTIFY && handleNotify$1(t, n));
        }, handleLite = function(t, e) {
            var n = MulticastLite.decode(e), i = n.bizType, r = n.groupId, o = n.msgId, s = n.payload, a = n.needAck;
            if (t.emit(getMessageEventName(t.isSupportUnbind, n), parsePayload(s), r), a) {
                var u = t.buildTitanData({
                    body: {
                        bizType: i,
                        groupId: r,
                        msgId: o
                    },
                    MessageType: MulticastLiteAck,
                    command: COMMAND$1.LITE_ACK,
                    protocol: PROTOCOL$2.TITAN
                });
                t.send(u);
            }
        }, handleNotify$1 = function(t, e) {
            var n = MulticastNotify.decode(e), i = n.offset, r = n.ts, o = n.minInterval, s = n.maxInterval, a = n.payload, u = n.needAck, c = n.groupId, f = getGroupInfo(t, n);
            if (f) {
                if (f.offset && f.offset.add) {
                    var l = f.offset.add(1);
                    if (l.lessThan(i)) return void sendSync$1(t);
                    if (l.greaterThan(i)) return;
                }
                if (f.offset = i, offsetList[c] = i, resetSync(t, o, s), t.emit(getMessageEventName(t.isSupportUnbind, n), parsePayload(a), c), 
                u) {
                    var h = t.buildTitanData({
                        body: {
                            ackInfo: _objectSpread2(_objectSpread2({}, f), {}, {
                                ts: r
                            })
                        },
                        MessageType: MulticastNotifyAck,
                        command: COMMAND$1.NOTIFY_ACK,
                        protocol: PROTOCOL$2.TITAN
                    });
                    t.send(h);
                }
            }
        }, resetSync = function(t, e, n) {
            e && n && t.backoff.reset(e, n), t.sendTimer && (clearTimeout(t.sendTimer), t.sendTimer = null);
            var i = t.backoff.duration();
            t.sendTimer = setTimeout(function() {
                sendSync$1(t);
            }, i);
        }, sendSync$1 = function(t) {
            if (!t.disableMulticastSync && 0 !== t.groupList.length) {
                var e = t.buildTitanData({
                    body: {
                        syncList: t.groupList
                    },
                    MessageType: MulticastSyncReq,
                    command: COMMAND$1.SYNC,
                    protocol: PROTOCOL$2.TITAN
                });
                t.send(e, function(e) {
                    handleSyncRes$1(t, e);
                }), resetSync(t);
            }
        }, handleSyncRes$1 = function(t, e) {
            var n = tryDo(function() {
                return e.data.body;
            });
            if (n) {
                var i = MulticastSyncResp.decode(n);
                if (i) {
                    var r = i.minInterval, o = i.maxInterval, s = i.needAck, a = i.resList;
                    t.backoff.reset(r, o, !1), a.forEach(function(e) {
                        var n = e.payList || [];
                        if (n.length) {
                            var i = getGroupInfo(t, e);
                            n.sort(function(t, e) {
                                return tryDo(function() {
                                    return t.offset.greaterThan(e.offset) ? 1 : -1;
                                }, t.offset - e.offset);
                            });
                            var a = n[n.length - 1], u = a.offset, c = a.ts;
                            if (tryDo(function() {
                                return i.offset.greaterThanOrEqual(u);
                            }, i.offset >= u)) return;
                            if (0 === i.offset) {
                                var f = n.map(function(t) {
                                    return {
                                        ts: t.ts,
                                        data: parsePayload(t.payload)
                                    };
                                });
                                t.emit(getHistoryEventName(t.isSupportUnbind, e), f);
                            } else n.forEach(function(n) {
                                if (tryDo(function() {
                                    return n.offset.greaterThan(i.offset);
                                }, n.offset > i.offset)) {
                                    var r = parsePayload(n.payload);
                                    t.emit(getMessageEventName(t.isSupportUnbind, e), r);
                                }
                            });
                            i.offset = u, offsetList[i.groupId] = u, resetSync(t, r, o), s && sendSyncAck(t, _objectSpread2(_objectSpread2({}, i), {}, {
                                ts: c
                            }));
                        }
                    });
                }
            }
        }, sendSyncAck = function(t, e) {
            var n = t.buildTitanData({
                body: {
                    ackList: [ e ]
                },
                MessageType: MulticastSyncAck,
                command: COMMAND$1.SYNC_ACK,
                protocol: PROTOCOL$2.SYNC_ACK
            });
            t.send(n);
        }, Multicast = {
            install: function(t) {
                mixin(t.hooks, {
                    init: init$1,
                    onMessage: onMessage$1,
                    onSessionSuccess: bindGroup
                });
            }
        }, COMMAND = {
            NOTIFY_DATA_LITE: "titan.notifyDataLite",
            NOTIFY_DATA_LITE_ACK: "titan.notifyDataLite.ack"
        }, PROTOCOL$1 = {
            NOTIFY_DATA_LITE: 1,
            NOTIFY_DATA_LITE_ACK: 1
        }, _pb$unicast$msg = pb.unicast.msg, NotifyDataLite = _pb$unicast$msg.NotifyDataLite, NotifyDataLiteAck = _pb$unicast$msg.NotifyDataLiteAck, Notify = _pb$unicast$msg.Notify, NotifyData = _pb$unicast$msg.NotifyData, Sync = _pb$unicast$msg.Sync, SyncResponse = _pb$unicast$msg.SyncResponse, Ack = _pb$unicast$msg.Ack, TokenFail = _pb$unicast$msg.TokenFail, NotifyInner = _pb$unicast$msg.NotifyInner;
        function onMessage(t, e) {
            if (e.cmd === CMD.TITAN) {
                var n = e.payload, i = n.command, r = n.protocol, o = n.body;
                i === COMMAND.NOTIFY_DATA_LITE && r === PROTOCOL$1.NOTIFY_DATA_LITE ? handleUnicastResponse(t, NotifyDataLite.decode(o)) : "titan.notify" === i ? handleNotify(t, Notify.decode(o)) : "titan.notifyData" === i ? handleNotifyData(t, NotifyData.decode(o)) : "titan.notify.inner" === i && handleNotifyInner(t, NotifyInner.decode(o));
            }
        }
        function onUpdateInfo(t) {
            t.msgOffsetMap = {};
        }
        function onSessionSuccess(t) {
            t.msgOffsetMap = t.msgOffsetMap || {}, sendSync(t, {
                syncAll: !0
            });
        }
        function handleNotifyInner(t, e) {
            var n = e || {}, i = n.bizType, r = n.body;
            if (5001 === i) {
                var o = TokenFail.decode(r), s = o.errCode, a = o.accesstoken, u = parsePayload(a);
                cmtvLog({
                    type: "handleNotifyInner",
                    fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                        errCode: s,
                        errToken: u
                    })
                }), t.emit("error", {
                    error_code: 1001,
                    error_msg: 622 === s ? "token过期" : "多端登录toekn踢下线"
                });
            }
        }
        function handleNotify(t, e) {
            var n = e || {}, i = n.uidGroupList, r = void 0 === i ? [] : i, o = n.titanidGroupList, s = void 0 === o ? [] : o, a = {}, u = {};
            r.forEach(function(e) {
                a[e] = t.msgOffsetMap[e] || 0;
            }), s.forEach(function(e) {
                u[e] = t.msgOffsetMap[e] || 0;
            }), sendSync(t, {
                uidOffsetMap: a,
                titanidOffsetMap: u
            });
        }
        function sendSync(t, e) {
            var n = t.buildTitanData({
                body: e,
                MessageType: Sync,
                command: "titan.sync",
                protocol: 1
            });
            t.send(n, function(e) {
                handleSyncRes(t, e);
            });
        }
        function handleSyncRes(t, e) {
            if (e && e.data && e.data.body) {
                var n = SyncResponse.decode(e.data.body);
                if (n) {
                    var i = n.uidMap, r = n.titanidMap, o = n.needAck, s = {
                        uidMap: processNotifyMap(t, i, o),
                        titanidMap: processNotifyMap(t, r, o)
                    };
                    o && sendAck(t, s);
                }
            }
        }
        function processNotifyMap(t, e, n) {
            var i = {}, r = function(r) {
                var o = e[r] && e[r].msgList;
                if (o && o.length) {
                    var s = o[o.length - 1].offset, a = t.msgOffsetMap[r];
                    if (a) {
                        if (tryDo(function() {
                            return a.greaterThanOrEqual(s);
                        })) return cmtvLog({
                            type: "unicastOffsetError",
                            fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                msgOffsetMap: JSON.stringify(t.msgOffsetMap),
                                maxOffset: s
                            })
                        }), "continue";
                        tryDo(function() {
                            return a.add(1).lessThan(s.add(1));
                        }) && (console.log("error", JSON.stringify(t.msgOffsetMap), s), cmtvLog({
                            type: "unicastOffsetError",
                            fields: _objectSpread2(_objectSpread2({}, t.baseOptions), {}, {
                                msgOffsetMap: JSON.stringify(t.msgOffsetMap),
                                maxOffset: s
                            })
                        }));
                    }
                    t.msgOffsetMap[r] = s, n && (i[r] = {
                        clientOffset: s,
                        msgDetailMap: {}
                    }), o.forEach(function(e) {
                        var o = e || {}, s = o.isExpired, u = o.payload, c = o.bizType, f = o.subType, l = o.msgId, h = o.timestamp, d = o.offset;
                        if ((!a || !tryDo(function() {
                            return a.greaterThanOrEqual(d);
                        })) && u) {
                            var p = parsePayload(u);
                            n && (i[r].msgDetailMap[d] = {
                                bizType: c,
                                subType: f,
                                msgId: l,
                                timestamp: h
                            }), s || t.emit("message", {
                                actionId: c,
                                payload: p
                            });
                        }
                    });
                }
            };
            for (var o in e) r(o);
            return i;
        }
        function sendAck(t, e) {
            var n = t.buildTitanData({
                body: e,
                MessageType: Ack,
                command: "titan.ack",
                protocol: 1
            });
            t.send(n);
        }
        function handleNotifyData(t, e) {
            var n = e || {}, i = n.uidMap, r = void 0 === i ? {} : i, o = n.titanidMap, s = void 0 === o ? {} : o;
            sendAck(t, {
                uidMap: processNotifyMap(t, r, !0),
                titanidMap: processNotifyMap(t, s, !0)
            });
        }
        function handleUnicastResponse(t, e) {
            var n = e || {}, i = n.payload, r = n.bizType, o = n.msgId, s = n.additionalMap, a = parsePayload(i);
            t.emit("message", {
                actionId: r,
                payload: a
            }), sendUnicastAck(t, {
                msgId: o,
                bizType: r,
                additionalMap: s
            });
        }
        function sendUnicastAck(t, e) {
            var n = {
                msgId: e.msgId,
                bizType: e.bizType,
                additionalMap: e.additionalMap
            }, i = t.buildTitanData({
                body: n,
                MessageType: NotifyDataLiteAck,
                command: COMMAND.NOTIFY_DATA_LITE_ACK,
                protocol: PROTOCOL$1.NOTIFY_DATA_LITE_ACK
            });
            t.send(i);
        }
        var index$2 = {
            install: function(t) {
                mixin(t.hooks, {
                    onMessage: onMessage,
                    onSessionSuccess: onSessionSuccess,
                    onUpdateInfo: onUpdateInfo
                });
            }
        }, PROTOCOL = {
            API: 2
        };
        function init(t) {
            t.setHeaders = function(e) {
                t.commonHeaders = e;
            }, t.api = function(e) {
                var n = e.url, i = void 0 === n ? "" : n, r = e.method, o = void 0 === r ? "POST" : r, s = e.params, a = void 0 === s ? {} : s, u = e.headers, c = void 0 === u ? {} : u;
                return new Promise(function(e, n) {
                    if (!i) throw new Error("必须提供url");
                    var r = "GET" === (o = o.toUpperCase()), s = new UrlParse(i, r), u = s.hostname, f = s.pathname, l = s.query, h = f;
                    if (r) {
                        for (var d in l) l.hasOwnProperty(d) && (l[d] = encodeURIComponent(l[d]));
                        a = Object.assign(l, a), s.set("query", a), h += "?";
                        var p = [];
                        for (var m in a) a.hasOwnProperty(m) && p.push("".concat(m, "=").concat(a[m]));
                        h += p.join("&"), i = s.toString();
                    } else h += l;
                    var g = convertHeaders(_objectSpread2(_objectSpread2({}, t.commonHeaders), c)), y = [ "".concat(o, " ").concat(h, " HTTP/1.1"), "Host: ".concat(u), "Connection: keep-alive", "AccessToken: ".concat(t.accesstoken), "Content-Type: application/json;charset=UTF-8", "Accept: */*", "Accept-Encoding: *", "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,ja;q=0.7,pt;q=0.6" ].concat(g);
                    if (!t.isWxApp && hasWindow ? y = y.concat([ "Origin: ".concat(window.location.protocol, "//").concat(window.location.hostname), "User-Agent: ".concat(window.navigator.userAgent), "Referer: ".concat(window.location.href) ]) : t.isWxApp && t.ua && (y = y.concat([ "User-Agent: ".concat(t.ua) ])), 
                    y = y.concat("\r\n"), !r) {
                        var b = JSON.stringify(a);
                        y.splice(3, 0, "Content-Length: ".concat(encode(b).byteLength)), y.splice(-1, 1, "", b);
                    }
                    var v = y.join("\r\n"), _ = t.buildTitanData({
                        body: v,
                        command: f,
                        host: u,
                        protocol: PROTOCOL.API,
                        isApi: !0
                    });
                    t.send(_, function(t) {
                        handleApiResponse(t, e, n);
                    }, !1, !0);
                });
            };
        }
        function handleApiResponse(t, e, n) {
            if (t.errMsg) n({
                error_code: t.errCode,
                error_msg: t.errMsg
            }); else {
                var i = t.data.body, r = (i = (i = Array.from(i)).join(",").split(",13,10,13,10,"))[1], o = (r = r.split(",13,10,")).length;
                if (o > 1) {
                    o >= 4 && "13,10" === r[o - 1] && (r = r.slice(0, -2));
                    var s = [];
                    r.forEach(function(t, e) {
                        1 & e && s.push(t);
                    }), r = s.join(",");
                } else r = r[0];
                var a = byteToStr(r = r.split(","));
                e(jsonParse(a, a));
            }
        }
        var index$1 = {
            install: function(t) {
                mixin(t.hooks, {
                    init: init
                });
            }
        }, index = {
            instance: null,
            getInstance: function(t) {
                return this.instance || (Titan.usePlugin(Multicast), this.instance = new Titan(t)), 
                this.instance;
            }
        };
        exports.Api = index$1, exports.Multicast = Multicast, exports.Titan = Titan, exports.Unicast = index$2, 
        exports.default = index;
    }, function(t) {
        return __REQUIRE__({}[t], t);
    }), __REQUIRE__(1688393929381);
}();