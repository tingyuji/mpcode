var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), n = t(require("../../@babel/runtime/regenerator")), a = t(require("../../@babel/runtime/helpers/asyncToGenerator")), i = require("../../utils/util").forward, s = require("../../utils/event"), r = require("../../utils/wxRequest"), o = getApp();

Page({
    data: {
        theme: o.globalData.theme,
        screenHeight: o.globalData.screenHeight,
        screenWidth: o.globalData.screenWidth,
        statusBarHeight: o.globalData.statusBarHeight,
        capsuleBarHeight: o.globalData.capsuleBarHeight,
        isFullScreen: o.globalData.isFullScreen,
        isBiggerScreen: o.globalData.isBiggerScreen,
        scrollTop: 0,
        config: {},
        lesson: {},
        zbDate: "",
        busy: !1,
        finish: !1,
        comments: []
    },
    onShareAppMessage: function() {
        return i();
    },
    onShow: function() {
        var t = o.globalData.theme;
        this.setData({
            theme: t
        }), o.setTheme();
    },
    onLoad: function(t) {
        var e = t.id;
        this.init(e);
    },
    onUnload: function() {
        s.remove("getConfig", this);
    },
    onReachBottom: function() {
        this.fetchComments();
    },
    init: function() {
        var t = (0, a.default)(n.default.mark(function t(e) {
            var a, i, s, o;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.initConfig(), t.next = 3, r({
                        url: "/v1/lessons/".concat(e)
                    });

                  case 3:
                    return a = t.sent, this.setData({
                        lesson: a
                    }), t.next = 7, r({
                        url: "/v1/lessons/".concat(e, "/activity_stats")
                    });

                  case 7:
                    i = t.sent, s = i.comment_count, o = i.favourite_count, this.setData({
                        comment_count: s,
                        favourite_count: o
                    }), this.fetchComments();

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    initConfig: function() {
        var t = this;
        o.globalData.config ? this.setData({
            appConfig: o.globalData.config
        }) : s.on("getConfig", this, function() {
            t.setData({
                appConfig: o.globalData.config
            });
        });
    },
    refreshComments: function() {
        this.setData({
            comments: [],
            busy: !1,
            finish: !1
        }), this.fetchComments();
    },
    fetchComments: function() {
        var t = (0, a.default)(n.default.mark(function t() {
            var a, i, s;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!this.data.busy && !this.data.finish) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 2:
                    return this.setData({
                        busy: !0
                    }), a = this.data.lesson.id, i = this.data.comments, t.prev = 5, t.next = 8, r({
                        url: "/v1/lessons/".concat(a, "/comments"),
                        data: {
                            limit: 10,
                            offset: this.data.comments.length
                        }
                    });

                  case 8:
                    s = t.sent, this.setData({
                        comments: [].concat((0, e.default)(i), (0, e.default)(s)),
                        busy: !1,
                        finish: s.length < 10
                    }), t.next = 15;
                    break;

                  case 12:
                    t.prev = 12, t.t0 = t.catch(5), this.setData({
                        busy: !1
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 5, 12 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    goToWriteComment: function() {
        var t = this.data.lesson.id;
        wx.navigateTo({
            url: "/pages/comment-creator/comment-creator?id=".concat(t)
        });
    },
    goToComment: function(t) {
        var e = t.detail.id;
        wx.navigateTo({
            url: "/pages/comment/comment?comment_id=".concat(e)
        });
    },
    like: function() {
        var t = (0, a.default)(n.default.mark(function t(e) {
            var a, i, s, o;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.detail, i = a.comment_id, s = this.data.lesson.id, t.next = 5, r({
                        url: "/v1/lessons/".concat(s, "/comments/").concat(i, "/like"),
                        method: "PUT"
                    });

                  case 5:
                    o = Array.from(this.data.comments, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !0,
                            like_count: t.like_count + 1
                        });
                    }), this.setData({
                        comments: o
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    unlike: function() {
        var t = (0, a.default)(n.default.mark(function t(e) {
            var a, i, s, o;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.detail, i = a.comment_id, s = this.data.lesson.id, t.next = 5, r({
                        url: "/v1/lessons/".concat(s, "/comments/").concat(i, "/like"),
                        method: "DELETE"
                    });

                  case 5:
                    o = Array.from(this.data.comments, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !1,
                            like_count: t.like_count - 1
                        });
                    }), this.setData({
                        comments: o
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    gotoProfile: function(t) {
        var e = t.detail;
        wx.navigateTo({
            url: "/pages/profile/profile?id=".concat(e.id)
        });
    },
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});