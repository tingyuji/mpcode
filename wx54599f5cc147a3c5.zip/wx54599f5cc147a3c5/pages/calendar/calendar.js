var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), a = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator")), r = getApp(), s = require("../../utils/wxRequest"), o = require("../../utils/moment/index.js"), i = require("../../utils/util"), h = i.forward, c = i.parseDateCode, u = i.convertZhNumber, l = [ "一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月" ];

Page({
    data: {
        theme: r.globalData.theme,
        screenHeight: r.globalData.screenHeight,
        screenWidth: r.globalData.screenWidth,
        statusBarHeight: r.globalData.statusBarHeight,
        capsuleBarHeight: r.globalData.capsuleBarHeight,
        isFullScreen: r.globalData.isFullScreen,
        lessons: {},
        monthsInYear: [],
        dates: {},
        current: 0,
        containerOffsets: []
    },
    onShareAppMessage: function() {
        return h();
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, a = this.data.containerOffsets, n = a[a.length - 1], r = a.findIndex(function(t) {
            return t > e;
        });
        if (r > 0) {
            var s = r - 1;
            this.data.current !== s && this.changeCurrentMonth(s);
        } else e >= n ? this.changeCurrentMonth(a.length - 1) : this.data.current && this.changeCurrentMonth(0);
    },
    changeCurrentMonth: function(t) {
        this.setData({
            current: t
        });
        var e = this.data.monthsInYear, a = e.length - 1;
        this.getLessonsInMonth(e[t].month), 0 !== t && this.getLessonsInMonth(e[t - 1].month), 
        t !== a && this.getLessonsInMonth(e[t + 1].month);
    },
    getLessonsInMonth: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, r, o, i, h;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (this.data.lessons[e]) {
                        t.next = 10;
                        break;
                    }
                    return n = this.data.dates[e], r = n[0].date, o = n[n.length - 1].date, t.next = 6, 
                    s({
                        url: "/v1/lessons",
                        data: {
                            from: o,
                            to: r
                        }
                    });

                  case 6:
                    i = t.sent, h = Object.assign({}, this.data.lessons), i.forEach(function(t) {
                        var e = c(t.date_by_day);
                        h[e] = t;
                    }), this.setData({
                        lessons: h
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    addNewOffset: function(t) {
        var a = this.data, n = a.containerOffsets, r = a.statusBarHeight, s = a.capsuleBarHeight, o = [].concat((0, 
        e.default)(n), [ t - (r + s) ]);
        o.sort(function(t, e) {
            return t - e;
        }), this.setData({
            containerOffsets: o
        });
    },
    scrollToMonth: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            scrollTop: this.data.containerOffsets[e] + 1
        });
    },
    onTapTopBar: function() {
        this.setData({
            scrollTop: 0
        });
    },
    onChangeYear: function(t) {
        var e = t.detail.value;
        this.init(e);
    },
    init: function(t) {
        var e = this, a = u("".concat(t));
        this.setData({
            year: t,
            zhYear: a,
            scrollTop: 0,
            dates: {},
            monthsInYear: [],
            containerOffsets: []
        });
        var n = function(t) {
            var e = [];
            return Array(12).fill(1).forEach(function(a, n) {
                var r = o({
                    year: t,
                    month: 11 - n
                });
                r.isBefore() && e.push({
                    zh_text_by_month: l[r.get("month")],
                    text_by_month: r.format("M月"),
                    month: r.format("YYYY-MM")
                });
            }), e;
        }("".concat(t)), r = {};
        n.forEach(function(t) {
            var e, a, n;
            r[t.month] = (e = t.month, a = [], n = o(e).daysInMonth(), Array(n).fill(1).forEach(function(t, r) {
                var s = o(e).set({
                    date: n - r
                });
                s.isBefore() && a.push({
                    day_by_date: s.get("date"),
                    date: s.format("YYYY-MM-DD")
                });
            }), a);
        }), this.setData({
            monthsInYear: n,
            dates: r
        }), this.changeCurrentMonth(0), setTimeout(function() {
            n.forEach(function(t) {
                var a = wx.createSelectorQuery();
                a.select("#month-".concat(t.month)).boundingClientRect(), a.selectViewport().scrollOffset(), 
                a.exec(function(t) {
                    e.addNewOffset(t[0].top);
                });
            });
        }, 300);
    },
    onShow: function() {
        var t = r.globalData.theme;
        this.setData({
            theme: t
        }), r.setTheme();
    },
    onLoad: function() {
        r.loadFont(), this.init(o().format("YYYY"));
    }
});