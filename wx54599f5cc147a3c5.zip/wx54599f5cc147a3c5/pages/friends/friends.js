var e = require("../../utils/layout_calculator"), a = require("../../utils/util").forward, t = getApp();

Page({
    data: {
        theme: t.globalData.theme,
        screenHeight: t.globalData.screenHeight,
        screenWidth: t.globalData.screenWidth,
        statusBarHeight: t.globalData.statusBarHeight,
        capsuleBarHeight: t.globalData.capsuleBarHeight,
        isFullScreen: t.globalData.isFullScreen,
        isBiggerScreen: t.globalData.isBiggerScreen,
        layout: e()
    },
    onShareAppMessage: function() {
        return a();
    },
    onShow: function() {
        var e = t.globalData.theme;
        this.setData({
            theme: e
        }), t.setTheme();
    }
});