var e = getApp();

Page({
    data: {
        theme: e.globalData.theme,
        screenHeight: e.globalData.screenHeight,
        screenWidth: e.globalData.screenWidth,
        statusBarHeight: e.globalData.statusBarHeight,
        capsuleBarHeight: e.globalData.capsuleBarHeight,
        isFullScreen: e.globalData.isFullScreen,
        isBiggerScreen: e.globalData.isBiggerScreen
    },
    onShow: function() {
        var a = e.globalData.theme;
        this.setData({
            theme: a
        }), e.setTheme();
    },
    onLoad: function() {
        this.init();
    },
    init: function(a) {
        e.setTheme();
    }
});