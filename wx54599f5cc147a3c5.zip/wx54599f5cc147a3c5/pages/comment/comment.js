var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), a = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator")), s = require("../../utils/wxRequest"), i = require("../../utils/moment/index.js"), r = require("../../utils/event"), o = require("../../utils/util"), c = o.forward, u = o.parseDateCode, l = getApp();

Page({
    data: {
        theme: l.globalData.theme,
        screenHeight: l.globalData.screenHeight,
        screenWidth: l.globalData.screenWidth,
        statusBarHeight: l.globalData.statusBarHeight,
        capsuleBarHeight: l.globalData.capsuleBarHeight,
        isFullScreen: l.globalData.isFullScreen,
        isBiggerScreen: l.globalData.isBiggerScreen,
        scrollTop: 0,
        config: {},
        showWordpad: !1,
        replyTarget: null,
        lesson: {},
        comment: {},
        busy: !1,
        finish: !1,
        replies: []
    },
    onShareAppMessage: function() {
        return c();
    },
    onShow: function() {
        var t = l.globalData.theme;
        this.setData({
            theme: t
        }), l.setTheme();
    },
    onLoad: function(t) {
        var e = t.comment_id, a = t.source;
        this.init(e, a);
    },
    onUnload: function() {
        r.remove("getConfig", this);
    },
    onReachBottom: function() {
        this.fetchReplies();
    },
    init: function() {
        var t = (0, n.default)(a.default.mark(function t(e, n) {
            var r, o, c, l;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.initConfig(), t.prev = 1, t.next = 4, s({
                        url: "/v1/comments/".concat(e)
                    });

                  case 4:
                    if (r = t.sent, this.setData({
                        comment: r
                    }), !n) {
                        t.next = 14;
                        break;
                    }
                    return t.next = 9, s({
                        url: "/v1/lessons/".concat(r.lesson_id)
                    });

                  case 9:
                    o = t.sent, c = u(o.date_by_day), l = i(c), o = Object.assign({}, o, {
                        month: l.format("M"),
                        date: l.format("D")
                    }), this.setData({
                        lesson: o
                    });

                  case 14:
                    t.next = 19;
                    break;

                  case 16:
                    t.prev = 16, t.t0 = t.catch(1), this.setData({
                        comment: {
                            comment_id: e
                        }
                    });

                  case 19:
                    this.fetchReplies();

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 1, 16 ] ]);
        }));
        return function(e, a) {
            return t.apply(this, arguments);
        };
    }(),
    initConfig: function() {
        var t = this;
        l.globalData.config ? this.setData({
            appConfig: l.globalData.config
        }) : r.on("getConfig", this, function() {
            t.setData({
                appConfig: l.globalData.config
            });
        });
    },
    refreshReplies: function() {
        this.setData({
            replies: [],
            busy: !1,
            finish: !1
        }), this.fetchReplies();
    },
    fetchReplies: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            var n, i, r;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!this.data.busy && !this.data.finish) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 2:
                    return this.setData({
                        busy: !0
                    }), n = this.data.comment.id, i = this.data.replies, t.prev = 5, t.next = 8, s({
                        url: "/v1/comments/".concat(n, "/comments"),
                        data: {
                            limit: 10,
                            offset: this.data.replies.length
                        }
                    });

                  case 8:
                    r = t.sent, this.setData({
                        replies: [].concat((0, e.default)(i), (0, e.default)(r)),
                        busy: !1,
                        finish: r.length < 10
                    }), t.next = 15;
                    break;

                  case 12:
                    t.prev = 12, t.t0 = t.catch(5), this.setData({
                        busy: !1
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 5, 12 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    replySomeone: function(t) {
        var e = t.detail, a = e.user, n = e.id;
        this.setData({
            replyTarget: {
                user: a,
                comment_id: n
            } || null,
            showWordpad: !0
        });
    },
    showWordpad: function() {
        this.data.appConfig.btnOn && this.setData({
            replyTarget: null,
            showWordpad: !0
        });
    },
    hideWordpad: function() {
        this.setData({
            showWordpad: !1
        });
    },
    submitReview: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i, r, o, c;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, i = n.content, r = this.data.comment, o = r.id, t.next = 6, 
                    s({
                        url: "/v1/comments/".concat(o, "/comments"),
                        method: "POST",
                        data: {
                            content: i
                        }
                    });

                  case 6:
                    this.refreshReplies(), c = Object.assign({}, r, {
                        sub_comment_count: r.sub_comment_count + 1
                    }), this.setData({
                        comment: c
                    });

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    submitReply: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i, r, o, c;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, i = n.content, r = n.comment_id, t.next = 4, s({
                        url: "/v1/comments/".concat(r, "/replies"),
                        method: "POST",
                        data: {
                            content: i
                        }
                    });

                  case 4:
                    this.refreshReplies(), o = this.data.comment, c = Object.assign({}, o, {
                        sub_comment_count: o.sub_comment_count + 1
                    }), this.setData({
                        comment: c
                    });

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    like: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i, r, o, c;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, i = n.comment_id, r = n.lesson_id, t.next = 4, s({
                        url: "/v1/lessons/".concat(r, "/comments/").concat(i, "/like"),
                        method: "PUT"
                    });

                  case 4:
                    i === this.data.comment.id ? (o = this.data.comment, this.setData({
                        comment: Object.assign({}, o, {
                            my_like: !0,
                            like_count: o.like_count + 1
                        })
                    })) : (c = Array.from(this.data.replies, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !0,
                            like_count: t.like_count + 1
                        });
                    }), this.setData({
                        replies: c
                    }));

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    unlike: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i, r, o, c;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, i = n.comment_id, r = n.lesson_id, t.next = 4, s({
                        url: "/v1/lessons/".concat(r, "/comments/").concat(i, "/like"),
                        method: "DELETE"
                    });

                  case 4:
                    i === this.data.comment.id ? (o = this.data.comment, this.setData({
                        comment: Object.assign({}, o, {
                            my_like: !1,
                            like_count: o.like_count - 1
                        })
                    })) : (c = Array.from(this.data.replies, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !1,
                            like_count: t.like_count - 1
                        });
                    }), this.setData({
                        replies: c
                    }));

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    gotoProfile: function(t) {
        var e = t.detail;
        wx.navigateTo({
            url: "/pages/profile/profile?id=".concat(e.id)
        });
    },
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});