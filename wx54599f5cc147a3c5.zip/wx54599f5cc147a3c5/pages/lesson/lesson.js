var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), n = t(require("../../@babel/runtime/regenerator")), a = t(require("../../@babel/runtime/helpers/asyncToGenerator")), s = getApp(), r = require("../../utils/event"), i = require("../../utils/wxRequest"), o = require("../../utils/moment/index.js"), u = require("../../utils/lunar"), c = require("../../utils/util"), d = c.forward, l = c.parseDateCode, h = c.convertZhDate, f = c.formatNumber, m = function(t) {
    var e = {};
    return t.forEach(function(t) {
        e[t.id] = t, e[t.id].month = "".concat(t.date_by_day).slice(4, 6), e[t.id].date = "".concat(t.date_by_day).slice(6, 8), 
        e[t.id].zbDate = h(l(t.date_by_day)), e[t.id].titleFadeInProgress = t.titleFadeInProgress || 0, 
        e[t.id].comment_count = t.comment_count || 0, e[t.id].favourite_count = t.favourite_count || 0, 
        e[t.id].isLike = s.globalData.favouriteLessons.includes(t.id);
    }), Object.keys(e).map(function(t) {
        return e[t];
    });
};

Page({
    data: {
        theme: s.globalData.theme,
        screenHeight: s.globalData.screenHeight,
        screenWidth: s.globalData.screenWidth,
        statusBarHeight: s.globalData.statusBarHeight,
        capsuleBarHeight: s.globalData.capsuleBarHeight,
        isFullScreen: s.globalData.isFullScreen,
        scrollTop: 0,
        firstLessonId: "",
        firstDate: "",
        lessons: [],
        painterWidth: 0,
        painterHeight: 0,
        drawData: [],
        writePhotosAlbum: !1,
        currentPages: [],
        shareActionsheetVisible: !1,
        loading: !0,
        dates: [],
        nextLessonComingRemain: "",
        nextLessonMonth: o().format("MM"),
        nextLessonDate: o().format("DD"),
        currentDate: "",
        currentWeekday: "",
        currentLdate: "",
        currentItemId: "tomorrow",
        currentLesson: {},
        duration: 0,
        current: 0,
        marking: !1
    },
    onShareAppMessage: function() {
        this.hideShareActionsheet();
        var t = this.data.currentItemId;
        return "tomorrow" === t ? d() : d(t);
    },
    init: function() {
        var t = (0, a.default)(n.default.mark(function t(e, a) {
            var s, r;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, this.setCurrentLession(e, a);

                  case 2:
                    s = t.sent, r = l(s.date_by_day), this.setDateDisplay(r), this.countDown(), this.changeLessons(m([ s ])), 
                    this.loadMore(), this.getCount();

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e, n) {
            return t.apply(this, arguments);
        };
    }(),
    setCurrentLession: function() {
        var t = (0, a.default)(n.default.mark(function t(e, a) {
            var s, r, o, u, c;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s = getCurrentPages(), t.next = 3, i({
                        url: "/v1/lessons/".concat(e || a)
                    });

                  case 3:
                    return r = t.sent, o = {
                        currentPages: s,
                        currentLesson: r,
                        currentItemId: r.id
                    }, this.data.lessons.length && (u = m([ r ])[0], c = this.data.lessons.findIndex(function(t) {
                        return t.id === r.id;
                    }), Object.assign(o, {
                        ["lessons[".concat(c, "]")]: u
                    })), this.setData(o), t.abrupt("return", r);

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e, n) {
            return t.apply(this, arguments);
        };
    }(),
    getCount: function() {
        var t = (0, a.default)(n.default.mark(function t() {
            var e, a, s, r, o;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ("tomorrow" === (e = this.data.currentItemId)) {
                        t.next = 9;
                        break;
                    }
                    return t.next = 4, i({
                        url: "/v1/lessons/".concat(e, "/activity_stats")
                    });

                  case 4:
                    a = t.sent, s = a.comment_count, r = a.favourite_count, o = this.data.lessons.findIndex(function(t) {
                        return t.id === e;
                    }), this.setData({
                        ["lessons[".concat(o, "].comment_count")]: s,
                        ["lessons[".concat(o, "].favourite_count")]: r
                    });

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    pushLessons: function(t) {
        var n = [].concat((0, e.default)(this.data.lessons), (0, e.default)(t));
        (n = m(n)).sort(function(t, e) {
            return t.date_by_day - e.date_by_day;
        }), this.changeLessons(n);
    },
    unshiftLessons: function(t) {
        var n = [].concat((0, e.default)(t), (0, e.default)(this.data.lessons));
        (n = m(n)).sort(function(t, e) {
            return t.date_by_day - e.date_by_day;
        }), this.changeLessons(n);
    },
    changeLessons: function(t) {
        var e = this, n = this.data.lessons;
        if (n.length !== t.length) {
            var a = {
                lessons: t,
                dates: this.makeDates(t)
            }, s = t[t.length - 1];
            if (n.length) {
                var r = t.findIndex(function(t) {
                    return t.id === e.data.currentItemId;
                });
                a.current = r;
            } else a.currentItemId = s.id, a.duration = 300;
            this.setData(a), this.data.loading && setTimeout(function() {
                e.setData({
                    loading: !1
                });
            }, 300);
        }
    },
    countDown: function() {
        var t = this, e = this.data.lessons, n = o();
        if (e.length) {
            var a = e[e.length - 1], s = l(a.date_by_day), r = o(s).add(1, "days"), i = r.diff(n, "seconds");
            i = i < 0 ? 0 : i;
            var u = f(parseInt(i / 3600)), c = f(parseInt(i / 60 % 60)), d = f(parseInt(i % 60)), h = o(i).format("".concat(u, " 时 ").concat(c, " 分 ").concat(d, " 秒"));
            this.setData({
                nextLessonComingRemain: h,
                nextLessonMonth: r.format("MM"),
                nextLessonDate: r.format("DD")
            }), i || this.loadNewOne();
        }
        clearTimeout(this.nextLessonComing), this.nextLessonComing = setTimeout(function() {
            t.nextLessonComing = null, t.countDown();
        }, 1e3);
    },
    loadNewOne: function() {
        var t = (0, a.default)(n.default.mark(function t() {
            var e, a, s, r;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = this.data.lessons, a = e[e.length - 1].date_by_day, s = o(l(a)).add(1, "days").format("YYYY-MM-DD"), 
                    t.next = 5, i({
                        url: "/v1/lessons/".concat(s)
                    });

                  case 5:
                    r = t.sent, "tomorrow" === this.data.currentItemId && this.setData({
                        loading: !0,
                        currentItemId: r.id
                    }), this.pushLessons([ r ]);

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    makeDates: function(t) {
        var e = t.map(function(t) {
            var e = l(t.date_by_day);
            return {
                date: e,
                day: e.split("-")[2]
            };
        });
        if (e.length) {
            var n = e[e.length - 1].date;
            n = o(n).add(1, "days").format("YYYY-MM-DD"), e.push({
                date: n,
                day: n.split("-")[2]
            });
        }
        return e;
    },
    setDateDisplay: function(t) {
        var e = u(t);
        this.setData({
            currentWeekday: "周".concat(e.cnDay),
            currentLdate: "".concat(e.lMonth, "月").concat(e.lDate),
            currentDate: t
        });
    },
    change: function(t) {
        var e = t.detail, n = e.currentItemId, a = e.current, s = this.data.lessons, r = s.find(function(t) {
            return t.id === n;
        }), i = {
            current: a,
            currentItemId: n,
            currentLesson: r
        };
        if ("tomorrow" !== n) {
            var u = l(r.date_by_day);
            this.setDateDisplay(u);
        } else {
            var c = s[s.length - 1], d = l(c.date_by_day);
            d = o(d).add(1, "days").format("YYYY-MM-DD"), this.setDateDisplay(d);
        }
        this.setData(i), this.getCount();
    },
    loadMore: function() {
        var t = (0, a.default)(n.default.mark(function t() {
            var a, s, r, u, c, d, h, f, m, g, p, v, y, D, w, x;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a = this.data, s = a.lessons, "tomorrow" != (r = a.currentItemId)) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 3:
                    if (u = s.find(function(t) {
                        return t.id === r;
                    }), c = l(u.date_by_day), d = o(c).subtract(5, "days"), h = o(l(s[0].date_by_day)).subtract(1, "days"), 
                    f = s.length >= 2 ? o(l(s[s.length - 2].date_by_day)).add(1, "days") : o(l(s[s.length - 1].date_by_day)).add(1, "days"), 
                    (m = o(c).add(5, "days")).isAfter() && (m = o()), g = [], !d.isBefore(h)) {
                        t.next = 18;
                        break;
                    }
                    return p = d.format("YYYY-MM-DD"), v = h.format("YYYY-MM-DD"), t.next = 16, i({
                        url: "/v1/lessons",
                        data: {
                            from: p,
                            to: v
                        }
                    });

                  case 16:
                    y = t.sent, g = [].concat((0, e.default)(g), (0, e.default)(y));

                  case 18:
                    if (!f.isBefore(m)) {
                        t.next = 25;
                        break;
                    }
                    return D = f.format("YYYY-MM-DD"), w = m.format("YYYY-MM-DD"), t.next = 23, i({
                        url: "/v1/lessons",
                        data: {
                            from: D,
                            to: w
                        }
                    });

                  case 23:
                    x = t.sent, g = [].concat((0, e.default)(g), (0, e.default)(x));

                  case 25:
                    this.unshiftLessons(g);

                  case 26:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    getMarkContent: function(t) {
        var e = this.data.lessons.find(function(e) {
            return e.id === t;
        }), n = "", a = null;
        return e.sections.forEach(function(t, e) {
            var s = t.sentences, r = null, i = !1;
            s.forEach(function(t, s) {
                t.mark && (i || (i = !0, n.length && (n += null !== a && e - a >= 2 ? "\n……\n" : "\n\n")), 
                null !== r && s - r >= 2 ? (n = n.trim(), n += "\n……\n") : null === r && n.length && s >= 1 && ("……" !== (n = n.trim()).trim().slice(n.length - 2, n.length) ? n += "\n……\n" : n += "\n"), 
                n += t.content, r = s, a = e);
            }), n = n.trim();
        }), n = n.trim();
    },
    getMarkContent: function(t) {
        var e = this.data.lessons.find(function(e) {
            return e.id === t;
        }), n = null;
        e.sections.forEach(function(t, e) {
            t.sentences.forEach(function(t, a) {
                n = "".concat(e, "-").concat(a), t.mark && n;
            });
        });
    },
    onShareMark: function() {
        var t = this.data.currentItemId;
        this.getMarkContent(t);
    },
    onMark: function(t) {
        var e = t.currentTarget.dataset, n = e.sectionIndex, a = e.sentenceIndex, s = e.lessonId, r = this.data.lessons.findIndex(function(t) {
            return t.id === s;
        }), i = this.data.lessons[r];
        this.setData({
            ["lessons[".concat(r, "].sections[").concat(n, "].sentences[").concat(a, "].mark")]: !i.sections[n].sentences[a].mark
        });
    },
    displayMarkShare: function() {
        var t = this.data.currentItemId, e = this.data.lessons.find(function(e) {
            return e.id === t;
        }).sections.find(function(t) {
            return t.sentences.find(function(t) {
                return t.mark;
            });
        });
        this.setData({
            markShareDisplay: e
        });
    },
    favourite: function() {
        var t = (0, a.default)(n.default.mark(function t(a) {
            var r, o, u, c, d, l, h, f;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = a.detail, o = s.globalData.favouriteLessons, u = r.lesson_id, c = (0, e.default)(this.data.lessons), 
                    d = c.findIndex(function(t) {
                        return t.id === u;
                    }), !(l = c[d]).isLike) {
                        t.next = 12;
                        break;
                    }
                    return t.next = 9, i({
                        url: "/v1/lessons/".concat(u, "/like"),
                        method: "DELETE"
                    });

                  case 9:
                    o = o.filter(function(t) {
                        return t !== u;
                    }), t.next = 15;
                    break;

                  case 12:
                    return t.next = 14, i({
                        url: "/v1/lessons/".concat(u, "/like"),
                        method: "PUT"
                    });

                  case 14:
                    o.push(u);

                  case 15:
                    s.globalData.favouriteLessons = o, h = !l.isLike, f = l.favourite_count, h ? f++ : f--, 
                    this.setData({
                        ["lessons[".concat(d, "].favourite_count")]: f,
                        ["lessons[".concat(d, "].isLike")]: h
                    });

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    goToComments: function(t) {
        var e = t.currentTarget.dataset.lessonId;
        wx.navigateTo({
            url: "/pages/comments/comments?id=".concat(e)
        });
    },
    onTapTopBar: function() {
        this.setData({
            scrollTop: 0
        });
    },
    showShareActionsheet: function() {
        this.setData({
            shareActionsheetVisible: !0
        });
    },
    hideShareActionsheet: function() {
        this.setData({
            shareActionsheetVisible: !1
        });
    },
    chooseShareMethod: function(t) {
        switch (t.detail.method) {
          case "moment":
            this.genMomentPic();
        }
    },
    changeTheme: function() {
        var t = "LIGHT" === s.globalData.theme ? "DARK" : "LIGHT";
        this.setData({
            theme: t
        }), s.globalData.theme = t, s.setTheme(), wx.setStorage({
            key: "theme",
            data: t
        });
    },
    genMomentPic: function() {
        var t = (0, a.default)(n.default.mark(function t() {
            var e, a, s, r = this;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    wx.showLoading({
                        mask: !0,
                        title: "正在生成海报"
                    }), e = this.data.currentItemId, a = this.data.lessons.find(function(t) {
                        return t.id === e;
                    }), s = "https://pics.tide.moreless.io/rike/article_".concat(e, ".png"), wx.request({
                        url: "".concat(s, "?imageInfo"),
                        success: function(t) {
                            var e = t.data, n = e.width, i = e.height;
                            r.draw({
                                url: s,
                                width: n,
                                height: i,
                                lesson: a
                            });
                        }
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    onDraw: function(t) {
        var e = t.detail.tempFilePath;
        this.save(e);
    },
    checkAuth: function(t) {
        wx.getSetting({
            fail: function(e) {
                t(!1);
            },
            success: function(e) {
                e.authSetting["scope.writePhotosAlbum"] || void 0 === e.authSetting["scope.writePhotosAlbum"] ? t(!0) : t(!1);
            }
        });
    },
    save: function(t) {
        var e = this;
        wx.saveImageToPhotosAlbum({
            filePath: t,
            fail: function(t) {
                wx.hideLoading(), "saveImageToPhotosAlbum:fail auth deny" === t.errMsg ? (e.setData({
                    authed: !1
                }), wx.showModal({
                    title: "未能保存",
                    content: "需要打开保存到相册的权限",
                    confirmText: "确定",
                    showCancel: !1
                })) : wx.showModal({
                    title: "未能保存",
                    content: "保存到系统相册时失败",
                    confirmText: "确定",
                    showCancel: !1
                });
            },
            success: function() {
                wx.hideLoading(), wx.showModal({
                    title: "你的海报已存放到系统相册",
                    content: "快去分享给朋友们，让他们也来岛读吧～",
                    confirmText: "我知道了",
                    showCancel: !1
                });
            }
        });
    },
    draw: function() {
        var t = (0, a.default)(n.default.mark(function t(e) {
            var a, s, r, o, u, c, d;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.url, s = e.width, r = e.height, o = e.lesson, console.log(r), u = [], 
                    t.next = 5, i({
                        url: "/v1/lessons/".concat(o.id, "/wechatmp_qrcode")
                    });

                  case 5:
                    c = t.sent, d = (d = c.url).replace("http://", "https://"), u.push({
                        type: "image",
                        url: a,
                        width: s,
                        height: r,
                        dx: 0,
                        dy: 0
                    }), u.push({
                        type: "text",
                        font: "arial",
                        color: "#000000",
                        alpha: .85,
                        size: "26px",
                        weight: "bold",
                        align: "left",
                        italic: !1,
                        dx: 80,
                        dy: 68,
                        maxWidth: 0,
                        content: "岛读"
                    }), u.push({
                        type: "text",
                        font: "arial",
                        color: "#000000",
                        alpha: .35,
                        size: "26px",
                        weight: "bold",
                        align: "left",
                        italic: !1,
                        dx: 80,
                        dy: 122,
                        maxWidth: 0,
                        content: "他们在岛屿阅读"
                    }), u.push({
                        type: "image",
                        url: d,
                        width: 96,
                        height: 96,
                        dx: 544,
                        dy: 64
                    }), r >= 4906 ? u.push({
                        type: "image",
                        url: d,
                        width: 176,
                        height: 176,
                        dx: 272,
                        dy: r - 560
                    }) : u.push({
                        type: "image",
                        url: d,
                        width: 128,
                        height: 128,
                        dx: 512,
                        dy: r - 328
                    }), this.setData({
                        painterWidth: s,
                        painterHeight: r,
                        drawData: u
                    });

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    onScroll: function(t) {
        var n = t.detail, a = t.currentTarget.dataset.lessonId, s = n.scrollTop, r = (0, 
        e.default)(this.data.lessons).findIndex(function(t) {
            return t.id === a;
        }), i = 0;
        (i = s / 150) <= 0 ? i = 0 : i > 1 && (i = 1), this.setData({
            ["lessons[".concat(r, "].titleFadeInProgress")]: i
        });
    },
    onShow: function() {
        var t = s.globalData.theme;
        this.setData({
            theme: t
        }), s.setTheme(), this.data.currentLesson.id && this.getCount();
    },
    onLoad: function(t) {
        var e = t.id, n = t.date;
        s.loadFont(), this.init(e, n), setTimeout(function() {
            r.emit("showCollectionGuide");
        }, 2e3);
    },
    selectEnd: function(t) {
        console.log(t);
    }
});