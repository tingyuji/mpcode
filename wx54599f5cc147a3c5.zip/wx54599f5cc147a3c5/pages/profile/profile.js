var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), a = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator")), r = require("../../utils/wxRequest"), s = require("../../utils/moment/index.js"), i = require("../../utils/util"), u = i.parseDateCode, o = i.forward, c = getApp();

Page({
    data: {
        theme: c.globalData.theme,
        screenHeight: c.globalData.screenHeight,
        screenWidth: c.globalData.screenWidth,
        statusBarHeight: c.globalData.statusBarHeight,
        capsuleBarHeight: c.globalData.capsuleBarHeight,
        isFullScreen: c.globalData.isFullScreen,
        isBiggerScreen: c.globalData.isBiggerScreen,
        userInfo: null,
        hasUserInfo: !1,
        joinedTime: "",
        current: "comment",
        busy: !1,
        finish: !1,
        list: [],
        titleFadeInProgress: 0,
        comments_count: 0
    },
    onShareAppMessage: function() {
        return o();
    },
    onPageScroll: function(t) {
        var e = t.scrollTop, a = this.data.titleFadeInProgress, n = {};
        if (e > 0) {
            var r = e / 150;
            r <= 1 ? n.titleFadeInProgress = r : a < 1 && (n.titleFadeInProgress = r);
        } else 0 !== a && (n.titleFadeInProgress = 0);
        Object.keys(n).length && this.setData(n);
    },
    onShow: function() {
        var t = c.globalData.theme;
        this.setData({
            theme: t
        }), c.setTheme(), this.getDatas();
    },
    onLoad: function(t) {
        this.init(t.id);
    },
    onReachBottom: function() {
        this.fetchList();
    },
    init: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return c.setTheme(), t.next = 3, r({
                        url: "/v1/users/".concat(e)
                    });

                  case 3:
                    (n = t.sent) && (i = s(1e3 * n.created_at).format("YYYY"), this.setData({
                        userInfo: n,
                        hasUserInfo: !0,
                        joinedTime: i
                    }), this.refreshList(), this.getDatas());

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    changeTab: function(t) {
        var e = this, a = t.currentTarget.dataset.tab, n = this.data.userInfo;
        this.setData({
            current: a
        }), this.refreshList(), r({
            url: "/v1/users/".concat(n.id, "/thoughts/count")
        }).then(function(t) {
            var a = t.count;
            e.setData({
                comments_count: a
            });
        });
    },
    changeTheme: function() {
        var t = "LIGHT" === c.globalData.theme ? "DARK" : "LIGHT";
        this.setData({
            theme: t
        }), c.globalData.theme = t, c.setTheme(), wx.setStorage({
            key: "theme",
            data: t
        });
    },
    getDatas: function() {
        var t, e = this, a = this.data, n = a.userInfo, s = a.comments_count, i = a.current;
        n && r({
            url: "/v1/users/".concat(n.id, "/thoughts/count")
        }).then(function(a) {
            var n = a.count;
            t = n, e.setData({
                comments_count: t
            }), commentsFinish = !0, t !== s && "comment" === i && e.refreshList();
        });
    },
    goToComment: function(t) {
        var e = t.detail.id;
        wx.navigateTo({
            url: "/pages/comment/comment?source=true&comment_id=".concat(e)
        });
    },
    test: function() {
        r({
            url: "/debug/info"
        });
    },
    refreshList: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.setData({
                        list: [],
                        busy: !1,
                        finish: !1
                    }), t.next = 3, this.fetchList();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    fetchList: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            var n, i, o, c, l, h, f;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = this.data, i = n.userInfo, o = n.current, c = n.busy, l = n.finish, !c && !l) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 3:
                    if (this.setData({
                        busy: !0
                    }), h = this.data.list, t.prev = 5, "like" !== o) {
                        t.next = 12;
                        break;
                    }
                    return t.next = 9, r({
                        url: "/v1/users/".concat(i.id, "/favourite_lessons"),
                        data: {
                            limit: 10,
                            offset: h.length
                        }
                    });

                  case 9:
                    f = t.sent, t.next = 16;
                    break;

                  case 12:
                    return t.next = 14, r({
                        url: "/v1/users/".concat(i.id, "/thoughts_profile"),
                        data: {
                            limit: 10,
                            offset: h.length
                        }
                    });

                  case 14:
                    f = (f = t.sent).map(function(t) {
                        var e = u(t.lesson.date_by_day), a = s(e), n = Object.assign({}, t.lesson, {
                            month: a.format("M"),
                            date: a.format("D")
                        });
                        return Object.assign({}, t, {
                            lesson: n
                        });
                    });

                  case 16:
                    this.setData({
                        list: [].concat((0, e.default)(h), (0, e.default)(f)),
                        busy: !1,
                        finish: f.length < 10
                    }), t.next = 22;
                    break;

                  case 19:
                    t.prev = 19, t.t0 = t.catch(5), this.setData({
                        busy: !1
                    });

                  case 22:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 5, 19 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    like: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, s, i, u;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, s = n.comment_id, i = n.lesson_id, t.next = 4, r({
                        url: "/v1/lessons/".concat(i, "/comments/").concat(s, "/like"),
                        method: "PUT"
                    });

                  case 4:
                    u = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== s) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !0,
                            like_count: t.thought.like_count + 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: u
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    unlike: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, s, i, u;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, s = n.comment_id, i = n.lesson_id, t.next = 4, r({
                        url: "/v1/lessons/".concat(i, "/comments/").concat(s, "/like"),
                        method: "DELETE"
                    });

                  case 4:
                    u = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== s) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !1,
                            like_count: t.thought.like_count - 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: u
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});