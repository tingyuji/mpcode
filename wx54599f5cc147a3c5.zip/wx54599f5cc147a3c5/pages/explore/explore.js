var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray"));

require("../../@babel/runtime/helpers/Arrayincludes");

var a = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator")), i = getApp(), s = require("../../utils/wxRequest"), r = require("../../utils/layout_calculator"), o = require("../../utils/moment/index.js"), c = require("../../utils/util"), d = c.forward, l = c.convertZhDate, u = c.parseDateCode, m = c.formatNumber, f = function(t) {
    var e = {};
    return t.forEach(function(t) {
        e[t.id] = t, e[t.id].month = "".concat(t.date_by_day).slice(4, 6), e[t.id].date = "".concat(t.date_by_day).slice(6, 8), 
        e[t.id].zbDate = l(u(t.date_by_day)), e[t.id].titleFadeInProgress = t.titleFadeInProgress || 0, 
        e[t.id].comment_count = t.comment_count || 0, e[t.id].favourite_count = t.favourite_count || 0, 
        e[t.id].isLike = i.globalData.favouriteLessons.includes(t.id);
        var a = e[t.id].article.split("\n\n");
        e[t.id].sections = t.sections && t.sections.length ? t.sections : Array.from(a, function(e, a) {
            var n = Array.from(e.replace(/([。：；？！」』\/）\n]|……|——)([^。：；？！」』）])/g, "$1{split}$2").split("{split}"), function(e, n) {
                return {
                    id: "".concat(t.id, "-").concat(a, "-").concat(n),
                    content: e,
                    mark: !1
                };
            });
            return {
                id: "".concat(t.id, "-").concat(a, "-").concat(n.length),
                sentences: n
            };
        });
    }), Object.keys(e).map(function(t) {
        return e[t];
    });
}, h = function(t) {
    return t * (i.globalData.screenWidth / 750);
};

Page({
    data: {
        theme: i.globalData.theme,
        layout: r({
            hasTabbar: !0,
            blockList: []
        }),
        cardsConst: [ {
            offset: 0,
            offsetAdvDiff: -15,
            alpha: 1,
            alphaAdvDiff: 0,
            scale: 1,
            scaleAdvDiff: 0
        }, {
            offset: 30,
            offsetAdvDiff: -15,
            alpha: .64,
            alphaAdvDiff: .23,
            scale: .92,
            scaleAdvDiff: .04
        }, {
            offset: 60,
            offsetAdvDiff: -15,
            alpha: .4,
            alphaAdvDiff: .11,
            scale: .84,
            scaleAdvDiff: .03
        }, {
            offset: 60,
            offsetAdvDiff: 0,
            alpha: 0,
            alphaAdvDiff: .2,
            scale: .84,
            scaleAdvDiff: 0
        } ],
        animating: !1,
        disableMovableAnimate: !1,
        cardX: h(-311),
        cardY: h(-400),
        baseCardX: h(-311),
        baseCardY: h(-400),
        progress: 0,
        maxRotate: 6,
        maxStampOpacity: 1,
        direction: "",
        comments: [],
        displayComents: [],
        lessonDict: {},
        readedComment: {},
        nextDayComingRemain: "",
        loading: !0
    },
    onShareAppMessage: function() {
        return d();
    },
    init: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            var e, n, i, r, c, d, l;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, s({
                        url: "/v1/today_recommend_comments"
                    });

                  case 2:
                    if (e = t.sent, n = o().format("YYYY-MM-DD"), (i = wx.getStorageSync("readedComment")) && i.date === n ? (r = i.ids, 
                    e = e.filter(function(t) {
                        return !r.includes(t.id);
                    })) : (i = {
                        date: n,
                        ids: []
                    }, wx.setStorage({
                        key: "readedComment",
                        data: i
                    })), c = e.map(function(t) {
                        return t.lesson_id;
                    }), c = new Set(c), c = Array.from(c), d = [], !c.length) {
                        t.next = 15;
                        break;
                    }
                    return t.next = 13, s({
                        url: "/v1/lessons/get_by_ids",
                        method: "POST",
                        data: {
                            ids: c
                        }
                    });

                  case 13:
                    d = t.sent, d = f(d);

                  case 15:
                    l = {}, d.forEach(function(t) {
                        l[t.id] = t;
                    }), this.setData({
                        displayComents: [],
                        comments: e,
                        lessonDict: l,
                        readedComment: i
                    }), this.fillCommentCards();

                  case 19:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    fillCommentCards: function(t) {
        var a = this, n = this.data, i = n.comments, s = n.displayComents, r = n.baseCardX, o = n.baseCardY;
        t && s.splice(0, 1);
        var c = 4 - s.length;
        c > i.length && (c = i.length);
        var d = i.splice(0, c);
        this.setData({
            comments: i,
            displayComents: [].concat((0, e.default)(s), (0, e.default)(d)),
            animating: !1,
            progress: 0,
            stampProgress: 0,
            direction: "",
            cardX: r,
            cardY: o
        }, function() {
            a.setData({
                disableMovableAnimate: !1,
                loading: !1,
                progress: 0,
                stampProgress: 0,
                direction: ""
            });
        });
    },
    onTouchMove: function(t) {
        var e, a, n, i = t.detail.x - this.data.baseCardX;
        i < 0 ? (i *= -1, n = "left") : n = "right", i > 0 ? (e = i - 0 > 30 ? 30 : i - 0, 
        a = i - 10 > 60 ? 60 : i - 10) : e = 0;
        var s = e / 30, r = a / 60;
        this.setData({
            progress: s,
            stampProgress: r,
            direction: n
        });
    },
    onTouchEnd: function(t) {
        var e = this.data, a = e.displayComents, n = e.stampProgress, i = e.readedComment, s = !1, r = o().format("YYYY-MM-DD");
        if (1 === n) {
            i.date !== r && (i.ids = []);
            var c = a[0];
            "right" === this.data.direction && this.like(c.id, c.lesson_id), i.ids.push(c.id), 
            i.date = r, s = !0, this.setData({
                animating: s,
                readedComment: i,
                disableMovableAnimate: s
            }), wx.setStorage({
                key: "readedComment",
                data: i
            });
        } else this.setData({
            animating: s,
            disableMovableAnimate: s,
            cardX: this.data.baseCardX,
            cardY: this.data.baseCardY
        });
    },
    onRolloutEnd: function() {
        this.fillCommentCards(!0);
    },
    gotoProfile: function(t) {
        var e = t.detail;
        wx.navigateTo({
            url: "/pages/profile/profile?id=".concat(e.id)
        });
    },
    goToComment: function(t) {
        var e = t.detail.id;
        wx.navigateTo({
            url: "/pages/comment/comment?comment_id=".concat(e)
        });
    },
    like: function() {
        var t = (0, n.default)(a.default.mark(function t(e, n) {
            var i, r;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, s({
                        url: "/v1/lessons/".concat(n, "/comments/").concat(e, "/like"),
                        method: "PUT"
                    });

                  case 2:
                    i = Array.from(this.data.comments, function(t) {
                        return t.id !== e ? t : Object.assign({}, t, {
                            my_like: !0,
                            like_count: t.like_count + 1
                        });
                    }), r = Array.from(this.data.displayComents, function(t) {
                        return t.id !== e ? t : Object.assign({}, t, {
                            my_like: !0,
                            like_count: t.like_count + 1
                        });
                    }), this.setData({
                        comments: i,
                        displayComents: r
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e, a) {
            return t.apply(this, arguments);
        };
    }(),
    onLike: function(t) {
        var e = t.detail, a = e.comment_id, n = e.lesson_id;
        this.like(a, n);
    },
    onUnlike: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, i, r, o, c;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, i = n.comment_id, r = n.lesson_id, t.next = 4, s({
                        url: "/v1/lessons/".concat(r, "/comments/").concat(i, "/like"),
                        method: "DELETE"
                    });

                  case 4:
                    o = Array.from(this.data.comments, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !1,
                            like_count: t.like_count - 1
                        });
                    }), c = Array.from(this.data.displayComents, function(t) {
                        return t.id !== i ? t : Object.assign({}, t, {
                            my_like: !1,
                            like_count: t.like_count - 1
                        });
                    }), this.setData({
                        comments: o,
                        displayComents: c
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    countDown: function() {
        var t = this, e = o(), a = o(e.format("YYYY-MM-DD")).add(1, "days").diff(e, "seconds");
        a = a < 0 ? 0 : a;
        var n = m(parseInt(a / 3600)), i = m(parseInt(a / 60 % 60)), s = m(parseInt(a % 60)), r = o(a).format("".concat(n, " 时 ").concat(i, " 分 ").concat(s, " 秒"));
        this.setData({
            nextDayComingRemain: r
        }), a || this.init(), clearTimeout(this.nextDayComing), this.nextDayComing = setTimeout(function() {
            t.nextDayComing = null, t.countDown();
        }, 1e3);
    },
    onShow: function() {
        var t = i.globalData.theme;
        this.setData({
            theme: t
        }), i.setTheme();
    },
    onLoad: function() {
        this.init(), this.countDown();
    }
});