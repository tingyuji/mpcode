var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), a = e(require("../../@babel/runtime/helpers/asyncToGenerator")), r = require("../../utils/moment/index.js"), n = require("../../utils/wxRequest"), s = require("../../utils/util").forward, i = getApp();

Page({
    data: {
        theme: i.globalData.theme,
        screenHeight: i.globalData.screenHeight,
        screenWidth: i.globalData.screenWidth,
        statusBarHeight: i.globalData.statusBarHeight,
        capsuleBarHeight: i.globalData.capsuleBarHeight,
        isFullScreen: i.globalData.isFullScreen,
        isBiggerScreen: i.globalData.isBiggerScreen,
        userInfo: i.globalData.userInfo,
        lesson: {},
        focus: !1,
        keyboardHeight: 0,
        cursor: 0,
        date: "",
        content: ""
    },
    onShareAppMessage: function() {
        return s();
    },
    onShow: function() {
        var e = i.globalData.theme;
        this.setData({
            theme: e
        }), i.setTheme();
    },
    onLoad: function(e) {
        var t = e.id, a = e.date;
        this.init(t, a);
    },
    init: function() {
        var e = (0, a.default)(t.default.mark(function e(a) {
            var s, o;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n({
                        url: "/v1/lessons/".concat(a)
                    });

                  case 2:
                    s = e.sent, o = r().format("YYYY 年 M 月 D 日"), this.setData({
                        lesson: s,
                        date: o,
                        userInfo: i.globalData.userInfo
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    formSubmit: function() {
        var e = (0, a.default)(t.default.mark(function e(a) {
            var r, s, i, o, u, l;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = a.detail, s = r.value.content, i = this.data.lesson.id, e.next = 5, n({
                        url: "/v1/lessons/".concat(i, "/comments"),
                        method: "POST",
                        data: {
                            content: s
                        }
                    });

                  case 5:
                    o = e.sent, (u = getCurrentPages()).length > 1 && ((l = u[u.length - 2]).refreshComments && l.refreshComments(o), 
                    wx.navigateBack());

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    focus: function() {
        this.setData({
            focus: !0
        });
    },
    onInput: function(e) {
        var t = e.detail;
        this.setData({
            content: t.value
        });
    },
    onFocus: function(e) {
        var t = e.detail;
        if (t.height) {
            var a = t.height;
            this.setData({
                focus: !0,
                keyboardHeight: a
            });
        } else this.setData({
            focus: !0
        });
    },
    onBlur: function(e) {
        e.detail;
        this.setData({
            focus: !1,
            keyboardHeight: 0
        });
    }
});