var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), a = e(require("../../@babel/runtime/helpers/asyncToGenerator")), n = require("../../utils/util").forward, i = require("../../utils/event"), r = getApp();

Page({
    data: {
        theme: r.globalData.theme,
        screenHeight: r.globalData.screenHeight,
        screenWidth: r.globalData.screenWidth,
        statusBarHeight: r.globalData.statusBarHeight,
        capsuleBarHeight: r.globalData.capsuleBarHeight,
        isFullScreen: r.globalData.isFullScreen,
        isBiggerScreen: r.globalData.isBiggerScreen
    },
    onShareAppMessage: function() {
        return n();
    },
    onShow: function() {
        var e = r.globalData.theme;
        this.setData({
            theme: e
        }), r.setTheme();
    },
    onLoad: function() {
        this.init();
    },
    onGotUserInfoWithWechatLogin: function() {
        var e = (0, a.default)(t.default.mark(function e(a) {
            var n, r;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getUserInfo:ok" === (n = a.detail).errMsg) {
                        wx.showLoading({
                            title: "正在登录"
                        });
                        try {
                            i.emit("gotUserInfo", n);
                        } catch (e) {
                            r = e.errMsg, wx.hideLoading(), wx.showToast({
                                title: r,
                                icon: "none"
                            });
                        }
                    }

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    setLoginedAction: function() {
        var e = this;
        i.on("logined", this, function() {
            wx.hideLoading(), wx.navigateBack({
                delta: 2
            }), i.remove("logined", e);
        });
    },
    init: function(e) {
        r.setTheme();
    },
    onUnload: function() {
        i.remove("logined", this);
    }
});