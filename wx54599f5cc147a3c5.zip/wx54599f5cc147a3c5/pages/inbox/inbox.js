var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/toConsumableArray")), a = e(require("../../@babel/runtime/regenerator")), s = e(require("../../@babel/runtime/helpers/asyncToGenerator")), r = require("../../utils/moment/index.js"), n = require("../../utils/util").forward, i = require("../../utils/wxRequest"), u = getApp();

Page({
    data: {
        theme: u.globalData.theme,
        screenHeight: u.globalData.screenHeight,
        screenWidth: u.globalData.screenWidth,
        statusBarHeight: u.globalData.statusBarHeight,
        capsuleBarHeight: u.globalData.capsuleBarHeight,
        isFullScreen: u.globalData.isFullScreen,
        isBiggerScreen: u.globalData.isBiggerScreen,
        scrollTop: 0,
        lesson: {},
        zbDate: "",
        busy: !1,
        finish: !1,
        messages: []
    },
    onShareAppMessage: function() {
        return n();
    },
    onShow: function() {
        var e = u.globalData.theme;
        this.setData({
            theme: e
        }), u.setTheme(), this.init();
    },
    onReachBottom: function() {
        this.fetchMessages();
    },
    init: function() {
        var e = (0, s.default)(a.default.mark(function e(t) {
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    this.fetchMessages();

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    refreshmessages: function() {
        this.setData({
            messages: [],
            busy: !1,
            finish: !1
        }), this.fetchMessages();
    },
    fetchMessages: function() {
        var e = (0, s.default)(a.default.mark(function e() {
            var s, n, u;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.data.busy && !this.data.finish) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 2:
                    return this.setData({
                        busy: !0
                    }), s = this.data.messages, e.prev = 4, e.next = 7, i({
                        url: "/v1/users/self/inbox/messages",
                        data: {
                            limit: 10,
                            offset: this.data.messages.length
                        }
                    });

                  case 7:
                    return n = e.sent, u = [], n = Array.from(n, function(e) {
                        return u.push(e.id), e.fromNow = r.fromNow(1e3 * e.updated_at), e;
                    }), this.setData({
                        messages: [].concat((0, t.default)(s), (0, t.default)(n)),
                        busy: !1,
                        finish: n.length < 10
                    }), e.next = 13, i({
                        url: "/v1/users/self/inbox/messages/read",
                        method: "PUT",
                        data: {
                            msg_ids: u,
                            read: !0
                        }
                    });

                  case 13:
                    e.next = 18;
                    break;

                  case 15:
                    e.prev = 15, e.t0 = e.catch(4), this.setData({
                        busy: !1
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 4, 15 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    navigateTo: function() {
        var e = (0, s.default)(a.default.mark(function e(t) {
            var s, r, n, i;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    s = t.currentTarget, r = s.dataset.messageId, (n = this.data.messages.find(function(e) {
                        return e.id === r;
                    })).comment_like_notification ? i = n.comment_like_notification.thought_id : n.comment_notification ? i = n.comment_notification.thought_id : n.reply_notification && (i = n.reply_notification.thought_id), 
                    wx.navigateTo({
                        url: "/pages/comment/comment?comment_id=".concat(i, "&source=true")
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});