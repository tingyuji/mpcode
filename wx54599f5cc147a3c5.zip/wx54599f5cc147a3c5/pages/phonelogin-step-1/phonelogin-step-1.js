var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), n = e(require("../../@babel/runtime/helpers/asyncToGenerator")), a = require("../../utils/wxRequest"), i = require("../../utils/moment/index.js"), o = require("../../utils/event"), r = getApp();

Page({
    data: {
        theme: r.globalData.theme,
        screenHeight: r.globalData.screenHeight,
        screenWidth: r.globalData.screenWidth,
        statusBarHeight: r.globalData.statusBarHeight,
        capsuleBarHeight: r.globalData.capsuleBarHeight,
        isFullScreen: r.globalData.isFullScreen,
        isBiggerScreen: r.globalData.isBiggerScreen,
        userInfo: null,
        sendTime: 0,
        remainTime: 0,
        sended: !1,
        verified: !1,
        showModal: !1,
        form: {
            nation_code: "86",
            phone_number: "",
            verify_code: ""
        }
    },
    onShow: function() {
        var e = r.globalData.theme;
        this.setData({
            theme: e
        }), r.setTheme();
    },
    onLoad: function() {
        this.init();
    },
    nationCodeInput: function(e) {
        var t = e.detail;
        this.setData({
            "form.nation_code": t.value
        });
    },
    phoneNumberInput: function(e) {
        var t = e.detail;
        this.setData({
            "form.phone_number": t.value
        });
    },
    verifyCodeChange: function(e) {
        var t = e.detail;
        this.setData({
            verified: 4 === t.value.length
        });
    },
    reset: function(e) {
        this.setData({
            sendTime: 0,
            remainTime: 0,
            sending: !1,
            sended: !1,
            verified: !1,
            showModal: !1,
            form: {
                nation_code: "86",
                phone_number: "",
                verify_code: ""
            }
        });
    },
    sendVerifyCode: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var i, o, r, s, u;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = n.detail, o = i.value, r = o.nation_code, s = o.phone_number, this.setData({
                        sending: !0
                    }), e.prev = 3, e.next = 6, a({
                        url: "/v1/request_wechatmp_phone_login",
                        method: "POST",
                        data: {
                            nation_code: r,
                            phone_number: s
                        }
                    });

                  case 6:
                    this.setData({
                        sended: !0
                    }), wx.navigateTo({
                        url: "/pages/phonelogin-step-2/phonelogin-step-2?nation_code=".concat(r, "&phone_number=").concat(s)
                    }), e.next = 14;
                    break;

                  case 10:
                    e.prev = 10, e.t0 = e.catch(3), "not found" === (u = e.t0.errMsg) ? this.setData({
                        showModal: !0
                    }) : wx.showToast({
                        title: u,
                        icon: "none"
                    });

                  case 14:
                    this.setData({
                        sending: !1
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 3, 10 ] ]);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    countDown: function() {
        var e = this, t = 3 - i().diff(this.data.sendTime, "s");
        this.setData({
            remainTime: t
        }), t > 0 ? setTimeout(function() {
            e.countDown();
        }, 1e3) : this.setData({
            sendTime: 0,
            remainTime: 0
        });
    },
    phoneLogin: function(e) {
        var t = e.detail.value, n = t.nation_code, a = t.phone_number, i = t.verify_code;
        this.setData({
            form: {
                nation_code: n,
                phone_number: a,
                verify_code: i
            }
        });
    },
    onGotUserInfoWithPhoneLogin: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var a;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getUserInfo:ok" !== n.detail.errMsg) {
                        e.next = 14;
                        break;
                    }
                    return wx.showLoading({
                        title: "正在登录"
                    }), o.on("logined", this, function() {
                        wx.hideLoading(), wx.navigateBack({
                            delta: 3
                        });
                    }), e.prev = 4, e.next = 7, r.phoneLogin(this.data.form);

                  case 7:
                    e.next = 14;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(4), a = e.t0.errMsg, wx.hideLoading(), "invalid verify code" === a ? wx.showToast({
                        title: "请输入正确的验证码",
                        icon: "none"
                    }) : wx.showToast({
                        title: a,
                        icon: "none"
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 4, 9 ] ]);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    onGotUserInfoWithWechatLogin: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var a, i, s, u, c, d;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getUserInfo:ok" !== (a = n.detail).errMsg) {
                        e.next = 16;
                        break;
                    }
                    return wx.showLoading({
                        title: "正在登录"
                    }), o.on("logined", this, function() {
                        wx.hideLoading(), wx.navigateBack({
                            delta: 3
                        });
                    }), e.prev = 4, i = a.encryptedData, s = a.iv, u = a.rawData, c = a.signature, console.log("phoneStepWechatLogin"), 
                    e.next = 9, r.login({
                        encryptedData: i,
                        iv: s,
                        rawData: u,
                        signature: c
                    });

                  case 9:
                    e.next = 16;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(4), d = e.t0.errMsg, wx.hideLoading(), wx.showToast({
                        title: d,
                        icon: "none"
                    });

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 4, 11 ] ]);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    closeModal: function() {
        this.setData({
            showModal: !1
        });
    },
    init: function(e) {
        r.setTheme();
    },
    onUnload: function() {
        o.remove("logined", this);
    }
});