var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), a = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator")), s = require("../../utils/wxRequest"), r = require("../../utils/moment/index.js"), o = require("../../utils/event"), u = require("../../utils/util"), i = u.parseDateCode, c = u.forward, l = getApp();

Page({
    data: {
        theme: l.globalData.theme,
        screenHeight: l.globalData.screenHeight,
        screenWidth: l.globalData.screenWidth,
        statusBarHeight: l.globalData.statusBarHeight,
        capsuleBarHeight: l.globalData.capsuleBarHeight,
        isFullScreen: l.globalData.isFullScreen,
        isBiggerScreen: l.globalData.isBiggerScreen,
        userInfo: {},
        hasUserInfo: Boolean(l.globalData.userInfo && l.globalData.userInfo.id),
        joinedTime: "",
        current: "comment",
        busy: !1,
        finish: !1,
        list: [],
        messages_count: 0,
        readed_count: 0,
        like_count: 0,
        comments_count: 0
    },
    onShareAppMessage: function() {
        return c();
    },
    onShow: function() {
        var t = l.globalData.theme, e = Boolean(l.globalData.userInfo && l.globalData.userInfo.id);
        this.setData({
            theme: t,
            hasUserInfo: e
        }), l.setTheme(), this.getDatas();
    },
    onLoad: function() {
        Boolean(l.globalData.userInfo && l.globalData.userInfo.id) && this.refreshAll();
    },
    onUnload: function() {
        o.remove("logined", this);
    },
    onReachBottom: function() {
        this.fetchList();
    },
    init: function(t) {
        l.setTheme();
        var e = l.globalData.userInfo;
        if (e) {
            var a = r().diff(1e3 * e.created_at, "days");
            this.setData({
                userInfo: e,
                hasUserInfo: !0,
                joinedTime: a
            }), this.refreshList();
        }
    },
    refreshAll: function() {
        this.init(), this.getDatas();
    },
    changeTab: function(t) {
        var e = this, a = t.currentTarget.dataset.tab;
        this.setData({
            current: a
        }), this.refreshList(), s({
            url: "/v1/users/self/inbox/messages/count?unread=true"
        }).then(function(t) {
            var a = t.count;
            e.setData({
                messages_count: a
            });
        }), s({
            url: "/v1/users/self/thoughts/count"
        }).then(function(t) {
            var a = t.count;
            e.setData({
                comments_count: a
            });
        }), s({
            url: "/v1/users/self/favourites/count"
        }).then(function(t) {
            var a = t.count;
            e.setData({
                like_count: a
            });
        });
    },
    changeTheme: function() {
        var t = "LIGHT" === l.globalData.theme ? "DARK" : "LIGHT";
        this.setData({
            theme: t
        }), l.globalData.theme = t, l.setTheme(), wx.setStorage({
            key: "theme",
            data: t
        });
    },
    getDatas: function() {
        var t = this, e = l.globalData.userInfo, a = this.data, n = a.messages_count, r = a.comments_count, o = a.like_count, u = a.current;
        if (e) {
            var i, c, h, f = !1, m = !1, g = !1;
            s({
                url: "/v1/users/self/inbox/messages/count?unread=true"
            }).then(function(e) {
                var a = e.count;
                i = a, t.setData({
                    messages_count: i
                }), f = !0, d();
            }), s({
                url: "/v1/users/self/thoughts/count"
            }).then(function(e) {
                var a = e.count;
                c = a, t.setData({
                    comments_count: c
                }), m = !0, d();
            }), s({
                url: "/v1/users/self/favourites/count"
            }).then(function(e) {
                var a = e.count;
                h = a, t.setData({
                    like_count: h
                }), g = !0, d();
            });
            var d = function() {
                f && m && g && (((i !== n || c !== r) && "comment" === u || h !== o && "like" === u) && t.refreshList());
            };
        }
    },
    goToComment: function(t) {
        var e = t.detail.id;
        wx.navigateTo({
            url: "/pages/comment/comment?source=true&comment_id=".concat(e)
        });
    },
    test: function() {
        s({
            url: "/debug/info"
        });
    },
    refreshList: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.setData({
                        list: [],
                        busy: !1,
                        finish: !1
                    }), t.next = 3, this.fetchList();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    fetchList: function() {
        var t = (0, n.default)(a.default.mark(function t() {
            var n, o, u, c, l, h;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = this.data, o = n.current, u = n.busy, c = n.finish, !u && !c) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 3:
                    if (this.setData({
                        busy: !0
                    }), l = this.data.list, t.prev = 5, "like" !== o) {
                        t.next = 12;
                        break;
                    }
                    return t.next = 9, s({
                        url: "/v1/users/self/favourite_lessons",
                        data: {
                            limit: 10,
                            offset: l.length
                        }
                    });

                  case 9:
                    h = t.sent, t.next = 16;
                    break;

                  case 12:
                    return t.next = 14, s({
                        url: "/v1/users/self/thoughts_profile",
                        data: {
                            limit: 10,
                            offset: l.length
                        }
                    });

                  case 14:
                    h = (h = t.sent).map(function(t) {
                        var e = i(t.lesson.date_by_day), a = r(e), n = Object.assign({}, t.lesson, {
                            month: a.format("M"),
                            date: a.format("D")
                        });
                        return Object.assign({}, t, {
                            lesson: n
                        });
                    });

                  case 16:
                    this.setData({
                        list: [].concat((0, e.default)(l), (0, e.default)(h)),
                        busy: !1,
                        finish: h.length < 10
                    }), t.next = 22;
                    break;

                  case 19:
                    t.prev = 19, t.t0 = t.catch(5), this.setData({
                        busy: !1
                    });

                  case 22:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 5, 19 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    like: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, r, o, u;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, r = n.comment_id, o = n.lesson_id, t.next = 4, s({
                        url: "/v1/lessons/".concat(o, "/comments/").concat(r, "/like"),
                        method: "PUT"
                    });

                  case 4:
                    u = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== r) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !0,
                            like_count: t.thought.like_count + 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: u
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    unlike: function() {
        var t = (0, n.default)(a.default.mark(function t(e) {
            var n, r, o, u;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, r = n.comment_id, o = n.lesson_id, t.next = 4, s({
                        url: "/v1/lessons/".concat(o, "/comments/").concat(r, "/like"),
                        method: "DELETE"
                    });

                  case 4:
                    u = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== r) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !1,
                            like_count: t.thought.like_count - 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: u
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    afterGetPhonenumber: function(t) {
        console.log(t);
    },
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});