var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/toConsumableArray")), n = t(require("../../@babel/runtime/regenerator")), s = t(require("../../@babel/runtime/helpers/asyncToGenerator")), a = require("../../utils/wxRequest"), r = require("../../utils/moment/index.js"), i = require("../../utils/event"), o = require("../../utils/layout_calculator"), u = require("../../utils/util"), c = u.parseDateCode, l = u.forward, f = getApp();

Page({
    data: {
        theme: f.globalData.theme,
        screenHeight: f.globalData.screenHeight,
        screenWidth: f.globalData.screenWidth,
        statusBarHeight: f.globalData.statusBarHeight,
        capsuleBarHeight: f.globalData.capsuleBarHeight,
        isFullScreen: f.globalData.isFullScreen,
        isBiggerScreen: f.globalData.isBiggerScreen,
        layout: o({
            hasTabbar: !0,
            tabBarHeight: 56,
            blockList: [ {
                size: 30,
                offset: 24
            }, {
                size: 21,
                offset: 8
            }, {
                size: 32,
                offset: 16
            }, {
                size: 327,
                offset: 40
            }, {
                size: 0,
                offset: 53
            } ]
        }),
        userInfo: {},
        hasUserInfo: Boolean(f.globalData.userInfo && f.globalData.userInfo.id),
        joinedTime: "",
        current: "comment",
        busy: !1,
        finish: !1,
        list: [],
        messages_count: 0,
        readed_count: 0,
        like_count: 0,
        comments_count: 0
    },
    onShareAppMessage: function() {
        return l();
    },
    onShow: function() {
        var t = f.globalData.theme;
        this.setData({
            theme: t
        }), f.setTheme(), this.initUser(), this.getDatas();
    },
    onLoad: function() {},
    onUnload: function() {
        i.remove("logined", this);
    },
    onReachBottom: function() {
        this.fetchList();
    },
    init: function() {
        f.setTheme(), this.initUser();
    },
    initUser: function() {
        var t = f.globalData.userInfo;
        if (t) {
            var e = r().diff(1e3 * t.created_at, "days");
            this.setData({
                userInfo: t,
                hasUserInfo: !0,
                joinedTime: e
            }), this.refreshList();
        }
    },
    gotoInbox: function() {
        wx.navigateTo({
            url: "/pages/inbox/inbox"
        });
    },
    gotoSelf: function() {
        wx.navigateTo({
            url: "/pages/self/self"
        });
    },
    refreshAll: function() {
        this.init(), this.getDatas();
    },
    changeTab: function(t) {
        var e = this, n = t.currentTarget.dataset.tab;
        this.setData({
            current: n
        }), this.refreshList(), a({
            url: "/v1/users/self/inbox/messages/count?unread=true"
        }).then(function(t) {
            var n = t.count;
            e.setData({
                messages_count: n
            });
        }), a({
            url: "/v1/users/self/thoughts/count"
        }).then(function(t) {
            var n = t.count;
            e.setData({
                comments_count: n
            });
        }), a({
            url: "/v1/users/self/favourites/count"
        }).then(function(t) {
            var n = t.count;
            e.setData({
                like_count: n
            });
        });
    },
    changeTheme: function() {
        var t = "LIGHT" === f.globalData.theme ? "DARK" : "LIGHT";
        this.setData({
            theme: t
        }), f.globalData.theme = t, f.setTheme(), wx.setStorage({
            key: "theme",
            data: t
        });
    },
    getDatas: function() {
        var t = this, e = f.globalData.userInfo, n = this.data, s = n.messages_count, r = n.comments_count, i = n.like_count, o = n.current;
        if (e) {
            var u, c, l, h = !1, m = !1, g = !1;
            a({
                url: "/v1/users/self/inbox/messages/count?unread=true"
            }).then(function(e) {
                var n = e.count;
                u = n, t.setData({
                    messages_count: u
                }), h = !0, d();
            }), a({
                url: "/v1/users/self/thoughts/count"
            }).then(function(e) {
                var n = e.count;
                c = n, t.setData({
                    comments_count: c
                }), m = !0, d();
            }), a({
                url: "/v1/users/self/favourites/count"
            }).then(function(e) {
                var n = e.count;
                l = n, t.setData({
                    like_count: l
                }), g = !0, d();
            });
            var d = function() {
                h && m && g && (((u !== s || c !== r) && "comment" === o || l !== i && "like" === o) && t.refreshList());
            };
        }
    },
    goToComment: function(t) {
        t.detail.id;
        wx.navigateTo({
            url: " / pages / comment / comment ? source = true & comment_id = $ {\n        id\n      }\n      "
        });
    },
    test: function() {
        a({
            url: "/debug/info"
        });
    },
    refreshList: function() {
        var t = (0, s.default)(n.default.mark(function t() {
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return this.setData({
                        list: [],
                        busy: !1,
                        finish: !1
                    }), t.next = 3, this.fetchList();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    fetchList: function() {
        var t = (0, s.default)(n.default.mark(function t() {
            var s, i, o, u, l, f;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (s = this.data, i = s.current, o = s.busy, u = s.finish, !o && !u) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 3:
                    if (this.setData({
                        busy: !0
                    }), l = this.data.list, t.prev = 5, "like" !== i) {
                        t.next = 12;
                        break;
                    }
                    return t.next = 9, a({
                        url: "/v1/users/self/favourite_lessons",
                        data: {
                            limit: 10,
                            offset: l.length
                        }
                    });

                  case 9:
                    f = t.sent, t.next = 16;
                    break;

                  case 12:
                    return t.next = 14, a({
                        url: "/v1/users/self/thoughts_profile",
                        data: {
                            limit: 10,
                            offset: l.length
                        }
                    });

                  case 14:
                    f = (f = t.sent).map(function(t) {
                        var e = c(t.lesson.date_by_day), n = r(e), s = Object.assign({}, t.lesson, {
                            month: n.format("M"),
                            date: n.format("D")
                        });
                        return Object.assign({}, t, {
                            lesson: s
                        });
                    });

                  case 16:
                    this.setData({
                        list: [].concat((0, e.default)(l), (0, e.default)(f)),
                        busy: !1,
                        finish: f.length < 10
                    }), t.next = 22;
                    break;

                  case 19:
                    t.prev = 19, t.t0 = t.catch(5), this.setData({
                        busy: !1
                    });

                  case 22:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 5, 19 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    like: function() {
        var t = (0, s.default)(n.default.mark(function t(e) {
            var s, r, i;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s = e.detail, r = s.comment_id, s.lesson_id, t.next = 4, a({
                        url: " / v1 / lessons / $ {\n        lesson_id\n      }\n      /comments/$ {\n        comment_id\n      }\n      /like",
                        method: "PUT"
                    });

                  case 4:
                    i = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== r) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !0,
                            like_count: t.thought.like_count + 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: i
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    unlike: function() {
        var t = (0, s.default)(n.default.mark(function t(e) {
            var s, r, i, o;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return s = e.detail, r = s.comment_id, i = s.lesson_id, t.next = 4, a({
                        url: "/v1/lessons/".concat(i, "/comments/").concat(r, "/like"),
                        method: "DELETE"
                    });

                  case 4:
                    o = Array.from(this.data.list, function(t) {
                        if (t.thought.id !== r) return t;
                        var e = Object.assign({}, t.thought, {
                            my_like: !1,
                            like_count: t.thought.like_count - 1
                        });
                        return Object.assign({}, t, {
                            thought: e
                        });
                    }), this.setData({
                        list: o
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    afterGetPhonenumber: function(t) {
        console.log(t);
    },
    onTapTopBar: function() {
        wx.pageScrollTo({
            scrollTop: 0
        });
    }
});