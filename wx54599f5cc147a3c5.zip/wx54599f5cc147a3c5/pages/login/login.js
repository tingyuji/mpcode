var e = require("../../utils/util").forward, a = getApp();

Page({
    data: {
        theme: a.globalData.theme,
        screenHeight: a.globalData.screenHeight,
        screenWidth: a.globalData.screenWidth,
        statusBarHeight: a.globalData.statusBarHeight,
        capsuleBarHeight: a.globalData.capsuleBarHeight,
        isFullScreen: a.globalData.isFullScreen,
        isBiggerScreen: a.globalData.isBiggerScreen
    },
    onShareAppMessage: function() {
        return e();
    },
    onShow: function() {
        var e = a.globalData.theme;
        this.setData({
            theme: e
        }), a.setTheme();
    },
    onLoad: function() {
        this.init();
    },
    afterLogin: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    init: function(e) {
        a.setTheme();
    }
});