var e = require("../../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../../@babel/runtime/regenerator")), t = e(require("../../@babel/runtime/helpers/asyncToGenerator")), n = getApp(), i = require("../../utils/wxShare").parseShareInfo;

Page({
    data: {},
    onShow: function() {},
    onLoad: function(e) {
        this.init(e);
    },
    init: function() {
        var e = (0, t.default)(r.default.mark(function e(t) {
            var a;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n.setTheme(), e.next = 3, i.bind(this)(t);

                  case 3:
                    (a = e.sent) && (a.comment_id ? wx.redirectTo({
                        url: "/pages/comment/comment?comment_id=".concat(a.comment_id)
                    }) : wx.redirectTo({
                        url: a.path
                    }));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }()
});