var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/toConsumableArray")), a = e(require("../../@babel/runtime/regenerator")), n = e(require("../../@babel/runtime/helpers/asyncToGenerator")), s = getApp(), r = require("../../utils/wxRequest"), i = require("../../utils/moment/index.js"), u = require("../../utils/util").forward, o = function(e) {
    var t = {};
    return e.forEach(function(e) {
        t[e.id] = e, t[e.id].month = "".concat(e.date_by_day).slice(4, 6), t[e.id].date = "".concat(e.date_by_day).slice(6, 8);
    }), Object.keys(t).map(function(e) {
        return t[e];
    });
};

Page({
    data: {
        theme: s.globalData.theme,
        screenHeight: s.globalData.screenHeight,
        screenWidth: s.globalData.screenWidth,
        statusBarHeight: s.globalData.statusBarHeight,
        capsuleBarHeight: s.globalData.capsuleBarHeight,
        isFullScreen: s.globalData.isFullScreen,
        lessons: []
    },
    onShareAppMessage: function() {
        return u();
    },
    init: function() {
        var e = (0, n.default)(a.default.mark(function e() {
            var t, n;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = i().format("YYYY-MM-DD"), e.next = 3, r({
                        url: "/v1/lessons/".concat(t)
                    });

                  case 3:
                    n = e.sent, this.setData({
                        lessons: o([ n ])
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    pushLessons: function(e) {
        var a = e.detail, n = [].concat((0, t.default)(this.data.lessons), (0, t.default)(a));
        (n = o(n)).sort(function(e, t) {
            return e.date_by_day - t.date_by_day;
        }), this.setData({
            lessons: n
        });
    },
    unshiftLessons: function(e) {
        var a = e.detail, n = [].concat((0, t.default)(a), (0, t.default)(this.data.lessons));
        (n = o(n)).sort(function(e, t) {
            return e.date_by_day - t.date_by_day;
        }), this.setData({
            lessons: n
        });
    },
    onShow: function() {
        var e = s.globalData.theme;
        this.setData({
            theme: e
        }), s.setTheme();
    },
    onLoad: function() {
        s.loadFont(), this.init();
    }
});