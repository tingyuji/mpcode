var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), n = e(require("../../@babel/runtime/helpers/asyncToGenerator")), a = getApp(), i = require("../../utils/wxRequest"), o = require("../../utils/moment/index.js"), r = require("../../utils/event");

Page({
    data: {
        theme: a.globalData.theme,
        screenHeight: a.globalData.screenHeight,
        screenWidth: a.globalData.screenWidth,
        statusBarHeight: a.globalData.statusBarHeight,
        capsuleBarHeight: a.globalData.capsuleBarHeight,
        isFullScreen: a.globalData.isFullScreen,
        isBiggerScreen: a.globalData.isBiggerScreen,
        userInfo: null,
        verified: !1,
        focus: !0,
        sendTime: 0,
        remainTime: 0,
        form: {
            nation_code: "86",
            phone_number: "",
            verify_code: ""
        }
    },
    onShow: function() {
        var e = a.globalData.theme;
        this.setData({
            theme: e
        }), a.setTheme();
    },
    onLoad: function(e) {
        var t = e.nation_code, n = e.phone_number;
        this.setData({
            "form.nation_code": t,
            "form.phone_number": n
        }), this.init();
    },
    focus: function() {
        this.setData({
            focus: !0
        });
    },
    sendVerifyCode: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, a, o, r;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = this.data.form, a = n.nation_code, o = n.phone_number, this.setData({
                        focus: !0,
                        sending: !0
                    }), e.prev = 2, e.next = 5, i({
                        url: "/v1/request_wechatmp_phone_login",
                        method: "POST",
                        data: {
                            nation_code: a,
                            phone_number: o
                        }
                    });

                  case 5:
                    this.setData({
                        remainTime: 60,
                        sendTime: +new Date()
                    }), this.countDown(), e.next = 13;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(2), "not found" === (r = e.t0.errMsg) ? this.setData({
                        showModal: !0
                    }) : wx.showToast({
                        title: r,
                        icon: "none"
                    });

                  case 13:
                    this.setData({
                        sending: !1
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 2, 9 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    countDown: function() {
        var e = this, t = 60 - o().diff(this.data.sendTime, "s");
        this.setData({
            remainTime: t
        }), t > 0 ? setTimeout(function() {
            e.countDown();
        }, 1e3) : this.setData({
            sendTime: 0,
            remainTime: 0
        });
    },
    verifyCodeChange: function(e) {
        var t = e.detail;
        this.setData({
            "form.verify_code": t.value,
            verified: 4 === t.value.length
        });
    },
    phoneLogin: function(e) {
        var t = e.detail.value.verify_code;
        this.setData({
            "form.verify_code": t
        });
    },
    onGotUserInfoWithPhoneLogin: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var i;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("getUserInfo:ok" !== n.detail.errMsg) {
                        e.next = 13;
                        break;
                    }
                    return wx.showLoading({
                        title: "正在登录"
                    }), e.prev = 3, e.next = 6, a.phoneLogin(this.data.form);

                  case 6:
                    e.next = 13;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(3), i = e.t0.errMsg, wx.hideLoading(), "invalid verify code" === i ? wx.showToast({
                        title: "请输入正确的验证码",
                        icon: "none"
                    }) : wx.showToast({
                        title: i,
                        icon: "none"
                    });

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 3, 8 ] ]);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    setLoginedAction: function() {
        var e = this;
        r.on("logined", this, function() {
            wx.hideLoading(), wx.navigateBack({
                delta: 4
            }), r.remove("logined", e);
        });
    },
    init: function(e) {
        a.setTheme(), this.setData({
            remainTime: 60,
            sendTime: +new Date()
        }), this.countDown();
    },
    onUnload: function() {
        r.remove("logined", this);
    }
});