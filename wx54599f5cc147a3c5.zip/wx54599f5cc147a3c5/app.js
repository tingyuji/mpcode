var e = require("@babel/runtime/helpers/interopRequireDefault"), t = e(require("@babel/runtime/regenerator")), n = e(require("@babel/runtime/helpers/asyncToGenerator")), r = require("utils/wxRequest"), s = require("utils/wxApi"), a = require("utils/event");

App({
    onLaunch: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var s, o = this;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log(this.globalData.config), e.next = 3, r({
                        baseUrl: "https://mina-api.moreless.io",
                        url: "/release/islanding-sync"
                    });

                  case 3:
                    s = e.sent, this.globalData.config = s, a.emit("getConfig"), this.setTheme(), this.globalData.qrcode_scene = n.query.scene, 
                    this.loadFont(), this.userInit(), this.getFavouriteLessons(), a.on("gotUserInfo", this, function() {
                        console.log("onGotUserInfo"), o.userInit(), o.getFavouriteLessons();
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    onShow: function() {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                var n = t.screenHeight, r = t.screenWidth, s = t.statusBarHeight;
                e.globalData.isFullScreen = parseInt(r / n * 100) < parseInt(9 / 17 * 100), e.globalData.isBiggerScreen = n > 667, 
                e.globalData.statusBarHeight = s, e.globalData.capsuleBarHeight = 44, e.globalData.screenHeight = n, 
                e.globalData.screenWidth = r;
            }
        });
    },
    parseQrcode: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, s;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (e.prev = 0, !(n = this.globalData.qrcode_scene)) {
                        e.next = 7;
                        break;
                    }
                    return e.next = 5, r({
                        url: "/v1/tidesleep/qrcode_info",
                        data: {
                            id: n
                        }
                    });

                  case 5:
                    return s = e.sent, e.abrupt("return", s);

                  case 7:
                    e.next = 12;
                    break;

                  case 9:
                    throw e.prev = 9, e.t0 = e.catch(0), e.t0;

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 0, 9 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    phoneLogin: function() {
        var e = (0, n.default)(t.default.mark(function e(n) {
            var s, a, o, u, c, i;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = n.phone_number, a = n.nation_code, o = n.verify_code, e.next = 3, this.getAuthCode();

                  case 3:
                    return u = e.sent, e.next = 6, r({
                        url: "/v1/wechatmp_phone_login",
                        method: "POST",
                        data: {
                            phone_number: s,
                            nation_code: a,
                            verify_code: o,
                            code: u
                        }
                    });

                  case 6:
                    return c = e.sent, i = c.tide_sid, wx.setStorageSync("sid", i), e.next = 11, this.setInfo();

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    userInit: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("userInit"), n = wx.getStorageSync("sid"), console.log("sid: ", n), 
                    !n || !this.checkWxSession()) {
                        e.next = 16;
                        break;
                    }
                    return console.log("check-success"), e.prev = 5, e.next = 8, this.setInfo();

                  case 8:
                    e.next = 14;
                    break;

                  case 10:
                    return e.prev = 10, e.t0 = e.catch(5), e.next = 14, this.loginWhitCode();

                  case 14:
                    e.next = 25;
                    break;

                  case 16:
                    return console.log("check-fail"), e.prev = 17, e.next = 20, this.loginWhitCode();

                  case 20:
                    e.next = 25;
                    break;

                  case 22:
                    e.prev = 22, e.t1 = e.catch(17), console.log(e.t1);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 5, 10 ], [ 17, 22 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    loginWhitCode: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, r, s;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("loginWhitCode"), e.next = 3, this.getAuthCode();

                  case 3:
                    return n = e.sent, e.next = 6, this.getWxUserInfo();

                  case 6:
                    return r = e.sent, e.prev = 7, e.next = 10, this.login(r, n);

                  case 10:
                    e.next = 17;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(7), s = e.t0.errMsg, wx.hideLoading(), wx.showToast({
                        title: s,
                        icon: "none"
                    });

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 7, 12 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    login: function() {
        var e = (0, n.default)(t.default.mark(function e(n, s) {
            var a, o, u;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("login"), console.log("code: ", s), a = {
                        user_info: n
                    }, !s) {
                        e.next = 7;
                        break;
                    }
                    a.code = s, e.next = 13;
                    break;

                  case 7:
                    return e.next = 9, this.getAuthCode();

                  case 9:
                    return a.code = e.sent, e.next = 12, this.getWxUserInfo();

                  case 12:
                    a.userInfo = e.sent;

                  case 13:
                    return e.next = 15, r({
                        url: "/v1/wechat_mp_login",
                        method: "POST",
                        data: a
                    });

                  case 15:
                    return o = e.sent, u = o.tide_sid, wx.setStorageSync("sid", u), e.next = 20, this.setInfo();

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t, n) {
            return e.apply(this, arguments);
        };
    }(),
    checkUserAuth: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("checkUserAuth"), n = s.wxGetSetting(), e.next = 4, n();

                  case 4:
                    if (e.sent.authSetting["scope.userInfo"]) {
                        e.next = 7;
                        break;
                    }
                    throw "user not auth";

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    checkWxSession: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = s.wxCheckSession(), e.next = 3, n();

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getCode: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, r, a;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("getCode"), n = s.wxLogin(), e.next = 4, n();

                  case 4:
                    return r = e.sent, a = r.code, e.abrupt("return", a);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getOpenId: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, s, a;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ((n = wx.getStorageSync("wxOpenId")) && this.checkWxSession()) {
                        e.next = 9;
                        break;
                    }
                    return e.next = 4, this.getCode();

                  case 4:
                    return s = e.sent, e.next = 7, r({
                        url: "/v1/tidesleep/wechat_openid",
                        data: {
                            code: s
                        }
                    });

                  case 7:
                    a = e.sent, n = a.openid;

                  case 9:
                    return wx.setStorageSync("wxOpenId", n), e.abrupt("return", n);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getAuthCode: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.log("getAuthCode"), e.next = 3, this.checkUserAuth();

                  case 3:
                    return e.abrupt("return", this.getCode());

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    setInfo: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("setInfo"), (n = this.globalData.userInfo) && n.nickname) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 5, this.getUserInfo();

                  case 5:
                    if ((n = e.sent).nickname) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 9, this.saveUserInfo();

                  case 9:
                    n = e.sent;

                  case 10:
                    this.globalData.userInfo = n, a.emit("logined"), console.log("setInfo-success");

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getUserInfo: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, r({
                        url: "/v1/users/self"
                    });

                  case 3:
                    return n = e.sent, e.abrupt("return", n);

                  case 7:
                    e.prev = 7, e.t0 = e.catch(0), this.globalData.relogin_count <= 3 && (this.globalData.relogin_count++, 
                    wx.removeStorageSync("sid"), this.userInit());

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 0, 7 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getWxUserInfo: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, r;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.checkUserAuth();

                  case 2:
                    return n = s.wxGetUserInfo(), e.next = 5, n({
                        withCredentials: !0
                    });

                  case 5:
                    return r = e.sent, e.abrupt("return", r);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    saveUserInfo: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n, s, a;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.getWxUserInfo();

                  case 2:
                    return n = e.sent, s = wx.getStorageSync("sid"), e.next = 6, r({
                        url: "/wechatmp/users/self/profile",
                        method: "POST",
                        data: {
                            rawData: n.rawData,
                            signature: n.signature,
                            encryptedData: n.encryptedData,
                            userInfo: n.userInfo,
                            iv: n.iv,
                            sid: s
                        }
                    });

                  case 6:
                    return a = e.sent, e.abrupt("return", a);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    getFavouriteLessons: function() {
        var e = (0, n.default)(t.default.mark(function e() {
            var n;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, r({
                        url: "/v1/users/self/favourite_lesson_ids"
                    });

                  case 2:
                    n = e.sent, this.globalData.favouriteLessons = n;

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    loadFont: function() {
        wx.loadFontFace({
            family: "FZYanSJW_Xian",
            source: 'url("https://pics.tide.moreless.io/rike/FZYanSJW_Xian.TTF")'
        }), wx.loadFontFace({
            family: "HYXinRenWenSongW",
            source: 'url("https://pics.tide.moreless.io/rike/HYXinRenWenSongW.ttf")'
        });
    },
    setTheme: function() {
        var e = "LIGHT" === this.globalData.theme;
        wx.setNavigationBarColor({
            frontColor: e ? "#000000" : "#ffffff",
            backgroundColor: e ? "#ffffff" : "#000000"
        }), wx.setBackgroundColor({
            backgroundColor: e ? "#ffffff" : "#121212",
            backgroundColorTop: e ? "#ffffff" : "#121212",
            backgroundColorBottom: e ? "#ffffff" : "#121212"
        }), wx.setTabBarStyle({
            color: e ? "#c2c2c2" : "#999999",
            selectedColor: e ? "#121212" : "#ffffff",
            borderStyle: e ? "white" : "black",
            backgroundColor: e ? "#ffffff" : "#121212"
        }), wx.setTabBarItem({
            index: 0,
            pagePath: "pages/index/index",
            text: "首页",
            iconPath: e ? "imgs/tabs/L-home-unselected.png" : "imgs/tabs/D-home-unselected.png",
            selectedIconPath: e ? "imgs/tabs/L-home-selected.png" : "imgs/tabs/D-home-selected.png"
        }), wx.setTabBarItem({
            index: 1,
            pagePath: "pages/explore/explore",
            text: "发现",
            iconPath: e ? "imgs/tabs/L-comments-unselected.png" : "imgs/tabs/D-comments-unselected.png",
            selectedIconPath: e ? "imgs/tabs/L-comments-selected.png" : "imgs/tabs/D-comments-selected.png"
        }), wx.setTabBarItem({
            index: 2,
            pagePath: "pages/profile/profile",
            text: "我",
            iconPath: e ? "imgs/tabs/L-me-unselected.png" : "imgs/tabs/D-me-unselected.png",
            selectedIconPath: e ? "imgs/tabs/L-me-selected.png" : "imgs/tabs/D-me-selected.png"
        });
    },
    globalData: {
        theme: wx.getStorageSync("theme") || "LIGHT",
        isBiggerScreen: !1,
        isFullScreen: !1,
        userInfo: null,
        favouriteLessons: [],
        qrcode_scene: "",
        qrcode_scene_scene_id: ""
    }
});