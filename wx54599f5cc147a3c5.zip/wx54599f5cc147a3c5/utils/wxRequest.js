var e = require("../@babel/runtime/helpers/interopRequireDefault");

require("../@babel/runtime/helpers/Arrayincludes");

var r, t = e(require("../@babel/runtime/regenerator")), n = e(require("../@babel/runtime/helpers/asyncToGenerator")), a = require("./base64.min.js").Base64;

function s(e) {
    return function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(t, n) {
            r.success = function(e) {
                [ 200, 204 ].includes(e.statusCode) ? t(e) : n({
                    errMsg: e.data.message || e.data.msg,
                    error: e.data.error,
                    details: e.data.details
                });
            }, r.fail = function(e) {
                n(e);
            }, e(r);
        });
    };
}

function o() {
    return (o = (0, n.default)(t.default.mark(function e(n) {
        var o, u, i, c;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return o = s(wx.request), r || (r = getApp()), u = wx.getStorageSync("sid"), n.header || (n.header = {}), 
                i = {
                    Authorization: "Basic ".concat(a.encode("W8TxC2uDKWy6P8G7u4mjV:khsvJs9pjhoP943o7VK9A")),
                    "ML-AppID": 3
                }, n.method && "post" === n.method.toLowerCase() && (i["Content-Type"] = "application/json"), 
                u && (i.Cookie = "tide_sid=".concat(u)), n.header = Object.assign(i, n.header), 
                n.url = "".concat(n.baseUrl || "https://rike-api.moreless.io").concat(n.url), e.next = 11, 
                o(n);

              case 11:
                if ("request:ok" === (c = e.sent).errMsg) {
                    e.next = 16;
                    break;
                }
                throw c.errMsg;

              case 16:
                if ([ 200, 204 ].includes(c.statusCode)) {
                    e.next = 20;
                    break;
                }
                throw c.data;

              case 20:
                return e.abrupt("return", c.data);

              case 21:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

Promise.prototype.finally = function(e) {
    var r = this.constructor;
    return this.then(function(t) {
        return r.resolve(e()).then(function() {
            return t;
        });
    }, function(t) {
        return r.resolve(e()).then(function() {
            throw t;
        });
    });
}, module.exports = function(e) {
    return o.apply(this, arguments);
};