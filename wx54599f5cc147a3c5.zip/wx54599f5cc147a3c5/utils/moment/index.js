var e = require("moment.min");

e.locale("zh-cn", {
    relativeTime: {
        future: "%s内",
        past: "%s前",
        s: "刚刚",
        m: "1 分钟",
        mm: "%d 分钟",
        h: "1 小时",
        hh: "%d 小时",
        d: "1 天",
        dd: "%d 天",
        M: "1 个月",
        MM: "%d 个月",
        y: "1 年",
        yy: "%d 年"
    }
});

var r = e.relativeTimeThreshold("s");

e.fromNow = function(o) {
    var d = e(o);
    return -1 * d.diff(void 0, "s") <= r ? d.fromNow(!0) : d.fromNow();
}, module.exports = e;