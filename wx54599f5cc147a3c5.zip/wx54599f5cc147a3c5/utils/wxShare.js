var e = require("../@babel/runtime/helpers/interopRequireDefault"), r = e(require("../@babel/runtime/regenerator")), t = e(require("../@babel/runtime/helpers/asyncToGenerator")), n = require("./base64.min.js").Base64, a = require("./wxApi").wxGetShareInfo, u = require("./wxRequest"), i = function(e, r, t) {
    null == t && (t = "");
    var n = new RegExp("\\b(" + r + "=).*?(&|$)");
    return e.search(n) >= 0 ? e.replace(n, "$1" + t + "$2") : e + (e.indexOf("?") > 0 ? "&" : "?") + r + "=" + t;
};

function c() {
    function e() {
        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1);
    }
    return e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e();
}

function s(e) {
    var r = getApp().globalData.userInfo, t = {
        openid: wx.getStorageSync("wxOpenId"),
        app_id: "3"
    };
    return r && r.id && (t.user_id = r.id, t.unionid = r.unionid), {
        share_id: c(),
        share_by: t,
        context: e
    };
}

function o() {
    return (o = (0, t.default)(r.default.mark(function e(t) {
        var a, i, c, o, p, f;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = t.path, i = s(i = t.context), c = n.encode(JSON.stringify(i)), o = {
                    context: i,
                    hash_key: c,
                    page: a,
                    force_recreated: !1,
                    app_id: "3"
                }, e.next = 6, u({
                    url: "/v1/gen_wechat_mp_qrcode",
                    method: "POST",
                    data: o
                });

              case 6:
                return p = e.sent, f = p.url, e.abrupt("return", f);

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function p(e) {
    return f.apply(this, arguments);
}

function f() {
    return (f = (0, t.default)(r.default.mark(function e(t) {
        var n;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (e.prev = 0, !t) {
                    e.next = 6;
                    break;
                }
                return e.next = 4, u({
                    url: "/v1/wechat_mp_qrcodes/".concat(t)
                });

              case 4:
                return n = e.sent, e.abrupt("return", n);

              case 6:
                e.next = 11;
                break;

              case 8:
                throw e.prev = 8, e.t0 = e.catch(0), e.t0;

              case 11:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 0, 8 ] ]);
    }))).apply(this, arguments);
}

function d() {
    return (d = (0, t.default)(r.default.mark(function e(t) {
        var n, a;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, p(t.scene);

              case 2:
                return n = e.sent, a = n.context, e.abrupt("return", a);

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function l() {
    return (l = (0, t.default)(r.default.mark(function e(t, n) {
        var i, c, s, o, p, f, d, l;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                if (i = getApp(), c = i.globalData.userInfo, s = wx.getStorageSync("wxOpenId"), 
                o = {
                    openid: s,
                    app_id: "3"
                }, c && c.id && (o.userid = c.id, o.unionid = c.unionid), t.trigger_by = o, !n) {
                    e.next = 22;
                    break;
                }
                return p = a(), e.prev = 10, e.next = 13, p({
                    shareTicket: n
                });

              case 13:
                f = e.sent, d = f.encryptedData, l = f.iv, t.share_ticket = {
                    encryptedData: d,
                    iv: l
                }, e.next = 22;
                break;

              case 19:
                e.prev = 19, e.t0 = e.catch(10), console.log(e.t0);

              case 22:
                return e.next = 24, u({
                    url: "/v1/wechat_mp_share_events",
                    method: "POST",
                    data: t
                });

              case 24:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 10, 19 ] ]);
    }))).apply(this, arguments);
}

module.exports = {
    genSharePath: function(e) {
        var r = e.path, t = s(e.context);
        return i(r, "shareInfo", JSON.stringify(t));
    },
    genShareQRCode: function(e) {
        return o.apply(this, arguments);
    },
    parseShareInfo: function(e) {
        return d.apply(this, arguments);
    },
    submitShareInfo: function(e, r) {
        return l.apply(this, arguments);
    }
};