var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/helpers/slicedToArray")), t = getApp(), n = [ "〇", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二" ], r = function(e) {
    return (e = e.toString())[1] ? e : "0" + e;
};

module.exports = {
    convertZhNumber: function(e) {
        var t = e.split(""), r = "";
        return t.forEach(function(e) {
            r += n[e];
        }), r;
    },
    convertZhDate: function(t) {
        var r = t.split("-"), a = (0, e.default)(r, 3), o = (a[0], a[1]), c = a[2], i = "".concat(n[parseInt(o)], "月"), u = function(e) {
            var t = parseInt(e);
            if (t >= 10) {
                var r = parseInt(e[0]), a = parseInt(e[1]);
                return "".concat(n[r]).concat(n[a]);
            }
            return "".concat(n[t], "日");
        }(c);
        return "".concat(i).concat(u);
    },
    formatTime: function(e) {
        var t = e.getFullYear(), n = e.getMonth() + 1, a = e.getDate(), o = e.getHours(), c = e.getMinutes(), i = e.getSeconds();
        return [ t, n, a ].map(r).join("/") + " " + [ o, c, i ].map(r).join(":");
    },
    formatNumber: r,
    parseDateCode: function(e) {
        var t = parseInt(e / 1e4), n = parseInt(e / 100) % (100 * t), a = e % (100 * (100 * t + n));
        return "".concat(t, "-").concat(r(n), "-").concat(r(a));
    },
    forward: function(e) {
        var n, r, a;
        return e ? (n = t.globalData.userInfo ? "".concat(t.globalData.userInfo.nickname, " 邀你一起来读：") : "我邀你一起来读：", 
        r = "/pages/lesson/lesson?id=".concat(e), a = "http://pics.tide.moreless.io/rike/forward_".concat(e, ".png")) : (n = t.globalData.userInfo ? "".concat(t.globalData.userInfo.nickname, " 邀你一起每天 5 分钟，读点好文章：") : "邀你一起每天 5 分钟，读点好文章：", 
        r = "/pages/index/index", a = "http://pics.tide.moreless.io/rike/forward.png"), 
        {
            title: n,
            path: r,
            imageUrl: a
        };
    },
    unique: function(e, t) {
        var n = {};
        return t ? (e.forEach(function(e) {
            n[e[t]] = e;
        }), e = Object.keys(n).map(function(e) {
            return n[e];
        })) : (e.forEach(function(e) {
            n[JSON.stringify(e)] = e;
        }), e = Object.keys(n).map(function(e) {
            return JSON.parse(e);
        })), e;
    }
};