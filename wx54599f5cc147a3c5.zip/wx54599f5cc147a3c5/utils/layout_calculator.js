var t = wx.getSystemInfoSync(), r = parseInt(t.windowWidth / t.screenHeight * 100) < parseInt(9 / 17 * 100) ? 34 : 0, e = t.screenHeight, a = (t.screenWidth, 
t.statusBarHeight);

module.exports = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = t.hasTabbar, n = void 0 !== i && i, o = t.hasNavbar, s = void 0 === o || o, d = t.tabBarHeight, l = void 0 === d ? 49 : d, v = t.navBarHeight, h = void 0 === v ? 44 : v, f = t.blockList, u = void 0 === f ? [] : f, c = a + (s ? h : 0), y = (n ? l : 0) + r, g = e - c - y, b = 667 - (20 + h + (n ? l : 0)), w = [], H = !0, B = !1, m = void 0;
    try {
        for (var p, x = u[Symbol.iterator](); !(H = (p = x.next()).done); H = !0) {
            var z = p.value;
            g -= z.size, b -= z.size;
        }
    } catch (t) {
        B = !0, m = t;
    } finally {
        try {
            H || null == x.return || x.return();
        } finally {
            if (B) throw m;
        }
    }
    var S = !0, I = !1, k = void 0;
    try {
        for (var P, T = u[Symbol.iterator](); !(S = (P = T.next()).done); S = !0) {
            var W = P.value, L = W.offset / (b / g);
            w.push({
                size: W.size,
                offset: L
            });
        }
    } catch (t) {
        I = !0, k = t;
    } finally {
        try {
            S || null == T.return || T.return();
        } finally {
            if (I) throw k;
        }
    }
    return {
        navBarHeight: h,
        tabBarHeight: l,
        windowPaddingTop: c,
        windowPaddingBottom: y,
        blocks: w
    };
};