var e = require("../../utils/moment/index.js");

Component({
    externalClasses: [ "icon-semicolon", "icon-reply", "icon-like", "icon-unlike", "icon-lgtm", "icon-unlgtm" ],
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        },
        direction: {
            type: String,
            value: "vertical"
        },
        isreply: {
            type: Boolean,
            value: !1
        },
        expand: {
            type: Boolean,
            value: !1
        },
        adaption: {
            type: Boolean,
            value: !1
        },
        scaleContent: {
            type: Boolean,
            value: !1
        },
        comment: {
            type: Object,
            observer: function(t) {
                if (t.id) {
                    var n = e.fromNow(1e3 * t.created_at), i = "larger", o = t.content.length;
                    o > 20 && o <= 80 ? i = "medium" : o > 80 && (i = "regular"), this.setData({
                        createdAt: n,
                        contentSize: i
                    });
                }
            }
        },
        lesson: {
            type: Object
        }
    },
    data: {
        createdAt: "",
        contentSize: "larger"
    },
    created: function() {},
    ready: function() {
        if (this.data.comment) {
            var t = e.fromNow(1e3 * this.data.comment.created_at);
            this.setData({
                createdAt: t
            });
        }
    },
    methods: {
        onTap: function() {
            var e = this.data.comment;
            this.triggerEvent("tapcomment", e);
        },
        onLongPress: function() {
            var e = this.data.comment;
            this.triggerEvent("longpresscomment", {
                comment_id: e.id,
                user: e.user
            });
        },
        reply: function() {
            var e = this.data.comment;
            this.triggerEvent("reply", e);
        },
        like: function() {
            var e = this.data.comment;
            e.my_like ? this.triggerEvent("unlike", {
                comment_id: e.id,
                lesson_id: e.lesson_id
            }) : this.triggerEvent("like", {
                comment_id: e.id,
                lesson_id: e.lesson_id
            });
        },
        tapAvatar: function() {
            var e = this.data.comment;
            this.triggerEvent("gotoprofile", e.user);
        }
    }
});