var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), r = e(require("../../@babel/runtime/helpers/asyncToGenerator")), n = require("../../utils/event");

getApp();

Component({
    externalClasses: [ "class-login-btn" ],
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        },
        text: {
            type: String,
            value: "确定授权"
        }
    },
    data: {},
    ready: function() {},
    methods: {
        onGotUserInfo: function() {
            var e = (0, r.default)(t.default.mark(function e(r) {
                var i, o;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ("getUserInfo:ok" === (i = r.detail).errMsg) {
                            wx.showLoading({
                                title: "正在登录"
                            });
                            try {
                                n.emit("gotUserInfo", i);
                            } catch (e) {
                                o = e.errMsg, wx.hideLoading(), wx.showToast({
                                    title: o,
                                    icon: "none"
                                });
                            }
                        }

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(),
        setLoginedAction: function() {
            var e = this;
            n.on("logined", this, function() {
                wx.hideLoading(), e.triggerEvent("afterlogin"), n.remove("logined", e);
            });
        }
    },
    detached: function() {
        n.remove("logined", this);
    }
});