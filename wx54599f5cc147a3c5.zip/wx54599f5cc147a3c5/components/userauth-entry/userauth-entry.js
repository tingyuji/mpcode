var t = getApp();

require("../../utils/event");

Component({
    externalClasses: [],
    properties: {
        action: {
            type: String
        },
        cbdata: {
            type: String
        }
    },
    data: {
        order: !1
    },
    methods: {
        action: function() {
            var t = this.data.cbdata ? JSON.parse(this.data.cbdata) : {};
            this.triggerEvent("afterlogin", t);
        },
        afterLogin: function() {
            t.globalData.userInfo ? this.action() : (this.setData({
                order: !0
            }), wx.navigateTo({
                url: "/pages/login/login"
            }));
        }
    },
    detached: function() {
        this.setData({
            order: !1
        });
    },
    pageLifetimes: {
        show: function() {
            this.data.order && t.globalData.userInfo && (this.setData({
                order: !1
            }), this.action());
        }
    }
});