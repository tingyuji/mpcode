var t = getApp();

Component({
    externalClasses: [],
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        },
        replyTarget: {
            type: Object,
            value: null
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.focus();
            }
        }
    },
    data: {
        isFullScreen: t.globalData.isFullScreen,
        userInfo: {},
        hasUserInfo: !1,
        focus: !1,
        keyboardHeight: 0,
        content: "",
        row: 2
    },
    created: function() {},
    methods: {
        formSubmit: function(t) {
            var e = t.detail.value.content, n = this.data.replyTarget;
            n ? this.triggerEvent("submitreply", {
                content: e,
                comment_id: n.comment_id
            }) : this.triggerEvent("submitreview", {
                content: e
            }), this.setData({
                content: ""
            }), this.hide();
        },
        lineChange: function(t) {
            var e = t.detail, n = e.lineCount > 2 ? e.lineCount : 2;
            this.setData({
                row: n
            });
        },
        focus: function() {
            this.setData({
                focus: !0
            });
        },
        hide: function() {
            this.setData({
                focus: !1
            }), this.triggerEvent("hide");
        },
        onInput: function(t) {
            var e = t.detail;
            this.setData({
                content: e.value
            });
        },
        onFocus: function(t) {
            var e = t.detail;
            if (e.height) {
                var n = e.height;
                this.setData({
                    focus: !0,
                    keyboardHeight: n
                });
            } else this.setData({
                focus: !0
            });
        },
        onBlur: function() {
            this.setData({
                keyboardHeight: 0
            });
        }
    }
});