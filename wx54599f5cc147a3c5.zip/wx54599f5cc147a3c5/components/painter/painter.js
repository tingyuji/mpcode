var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), r = t(require("../../@babel/runtime/helpers/asyncToGenerator")), a = require("../../utils/wxApi");

Component({
    properties: {
        width: {
            type: Number
        },
        height: {
            type: Number
        },
        drawData: {
            type: Array,
            observer: function() {
                this.refreshPainter();
            }
        }
    },
    data: {},
    ready: function() {
        this.refreshPainter();
    },
    methods: {
        refreshPainter: function() {
            var t = (0, r.default)(e.default.mark(function t() {
                var r, a, n, i, s, c, u, o, h, d = this;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (r = this.data, a = r.width, n = r.height, !this.data.drawData.length) {
                            t.next = 30;
                            break;
                        }
                        this.ctx = wx.createCanvasContext("painter", this), i = !0, s = !1, c = void 0, 
                        t.prev = 6, u = this.data.drawData[Symbol.iterator]();

                      case 8:
                        if (i = (o = u.next()).done) {
                            t.next = 15;
                            break;
                        }
                        return h = o.value, t.next = 12, this.assignPainter(h);

                      case 12:
                        i = !0, t.next = 8;
                        break;

                      case 15:
                        t.next = 21;
                        break;

                      case 17:
                        t.prev = 17, t.t0 = t.catch(6), s = !0, c = t.t0;

                      case 21:
                        t.prev = 21, t.prev = 22, i || null == u.return || u.return();

                      case 24:
                        if (t.prev = 24, !s) {
                            t.next = 27;
                            break;
                        }
                        throw c;

                      case 27:
                        return t.finish(24);

                      case 28:
                        return t.finish(21);

                      case 29:
                        this.ctx.draw(!0, function() {
                            wx.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: a,
                                height: n,
                                destWidth: a,
                                destHeight: n,
                                canvasId: "painter",
                                success: function(t) {
                                    d.triggerEvent("draw", {
                                        tempFilePath: t.tempFilePath
                                    });
                                }
                            }, d);
                        });

                      case 30:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 6, 17, 21, 29 ], [ 22, , 24, 28 ] ]);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        assignPainter: function() {
            var t = (0, r.default)(e.default.mark(function t(r) {
                var a;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        a = r.type, t.t0 = a, t.next = "image" === t.t0 ? 4 : "text" === t.t0 ? 7 : 10;
                        break;

                      case 4:
                        return t.next = 6, this.drawImage(r);

                      case 6:
                        return t.abrupt("break", 10);

                      case 7:
                        return t.next = 9, this.drawText(r);

                      case 9:
                        return t.abrupt("break", 10);

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(),
        drawImage: function() {
            var t = (0, r.default)(e.default.mark(function t(r) {
                var n, i, s, c, u, o, h, d, l, f;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = r.dx, i = r.dy, s = r.width, c = r.height, u = r.url, o = r.alpha, h = void 0 === o ? 1 : o, 
                        d = a.wxDownloadFile(), t.next = 4, d({
                            url: u
                        });

                      case 4:
                        l = t.sent, f = l.tempFilePath, this.ctx.setGlobalAlpha(h), this.ctx.drawImage(f, n, i, s, c);

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(),
        drawText: function(t) {
            var e = t.color, r = void 0 === e ? "#ffffff" : e, a = t.alpha, n = void 0 === a ? 1 : a, i = t.font, s = void 0 === i ? "arial" : i, c = t.size, u = void 0 === c ? "64px" : c, o = t.weight, h = void 0 === o ? "bold" : o, d = t.style, l = void 0 === d ? "normal" : d, f = t.align, p = void 0 === f ? "left" : f, x = t.baseline, v = void 0 === x ? "top" : x, w = t.dx, b = void 0 === w ? 0 : w, m = t.dy, g = void 0 === m ? 0 : m, y = t.content, k = void 0 === y ? "" : y;
            this.ctx.font = "".concat(l, " ").concat(h, " ").concat(u, " ").concat(s), this.ctx.setGlobalAlpha(n), 
            this.ctx.setFillStyle(r), this.ctx.setTextAlign(p), this.ctx.setTextBaseline(v), 
            this.ctx.fillText(k, b, g);
        }
    }
});