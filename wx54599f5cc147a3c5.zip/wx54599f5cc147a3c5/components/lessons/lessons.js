var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), a = t(require("../../@babel/runtime/helpers/asyncToGenerator")), r = getApp(), n = require("../../utils/wxRequest"), s = require("../../utils/moment/index.js"), o = require("../../utils/lunar"), i = require("../../utils/util"), u = i.parseDateCode, d = i.formatNumber;

Component({
    externalClasses: [ "icon-home", "icon-like", "icon-unlike", "icon-comment", "icon-share" ],
    properties: {
        lessons: {
            type: Array,
            value: [],
            observer: function(t, e) {
                var a = this;
                if (e.length !== t.length) {
                    var r = {
                        dates: this.makeDates(t)
                    }, n = t[t.length - 1];
                    if (e.length) {
                        var s = this.data.lessons.findIndex(function(t) {
                            return t.id === a.data.currentItemId;
                        });
                        r.current = s;
                    } else r.currentItemId = n.id, r.duration = 300;
                    this.setData(r), this.data.loading && setTimeout(function() {
                        a.setData({
                            loading: !1
                        });
                    }, 300);
                }
            }
        },
        theme: {
            type: String,
            value: "LIGHT"
        },
        firstlesson: {
            type: String
        },
        firstdate: {
            type: String
        }
    },
    data: {
        screenHeight: r.globalData.screenHeight,
        screenWidth: r.globalData.screenWidth,
        statusBarHeight: r.globalData.statusBarHeight,
        capsuleBarHeight: r.globalData.capsuleBarHeight,
        isFullScreen: r.globalData.isFullScreen,
        currentPages: [],
        loading: !0,
        dates: [],
        nextLessonComingRemain: "",
        nextLessonMonth: s().format("MM"),
        nextLessonDate: s().format("DD"),
        currentDate: "",
        currentWeekday: "",
        currentLdate: "",
        currentItemId: "tomorrow",
        duration: 0,
        current: 0
    },
    created: function() {
        var t = getCurrentPages();
        this.setData({
            currentPages: t
        }), this.setDateDisplay(this.data.firstdate), this.countDown();
    },
    methods: {
        goToLesson: function(t) {
            var e = t.currentTarget.dataset.lessonId;
            wx.navigateTo({
                url: "/pages/lesson/lesson?id=".concat(e)
            });
        },
        countDown: function() {
            var t = this, e = this.data.lessons, a = s();
            if (e.length) {
                var r = e[e.length - 1], n = u(r.date_by_day), o = s(n).add(1, "days"), i = o.diff(a, "seconds");
                i = i < 0 ? 0 : i;
                var l = d(parseInt(i / 3600)), c = d(parseInt(i / 60 % 60)), h = d(parseInt(i % 60)), f = s(i).format("".concat(l, " 时 ").concat(c, " 分 ").concat(h, " 秒"));
                this.setData({
                    nextLessonComingRemain: f,
                    nextLessonMonth: o.format("MM"),
                    nextLessonDate: o.format("DD")
                }), i || this.loadTomorrow();
            }
            clearTimeout(this.nextLessonComing), this.nextLessonComing = setTimeout(function() {
                t.nextLessonComing = null, t.countDown();
            }, 1e3);
        },
        loadTomorrow: function() {
            var t = (0, a.default)(e.default.mark(function t() {
                var a, r, o, i;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a = this.data.lessons, r = a[a.length - 1].date_by_day, o = s(u(r)).add(1, "days").format("YYYY-MM-DD"), 
                        t.next = 5, n({
                            url: "/v1/lessons/".concat(o)
                        });

                      case 5:
                        i = t.sent, "tomorrow" === this.data.currentItemId && this.setData({
                            loading: !0,
                            currentItemId: i.id
                        }), this.triggerEvent("loadtomorrow", [ i ]);

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        makeDates: function(t) {
            var e = t.map(function(t) {
                var e = u(t.date_by_day);
                return {
                    date: e,
                    day: e.split("-")[2]
                };
            });
            if (e.length) {
                var a = e[e.length - 1].date;
                a = s(a).add(1, "days").format("YYYY-MM-DD"), e.push({
                    date: a,
                    day: a.split("-")[2]
                });
            }
            return e;
        },
        setDateDisplay: function(t) {
            var e = o(t);
            this.setData({
                currentWeekday: "周".concat(e.cnDay),
                currentLdate: "".concat(e.lMonth, "月").concat(e.lDate),
                currentDate: t
            });
        },
        change: function(t) {
            var e = t.detail, a = e.currentItemId, r = e.current, n = this.data.lessons, o = n.find(function(t) {
                return t.id === a;
            }), i = {
                current: r,
                currentItemId: a
            };
            if ("tomorrow" !== a) {
                var d = u(o.date_by_day);
                this.setDateDisplay(d);
            } else {
                var l = n[n.length - 1], c = u(l.date_by_day);
                c = s(c).add(1, "days").format("YYYY-MM-DD"), this.setDateDisplay(c);
            }
            this.setData(i);
        },
        loadMore: function() {
            var t = (0, a.default)(e.default.mark(function t(a) {
                var r, o, i, d, l, c, h, f, m;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (r = a.detail, "tomorrow" != (o = r.currentItemId)) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", !1);

                      case 4:
                        if (i = this.data.lessons.find(function(t) {
                            return t.id === o;
                        }), d = u(i.date_by_day), l = s(d).subtract(10, "days"), (c = s(u(this.data.lessons[0].date_by_day))).subtract(1, "days"), 
                        !l.isBefore(c)) {
                            t.next = 16;
                            break;
                        }
                        return h = l.format("YYYY-MM-DD"), f = c.format("YYYY-MM-DD"), t.next = 14, n({
                            url: "/v1/lessons",
                            data: {
                                from: h,
                                to: f
                            }
                        });

                      case 14:
                        m = t.sent, this.triggerEvent("unshiftlessons", m);

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(),
        onScroll: function(t) {
            var e = t.detail, a = t.currentTarget.dataset.lessonId, r = e.scrollTop;
            this.triggerEvent("scroll", {
                scrollTop: r,
                lessonId: a
            });
        }
    }
});