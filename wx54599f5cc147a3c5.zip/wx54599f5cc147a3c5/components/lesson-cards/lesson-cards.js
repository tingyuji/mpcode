var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), a = t(require("../../@babel/runtime/helpers/asyncToGenerator")), n = getApp(), r = require("../../utils/wxRequest"), s = require("../../utils/moment/index.js"), o = require("../../utils/lunar"), i = require("../../utils/util"), u = i.parseDateCode, d = i.formatNumber;

Component({
    externalClasses: [ "icon-semicolon" ],
    properties: {
        lessons: {
            type: Array,
            value: [],
            observer: function(t, e) {
                var a = this;
                if (e.length !== t.length) {
                    var n = {
                        dates: this.makeDates(t)
                    }, r = t[t.length - 1];
                    if (e.length) {
                        var s = this.data.lessons.findIndex(function(t) {
                            return t.id === a.data.currentItemId;
                        });
                        n.current = s;
                    } else n.currentItemId = r.id, n.duration = 300;
                    this.setData(n), this.data.loading && setTimeout(function() {
                        a.setData({
                            loading: !1
                        });
                    }, 300);
                }
            }
        },
        theme: {
            type: String,
            value: "LIGHT"
        }
    },
    data: {
        screenHeight: n.globalData.screenHeight,
        screenWidth: n.globalData.screenWidth,
        statusBarHeight: n.globalData.statusBarHeight,
        capsuleBarHeight: n.globalData.capsuleBarHeight,
        isFullScreen: n.globalData.isFullScreen,
        loading: !0,
        dates: [],
        nextLessonComingRemain: "",
        nextLessonMonth: s().format("MM"),
        nextLessonDate: s().format("DD"),
        currentDate: "",
        currentWeekday: "",
        currentLdate: "",
        currentItemId: "tomorrow",
        duration: 0,
        current: 0
    },
    created: function() {
        var t = s().format("YYYY-MM-DD");
        this.setDateDisplay(t), this.countDown();
    },
    methods: {
        goToLesson: function(t) {
            var e = t.currentTarget.dataset, a = e.lessonId, n = e.date;
            wx.navigateTo({
                url: "/pages/lesson/lesson?id=".concat(a, "&date=").concat(n)
            });
        },
        countDown: function() {
            var t = this, e = this.data.lessons, a = s();
            if (e.length) {
                var n = e[e.length - 1], r = u(n.date_by_day), o = s(r).add(1, "days"), i = o.diff(a, "seconds");
                i = i < 0 ? 0 : i;
                var c = d(parseInt(i / 3600)), l = d(parseInt(i / 60 % 60)), h = d(parseInt(i % 60)), f = s(i).format("".concat(c, " 时 ").concat(l, " 分 ").concat(h, " 秒"));
                this.setData({
                    nextLessonComingRemain: f,
                    nextLessonMonth: o.format("MM"),
                    nextLessonDate: o.format("DD")
                }), i || this.loadTomorrow();
            }
            clearTimeout(this.nextLessonComing), this.nextLessonComing = setTimeout(function() {
                t.nextLessonComing = null, t.countDown();
            }, 1e3);
        },
        loadTomorrow: function() {
            var t = (0, a.default)(e.default.mark(function t() {
                var a, n, o, i;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a = this.data.lessons, n = a[a.length - 1].date_by_day, o = s(u(n)).add(1, "days").format("YYYY-MM-DD"), 
                        t.next = 5, r({
                            url: "/v1/lessons/".concat(o)
                        });

                      case 5:
                        i = t.sent, "tomorrow" === this.data.currentItemId && this.setData({
                            loading: !0,
                            currentItemId: i.id
                        }), this.triggerEvent("loadtomorrow", [ i ]);

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        makeDates: function(t) {
            var e = t.map(function(t) {
                var e = u(t.date_by_day);
                return {
                    date: e,
                    day: e.split("-")[2]
                };
            });
            if (e.length) {
                var a = e[e.length - 1].date;
                a = s(a).add(1, "days").format("YYYY-MM-DD"), e.push({
                    date: a,
                    day: a.split("-")[2]
                });
            }
            return e;
        },
        setDateDisplay: function(t) {
            var e = o(t);
            this.setData({
                currentWeekday: "周".concat(e.cnDay),
                currentLdate: "".concat(e.lMonth, "月").concat(e.lDate),
                currentDate: t
            });
        },
        change: function(t) {
            var e = t.detail, a = e.currentItemId, n = e.current, r = this.data.lessons, o = r.find(function(t) {
                return t.id === a;
            }), i = {
                current: n,
                currentItemId: a
            };
            if ("tomorrow" !== a) {
                var d = u(o.date_by_day);
                this.setDateDisplay(d);
            } else {
                var c = r[r.length - 1], l = u(c.date_by_day);
                l = s(l).add(1, "days").format("YYYY-MM-DD"), this.setDateDisplay(l);
            }
            this.setData(i);
        },
        loadMore: function() {
            var t = (0, a.default)(e.default.mark(function t(a) {
                var n, o, i, d, c, l, h, f, m;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (n = a.detail, "tomorrow" != (o = n.currentItemId)) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", !1);

                      case 4:
                        if (i = this.data.lessons.find(function(t) {
                            return t.id === o;
                        }), d = u(i.date_by_day), c = s(d).subtract(10, "days"), (l = s(u(this.data.lessons[0].date_by_day))).subtract(1, "days"), 
                        !c.isBefore(l)) {
                            t.next = 16;
                            break;
                        }
                        return h = c.format("YYYY-MM-DD"), f = l.format("YYYY-MM-DD"), t.next = 14, r({
                            url: "/v1/lessons",
                            data: {
                                from: h,
                                to: f
                            }
                        });

                      case 14:
                        m = t.sent, this.triggerEvent("unshiftlessons", m);

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }()
    }
});