var t = require("../../utils/layout_calculator");

Component({
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        },
        hideBtns: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        layout: t(),
        showHomeBtn: !1
    },
    pageLifetimes: {
        show: function() {
            var t = 1 === getCurrentPages().length;
            this.setData({
                showHomeBtn: t
            });
        }
    },
    methods: {
        onTapTopBar: function() {
            this.triggerEvent("taptopbar");
        }
    }
});