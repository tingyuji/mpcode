var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/typeof")), n = e(require("../../@babel/runtime/regenerator")), i = e(require("../../@babel/runtime/helpers/asyncToGenerator")), o = require("../../utils/event"), r = getApp();

Component({
    externalClasses: [ "ex-icon-moon", "ex-icon-sun", "ex-icon-pencil" ],
    properties: {
        theme: {
            type: String,
            value: "LIGHT"
        },
        show: {
            type: Boolean,
            value: !1
        },
        lesson: {
            type: Object
        }
    },
    data: {
        isFullScreen: r.globalData.isFullScreen,
        appConfig: {}
    },
    ready: function() {
        this.initConfig();
    },
    methods: {
        initConfig: function() {
            var e = this;
            r.globalData.config ? this.setData({
                appConfig: r.globalData.config
            }) : o.on("getConfig", this, function() {
                e.setData({
                    appConfig: r.globalData.config
                });
            });
        },
        cancel: function() {
            this.triggerEvent("hide");
        },
        goToWriteComment: function() {
            var e = this.data.lesson.id;
            wx.navigateTo({
                url: "/pages/comment-creator/comment-creator?id=".concat(e)
            }), this.triggerEvent("hide");
        },
        changeTheme: function() {
            this.triggerEvent("changetheme"), this.triggerEvent("hide");
        },
        checkAuth: function(e) {
            wx.getSetting({
                fail: function(t) {
                    e(!1);
                },
                success: function(t) {
                    t.authSetting["scope.writePhotosAlbum"] || void 0 === t.authSetting["scope.writePhotosAlbum"] ? e(!0) : e(!1);
                }
            });
        },
        openPhotosAlbumAuth: function(e) {
            wx.showModal({
                title: "需要打开保存到相册的权限才能使用该功能",
                success: function(t) {
                    t.confirm && wx.openSetting({
                        success: function(t) {
                            (t.authSetting["scope.writePhotosAlbum"] || void 0 === t.authSetting["scope.writePhotosAlbum"]) && e();
                        }
                    });
                }
            });
        },
        shareToMoment: function() {
            var e = (0, i.default)(n.default.mark(function e() {
                var t = this;
                return n.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.checkAuth(function(e) {
                            e ? (t.triggerEvent("choose", {
                                method: "moment"
                            }), t.triggerEvent("hide")) : t.openPhotosAlbumAuth(function() {
                                t.triggerEvent("choose", {
                                    method: "moment"
                                }), t.triggerEvent("hide");
                            });
                        });

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        onGotUserInfo: function() {
            var e = (0, i.default)(n.default.mark(function e(i) {
                var o;
                return n.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return r.userInfoReadyCallback = function() {
                            wx.hideLoading(), i && i();
                        }, wx.showLoading({
                            title: "正在授权"
                        }), e.prev = 2, e.next = 5, r.userInit();

                      case 5:
                        e.next = 13;
                        break;

                      case 7:
                        e.prev = 7, e.t0 = e.catch(2), wx.hideLoading(), o = "未知错误", "string" == typeof e.t0 ? o = e.t0 : "object" === (0, 
                        t.default)(e.t0) && (o = e.t0.errMsg ? e.t0.errMsg : JSON.stringify(e.t0)), wx.showToast({
                            title: o,
                            icon: "none"
                        });

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 2, 7 ] ]);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }()
    }
});