var e = require("743567A7539B32CF12530FA0A59940C3.js"), r = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    GetSessionKey: function(o, t) {
        var a = e.baseHost + "/api/mp/gsk";
        r.req(a, o, "POST", t);
    },
    wxGetorgInfo: function(o, t) {
        var a = e.baseHost + "/api/mp/getorginfo/" + o;
        r.req(a, null, "GET", t);
    },
    getOrgProjectList: function(o, t, a, s) {
        var i = e.baseHost + "/api/mp/getorgprojects/" + o + "/" + a + (null == t ? "" : "/" + t);
        r.req(i, null, "GET", s);
    },
    getOrgProject: function(o, t, a) {
        var s = e.baseHost + "/api/mp/getorgproject/" + o + "/" + t;
        r.req(s, null, "GET", a);
    },
    uploadOcrIdCrad: function(o, t, a, s, i) {
        var n = e.baseHost + "/api/mp/IdCradInfo";
        r.ulf(n, o, t, a, s, i);
    },
    serch: function(o, t, a) {
        var s = e.baseHost + "/api/mp/serch/" + o + "/" + t;
        r.req(s, null, "GET", a);
    },
    upLoadImg: function(o, t, a, s, i) {
        var n = e.baseHost + "/api/mp/upLoadImg";
        r.ulf(n, o, t, a, s, i);
    },
    verifyvode: function(o, t, a, s) {
        var i = e.baseHost + "/api/mp/verifyvode/" + o + "/" + t + "/" + a;
        r.req(i, null, "GET", s);
    },
    getWxPhone: function(o, t) {
        var a = e.baseHost + "/api/mp/getWxPhone";
        r.req(a, o, "POST", t);
    },
    wxorderquery: function(o, t) {
        var a = e.baseHost + "/api/mp/wxorderquery";
        r.req(a, o, "POST", t);
    },
    wxRegisterOrgs: function(o, t) {
        var a = e.baseHost + "/api/mp/wxRegisterOrgs";
        r.req(a, o, "POST", t);
    },
    qrcodestate: function(o, t, a) {
        var s = e.baseHost + "/api/mp/qrcodestate/" + o + "/" + t;
        r.req(s, null, "GET", a);
    },
    orgLogin: function(o, t) {
        var a = e.baseHost + "/api/mp/orgLogin";
        r.req(a, o, "POST", t);
    },
    queryCertQrCode: function(o, t) {
        var a = e.baseHost + "/api/mp/queryCertQrCode";
        r.req(a, o, "POST", t);
    },
    saveCertQrCode: function(o, t) {
        var a = e.baseHost + "/api/mp/saveCertQrCode";
        r.req(a, o, "POST", t);
    },
    getphotos: function(o, t) {
        var a = e.baseHost + "/api/mp/getphotos/" + o;
        r.req(a, null, "GET", t);
    },
    QuesryGrade: function(o, t) {
        var a = e.baseHost + "/api/mp/QuesryGrade";
        r.req(a, o, "POST", t);
    },
    SaveInvoice: function(o, t) {
        var a = e.baseHost + "/api/mp/SaveInvoice";
        r.req(a, o, "POST", t);
    },
    SaveMailAderress: function(o, t) {
        var a = e.baseHost + "/api/mp/SaveMailAderress";
        r.req(a, o, "POST", t);
    },
    NewNotify: function(o, t) {
        var a = e.baseHost + "/api/mp/NewNotify";
        r.req(a, o, "POST", t);
    },
    getnotifys: function(o, t) {
        var a = e.baseHost + "/api/mp/getnotifys/" + o;
        r.req(a, null, "GET", t);
    },
    GetNotify: function(o, t) {
        var a = e.baseHost + "/api/mp/GetNotify/" + o;
        r.req(a, null, "GET", t);
    },
    submitNotify: function(o, t) {
        var a = e.baseHost + "/api/mp/notifyuser";
        r.req(a, o, "POST", t);
    }
};