var e, t = require("@babel/runtime/helpers/defineProperty.js"), s = require("743567A7539B32CF12530FA0A59940C3.js"), i = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js"), u = function(e, t) {
    var u = s.simulateHost + "/simulate/GetPractical";
    i.req(u, e, "POST", t);
};

module.exports = (t(e = {
    wxLogin: function(e, t) {
        var u = s.simulateHost + "/simulate/wxvLogin";
        i.req(u, e, "POST", t);
    },
    upuser: function(e, t) {
        var u = s.simulateHost + "/simulate/upuser";
        i.req(u, e, "POST", t);
    },
    queryQuestion: function(e, t) {
        var u = s.simulateHost + "/simulate/queryquestion";
        i.req(u, e, "POST", t);
    },
    queryQuestions: function(e, t) {
        var u = s.simulateHost + "/simulate/queryquestions";
        i.req(u, e, "POST", t);
    },
    seqreadlist: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/getalikelist/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    setsequenceindex: function(e, t) {
        var u = s.simulateHost + "/simulate/setsequenceindex";
        i.req(u, e, "POST", t);
    },
    seqreadrest: function(e, t, u) {
        var a = s.simulateHost + "/simulate/seqreadrest/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetUserSearch: function(e, t) {
        var u = s.simulateHost + "/simulate/GetUserSearch/" + e;
        i.req(u, null, "GET", t);
    },
    SetErrorSimulateIndex: function(e, t) {
        var u = s.simulateHost + "/simulate/SetErrorSimulateIndex";
        i.req(u, e, "POST", t);
    },
    RestErrorRecord: function(e, t) {
        var u = s.simulateHost + "/simulate/RestErrorRecord/" + e;
        i.req(u, null, "GET", t);
    },
    RemoveErrorSimulate: function(e, t, u) {
        var a = s.simulateHost + "/simulate/RemoveErrorSimulate/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    RemoveAllErrorSimulate: function(e, t) {
        var u = s.simulateHost + "/simulate/RemoveAllErrorSimulate/" + e;
        i.req(u, null, "GET", t);
    },
    AddErrorQuestionBank: function(e, t) {
        var u = s.simulateHost + "/simulate/AddErrorQuestionBank";
        i.req(u, e, "POST", t);
    },
    GetAudit: function(e, t) {
        var u = s.simulateHost + "/simulate/Audit/" + e;
        i.req(u, null, "GET", t);
    },
    getUserInfo: function(e, t) {
        var u = s.simulateHost + "/simulate/getuserinfo/" + e;
        i.req(u, null, "GET", t);
    },
    getQuestionArea: function(e) {
        var t = s.simulateHost + "/simulate/getquestionarea";
        i.req(t, null, "GET", e);
    },
    feedback: function(e, t) {
        var u = s.simulateHost + "/simulate/feedback";
        i.req(u, e, "POST", t);
    },
    getRecharge: function(e) {
        var t = s.simulateHost + "/simulate/getrecharge";
        i.req(t, null, "GET", e);
    },
    getAllClassify: function(e) {
        var t = s.simulateHost + "/simulate/getallclassify";
        i.req(t, null, "GET", e);
    },
    updateSales: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/updateSales/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getSimulateRewind: function(e) {
        var t = s.simulateHost + "/simulate/getsimulaterewind";
        i.req(t, null, "GET", e);
    },
    delSalesman: function(e, t, u) {
        var a = s.simulateHost + "/simulate/delSalesman/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    restSequenceTestIndex: function(e, t) {
        var u = s.simulateHost + "/simulate/restsequencetestindex/" + e;
        i.req(u, null, "GET", t);
    },
    easyErrorRankingList: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/easyErrorRankingList/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getSequenceQuestionSpecial: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/getsequencequestionspecial/" + e + "/" + t + "/" + u + "/" + a;
        i.req(n, null, "GET", l);
    },
    OrgSituation: function(e, t, u) {
        var a = s.simulateHost + "/simulate/orgsituation/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    getTodayUser: function(e, t, u) {
        var a = s.simulateHost + "/simulate/getTodayUser/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    setSpecialQusetion: function(e, t) {
        var u = s.simulateHost + "/simulate/setspecialqusetion";
        i.req(u, e, "POST", t);
    },
    OrgSituationSearch: function(e, t, u) {
        var a = s.simulateHost + "/simulate/orgsituationsearch/" + e + "/" + encodeURI(t);
        i.req(a, null, "GET", u);
    },
    GetUserSimulation: function(e, t) {
        var u = s.simulateHost + "/simulate/GetUserSimulation/" + e;
        i.req(u, null, "GET", t);
    },
    RestSpecialTestIndex: function(e, t) {
        var u = s.simulateHost + "/simulate/RestSpecialTestIndex/" + e;
        i.req(u, null, "GET", t);
    },
    specialStatistics: function(e, t) {
        var u = s.simulateHost + "/simulate/specialstatistics/" + e;
        i.req(u, null, "GET", t);
    },
    updateOnlineTime: function(e, t) {
        var u = s.simulateHost + "/simulate/onlinetime";
        i.req(u, null, "GET", t);
    },
    updateTime: function(e, t) {
        var u = s.simulateHost + "/simulate/updatetime/" + e;
        i.req(u, null, "GET", t);
    },
    applyOrgSalesman: function(e, t) {
        var u = s.simulateHost + "/simulate/applyorgsalesman";
        i.req(u, e, "POST", t);
    },
    getQuestionBlank: function(e, t, u, a) {
        var l = "";
        l = u ? s.simulateHost + "/simulate/getquestionclassifyr/" + e + "/" + t + "/" + u : s.simulateHost + "/simulate/getquestionclassifyr/" + e + "/" + t, 
        i.req(l, null, "GET", a);
    },
    setUserDefQuestion: function(e, t) {
        var u = s.simulateHost + "/simulate/setuserdef";
        i.req(u, e, "POST", t);
    },
    getUserVipInfo: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/getuservipinfo/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getSequenceQuestion: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/getquestion/" + e + "/" + t + "/" + u + "/" + a;
        i.req(n, null, "GET", l);
    },
    setSequenceQusetion: function(e, t) {
        var u = s.simulateHost + "/simulate/setsequencequsetion";
        i.req(u, e, "POST", t);
    },
    getSequencePaperList: function(e, t) {
        var u = s.simulateHost + "/simulate/GetSequencePaperList/" + e;
        i.req(u, null, "GET", t);
    },
    getSimulateTestPaper: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/getsimulatetestpaper/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    saveSimulateRewinding: function(e, t) {
        var u = s.simulateHost + "/simulate/savesimulaterewinding";
        i.req(u, e, "POST", t);
    },
    getrewindings: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/getrewindingsbypage/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getRewindingDetail: function(e, t) {
        var u = s.simulateHost + "/simulate/getrewindingdetail/" + e;
        i.req(u, null, "GET", t);
    },
    addUserErrorQuestion: function(e, t) {
        var u = s.simulateHost + "/simulate/adderrorquestion";
        i.req(u, e, "POST", t);
    },
    getErrorQuestion: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/geterrorquestion/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getVipCrad: function(e, t, u) {
        var a = s.simulateHost + "/simulate/getvipcrad/" + e;
        t && (a = s.simulateHost + "/simulate/getvipcrad/" + e + "/" + t), i.req(a, null, "GET", u);
    },
    getTimeLimitTestPaper: function(e, t, u) {
        var a = s.simulateHost + "/simulate/gettimelimittestpaper/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    addgetTimeLimit: function(e, t) {
        var u = s.simulateHost + "/simulate/addgettimelimit";
        i.req(u, e, "POST", t);
    },
    getUserStatistics: function(e, t) {
        var u = s.simulateHost + "/simulate/getuserstatistics/" + e;
        i.req(u, null, "GET", t);
    },
    deleteerrorquestion: function(e, t) {
        var u = s.simulateHost + "/simulate/deleteerrorquestion";
        i.req(u, e, "POST", t);
    },
    syncBlance: function(e, t, u) {
        var a = s.simulateHost + "/simulate/syncblance/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    getQequenceQuestion: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/getsequencepages/" + e + "/" + t + "/" + u + "/" + a;
        i.req(n, null, "GET", l);
    },
    bindOrgCode: function(e, t) {
        var u = s.simulateHost + "/simulate/bindorgcode";
        i.req(u, e, "POST", t);
    },
    orgLoign: function(e, t) {
        var u = s.simulateHost + "/simulate/orglogin";
        i.req(u, e, "POST", t);
    },
    getRecordTaday: function(e, t) {
        var u = s.simulateHost + "/simulate/getrecordtaday/" + e;
        i.req(u, null, "GET", t);
    },
    getRecordCashExteact: function(e, t) {
        var u = s.simulateHost + "/simulate/getrecordcashExteact/" + e;
        i.req(u, null, "GET", t);
    },
    cashExtract: function(e, t) {
        var u = s.simulateHost + "/simulate/cashextract";
        i.req(u, e, "POST", t);
    },
    newOrgEnter: function(e, t) {
        var u = s.simulateHost + "/simulate/neworgenter";
        i.req(u, e, "POST", t);
    },
    getOrgStatistics: function(e, t) {
        var u = s.simulateHost + "/simulate/getorgstatistics/" + e;
        i.req(u, null, "GET", t);
    },
    getOrgSalesman: function(e, t) {
        var u = s.simulateHost + "/simulate/getOrgSales/" + e;
        i.req(u, null, "GET", t);
    },
    bdspeech: function(e, t) {
        var u = s.simulateHost + "/simulate/bdspeech";
        i.req(u, e, "POST", t);
    },
    GetQuestionRetrainingState: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetQuestionRetrainingState/" + e + "/" + t + "/2";
        i.req(a, null, "GET", u);
    },
    GetNotify: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetNotify/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetPractical: u,
    getErrorSimulateQuestion: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/GetErrorSimulate/" + e + "/" + t + "/" + u + "/" + a;
        i.req(n, null, "GET", l);
    },
    GetUserTimeAndGroud: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetUserTimeAndGroud/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetHelp: function(e, t) {
        var u = s.simulateHost + "/simulate/GetHelp/" + e;
        i.req(u, null, "GET", t);
    },
    cradLogin: function(e, t) {
        var u = s.simulateHost + "/simulate/CradLogin";
        i.req(u, e, "POST", t);
    },
    GetUserProjectInfo: function(e, t) {
        var u = s.simulateHost + "/simulate/GetUserProjectInfo/" + e;
        i.req(u, null, "GET", t);
    },
    GetAutonym: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetAutonym/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    Autonym: function(e, t) {
        var u = s.simulateHost + "/simulate/Autonym";
        i.req(u, e, "POST", t);
    },
    AkxAutonym: function(e, t) {
        var u = s.simulateHost + "/simulate/AkxAutonym";
        i.req(u, e, "POST", t);
    },
    getUserData: function(e, t) {
        var u = s.simulateHost + "/simulate/getuserdatainfo";
        i.req(u, null, "GET", t);
    },
    CheckProjectSync: function(e, t) {
        var u = s.simulateHost + "/simulate/CheckProjectSync/" + e;
        i.req(u, null, "GET", t);
    },
    ChangeDefPeoject: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/ChangeDefPeoject/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    getuservips: function(e, t, u) {
        var a = s.simulateHost + "/simulate/getuservips/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    UpdateUserName: function(e, t) {
        var u = s.simulateHost + "/simulate/UpdateUserName";
        i.req(u, e, "POST", t);
    },
    ActiveVipCrad: function(e, t, u) {
        var a = s.simulateHost + "/simulate/ActiveVipCrad/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetProjectImportUser: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetProjectImportUser/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetQuestionCatalogue: function(e, t) {
        var u = s.simulateHost + "/simulate/GetQuestionCatalogue/" + e;
        i.req(u, null, "GET", t);
    },
    SearchProject: function(e, t) {
        var u = s.simulateHost + "/simulate/SearchProject";
        i.req(u, e, "POST", t);
    },
    myorders: function(e, t) {
        var u = s.simulateHost + "/simulate/myorders/" + e;
        i.req(u, null, "GET", t);
    },
    myorderdal: function(e, t) {
        var u = s.simulateHost + "/simulate/myorderdal/" + e;
        i.req(u, null, "GET", t);
    },
    GetCollect: function(e, t, u, a) {
        var l = s.simulateHost + "/simulate/GetCollect/" + e + "/" + t + "/" + u;
        i.req(l, null, "GET", a);
    },
    AddCollect: function(e, t) {
        var u = s.simulateHost + "/simulate/AddCollect";
        i.req(u, e, "POST", t);
    },
    setcollectquestion: function(e, t) {
        var u = s.simulateHost + "/simulate/setcollectquestion";
        i.req(u, e, "POST", t);
    },
    restcollectindex: function(e, t) {
        var u = s.simulateHost + "/simulate/restcollectindex/" + e;
        i.req(u, null, "GET", t);
    },
    setcollectindex: function(e, t) {
        var u = s.simulateHost + "/simulate/setcollectindex";
        i.req(u, e, "POST", t);
    },
    RemoveCollectSimulate: function(e, t, u) {
        var a = s.simulateHost + "/simulate/RemoveCollectSimulate/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    GetSreacVip: function(e, t, u) {
        var a = s.simulateHost + "/simulate/GetSreacVip/" + e + "/" + t;
        i.req(a, null, "GET", u);
    },
    QuestionSreach: function(e, t) {
        var u = s.simulateHost + "/simulate/QuestionSreach";
        i.req(u, e, "POST", t);
    },
    QuestionWordPicOcr: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/QuestionWordPicOcr";
        i.ulf(n, e, t, u, a, l);
    },
    QuestionSreachRec: function(e, t, u, a, l) {
        var n = s.simulateHost + "/simulate/QuestionSreachRec";
        i.ulf(n, e, t, u, a, l);
    },
    getquestioncollect: function(e, t) {
        var u = s.simulateHost + "/simulate/getquestioncollect";
        i.req(u, e, "POST", t);
    }
}, "GetPractical", u), t(e, "getseqactual", function(e, t, u, a) {
    var l = s.simulateHost + "/simulate/getseqactual/" + e + "/" + t + "/" + u;
    i.req(l, null, "GET", a);
}), t(e, "GetQuestion", function(e, t) {
    var u = s.simulateHost + "/simulate/GetQuestion/" + e;
    i.req(u, null, "GET", t);
}), t(e, "getLikes", function(e, t, u, a) {
    var l = s.simulateHost + "/simulate/getlikes/" + e + "/" + t + "/" + u;
    i.req(l, null, "GET", a);
}), t(e, "setReadQuestion", function(e, t, u, a) {
    var l = s.simulateHost + "/simulate/setreadquestion/" + e + "/" + t + "/" + u;
    i.req(l, null, "GET", a);
}), t(e, "getPhoneNumber", function(e, t) {
    var u = s.simulateHost + "/simulate/getphonenumber";
    i.req(u, e, "POST", t);
}), t(e, "RemoveAllCollect", function(e, t, u) {
    var a = s.simulateHost + "/simulate/RemoveAllCollect/" + e + "/" + t;
    i.req(a, null, "GET", u);
}), t(e, "getOftenQuestion", function(e, t, u, a) {
    var l = s.simulateHost + "/simulate/GetOftenTestQuestion/" + e + "/" + t + "/" + u;
    i.req(l, null, "GET", a);
}), t(e, "orderCardMail", function(e, t) {
    var u = s.simulateHost + "/simulate/ordercardmail";
    i.req(u, e, "POST", t);
}), e);