var e = require("743567A7539B32CF12530FA0A59940C3.js"), i = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    getvideoinfo: function(t, o) {
        var u = e.simulateHost + "/video/getvideoinfo/" + t;
        i.req(u, null, "GET", o);
    },
    getvideos: function(t) {
        var o = e.simulateHost + "/video/getvideos";
        i.req(o, null, "GET", t);
    },
    getvideovip: function(t, o, u) {
        var s = e.simulateHost + "/video/getvideovip/" + t + "/" + o;
        i.req(s, null, "GET", u);
    },
    GetQuestionVideo: function(t, o, u, s) {
        var n = e.simulateHost + "/simulate/GetQuestionVideo/" + t + "/" + o + "/" + u;
        i.req(n, null, "GET", s);
    },
    SetQuestionVideIndex: function(t, o) {
        var u = e.simulateHost + "/simulate/SetQuestionVideIndex";
        i.req(u, t, "POST", o);
    }
};