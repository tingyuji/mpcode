var e = require("../../D6C5E9D0539B32CFB0A381D7EAF940C3.js");

Component({
    properties: {
        userid: {
            type: String
        },
        projectid: {
            type: String
        }
    },
    data: {
        recording: !1,
        intervalId: 0,
        proc: 0,
        recordtime: 0,
        options: {
            duration: 6e4,
            sampleRate: 16e3,
            numberOfChannels: 1,
            encodeBitRate: 48e3,
            format: "wav"
        },
        recorderManager: null
    },
    methods: {
        cancelRecord: function() {
            this.triggerEvent("cancel"), this.data.recorderManager && this.data.recorderManager.stop();
        },
        startRecord: function() {
            var t = this;
            this.setData({
                recording: !0
            }), this.data.intervalId = setInterval(function() {
                var e = t.data.recordtime + 50;
                t.setData({
                    recordtime: e,
                    proc: e / t.data.options.duration
                }), t.data.proc >= 1 && (clearInterval(t.data.intervalId), t.setData({
                    recording: !1,
                    proc: 0
                }));
            }, 50), this.data.recorderManager = wx.getRecorderManager(), this.data.recorderManager.onStart(function(e) {
                console.log("开始", e);
            }), this.data.recorderManager.onStop(function(r) {
                console.log("停止", r.tempFilePath);
                var a = {
                    userId: t.properties.userid,
                    ProjectId: t.properties.projectid
                };
                wx.showLoading({
                    title: "正在识别内容..."
                }), e.QuestionSreachRec(r.tempFilePath, a, function(e) {
                    wx.hideLoading(), 0 == e.state ? t.triggerEvent("result", {
                        data: e.data
                    }) : wx.showToast({
                        title: r.data + "",
                        icon: "none"
                    });
                });
            }), this.data.recorderManager.onError(function(e) {
                console.log("错误", e);
            }), this.data.recorderManager.start(this.data.options);
        }
    }
});