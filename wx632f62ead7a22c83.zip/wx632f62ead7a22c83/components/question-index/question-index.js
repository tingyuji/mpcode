Component({
    properties: {
        indexlist: {
            type: Object,
            value: null
        },
        color: {
            type: String,
            value: null
        },
        curindex: {
            type: Number,
            value: 0
        },
        sum: {
            type: Number,
            value: 0
        },
        vip: {
            type: Boolean,
            value: 0
        },
        answerShow: {
            type: String,
            value: 0
        }
    },
    data: {
        scrollheight: 0
    },
    methods: {
        QuestionIndex: function(e) {
            var t = e.currentTarget.dataset.indexid;
            this.triggerEvent("questionindex", {
                tempid: t
            });
        },
        CancelIndex: function() {
            this.triggerEvent("cancelindex");
        }
    },
    lifetimes: {
        ready: function() {
            var e = this;
            this.createSelectorQuery().select("#container").boundingClientRect(function(t) {
                e.setData({
                    scrollheight: t.height - 100
                });
            }).exec();
        }
    }
});