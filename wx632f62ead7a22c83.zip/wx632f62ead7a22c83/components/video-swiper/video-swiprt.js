var t = require("../../@babel/runtime/helpers/objectSpread2"), e = getApp();

Component({
    options: {
        addGlobalClass: !0,
        pureDataPattern: /^_/
    },
    properties: {
        index: {
            type: Number,
            value: 0,
            observer: function(t) {
                if (!this.data.vip && this.data.prevQueue.length >= 7) return this.vipHit(), !1;
                t < 0 && this._videoIndexChanged(t - 1);
            }
        },
        duration: {
            type: Number,
            value: 200
        },
        easingFunction: {
            type: String,
            value: "default"
        },
        loop: {
            type: Boolean,
            value: !1
        },
        autoplay: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.data._videoContexts.forEach(function(t) {
                    t.pause();
                });
            }
        },
        play: {
            type: Boolean,
            value: !0,
            observer: function(t) {
                var e = this;
                t && this.data._videoContexts.forEach(function(t, i) {
                    i === e.data.curVideoIndex && t.play();
                });
            }
        },
        videoList: {
            type: Array,
            value: [],
            observer: function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                0 != t.length && this._videoListChanged(t);
            }
        }
    },
    data: {
        videolist: [],
        nextQueue: [],
        prevQueue: [],
        curQueue: [],
        circular: !1,
        _last: 1,
        _change: -1,
        _invalidUp: 0,
        _invalidDown: 0,
        _videoContexts: [],
        interval: 2e4,
        curVideoIndex: 0,
        vip: null,
        userInfo: null
    },
    lifetimes: {
        attached: function() {
            this.setData({
                vip: e.globalData.vip,
                userInfo: e.globalData.userInfo
            }), console.log(this.data.userInfo), this.data._videoContexts = [ wx.createVideoContext("video_0", this), wx.createVideoContext("video_1", this), wx.createVideoContext("video_2", this) ];
        }
    },
    methods: {
        _videoListChanged: function(t) {
            var e = this, i = this.data;
            this.data.videolist = t, i.prevQueue = t.splice(0, this.properties.index), t.forEach(function(t) {
                i.nextQueue.push(t);
            }), 0 === i.curQueue.length && this.setData({
                curQueue: i.nextQueue.splice(0, 3)
            }, function() {
                i.curQueue.length > 0 && (e.triggerEvent("change", {
                    activeId: i.curQueue[1].id
                }), e.playCurrent(1));
            });
        },
        _videoIndexChanged: function(t) {
            var e = this, i = this.data;
            if (0 != i.nextQueue.length) {
                var a = this.data.videoList;
                i.prevQueue = a.splice(0, t), i.nextQueue = a, i.nextQueue.length < 3 || this.setData({
                    curQueue: i.nextQueue.splice(0, 3)
                }, function() {
                    i.curQueue.length > 0 && (e.triggerEvent("change", {
                        activeId: i.curQueue[1].id
                    }), e.playCurrent(1));
                });
            }
        },
        animationfinish: function(t) {
            var e = this.data, i = e._last, a = e._change, n = e.curQueue, o = e.prevQueue, u = e.nextQueue, r = t.detail.current, s = r - i;
            if (0 !== s) {
                this.data._last = r, this.playCurrent(r), this.triggerEvent("change", {
                    activeId: n[r].id
                });
                var d = 1 === s || -2 === s ? "up" : "down";
                if ("up" === d) {
                    if (!this.data.vip && this.data.prevQueue.length >= 7) return this.vipHit(), !1;
                    if (0 === this.data._invalidDown) {
                        var h = (a + 1) % 3, c = u.shift(), p = n[h];
                        c ? (o.push(p), n[h] = c, this.data._change = h) : this.data._invalidUp += 1;
                    } else this.data._invalidDown -= 1;
                }
                if ("down" === d) if (0 === this.data._invalidUp) {
                    var l = a, v = n[l], g = o.pop();
                    g ? (n[l] = g, u.unshift(v), this.data._change = (l - 1 + 3) % 3) : this.data._invalidDown += 1;
                } else this.data._invalidUp -= 1;
                var f = !0;
                0 === u.length && 0 !== r && (f = !1), 0 === o.length && 2 !== r && (f = !1), this.setData({
                    curQueue: n,
                    circular: f
                });
            }
        },
        playCurrent: function(t) {
            this.data.curQueue.length > 0 && 1 == this.properties.autoplay && this.setData({
                interval: 1e3 * (this.data.curQueue[t].duration + 1)
            }), this.data._videoContexts.forEach(function(e, i) {
                i !== t ? e.stop() : e.play();
            });
        },
        onPlay: function(t) {
            this.trigger(t, "play");
        },
        onPause: function(t) {
            this.data.curVideoIndex = t.target.dataset.index, this.trigger(t, "pause");
        },
        onEnded: function(t) {
            this.trigger(t, "ended");
        },
        onError: function(t) {
            this.trigger(t, "error");
        },
        onTimeUpdate: function(t) {
            this.trigger(t, "timeupdate");
        },
        onWaiting: function(t) {
            this.trigger(t, "wait");
        },
        onProgress: function(t) {
            this.trigger(t, "progress");
        },
        onLoadedMetaData: function(t) {
            this.trigger(t, "loadedmetadata");
        },
        trigger: function(e, i) {
            var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, n = e.detail, o = e.target.dataset.id;
            this.triggerEvent(i, Object.assign(t(t({}, n), {}, {
                activeId: o
            }), a));
        },
        videoPlay: function(t) {
            this.data._videoContexts.forEach(function(t, e) {
                t.pause();
            }), this.trigger(t, "playpause");
        },
        vipHit: function() {
            var t = this;
            this.data._videoContexts.forEach(function(t) {
                t.pause();
            }), "ios" != wx.getSystemInfoSync().platform ? wx.showModal({
                title: "提示",
                content: "购买VIP即可使用并练习完整题库！",
                confirmText: "充值",
                showCancel: !1,
                success: function(e) {
                    1 == e.confirm && wx.navigateTo({
                        url: "/pages/study/vippay/vippay?viptype=vip&type=" + t.data.userInfo.projectClass.projectVipType + "&projectName=" + t.data.classifyname
                    });
                }
            }) : wx.showModal({
                title: "提示信息",
                content: "您还不是VIP！",
                confirmText: "激活",
                showCancel: !1,
                success: function(t) {
                    return !!t.confirm && (wx.navigateTo({
                        url: "/pages/study/vippay/vippay?tab=acvip&type=2&viptype=vip"
                    }), !1);
                }
            });
        }
    }
});