Component({
    properties: {},
    data: {},
    methods: {
        cancel: function(t) {
            this.triggerEvent("cancel");
        }
    }
});