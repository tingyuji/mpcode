require("../../D6C5E9D0539B32CFB0A381D7EAF940C3.js"), require("../../743567A7539B32CF12530FA0A59940C3.js");

var e = getApp();

Component({
    properties: {
        color: {
            type: String,
            value: "#439445"
        },
        autonymCancel: {
            type: Boolean,
            value: !1
        },
        Title: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {
        autonymSubmit: function(t) {
            var a = this;
            e.updateUser(function(e) {
                null == e && wx.navigateTo({
                    url: "/pages/auth/auth?title=" + a.data.Title
                });
            });
        },
        cancel: function() {
            this.triggerEvent("cancel");
        }
    }
});