var e = getApp();

Component({
    properties: {
        color: {
            type: String,
            value: "#439445"
        },
        url: {
            type: String,
            value: "home"
        }
    },
    data: {
        app: e,
        urls: {
            index: "/pages/index/index",
            practical: "/pages/videos/videolist/videolist",
            personal: "/pages/study/personal/personal"
        },
        urlsakh: {
            index: "/pages/home/home",
            practical: "/pages/videos/videolist/videolist",
            personal: "/pages/study/personal/personal"
        }
    },
    methods: {
        opennav: function(a) {
            var t = a.currentTarget.dataset.url;
            this.properties.url != t && (e.globalData.simulateUserInfo ? "zyakhmp" == e.globalData.appIdentify || "akhzy" == e.globalData.appIdentify ? wx.redirectTo({
                url: this.data.urlsakh[t]
            }) : wx.redirectTo({
                url: this.data.urls[t]
            }) : wx.showToast({
                title: "请先点击登录!",
                icon: "none"
            }));
        },
        lifetimes: {
            attached: function() {
                this.setData({
                    color: this.properties.color
                });
            },
            detached: function() {}
        }
    }
});