var e = require("743567A7539B32CF12530FA0A59940C3.js"), r = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    wxLogin: function(i, s) {
        var o = e.baseHost + "/api/mp/wxmplogin";
        r.req(o, i, "POST", s);
    }
};