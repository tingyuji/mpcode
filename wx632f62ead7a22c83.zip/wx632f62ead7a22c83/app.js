var a = require("D6C5E9D0539B32CFB0A381D7EAF940C3.js"), o = require("CAE540F6539B32CFAC8328F135B940C3.js"), t = require("743567A7539B32CF12530FA0A59940C3.js");

App({
    globalData: {
        enterScene: [ 1035, 1037, 1043, 1047, 1048, 1049, 1024, 1007, 1008, 1011, 1012, 1013, 1014 ],
        appIdentify: "zyakxksmp",
        appName: "安考星",
        adunit: "adunit-e7ef90de75091a66",
        userInfo: null,
        orgInfo: null,
        simulateUserInfo: null,
        baseHost: t.baseHost,
        imgHost: t.imgHost,
        orgCode: null,
        subjectColor: null,
        fontSize: 14,
        zyuid: null,
        vip: !1,
        isEdit: !1
    },
    onLaunch: function(a) {
        this.globalData.orgCode = a.query.org || a.query.scene, this.globalData.zyuid = a.query.uid, 
        null != this.globalData.orgCode ? wx.setStorage({
            data: this.globalData.orgCode,
            key: "orgcode"
        }) : this.globalData.orgCode = wx.getStorageSync("orgcode"), "akhmnmp" != this.globalData.appIdentify && "akhzy" != this.globalData.appIdentify || (this.globalData.appName = "安考汇"), 
        this.updateApp(), this.updateOnlineTime();
    },
    updateApp: function() {
        if (wx.getUpdateManager) {
            var a = wx.getUpdateManager();
            a.onUpdateReady(function() {
                wx.showModal({
                    title: "新版更新!",
                    content: "有新的版本可用！",
                    success: function(o) {
                        o.confirm && a.applyUpdate();
                    }
                });
            });
        }
    },
    wxGetOrgInfo: function() {
        var a = this;
        null != this.globalData.orgCode && "" != this.globalData.orgCode ? o.wxGetorgInfo(this.globalData.orgCode, function(o) {
            0 == o.state && o.data && o.data.user ? (a.globalData.orgInfo = o.data.user.org, 
            a.globalData.subjectColor = o.data.user.org.subjectColor, o.data.jwtToken && delete a.globalData.orgInfo.jwtToken, 
            a.orgInfoCallback && a.orgInfoCallback(a.globalData.orgInfo)) : a.orgInfoCallback && a.orgInfoCallback();
        }) : this.orgInfoCallback();
    },
    wxLogin: function(o) {
        var t = this;
        wx.login({
            success: function(e) {
                var n = {
                    app: t.globalData.appIdentify,
                    code: e.code,
                    orgCode: t.globalData.orgCode,
                    zyuid: t.globalData.zyuid
                };
                a.wxLogin(n, function(a) {
                    0 == a.state ? (t.globalData.simulateUserInfo = a.data.user, a.data.jwtToken && wx.setStorageSync("mmtoken", a.data.jwtToken), 
                    t.userInfoReadyCallback && t.userInfoReadyCallback(a.data.user, a.data.userInfo), 
                    o && o(a.data.user)) : 2 == a.state ? t.userLockCallback && t.userLockCallback() : wx.showModal({
                        title: "提示",
                        content: "同步数据异常,请稍后重试"
                    });
                });
            },
            fail: function() {
                t.wxLogin();
            }
        });
    },
    GetSessionKey: function(a) {
        var t = this;
        wx.login({
            success: function(e) {
                o.GetSessionKey({
                    code: e.code,
                    app: t.globalData.appIdentify
                }, function(o, t) {
                    0 == o.state && (wx.removeStorageSync("sid"), (t.Cookie || t["Set-Cookie"]) && wx.setStorageSync("sid", t.Cookie || t["Set-Cookie"]), 
                    a && a());
                });
            }
        });
    },
    onShow: function(a) {},
    updateOnlineTime: function() {
        var o = this;
        setInterval(function(t) {
            null != o.globalData.simulateUserInfo && (a.updateOnlineTime(o.globalData.simulateUserInfo.guid, function(a) {}), 
            a.updateTime(o.globalData.simulateUserInfo.guid, function(a) {}));
        }, 6e4);
    },
    updateUser: function(o) {
        var t = this;
        0 == this.globalData.simulateUserInfo.info ? wx.getUserProfile({
            lang: "zh_CN",
            desc: "显示用户基本信息",
            success: function(e) {
                a.upuser(e.userInfo, function(a) {
                    0 == a.state && (t.globalData.simulateUserInfo = a.data, o());
                });
            }
        }) : o();
    }
});