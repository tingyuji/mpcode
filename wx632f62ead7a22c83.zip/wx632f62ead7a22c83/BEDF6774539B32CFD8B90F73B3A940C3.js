var r = require("743567A7539B32CF12530FA0A59940C3.js"), e = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    wxInitApplyInfo: function(p, a) {
        var t = r.baseHost + "/api/mp/initapplyinfo";
        e.req(t, p, "POST", a);
    },
    applyOrder: function(p, a) {
        var t = r.baseHost + "/api/mp/applyorder";
        e.req(t, p, "POST", a);
    },
    udApplyOrder: function(p, a) {
        var t = r.baseHost + "/api/mp/UdApplyOrder";
        e.req(t, p, "POST", a);
    },
    orcSegment: function(p, a, t, o, n) {
        var s = r.baseHost + "/api/mp/segment";
        e.ulf(s, p, a, t, o, n);
    },
    delApplyOrdere: function(p, a) {
        var t = r.baseHost + "/api/mp/dao/" + p;
        e.req(t, null, "GET", a);
    },
    getOrder: function(p, a) {
        var t = r.baseHost + "/api/mp/getorder/" + p;
        e.req(t, null, "GET", a);
    },
    OrderUnder: function(p, a) {
        var t = r.baseHost + "/api/mp/wxpay";
        e.req(t, p, "POST", a);
    },
    GetOrders: function(p, a) {
        var t = r.baseHost + "/api/mp/GetOrders";
        e.req(t, p, "POST", a);
    },
    orderpatternoff: function(p, a) {
        var t = r.baseHost + "/api/mp/orderpatternoff";
        e.req(t, p, "POST", a);
    }
};