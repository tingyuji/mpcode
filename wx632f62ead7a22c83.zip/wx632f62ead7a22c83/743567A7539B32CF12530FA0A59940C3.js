module.exports = {
    imgHost: "https://imgs.sczyaq.com",
    baseHost: "https://ankaohui.com",
    simulateHost: "https://apis.sczyaq.com"
};