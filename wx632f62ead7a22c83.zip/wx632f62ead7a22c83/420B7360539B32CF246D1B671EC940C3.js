var e = require("743567A7539B32CF12530FA0A59940C3.js"), r = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    underorder: function(t, i) {
        var s = e.simulateHost + "/spapi/underorder";
        r.req(s, t, "POST", i);
    },
    getOrderDetailById: function(t, i) {
        var s = e.simulateHost + "/spapi/orderdetail/" + t;
        r.req(s, null, "GET", i);
    },
    getbinduser: function(t, i) {
        var s = e.simulateHost + "/spapi/getbinduser/" + t;
        r.req(s, null, "GET", i);
    },
    getorderlist: function(t, i) {
        var s = e.simulateHost + "/spapi/getorderlist/" + t;
        r.req(s, null, "GET", i);
    },
    teamApply: function(t, i) {
        var s = e.simulateHost + "/spapi/teamapply";
        r.req(s, t, "POST", i);
    },
    OrderQueryCrad: function(t, i) {
        var s = e.simulateHost + "/simulate/OrderQueryCrad/" + t;
        r.req(s, null, "GET", i);
    }
};