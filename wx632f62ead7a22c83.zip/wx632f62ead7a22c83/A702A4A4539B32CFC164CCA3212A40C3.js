var e = function(e) {
    return (e = e.toString())[1] ? e : "0" + e;
};

module.exports = {
    formatTime: function(t) {
        var r = t.getFullYear(), n = t.getMonth() + 1, a = t.getDate(), i = t.getHours(), o = t.getMinutes(), u = t.getSeconds();
        return [ r, n, a ].map(e).join("/") + " " + [ i, o, u ].map(e).join(":");
    },
    formatDate: function(e) {
        var t = e.getFullYear(), r = e.getMonth() + 1, n = e.getDate();
        e.getHours(), e.getMinutes(), e.getSeconds();
        return t + "/" + (r[1] ? r : "0" + r) + "/" + (n[1] ? n : "0" + n);
    },
    formatMoney: function(e) {
        if (/[^0-9\.]/.test(e)) return "invalid value";
        e = (e = ((e = e.replace(/^(\d*)$/, "$1.")) + "00").replace(/(\d*\.\d\d)\d*/, "$1")).replace(".", ",");
        for (var t = /(\d)(\d{3},)/; t.test(e); ) e = e.replace(t, "$1,$2");
        return "￥" + (e = e.replace(/,(\d\d)$/, ".$1")).replace(/^\./, "0.");
    },
    formatTimeMinute: function(t) {
        var r = t.getFullYear(), n = t.getMonth() + 1, a = t.getDate(), i = t.getHours(), o = t.getMinutes();
        t.getSeconds();
        return [ r, n, a ].map(e).join("/") + " " + [ i, o ].map(e).join(":");
    },
    imgReplaceSrc: function(e, t) {
        return e.replace(/<img [^>]*src=['"]([^'"]+)[^>]*>/gi, function(e, r) {
            return r = r.replace("/api/file/df", ""), "<img style='max-width:100%;height:auto' src=" + t + r + "></img>";
        });
    }
};