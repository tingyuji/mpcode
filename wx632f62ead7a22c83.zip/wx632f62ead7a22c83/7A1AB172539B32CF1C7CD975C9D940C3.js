var e = require("743567A7539B32CF12530FA0A59940C3.js"), r = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    getClassifyProjectBytype: function(u, t, i) {
        var s = e.simulateHost + "/simulate/classify/" + u + "/" + t;
        r.req(s, null, "GET", i);
    },
    getOpenid: function(u, t, i) {
        var s = e.simulateHost + "/simulate/openid/" + u + "/" + t;
        r.req(s, null, "GET", i);
    },
    unifiedorderPay: function(u, t) {
        var i = e.simulateHost + "/simulate/underorderpay";
        r.req(i, u, "POST", t);
    },
    orderquery: function(u, t, i, s) {
        var a = e.simulateHost + "/simulate/orderquery/" + u + "/" + t + "/" + i;
        r.req(a, null, "GET", s);
    },
    getspuuid: function(u, t, i) {
        var s = e.simulateHost + "/simulate/getspuuid";
        u.key = t, r.req(s, u, "POST", i);
    },
    buycradunderorder: function(u, t) {
        var i = e.simulateHost + "/simulate/buycradunderorder";
        r.req(i, u, "POST", t);
    }
};