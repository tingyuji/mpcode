var e = require("743567A7539B32CF12530FA0A59940C3.js"), r = require("B9FAF8D7539B32CFDF9C90D0AAE940C3.js");

module.exports = {
    getorgschool: function(t, o) {
        var g = e.baseHost + "/api/mp/getorgschool/" + t;
        r.req(g, null, "GET", o);
    },
    getorgpage: function(t, o) {
        var g = e.baseHost + "/api/mp/getorgpage/" + t;
        r.req(g, null, "GET", o);
    },
    getorgfaq: function(t, o) {
        var g = e.baseHost + "/api/mp/getorgfaq/" + t;
        r.req(g, null, "GET", o);
    },
    getorgsetting: function(t, o) {
        var g = e.baseHost + "/api/mp/getorgsetting/" + t;
        r.req(g, null, "GET", o);
    }
};