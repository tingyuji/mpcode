var e = require("743567A7539B32CF12530FA0A59940C3.js");

getApp();

module.exports = {
    req: function(t, a, r, s) {
        var o = {};
        if (0 == t.indexOf(e.baseHost)) {
            var u = wx.getStorageSync("token"), i = wx.getStorageSync("sid");
            i && (o.Cookie = i), u && (o.Authorization = "Bearer " + u);
        } else {
            (u = wx.getStorageSync("mmtoken")) && (o.Authorization = "Bearer " + u);
        }
        wx.request({
            url: t,
            data: a,
            header: o,
            method: r,
            dataType: "json",
            success: function(e) {
                200 == e.statusCode ? s(e.data, e.header) : s({
                    data: {
                        state: 1
                    }
                });
            },
            fail: function(e) {
                s({
                    data: {
                        state: 1
                    }
                });
            },
            complete: function(e) {}
        });
    },
    ulf: function(t, a, r, s, o, u) {
        if (0 == t.indexOf(e.baseHost)) {
            var i = wx.getStorageSync("token"), n = {};
            i && (n = {
                Authorization: "Bearer " + i,
                "Content-Type": "multipart/form-data;charset=utf-8"
            });
        } else {
            var c = wx.getStorageSync("mmtoken");
            c && (n = {
                Authorization: "Bearer " + c,
                "Content-Type": "multipart/form-data;charset=utf-8"
            });
        }
        return wx.uploadFile({
            header: n,
            url: t,
            filePath: a,
            name: "file",
            formData: r,
            success: function(e) {
                s(JSON.parse(e.data));
            },
            fail: o,
            complete: u
        });
    },
    batchUpload: function(e, t, a, r) {
        if (e.uploadUrl) if (e.imgPaths instanceof Array) {
            var s = wx.getStorageSync("token"), o = {};
            s && (o = {
                Authorization: "Bearer " + s,
                "Content-Type": "multipart/form-data;charset=utf-8"
            });
            var u = e.imgPaths.length, i = e.subscript ? e.subscript : 0, n = e.successNum ? e.successNum : 0, c = e.failNum ? e.failNum : 0, l = e.resultData ? e.resultData : [];
            wx.uploadFile({
                url: e.uploadUrl,
                filePath: e.imgPaths[i],
                name: "file",
                headers: o,
                formData: t,
                success: function(e) {
                    if (200 == e.statusCode) {
                        var t = JSON.parse(e.data);
                        n++, l.push(t.url);
                    } else c++;
                },
                fail: function(e) {
                    c++;
                },
                complete: function() {
                    ++i == u ? r({
                        imgPaths: l,
                        successNum: n,
                        failNum: c
                    }) : (e.subscript = i, e.successNum = n, e.failNum = c, e.resultData = l, a(e, a, r));
                }
            });
        } else console.log("请传入array类型"); else console.log("请传入上传地址");
    }
};