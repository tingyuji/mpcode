var t, a = require("../../@babel/runtime/helpers/defineProperty"), e = require("../../D6C5E9D0539B32CFB0A381D7EAF940C3.js"), o = getApp();

Page({
    data: (t = {
        app: o,
        orgInfo: null,
        userData: null,
        userInfo: null,
        onlineTime: 0,
        curProject: null,
        projectShapeState: null,
        userVip: null,
        projectName: null,
        platform: null,
        system: null,
        IsAuthorization: !1,
        autonymAkxState: !1
    }, a(t, "userInfo", null), a(t, "introductionvideostate", !1), a(t, "oftenSum", 0), 
    t),
    onLoad: function(t) {
        var a = this;
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#248325"
        }), this.setData({
            orgInfo: o.globalData.orgInfo,
            userData: o.globalData.simulateUserInfo,
            platform: wx.getSystemInfoSync().platform
        }), wx.setNavigationBarTitle({
            title: o.globalData.appName
        }), null == this.data.userData ? (wx.showLoading({
            title: "加载中..."
        }), o.userInfoReadyCallback = function(t, e) {
            wx.hideLoading(), t && (a.setData({
                userData: t
            }), a.getUserDataInfo(1));
        }, o.wxLogin()) : (wx.showLoading({
            title: "加载中..."
        }), this.getUserDataInfo(2)), this.initOrgInfo(function(t) {
            t && a.setData({
                orgInfo: t
            });
        }), o.userLockCallback = function() {
            wx.hideLoading(), a.setData({
                UserLockState: !0,
                loadingState: !1
            });
        };
    },
    akhkssayc: function() {
        "akhzy" != o.globalData.appIdentify || wx.showModal({
            title: "提示",
            content: "该小程序已进行功能升级，请前往新版学习（数据完全同步）！",
            confirmText: "新版本",
            showCancel: !1,
            complete: function(t) {
                wx.navigateToMiniProgram({
                    appId: "wx84413d5a454ddd8d"
                });
            }
        });
    },
    initOrgInfo: function(t) {
        var a = this;
        o.orgInfoCallback = function(e) {
            e && (delete e.subjectColor, a.setData({
                orgInfo: e
            }), "0" == e.autonym && a.data.userInfo && 0 == a.data.userInfo.autonym && a.setData({
                autonymAkxState: !0
            })), t(e);
        };
    },
    getUserDataInfo: function(t) {
        var a = this;
        null != this.data.userData && e.getUserData(this.data.userData.guid, function(t) {
            if (0 == t.state && t.data) {
                o.globalData.isEdit = !1;
                var e = t.data;
                o.globalData.vip = !(!e.vip || 1 != e.vip.vipState), o.globalData.userInfo = e, 
                a.setData({
                    curProject: e.projectClass,
                    projectShapeState: null != e.projectClass ? e.projectClass.shapeShow : 0,
                    userVip: e.vip,
                    projectName: a.getProjectName(e.projectClass, e.repetition),
                    autonymAkxState: !(!a.data.orgInfo || "0" != a.data.orgInfo.autonym || 0 != e.autonym),
                    userInfo: e,
                    oftenSum: e.oftenSum,
                    vip: o.globalData.vip
                }), null == o.globalData.orgInfo && null != e.orgCode && (o.globalData.orgCode = e.orgCode, 
                o.wxGetOrgInfo());
            } else 2 == t.state && a.setData({
                UserLockState: !0,
                loadingState: !1
            });
            wx.hideLoading();
        });
    },
    getProjectName: function(t, a) {
        if (null == t) return null;
        if (null != t.classifyName) {
            if (1 == t.shapeShow) {
                var e = "";
                return 0 == a ? e = "新训" : 1 == a ? e = "复训" : 2 == a && (e = "换证"), t.classifyName + "-" + t.projectName + "(" + e + ")";
            }
            return t.classifyName + "-" + t.projectName;
        }
        return t.projectName;
    },
    onShow: function() {
        this.getUserDataInfo(3), null == this.data.orgInfo && o.wxGetOrgInfo();
    },
    opneQuestionBtn: function() {
        o.updateUser(function(t) {
            null == t && wx.navigateTo({
                url: "/pages/study/project/project"
            });
        });
    },
    openRechargeBtn: function(t) {
        var a = this;
        null != this.data.userData ? o.updateUser(function(t) {
            if (null == t) {
                if (null == a.data.curProject || null == a.data.curProject.projectId) return void wx.showModal({
                    title: "提示信息",
                    content: "您还没选择练习题库，请先选择练习题库",
                    confirmText: "选择题库",
                    cancelText: "取消",
                    success: function(t) {
                        t.confirm && wx.navigateTo({
                            url: "/pages/study/project/project"
                        });
                    }
                });
                "ios" != a.data.platform ? wx.navigateTo({
                    url: "/pages/study/vippay/vippay?viptype=vip&type=" + a.data.curProject.projectVipType + "&projectName=" + a.data.projectName
                }) : wx.navigateTo({
                    url: "/pages/study/vippay/vippay?tab=acvip&type=2&viptype=vip"
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "自动登录失败，可点击登录重新获取登录数据。",
            confirmText: "重新登录",
            success: function(t) {
                t.confirm && o.wxLogin();
            }
        });
    },
    openModel: function(t) {
        var a = this;
        "akhzy" != o.globalData.appIdentify ? null != this.data.userData ? null != this.data.curProject ? o.updateUser(function(e) {
            if (null == e && a.data.curProject && a.data.curProject.projectId) {
                var o = null;
                "sequence" == t.currentTarget.dataset.type && (o = "/pages/study/sequence-index/sequence-index?shape=" + t.currentTarget.dataset.type + "&classifyId=" + a.data.curProject.projectId + "&classifyname=" + a.data.projectName + "&v=" + a.data.curProject.version + "&vtype=" + a.data.curProject.projectVipType, 
                wx.navigateTo({
                    url: o
                })), "special" == t.currentTarget.dataset.type && a.vipVerify(!1) && (o = "/pages/study/special/special?classifyId=" + a.data.curProject.projectId + "&classifyname=" + a.data.projectName, 
                wx.navigateTo({
                    url: o
                })), "simulate" == t.currentTarget.dataset.type && (o = "/pages/study/simulate-index/simulate-index?shape=" + t.currentTarget.dataset.type + "&classifyId=" + a.data.curProject.projectId + "&classifyname=" + a.data.projectName + "&score=" + a.data.curProject.projectScore + "&vtype=" + a.data.curProject.projectVipType + "&testSum=" + a.data.curProject.testSum, 
                wx.navigateTo({
                    url: o
                })), "curfew" == t.currentTarget.dataset.type && (o = "/pages/study/quick_search/quick_search?classifyId=" + a.data.curProject.projectId + "&classifyname=" + a.data.projectName + "&vtype=" + a.data.curProject.projectVipType, 
                wx.navigateTo({
                    url: o
                })), "read" == t.currentTarget.dataset.type && a.vipVerify() && (o = "/pages/study/question/question?type=read&projectid=" + a.data.curProject.projectId, 
                wx.navigateTo({
                    url: o
                })), "actual" == t.currentTarget.dataset.type && wx.navigateTo({
                    url: "/pages/study/Actual/projects/projects"
                }), "collect" == t.currentTarget.dataset.type && a.vipVerify("collect") && wx.navigateTo({
                    url: "/pages/study/question/question?type=collect&projectid=" + a.data.curProject.projectId
                });
            }
        }) : wx.showModal({
            title: "提示信息",
            content: "您还没选择练习题库，请先选择练习题库",
            confirmText: "选择题库",
            cancelText: "取消",
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "/pages/study/project/project"
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "自动登录失败，可点击登录重新获取登录数据。",
            confirmText: "重新登录",
            success: function(t) {
                t.confirm && o.wxLogin();
            }
        }) : this.akhkssayc();
    },
    vipVerify: function(t) {
        var a = this;
        if (null != this.data.userVip && 1 == this.data.userVip.vipState) return !0;
        var e = "ios" == this.data.platform ? "您还不是VIP!" : "购买VIP即可使用并练习完整题库！", o = "ios" != this.data.platform ? "充值" : "激活";
        console.log(o), wx.showModal({
            title: "提示信息",
            content: e,
            confirmText: o,
            success: function(t) {
                return !!t.confirm && (a.openRechargeBtn(), !1);
            }
        });
    },
    onShareAppMessage: function() {
        return this.data.orgInfo ? {
            title: o.globalData.appName + " - 免费模拟考试",
            path: "/pages/home/home?org=" + this.data.orgInfo.orgCode,
            imageUrl: "/imgs/simulate/akhtkzf.jpg"
        } : {
            title: o.globalData.appName + " - 免费模拟考试",
            path: "/pages/home/home",
            imageUrl: "/imgs/simulate/akhtkzf.jpg"
        };
    },
    openchat: function() {
        wx.openCustomerServiceChat({
            extInfo: {
                url: "https://work.weixin.qq.com/kfid/kfc0b29f55778f4da12"
            },
            corpId: "wwf6b6cb49ed67839c",
            showMessageCard: !0,
            success: function() {}
        });
    }
});