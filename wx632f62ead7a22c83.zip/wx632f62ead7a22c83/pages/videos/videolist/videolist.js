var t = require("../../../93973AF6539B32CFF5F152F1771A40C3.js"), o = getApp();

Page({
    data: {
        app: o,
        orgInfo: null,
        videos: []
    },
    onLoad: function(t) {
        var a = this;
        this.getvideos(), null == this.data.orgInfo ? (this.initOrgInfo(function(t) {
            t && a.setData({
                orgInfo: t
            });
        }), o.wxGetOrgInfo()) : this.setData({
            orgInfo: o.globalData.orgInfo
        });
    },
    initOrgInfo: function(t) {
        var a = this;
        o.orgInfoCallback = function(o) {
            o && a.setData({
                orgInfo: o
            }), t(o);
        };
    },
    getvideos: function() {
        var o = this;
        t.getvideos(function(t) {
            0 == t.state && o.setData({
                videos: t.data
            });
        });
    },
    openVideo: function(t) {
        var o = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/videos/play/play?id=" + o
        });
    }
});