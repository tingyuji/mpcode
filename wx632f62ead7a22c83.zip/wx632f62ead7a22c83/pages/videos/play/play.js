var t = require("../../../93973AF6539B32CFF5F152F1771A40C3.js"), e = require("../../../A702A4A4539B32CFC164CCA3212A40C3.js"), a = getApp();

Page({
    data: {
        orgInfo: null,
        app: a,
        videoprojects: [],
        videoProjectId: null,
        curtab: "catalog",
        video: {},
        videoContext: null,
        videovpi: null,
        userData: null,
        videocontrols: !1,
        platform: "ad",
        loginState: !1
    },
    onLoad: function(t) {
        this.data.videoContext = wx.createVideoContext("video-id", this), this.setData({
            platform: wx.getSystemInfoSync().platform,
            orgInfo: a.globalData.orgInfo,
            videoProjectId: t.id,
            userData: a.globalData.simulateUserInfo
        }), this.getvideoinfo();
    },
    getvideoinfo: function() {
        var i = this;
        t.getvideoinfo(this.data.videoProjectId, function(t) {
            if (0 == t.state) {
                wx.setNavigationBarTitle({
                    title: t.data.project.title
                }), t.data.project.describe && (t.data.project.describe = t.data.project.describe.replace(new RegExp('style="(.*?)"', "g"), ""), 
                t.data.project.describe = e.imgReplaceSrc(t.data.project.describe, a.globalData.imgHost));
                for (var o = 0, d = 0; d < t.data.videolist.length; d++) for (var s = 0; s < t.data.videolist[d].videos.length; s++) t.data.videolist[d].videos[s].index = ++o;
                i.setData({
                    videoprojects: t.data,
                    video: t.data.videolist[0].videos[0]
                }), i.setPalyState(t.data.videolist[0].videos[0].guid);
            }
        });
    },
    videopause: function(t) {
        this.setData({
            videocontrols: !1
        });
    },
    setPalyState: function(t) {
        for (var e = 0; e < this.data.videoprojects.videolist.length; e++) for (var a = 0; a < this.data.videoprojects.videolist[e].videos.length; a++) this.data.videoprojects.videolist[e].videos[a].guid == t ? this.data.videoprojects.videolist[e].videos[a].playstate = !0 : this.data.videoprojects.videolist[e].videos[a].playstate = !1;
        this.setData({
            videoprojects: this.data.videoprojects
        });
    },
    videoplay: function(t) {
        this.data.videoContext && this.data.videoContext.play(), this.setData({
            videocontrols: !0
        });
    },
    palyvideo: function(t) {
        var e = t.currentTarget.dataset.video;
        this.setData({
            video: e
        }), this.setPalyState(e.guid);
    },
    tabChange: function(t) {
        var e = t.currentTarget.dataset.tab;
        this.setData({
            curtab: e
        });
    }
});