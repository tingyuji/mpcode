var t = require("../../D6C5E9D0539B32CFB0A381D7EAF940C3.js"), a = getApp();

Page({
    data: {
        orgInfo: null,
        autonymName: null,
        userInfo: null,
        autonymPhone: null,
        autonymIdNum: null,
        autonymCompany: null,
        autonymContent: "Name;IdNum;Phone",
        Phone: "请输入手机号",
        Title: "根据机构要求选择是否进行实名认证",
        autonymCancel: !0,
        dealChecked: !1
    },
    onLoad: function(t) {
        this.setData({
            orgInfo: a.globalData.orgInfo,
            userData: a.globalData.simulateUserInfo,
            platform: wx.getSystemInfoSync().platform,
            Title: t.title,
            autonymContent: this.autonymContent()
        });
    },
    autonymContent: function(t) {
        return null == a.globalData.orgInfo || null == a.globalData.orgInfo.autonymContent ? this.data.autonymContent : a.globalData.orgInfo.autonymContent;
    },
    autonymNameChange: function(t) {
        this.data.autonymName = t.detail.value;
    },
    autonymPhoneChange: function(t) {
        this.data.autonymPhone = t.detail.value;
    },
    autonymIdNumChange: function(t) {
        this.data.autonymIdNum = t.detail.value;
    },
    autonymCompanyChange: function(t) {
        this.data.autonymCompany = t.detail.value;
    },
    getAutonymPhone: function(n) {
        var o = this;
        null != n.detail.code && (wx.showLoading({
            title: "获取中..."
        }), t.getPhoneNumber({
            app: a.globalData.appIdentify,
            code: n.detail.code
        }, function(t) {
            0 == t.state ? o.setData({
                Phone: t.data,
                autonymPhone: t.data
            }) : wx.showToast({
                title: t.data,
                icon: "none"
            }), wx.hideLoading();
        }));
    },
    openprotocol: function(t) {
        wx.navigateTo({
            url: "/pages/study/personal/agreement/agreement"
        });
    },
    idCardDealChange: function(t) {
        this.setData({
            dealChecked: t.detail.value
        });
    },
    validateIdCard: function(t) {
        if (!/^([1-6][1-9]|50)\d{4}(18|19|20)\d{2}((0[1-9])|10|11|12)(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/.test(t)) return !1;
        if (18 == t.length) {
            for (var a = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2), n = new Array(1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2), o = 0, e = 0; e < 17; e++) o += t.substring(e, e + 1) * a[e];
            var i = o % 11, u = t.substring(17);
            return 2 == i ? "X" == u || "x" == u : u == n[i];
        }
    },
    autonymSubmit: function() {
        var n = this;
        if (this.data.autonymContent.indexOf("Name") > -1 && (null == this.data.autonymName || 0 == this.data.autonymName.lenght)) wx.showToast({
            title: "姓名不能为空",
            icon: "none"
        }); else if (this.data.autonymContent.indexOf("Phone") > -1 && (null == this.data.autonymPhone || 0 == this.data.autonymPhone.lenght)) wx.showToast({
            title: "手机号码不能为空",
            icon: "none"
        }); else if (this.data.autonymContent.indexOf("IdNum") > -1 && (null == this.data.autonymIdNum || 0 == this.data.autonymIdNum.lenght)) wx.showToast({
            title: "身份证号码不能为空",
            icon: "none"
        }); else if (this.data.autonymContent.indexOf("IdNum") > -1 && !this.validateIdCard(this.data.autonymIdNum)) wx.showToast({
            title: "身份证号码不正确",
            icon: "none"
        }); else if (this.data.autonymContent.indexOf("Company") > -1 && (null == this.data.autonymCompany || 0 == this.data.autonymCompany.lenght)) wx.showToast({
            title: "单位名称不能为空",
            icon: "none"
        }); else if (0 != this.data.dealChecked) {
            var o = {
                Name: this.data.autonymName,
                OrgCode: a.globalData.orgCode,
                UserId: a.globalData.simulateUserInfo.guid,
                Phone: this.data.autonymPhone,
                IdNum: this.data.autonymIdNum,
                Company: this.data.autonymCompany
            };
            t.AkxAutonym(o, function(t) {
                0 == t.state ? (wx.showToast({
                    title: "提交成功",
                    icon: "none"
                }), a.globalData.isEdit = !0, n.cancel()) : wx.showToast({
                    title: "" + t.data,
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "请同意并勾选用户协议哦",
            icon: "none"
        });
    },
    cancel: function(t) {
        wx.navigateBack({
            delta: 1
        });
    }
});