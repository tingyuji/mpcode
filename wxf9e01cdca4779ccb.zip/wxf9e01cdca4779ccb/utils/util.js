var t = require("../config.js"), n = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}, e = wx.getSystemInfoSync(), o = function() {
    var t = getCurrentPages();
    return t[t.length - 1].route;
};

module.exports = {
    formatTimeFromTs: function(t) {
        var n = new Date(t), e = n.getFullYear(), o = n.getMonth() + 1, r = n.getDate();
        return r < 10 && (r = "0" + r), o < 10 && (o = "0" + o), "".concat(e, ".").concat(o, ".").concat(r);
    },
    formatTime: function(t) {
        var e = t.getFullYear(), o = t.getMonth() + 1, r = t.getDate(), a = t.getHours(), i = t.getMinutes(), c = t.getSeconds();
        return [ e, o, r ].map(n).join("/") + " " + [ a, i, c ].map(n).join(":");
    },
    rpxToPx: function(t) {
        return t * (e.windowWidth / 750);
    },
    pxToRpx: function(t) {
        return t * (750 / e.windowWidth);
    },
    getRandomInt: function(t, n) {
        return Math.floor(Math.random() * (n - t + 1) + t);
    },
    getRandomArbitrary: function(t, n) {
        return Math.random() * (n - t) + t;
    },
    getRadian: function(t) {
        return Math.sin(Math.PI * t / 180);
    },
    getWeatherHashKeys: function(t, n) {
        for (var e = Object.keys(t), o = [], r = 0; r < e.length; r++) for (var a = e[r].split("|"), i = 0; i < a.length; i++) {
            var c = a[i];
            n.indexOf(c) >= 0 && o.join("").indexOf(c) < 0 && o.push(e[r]);
        }
        return o;
    },
    showLoadingTips: function(t) {
        t = t || "加载中", wx.showNavigationBarLoading(), wx.showLoading({
            title: t
        });
    },
    hideLodingTips: function() {
        wx.hideLoading(), wx.stopPullDownRefresh(), wx.hideNavigationBarLoading();
    },
    timeTextFormat: function(t) {
        if ((t = Math.ceil(t)) <= 0) return "00:00";
        var n = Math.floor(t / 3600), e = Math.floor(t / 60) + "";
        e = e.length > 1 ? e : "0" + e;
        var o = t % 60 + "";
        return o = o.length > 1 ? o : "0" + o, n > 0 ? "".concat(n, ":").concat(e, ":").concat(o) : "".concat(e, ":").concat(o);
    },
    parseLyrics: function(t) {
        for (var n = {}, e = [], o = [], r = [], a = {}, i = (t = t || "").split("\n"), c = 0; c < i.length; c++) {
            var s = i[c].match(/\[([\S\s]*?)\]([\S\s]*)/);
            if (s && s.length >= 3) {
                for (var g = s[1], u = s[2], f = g.split("."), l = f.length > 1 ? parseInt(f[1]) / 1e3 : 0, h = f.length > 0 ? f[0].split(":") : [], d = 0; d < h.length; d++) {
                    var p = parseInt(h[d]);
                    l += Math.pow(60, h.length - 1 - d) * p;
                }
                var m = /^\d+$/.test(u);
                n[l] = u, e.push({
                    time: l,
                    text: u,
                    isCountdown: m
                }), o.push(l), r.push(u), a[l] = m;
            }
        }
        return {
            lyrics: n,
            lyricsList: e,
            lyricsTimes: o,
            lyricsValues: r,
            lyricsCountdown: a
        };
    },
    getCommonShareData: function() {
        var n = getCurrentPages(), e = n[n.length - 1], o = wx.getStorageSync(t.config.CONST_KEY.LOGIN_DATA) || {};
        return {
            title: "细雨春风，伴你入眠",
            path: "/".concat(e.route).concat(o.htid ? "?suid=" + o.htid : "?nonce=n")
        };
    },
    handleAppPageOption: function(t) {
        var n = t;
        t && t.scene && decodeURIComponent(t.scene).split("&").forEach(function(t) {
            var e = t.split("=");
            e.length >= 2 && (n[e[0]] = e[1]);
        });
        return n;
    },
    handleAPPConfig: function(n) {
        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (n) {
            var r = wx.getStorageSync(t.config.CONST_KEY.IS_BIG_FONT_MODE) || !1;
            n.setData({
                isBigFontMode: r
            });
            var a = wx.getStorageSync(t.config.CONST_KEY.IS_NIGHT_MODE) || !1;
            if (n.setData({
                isNightMode: a
            }), e) {
                var i = o();
                wx.setTabBarStyle({
                    color: a ? "#666666" : "#000000",
                    selectedColor: "#3F98E4",
                    backgroundColor: a ? "#312736" : "#FFFFFF",
                    borderStyle: "black"
                });
                var c = [ "pages/my/my", "pages/main/main" ], s = !1;
                c.forEach(function(t) {
                    i.indexOf(t) >= 0 && (s = !0);
                });
                var g = a || s ? "#ffffff" : "#000000";
                wx.setNavigationBarColor({
                    frontColor: g,
                    backgroundColor: "transparent",
                    animation: {}
                });
                var u = a ? "#261C2C" : "#ffffff";
                wx.setBackgroundColor({
                    backgroundColor: u
                });
            }
        } else console.error("没有上下文，无法执行handleAPPConfig");
    },
    safePhoneNum: function(t) {
        return t ? ("number" == typeof t && (t = t.toString()), t.length >= 11 ? t.substr(0, 3) + "****" + t.substr(7, 11) : t) : t;
    },
    getCurrentPagePath: o
};