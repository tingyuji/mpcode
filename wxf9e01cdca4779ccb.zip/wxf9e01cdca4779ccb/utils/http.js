Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.HTTP = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), n = require("../config.js"), o = require("../utils/util.js"), r = getApp(), i = r && r.globalData || {}, s = function() {
    function r() {
        e(this, r), this.showError = !0;
    }
    return t(r, [ {
        key: "request",
        value: function(e) {
            var t = this;
            return new Promise(function(o, r) {
                var i = wx.getStorageSync(n.config.CONST_KEY.TOKEN), s = [ "/user/login", "/config" ].join("|"), c = "(".concat(s, ")$");
                new RegExp(c, "i").test(e.url) || i ? t._request(e).then(function(e) {
                    o(e);
                }).catch(function(e) {
                    r(e);
                }) : t._login().then(function(i) {
                    wx.setStorageSync(n.config.CONST_KEY.TOKEN, i.data.token), wx.setStorageSync(n.config.CONST_KEY.LOGIN_DATA, i.data), 
                    wx.setStorageSync(n.config.CONST_KEY.VIP_INFO, i.data.user_cosleep || {
                        vip_expires: 0,
                        is_vip: 0
                    }), t._request(e).then(function(e) {
                        o(e);
                    }).catch(function(e) {
                        r(e);
                    });
                }).catch(function(e) {
                    r(e);
                });
            });
        }
    }, {
        key: "uploadFile",
        value: function(e) {
            var t = this;
            return new Promise(function(o, r) {
                wx.getStorageSync(n.config.CONST_KEY.TOKEN) ? t._uploadFile(e).then(function(e) {
                    o(e);
                }).catch(function(e) {
                    r(e);
                }) : t._login().then(function(i) {
                    wx.setStorageSync(n.config.CONST_KEY.TOKEN, i.data.token), wx.setStorageSync(n.config.CONST_KEY.LOGIN_DATA, i.data), 
                    wx.setStorageSync(n.config.CONST_KEY.VIP_INFO, i.data.user_cosleep || {
                        vip_expires: 0,
                        is_vip: 0
                    }), t._uploadFile(e).then(function(e) {
                        o(e);
                    }).catch(function(e) {
                        r(e);
                    });
                }).catch(function(e) {
                    r(e);
                });
            });
        }
    }, {
        key: "_uploadFile",
        value: function(e) {
            var t = this;
            return new Promise(function(r, i) {
                e.url && 0 !== e.url.indexOf("http") && (e.url = "".concat(n.config.BASE_URL).concat(e.url));
                var s = wx.getStorageSync(n.config.CONST_KEY.TOKEN), c = {
                    method: "GET",
                    header: Object.assign(n.config.REQUEST_HEADER, {
                        token: s
                    }),
                    success: function(e) {
                        if (e.statusCode.toString().startsWith("2")) {
                            var s = JSON.parse(e.data);
                            3 === s.status ? (wx.removeStorageSync(n.config.CONST_KEY.TOKEN), wx.removeStorageSync(n.config.CONST_KEY.LOGIN_DATA), 
                            i(s), (0, o.hideLodingTips)(), t._showError(s.msg)) : 1 !== s.status ? (i(s), (0, 
                            o.hideLodingTips)(), t._showError(s.msg)) : r(s.data);
                        } else i(e), (0, o.hideLodingTips)(), t._showError();
                    },
                    fail: function(e) {
                        i(e), t._show_error(e.errMsg);
                    }
                };
                Object.assign(c, e), wx.uploadFile(c);
            });
        }
    }, {
        key: "_login",
        value: function() {
            return new Promise(function(e, t) {
                wx.login({
                    success: function(o) {
                        if (o.code) {
                            var r = i && i.query && i.query.share_uid;
                            wx.request({
                                method: "POST",
                                header: n.config.REQUEST_HEADER,
                                url: "".concat(n.config.BASE_URL, "/user/login"),
                                data: {
                                    code: o.code,
                                    user_invite_from: r
                                },
                                success: function(n) {
                                    var o = n.data;
                                    1 === o.status ? e(o) : t(o);
                                },
                                fail: function(e) {
                                    console.log(e), t(e);
                                }
                            });
                        } else console.log("登录失败！" + o.errMsg), t(o.errMsg);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    }, {
        key: "_request",
        value: function(e) {
            var t = this;
            return new Promise(function(r, i) {
                e.url && 0 !== e.url.indexOf("http") && (e.url = "".concat(n.config.BASE_URL).concat(e.url));
                var s = wx.getStorageSync(n.config.CONST_KEY.TOKEN), c = {
                    method: "GET",
                    header: Object.assign(n.config.REQUEST_HEADER, {
                        token: s
                    }),
                    success: function(e) {
                        if (e.statusCode.toString().startsWith("2")) {
                            var s = e.data;
                            3 === s.status ? (wx.removeStorageSync(n.config.CONST_KEY.TOKEN), wx.removeStorageSync(n.config.CONST_KEY.LOGIN_DATA), 
                            i(s), (0, o.hideLodingTips)(), t._showError(s.msg)) : 1 !== s.status ? (i(s), (0, 
                            o.hideLodingTips)(), t._showError(s.msg)) : r(s.data);
                        } else i(e), (0, o.hideLodingTips)(), t._showError();
                    },
                    fail: function(e) {
                        i(e), t._show_error(e.errMsg);
                    }
                };
                Object.assign(c, e), wx.request(c);
            });
        }
    }, {
        key: "_showError",
        value: function(e) {
            this.showError && (e = e || "未知错误", wx.showToast({
                title: e,
                icon: "none",
                duration: 2e3
            }));
        }
    } ]), r;
}();

exports.HTTP = s;