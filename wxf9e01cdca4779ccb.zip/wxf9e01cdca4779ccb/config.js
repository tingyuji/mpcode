Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.config = void 0;

var _ = "develop" == wx.getAccountInfoSync().miniProgram.envVersion, e = wx.getSystemInfoSync().system;

console.log("isDebug:", _);

var i = {
    IS_DEBUG: _,
    BASE_URL: _ ? "https://api.debug.psy-1.com/miniapp/v1" : "https://api.psy-1.com/miniapp/v1",
    REQUEST_HEADER: {
        "content-type": "application/json",
        platformid: "3",
        packageid: "12",
        version: "7",
        channelid: /iOS/.test(e) ? "1" : "2"
    },
    CONST_KEY: {
        TOKEN: "token",
        LOGIN_DATA: "login_data",
        VIP_INFO: "vip_info",
        WX_ACODE_KEY_PREFIX: "wx_acode:",
        HAVE_SHOW_VOICE_TRANSFER_TIPS: "have_show_voice_transfer_tips",
        IS_NIGHT_MODE: "is_night_mode",
        IS_BIG_FONT_MODE: "is_big_font_mode",
        MUSIC_TOP: "music_top",
        MUSIC_NEW_DICT: "musi_new_dict",
        IS_EVERIN_CALENDAR: "is_everin_calendar",
        MAIN_AD_LAST_SHOW_TIME: "main_ad_last_show_time"
    },
    MUSIC_TYPE: {
        NOISE: "noise",
        VOICE: "voice",
        SLEEP_BREATH: "sleep_breath",
        RECOMMEND: "recommend"
    }
};

exports.config = i;