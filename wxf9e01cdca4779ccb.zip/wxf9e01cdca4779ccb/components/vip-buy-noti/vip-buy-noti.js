var t = require("../../utils/util.js");

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                var e = this;
                t && (this.setData({
                    containerStyle: "display:flex;"
                }), setTimeout(function() {
                    e.show();
                }, 300));
            }
        },
        vipPower: {
            type: String,
            value: "开通会员可尊享更多权益"
        }
    },
    data: {
        isShow: !1,
        userInfo: {},
        containerStyle: "display:none;"
    },
    attached: function() {
        (0, t.handleAPPConfig)(this);
    },
    pageLifetimes: {
        show: function() {
            (0, t.handleAPPConfig)(this);
        }
    },
    methods: {
        buy: function() {
            wx.navigateTo({
                url: "/pages/pay/pay"
            }), this.hide();
        },
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        hide: function(t) {
            var e = this, i = "string" == typeof t ? t : "";
            this.setData({
                isShow: !1
            }), setTimeout(function() {
                e.setData({
                    containerStyle: "display:none;",
                    show: !1
                }), e.triggerEvent("hide", {
                    msg: i
                });
            }, 500);
        },
        preventEvent: function() {}
    }
});