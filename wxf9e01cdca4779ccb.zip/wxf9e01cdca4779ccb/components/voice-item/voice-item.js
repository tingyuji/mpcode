Component({
    properties: {
        itemIdx: {
            type: Number
        },
        currentMusicId: {
            type: String
        },
        isMusicPlaying: {
            type: Boolean,
            value: !1
        },
        isMusicLoading: {
            type: Boolean,
            value: !1
        },
        item: {
            type: Object,
            value: {},
            observer: function(e) {}
        },
        isNightMode: {
            type: Boolean,
            value: !1
        },
        isBigFontMode: {
            type: Boolean,
            value: !1
        }
    },
    ready: function() {},
    data: {},
    methods: {}
});