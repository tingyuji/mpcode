Component({
    properties: {
        timeArray: {
            type: Array,
            value: [ 5, 10, 15, 30, 60 ]
        },
        timeType: {
            type: Number,
            value: -1,
            observer: function(t) {
                this.setData({
                    timeControlOffset: 100 * t + this.data.timeControlBaseOffset
                });
            }
        },
        timeingTipsText: {
            type: String,
            value: "未知"
        },
        isShow: {
            type: Boolean,
            value: !1
        },
        colorStyle: {
            type: String,
            value: "light"
        }
    },
    data: {
        timeControlBaseOffset: 76,
        timeControlOffset: 176,
        animTimeControlSpot: {},
        anim_timeingPannel: {}
    },
    ready: function() {
        this.winWidth = wx.getSystemInfoSync().windowWidth;
    },
    methods: {
        manualSelTimeType: function(t) {
            var i = this, e = t.currentTarget.dataset.tmtype;
            if (this.data.timeType !== e) {
                var o = 100 * e + this.data.timeControlBaseOffset;
                this.animTimeControlSpot = wx.createAnimation({
                    duration: 500,
                    timingFunction: "ease"
                }), this.animTimeControlSpot.left(o + "rpx").step({
                    duration: 500
                }), this.setData({
                    animTimeControlSpot: this.animTimeControlSpot.export()
                }), setTimeout(function() {
                    i.setData({
                        timeControlOffset: o
                    });
                }, 600), this.setData({
                    timeType: e
                }), this.notifyPosChange();
            }
        },
        timeTouchStart: function(t) {
            this.animTimeControlSpot = wx.createAnimation({
                duration: 0,
                timingFunction: "ease"
            }), this.animTimeControlSpot.opacity(1).step({
                duration: 0
            }), this.setData({
                animTimeControlSpot: this.animTimeControlSpot.export()
            }), this.originTimeOffest = this.data.timeControlOffset, this.touchX = t.changedTouches[0].clientX;
        },
        timeTouchMove: function(t) {
            var i = 750 * (t.changedTouches[0].clientX - this.touchX) / this.winWidth, e = this.originTimeOffest + i;
            e = (e = e > 600 + this.data.timeControlBaseOffset ? 600 + this.data.timeControlBaseOffset : e) < this.data.timeControlBaseOffset ? this.data.timeControlBaseOffset : e, 
            this.setData({
                timeControlOffset: e
            });
        },
        timeTouchCancel: function(t) {
            this.setData({
                timeControlOffset: this.originTimeOffest
            });
        },
        timeTouchEnd: function(t) {
            this.handleLastTimePosition(t);
        },
        handleLastTimePosition: function(t) {
            var i = this, e = this.data.timeType, o = this.originTimeOffest + 750 * (t.changedTouches[0].clientX - this.touchX) / this.winWidth - this.data.timeControlBaseOffset, n = Math.floor(o / 100), a = (n = n >= 0 ? n : 0) + (o / 100 * 100 % 100 / 100 >= .5 ? 1 : 0), s = 100 * (a = a > 5 ? 5 : a) + this.data.timeControlBaseOffset;
            this.animTimeControlSpot = wx.createAnimation({
                duration: 500,
                timingFunction: "ease"
            }), this.animTimeControlSpot.left(s + "rpx").step({
                duration: 500
            }), this.setData({
                animTimeControlSpot: this.animTimeControlSpot.export()
            }), setTimeout(function() {
                i.setData({
                    timeControlOffset: s
                });
            }, 600), this.setData({
                timeType: a
            }), e !== a && this.notifyPosChange();
        },
        notifyPosChange: function() {
            this.triggerEvent("timeChange", {
                index: this.data.timeType
            });
        },
        hideTimeingPannel: function() {
            this.triggerEvent("hide");
        }
    }
});