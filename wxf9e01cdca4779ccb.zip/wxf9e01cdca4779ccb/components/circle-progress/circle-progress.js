var t = require("../../utils/util.js");

Component({
    properties: {
        cWidth: {
            type: Number,
            value: 90,
            observer: function(t) {
                this.changeDefaultStyle();
            }
        },
        cHeight: {
            type: Number,
            value: 90,
            observer: function(t) {
                this.changeDefaultStyle();
            }
        },
        cProgressWidth: {
            type: Number,
            value: 8
        },
        cProgressColor: {
            type: String,
            value: "black"
        },
        cProgressBgColor: {
            type: String,
            value: "gray"
        },
        cBgColor: {
            type: String,
            value: "white"
        },
        cPercent: {
            type: Number,
            value: 80,
            observer: function(t) {
                this.changePercent();
            }
        }
    },
    data: {
        frameStyle: "",
        maskFrameStyle: "",
        progressLeftStyle: "",
        progressRightStyle: "",
        clipLeftStyle: "",
        clipRightStyle: ""
    },
    ready: function() {
        this.changeDefaultStyle(), this.changePercent();
    },
    methods: {
        changeDefaultStyle: function() {
            this.setData({
                frameStyle: "width:".concat(this.data.cWidth, "rpx;height:").concat(this.data.cHeight, "rpx;"),
                maskFrameStyle: "width:".concat(this.data.cWidth - 2 * this.data.cProgressWidth, "rpx;height:").concat(this.data.cHeight - 2 * this.data.cProgressWidth, "rpx;"),
                clipLeftStyle: "clip:rect(0,".concat((0, t.rpxToPx)(this.data.cHeight / 2), "px,auto,0);"),
                clipRightStyle: "clip:rect(0,auto,auto,".concat((0, t.rpxToPx)(this.data.cHeight / 2), "px);")
            });
        },
        changePercent: function() {
            var e = "", a = "", r = "", c = 3.6 * this.data.cPercent;
            (c = c >= 360 ? 360 : c) <= 180 ? (a = "transform: rotate(".concat(c, "deg);"), 
            r = "clip:rect(0,".concat((0, t.rpxToPx)(this.data.cHeight / 2), "px,auto,0);")) : (a = "transform: rotate(180deg);", 
            e = "transform: rotate(".concat(c - 180, "deg);"), r = "clip:rect(0,".concat((0, 
            t.rpxToPx)(this.data.cHeight / 2) - .2, "px,auto,0);")), this.setData({
                progressLeftStyle: e,
                progressRightStyle: a,
                clipLeftStyle: r
            });
        }
    }
});