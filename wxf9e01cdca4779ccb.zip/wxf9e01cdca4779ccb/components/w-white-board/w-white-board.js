Component({
    properties: {},
    data: {
        change_size: "",
        change_rotate: "",
        open_state: !1
    },
    ready: function() {},
    methods: {
        clickEvent: function() {
            this.data.open_state ? this.setData({
                change_size: "change-size-reverse",
                change_rotate: "",
                open_state: !1
            }) : this.setData({
                change_size: "change-size",
                change_rotate: "change-rotate",
                open_state: !0
            });
        },
        clickItem: function(e) {
            this.clickEvent();
            var t = e.currentTarget.dataset.eventType;
            this.triggerEvent(t);
        }
    }
});