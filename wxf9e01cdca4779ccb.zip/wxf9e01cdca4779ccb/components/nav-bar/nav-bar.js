var t = require("../../utils/util.js");

Component({
    properties: {
        isShowBackBtn: {
            type: Boolean,
            value: !1
        },
        isCustomBackAction: {
            type: Boolean,
            value: !1
        },
        isShowBottomLine: {
            type: Boolean,
            value: !1
        },
        isFixTop: {
            type: Boolean,
            value: !1
        },
        bgColor: {
            type: String,
            value: "transparent"
        },
        titleColor: {
            type: String,
            value: "black"
        }
    },
    data: {
        appContainerStyle: "",
        appNavStyle: ""
    },
    attached: function() {
        var a = wx.getSystemInfoSync();
        this.setData({
            appContainerStyle: "height:".concat((0, t.rpxToPx)(88) + a.statusBarHeight, "px;"),
            appNavStyle: "padding-top:".concat(a.statusBarHeight, "px;")
        });
    },
    methods: {
        goBack: function() {
            this.data.isCustomBackAction ? this.triggerEvent("back") : wx.navigateBack({
                delta: 1
            });
        }
    }
});