var e = require("../../model/user.js"), t = require("../../utils/util.js"), n = require("../../config.js"), i = new e.UserModel();

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                var n = this;
                e && ((0, t.handleAPPConfig)(this), this.setData({
                    containerStyle: "display:flex;"
                }), setTimeout(function() {
                    n.show();
                }, 300));
            }
        }
    },
    attached: function() {
        (0, t.handleAPPConfig)(this);
    },
    pageLifetimes: {
        show: function() {
            (0, t.handleAPPConfig)(this);
        }
    },
    data: {
        isShow: !1,
        containerStyle: "display:none;",
        vcodeTimer: null,
        vcodeBtnText: "获取",
        phoneVal: "",
        vcodeVal: "",
        remainSec: 0,
        isSendedVCode: !1,
        bindBtnText: "绑定"
    },
    methods: {
        phoneChange: function(e) {
            this.setData({
                phoneVal: e.detail.value
            });
        },
        vcodeChange: function(e) {
            this.setData({
                vcodeVal: e.detail.value
            });
        },
        getVcode: function() {
            var e = this;
            this.data.remainSec > 0 || (/^1[123456789]\d{9}$/.test(this.data.phoneVal) ? ((0, 
            t.showLoadingTips)(), i.getVCode({
                mobile: this.data.phoneVal
            }).then(function(n) {
                (0, t.hideLodingTips)(), wx.showToast({
                    title: "验证码已发送",
                    icon: "success"
                });
                var i = setInterval(function() {
                    e.changeVCodeCD();
                }, 1e3);
                e.setData({
                    remainSec: 60,
                    vcodeTimer: i,
                    isSendedVCode: !0
                });
            }).catch(function(e) {
                console.log(e);
            })) : wx.showToast({
                title: "请输入正确的手机号码",
                icon: "none"
            }));
        },
        changeVCodeCD: function() {
            if (this.data.remainSec > 0) {
                var e = this.data.remainSec - 1;
                this.setData({
                    remainSec: e,
                    vcodeBtnText: "".concat(e, "s")
                });
            } else clearInterval(this.data.vcodeTimer), this.setData({
                remainSec: 0,
                vcodeTimer: null,
                vcodeBtnText: "获取验证码"
            });
        },
        bindPhone: function() {
            var e = this;
            /^1[123456789]\d{9}$/.test(this.data.phoneVal) ? 0 !== this.data.vcodeVal.length ? ((0, 
            t.showLoadingTips)(), i.bindPhone({
                mobile: this.data.phoneVal,
                code: this.data.vcodeVal
            }).then(function(i) {
                (0, t.hideLodingTips)(), wx.showToast({
                    title: "手机绑定成功",
                    icon: "success"
                });
                var o = wx.getStorageSync(n.config.CONST_KEY.LOGIN_DATA) || {};
                o.user_mobile = e.data.phoneVal, wx.setStorageSync(n.config.CONST_KEY.LOGIN_DATA, o), 
                e.hide(), e.triggerEvent("bindPhoneSuccess");
            }).catch(function(e) {
                console.log(e);
            })) : wx.showToast({
                title: "请先输入验证码",
                icon: "none"
            }) : wx.showToast({
                title: "请输入正确的手机号码",
                icon: "none"
            });
        },
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        hide: function(e) {
            var t = this, n = "string" == typeof e ? e : "";
            this.setData({
                isShow: !1
            }), setTimeout(function() {
                t.setData({
                    containerStyle: "display:none;",
                    show: !1
                }), t.triggerEvent("hide", {
                    msg: n
                });
            }, 500);
        },
        preventEvent: function() {}
    }
});