var t = require("../../utils/util.js");

Component({
    properties: {},
    data: {
        topTipText: "",
        isShowTopTip: !1
    },
    attached: function() {
        var i = wx.getSystemInfoSync();
        this.setData({
            appContainerStyle: "height:".concat((0, t.rpxToPx)(88) + i.statusBarHeight, "px;"),
            appNavStyle: "padding-top:".concat(i.statusBarHeight, "px;")
        });
    },
    methods: {
        showTopTips: function(t) {
            var i = this;
            this.setData({
                topTipText: t,
                isShowTopTip: !0
            }), clearTimeout(this.topTipsTimer), this.topTipsTimer = setTimeout(function() {
                i.hideTopTips();
            }, 2e3);
        },
        hideTopTips: function() {
            this.setData({
                isShowTopTip: !1
            });
        }
    }
});