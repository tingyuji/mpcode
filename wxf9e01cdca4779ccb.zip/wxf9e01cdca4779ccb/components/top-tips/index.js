Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    var t = (o = getCurrentPages(), o[o.length - 1]).selectComponent("#top-tips");
    var o;
    t ? t.showTopTips(e) : console.warn("未找到 topTips 节点");
};