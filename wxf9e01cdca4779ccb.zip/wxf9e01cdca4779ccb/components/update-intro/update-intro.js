var t = require("../../utils/util.js");

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                var i = this;
                e && ((0, t.handleAPPConfig)(this), this.setData({
                    containerStyle: "display:flex;"
                }), setTimeout(function() {
                    i.show();
                }, 300));
            }
        },
        updateIntroText: {
            type: String,
            value: ""
        }
    },
    data: {
        isShow: !1,
        userInfo: {},
        containerStyle: "display:none;"
    },
    attached: function() {
        (0, t.handleAPPConfig)(this);
    },
    pageLifetimes: {
        show: function() {
            (0, t.handleAPPConfig)(this);
        }
    },
    methods: {
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        hide: function(t) {
            var e = this, i = "string" == typeof t ? t : "";
            this.setData({
                isShow: !1
            }), setTimeout(function() {
                e.setData({
                    containerStyle: "display:none;",
                    show: !1
                }), e.triggerEvent("hide", {
                    msg: i
                });
            }, 500);
        },
        preventEvent: function() {}
    }
});