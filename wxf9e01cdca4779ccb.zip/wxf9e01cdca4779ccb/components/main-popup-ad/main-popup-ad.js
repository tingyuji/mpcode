var t = getApp().globalData;

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                var i = this;
                e && (this.setData({
                    image: t.config.home_popup_ad.ad_img,
                    containerStyle: "display:flex;"
                }), setTimeout(function() {
                    i.show();
                }, 300));
            }
        }
    },
    data: {
        isShow: !1,
        userInfo: {},
        containerStyle: "display:none;",
        image: ""
    },
    methods: {
        show: function() {
            this.setData({
                isShow: !0
            });
        },
        hide: function(t) {
            var e = this, i = "string" == typeof t ? t : "";
            this.setData({
                isShow: !1
            }), setTimeout(function() {
                e.setData({
                    containerStyle: "display:none;",
                    show: !1
                }), e.triggerEvent("hide", {
                    msg: i
                });
            }, 500);
        },
        preventEvent: function() {},
        tapAdInner: function() {
            this.triggerEvent("tapAd");
        }
    }
});