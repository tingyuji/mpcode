Component({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {
                this.setData({
                    scrollToMid: "music-item-".concat(e.category_id, "-").concat(e.scrollToMid)
                });
            }
        },
        currentMusicId: {
            type: String
        },
        isMusicPlaying: {
            type: Boolean,
            value: !1
        },
        isMusicLoading: {
            type: Boolean,
            value: !1
        },
        timerRemainSec: {
            type: Number,
            value: 0
        },
        currentProgress: {
            type: Number,
            value: 0
        },
        isNightMode: {
            type: Boolean,
            value: !1
        },
        isBigFontMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        scrollToMid: ""
    },
    methods: {
        clickRecommend: function(e) {
            var t = e.currentTarget.dataset.item;
            this.triggerEvent("selMusic", {
                item: t
            });
        }
    }
});