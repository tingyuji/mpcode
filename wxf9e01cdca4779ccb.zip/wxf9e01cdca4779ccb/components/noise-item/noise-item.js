Component({
    properties: {
        currentMusicId: {
            type: String
        },
        isMusicPlaying: {
            type: Boolean,
            value: !1
        },
        noiseItem: {
            type: Object,
            value: {},
            observer: function(e) {}
        },
        isNew: {
            type: Boolean,
            value: !1
        },
        isNightMode: {
            type: Boolean,
            value: !1
        },
        isBigFontMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {}
});