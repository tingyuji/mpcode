Component({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(e) {}
        },
        currentMusicId: {
            type: String
        },
        isMusicPlaying: {
            type: Boolean,
            value: !1
        },
        isMusicLoading: {
            type: Boolean,
            value: !1
        },
        timerRemainSec: {
            type: Number,
            value: 0
        },
        currentProgress: {
            type: Number,
            value: 0
        },
        isNightMode: {
            type: Boolean,
            value: !1
        },
        isBigFontMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {}
});