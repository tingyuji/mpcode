Component({
    properties: {
        item: {
            type: Object,
            value: {},
            observer: function(t) {}
        },
        isNightMode: {
            type: Boolean,
            value: !1
        },
        isBigFontMode: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        tapContent: function() {
            this.triggerEvent("tapContent", {
                item: this.data.item
            });
        },
        tapIcon: function() {
            this.triggerEvent("tapIcon", {
                item: this.data.item
            });
        }
    }
});