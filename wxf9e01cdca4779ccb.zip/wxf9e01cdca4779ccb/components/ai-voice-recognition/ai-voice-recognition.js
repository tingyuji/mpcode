var e = require("../../model/noise.js"), i = require("../../utils/util.js"), t = new e.NoiseModel();

Component({
    properties: {
        item: {
            type: Object,
            value: {}
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                var i = this;
                e && (this.setData({
                    containerStyle: "display:flex;"
                }), setTimeout(function() {
                    i.show();
                }, 300));
            }
        },
        currentMusic: {
            type: Object,
            value: {},
            observer: function(e) {
                e && e.color_miniapp && e.cover_miniapp_big && this.setData({
                    iconBgPath: "/images/share/share_".concat(e.color_miniapp, ".png"),
                    iconPath: e.cover_miniapp_big
                });
            }
        }
    },
    data: {
        isShow: !1,
        userInfo: {},
        containerStyle: "display:none;",
        iconBgPath: "",
        iconPath: "",
        willToRecord: !1,
        isVoiceRecording: !1,
        voiceRecordCountLast: 3,
        isVoiceRecordCountLast: !1,
        isRecognising: !1,
        isPlayingSearchMusic: !1,
        isRandom: !1
    },
    attached: function() {
        (0, i.handleAPPConfig)(this);
    },
    pageLifetimes: {
        show: function() {
            (0, i.handleAPPConfig)(this);
        }
    },
    methods: {
        show: function() {
            this.setData({
                isShow: !0,
                isPlayingSearchMusic: !1
            });
        },
        hide: function(e) {
            var i = this, t = "string" == typeof e ? e : "";
            this.setData({
                isShow: !1
            }), setTimeout(function() {
                i.setData({
                    containerStyle: "display:none;",
                    show: !1
                }), i.triggerEvent("hide", {
                    msg: t
                });
            }, 500);
        },
        preventEvent: function() {},
        aiVoiceRecord: function() {
            var e = this;
            this.triggerEvent("pauseMusic"), this.setData({
                isVoiceRecording: !0,
                isVoiceRecordCountLast: !1,
                isPlayingSearchMusic: !1,
                voiceRecordCountLast: 3
            }), setTimeout(function() {
                e.setData({
                    willToRecord: !e.data.isVoiceRecording
                });
            }, 1e3), this.recordLastTimer = setTimeout(function() {
                e.voiceRecordCount();
            }, 5e3), wx.startRecord({
                success: function(i) {
                    var o = i.tempFilePath;
                    e.setData({
                        isRecognising: !0
                    }), t.showError = !1, t.aiRecognition({
                        filePath: o,
                        name: "voice"
                    }).then(function(i) {
                        console.log("识别结果", i);
                        var t = i.music_match;
                        e.triggerEvent("playMusic", {
                            mid: t
                        }), e.setData({
                            isRandom: !1,
                            willToRecord: !1,
                            isVoiceRecording: !1,
                            isVoiceRecordCountLast: !1,
                            isRecognising: !1,
                            isPlayingSearchMusic: !0
                        });
                    }).catch(function(i) {
                        e.triggerEvent("playMusic"), e.setData({
                            isRandom: !0,
                            willToRecord: !1,
                            isVoiceRecording: !1,
                            isVoiceRecordCountLast: !1,
                            isRecognising: !1,
                            isPlayingSearchMusic: !0
                        }), console.log(i);
                    });
                },
                fail: function(e) {
                    console.log("record", e), "startRecord:fail auth deny" !== e.errMsg ? wx.showModal({
                        title: "提示",
                        content: e.errMsg,
                        showCancel: !1
                    }) : wx.openSetting({
                        success: function(e) {}
                    });
                },
                complete: function(i) {
                    e.triggerEvent("pauseMusic"), e.setData({
                        isVoiceRecording: !1,
                        isVoiceRecordCountLast: !1
                    });
                }
            });
        },
        aiVoiceRecordStop: function() {
            clearTimeout(this.recordLastTimer), this.recordLastTimer = null, this.setData({
                isVoiceRecording: !1,
                isVoiceRecordCountLast: !1
            }), wx.stopRecord();
        },
        voiceRecordCount: function() {
            var e = this;
            if (3 === this.data.voiceRecordCountLast) this.setData({
                isVoiceRecordCountLast: !0
            }), this.recordLastTimer = setTimeout(function() {
                var i = e.data.voiceRecordCountLast - 1;
                e.setData({
                    voiceRecordCountLast: i
                }), e.recordLastTimer = setTimeout(function() {
                    e.voiceRecordCount();
                }, 1e3);
            }, 1e3); else if (this.data.voiceRecordCountLast >= 1) {
                var i = this.data.voiceRecordCountLast - 1;
                this.setData({
                    voiceRecordCountLast: i
                }), this.recordLastTimer = setTimeout(function() {
                    i > 0 ? e.voiceRecordCount() : e.aiVoiceRecordStop();
                }, 1e3);
            } else this.aiVoiceRecordStop();
        }
    }
});