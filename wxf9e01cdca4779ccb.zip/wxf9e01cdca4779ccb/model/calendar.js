Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.CalendarModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = require("../@babel/runtime/helpers/inherits"), u = require("../@babel/runtime/helpers/createSuper"), l = function(l) {
    t(i, l);
    var a = u(i);
    function i() {
        return e(this, i), a.apply(this, arguments);
    }
    return r(i, [ {
        key: "getCalendarMusic",
        value: function(e) {
            return this.request({
                url: "/calender/music",
                data: e
            });
        }
    } ]), i;
}(require("../utils/http.js").HTTP);

exports.CalendarModel = l;