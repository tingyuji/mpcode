Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.PayModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = require("../@babel/runtime/helpers/inherits"), u = require("../@babel/runtime/helpers/createSuper"), i = function(i) {
    t(l, i);
    var s = u(l);
    function l() {
        return e(this, l), s.apply(this, arguments);
    }
    return r(l, [ {
        key: "getVipGoods",
        value: function() {
            return this.request({
                url: "/vip/goods"
            });
        }
    }, {
        key: "buyVip",
        value: function(e) {
            return this.request({
                method: "POST",
                url: "/vip/order",
                data: e
            });
        }
    } ]), l;
}(require("../utils/http.js").HTTP);

exports.PayModel = i;