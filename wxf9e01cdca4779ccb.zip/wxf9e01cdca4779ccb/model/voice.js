Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.VoiceModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = require("../@babel/runtime/helpers/inherits"), i = require("../@babel/runtime/helpers/createSuper"), u = function(u) {
    t(a, u);
    var s = i(a);
    function a() {
        return e(this, a), s.apply(this, arguments);
    }
    return r(a, [ {
        key: "getVoiceCategory",
        value: function(e) {
            return this.request({
                url: "/music/voice/category",
                data: e
            });
        }
    }, {
        key: "getMusicListByCategory",
        value: function(e) {
            return this.request({
                url: "/music/voice",
                data: e
            });
        }
    } ]), a;
}(require("../utils/http.js").HTTP);

exports.VoiceModel = u;