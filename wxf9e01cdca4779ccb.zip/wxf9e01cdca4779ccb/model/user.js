Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.UserModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), n = require("../@babel/runtime/helpers/inherits"), r = require("../@babel/runtime/helpers/createSuper"), i = require("../utils/http.js"), o = require("../config.js"), c = function(i) {
    n(u, i);
    var c = r(u);
    function u() {
        return e(this, u), c.apply(this, arguments);
    }
    return t(u, [ {
        key: "getUserInfo",
        value: function() {
            var e = this;
            return new Promise(function(t, n) {
                e.request({
                    url: "/user/info"
                }).then(function(e) {
                    wx.setStorageSync(o.config.CONST_KEY.LOGIN_DATA, e), wx.setStorageSync(o.config.CONST_KEY.VIP_INFO, e.user_cosleep || {
                        vip_expires: 0,
                        is_vip: 0
                    }), t(e);
                }).catch(function(e) {
                    n(e);
                });
            });
        }
    }, {
        key: "getVCode",
        value: function(e) {
            return this.request({
                method: "POST",
                url: "/verifycode/send",
                data: e
            });
        }
    }, {
        key: "bindPhone",
        value: function(e) {
            return this.request({
                method: "POST",
                url: "/user/mobile/bind",
                data: e
            });
        }
    }, {
        key: "wxBindPhone",
        value: function(e) {
            var t = this;
            return new Promise(function(n, r) {
                t.request({
                    method: "POST",
                    url: "/user/mobile/set",
                    data: e
                }).then(function(e) {
                    wx.setStorageSync(o.config.CONST_KEY.LOGIN_DATA, e), wx.setStorageSync(o.config.CONST_KEY.VIP_INFO, e.user_cosleep || {
                        vip_expires: 0,
                        is_vip: 0
                    }), n(e);
                }).catch(function(e) {
                    r(e);
                });
            });
        }
    }, {
        key: "delAccount",
        value: function() {
            var e = this;
            return new Promise(function(t, n) {
                e.request({
                    method: "POST",
                    url: "/user/suicide"
                }).then(function(e) {
                    wx.removeStorageSync(o.config.CONST_KEY.TOKEN), t(e);
                }).catch(function(e) {
                    n(e);
                });
            });
        }
    }, {
        key: "getShareWxCode",
        value: function(e) {
            var t = this, n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
            return new Promise(function(r, i) {
                var c = "".concat(o.config.CONST_KEY.WX_ACODE_KEY_PREFIX).concat(JSON.stringify(e)), u = wx.getStorageSync(c);
                u ? wx.getFileInfo({
                    filePath: u,
                    success: function(e) {
                        console.log(e), r(u);
                    },
                    fail: function(o) {
                        console.log(o), t._getShareWxCode(e, n).then(function(e) {
                            r(e);
                        }).catch(function(e) {
                            i(e);
                        });
                    }
                }) : t._getShareWxCode(e, n).then(function(e) {
                    r(e);
                }).catch(function(e) {
                    i(e);
                });
            });
        }
    }, {
        key: "_getShareWxCode",
        value: function(e) {
            var t = this, n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return new Promise(function(r, i) {
                var c = "".concat(o.config.CONST_KEY.WX_ACODE_KEY_PREFIX).concat(JSON.stringify(e));
                return t.request({
                    method: "POST",
                    url: "/qrcode/create",
                    data: e
                }).then(function(e) {
                    wx.getImageInfo({
                        src: e.qrcode_url,
                        success: function(e) {
                            n ? wx.saveFile({
                                tempFilePath: e.path,
                                success: function(e) {
                                    var t = e.savedFilePath;
                                    wx.setStorageSync(c, t), r(t);
                                },
                                fail: function(e) {
                                    i(e);
                                }
                            }) : r(e.path);
                        },
                        fail: function(e) {
                            i(e);
                        }
                    });
                }).catch(function(e) {
                    i(e);
                });
            });
        }
    } ]), u;
}(i.HTTP);

exports.UserModel = c;