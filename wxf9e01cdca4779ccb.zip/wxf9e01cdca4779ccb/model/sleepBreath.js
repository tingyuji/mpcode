Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SleepBreathModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), t = require("../@babel/runtime/helpers/inherits"), l = require("../@babel/runtime/helpers/createSuper"), u = function(u) {
    t(s, u);
    var i = l(s);
    function s() {
        return e(this, s), i.apply(this, arguments);
    }
    return r(s, [ {
        key: "getSleepBreathList",
        value: function() {
            return this.request({
                url: "/sleep/breath"
            });
        }
    }, {
        key: "getSleepBreathDetail",
        value: function(e) {
            return this.request({
                url: "/sleep/breath/detail",
                data: e
            });
        }
    } ]), s;
}(require("../utils/http.js").HTTP);

exports.SleepBreathModel = u;