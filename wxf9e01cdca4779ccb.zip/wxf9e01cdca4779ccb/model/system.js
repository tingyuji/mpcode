Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SystemModel = void 0;

var e = require("../@babel/runtime/helpers/typeof"), t = require("../@babel/runtime/helpers/classCallCheck"), r = require("../@babel/runtime/helpers/createClass"), i = require("../@babel/runtime/helpers/inherits"), u = require("../@babel/runtime/helpers/createSuper"), n = function(n) {
    i(s, n);
    var l = u(s);
    function s() {
        return t(this, s), l.apply(this, arguments);
    }
    return r(s, [ {
        key: "getConfig",
        value: function() {
            return this.request({
                url: "/config"
            });
        }
    }, {
        key: "getNotification",
        value: function() {
            return this.request({
                url: "/notification"
            });
        }
    }, {
        key: "getAd",
        value: function() {
            return this.request({
                url: "/ad"
            });
        }
    }, {
        key: "reportError",
        value: function(t, r) {
            var i = "object" === e(t) ? t : {
                title: r,
                content: t
            }, u = i.title, n = i.content;
            return this.request({
                method: "POST",
                url: "/catchError",
                data: {
                    title: u,
                    content: n
                }
            });
        }
    } ]), s;
}(require("../utils/http.js").HTTP);

exports.SystemModel = n;