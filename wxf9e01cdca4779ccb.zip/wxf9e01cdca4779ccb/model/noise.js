Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.NoiseModel = void 0;

var e = require("../@babel/runtime/helpers/classCallCheck"), t = require("../@babel/runtime/helpers/createClass"), r = require("../@babel/runtime/helpers/inherits"), i = require("../@babel/runtime/helpers/createSuper"), u = function(u) {
    r(l, u);
    var s = i(l);
    function l() {
        return e(this, l), s.apply(this, arguments);
    }
    return t(l, [ {
        key: "getNoiseMusicList",
        value: function() {
            return this.request({
                url: "/music/simpleDetail"
            });
        }
    }, {
        key: "getMusicListByTag",
        value: function(e) {
            return this.request({
                url: "/tag/music",
                data: e
            });
        }
    }, {
        key: "getTagList",
        value: function() {
            return this.request({
                url: "/music/tag"
            });
        }
    }, {
        key: "aiRecognition",
        value: function(e) {
            var t = Object.assign(e, {
                url: "/bot/speechToText"
            });
            return this.uploadFile(t);
        }
    } ]), l;
}(require("../utils/http.js").HTTP);

exports.NoiseModel = u;