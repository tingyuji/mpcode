var o = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../config.js"), i = require("../../model/pay.js"), t = require("../../model/user.js"), n = require("../../utils/util.js"), a = o(require("../../components/top-tips/index")), s = new i.PayModel(), r = new t.UserModel();

Page({
    data: {
        vipInfo: {},
        userVipExpire: "",
        vipGoods: [],
        currentVipGood: {},
        isShowBindPhone: !1
    },
    onLoad: function(o) {
        this.loadUserMobileFromCache(), this.loadVipInfoFromCache(), (0, n.showLoadingTips)(), 
        this.loadPayData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        (0, n.showLoadingTips)(), this.loadPayData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, n.getCommonShareData)();
    },
    loadUserMobileFromCache: function() {
        var o = wx.getStorageSync(e.config.CONST_KEY.LOGIN_DATA);
        this.setData({
            user_mobile: o.mobile
        });
    },
    loadVipInfoFromCache: function() {
        var o = wx.getStorageSync(e.config.CONST_KEY.VIP_INFO);
        this.setData({
            vipInfo: o,
            userVipExpire: 1 === o.is_vip ? (0, n.formatTimeFromTs)(1e3 * o.vip_expires) : "还不是会员"
        });
    },
    loadPayData: function() {
        var o = this;
        Promise.all([ r.getUserInfo(), s.getVipGoods() ]).then(function(e) {
            (0, n.hideLodingTips)(), o.loadVipInfoFromCache();
            var i = e[1];
            o.setData({
                currentVipGood: i[0],
                vipGoods: i
            });
        }).catch(function(o) {
            console.log(o);
        });
    },
    selVipGood: function(o) {
        var e = o.currentTarget.dataset.item;
        this.setData({
            currentVipGood: e
        });
    },
    buyUser: function() {
        var o = this;
        (0, n.showLoadingTips)();
        var e = this.data.currentVipGood.goods_id;
        s.buyVip({
            goods_id: e
        }).then(function(e) {
            (0, n.hideLodingTips)();
            var i = Object.assign(e.pay_platforms.wechatpay, {
                success: function(e) {
                    console.log(e), (0, a.default)("你已成功开通".concat(o.data.currentVipGood.goods_name, "会员")), 
                    r.getUserInfo().then(function(e) {
                        o.loadVipInfoFromCache();
                    }).catch();
                },
                fail: function(o) {
                    console.log(o), (0, a.default)("支付尚未成功");
                }
            });
            wx.requestPayment(i);
        }).catch(function(e) {
            console.log(e), (0, n.hideLodingTips)(), o.setData({
                isShowBindPhone: !0
            });
        });
    },
    getPhoneNumber: function(o) {
        var e = this;
        o.detail.iv && o.detail.encryptedData && ((0, n.showLoadingTips)(), r.wxBindPhone({
            iv: o.detail.iv,
            encryptedData: o.detail.encryptedData
        }).then(function(o) {
            (0, n.hideLodingTips)(), e.loadUserMobileFromCache(), e.buyUser();
        }).catch(function(o) {
            (0, n.hideLodingTips)(), console.log(o), o && !o.status && e.buyUser();
        }));
    },
    gotoAgreement: function() {
        wx.navigateTo({
            url: "/pages/web/web?url=https://www.heartide.com/cosleep/help/doc#/agreement"
        });
    },
    gotoPrivacy: function() {
        wx.navigateTo({
            url: "/pages/web/web?url=https://www.heartide.com/cosleep/help/doc#/gkqb8z"
        });
    }
});