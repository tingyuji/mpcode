var n = require("../../model/system.js"), e = require("../../utils/util.js"), t = new n.SystemModel(), o = getApp().globalData;

Page({
    data: {
        innerAdsList: []
    },
    onLoad: function(n) {
        var i = this;
        o.query = Object.assign(o.query, (0, e.handleAppPageOption)(n)), (0, e.handleAPPConfig)(this), 
        (0, e.showLoadingTips)(), t.getAd().then(function(n) {
            (0, e.hideLodingTips)(), i.setData({
                innerAdsList: n.resource_recommend
            });
        }).catch(function(n) {
            console.log(n), (0, e.hideLodingTips)();
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.getCommonShareData)();
    },
    openMiniApp: function(n) {
        var e = n.currentTarget.dataset.appdata, o = {};
        try {
            o = JSON.parse(e.recommend_link);
        } catch (n) {
            t.reportError(n.message, "app内页推荐JSON解析错误").then().catch();
        }
        o.success = function(n) {
            wx.reportAnalytics("recommend_app_inner", {
                appid: e.recommend_id,
                appname: e.recommend_title
            });
        }, o.fail = function(n) {
            t.reportError(n.errMsg, "app内页推荐唤起失败").then().catch(), wx.showToast({
                title: "打开“".concat(e.recommend_title, "”失败"),
                icon: "none",
                duration: 2e3
            });
        }, wx.navigateToMiniProgram(o);
    }
});