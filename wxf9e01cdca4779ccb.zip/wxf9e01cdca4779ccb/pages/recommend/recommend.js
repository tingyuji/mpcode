var e = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../model/recommend.js"), t = require("../../utils/util.js"), n = require("../../config.js"), a = new i.RecommendModel(), s = getApp().globalData;

Page({
    data: {
        musicList: [],
        currentMusic: {},
        isMusicLoading: !1,
        isMusicPlaying: !1,
        currentTime: 0,
        currentProgress: 0,
        timerRemainSec: 0,
        timeMinsPerPlay: 30
    },
    onLoad: function(e) {
        s.query = Object.assign(s.query, (0, t.handleAppPageOption)(e)), (0, t.handleAPPConfig)(this, !0), 
        (0, t.showLoadingTips)(), this.getRecommendMusicList();
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        if ((0, t.handleAPPConfig)(this, !0), this.hidePageTimerRemainSec > 0 && this.hidePageTs > 0) {
            var i = new Date().getTime(), a = Math.floor((i - this.hidePageTs) / 1e3), o = this.hidePageTimerRemainSec - a;
            o = o > 0 ? o : 0, this.setData({
                timerRemainSec: o
            }), setTimeout(function() {
                e.startTimer();
            }, 1), this.hidePageTimerRemainSec = 0, this.hidePageTs = 0;
        }
        s.currentMusicType === n.config.MUSIC_TYPE.RECOMMEND ? this.bindAudioStatus() : this.setData({
            isMusicPlaying: !1
        });
    },
    onHide: function() {
        this.data.isMusicPlaying && (this.hidePageTimerRemainSec = this.data.timerRemainSec, 
        this.hidePageTs = new Date().getTime());
    },
    onUnload: function() {
        console.warn("recommend unload");
    },
    onPullDownRefresh: function() {
        (0, t.showLoadingTips)(), this.getRecommendMusicList();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = (0, t.getCommonShareData)();
        return this.data.currentMusic.recommend_id && (e.path += "&tid=".concat(this.data.currentMusic.recommend_category_id, "&mid=").concat(this.data.currentMusic.recommend_id)), 
        e;
    },
    getRecommendMusicList: function() {
        var i = this;
        a.getRecommendMusicList().then(function(n) {
            if ((0, t.hideLodingTips)(), i.setData({
                musicList: n
            }), s.query.tid) {
                var a = parseInt(s.query.tid);
                delete s.query.tid;
                for (var o = function(t) {
                    var o = n[t];
                    if (o.category_id === a) {
                        var r = wx.createSelectorQuery();
                        return r.select(".category-item-".concat(a)).boundingClientRect(), r.selectViewport(), 
                        r.exec(function(n) {
                            var a = n[0], r = s.isAndroid ? 800 : 500;
                            setTimeout(function() {
                                wx.pageScrollTo({
                                    scrollTop: a.height * t,
                                    duration: 300
                                }), setTimeout(function() {
                                    if (s.query.mid) {
                                        var n = parseInt(s.query.mid);
                                        delete s.query.mid;
                                        for (var a = 0; a < o.recommend_list.length; a++) {
                                            var r = o.recommend_list[a];
                                            if (r.recommend_id === n) {
                                                var c = {
                                                    detail: {
                                                        item: r
                                                    }
                                                };
                                                i.setData(e({}, "musicList[".concat(t, "].scrollToMid"), n)), i.selMusic(c);
                                                break;
                                            }
                                        }
                                    }
                                }, 300);
                            }, r);
                        }), "break";
                    }
                }, r = 0; r < n.length; r++) {
                    if ("break" === o(r)) break;
                }
            }
        }).catch(function(e) {
            console.error(e), (0, t.hideLodingTips)();
        });
    },
    rePlayCurrentMusic: function() {
        var e = this.data.currentMusic;
        this.bindAudioStatus(), this.setData({
            isMusicLoading: !0
        }), s.currentMusic = e, s.currentMusicUrl = e.recommend_music, s.currentMusicType = n.config.MUSIC_TYPE.RECOMMEND;
        var i = wx.getBackgroundAudioManager();
        i.stop(), i.src = e.recommend_music, i.title = e.recommend_name, i.epname = "心潮小睡眠", 
        i.singer = "", i.coverImgUrl = encodeURI(e.recommend_bg), i.seek(0), i.play(), this.startTimer();
    },
    toggleMusic: function() {
        this.selMusic();
    },
    selMusic: function(e) {
        var i = wx.getBackgroundAudioManager(), t = e ? e.detail.item : this.data.currentMusic;
        if (t.recommend_id) {
            if (this.data.currentMusic.recommend_id === t.recommend_id && i.src === t.recommend_music) return i.paused ? i.currentTime >= i.duration || 0 === i.currentTime ? this.rePlayCurrentMusic() : i.play() : i.pause(), 
            void this.setData({
                isMusicPlaying: !this.data.isMusicPlaying
            });
            this.data.currentMusic.recommend_id === t.recommend_id || this.setData({
                timerRemainSec: 60 * this.data.timeMinsPerPlay
            }), this.setData({
                currentMusic: t
            }), this.rePlayCurrentMusic();
        }
    },
    bindAudioStatus: function() {
        var e = this;
        clearInterval(s.noiseTimer), clearInterval(s.recommendTimer);
        var i = wx.getBackgroundAudioManager();
        this.setData({
            isMusicPlaying: !i.paused
        }), i.onWaiting(function() {
            console.log("recommend 音频加载中"), e.setData({
                isMusicLoading: !0
            });
        }), i.onCanplay(function() {
            console.log("recommend 音频onCanplay"), e.setData({
                isMusicLoading: !1
            });
        }), i.onPlay(function() {
            console.log("recommend 音频播放中"), e.setData({
                isMusicPlaying: !0,
                isMusicLoading: !1
            }), e.startTimer();
        }), i.onTimeUpdate(function() {}), i.onPause(function() {
            console.log("recommend onPause"), e.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), i.onStop(function() {
            console.log("recommend onStop"), e.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), i.onEnded(function() {
            if (console.log("recommend onEnded"), e.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), e.hidePageTimerRemainSec > 0 && e.hidePageTs > 0) {
                var i = new Date().getTime(), t = Math.floor((i - e.hidePageTs) / 1e3), n = e.hidePageTimerRemainSec - t;
                n > 0 ? (console.log("页面处于后台位置，且剩余时为".concat(n, "，继续循环")), e.rePlayCurrentMusic()) : console.log("页面处于后台位置，且剩余时小于等于0，结束循环");
            } else e.data.timerRemainSec > 0 ? (console.log("页面处于前端位置，且剩余时为".concat(e.data.timerRemainSec, "，继续循环")), 
            e.rePlayCurrentMusic()) : console.log("定时已经结束，所以onend不会触发循环播放");
        }), i.onError(function(i) {
            console.log("recommend onError", i), e.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), (0, t.hideLodingTips)(), wx.showToast({
                title: "音频加载失败(".concat(i.errCode, ")"),
                icon: "none"
            });
        });
    },
    startTimer: function() {
        var e = this;
        this.stopTimer(), console.log("startTimer");
        var i = setInterval(function() {
            var i = e.data.timerRemainSec;
            i > 0 && e.data.isMusicPlaying ? (i -= 1, e.setData({
                timerRemainSec: i,
                currentProgress: 100 * (1 - i / (60 * e.data.timeMinsPerPlay))
            })) : i <= 0 && e.timeoutCallBack();
        }, 1e3);
        s.recommendTimer = i, this.setData({
            timer: i
        });
    },
    timeoutCallBack: function() {
        console.log("定时已经结束回调，停止音频，并重置时间"), wx.getBackgroundAudioManager().stop(), this.setData({
            timerRemainSec: 60 * this.data.timeMinsPerPlay
        });
    },
    stopTimer: function() {
        console.log("stopTimer"), clearInterval(this.data.timer);
    }
});