var t = require("../../model/system.js"), e = require("../../utils/util.js"), o = new t.SystemModel();

Page({
    data: {
        isShowUpdateIntro: !1,
        updateIntroText: ""
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, e.getCommonShareData)();
    },
    showUpdateIntro: function() {
        var t = this;
        this.data.updateIntroText && this.data.updateIntroText.length > 0 ? this.setData({
            isShowUpdateIntro: !0
        }) : ((0, e.showLoadingTips)(), o.getNotification().then(function(o) {
            (0, e.hideLodingTips)(), t.setData({
                updateIntroText: o.miniapp_update,
                isShowUpdateIntro: !0
            });
        }).catch(function(t) {
            console.error(t), (0, e.hideLodingTips)();
        }));
    },
    hideUpdateIntro: function() {
        this.setData({
            isShowUpdateIntro: !1
        });
    },
    gotoService: function() {
        wx.navigateTo({
            url: "/pages/web/web?url=https://www.heartide.com/cosleep/help/doc#/dn8inn"
        });
    },
    gotoPrivacy: function() {
        wx.navigateTo({
            url: "/pages/web/web?url=https://www.heartide.com/cosleep/help/doc#/gkqb8z"
        });
    }
});