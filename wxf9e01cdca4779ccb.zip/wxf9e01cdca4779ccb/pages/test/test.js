var e = require("../../utils/util.js");

Page({
    data: {
        todayDate: new Date().getTime(),
        codeDate: new Date(2020, 0, 1).getTime(),
        codeMinDate: new Date(2020, 0, 1).getTime(),
        codeMaxDate: new Date(2020, 11, 31).getTime(),
        firstInChecked: !0
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    onChangeFirstIn: function(e) {
        this.setData({
            firstInChecked: e.detail
        });
    },
    todayDateChange: function(e) {
        this.setData({
            todayDate: e.detail
        });
    },
    codeDateChange: function(e) {
        this.setData({
            codeDate: e.detail
        });
    },
    gotest: function() {
        var t = Math.floor((this.data.codeDate - 1577808e6) / 864e5) + 1, a = "/pages/calendar/calendar?fromTestPage=1&calendarId=".concat(t, "&isFirstIn=").concat(this.data.firstInChecked ? 1 : 0, "&fakeToday=").concat(this.data.todayDate);
        console.info(a), (0, e.showLoadingTips)("跳转中"), wx.navigateTo({
            url: a,
            complete: function() {
                (0, e.hideLodingTips)();
            }
        });
    }
});