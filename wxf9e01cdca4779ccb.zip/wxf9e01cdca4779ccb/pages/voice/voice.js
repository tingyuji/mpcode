var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../model/voice.js"), a = require("../../utils/util.js"), s = require("../../config.js"), o = t(require("../../components/top-tips/index")), r = new i.VoiceModel(), n = getApp().globalData;

Page({
    data: {
        currentMusic: {},
        categoryMusicListsHash: {},
        categoryList: [],
        selCategoryId: 0,
        currentCategoryIdx: 0,
        categorySelectedLeft: 0,
        categorySelectedWidth: 0,
        musicList: [],
        isShowVoiceTips: !1,
        bottomOriginSwiperHeight: 0,
        bottomSwiperHeight: 0,
        musicViewOriginContainerHeight: 0,
        musicTopViewStyle: "",
        musicListViewStyle: "",
        isMusicLoading: !1,
        isMusicPlaying: !1,
        categoryScrollLeft: 0,
        currentTime: 0,
        currentProgress: 0,
        resumeCurrentTime: 0,
        isShowBuyTips: !1,
        currentPlayMode: 1,
        currentPlayTime: 1,
        totalPlayTime: 1,
        playTimeText: "1/1",
        vipInfo: wx.getStorageSync(s.config.CONST_KEY.VIP_INFO) || {}
    },
    onLoad: function(t) {
        this.setData({
            vipInfo: wx.getStorageSync(s.config.CONST_KEY.VIP_INFO)
        }), n.query = Object.assign(n.query, (0, a.handleAppPageOption)(t)), (0, a.handleAPPConfig)(this, !0), 
        (0, a.showLoadingTips)(), this.getVoiceData();
    },
    onReady: function() {
        var t = this, e = wx.createSelectorQuery();
        e.selectAll(".music-view-container").boundingClientRect(), e.selectViewport(), e.exec(function(e) {
            var i = e[0];
            t.setData({
                musicViewOriginContainerHeight: i[0].height
            });
        }), this.calcBottomPannelHeight();
    },
    onShow: function() {
        (0, a.handleAPPConfig)(this, !0), n.currentMusicType === s.config.MUSIC_TYPE.VOICE ? this.bindAudioStatus() : this.setData({
            isMusicPlaying: !1
        });
        var t = wx.getStorageSync(s.config.CONST_KEY.VIP_INFO);
        if (this.data.vipInfo.is_vip !== t.is_vip && this.getVoiceData(), this.setData({
            vipInfo: t
        }), n.voiceJump && this.data.categoryList.length > 0) {
            var e = n.voiceJump;
            if (this.jumpToCategoryId(e.category_id), this.data.categoryMusicListsHash[this.data.selCategoryId] && this.data.categoryMusicListsHash[this.data.selCategoryId].lists.length > 0) {
                delete n.voiceJump;
                var i = {
                    currentTarget: {
                        dataset: {
                            item: this.data.categoryMusicListsHash[this.data.selCategoryId].lists[0]
                        }
                    }
                };
                this.selMusic(i);
            }
        }
    },
    onHide: function() {},
    onUnload: function() {
        console.warn("voice unload");
    },
    onPullDownRefresh: function() {
        this.getVoiceData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = (0, a.getCommonShareData)();
        return this.data.currentMusic.id && (t.imageUrl = encodeURI(this.data.currentMusic.resurl), 
        t.path += "&tid=".concat(this.data.selCategoryId, "&mid=").concat(this.data.currentMusic.id)), 
        t;
    },
    calcBottomPannelHeight: function() {
        var t = this, e = wx.createSelectorQuery();
        e.selectAll(".voice-list-container, #music-category-scrollview").boundingClientRect(), 
        e.selectViewport(), e.exec(function(e) {
            var i = e[0];
            t.setData({
                bottomOriginSwiperHeight: i[0].height - i[1].height,
                bottomSwiperHeight: i[0].height - i[1].height
            });
        });
    },
    toggleTips: function() {
        this.data.isShowVoiceTips ? this.closeTips() : this.openTips();
    },
    openTips: function() {
        var t = this, e = wx.createSelectorQuery();
        e.selectAll(".music-view").boundingClientRect(), e.selectViewport(), e.exec(function(e) {
            var i = e[0];
            t.setData({
                isShowVoiceTips: !0,
                musicListViewStyle: "height:".concat(wx.getSystemInfoSync().windowHeight - i[0].bottom, "px;"),
                musicTopViewStyle: "height:".concat(i[0].height, "px;"),
                bottomSwiperHeight: t.data.bottomOriginSwiperHeight - (i[0].height - t.data.musicViewOriginContainerHeight)
            });
        });
    },
    closeTips: function() {
        this.setData({
            isShowVoiceTips: !1,
            musicListViewStyle: "",
            musicTopViewStyle: "",
            bottomSwiperHeight: this.data.bottomOriginSwiperHeight
        });
    },
    getVoiceData: function() {
        var t = this;
        this.setData({
            categoryList: [],
            categoryMusicListsHash: {}
        }), r.getVoiceCategory().then(function(e) {
            if ((0, a.hideLodingTips)(), t.setData({
                categoryList: e
            }), n.query.tid) {
                var i = parseInt(n.query.tid);
                delete n.query.tid;
                for (var s = 0; s < e.length; s++) {
                    var o = e[s];
                    o.category_id === i && (t.setData({
                        currentCategoryIdx: s,
                        selCategoryId: o.category_id
                    }), t.changeSelectLinePos());
                }
            }
            if (n.voiceJump) {
                var r = n.voiceJump, c = t.getCategoryPosInfo(r.category_id).idx;
                t.setData({
                    currentCategoryIdx: c,
                    selCategoryId: r.category_id
                }), t.changeSelectLinePos();
            }
            0 === t.data.selCategoryId && (t.setData({
                selCategoryId: e[0].category_id
            }), t.changeSelectLinePos()), t.getCurrentCategoryMusicList(), t.calcBottomPannelHeight();
        }).catch(function(t) {
            console.log(t);
        });
    },
    changeCategory: function(t) {
        var e = t.currentTarget.dataset.item, i = t.currentTarget.dataset.idx;
        this.setData({
            selCategoryId: e.category_id,
            currentCategoryIdx: i
        }), this.changeSelectLinePos();
    },
    bindCategoryChange: function(t) {
        var e = t.detail.current, i = this.data.categoryList[e];
        this.setData({
            selCategoryId: i.category_id,
            currentCategoryIdx: e
        }), this.changeSelectLinePos(), this.getCurrentCategoryMusicList();
    },
    changeSelectLinePos: function() {
        var t = this;
        Promise.all([ new Promise(function(t, e) {
            var i = wx.createSelectorQuery();
            i.select("#music-category-contentview").boundingClientRect(), i.selectViewport(), 
            i.exec(function(e) {
                var i = e[0];
                t(i);
            });
        }), new Promise(function(e, i) {
            var a = wx.createSelectorQuery();
            a.select(".category-item-".concat(t.data.selCategoryId, " .title")).boundingClientRect(), 
            a.selectViewport(), a.exec(function(t) {
                var i = t[0];
                e(i);
            });
        }) ]).then(function(e) {
            var i = e[0], a = e[1];
            t.setData({
                categorySelectedLeft: a.left - i.left,
                categorySelectedWidth: a.width,
                categoryScrollLeft: a.left - i.left - (wx.getSystemInfoSync().windowWidth - a.width) / 2
            });
        });
    },
    loadMoreData: function() {
        this.getCurrentCategoryMusicList(!0);
    },
    getCurrentCategoryMusicList: function(t) {
        var i = this, o = this.data.categoryMusicListsHash[this.data.selCategoryId] || {
            p: -1,
            lists: [],
            loading: !1,
            end: !1
        };
        o.end || !t && o.p > -1 ? (0, a.hideLodingTips)() : (-1 === o.p && (0, a.showLoadingTips)(), 
        o.loading = !0, this.setData(e({}, "categoryMusicListsHash.".concat(this.data.selCategoryId), o)), 
        r.getMusicListByCategory({
            category_id: this.data.selCategoryId,
            p: o.p + 1
        }).then(function(t) {
            (0, a.hideLodingTips)();
            var r = t.filter(function(t) {
                return 1 === t.single_auth;
            }), c = t.filter(function(t) {
                return !t.single_auth;
            });
            if (t = r.concat(c), !n.canBuy && n.config.audit_mode) {
                var u = wx.getStorageSync(s.config.CONST_KEY.VIP_INFO);
                t = t.filter(function(t) {
                    return !(1 === t.needvip && 1 !== t.single_auth && !u.is_vip);
                });
            }
            if (o.loading = !1, o.end = 0 === t.length, o.lists = o.lists.concat(t), o.p++, 
            i.setData(e({}, "categoryMusicListsHash.".concat(i.data.selCategoryId), o)), n.query.mid) {
                var l = parseInt(n.query.mid);
                delete n.query.mid;
                for (var d = 0; d < o.lists.length; d++) {
                    var g = o.lists[d];
                    if (g.id === l) {
                        i.setData(e({}, "categoryMusicListsHash.".concat(i.data.selCategoryId, ".scrollIntoView"), "music-item-".concat(i.data.selCategoryId, "-").concat(l)));
                        var h = {
                            currentTarget: {
                                dataset: {
                                    item: g
                                }
                            }
                        };
                        i.selMusic(h);
                        break;
                    }
                }
            }
            if (n.voiceJump) {
                delete n.voiceJump;
                var y = {
                    currentTarget: {
                        dataset: {
                            item: i.data.categoryMusicListsHash[i.data.selCategoryId].lists[0]
                        }
                    }
                };
                i.selMusic(y);
            }
        }).catch(function(t) {
            console.log(t);
        }));
    },
    rePlayCurrentMusic: function() {
        var t = this.data.currentMusic;
        this.bindAudioStatus(), this.setData({
            isMusicLoading: !0
        }), n.currentMusic = t, n.currentMusicUrl = t.musicurl, n.currentMusicType = s.config.MUSIC_TYPE.VOICE;
        var e = wx.getBackgroundAudioManager();
        e.stop(), e.src = t.musicurl, e.title = t.musicdesc, e.epname = "心潮小睡眠", e.singer = "", 
        e.coverImgUrl = encodeURI(t.resurl), e.seek(0), e.play();
    },
    toggleMusic: function() {
        this.data.currentMusic.id || this.setData({
            currentMusic: this.data.categoryMusicListsHash[this.data.selCategoryId].lists[0]
        }), this.selMusic();
    },
    selMusic: function(t) {
        var e = wx.getBackgroundAudioManager(), i = t ? t.currentTarget.dataset.item : this.data.currentMusic;
        if (i.id) if (1 !== i.needvip || 1 === i.single_auth || this.data.vipInfo.is_vip) {
            if (this.data.currentMusic.id === i.id && e.src === i.musicurl) return e.paused ? e.currentTime >= e.duration || 0 === e.currentTime ? this.rePlayCurrentMusic() : e.play() : e.pause(), 
            void this.setData({
                isMusicPlaying: !this.data.isMusicPlaying
            });
            this.data.currentMusic.id === i.id && this.setData({
                resumeCurrentTime: this.data.currentTime
            }), this.setData({
                currentMusic: i
            }), this.rePlayCurrentMusic();
        } else n.isIOS && !n.config.ios_pay_enable || n.isAndroid && !n.config.android_pay_enable ? (0, 
        o.default)("你还不是会员") : this.setData({
            isShowBuyTips: !0
        });
    },
    bindAudioStatus: function() {
        var t = this;
        clearInterval(n.noiseTimer), clearInterval(n.recommendTimer);
        var e = wx.getBackgroundAudioManager();
        this.setData({
            isMusicPlaying: !e.paused
        }), e.onWaiting(function() {
            console.log("white voice 音频加载中"), t.setData({
                isMusicLoading: !0
            });
        }), e.onCanplay(function() {
            console.log("white voice 音频onCanplay"), t.setData({
                isMusicLoading: !1
            });
        }), e.onPlay(function() {
            (console.log("white voice 音频播放中"), t.setData({
                isMusicPlaying: !0,
                isMusicLoading: !1
            }), t.data.resumeCurrentTime > 0) && (wx.getBackgroundAudioManager().seek(t.data.resumeCurrentTime), 
            t.setData({
                resumeCurrentTime: 0
            }));
        }), e.onTimeUpdate(function() {
            t.setData({
                currentProgress: Math.floor(e.currentTime / e.duration * 100),
                currentTime: e.currentTime
            });
        }), e.onPause(function() {
            console.log("white voice onPause"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), e.onStop(function() {
            console.log("white voice onStop"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), e.onEnded(function() {
            console.log("white voice onEnded"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), t.data.totalPlayTime > 5 ? t.playNextMusic() : t.data.currentPlayTime < t.data.totalPlayTime ? (t.setData({
                currentPlayTime: t.data.currentPlayTime + 1
            }), t.playNextMusic()) : t.resetTime(), t.calcPlayTimeText();
        }), e.onError(function(e) {
            console.log("white voice onError", e), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), (0, a.hideLodingTips)(), wx.showToast({
                title: "音频加载失败(".concat(e.errCode, ")"),
                icon: "none"
            });
        });
    },
    playNextMusic: function() {
        if (1 === this.data.currentPlayMode && this.rePlayCurrentMusic(), 2 === this.data.currentPlayMode) {
            for (var t, e, i = this.data.categoryMusicListsHash[this.data.selCategoryId].lists, a = -1, s = 0; s < i.length; s++) {
                var o = i[s], r = !0;
                if (1 === o.needvip && 1 !== o.single_auth && (this.data.vipInfo.is_vip || (r = !1)), 
                r && !t && (t = o), o.id === this.data.currentMusic.id && (a = s), a >= 0 && s > a && r && !e) {
                    e = o;
                    break;
                }
            }
            this.setData({
                currentMusic: e || t
            }), this.rePlayCurrentMusic();
        }
    },
    changePlayMode: function() {
        var t = 1 === this.data.currentPlayMode ? 2 : 1, e = 1 === t ? "开启单曲播放模式" : 2 === t ? "开启列表播放模式" : "";
        this.setData({
            currentPlayMode: t
        }), (0, o.default)(e);
    },
    changePlayTime: function() {
        var t = this.data.totalPlayTime > 5 ? 1 : this.data.totalPlayTime + 1;
        this.setData({
            currentPlayTime: 1,
            totalPlayTime: t
        }), this.calcPlayTimeText(), this.data.totalPlayTime > 5 ? (1 === this.data.currentPlayMode && (0, 
        o.default)("循环播放该单曲"), 2 === this.data.currentPlayMode && (0, o.default)("循环播放列表")) : (1 === this.data.currentPlayMode && (0, 
        o.default)("播放该单曲".concat(this.data.totalPlayTime, "次")), 2 === this.data.currentPlayMode && (0, 
        o.default)("播放".concat(this.data.totalPlayTime, "首引导语")));
    },
    resetTime: function() {
        this.setData({
            currentPlayTime: 1
        }), this.calcPlayTimeText();
    },
    calcPlayTimeText: function() {
        this.data.totalPlayTime > 5 ? this.setData({
            playTimeText: "∞"
        }) : this.setData({
            playTimeText: "".concat(this.data.currentPlayTime, "/").concat(this.data.totalPlayTime)
        });
    },
    getCategoryPosInfo: function(t) {
        if (!(this.data.categoryList.length <= 0)) {
            for (var e = 0, i = {}, a = 0; a < this.data.categoryList.length; a++) {
                var s = this.data.categoryList[a];
                if (s.category_id === t) {
                    e = a, i = s;
                    break;
                }
            }
            return {
                idx: e,
                item: i
            };
        }
    },
    jumpToCategoryId: function(t) {
        var e = this.getCategoryPosInfo(t), i = e.idx, a = e.item;
        this.changeCategory({
            currentTarget: {
                dataset: {
                    item: a,
                    idx: i
                }
            }
        });
    }
});