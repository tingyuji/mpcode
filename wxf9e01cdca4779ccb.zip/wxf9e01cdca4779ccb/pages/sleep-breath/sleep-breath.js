var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../model/sleepBreath.js"), i = require("../../utils/util.js"), a = e(require("../../components/top-tips/index")), n = require("../../config.js"), r = new t.SleepBreathModel(), o = getApp().globalData;

Page({
    data: {
        musicList: [],
        currentSleepBreath: {},
        isShowSleepBreathTips: !1,
        isShowBuyTips: !1
    },
    onLoad: function(e) {
        o.query = Object.assign(o.query, (0, i.handleAppPageOption)(e)), (0, i.handleAPPConfig)(this, !0), 
        (0, i.showLoadingTips)(), this.getSleepBreathList();
    },
    onReady: function() {},
    onShow: function() {
        (0, i.handleAPPConfig)(this, !0);
    },
    onHide: function() {},
    onUnload: function() {
        console.warn("sleep-breath unload");
    },
    onPullDownRefresh: function() {
        (0, i.showLoadingTips)(), this.getSleepBreathList();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, i.getCommonShareData)();
    },
    gotoBreathDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        if (1 === t.needcoin && !wx.getStorageSync(n.config.CONST_KEY.VIP_INFO).is_vip) return void (o.isIOS && !o.config.ios_pay_enable || o.isAndroid && !o.config.android_pay_enable ? (0, 
        a.default)("你还不是会员") : this.setData({
            isShowBuyTips: !0
        }));
        wx.navigateTo({
            url: "/pages/sleep-breath-detail/sleep-breath-detail?id=".concat(t.prepare_id)
        });
    },
    getSleepBreathList: function() {
        var e = this;
        r.getSleepBreathList().then(function(t) {
            if ((0, i.hideLodingTips)(), !o.canBuy && o.config.audit_mode) {
                var a = wx.getStorageSync(n.config.CONST_KEY.VIP_INFO);
                t.breath_list = t.breath_list.filter(function(e) {
                    return !(1 === e.needcoin && !a.is_vip);
                });
            }
            if (e.setData({
                musicList: t.breath_list
            }), o.query.mid) {
                var r = parseInt(o.query.mid);
                delete o.query.mid;
                for (var s = 0; s < t.breath_list.length; s++) {
                    var h = t.breath_list[s];
                    if (h.prepare_id === r) {
                        var l = {
                            currentTarget: {
                                dataset: {
                                    item: h
                                }
                            }
                        };
                        e.gotoBreathDetail(l);
                        break;
                    }
                }
            }
        }).catch(function(e) {
            console.error(e), (0, i.hideLodingTips)();
        });
    },
    showBreathHelp: function(e) {
        var t = e.currentTarget.dataset.item;
        this.setData({
            currentSleepBreath: t,
            isShowSleepBreathTips: !0
        });
    }
});