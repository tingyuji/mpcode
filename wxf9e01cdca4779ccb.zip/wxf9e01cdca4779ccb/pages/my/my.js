var n = require("../../model/user.js"), o = require("../../utils/util.js"), e = require("../../config.js"), t = new (require("../../model/system.js").SystemModel)(), i = new n.UserModel(), a = getApp().globalData;

Page({
    data: {
        isios: !0,
        vipInfo: {},
        userData: {},
        userVipExpire: "你还不是会员",
        isShowBindPhone: !1,
        isShowUpdateIntro: !1,
        updateIntroText: "",
        canBuy: !1,
        needHideVipCell: !0,
        isDebug: !1,
        myAppAd: null
    },
    onLoad: function(n) {
        this.setData({
            isDebug: e.config.IS_DEBUG,
            isios: a.isios
        }), (0, o.handleAPPConfig)(this, !0), this.loadUserInfoFromCache(), a && a.config && this.setData({
            myAppAd: a.config.my_app_ad
        });
    },
    onReady: function() {},
    onShow: function() {
        (0, o.handleAPPConfig)(this, !0), this.getUserInfo();
    },
    onHide: function() {},
    onUnload: function() {
        console.warn("my unload");
    },
    onPullDownRefresh: function() {
        (0, o.showLoadingTips)(), this.getUserInfo();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, o.getCommonShareData)();
    },
    loadUserInfoFromCache: function() {
        var n = wx.getStorageSync(e.config.CONST_KEY.VIP_INFO), t = wx.getStorageSync(e.config.CONST_KEY.LOGIN_DATA);
        t.mobile && (t.mobile = (0, o.safePhoneNum)(t.mobile)), this.setData({
            userData: t,
            vipInfo: n,
            userVipExpire: 1 === n.is_vip ? (0, o.formatTimeFromTs)(1e3 * n.vip_expires) : "你还不是会员",
            canBuy: a.canBuy,
            needHideVipCell: !a.canBuy && a.config.audit_mode
        });
    },
    getUserInfo: function() {
        var n = this;
        i.getUserInfo().then(function(e) {
            (0, o.hideLodingTips)(), n.loadUserInfoFromCache();
        }).catch(function(n) {
            console.error(n), (0, o.hideLodingTips)();
        });
    },
    gotoPay: function() {
        this.data.canBuy ? wx.navigateTo({
            url: "/pages/pay/pay"
        }) : console.log("不能购买");
    },
    getPhoneNumber: function(n) {
        var e = this;
        n.detail.iv && n.detail.encryptedData && ((0, o.showLoadingTips)(), i.wxBindPhone({
            iv: n.detail.iv,
            encryptedData: n.detail.encryptedData
        }).then(function(n) {
            (0, o.hideLodingTips)(), wx.showToast({
                title: "手机绑定成功",
                icon: "success"
            }), e.loadUserInfoFromCache();
        }).catch(function(n) {
            console.log(n), (0, o.hideLodingTips)(), e.setData({
                isShowBindPhone: !0
            });
        }));
    },
    bindPhoneSuccess: function() {
        this.getUserInfo();
    },
    gotoAboutUs: function() {
        wx.navigateTo({
            url: "/pages/about-us/about-us"
        });
    },
    showUpdateIntro: function() {
        var n = this;
        this.data.updateIntroText && this.data.updateIntroText.length > 0 ? this.setData({
            isShowUpdateIntro: !0
        }) : ((0, o.showLoadingTips)(), t.getNotification().then(function(e) {
            (0, o.hideLodingTips)(), n.setData({
                updateIntroText: e.miniapp_update,
                isShowUpdateIntro: !0
            });
        }).catch(function(n) {
            console.error(n), (0, o.hideLodingTips)();
        }));
    },
    hideUpdateIntro: function() {
        this.setData({
            isShowUpdateIntro: !1
        });
    },
    onChangeNightMode: function(n) {
        wx.setStorageSync(e.config.CONST_KEY.IS_NIGHT_MODE, n.detail), (0, o.handleAPPConfig)(this, !0);
    },
    onChangeFontMode: function(n) {
        wx.setStorageSync(e.config.CONST_KEY.IS_BIG_FONT_MODE, n.detail), (0, o.handleAPPConfig)(this, !0);
    },
    delAccount: function() {
        var n = this;
        wx.showModal({
            title: "删除账号",
            content: "确定删除账号？",
            success: function(e) {
                e.confirm && ((0, o.showLoadingTips)("删除中"), i.delAccount().then(function(o) {
                    n.getUserInfo();
                }).catch(function(n) {
                    console.error(n), (0, o.hideLodingTips)();
                }));
            }
        });
    },
    testPage: function() {
        wx.navigateTo({
            url: "/pages/test/test"
        });
    },
    myAppAdAction: function() {
        var n = !1;
        try {
            var o = a && a.config && a.config.my_app_ad.ad_link && JSON.parse(a.config.my_app_ad.ad_link);
            if (!o.appId) throw new Error("我的页面广告数据没有APPID");
            o.success = function(n) {
                console.info(n);
            }, o.fail = function(n) {
                console.log(n);
            }, wx.navigateToMiniProgram(o);
        } catch (o) {
            n = !0, t.reportError(o, "我的页面底部广告唤起失败").then().catch();
        }
        if (n) {
            var e = a && a.config && a.config.my_app_ad.ad_link && JSON.parse(a.config.my_app_ad.ad_link);
            wx.navigateTo({
                url: "/pages/web/web?url=" + e.link
            });
        }
    }
});