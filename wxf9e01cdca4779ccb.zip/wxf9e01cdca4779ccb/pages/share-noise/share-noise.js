var e = require("../../model/user.js"), a = require("../../utils/util.js"), t = new e.UserModel(), o = getApp().globalData;

Page({
    data: {
        shareNoise: {}
    },
    onLoad: function(e) {
        (0, a.handleAppPageOption)(e), (0, a.handleAPPConfig)(this), this.setData({
            shareNoise: o.shareNoise
        });
    },
    onReady: function() {
        this.genShareCanvas();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, a.getCommonShareData)();
    },
    getWinWidth: function() {
        if (!this.winWidth) {
            var e = wx.getSystemInfoSync().windowWidth;
            this.winWidth = e;
        }
        return this.winWidth;
    },
    genShareCanvas: function() {
        var e = this;
        this.setData({
            isShowShareCanvas: !1
        });
        (0, a.showLoadingTips)("生成中"), Promise.all([ t.getShareWxCode({
            path: "pages/main/main",
            scene: "tag=1&mid=".concat(this.data.shareNoise.id),
            width: 280
        }, !1), new Promise(function(a, t) {
            wx.getImageInfo({
                src: e.data.shareNoise.cover_miniapp_big,
                success: function(e) {
                    a(e.path);
                },
                fail: function(e) {
                    t(e);
                }
            });
        }) ]).then(function(a) {
            var t = {
                "bg-blue": "#3fa8f4",
                "bg-red": "#ff7b5c",
                "bg-green": "#3dc48d",
                "bg-dark-blue": "#065784",
                "bg-pink": "#ed9ae6",
                "bg-purple": "#3B3354"
            }["bg-" + e.data.shareNoise.color_miniapp], o = e.data.shareNoise.musicdesc, i = "/images/share/share_".concat(e.data.shareNoise.color_miniapp, ".png");
            e.startDrawCanvas(i, a[0], a[1], t, o);
        }).catch(function(e) {
            console.log(e), (0, a.hideLodingTips)(), wx.showToast({
                title: "生成失败",
                icon: "none"
            });
        });
    },
    startDrawCanvas: function(e, t, o, i, n, s) {
        var r = this, h = (0, a.rpxToPx)(566), c = (0, a.rpxToPx)(820), x = wx.createCanvasContext("shareCanvas");
        x.setFillStyle("white"), x.fillRect(0, 0, h, c), s && (x.setFillStyle(i), x.fillRect((0, 
        a.rpxToPx)(50), (0, a.rpxToPx)(57), (0, a.rpxToPx)(466), (0, a.rpxToPx)(400))), 
        x.drawImage(e, 0, (0, a.rpxToPx)(26), (0, a.rpxToPx)(566), (0, a.rpxToPx)(462)), 
        x.drawImage(o, (0, a.rpxToPx)(188), (0, a.rpxToPx)(162), (0, a.rpxToPx)(190), (0, 
        a.rpxToPx)(190)), x.setTextAlign("center"), x.setFillStyle(i), x.setFontSize((0, 
        a.rpxToPx)(72)), x.fillText(n, (0, a.rpxToPx)(280), (0, a.rpxToPx)(530)), x.setTextAlign("center"), 
        x.setFillStyle("#4D4D4D"), x.setFontSize((0, a.rpxToPx)(23)), x.fillText("— 这里藏着好眠秘密? —", (0, 
        a.rpxToPx)(280), (0, a.rpxToPx)(600)), x.drawImage(t, (0, a.rpxToPx)(233), (0, a.rpxToPx)(680), (0, 
        a.rpxToPx)(100), (0, a.rpxToPx)(100)), x.drawImage("/images/share/qrcode_bg.png", (0, 
        a.rpxToPx)(213), (0, a.rpxToPx)(660), (0, a.rpxToPx)(140), (0, a.rpxToPx)(140)), 
        x.draw(!1, function() {
            r.setData({
                isShowShareCanvas: !0
            }), (0, a.hideLodingTips)(), console.log("绘制完成");
        });
    },
    saveSharePic: function() {
        this.data.isShowShareCanvas && wx.canvasToTempFilePath({
            canvasId: "shareCanvas",
            success: function(e) {
                console.log(e.tempFilePath), wx.saveImageToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function(e) {
                        wx.showToast({
                            title: "已保存到系统相册"
                        });
                    },
                    fail: function(e) {
                        "saveImageToPhotosAlbum:fail auth deny" === e.errMsg && wx.showModal({
                            title: "提示",
                            content: "需要获取保存图片到相册的权限",
                            success: function(e) {
                                e.confirm ? wx.openSetting() : e.cancel && console.log("用户点击取消");
                            }
                        });
                    }
                });
            }
        });
    },
    showShareView: function() {
        var e = this, t = (0, a.rpxToPx)(566), o = (0, a.rpxToPx)(820), i = wx.createCanvasContext("shareCanvas");
        i.clearRect(0, 0, t, o), i.draw(!1, function() {
            e.genShareCanvas();
        });
        var n = this;
        this.setData({
            isShowShareView: !0
        }), setTimeout(function() {
            n.anim_ShareView = wx.createAnimation({
                duration: 500,
                timingFunction: "ease"
            }), n.anim_ShareView.opacity(1).step({
                duration: 500
            }), n.setData({
                anim_ShareView: n.anim_ShareView.export()
            });
        }, 100);
    },
    hideShareView: function(e) {
        console.log(e), "shareCanvas" !== e.target.id && "share-canvas-btn" !== e.target.id && this.setData({
            isShowShareCanvas: !1,
            isShowShareView: !1
        });
    }
});