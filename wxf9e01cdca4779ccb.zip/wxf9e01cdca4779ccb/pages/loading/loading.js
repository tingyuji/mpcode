Page({
    data: {},
    onLoad: function(n) {
        var o = n.jumpUrl;
        setTimeout(function() {
            wx.redirectTo({
                url: "/pages/web/web?url=" + o
            });
        }, 1e3);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});