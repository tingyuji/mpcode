Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {
        setTimeout(function() {
            wx.switchTab({
                url: "/pages/main/main"
            });
        }, 2e3);
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        console.warn("welcome unload");
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});