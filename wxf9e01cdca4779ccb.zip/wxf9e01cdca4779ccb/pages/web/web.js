var n = require("../../utils/util.js");

Page({
    data: {
        webUrl: ""
    },
    onLoad: function(o) {
        var e = decodeURIComponent(o.url);
        wx.reportAnalytics("open_web_url", {
            weburl: e
        }), console.info("web", e), this.setData({
            webUrl: e
        }), (0, n.showLoadingTips)();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, n.getCommonShareData)();
    },
    webviewLoad: function() {
        (0, n.hideLodingTips)();
    },
    webviewError: function() {
        (0, n.hideLodingTips)(), wx.showToast({
            title: "加载失败",
            icon: "none"
        });
    }
});