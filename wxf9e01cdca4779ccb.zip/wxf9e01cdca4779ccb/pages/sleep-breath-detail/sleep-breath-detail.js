var e = require("../../model/sleepBreath.js"), t = require("../../utils/util.js"), i = new e.SleepBreathModel(), a = getApp().globalData;

Page({
    data: {
        sleepBreath: {
            prepare_title: "加载中"
        },
        currentTime: 0,
        remainTimeText: "",
        lyrics: {},
        lyricsList: [],
        lyricsValues: [],
        currentLyricIndex: -1,
        breathAnim: [],
        isTimePannelOpen: !1,
        timeArray: [ 5, 10, 15, 30, 60 ],
        timeType: 1,
        timeingTipsText: "未知",
        timer: null,
        timerRemainSec: 0,
        timerRemainTimeText: "00:00",
        isMusicLoading: !1,
        isMusicPlaying: !1,
        isShowSleepBreathTips: !1
    },
    onLoad: function(e) {
        var i = e.id;
        a.query = Object.assign(a.query, (0, t.handleAppPageOption)(e)), (0, t.handleAPPConfig)(this, !0), 
        wx.getBackgroundAudioManager().pause(), this.resetTime(), this.calcTimePannelTipsText(this.data.timeType), 
        (0, t.showLoadingTips)(), this.getSleepBreathDetail(i);
    },
    onReady: function() {
        this.bindAudioStatus();
    },
    onShow: function() {
        var e = this;
        if ((0, t.handleAPPConfig)(this), this.hidePageTimerRemainSec > 0 && this.hidePageTs > 0) {
            var i = new Date().getTime(), a = Math.floor((i - this.hidePageTs) / 1e3), n = this.hidePageTimerRemainSec - a;
            n = n > 0 ? n : 0, this.setData({
                timerRemainSec: n
            }), setTimeout(function() {
                e.startTimer();
            }, 1), this.hidePageTimerRemainSec = 0, this.hidePageTs = 0;
        }
    },
    onHide: function() {
        this.data.isMusicPlaying && (this.hidePageTimerRemainSec = this.data.timerRemainSec, 
        this.hidePageTs = new Date().getTime());
    },
    onUnload: function() {
        this.stopTimer(), this.resetAudioManager();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return (0, t.getCommonShareData)();
    },
    goBack: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    getSleepBreathDetail: function(e) {
        var a = this;
        i.getSleepBreathDetail({
            prepare_id: e
        }).then(function(e) {
            (0, t.hideLodingTips)();
            var i = a.parseLyrics(e.prepare_breath), n = i.lyrics, r = i.lyricsList, s = i.lyricsTimes, o = i.lyricsDurations, l = i.lyricsValues, c = i.lyricsCountdown;
            a.setData({
                sleepBreath: e,
                lyrics: n,
                lyricsList: r,
                lyricsTimes: s,
                lyricsDurations: o,
                lyricsValues: l,
                lyricsCountdown: c
            }), a.playOnce();
        }).catch(function(e) {
            console.log(e);
        });
    },
    showInfo: function() {
        console.log("show");
    },
    parseLyrics: function(e) {
        for (var t = {}, i = [], a = [], n = [], r = [], s = {}, o = (e = e || "").split("\n"), l = 0; l < o.length; l++) {
            var c = o[l].match(/\[([\S\s]*?),([\S\s]*?),([\S\s]*?)\]/);
            if (c && c.length >= 4) {
                for (var h = c[1], m = c[2], d = c[3], p = h.split("."), u = p.length > 1 ? parseInt(p[1]) / 1e3 : 0, g = p.length > 0 ? p[0].split(":") : [], T = 0; T < g.length; T++) {
                    var y = parseInt(g[T]);
                    u += Math.pow(60, g.length - 1 - T) * y;
                }
                var f = /^\d+$/.test(d);
                t[u] = d, i.push({
                    time: u,
                    text: d,
                    duration: m,
                    isCountdown: f
                }), a.push(u), n.push(m), r.push(d), s[u] = f;
            }
        }
        return {
            lyrics: t,
            lyricsList: i,
            lyricsTimes: a,
            lyricsDurations: n,
            lyricsValues: r,
            lyricsCountdown: s
        };
    },
    resetAudioManager: function() {
        var e = wx.getBackgroundAudioManager();
        e.pause(), e.onWaiting(null), e.onPlay(null), e.onTimeUpdate(null), e.onPause(null), 
        e.onStop(null), e.onEnded(null), e.onError(null);
    },
    playOnce: function() {
        if (!this.data.isMusicPlaying) {
            this.setData({
                isMusicPlaying: !0,
                currentTime: 0
            });
            for (var e = this.data.lyricsTimes, i = 0; i < e.length; i++) {
                var a = e[i], n = this.data.lyricsValues[i], r = 1e3 * a;
                if (n.indexOf("吸气") >= 0) {
                    1 === this.data.sleepBreath.prepare_breath_direction ? this.breathCircleShrink(r) : this.breathCircleExpansion(r);
                    break;
                }
                if (n.indexOf("呼气") >= 0) {
                    1 === this.data.sleepBreath.prepare_breath_direction ? this.breathCircleExpansion(r) : this.breathCircleShrink(r);
                    break;
                }
            }
            var s = wx.getBackgroundAudioManager();
            s.stop(), s.src = this.data.sleepBreath.prepare_cadence, s.coverImgUrl = encodeURI(this.data.sleepBreath.prepare_icon), 
            s.title = this.data.sleepBreath.prepare_title, s.epname = "心潮小睡眠", s.singer = "", 
            s.seek(0), s.play(), (0, t.showLoadingTips)("音频加载中"), this.startTimer();
        }
    },
    bindAudioStatus: function() {
        var e = this;
        clearInterval(a.noiseTimer), clearInterval(a.recommendTimer);
        var i = wx.getBackgroundAudioManager();
        i.onWaiting(function() {
            console.log("breath 音频加载中");
        }), i.onPlay(function() {
            console.log("breath 音频播放中"), (0, t.hideLodingTips)(), e.setData({
                isMusicPlaying: !0
            }), e.startTimer();
        }), i.onTimeUpdate(function() {
            var a = i.duration, n = i.currentTime, r = n + .5, s = a - n, o = n >= 0 ? (0, t.timeTextFormat)(s) : (0, 
            t.timeTextFormat)(a);
            e.setData({
                remainTimeText: o
            });
            for (var l = -1, c = -1, h = e.data.lyricsTimes, m = 0; m < h.length; m++) {
                if (r > h[m] && (!(m + 1 < h.length) || r < h[m + 1])) {
                    l = m, m + 1 < h.length && (c = m + 1);
                    break;
                }
            }
            if (e.data.currentLyricIndex !== l) {
                e.setData({
                    currentLyricIndex: l
                });
                var d = e.data.lyricsValues[l], p = parseInt(1e3 * ((c > -1 ? parseFloat(h[c]) : a) - parseFloat(h[l])));
                d && d.indexOf("吸气") >= 0 && (console.log("吸气"), 1 === e.data.sleepBreath.prepare_breath_direction ? e.breathCircleExpansion(p, 500) : e.breathCircleShrink(p, 500)), 
                d && d.indexOf("呼气") >= 0 && (console.log("呼气"), 1 === e.data.sleepBreath.prepare_breath_direction ? e.breathCircleShrink(p, 500) : e.breathCircleExpansion(p, 500));
            }
        }), i.onPause(function() {
            console.log("breath onPause"), e.setData({
                isMusicPlaying: !1
            });
        }), i.onStop(function() {
            console.log("breath onStop"), e.setData({
                isMusicPlaying: !1
            });
        }), i.onEnded(function() {
            if (console.log("breath onEnded"), e.setData({
                currentLyricIndex: -1,
                isMusicPlaying: !1
            }), e.hidePageTimerRemainSec > 0 && e.hidePageTs > 0) {
                var t = new Date().getTime(), i = Math.floor((t - e.hidePageTs) / 1e3), a = e.hidePageTimerRemainSec - i;
                a > 0 ? (console.log("页面处于后台位置，且剩余时为".concat(a, "，继续循环")), e.playOnce()) : console.log("页面处于后台位置，且剩余时小于等于0，结束循环");
            } else e.data.timerRemainSec > 0 ? (console.log("页面处于前端位置，且剩余时为".concat(e.data.timerRemainSec, "，继续循环")), 
            e.playOnce()) : console.log("定时已经结束，所以onend不会触发循环播放");
        }), i.onError(function(t) {
            console.log("breath onError"), console.log(t), e.setData({
                isMusicPlaying: !1
            });
        });
    },
    breathCircleExpansion: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        console.log("扩张", t, i);
        var a = wx.createAnimation().scale(1).opacity(1).step({
            duration: t
        }), n = wx.createAnimation().scale(1).opacity(1).step({
            duration: t
        }), r = wx.createAnimation().scale(1).opacity(1).step({
            duration: t
        });
        setTimeout(function() {
            e.setData({
                breathAnim1: a.export(),
                breathAnim2: n.export(),
                breathAnim3: r.export()
            });
        }, i);
    },
    breathCircleShrink: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        console.log("收缩", t, i);
        var a = wx.createAnimation().scale(.8).opacity(.3).step({
            duration: t
        }), n = wx.createAnimation().scale(.84).opacity(.3).step({
            duration: t
        }), r = wx.createAnimation().scale(.9).opacity(.8).step({
            duration: t
        });
        setTimeout(function() {
            e.setData({
                breathAnim1: a.export(),
                breathAnim2: n.export(),
                breathAnim3: r.export()
            });
        }, i);
    },
    timeChange: function(e) {
        var t = e.detail.index;
        this.calcTimePannelTipsText(t), this.setData({
            timeType: t
        }), this.resetTime();
    },
    resetTime: function() {
        var e = 0;
        e = this.data.timeType > this.data.timeArray.length - 1 ? 5999940 : 60 * this.data.timeArray[this.data.timeType], 
        this.setData({
            timerRemainSec: e
        }), this.calcTimePannelTipsText(this.data.timeType), this.calcTimerRemainTimeText();
    },
    toggleTimePannel: function() {
        this.setData({
            isTimePannelOpen: !this.data.isTimePannelOpen
        });
    },
    calcTimerRemainTimeText: function() {
        var e = "";
        if (this.data.timeType > this.data.timeArray.length - 1) e = "∞"; else {
            var t = Math.floor(this.data.timerRemainSec / 60) + "";
            t = t.length > 1 ? t : "0" + t;
            var i = this.data.timerRemainSec % 60 + "";
            i = i.length > 1 ? i : "0" + i, e = "".concat(t, ":").concat(i);
        }
        this.setData({
            timerRemainTimeText: e
        });
    },
    calcTimePannelTipsText: function(e) {
        this.setData({
            timeType: e
        });
        var t = "";
        t = this.data.timeType > this.data.timeArray.length - 1 ? "循环播放" : "".concat(this.data.timeArray[this.data.timeType], "分钟定时关闭"), 
        this.setData({
            timeingTipsText: t
        });
    },
    startTimer: function() {
        var e = this;
        if (this.stopTimer(), console.log("startTimer"), this.data.timeType > this.data.timeArray.length - 1) console.log("无限循环，不触发定时"); else {
            var t = setInterval(function() {
                var t = e.data.timerRemainSec;
                t > 0 && e.data.isMusicPlaying ? (t -= 1, e.setData({
                    timerRemainSec: t
                }), e.calcTimerRemainTimeText()) : t <= 0 && e.timeoutCallBack();
            }, 1e3);
            a.noiseTimer = t, this.setData({
                timer: t
            });
        }
    },
    timeoutCallBack: function() {
        console.log("定时已经结束回调，停止音频，并重置时间"), wx.getBackgroundAudioManager().stop(), this.resetTime();
    },
    stopTimer: function() {
        console.log("stopTimer"), clearInterval(this.data.timer);
    },
    showBreathHelp: function(e) {
        this.setData({
            isShowSleepBreathTips: !0
        });
    }
});