var t = require("../../config.js"), a = require("./bgdata"), i = require("../../utils/base64.min.js"), e = require("../../utils/util.js"), n = require("../../model/calendar.js"), o = getApp().globalData, s = new n.CalendarModel();

Page({
    data: {
        isDebug: !1,
        todayCid: -1,
        cid: -1,
        cDate: null,
        cDateText: "",
        cDateMonth: 1,
        bgColor: "#F7F7F7",
        cardBgColor: "#FFFFFF",
        day0Ts: 1577808e6,
        options: {},
        force_open: !0,
        isFirstIn: !0,
        isInYear: !0,
        isInYear2020: !1,
        isToday: !1,
        isPassDay: !1,
        isFutureDay: !1,
        commingTimer: null,
        commingTimeText: "",
        introMusic: "",
        isIntroPlaying: !1,
        isIntroLoading: !1,
        openAnimation: {},
        musicBgImgData: "",
        baseColor: "#000000",
        dayMusic: {},
        isApiLoading: !0,
        dateText: "",
        dateText2: "",
        dateText3: "",
        timer: null,
        timeMinsPerPlay: 30,
        timerRemainSec: 0,
        isMusicLoading: !1,
        isMusicPlaying: !1,
        introLyricTimes: [ 2439, 3931, 6644, 10718, 13776, 17881, 19219, 22250, 27824, 32110, 34786, 36738, 39535, 42845, 46833, 52829, 55803, 60627, 66e3, 69673, 72e3, 74730, 79475, 83676, 88541, 91227, 96058, 98859, 103397, 106e3, 107735, 113049, 115726, 118648, 121738, 127119, 129443, 132834 ],
        introLyricTexts: [ "我的朋友", "你好", "这里是小睡眠和言仓", "或许你已经认识我们了", "或许你还从未了解过我们", "没关系", "这是一件常事", "花和花之间也不都知道对方的名字", "这个世界存在着75.94亿人", "总有人互不相识", "神奇的是", "在你不知道的地方", "那些你以为毫不相关的人", "可能也在和你做着相同的事", "因为某个相同的信念", "小睡眠和言仓", "对于彼此就是这样的存在", "我们都相信声音给人带来的治愈力量", "我们寻找那些藏在自然里", "日常里的声响", "将它们带到你面前", "希望你能感受到它们的奇妙之处", "这本日历就源自于我们的相遇", "而这也是我们希望它给你带去的意义", "让身处写字楼的你", "去听一听挪威森林里的莺啼", "让此时此地的你", "去听一听地球上另一端的城市话语", "让每日疲于奔波的你", "静下来听一锅汤", "因沸腾而发出的咕噜咕噜的欣喜", "我们想让你知道", "即使身处喧嚣的城市", "你依然能拥有森林大海", "世间万物以及无所事事的惬意", "这一日一声", "便是你和它们相遇的契机", "小睡眠和言仓 附上" ],
        currentLyricText: ""
    },
    onLoad: function(a) {
        this.setData({
            options: a || {},
            isDebug: t.config.IS_DEBUG
        }), console.info(this.data.options.calendarId);
        var i = parseInt(this.data.options.calendarId || o.query.calendarId || 0);
        this.initData(i);
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        if (this.hidePageTimerRemainSec > 0 && this.hidePageTs > 0) {
            var a = new Date().getTime(), i = Math.floor((a - this.hidePageTs) / 1e3), e = this.hidePageTimerRemainSec - i;
            e = e > 0 ? e : 0, this.setData({
                timerRemainSec: e
            }), setTimeout(function() {
                t.startTimer();
            }, 1), this.hidePageTimerRemainSec = 0, this.hidePageTs = 0, this.bindAudioStatus();
        }
    },
    onHide: function() {
        this.data.isMusicPlaying && (this.hidePageTimerRemainSec = this.data.timerRemainSec, 
        this.hidePageTs = new Date().getTime());
    },
    onUnload: function() {
        wx.getBackgroundAudioManager().stop(), this.data.commingTimer && clearInterval(this.data.commingTimer);
    },
    onPullDownRefresh: function() {},
    onShareAppMessage: function() {
        return {
            title: "自然物语-小睡眠日历",
            path: "/pages/calendar/calendar?calendarId=".concat(this.data.cid)
        };
    },
    toCnNum: function(t, a) {
        var i = Number(t), e = [ "零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "百", "千", "万", "亿" ], n = String(i).length;
        return 1 === n ? a && 0 === t ? "日" : e[i] : 2 === n ? 10 === i ? e[i] : i > 10 && i < 20 ? "十" + e[String(i).charAt(1)] : e[String(i).charAt(0)] + "十" + e[String(i).charAt(1)].replace("零", "") : void 0;
    },
    imgToB64: function(t, a) {
        a = a || this.data.baseColor;
        var e = t.replace(/fill="#000000"/g, 'fill="'.concat(a, '"'));
        return "data:image/svg+xml;base64," + i.Base64.encode(e);
    },
    initData: function(t) {
        t = t || this.data.cid || 1;
        var a = this.data.day0Ts, i = new Date(a + 864e5 * (t - 1)), e = function(t) {
            return 1 === "".concat(t).length ? "0".concat(t) : "".concat(t);
        }, n = "".concat(i.getFullYear(), "-").concat(e(i.getMonth() + 1), "-").concat(e(i.getDate()));
        if (t > 366) if (t < 379) n = "月份".concat(e(t - 366)); else switch (t) {
          case 379:
            n = "年头";
            break;

          case 380:
            n = "年尾";
            break;

          case 381:
            n = "封面";
            break;

          case 382:
            n = "落款";
            break;

          default:
            n = "无效id";
        } else t < 1 && (n = "无效id");
        this.setData({
            cid: t,
            cDate: i,
            cDateMonth: i.getMonth() + 1,
            cDateText: n,
            dateText: i.getDate(),
            dateText2: "".concat(e(i.getMonth() + 1), ".").concat(i.getFullYear()),
            dateText3: "".concat(this.toCnNum(i.getMonth() + 1), "月").concat(this.toCnNum(i.getDate()), "日，星期").concat(this.toCnNum(i.getDay(), !0)),
            timerRemainSec: 60 * this.data.timeMinsPerPlay
        }), this.checkConfig(), this.loadCalendarData();
    },
    loadCalendarData: function() {
        var i = this;
        this.setData({
            isApiLoading: !0
        }), (0, e.showLoadingTips)();
        var n = {
            id: this.data.cid
        };
        t.config.IS_DEBUG && (n.debug = 2), s.getCalendarMusic(n).then(function(t) {
            if ((0, e.hideLodingTips)(), console.info(t), i.setData({
                force_open: !i.data.isFirstIn && t.force_open && 1 === t.force_open
            }), i.checkConfig(), t.envelope_music && i.setData({
                introMusic: t.envelope_music
            }), t.day_music && t.day_music.id) i.setData({
                dayMusic: t.day_music,
                baseColor: t.day_music.color,
                musicBgImgData: i.imgToB64(a.bgData["bg".concat(t.day_music.bg)], t.day_music.color)
            }), setTimeout(function() {
                i.setData({
                    isApiLoading: !1
                });
            }, 100); else if (i.data.isInYear) {
                if (382 === i.data.cid) return;
                wx.showToast({
                    title: "无数据",
                    icon: "none"
                });
            }
        }).catch(function(t) {
            console.error(t), (0, e.hideLodingTips)(), i.setData({
                isApiLoading: !1
            });
        });
    },
    listenToday: function() {
        this.initData(this.data.todayCid);
    },
    checkConfig: function() {
        var a = this, i = this.data.cDate.getTime(), e = new Date().getTime();
        this.data.force_open && (e = i);
        var n = wx.getStorageSync(t.config.CONST_KEY.IS_EVERIN_CALENDAR) || !1;
        n || wx.setStorageSync(t.config.CONST_KEY.IS_EVERIN_CALENDAR, !0), this.data.options.fromTestPage && t.config.IS_DEBUG && (e = parseInt(this.data.options.fakeToday), 
        n = !parseInt(this.data.options.isFirstIn));
        var o = Math.floor((e - this.data.day0Ts) / 864e5) + 1;
        o = (o = o <= 0 ? 1 : o) > 366 ? this.data.cid : o;
        var s = e >= this.data.day0Ts, r = 2020 === new Date(e).getFullYear(), c = new Date(i).toDateString() === new Date(e).toDateString(), d = !c && e > i, u = !c && e < i;
        if (this.setData({
            todayCid: o,
            isFirstIn: !n,
            isInYear: s,
            isInYear2020: r,
            isToday: c,
            isPassDay: d,
            isFutureDay: u,
            bgColor: d ? "#EDE3D1" : "#F7F7F7",
            cardBgColor: d ? "#f8f4ef" : "#FFFFFF"
        }), 382 === this.data.cid && this.setData({
            isFirstIn: !0
        }), !s) {
            this.data.commingTimer && clearInterval(this.data.commingTimer), this.calcCountdownInYear();
            var l = setInterval(function() {
                a.calcCountdownInYear();
            }, 1e3);
            this.setData({
                commingTimer: l
            });
        }
    },
    calcCountdownInYear: function() {
        if (!this.data.isInYear) {
            var t = function(t) {
                return 1 === "".concat(t).length ? "0".concat(t) : "".concat(t);
            }, a = Math.floor((this.data.day0Ts - new Date().getTime()) / 1e3);
            if (a < 0) return clearInterval(this.data.commingTimer), void this.checkConfig();
            var i = a % 60, e = Math.floor(a / 60) % 60, n = Math.floor(a / 60 / 60) % 24, o = Math.floor(a / 60 / 60 / 24);
            this.setData({
                commingTimeText: '<span class="countdown-rt-big">'.concat(t(o), '</span> 天 <span class="countdown-rt-big">').concat(t(n), '</span> 时 <span class="countdown-rt-big">').concat(t(e), '</span> 分 <span class="countdown-rt-big">').concat(t(i), "</span> 秒后")
            });
        }
    },
    toggleIntro: function() {
        var t = wx.getBackgroundAudioManager();
        if (t.src && t.src === this.data.introMusic) return t.paused ? t.currentTime >= t.duration || 0 === t.currentTime ? this.rePlayIntroMusic() : (this.bindIntroAudioStatus(), 
        t.play()) : t.pause(), void this.setData({
            isIntroPlaying: !this.data.isIntroPlaying
        });
        this.rePlayIntroMusic();
    },
    rePlayIntroMusic: function() {
        this.setData({
            isIntroPlaying: !0,
            isIntroLoading: !0
        }), this.bindIntroAudioStatus();
        var t = wx.getBackgroundAudioManager();
        t.stop(), t.src = this.data.introMusic, t.title = "一封来信", t.epname = "心潮小睡眠", t.singer = "", 
        t.coverImgUrl = "https://res.psy-1.com/miniapp/xiaoshuimian_logo_screen.png", t.seek(0), 
        t.play();
    },
    bindIntroAudioStatus: function() {
        var t = this, a = wx.getBackgroundAudioManager();
        a.onTimeUpdate(function() {
            var i, e = 1e3 * a.currentTime + 500;
            console.info(e);
            for (var n = 0; n < t.data.introLyricTimes.length; n++) {
                if (t.data.introLyricTimes[n] > e) {
                    i = n;
                    break;
                }
                n === t.data.introLyricTimes.length - 1 && (i = n + 1);
            }
            i - 1 >= 0 && t.setData({
                currentLyricText: t.data.introLyricTexts[i - 1]
            });
        }), a.onWaiting(function() {
            t.setData({
                isIntroLoading: !0
            });
        }), a.onCanplay(function() {
            t.setData({
                isIntroLoading: !1
            });
        }), a.onPlay(function() {
            t.setData({
                isIntroPlaying: !0,
                isIntroLoading: !1
            });
        }), a.onPause(function() {
            t.setData({
                isIntroPlaying: !1,
                isIntroLoading: !1
            });
        }), a.onStop(function() {
            t.setData({
                isIntroPlaying: !1,
                isIntroLoading: !1
            });
        }), a.onEnded(function() {
            t.setData({
                isIntroPlaying: !1,
                isIntroLoading: !1,
                currentLyricText: ""
            });
        });
    },
    openCalendar: function() {
        var t = this, a = wx.createAnimation({
            duration: 800
        }).scale(1.2, 1.2).opacity(0).step();
        this.setData({
            openAnimation: a.export(),
            isApiLoading: !0
        }), setTimeout(function() {
            t.setData({
                isFirstIn: !1
            }), t.initData(t.data.todayCid), t.setData({
                isFirstIn: !1
            });
        }, 800), wx.getBackgroundAudioManager().stop(), this.bindAudioStatus();
    },
    gotoHome: function() {
        wx.redirectTo({
            url: "/pages/welcome/welcome"
        });
    },
    rePlayCurrentMusic: function() {
        var t = this.data.dayMusic;
        if (t.musicurl) {
            this.bindAudioStatus(), this.setData({
                isMusicPlaying: !0,
                isMusicLoading: !0
            });
            var a = wx.getBackgroundAudioManager();
            a.stop(), a.src = t.musicurl, a.title = t.musicdesc, a.epname = "心潮小睡眠", a.singer = "", 
            a.coverImgUrl = "https://res.psy-1.com/miniapp/xiaoshuimian_logo_screen.png", a.seek(0), 
            a.play(), this.startTimer();
        } else wx.showToast({
            title: "音频不存在",
            icon: "none"
        });
    },
    toggleMusic: function() {
        this.selMusic();
    },
    selMusic: function(t) {
        var a = wx.getBackgroundAudioManager(), i = this.data.dayMusic;
        if (i.id) return a.src && a.src === i.musicurl ? (a.paused ? a.currentTime >= a.duration || 0 === a.currentTime ? this.rePlayCurrentMusic() : (this.bindAudioStatus(), 
        a.play()) : a.pause(), void this.setData({
            isMusicPlaying: !this.data.isMusicPlaying
        })) : void this.rePlayCurrentMusic();
    },
    bindAudioStatus: function() {
        var t = this;
        clearInterval(o.noiseTimer), clearInterval(o.calendarTimer);
        var a = wx.getBackgroundAudioManager();
        a.onWaiting(function() {
            console.log("calendar 音频加载中"), t.setData({
                isMusicLoading: !0
            });
        }), a.onCanplay(function() {
            console.log("calendar 音频onCanplay"), t.setData({
                isMusicLoading: !1
            });
        }), a.onPlay(function() {
            console.log("calendar 音频播放中"), t.setData({
                isMusicPlaying: !0,
                isMusicLoading: !1
            }), t.startTimer();
        }), a.onTimeUpdate(function() {}), a.onPause(function() {
            console.log("calendar onPause"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), a.onStop(function() {
            console.log("calendar onStop"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), a.onEnded(function() {
            if (console.log("calendar onEnded"), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), t.hidePageTimerRemainSec > 0 && t.hidePageTs > 0) {
                var a = new Date().getTime(), i = Math.floor((a - t.hidePageTs) / 1e3), e = t.hidePageTimerRemainSec - i;
                e > 0 ? (console.log("页面处于后台位置，且剩余时为".concat(e, "，继续循环")), t.rePlayCurrentMusic()) : console.log("页面处于后台位置，且剩余时小于等于0，结束循环");
            } else t.data.timerRemainSec > 0 ? (console.log("页面处于前端位置，且剩余时为".concat(t.data.timerRemainSec, "，继续循环")), 
            t.rePlayCurrentMusic()) : console.log("定时已经结束，所以onend不会触发循环播放");
        }), a.onError(function(a) {
            console.log("calendar onError", a), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), (0, e.hideLodingTips)(), wx.showToast({
                title: "音频加载失败(".concat(a.errCode, ")"),
                icon: "none"
            });
        });
    },
    startTimer: function() {
        var t = this;
        this.stopTimer(), console.log("startTimer");
        var a = setInterval(function() {
            var a = t.data.timerRemainSec;
            a > 0 && t.data.isMusicPlaying ? (a -= 1, t.setData({
                timerRemainSec: a,
                currentProgress: 100 * (1 - a / (60 * t.data.timeMinsPerPlay))
            })) : a <= 0 && t.timeoutCallBack();
        }, 1e3);
        this.setData({
            timer: a
        });
    },
    timeoutCallBack: function() {
        console.log("定时已经结束回调，停止音频，并重置时间"), wx.getBackgroundAudioManager().stop(), this.setData({
            timerRemainSec: 60 * this.data.timeMinsPerPlay
        });
    },
    stopTimer: function() {
        console.log("stopTimer"), clearInterval(this.data.timer);
    }
});