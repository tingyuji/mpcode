require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../@babel/runtime/helpers/typeof"), e = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../model/noise.js"), a = require("../../model/system.js"), s = require("../../utils/util.js"), n = require("../../config.js"), o = new i.NoiseModel(), c = new a.SystemModel(), r = getApp().globalData;

Page({
    data: {
        isPlaying: !1,
        currentMusic: {
            color_miniapp: "blue",
            musicdesc: "加载中"
        },
        musicListScrollTop: 0,
        bottomPannelHeight: 0,
        bottomSwiperHeight: 0,
        tagSelectedLeft: 0,
        tagSelectedWidth: 0,
        tagMusicListsHash: {},
        tagList: [],
        selTagId: 0,
        currentTagIdx: 0,
        musicNewDict: {},
        isTimeHeightAnimOpen: !1,
        isTimePannelOpen: !1,
        timeArray: [ 5, 10, 15, 30, 60 ],
        timeType: 3,
        timeingTipsText: "",
        timer: null,
        timerRemainSec: 0,
        timerRemainTimeText: "00:00",
        isMusicLoading: !1,
        isMusicPlaying: !1,
        isShowMusicPlaying: !1,
        categoryScrollLeft: 0,
        plusBtnTop: 140,
        isShowVoiceTransferTips: !1,
        isShowAiVoiceRecognition: !1,
        homePopupAd: null,
        isShowMainPopupAd: !1,
        adconfig: {},
        showFloat: !1
    },
    closeFloatAD: function() {
        this.setData({
            showFloat: !1
        });
    },
    jump: function(t) {
        console.log(this.data.adconfig.music_button_ad.ad_link);
        var e = t.currentTarget.dataset.position, i = {};
        "bottom" === e ? i = JSON.parse(this.data.adconfig.music_float_ad.ad_link) : "top" === e && (i = JSON.parse(this.data.adconfig.music_button_ad.ad_link)), 
        i.appId ? (i.success = function(t) {
            console.info(t);
        }, i.fail = function(t) {
            console.log(t);
        }, wx.navigateToMiniProgram(i)) : wx.navigateTo({
            url: "/pages/web/web?url=" + i.link
        });
    },
    isShowAD: function(t, e) {
        var i = !1, a = wx.getStorageSync(e), s = new Date(a), n = new Date(), o = s.getTime(), c = n.getTime();
        switch (Number(t)) {
          case 1:
            r.firstOpenGlobal || (console.log("每次都打开"), i = !0, r.firstOpenGlobal = !0);
            break;

          case 2:
            i = c - o > 864e5 || !a, console.log("每天打开一次");
            break;

          case 3:
            i = c - o > 2592e5 || !a, console.log("每3天打开一次");
            break;

          case 4:
            i = c - o > 6048e5 || !a, console.log("每周打开一次");
        }
        return i && wx.setStorageSync(e, new Date().getTime()), i;
    },
    onLoad: function(t) {
        var e = this;
        setTimeout(function() {
            console.log("HOME_AD:", r.config);
            var t = 0;
            r.config.music_float_ad && r.config.music_float_ad.ad_frequency && (t = r.config.music_float_ad.ad_frequency);
            var i = e.isShowAD(t, "float_ad");
            if (r && r.config && r.config.home_popup_ad) try {
                e.setData({
                    homePopupAd: r.config.home_popup_ad
                });
                var a = parseInt(wx.getStorageSync(n.config.CONST_KEY.MAIN_AD_LAST_SHOW_TIME) || 0), s = new Date(a), o = !1, c = parseInt(e.data.homePopupAd.ad_frequency), l = new Date(), u = l.getTime();
                switch (c) {
                  case 1:
                    o = !0;
                    break;

                  case 2:
                    (u - a > 864e5 || s.getDate() !== u.getDate()) && (o = !0);
                    break;

                  case 3:
                    (u - a > 2592e5 || u - a > 1728e5 && s.getDate() !== u.getDate()) && (o = !0);
                    break;

                  case 4:
                    var g = new Date(l.getFullYear(), 0, 1), d = Math.ceil(((l - g) / 864e5 + g.getDay() + 1) / 7), h = new Date(s.getFullYear(), 0, 1);
                    d !== Math.ceil(((s - h) / 864e5 + h.getDay() + 1) / 7) && (o = !0);
                }
                var m = wx.getStorageSync(n.config.CONST_KEY.VIP_INFO) || {};
                m && 1 === m.is_vip && (o = !1), e.setData({
                    isShowMainPopupAd: o
                }), e.data.isShowMainPopupAd && wx.setStorageSync(n.config.CONST_KEY.MAIN_AD_LAST_SHOW_TIME, u);
            } catch (t) {
                console.info(t);
            }
            console.log("ISSHOW:", i), e.setData({
                showFloat: i,
                adconfig: r.config
            });
        }, 2500), r.query = Object.assign(r.query, (0, s.handleAppPageOption)(t)), (0, s.handleAPPConfig)(this, !0);
        var i = wx.getSystemInfoSync();
        i.model.indexOf("iPhone X") >= 0 && this.setData({
            plusBtnTop: 180
        }), i.system.indexOf("Android") >= 0 && this.setData({
            plusBtnTop: 160
        }), this.resetTime(), (0, s.showLoadingTips)(), this.getNoiseData();
    },
    onReady: function() {
        this.calcBottomPannelHeight();
    },
    onShow: function() {
        var t = this;
        if ((0, s.handleAPPConfig)(this, !0), this.hidePageTimerRemainSec > 0 && this.hidePageTs > 0) {
            var e = new Date().getTime(), i = Math.floor((e - this.hidePageTs) / 1e3), a = this.hidePageTimerRemainSec - i;
            a = a > 0 ? a : 0, this.setData({
                timerRemainSec: a
            }), setTimeout(function() {
                t.startTimer();
            }, 1), this.hidePageTimerRemainSec = 0, this.hidePageTs = 0;
        }
        r.currentMusicType === n.config.MUSIC_TYPE.NOISE ? this.bindAudioStatus() : this.setData({
            isShowMusicPlaying: !1,
            isMusicPlaying: !1
        });
    },
    onHide: function() {
        this.data.isMusicPlaying && (this.hidePageTimerRemainSec = this.data.timerRemainSec, 
        this.hidePageTs = new Date().getTime());
    },
    onUnload: function() {
        console.warn("main unload");
    },
    onPullDownRefresh: function() {
        this.getNoiseData();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = (0, s.getCommonShareData)();
        return this.data.currentMusic.id && (t.path += "&tid=".concat(this.data.selTagId, "&mid=").concat(this.data.currentMusic.id)), 
        t;
    },
    calcBottomPannelHeight: function(t) {
        var e = this, i = wx.createSelectorQuery();
        i.selectAll("#main-container, #main-music-timeing, #music-category-scrollview").boundingClientRect(), 
        i.selectViewport(), i.exec(function(i) {
            var a = i[0], s = wx.getSystemInfoSync(), n = s.windowHeight - a[0].height, o = s.windowWidth / 750 * 190;
            e.setData({
                bottomPannelHeight: n - (t ? o : 0),
                bottomSwiperHeight: n - a[1].height - a[2].height - (t ? o : 0)
            });
        });
    },
    showPlayTips: function() {
        console.log("显示白噪音介绍");
    },
    getNoiseData: function() {
        var t = this;
        this.setData({
            tagList: [],
            tagMusicListsHash: {}
        }), o.getTagList().then(function(e) {
            if ((0, s.hideLodingTips)(), t.setData({
                tagList: e
            }), r.query.tid) {
                var i = parseInt(r.query.tid);
                delete r.query.tid;
                for (var a = 0; a < e.length; a++) {
                    var n = e[a];
                    n.tag_id === i && (t.setData({
                        currentTagIdx: a,
                        selTagId: n.tag_id
                    }), t.changeSelectLinePos());
                }
            }
            t.data.selTagId <= 0 && (t.setData({
                currentTagIdx: 0,
                selTagId: e[0].tag_id
            }), t.changeSelectLinePos()), t.getCurrentTagMusicList(), t.calcBottomPannelHeight();
        }).catch(function(t) {
            console.log(t);
        });
    },
    changeTag: function(t) {
        var e = t.currentTarget.dataset.item, i = t.currentTarget.dataset.idx;
        this.setData({
            selTagId: e.tag_id,
            currentTagIdx: i
        }), this.changeSelectLinePos();
    },
    bindTagChange: function(t) {
        var e = t.detail.current, i = this.data.tagList[e], a = e !== this.data.currentTagIdx;
        this.setData({
            selTagId: i.tag_id,
            currentTagIdx: e
        }), a && this.changeSelectLinePos(), this.getCurrentTagMusicList(), this.reAssignList(i.tag_id);
    },
    changeSelectLinePos: function() {
        var t = this;
        Promise.all([ new Promise(function(t, e) {
            var i = wx.createSelectorQuery();
            i.select("#music-category-contentview").boundingClientRect(), i.selectViewport(), 
            i.exec(function(e) {
                var i = e[0];
                t(i);
            });
        }), new Promise(function(e, i) {
            var a = wx.createSelectorQuery();
            a.select(".category-item-".concat(t.data.selTagId, " .title")).boundingClientRect(), 
            a.selectViewport(), a.exec(function(t) {
                var i = t[0];
                e(i);
            });
        }) ]).then(function(e) {
            var i = e[0], a = e[1];
            i && a && t.setData({
                tagSelectedLeft: a.left - i.left,
                tagSelectedWidth: a.width,
                categoryScrollLeft: a.left - i.left - (wx.getSystemInfoSync().windowWidth - a.width) / 2
            });
        });
    },
    loadMoreData: function() {
        this.getCurrentTagMusicList(!0);
    },
    getCurrentTagMusicList: function(i) {
        var a = this, l = this.data.tagMusicListsHash[this.data.selTagId] || {
            p: -1,
            lists: [],
            scrollIntoView: "",
            loading: !1,
            end: !1
        };
        l.end || !i && l.p > -1 ? (0, s.hideLodingTips)() : (-1 === l.p && (0, s.showLoadingTips)(), 
        l.loading = !0, this.setData(e({}, "tagMusicListsHash.".concat(this.data.selTagId), l)), 
        Promise.all([ c.getAd(), o.getMusicListByTag({
            tag_id: this.data.selTagId,
            p: l.p + 1
        }) ]).then(function(i) {
            (0, s.hideLodingTips)();
            var o = i[0], c = i[1];
            if (0 === a.data.currentTagIdx) {
                var u = {}, g = wx.getStorageSync(n.config.CONST_KEY.MUSIC_NEW_DICT);
                "object" === t(g) ? c.forEach(function(t, e, i) {
                    u[t.id] = !0;
                }) : (c.forEach(function(t, e, i) {
                    u[t.id] = !1;
                }), g = {}), Object.assign(u, g), wx.setStorageSync(n.config.CONST_KEY.MUSIC_NEW_DICT, u), 
                a.setData({
                    musicNewDict: u
                });
            }
            if (l.loading = !1, l.end = 0 === c.length, l.lists = l.lists.concat(c), l.p++, 
            a.setData(e({}, "tagMusicListsHash.".concat(a.data.selTagId), l)), l.ad = o, a.reAssignList(a.data.selTagId), 
            r.query.mid) {
                var d = parseInt(r.query.mid);
                delete r.query.mid;
                for (var h = 0; h < l.lists.length; h++) {
                    var m = l.lists[h];
                    if (m.id === d) {
                        a.setData(e({}, "tagMusicListsHash.".concat(a.data.selTagId, ".scrollIntoView"), "music-item-".concat(a.data.selTagId, "-").concat(d)));
                        var p = {
                            currentTarget: {
                                dataset: {
                                    item: m
                                }
                            }
                        };
                        a.selMusic(p), wx.reportAnalytics("share_music_income", {
                            music_id: m.id,
                            music_name: m.musicdesc
                        });
                        break;
                    }
                }
            }
            !a.data.currentMusic.musicurl && c.length > 0 && a.setData({
                currentMusic: c[0]
            }), r.query.jumpUrl && a.handleInJumpUrl();
        }).catch(function(t) {
            console.log(t);
        }));
    },
    toggleTimePannel: function() {
        this.setData({
            isTimeHeightAnimOpen: !0,
            isTimePannelOpen: !this.data.isTimePannelOpen
        }), this.data.isTimePannelOpen ? this.calcBottomPannelHeight(!0) : this.calcBottomPannelHeight();
    },
    rePlayCurrentMusic: function() {
        var t = this.data.currentMusic;
        this.bindAudioStatus(), this.setData({
            isMusicLoading: !0
        }), r.currentMusic = t, r.currentMusicUrl = t.musicurl, r.currentMusicType = n.config.MUSIC_TYPE.NOISE;
        var e = wx.getBackgroundAudioManager();
        e.stop(), e.src = t.musicurl, e.title = t.musicdesc, e.epname = "心潮小睡眠", e.singer = "", 
        e.coverImgUrl = "https://res.psy-1.com/miniapp/xiaoshuimian_logo_screen.png", e.seek(0), 
        e.play(), this.startTimer();
    },
    toggleMusic: function() {
        this.selMusic();
    },
    selMusic: function(t) {
        var e = wx.getBackgroundAudioManager(), i = t ? t.currentTarget.dataset.item : this.data.currentMusic;
        if (i.ad_id) this.selAd(i); else {
            var a = this.data.musicNewDict;
            if (a[i.id] && (a[i.id] = !1, this.setData({
                musicNewDict: a
            }), wx.setStorageSync(n.config.CONST_KEY.MUSIC_NEW_DICT, a)), this.data.currentMusic.id === i.id && e.src === i.musicurl) return e.paused ? e.currentTime >= e.duration || 0 === e.currentTime ? this.rePlayCurrentMusic() : e.play() : e.pause(), 
            void this.setData({
                isShowMusicPlaying: !this.data.isMusicPlaying,
                isMusicPlaying: !this.data.isMusicPlaying
            });
            this.setData({
                currentMusic: i
            }), this.rePlayCurrentMusic();
        }
    },
    bindAudioStatus: function() {
        var t = this;
        clearInterval(r.noiseTimer), clearInterval(r.recommendTimer);
        var e = wx.getBackgroundAudioManager();
        this.setData({
            isMusicPlaying: !e.paused,
            isShowMusicPlaying: !e.paused
        }), e.onWaiting(function() {
            console.log("white noise 音频加载中"), t.setData({
                isMusicLoading: !0
            });
        }), e.onCanplay(function() {
            console.log("white noise 音频onCanplay"), t.setData({
                isMusicLoading: !1
            });
        }), e.onPlay(function() {
            console.log("white noise 音频播放中"), t.startTimer(), t.setData({
                isShowMusicPlaying: !0,
                isMusicPlaying: !0,
                isMusicLoading: !1
            });
        }), e.onTimeUpdate(function() {}), e.onPause(function() {
            console.log("white noise onPause"), t.stopTimer(), t.setData({
                isShowMusicPlaying: !1,
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), e.onStop(function() {
            console.log("white noise onStop"), t.stopTimer(), t.setData({
                isMusicPlaying: !1,
                isMusicLoading: !1
            });
        }), e.onEnded(function() {
            if (console.log("white noise onEnded"), t.setData({
                isShowMusicPlaying: !1,
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), t.hidePageTimerRemainSec > 0 && t.hidePageTs > 0) {
                var e = new Date().getTime(), i = Math.floor((e - t.hidePageTs) / 1e3), a = t.hidePageTimerRemainSec - i;
                a > 0 ? (console.log("页面处于后台位置，且剩余时为".concat(a, "，继续循环")), t.rePlayCurrentMusic()) : console.log("页面处于后台位置，且剩余时小于等于0，结束循环");
            } else t.data.timerRemainSec > 0 ? (console.log("页面处于前端位置，且剩余时为".concat(t.data.timerRemainSec, "，继续循环")), 
            t.rePlayCurrentMusic()) : console.log("定时已经结束，所以onend不会触发循环播放");
        }), e.onError(function(e) {
            console.log("white noise onError", e), t.stopTimer(), t.setData({
                isShowMusicPlaying: !1,
                isMusicPlaying: !1,
                isMusicLoading: !1
            }), (0, s.hideLodingTips)(), wx.showToast({
                title: "音频加载失败(".concat(e.errCode, ")"),
                icon: "none"
            });
        });
    },
    resetTime: function() {
        var t = 0;
        t = this.data.timeType > this.data.timeArray.length - 1 ? 5999940 : 60 * this.data.timeArray[this.data.timeType], 
        this.setData({
            timerRemainSec: t
        }), this.calcTimePannelTipsText(this.data.timeType), this.calcTimerRemainTimeText();
    },
    calcTimerRemainTimeText: function() {
        var t = "";
        if (this.data.timeType > this.data.timeArray.length - 1) t = "∞"; else {
            var e = Math.floor(this.data.timerRemainSec / 60) + "";
            e = e.length > 1 ? e : "0" + e;
            var i = this.data.timerRemainSec % 60 + "";
            i = i.length > 1 ? i : "0" + i, t = "".concat(e, ":").concat(i);
        }
        this.setData({
            timerRemainTimeText: t
        });
    },
    timeChange: function(t) {
        var e = t.detail.index;
        this.calcTimePannelTipsText(e), this.setData({
            timeType: e
        }), this.resetTime();
    },
    calcTimePannelTipsText: function(t) {
        this.setData({
            timeType: t
        });
        var e = "";
        e = this.data.timeType > this.data.timeArray.length - 1 ? "循环播放" : "".concat(this.data.timeArray[this.data.timeType], "分钟定时关闭"), 
        this.setData({
            timeingTipsText: e
        });
    },
    startTimer: function() {
        var t = this;
        if (this.stopTimer(), console.log("startTimer"), this.data.timeType > this.data.timeArray.length - 1) console.log("无限循环，不触发定时"); else {
            var e = setInterval(function() {
                var e = t.data.timerRemainSec;
                e > 0 && t.data.isMusicPlaying ? (e -= 1, t.setData({
                    timerRemainSec: e
                }), t.calcTimerRemainTimeText()) : e <= 0 && t.timeoutCallBack();
            }, 1e3);
            r.noiseTimer = e, this.setData({
                timer: e
            });
        }
    },
    timeoutCallBack: function() {
        console.log("定时已经结束回调，停止音频，并重置时间"), wx.getBackgroundAudioManager().stop(), this.resetTime();
    },
    stopTimer: function() {
        console.log("stopTimer"), clearInterval(this.data.timer);
    },
    shareNoise: function() {
        r.shareNoise = this.data.currentMusic, wx.navigateTo({
            url: "/pages/share-noise/share-noise"
        });
    },
    musicTop: function() {
        var t = this, i = n.config.CONST_KEY.MUSIC_TOP, a = wx.getStorageSync(i) || [];
        (a = a.filter(function(e) {
            return e.id !== t.data.currentMusic.id;
        })).unshift(this.data.currentMusic.id), wx.setStorageSync(i, a), this.reAssignList(this.data.selTagId), 
        setTimeout(function() {
            t.setData(e({}, "tagMusicListsHash.".concat(t.data.selTagId, ".scrollIntoView"), "music-item-".concat(t.data.selTagId, "-").concat(t.data.currentMusic.id)));
        }, 300);
    },
    assignTopMusic: function(t) {
        var e = wx.getStorageSync(n.config.CONST_KEY.MUSIC_TOP) || [], i = t.filter(function(t) {
            return e.includes(t.id);
        });
        i = i.sort(function(t, i) {
            return e.indexOf(t.id) > e.indexOf(i.id);
        });
        var a = t.filter(function(t) {
            return !e.includes(t.id);
        });
        return i.concat(a);
    },
    insertAdToMusic: function(t, e) {
        var i = e.music_stream_ad, a = e.resource_recommend;
        if (i && i.length > 0) {
            var s = i[0];
            s.cover_miniapp_black = s.ad_cover_black, s.musicdesc = s.ad_name, t.splice(3, 0, s);
        }
        if (i && i.length > 1) {
            var n = i[1];
            n.cover_miniapp_black = n.ad_cover_black, n.musicdesc = n.ad_name, t.splice(7, 0, n);
        }
        return a && a.length > 0 && t.splice(11, 0, {
            ad_id: -1,
            musicdesc: "更多推荐",
            cover_miniapp_black: "/images/home_ad.png"
        }), t;
    },
    reAssignList: function(t) {
        t = t || this.data.selTagId;
        var i = this.data.tagMusicListsHash[t], a = i.lists.filter(function(t) {
            return !t.ad_id;
        });
        a = this.assignTopMusic(a), 0 === this.data.currentTagIdx && (a = this.insertAdToMusic(a, i.ad)), 
        this.setData(e({}, "tagMusicListsHash.".concat(t, ".lists"), a));
    },
    randomPlay: function() {
        var t = this.data.tagMusicListsHash[this.data.selTagId].lists, i = t[(0, s.getRandomInt)(0, t.length - 1)];
        this.setData(e({
            currentMusic: i
        }, "tagMusicListsHash.".concat(this.data.selTagId, ".scrollIntoView"), "music-item-".concat(this.data.selTagId, "-").concat(i.id))), 
        this.rePlayCurrentMusic();
    },
    aiSearch: function() {
        var t = this;
        wx.getSetting({
            success: function(e) {
                console.log(e), e.authSetting["scope.record"] ? (console.log("录音已授权"), t.setData({
                    isShowAiVoiceRecognition: !0
                })) : wx.authorize({
                    scope: "scope.record",
                    success: function() {
                        console.log("录音授权成功"), t.setData({
                            isShowAiVoiceRecognition: !0
                        });
                    },
                    fail: function() {
                        wx.showModal({
                            title: "提示",
                            content: "需要授权录音功能后才能使用智能语音功能。",
                            success: function(e) {
                                e.confirm && wx.openSetting({
                                    success: function(e) {
                                        e.authSetting["scope.record"] && t.setData({
                                            isShowAiVoiceRecognition: !0
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    pauseMusic: function() {
        wx.getBackgroundAudioManager().pause();
    },
    aiVoicePlayMusic: function(t) {
        var i, a, n = t.detail && t.detail.mid, o = this.data.tagMusicListsHash[this.data.tagList[0].tag_id], c = [];
        if (c = o ? o.lists : this.data.tagMusicListsHash[this.data.selTagId].lists, n) for (var r = 0; r < c.length; r++) {
            var l = c[r];
            if (l.id === n) {
                a = l;
                break;
            }
        }
        a || (a = c[(0, s.getRandomInt)(0, c.length - 1)]);
        this.setData((e(i = {
            currentMusic: a
        }, "tagMusicListsHash.".concat(this.data.selTagId, ".scrollIntoView"), "music-item-".concat(this.data.selTagId, "-").concat(a.id)), 
        e(i, "tagMusicListsHash.".concat(this.data.tagList[0].tag_id, ".scrollIntoView"), "music-item-".concat(this.data.tagList[0].tag_id, "-").concat(a.id)), 
        i)), this.rePlayCurrentMusic();
    },
    selAd: function(t) {
        if (console.log("zheli"), !t.ad_id || t.ad_id < 0) return wx.reportAnalytics("goto_app_inner_list", {}), 
        void wx.navigateTo({
            url: "/pages/ad-miniapp/ad-miniapp"
        });
        var e = {};
        try {
            e = JSON.parse(t.ad_link);
        } catch (t) {
            console.log(t), c.reportError(t.message, "外部广告JSON解析错误").then().catch();
        }
        1 === t.ad_type && (console.log("APPID:", t.ad_id), console.log("APPNAME:", t.ad_name), 
        e.success = function(e) {
            wx.reportAnalytics("recommend_app_outer", {
                appid: t.ad_id,
                appname: t.ad_name
            });
        }, e.fail = function(e) {
            console.log(e), c.reportError(e.errMsg, "外部广告唤起失败").then().catch(), wx.showToast({
                title: "打开“".concat(t.ad_name, "”失败"),
                icon: "none",
                duration: 2e3
            });
        }, wx.navigateToMiniProgram(e)), 2 === t.ad_type && 20 === e.func_type && (r.voiceJump = e, 
        wx.switchTab({
            url: "/pages/voice/voice",
            fail: function(t) {
                console.log(t), wx.showToast({
                    title: "打开“助眠模块”失败",
                    icon: "none",
                    duration: 2e3
                });
            }
        }));
    },
    mainPopupAdAction: function() {
        var t = !1;
        try {
            var e = r && r.config && r.config.home_popup_ad.ad_link && JSON.parse(r.config.home_popup_ad.ad_link);
            if (!e.appId) throw new Error("我的页面广告数据没有APPID");
            e.success = function(t) {
                console.info(t);
            }, e.fail = function(t) {
                console.log(t);
            }, wx.navigateToMiniProgram(e);
        } catch (e) {
            t = !0, c.reportError(e, "我的页面底部广告唤起失败").then().catch();
        }
        if (t) {
            console.log("GOGO");
            var i = r && r.config && r.config.home_popup_ad.ad_link && JSON.parse(r.config.home_popup_ad.ad_link);
            wx.navigateTo({
                url: "/pages/web/web?url=" + i.link
            });
        }
    },
    handleInJumpUrl: function() {
        var t = r.query.jumpUrl;
        delete r.query.jumpUrl, console.info("handleInJumpUrl", t), wx.navigateTo({
            url: "/pages/web/web?url=".concat(t)
        });
    }
});