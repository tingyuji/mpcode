var e = require("@babel/runtime/helpers/interopRequireDefault")(require("@babel/runtime/regenerator")), a = require("@babel/runtime/helpers/asyncToGenerator"), n = require("./utils/util.js"), t = require("./model/user.js"), o = new (require("./model/system.js").SystemModel)(), l = new t.UserModel();

App({
    onLaunch: function(e) {
        this.globalData.isios = /iPad|iPhone/.test(wx.getSystemInfoSync().model), console.log("isIOS：", this.globalData.isios), 
        console.log("app", e);
        try {
            var a = e.query && e.query.channel ? e.query.channel : "default";
            wx.reportAnalytics("channel_statistics_manual", {
                channel: a,
                path: e.path
            });
        } catch (e) {
            console.log(e);
        }
        this.globalData.query = Object.assign(this.globalData.query, (0, n.handleAppPageOption)(e.query)), 
        this.globalData.systemInfo = wx.getSystemInfoSync(), this.globalData.isIOS = this.globalData.systemInfo.system.indexOf("iOS") >= 0, 
        this.globalData.isAndroid = this.globalData.systemInfo.system.indexOf("Android") >= 0;
    },
    getInfo: function() {
        var e = this;
        return new Promise(function(a, n) {
            o.getConfig().then(function(n) {
                n.android_pay_enable = "1" === n.android_pay_enable, n.ios_pay_enable = "1" === n.ios_pay_enable, 
                n.audit_mode = "1" === n.audit_mode, e.globalData.config = n, e.globalData.canBuy = e.globalData.isIOS && e.globalData.config.ios_pay_enable || e.globalData.isAndroid && e.globalData.config.android_pay_enable, 
                console.log("GLOBALDATA:", e.globalData), a();
            }).catch(function(e) {
                n(e), console.log(e);
            });
        });
    },
    onShow: function() {
        var n = this;
        return a(e.default.mark(function t() {
            return e.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    l.getUserInfo().then().catch(), setTimeout(a(e.default.mark(function a() {
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, n.getInfo();

                              case 2:
                              case "end":
                                return e.stop();
                            }
                        }, a);
                    })), 1e3);

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    globalData: {
        systemInfo: {},
        config: {
            android_pay_enable: !1,
            ios_pay_enable: !1,
            audit_mode: !1
        },
        query: {},
        firstOpenGlobal: !1,
        userInfo: null,
        noiseTimer: null,
        recommendTimer: null,
        currentMusic: {},
        currentMusicUrl: "",
        currentMusicType: ""
    }
});