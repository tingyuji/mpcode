(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/guide/index" ], {
    2423: function(e, t, n) {
        n.r(t);
        var o = n(2424), r = n(2426), c = (n(2428), n(94)), i = Object(c.default)(r.default, o.render, o.staticRenderFns, !1, null, "67ef2ac2", null);
        i.options.__file = "src/components/guide/index.vue", t.default = i.exports;
    },
    2424: function(e, t, n) {
        n.r(t);
        var o = n(2425);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    2425: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    2426: function(e, t, n) {
        n.r(t);
        var o = n(2427);
        t.default = o.default;
    },
    2427: function(e, t, n) {
        n.r(t), function(e) {
            var o = n(19), r = n(88), c = n.n(r), i = n(45);
            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            t.default = {
                name: "Guide",
                props: {
                    showGuide: {
                        type: Boolean,
                        default: !1
                    },
                    guideImg: {
                        type: String,
                        default: "https://webimg.dewucdn.com/node-common/3e606fd9241316fd34dff065e30ecfe1.png"
                    }
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(n), !0).forEach(function(t) {
                            a(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, Object(o.mapState)([ "SERVICE_ENV" ])),
                methods: {
                    pushCustomerService: function() {
                        var t = e.getStorageSync("X-Auth-Token") || c.a.get("xAuthToken"), n = e.getStorageSync("userInfo") || "", o = n.userId, r = n.icon, u = "https://".concat(this.SERVICE_ENV, "-chat.dewu.com/h5?");
                        "pro" === this.SERVICE_ENV && (u = "https://chat.dewu.com/h5?");
                        var a = new Date().getTime(), d = "".concat(u, "im=") + encodeURIComponent("ts=".concat(a, "&channel=10002&sourceId=10003&fromPage=myOrder&fromTitle=我的购买&userId=").concat(o, "&avatar=").concat(r, "&token=").concat(t));
                        console.log("webUrl", this.SERVICE_ENV, d), Object(i.navigationToWeb)(d);
                    },
                    closeGuide: function() {
                        this.$emit("update:showGuide", !1);
                    }
                }
            };
        }.call(this, n(1).default);
    },
    2428: function(e, t, n) {
        n.r(t);
        var o = n(2429), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = r.a;
    },
    2429: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/guide/index-create-component", {
    "components/guide/index-create-component": function(e, t, n) {
        n("1").createComponent(n(2423));
    }
}, [ [ "components/guide/index-create-component" ] ] ]);