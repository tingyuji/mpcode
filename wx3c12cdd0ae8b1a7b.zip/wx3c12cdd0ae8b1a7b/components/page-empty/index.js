(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/page-empty/index" ], {
    1672: function(e, n, t) {
        t.r(n);
        var o = t(1673), r = t(1675), c = (t(1677), t(94)), a = Object(c.default)(r.default, o.render, o.staticRenderFns, !1, null, "29eb7662", null);
        a.options.__file = "src/components/page-empty/index.vue", n.default = a.exports;
    },
    1673: function(e, n, t) {
        t.r(n);
        var o = t(1674);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    1674: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    1675: function(e, n, t) {
        t.r(n);
        var o = t(1676);
        n.default = o.default;
    },
    1676: function(e, n, t) {
        t.r(n), n.default = {
            props: {
                message: {
                    type: String,
                    default: "这里还没有内容"
                }
            }
        };
    },
    1677: function(e, n, t) {
        t.r(n);
        var o = t(1678), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    },
    1678: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/page-empty/index-create-component", {
    "components/page-empty/index-create-component": function(e, n, t) {
        t("1").createComponent(t(1672));
    }
}, [ [ "components/page-empty/index-create-component" ] ] ]);