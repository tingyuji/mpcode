(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/badge/badge/index" ], {
    1502: function(e, n, t) {
        t.r(n);
        var o = t(1503), r = t(1505), a = (t(1507), t(94)), d = Object(a.default)(r.default, o.render, o.staticRenderFns, !1, null, "1f795bcc", null);
        d.options.__file = "src/components/badge/badge/index.vue", n.default = d.exports;
    },
    1503: function(e, n, t) {
        t.r(n);
        var o = t(1504);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    1504: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    1505: function(e, n, t) {
        t.r(n);
        var o = t(1506);
        n.default = o.default;
    },
    1506: function(e, n, t) {
        t.r(n), n.default = {
            props: {
                color: {
                    type: String,
                    default: "#fff"
                },
                backgroundColor: {
                    type: String,
                    default: "#f44"
                },
                fontSize: {
                    type: Number,
                    default: 10
                },
                boxShadow: {
                    type: String,
                    default: "0 0 0 2px #fff"
                },
                styles: {
                    type: String,
                    default: ""
                }
            }
        };
    },
    1507: function(e, n, t) {
        t.r(n);
        var o = t(1508), r = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = r.a;
    },
    1508: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/badge/badge/index-create-component", {
    "components/badge/badge/index-create-component": function(e, n, t) {
        t("1").createComponent(t(1502));
    }
}, [ [ "components/badge/badge/index-create-component" ] ] ]);