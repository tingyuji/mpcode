(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/badge/pot-badge/index" ], {
    3724: function(n, e, t) {
        t.r(e);
        var o = t(3725), r = t(3727), a = (t(3729), t(94)), c = Object(a.default)(r.default, o.render, o.staticRenderFns, !1, null, "3f3ecca2", null);
        c.options.__file = "src/components/badge/pot-badge/index.vue", e.default = c.exports;
    },
    3725: function(n, e, t) {
        t.r(e);
        var o = t(3726);
        t.d(e, "render", function() {
            return o.render;
        }), t.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    3726: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    3727: function(n, e, t) {
        t.r(e);
        var o = t(3728);
        e.default = o.default;
    },
    3728: function(n, e, t) {
        t.r(e), e.default = {
            props: {
                num: {
                    type: Number,
                    default: 0
                }
            },
            computed: {
                amount: function() {
                    return this.num > 99 ? "99+" : this.num;
                }
            }
        };
    },
    3729: function(n, e, t) {
        t.r(e);
        var o = t(3730), r = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = r.a;
    },
    3730: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/badge/pot-badge/index-create-component", {
    "components/badge/pot-badge/index-create-component": function(n, e, t) {
        t("1").createComponent(t(3724));
    }
}, [ [ "components/badge/pot-badge/index-create-component" ] ] ]);