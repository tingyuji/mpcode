(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/product-flow/index" ], {
    2049: function(n, e, t) {
        t.r(e);
        var o = t(2050), r = t(2052), c = (t(2054), t(94)), u = Object(c.default)(r.default, o.render, o.staticRenderFns, !1, null, "34e2eedf", null);
        u.options.__file = "src/components/product-flow/index.vue", e.default = u.exports;
    },
    2050: function(n, e, t) {
        t.r(e);
        var o = t(2051);
        t.d(e, "render", function() {
            return o.render;
        }), t.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    2051: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    2052: function(n, e, t) {
        t.r(e);
        var o = t(2053);
        e.default = o.default;
    },
    2053: function(n, e, t) {
        t.r(e);
        var o = t(105);
        e.default = {
            components: {
                ProductItem: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("components/product-flow/item") ]).then(t.bind(null, 3900));
                }
            },
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [ {} ];
                    }
                }
            },
            computed: {
                isDefaultSlot: function() {
                    return this.$slots.default;
                }
            },
            created: function() {
                var n = this;
                o.default.$on("product-exposure", function() {
                    for (var e = arguments.length, t = new Array(e), o = 0; o < e; o++) t[o] = arguments[o];
                    n.$emit("product-exposure", t);
                });
            }
        };
    },
    2054: function(n, e, t) {
        t.r(e);
        var o = t(2055), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = r.a;
    },
    2055: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/product-flow/index-create-component", {
    "components/product-flow/index-create-component": function(n, e, t) {
        t("1").createComponent(t(2049));
    }
}, [ [ "components/product-flow/index-create-component" ] ] ]);