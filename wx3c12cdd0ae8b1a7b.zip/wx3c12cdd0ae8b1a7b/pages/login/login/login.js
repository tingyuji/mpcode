(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login/login" ], {
    138: function(o, n, t) {
        t.r(n), function(o) {
            t(7), t(8), t(2), o(t(139).default);
        }.call(this, t(1).createPage);
    },
    139: function(o, n, t) {
        t.r(n);
        var e = t(140), i = t(142), r = (t(144), t(94)), c = Object(r.default)(i.default, e.render, e.staticRenderFns, !1, null, null, null);
        c.options.__file = "src/pages/login/login/login.vue", n.default = c.exports;
    },
    140: function(o, n, t) {
        t.r(n);
        var e = t(141);
        t.d(n, "render", function() {
            return e.render;
        }), t.d(n, "staticRenderFns", function() {
            return e.staticRenderFns;
        });
    },
    141: function(o, n, t) {
        t.r(n), t.d(n, "render", function() {
            return e;
        }), t.d(n, "staticRenderFns", function() {
            return i;
        });
        var e = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
        e._withStripped = !0;
    },
    142: function(o, n, t) {
        t.r(n);
        var e = t(143);
        n.default = e.default;
    },
    143: function(o, n, t) {
        t.r(n), function(o) {
            var e = t(15), i = t(45), r = t(106), c = t(120), s = t(121);
            n.default = {
                components: {
                    customNavigation: function() {
                        return t.e("components/customNavigation/customNavigation").then(t.bind(null, 1615));
                    },
                    ProtocolAgreed: function() {
                        return Promise.all([ t.e("common/vendor"), t.e("pages/login/components/protocol-agreed-component") ]).then(t.bind(null, 1622));
                    }
                },
                data: function() {
                    return {
                        token: "",
                        promiseId: "",
                        protocolAgreed: !1,
                        showProtocolPopUp: !1
                    };
                },
                onLoad: function(o) {
                    this.token = o.token || "";
                },
                methods: {
                    toggleCheck: function(o) {
                        this.protocolAgreed = o;
                    },
                    onClickWithoutProtocolAgreed: function() {
                        this.protocolAgreed || (this.showProtocolPopUp = !0);
                    },
                    getPhoneNumber: function(n) {
                        var t = this;
                        if (this.protocolAgreed) {
                            var c = n.detail, s = c.iv, u = c.encryptedData;
                            if (s && u) {
                                var l = {
                                    type: "wxapp",
                                    weixinData: JSON.stringify({
                                        encryptedData: u,
                                        iv: s
                                    }),
                                    token: this.token
                                }, a = {
                                    php: !0
                                };
                                Object(i.checkSessionKey)().then(function(n) {
                                    n && (l.token = t.token = n), t.duserver.postRequest("mapi/users/appMobileLogin", l, a).then(function(n) {
                                        if (200 === n.status) {
                                            Object(e.loginSuccessCallBack)(n.data, !0);
                                            var i = n.data.userInfo || {}, c = i.userId;
                                            t.RiskSDK && t.RiskSDK.bindUser("wx", c), Object(r.bindBehaviorTracking)(), t.commonSinginLogin({
                                                title: "一键登录",
                                                userId: i.userId,
                                                isSuccess: 1
                                            });
                                        } else o.showToast({
                                            title: n.msg || "未知错误",
                                            icon: "none"
                                        }), t.commonSinginLogin({
                                            title: "一键登录",
                                            userId: "",
                                            isSuccess: 0
                                        });
                                    }).catch(function(o) {
                                        console.log("login fail:" + o), t.commonSinginLogin({
                                            title: "一键登录",
                                            userId: "",
                                            isSuccess: 0
                                        });
                                    });
                                }).catch(function(o) {
                                    console.error(o);
                                });
                            }
                        } else this.showProtocolPopUp = !0;
                    },
                    goDuLogin: function() {
                        var n = this.protocolAgreed;
                        if (n) {
                            var t = "/pages/login/duLogin/login?token=" + this.token;
                            n && (t += "&protocal=1"), o.navigateTo({
                                url: t
                            });
                        } else this.showProtocolPopUp = !0;
                    },
                    commonSinginLogin: function(o) {
                        var n = o.title, t = o.userId, e = o.isSuccess, i = s.default.common_singin_login_click_1189_2182({
                            userId: t,
                            title: n,
                            isSuccess: e,
                            url: Object(s.getCurrentPageUrl)()
                        });
                        Object(c.oneTrack)(i.eventName, i.data);
                    },
                    closeProtocolPopup: function() {
                        this.showProtocolPopUp = !1;
                    },
                    handleAgreed: function() {
                        this.protocolAgreed = !0, this.showProtocolPopUp = !1;
                    }
                }
            };
        }.call(this, t(1).default);
    },
    144: function(o, n, t) {
        t.r(n);
        var e = t(145), i = t.n(e);
        for (var r in e) [ "default" ].indexOf(r) < 0 && function(o) {
            t.d(n, o, function() {
                return e[o];
            });
        }(r);
        n.default = i.a;
    },
    145: function(o, n, t) {}
}, [ [ 138, "common/runtime", "common/vendor" ] ] ]);