(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/components/protocol-agreed-component" ], {
    1622: function(e, n, o) {
        o.r(n);
        var t = o(1623), r = o(1625), c = (o(1627), o(94)), a = Object(c.default)(r.default, t.render, t.staticRenderFns, !1, null, "40399624", null);
        a.options.__file = "src/pages/login/components/protocol-agreed-component.vue", n.default = a.exports;
    },
    1623: function(e, n, o) {
        o.r(n);
        var t = o(1624);
        o.d(n, "render", function() {
            return t.render;
        }), o.d(n, "staticRenderFns", function() {
            return t.staticRenderFns;
        });
    },
    1624: function(e, n, o) {
        o.r(n), o.d(n, "render", function() {
            return t;
        }), o.d(n, "staticRenderFns", function() {
            return r;
        });
        var t = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        t._withStripped = !0;
    },
    1625: function(e, n, o) {
        o.r(n);
        var t = o(1626);
        n.default = t.default;
    },
    1626: function(e, n, o) {
        o.r(n);
        var t = o(109);
        n.default = {
            name: "ProtocolAgreed",
            props: {
                agreed: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {};
            },
            methods: {
                toggleCheck: function() {
                    this.$emit("toggleCheck", !this.agreed);
                },
                goProtocolPage: t.goProtocolPage
            }
        };
    },
    1627: function(e, n, o) {
        o.r(n);
        var t = o(1628), r = o.n(t);
        for (var c in t) [ "default" ].indexOf(c) < 0 && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(c);
        n.default = r.a;
    },
    1628: function(e, n, o) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/login/components/protocol-agreed-component-create-component", {
    "pages/login/components/protocol-agreed-component-create-component": function(e, n, o) {
        o("1").createComponent(o(1622));
    }
}, [ [ "pages/login/components/protocol-agreed-component-create-component" ] ] ]);