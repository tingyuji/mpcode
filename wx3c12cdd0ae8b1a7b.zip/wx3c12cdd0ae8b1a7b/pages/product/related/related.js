(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/product/related/related" ], {
    170: function(t, n, e) {
        e.r(n), function(t) {
            e(7), e(8), e(2), t(e(171).default);
        }.call(this, e(1).createPage);
    },
    171: function(t, n, e) {
        e.r(n);
        var a = e(172), o = e(174), i = (e(176), e(94)), r = Object(i.default)(o.default, a.render, a.staticRenderFns, !1, null, null, null);
        r.options.__file = "src/pages/product/related/related.vue", n.default = r.exports;
    },
    172: function(t, n, e) {
        e.r(n);
        var a = e(173);
        e.d(n, "render", function() {
            return a.render;
        }), e.d(n, "staticRenderFns", function() {
            return a.staticRenderFns;
        });
    },
    173: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return a;
        }), e.d(n, "staticRenderFns", function() {
            return o;
        });
        var a = function() {
            var t = this, n = (t.$createElement, t._self._c, t.__map(t.datalist, function(n, e) {
                var a = t.filter.handleImage(n.logoUrl, "300"), o = t.filter.handlePrice(n.price);
                return {
                    $orig: t.__get_orig(n),
                    g0: a,
                    g1: o
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: n
                }
            });
        }, o = [];
        a._withStripped = !0;
    },
    174: function(t, n, e) {
        e.r(n);
        var a = e(175);
        n.default = a.default;
    },
    175: function(t, n, e) {
        e.r(n), function(t) {
            n.default = {
                data: function() {
                    return {
                        datalist: [],
                        productId: 0,
                        lastId: ""
                    };
                },
                onLoad: function(t) {
                    this.setData({
                        productId: t.productId
                    }), this.getProductList(!0);
                },
                onReady: function() {},
                onShow: function() {},
                onHide: function() {},
                onUnload: function() {},
                onPullDownRefresh: function() {
                    this.getProductList(!0);
                },
                onReachBottom: function() {
                    this.getProductList(!1);
                },
                onShareAppMessage: function() {},
                methods: {
                    enterProductDetail: function(n) {
                        var e = n.currentTarget.dataset.index, a = this.datalist[e];
                        t.navigateTo({
                            url: "/product/ProductDetail?spuId=".concat(a.spuId)
                        });
                    },
                    getProductList: function(n) {
                        var e = this;
                        if (0 != n || "" != e.lastId) {
                            var a = {
                                limit: 20,
                                spuId: e.productId,
                                lastId: n ? "" : e.lastId
                            };
                            this.duserver.postRequest("/api/v1/h5/commodity/fire/relation-list", a, {
                                stone: !0,
                                json: !0
                            }).then(function(a) {
                                if (a && 200 === a.status) {
                                    var o = n ? a.data.list : e.datalist.concat(a.data.list), i = a.data.lastId ? a.data.lastId : "";
                                    e.setData({
                                        datalist: o,
                                        lastId: i
                                    });
                                } else t.showToast({
                                    icon: "none",
                                    title: a.msg
                                });
                                setTimeout(function() {
                                    t.hideNavigationBarLoading(), t.stopPullDownRefresh();
                                }, 1e3);
                            });
                        }
                    }
                }
            };
        }.call(this, e(1).default);
    },
    176: function(t, n, e) {
        e.r(n);
        var a = e(177), o = e.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        n.default = o.a;
    },
    177: function(t, n, e) {}
}, [ [ 170, "common/runtime", "common/vendor" ] ] ]);