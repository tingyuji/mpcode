(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/identify/index" ], {
    184: function(e, t, n) {
        n.r(t), function(e) {
            n(7), n(8), n(2), e(n(185).default);
        }.call(this, n(1).createPage);
    },
    185: function(e, t, n) {
        n.r(t);
        var i = n(186), o = n(188), r = (n(209), n(94)), s = Object(r.default)(o.default, i.render, i.staticRenderFns, !1, null, "736d6813", null);
        s.options.__file = "src/pages/identify/index.vue", t.default = s.exports;
    },
    186: function(e, t, n) {
        n.r(t);
        var i = n(187);
        n.d(t, "render", function() {
            return i.render;
        }), n.d(t, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    187: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return i;
        }), n.d(t, "staticRenderFns", function() {
            return o;
        });
        var i = function() {
            this.$createElement;
            var e = (this._self._c, this.thousands(this.home.identifyInfo.totalNum)), t = JSON.stringify({
                id: "identify_block_click_1044_213",
                utm_source: this.channel
            }), n = JSON.stringify({
                id: "identify_block_click_1044_2392"
            }), i = JSON.stringify({
                id: "identify_block_content_click_1044_6",
                position: 2,
                block_content_url: "/account/MyCouponPage"
            }), o = JSON.stringify({
                id: "identify_block_content_click_1044_6",
                position: 1,
                block_content_url: "/identify/pages/identifylist/index"
            });
            this.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    g0: t,
                    g1: n,
                    g2: i,
                    g3: o
                }
            });
        }, o = [];
        i._withStripped = !0;
    },
    188: function(e, t, n) {
        n.r(t);
        var i = n(189);
        t.default = i.default;
    },
    189: function(e, t, n) {
        n.r(t), function(e) {
            var i = n(45), o = n(190), r = (n(191), n(207)), s = n(208);
            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    t && (i = i.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach(function(t) {
                        d(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function d(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            var u = {
                title: "得物在线鉴别",
                path: "pages/identify/index"
            };
            t.default = {
                components: {
                    Identifyer: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("pages/identify/components/identifyer/index") ]).then(n.bind(null, 1629));
                    },
                    Qa: function() {
                        return Promise.all([ n.e("common/vendor"), n.e("pages/identify/components/qa/index") ]).then(n.bind(null, 1637));
                    },
                    Banner: function() {
                        return n.e("pages/identify/components/banner/index").then(n.bind(null, 1644));
                    },
                    Category: function() {
                        return n.e("pages/identify/components/category/index").then(n.bind(null, 1651));
                    },
                    Introduce: function() {
                        return n.e("pages/identify/components/introduce/index").then(n.bind(null, 1658));
                    },
                    OnlineCategory: function() {
                        return n.e("pages/identify/components/onlinecategory/index").then(n.bind(null, 1665));
                    }
                },
                mixins: [ r.shareMix ],
                data: function() {
                    return {
                        share: c({}, u),
                        showCategory: !1,
                        showonlineCategory: !1,
                        introduceImg: "",
                        identifyerNum: 0,
                        identifyId: "",
                        isLogin: Object(i.isLogin)(),
                        shareItem: {},
                        identifyer: [],
                        onlineNewMessageNum: 0,
                        offlineNewMessageNum: 0,
                        identifyList: [],
                        hidePage: !0,
                        lastId: 0,
                        isShowpopo: !1,
                        modalStatus: !1,
                        sourcelist: [],
                        showIntroduce: !1,
                        canDelete: !0,
                        deleteModalStatus: !1,
                        home: {
                            identifyInfo: {
                                title: "鉴别服务开创者",
                                buttonText: "在线鉴别",
                                totalNum: 262764779,
                                freeNum: 262764779
                            },
                            expertTitle: "124位鉴别师"
                        },
                        channel: "",
                        timer: null
                    };
                },
                computed: {
                    hotBatch: function() {
                        var e = this.onlineNewMessageNum, t = this.offlineNewMessageNum;
                        return e > 0 || t > 0;
                    },
                    hotBatchType: function() {
                        var e = this.onlineNewMessageNum, t = this.offlineNewMessageNum;
                        return e > 0 ? "onlineIdentify" : t > 0 ? "physicalIdentify" : "onlineIdentify";
                    }
                },
                onPullDownRefresh: function() {
                    console.log("onPullDownRefresh", this.isLogin), this.getHomeData(), this.getHint(), 
                    this.getIdentifyer();
                },
                onTabItemTap: function(t) {
                    this.identifyExposureTrack("trade_block_content_click_734_350"), e.hideTabBarRedDot({
                        index: t.index
                    });
                },
                onHide: function() {
                    this.hidePage = !0, this.showCategory = !1;
                },
                onUnload: function() {
                    this.hidePage = !0;
                },
                onShow: function() {
                    var t = this;
                    this.isLogin = Object(i.isLogin)(), console.log("onShow", this.isLogin), this.getHomeData(), 
                    this.hidePage = !1, this.getIdentifyer(), this.getHint(), this.getSource();
                    var n = new s.default().getCurrentPage().options || {};
                    console.log("curparam", n), this.channel = n.channel || "", e.setStorageSync("channel", this.channel), 
                    this.identifyExposureTrack("identify_pageview_1044", {
                        utm_source: this.channel
                    }), this.identifyExposureTrack("identify_block_exposure_1044_2392"), e.getStorageSync("offflineOpen") || (e.setStorageSync("offflineOpen", !0), 
                    this.isShowpopo = !0, this.timer = setTimeout(function() {
                        t.isShowpopo = !1, clearTimeout(t.timer), t.timer = null;
                    }, 3e3));
                },
                onLoad: function() {
                    e.setNavigationBarColor({
                        frontColor: "#000000",
                        backgroundColor: "#F5F5F9"
                    });
                },
                methods: {
                    goToPublic: function(t) {
                        var n = t.extra, i = n.productId, r = n.seriesId, s = n.secondClassId, a = n.brandId, c = n.promptId, d = n.status, u = {
                            seriesId: r,
                            promptId: c,
                            secondClassId: s,
                            brandId: a
                        };
                        i && (u = {
                            productId: Number(t.productId),
                            status: d + ""
                        }), e.navigateTo({
                            url: "/identify/pages/publish/index?" + Object(o.urlEncode)(u)
                        });
                    },
                    handleaCouponPage: function() {
                        e.navigateTo({
                            url: "/account/MyCouponPage"
                        });
                    },
                    handlemyidentify: function() {
                        if (console.log("去我的鉴别"), this.isLogin) {
                            var t = [ "online", "offline" ][+("physicalIdentify" === this.hotBatchType)];
                            e.navigateTo({
                                url: "/identify/pages/identifylist/index?mode=".concat(t)
                            });
                        } else this.goLogin();
                    },
                    thousands: function(e) {
                        return function(e) {
                            var t = e.toString(), n = t.indexOf(".") > -1 ? /(\d)(?=(\d{3})+\.)/g : /(\d)(?=(?:\d{3})+$)/g;
                            return t.replace(n, "$1,");
                        }(e);
                    },
                    identifyStep: function() {
                        this.isLogin ? this.showonlineCategory = !0 : this.goLogin();
                    },
                    getIdentifyer: function() {
                        var e = this;
                        this.identifyList = [], this.duserver.getRequest("/identify-server/v1/common/expert/expertOnlineTotalInfoXcx").then(function(t) {
                            200 == (null == t ? void 0 : t.status) && (e.identifyer = t.data, e.identifyerNum = t.data.total, 
                            e.identifyer.expertListMap.forEach(function(t) {
                                var n = parseInt(Math.random() * t.length, 10);
                                t[n] && e.identifyList.push(t[n]);
                            }), e.identifyList.forEach(function(e) {
                                e.desc.replace("/", "|");
                            }));
                        });
                    },
                    getHomeData: function() {
                        var t = this, n = {
                            1: "/identify-index/v1/identify/xcx",
                            0: "/api/v1/h5/identify-index/v1/common/identify/xcx"
                        }[this.isLogin ? "1" : "0"];
                        this.duserver.getRequest(n).then(function(n) {
                            200 == (null == n ? void 0 : n.status) && (t.home = n.data), e.setStorageSync("serveTitle", t.home.identifyInfo.text), 
                            setTimeout(function() {
                                e.hideNavigationBarLoading(), e.stopPullDownRefresh();
                            }, 1e3);
                        });
                    },
                    getHint: function() {
                        if (this.isLogin) {
                            var e = this;
                            wx.getStorage({
                                key: "userInfo",
                                success: function(t) {
                                    var n = t.data && t.data.userId || "";
                                    e.duserver.postRequest("/api/v1/h5/hot/hint/v1/getUserH5HotBatch", {
                                        userId: n,
                                        hotType: "number"
                                    }, {
                                        json: !0
                                    }).then(function(t) {
                                        200 == (null == t ? void 0 : t.status) && (e.onlineNewMessageNum = t.data && t.data.identifyNum || 0);
                                    }), e.duserver.getRequest("/identify-order/api/v1/internal/api/physical/hot-hint/get", {
                                        userId: n,
                                        type: "physicalIdentifyNum"
                                    }).then(function(t) {
                                        var n = t.code, i = t.data;
                                        200 === n && (e.offlineNewMessageNum = i && i.num || 0);
                                    }).catch(console.error);
                                }
                            });
                        }
                    },
                    getSource: function() {
                        var e = this;
                        try {
                            this.duserver.getRequest("/identify-server/v1/common/wechat/xcx/resource/list", {
                                tenant: 1,
                                positionType: 1,
                                pageSize: 4
                            }, {
                                json: !0
                            }).then(function(t) {
                                200 == (null == t ? void 0 : t.status) && (console.log("hint", t), e.sourcelist = t.data || [], 
                                e.identifyExposureTrack("identify_block_content_exposure_1044_4", {
                                    identify_block_content_info_list: [ {
                                        position: 1,
                                        block_content_url: e.sourcelist[0] ? e.sourcelist[0].actionUrl : ""
                                    } ]
                                }));
                            });
                        } catch (e) {
                            console.log("hint", e);
                        }
                    },
                    handleofflineIdent: function() {
                        var e = this;
                        try {
                            this.duserver.getRequest("/identify-order/api/v1/internal/api/physical/check-placed-order", {
                                json: !0
                            }).then(function(t) {
                                200 == (null == t ? void 0 : t.status) && (t.data.placedOrder ? (e.showCategory = !0, 
                                e.identifyExposureTrack("identify_block_exposure_1305")) : (e.introduceImg = t.data.imageUrl, 
                                e.showIntroduce = !0, e.identifyExposureTrack("identify_block_exposure_1382")));
                            });
                        } catch (e) {
                            console.log("hint", e);
                        }
                    },
                    goPublish: function(t) {
                        var n = t.brandId, i = t.categoryId, r = t.categoryName, s = t.enableSearch;
                        "" !== n ? (console.log("brandId1", n), e.navigateTo({
                            url: "/identify/pages/offlinepublish/index?" + Object(o.urlEncode)({
                                brandId: n,
                                firstCategoryId: i,
                                firstCategoryName: r
                            })
                        })) : (console.log("brandId2", n), e.navigateTo({
                            url: "/identify/pages/classificationV2/index?firstCategoryId=".concat(i, "&firstCategoryName=").concat(r, "&enableSearch=").concat(s)
                        }));
                    },
                    gopinxuan: function() {
                        e.navigateTo({
                            url: "/identify/pages/web/web?" + Object(o.urlEncode)({
                                url: "https://cdn-fast.dewu.com/nezha-plus/detail/62ecc9d7de095d3d806fc0a7?duWebviewBg=%23ffffff&outside_channel_type=0&share_platform_title=0"
                            })
                        });
                    },
                    closeIntroduce: function(e) {
                        e && (this.showCategory = e), this.showIntroduce = !1;
                    },
                    closeClass: function() {
                        this.showCategory = !1, this.showonlineCategory = !1;
                    },
                    goLogin: function() {
                        this.isLogin || Object(i.doLogin)();
                    }
                }
            };
        }.call(this, n(1).default);
    },
    209: function(e, t, n) {
        n.r(t);
        var i = n(210), o = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = o.a;
    },
    210: function(e, t, n) {}
}, [ [ 184, "common/runtime", "common/vendor" ] ] ]);