(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/identify/components/introduce/index" ], {
    1658: function(n, e, t) {
        t.r(e);
        var o = t(1659), i = t(1661), r = (t(1663), t(94)), c = Object(r.default)(i.default, o.render, o.staticRenderFns, !1, null, "17bb4a10", null);
        c.options.__file = "src/pages/identify/components/introduce/index.vue", e.default = c.exports;
    },
    1659: function(n, e, t) {
        t.r(e);
        var o = t(1660);
        t.d(e, "render", function() {
            return o.render;
        }), t.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    1660: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return o;
        }), t.d(e, "staticRenderFns", function() {
            return i;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
        o._withStripped = !0;
    },
    1661: function(n, e, t) {
        t.r(e);
        var o = t(1662);
        e.default = o.default;
    },
    1662: function(n, e, t) {
        t.r(e), e.default = {
            name: "Category",
            props: {
                showIntroduce: {
                    type: Boolean,
                    default: function() {
                        return !1;
                    }
                },
                imgUrl: {
                    type: String,
                    default: function() {
                        return "";
                    }
                }
            },
            data: function() {
                return {
                    show: !0
                };
            },
            mounted: function() {},
            methods: {
                closeMask: function() {
                    this.$emit("closeIntroduce", !1);
                },
                goBrand: function() {
                    this.$emit("closeIntroduce", !0), this.identifyExposureTrack("identify_block_click_1382");
                }
            }
        };
    },
    1663: function(n, e, t) {
        t.r(e);
        var o = t(1664), i = t.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(r);
        e.default = i.a;
    },
    1664: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/identify/components/introduce/index-create-component", {
    "pages/identify/components/introduce/index-create-component": function(n, e, t) {
        t("1").createComponent(t(1658));
    }
}, [ [ "pages/identify/components/introduce/index-create-component" ] ] ]);