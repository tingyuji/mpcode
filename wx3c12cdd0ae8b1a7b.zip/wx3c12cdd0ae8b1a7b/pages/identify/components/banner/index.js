(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/identify/components/banner/index" ], {
    1644: function(n, e, t) {
        t.r(e);
        var i = t(1645), o = t(1647), c = (t(1649), t(94)), r = Object(c.default)(o.default, i.render, i.staticRenderFns, !1, null, "364e0aee", null);
        r.options.__file = "src/pages/identify/components/banner/index.vue", e.default = r.exports;
    },
    1645: function(n, e, t) {
        t.r(e);
        var i = t(1646);
        t.d(e, "render", function() {
            return i.render;
        }), t.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        });
    },
    1646: function(n, e, t) {
        t.r(e), t.d(e, "render", function() {
            return i;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        });
        var i = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
        i._withStripped = !0;
    },
    1647: function(n, e, t) {
        t.r(e);
        var i = t(1648);
        e.default = i.default;
    },
    1648: function(n, e, t) {
        t.r(e), function(n) {
            e.default = {
                props: {
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    hidePage: {
                        type: Boolean,
                        default: function() {
                            return !1;
                        }
                    }
                },
                name: "banner",
                data: function() {
                    return {
                        activeindex: 0
                    };
                },
                methods: {
                    bannerChange: function(n) {
                        this.activeindex = n.detail.current, this.exposure(this.list[this.activeindex], this.activeindex + 1);
                    },
                    handleJump: function(e) {
                        if (2 === e.resourceType) {
                            var t = e.actionUrl;
                            console.log("33333====>", t), this.identifyExposureTrack("identify_block_content_click_1044_4", {
                                position: this.activeindex + 1,
                                block_content_url: e.actionUrl
                            }), n.navigateTo({
                                url: "/packageSecond/pages/web/activityWeb?loadUrl=".concat(encodeURIComponent(t))
                            });
                        }
                    },
                    exposure: function(n, e) {
                        this.identifyExposureTrack("identify_block_content_exposure_1044_4", {
                            identify_block_content_info_list: [ {
                                position: e,
                                block_content_url: n.actionUrl
                            } ]
                        });
                    }
                }
            };
        }.call(this, t(1).default);
    },
    1649: function(n, e, t) {
        t.r(e);
        var i = t(1650), o = t.n(i);
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(c);
        e.default = o.a;
    },
    1650: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/identify/components/banner/index-create-component", {
    "pages/identify/components/banner/index-create-component": function(n, e, t) {
        t("1").createComponent(t(1644));
    }
}, [ [ "pages/identify/components/banner/index-create-component" ] ] ]);