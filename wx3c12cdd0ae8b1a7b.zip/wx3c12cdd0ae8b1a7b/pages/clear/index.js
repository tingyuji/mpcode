(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/clear/index" ], {
    178: function(e, t, n) {
        n.r(t), function(e) {
            n(7), n(8), n(2), e(n(179).default);
        }.call(this, n(1).createPage);
    },
    179: function(e, t, n) {
        n.r(t);
        var r = n(180), a = n(182), c = n(94), o = Object(c.default)(a.default, r.render, r.staticRenderFns, !1, null, "e1a41088", null);
        o.options.__file = "src/pages/clear/index.vue", t.default = o.exports;
    },
    180: function(e, t, n) {
        n.r(t);
        var r = n(181);
        n.d(t, "render", function() {
            return r.render;
        }), n.d(t, "staticRenderFns", function() {
            return r.staticRenderFns;
        });
    },
    181: function(e, t, n) {
        n.r(t), n.d(t, "render", function() {
            return r;
        }), n.d(t, "staticRenderFns", function() {
            return a;
        });
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
        r._withStripped = !0;
    },
    182: function(e, t, n) {
        n.r(t);
        var r = n(183);
        t.default = r.default;
    },
    183: function(e, t, n) {
        n.r(t), function(e) {
            var r = n(120), a = n(121);
            t.default = {
                onLoad: function() {
                    e.showLoading({
                        title: "加载中"
                    }), e.redirectTo({
                        url: "/clear/pages/home/home?source=tab"
                    });
                },
                onTabItemTap: function(e) {
                    var t = a.default.trade_block_content_click_734_350({
                        title: e.text.trim(),
                        pos: Number(e.index) + 1
                    });
                    Object(r.oneTrack)(t.eventName, t.data);
                }
            };
        }.call(this, n(1).default);
    }
}, [ [ 178, "common/runtime", "common/vendor" ] ] ]);