(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/protocol/protocol" ], {
    154: function(t, e, r) {
        r.r(e), function(t) {
            r(7), r(8), r(2), t(r(155).default);
        }.call(this, r(1).createPage);
    },
    155: function(t, e, r) {
        r.r(e);
        var n = r(156), o = r(158), c = (r(160), r(94)), i = Object(c.default)(o.default, n.render, n.staticRenderFns, !1, null, null, null);
        i.options.__file = "src/pages/protocol/protocol.vue", e.default = i.exports;
    },
    156: function(t, e, r) {
        r.r(e);
        var n = r(157);
        r.d(e, "render", function() {
            return n.render;
        }), r.d(e, "staticRenderFns", function() {
            return n.staticRenderFns;
        });
    },
    157: function(t, e, r) {
        r.r(e), r.d(e, "render", function() {
            return n;
        }), r.d(e, "staticRenderFns", function() {
            return o;
        });
        var n = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
        n._withStripped = !0;
    },
    158: function(t, e, r) {
        r.r(e);
        var n = r(159);
        e.default = n.default;
    },
    159: function(t, e, r) {
        r.r(e), function(t) {
            var n = r(19), o = r(45), c = r(97);
            function i(t, e) {
                var r = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), r.push.apply(r, n);
                }
                return r;
            }
            function u(t, e, r) {
                return e in t ? Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = r, t;
            }
            e.default = {
                data: function() {
                    return {
                        redirectRoute: "/pages/index/index"
                    };
                },
                computed: function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? i(Object(r), !0).forEach(function(e) {
                            u(t, e, r[e]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : i(Object(r)).forEach(function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
                        });
                    }
                    return t;
                }({}, Object(n.mapState)([ "SERVICE_ENV" ])),
                methods: {
                    agreeWith: function() {
                        Object(o.setPrivacyAgreement)(!0), Object(c.sdkWithPrivacyAgreement)(), t.reLaunch({
                            url: this.redirectRoute
                        });
                    },
                    doNotAgree: function() {
                        Object(o.setPrivacyAgreement)(!1), "pro" === this.SERVICE_ENV ? Object(o.navigationToWeb)("https://m.dewu.com/h5-preview/") : Object(o.navigationToWeb)("https://t1-m.dewu.net/h5-preview/");
                    },
                    getUrlFromRoute: function(t) {
                        t.path && ("ProductDetail" === t.path ? this.redirectRoute = this.transformUrl(t, "product/ProductDetail") : this.redirectRoute = this.transformUrl(t));
                    },
                    transformUrl: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", r = Object.keys(t).filter(function(t) {
                            return "path" !== t;
                        }).reduce(function(e, r) {
                            return "".concat(e, "&").concat(r, "=").concat(t[r]);
                        }, "/".concat(e || t.path, "?"));
                        return r;
                    }
                },
                onLoad: function(t) {
                    this.getUrlFromRoute(t), Object(o.getPrivacyAgreement)() && this.agreeWith();
                }
            };
        }.call(this, r(1).default);
    },
    160: function(t, e, r) {
        r.r(e);
        var n = r(161), o = r.n(n);
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            r.d(e, t, function() {
                return n[t];
            });
        }(c);
        e.default = o.a;
    },
    161: function(t, e, r) {}
}, [ [ 154, "common/runtime", "common/vendor" ] ] ]);