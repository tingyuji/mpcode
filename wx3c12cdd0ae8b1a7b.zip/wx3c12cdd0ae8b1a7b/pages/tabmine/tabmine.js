(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/tabmine/tabmine" ], {
    126: function(t, e, n) {
        n.r(e), function(t) {
            n(7), n(8), n(2), t(n(127).default);
        }.call(this, n(1).createPage);
    },
    127: function(t, e, n) {
        n.r(e);
        var o = n(128), r = n(130), a = (n(136), n(94)), c = Object(a.default)(r.default, o.render, o.staticRenderFns, !1, null, "0cd40e6d", null);
        c.options.__file = "src/pages/tabmine/tabmine.vue", e.default = c.exports;
    },
    128: function(t, e, n) {
        n.r(e);
        var o = n(129);
        n.d(e, "render", function() {
            return o.render;
        }), n.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    129: function(t, e, n) {
        n.r(e), n.d(e, "render", function() {
            return o;
        }), n.d(e, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    130: function(t, e, n) {
        n.r(e);
        var o = n(131);
        e.default = o.default;
    },
    131: function(t, e, n) {
        n.r(e), function(t) {
            var o, r, a = n(4), c = n.n(a), i = n(88), u = n.n(i), s = n(15), l = n(19), d = (n(105), 
            n(107)), f = n(54), h = n(106), g = n(132), v = n(120), p = n(121), m = n(134), b = n(16), _ = n(122), y = n(45), S = n(135);
            function E(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t;
                }(t) || function(t, e) {
                    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (null != n) {
                        var o, r, a = [], c = !0, i = !1;
                        try {
                            for (n = n.call(t); !(c = (o = n.next()).done) && (a.push(o.value), !e || a.length !== e); c = !0) ;
                        } catch (t) {
                            i = !0, r = t;
                        } finally {
                            try {
                                c || null == n.return || n.return();
                            } finally {
                                if (i) throw r;
                            }
                        }
                        return a;
                    }
                }(t, e) || function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return O(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? O(t, e) : void 0;
                    }
                }(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function O(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o;
            }
            function T(t, e, n, o, r, a, c) {
                try {
                    var i = t[a](c), u = i.value;
                } catch (t) {
                    return void n(t);
                }
                i.done ? e(u) : Promise.resolve(u).then(o, r);
            }
            function w(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(o, r) {
                        var a = t.apply(e, n);
                        function c(t) {
                            T(a, o, r, c, i, "next", t);
                        }
                        function i(t) {
                            T(a, o, r, c, i, "throw", t);
                        }
                        c(void 0);
                    });
                };
            }
            function k(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function I(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            e.default = {
                name: "Tabmine",
                components: {
                    MineOrder: function() {
                        return n.e("components/mineOrder/index").then(n.bind(null, 1608));
                    }
                },
                data: function() {
                    return {
                        data: {
                            userInfo: {
                                icon: ""
                            },
                            total: {
                                couponNum: ""
                            },
                            subCount: 0,
                            favoriteProductCount: 0,
                            assets: {
                                cashBalance: 0
                            },
                            myOrder: {
                                unpaid: {
                                    count: 0
                                },
                                unShipped: {
                                    count: 0
                                },
                                toBeReceived: {
                                    count: 0
                                }
                            }
                        },
                        notice: {
                            buyerNum: "",
                            officialNum: ""
                        },
                        customerServiceCenterUrl: "",
                        isLogin: !1,
                        ENV_Array: Array.from(f.BASE_ENV_LIST.keys()),
                        ENV_MAP_KEYS: f.BASE_ENV_LIST.keys(),
                        userId: "",
                        showCollectButton: !1,
                        showSubButton: !1,
                        runCGB: !1
                    };
                },
                computed: function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? k(Object(n), !0).forEach(function(e) {
                            I(t, e, n[e]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : k(Object(n)).forEach(function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                        });
                    }
                    return t;
                }({}, Object(l.mapState)([ "IS_PRODUCTION", "SERVICE_ENV", "isShowClear", "loginToken", "platform" ])),
                onLoad: function() {
                    _.cgbTrackConfig.third_dw_mall_01("我的"), this.getData();
                },
                onUnload: function() {},
                onShow: function() {
                    var e = this;
                    console.log("onShow 进来了"), this.getData(), this.getABData();
                    var n = p.default.trade_common_pageview_1314({
                        url: Object(p.getCurrentPageUrl)()
                    });
                    Object(v.oneTrack)(n.eventName, n.data), this.$nextTick(function() {
                        t.createIntersectionObserver(e, {
                            observeAll: !0
                        }).relativeToViewport().observe(".track-button", function(t) {
                            t.intersectionRatio > 0 && setTimeout(function() {
                                var n = t.dataset.type, o = {
                                    collect: "我的收藏",
                                    sub: "我的订阅",
                                    follow: "关注服务号"
                                }[n], r = "follow" === n ? "" : e.data.favoriteProductCount, a = m.default.trade_common_exposure_1314_2405({
                                    block_content_id: r,
                                    block_content_title: o
                                });
                                Object(v.oneTrack)(a.eventName, a.data);
                            }, 500);
                        });
                    });
                },
                onTabItemTap: function(t) {
                    var e = p.default.trade_block_content_click_734_350({
                        title: t.text,
                        pos: Number(t.index) + 1
                    });
                    Object(v.oneTrack)(e.eventName, e.data);
                },
                methods: {
                    checkEnv: function() {},
                    getABData: function() {
                        var e = this, n = t.getStorageSync("userInfo").userId || "", o = "490_wx_collection";
                        Object(b.postRequest)("/api/v1/h5/abtestsdk/upgrade/h5", {
                            userId: n,
                            currentGroupParm: o,
                            noToast: !0
                        }, {
                            stone: !0,
                            json: !0
                        }).then(function(t) {
                            console.log("490_wx_collection", t), t && t.data && "2" === t.data[o] ? e.showCollectButton = !0 : e.showCollectButton = !1;
                        }).catch(function(t) {
                            e.showCollectButton = !1, console.log(t);
                        });
                    },
                    getData: function() {
                        var e = this;
                        this.loginToken || this.isLogin ? this.duserver.postRequest("/api/v1/h5/index/fire/user-info", {}, {
                            stone: !0,
                            json: !0
                        }).then(function(n) {
                            if (n) if (200 === n.status) {
                                e.isLogin = !0;
                                var o = n.data.userInfo || {};
                                n.data.features.forEach(function(t) {
                                    7 === t.id && (e.customerServiceCenterUrl = t.jumpUrl);
                                }), e.data = n.data, e.notice = n.tradeNotice || {}, e.userId = o.userId, e.RiskSDK && e.RiskSDK.bindUser("wx", e.userId), 
                                Object(h.bindBehaviorTracking)(), Object(g.default)();
                            } else t.showToast({
                                icon: "none",
                                title: n.msg
                            });
                        }) : console.log("登陆之后才调userInfo");
                    },
                    pushMyCollect: function() {
                        if (this.isLogin) {
                            var e = m.default.trade_common_click_1314_2405({
                                block_content_id: this.data.favoriteProductCount,
                                block_content_title: "我的收藏"
                            });
                            Object(v.oneTrack)(e.eventName, e.data), t.navigateTo({
                                url: "/product/myCollect/myCollect"
                            });
                        } else Object(s.login)(!0);
                    },
                    pushMySub: function() {
                        if (this.isLogin) {
                            var e = m.default.trade_common_click_1314_2405({
                                block_content_id: this.data.subCount,
                                block_content_title: "我的订阅"
                            });
                            Object(v.oneTrack)(e.eventName, e.data), t.navigateTo({
                                url: "/product/mySubscription/mySubscription"
                            });
                        } else Object(s.login)(!0);
                    },
                    pushMessageVC: function() {
                        this.isLogin ? t.navigateTo({
                            url: "/notice/NoticeListPage"
                        }) : Object(s.login)(!0);
                    },
                    cleanOrderHistory: function() {
                        t.navigateTo({
                            url: "/clear/pages/orderHistory/orderHistory"
                        });
                    },
                    pushMyAddress: function() {
                        this.isLogin ? t.navigateTo({
                            url: "/account/ShippingAddressPage"
                        }) : Object(s.login)(!0);
                    },
                    pushMyCoupon: function() {
                        this.isLogin ? t.navigateTo({
                            url: "/account/MyCouponPage"
                        }) : Object(s.login)(!0);
                    },
                    pushCustomerService: function() {
                        if (Object(d.isCGB)()) t.makePhoneCall({
                            phoneNumber: "4008919888"
                        }); else {
                            var e, n = t.getStorageSync("X-Auth-Token") || u.a.get("xAuthToken"), o = this.data.userInfo, r = o.userId, a = o.icon, c = /https:\/\/(.+)/.exec(this.customerServiceCenterUrl)[1];
                            e = "pre" === this.SERVICE_ENV ? c.replace("poizon.com", "dewu.com") : c.replace("poizon.com", "dewu.net");
                            var i = "".concat("pro" === this.SERVICE_ENV ? "".concat(this.customerServiceCenterUrl.replace("m.poizon.com", "m.dewu.com"), "&im=") : "https://".concat(this.SERVICE_ENV, "-").concat(e, "&im=")), s = new Date().getTime(), l = "".concat(i) + encodeURIComponent("ts=".concat(s, "?channel=10002&sourceId=10006&fromPage=tabmine&fromTitle=客服中心&userId=").concat(r, "&avatar=").concat(a, "&token=").concat(n));
                            console.log("webUrl", l), Object(y.navigationToWeb)(l);
                        }
                    },
                    pushAccount: function(e) {
                        if (this.isLogin) {
                            var n = this.data.assets.cashBalance ? this.data.assets.cashBalance : 0;
                            t.navigateTo({
                                url: "/account/MyCashPage?cashBalance=" + n
                            });
                        } else Object(s.login)(!0);
                    },
                    goPrivacyProtocol: function() {
                        Object(y.navigationToWeb)("https://m.dewu.com/hybird/h5other/private-policy");
                    },
                    pushMyOrder: function() {
                        this.isLogin ? t.navigateTo({
                            url: "/order/buyer/orderList"
                        }) : Object(s.login)(!0);
                    },
                    goLogin: function() {
                        var t = this;
                        this.isLogin || Object(s.login)(!0).then(function() {
                            t.getData();
                        });
                    },
                    logout: (r = w(c.a.mark(function e() {
                        var n;
                        return c.a.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.showModal({
                                    title: "提示",
                                    content: "确认退出登录？",
                                    cancelText: "取消",
                                    confirmText: "确定"
                                }).then(function(t) {
                                    return t[1];
                                });

                              case 2:
                                if (!(n = e.sent).confirm) {
                                    e.next = 20;
                                    break;
                                }
                                return this.$store.state.loginToken = "", this.$store.state.openId = "", this.notice = {
                                    buyerNum: "",
                                    officialNum: ""
                                }, this.data.myOrder = {
                                    unpaid: {
                                        count: 0
                                    },
                                    unShipped: {
                                        count: 0
                                    },
                                    toBeReceived: {
                                        count: 0
                                    }
                                }, e.next = 10, t.removeStorage({
                                    key: "loginToken"
                                });

                              case 10:
                                return e.next = 12, t.removeStorage({
                                    key: "X-Auth-Token"
                                });

                              case 12:
                                return e.next = 14, t.removeStorage({
                                    key: "userInfo"
                                });

                              case 14:
                                return e.next = 16, t.removeStorage({
                                    key: "MP-WEIXIN-UNION-ID"
                                });

                              case 16:
                                this.isLogin = !1, t.showToast({
                                    title: "退出登录成功",
                                    icon: "none"
                                }), e.next = 21;
                                break;

                              case 20:
                                n.cancel;

                              case 21:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    })), function() {
                        return r.apply(this, arguments);
                    }),
                    changeServiceEnv: function() {
                        var e = this.ENV_MAP_KEYS.next();
                        if (e.done) return this.ENV_MAP_KEYS = f.BASE_ENV_LIST.keys(), void this.changeServiceEnv();
                        e.value !== this.SERVICE_ENV ? (this.$store.commit("SET_SERVICE_ENV", e.value), 
                        t.showToast({
                            title: "当前环境是".concat(this.SERVICE_ENV)
                        })) : this.changeServiceEnv();
                    },
                    radioChange: function(e) {
                        var n = e.detail.value;
                        this.$store.commit("SET_SERVICE_ENV", n), t.showToast({
                            title: "当前环境是".concat(this.SERVICE_ENV)
                        });
                    },
                    getCode: (o = w(c.a.mark(function e() {
                        var n, o, r, a;
                        return c.a.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.login();

                              case 2:
                                n = e.sent, o = E(n, 2), r = o[0], a = o[1], r && t.showToast({
                                    icon: "none",
                                    title: r
                                }), a.code || t.showToast({
                                    icon: "none",
                                    title: "未获取到微信凭证"
                                }), a && a.code && t.setClipboardData({
                                    data: a.code,
                                    success: function(e) {
                                        t.showToast({
                                            title: "复制成功"
                                        });
                                    }
                                });

                              case 9:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    })), function() {
                        return o.apply(this, arguments);
                    }),
                    goAccountLayoutPage: function() {
                        var e = f.BASE_ENV_LIST.get(this.$store.state.SERVICE_ENV).PHPBASE_URL, n = "".concat(e).concat("hybird/h5baseService/accountLogoutAgree");
                        this.$store.commit("SET_WEB_URL", n), t.navigateTo({
                            url: "/packageSecond/pages/web/activityWeb?loadUrl=".concat(encodeURIComponent(n))
                        });
                    },
                    goSettingPrivacyPage: function() {
                        t.navigateTo({
                            url: "/account/PrivacySettingPage?userId=".concat(this.userId)
                        });
                    },
                    goFollowNumber: function() {
                        var t = m.default.trade_common_click_1314_2405({
                            block_content_id: "",
                            block_content_title: "关注服务号"
                        });
                        Object(v.oneTrack)(t.eventName, t.data), Object(y.navigationToWeb)(S.followServiceUrl);
                    }
                }
            };
        }.call(this, n(1).default);
    },
    136: function(t, e, n) {
        n.r(e);
        var o = n(137), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = r.a;
    },
    137: function(t, e, n) {}
}, [ [ 126, "common/runtime", "common/vendor" ] ] ]);