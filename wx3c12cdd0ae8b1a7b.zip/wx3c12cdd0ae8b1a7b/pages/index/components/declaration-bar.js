(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/components/declaration-bar" ], {
    1551: function(e, n, t) {
        t.r(n);
        var a = t(1552), o = t(1554), r = (t(1556), t(94)), c = Object(r.default)(o.default, a.render, a.staticRenderFns, !1, null, "45b79bb0", null);
        c.options.__file = "src/pages/index/components/declaration-bar.vue", n.default = c.exports;
    },
    1552: function(e, n, t) {
        t.r(n);
        var a = t(1553);
        t.d(n, "render", function() {
            return a.render;
        }), t.d(n, "staticRenderFns", function() {
            return a.staticRenderFns;
        });
    },
    1553: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return a;
        }), t.d(n, "staticRenderFns", function() {
            return o;
        });
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
        a._withStripped = !0;
    },
    1554: function(e, n, t) {
        t.r(n);
        var a = t(1555);
        n.default = a.default;
    },
    1555: function(e, n, t) {
        t.r(n), function(e) {
            n.default = {
                props: {
                    type: {
                        type: Number,
                        required: !0
                    }
                },
                methods: {
                    goDeclaration: function() {
                        this.$store.commit("SET_WEB_URL", "https://fast.dewu.com/nezha-plus/detail/600d0e219f02f854989d3757"), 
                        e.navigateTo({
                            url: "/packageSecond/pages/web/web"
                        });
                    }
                }
            };
        }.call(this, t(1).default);
    },
    1556: function(e, n, t) {
        t.r(n);
        var a = t(1557), o = t.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(r);
        n.default = o.a;
    },
    1557: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/index/components/declaration-bar-create-component", {
    "pages/index/components/declaration-bar-create-component": function(e, n, t) {
        t("1").createComponent(t(1551));
    }
}, [ [ "pages/index/components/declaration-bar-create-component" ] ] ]);