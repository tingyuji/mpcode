(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/components/promotion" ], {
    1587: function(n, o, t) {
        t.r(o);
        var e = t(1588), r = t(1590), i = (t(1592), t(94)), u = Object(i.default)(r.default, e.render, e.staticRenderFns, !1, null, "2dffa80b", null);
        u.options.__file = "src/pages/index/components/promotion.vue", o.default = u.exports;
    },
    1588: function(n, o, t) {
        t.r(o);
        var e = t(1589);
        t.d(o, "render", function() {
            return e.render;
        }), t.d(o, "staticRenderFns", function() {
            return e.staticRenderFns;
        });
    },
    1589: function(n, o, t) {
        t.r(o), t.d(o, "render", function() {
            return e;
        }), t.d(o, "staticRenderFns", function() {
            return r;
        });
        var e = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        e._withStripped = !0;
    },
    1590: function(n, o, t) {
        t.r(o);
        var e = t(1591);
        o.default = e.default;
    },
    1591: function(n, o, t) {
        t.r(o);
        var e = t(1577);
        o.default = {
            props: {
                info: {
                    type: Object,
                    default: {}
                }
            },
            methods: {
                goPromotion: function() {
                    this.info.routerCoordinate && this.info.routerCoordinate.length && (console.log("---this.info.routerCoordinate[0].routerUrl", this.info.routerCoordinate[0].routerUrl), 
                    Object(e.doPromotionJump)({
                        url: this.info.routerCoordinate[0].routerUrl
                    }, this));
                }
            }
        };
    },
    1592: function(n, o, t) {
        t.r(o);
        var e = t(1593), r = t.n(e);
        for (var i in e) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(o, n, function() {
                return e[n];
            });
        }(i);
        o.default = r.a;
    },
    1593: function(n, o, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/index/components/promotion-create-component", {
    "pages/index/components/promotion-create-component": function(n, o, t) {
        t("1").createComponent(t(1587));
    }
}, [ [ "pages/index/components/promotion-create-component" ] ] ]);