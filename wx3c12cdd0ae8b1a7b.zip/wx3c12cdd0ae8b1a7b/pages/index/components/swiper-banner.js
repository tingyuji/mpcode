require("../../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/components/swiper-banner" ], {
    1544: function(e, n, t) {
        t.r(n);
        var r = t(1545), a = t(1547), i = (t(1549), t(94)), o = Object(i.default)(a.default, r.render, r.staticRenderFns, !1, null, "3c1c5e89", null);
        o.options.__file = "src/pages/index/components/swiper-banner.vue", n.default = o.exports;
    },
    1545: function(e, n, t) {
        t.r(n);
        var r = t(1546);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        });
    },
    1546: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return r;
        }), t.d(n, "staticRenderFns", function() {
            return a;
        });
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
        r._withStripped = !0;
    },
    1547: function(e, n, t) {
        t.r(n);
        var r = t(1548);
        n.default = r.default;
    },
    1548: function(e, n, t) {
        t.r(n), function(e) {
            var r = t(550), a = t(579), i = t.n(a);
            n.default = {
                props: {
                    list: {
                        type: Array,
                        required: !0
                    },
                    options: {
                        type: Object,
                        required: !0
                    },
                    type: {
                        type: Number,
                        required: !0
                    }
                },
                data: function() {
                    return {
                        activeIndex: 0
                    };
                },
                methods: {
                    itemClick: function(n) {
                        e.reportAnalytics("trade_banner", {
                            bannerid: n.advId
                        });
                        var t = n.routerUrl;
                        if (t) if (t.includes("/product/ProductDetail")) e.navigateTo({
                            url: Object(r.parse)(t).path.replace("/router", "")
                        }); else if (t.indexOf("/games/trend-brainSpeed/home/index") > -1) e.navigateTo({
                            url: t
                        }); else {
                            if (t.includes("/web/BrowserPage")) {
                                var a = Object(r.parse)(t), o = new i.a(a.query);
                                return this.$store.commit("SET_WEB_URL", o.get("loadUrl") || ""), void e.navigateTo({
                                    url: "/packageSecond/pages/web/web"
                                });
                            }
                            this.$store.commit("SET_WEB_URL", t), e.navigateTo({
                                url: "/packageSecond/pages/web/web"
                            });
                        }
                    },
                    checkUrl: function(n) {
                        n.indexOf("/games/trend-brainSpeed/home/index") > -1 ? e.navigateTo({
                            url: n
                        }) : (this.$store.commit("SET_WEB_URL", n), e.navigateTo({
                            url: "/packageSecond/pages/web/web"
                        }));
                    },
                    change: function(e) {
                        null != e.detail.current && (this.activeIndex = e.detail.current);
                    }
                }
            };
        }.call(this, t(1).default);
    },
    1549: function(e, n, t) {
        t.r(n);
        var r = t(1550), a = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = a.a;
    },
    1550: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "pages/index/components/swiper-banner-create-component", {
    "pages/index/components/swiper-banner-create-component": function(e, n, t) {
        t("1").createComponent(t(1544));
    }
}, [ [ "pages/index/components/swiper-banner-create-component" ] ] ]);