(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    113: function(t, n, e) {
        e.r(n), function(t) {
            e(7), e(8), e(2), t(e(114).default);
        }.call(this, e(1).createPage);
    },
    114: function(t, n, e) {
        e.r(n);
        var a = e(115), i = e(117), r = (e(124), e(94)), o = Object(r.default)(i.default, a.render, a.staticRenderFns, !1, null, "1badc801", null);
        o.options.__file = "src/pages/index/index.vue", n.default = o.exports;
    },
    115: function(t, n, e) {
        e.r(n);
        var a = e(116);
        e.d(n, "render", function() {
            return a.render;
        }), e.d(n, "staticRenderFns", function() {
            return a.staticRenderFns;
        });
    },
    116: function(t, n, e) {
        e.r(n), e.d(n, "render", function() {
            return a;
        }), e.d(n, "staticRenderFns", function() {
            return i;
        });
        var a = function() {
            var t = this, n = (t.$createElement, t._self._c, t.channels.slice(0, 4));
            t._isMounted || (t.e0 = function(n) {
                t.downLoadModalShow = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, i = [];
        a._withStripped = !0;
    },
    117: function(t, n, e) {
        e.r(n);
        var a = e(118);
        n.default = a.default;
    },
    118: function(t, n, e) {
        e.r(n), function(t) {
            var a, i, r = e(4), o = e.n(r), s = e(119), u = e(19), l = e(120), c = e(121), d = e(122), p = e(107), h = e(123), f = e(15);
            function m(t, n, e, a, i, r, o) {
                try {
                    var s = t[r](o), u = s.value;
                } catch (t) {
                    return void e(t);
                }
                s.done ? n(u) : Promise.resolve(u).then(a, i);
            }
            function g(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(a, i) {
                        var r = t.apply(n, e);
                        function o(t) {
                            m(r, a, i, o, s, "next", t);
                        }
                        function s(t) {
                            m(r, a, i, o, s, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            function b(t, n) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    n && (a = a.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(t, n).enumerable;
                    })), e.push.apply(e, a);
                }
                return e;
            }
            function v(t) {
                for (var n = 1; n < arguments.length; n++) {
                    var e = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? b(Object(e), !0).forEach(function(n) {
                        w(t, n, e[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : b(Object(e)).forEach(function(n) {
                        Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(e, n));
                    });
                }
                return t;
            }
            function w(t, n, e) {
                return n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e, t;
            }
            n.default = {
                components: {
                    Loadmore: function() {
                        return e.e("components/loadmore/index").then(e.bind(null, 1565));
                    },
                    ScrollTitle: function() {
                        return Promise.all([ e.e("common/vendor"), e.e("components/ScrollTitle/ScrollTitle") ]).then(e.bind(null, 1601));
                    },
                    SearchBar: function() {
                        return e.e("pages/index/components/search-bar").then(e.bind(null, 1537));
                    },
                    SwiperBanner: function() {
                        return Promise.all([ e.e("common/vendor"), e.e("pages/index/components/swiper-banner") ]).then(e.bind(null, 1544));
                    },
                    DeclarationBar: function() {
                        return e.e("pages/index/components/declaration-bar").then(e.bind(null, 1551));
                    },
                    HotList: function() {
                        return e.e("pages/index/components/hot-list").then(e.bind(null, 1558));
                    },
                    downLoadModal: function() {
                        return e.e("components/download-modal/index").then(e.bind(null, 1594));
                    },
                    ActivityEntery: function() {
                        return Promise.all([ e.e("common/vendor"), e.e("pages/index/components/activity-entery") ]).then(e.bind(null, 1572));
                    },
                    KingkongEntry: function() {
                        return Promise.all([ e.e("common/vendor"), e.e("pages/index/components/kingkong-entry") ]).then(e.bind(null, 1580));
                    },
                    Promotion: function() {
                        return Promise.all([ e.e("common/vendor"), e.e("pages/index/components/promotion") ]).then(e.bind(null, 1587));
                    }
                },
                data: function() {
                    return {
                        greyFilter: !1,
                        downLoadModalShow: !1,
                        selectTitleIndex: 0,
                        userInfo: {},
                        dataList: [],
                        banner: [],
                        seriesList: [],
                        bottomLoading: !1,
                        pageLoading: !1,
                        swiperBannerOptions: {
                            autoplay: !1,
                            duration: 250
                        },
                        channels: [],
                        actBanner: [],
                        params: {
                            tabId: "",
                            limit: 20,
                            lastId: ""
                        }
                    };
                },
                computed: v({}, Object(u.mapGetters)({
                    tabs: "indexTabList"
                })),
                onLoad: function(n) {
                    this.getGreyFilter(), Object(p.isCGB)() && t.setNavigationBarTitle({
                        title: "得物"
                    }), d.cgbTrackConfig.third_dw_mall_01("购买"), this.getData(!0), t.showShareMenu({
                        withShareTicket: !0,
                        menus: [ "shareAppMessage", "shareTimeline" ]
                    });
                    var e = c.default.trade_pageview_734({
                        url: Object(c.getCurrentPageUrl)()
                    });
                    Object(l.oneTrack)(e.eventName, e.data);
                },
                onShow: function() {
                    this.swiperBannerOptions.autoplay = !0, t.hideNavigationBarLoading(), t.stopPullDownRefresh(), 
                    Object(f.getInitData)();
                },
                onReachBottom: function() {
                    this.getData(!1);
                },
                onPullDownRefresh: function() {
                    this.getData(!0);
                },
                onShareAppMessage: function(t) {
                    return {
                        title: "得物App新一代潮流生活方式平台，下载app得520新人礼包！",
                        imageUrl: ""
                    };
                },
                onShareTimeline: function() {
                    return {
                        title: "得物App新一代潮流生活方式平台，下载app得520新人礼包！",
                        query: "from=pyq"
                    };
                },
                onTabItemTap: function(t) {
                    var n = c.default.trade_block_content_click_734_350({
                        title: t.text,
                        pos: Number(t.index) + 1
                    });
                    Object(l.oneTrack)(n.eventName, n.data);
                },
                methods: {
                    getGreyFilter: function() {
                        var t = this;
                        Object(h.getConfigByKey)("indexGreyFilter", {
                            open: !1
                        }).then(function(n) {
                            t.greyFilter = n.open;
                        });
                    },
                    swiperBannerClick: function(t) {
                        t.key || (this.downLoadModalShow = !0);
                    },
                    getShopping: (i = g(o.a.mark(function n(e) {
                        var a, i, r, u, l, c, d, p, h, f, m, g, b;
                        return o.a.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if (e || this.params.lastId) {
                                    n.next = 2;
                                    break;
                                }
                                return n.abrupt("return");

                              case 2:
                                if (!this.bottomLoading) {
                                    n.next = 4;
                                    break;
                                }
                                return n.abrupt("return");

                              case 4:
                                return this.startLoading(e), this.params.lastId = e ? "" : this.params.lastId, u = v({}, this.params), 
                                e && (u.limit += 1), u.platform = "h5", u.version = "4.73.0", u.isVisitor = !1, 
                                n.next = 13, s.default.getShopping(Object.assign(u, {
                                    newAdvForH5: !0
                                })).catch(function(t) {
                                    return t;
                                });

                              case 13:
                                if (l = n.sent, this.stopLoading(), !l || 200 === l.status) {
                                    n.next = 18;
                                    break;
                                }
                                return l.msg && t.showToast({
                                    title: l.msg,
                                    icon: "none"
                                }), n.abrupt("return");

                              case 18:
                                if (this.params.lastId = +(null == l || null === (a = l.data) || void 0 === a ? void 0 : a.lastId), 
                                e) {
                                    n.next = 22;
                                    break;
                                }
                                return this.dataList = this.dataList.concat(this.fixImage(null == l || null === (c = l.data) || void 0 === c ? void 0 : c.hotList)), 
                                n.abrupt("return");

                              case 22:
                                d = (null == l ? void 0 : l.data) || {}, p = d.hotList, h = void 0 === p ? [] : p, 
                                f = d.growthChannels, m = void 0 === f ? {} : f, g = d.actBanner, b = void 0 === g ? [] : g, 
                                h[0] && 1 === h[0].typeId && (h = h.slice(1)), this.banner = (null == l || null === (i = l.data) || void 0 === i ? void 0 : i.banner) || [], 
                                this.seriesList = (null == l || null === (r = l.data) || void 0 === r ? void 0 : r.seriesList) || [], 
                                this.dataList = this.fixImage(h), this.channels = m.channels || [], this.actBanner = b;

                              case 29:
                              case "end":
                                return n.stop();
                            }
                        }, n, this);
                    })), function(t) {
                        return i.apply(this, arguments);
                    }),
                    fixImage: function(t) {
                        return (t || []).forEach(function(t) {
                            if (2 === t.typeId) {
                                var n = t.boutique.images;
                                n.length > 6 && (t.boutique.images = n.slice(0, 6));
                            }
                        }), t;
                    },
                    getTabDetail: (a = g(o.a.mark(function n(e) {
                        var a, i, r, u, l;
                        return o.a.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if (e || this.params.lastId) {
                                    n.next = 2;
                                    break;
                                }
                                return n.abrupt("return");

                              case 2:
                                if (!this.bottomLoading) {
                                    n.next = 4;
                                    break;
                                }
                                return n.abrupt("return");

                              case 4:
                                return this.startLoading(e), this.params.lastId = e ? "" : this.params.lastId, n.next = 8, 
                                s.default.getTabDetail(v({}, this.params)).catch(function(t) {
                                    return t;
                                });

                              case 8:
                                if (r = n.sent, this.stopLoading(), !r || 200 === r.status) {
                                    n.next = 13;
                                    break;
                                }
                                return r.msg && t.showToast({
                                    title: r.msg,
                                    icon: "none"
                                }), n.abrupt("return");

                              case 13:
                                if (this.params.lastId = +(null == r || null === (a = r.data) || void 0 === a ? void 0 : a.lastId), 
                                (u = null == r || null === (i = r.data) || void 0 === i ? void 0 : i.list) && u.length) {
                                    n.next = 18;
                                    break;
                                }
                                return this.params.lastId = "", n.abrupt("return");

                              case 18:
                                if (e) {
                                    n.next = 21;
                                    break;
                                }
                                return this.dataList = this.dataList.concat(null == r || null === (l = r.data) || void 0 === l ? void 0 : l.list), 
                                n.abrupt("return");

                              case 21:
                                this.dataList = u;

                              case 22:
                              case "end":
                                return n.stop();
                            }
                        }, n, this);
                    })), function(t) {
                        return a.apply(this, arguments);
                    }),
                    handleTabClick: function(t) {
                        var n = t.item, e = t.index;
                        this.selectTitleIndex !== e && (this.selectTitleIndex = e, this.params.tabId = n.id, 
                        this.getData(!0));
                    },
                    getData: function(t) {
                        0 === this.selectTitleIndex ? this.getShopping(t) : this.getTabDetail(t);
                    },
                    startLoading: function(n) {
                        n || (this.bottomLoading = !0), t.showNavigationBarLoading();
                    },
                    stopLoading: function() {
                        t.hideNavigationBarLoading(), t.stopPullDownRefresh(), this.bottomLoading = !1;
                    }
                }
            };
        }.call(this, e(1).default);
    },
    124: function(t, n, e) {
        e.r(n);
        var a = e(125), i = e.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        n.default = i.a;
    },
    125: function(t, n, e) {}
}, [ [ 113, "common/runtime", "common/vendor" ] ] ]);