(global.webpackJsonp = global.webpackJsonp || []).push([ [ "shell/recommendSkeleton" ], {
    2063: function(e, n, t) {
        t.r(n);
        var o = t(2064), r = t(2066), l = (t(2068), t(94)), c = Object(l.default)(r.default, o.render, o.staticRenderFns, !1, null, "6b9d5441", null);
        c.options.__file = "src/shell/recommendSkeleton.vue", n.default = c.exports;
    },
    2064: function(e, n, t) {
        t.r(n);
        var o = t(2065);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        });
    },
    2065: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        });
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
        o._withStripped = !0;
    },
    2066: function(e, n, t) {
        t.r(n);
        var o = t(2067);
        n.default = o.default;
    },
    2067: function(e, n, t) {
        t.r(n), n.default = {
            name: "Skeleton",
            props: {
                isShow: {
                    type: Boolean,
                    default: !1
                }
            }
        };
    },
    2068: function(e, n, t) {
        t.r(n);
        var o = t(2069), r = t.n(o);
        for (var l in o) [ "default" ].indexOf(l) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(l);
        n.default = r.a;
    },
    2069: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "shell/recommendSkeleton-create-component", {
    "shell/recommendSkeleton-create-component": function(e, n, t) {
        t("1").createComponent(t(2063));
    }
}, [ [ "shell/recommendSkeleton-create-component" ] ] ]);