(global.webpackJsonp = global.webpackJsonp || []).push([ [ "shell/brandDetailHeadSkeleton" ], {
    2105: function(e, n, t) {
        t.r(n);
        var r = t(2106), a = t(2108), l = (t(2110), t(94)), o = Object(l.default)(a.default, r.render, r.staticRenderFns, !1, null, "14f9de3d", null);
        o.options.__file = "src/shell/brandDetailHeadSkeleton.vue", n.default = o.exports;
    },
    2106: function(e, n, t) {
        t.r(n);
        var r = t(2107);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        });
    },
    2107: function(e, n, t) {
        t.r(n), t.d(n, "render", function() {
            return r;
        }), t.d(n, "staticRenderFns", function() {
            return a;
        });
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
        r._withStripped = !0;
    },
    2108: function(e, n, t) {
        t.r(n);
        var r = t(2109);
        n.default = r.default;
    },
    2109: function(e, n, t) {
        t.r(n), n.default = {};
    },
    2110: function(e, n, t) {
        t.r(n);
        var r = t(2111), a = t.n(r);
        for (var l in r) [ "default" ].indexOf(l) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(l);
        n.default = a.a;
    },
    2111: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "shell/brandDetailHeadSkeleton-create-component", {
    "shell/brandDetailHeadSkeleton-create-component": function(e, n, t) {
        t("1").createComponent(t(2105));
    }
}, [ [ "shell/brandDetailHeadSkeleton-create-component" ] ] ]);