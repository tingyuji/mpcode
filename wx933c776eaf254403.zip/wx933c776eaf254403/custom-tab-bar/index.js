Page({
    data: {
        list: [ {
            pagePath: "/pages/order/component",
            text: "订单",
            iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
            selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
        }, {
            pagePath: "/pages/serProviders/component",
            text: "服务商",
            iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
            selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
        }, {
            pagePath: "/pages/financial/component",
            text: "财务",
            iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
            selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
        }, {
            pagePath: "/pages/my/component",
            text: "我的",
            iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
            selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
        } ],
        selected: 0
    },
    upswitch: function(a) {
        var t = a.currentTarget.dataset.path;
        wx.reLaunch({
            url: t
        });
    },
    onLoad: function(a) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});