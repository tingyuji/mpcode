var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../miniprogram_npm/@vant/weapp/toast/toast"));

require("../../request/api.js");

Component({
    properties: {},
    data: {
        sms: "",
        oldPassword: "",
        newPassword: "",
        modile: "",
        codeText: "发送验证码",
        status: !1,
        sended: !1,
        errorMassage: ""
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            console.info("页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        submit: function() {
            this.data.newPassword === this.data.oldPassword ? wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/password/update",
                method: "Post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    mobile: this.data.modile,
                    password: this.data.newPassword,
                    sms_code: this.data.sms
                },
                success: function(t) {
                    (0, e.default)("修改成功，即将跳转登录页面"), console.log(t), "success" == t.data && wx.navigateTo({
                        url: "/pages/login/component"
                    });
                }
            }) : (0, e.default)("两次密码不一致");
        },
        requirePassword: function(e) {
            console.log(e), this.data.newPassword !== e.detail ? this.setData({
                errorMassage: "两次密码不一致"
            }) : this.setData({
                errorMassage: ""
            });
        },
        telcode: function() {
            var t = this;
            if (this.data.sended) return !1;
            this.setData({
                sended: !0
            }), wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/find-pwd/smsCode/" + this.data.modile,
                method: "get",
                success: function(a) {
                    5 == a.data ? ((0, e.default)("验证码已发送"), t.setitem()) : (t.setData({
                        sended: !1
                    }), (0, e.default)(a.data.message));
                },
                fail: function(a) {
                    a.data.message ? (0, e.default)(a.data.message) : (0, e.default)(a.message), t.setData({
                        sended: !1
                    });
                }
            });
        },
        setitem: function() {
            var e = this, t = 60, a = setInterval(function() {
                t--, e.setData({
                    codeText: t + "秒后重新发送",
                    status: !0
                }), 0 == t && (e.setData({
                    codeText: "获取动态密码",
                    status: !1,
                    sended: !1
                }), t = 60, clearInterval(a));
            }, 1e3);
        },
        onChange: function(e) {
            switch (e.currentTarget.dataset.type) {
              case "sms":
                this.setData({
                    sms: e.detail
                });
                break;

              case "oldPassword":
                this.setData({
                    oldPassword: e.detail
                });
                break;

              case "newPassword":
                this.setData({
                    newPassword: e.detail
                });
                break;

              case "modile":
                this.setData({
                    modile: e.detail
                });
                break;

              default:
                console.log("未查到");
            }
        }
    }
});