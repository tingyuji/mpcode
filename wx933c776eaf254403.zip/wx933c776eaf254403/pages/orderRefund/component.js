Page({
    data: {
        id: 0,
        imgList: [],
        shopInfo: {}
    },
    onLoad: function(t) {
        var e = this;
        console.log(t), this.setData({
            id: t.id
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(t) {
                console.log(t);
                var o = t.data.imgUrl.map(function(t) {
                    return t.attachment_path;
                });
                t.data.orderInfo.time = e.timeFormatter(t.data.orderInfo.created_time), e.setData({
                    imgList: o,
                    shopInfo: t.data.orderInfo
                });
            }
        });
    },
    timeFormatter: function(t) {
        if (!t) return t;
        var e = t.substr(0, 10) + " " + t.substring(11, 13) + ":" + t.substring(14, 16) + ":" + t.substring(17, 19);
        return e = e.replace(/-/g, "/"), e = new Date(e), e = (e = new Date(e.getTime() + 288e5)).getFullYear() + "-" + (e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-" + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate()) + " " + (e.getHours() < 10 ? "0" + e.getHours() : e.getHours()) + ":" + (e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":" + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
    },
    upshow: function() {
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(t) {
                console.log(t);
            }
        });
    },
    fmemberDetail: function(t) {
        if ("供应商" == this.data.identity) {
            var e = t.currentTarget.dataset.id.facilitator_id;
            wx.navigateTo({
                url: "/pages/serproDetail/component?id=" + e
            });
        } else {
            var o = t.currentTarget.dataset.id.supplier_id;
            wx.navigateTo({
                url: "/pagesB/gys_detail/component?id=" + o
            });
        }
    },
    onClick: function(t) {
        var e = this, o = t.currentTarget.dataset.type;
        "Confirm" == o ? wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + this.data.id,
            method: "get",
            data: {
                state: "Confirm"
            },
            success: function(t) {
                console.log(t), e.upshow();
            }
        }) : "Wrong" == o && wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + this.data.id,
            method: "get",
            data: {
                state: "Wrong"
            },
            success: function(t) {
                console.log(t), e.upshow();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});