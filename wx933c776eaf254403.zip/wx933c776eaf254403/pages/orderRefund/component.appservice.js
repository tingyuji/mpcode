$gwx_XC_93=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_93 || [];
function gz$gwx_XC_93_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_93_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_93_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_93_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'=='],[[6],[[7],[3,'imgList']],[3,'length']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_93_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_93_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_93=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_93=true;
var x=['./pages/orderRefund/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_93_1()
var fWY=_v()
_(r,fWY)
if(_oz(z,0,e,s,gg)){fWY.wxVkey=1
}
fWY.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_93";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_93();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/orderRefund/component.wxml'] = [$gwx_XC_93, './pages/orderRefund/component.wxml'];else __wxAppCode__['pages/orderRefund/component.wxml'] = $gwx_XC_93( './pages/orderRefund/component.wxml' );
	;__wxRoute = "pages/orderRefund/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/orderRefund/component.js";define("pages/orderRefund/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{id:0,imgList:[],shopInfo:{}},onLoad:function(t){var e=this;console.log(t),this.setData({id:t.id}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/"+this.data.id,method:"get",success:function(t){console.log(t);var o=t.data.imgUrl.map((function(t){return t.attachment_path}));t.data.orderInfo.time=e.timeFormatter(t.data.orderInfo.created_time),e.setData({imgList:o,shopInfo:t.data.orderInfo})}})},timeFormatter:function(t){if(!t)return t;var e=t.substr(0,10)+" "+t.substring(11,13)+":"+t.substring(14,16)+":"+t.substring(17,19);return e=e.replace(/-/g,"/"),e=new Date(e),e=(e=new Date(e.getTime()+288e5)).getFullYear()+"-"+(e.getMonth()+1<10?"0"+(e.getMonth()+1):e.getMonth()+1)+"-"+(e.getDate()<10?"0"+e.getDate():e.getDate())+" "+(e.getHours()<10?"0"+e.getHours():e.getHours())+":"+(e.getMinutes()<10?"0"+e.getMinutes():e.getMinutes())+":"+(e.getSeconds()<10?"0"+e.getSeconds():e.getSeconds())},upshow:function(){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/"+this.data.id,method:"get",success:function(t){console.log(t)}})},fmemberDetail:function(t){if("供应商"==this.data.identity){var e=t.currentTarget.dataset.id.facilitator_id;wx.navigateTo({url:"/pages/serproDetail/component?id="+e})}else{var o=t.currentTarget.dataset.id.supplier_id;wx.navigateTo({url:"/pagesB/gys_detail/component?id="+o})}},onClick:function(t){var e=this,o=t.currentTarget.dataset.type;"Confirm"==o?wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/"+this.data.id,method:"get",data:{state:"Confirm"},success:function(t){console.log(t),e.upshow()}}):"Wrong"==o&&wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/"+this.data.id,method:"get",data:{state:"Wrong"},success:function(t){console.log(t),e.upshow()}})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/orderRefund/component.js'});require("pages/orderRefund/component.js");