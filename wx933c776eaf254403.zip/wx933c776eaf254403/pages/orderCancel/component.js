Page({
    data: {
        id: 0,
        imgList: [],
        shopInfo: {}
    },
    onLoad: function(t) {
        var e = this;
        console.log(t), this.setData({
            id: t.id
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(t) {
                var a = [];
                a.push(t.data.imgUrl.attachment_path), t.data.orderInfo.time = e.timeFormatter(t.data.orderInfo.created_time), 
                e.setData({
                    imgList: a,
                    shopInfo: t.data.orderInfo
                });
            }
        });
    },
    timeFormatter: function(t) {
        if (!t) return t;
        var e = t.substr(0, 10) + " " + t.substring(11, 13) + ":" + t.substring(14, 16) + ":" + t.substring(17, 19);
        return e = e.replace(/-/g, "/"), e = new Date(e), e = (e = new Date(e.getTime() + 288e5)).getFullYear() + "-" + (e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-" + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate()) + " " + (e.getHours() < 10 ? "0" + e.getHours() : e.getHours()) + ":" + (e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":" + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
    },
    upshow: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(e) {
                var a = [];
                a.push(e.data.imgUrl.attachment_path), e.data.orderInfo.time = t.timeFormatter(e.data.orderInfo.created_time), 
                t.setData({
                    imgList: a,
                    shopInfo: e.data.orderInfo
                });
            }
        });
    },
    onClick: function(t) {
        var e = this, a = t.currentTarget.dataset.type;
        "Nocancel" == a ? wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + this.data.id,
            method: "get",
            data: {
                state: "NoCancel"
            },
            success: function(t) {
                wx.showToast({
                    title: "操作成功"
                }), e.upshow();
            }
        }) : "cancel" == a && wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + this.data.id,
            method: "get",
            data: {
                state: "Cancel"
            },
            success: function(t) {
                wx.showToast({
                    title: "操作成功"
                }), e.upshow();
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});