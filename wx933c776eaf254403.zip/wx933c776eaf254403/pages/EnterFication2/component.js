var a = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/toConsumableArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), s = a(require("../../miniprogram_npm/@vant/weapp/toast/toast"));

Page({
    onLoad: function(a) {},
    onShow: function() {
        wx.getStorageSync("enterprise") && this.setData({
            formDate: wx.getStorageSync("enterprise"),
            tax_registration_cert_number: wx.getStorageSync("enterprise").organization_cert_number,
            short_name: wx.getStorageSync("enterprise").business_license_company_name
        });
    },
    data: {
        bankno_name: "",
        show: !1,
        codeText: "发送验证码",
        status: !1,
        searchList: [],
        formDate: {},
        contact_id_card_name: "",
        legal_person_id_card_copy: "",
        legal_person_id_card_national: "",
        legal_person_id_card_name: "",
        legal_person_id_card_number: "",
        legal_person_id_card_valid_time: "",
        settle_acct_name: "",
        settle_acct_bank_code: "",
        settle_acct_bank_acct_no: "",
        organization_type: "1",
        settle_acct_type: "2",
        password: "",
        okpassword: "",
        images: "",
        imagesName: "",
        images1: "",
        images2: "",
        images3: "",
        imagesName1: "",
        short_name: "",
        tax_registration_cert_number: "",
        contact_id_card_number: "",
        contact_id_card_valid_time: "",
        contact_mobile_number: "",
        contact_email: "",
        setflag: !1,
        errorMaeeage: "",
        abc: "",
        sms_code: "",
        mobile_number: "",
        submitStatus: !1,
        columns: [],
        bankshow: !1,
        bankPageno: 1,
        bankNo: "",
        tipText: "",
        tipShow: !1,
        page_no: 1,
        bank_noText: "",
        bank_noShow: !1
    },
    setpassword: function() {
        this.setData({
            setflag: !0
        });
    },
    onClose: function() {
        this.setData({
            setflag: !1
        });
    },
    submit: function() {
        "" == this.data.errorMaeeage && 6 == this.data.password.length && 6 == this.data.okpassword.length ? (this.sub(), 
        this.setData({
            setflag: !1
        })) : wx.showToast({
            icon: "error",
            title: "请设置正确的交易密码"
        });
    },
    reultvalue: function(a) {
        if (this.data.password && 6 == this.data.password.length && this.data.okpassword && 6 == this.data.okpassword.length) if (this.data.password != this.data.okpassword) this.setData({
            errorMaeeage: "两次密码不一致"
        }); else {
            if (!/^[0-9]{6,6}$/.test(a.detail)) return this.setData({
                errorMaeeage: "密码必须为6为数字"
            }), !1;
            this.setData({
                errorMaeeage: ""
            });
        }
    },
    setshopInfo: function() {
        var a = wx.getStorageSync("uid");
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/api/shop/" + a,
            method: "get",
            success: function(t) {
                (t.data = "success") ? wx.request({
                    url: "https://api.seller.hhtt168.com/seller/applet/api/getShopdetail/" + a,
                    method: "get",
                    success: function(a) {
                        console.log(a), "success" == a.data ? wx.navigateTo({
                            url: "/pages/creEnd/component"
                        }) : wx.showModal({
                            content: "提交失败"
                        });
                    },
                    fail: function(a) {
                        wx.showModal({
                            content: "提交失败"
                        });
                    }
                }) : wx.showModal({
                    content: "提交失败"
                });
            },
            fail: function(a) {
                wx.showModal({
                    content: "提交失败"
                });
            }
        });
    },
    changeUp: function() {
        var a = this, t = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                if (console.log(e), e.tempFiles[0].size > 2097152) return wx.showToast({
                    title: "图片超过2M",
                    icon: "error"
                }), !1;
                var s = e.tempFiles[0].tempFilePath, o = s.length - 12, n = s.length, i = s.slice(o, n), c = e.tempFiles[0].tempFilePath;
                a.setData({
                    images: c,
                    imagesName: i
                }), wx.showToast({
                    title: "上传中",
                    icon: "loading",
                    duration: 4e3
                }), wx.uploadFile({
                    name: "file",
                    filePath: c,
                    url: "https://api.base.hhtt168.com/uploaders",
                    method: "POST",
                    formData: {
                        file: c,
                        scene: "CUS"
                    },
                    success: function(e) {
                        var s = JSON.parse(e.data).url;
                        a.upCont(s, "up"), wx.request({
                            url: "https://api.seller.hhtt168.com/seller/shops/ocr/getFTCAIDCardOCR",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                            },
                            method: "POST",
                            data: {
                                positiveImg: s
                            },
                            success: function(a) {
                                var e = JSON.parse(a.data.front);
                                t.setData({
                                    legal_person_id_card_name: e.Name,
                                    legal_person_id_card_number: e.IdNum
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    changeUp2: function() {
        var a = this, t = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                if (console.log(e), e.tempFiles[0].size > 2097152) return wx.showToast({
                    title: "图片超过2M",
                    icon: "error"
                }), !1;
                var s = e.tempFiles[0].tempFilePath, o = s.length - 12, n = s.length, i = s.slice(o, n), c = e.tempFiles[0].tempFilePath;
                a.setData({
                    images2: c,
                    imagesName: i
                }), wx.showToast({
                    title: "上传中",
                    icon: "loading",
                    duration: 4e3
                }), wx.uploadFile({
                    name: "file",
                    filePath: c,
                    url: "https://api.base.hhtt168.com/uploaders",
                    method: "POST",
                    formData: {
                        file: c,
                        scene: "CUS"
                    },
                    success: function(e) {
                        var s = JSON.parse(e.data).url;
                        a.upCont2(s, "up"), wx.request({
                            url: "https://api.seller.hhtt168.com/seller/shops/ocr/getFTCAIDCardOCR",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                            },
                            method: "POST",
                            data: {
                                positiveImg: s
                            },
                            success: function(a) {
                                var e = JSON.parse(a.data.front);
                                t.setData({
                                    contact_id_card_name: e.Name,
                                    contact_id_card_number: e.IdNum
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    changBottom: function() {
        var a = this, t = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                if (console.log(e), e.tempFiles[0].size > 2097152) return wx.showToast({
                    title: "图片超过2M",
                    icon: "error"
                }), !1;
                var s = e.tempFiles[0].tempFilePath, o = s.length - 12, n = s.length, i = s.slice(o, n), c = e.tempFiles[0].tempFilePath;
                a.setData({
                    images1: c,
                    imagesName1: i
                }), wx.showToast({
                    title: "上传中",
                    icon: "loading",
                    duration: 4e3
                }), wx.uploadFile({
                    name: "file",
                    filePath: c,
                    url: "https://api.base.hhtt168.com/uploaders",
                    method: "POST",
                    formData: {
                        file: c,
                        scene: "CUS"
                    },
                    success: function(e) {
                        var s = JSON.parse(e.data).url;
                        a.upCont(s, "bottom"), wx.request({
                            url: "https://api.seller.hhtt168.com/seller/shops/ocr/getBTCAIDCardOCR",
                            method: "POST",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                            },
                            data: {
                                backImg: s
                            },
                            success: function(a) {
                                var e = JSON.parse(a.data.back);
                                t.setData({
                                    legal_person_id_card_valid_time: e.ValidDate
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    changBottom2: function() {
        var a = this, t = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                if (console.log(e), e.tempFiles[0].size > 2097152) return wx.showToast({
                    title: "图片超过2M",
                    icon: "error"
                }), !1;
                var s = e.tempFiles[0].tempFilePath, o = s.length - 12, n = s.length, i = s.slice(o, n), c = e.tempFiles[0].tempFilePath;
                a.setData({
                    images3: c,
                    imagesName1: i
                }), wx.showToast({
                    title: "上传中",
                    icon: "loading",
                    duration: 4e3
                }), wx.uploadFile({
                    name: "file",
                    filePath: c,
                    url: "https://api.base.hhtt168.com/uploaders",
                    method: "POST",
                    formData: {
                        file: c,
                        scene: "CUS"
                    },
                    success: function(e) {
                        var s = JSON.parse(e.data).url;
                        a.upCont2(s, "bottom"), wx.request({
                            url: "https://api.seller.hhtt168.com/seller/shops/ocr/getBTCAIDCardOCR",
                            method: "POST",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                            },
                            data: {
                                backImg: s
                            },
                            success: function(a) {
                                var e = JSON.parse(a.data.back);
                                t.setData({
                                    contact_id_card_valid_time: e.ValidDate
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    conversionAddress: function(a, t, e) {
        var s = this;
        "" !== a ? wx.getFileSystemManager().readFile({
            filePath: a,
            encoding: "base64",
            success: function(o) {
                var n = "data:image/png;base64," + o.data;
                s.upCont(n, t, e, a);
            }
        }) : wx.showToast({
            title: "请先选择图片！"
        });
    },
    upCont: function(a, t) {
        var e = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssUploadImages",
                timestamp: Date.parse(new Date())
            },
            data: {
                file_name: "2345.jpg",
                file: a
            },
            success: function(a) {
                console.log(a), "" != a.data ? "up" == t ? e.setData({
                    legal_person_id_card_copy: a.data
                }) : e.setData({
                    legal_person_id_card_national: a.data
                }) : wx.showModal({
                    title: "提示",
                    content: "上传失败！"
                });
            }
        });
    },
    upCont2: function(a, t) {
        var e = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssUploadImages",
                timestamp: Date.parse(new Date())
            },
            data: {
                file_name: "2345.jpg",
                file: a
            },
            success: function(a) {
                console.log(a), "" != a.data ? "up" == t ? e.setData({
                    contact_id_card_copy: a.data
                }) : e.setData({
                    contact_id_card_national: a.data
                }) : wx.showModal({
                    title: "提示",
                    content: "上传失败！"
                });
            }
        });
    },
    sub: function() {
        var a = this, t = this.data.formDate;
        this.setData({
            submitStatus: !0
        }), delete t.organization_cert_number, delete t.organization_cert_valid_time;
        var s = e(e({}, t), {}, {
            legal_person_id_card_copy: this.data.legal_person_id_card_copy,
            legal_person_id_card_national: this.data.legal_person_id_card_national,
            legal_person_id_card_name: this.data.legal_person_id_card_name,
            legal_person_id_card_number: this.data.legal_person_id_card_number,
            legal_person_id_card_valid_time: this.data.legal_person_id_card_valid_time.split("-").join(",").split(".").join("-"),
            contact_id_card_name: this.data.contact_id_card_name,
            settle_acct_name: this.data.settle_acct_name,
            settle_acct_bank_code: this.data.settle_acct_bank_code,
            settle_acct_bank_branch_code: this.data.settle_acct_bank_branch_code,
            settle_acct_bank_acct_no: this.data.settle_acct_bank_acct_no,
            password: this.data.password,
            organization_type: this.data.organization_type,
            settle_acct_type: "1" == this.data.organization_type ? "2" : this.data.settle_acct_type,
            short_name: this.data.short_name,
            legal_person_id_card_type: "1",
            contact_id_card_type: "1",
            contact_id_card_copy: this.data.contact_id_card_copy,
            contact_id_card_national: this.data.contact_id_card_national,
            contact_id_card_number: this.data.contact_id_card_number,
            contact_id_card_valid_time: this.data.contact_id_card_valid_time.split("-").join(",").split(".").join("-"),
            contact_mobile_number: this.data.contact_mobile_number,
            contact_email: "".concat(this.data.contact_mobile_number, "@163.com"),
            shop_id: wx.getStorageSync("userShopid")
        });
        2 == this.data.organization_type ? (s.legal_person_mobile_number = this.data.mobile_number, 
        s.sms_code = this.data.sms_code, s.id_card_copy = this.data.legal_person_id_card_copy, 
        s.id_card_national = this.data.legal_person_id_card_national, s.id_card_number = this.data.legal_person_id_card_number, 
        s.id_card_valid_time = this.data.legal_person_id_card_valid_time.split("-").join(",").split(".").join("-"), 
        s.id_card_name = this.data.legal_person_id_card_name, wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchInfoAdd",
            method: "POST",
            data: s,
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssMchApplications",
                timestamp: Date.parse(new Date())
            },
            success: function(t) {
                console.log(t), t.data.outRequestNo ? (a.setData({
                    submitStatus: !1
                }), wx.showToast({
                    title: "成功"
                }), wx.reLaunch({
                    url: "/pages/creEnd/component"
                })) : (wx.showModal({
                    content: t.data
                }), a.setData({
                    submitStatus: !1
                }));
            }
        })) : wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchInfoAdd",
            method: "POST",
            data: s,
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssMchApplications",
                timestamp: Date.parse(new Date())
            },
            success: function(t) {
                console.log(t), t.data.outRequestNo ? (wx.showToast({
                    title: "成功"
                }), a.setData({
                    submitStatus: !1
                }), wx.reLaunch({
                    url: "/pages/creEnd/component"
                })) : (t.data.message ? wx.showModal({
                    content: t.data.message
                }) : wx.showModal({
                    content: t.data
                }), a.setData({
                    submitStatus: !1
                }));
            }
        });
    },
    upClone: function() {
        this.setData({
            show: !1
        });
    },
    upbanklist: function() {
        var a = this, e = this.data.page_no + 1, s = {
            page_no: e,
            page_size: 20,
            bank_name: this.data.company_name,
            bank_no: this.data.bankNo
        };
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: s,
            success: function(s) {
                console.log(s), s.data.data.length > 0 ? a.setData({
                    searchList: [].concat(t(a.data.searchList), t(s.data.data)),
                    tipText: "查看更多",
                    tipShow: !0,
                    page_no: e
                }) : a.setData({
                    tipText: "暂无更多选项",
                    tipShow: !0
                });
            }
        });
    },
    cancel: function() {
        this.setData({
            show: !1
        });
    },
    chosebank: function() {
        var a = this;
        if ("" == this.data.bankNo) (0, s.default)("请先选择开户行简称"); else {
            this.setData({
                show: !0
            });
            var t = {
                page_no: this.data.page_no,
                page_size: 20,
                bank_name: "",
                bank_no: this.data.bankNo
            };
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",
                method: "POST",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                },
                data: t,
                success: function(t) {
                    console.log(t), t.data.data.length > 0 ? a.setData({
                        searchList: t.data.data || [],
                        tipText: "查看更多",
                        tipShow: !0
                    }) : a.setData({
                        searchList: [],
                        tipText: "暂无信息",
                        tipShow: !0
                    });
                }
            });
        }
    },
    onSearch: function(a) {
        var t = this, e = {}, s = this.data.company_name;
        a.detail.x ? (console.log(2), e = {
            page_no: this.data.page_no,
            page_size: 20,
            bank_name: s,
            bank_no: this.data.bankNo
        }) : (console.log(1), e = {
            page_no: this.data.page_no,
            page_size: 20,
            bank_name: a.detail,
            bank_no: this.data.bankNo
        }), console.log(e, this.data.company_name, a), wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: e,
            success: function(a) {
                console.log(a), a.data.data.length > 0 ? t.setData({
                    searchList: a.data.data || [],
                    tipText: "查看更多",
                    tipShow: !0
                }) : t.setData({
                    searchList: [],
                    tipText: "暂无信息",
                    tipShow: !0
                });
            }
        });
    },
    onSearchbankno: function() {
        var a = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: {
                bank_no: this.data.bankno_name,
                page_no: this.data.bankPageno,
                page_size: 20
            },
            success: function(t) {
                console.log(t), a.setData({
                    columns: t.data.data
                });
            }
        });
    },
    uplist: function() {
        var a = this, e = this.data.bankPageno + 1;
        console.log(1), wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: {
                bank_no: this.data.bankno_name,
                page_no: e,
                page_size: 15
            },
            success: function(s) {
                console.log(s), 0 == s.data.data.length ? a.setData({
                    bank_noText: "没有更多了"
                }) : a.setData({
                    columns: [].concat(t(a.data.columns), t(s.data.data)),
                    bankPageno: e,
                    bankLoading: !1
                });
            }
        });
    },
    setItem: function(a) {
        var t = a.currentTarget.dataset.item;
        this.setData({
            show: !1,
            abc: t.bank_name,
            settle_acct_bank_code: t.bank_code,
            settle_acct_bank_branch_code: t.drec_code
        });
    },
    telcode: function() {
        var a = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getPhoneCode",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            method: "POST",
            data: {
                mobile_number: this.data.mobile_number
            },
            success: function(t) {
                console.log(t), 2 == t.data ? (wx.showToast({
                    title: "验证码已发送"
                }), a.setJb()) : t.data.message ? (0, s.default)(t.data.message) : wx.showToast({
                    title: t.data
                });
            }
        });
    },
    bankClose: function() {
        this.setData({
            bankshow: !1,
            bank_noShow: !1
        });
    },
    banknolist: function() {},
    onConfirm: function(a) {
        var t = a.currentTarget.dataset.item;
        this.setData({
            bankNo: t.bank_no,
            bankshow: !1
        });
    },
    columnsChange: function() {
        var a = this, e = this.data.bankPageno + 1;
        this.setData({
            bankLoading: !0
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: {
                bank_no: "",
                page_no: e,
                page_size: 15
            },
            success: function(s) {
                console.log(s), 0 == s.data.data.length ? a.setData({
                    bank_noText: "没有更多了"
                }) : a.setData({
                    columns: [].concat(t(a.data.columns), t(s.data.data)),
                    bankPageno: e,
                    bankLoading: !1
                });
            }
        });
    },
    showBank: function() {
        this.getbankList(), this.setData({
            bankshow: !0,
            bank_noShow: !0,
            bank_noText: "查看更多"
        });
    },
    getbankList: function() {
        var a = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: {
                bank_no: "",
                page_no: this.data.bankPageno,
                page_size: 15
            },
            success: function(t) {
                console.log(t), a.setData({
                    columns: t.data.data
                });
            }
        });
    },
    setJb: function() {
        var a = this, t = 60, e = setInterval(function() {
            t--, a.setData({
                codeText: t + "秒后重新发送",
                status: !0
            }), 0 == t && (a.setData({
                codeText: "获取验证码",
                status: !1
            }), t = 60, clearInterval(e));
        }, 1e3);
    }
});