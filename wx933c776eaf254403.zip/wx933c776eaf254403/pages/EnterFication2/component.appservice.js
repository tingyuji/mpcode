$gwx_XC_74=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_74 || [];
function gz$gwx_XC_74_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'wrapper'])
Z([3,'group_5'])
Z([3,'changeUp'])
Z([3,'block_1'])
Z([[2,'=='],[[7],[3,'images']],[1,'']])
Z([[2,'!='],[[7],[3,'images']],[1,'']])
Z([3,'changBottom'])
Z([3,'block_2'])
Z([[2,'=='],[[7],[3,'images1']],[1,'']])
Z([[2,'!='],[[7],[3,'images1']],[1,'']])
Z([3,'horizontal'])
Z([[7],[3,'organization_type']])
Z([3,'2'])
Z([3,'1'])
Z([[2,'=='],[[7],[3,'organization_type']],[1,2]])
Z(z[11])
Z([[7],[3,'settle_acct_type']])
Z(z[14])
Z(z[13])
Z([3,'法人姓名'])
Z([[7],[3,'legal_person_id_card_name']])
Z([3,'姓名'])
Z([3,'身份证号'])
Z([[7],[3,'legal_person_id_card_number']])
Z(z[23])
Z([3,'有效日期'])
Z([[7],[3,'legal_person_id_card_valid_time']])
Z(z[26])
Z([3,'开户名'])
Z([[7],[3,'settle_acct_name']])
Z(z[29])
Z([3,'showBank'])
Z([3,'开户行简称'])
Z([[7],[3,'bankNo']])
Z(z[33])
Z([3,'chosebank'])
Z([3,'支行名称'])
Z([[7],[3,'abc']])
Z(z[37])
Z([3,'银行账号'])
Z([[7],[3,'settle_acct_bank_acct_no']])
Z(z[40])
Z([[2,'=='],[[7],[3,'settle_acct_type']],[1,1]])
Z([3,'银行绑定手机号'])
Z([[7],[3,'mobile_number']])
Z(z[44])
Z([3,'260rpx'])
Z(z[43])
Z([1,false])
Z([3,'短信验证码'])
Z([[7],[3,'sms_code']])
Z([3,'请输入短信验证码'])
Z([3,'telcode'])
Z([[7],[3,'status']])
Z([3,'small'])
Z([3,'button'])
Z([3,'primary'])
Z(z[2])
Z([3,'changeUp2'])
Z(z[4])
Z([[2,'=='],[[7],[3,'images2']],[1,'']])
Z([[2,'!='],[[7],[3,'images2']],[1,'']])
Z([3,'changBottom2'])
Z(z[8])
Z([[2,'=='],[[7],[3,'images3']],[1,'']])
Z([[2,'!='],[[7],[3,'images3']],[1,'']])
Z([3,'联系人姓名'])
Z([[7],[3,'contact_id_card_name']])
Z(z[22])
Z([3,'身份证'])
Z([[7],[3,'contact_id_card_number']])
Z([3,'联系人身份证号'])
Z([3,'证件有效期'])
Z([[7],[3,'contact_id_card_valid_time']])
Z([3,'联系人证件有效期'])
Z([3,'联系人手机号'])
Z([[7],[3,'contact_mobile_number']])
Z(z[76])
Z([3,'onClose'])
Z([3,'submit'])
Z([3,'#2f86f6'])
Z([[7],[3,'setflag']])
Z([3,'设置6位数字密码'])
Z([3,'reultvalue'])
Z([3,'交易密码'])
Z([[7],[3,'password']])
Z(z[85])
Z([3,'password'])
Z(z[84])
Z([[7],[3,'errorMaeeage']])
Z([3,'确认密码'])
Z([[7],[3,'okpassword']])
Z(z[91])
Z(z[88])
Z([3,'z-index: 999999'])
Z([3,'left'])
Z([[7],[3,'bankshow']])
Z([3,'onSearchbankno'])
Z([[7],[3,'bankno_name']])
Z([3,'请输入银行关键词'])
Z([3,'round'])
Z([3,'bankClose'])
Z(z[55])
Z([3,'info'])
Z(z[95])
Z(z[96])
Z([[7],[3,'show']])
Z([3,'pop_wrapper'])
Z([3,'onSearch'])
Z([[7],[3,'company_name']])
Z(z[100])
Z(z[101])
Z([3,'upClone'])
Z(z[55])
Z(z[104])
Z([3,'van-toast'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_74=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_74=true;
var x=['./pages/EnterFication2/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_74_1()
var aHS=_n('view')
_rz(z,aHS,'class',0,e,s,gg)
var tIS=_n('view')
_rz(z,tIS,'class',1,e,s,gg)
var xMS=_n('view')
_rz(z,xMS,'class',2,e,s,gg)
var oNS=_mz(z,'view',['bindtap',3,'class',1],[],e,s,gg)
var fOS=_v()
_(oNS,fOS)
if(_oz(z,5,e,s,gg)){fOS.wxVkey=1
}
var cPS=_v()
_(oNS,cPS)
if(_oz(z,6,e,s,gg)){cPS.wxVkey=1
}
fOS.wxXCkey=1
cPS.wxXCkey=1
_(xMS,oNS)
var hQS=_mz(z,'view',['bindtap',7,'class',1],[],e,s,gg)
var oRS=_v()
_(hQS,oRS)
if(_oz(z,9,e,s,gg)){oRS.wxVkey=1
}
var cSS=_v()
_(hQS,cSS)
if(_oz(z,10,e,s,gg)){cSS.wxVkey=1
}
oRS.wxXCkey=1
cSS.wxXCkey=1
_(xMS,hQS)
_(tIS,xMS)
var oTS=_mz(z,'van-radio-group',['direction',11,'value',1],[],e,s,gg)
oTS.rawAttr={"model:value":"{{organization_type}}",};var lUS=_n('van-radio')
_rz(z,lUS,'name',13,e,s,gg)
_(oTS,lUS)
var aVS=_n('van-radio')
_rz(z,aVS,'name',14,e,s,gg)
_(oTS,aVS)
_(tIS,oTS)
var eJS=_v()
_(tIS,eJS)
if(_oz(z,15,e,s,gg)){eJS.wxVkey=1
var tWS=_mz(z,'van-radio-group',['direction',16,'value',1],[],e,s,gg)
tWS.rawAttr={"model:value":"{{settle_acct_type}}",};var eXS=_n('van-radio')
_rz(z,eXS,'name',18,e,s,gg)
_(tWS,eXS)
var bYS=_n('van-radio')
_rz(z,bYS,'name',19,e,s,gg)
_(tWS,bYS)
_(eJS,tWS)
}
var oZS=_mz(z,'van-field',['label',20,'value',1,'placeholder',2],[],e,s,gg)
oZS.rawAttr={"model:value":"{{ legal_person_id_card_name }}",};_(tIS,oZS)
var x1S=_mz(z,'van-field',['label',23,'value',1,'placeholder',2],[],e,s,gg)
x1S.rawAttr={"model:value":"{{ legal_person_id_card_number }}",};_(tIS,x1S)
var o2S=_mz(z,'van-field',['label',26,'value',1,'placeholder',2],[],e,s,gg)
o2S.rawAttr={"model:value":"{{ legal_person_id_card_valid_time }}",};_(tIS,o2S)
var f3S=_mz(z,'van-field',['label',29,'value',1,'placeholder',2],[],e,s,gg)
f3S.rawAttr={"model:value":"{{ settle_acct_name }}",};_(tIS,f3S)
var c4S=_mz(z,'van-field',['readonly',-1,'bindtap',32,'label',1,'value',2,'placeholder',3],[],e,s,gg)
c4S.rawAttr={"model:value":"{{ bankNo }}",};_(tIS,c4S)
var h5S=_mz(z,'van-field',['readonly',-1,'bindtap',36,'label',1,'value',2,'placeholder',3],[],e,s,gg)
h5S.rawAttr={"model:value":"{{ abc }}",};_(tIS,h5S)
var o6S=_mz(z,'van-field',['label',40,'value',1,'placeholder',2],[],e,s,gg)
o6S.rawAttr={"model:value":"{{ settle_acct_bank_acct_no }}",};_(tIS,o6S)
var bKS=_v()
_(tIS,bKS)
if(_oz(z,43,e,s,gg)){bKS.wxVkey=1
var c7S=_mz(z,'van-field',['label',44,'value',1,'placeholder',2,'titleWidth',3],[],e,s,gg)
c7S.rawAttr={"model:value":"{{ mobile_number }}",};_(bKS,c7S)
}
var oLS=_v()
_(tIS,oLS)
if(_oz(z,48,e,s,gg)){oLS.wxVkey=1
var o8S=_mz(z,'van-field',['center',-1,'clearable',-1,'useButtonSlot',-1,'border',49,'label',1,'value',2,'placeholder',3],[],e,s,gg)
o8S.rawAttr={"model:value":"{{ sms_code }}",};var l9S=_mz(z,'van-button',['bind:click',53,'disabled',1,'size',2,'slot',3,'type',4],[],e,s,gg)
_(o8S,l9S)
_(oLS,o8S)
}
var a0S=_n('view')
_rz(z,a0S,'class',58,e,s,gg)
var tAT=_mz(z,'view',['bindtap',59,'class',1],[],e,s,gg)
var eBT=_v()
_(tAT,eBT)
if(_oz(z,61,e,s,gg)){eBT.wxVkey=1
}
var bCT=_v()
_(tAT,bCT)
if(_oz(z,62,e,s,gg)){bCT.wxVkey=1
}
eBT.wxXCkey=1
bCT.wxXCkey=1
_(a0S,tAT)
var oDT=_mz(z,'view',['bindtap',63,'class',1],[],e,s,gg)
var xET=_v()
_(oDT,xET)
if(_oz(z,65,e,s,gg)){xET.wxVkey=1
}
var oFT=_v()
_(oDT,oFT)
if(_oz(z,66,e,s,gg)){oFT.wxVkey=1
}
xET.wxXCkey=1
oFT.wxXCkey=1
_(a0S,oDT)
_(tIS,a0S)
var fGT=_mz(z,'van-field',['label',67,'value',1,'placeholder',2],[],e,s,gg)
fGT.rawAttr={"model:value":"{{ contact_id_card_name }}",};_(tIS,fGT)
var cHT=_mz(z,'van-field',['label',70,'value',1,'placeholder',2],[],e,s,gg)
cHT.rawAttr={"model:value":"{{ contact_id_card_number }}",};_(tIS,cHT)
var hIT=_mz(z,'van-field',['label',73,'value',1,'placeholder',2],[],e,s,gg)
hIT.rawAttr={"model:value":"{{ contact_id_card_valid_time }}",};_(tIS,hIT)
var oJT=_mz(z,'van-field',['label',76,'value',1,'placeholder',2],[],e,s,gg)
oJT.rawAttr={"model:value":"{{ contact_mobile_number }}",};_(tIS,oJT)
eJS.wxXCkey=1
eJS.wxXCkey=3
bKS.wxXCkey=1
bKS.wxXCkey=3
oLS.wxXCkey=1
oLS.wxXCkey=3
_(aHS,tIS)
var cKT=_mz(z,'van-dialog',['showCancelButton',-1,'useSlot',-1,'bind:close',79,'bind:confirm',1,'confirmButtonColor',2,'show',3,'title',4],[],e,s,gg)
var oLT=_mz(z,'van-field',['bind:change',84,'label',1,'value',2,'placeholder',3,'type',4],[],e,s,gg)
oLT.rawAttr={"model:value":"{{ password }}",};_(cKT,oLT)
var lMT=_mz(z,'van-field',['bind:change',89,'errorMessage',1,'label',2,'value',3,'placeholder',4,'type',5],[],e,s,gg)
lMT.rawAttr={"model:value":"{{ okpassword }}",};_(cKT,lMT)
_(aHS,cKT)
_(r,aHS)
var aNT=_mz(z,'van-popup',['customStyle',95,'position',1,'show',2],[],e,s,gg)
var tOT=_mz(z,'van-search',['showAction',-1,'useActionSlot',-1,'bind:search',98,'value',1,'placeholder',2,'shape',3],[],e,s,gg)
tOT.rawAttr={"model:value":"{{ bankno_name }}",};_(aNT,tOT)
var ePT=_mz(z,'van-button',['bindtap',102,'size',1,'type',2],[],e,s,gg)
_(aNT,ePT)
_(r,aNT)
var bQT=_mz(z,'van-popup',['customStyle',105,'position',1,'show',2],[],e,s,gg)
var oRT=_n('view')
_rz(z,oRT,'class',108,e,s,gg)
var xST=_mz(z,'van-search',['showAction',-1,'useActionSlot',-1,'bind:search',109,'value',1,'placeholder',2,'shape',3],[],e,s,gg)
xST.rawAttr={"model:value":"{{ company_name }}",};_(oRT,xST)
var oTT=_mz(z,'van-button',['bindtap',113,'size',1,'type',2],[],e,s,gg)
_(oRT,oTT)
_(bQT,oRT)
_(r,bQT)
var fUT=_n('van-toast')
_rz(z,fUT,'id',116,e,s,gg)
_(r,fUT)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_74";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_74();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/EnterFication2/component.wxml'] = [$gwx_XC_74, './pages/EnterFication2/component.wxml'];else __wxAppCode__['pages/EnterFication2/component.wxml'] = $gwx_XC_74( './pages/EnterFication2/component.wxml' );
	;__wxRoute = "pages/EnterFication2/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/EnterFication2/component.js";define("pages/EnterFication2/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../@babel/runtime/helpers/interopRequireDefault").default,t=require("../../@babel/runtime/helpers/toConsumableArray"),e=require("../../@babel/runtime/helpers/objectSpread2"),s=a(require("../../miniprogram_npm/@vant/weapp/toast/toast"));Page({onLoad:function(a){},onShow:function(){wx.getStorageSync("enterprise")&&this.setData({formDate:wx.getStorageSync("enterprise"),tax_registration_cert_number:wx.getStorageSync("enterprise").organization_cert_number,short_name:wx.getStorageSync("enterprise").business_license_company_name})},data:{bankno_name:"",show:!1,codeText:"发送验证码",status:!1,searchList:[],formDate:{},contact_id_card_name:"",legal_person_id_card_copy:"",legal_person_id_card_national:"",legal_person_id_card_name:"",legal_person_id_card_number:"",legal_person_id_card_valid_time:"",settle_acct_name:"",settle_acct_bank_code:"",settle_acct_bank_acct_no:"",organization_type:"1",settle_acct_type:"2",password:"",okpassword:"",images:"",imagesName:"",images1:"",images2:"",images3:"",imagesName1:"",short_name:"",tax_registration_cert_number:"",contact_id_card_number:"",contact_id_card_valid_time:"",contact_mobile_number:"",contact_email:"",setflag:!1,errorMaeeage:"",abc:"",sms_code:"",mobile_number:"",submitStatus:!1,columns:[],bankshow:!1,bankPageno:1,bankNo:"",tipText:"",tipShow:!1,page_no:1,bank_noText:"",bank_noShow:!1},setpassword:function(){this.setData({setflag:!0})},onClose:function(){this.setData({setflag:!1})},submit:function(){""==this.data.errorMaeeage&&6==this.data.password.length&&6==this.data.okpassword.length?(this.sub(),this.setData({setflag:!1})):wx.showToast({icon:"error",title:"请设置正确的交易密码"})},reultvalue:function(a){if(this.data.password&&6==this.data.password.length&&this.data.okpassword&&6==this.data.okpassword.length)if(this.data.password!=this.data.okpassword)this.setData({errorMaeeage:"两次密码不一致"});else{if(!/^[0-9]{6,6}$/.test(a.detail))return this.setData({errorMaeeage:"密码必须为6为数字"}),!1;this.setData({errorMaeeage:""})}},setshopInfo:function(){var a=wx.getStorageSync("uid");wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/shop/"+a,method:"get",success:function(t){(t.data="success")?wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getShopdetail/"+a,method:"get",success:function(a){console.log(a),"success"==a.data?wx.navigateTo({url:"/pages/creEnd/component"}):wx.showModal({content:"提交失败"})},fail:function(a){wx.showModal({content:"提交失败"})}}):wx.showModal({content:"提交失败"})},fail:function(a){wx.showModal({content:"提交失败"})}})},changeUp:function(){var a=this,t=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["original","compressed"],sourceType:["album","camera"],success:function(e){if(console.log(e),e.tempFiles[0].size>2097152)return wx.showToast({title:"图片超过2M",icon:"error"}),!1;var s=e.tempFiles[0].tempFilePath,o=s.length-12,n=s.length,i=s.slice(o,n),c=e.tempFiles[0].tempFilePath;a.setData({images:c,imagesName:i}),wx.showToast({title:"上传中",icon:"loading",duration:4e3}),wx.uploadFile({name:"file",filePath:c,url:"https://api.base.hhtt168.com/uploaders",method:"POST",formData:{file:c,scene:"CUS"},success:function(e){var s=JSON.parse(e.data).url;a.upCont(s,"up"),wx.request({url:"https://api.seller.hhtt168.com/seller/shops/ocr/getFTCAIDCardOCR",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"POST",data:{positiveImg:s},success:function(a){var e=JSON.parse(a.data.front);t.setData({legal_person_id_card_name:e.Name,legal_person_id_card_number:e.IdNum})}})}})}})},changeUp2:function(){var a=this,t=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["original","compressed"],sourceType:["album","camera"],success:function(e){if(console.log(e),e.tempFiles[0].size>2097152)return wx.showToast({title:"图片超过2M",icon:"error"}),!1;var s=e.tempFiles[0].tempFilePath,o=s.length-12,n=s.length,i=s.slice(o,n),c=e.tempFiles[0].tempFilePath;a.setData({images2:c,imagesName:i}),wx.showToast({title:"上传中",icon:"loading",duration:4e3}),wx.uploadFile({name:"file",filePath:c,url:"https://api.base.hhtt168.com/uploaders",method:"POST",formData:{file:c,scene:"CUS"},success:function(e){var s=JSON.parse(e.data).url;a.upCont2(s,"up"),wx.request({url:"https://api.seller.hhtt168.com/seller/shops/ocr/getFTCAIDCardOCR",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"POST",data:{positiveImg:s},success:function(a){var e=JSON.parse(a.data.front);t.setData({contact_id_card_name:e.Name,contact_id_card_number:e.IdNum})}})}})}})},changBottom:function(){var a=this,t=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["original","compressed"],sourceType:["album","camera"],success:function(e){if(console.log(e),e.tempFiles[0].size>2097152)return wx.showToast({title:"图片超过2M",icon:"error"}),!1;var s=e.tempFiles[0].tempFilePath,o=s.length-12,n=s.length,i=s.slice(o,n),c=e.tempFiles[0].tempFilePath;a.setData({images1:c,imagesName1:i}),wx.showToast({title:"上传中",icon:"loading",duration:4e3}),wx.uploadFile({name:"file",filePath:c,url:"https://api.base.hhtt168.com/uploaders",method:"POST",formData:{file:c,scene:"CUS"},success:function(e){var s=JSON.parse(e.data).url;a.upCont(s,"bottom"),wx.request({url:"https://api.seller.hhtt168.com/seller/shops/ocr/getBTCAIDCardOCR",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{backImg:s},success:function(a){var e=JSON.parse(a.data.back);t.setData({legal_person_id_card_valid_time:e.ValidDate})}})}})}})},changBottom2:function(){var a=this,t=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["original","compressed"],sourceType:["album","camera"],success:function(e){if(console.log(e),e.tempFiles[0].size>2097152)return wx.showToast({title:"图片超过2M",icon:"error"}),!1;var s=e.tempFiles[0].tempFilePath,o=s.length-12,n=s.length,i=s.slice(o,n),c=e.tempFiles[0].tempFilePath;a.setData({images3:c,imagesName1:i}),wx.showToast({title:"上传中",icon:"loading",duration:4e3}),wx.uploadFile({name:"file",filePath:c,url:"https://api.base.hhtt168.com/uploaders",method:"POST",formData:{file:c,scene:"CUS"},success:function(e){var s=JSON.parse(e.data).url;a.upCont2(s,"bottom"),wx.request({url:"https://api.seller.hhtt168.com/seller/shops/ocr/getBTCAIDCardOCR",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{backImg:s},success:function(a){var e=JSON.parse(a.data.back);t.setData({contact_id_card_valid_time:e.ValidDate})}})}})}})},conversionAddress:function(a,t,e){var s=this;""!==a?wx.getFileSystemManager().readFile({filePath:a,encoding:"base64",success:function(o){var n="data:image/png;base64,"+o.data;s.upCont(n,t,e,a)}}):wx.showToast({title:"请先选择图片！"})},upCont:function(a,t){var e=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssUploadImages",timestamp:Date.parse(new Date)},data:{file_name:"2345.jpg",file:a},success:function(a){console.log(a),""!=a.data?"up"==t?e.setData({legal_person_id_card_copy:a.data}):e.setData({legal_person_id_card_national:a.data}):wx.showModal({title:"提示",content:"上传失败！"})}})},upCont2:function(a,t){var e=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssUploadImages",timestamp:Date.parse(new Date)},data:{file_name:"2345.jpg",file:a},success:function(a){console.log(a),""!=a.data?"up"==t?e.setData({contact_id_card_copy:a.data}):e.setData({contact_id_card_national:a.data}):wx.showModal({title:"提示",content:"上传失败！"})}})},sub:function(){var a=this,t=this.data.formDate;this.setData({submitStatus:!0}),delete t.organization_cert_number,delete t.organization_cert_valid_time;var s=e(e({},t),{},{legal_person_id_card_copy:this.data.legal_person_id_card_copy,legal_person_id_card_national:this.data.legal_person_id_card_national,legal_person_id_card_name:this.data.legal_person_id_card_name,legal_person_id_card_number:this.data.legal_person_id_card_number,legal_person_id_card_valid_time:this.data.legal_person_id_card_valid_time.split("-").join(",").split(".").join("-"),contact_id_card_name:this.data.contact_id_card_name,settle_acct_name:this.data.settle_acct_name,settle_acct_bank_code:this.data.settle_acct_bank_code,settle_acct_bank_branch_code:this.data.settle_acct_bank_branch_code,settle_acct_bank_acct_no:this.data.settle_acct_bank_acct_no,password:this.data.password,organization_type:this.data.organization_type,settle_acct_type:"1"==this.data.organization_type?"2":this.data.settle_acct_type,short_name:this.data.short_name,legal_person_id_card_type:"1",contact_id_card_type:"1",contact_id_card_copy:this.data.contact_id_card_copy,contact_id_card_national:this.data.contact_id_card_national,contact_id_card_number:this.data.contact_id_card_number,contact_id_card_valid_time:this.data.contact_id_card_valid_time.split("-").join(",").split(".").join("-"),contact_mobile_number:this.data.contact_mobile_number,contact_email:"".concat(this.data.contact_mobile_number,"@163.com"),shop_id:wx.getStorageSync("userShopid")});2==this.data.organization_type?(s.legal_person_mobile_number=this.data.mobile_number,s.sms_code=this.data.sms_code,s.id_card_copy=this.data.legal_person_id_card_copy,s.id_card_national=this.data.legal_person_id_card_national,s.id_card_number=this.data.legal_person_id_card_number,s.id_card_valid_time=this.data.legal_person_id_card_valid_time.split("-").join(",").split(".").join("-"),s.id_card_name=this.data.legal_person_id_card_name,wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchInfoAdd",method:"POST",data:s,header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssMchApplications",timestamp:Date.parse(new Date)},success:function(t){console.log(t),t.data.outRequestNo?(a.setData({submitStatus:!1}),wx.showToast({title:"成功"}),wx.reLaunch({url:"/pages/creEnd/component"})):(wx.showModal({content:t.data}),a.setData({submitStatus:!1}))}})):wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchInfoAdd",method:"POST",data:s,header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssMchApplications",timestamp:Date.parse(new Date)},success:function(t){console.log(t),t.data.outRequestNo?(wx.showToast({title:"成功"}),a.setData({submitStatus:!1}),wx.reLaunch({url:"/pages/creEnd/component"})):(t.data.message?wx.showModal({content:t.data.message}):wx.showModal({content:t.data}),a.setData({submitStatus:!1}))}})},upClone:function(){this.setData({show:!1})},upbanklist:function(){var a=this,e=this.data.page_no+1,s={page_no:e,page_size:20,bank_name:this.data.company_name,bank_no:this.data.bankNo};wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:s,success:function(s){console.log(s),s.data.data.length>0?a.setData({searchList:[].concat(t(a.data.searchList),t(s.data.data)),tipText:"查看更多",tipShow:!0,page_no:e}):a.setData({tipText:"暂无更多选项",tipShow:!0})}})},cancel:function(){this.setData({show:!1})},chosebank:function(){var a=this;if(""==this.data.bankNo)(0,s.default)("请先选择开户行简称");else{this.setData({show:!0});var t={page_no:this.data.page_no,page_size:20,bank_name:"",bank_no:this.data.bankNo};wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:t,success:function(t){console.log(t),t.data.data.length>0?a.setData({searchList:t.data.data||[],tipText:"查看更多",tipShow:!0}):a.setData({searchList:[],tipText:"暂无信息",tipShow:!0})}})}},onSearch:function(a){var t=this,e={},s=this.data.company_name;a.detail.x?(console.log(2),e={page_no:this.data.page_no,page_size:20,bank_name:s,bank_no:this.data.bankNo}):(console.log(1),e={page_no:this.data.page_no,page_size:20,bank_name:a.detail,bank_no:this.data.bankNo}),console.log(e,this.data.company_name,a),wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getMchBankCode",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:e,success:function(a){console.log(a),a.data.data.length>0?t.setData({searchList:a.data.data||[],tipText:"查看更多",tipShow:!0}):t.setData({searchList:[],tipText:"暂无信息",tipShow:!0})}})},onSearchbankno:function(){var a=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{bank_no:this.data.bankno_name,page_no:this.data.bankPageno,page_size:20},success:function(t){console.log(t),a.setData({columns:t.data.data})}})},uplist:function(){var a=this,e=this.data.bankPageno+1;console.log(1),wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{bank_no:this.data.bankno_name,page_no:e,page_size:15},success:function(s){console.log(s),0==s.data.data.length?a.setData({bank_noText:"没有更多了"}):a.setData({columns:[].concat(t(a.data.columns),t(s.data.data)),bankPageno:e,bankLoading:!1})}})},setItem:function(a){var t=a.currentTarget.dataset.item;this.setData({show:!1,abc:t.bank_name,settle_acct_bank_code:t.bank_code,settle_acct_bank_branch_code:t.drec_code})},telcode:function(){var a=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getPhoneCode",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"POST",data:{mobile_number:this.data.mobile_number},success:function(t){console.log(t),2==t.data?(wx.showToast({title:"验证码已发送"}),a.setJb()):t.data.message?(0,s.default)(t.data.message):wx.showToast({title:t.data})}})},bankClose:function(){this.setData({bankshow:!1,bank_noShow:!1})},banknolist:function(){},onConfirm:function(a){var t=a.currentTarget.dataset.item;this.setData({bankNo:t.bank_no,bankshow:!1})},columnsChange:function(){var a=this,e=this.data.bankPageno+1;this.setData({bankLoading:!0}),wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{bank_no:"",page_no:e,page_size:15},success:function(s){console.log(s),0==s.data.data.length?a.setData({bank_noText:"没有更多了"}):a.setData({columns:[].concat(t(a.data.columns),t(s.data.data)),bankPageno:e,bankLoading:!1})}})},showBank:function(){this.getbankList(),this.setData({bankshow:!0,bank_noShow:!0,bank_noText:"查看更多"})},getbankList:function(){var a=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/bankNoList",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{bank_no:"",page_no:this.data.bankPageno,page_size:15},success:function(t){console.log(t),a.setData({columns:t.data.data})}})},setJb:function(){var a=this,t=60,e=setInterval((function(){t--,a.setData({codeText:t+"秒后重新发送",status:!0}),0==t&&(a.setData({codeText:"获取验证码",status:!1}),t=60,clearInterval(e))}),1e3)}});
},{isPage:true,isComponent:true,currentFile:'pages/EnterFication2/component.js'});require("pages/EnterFication2/component.js");