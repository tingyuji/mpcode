Component({
    properties: {},
    data: {
        addList: {}
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            this.getaddList(), console.info("添加供应商页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        onClick: function(t) {
            var e = wx.getStorageSync("uid"), s = t.currentTarget.dataset.status;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierAudit/" + e + "/" + this.data.addList.fmember_id,
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                },
                data: {
                    status: s
                },
                success: function(t) {
                    console.log(t), "AGREE" == s ? wx.showToast({
                        title: "已同意"
                    }) : wx.showToast({
                        title: "已拒绝"
                    }), setTimeout(function() {
                        wx.switchTab({
                            url: "/pages/my/component"
                        });
                    }, 1e3);
                }
            });
        },
        getaddList: function() {
            var t = this, e = wx.getStorageSync("uid");
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getFacilitatorList/" + e,
                method: "post",
                success: function(e) {
                    console.log(e), e.data.count > 0 && (console.log(1), t.setData({
                        addList: e.data.list[0]
                    }));
                }
            });
        }
    }
});