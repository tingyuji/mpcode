$gwx_XC_90=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_90 || [];
function gz$gwx_XC_90_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_90_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'margin-bottom: 130rpx;width: 100%; height: 1500rpx; '])
Z([[2,'=='],[[7],[3,'identity']],[1,'供应商']])
Z([3,'page'])
Z([[2,'>'],[[6],[[7],[3,'order_list']],[3,'length']],[1,0]])
Z([[2,'<='],[[6],[[7],[3,'order_list']],[3,'length']],[1,0]])
Z([[2,'=='],[[7],[3,'identity']],[1,'服务商']])
Z([3,'margin-bottom: 100rpx;'])
Z([[2,'=='],[[7],[3,'identity']],[1,'代理商']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_90_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_90=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_90=true;
var x=['./pages/order/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_90_1()
var bEY=_n('page')
_rz(z,bEY,'style',0,e,s,gg)
var oFY=_v()
_(bEY,oFY)
if(_oz(z,1,e,s,gg)){oFY.wxVkey=1
var fIY=_n('view')
_rz(z,fIY,'class',2,e,s,gg)
var cJY=_v()
_(fIY,cJY)
if(_oz(z,3,e,s,gg)){cJY.wxVkey=1
}
var hKY=_v()
_(fIY,hKY)
if(_oz(z,4,e,s,gg)){hKY.wxVkey=1
}
cJY.wxXCkey=1
hKY.wxXCkey=1
_(oFY,fIY)
}
var xGY=_v()
_(bEY,xGY)
if(_oz(z,5,e,s,gg)){xGY.wxVkey=1
var oLY=_n('fwsOrder')
_rz(z,oLY,'style',6,e,s,gg)
_(xGY,oLY)
}
var oHY=_v()
_(bEY,oHY)
if(_oz(z,7,e,s,gg)){oHY.wxVkey=1
var cMY=_n('yeji')
_(oHY,cMY)
}
oFY.wxXCkey=1
xGY.wxXCkey=1
xGY.wxXCkey=3
oHY.wxXCkey=1
oHY.wxXCkey=3
_(r,bEY)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_90";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_90();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/order/component.wxml'] = [$gwx_XC_90, './pages/order/component.wxml'];else __wxAppCode__['pages/order/component.wxml'] = $gwx_XC_90( './pages/order/component.wxml' );
	;__wxRoute = "pages/order/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/order/component.js";define("pages/order/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{order_list:[],orderCount:68,moneyCount:5e4,type:"ServiceOrder",identity:"供应商"},onLoad:function(t){},init:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){a.data=a.data.map((function(t){return t.total_cost=(t.total_cost/100).toFixed(2),t.order_vo=t.order_vo.map((function(t){return console.log(t),"OrderAdd"==t.state?t.status="待确认":"Wrong"==t.state?t.status="信息有误":"OrderUpdate"==t.state?t.status="待确认":"Confirm"==t.state?t.status="已确认":"ApplyCancel"==t.state?t.status="作废请求":"Cancel"==t.state&&(t.status="作废"),t.receivable=(t.receivable/100).toFixed(2),t.fwf=(t.total_cost*(t.service_rate/100)/100).toFixed(2),t.image_list=JSON.parse(t.image_list),t.avatar=t.image_list[0]?t.image_list[0].imageUrl:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png",console.log(t.avatar),t})),t})),a.data.forEach((function(t){})),t.setData({order_list:a.data})}}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",method:"get",data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){console.log(a);var e=parseFloat(a.data.moneyCount/100).toFixed(2);t.setData({moneyCount:e,orderCount:a.data.orderCount})}})},getOrder:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){console.log(a),a.data.forEach((function(t){t.total_cost=(t.total_cost/100).toFixed(2),t.order_vo.forEach((function(t){"OrderAdd"==t.state?t.status="待确认":"Wrong"==t.state?t.status="信息有误":"OrderUpdate"==t.state?t.status="待确认":"Confirm"==t.state?t.status="已确认":"Cancel"==t.state&&(t.status="作废"),t.receivable=(t.receivable/100).toFixed(2),t.fwf=(t.total_cost*(t.service_rate/100)/100).toFixed(2)}))})),t.setData({order_list:a.data})}}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",method:"get",data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){console.log(a);var e=parseFloat(a.data.moneyCount/100).toFixed(2);t.setData({moneyCount:e,orderCount:a.data.orderCount})}})},godetail:function(t){var a=t.currentTarget.dataset.id;t.currentTarget.dataset.state;return wx.navigateTo({url:"/pages/orderDetail/component?id="+a}),!1},changenav:function(t){console.log(t);var a=t.currentTarget.dataset.type;this.setData({type:a}),this.getOrder()},onReady:function(){wx.getStorageSync("username")||wx.reLaunch({url:"/pages/login/component"})},onShow:function(){var t=this;if("function"==typeof this.getTabBar&&this.getTabBar())if(this.getTabBar().setData({selected:0}),"服务商"==wx.getStorageSync("identity")){this.getTabBar().setData({list:[{pagePath:"/pages/order/component",text:"订单",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"供应商",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"财务",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}]})}else if("代理商"==wx.getStorageSync("identity")){var a=[];a="Salesman"==wx.getStorageSync("identityStatus")||"SalesDirector"==wx.getStorageSync("identityStatus")||"Sales"==wx.getStorageSync("identityStatus")?[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}]:[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"人员",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:a}),this.setData({identityStatus:wx.getStorageSync("identityStatus")})}var e=wx.getStorageSync("identity");console.log(e),this.setData({identity:e}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){a.data=a.data.map((function(t){return t.total_cost=(t.total_cost/100).toFixed(2),t.order_vo=t.order_vo.map((function(t){return console.log(t),"OrderAdd"==t.state?t.status="待确认":"Wrong"==t.state?t.status="信息有误":"OrderUpdate"==t.state?t.status="待确认":"Confirm"==t.state?t.status="已确认":"ApplyCancel"==t.state?t.status="作废请求":"Cancel"==t.state&&(t.status="作废"),t.receivable=(t.receivable/100).toFixed(2),t.fwf=(t.total_cost*(t.service_rate/100)/100).toFixed(2),t.image_list=JSON.parse(t.image_list),t.avatar=t.image_list[0]?t.image_list[0].imageUrl:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png",console.log(t.avatar),t})),t})),a.data.forEach((function(t){})),t.setData({order_list:a.data})}}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",method:"get",data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){console.log(a);var e=parseFloat(a.data.moneyCount/100).toFixed(2);t.setData({moneyCount:e,orderCount:a.data.orderCount})}})},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){var t=this;if(wx.showNavigationBarLoading(),"function"==typeof this.getTabBar&&this.getTabBar())if(this.getTabBar().setData({selected:0}),"服务商"==wx.getStorageSync("identity")){this.getTabBar().setData({list:[{pagePath:"/pages/order/component",text:"订单",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"供应商",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"财务",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}]})}else if("代理商"==wx.getStorageSync("identity")){var a=[];a="Salesman"==wx.getStorageSync("identityStatus")?[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}]:[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"人员",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:a}),this.setData({identityStatus:wx.getStorageSync("identityStatus")})}var e=wx.getStorageSync("identity");console.log(e),this.setData({identity:e}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){a.data=a.data.map((function(t){return t.total_cost=(t.total_cost/100).toFixed(2),t.order_vo=t.order_vo.map((function(t){return console.log(t),"OrderAdd"==t.state?t.status="待确认":"Wrong"==t.state?t.status="信息有误":"OrderUpdate"==t.state?t.status="待确认":"Confirm"==t.state?t.status="已确认":"ApplyCancel"==t.state?t.status="作废请求":"Cancel"==t.state&&(t.status="作废"),t.receivable=(t.receivable/100).toFixed(2),t.fwf=(t.total_cost*(t.service_rate/100)/100).toFixed(2),t.image_list=JSON.parse(t.image_list),t.avatar=t.image_list[0]?t.image_list[0].imageUrl:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png",console.log(t.avatar),t})),t})),a.data.forEach((function(t){})),t.setData({order_list:a.data})}}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",method:"get",data:{smember_id:wx.getStorageSync("uid"),order_type:this.data.type},success:function(a){console.log(a);var e=parseFloat(a.data.moneyCount/100).toFixed(2);t.setData({moneyCount:e,orderCount:a.data.orderCount})}}),wx.hideNavigationBarLoading(),wx.stopPullDownRefresh()},onReachBottom:function(){},onShareAppMessage:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/order/component.js'});require("pages/order/component.js");