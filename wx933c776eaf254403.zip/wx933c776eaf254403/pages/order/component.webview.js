$gwx_XC_90=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_90 || [];
function gz$gwx_XC_90_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_90_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'margin-bottom: 130rpx;width: 100%; height: 1500rpx; '])
Z([[2,'=='],[[7],[3,'identity']],[1,'供应商']])
Z([3,'page'])
Z([3,'tab_nav'])
Z([3,'changenav'])
Z([a,[3,'nav_item '],[[2,'?:'],[[2,'=='],[[7],[3,'type']],[1,'ServiceOrder']],[1,'active'],[1,'']]])
Z([3,'ServiceOrder'])
Z([3,' 订单 '])
Z(z[4])
Z([a,z[5][1],[[2,'?:'],[[2,'=='],[[7],[3,'type']],[1,'ReturnOrder']],[1,'active'],[1,'']]])
Z([3,'ReturnOrder'])
Z([3,' 退单 '])
Z([[2,'>'],[[6],[[7],[3,'order_list']],[3,'length']],[1,0]])
Z([3,'listWrapper'])
Z([3,'group_6'])
Z([3,'group_7'])
Z([3,'section_1'])
Z([3,'text_6'])
Z([3,'1'])
Z([3,'订单总金额'])
Z([3,'text-wrapper_3'])
Z([3,'text_7'])
Z(z[18])
Z([a,[3,'¥'],[[7],[3,'moneyCount']]])
Z([3,'text_8'])
Z(z[18])
Z([a,[[7],[3,'orderCount']],[3,'笔订单']])
Z([[7],[3,'order_list']])
Z([3,'box_5'])
Z([3,'tag_1'])
Z([3,'text_5'])
Z(z[18])
Z([a,[[2,'||'],[[6],[[7],[3,'item']],[3,'created_time']],[1,'-']]])
Z([3,'text_66'])
Z([3,'true'])
Z(z[18])
Z([a,[3,'总计\x26nbsp;¥'],[[2,'||'],[[6],[[7],[3,'item']],[3,'total_cost']],[1,'-']]])
Z([[6],[[7],[3,'item']],[3,'order_vo']])
Z([3,'index'])
Z([3,'godetail'])
Z([3,'order_item'])
Z([[6],[[7],[3,'item']],[3,'id']])
Z([[6],[[7],[3,'item']],[3,'state']])
Z([3,'text-wrapper_4'])
Z([3,'text_11'])
Z(z[18])
Z([a,[[6],[[7],[3,'item']],[3,'created_time']]])
Z([3,'text_12'])
Z(z[18])
Z([a,[[6],[[7],[3,'item']],[3,'status']]])
Z([3,'group_9'])
Z([3,'group_10'])
Z([3,'text-group_1'])
Z([3,'text_13'])
Z(z[18])
Z([a,[[6],[[7],[3,'item']],[3,'goods_name']]])
Z([3,'text_14'])
Z(z[34])
Z(z[18])
Z([a,[[6],[[7],[3,'item']],[3,'company_name']],[3,'\x26nbsp;']])
Z([3,'text_15'])
Z(z[18])
Z([a,[3,'应收金额：¥'],[[6],[[7],[3,'item']],[3,'receivable']]])
Z([3,'text_16'])
Z(z[18])
Z([a,[3,'服务费：¥'],[[6],[[7],[3,'item']],[3,'fwf']]])
Z([[2,'<='],[[6],[[7],[3,'order_list']],[3,'length']],[1,0]])
Z([3,'noData'])
Z([3,''])
Z([3,'/images/image/nodata.png'])
Z([[2,'=='],[[7],[3,'identity']],[1,'服务商']])
Z([3,'margin-bottom: 100rpx;'])
Z([[2,'=='],[[7],[3,'identity']],[1,'代理商']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_90_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_90_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_90=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_90=true;
var x=['./pages/order/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_90_1()
var tASB=_n('page')
_rz(z,tASB,'style',0,e,s,gg)
var eBSB=_v()
_(tASB,eBSB)
if(_oz(z,1,e,s,gg)){eBSB.wxVkey=1
var xESB=_n('view')
_rz(z,xESB,'class',2,e,s,gg)
var cHSB=_n('view')
_rz(z,cHSB,'class',3,e,s,gg)
var hISB=_mz(z,'view',['bindtap',4,'class',1,'data-type',2],[],e,s,gg)
var oJSB=_oz(z,7,e,s,gg)
_(hISB,oJSB)
_(cHSB,hISB)
var cKSB=_mz(z,'view',['bindtap',8,'class',1,'data-type',2],[],e,s,gg)
var oLSB=_oz(z,11,e,s,gg)
_(cKSB,oLSB)
_(cHSB,cKSB)
_(xESB,cHSB)
var oFSB=_v()
_(xESB,oFSB)
if(_oz(z,12,e,s,gg)){oFSB.wxVkey=1
var lMSB=_n('view')
_rz(z,lMSB,'class',13,e,s,gg)
var aNSB=_n('view')
_rz(z,aNSB,'class',14,e,s,gg)
var tOSB=_n('view')
_rz(z,tOSB,'class',15,e,s,gg)
var ePSB=_n('view')
_rz(z,ePSB,'class',16,e,s,gg)
var bQSB=_mz(z,'text',['class',17,'lines',1],[],e,s,gg)
var oRSB=_oz(z,19,e,s,gg)
_(bQSB,oRSB)
_(ePSB,bQSB)
_(tOSB,ePSB)
var xSSB=_n('view')
_rz(z,xSSB,'class',20,e,s,gg)
var oTSB=_mz(z,'text',['class',21,'lines',1],[],e,s,gg)
var fUSB=_oz(z,23,e,s,gg)
_(oTSB,fUSB)
_(xSSB,oTSB)
var cVSB=_mz(z,'text',['class',24,'lines',1],[],e,s,gg)
var hWSB=_oz(z,26,e,s,gg)
_(cVSB,hWSB)
_(xSSB,cVSB)
_(tOSB,xSSB)
_(aNSB,tOSB)
_(lMSB,aNSB)
var oXSB=_v()
_(lMSB,oXSB)
var cYSB=function(l1SB,oZSB,a2SB,gg){
var e4SB=_n('view')
var b5SB=_n('view')
_rz(z,b5SB,'class',28,l1SB,oZSB,gg)
var o6SB=_n('view')
_rz(z,o6SB,'class',29,l1SB,oZSB,gg)
var x7SB=_mz(z,'text',['class',30,'lines',1],[],l1SB,oZSB,gg)
var o8SB=_oz(z,32,l1SB,oZSB,gg)
_(x7SB,o8SB)
_(o6SB,x7SB)
_(b5SB,o6SB)
var f9SB=_mz(z,'text',['class',33,'decode',1,'lines',2],[],l1SB,oZSB,gg)
var c0SB=_oz(z,36,l1SB,oZSB,gg)
_(f9SB,c0SB)
_(b5SB,f9SB)
_(e4SB,b5SB)
var hATB=_v()
_(e4SB,hATB)
var oBTB=function(oDTB,cCTB,lETB,gg){
var tGTB=_mz(z,'view',['bindtap',39,'class',1,'data-id',2,'data-state',3],[],oDTB,cCTB,gg)
var eHTB=_n('view')
_rz(z,eHTB,'class',43,oDTB,cCTB,gg)
var bITB=_mz(z,'text',['class',44,'lines',1],[],oDTB,cCTB,gg)
var oJTB=_oz(z,46,oDTB,cCTB,gg)
_(bITB,oJTB)
_(eHTB,bITB)
var xKTB=_mz(z,'text',['class',47,'lines',1],[],oDTB,cCTB,gg)
var oLTB=_oz(z,49,oDTB,cCTB,gg)
_(xKTB,oLTB)
_(eHTB,xKTB)
_(tGTB,eHTB)
var fMTB=_n('view')
_rz(z,fMTB,'class',50,oDTB,cCTB,gg)
_(tGTB,fMTB)
var cNTB=_n('view')
_rz(z,cNTB,'class',51,oDTB,cCTB,gg)
var hOTB=_n('view')
_rz(z,hOTB,'class',52,oDTB,cCTB,gg)
var oPTB=_mz(z,'text',['class',53,'lines',1],[],oDTB,cCTB,gg)
var cQTB=_oz(z,55,oDTB,cCTB,gg)
_(oPTB,cQTB)
_(hOTB,oPTB)
var oRTB=_mz(z,'text',['class',56,'decode',1,'lines',2],[],oDTB,cCTB,gg)
var lSTB=_oz(z,59,oDTB,cCTB,gg)
_(oRTB,lSTB)
_(hOTB,oRTB)
var aTTB=_mz(z,'text',['class',60,'lines',1],[],oDTB,cCTB,gg)
var tUTB=_oz(z,62,oDTB,cCTB,gg)
_(aTTB,tUTB)
_(hOTB,aTTB)
_(cNTB,hOTB)
var eVTB=_mz(z,'text',['class',63,'lines',1],[],oDTB,cCTB,gg)
var bWTB=_oz(z,65,oDTB,cCTB,gg)
_(eVTB,bWTB)
_(cNTB,eVTB)
_(tGTB,cNTB)
_(lETB,tGTB)
return lETB
}
hATB.wxXCkey=2
_2z(z,37,oBTB,l1SB,oZSB,gg,hATB,'item','index','index')
_(a2SB,e4SB)
return a2SB
}
oXSB.wxXCkey=2
_2z(z,27,cYSB,e,s,gg,oXSB,'item','index','')
_(oFSB,lMSB)
}
var fGSB=_v()
_(xESB,fGSB)
if(_oz(z,66,e,s,gg)){fGSB.wxVkey=1
var oXTB=_n('view')
_rz(z,oXTB,'class',67,e,s,gg)
var xYTB=_mz(z,'image',['mode',68,'src',1],[],e,s,gg)
_(oXTB,xYTB)
_(fGSB,oXTB)
}
oFSB.wxXCkey=1
fGSB.wxXCkey=1
_(eBSB,xESB)
}
var bCSB=_v()
_(tASB,bCSB)
if(_oz(z,70,e,s,gg)){bCSB.wxVkey=1
var oZTB=_n('fwsOrder')
_rz(z,oZTB,'style',71,e,s,gg)
_(bCSB,oZTB)
}
var oDSB=_v()
_(tASB,oDSB)
if(_oz(z,72,e,s,gg)){oDSB.wxVkey=1
var f1TB=_n('yeji')
_(oDSB,f1TB)
}
eBSB.wxXCkey=1
bCSB.wxXCkey=1
bCSB.wxXCkey=3
oDSB.wxXCkey=1
oDSB.wxXCkey=3
_(r,tASB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_90";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_90();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/order/component.wxml'] = [$gwx_XC_90, './pages/order/component.wxml'];else __wxAppCode__['pages/order/component.wxml'] = $gwx_XC_90( './pages/order/component.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/order/component.wxss'] = setCssToHead([".",[1],"page{background-color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin-bottom:",[0,130],";overflow:hidden;position:relative;width:",[0,750],"}\n.",[1],"listWrapper{overflow:scroll}\n.",[1],"listWrapper,.",[1],"noData{background-color:#f6f7fb;height:calc(100vh - ",[0,240],")}\n.",[1],"noData{-webkit-align-items:center;align-items:center;-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"group_1,.",[1],"noData{display:-webkit-flex;display:flex}\n.",[1],"group_1{-webkit-flex-direction:row;flex-direction:row;margin:0 ",[0,29]," 0 ",[0,58],"}\n.",[1],"text_3{color:#000;font-family:PingFangSC-Regular;font-size:",[0,34],";line-height:",[0,48],";margin-top:",[0,2],";overflow-wrap:break-word;text-align:center;white-space:nowrap}\n.",[1],"tab_nav{display:-webkit-flex;display:flex;height:",[0,100],";-webkit-justify-content:space-around;justify-content:space-around;width:100%}\n.",[1],"nav_item{-webkit-flex:1;flex:1;font-size:",[0,32],";line-height:",[0,100],";text-align:center}\n.",[1],"active{border-bottom:",[0,8]," solid #508cee;color:#508cee}\n.",[1],"order_item{background:#fff;height:",[0,220],";overflow:hidden;padding:",[0,4],";width:",[0,750],"}\n.",[1],"group_6{background-color:#f6f7fb;padding:",[0,30]," ",[0,20]," ",[0,21],"}\n.",[1],"group_6,.",[1],"group_7{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"group_7{background-color:#2f86f6;border-radius:",[0,28],";padding:",[0,32]," ",[0,40]," ",[0,33],"}\n.",[1],"section_1{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;width:",[0,630],"}\n.",[1],"text_6{color:#fff;font-family:PingFangSC-Medium;font-size:",[0,32],";letter-spacing:",[0,0],";line-height:",[0,32],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"icon_1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAA6UlEQVR4nO2WMWpCQRRFzxUNWAVXYaELsEntApLKDZhG3IFFVpEqkMJKcAmawsImC4gLsBOrFB/Fm+bDH8wPhIxRkDnd3MtweY95vIFE4p9QeLA9BEbADOhJ2uX6HdCOzMokvZQ6tjcu6AT62CcgzKoeZc+AB2ANfAT6EriNrfhHx3bNdsd2IzIkkfg2xy2gD7xJmgb6DVCPzNpL+ix1bK/ykTvYbgb66wnGeB9mVSKr+DNlrX4E5mdtdeL6OeeSOH7VE4q12Ja0zfUB0I3MyiTdlzq+4EfgieLr8x7oz8AituLI+4nE7/gCmHlJXGvm4XAAAAAASUVORK5CYII\x3d) 100% no-repeat;background-size:100% 100%;-webkit-flex-direction:column;flex-direction:column;height:",[0,30],";margin:",[0,1]," 0;width:",[0,30],"}\n.",[1],"icon_1,.",[1],"text-wrapper_3{display:-webkit-flex;display:flex}\n.",[1],"text-wrapper_3{-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,33],";width:",[0,630],"}\n.",[1],"text_7{font-family:PingFangSC-Medium;font-size:",[0,50],";line-height:",[0,36],";margin-top:",[0,2],";text-align:left}\n.",[1],"text_7,.",[1],"text_8{color:#fff;overflow-wrap:break-word;white-space:nowrap}\n.",[1],"text_8{font-family:PingFangSC-Regular;font-size:",[0,28],";line-height:",[0,40],";text-align:right}\n.",[1],"group_8{-webkit-align-self:center;align-self:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,21],";width:",[0,690],"}\n.",[1],"text_9{color:#2f86f6;font-family:PingFangSC-Medium;font-size:",[0,30],";line-height:",[0,42],";text-align:center}\n.",[1],"text_10,.",[1],"text_9{overflow-wrap:break-word;white-space:nowrap}\n.",[1],"text_10{color:#666f83;font-family:PingFangSC-Regular;font-size:",[0,26],";line-height:",[0,37],";margin-top:",[0,6],";text-align:left}\n.",[1],"text-wrapper_4{-webkit-align-self:center;align-self:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,20],";width:",[0,690],"}\n.",[1],"text_11{color:#111a34;font-family:PingFangSC-Regular;letter-spacing:",[0,0],";padding-left:",[0,20],";text-align:left}\n.",[1],"text_11,.",[1],"text_12{font-size:",[0,26],";line-height:",[0,37],";overflow-wrap:break-word;white-space:nowrap}\n.",[1],"text_12{color:#ff7d41;font-family:PingFangSC-Medium;text-align:right}\n.",[1],"group_9{background-color:#e6e6e6;-webkit-flex-direction:column;flex-direction:column;height:",[0,1],";margin:",[0,20]," 0 0 ",[0,30],";width:",[0,720],"}\n.",[1],"group_10,.",[1],"group_9{display:-webkit-flex;display:flex}\n.",[1],"group_10{box-sizing:border-box;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,20]," ",[0,51]," 0 ",[0,30],";padding-left:",[0,30],"}\n.",[1],"image_2{height:",[0,120],";width:",[0,120],"}\n.",[1],"text-group_1{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,120],";overflow:hidden;width:60%}\n.",[1],"text_13{color:#111a34;font-family:PingFangSC-Regular;font-size:",[0,24],";line-height:",[0,33],";margin-right:",[0,112],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"text_14{margin:",[0,11]," ",[0,10]," 0 0}\n.",[1],"text_14,.",[1],"text_15{color:#666f83;font-family:PingFangSC-Regular;font-size:",[0,24],";line-height:",[0,33],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"text_15{margin-top:",[0,10],"}\n.",[1],"text_16{color:#666f83;font-family:PingFangSC-Regular;font-size:",[0,24],";line-height:",[0,33],";margin:",[0,87]," 0 0 ",[0,0],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"group_11{background-color:#f6f7fb;-webkit-flex-direction:column;flex-direction:column;height:",[0,20],";margin-top:",[0,20],";width:",[0,750],"}\n.",[1],"box_5,.",[1],"group_11{display:-webkit-flex;display:flex}\n.",[1],"box_5{-webkit-align-self:center;align-self:center;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,25]," 0;padding:0 3vw;width:100vw}\n.",[1],"tag_1{background-color:#fff;border-radius:",[0,24],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding:",[0,3]," ",[0,24]," ",[0,3]," ",[0,25],"}\n.",[1],"text_5{color:#2f86f6;font-family:PingFangSC-Medium;font-size:",[0,30],";line-height:",[0,42],";overflow-wrap:break-word;text-align:center;white-space:nowrap}\n.",[1],"avatar{height:16vw;width:16vw}\n.",[1],"text_66{color:#aaa;font-family:PingFangSC-Medium;font-size:",[0,26],";line-height:",[0,37],";margin-top:",[0,6],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n",],undefined,{path:"./pages/order/component.wxss"});
}