Page({
    data: {
        order_list: [],
        orderCount: 68,
        moneyCount: 5e4,
        type: "ServiceOrder",
        identity: "供应商"
    },
    onLoad: function(t) {},
    init: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",
            method: "get",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                a.data = a.data.map(function(t) {
                    return t.total_cost = (t.total_cost / 100).toFixed(2), t.order_vo = t.order_vo.map(function(t) {
                        return console.log(t), "OrderAdd" == t.state ? t.status = "待确认" : "Wrong" == t.state ? t.status = "信息有误" : "OrderUpdate" == t.state ? t.status = "待确认" : "Confirm" == t.state ? t.status = "已确认" : "ApplyCancel" == t.state ? t.status = "作废请求" : "Cancel" == t.state && (t.status = "作废"), 
                        t.receivable = (t.receivable / 100).toFixed(2), t.fwf = (t.total_cost * (t.service_rate / 100) / 100).toFixed(2), 
                        t.image_list = JSON.parse(t.image_list), t.avatar = t.image_list[0] ? t.image_list[0].imageUrl : "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png", 
                        console.log(t.avatar), t;
                    }), t;
                }), a.data.forEach(function(t) {}), t.setData({
                    order_list: a.data
                });
            }
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",
            method: "get",
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                console.log(a);
                var e = parseFloat(a.data.moneyCount / 100).toFixed(2);
                t.setData({
                    moneyCount: e,
                    orderCount: a.data.orderCount
                });
            }
        });
    },
    getOrder: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",
            method: "get",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                console.log(a), a.data.forEach(function(t) {
                    t.total_cost = (t.total_cost / 100).toFixed(2), t.order_vo.forEach(function(t) {
                        "OrderAdd" == t.state ? t.status = "待确认" : "Wrong" == t.state ? t.status = "信息有误" : "OrderUpdate" == t.state ? t.status = "待确认" : "Confirm" == t.state ? t.status = "已确认" : "Cancel" == t.state && (t.status = "作废"), 
                        t.receivable = (t.receivable / 100).toFixed(2), t.fwf = (t.total_cost * (t.service_rate / 100) / 100).toFixed(2);
                    });
                }), t.setData({
                    order_list: a.data
                });
            }
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",
            method: "get",
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                console.log(a);
                var e = parseFloat(a.data.moneyCount / 100).toFixed(2);
                t.setData({
                    moneyCount: e,
                    orderCount: a.data.orderCount
                });
            }
        });
    },
    godetail: function(t) {
        var a = t.currentTarget.dataset.id;
        t.currentTarget.dataset.state;
        return wx.navigateTo({
            url: "/pages/orderDetail/component?id=" + a
        }), !1;
    },
    changenav: function(t) {
        console.log(t);
        var a = t.currentTarget.dataset.type;
        this.setData({
            type: a
        }), this.getOrder();
    },
    onReady: function() {
        wx.getStorageSync("username") || wx.reLaunch({
            url: "/pages/login/component"
        });
    },
    onShow: function() {
        var t = this;
        if ("function" == typeof this.getTabBar && this.getTabBar()) if (this.getTabBar().setData({
            selected: 0
        }), "服务商" == wx.getStorageSync("identity")) {
            this.getTabBar().setData({
                list: [ {
                    pagePath: "/pages/order/component",
                    text: "订单",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
                }, {
                    pagePath: "/pages/serProviders/component",
                    text: "供应商",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
                }, {
                    pagePath: "/pages/financial/component",
                    text: "财务",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
                }, {
                    pagePath: "/pages/my/component",
                    text: "我的",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
                } ]
            });
        } else if ("代理商" == wx.getStorageSync("identity")) {
            var a = [];
            a = "Salesman" == wx.getStorageSync("identityStatus") || "SalesDirector" == wx.getStorageSync("identityStatus") || "Sales" == wx.getStorageSync("identityStatus") ? [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ] : [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/serProviders/component",
                text: "人员",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: a
            }), this.setData({
                identityStatus: wx.getStorageSync("identityStatus")
            });
        }
        var e = wx.getStorageSync("identity");
        console.log(e), this.setData({
            identity: e
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",
            method: "get",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                a.data = a.data.map(function(t) {
                    return t.total_cost = (t.total_cost / 100).toFixed(2), t.order_vo = t.order_vo.map(function(t) {
                        return console.log(t), "OrderAdd" == t.state ? t.status = "待确认" : "Wrong" == t.state ? t.status = "信息有误" : "OrderUpdate" == t.state ? t.status = "待确认" : "Confirm" == t.state ? t.status = "已确认" : "ApplyCancel" == t.state ? t.status = "作废请求" : "Cancel" == t.state && (t.status = "作废"), 
                        t.receivable = (t.receivable / 100).toFixed(2), t.fwf = (t.total_cost * (t.service_rate / 100) / 100).toFixed(2), 
                        t.image_list = JSON.parse(t.image_list), t.avatar = t.image_list[0] ? t.image_list[0].imageUrl : "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png", 
                        console.log(t.avatar), t;
                    }), t;
                }), a.data.forEach(function(t) {}), t.setData({
                    order_list: a.data
                });
            }
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",
            method: "get",
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                console.log(a);
                var e = parseFloat(a.data.moneyCount / 100).toFixed(2);
                t.setData({
                    moneyCount: e,
                    orderCount: a.data.orderCount
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var t = this;
        if (wx.showNavigationBarLoading(), "function" == typeof this.getTabBar && this.getTabBar()) if (this.getTabBar().setData({
            selected: 0
        }), "服务商" == wx.getStorageSync("identity")) {
            this.getTabBar().setData({
                list: [ {
                    pagePath: "/pages/order/component",
                    text: "订单",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
                }, {
                    pagePath: "/pages/serProviders/component",
                    text: "供应商",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
                }, {
                    pagePath: "/pages/financial/component",
                    text: "财务",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
                }, {
                    pagePath: "/pages/my/component",
                    text: "我的",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
                } ]
            });
        } else if ("代理商" == wx.getStorageSync("identity")) {
            var a = [];
            a = "Salesman" == wx.getStorageSync("identityStatus") ? [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ] : [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/serProviders/component",
                text: "人员",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: a
            }), this.setData({
                identityStatus: wx.getStorageSync("identityStatus")
            });
        }
        var e = wx.getStorageSync("identity");
        console.log(e), this.setData({
            identity: e
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlist",
            method: "get",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                a.data = a.data.map(function(t) {
                    return t.total_cost = (t.total_cost / 100).toFixed(2), t.order_vo = t.order_vo.map(function(t) {
                        return console.log(t), "OrderAdd" == t.state ? t.status = "待确认" : "Wrong" == t.state ? t.status = "信息有误" : "OrderUpdate" == t.state ? t.status = "待确认" : "Confirm" == t.state ? t.status = "已确认" : "ApplyCancel" == t.state ? t.status = "作废请求" : "Cancel" == t.state && (t.status = "作废"), 
                        t.receivable = (t.receivable / 100).toFixed(2), t.fwf = (t.total_cost * (t.service_rate / 100) / 100).toFixed(2), 
                        t.image_list = JSON.parse(t.image_list), t.avatar = t.image_list[0] ? t.image_list[0].imageUrl : "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png", 
                        console.log(t.avatar), t;
                    }), t;
                }), a.data.forEach(function(t) {}), t.setData({
                    order_list: a.data
                });
            }
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSOrderlistCount",
            method: "get",
            data: {
                smember_id: wx.getStorageSync("uid"),
                order_type: this.data.type
            },
            success: function(a) {
                console.log(a);
                var e = parseFloat(a.data.moneyCount / 100).toFixed(2);
                t.setData({
                    moneyCount: e,
                    orderCount: a.data.orderCount
                });
            }
        }), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});