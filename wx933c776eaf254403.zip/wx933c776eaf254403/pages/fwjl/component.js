Component({
    properties: {},
    data: {
        serviceFee: 0,
        rechargeRecordList: []
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            wx.getStorageSync("userShopid"), wx.getStorageSync("semberShopid");
            this.fetchList(), console.info("页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        invoice: function() {
            wx.navigateTo({
                url: "/pagesB/invoice/invoice"
            });
        },
        fetchList: function() {
            var e = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getRechargeRecordList/" + wx.getStorageSync("uid"),
                method: "get",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    smember_id: wx.getStorageSync("uid"),
                    order_type: this.data.type
                },
                success: function(t) {
                    e.setData({
                        serviceFee: parseFloat(t.data.serviceFee / 100).toFixed(2),
                        rechargeRecordList: t.data.rechargeRecordList
                    });
                }
            });
        }
    }
});