$gwx_XC_89=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_89 || [];
function gz$gwx_XC_89_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_89_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_89_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_89_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'block_2'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'status']],[1,'代理商']],[[2,'!='],[[7],[3,'job_no']],[1,'']]])
Z([3,'list_box'])
Z([[2,'=='],[[7],[3,'status']],[1,'代理商']])
Z([3,'setInfo'])
Z([3,'list_item'])
Z([3,'arrow'])
Z([[2,'||'],[[2,'=='],[[7],[3,'status']],[1,'服务商']],[[2,'=='],[[7],[3,'status']],[1,'供应商']]])
Z([3,'rzxz'])
Z(z[6])
Z([[6],[[7],[3,'userData']],[3,'status']])
Z(z[7])
Z(z[8])
Z([3,'cusrz'])
Z(z[6])
Z([[6],[[7],[3,'userData']],[3,'cusstatus']])
Z(z[7])
Z([[2,'=='],[[7],[3,'status']],[1,'服务商']])
Z([3,'Paymentaccount'])
Z(z[6])
Z(z[7])
Z([[2,'=='],[[7],[3,'status']],[1,'供应商']])
Z(z[19])
Z(z[6])
Z(z[7])
Z(z[18])
Z([3,'tofwjl'])
Z(z[6])
Z(z[7])
Z([[2,'||'],[[2,'=='],[[7],[3,'status']],[1,'供应商']],[[2,'=='],[[7],[3,'status']],[1,'服务商']]])
Z([3,'addSerpro'])
Z(z[6])
Z([[2,'&&'],[[2,'!='],[[7],[3,'faciNum']],[1,0]],[[2,'=='],[[7],[3,'status']],[1,'供应商']]])
Z(z[7])
Z([[2,'&&'],[[2,'=='],[[7],[3,'status']],[1,'代理商']],[[2,'=='],[[7],[3,'identityStatus']],[1,'GeneralAgent']]])
Z([3,'addSales'])
Z(z[6])
Z(z[7])
Z([3,'swichStatus'])
Z(z[6])
Z(z[7])
Z(z[7])
Z([3,'forgotPassword'])
Z(z[6])
Z(z[7])
Z([3,'outLogin'])
Z(z[6])
Z(z[7])
Z([3,'van-dialog'])
Z([[7],[3,'actions']])
Z([3,'onClose'])
Z(z[51])
Z([3,'rzSubmit'])
Z([3,'取消'])
Z([[7],[3,'rzxzFlag']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_89_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_89_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_89=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_89=true;
var x=['./pages/my/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_89_1()
var oBX=_n('view')
_rz(z,oBX,'class',0,e,s,gg)
var fCX=_n('view')
_rz(z,fCX,'class',1,e,s,gg)
var cDX=_v()
_(fCX,cDX)
if(_oz(z,2,e,s,gg)){cDX.wxVkey=1
}
var hEX=_n('view')
_rz(z,hEX,'class',3,e,s,gg)
var oFX=_v()
_(hEX,oFX)
if(_oz(z,4,e,s,gg)){oFX.wxVkey=1
var oNX=_mz(z,'view',['bindtap',5,'class',1],[],e,s,gg)
var xOX=_n('van-icon')
_rz(z,xOX,'name',7,e,s,gg)
_(oNX,xOX)
_(oFX,oNX)
}
var cGX=_v()
_(hEX,cGX)
if(_oz(z,8,e,s,gg)){cGX.wxVkey=1
var oPX=_mz(z,'view',['bindtap',9,'class',1,'data-status',2],[],e,s,gg)
var fQX=_n('van-icon')
_rz(z,fQX,'name',12,e,s,gg)
_(oPX,fQX)
_(cGX,oPX)
}
var oHX=_v()
_(hEX,oHX)
if(_oz(z,13,e,s,gg)){oHX.wxVkey=1
var cRX=_mz(z,'view',['bindtap',14,'class',1,'data-status',2],[],e,s,gg)
var hSX=_n('van-icon')
_rz(z,hSX,'name',17,e,s,gg)
_(cRX,hSX)
_(oHX,cRX)
}
var lIX=_v()
_(hEX,lIX)
if(_oz(z,18,e,s,gg)){lIX.wxVkey=1
var oTX=_mz(z,'view',['bindtap',19,'class',1],[],e,s,gg)
var cUX=_n('van-icon')
_rz(z,cUX,'name',21,e,s,gg)
_(oTX,cUX)
_(lIX,oTX)
}
var aJX=_v()
_(hEX,aJX)
if(_oz(z,22,e,s,gg)){aJX.wxVkey=1
var oVX=_mz(z,'view',['bindtap',23,'class',1],[],e,s,gg)
var lWX=_n('van-icon')
_rz(z,lWX,'name',25,e,s,gg)
_(oVX,lWX)
_(aJX,oVX)
}
var tKX=_v()
_(hEX,tKX)
if(_oz(z,26,e,s,gg)){tKX.wxVkey=1
var aXX=_mz(z,'view',['bindtap',27,'class',1],[],e,s,gg)
var tYX=_n('van-icon')
_rz(z,tYX,'name',29,e,s,gg)
_(aXX,tYX)
_(tKX,aXX)
}
var eLX=_v()
_(hEX,eLX)
if(_oz(z,30,e,s,gg)){eLX.wxVkey=1
var eZX=_mz(z,'view',['bindtap',31,'class',1],[],e,s,gg)
var b1X=_v()
_(eZX,b1X)
if(_oz(z,33,e,s,gg)){b1X.wxVkey=1
}
var o2X=_n('van-icon')
_rz(z,o2X,'name',34,e,s,gg)
_(eZX,o2X)
b1X.wxXCkey=1
_(eLX,eZX)
}
var bMX=_v()
_(hEX,bMX)
if(_oz(z,35,e,s,gg)){bMX.wxVkey=1
var x3X=_mz(z,'view',['bindtap',36,'class',1],[],e,s,gg)
var o4X=_n('van-icon')
_rz(z,o4X,'name',38,e,s,gg)
_(x3X,o4X)
_(bMX,x3X)
}
var f5X=_mz(z,'view',['bindtap',39,'class',1],[],e,s,gg)
var c6X=_n('van-icon')
_rz(z,c6X,'name',41,e,s,gg)
_(f5X,c6X)
_(hEX,f5X)
var h7X=_n('van-icon')
_rz(z,h7X,'name',42,e,s,gg)
_(hEX,h7X)
var o8X=_mz(z,'view',['bindtap',43,'class',1],[],e,s,gg)
var c9X=_n('van-icon')
_rz(z,c9X,'name',45,e,s,gg)
_(o8X,c9X)
_(hEX,o8X)
var o0X=_mz(z,'view',['bindtap',46,'class',1],[],e,s,gg)
var lAY=_n('van-icon')
_rz(z,lAY,'name',48,e,s,gg)
_(o0X,lAY)
_(hEX,o0X)
oFX.wxXCkey=1
oFX.wxXCkey=3
cGX.wxXCkey=1
cGX.wxXCkey=3
oHX.wxXCkey=1
oHX.wxXCkey=3
lIX.wxXCkey=1
lIX.wxXCkey=3
aJX.wxXCkey=1
aJX.wxXCkey=3
tKX.wxXCkey=1
tKX.wxXCkey=3
eLX.wxXCkey=1
eLX.wxXCkey=3
bMX.wxXCkey=1
bMX.wxXCkey=3
_(fCX,hEX)
cDX.wxXCkey=1
_(oBX,fCX)
var aBY=_n('van-dialog')
_rz(z,aBY,'id',49,e,s,gg)
_(oBX,aBY)
_(r,oBX)
var tCY=_mz(z,'van-action-sheet',['actions',50,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'show',5],[],e,s,gg)
_(r,tCY)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_89";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_89();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/my/component.wxml'] = [$gwx_XC_89, './pages/my/component.wxml'];else __wxAppCode__['pages/my/component.wxml'] = $gwx_XC_89( './pages/my/component.wxml' );
	;__wxRoute = "pages/my/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/my/component.js";define("pages/my/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/interopRequireDefault").default,a=require("../../@babel/runtime/helpers/objectSpread2"),e=t(require("../../miniprogram_npm/@vant/weapp/dialog/dialog"));Page({data:{rzxzFlag:!1,status:"",rzstatus:"未认证",userData:{cusstatus:"未认证"},faciNum:0,identityStatus:"",job_no:"",actions:[{name:"公司认证",id:"qy"}]},getfaciNumber:function(){var t=this;"供应商"==wx.getStorageSync("identity")&&wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getFacilitatorList/"+wx.getStorageSync("uid"),method:"POST",success:function(a){console.log(a),t.setData({faciNum:a.data.count})}})},outLogin:function(){e.default.confirm({message:"确认要退出登录吗"}).then((function(){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/logout",method:"get",header:{"Content-Type":"application/json;charset=utf-8",dataType:"json"},data:{member_id:wx.getStorageSync("uid")},success:function(t){console.log(t),200==t.statusCode&&(wx.setStorageSync("uid",""),wx.removeStorageSync("checkedSupplier"),wx.removeStorageSync("company_name"),wx.reLaunch({url:"/pages/login/component"}))}})})).catch((function(){}))},rzxz:function(t){if(console.log(t),"已认证"==t.currentTarget.dataset.status)return wx.navigateTo({url:"/pagesB/resPage/index"}),!1;wx.navigateTo({url:"/pages/Enterprisecertification/component"})},cusrz:function(t){if("已认证"==t.currentTarget.dataset.status)return!1;wx.navigateTo({url:"/pages/Personalauthentication/component"})},onClose:function(){this.setData({rzxzFlag:!1})},rzSubmit:function(t){var a=t.detail.id;"qy"==a||("gr"==a?wx.navigateTo({url:"/pages/Personalauthentication/component"}):"qx"==a&&this.setData({rzxzFlag:!1}))},Paymentaccount:function(){wx.navigateTo({url:"/pages/Paymentaccount/component"})},addSerpro:function(){"供应商"==wx.getStorageSync("identity")?wx.navigateTo({url:"/pages/addSerpro/component"}):wx.navigateTo({url:"/pagesA/gys_list/component"})},addSales:function(){wx.navigateTo({url:"/pagesA/addSales/component"})},setInfo:function(){wx.navigateTo({url:"/pages/setInfo/component"})},setCount:function(){wx.navigateTo({url:"/pages/setCount/component"})},swichStatus:function(){"APPLY"==wx.getStorageSync("apply_state")?wx.reLaunch({url:"/pages/applyOk/component"}):wx.navigateTo({url:"/pages/switchStatus/component"})},tokefu:function(){},bindShop:function(){wx.navigateTo({url:"/pages/bindShop/component"})},forgotPassword:function(){wx.navigateTo({url:"/pages/forgotPassword/component?type=1"})},setUserdata:function(){var t=this;wx.getUserProfile({lang:"zh_CN",desc:"更新用户信息",success:function(e){console.log(e.userInfo);var o=a({head_img_url:e.userInfo.avatarUrl,uname:e.userInfo.nickName},t.data.userData);t.setData({userData:o})},fail:function(t){}})},onLoad:function(t){this.setData({status:wx.getStorageSync("identity")})},onReady:function(){},onShow:function(){if("function"==typeof this.getTabBar&&this.getTabBar())if(wx.getStorageSync("job_no")&&this.setData({job_no:wx.getStorageSync("job_no")}),"服务商"==wx.getStorageSync("identity")){this.getTabBar().setData({list:[{pagePath:"/pages/order/component",text:"订单",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"供应商",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"财务",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],selected:3})}else if("代理商"==wx.getStorageSync("identity")){var t=[];"Salesman"==wx.getStorageSync("identityStatus")||"SalesDirector"==wx.getStorageSync("identityStatus")||"Sales"==wx.getStorageSync("identityStatus")?(t=[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:t,selected:2})):(t=[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"人员",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:t,selected:3})),this.setData({identityStatus:wx.getStorageSync("identityStatus")})}else this.getTabBar().setData({selected:3});this.getUserinfo(),this.getfaciNumber(),this.getUserCusinfo()},tofwjl:function(){wx.navigateTo({url:"/pages/fwjl/component"})},getUserinfo:function(){var t=this;this.setUserdata(),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/"+wx.getStorageSync("uid"),method:"get",success:function(a){console.log(a);var e=a.data;switch(e.disables){case 0:e.status="未认证";break;case 1:e.status="提交";break;case 2:e.status="审核";break;case 3:e.status="驳回";break;case 4:e.status="重提交";break;case 5:e.status="已认证";break;default:console.log("未定义"),e.status="未认证"}e.cusstatus="未认证",e.head_img_url=a.data.face||"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png",t.setData({userData:e})}})},getUserCusinfo:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getHTCusInfoByShopId",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},data:{shop_id:wx.getStorageSync("userShopid")},success:function(a){if(console.log(a),a.data.id_card_name){var e=t.data.userData;e.cusstatus="已认证",t.setData({userData:e})}}})},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/my/component.js'});require("pages/my/component.js");