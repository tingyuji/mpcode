var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, a = require("../../@babel/runtime/helpers/objectSpread2"), e = t(require("../../miniprogram_npm/@vant/weapp/dialog/dialog"));

Page({
    data: {
        rzxzFlag: !1,
        status: "",
        rzstatus: "未认证",
        userData: {
            cusstatus: "未认证"
        },
        faciNum: 0,
        identityStatus: "",
        job_no: "",
        actions: [ {
            name: "公司认证",
            id: "qy"
        } ]
    },
    getfaciNumber: function() {
        var t = this;
        "供应商" == wx.getStorageSync("identity") && wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getFacilitatorList/" + wx.getStorageSync("uid"),
            method: "POST",
            success: function(a) {
                console.log(a), t.setData({
                    faciNum: a.data.count
                });
            }
        });
    },
    outLogin: function() {
        e.default.confirm({
            message: "确认要退出登录吗"
        }).then(function() {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/logout",
                method: "get",
                header: {
                    "Content-Type": "application/json;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    member_id: wx.getStorageSync("uid")
                },
                success: function(t) {
                    console.log(t), 200 == t.statusCode && (wx.setStorageSync("uid", ""), wx.removeStorageSync("checkedSupplier"), 
                    wx.removeStorageSync("company_name"), wx.reLaunch({
                        url: "/pages/login/component"
                    }));
                }
            });
        }).catch(function() {});
    },
    rzxz: function(t) {
        if (console.log(t), "已认证" == t.currentTarget.dataset.status) return wx.navigateTo({
            url: "/pagesB/resPage/index"
        }), !1;
        wx.navigateTo({
            url: "/pages/Enterprisecertification/component"
        });
    },
    cusrz: function(t) {
        if ("已认证" == t.currentTarget.dataset.status) return !1;
        wx.navigateTo({
            url: "/pages/Personalauthentication/component"
        });
    },
    onClose: function() {
        this.setData({
            rzxzFlag: !1
        });
    },
    rzSubmit: function(t) {
        var a = t.detail.id;
        "qy" == a || ("gr" == a ? wx.navigateTo({
            url: "/pages/Personalauthentication/component"
        }) : "qx" == a && this.setData({
            rzxzFlag: !1
        }));
    },
    Paymentaccount: function() {
        wx.navigateTo({
            url: "/pages/Paymentaccount/component"
        });
    },
    addSerpro: function() {
        "供应商" == wx.getStorageSync("identity") ? wx.navigateTo({
            url: "/pages/addSerpro/component"
        }) : wx.navigateTo({
            url: "/pagesA/gys_list/component"
        });
    },
    addSales: function() {
        wx.navigateTo({
            url: "/pagesA/addSales/component"
        });
    },
    setInfo: function() {
        wx.navigateTo({
            url: "/pages/setInfo/component"
        });
    },
    setCount: function() {
        wx.navigateTo({
            url: "/pages/setCount/component"
        });
    },
    swichStatus: function() {
        "APPLY" == wx.getStorageSync("apply_state") ? wx.reLaunch({
            url: "/pages/applyOk/component"
        }) : wx.navigateTo({
            url: "/pages/switchStatus/component"
        });
    },
    tokefu: function() {},
    bindShop: function() {
        wx.navigateTo({
            url: "/pages/bindShop/component"
        });
    },
    forgotPassword: function() {
        wx.navigateTo({
            url: "/pages/forgotPassword/component?type=1"
        });
    },
    setUserdata: function() {
        var t = this;
        wx.getUserProfile({
            lang: "zh_CN",
            desc: "更新用户信息",
            success: function(e) {
                console.log(e.userInfo);
                var o = a({
                    head_img_url: e.userInfo.avatarUrl,
                    uname: e.userInfo.nickName
                }, t.data.userData);
                t.setData({
                    userData: o
                });
            },
            fail: function(t) {}
        });
    },
    onLoad: function(t) {
        this.setData({
            status: wx.getStorageSync("identity")
        });
    },
    onReady: function() {},
    onShow: function() {
        if ("function" == typeof this.getTabBar && this.getTabBar()) if (wx.getStorageSync("job_no") && this.setData({
            job_no: wx.getStorageSync("job_no")
        }), "服务商" == wx.getStorageSync("identity")) {
            this.getTabBar().setData({
                list: [ {
                    pagePath: "/pages/order/component",
                    text: "订单",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
                }, {
                    pagePath: "/pages/serProviders/component",
                    text: "供应商",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
                }, {
                    pagePath: "/pages/financial/component",
                    text: "财务",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
                }, {
                    pagePath: "/pages/my/component",
                    text: "我的",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
                } ],
                selected: 3
            });
        } else if ("代理商" == wx.getStorageSync("identity")) {
            var t = [];
            "Salesman" == wx.getStorageSync("identityStatus") || "SalesDirector" == wx.getStorageSync("identityStatus") || "Sales" == wx.getStorageSync("identityStatus") ? (t = [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: t,
                selected: 2
            })) : (t = [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/serProviders/component",
                text: "人员",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: t,
                selected: 3
            })), this.setData({
                identityStatus: wx.getStorageSync("identityStatus")
            });
        } else this.getTabBar().setData({
            selected: 3
        });
        this.getUserinfo(), this.getfaciNumber(), this.getUserCusinfo();
    },
    tofwjl: function() {
        wx.navigateTo({
            url: "/pages/fwjl/component"
        });
    },
    getUserinfo: function() {
        var t = this;
        this.setUserdata(), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/" + wx.getStorageSync("uid"),
            method: "get",
            success: function(a) {
                console.log(a);
                var e = a.data;
                switch (e.disables) {
                  case 0:
                    e.status = "未认证";
                    break;

                  case 1:
                    e.status = "提交";
                    break;

                  case 2:
                    e.status = "审核";
                    break;

                  case 3:
                    e.status = "驳回";
                    break;

                  case 4:
                    e.status = "重提交";
                    break;

                  case 5:
                    e.status = "已认证";
                    break;

                  default:
                    console.log("未定义"), e.status = "未认证";
                }
                e.cusstatus = "未认证", e.head_img_url = a.data.face || "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png", 
                t.setData({
                    userData: e
                });
            }
        });
    },
    getUserCusinfo: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getHTCusInfoByShopId",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            data: {
                shop_id: wx.getStorageSync("userShopid")
            },
            success: function(a) {
                if (console.log(a), a.data.id_card_name) {
                    var e = t.data.userData;
                    e.cusstatus = "已认证", t.setData({
                        userData: e
                    });
                }
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});