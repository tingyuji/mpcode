Page({
    data: {
        titleList: {
            nav1: "收款记录",
            nav2: "提现记录",
            nav3: "付款记录",
            titleText: "已收款",
            titleText2: "已付款"
        },
        Collection: "",
        CollectionList: [],
        Uncollected: 0,
        UncollectedList: [],
        type: "Allocation",
        count: "",
        moneyCount: "",
        identity: "供应商"
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        if ("服务商" == wx.getStorageSync("identity") && this.setData({
            titleList: {
                nav1: "收款记录",
                nav2: "提现记录",
                nav3: "付款记录",
                titleText: "已收款",
                titleText2: "已付款"
            }
        }), "function" == typeof this.getTabBar && this.getTabBar()) if ("服务商" == wx.getStorageSync("identity")) {
            this.getTabBar().setData({
                list: [ {
                    pagePath: "/pages/order/component",
                    text: "订单",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
                }, {
                    pagePath: "/pages/serProviders/component",
                    text: "供应商",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
                }, {
                    pagePath: "/pages/financial/component",
                    text: "财务",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
                }, {
                    pagePath: "/pages/my/component",
                    text: "我的",
                    iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                    selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
                } ],
                selected: 2
            });
        } else if ("代理商" == wx.getStorageSync("identity")) {
            var t = [];
            "Salesman" == wx.getStorageSync("identityStatus") || "SalesDirector" == wx.getStorageSync("identityStatus") || "Sales" == wx.getStorageSync("identityStatus") ? (t = [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: t,
                selected: 1
            })) : (t = [ {
                pagePath: "/pages/order/component",
                text: "业绩",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"
            }, {
                pagePath: "/pages/serProviders/component",
                text: "人员",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"
            }, {
                pagePath: "/pages/financial/component",
                text: "客户",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"
            }, {
                pagePath: "/pages/my/component",
                text: "我的",
                iconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",
                selectedIconPath: "http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"
            } ], this.getTabBar().setData({
                list: t,
                selected: 2
            })), this.setData({
                identityStatus: wx.getStorageSync("identityStatus")
            });
        } else this.getTabBar().setData({
            selected: 2
        });
        var a = wx.getStorageSync("identity");
        this.setData({
            identity: a
        }), console.info("页面加载"), this.getGysdata();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    uplist: function(t) {
        var a = wx.getStorageSync("identity"), e = t.currentTarget.dataset.type;
        "Allocation" == e ? (this.setData({
            type: "Allocation"
        }), this.getGysdata()) : "Withdrawals" == e ? (this.setData({
            type: "Withdrawals"
        }), "服务商" == a ? this.getWitfwsdata() : this.getWitgysdata()) : "ocation" == e && (this.getFwsdata(), 
        this.setData({
            type: "ocation"
        }));
    },
    getSkjl: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getSAllocationsCount",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid")
            },
            success: function(a) {
                console.log(a);
                var e = (parseFloat(a.data.Collection) / 100).toFixed(2), o = (parseFloat(a.data.Uncollected) / 100).toFixed(2), n = a.data.SAllocationsList;
                console.log(e, o, n), n.forEach(function(t) {
                    t.amount = (t.amount / 100).toFixed(2), 0 != t.allocation_do.length && t.allocation_do.forEach(function(t) {
                        t.amount = (t.amount / 100).toFixed(2);
                    });
                }), t.setData({
                    Collection: e,
                    Uncollected: o,
                    CollectionList: n
                });
            }
        });
    },
    getGysdata: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getSAllocationsCount",
            method: "post",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json"
            },
            data: {
                smember_id: wx.getStorageSync("uid")
            },
            success: function(a) {
                console.log(a.data);
                var e = (parseFloat(a.data.Collection) / 100).toFixed(2), o = (parseFloat(a.data.Uncollected) / 100).toFixed(2), n = a.data.SAllocationsList;
                console.log(e, o, n), n.forEach(function(t) {
                    t.amount = (t.amount / 100).toFixed(2), 0 != t.allocation_do.length && t.allocation_do.forEach(function(t) {
                        t.amount = (t.amount / 100).toFixed(2);
                    });
                }), t.setData({
                    Collection: e,
                    Uncollected: o,
                    CollectionList: n
                });
            }
        });
    },
    getFwsdata: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getFAllocationsCount",
            method: "post",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssCreateBalanceAcct",
                timestamp: Date.parse(new Date())
            },
            data: {
                fmember_id: wx.getStorageSync("uid")
            },
            success: function(a) {
                console.log(a);
                var e = (parseFloat(a.data.Collection) / 100).toFixed(2), o = (parseFloat(a.data.Uncollected) / 100).toFixed(2), n = a.data.FAllocationsList;
                n.forEach(function(t) {
                    t.amount = (t.amount / 100).toFixed(2), 0 != t.allocation_do.length && t.allocation_do.forEach(function(t) {
                        t.amount = (t.amount / 100).toFixed(2);
                    });
                }), t.setData({
                    Collection: e,
                    Uncollected: o,
                    CollectionList: n
                });
            }
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getAllocationList",
            method: "post",
            success: function(a) {
                t.setData({
                    CollectionList: a.data
                });
            }
        });
    },
    getWitgysdata: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getWithdrawalsCount",
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssCreateBalanceAcct",
                timestamp: Date.parse(new Date())
            },
            data: {
                shop_id: wx.getStorageSync("userShopid")
            },
            success: function(a) {
                console.log(a);
                var e = (parseFloat(a.data.moneyCount) / 100).toFixed(2), o = a.data.WithdrawalsList;
                o.forEach(function(t) {
                    t.amount = (t.amount / 100).toFixed(2), t.withdrawals_do.forEach(function(t) {
                        t.amount = (t.amount / 100).toFixed(2);
                    });
                }), t.setData({
                    count: a.data.count,
                    moneyCount: e,
                    UncollectedList: o
                });
            }
        });
    },
    getWitfwsdata: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getWithdrawalsCount",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                dataType: "json",
                transCode: "szbank_ssCreateBalanceAcct",
                timestamp: Date.parse(new Date())
            },
            data: {
                shop_id: wx.getStorageSync("userShopid")
            },
            method: "POST",
            success: function(a) {
                console.log(a);
                var e = (parseFloat(a.data.moneyCount) / 100).toFixed(2), o = a.data.WithdrawalsList;
                o.forEach(function(t) {
                    t.amount = (t.amount / 100).toFixed(2), t.withdrawals_do.forEach(function(t) {
                        t.amount = (t.amount / 100).toFixed(2);
                    });
                }), t.setData({
                    count: a.data.count,
                    moneyCount: e,
                    UncollectedList: o
                });
            }
        });
    }
});