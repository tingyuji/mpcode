$gwx_XC_85=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_85 || [];
function gz$gwx_XC_85_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_85_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_85_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_85_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'||'],[[2,'=='],[[7],[3,'identity']],[1,'供应商']],[[2,'=='],[[7],[3,'identity']],[1,'服务商']]])
Z([3,'wrapper'])
Z([[2,'=='],[[7],[3,'type']],[1,'Allocation']])
Z([[2,'=='],[[7],[3,'type']],[1,'ocation']])
Z([[2,'=='],[[7],[3,'type']],[1,'Withdrawals']])
Z([[7],[3,'CollectionList']])
Z([3,'index'])
Z(z[2])
Z(z[5])
Z(z[6])
Z([[2,'=='],[[7],[3,'type']],[1,'ocation']])
Z([[7],[3,'UncollectedList']])
Z(z[6])
Z(z[4])
Z([3,''])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_85_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_85_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_85=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_85=true;
var x=['./pages/financial/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_85_1()
var b3V=_v()
_(r,b3V)
if(_oz(z,0,e,s,gg)){b3V.wxVkey=1
var o4V=_n('view')
_rz(z,o4V,'class',1,e,s,gg)
var x5V=_v()
_(o4V,x5V)
if(_oz(z,2,e,s,gg)){x5V.wxVkey=1
}
var o6V=_v()
_(o4V,o6V)
if(_oz(z,3,e,s,gg)){o6V.wxVkey=1
}
var f7V=_v()
_(o4V,f7V)
if(_oz(z,4,e,s,gg)){f7V.wxVkey=1
}
var c8V=_v()
_(o4V,c8V)
var h9V=function(cAW,o0V,oBW,gg){
var aDW=_v()
_(oBW,aDW)
if(_oz(z,7,cAW,o0V,gg)){aDW.wxVkey=1
}
aDW.wxXCkey=1
return oBW
}
c8V.wxXCkey=2
_2z(z,5,h9V,e,s,gg,c8V,'item','index','index')
var tEW=_v()
_(o4V,tEW)
var eFW=function(oHW,bGW,xIW,gg){
var fKW=_v()
_(xIW,fKW)
if(_oz(z,10,oHW,bGW,gg)){fKW.wxVkey=1
}
fKW.wxXCkey=1
return xIW
}
tEW.wxXCkey=2
_2z(z,8,eFW,e,s,gg,tEW,'item','index','index')
var cLW=_v()
_(o4V,cLW)
var hMW=function(cOW,oNW,oPW,gg){
var aRW=_v()
_(oPW,aRW)
if(_oz(z,13,cOW,oNW,gg)){aRW.wxVkey=1
}
aRW.wxXCkey=1
return oPW
}
cLW.wxXCkey=2
_2z(z,11,hMW,e,s,gg,cLW,'item','index','index')
x5V.wxXCkey=1
o6V.wxXCkey=1
f7V.wxXCkey=1
_(b3V,o4V)
}
else{b3V.wxVkey=2
var tSW=_n('custo')
_(b3V,tSW)
}
b3V.wxXCkey=1
b3V.wxXCkey=3
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_85";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_85();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/financial/component.wxml'] = [$gwx_XC_85, './pages/financial/component.wxml'];else __wxAppCode__['pages/financial/component.wxml'] = $gwx_XC_85( './pages/financial/component.wxml' );
	;__wxRoute = "pages/financial/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/financial/component.js";define("pages/financial/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{titleList:{nav1:"收款记录",nav2:"提现记录",nav3:"付款记录",titleText:"已收款",titleText2:"已付款"},Collection:"",CollectionList:[],Uncollected:0,UncollectedList:[],type:"Allocation",count:"",moneyCount:"",identity:"供应商"},onLoad:function(t){},onReady:function(){},onShow:function(){if("服务商"==wx.getStorageSync("identity")&&this.setData({titleList:{nav1:"收款记录",nav2:"提现记录",nav3:"付款记录",titleText:"已收款",titleText2:"已付款"}}),"function"==typeof this.getTabBar&&this.getTabBar())if("服务商"==wx.getStorageSync("identity")){this.getTabBar().setData({list:[{pagePath:"/pages/order/component",text:"订单",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"供应商",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"财务",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],selected:2})}else if("代理商"==wx.getStorageSync("identity")){var t=[];"Salesman"==wx.getStorageSync("identityStatus")||"SalesDirector"==wx.getStorageSync("identityStatus")||"Sales"==wx.getStorageSync("identityStatus")?(t=[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:t,selected:1})):(t=[{pagePath:"/pages/order/component",text:"业绩",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/36.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/38.png"},{pagePath:"/pages/serProviders/component",text:"人员",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/40.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/12.png"},{pagePath:"/pages/financial/component",text:"客户",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/32.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/34.png"},{pagePath:"/pages/my/component",text:"我的",iconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/20.png",selectedIconPath:"http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/image/22.png"}],this.getTabBar().setData({list:t,selected:2})),this.setData({identityStatus:wx.getStorageSync("identityStatus")})}else this.getTabBar().setData({selected:2});var a=wx.getStorageSync("identity");this.setData({identity:a}),console.info("页面加载"),this.getGysdata()},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){},uplist:function(t){var a=wx.getStorageSync("identity"),e=t.currentTarget.dataset.type;"Allocation"==e?(this.setData({type:"Allocation"}),this.getGysdata()):"Withdrawals"==e?(this.setData({type:"Withdrawals"}),"服务商"==a?this.getWitfwsdata():this.getWitgysdata()):"ocation"==e&&(this.getFwsdata(),this.setData({type:"ocation"}))},getSkjl:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getSAllocationsCount",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid")},success:function(a){console.log(a);var e=(parseFloat(a.data.Collection)/100).toFixed(2),o=(parseFloat(a.data.Uncollected)/100).toFixed(2),n=a.data.SAllocationsList;console.log(e,o,n),n.forEach((function(t){t.amount=(t.amount/100).toFixed(2),0!=t.allocation_do.length&&t.allocation_do.forEach((function(t){t.amount=(t.amount/100).toFixed(2)}))})),t.setData({Collection:e,Uncollected:o,CollectionList:n})}})},getGysdata:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getSAllocationsCount",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{smember_id:wx.getStorageSync("uid")},success:function(a){console.log(a.data);var e=(parseFloat(a.data.Collection)/100).toFixed(2),o=(parseFloat(a.data.Uncollected)/100).toFixed(2),n=a.data.SAllocationsList;console.log(e,o,n),n.forEach((function(t){t.amount=(t.amount/100).toFixed(2),0!=t.allocation_do.length&&t.allocation_do.forEach((function(t){t.amount=(t.amount/100).toFixed(2)}))})),t.setData({Collection:e,Uncollected:o,CollectionList:n})}})},getFwsdata:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getFAllocationsCount",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssCreateBalanceAcct",timestamp:Date.parse(new Date)},data:{fmember_id:wx.getStorageSync("uid")},success:function(a){console.log(a);var e=(parseFloat(a.data.Collection)/100).toFixed(2),o=(parseFloat(a.data.Uncollected)/100).toFixed(2),n=a.data.FAllocationsList;n.forEach((function(t){t.amount=(t.amount/100).toFixed(2),0!=t.allocation_do.length&&t.allocation_do.forEach((function(t){t.amount=(t.amount/100).toFixed(2)}))})),t.setData({Collection:e,Uncollected:o,CollectionList:n})}}),wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getAllocationList",method:"post",success:function(a){t.setData({CollectionList:a.data})}})},getWitgysdata:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getWithdrawalsCount",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssCreateBalanceAcct",timestamp:Date.parse(new Date)},data:{shop_id:wx.getStorageSync("userShopid")},success:function(a){console.log(a);var e=(parseFloat(a.data.moneyCount)/100).toFixed(2),o=a.data.WithdrawalsList;o.forEach((function(t){t.amount=(t.amount/100).toFixed(2),t.withdrawals_do.forEach((function(t){t.amount=(t.amount/100).toFixed(2)}))})),t.setData({count:a.data.count,moneyCount:e,UncollectedList:o})}})},getWitfwsdata:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankBillAPI/getWithdrawalsCount",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssCreateBalanceAcct",timestamp:Date.parse(new Date)},data:{shop_id:wx.getStorageSync("userShopid")},method:"POST",success:function(a){console.log(a);var e=(parseFloat(a.data.moneyCount)/100).toFixed(2),o=a.data.WithdrawalsList;o.forEach((function(t){t.amount=(t.amount/100).toFixed(2),t.withdrawals_do.forEach((function(t){t.amount=(t.amount/100).toFixed(2)}))})),t.setData({count:a.data.count,moneyCount:e,UncollectedList:o})}})}});
},{isPage:true,isComponent:true,currentFile:'pages/financial/component.js'});require("pages/financial/component.js");