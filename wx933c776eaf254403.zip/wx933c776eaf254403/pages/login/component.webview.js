$gwx_XC_88=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_88 || [];
function gz$gwx_XC_88_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_88_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'box_5'])
Z([3,'userSubmit'])
Z([a,[3,'text-wrapper_2 '],[[2,'?:'],[[2,'=='],[[7],[3,'flag']],[1,true]],[1,'login-flag'],[1,'']]])
Z([3,'text_4'])
Z([3,'1'])
Z([3,'账密登录'])
Z([3,'telSubmit'])
Z([a,[3,'text-wrapper_3 '],[[2,'?:'],[[2,'=='],[[7],[3,'flag']],[1,false]],[1,'login-flag'],[1,'']]])
Z([3,'text_5'])
Z(z[5])
Z([3,'手机登录'])
Z([3,'box_6'])
Z([[2,'=='],[[7],[3,'flag']],[1,true]])
Z([3,'userinput'])
Z([3,''])
Z(z[15])
Z([3,'请输入账号'])
Z([3,'text'])
Z([[7],[3,'username']])
Z([3,'passinput'])
Z(z[15])
Z(z[15])
Z([3,'请输入密码'])
Z([3,'password'])
Z([[7],[3,'password']])
Z([[2,'=='],[[7],[3,'flag']],[1,false]])
Z([3,'tel'])
Z([3,'changetel'])
Z(z[15])
Z(z[15])
Z([3,'请输入手机号'])
Z(z[18])
Z([[7],[3,'tel']])
Z([3,'changesms'])
Z([3,'请输入验证码'])
Z(z[18])
Z([[7],[3,'sms']])
Z([[2,'?:'],[[7],[3,'status']],[1,''],[1,'phoneLogin']])
Z([3,'z-index: 999;'])
Z([a,[[7],[3,'codeText']]])
Z([3,'block_2'])
Z([3,'image-text_1'])
Z([3,'onChange'])
Z([[7],[3,'checked']])
Z([3,'text-group_1'])
Z([3,'text_8'])
Z(z[5])
Z([3,'已阅读并同意'])
Z([3,'toxiey'])
Z([3,'text_9'])
Z(z[5])
Z([3,'《服务协议》'])
Z([3,'goforgotPassword'])
Z([3,'text_10'])
Z(z[5])
Z([3,'忘记密码？'])
Z([3,'onClick'])
Z([3,'button_1'])
Z([3,'large'])
Z([3,'info'])
Z([3,'登录'])
Z([3,'tozhuce'])
Z([3,'text_12'])
Z(z[5])
Z([3,'还没账号？点击注册'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_88_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_88=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_88=true;
var x=['./pages/login/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_88_1()
var oVNB=_n('view')
_rz(z,oVNB,'class',0,e,s,gg)
var cWNB=_n('view')
_rz(z,cWNB,'class',1,e,s,gg)
var oXNB=_mz(z,'view',['bindtap',2,'class',1],[],e,s,gg)
var lYNB=_mz(z,'text',['class',4,'lines',1],[],e,s,gg)
var aZNB=_oz(z,6,e,s,gg)
_(lYNB,aZNB)
_(oXNB,lYNB)
_(cWNB,oXNB)
var t1NB=_mz(z,'view',['bindtap',7,'class',1],[],e,s,gg)
var e2NB=_mz(z,'text',['class',9,'lines',1],[],e,s,gg)
var b3NB=_oz(z,11,e,s,gg)
_(e2NB,b3NB)
_(t1NB,e2NB)
_(cWNB,t1NB)
_(oVNB,cWNB)
var o4NB=_n('view')
_rz(z,o4NB,'class',12,e,s,gg)
var x5NB=_v()
_(o4NB,x5NB)
if(_oz(z,13,e,s,gg)){x5NB.wxVkey=1
var f7NB=_n('view')
var c8NB=_mz(z,'input',['bindinput',14,'id',1,'name',2,'placeholder',3,'type',4,'value',5],[],e,s,gg)
_(f7NB,c8NB)
var h9NB=_mz(z,'input',['bindinput',20,'id',1,'name',2,'placeholder',3,'type',4,'value',5],[],e,s,gg)
_(f7NB,h9NB)
_(x5NB,f7NB)
}
var o6NB=_v()
_(o4NB,o6NB)
if(_oz(z,26,e,s,gg)){o6NB.wxVkey=1
var o0NB=_n('view')
_rz(z,o0NB,'class',27,e,s,gg)
var cAOB=_n('view')
var oBOB=_mz(z,'input',['bindinput',28,'id',1,'name',2,'placeholder',3,'type',4,'value',5],[],e,s,gg)
_(cAOB,oBOB)
_(o0NB,cAOB)
var lCOB=_n('view')
var aDOB=_mz(z,'input',['bindinput',34,'placeholder',1,'type',2,'value',3],[],e,s,gg)
_(lCOB,aDOB)
var tEOB=_mz(z,'text',['bindtap',38,'style',1],[],e,s,gg)
var eFOB=_oz(z,40,e,s,gg)
_(tEOB,eFOB)
_(lCOB,tEOB)
_(o0NB,lCOB)
_(o6NB,o0NB)
}
var bGOB=_n('view')
_rz(z,bGOB,'class',41,e,s,gg)
var oHOB=_n('view')
_rz(z,oHOB,'class',42,e,s,gg)
var xIOB=_mz(z,'van-checkbox',['bind:change',43,'value',1],[],e,s,gg)
_(oHOB,xIOB)
var oJOB=_n('view')
_rz(z,oJOB,'class',45,e,s,gg)
var fKOB=_mz(z,'text',['class',46,'lines',1],[],e,s,gg)
var cLOB=_oz(z,48,e,s,gg)
_(fKOB,cLOB)
_(oJOB,fKOB)
var hMOB=_mz(z,'text',['bindtap',49,'class',1,'lines',2],[],e,s,gg)
var oNOB=_oz(z,52,e,s,gg)
_(hMOB,oNOB)
_(oJOB,hMOB)
_(oHOB,oJOB)
_(bGOB,oHOB)
var cOOB=_mz(z,'text',['bindtap',53,'class',1,'lines',2],[],e,s,gg)
var oPOB=_oz(z,56,e,s,gg)
_(cOOB,oPOB)
_(bGOB,cOOB)
_(o4NB,bGOB)
var lQOB=_mz(z,'van-button',['bindtap',57,'class',1,'size',2,'type',3],[],e,s,gg)
var aROB=_oz(z,61,e,s,gg)
_(lQOB,aROB)
_(o4NB,lQOB)
var tSOB=_mz(z,'text',['bindtap',62,'class',1,'lines',2],[],e,s,gg)
var eTOB=_oz(z,65,e,s,gg)
_(tSOB,eTOB)
_(o4NB,tSOB)
x5NB.wxXCkey=1
o6NB.wxXCkey=1
_(oVNB,o4NB)
_(r,oVNB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_88";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_88();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/login/component.wxml'] = [$gwx_XC_88, './pages/login/component.wxml'];else __wxAppCode__['pages/login/component.wxml'] = $gwx_XC_88( './pages/login/component.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/login/component.wxss'] = setCssToHead([".",[1],"page{background-color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;overflow:hidden;position:relative;width:",[0,750],"}\nwx-van-checkbox{height:100%;width:100%}\n.",[1],"box_5{background:url(http://huitou-1255757638.cos.ap-shanghai.myqcloud.com/images/lanhu_1dengluye/SketchPngc12640c910b2fed2d81810a8e50ac1ab9d3598b4322a79666f21851eda4e0bd4.png) 100% no-repeat;background-size:contain;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,-1],";padding-top:",[0,444],";width:",[0,750],"}\n.",[1],"box_5,.",[1],"text-wrapper_2{display:-webkit-flex;display:flex}\n.",[1],"text-wrapper_2{-webkit-align-items:center;align-items:center;background-color:#f8f8f8;border-top-left-radius:",[0,10],";border-top-right-radius:",[0,10],";color:#666f83;-webkit-flex:1;flex:1;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;padding:",[0,21]," 0}\n.",[1],"text_4{font-family:PingFangSC-Medium;font-size:",[0,32],";line-height:",[0,40],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"text-wrapper_3{-webkit-align-items:center;align-items:center;background-color:#f8f8f8;border-top-left-radius:",[0,10],";border-top-right-radius:",[0,10],";color:#666f83;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;padding:",[0,21]," 0}\n.",[1],"text_5{font-family:PingFangSC-Regular;font-size:",[0,32],";line-height:",[0,40],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"box_6{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin:0 auto;padding:",[0,100]," 0 0}\n.",[1],"block_2{margin:",[0,45]," 0 0 ",[0,5],";width:",[0,600],"}\n.",[1],"block_2,.",[1],"image-text_1{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"image-text_1{width:",[0,286],"}\n.",[1],"checkbox_1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAACshmLzAAADJUlEQVRYCc1XPWgUQRSeN3fm9jhIJ+hhpUnhFUYCB1YSK/9AY6HNFRaioIVFQLlLQMNBzqB4hYVW6bTRQhBEwcJKCATlULhCE7UIF8EuEG4v5vb53u7OspedXfd+QtyDzOS9N+/75r2ZNzMgYn4Xn+PQyvfWCQutc0JADoXI0tD9AgXQrwFCNITAugT56tDB1PsXl2AzjmsaF/3l7+O+P1vmHbIqoMDhaGtHS4zWqfdsT9IoL92GX1FjQgmcfoSpxoY5Q4OnBGImykmoDmCDdNVsxph7cxNaOjstAZ71Zrv5ksJ7TDeoaxmIxaFE+oIuGgEC4w9aR9pb7dcEfqBroKgBIFYTycTZT7dSn/1mHQTcmS8NHFwhEgmKRN4fCal0nHM37IOduQLglqLKGIylxB4Be8ENKufKu64lDHdx21o7BU7ozeWeV7sOKEpGu2MoYYxwKuwI2Pu8160WAQQATa2asNzaIiRXODIqaA37EsICDc9R1fwR4qbA2JLLa9wKF+JII4aFWsm4WiulfwKIdxoDWo84zNjSqe06k15lDjiFH8fmzYeIeC3ME2PTGgAK06C+TnBhWVPRniEn3VMt2i6WtltwLgsiK+kvH6shH1h0sn0IUfrE3YPbgwnbK0Q+b16XFtCVyZJxnPL51BMGOj2Csx8QKPkyEfCpBChGZwGsyaJxWU+iD3AHY01SKQwlQFtl+milOacn0Tc4zV00KAVYVxPWtXoS/YM7WFiH8XnzZNuy3urA/TJajJXadHpmFlHeJdZqn/97q/m9dPYTUp4CLoffls3fXJk61cH/FAnWjFWa94hHMWgVT0K+1kdHjL32aUh5fkwErscZyiRod5gWYjmOfZgN+XlCEb3xfxzH7hWpGsZ2B+RVdS3zChFfnWlfLO4AWKdLwrCxXKmdAmWxq5dSJsFhSULiDEViVZEaWEs+2bcKvfLrpUAJPhZTX/jqPNB0OA+TPPtWOKoNEGAFs8xm0hN0WpSF87xS9t219lgos6/tM1eOOtaAEvpbXhe78jj1k+A+V8yvK60JENZ5KsSHEex7hLpL8PN8jc+Vbp/nfwHBLHOYw1RIPQAAAABJRU5ErkJggg\x3d\x3d) 100% no-repeat;background-size:100% 100%;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,32],";margin:",[0,2]," 0 ",[0,1],";width:",[0,32],"}\n.",[1],"text-group_1{font-family:PingFangSC-Light;font-size:",[0,0],";height:",[0,35],";line-height:",[0,35],";overflow-wrap:break-word;text-align:left;white-space:nowrap;width:",[0,240],"}\n.",[1],"text_8{color:#858b9c}\n.",[1],"text_8,.",[1],"text_9{font-family:PingFangSC-Light;font-size:",[0,24],";line-height:",[0,35],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"text_9{color:#547aa5}\n.",[1],"text_10{color:#888;font-family:PingFangSC-Medium;font-size:",[0,26],";line-height:",[0,30],";margin-top:",[0,3],";overflow-wrap:break-word;text-align:right;white-space:nowrap}\n.",[1],"button_1{-webkit-align-items:center;align-items:center;background-color:#2f86f6;border-radius:",[0,10],";color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;font-size:",[0,36],";height:",[0,80],";-webkit-justify-content:center;justify-content:center;line-height:",[0,80],";margin-top:",[0,40],";width:",[0,600],"}\n.",[1],"text_11{color:#fff;font-size:",[0,24],";text-align:center}\n.",[1],"text_11,.",[1],"text_12{font-family:PingFangSC-Medium;line-height:",[0,30],";overflow-wrap:break-word;white-space:nowrap}\n.",[1],"text_12{-webkit-align-self:center;align-self:center;color:#666f83;font-size:",[0,28],";font-weight:600;margin-top:",[0,36],";text-align:left}\n.",[1],"tel\x3ewx-view:nth-child(2){margin-bottom:",[0,20],";position:relative}\n.",[1],"tel\x3ewx-view:nth-child(2) wx-input{margin-bottom:0}\n.",[1],"tel\x3ewx-view:nth-child(2) wx-text{color:#2f86f6;font-size:",[0,24],";font-weight:500;padding:",[0,20]," 0;position:absolute;right:",[0,20],";text-align:center;top:",[0,6],"}\n.",[1],"box_6 wx-input{border:",[0,2]," solid #e4e4e4;border-radius:",[0,10],";box-sizing:border-box;color:#000;font-size:",[0,32],";font-weight:500;height:",[0,80],";margin-bottom:",[0,20],";padding-left:",[0,30],";width:",[0,600],"}\n.",[1],"box_6 wx-input::-webkit-input-placeholder{font-weight:400}\n.",[1],"box_6 wx-input::placeholder{font-weight:400}\n.",[1],"login-flag{background-color:#fff!important;color:#2f86f6!important}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/login/component.wxss:1:5044)",{path:"./pages/login/component.wxss"});
}