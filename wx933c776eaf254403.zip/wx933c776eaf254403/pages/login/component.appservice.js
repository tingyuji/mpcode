$gwx_XC_88=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_88 || [];
function gz$gwx_XC_88_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_88_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'box_6'])
Z([[2,'=='],[[7],[3,'flag']],[1,true]])
Z([[2,'=='],[[7],[3,'flag']],[1,false]])
Z([3,'onChange'])
Z([[7],[3,'checked']])
Z([3,'onClick'])
Z([3,'button_1'])
Z([3,'large'])
Z([3,'info'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_88_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_88_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_88=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_88=true;
var x=['./pages/login/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_88_1()
var a6W=_n('view')
_rz(z,a6W,'class',0,e,s,gg)
var t7W=_v()
_(a6W,t7W)
if(_oz(z,1,e,s,gg)){t7W.wxVkey=1
}
var e8W=_v()
_(a6W,e8W)
if(_oz(z,2,e,s,gg)){e8W.wxVkey=1
}
var b9W=_mz(z,'van-checkbox',['bind:change',3,'value',1],[],e,s,gg)
_(a6W,b9W)
var o0W=_mz(z,'van-button',['bindtap',5,'class',1,'size',2,'type',3],[],e,s,gg)
_(a6W,o0W)
t7W.wxXCkey=1
e8W.wxXCkey=1
_(r,a6W)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_88";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_88();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/login/component.wxml'] = [$gwx_XC_88, './pages/login/component.wxml'];else __wxAppCode__['pages/login/component.wxml'] = $gwx_XC_88( './pages/login/component.wxml' );
	;__wxRoute = "pages/login/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/login/component.js";define("pages/login/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{},data:{my_header:{},checked:!1,tel:"",flag:!0,username:"",password:"",sms:"",codeText:"获取验证码",status:!1,sended:!1},lifetimes:{created:function(){if(wx.getStorageSync("uid"))return wx.reLaunch({url:"/pages/order/component"}),!1;this.wxSilentLogin().then((function(e){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getOpenId",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{code:e},success:function(e){wx.setStorageSync("openid",e.data)},fail:function(e){wx.showModal({content:e})}})})).catch((function(e){wx.showModal({content:e})}))},attached:function(){console.info("页面加载")},detached:function(){console.info("页面卸载")}},methods:{onChange:function(e){console.log(e),this.setData({checked:e.detail})},onClick:function(){var e=this;if(!this.data.checked)return wx.showToast({icon:"none",title:"需同意服务协议后再使用登录服务"});this.wxSilentLogin().then((function(t){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getOpenId",method:"get",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{code:t},success:function(t){if(wx.removeStorageSync("checkedSupplier"),wx.removeStorageSync("company_name"),wx.setStorageSync("openid",t.data),1==e.data.flag)wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/login",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{openid:t.data,username:e.data.username,password:e.data.password},success:function(t){e.getUserinfo(t.data.uid),wx.setStorageSync("uid",t.data.uid),wx.setStorageSync("sid",t.data.sales_id),t.data.uid?wx.showModal({content:"登录成功",success:function(e){wx.reLaunch({url:"/pages/order/component"})}}):wx.showToast({icon:"error",title:t.data.message})},fail:function(e){wx.showModal({content:e})}});else{console.log(e.data);var a=e.data.sms.toString();wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/login/"+e.data.tel,header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"post",data:{openid:t.data,sms_code:a},success:function(t){console.log(t),e.getUserinfo(t.data.uid),wx.setStorageSync("uid",t.data.uid),wx.setStorageSync("sid",t.data.sales_id),"登录成功"==t.data.message?wx.showModal({content:"登录成功",success:function(e){wx.reLaunch({url:"/pages/order/component"})}}):wx.showModal({content:t.data.message})},fail:function(e){wx.showModal({content:e})}})}},fail:function(e){wx.showModal({content:e})}})})).catch((function(e){wx.showModal({content:e})}))},getUserinfo:function(e){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/"+e,method:"get",success:function(e){wx.setStorageSync("disables",e.data.disables),wx.setStorageSync("apply_state",e.data.apply_state),wx.setStorageSync("userShopid",e.data.shop_id),"Facilitator"==e.data.identity?wx.setStorageSync("identity","服务商"):wx.setStorageSync("identity","供应商"),wx.setStorageSync("username",e.data.uname)}})},setitem:function(){var e=this,t=60,a=setInterval((function(){t--,e.setData({codeText:t+"秒后重新发送",status:!0}),0==t&&(e.setData({codeText:"获取验证码",status:!1,sended:!1}),t=60,clearInterval(a))}),1e3)},goforgotPassword:function(){wx.navigateTo({url:"/pages/forgotPassword/component"})},wxGetUserProfile:function(){return new Promise((function(e,t){wx.getUserProfile({lang:"zh_CN",desc:"用户登录",success:function(t){console.log(t),wx.setStorageSync("wxUserInfo",t.userInfo),e(t)},fail:function(e){t(e)}})}))},wxSilentLogin:function(){return new Promise((function(e,t){wx.login({success:function(t){e(t.code)},fail:function(e){t(e)}})}))},tozhuce:function(){wx.getUserProfile({desc:"desc",success:function(e){wx.setStorageSync("userData",e.userInfo),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getUserInfo",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"post",data:{open_id:wx.getStorageSync("openid"),nick_name:e.userInfo.nickName,head_img_url:e.userInfo.avatarUrl},success:function(e){wx.navigateTo({url:"/pages/zhuce/component"})},fail:function(e){wx.showModal({content:e})}})},fail:function(e){wx.showModal({content:e})}})},getidentity:function(e){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/"+e,method:"get",success:function(e){console.log(e)}})},userSubmit:function(){console.log(1),this.setData({flag:!0})},telSubmit:function(){console.log(2),this.setData({flag:!1})},phoneLogin:function(){var e=this;return/^[1][3,4,5,7,8,9][0-9]{9}$/.test(this.data.tel)?!this.data.sended&&(this.setData({sended:!0}),void wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/smscode/"+this.data.tel,method:"get",success:function(t){5!=t.data?(wx.showToast({title:t.data.message}),e.setData({sended:!1})):e.setitem()},fail:function(){e.setData({sended:!1})}})):(wx.showToast({title:"手机号错误",icon:"error"}),!1)},getTelCode:function(){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/api/smscode/"+this.data.tel,method:"POST",header:{},success:function(e){console.log(e)}})},changetel:function(e){this.setData({tel:e.detail.value})},changesms:function(e){console.log(e),this.setData({sms:e.detail.value})},userinput:function(e){this.setData({username:e.detail.value})},passinput:function(e){this.setData({password:e.detail.value})},toxiey:function(){wx.navigateTo({url:"/pages/xiey/component"})}}});
},{isPage:true,isComponent:true,currentFile:'pages/login/component.js'});require("pages/login/component.js");