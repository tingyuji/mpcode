Component({
    properties: {},
    data: {
        my_header: {},
        checked: !1,
        tel: "",
        flag: !0,
        username: "",
        password: "",
        sms: "",
        codeText: "获取验证码",
        status: !1,
        sended: !1
    },
    lifetimes: {
        created: function() {
            if (wx.getStorageSync("uid")) return wx.reLaunch({
                url: "/pages/order/component"
            }), !1;
            this.wxSilentLogin().then(function(e) {
                wx.request({
                    url: "https://api.seller.hhtt168.com/seller/applet/api/getOpenId",
                    method: "get",
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                    },
                    data: {
                        code: e
                    },
                    success: function(e) {
                        wx.setStorageSync("openid", e.data);
                    },
                    fail: function(e) {
                        wx.showModal({
                            content: e
                        });
                    }
                });
            }).catch(function(e) {
                wx.showModal({
                    content: e
                });
            });
        },
        attached: function() {
            console.info("页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        onChange: function(e) {
            console.log(e), this.setData({
                checked: e.detail
            });
        },
        onClick: function() {
            var e = this;
            if (!this.data.checked) return wx.showToast({
                icon: "none",
                title: "需同意服务协议后再使用登录服务"
            });
            this.wxSilentLogin().then(function(t) {
                wx.request({
                    url: "https://api.seller.hhtt168.com/seller/applet/api/getOpenId",
                    method: "get",
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                    },
                    data: {
                        code: t
                    },
                    success: function(t) {
                        if (wx.removeStorageSync("checkedSupplier"), wx.removeStorageSync("company_name"), 
                        wx.setStorageSync("openid", t.data), 1 == e.data.flag) wx.request({
                            url: "https://api.seller.hhtt168.com/seller/applet/api/login",
                            method: "POST",
                            header: {
                                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                                dataType: "json"
                            },
                            data: {
                                openid: t.data,
                                username: e.data.username,
                                password: e.data.password
                            },
                            success: function(t) {
                                e.getUserinfo(t.data.uid), wx.setStorageSync("uid", t.data.uid), wx.setStorageSync("sid", t.data.sales_id), 
                                t.data.uid ? wx.showModal({
                                    content: "登录成功",
                                    success: function(e) {
                                        wx.reLaunch({
                                            url: "/pages/order/component"
                                        });
                                    }
                                }) : wx.showToast({
                                    icon: "error",
                                    title: t.data.message
                                });
                            },
                            fail: function(e) {
                                wx.showModal({
                                    content: e
                                });
                            }
                        }); else {
                            console.log(e.data);
                            var a = e.data.sms.toString();
                            wx.request({
                                url: "https://api.seller.hhtt168.com/seller/applet/api/login/" + e.data.tel,
                                header: {
                                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                                },
                                method: "post",
                                data: {
                                    openid: t.data,
                                    sms_code: a
                                },
                                success: function(t) {
                                    console.log(t), e.getUserinfo(t.data.uid), wx.setStorageSync("uid", t.data.uid), 
                                    wx.setStorageSync("sid", t.data.sales_id), "登录成功" == t.data.message ? wx.showModal({
                                        content: "登录成功",
                                        success: function(e) {
                                            wx.reLaunch({
                                                url: "/pages/order/component"
                                            });
                                        }
                                    }) : wx.showModal({
                                        content: t.data.message
                                    });
                                },
                                fail: function(e) {
                                    wx.showModal({
                                        content: e
                                    });
                                }
                            });
                        }
                    },
                    fail: function(e) {
                        wx.showModal({
                            content: e
                        });
                    }
                });
            }).catch(function(e) {
                wx.showModal({
                    content: e
                });
            });
        },
        getUserinfo: function(e) {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/" + e,
                method: "get",
                success: function(e) {
                    wx.setStorageSync("disables", e.data.disables), wx.setStorageSync("apply_state", e.data.apply_state), 
                    wx.setStorageSync("userShopid", e.data.shop_id), "Facilitator" == e.data.identity ? wx.setStorageSync("identity", "服务商") : wx.setStorageSync("identity", "供应商"), 
                    wx.setStorageSync("username", e.data.uname);
                }
            });
        },
        setitem: function() {
            var e = this, t = 60, a = setInterval(function() {
                t--, e.setData({
                    codeText: t + "秒后重新发送",
                    status: !0
                }), 0 == t && (e.setData({
                    codeText: "获取验证码",
                    status: !1,
                    sended: !1
                }), t = 60, clearInterval(a));
            }, 1e3);
        },
        goforgotPassword: function() {
            wx.navigateTo({
                url: "/pages/forgotPassword/component"
            });
        },
        wxGetUserProfile: function() {
            return new Promise(function(e, t) {
                wx.getUserProfile({
                    lang: "zh_CN",
                    desc: "用户登录",
                    success: function(t) {
                        console.log(t), wx.setStorageSync("wxUserInfo", t.userInfo), e(t);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        },
        wxSilentLogin: function() {
            return new Promise(function(e, t) {
                wx.login({
                    success: function(t) {
                        e(t.code);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        },
        tozhuce: function() {
            wx.getUserProfile({
                desc: "desc",
                success: function(e) {
                    wx.setStorageSync("userData", e.userInfo), wx.request({
                        url: "https://api.seller.hhtt168.com/seller/applet/api/getUserInfo",
                        header: {
                            "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                        },
                        method: "post",
                        data: {
                            open_id: wx.getStorageSync("openid"),
                            nick_name: e.userInfo.nickName,
                            head_img_url: e.userInfo.avatarUrl
                        },
                        success: function(e) {
                            wx.navigateTo({
                                url: "/pages/zhuce/component"
                            });
                        },
                        fail: function(e) {
                            wx.showModal({
                                content: e
                            });
                        }
                    });
                },
                fail: function(e) {
                    wx.showModal({
                        content: e
                    });
                }
            });
        },
        getidentity: function(e) {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/getMemberInfo/" + e,
                method: "get",
                success: function(e) {
                    console.log(e);
                }
            });
        },
        userSubmit: function() {
            console.log(1), this.setData({
                flag: !0
            });
        },
        telSubmit: function() {
            console.log(2), this.setData({
                flag: !1
            });
        },
        phoneLogin: function() {
            var e = this;
            return /^[1][3,4,5,7,8,9][0-9]{9}$/.test(this.data.tel) ? !this.data.sended && (this.setData({
                sended: !0
            }), void wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/smscode/" + this.data.tel,
                method: "get",
                success: function(t) {
                    5 != t.data ? (wx.showToast({
                        title: t.data.message
                    }), e.setData({
                        sended: !1
                    })) : e.setitem();
                },
                fail: function() {
                    e.setData({
                        sended: !1
                    });
                }
            })) : (wx.showToast({
                title: "手机号错误",
                icon: "error"
            }), !1);
        },
        getTelCode: function() {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/api/smscode/" + this.data.tel,
                method: "POST",
                header: {},
                success: function(e) {
                    console.log(e);
                }
            });
        },
        changetel: function(e) {
            this.setData({
                tel: e.detail.value
            });
        },
        changesms: function(e) {
            console.log(e), this.setData({
                sms: e.detail.value
            });
        },
        userinput: function(e) {
            this.setData({
                username: e.detail.value
            });
        },
        passinput: function(e) {
            this.setData({
                password: e.detail.value
            });
        },
        toxiey: function() {
            wx.navigateTo({
                url: "/pages/xiey/component"
            });
        }
    }
});