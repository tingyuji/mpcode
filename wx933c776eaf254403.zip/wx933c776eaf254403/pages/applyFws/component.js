Component({
    properties: {},
    data: {},
    lifetimes: {
        created: function() {},
        attached: function() {
            console.info("服务商申请页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        onClick: function() {
            var e = wx.getStorageSync("uid");
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getApplySupplierInfo/" + e,
                method: "GET",
                success: function(e) {
                    console.log(e), "success" == e.data ? wx.reLaunch({
                        url: "/pages/applyOk/component"
                    }) : wx.showModal({
                        content: e.data
                    });
                }
            });
        },
        goup: function() {
            wx.navigateTo({
                url: "/pages/switchStatus/component"
            });
        }
    }
});