var t = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../miniprogram_npm/@vant/weapp/dialog/dialog"));

Page({
    data: {
        id: 0,
        imgList: "",
        shopInfo: {},
        identity: "供应商",
        priceName: "应收金额"
    },
    onLoad: function(t) {
        var e = this;
        console.log(t), this.setData({
            id: t.id,
            identity: wx.getStorageSync("identity")
        }), wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(t) {
                var a = t.data.imgUrl && t.data.imgUrl.length > 0 ? t.data.imgUrl : [ {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                }, {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                }, {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                } ];
                t.data.orderInfo.time = t.data.orderInfo.created_time;
                var o = t.data.orderInfo.state;
                "OrderAdd" == o ? t.data.orderInfo.status = "待确认" : "Wrong" == o ? t.data.orderInfo.status = "信息有误" : "OrderUpdate" == o ? t.data.orderInfo.status = "待确认" : "Confirm" == o ? t.data.orderInfo.status = "已确认" : "ApplyCancel" == o ? t.data.orderInfo.status = "作废请求" : "Cancel" == o && (t.data.orderInfo.status = "作废"), 
                "ReturnOrder" == t.data.orderInfo.order_type && e.setData({
                    priceName: "应退金额"
                }), e.setData({
                    imgList: a[0].attachment_path,
                    shopInfo: t.data.orderInfo
                });
            }
        });
    },
    timeFormatter: function(t) {
        if (!t) return t;
        var e = t.substr(0, 10) + " " + t.substring(11, 13) + ":" + t.substring(14, 16) + ":" + t.substring(17, 19);
        return e = e.replace(/-/g, "/"), e = new Date(e), e = (e = new Date(e.getTime() + 288e5)).getFullYear() + "-" + (e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-" + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate()) + " " + (e.getHours() < 10 ? "0" + e.getHours() : e.getHours()) + ":" + (e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":" + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
    },
    upshow: function() {
        var t = this;
        wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/" + this.data.id,
            method: "get",
            success: function(e) {
                var a = e.data.imgUrl && e.data.imgUrl.length > 0 ? e.data.imgUrl : [ {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                }, {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                }, {
                    attachment_path: "https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"
                } ];
                e.data.orderInfo.time = t.timeFormatter(e.data.orderInfo.created_time), t.setData({
                    imgList: a[0].attachment_path,
                    shopInfo: e.data.orderInfo
                });
            }
        });
    },
    fmemberDetail: function(t) {
        if ("供应商" == this.data.identity) {
            var e = t.currentTarget.dataset.id.facilitator_id;
            wx.navigateTo({
                url: "/pages/serproDetail/component?id=" + e
            });
        } else {
            var a = t.currentTarget.dataset.id.supplier_id;
            wx.navigateTo({
                url: "/pagesB/gys_detail/component?id=" + a
            });
        }
    },
    onClick: function(e) {
        var a = this, o = e.currentTarget.dataset.type;
        "Confirm" == o ? t.default.confirm({
            title: "警告",
            message: "是否确认订单"
        }).then(function() {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + a.data.id,
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                },
                data: {
                    state: "Confirm"
                },
                success: function(t) {
                    wx.showToast({
                        title: "操作成功"
                    }), a.upshow();
                }
            });
        }).catch(function() {}) : "Wrong" == o ? wx.request({
            url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + this.data.id,
            method: "post",
            header: {
                "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            data: {
                state: "Wrong"
            },
            success: function(t) {
                wx.showToast({
                    title: "操作成功"
                }), a.upshow();
            }
        }) : "Cancel" == o ? t.default.confirm({
            title: "警告",
            message: "是否作废订单"
        }).then(function() {
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/" + a.data.id,
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                },
                data: {
                    state: "Cancel"
                },
                success: function(t) {
                    wx.showToast({
                        title: "操作成功"
                    }), a.upshow();
                }
            });
        }).catch(function() {}) : "OrderUpdate" == o && wx.navigateTo({
            url: "/pagesA/editorder/component?id=" + this.data.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});