$gwx_XC_92=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_92 || [];
function gz$gwx_XC_92_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_92_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_92_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_92_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'identity']],[1,'供应商']],[[2,'||'],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'OrderAdd']],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'OrderUpdate']]]])
Z([[2,'||'],[[2,'||'],[[2,'&&'],[[2,'=='],[[7],[3,'identity']],[1,'供应商']],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'Wrong']]],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'Confirm']]],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'Cancel']]])
Z([[2,'&&'],[[2,'=='],[[7],[3,'identity']],[1,'服务商']],[[2,'||'],[[2,'||'],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'Wrong']],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'OrderAdd']]],[[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'OrderUpdate']]]])
Z([[2,'=='],[[6],[[7],[3,'shopInfo']],[3,'state']],[1,'Wrong']])
Z([3,'van-dialog'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_92_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_92_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_92=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_92=true;
var x=['./pages/orderDetail/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_92_1()
var aPY=_n('view')
_rz(z,aPY,'class',0,e,s,gg)
var tQY=_v()
_(aPY,tQY)
if(_oz(z,1,e,s,gg)){tQY.wxVkey=1
}
var eRY=_v()
_(aPY,eRY)
if(_oz(z,2,e,s,gg)){eRY.wxVkey=1
}
var bSY=_v()
_(aPY,bSY)
if(_oz(z,3,e,s,gg)){bSY.wxVkey=1
var oTY=_v()
_(bSY,oTY)
if(_oz(z,4,e,s,gg)){oTY.wxVkey=1
}
oTY.wxXCkey=1
}
var xUY=_n('van-dialog')
_rz(z,xUY,'id',5,e,s,gg)
_(aPY,xUY)
tQY.wxXCkey=1
eRY.wxXCkey=1
bSY.wxXCkey=1
_(r,aPY)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_92";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_92();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/orderDetail/component.wxml'] = [$gwx_XC_92, './pages/orderDetail/component.wxml'];else __wxAppCode__['pages/orderDetail/component.wxml'] = $gwx_XC_92( './pages/orderDetail/component.wxml' );
	;__wxRoute = "pages/orderDetail/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/orderDetail/component.js";define("pages/orderDetail/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=(0,require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../miniprogram_npm/@vant/weapp/dialog/dialog"));Page({data:{id:0,imgList:"",shopInfo:{},identity:"供应商",priceName:"应收金额"},onLoad:function(t){var e=this;console.log(t),this.setData({id:t.id,identity:wx.getStorageSync("identity")}),wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/"+this.data.id,method:"get",success:function(t){var a=t.data.imgUrl&&t.data.imgUrl.length>0?t.data.imgUrl:[{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"},{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"},{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"}];t.data.orderInfo.time=t.data.orderInfo.created_time;var o=t.data.orderInfo.state;"OrderAdd"==o?t.data.orderInfo.status="待确认":"Wrong"==o?t.data.orderInfo.status="信息有误":"OrderUpdate"==o?t.data.orderInfo.status="待确认":"Confirm"==o?t.data.orderInfo.status="已确认":"ApplyCancel"==o?t.data.orderInfo.status="作废请求":"Cancel"==o&&(t.data.orderInfo.status="作废"),"ReturnOrder"==t.data.orderInfo.order_type&&e.setData({priceName:"应退金额"}),e.setData({imgList:a[0].attachment_path,shopInfo:t.data.orderInfo})}})},timeFormatter:function(t){if(!t)return t;var e=t.substr(0,10)+" "+t.substring(11,13)+":"+t.substring(14,16)+":"+t.substring(17,19);return e=e.replace(/-/g,"/"),e=new Date(e),e=(e=new Date(e.getTime()+288e5)).getFullYear()+"-"+(e.getMonth()+1<10?"0"+(e.getMonth()+1):e.getMonth()+1)+"-"+(e.getDate()<10?"0"+e.getDate():e.getDate())+" "+(e.getHours()<10?"0"+e.getHours():e.getHours())+":"+(e.getMinutes()<10?"0"+e.getMinutes():e.getMinutes())+":"+(e.getSeconds()<10?"0"+e.getSeconds():e.getSeconds())},upshow:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getOrderInfo/"+this.data.id,method:"get",success:function(e){var a=e.data.imgUrl&&e.data.imgUrl.length>0?e.data.imgUrl:[{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"},{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"},{attachment_path:"https://huitou-1255757638.cos.ap-shanghai.myqcloud.com/imgnormal/logo.png"}];e.data.orderInfo.time=t.timeFormatter(e.data.orderInfo.created_time),t.setData({imgList:a[0].attachment_path,shopInfo:e.data.orderInfo})}})},fmemberDetail:function(t){if("供应商"==this.data.identity){var e=t.currentTarget.dataset.id.facilitator_id;wx.navigateTo({url:"/pages/serproDetail/component?id="+e})}else{var a=t.currentTarget.dataset.id.supplier_id;wx.navigateTo({url:"/pagesB/gys_detail/component?id="+a})}},onClick:function(e){var a=this,o=e.currentTarget.dataset.type;"Confirm"==o?t.default.confirm({title:"警告",message:"是否确认订单"}).then((function(){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/"+a.data.id,method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{state:"Confirm"},success:function(t){wx.showToast({title:"操作成功"}),a.upshow()}})})).catch((function(){})):"Wrong"==o?wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/"+this.data.id,method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{state:"Wrong"},success:function(t){wx.showToast({title:"操作成功"}),a.upshow()}}):"Cancel"==o?t.default.confirm({title:"警告",message:"是否作废订单"}).then((function(){wx.request({url:"https://api.seller.hhtt168.com/seller/applet/SupplierAPI/getSupplierOrder/"+a.data.id,method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},data:{state:"Cancel"},success:function(t){wx.showToast({title:"操作成功"}),a.upshow()}})})).catch((function(){})):"OrderUpdate"==o&&wx.navigateTo({url:"/pagesA/editorder/component?id="+this.data.id})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/orderDetail/component.js'});require("pages/orderDetail/component.js");