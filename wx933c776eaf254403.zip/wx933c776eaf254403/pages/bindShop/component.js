Component({
    properties: {},
    data: {
        serviceFee: 0,
        rechargeRecordList: [],
        showSheet: !1,
        actions: [ {
            name: "抖音",
            id: "qy"
        }, {
            name: "快手",
            id: "gr"
        } ]
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            wx.getStorageSync("userShopid"), wx.getStorageSync("semberShopid");
            this.fetchList(), console.info("页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        fetchList: function() {
            var e = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getRechargeRecordList/" + wx.getStorageSync("uid"),
                method: "get",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    smember_id: wx.getStorageSync("uid"),
                    order_type: this.data.type
                },
                success: function(t) {
                    e.setData({
                        serviceFee: t.data.serviceFee,
                        rechargeRecordList: t.data.rechargeRecordList
                    });
                }
            });
        },
        toShopDetail: function() {
            wx.navigateTo({
                url: "/pages/shopInfo/component"
            });
        },
        bindShop: function() {
            this.setData({
                showSheet: !0
            });
        },
        onClose: function() {
            this.setData({
                showSheet: !1
            });
        }
    }
});