var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../miniprogram_npm/@vant/weapp/toast/toast"));

Component({
    properties: {},
    data: {
        business_license_company_name: "",
        organization_cert_number: "",
        legal_person_id_card_name: "",
        business_license_company_address: "",
        business_license_valid_time: "",
        business_license_copy: "",
        business_license_number: "",
        organization_cert_valid_time: "",
        images: "",
        baseImg: "",
        imagesName: "",
        timerange: ""
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            console.info("页面加载");
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        nextStep: function() {
            if ("" == this.data.business_license_company_name || "" == this.data.organization_cert_number || "" == this.data.legal_person_id_card_name || "" == this.data.business_license_company_address || "" == this.data.business_license_valid_time) e.default.fail("请填写完整"); else {
                var a = {
                    business_license_company_name: this.data.business_license_company_name,
                    organization_cert_number: this.data.organization_cert_number,
                    legal_person_id_card_name: this.data.legal_person_id_card_name,
                    business_license_company_address: this.data.business_license_company_address,
                    business_license_valid_time: this.data.business_license_valid_time,
                    business_license_copy: this.data.business_license_copy,
                    business_license_number: this.data.business_license_number,
                    organization_cert_valid_time: this.data.timerange
                };
                wx.setStorageSync("enterprise", a), wx.navigateTo({
                    url: "/pages/EnterFication2/component"
                });
            }
        },
        upimage: function() {
            var e = this, a = this;
            wx.chooseMedia({
                count: 1,
                mediaType: [ "image" ],
                sizeType: [ "original", "compressed" ],
                sourceType: [ "album", "camera" ],
                success: function(s) {
                    if (console.log(s), s.tempFiles[0].size > 2097152) return wx.showToast({
                        title: "图片超过2M",
                        icon: "error"
                    }), !1;
                    var i = s.tempFiles[0].tempFilePath, n = i.length - 12, t = i.length, o = i.slice(n, t), c = s.tempFiles[0].tempFilePath;
                    e.setData({
                        images: c,
                        imagesName: o
                    }), wx.showToast({
                        title: "上传中",
                        icon: "loading",
                        duration: 4e3
                    }), wx.uploadFile({
                        name: "file",
                        filePath: c,
                        url: "https://api.base.hhtt168.com/uploaders",
                        method: "POST",
                        formData: {
                            file: c,
                            scene: "CUS"
                        },
                        success: function(e) {
                            var s = JSON.parse(e.data).url;
                            a.upCont(s), wx.request({
                                url: "https://api.seller.hhtt168.com/seller/shops/ocr/getTCAVerifyBasicBizLicense",
                                header: {
                                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
                                },
                                method: "POST",
                                data: {
                                    imageUrl: s
                                },
                                success: function(e) {
                                    var s = JSON.parse(e.data.license);
                                    console.log(s);
                                    var i = s.Period.split("至"), n = i[0].replace("年", "-");
                                    n = (n = n.replace("月", "-")).replace("日", "");
                                    var t = i[1];
                                    "长期" != t && (t = (t = (t = t.replace("年", "-")).replace("月", "-")).replace("日", "")), 
                                    console.log(n), console.log(i), a.setData({
                                        business_license_company_name: s.Name,
                                        organization_cert_number: s.RegNum,
                                        organization_cert_valid_time: "".concat(n, ",").concat(t),
                                        legal_person_id_card_name: s.Person,
                                        business_license_company_address: s.Address,
                                        business_license_number: s.RegNum,
                                        business_license_valid_time: "".concat(n, ",").concat(t),
                                        timerange: "".concat(n, ",").concat(t)
                                    });
                                }
                            });
                        }
                    });
                }
            });
        },
        conversionAddress: function() {
            var e = this;
            "" !== e.data.images ? wx.getFileSystemManager().readFile({
                filePath: e.data.images,
                encoding: "base64",
                success: function(a) {
                    e.data.baseImg = a.data, e.upCont(e.data.baseImg, e.data.images);
                }
            }) : wx.showToast({
                title: "请先选择图片！"
            });
        },
        upCont: function(e) {
            var a = this;
            return wx.request({
                url: "https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",
                method: "POST",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json",
                    transCode: "szbank_ssUploadImages",
                    timestamp: Date.parse(new Date())
                },
                data: {
                    file_name: "1234.jpg",
                    file: e
                },
                success: function(e) {
                    "" != e.data && a.setData({
                        business_license_copy: e.data
                    });
                }
            }), !1;
        }
    }
});