$gwx_XC_75=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_75 || [];
function gz$gwx_XC_75_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'van-toast'])
Z([3,'wrapper'])
Z([3,'upimage'])
Z([3,'group_3'])
Z([[2,'=='],[[7],[3,'images']],[1,'']])
Z([[2,'!='],[[7],[3,'images']],[1,'']])
Z([3,'企业名称'])
Z([[7],[3,'business_license_company_name']])
Z(z[7])
Z([3,'企业代码'])
Z([[7],[3,'organization_cert_number']])
Z(z[10])
Z([3,'机构有效期'])
Z([[7],[3,'timerange']])
Z([3,'xxxx-xx-xx,xxxx-xx-xx'])
Z([3,'textarea'])
Z([3,'法人姓名'])
Z([[7],[3,'legal_person_id_card_name']])
Z(z[17])
Z([3,'注册地址'])
Z([[7],[3,'business_license_company_address']])
Z(z[20])
Z([3,'统一社会信用代码'])
Z([[7],[3,'business_license_number']])
Z(z[23])
Z([3,'经营期限'])
Z(z[14])
Z(z[26])
Z(z[16])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_75=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_75=true;
var x=['./pages/Enterprisecertification/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_75_1()
var hWT=_n('view')
_rz(z,hWT,'class',0,e,s,gg)
var oXT=_n('van-toast')
_rz(z,oXT,'id',1,e,s,gg)
_(hWT,oXT)
var cYT=_n('view')
_rz(z,cYT,'class',2,e,s,gg)
var oZT=_mz(z,'view',['bindtap',3,'class',1],[],e,s,gg)
var l1T=_v()
_(oZT,l1T)
if(_oz(z,5,e,s,gg)){l1T.wxVkey=1
}
var a2T=_v()
_(oZT,a2T)
if(_oz(z,6,e,s,gg)){a2T.wxVkey=1
}
l1T.wxXCkey=1
a2T.wxXCkey=1
_(cYT,oZT)
var t3T=_mz(z,'van-field',['label',7,'value',1,'placeholder',2],[],e,s,gg)
t3T.rawAttr={"model:value":"{{ business_license_company_name }}",};_(cYT,t3T)
var e4T=_mz(z,'van-field',['label',10,'value',1,'placeholder',2],[],e,s,gg)
e4T.rawAttr={"model:value":"{{ organization_cert_number }}",};_(cYT,e4T)
var b5T=_mz(z,'van-field',['label',13,'value',1,'placeholder',2,'type',3],[],e,s,gg)
b5T.rawAttr={"model:value":"{{ timerange }}",};_(cYT,b5T)
var o6T=_mz(z,'van-field',['label',17,'value',1,'placeholder',2],[],e,s,gg)
o6T.rawAttr={"model:value":"{{ legal_person_id_card_name }}",};_(cYT,o6T)
var x7T=_mz(z,'van-field',['label',20,'value',1,'placeholder',2],[],e,s,gg)
x7T.rawAttr={"model:value":"{{ business_license_company_address }}",};_(cYT,x7T)
var o8T=_mz(z,'van-field',['label',23,'value',1,'placeholder',2],[],e,s,gg)
o8T.rawAttr={"model:value":"{{ business_license_number }}",};_(cYT,o8T)
var f9T=_mz(z,'van-field',['label',26,'value',1,'placeholder',2,'type',3],[],e,s,gg)
f9T.rawAttr={"model:value":"{{ timerange }}",};_(cYT,f9T)
_(hWT,cYT)
_(r,hWT)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_75";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_75();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/Enterprisecertification/component.wxml'] = [$gwx_XC_75, './pages/Enterprisecertification/component.wxml'];else __wxAppCode__['pages/Enterprisecertification/component.wxml'] = $gwx_XC_75( './pages/Enterprisecertification/component.wxml' );
	;__wxRoute = "pages/Enterprisecertification/component";__wxRouteBegin = true;__wxAppCurrentFile__="pages/Enterprisecertification/component.js";define("pages/Enterprisecertification/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=(0,require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../miniprogram_npm/@vant/weapp/toast/toast"));Component({properties:{},data:{business_license_company_name:"",organization_cert_number:"",legal_person_id_card_name:"",business_license_company_address:"",business_license_valid_time:"",business_license_copy:"",business_license_number:"",organization_cert_valid_time:"",images:"",baseImg:"",imagesName:"",timerange:""},lifetimes:{created:function(){},attached:function(){console.info("页面加载")},detached:function(){console.info("页面卸载")}},methods:{nextStep:function(){if(""==this.data.business_license_company_name||""==this.data.organization_cert_number||""==this.data.legal_person_id_card_name||""==this.data.business_license_company_address||""==this.data.business_license_valid_time)e.default.fail("请填写完整");else{var a={business_license_company_name:this.data.business_license_company_name,organization_cert_number:this.data.organization_cert_number,legal_person_id_card_name:this.data.legal_person_id_card_name,business_license_company_address:this.data.business_license_company_address,business_license_valid_time:this.data.business_license_valid_time,business_license_copy:this.data.business_license_copy,business_license_number:this.data.business_license_number,organization_cert_valid_time:this.data.timerange};wx.setStorageSync("enterprise",a),wx.navigateTo({url:"/pages/EnterFication2/component"})}},upimage:function(){var e=this,a=this;wx.chooseMedia({count:1,mediaType:["image"],sizeType:["original","compressed"],sourceType:["album","camera"],success:function(s){if(console.log(s),s.tempFiles[0].size>2097152)return wx.showToast({title:"图片超过2M",icon:"error"}),!1;var i=s.tempFiles[0].tempFilePath,n=i.length-12,t=i.length,o=i.slice(n,t),c=s.tempFiles[0].tempFilePath;e.setData({images:c,imagesName:o}),wx.showToast({title:"上传中",icon:"loading",duration:4e3}),wx.uploadFile({name:"file",filePath:c,url:"https://api.base.hhtt168.com/uploaders",method:"POST",formData:{file:c,scene:"CUS"},success:function(e){var s=JSON.parse(e.data).url;a.upCont(s),wx.request({url:"https://api.seller.hhtt168.com/seller/shops/ocr/getTCAVerifyBasicBizLicense",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8"},method:"POST",data:{imageUrl:s},success:function(e){var s=JSON.parse(e.data.license);console.log(s);var i=s.Period.split("至"),n=i[0].replace("年","-");n=(n=n.replace("月","-")).replace("日","");var t=i[1];"长期"!=t&&(t=(t=(t=t.replace("年","-")).replace("月","-")).replace("日","")),console.log(n),console.log(i),a.setData({business_license_company_name:s.Name,organization_cert_number:s.RegNum,organization_cert_valid_time:"".concat(n,",").concat(t),legal_person_id_card_name:s.Person,business_license_company_address:s.Address,business_license_number:s.RegNum,business_license_valid_time:"".concat(n,",").concat(t),timerange:"".concat(n,",").concat(t)})}})}})}})},conversionAddress:function(){var e=this;""!==e.data.images?wx.getFileSystemManager().readFile({filePath:e.data.images,encoding:"base64",success:function(a){e.data.baseImg=a.data,e.upCont(e.data.baseImg,e.data.images)}}):wx.showToast({title:"请先选择图片！"})},upCont:function(e){var a=this;return wx.request({url:"https://api.seller.hhtt168.com/seller/shop/SZBankUserAPI/getUploads",method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json",transCode:"szbank_ssUploadImages",timestamp:Date.parse(new Date)},data:{file_name:"1234.jpg",file:e},success:function(e){""!=e.data&&a.setData({business_license_copy:e.data})}}),!1}}});
},{isPage:true,isComponent:true,currentFile:'pages/Enterprisecertification/component.js'});require("pages/Enterprisecertification/component.js");