$gwx_XC_75=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_75 || [];
function gz$gwx_XC_75_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'van-toast'])
Z([3,'text-group_1'])
Z([3,'text_4'])
Z([3,'1'])
Z([3,'上传并提交您的营业执照'])
Z([3,'text_5'])
Z(z[4])
Z([3,'上传后请核对信息，如信息有误请手动修改后提交'])
Z([3,'wrapper'])
Z([3,'text_6'])
Z(z[4])
Z([3,'营业执照(个体户/企业)'])
Z([3,'upimage'])
Z([3,'group_3'])
Z([[2,'=='],[[7],[3,'images']],[1,'']])
Z([3,'image-text_1'])
Z([3,'box_4'])
Z([3,'text-group_2'])
Z(z[4])
Z([3,'拍摄营业执照'])
Z([[2,'!='],[[7],[3,'images']],[1,'']])
Z([3,'img_box'])
Z([[7],[3,'images']])
Z([3,'企业名称'])
Z([[7],[3,'business_license_company_name']])
Z(z[24])
Z([3,'企业代码'])
Z([[7],[3,'organization_cert_number']])
Z(z[27])
Z([3,'机构有效期'])
Z([[7],[3,'timerange']])
Z([3,'xxxx-xx-xx,xxxx-xx-xx'])
Z([3,'textarea'])
Z([3,'法人姓名'])
Z([[7],[3,'legal_person_id_card_name']])
Z(z[34])
Z([3,'注册地址'])
Z([[7],[3,'business_license_company_address']])
Z(z[37])
Z([3,'统一社会信用代码'])
Z([[7],[3,'business_license_number']])
Z(z[40])
Z([3,'经营期限'])
Z(z[31])
Z(z[43])
Z(z[33])
Z([3,'nextStep'])
Z([3,'button_1'])
Z([3,'text_17'])
Z(z[4])
Z([3,'下一步'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_75_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_75_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_75=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_75=true;
var x=['./pages/Enterprisecertification/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_75_1()
var xABB=_n('view')
_rz(z,xABB,'class',0,e,s,gg)
var oBBB=_n('van-toast')
_rz(z,oBBB,'id',1,e,s,gg)
_(xABB,oBBB)
var fCBB=_n('view')
_rz(z,fCBB,'class',2,e,s,gg)
var cDBB=_mz(z,'text',['class',3,'lines',1],[],e,s,gg)
var hEBB=_oz(z,5,e,s,gg)
_(cDBB,hEBB)
_(fCBB,cDBB)
var oFBB=_mz(z,'text',['class',6,'lines',1],[],e,s,gg)
var cGBB=_oz(z,8,e,s,gg)
_(oFBB,cGBB)
_(fCBB,oFBB)
_(xABB,fCBB)
var oHBB=_n('view')
_rz(z,oHBB,'class',9,e,s,gg)
var lIBB=_mz(z,'text',['class',10,'lines',1],[],e,s,gg)
var aJBB=_oz(z,12,e,s,gg)
_(lIBB,aJBB)
_(oHBB,lIBB)
var tKBB=_mz(z,'view',['bindtap',13,'class',1],[],e,s,gg)
var eLBB=_v()
_(tKBB,eLBB)
if(_oz(z,15,e,s,gg)){eLBB.wxVkey=1
var oNBB=_n('view')
_rz(z,oNBB,'class',16,e,s,gg)
var xOBB=_n('view')
_rz(z,xOBB,'class',17,e,s,gg)
_(oNBB,xOBB)
var oPBB=_mz(z,'text',['class',18,'lines',1],[],e,s,gg)
var fQBB=_oz(z,20,e,s,gg)
_(oPBB,fQBB)
_(oNBB,oPBB)
_(eLBB,oNBB)
}
var bMBB=_v()
_(tKBB,bMBB)
if(_oz(z,21,e,s,gg)){bMBB.wxVkey=1
var cRBB=_n('view')
_rz(z,cRBB,'class',22,e,s,gg)
var hSBB=_n('image')
_rz(z,hSBB,'src',23,e,s,gg)
_(cRBB,hSBB)
_(bMBB,cRBB)
}
eLBB.wxXCkey=1
bMBB.wxXCkey=1
_(oHBB,tKBB)
var oTBB=_mz(z,'van-field',['label',24,'value',1,'placeholder',2],[],e,s,gg)
oTBB.rawAttr={"model:value":"{{ business_license_company_name }}",};_(oHBB,oTBB)
var cUBB=_mz(z,'van-field',['label',27,'value',1,'placeholder',2],[],e,s,gg)
cUBB.rawAttr={"model:value":"{{ organization_cert_number }}",};_(oHBB,cUBB)
var oVBB=_mz(z,'van-field',['label',30,'value',1,'placeholder',2,'type',3],[],e,s,gg)
oVBB.rawAttr={"model:value":"{{ timerange }}",};_(oHBB,oVBB)
var lWBB=_mz(z,'van-field',['label',34,'value',1,'placeholder',2],[],e,s,gg)
lWBB.rawAttr={"model:value":"{{ legal_person_id_card_name }}",};_(oHBB,lWBB)
var aXBB=_mz(z,'van-field',['label',37,'value',1,'placeholder',2],[],e,s,gg)
aXBB.rawAttr={"model:value":"{{ business_license_company_address }}",};_(oHBB,aXBB)
var tYBB=_mz(z,'van-field',['label',40,'value',1,'placeholder',2],[],e,s,gg)
tYBB.rawAttr={"model:value":"{{ business_license_number }}",};_(oHBB,tYBB)
var eZBB=_mz(z,'van-field',['label',43,'value',1,'placeholder',2,'type',3],[],e,s,gg)
eZBB.rawAttr={"model:value":"{{ timerange }}",};_(oHBB,eZBB)
var b1BB=_mz(z,'button',['bindtap',47,'class',1],[],e,s,gg)
var o2BB=_mz(z,'text',['class',49,'lines',1],[],e,s,gg)
var x3BB=_oz(z,51,e,s,gg)
_(o2BB,x3BB)
_(b1BB,o2BB)
_(oHBB,b1BB)
_(xABB,oHBB)
_(r,xABB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_75";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_75();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/Enterprisecertification/component.wxml'] = [$gwx_XC_75, './pages/Enterprisecertification/component.wxml'];else __wxAppCode__['pages/Enterprisecertification/component.wxml'] = $gwx_XC_75( './pages/Enterprisecertification/component.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/Enterprisecertification/component.wxss'] = setCssToHead([".",[1],"page{background-color:#fff;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100vh;overflow:hidden;padding:",[0,18]," ",[0,13]," ",[0,64]," ",[0,32],";position:relative;width:",[0,750],"}\n.",[1],"wrapper{height:calc(100vh ",[0,-220],");overflow:scroll}\n.",[1],"text-group_1{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding:",[0,71]," ",[0,81]," ",[0,60]," ",[0,8],"}\n.",[1],"text_4{color:#111a34;font-size:",[0,52],";line-height:",[0,52],";margin-right:",[0,44],"}\n.",[1],"text_4,.",[1],"text_5{font-family:PingFangSC-Regular;overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"text_5{color:#858b9c;font-size:",[0,28],";line-height:",[0,28],";margin-top:",[0,24],"}\n.",[1],"text_6{color:#111a34;font-family:PingFangSC-Regular;font-size:",[0,32],";line-height:",[0,32],";margin:",[0,88]," ",[0,371]," 0 ",[0,8],";overflow-wrap:break-word;text-align:left;white-space:nowrap}\n.",[1],"group_3{background-color:#fff;border-radius:",[0,4],";box-shadow:0 5px 20px 0 rgba(197,202,213,.25);-webkit-flex-direction:row;flex-direction:row;margin:",[0,32]," ",[0,257]," 0 ",[0,8],"}\n.",[1],"group_3,.",[1],"image-text_1{display:-webkit-flex;display:flex}\n.",[1],"image-text_1{-webkit-flex-direction:column;flex-direction:column;margin:",[0,49]," ",[0,138]," ",[0,50]," ",[0,135],"}\n.",[1],"img_box{height:",[0,216],";width:",[0,380],"}\n.",[1],"img_box wx-image{height:100%;width:100%}\n.",[1],"box_4{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAABwCAYAAACKJjv2AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAqKADAAQAAAABAAAAcAAAAADICSlOAAANoElEQVR4Ae1de5AcRRn/enbm9vaeySW5PIwSHhogFHlJiDyEgAhRKV4FlPIoqaKUyh8UYExAfFJlCI+iFCqKIPAHUKIptECRMhIlQoglxFBCUDzBB5iQxORyudc+Zqb9vt1cdpObveuZ2d3u3fu+qrm97enu7+tf/7anH1/3CCiRxWtlpw+5OdICURJc9t+U7by95RYxXDYC35jwCJx2j+wekrlZKkBIX+Y+dkxTz/orRHYkfp6IC+4cngMSHpUCzgaJfxUFI/53Zlvq2OdvFBnFJBxtAiGweE32VE94L0kpHeViC5ERIB9JJVMrqfGzzl4n2zDxJglyWRhykkIJYA+3q7W2ygZyxIZBwAfXwsLQpS5SJqWEFUOZ9GOUSCxYO7RK+nAXCIF8E18By9qsmtt0y9m+4atiUDU+x5t4CCy8S87CbuNslZIL4TrSE1/GhvIaiu8Ie5GYv2boafz/UiHEC6/fljpPJSOOwwhUC4Hl98vkjsF0H5I0iY3lDRYSc+pBZbuqpZTzZQRUEaDxjJDyQCG+nBauf6CqheMxAhVCgAlaISA5m+ogwAStDq6ca4UQYIJWCEjOpjoIMEGrgyvnWiEE7Arlk88GVwxSrgsLXenNEyDUVw8qaQTnpRMBCcLvSdr2Vpwd6q2EIRUjaMZ1L0nnvAdx/qqbDMOVqUrYx3nUGwJY7Zmcl0YufCNpW/chUf04RagIQdOue6HvyZ/HMYTTNg4C+CRtxobqnnTWb8dSfStOyWL3QdEYW3rwUBwjOG1jIoCt59fSUh4Xp3SxCZrLwTx8oM+IYwSnbUwE8o1XzjsrTumIoCPOHiOfofKT0jsxVAKOPKEQQNe5E0IXWBQckIQvBmzLStzh+94ey7K+FzqjQoJExHScbGIgEH6cY1k3g+9fKFqTTyo7J5fDMpNxr/ZBPl7uPodPbASEgO83Nzk3RUUhdh80qmJOxwioIMAEVUGJ42hDgAmqDXpWrIIAE1QFJY6jDQEmqDboWbEKAkxQFZQ4jjYEmKDaoGfFKggwQVVQ4jjaEGCCaoOeFasgwARVQYnjaEOACaoNelasggATVAUljqMNgfCeJtpMra3ifUO0daF221amtglw2C9sVCUzQUdBUgj47gYXNr9TO4I+9PkEnDyLH2hHVgcT9EhENH23rXiejznXg2zOAw8/fTy/MJGwIGFZkEw6+Bkvb02Q5NUyQXWiX6LbjtB4EhEP9A/DwFAGXLf85slkkwMd7UloTSVLNNbHv0xQQ+oJG7xQMjiUhb37B9DxfPxuSCabgz17c9Bnp2Ha1DZw7Prp7DY8Qan6/jcQqu7zkbNu+DRxUvSlJewZUHsUHxhI51tOPHAY2pskqPIti6dq7Ni1H6ZObofWlqY45tYsrTaCpvFXXYuzHWg0fumjNcMzsqIVP/UwLV0qQi0gndwOsOrMIVg0S/3XhL0C2LOvH8+G7YBUs/mHv2gjaBabKNyWmge5mn+yWWqVtBWzmkWLlfeevf0wa8YkbH1D9i1iaQ2f2GzrwpeHUygiQAOs3r5IO80VNVQmGhO0MjjWZS400Mrh1JTJwgQ1uXZqYBtNUZksTFCTa6cGtg2ncbBqsGgbPaSSNM1R/UFSOj9/PVpPCgewTQGlH8QGZYw5b4OrMppp2Zz6DEA0DfFSBVRRvAxVUzs18oyw8yUc3Up8c7kDy+eNLv7tz2bhue3x+mUJnDjwRv8mVKGpeTwPJ/tNXQ4dXUM1h6f+FZ7yEQvOmZuAJXMsmN4uoC0p4MCwhJ0HJGz5pwcv/M2DN3eay1hTyUnMmLAEffxPLvwWiXOkbA9BpJNmCVh5rgMLZo9eOuxICaBr7nQLvrjUgZff8eC+jTl4d69ZRCWnEpNlwhL0rQ8k0BVVrliUgFXnOVDqhZTD5/oH2Gr24QvKJ7cAzOwUgK/yy6s449gELMaW9uu/zMLGt8s7dkS1J2o68ngyWSYsQeNUyrWn2nDLOcVlwn/t9eHhV1zY1OPBQMmszeQUwKeOT8D1pzkwvUNAyhFw7yVNsPqZHGz46+jWO45NUdN6ngeDw1n0dDJzbd7sn09U1KuY7hNHW3DTsuLv+gnsKlz2cAaee/NwcpIJvdiSrt/mwUU/SsPz2wujZTwWG+74rANzu9UcQ6pYlHzWNEDq3W/uihITNAQDyGfz1k87hx7bj7ySg3uxXzneiD2N3Lzt2Rz86o0CSZuxJV2N+bCMjwATdHyMDsX43EkJOKqrANnr73vwwKZwc4jfeT4H7/UW+p+LPpwAao1NkLbWZhPMCLTBDIQCTTMv8PwTi6P1B14MR04qDS17P/hSMd35JxTz01Vacrnr7MDOsqGijaDkaUfudrW4KoF9E3Lp4zgKJ9nVL2Hre9FG4hv/7kHGLcwenI4je11Cc5/TprTD9Kkd6PZsrhR7+zW2sX9wuCb+oANDBH/8YnbjBLxDS0Qob+6IRk5KS0vfPbsl0BzqtINbjXU4FE2b0gHNyfi4UJmqKdpa0GoWqhp5T2kttjN7B6PPn5Jt+0rSd7UU862G3UF5dk1qrQtyku3m/4SCENYQNpApkrIt5ubItpIxSWm+1S4WLRpM7WqDFkPnPIPKzwQNQiUgbPdAkaDHTIn+4KH2cs7BmYChrITBbICyEEGWYg+SSNnV2QK26g67EDZUM2p0pKtplYF596ep71joex4/w4KZuDIURebPtqDrYHdh63+i92VHdCeDfAZHbuJnEvuZs2dMhm4cENUbOakY2ghq0ckXNbhIT6XkdzgCH5HrT4/28PlSSbrS/EbyDfvpjbPx0EkkkJiVwyCsfXHjR0M5rlZM31ajUy4KXcfR/qBRivDUVheuWWJDS5OAS+Yn0OnDg1feVW8FLz45AacdU5ha2oVOJb+O6XdKZfD9sfW749yPgkMt09TvT6uWKB3U1Yt77H+MTiEkNOC4++ImWIo+oCqyHCf5b7+guLx5/4s5nA9VSTl2HNcbm6BpnNd6b8c+2Lm7L78fvrdvCPrx4Afa6kHe9OOlH1t79e9qa0GrX7TqaHhsiwvzP2TBWR9N5B2T113ZBD95zUPi5mA/OoccKeTAvOKTNlx0chHq9X92Y3vtH6lnrO/kEOLhOQSZMgMy6mql8JCxdpxeGK9PO5aeatwrolaN3BswTxrL3/pMNt96nnlcIr9V4mp87F+5OAE06OnZgwd6oTf9ZJzfPGGmyJN5xCeU4Hj2Ly6s3VCZLkel4PWwFabdnXS1tSSB5kktQ07EY4JGqOVh5NeN67Nww5k2esvbkLQLq0xLj07A0qODM+zHs5fW/SEHT20tDrSCY+oNJZJm8NFPS6AmnDrCBI3IB2pJf4iOH0+/7sK1Sxw4dy5OPXWO7o+SMzNtLXniVTfvaR9RXU2T0WEOdDTOzO7OmuoNUsYEDUIlRNjufsj7hN67EWD2JJHfNNeJzkF0aBlt/6CrHiWDfdYDA8PQ0abX04kJWkH2vL9fAl2NInTMo26Cjn4mNQq6XI7YCNCpzS4eKa5TmKA60a8D3ZmsXoJqe8TTBHItHobpkl2WdcAH40ykXZ86RRtB6TjqWhxgm8uRU4e2Yuqs24ropkl+ncKPeJ3o14Fu3X3Qhm9a6GCPluISeE0pQbpVhE47jirVdlTS3YI2PEEnpST84jo9S4v0XqLxfDCJAOTMYarodibhR7xmZugehIxXfN32aWtBU81NipsVxoPQ3PsqJ8d5B7cgm1oK6n3Qy8J0OY9oI2g9ve2smuSh3mczvqrQZJmQBDW5QmppWwueRU4XSzAC3AcNxoVDDUGACWpIRbAZwQgwQYNx4VBDEGCCGlIRbEYwAkzQYFw41BAEmKCGVASbEYwAEzQYFw41BAEmqCEVwWYEI8AEDcaFQw1BgAlqSEWwGcEIMEGDceFQQxBgghpSEWxGMAJM0GBcONQQBJighlQEmxGMQGyCSkt+EJw1hzICAEJYO+PgYC+8M3OZD97tVkLcvG1ValPYzJK2vTWD76FGUdwiFlYDx69nBHzwXwtr/8I1Q7egI/eVlrCusjCDFXiCwkLpwXVhM6L4+PbeXvxYFyUtp2lwBARsbrbt34ctJZJzJV5LPPAvo2NKR7Z9jHyGzQ+STmK1APGb0Ak5QcMigLx6Szj2tdiAjX1GeTACBS4KzCH4frhQNAIPG4QLMhn3Kl/A+QLkSfid9zGEg7ERYvsgxT/wsfpy0rF+gLyIffBQRQg6giy+k+dJ/J8uFkagIgjEHsVXxArOhBEogwATtAwwHGwGAkxQM+qBrSiDABO0DDAcbAYCTFAz6oGtKIMAE7QMMBxsBgJMUDPqga0og0CRoLLhD5srAwEHm4qAkCAtXId/nwyUQh5rqqFs18RB4Iw75WRcierKlxi5aeOXTfg2gy8gUU9dsHb4UTy2ejPggpUSJI71x20rk28pxeVIEw4B8nBbdHf6HOTTUSqF93HtfcBPX4MNZwKXST0LxGZx+c9koued4S14UOkpKpmUxsFMhlut5umbVwt8ISALI3A4AgvWpD8jwX/u8FC1b+hqd9e225pvtdZfIbxuO7UMkz2AHkn/Vkt+KNar562CwUPf+B9GoBQBG3pwZJPvQpYGl/ufWk18or9hWdYKIifFQ6+ow4Va1MNDyn8jcpe/y3cYgQICqpyadznIbx/hnvd/8EL3LTn+OusAAAAASUVORK5CYII\x3d) ",[0,0]," ",[0,-1]," no-repeat;background-size:",[0,168]," ",[0,112],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,110],";width:",[0,167],"}\n.",[1],"text-group_2{color:#858b9c;font-family:PingFangSC-Regular;font-size:",[0,24],";line-height:",[0,32],";margin:",[0,19]," ",[0,10]," 0 ",[0,13],";overflow-wrap:break-word;text-align:center;white-space:nowrap}\n.",[1],"button_1{background-color:#2f86f6;border-radius:",[0,10],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin:",[0,60]," ",[0,27]," 0 ",[0,8],";padding:",[0,24]," ",[0,279]," ",[0,24]," ",[0,281],"}\nwx-van-toast{width:100%}\n.",[1],"text_17{color:#fff;font-family:PingFangSC-Medium;font-size:",[0,36],";letter-spacing:",[0,0],";line-height:",[0,50],";overflow-wrap:break-word;text-align:center;white-space:nowrap}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/Enterprisecertification/component.wxss:1:6685)",{path:"./pages/Enterprisecertification/component.wxss"});
}