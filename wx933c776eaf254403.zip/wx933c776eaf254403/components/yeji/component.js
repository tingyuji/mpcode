Component({
    properties: {},
    data: {
        orderCount: {},
        KanbanData: {},
        klist: [],
        show: !1,
        actions: [ {
            name: "服务单",
            id: "ServiceOrder"
        }, {
            name: "退货单",
            id: "ReturnOrder"
        } ]
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            console.info("页面加载"), this.getOrderCount(), this.getKanbanData(), this.getListData();
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        onClick: function() {
            this.setData({
                show: !0
            }), console.log(this.data.show);
        },
        onClose: function() {
            this.setData({
                show: !1
            });
        },
        toFix: function(t) {
            return t ? parseFloat(t / 100).toFixed(2) : "0.00";
        },
        getOrderCount: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesOrderCount",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid")
                },
                success: function(o) {
                    console.log(o), o.data.costCount = t.toFix(o.data.costCount), o.data.serviceCostCount = t.toFix(o.data.serviceCostCount), 
                    o.data.totalCostCount = t.toFix(o.data.totalCostCount), o.data.serviceCostTotalCount = t.toFix(o.data.serviceCostTotalCount), 
                    o.data.data.weekCount.weekMoney = t.toFix(o.data.data.weekCount.weekMoney), o.data.data.weekCount.weekCommission = t.toFix(o.data.data.weekCount.weekCommission), 
                    o.data.data.monthCount.monthMoney = t.toFix(o.data.data.monthCount.monthMoney), 
                    o.data.data.monthCount.monthCommission = t.toFix(o.data.data.monthCount.monthCommission), 
                    t.setData({
                        orderCount: o.data.data
                    });
                }
            });
        },
        getKanbanData: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesOrderData",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid")
                },
                success: function(o) {
                    var a = o.data.data;
                    a.Commission = t.toFix(a.Commission), a.Money = t.toFix(a.Money), t.setData({
                        KanbanData: a
                    });
                }
            });
        },
        getListData: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getAllSalesOrderCountList",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid")
                },
                success: function(o) {
                    console.log(o);
                    var a = o.data.data;
                    a.forEach(function(o) {
                        o.list.order_commission = t.toFix(o.list.order_commission), o.list.order_money = t.toFix(o.list.order_money);
                    }), t.setData({
                        klist: a
                    });
                }
            });
        },
        goOrderlist: function() {
            wx.navigateTo({
                url: "/pagesB/yejiList/component"
            });
        },
        addorder: function(t) {
            var o = t.detail.id;
            console.log(o), wx.navigateTo({
                url: "/pagesA/addorder/component?order_type=" + o
            });
        }
    }
});