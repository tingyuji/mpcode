$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'actions']])
Z([3,'onClose'])
Z(z[1])
Z([3,'addorder'])
Z([3,'取消'])
Z([[7],[3,'show']])
Z([3,'9999999999999999'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./components/yeji/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var oVB=_mz(z,'van-action-sheet',['actions',0,'bind:cancel',1,'bind:close',1,'bind:select',2,'cancelText',3,'show',4,'zIndex',5],[],e,s,gg)
_(r,oVB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/yeji/component.wxml'] = [$gwx_XC_3, './components/yeji/component.wxml'];else __wxAppCode__['components/yeji/component.wxml'] = $gwx_XC_3( './components/yeji/component.wxml' );
	;__wxRoute = "components/yeji/component";__wxRouteBegin = true;__wxAppCurrentFile__="components/yeji/component.js";define("components/yeji/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{},data:{orderCount:{},KanbanData:{},klist:[],show:!1,actions:[{name:"服务单",id:"ServiceOrder"},{name:"退货单",id:"ReturnOrder"}]},lifetimes:{created:function(){},attached:function(){console.info("页面加载"),this.getOrderCount(),this.getKanbanData(),this.getListData()},detached:function(){console.info("页面卸载")}},methods:{onClick:function(){this.setData({show:!0}),console.log(this.data.show)},onClose:function(){this.setData({show:!1})},toFix:function(t){return t?parseFloat(t/100).toFixed(2):"0.00"},getOrderCount:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesOrderCount",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid")},success:function(o){console.log(o),o.data.costCount=t.toFix(o.data.costCount),o.data.serviceCostCount=t.toFix(o.data.serviceCostCount),o.data.totalCostCount=t.toFix(o.data.totalCostCount),o.data.serviceCostTotalCount=t.toFix(o.data.serviceCostTotalCount),o.data.data.weekCount.weekMoney=t.toFix(o.data.data.weekCount.weekMoney),o.data.data.weekCount.weekCommission=t.toFix(o.data.data.weekCount.weekCommission),o.data.data.monthCount.monthMoney=t.toFix(o.data.data.monthCount.monthMoney),o.data.data.monthCount.monthCommission=t.toFix(o.data.data.monthCount.monthCommission),t.setData({orderCount:o.data.data})}})},getKanbanData:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesOrderData",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid")},success:function(o){var a=o.data.data;a.Commission=t.toFix(a.Commission),a.Money=t.toFix(a.Money),t.setData({KanbanData:a})}})},getListData:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getAllSalesOrderCountList",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid")},success:function(o){console.log(o);var a=o.data.data;a.forEach((function(o){o.list.order_commission=t.toFix(o.list.order_commission),o.list.order_money=t.toFix(o.list.order_money)})),t.setData({klist:a})}})},goOrderlist:function(){wx.navigateTo({url:"/pagesB/yejiList/component"})},addorder:function(t){var o=t.detail.id;console.log(o),wx.navigateTo({url:"/pagesA/addorder/component?order_type="+o})}}});
},{isPage:false,isComponent:true,currentFile:'components/yeji/component.js'});require("components/yeji/component.js");