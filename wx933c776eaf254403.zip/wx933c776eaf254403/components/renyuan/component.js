Component({
    properties: {},
    data: {
        order_list: [],
        orderCount: 68,
        moneyCount: 5e4,
        type: "ServiceOrder",
        identity: "供应商",
        show: !1
    },
    lifetimes: {
        created: function() {
            wx.getStorageSync("username") || wx.reLaunch({
                url: "/pages/login/component"
            });
        },
        attached: function() {
            console.info("页面加载"), this.getList();
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        godetail: function(t) {
            var e = t.currentTarget.dataset.id;
            t.currentTarget.dataset.state;
            return wx.navigateTo({
                url: "/pages/orderDetail/component?id=" + e
            }), !1;
        },
        setshow: function() {
            this.setData({
                show: !0
            });
        },
        onClose: function() {
            this.setData({
                show: !1
            });
        },
        onSearch: function(t) {
            this.getList(t);
        },
        gocomlist: function(t) {
            wx.setStorageSync("comlistid", t.currentTarget.dataset.id), wx.navigateTo({
                url: "/pagesB/rycomlist/index?id=" + t.currentTarget.dataset.id
            });
        },
        getList: function(t) {
            var e = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesManList",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid")
                },
                success: function(t) {
                    var o = t.data.data;
                    console.log(o), o.forEach(function(t) {
                        null != t.sales_do && (t.sales_do.order_amount = parseFloat(t.sales_do.order_amount / 100).toFixed(2), 
                        t.sales_do.manager_cost = parseFloat(t.sales_do.manager_cost).toFixed(2));
                    }), e.setData({
                        order_list: o,
                        show: !1
                    });
                }
            });
        },
        toList: function(t) {
            wx.navigateTo({
                url: "/pagesB/renyuanList/component?id=" + t
            });
        }
    }
});