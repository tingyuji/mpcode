$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'section_5'])
Z([[7],[3,'order_list']])
Z([3,'index'])
Z([3,'box_2'])
Z([3,'item_content'])
Z([3,'item_line bb'])
Z([3,'item_desc'])
Z([a,[3,' '],[[6],[[6],[[7],[3,'item']],[3,'sales_do']],[3,'name']],[3,' ']])
Z([3,'item_v'])
Z([a,[3,' ID:'],[[6],[[6],[[7],[3,'item']],[3,'sales_do']],[3,'job_no']],z[8][1]])
Z([3,'mpbile'])
Z([a,z[8][1],[[6],[[6],[[7],[3,'item']],[3,'sales_do']],[3,'mobile']],z[8][1]])
Z([3,'icon_1'])
Z([3,'gocomlist'])
Z([3,'eizhi'])
Z([[6],[[7],[3,'item']],[3,'sales_id']])
Z([3,'lt'])
Z([3,' 客户列表 '])
Z([3,'blue'])
Z([3,'width: 60rpx;font-size: 30rpx;display: flex;'])
Z([3,' 查看 '])
Z([3,'friends-o'])
Z([3,'toList'])
Z(z[15])
Z(z[17])
Z([3,' 服务佣金 '])
Z([3,'orange'])
Z([3,'width: 130rpx;font-size: 30rpx;display: flex;'])
Z([3,'按月统计'])
Z([3,'notes-o'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/renyuan/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var o8F=_n('view')
_rz(z,o8F,'class',0,e,s,gg)
var f9F=_n('view')
_rz(z,f9F,'class',1,e,s,gg)
var c0F=_v()
_(f9F,c0F)
var hAG=function(cCG,oBG,oDG,gg){
var aFG=_n('view')
_rz(z,aFG,'class',4,cCG,oBG,gg)
var tGG=_n('view')
_rz(z,tGG,'class',5,cCG,oBG,gg)
var eHG=_n('view')
_rz(z,eHG,'class',6,cCG,oBG,gg)
var bIG=_n('view')
var oJG=_n('view')
_rz(z,oJG,'class',7,cCG,oBG,gg)
var xKG=_oz(z,8,cCG,oBG,gg)
_(oJG,xKG)
var oLG=_n('view')
_rz(z,oLG,'class',9,cCG,oBG,gg)
var fMG=_oz(z,10,cCG,oBG,gg)
_(oLG,fMG)
_(oJG,oLG)
_(bIG,oJG)
var cNG=_n('view')
_rz(z,cNG,'class',11,cCG,oBG,gg)
var hOG=_oz(z,12,cCG,oBG,gg)
_(cNG,hOG)
_(bIG,cNG)
_(eHG,bIG)
var oPG=_n('view')
_rz(z,oPG,'class',13,cCG,oBG,gg)
_(eHG,oPG)
_(tGG,eHG)
var cQG=_n('view')
var oRG=_mz(z,'view',['bindtap',14,'class',1,'data-id',2],[],cCG,oBG,gg)
var lSG=_n('view')
_rz(z,lSG,'class',17,cCG,oBG,gg)
var aTG=_oz(z,18,cCG,oBG,gg)
_(lSG,aTG)
_(oRG,lSG)
var tUG=_n('view')
_rz(z,tUG,'class',19,cCG,oBG,gg)
var eVG=_n('view')
_rz(z,eVG,'style',20,cCG,oBG,gg)
var bWG=_oz(z,21,cCG,oBG,gg)
_(eVG,bWG)
_(tUG,eVG)
var oXG=_n('van-icon')
_rz(z,oXG,'name',22,cCG,oBG,gg)
_(tUG,oXG)
_(oRG,tUG)
_(cQG,oRG)
var xYG=_mz(z,'view',['bindtap',23,'class',1],[],cCG,oBG,gg)
var oZG=_n('view')
_rz(z,oZG,'class',25,cCG,oBG,gg)
var f1G=_oz(z,26,cCG,oBG,gg)
_(oZG,f1G)
_(xYG,oZG)
var c2G=_n('view')
_rz(z,c2G,'class',27,cCG,oBG,gg)
var h3G=_n('view')
_rz(z,h3G,'style',28,cCG,oBG,gg)
var o4G=_oz(z,29,cCG,oBG,gg)
_(h3G,o4G)
_(c2G,h3G)
var c5G=_n('van-icon')
_rz(z,c5G,'name',30,cCG,oBG,gg)
_(c2G,c5G)
_(xYG,c2G)
_(cQG,xYG)
_(tGG,cQG)
_(aFG,tGG)
_(oDG,aFG)
return oDG
}
c0F.wxXCkey=4
_2z(z,2,hAG,e,s,gg,c0F,'item','index','index')
_(o8F,f9F)
_(r,o8F)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/renyuan/component.wxml'] = [$gwx_XC_2, './components/renyuan/component.wxml'];else __wxAppCode__['components/renyuan/component.wxml'] = $gwx_XC_2( './components/renyuan/component.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/renyuan/component.wxss'] = setCssToHead([".",[1],"page{background-color:#f6f7fb;-webkit-justify-content:center;justify-content:center;min-height:100vh;overflow:hidden;position:relative;width:100vw}\n.",[1],"box_2,.",[1],"page{display:-webkit-flex;display:flex}\n.",[1],"box_2{background-color:#fff;border-radius:",[0,12],";-webkit-flex-direction:row;flex-direction:row;margin:",[0,20]," 0;padding:",[0,24]," ",[0,30]," ",[0,30],";width:94vw}\n.",[1],"icon_1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAASCAYAAABit09LAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAACqADAAQAAAABAAAAEgAAAABr6GS2AAAA3UlEQVQoFY3SQQqCQBQGYGcaF1GBtOgGErRrGW1apOCmfdjd2neBQRnoCEFrD9DKhbtg0N4vJDk56gMZ8H3z857IgiC4VlW1c133LKV8OJbiQNRba61VFEVbi3M4khhjOV1Y9mGGBCQBAeOSEOJojlHDMbiBQ7gF+/Af7MI0+2GChllZlr18338SuFBvSgsuOhPDMFyVZXkntKFHc85P3EwzEfXjNE1lK7ELKaVuCGtgH2rgEKrhGASIvwcz1NvRGX9nQvO3sPWMvtObTivCBeF53r4oinmSJDle2OoDm7OjUFLUehAAAAAASUVORK5CYII\x3d) 100% no-repeat;background-size:100% 100%;height:",[0,18],";margin-top:",[0,-20],";width:",[0,10],"}\n.",[1],"icon_1,.",[1],"item_content{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"item_content{-webkit-flex:1;flex:1}\n.",[1],"item_line{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"face{height:",[0,120],";width:",[0,120],"}\n.",[1],"bb{border-bottom:1px solid #eee}\n.",[1],"item_desc{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"item_v{color:#aaa;font-size:",[0,28],";margin-left:",[0,24],"}\n.",[1],"mpbile{color:#777;font-size:",[0,28],";margin-top:",[0,10],";padding-bottom:",[0,20],"}\n.",[1],"eizhi{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,20]," 0 ",[0,10],"}\n.",[1],"lt{color:#333;font-size:",[0,28],"}\n.",[1],"blue{color:#527fcf;display:-webkit-flex;display:flex;-webkit-justify-content:flex-end;justify-content:flex-end;width:50%}\n.",[1],"green{color:#6ea095}\n.",[1],"orange{color:#e08966;display:-webkit-flex;display:flex;-webkit-justify-content:flex-end;justify-content:flex-end;width:50%}\n",],undefined,{path:"./components/renyuan/component.wxss"});
}