$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'order_list']])
Z([3,'index'])
Z([3,'gocomlist'])
Z([3,'eizhi'])
Z([[6],[[7],[3,'item']],[3,'sales_id']])
Z([3,'friends-o'])
Z([3,'toList'])
Z(z[3])
Z([3,'notes-o'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/renyuan/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var oJB=_v()
_(r,oJB)
var fKB=function(hMB,cLB,oNB,gg){
var oPB=_n('view')
var lQB=_mz(z,'view',['bindtap',2,'class',1,'data-id',2],[],hMB,cLB,gg)
var aRB=_n('van-icon')
_rz(z,aRB,'name',5,hMB,cLB,gg)
_(lQB,aRB)
_(oPB,lQB)
var tSB=_mz(z,'view',['bindtap',6,'class',1],[],hMB,cLB,gg)
var eTB=_n('van-icon')
_rz(z,eTB,'name',8,hMB,cLB,gg)
_(tSB,eTB)
_(oPB,tSB)
_(oNB,oPB)
return oNB
}
oJB.wxXCkey=4
_2z(z,0,fKB,e,s,gg,oJB,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/renyuan/component.wxml'] = [$gwx_XC_2, './components/renyuan/component.wxml'];else __wxAppCode__['components/renyuan/component.wxml'] = $gwx_XC_2( './components/renyuan/component.wxml' );
	;__wxRoute = "components/renyuan/component";__wxRouteBegin = true;__wxAppCurrentFile__="components/renyuan/component.js";define("components/renyuan/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{},data:{order_list:[],orderCount:68,moneyCount:5e4,type:"ServiceOrder",identity:"供应商",show:!1},lifetimes:{created:function(){wx.getStorageSync("username")||wx.reLaunch({url:"/pages/login/component"})},attached:function(){console.info("页面加载"),this.getList()},detached:function(){console.info("页面卸载")}},methods:{godetail:function(t){var e=t.currentTarget.dataset.id;t.currentTarget.dataset.state;return wx.navigateTo({url:"/pages/orderDetail/component?id="+e}),!1},setshow:function(){this.setData({show:!0})},onClose:function(){this.setData({show:!1})},onSearch:function(t){this.getList(t)},gocomlist:function(t){wx.setStorageSync("comlistid",t.currentTarget.dataset.id),wx.navigateTo({url:"/pagesB/rycomlist/index?id="+t.currentTarget.dataset.id})},getList:function(t){var e=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getSalesManList",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid")},success:function(t){var o=t.data.data;console.log(o),o.forEach((function(t){null!=t.sales_do&&(t.sales_do.order_amount=parseFloat(t.sales_do.order_amount/100).toFixed(2),t.sales_do.manager_cost=parseFloat(t.sales_do.manager_cost).toFixed(2))})),e.setData({order_list:o,show:!1})}})},toList:function(t){wx.navigateTo({url:"/pagesB/renyuanList/component?id="+t})}}});
},{isPage:false,isComponent:true,currentFile:'components/renyuan/component.js'});require("components/renyuan/component.js");