$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'box_o'])
Z([3,'toOrderList'])
Z([3,'other_item bb'])
Z([3,'arrow'])
Z(z[1])
Z(z[2])
Z(z[3])
Z(z[1])
Z([3,'other_item  bb'])
Z(z[3])
Z(z[1])
Z(z[2])
Z(z[3])
Z(z[1])
Z(z[8])
Z(z[3])
Z(z[1])
Z([3,'other_item'])
Z(z[3])
Z([[7],[3,'actions']])
Z([3,'onClose'])
Z(z[20])
Z([3,'addorder'])
Z([3,'取消'])
Z([[7],[3,'show']])
Z([3,'9999999999999999'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/fws_order/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var x5=_n('view')
_rz(z,x5,'class',0,e,s,gg)
var o6=_mz(z,'view',['bindtap',1,'class',1],[],e,s,gg)
var f7=_n('van-icon')
_rz(z,f7,'name',3,e,s,gg)
_(o6,f7)
_(x5,o6)
var c8=_mz(z,'view',['bindtap',4,'class',1],[],e,s,gg)
var h9=_n('van-icon')
_rz(z,h9,'name',6,e,s,gg)
_(c8,h9)
_(x5,c8)
var o0=_mz(z,'view',['bindtap',7,'class',1],[],e,s,gg)
var cAB=_n('van-icon')
_rz(z,cAB,'name',9,e,s,gg)
_(o0,cAB)
_(x5,o0)
var oBB=_mz(z,'view',['bindtap',10,'class',1],[],e,s,gg)
var lCB=_n('van-icon')
_rz(z,lCB,'name',12,e,s,gg)
_(oBB,lCB)
_(x5,oBB)
var aDB=_mz(z,'view',['bindtap',13,'class',1],[],e,s,gg)
var tEB=_n('van-icon')
_rz(z,tEB,'name',15,e,s,gg)
_(aDB,tEB)
_(x5,aDB)
var eFB=_mz(z,'view',['bindtap',16,'class',1],[],e,s,gg)
var bGB=_n('van-icon')
_rz(z,bGB,'name',18,e,s,gg)
_(eFB,bGB)
_(x5,eFB)
_(r,x5)
var oHB=_mz(z,'van-action-sheet',['actions',19,'bind:cancel',1,'bind:close',2,'bind:select',3,'cancelText',4,'show',5,'zIndex',6],[],e,s,gg)
_(r,oHB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/fws_order/component.wxml'] = [$gwx_XC_1, './components/fws_order/component.wxml'];else __wxAppCode__['components/fws_order/component.wxml'] = $gwx_XC_1( './components/fws_order/component.wxml' );
	;__wxRoute = "components/fws_order/component";__wxRouteBegin = true;__wxAppCurrentFile__="components/fws_order/component.js";define("components/fws_order/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{},data:{orderCount:{},KanbanData:{},show:!1,actions:[{name:"服务单",id:"ServiceOrder"},{name:"退货单",id:"ReturnOrder"}]},lifetimes:{created:function(){},attached:function(){console.info("页面加载"),this.getOrderCount(),this.getKanbanData()},detached:function(){console.info("页面卸载")}},methods:{onClick:function(){this.setData({show:!0}),console.log(this.data.show)},onClose:function(){this.setData({show:!1})},toFix:function(t){return t?t.toFixed(2):"0.00"},getOrderCount:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getFOrderCount",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{fmember_id:wx.getStorageSync("uid")},success:function(o){o.data.costCount=t.toFix(o.data.costCount/100),o.data.serviceCostCount=t.toFix(o.data.serviceCostCount/100),o.data.totalCostCount=t.toFix(o.data.totalCostCount/100),o.data.serviceCostTotalCount=t.toFix(o.data.serviceCostTotalCount/100),o.data.confirmCostTotalCount=t.toFix(o.data.confirmCostTotalCount/100),o.data.confirmCostCount=t.toFix(o.data.confirmCostCount/100),t.setData({orderCount:o.data})}})},getKanbanData:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getROrderCount",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{fmember_id:wx.getStorageSync("uid")},success:function(o){o.data.returnCostCount=t.toFix(o.data.returnCostCount/100),o.data.returnServiceCostTotalCount=t.toFix(o.data.returnServiceCostTotalCount/100),t.setData({KanbanData:o.data})}})},goOrderlist:function(){wx.navigateTo({url:"/pagesA/fws_Orderlist/component"})},toOrderList:function(){wx.navigateTo({url:"/pagesA/indexDetail/index"})},addorder:function(t){var o=t.detail.id;console.log(o),wx.navigateTo({url:"/pagesA/addorder/component?order_type="+o})}}});
},{isPage:false,isComponent:true,currentFile:'components/fws_order/component.js'});require("components/fws_order/component.js");