Component({
    properties: {},
    data: {
        orderCount: {},
        KanbanData: {},
        show: !1,
        actions: [ {
            name: "服务单",
            id: "ServiceOrder"
        }, {
            name: "退货单",
            id: "ReturnOrder"
        } ]
    },
    lifetimes: {
        created: function() {},
        attached: function() {
            console.info("页面加载"), this.getOrderCount(), this.getKanbanData();
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        onClick: function() {
            this.setData({
                show: !0
            }), console.log(this.data.show);
        },
        onClose: function() {
            this.setData({
                show: !1
            });
        },
        toFix: function(t) {
            return t ? t.toFixed(2) : "0.00";
        },
        getOrderCount: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getFOrderCount",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    fmember_id: wx.getStorageSync("uid")
                },
                success: function(o) {
                    o.data.costCount = t.toFix(o.data.costCount / 100), o.data.serviceCostCount = t.toFix(o.data.serviceCostCount / 100), 
                    o.data.totalCostCount = t.toFix(o.data.totalCostCount / 100), o.data.serviceCostTotalCount = t.toFix(o.data.serviceCostTotalCount / 100), 
                    o.data.confirmCostTotalCount = t.toFix(o.data.confirmCostTotalCount / 100), o.data.confirmCostCount = t.toFix(o.data.confirmCostCount / 100), 
                    t.setData({
                        orderCount: o.data
                    });
                }
            });
        },
        getKanbanData: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/FacilitatorAPI/getROrderCount",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    fmember_id: wx.getStorageSync("uid")
                },
                success: function(o) {
                    o.data.returnCostCount = t.toFix(o.data.returnCostCount / 100), o.data.returnServiceCostTotalCount = t.toFix(o.data.returnServiceCostTotalCount / 100), 
                    t.setData({
                        KanbanData: o.data
                    });
                }
            });
        },
        goOrderlist: function() {
            wx.navigateTo({
                url: "/pagesA/fws_Orderlist/component"
            });
        },
        toOrderList: function() {
            wx.navigateTo({
                url: "/pagesA/indexDetail/index"
            });
        },
        addorder: function(t) {
            var o = t.detail.id;
            console.log(o), wx.navigateTo({
                url: "/pagesA/addorder/component?order_type=" + o
            });
        }
    }
});