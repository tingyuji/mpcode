Component({
    properties: {},
    data: {
        page_list: [],
        page_no: 1,
        page_size: 10,
        customerList: []
    },
    lifetimes: {
        created: function() {
            this.getCusList();
        },
        attached: function() {
            console.info("页面加载"), this.getCusList(), wx.setNavigationBarTitle({
                title: "客户"
            });
        },
        detached: function() {
            console.info("页面卸载");
        }
    },
    methods: {
        editsales: function(t) {
            var e = t.currentTarget.dataset.customer_id, a = t.currentTarget.dataset.service, o = t.currentTarget.dataset.order_id;
            if ("GeneralAgent" != wx.getStorageSync("identityStatus")) return wx.showModal({
                title: "无权限进行操作，请联系总代理修改"
            });
            wx.navigateTo({
                url: "/pagesB/editsales/editsales?id=" + e + "&rate=" + a + "&orderId=" + o
            });
        },
        getList: function(t) {
            var e = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getCustomerLists",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid"),
                    page_no: this.data.page_no,
                    page_size: this.data.page_size
                },
                success: function(t) {
                    console.log(t);
                    var a = t.data.data.customerList;
                    a.forEach(function(t) {
                        t.money = parseFloat(t.money / 100).toFixed(2), t.page_list.data.forEach(function(t) {
                            var e = t.created_time, a = new Date(e), o = a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() + " " + a.getHours() + ":" + a.getMinutes() + ":" + a.getSeconds();
                            t.created_time = o, t.commission = parseFloat(t.commission / 100).toFixed(2);
                        });
                    }), e.setData({
                        page_list: a,
                        show: !1
                    });
                }
            });
        },
        getCusList: function() {
            var t = this;
            wx.request({
                url: "https://api.seller.hhtt168.com/seller/applet/salesApi/getCustomerList",
                method: "post",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
                    dataType: "json"
                },
                data: {
                    sales_id: wx.getStorageSync("sid")
                },
                success: function(e) {
                    console.log(e, "cuslist"), e.data.data = e.data.data.filter(function(t) {
                        return null != t.customer_data_vo;
                    }), e.data.data.forEach(function(t) {
                        null != t.customer_data_vo && (t.customer_data_vo.commission = parseFloat(t.customer_data_vo.commission / 100).toFixed(2), 
                        t.manager = parseFloat(parseFloat(t.customer_data_vo.spercentage_rate).toFixed(2) * parseFloat(t.customer_data_vo.total_rate).toFixed(2) / 100).toFixed(2) / 10, 
                        t.mangers = parseFloat(parseFloat(t.customer_data_vo.apercentage_rate).toFixed(2) * parseFloat(t.customer_data_vo.total_rate).toFixed(2) / 100).toFixed(2) / 10, 
                        t.customer_data_vo.total_rate = parseFloat(t.customer_data_vo.total_rate / 1e3).toFixed(2), 
                        t.customer_data_vo.service_rate = parseFloat(t.customer_data_vo.service_rate / 1e3).toFixed(2), 
                        t.customer_data_vo.percentage_rate = parseFloat(100 * t.customer_data_vo.percentage_rate).toFixed(2), 
                        t.customer_data_vo.sales_rate = parseFloat(t.customer_data_vo.sales_rate / 1e3).toFixed(2));
                    }), t.setData({
                        customerList: e.data.data
                    });
                }
            });
        },
        toList: function(t) {
            console.log(t), wx.reLaunch({
                url: "/pagesB/cusmothlist/index?customer_id=" + t.currentTarget.dataset.customer_id
            });
        }
    }
});