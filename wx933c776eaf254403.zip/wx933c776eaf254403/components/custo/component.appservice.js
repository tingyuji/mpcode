$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'customerList']])
Z([3,'index'])
Z([3,'toList'])
Z([[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'customer_id']])
Z([3,'arrow'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./components/custo/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oV=_v()
_(r,oV)
var cW=function(lY,oX,aZ,gg){
var e2=_mz(z,'view',['bindtap',2,'data-customer_id',1],[],lY,oX,gg)
var b3=_n('van-icon')
_rz(z,b3,'name',4,lY,oX,gg)
_(e2,b3)
_(aZ,e2)
return aZ
}
oV.wxXCkey=4
_2z(z,0,cW,e,s,gg,oV,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/custo/component.wxml'] = [$gwx_XC_0, './components/custo/component.wxml'];else __wxAppCode__['components/custo/component.wxml'] = $gwx_XC_0( './components/custo/component.wxml' );
	;__wxRoute = "components/custo/component";__wxRouteBegin = true;__wxAppCurrentFile__="components/custo/component.js";define("components/custo/component.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Component({properties:{},data:{page_list:[],page_no:1,page_size:10,customerList:[]},lifetimes:{created:function(){this.getCusList()},attached:function(){console.info("页面加载"),this.getCusList(),wx.setNavigationBarTitle({title:"客户"})},detached:function(){console.info("页面卸载")}},methods:{editsales:function(t){var e=t.currentTarget.dataset.customer_id,a=t.currentTarget.dataset.service,o=t.currentTarget.dataset.order_id;if("GeneralAgent"!=wx.getStorageSync("identityStatus"))return wx.showModal({title:"无权限进行操作，请联系总代理修改"});wx.navigateTo({url:"/pagesB/editsales/editsales?id="+e+"&rate="+a+"&orderId="+o})},getList:function(t){var e=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getCustomerLists",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid"),page_no:this.data.page_no,page_size:this.data.page_size},success:function(t){console.log(t);var a=t.data.data.customerList;a.forEach((function(t){t.money=parseFloat(t.money/100).toFixed(2),t.page_list.data.forEach((function(t){var e=t.created_time,a=new Date(e),o=a.getFullYear()+"-"+(a.getMonth()+1)+"-"+a.getDate()+" "+a.getHours()+":"+a.getMinutes()+":"+a.getSeconds();t.created_time=o,t.commission=parseFloat(t.commission/100).toFixed(2)}))})),e.setData({page_list:a,show:!1})}})},getCusList:function(){var t=this;wx.request({url:"https://api.seller.hhtt168.com/seller/applet/salesApi/getCustomerList",method:"post",header:{"Content-Type":"application/x-www-form-urlencoded;charset=utf-8",dataType:"json"},data:{sales_id:wx.getStorageSync("sid")},success:function(e){console.log(e,"cuslist"),e.data.data=e.data.data.filter((function(t){return null!=t.customer_data_vo})),e.data.data.forEach((function(t){null!=t.customer_data_vo&&(t.customer_data_vo.commission=parseFloat(t.customer_data_vo.commission/100).toFixed(2),t.manager=parseFloat(parseFloat(t.customer_data_vo.spercentage_rate).toFixed(2)*parseFloat(t.customer_data_vo.total_rate).toFixed(2)/100).toFixed(2)/10,t.mangers=parseFloat(parseFloat(t.customer_data_vo.apercentage_rate).toFixed(2)*parseFloat(t.customer_data_vo.total_rate).toFixed(2)/100).toFixed(2)/10,t.customer_data_vo.total_rate=parseFloat(t.customer_data_vo.total_rate/1e3).toFixed(2),t.customer_data_vo.service_rate=parseFloat(t.customer_data_vo.service_rate/1e3).toFixed(2),t.customer_data_vo.percentage_rate=parseFloat(100*t.customer_data_vo.percentage_rate).toFixed(2),t.customer_data_vo.sales_rate=parseFloat(t.customer_data_vo.sales_rate/1e3).toFixed(2))})),t.setData({customerList:e.data.data})}})},toList:function(t){console.log(t),wx.reLaunch({url:"/pagesB/cusmothlist/index?customer_id="+t.currentTarget.dataset.customer_id})}}});
},{isPage:false,isComponent:true,currentFile:'components/custo/component.js'});require("components/custo/component.js");