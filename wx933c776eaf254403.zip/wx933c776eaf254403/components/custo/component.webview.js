$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page_box'])
Z([3,'cus_list'])
Z([[7],[3,'customerList']])
Z([3,'index'])
Z([3,'box_2'])
Z([3,'item_content'])
Z([3,'item_line bb'])
Z([3,'item_desc'])
Z([a,[3,' '],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'name']],[3,' ']])
Z([3,'item_v'])
Z([3,'mpbile'])
Z([3,'icon_1'])
Z([3,'eizhi'])
Z([3,'fl'])
Z([a,[3,' 客户费率'],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'service_rate']],[3,'% ']])
Z(z[13])
Z(z[12])
Z([3,'lt'])
Z([3,' 代理佣金总额统计 '])
Z([3,'toList'])
Z([[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'customer_id']])
Z([3,'arrow'])
Z(z[12])
Z(z[17])
Z([3,' 代理总佣金费率 '])
Z([3,'blue'])
Z([a,z[8][1],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'total_rate']]])
Z([3,'font-size: 28rpx;'])
Z([3,'%'])
Z(z[12])
Z(z[17])
Z([3,' 销售佣金设置 '])
Z([3,'editsales'])
Z([3,'green'])
Z(z[20])
Z([[6],[[7],[3,'item']],[3,'order_id']])
Z([[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'service_rate']])
Z([3,' 查看 '])
Z(z[12])
Z([3,' 代理销售佣金费率 '])
Z([a,z[8][1],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'sales_rate']],z[28]])
Z([a,z[8][1],[[2,'*'],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'spercentage_rate']],[1,100]],z[28]])
Z(z[12])
Z([3,' 代理经理佣金费率 '])
Z([a,z[8][1],[[2,'/'],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'out_manager_rate']],[1,1000]],z[28]])
Z([a,z[8][1],[[2,'*'],[[6],[[6],[[7],[3,'item']],[3,'customer_data_vo']],[3,'apercentage_rate']],[1,100]],z[28]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./components/custo/component.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oJB=_n('page')
_rz(z,oJB,'class',0,e,s,gg)
var fKB=_n('view')
_rz(z,fKB,'class',1,e,s,gg)
var cLB=_v()
_(fKB,cLB)
var hMB=function(cOB,oNB,oPB,gg){
var aRB=_n('view')
_rz(z,aRB,'class',4,cOB,oNB,gg)
var tSB=_n('view')
_rz(z,tSB,'class',5,cOB,oNB,gg)
var eTB=_n('view')
_rz(z,eTB,'class',6,cOB,oNB,gg)
var bUB=_n('view')
var oVB=_n('view')
_rz(z,oVB,'class',7,cOB,oNB,gg)
var xWB=_oz(z,8,cOB,oNB,gg)
_(oVB,xWB)
var oXB=_n('view')
_rz(z,oXB,'class',9,cOB,oNB,gg)
_(oVB,oXB)
_(bUB,oVB)
var fYB=_n('view')
_rz(z,fYB,'class',10,cOB,oNB,gg)
_(bUB,fYB)
_(eTB,bUB)
var cZB=_n('view')
_rz(z,cZB,'class',11,cOB,oNB,gg)
_(eTB,cZB)
_(tSB,eTB)
var h1B=_n('view')
var o2B=_n('view')
_rz(z,o2B,'class',12,cOB,oNB,gg)
var c3B=_n('view')
_rz(z,c3B,'class',13,cOB,oNB,gg)
var o4B=_oz(z,14,cOB,oNB,gg)
_(c3B,o4B)
_(o2B,c3B)
var l5B=_n('view')
_rz(z,l5B,'class',15,cOB,oNB,gg)
_(o2B,l5B)
_(h1B,o2B)
var a6B=_n('view')
_rz(z,a6B,'class',16,cOB,oNB,gg)
var t7B=_n('view')
_rz(z,t7B,'class',17,cOB,oNB,gg)
var e8B=_oz(z,18,cOB,oNB,gg)
_(t7B,e8B)
_(a6B,t7B)
var b9B=_mz(z,'view',['bindtap',19,'data-customer_id',1],[],cOB,oNB,gg)
var o0B=_n('van-icon')
_rz(z,o0B,'name',21,cOB,oNB,gg)
_(b9B,o0B)
_(a6B,b9B)
_(h1B,a6B)
var xAC=_n('view')
_rz(z,xAC,'class',22,cOB,oNB,gg)
var oBC=_n('view')
_rz(z,oBC,'class',23,cOB,oNB,gg)
var fCC=_oz(z,24,cOB,oNB,gg)
_(oBC,fCC)
_(xAC,oBC)
var cDC=_n('view')
_rz(z,cDC,'class',25,cOB,oNB,gg)
var hEC=_oz(z,26,cOB,oNB,gg)
_(cDC,hEC)
var oFC=_n('text')
_rz(z,oFC,'style',27,cOB,oNB,gg)
var cGC=_oz(z,28,cOB,oNB,gg)
_(oFC,cGC)
_(cDC,oFC)
_(xAC,cDC)
_(h1B,xAC)
var oHC=_n('view')
_rz(z,oHC,'class',29,cOB,oNB,gg)
var lIC=_n('view')
_rz(z,lIC,'class',30,cOB,oNB,gg)
var aJC=_oz(z,31,cOB,oNB,gg)
_(lIC,aJC)
_(oHC,lIC)
var tKC=_mz(z,'view',['bindtap',32,'class',1,'data-customer_id',2,'data-order_id',3,'data-service',4],[],cOB,oNB,gg)
var eLC=_oz(z,37,cOB,oNB,gg)
_(tKC,eLC)
_(oHC,tKC)
_(h1B,oHC)
var bMC=_n('view')
_rz(z,bMC,'class',38,cOB,oNB,gg)
var oNC=_oz(z,39,cOB,oNB,gg)
_(bMC,oNC)
var xOC=_n('text')
var oPC=_oz(z,40,cOB,oNB,gg)
_(xOC,oPC)
_(bMC,xOC)
var fQC=_n('text')
var cRC=_oz(z,41,cOB,oNB,gg)
_(fQC,cRC)
_(bMC,fQC)
_(h1B,bMC)
var hSC=_n('view')
_rz(z,hSC,'class',42,cOB,oNB,gg)
var oTC=_oz(z,43,cOB,oNB,gg)
_(hSC,oTC)
var cUC=_n('text')
var oVC=_oz(z,44,cOB,oNB,gg)
_(cUC,oVC)
_(hSC,cUC)
var lWC=_n('text')
var aXC=_oz(z,45,cOB,oNB,gg)
_(lWC,aXC)
_(hSC,lWC)
_(h1B,hSC)
_(tSB,h1B)
_(aRB,tSB)
_(oPB,aRB)
return oPB
}
cLB.wxXCkey=4
_2z(z,2,hMB,e,s,gg,cLB,'item','index','index')
_(oJB,fKB)
_(r,oJB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/custo/component.wxml'] = [$gwx_XC_0, './components/custo/component.wxml'];else __wxAppCode__['components/custo/component.wxml'] = $gwx_XC_0( './components/custo/component.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/custo/component.wxss'] = setCssToHead([".",[1],"page_box{-webkit-align-items:center;align-items:center;background-color:#f6f7fb;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding-top:",[0,20],";width:100vw}\n.",[1],"fl{height:",[0,40],"}\n.",[1],"cus_list{margin-bottom:",[0,200],"}\n.",[1],"box_2{background-color:#fff;border-radius:",[0,12],";display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;margin:",[0,20]," 0;padding:",[0,24]," ",[0,30]," ",[0,30],";width:94vw}\n.",[1],"icon_1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAASCAYAAABit09LAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAACqADAAQAAAABAAAAEgAAAABr6GS2AAAA3UlEQVQoFY3SQQqCQBQGYGcaF1GBtOgGErRrGW1apOCmfdjd2neBQRnoCEFrD9DKhbtg0N4vJDk56gMZ8H3z857IgiC4VlW1c133LKV8OJbiQNRba61VFEVbi3M4khhjOV1Y9mGGBCQBAeOSEOJojlHDMbiBQ7gF+/Af7MI0+2GChllZlr18338SuFBvSgsuOhPDMFyVZXkntKFHc85P3EwzEfXjNE1lK7ELKaVuCGtgH2rgEKrhGASIvwcz1NvRGX9nQvO3sPWMvtObTivCBeF53r4oinmSJDle2OoDm7OjUFLUehAAAAAASUVORK5CYII\x3d) 100% no-repeat;background-size:100% 100%;height:",[0,18],";margin-top:",[0,-20],";width:",[0,10],"}\n.",[1],"icon_1,.",[1],"item_content{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"item_content{-webkit-flex:1;flex:1}\n.",[1],"item_line{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"face{height:",[0,120],";width:",[0,120],"}\n.",[1],"bb{border-bottom:1px solid #eee}\n.",[1],"item_desc{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"item_v{color:#aaa;font-size:",[0,28],";margin-left:",[0,24],"}\n.",[1],"mpbile{color:#777;font-size:",[0,28],";margin-top:",[0,10],";padding-bottom:",[0,20],"}\n.",[1],"eizhi{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,20]," 0 ",[0,10],"}\n.",[1],"eizhi,.",[1],"lt{font-size:",[0,30],"}\n.",[1],"lt{color:#333}\n.",[1],"blue{color:#527fcf;font-size:",[0,36],";text-align:center;width:",[0,120],"}\n.",[1],"green{color:#6ea095}\n.",[1],"orange{color:#e08966}\n",],undefined,{path:"./components/custo/component.wxss"});
}