$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox']],[[4],[[5],[[8],'horizontal',[[2,'==='],[[7],[3,'direction']],[1,'horizontal']]]]]]],[3,' custom-class']])
Z([[2,'==='],[[7],[3,'labelPosition']],[1,'left']])
Z([3,'onClickLabel'])
Z([a,[3,'label-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__label']],[[4],[[5],[[5],[[7],[3,'labelPosition']]],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]]]]]]])
Z([3,'toggle'])
Z([3,'van-checkbox__icon-wrap'])
Z([[7],[3,'useIconSlot']])
Z([3,'icon'])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'checkbox__icon']],[[4],[[5],[[5],[[7],[3,'shape']]],[[9],[[8],'disabled',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'parentDisabled']]]],[[8],'checked',[[7],[3,'value']]]]]]]])
Z([3,'icon-class'])
Z([3,'line-height: 1.25em;'])
Z([3,'success'])
Z([3,'0.8em'])
Z([[12],[[6],[[7],[3,'computed']],[3,'iconStyle']],[[5],[[5],[[5],[[5],[[5],[[7],[3,'checkedColor']]],[[7],[3,'value']]],[[7],[3,'disabled']]],[[7],[3,'parentDisabled']]],[[7],[3,'iconSize']]]])
Z([[2,'==='],[[7],[3,'labelPosition']],[1,'right']])
Z(z[2])
Z([a,z[3][1],z[3][2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./miniprogram_npm/@vant/weapp/checkbox/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var oZE=_n('view')
_rz(z,oZE,'class',0,e,s,gg)
var x1E=_v()
_(oZE,x1E)
if(_oz(z,1,e,s,gg)){x1E.wxVkey=1
var f3E=_mz(z,'view',['bindtap',2,'class',1],[],e,s,gg)
var c4E=_n('slot')
_(f3E,c4E)
_(x1E,f3E)
}
var h5E=_mz(z,'view',['bindtap',4,'class',1],[],e,s,gg)
var o6E=_v()
_(h5E,o6E)
if(_oz(z,6,e,s,gg)){o6E.wxVkey=1
var c7E=_n('slot')
_rz(z,c7E,'name',7,e,s,gg)
_(o6E,c7E)
}
else{o6E.wxVkey=2
var o8E=_mz(z,'van-icon',['class',8,'customClass',1,'customStyle',2,'name',3,'size',4,'style',5],[],e,s,gg)
_(o6E,o8E)
}
o6E.wxXCkey=1
o6E.wxXCkey=3
_(oZE,h5E)
var o2E=_v()
_(oZE,o2E)
if(_oz(z,14,e,s,gg)){o2E.wxVkey=1
var l9E=_mz(z,'view',['bindtap',15,'class',1],[],e,s,gg)
var a0E=_n('slot')
_(l9E,a0E)
_(o2E,l9E)
}
x1E.wxXCkey=1
o2E.wxXCkey=1
_(r,oZE)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/checkbox/index.wxml'] = [$gwx_XC_14, './miniprogram_npm/@vant/weapp/checkbox/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/checkbox/index.wxml'] = $gwx_XC_14( './miniprogram_npm/@vant/weapp/checkbox/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/checkbox/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/checkbox/index.js";define("miniprogram_npm/@vant/weapp/checkbox/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/relation");function a(e,a){e.$emit("input",a),e.$emit("change",a)}(0,require("../common/component").VantComponent)({field:!0,relation:(0,e.useParent)("checkbox-group"),classes:["icon-class","label-class"],props:{value:Boolean,disabled:Boolean,useIconSlot:Boolean,checkedColor:String,labelPosition:{type:String,value:"right"},labelDisabled:Boolean,shape:{type:String,value:"round"},iconSize:{type:null,value:20}},data:{parentDisabled:!1,direction:"vertical"},methods:{emitChange:function(e){this.parent?this.setParentValue(this.parent,e):a(this,e)},toggle:function(){var e=this.data,a=e.parentDisabled,t=e.disabled,i=e.value;t||a||this.emitChange(!i)},onClickLabel:function(){var e=this.data,a=e.labelDisabled,t=e.parentDisabled,i=e.disabled,n=e.value;i||a||t||this.emitChange(!n)},setParentValue:function(e,t){var i=e.data.value.slice(),n=this.data.name,l=e.data.max;if(t){if(l&&i.length>=l)return;-1===i.indexOf(n)&&(i.push(n),a(e,i))}else{var o=i.indexOf(n);-1!==o&&(i.splice(o,1),a(e,i))}}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/checkbox/index.js'});require("miniprogram_npm/@vant/weapp/checkbox/index.js");