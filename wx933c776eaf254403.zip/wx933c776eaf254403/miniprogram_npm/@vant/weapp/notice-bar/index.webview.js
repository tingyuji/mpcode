$gwx_XC_40=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_40 || [];
function gz$gwx_XC_40_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_40_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'onClick'])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'notice-bar']],[[9],[[8],'withicon',[[7],[3,'mode']]],[[8],'wrapable',[[7],[3,'wrapable']]]]]]])
Z([[12],[[6],[[7],[3,'computed']],[3,'rootStyle']],[[5],[[9],[[9],[[8],'color',[[7],[3,'color']]],[[8],'backgroundColor',[[7],[3,'backgroundColor']]]],[[8],'background',[[7],[3,'background']]]]]])
Z([[7],[3,'leftIcon']])
Z([3,'van-notice-bar__left-icon'])
Z(z[4])
Z([3,'left-icon'])
Z([3,'van-notice-bar__wrap'])
Z([[7],[3,'animationData']])
Z([a,[3,'van-notice-bar__content '],[[2,'?:'],[[2,'&&'],[[2,'==='],[[7],[3,'scrollable']],[1,false]],[[2,'!'],[[7],[3,'wrapable']]]],[1,'van-ellipsis'],[1,'']]])
Z([a,[3,' '],[[7],[3,'text']],[3,' ']])
Z([[2,'!'],[[7],[3,'text']]])
Z([[2,'==='],[[7],[3,'mode']],[1,'closeable']])
Z([3,'onClickIcon'])
Z([3,'van-notice-bar__right-icon'])
Z([3,'cross'])
Z([[2,'==='],[[7],[3,'mode']],[1,'link']])
Z([[7],[3,'openType']])
Z([[7],[3,'url']])
Z(z[15])
Z([3,'arrow'])
Z([3,'right-icon'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_40_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_40_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_40=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_40=true;
var x=['./miniprogram_npm/@vant/weapp/notice-bar/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_40_1()
var t1V=_v()
_(r,t1V)
if(_oz(z,0,e,s,gg)){t1V.wxVkey=1
var e2V=_mz(z,'view',['bind:tap',1,'class',1,'style',2],[],e,s,gg)
var b3V=_v()
_(e2V,b3V)
if(_oz(z,4,e,s,gg)){b3V.wxVkey=1
var x5V=_mz(z,'van-icon',['class',5,'name',1],[],e,s,gg)
_(b3V,x5V)
}
else{b3V.wxVkey=2
var o6V=_n('slot')
_rz(z,o6V,'name',7,e,s,gg)
_(b3V,o6V)
}
var f7V=_n('view')
_rz(z,f7V,'class',8,e,s,gg)
var c8V=_mz(z,'view',['animation',9,'class',1],[],e,s,gg)
var o0V=_oz(z,11,e,s,gg)
_(c8V,o0V)
var h9V=_v()
_(c8V,h9V)
if(_oz(z,12,e,s,gg)){h9V.wxVkey=1
var cAW=_n('slot')
_(h9V,cAW)
}
h9V.wxXCkey=1
_(f7V,c8V)
_(e2V,f7V)
var o4V=_v()
_(e2V,o4V)
if(_oz(z,13,e,s,gg)){o4V.wxVkey=1
var oBW=_mz(z,'van-icon',['catch:tap',14,'class',1,'name',2],[],e,s,gg)
_(o4V,oBW)
}
else if(_oz(z,17,e,s,gg)){o4V.wxVkey=2
var lCW=_mz(z,'navigator',['openType',18,'url',1],[],e,s,gg)
var aDW=_mz(z,'van-icon',['class',20,'name',1],[],e,s,gg)
_(lCW,aDW)
_(o4V,lCW)
}
else{o4V.wxVkey=3
var tEW=_n('slot')
_rz(z,tEW,'name',22,e,s,gg)
_(o4V,tEW)
}
b3V.wxXCkey=1
b3V.wxXCkey=3
o4V.wxXCkey=1
o4V.wxXCkey=3
o4V.wxXCkey=3
_(t1V,e2V)
}
t1V.wxXCkey=1
t1V.wxXCkey=3
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_40";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_40();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/notice-bar/index.wxml'] = [$gwx_XC_40, './miniprogram_npm/@vant/weapp/notice-bar/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/notice-bar/index.wxml'] = $gwx_XC_40( './miniprogram_npm/@vant/weapp/notice-bar/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/notice-bar/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-notice-bar{-webkit-align-items:center;align-items:center;background-color:var(--notice-bar-background-color,#fffbe8);color:var(--notice-bar-text-color,#ed6a0c);display:-webkit-flex;display:flex;font-size:var(--notice-bar-font-size,14px);height:var(--notice-bar-height,40px);line-height:var(--notice-bar-line-height,24px);padding:var(--notice-bar-padding,0 16px)}\n.",[1],"van-notice-bar--withicon{padding-right:40px;position:relative}\n.",[1],"van-notice-bar--wrapable{height:auto;padding:var(--notice-bar-wrapable-padding,8px 16px)}\n.",[1],"van-notice-bar--wrapable .",[1],"van-notice-bar__wrap{height:auto}\n.",[1],"van-notice-bar--wrapable .",[1],"van-notice-bar__content{position:relative;white-space:normal}\n.",[1],"van-notice-bar__left-icon{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin-right:4px;vertical-align:middle}\n.",[1],"van-notice-bar__left-icon,.",[1],"van-notice-bar__right-icon{font-size:var(--notice-bar-icon-size,16px);min-width:var(--notice-bar-icon-min-width,22px)}\n.",[1],"van-notice-bar__right-icon{position:absolute;right:15px;top:10px}\n.",[1],"van-notice-bar__wrap{-webkit-flex:1;flex:1;height:var(--notice-bar-line-height,24px);overflow:hidden;position:relative}\n.",[1],"van-notice-bar__content{position:absolute;white-space:nowrap}\n.",[1],"van-notice-bar__content.",[1],"van-ellipsis{max-width:100%}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/notice-bar/index.wxss"});
}