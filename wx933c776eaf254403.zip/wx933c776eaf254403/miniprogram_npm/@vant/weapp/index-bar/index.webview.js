$gwx_XC_36=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_36 || [];
function gz$gwx_XC_36_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-index-bar'])
Z([[7],[3,'showSidebar']])
Z([3,'onClick'])
Z([3,'onTouchStop'])
Z(z[3])
Z([3,'onTouchMove'])
Z([3,'van-index-bar__sidebar'])
Z([[7],[3,'indexList']])
Z([3,'index'])
Z([3,'van-index-bar__index'])
Z([[7],[3,'index']])
Z([a,[3,'z-index: '],[[2,'+'],[[7],[3,'zIndex']],[1,1]],[3,'; color: '],[[2,'?:'],[[2,'==='],[[7],[3,'activeAnchorIndex']],[[7],[3,'index']]],[[7],[3,'highlightColor']],[1,'']]])
Z([a,[3,' '],[[7],[3,'item']],[3,' ']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_36=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_36=true;
var x=['./miniprogram_npm/@vant/weapp/index-bar/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_36_1()
var xKU=_n('view')
_rz(z,xKU,'class',0,e,s,gg)
var fMU=_n('slot')
_(xKU,fMU)
var oLU=_v()
_(xKU,oLU)
if(_oz(z,1,e,s,gg)){oLU.wxVkey=1
var cNU=_mz(z,'view',['catch:tap',2,'catch:touchcancel',1,'catch:touchend',2,'catch:touchmove',3,'class',4],[],e,s,gg)
var hOU=_v()
_(cNU,hOU)
var oPU=function(oRU,cQU,lSU,gg){
var tUU=_mz(z,'view',['class',9,'data-index',1,'style',2],[],oRU,cQU,gg)
var eVU=_oz(z,12,oRU,cQU,gg)
_(tUU,eVU)
_(lSU,tUU)
return lSU
}
hOU.wxXCkey=2
_2z(z,7,oPU,e,s,gg,hOU,'item','index','index')
_(oLU,cNU)
}
oLU.wxXCkey=1
_(r,xKU)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_36";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_36();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/index-bar/index.wxml'] = [$gwx_XC_36, './miniprogram_npm/@vant/weapp/index-bar/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/index-bar/index.wxml'] = $gwx_XC_36( './miniprogram_npm/@vant/weapp/index-bar/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/index-bar/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-index-bar{position:relative}\n.",[1],"van-index-bar__sidebar{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;position:fixed;right:0;text-align:center;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);-webkit-user-select:none;user-select:none}\n.",[1],"van-index-bar__index{font-size:var(--index-bar-index-font-size,10px);font-weight:500;line-height:var(--index-bar-index-line-height,14px);padding:0 var(--padding-base,4px) 0 var(--padding-md,16px)}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/index-bar/index.wxss"});
}