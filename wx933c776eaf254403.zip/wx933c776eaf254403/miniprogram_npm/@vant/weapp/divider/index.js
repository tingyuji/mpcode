Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").VantComponent)({
    props: {
        dashed: Boolean,
        hairline: Boolean,
        contentPosition: String,
        fontSize: String,
        borderColor: String,
        textColor: String,
        customStyle: String
    }
});