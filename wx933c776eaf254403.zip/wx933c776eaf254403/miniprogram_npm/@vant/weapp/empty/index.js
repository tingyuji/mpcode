Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").VantComponent)({
    props: {
        description: String,
        image: {
            type: String,
            value: "default"
        }
    }
});