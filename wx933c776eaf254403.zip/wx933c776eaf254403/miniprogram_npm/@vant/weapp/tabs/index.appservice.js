$gwx_XC_68=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_68 || [];
function gz$gwx_XC_68_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tabs']],[[4],[[5],[[7],[3,'type']]]]]]])
Z([3,'onTouchScroll'])
Z([[7],[3,'container']])
Z([[2,'!'],[[7],[3,'sticky']]])
Z([[7],[3,'offsetTop']])
Z([[7],[3,'zIndex']])
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tabs__wrap']],[[8],'scrollable',[[7],[3,'scrollable']]]]],[3,' '],[[2,'?:'],[[2,'&&'],[[2,'==='],[[7],[3,'type']],[1,'line']],[[7],[3,'border']]],[1,'van-hairline--top-bottom'],[1,'']]])
Z([3,'nav-left'])
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tabs__nav']],[[4],[[5],[[5],[[7],[3,'type']]],[[8],'complete',[[2,'!'],[[7],[3,'ellipsis']]]]]]]],[3,' nav-class']])
Z([[12],[[6],[[7],[3,'computed']],[3,'navStyle']],[[5],[[5],[[7],[3,'color']]],[[7],[3,'type']]]])
Z([[2,'==='],[[7],[3,'type']],[1,'line']])
Z([[7],[3,'tabs']])
Z([3,'index'])
Z([3,'onTap'])
Z([a,[[12],[[6],[[7],[3,'computed']],[3,'tabClass']],[[5],[[5],[[2,'==='],[[7],[3,'index']],[[7],[3,'currentIndex']]]],[[7],[3,'ellipsis']]]],z[6][2],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'tab']],[[9],[[9],[[8],'active',[[2,'==='],[[7],[3,'index']],[[7],[3,'currentIndex']]]],[[8],'disabled',[[6],[[7],[3,'item']],[3,'disabled']]]],[[8],'complete',[[2,'!'],[[7],[3,'ellipsis']]]]]]]])
Z([[7],[3,'index']])
Z([[12],[[6],[[7],[3,'computed']],[3,'tabStyle']],[[5],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[8],'active',[[2,'==='],[[7],[3,'index']],[[7],[3,'currentIndex']]]],[[8],'ellipsis',[[7],[3,'ellipsis']]]],[[8],'color',[[7],[3,'color']]]],[[8],'type',[[7],[3,'type']]]],[[8],'disabled',[[6],[[7],[3,'item']],[3,'disabled']]]],[[8],'titleActiveColor',[[7],[3,'titleActiveColor']]]],[[8],'titleInactiveColor',[[7],[3,'titleInactiveColor']]]],[[8],'swipeThreshold',[[7],[3,'swipeThreshold']]]],[[8],'scrollable',[[7],[3,'scrollable']]]]]])
Z([[2,'||'],[[2,'!=='],[[6],[[7],[3,'item']],[3,'info']],[1,null]],[[6],[[7],[3,'item']],[3,'dot']]])
Z([3,'van-tab__title__info'])
Z([[6],[[7],[3,'item']],[3,'dot']])
Z([[6],[[7],[3,'item']],[3,'info']])
Z([3,'nav-right'])
Z([3,'onTouchEnd'])
Z(z[22])
Z([3,'onTouchMove'])
Z([3,'onTouchStart'])
Z([3,'van-tabs__content'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_68=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_68=true;
var x=['./miniprogram_npm/@vant/weapp/tabs/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_68_1()
var h1P=_n('view')
_rz(z,h1P,'class',0,e,s,gg)
var o2P=_mz(z,'van-sticky',['bind:scroll',1,'container',1,'disabled',2,'offsetTop',3,'zIndex',4],[],e,s,gg)
var c3P=_n('view')
_rz(z,c3P,'class',6,e,s,gg)
var o4P=_n('slot')
_rz(z,o4P,'name',7,e,s,gg)
_(c3P,o4P)
var l5P=_mz(z,'view',['class',8,'style',1],[],e,s,gg)
var a6P=_v()
_(l5P,a6P)
if(_oz(z,10,e,s,gg)){a6P.wxVkey=1
}
var t7P=_v()
_(l5P,t7P)
var e8P=function(o0P,b9P,xAQ,gg){
var fCQ=_mz(z,'view',['bind:tap',13,'class',1,'data-index',2,'style',3],[],o0P,b9P,gg)
var cDQ=_v()
_(fCQ,cDQ)
if(_oz(z,17,o0P,b9P,gg)){cDQ.wxVkey=1
var hEQ=_mz(z,'van-info',['customClass',18,'dot',1,'info',2],[],o0P,b9P,gg)
_(cDQ,hEQ)
}
cDQ.wxXCkey=1
cDQ.wxXCkey=3
_(xAQ,fCQ)
return xAQ
}
t7P.wxXCkey=4
_2z(z,11,e8P,e,s,gg,t7P,'item','index','index')
a6P.wxXCkey=1
_(c3P,l5P)
var oFQ=_n('slot')
_rz(z,oFQ,'name',21,e,s,gg)
_(c3P,oFQ)
_(o2P,c3P)
_(h1P,o2P)
var cGQ=_mz(z,'view',['bind:touchcancel',22,'bind:touchend',1,'bind:touchmove',2,'bind:touchstart',3,'class',4],[],e,s,gg)
var oHQ=_n('slot')
_(cGQ,oHQ)
_(h1P,cGQ)
_(r,h1P)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_68";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_68();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/tabs/index.wxml'] = [$gwx_XC_68, './miniprogram_npm/@vant/weapp/tabs/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/tabs/index.wxml'] = $gwx_XC_68( './miniprogram_npm/@vant/weapp/tabs/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/tabs/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/tabs/index.js";define("miniprogram_npm/@vant/weapp/tabs/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t=require("../common/component"),e=require("../mixins/touch"),i=require("../common/utils"),n=require("../common/validator"),a=require("../common/relation");(0,t.VantComponent)({mixins:[e.touch],classes:["nav-class","tab-class","tab-active-class","line-class"],relation:(0,a.useChildren)("tab",(function(){this.updateTabs()})),props:{sticky:Boolean,border:Boolean,swipeable:Boolean,titleActiveColor:String,titleInactiveColor:String,color:String,animated:{type:Boolean,observer:function(){var t=this;this.children.forEach((function(e,i){return e.updateRender(i===t.data.currentIndex,t)}))}},lineWidth:{type:null,value:40,observer:"resize"},lineHeight:{type:null,value:-1},active:{type:null,value:0,observer:function(t){t!==this.getCurrentName()&&this.setCurrentIndexByName(t)}},type:{type:String,value:"line"},ellipsis:{type:Boolean,value:!0},duration:{type:Number,value:.3},zIndex:{type:Number,value:1},swipeThreshold:{type:Number,value:5,observer:function(t){this.setData({scrollable:this.children.length>t||!this.data.ellipsis})}},offsetTop:{type:Number,value:0},lazyRender:{type:Boolean,value:!0}},data:{tabs:[],scrollLeft:0,scrollable:!1,currentIndex:0,container:null,skipTransition:!0,scrollWithAnimation:!1,lineOffsetLeft:0},mounted:function(){var t=this;(0,i.requestAnimationFrame)((function(){t.swiping=!0,t.setData({container:function(){return t.createSelectorQuery().select(".van-tabs")}}),t.resize(),t.scrollIntoView()}))},methods:{updateTabs:function(){var t=this.children,e=void 0===t?[]:t,i=this.data;this.setData({tabs:e.map((function(t){return t.data})),scrollable:this.children.length>i.swipeThreshold||!i.ellipsis}),this.setCurrentIndexByName(i.active||this.getCurrentName())},trigger:function(t,e){var i=this.data.currentIndex,a=e||this.children[i];(0,n.isDef)(a)&&this.$emit(t,{index:a.index,name:a.getComputedName(),title:a.data.title})},onTap:function(t){var e=this,n=t.currentTarget.dataset.index,a=this.children[n];a.data.disabled?this.trigger("disabled",a):(this.setCurrentIndex(n),(0,i.nextTick)((function(){e.trigger("click")})))},setCurrentIndexByName:function(t){var e=this.children,i=(void 0===e?[]:e).filter((function(e){return e.getComputedName()===t}));i.length&&this.setCurrentIndex(i[0].index)},setCurrentIndex:function(t){var e=this,a=this.data,r=this.children,s=void 0===r?[]:r;if(!(!(0,n.isDef)(t)||t>=s.length||t<0)&&((0,i.groupSetData)(this,(function(){s.forEach((function(i,n){var a=n===t;a===i.data.active&&i.inited||i.updateRender(a,e)}))})),t!==a.currentIndex)){var o=null!==a.currentIndex;this.setData({currentIndex:t}),(0,i.requestAnimationFrame)((function(){e.resize(),e.scrollIntoView()})),(0,i.nextTick)((function(){e.trigger("input"),o&&e.trigger("change")}))}},getCurrentName:function(){var t=this.children[this.data.currentIndex];if(t)return t.getComputedName()},resize:function(){var t=this;if("line"===this.data.type){var e=this.data,n=e.currentIndex,a=e.ellipsis,r=e.skipTransition;Promise.all([(0,i.getAllRect)(this,".van-tab"),(0,i.getRect)(this,".van-tabs__line")]).then((function(e){var s=e[0],o=void 0===s?[]:s,l=e[1],c=o[n];if(null!=c){var u=o.slice(0,n).reduce((function(t,e){return t+e.width}),0);u+=(c.width-l.width)/2+(a?0:8),t.setData({lineOffsetLeft:u}),t.swiping=!0,r&&(0,i.nextTick)((function(){t.setData({skipTransition:!1})}))}}))}},scrollIntoView:function(){var t=this,e=this.data,n=e.currentIndex,a=e.scrollable,r=e.scrollWithAnimation;a&&Promise.all([(0,i.getAllRect)(this,".van-tab"),(0,i.getRect)(this,".van-tabs__nav")]).then((function(e){var a=e[0],s=e[1],o=a[n],l=a.slice(0,n).reduce((function(t,e){return t+e.width}),0);t.setData({scrollLeft:l-(s.width-o.width)/2}),r||(0,i.nextTick)((function(){t.setData({scrollWithAnimation:!0})}))}))},onTouchScroll:function(t){this.$emit("scroll",t.detail)},onTouchStart:function(t){this.data.swipeable&&(this.swiping=!0,this.touchStart(t))},onTouchMove:function(t){this.data.swipeable&&this.swiping&&this.touchMove(t)},onTouchEnd:function(){if(this.data.swipeable&&this.swiping){var t=this.direction,e=this.deltaX,i=this.offsetX;if("horizontal"===t&&i>=50){var n=this.getAvaiableTab(e);-1!==n&&this.setCurrentIndex(n)}this.swiping=!1}},getAvaiableTab:function(t){for(var e=this.data,i=e.tabs,n=e.currentIndex,a=t>0?-1:1,r=a;n+r<i.length&&n+r>=0;r+=a){var s=n+r;if(s>=0&&s<i.length&&i[s]&&!i[s].disabled)return s}return-1}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/tabs/index.js'});require("miniprogram_npm/@vant/weapp/tabs/index.js");