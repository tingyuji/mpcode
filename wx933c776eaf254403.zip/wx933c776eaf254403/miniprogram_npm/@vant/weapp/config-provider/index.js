Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").VantComponent)({
    props: {
        themeVars: {
            type: Object,
            value: {}
        }
    }
});