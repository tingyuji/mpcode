$gwx_XC_62=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_62 || [];
function gz$gwx_XC_62_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_62_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'van-submit-bar custom-class'])
Z([3,'top'])
Z([3,'van-submit-bar__tip'])
Z([[7],[3,'tipIcon']])
Z([3,'van-submit-bar__tip-icon'])
Z(z[3])
Z([3,'12px'])
Z([[7],[3,'hasTip']])
Z([3,'van-submit-bar__tip-text'])
Z([a,[3,' '],[[7],[3,'tip']],[3,' ']])
Z([3,'tip'])
Z([3,'bar-class van-submit-bar__bar'])
Z([[7],[3,'hasPrice']])
Z([3,'van-submit-bar__text'])
Z([a,[[2,'||'],[[7],[3,'label']],[1,'合计：']]])
Z([3,'van-submit-bar__price price-class'])
Z([3,'van-submit-bar__currency'])
Z([a,[[7],[3,'currency']],z[9][1]])
Z([3,'van-submit-bar__price-integer'])
Z([a,[[7],[3,'integerStr']]])
Z([a,[[7],[3,'decimalStr']]])
Z([3,'van-submit-bar__suffix-label'])
Z([a,[[7],[3,'suffixLabel']]])
Z([3,'onSubmit'])
Z([3,'van-submit-bar__button'])
Z([3,'button-class'])
Z([3,'width: 100%;'])
Z([[7],[3,'disabled']])
Z([[7],[3,'loading']])
Z([[7],[3,'buttonType']])
Z([a,z[9][1],[[2,'?:'],[[7],[3,'loading']],[1,''],[[7],[3,'buttonText']]],z[9][1]])
Z([[7],[3,'safeAreaInsetBottom']])
Z([3,'van-submit-bar__safe'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_62_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_62=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_62=true;
var x=['./miniprogram_npm/@vant/weapp/submit-bar/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_62_1()
var b33=_n('view')
_rz(z,b33,'class',0,e,s,gg)
var x53=_n('slot')
_rz(z,x53,'name',1,e,s,gg)
_(b33,x53)
var o63=_n('view')
_rz(z,o63,'class',2,e,s,gg)
var f73=_v()
_(o63,f73)
if(_oz(z,3,e,s,gg)){f73.wxVkey=1
var h93=_mz(z,'van-icon',['customClass',4,'name',1,'size',2],[],e,s,gg)
_(f73,h93)
}
var c83=_v()
_(o63,c83)
if(_oz(z,7,e,s,gg)){c83.wxVkey=1
var o03=_n('view')
_rz(z,o03,'class',8,e,s,gg)
var cA4=_oz(z,9,e,s,gg)
_(o03,cA4)
_(c83,o03)
}
var oB4=_n('slot')
_rz(z,oB4,'name',10,e,s,gg)
_(o63,oB4)
f73.wxXCkey=1
f73.wxXCkey=3
c83.wxXCkey=1
_(b33,o63)
var lC4=_n('view')
_rz(z,lC4,'class',11,e,s,gg)
var tE4=_n('slot')
_(lC4,tE4)
var aD4=_v()
_(lC4,aD4)
if(_oz(z,12,e,s,gg)){aD4.wxVkey=1
var eF4=_n('view')
_rz(z,eF4,'class',13,e,s,gg)
var bG4=_n('text')
var oH4=_oz(z,14,e,s,gg)
_(bG4,oH4)
_(eF4,bG4)
var xI4=_n('text')
_rz(z,xI4,'class',15,e,s,gg)
var oJ4=_n('text')
_rz(z,oJ4,'class',16,e,s,gg)
var fK4=_oz(z,17,e,s,gg)
_(oJ4,fK4)
_(xI4,oJ4)
var cL4=_n('text')
_rz(z,cL4,'class',18,e,s,gg)
var hM4=_oz(z,19,e,s,gg)
_(cL4,hM4)
_(xI4,cL4)
var oN4=_n('text')
var cO4=_oz(z,20,e,s,gg)
_(oN4,cO4)
_(xI4,oN4)
_(eF4,xI4)
var oP4=_n('text')
_rz(z,oP4,'class',21,e,s,gg)
var lQ4=_oz(z,22,e,s,gg)
_(oP4,lQ4)
_(eF4,oP4)
_(aD4,eF4)
}
var aR4=_mz(z,'van-button',['round',-1,'bind:click',23,'class',1,'customClass',2,'customStyle',3,'disabled',4,'loading',5,'type',6],[],e,s,gg)
var tS4=_oz(z,30,e,s,gg)
_(aR4,tS4)
_(lC4,aR4)
aD4.wxXCkey=1
_(b33,lC4)
var o43=_v()
_(b33,o43)
if(_oz(z,31,e,s,gg)){o43.wxVkey=1
var eT4=_n('view')
_rz(z,eT4,'class',32,e,s,gg)
_(o43,eT4)
}
o43.wxXCkey=1
_(r,b33)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_62";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_62();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/submit-bar/index.wxml'] = [$gwx_XC_62, './miniprogram_npm/@vant/weapp/submit-bar/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/submit-bar/index.wxml'] = $gwx_XC_62( './miniprogram_npm/@vant/weapp/submit-bar/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/submit-bar/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-submit-bar{background-color:var(--submit-bar-background-color,#fff);bottom:0;left:0;position:fixed;-webkit-user-select:none;user-select:none;width:100%;z-index:var(--submit-bar-z-index,100)}\n.",[1],"van-submit-bar__tip{background-color:var(--submit-bar-tip-background-color,#fff7cc);color:var(--submit-bar-tip-color,#f56723);font-size:var(--submit-bar-tip-font-size,12px);line-height:var(--submit-bar-tip-line-height,1.5);padding:var(--submit-bar-tip-padding,10px)}\n.",[1],"van-submit-bar__tip:empty{display:none}\n.",[1],"van-submit-bar__tip-icon{margin-right:4px;vertical-align:middle}\n.",[1],"van-submit-bar__tip-text{display:inline;vertical-align:middle}\n.",[1],"van-submit-bar__bar{-webkit-align-items:center;align-items:center;background-color:var(--submit-bar-background-color,#fff);display:-webkit-flex;display:flex;font-size:var(--submit-bar-text-font-size,14px);height:var(--submit-bar-height,50px);-webkit-justify-content:flex-end;justify-content:flex-end;padding:var(--submit-bar-padding,0 16px)}\n.",[1],"van-submit-bar__safe{height:constant(safe-area-inset-bottom);height:env(safe-area-inset-bottom)}\n.",[1],"van-submit-bar__text{color:var(--submit-bar-text-color,#323233);-webkit-flex:1;flex:1;font-weight:var(--font-weight-bold,500);padding-right:var(--padding-sm,12px);text-align:right}\n.",[1],"van-submit-bar__price{color:var(--submit-bar-price-color,#ee0a24);font-size:var(--submit-bar-price-font-size,12px);font-weight:var(--font-weight-bold,500)}\n.",[1],"van-submit-bar__price-integer{font-family:Avenir-Heavy,PingFang SC,Helvetica Neue,Arial,sans-serif;font-size:20px}\n.",[1],"van-submit-bar__currency{font-size:var(--submit-bar-currency-font-size,12px)}\n.",[1],"van-submit-bar__suffix-label{margin-left:5px}\n.",[1],"van-submit-bar__button{--button-default-height:var(--submit-bar-button-height,40px)!important;--button-line-height:var(--submit-bar-button-height,40px)!important;font-weight:var(--font-weight-bold,500);width:var(--submit-bar-button-width,110px)}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/submit-bar/index.wxss"});
}