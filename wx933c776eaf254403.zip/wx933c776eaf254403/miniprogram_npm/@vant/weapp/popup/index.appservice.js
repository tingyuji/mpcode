$gwx_XC_46=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_46 || [];
function gz$gwx_XC_46_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'overlay']])
Z([3,'onClickOverlay'])
Z([[7],[3,'overlayStyle']])
Z([[7],[3,'duration']])
Z([[7],[3,'lockScroll']])
Z([[7],[3,'show']])
Z([[7],[3,'zIndex']])
Z([[7],[3,'inited']])
Z([3,'onTransitionEnd'])
Z([a,[3,'custom-class '],[[7],[3,'classes']],[3,' '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'popup']],[[4],[[5],[[5],[[7],[3,'position']]],[[9],[[9],[[8],'round',[[7],[3,'round']]],[[8],'safe',[[7],[3,'safeAreaInsetBottom']]]],[[8],'safeTop',[[7],[3,'safeAreaInsetTop']]]]]]]]])
Z([[12],[[6],[[7],[3,'computed']],[3,'popupStyle']],[[5],[[9],[[9],[[9],[[8],'zIndex',[[7],[3,'zIndex']]],[[8],'currentDuration',[[7],[3,'currentDuration']]]],[[8],'display',[[7],[3,'display']]]],[[8],'customStyle',[[7],[3,'customStyle']]]]]])
Z([[7],[3,'closeable']])
Z([3,'onClickCloseIcon'])
Z([a,[3,'close-icon-class van-popup__close-icon van-popup__close-icon--'],[[7],[3,'closeIconPosition']]])
Z([[7],[3,'closeIcon']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_46=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_46=true;
var x=['./miniprogram_npm/@vant/weapp/popup/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_46_1()
var t5K=_v()
_(r,t5K)
if(_oz(z,0,e,s,gg)){t5K.wxVkey=1
var b7K=_mz(z,'van-overlay',['bind:click',1,'customStyle',1,'duration',2,'lockScroll',3,'show',4,'zIndex',5],[],e,s,gg)
_(t5K,b7K)
}
var e6K=_v()
_(r,e6K)
if(_oz(z,7,e,s,gg)){e6K.wxVkey=1
var o8K=_mz(z,'view',['bind:transitionend',8,'class',1,'style',2],[],e,s,gg)
var o0K=_n('slot')
_(o8K,o0K)
var x9K=_v()
_(o8K,x9K)
if(_oz(z,11,e,s,gg)){x9K.wxVkey=1
var fAL=_mz(z,'van-icon',['bind:tap',12,'class',1,'name',2],[],e,s,gg)
_(x9K,fAL)
}
x9K.wxXCkey=1
x9K.wxXCkey=3
_(e6K,o8K)
}
t5K.wxXCkey=1
t5K.wxXCkey=3
e6K.wxXCkey=1
e6K.wxXCkey=3
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_46";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_46();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/popup/index.wxml'] = [$gwx_XC_46, './miniprogram_npm/@vant/weapp/popup/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/popup/index.wxml'] = $gwx_XC_46( './miniprogram_npm/@vant/weapp/popup/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/popup/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/popup/index.js";define("miniprogram_npm/@vant/weapp/popup/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),o=require("../mixins/transition");(0,e.VantComponent)({classes:["enter-class","enter-active-class","enter-to-class","leave-class","leave-active-class","leave-to-class","close-icon-class"],mixins:[(0,o.transition)(!1)],props:{round:Boolean,closeable:Boolean,customStyle:String,overlayStyle:String,transition:{type:String,observer:"observeClass"},zIndex:{type:Number,value:100},overlay:{type:Boolean,value:!0},closeIcon:{type:String,value:"cross"},closeIconPosition:{type:String,value:"top-right"},closeOnClickOverlay:{type:Boolean,value:!0},position:{type:String,value:"center",observer:"observeClass"},safeAreaInsetBottom:{type:Boolean,value:!0},safeAreaInsetTop:{type:Boolean,value:!1},lockScroll:{type:Boolean,value:!0}},created:function(){this.observeClass()},methods:{onClickCloseIcon:function(){this.$emit("close")},onClickOverlay:function(){this.$emit("click-overlay"),this.data.closeOnClickOverlay&&this.$emit("close")},observeClass:function(){var e=this.data,o=e.transition,t=e.position,s=e.duration,n={name:o||t};"none"===o?(n.duration=0,this.originDuration=s):null!=this.originDuration&&(n.duration=this.originDuration),this.setData(n)}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/popup/index.js'});require("miniprogram_npm/@vant/weapp/popup/index.js");