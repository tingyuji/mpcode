$gwx_XC_29=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_29 || [];
function gz$gwx_XC_29_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([3,'onClick'])
Z([3,'onContact'])
Z([3,'onError'])
Z([3,'onGetPhoneNumber'])
Z([3,'onGetUserInfo'])
Z([3,'onLaunchApp'])
Z([3,'onOpenSetting'])
Z([[7],[3,'businessId']])
Z([3,'van-goods-action-icon'])
Z([[7],[3,'disabled']])
Z([[7],[3,'id']])
Z([[7],[3,'lang']])
Z([[7],[3,'loading']])
Z([[7],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([3,'large'])
Z([[7],[3,'icon']])
Z([3,'van-goods-action-icon__icon'])
Z([[7],[3,'classPrefix']])
Z([3,'icon-class'])
Z([[7],[3,'dot']])
Z([[7],[3,'info']])
Z(z[21])
Z([3,'icon'])
Z([3,'text-class'])
Z([a,[[7],[3,'text']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_29=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_29=true;
var x=['./miniprogram_npm/@vant/weapp/goods-action-icon/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_29_1()
var f3S=_mz(z,'van-button',['square',-1,'appParameter',0,'bind:click',1,'bindcontact',1,'binderror',2,'bindgetphonenumber',3,'bindgetuserinfo',4,'bindlaunchapp',5,'bindopensetting',6,'businessId',7,'customClass',8,'disabled',9,'id',10,'lang',11,'loading',12,'openType',13,'sendMessageImg',14,'sendMessagePath',15,'sendMessageTitle',16,'sessionFrom',17,'showMessageCard',18,'size',19],[],e,s,gg)
var c4S=_v()
_(f3S,c4S)
if(_oz(z,21,e,s,gg)){c4S.wxVkey=1
var h5S=_mz(z,'van-icon',['class',22,'classPrefix',1,'customClass',2,'dot',3,'info',4,'name',5],[],e,s,gg)
_(c4S,h5S)
}
else{c4S.wxVkey=2
var o6S=_n('slot')
_rz(z,o6S,'name',28,e,s,gg)
_(c4S,o6S)
}
var c7S=_n('text')
_rz(z,c7S,'class',29,e,s,gg)
var o8S=_oz(z,30,e,s,gg)
_(c7S,o8S)
_(f3S,c7S)
c4S.wxXCkey=1
c4S.wxXCkey=3
_(r,f3S)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_29";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_29();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/goods-action-icon/index.wxml'] = [$gwx_XC_29, './miniprogram_npm/@vant/weapp/goods-action-icon/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/goods-action-icon/index.wxml'] = $gwx_XC_29( './miniprogram_npm/@vant/weapp/goods-action-icon/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/goods-action-icon/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-goods-action-icon{border:none!important;color:var(--goods-action-icon-text-color,#646566)!important;display:-webkit-flex!important;display:flex!important;-webkit-flex-direction:column;flex-direction:column;font-size:var(--goods-action-icon-font-size,10px)!important;height:var(--goods-action-icon-height,50px)!important;-webkit-justify-content:center!important;justify-content:center!important;line-height:1!important;min-width:var(--goods-action-icon-width,48px)}\n.",[1],"van-goods-action-icon__icon{color:var(--goods-action-icon-color,#323233);display:-webkit-flex;display:flex;font-size:var(--goods-action-icon-size,18px);margin:0 auto 5px}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/goods-action-icon/index.wxss"});
}