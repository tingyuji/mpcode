$gwx_XC_57=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_57 || [];
function gz$gwx_XC_57_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_57_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'loading']])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'skeleton']],[[4],[[5],[[8],'animate',[[7],[3,'animate']]]]]]]])
Z([[7],[3,'avatar']])
Z([a,[3,'avatar-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'skeleton__avatar']],[[4],[[5],[[7],[3,'avatarShape']]]]]]])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[[7],[3,'avatarSize']]],[1,';height:']],[[7],[3,'avatarSize']]])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'skeleton__content']]])
Z([[7],[3,'title']])
Z([a,[3,'title-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'skeleton__title']]]])
Z([[2,'+'],[1,'width:'],[[7],[3,'titleWidth']]])
Z([3,'index'])
Z([[7],[3,'rowArray']])
Z(z[9])
Z([a,[3,'row-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[1,'skeleton__row']]]])
Z([[2,'+'],[1,'width:'],[[2,'?:'],[[7],[3,'isArray']],[[6],[[7],[3,'rowWidth']],[[7],[3,'index']]],[[7],[3,'rowWidth']]]])
Z(z[5])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_57_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_57_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_57=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_57=true;
var x=['./miniprogram_npm/@vant/weapp/skeleton/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_57_1()
var e41=_v()
_(r,e41)
if(_oz(z,0,e,s,gg)){e41.wxVkey=1
var b51=_n('view')
_rz(z,b51,'class',1,e,s,gg)
var o61=_v()
_(b51,o61)
if(_oz(z,2,e,s,gg)){o61.wxVkey=1
var x71=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
_(o61,x71)
}
var o81=_n('view')
_rz(z,o81,'class',5,e,s,gg)
var f91=_v()
_(o81,f91)
if(_oz(z,6,e,s,gg)){f91.wxVkey=1
var c01=_mz(z,'view',['class',7,'style',1],[],e,s,gg)
_(f91,c01)
}
var hA2=_v()
_(o81,hA2)
var oB2=function(oD2,cC2,lE2,gg){
var tG2=_mz(z,'view',['class',12,'style',1],[],oD2,cC2,gg)
_(lE2,tG2)
return lE2
}
hA2.wxXCkey=2
_2z(z,10,oB2,e,s,gg,hA2,'item','index','index')
f91.wxXCkey=1
_(b51,o81)
o61.wxXCkey=1
_(e41,b51)
}
else{e41.wxVkey=2
var eH2=_n('view')
_rz(z,eH2,'class',14,e,s,gg)
var bI2=_n('slot')
_(eH2,bI2)
_(e41,eH2)
}
e41.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_57";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_57();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/skeleton/index.wxml'] = [$gwx_XC_57, './miniprogram_npm/@vant/weapp/skeleton/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/skeleton/index.wxml'] = $gwx_XC_57( './miniprogram_npm/@vant/weapp/skeleton/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/skeleton/index.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-skeleton{box-sizing:border-box;display:-webkit-flex;display:flex;padding:var(--skeleton-padding,0 16px);width:100%}\n.",[1],"van-skeleton__avatar{background-color:var(--skeleton-avatar-background-color,#f2f3f5);-webkit-flex-shrink:0;flex-shrink:0;margin-right:var(--padding-md,16px)}\n.",[1],"van-skeleton__avatar--round{border-radius:100%}\n.",[1],"van-skeleton__content{-webkit-flex:1;flex:1}\n.",[1],"van-skeleton__avatar+.",[1],"van-skeleton__content{padding-top:var(--padding-xs,8px)}\n.",[1],"van-skeleton__row,.",[1],"van-skeleton__title{background-color:var(--skeleton-row-background-color,#f2f3f5);height:var(--skeleton-row-height,16px)}\n.",[1],"van-skeleton__title{margin:0}\n.",[1],"van-skeleton__row:not(:first-child){margin-top:var(--skeleton-row-margin-top,12px)}\n.",[1],"van-skeleton__title+.",[1],"van-skeleton__row{margin-top:20px}\n.",[1],"van-skeleton--animate{-webkit-animation:van-skeleton-blink 1.2s ease-in-out infinite;animation:van-skeleton-blink 1.2s ease-in-out infinite}\n@-webkit-keyframes van-skeleton-blink{50%{opacity:.6}\n}@keyframes van-skeleton-blink{50%{opacity:.6}\n}",],undefined,{path:"./miniprogram_npm/@vant/weapp/skeleton/index.wxss"});
}