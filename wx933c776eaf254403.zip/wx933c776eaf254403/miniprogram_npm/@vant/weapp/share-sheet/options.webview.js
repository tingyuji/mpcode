$gwx_XC_54=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_54 || [];
function gz$gwx_XC_54_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_54_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'share-sheet__options']],[[8],'border',[[7],[3,'showBorder']]]]])
Z([[7],[3,'options']])
Z([3,'index'])
Z([3,'onSelect'])
Z([3,'van-share-sheet__option'])
Z([[7],[3,'index']])
Z([3,'van-share-sheet__button'])
Z([[6],[[7],[3,'item']],[3,'openType']])
Z([3,'van-share-sheet__icon'])
Z([[12],[[6],[[7],[3,'computed']],[3,'getIconURL']],[[5],[[6],[[7],[3,'item']],[3,'icon']]]])
Z([[6],[[7],[3,'item']],[3,'name']])
Z([3,'van-share-sheet__name'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([[6],[[7],[3,'item']],[3,'description']])
Z([3,'van-share-sheet__option-description'])
Z([a,[3,' '],[[6],[[7],[3,'item']],[3,'description']],[3,' ']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_54_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_54=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_54=true;
var x=['./miniprogram_npm/@vant/weapp/share-sheet/options.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_54_1()
var tA1=_n('view')
_rz(z,tA1,'class',0,e,s,gg)
var eB1=_v()
_(tA1,eB1)
var bC1=function(xE1,oD1,oF1,gg){
var cH1=_mz(z,'view',['bindtap',3,'class',1,'data-index',2],[],xE1,oD1,gg)
var hI1=_mz(z,'button',['class',6,'openType',1],[],xE1,oD1,gg)
var oL1=_mz(z,'image',['class',8,'src',1],[],xE1,oD1,gg)
_(hI1,oL1)
var oJ1=_v()
_(hI1,oJ1)
if(_oz(z,10,xE1,oD1,gg)){oJ1.wxVkey=1
var lM1=_n('view')
_rz(z,lM1,'class',11,xE1,oD1,gg)
var aN1=_oz(z,12,xE1,oD1,gg)
_(lM1,aN1)
_(oJ1,lM1)
}
var cK1=_v()
_(hI1,cK1)
if(_oz(z,13,xE1,oD1,gg)){cK1.wxVkey=1
var tO1=_n('view')
_rz(z,tO1,'class',14,xE1,oD1,gg)
var eP1=_oz(z,15,xE1,oD1,gg)
_(tO1,eP1)
_(cK1,tO1)
}
oJ1.wxXCkey=1
cK1.wxXCkey=1
_(cH1,hI1)
_(oF1,cH1)
return oF1
}
eB1.wxXCkey=2
_2z(z,1,bC1,e,s,gg,eB1,'item','index','index')
_(r,tA1)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_54";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_54();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/share-sheet/options.wxml'] = [$gwx_XC_54, './miniprogram_npm/@vant/weapp/share-sheet/options.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/share-sheet/options.wxml'] = $gwx_XC_54( './miniprogram_npm/@vant/weapp/share-sheet/options.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['miniprogram_npm/@vant/weapp/share-sheet/options.wxss'] = setCssToHead([[2,"./miniprogram_npm/@vant/weapp/common/index.wxss"],".",[1],"van-share-sheet__options{-webkit-overflow-scrolling:touch;display:-webkit-flex;display:flex;overflow-x:auto;overflow-y:visible;padding:16px 0 16px 8px;position:relative}\n.",[1],"van-share-sheet__options--border:before{border-top:1px solid #ebedf0;box-sizing:border-box;content:\x22 \x22;left:16px;pointer-events:none;position:absolute;right:0;top:0;-webkit-transform:scaleY(.5);transform:scaleY(.5);-webkit-transform-origin:center;transform-origin:center}\n.",[1],"van-share-sheet__options::-webkit-scrollbar{height:0}\n.",[1],"van-share-sheet__option{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-user-select:none;user-select:none}\n.",[1],"van-share-sheet__option:active{opacity:.7}\n.",[1],"van-share-sheet__button{background-color:initial;border:0;height:auto;line-height:inherit;padding:0}\n.",[1],"van-share-sheet__button:after{border:0}\n.",[1],"van-share-sheet__icon{height:48px;margin:0 16px;width:48px}\n.",[1],"van-share-sheet__name{color:#646566;font-size:12px;margin-top:8px;padding:0 4px}\n.",[1],"van-share-sheet__option-description{color:#c8c9cc;font-size:12px;padding:0 4px}\n",],undefined,{path:"./miniprogram_npm/@vant/weapp/share-sheet/options.wxss"});
}