Object.defineProperty(exports, "__esModule", {
    value: !0
}), (0, require("../common/component").VantComponent)({
    props: {
        title: String,
        border: {
            type: Boolean,
            value: !0
        },
        inset: Boolean
    }
});