$gwx_XC_60=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_60 || [];
function gz$gwx_XC_60_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_60_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_60_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_60_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'steps']])
Z([3,'index'])
Z([3,'onClick'])
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'step']],[[4],[[5],[[5],[[7],[3,'direction']]],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]]]]]],[3,' van-hairline']])
Z([[7],[3,'index']])
Z([[2,'?:'],[[2,'==='],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]],[1,'inactive']],[[2,'+'],[1,'color: '],[[7],[3,'inactiveColor']]],[1,'']])
Z([3,'van-step__circle-container'])
Z([[2,'!=='],[[7],[3,'index']],[[7],[3,'active']]])
Z([[2,'||'],[[6],[[7],[3,'item']],[3,'inactiveIcon']],[[7],[3,'inactiveIcon']]])
Z([[2,'?:'],[[2,'==='],[[12],[[7],[3,'status']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'active']]]],[1,'inactive']],[[7],[3,'inactiveColor']],[[7],[3,'activeColor']]])
Z([3,'van-step__icon'])
Z(z[8])
Z([[7],[3,'activeColor']])
Z(z[10])
Z([[2,'||'],[[6],[[7],[3,'item']],[3,'activeIcon']],[[7],[3,'activeIcon']]])
Z([[2,'!=='],[[7],[3,'index']],[[2,'-'],[[6],[[7],[3,'steps']],[3,'length']],[1,1]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_60_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_60_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_60=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_60=true;
var x=['./miniprogram_npm/@vant/weapp/steps/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_60_1()
var oDO=_v()
_(r,oDO)
var fEO=function(hGO,cFO,oHO,gg){
var oJO=_mz(z,'view',['bindtap',2,'class',1,'data-index',2,'style',3],[],hGO,cFO,gg)
var aLO=_n('view')
_rz(z,aLO,'class',6,hGO,cFO,gg)
var tMO=_v()
_(aLO,tMO)
if(_oz(z,7,hGO,cFO,gg)){tMO.wxVkey=1
var eNO=_v()
_(tMO,eNO)
if(_oz(z,8,hGO,cFO,gg)){eNO.wxVkey=1
var bOO=_mz(z,'van-icon',['color',9,'customClass',1,'name',2],[],hGO,cFO,gg)
_(eNO,bOO)
}
else{eNO.wxVkey=2
}
eNO.wxXCkey=1
eNO.wxXCkey=3
}
else{tMO.wxVkey=2
var oPO=_mz(z,'van-icon',['color',12,'customClass',1,'name',2],[],hGO,cFO,gg)
_(tMO,oPO)
}
tMO.wxXCkey=1
tMO.wxXCkey=3
tMO.wxXCkey=3
_(oJO,aLO)
var lKO=_v()
_(oJO,lKO)
if(_oz(z,15,hGO,cFO,gg)){lKO.wxVkey=1
}
lKO.wxXCkey=1
_(oHO,oJO)
return oHO
}
oDO.wxXCkey=4
_2z(z,0,fEO,e,s,gg,oDO,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_60";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_60();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/steps/index.wxml'] = [$gwx_XC_60, './miniprogram_npm/@vant/weapp/steps/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/steps/index.wxml'] = $gwx_XC_60( './miniprogram_npm/@vant/weapp/steps/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/steps/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/steps/index.js";define("miniprogram_npm/@vant/weapp/steps/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/color");(0,e.VantComponent)({classes:["desc-class"],props:{icon:String,steps:Array,active:Number,direction:{type:String,value:"horizontal"},activeColor:{type:String,value:t.GREEN},inactiveColor:{type:String,value:t.GRAY_DARK},activeIcon:{type:String,value:"checked"},inactiveIcon:String},methods:{onClick:function(e){var t=e.currentTarget.dataset.index;this.$emit("click-step",t)}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/steps/index.js'});require("miniprogram_npm/@vant/weapp/steps/index.js");