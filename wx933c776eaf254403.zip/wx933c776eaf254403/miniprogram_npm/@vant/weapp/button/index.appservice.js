$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([[7],[3,'ariaLabel']])
Z([3,'onChooseAvatar'])
Z([3,'onContact'])
Z([3,'onError'])
Z([3,'onGetPhoneNumber'])
Z([3,'onGetUserInfo'])
Z([3,'onLaunchApp'])
Z([3,'onOpenSetting'])
Z([[2,'?:'],[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]],[1,''],[1,'onClick']])
Z([[7],[3,'businessId']])
Z([a,[3,'custom-class '],[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'button']],[[4],[[5],[[5],[[5],[[7],[3,'type']]],[[7],[3,'size']]],[[9],[[9],[[9],[[9],[[9],[[9],[[9],[[8],'block',[[7],[3,'block']]],[[8],'round',[[7],[3,'round']]]],[[8],'plain',[[7],[3,'plain']]]],[[8],'square',[[7],[3,'square']]]],[[8],'loading',[[7],[3,'loading']]]],[[8],'disabled',[[7],[3,'disabled']]]],[[8],'hairline',[[7],[3,'hairline']]]],[[8],'unclickable',[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]]]]]]]],[3,' '],[[2,'?:'],[[7],[3,'hairline']],[1,'van-hairline--surround'],[1,'']]])
Z([[7],[3,'dataset']])
Z([[7],[3,'formType']])
Z([3,'van-button--active hover-class'])
Z([[7],[3,'id']])
Z([[7],[3,'lang']])
Z([[2,'?:'],[[2,'||'],[[2,'||'],[[7],[3,'disabled']],[[7],[3,'loading']]],[[2,'&&'],[[7],[3,'canIUseGetUserProfile']],[[2,'==='],[[7],[3,'openType']],[1,'getUserInfo']]]],[1,''],[[7],[3,'openType']]])
Z([[7],[3,'sendMessageImg']])
Z([[7],[3,'sendMessagePath']])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([[12],[[6],[[7],[3,'computed']],[3,'rootStyle']],[[5],[[9],[[9],[[8],'plain',[[7],[3,'plain']]],[[8],'color',[[7],[3,'color']]]],[[8],'customStyle',[[7],[3,'customStyle']]]]]])
Z([[7],[3,'loading']])
Z([[12],[[6],[[7],[3,'computed']],[3,'loadingColor']],[[5],[[9],[[9],[[8],'type',[[7],[3,'type']]],[[8],'color',[[7],[3,'color']]]],[[8],'plain',[[7],[3,'plain']]]]]])
Z([3,'loading-class'])
Z([[7],[3,'loadingSize']])
Z([[7],[3,'loadingType']])
Z([[7],[3,'loadingText']])
Z([[7],[3,'icon']])
Z([3,'van-button__icon'])
Z([[7],[3,'classPrefix']])
Z([3,'line-height: inherit;'])
Z(z[30])
Z([3,'1.2em'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./miniprogram_npm/@vant/weapp/button/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
var oHC=_mz(z,'button',['appParameter',0,'ariaLabel',1,'bindchooseavatar',1,'bindcontact',2,'binderror',3,'bindgetphonenumber',4,'bindgetuserinfo',5,'bindlaunchapp',6,'bindopensetting',7,'bindtap',8,'businessId',9,'class',10,'data-detail',11,'formType',12,'hoverClass',13,'id',14,'lang',15,'openType',16,'sendMessageImg',17,'sendMessagePath',18,'sendMessageTitle',19,'sessionFrom',20,'showMessageCard',21,'style',22],[],e,s,gg)
var lIC=_v()
_(oHC,lIC)
if(_oz(z,24,e,s,gg)){lIC.wxVkey=1
var tKC=_mz(z,'van-loading',['color',25,'customClass',1,'size',2,'type',3],[],e,s,gg)
_(lIC,tKC)
var aJC=_v()
_(lIC,aJC)
if(_oz(z,29,e,s,gg)){aJC.wxVkey=1
}
aJC.wxXCkey=1
}
else{lIC.wxVkey=2
var eLC=_v()
_(lIC,eLC)
if(_oz(z,30,e,s,gg)){eLC.wxVkey=1
var bMC=_mz(z,'van-icon',['class',31,'classPrefix',1,'customStyle',2,'name',3,'size',4],[],e,s,gg)
_(eLC,bMC)
}
var oNC=_n('slot')
_(lIC,oNC)
eLC.wxXCkey=1
eLC.wxXCkey=3
}
lIC.wxXCkey=1
lIC.wxXCkey=3
lIC.wxXCkey=3
_(r,oHC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/button/index.wxml'] = [$gwx_XC_6, './miniprogram_npm/@vant/weapp/button/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/button/index.wxml'] = $gwx_XC_6( './miniprogram_npm/@vant/weapp/button/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/button/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/button/index.js";define("miniprogram_npm/@vant/weapp/button/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),o=require("../mixins/button"),n=require("../common/version"),t=[o.button];(0,n.canIUseFormFieldButton)()&&t.push("wx://form-field-button"),(0,e.VantComponent)({mixins:t,classes:["hover-class","loading-class"],data:{baseStyle:""},props:{formType:String,icon:String,classPrefix:{type:String,value:"van-icon"},plain:Boolean,block:Boolean,round:Boolean,square:Boolean,loading:Boolean,hairline:Boolean,disabled:Boolean,loadingText:String,customStyle:String,loadingType:{type:String,value:"circular"},type:{type:String,value:"default"},dataset:null,size:{type:String,value:"normal"},loadingSize:{type:String,value:"20px"},color:String},methods:{onClick:function(e){var o=this;this.$emit("click",e);var n=this.data,t=n.canIUseGetUserProfile,i=n.openType,a=n.getUserProfileDesc,l=n.lang;"getUserInfo"===i&&t&&wx.getUserProfile({desc:a||"  ",lang:l||"en",complete:function(e){o.$emit("getuserinfo",e)}})}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/button/index.js'});require("miniprogram_npm/@vant/weapp/button/index.js");