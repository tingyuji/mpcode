$gwx_XC_52=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_52 || [];
function gz$gwx_XC_52_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search']],[[8],'withaction',[[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]]]]],[3,' custom-class']])
Z([a,[3,'background: '],[[7],[3,'background']]])
Z([[12],[[6],[[7],[3,'utils']],[3,'bem']],[[5],[[5],[1,'search__content']],[[4],[[5],[[7],[3,'shape']]]]]])
Z([[7],[3,'label']])
Z([3,'label'])
Z([3,'onBlur'])
Z([3,'onChange'])
Z([3,'onClear'])
Z([3,'onClickInput'])
Z([3,'onSearch'])
Z([3,'onFocus'])
Z([1,false])
Z([3,'van-search__field field-class'])
Z([[7],[3,'clearIcon']])
Z([[7],[3,'clearTrigger']])
Z([[7],[3,'clearable']])
Z([3,'search'])
Z([3,'padding: 5px 10px 5px 0; background-color: transparent;'])
Z([[7],[3,'disabled']])
Z([[7],[3,'error']])
Z([[7],[3,'focus']])
Z([[7],[3,'inputAlign']])
Z([3,'input-class'])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useLeftIconSlot']]],[[7],[3,'leftIcon']],[1,'']])
Z([[7],[3,'maxlength']])
Z([[7],[3,'placeholder']])
Z([[7],[3,'placeholderStyle']])
Z([[7],[3,'readonly']])
Z([[2,'?:'],[[2,'!'],[[7],[3,'useRightIconSlot']]],[[7],[3,'rightIcon']],[1,'']])
Z(z[16])
Z([[7],[3,'value']])
Z([[7],[3,'useLeftIconSlot']])
Z([3,'left-icon'])
Z(z[32])
Z([[7],[3,'useRightIconSlot']])
Z([3,'right-icon'])
Z(z[35])
Z([[2,'||'],[[7],[3,'showAction']],[[7],[3,'useActionSlot']]])
Z([3,'van-search__action'])
Z([3,'van-search__action--hover'])
Z([3,'70'])
Z([[7],[3,'useActionSlot']])
Z([3,'action'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_52=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_52=true;
var x=['./miniprogram_npm/@vant/weapp/search/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_52_1()
var c7L=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var l9L=_n('view')
_rz(z,l9L,'class',2,e,s,gg)
var a0L=_v()
_(l9L,a0L)
if(_oz(z,3,e,s,gg)){a0L.wxVkey=1
}
else{a0L.wxVkey=2
var tAM=_n('slot')
_rz(z,tAM,'name',4,e,s,gg)
_(a0L,tAM)
}
var eBM=_mz(z,'van-field',['bind:blur',5,'bind:change',1,'bind:clear',2,'bind:click-input',3,'bind:confirm',4,'bind:focus',5,'border',6,'class',7,'clearIcon',8,'clearTrigger',9,'clearable',10,'confirmType',11,'customStyle',12,'disabled',13,'error',14,'focus',15,'inputAlign',16,'inputClass',17,'leftIcon',18,'maxlength',19,'placeholder',20,'placeholderStyle',21,'readonly',22,'rightIcon',23,'type',24,'value',25],[],e,s,gg)
var bCM=_v()
_(eBM,bCM)
if(_oz(z,31,e,s,gg)){bCM.wxVkey=1
var xEM=_mz(z,'slot',['name',32,'slot',1],[],e,s,gg)
_(bCM,xEM)
}
var oDM=_v()
_(eBM,oDM)
if(_oz(z,34,e,s,gg)){oDM.wxVkey=1
var oFM=_mz(z,'slot',['name',35,'slot',1],[],e,s,gg)
_(oDM,oFM)
}
bCM.wxXCkey=1
oDM.wxXCkey=1
_(l9L,eBM)
a0L.wxXCkey=1
_(c7L,l9L)
var o8L=_v()
_(c7L,o8L)
if(_oz(z,37,e,s,gg)){o8L.wxVkey=1
var fGM=_mz(z,'view',['class',38,'hoverClass',1,'hoverStayTime',2],[],e,s,gg)
var cHM=_v()
_(fGM,cHM)
if(_oz(z,41,e,s,gg)){cHM.wxVkey=1
var hIM=_n('slot')
_rz(z,hIM,'name',42,e,s,gg)
_(cHM,hIM)
}
else{cHM.wxVkey=2
}
cHM.wxXCkey=1
_(o8L,fGM)
}
o8L.wxXCkey=1
_(r,c7L)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_52";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_52();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/@vant/weapp/search/index.wxml'] = [$gwx_XC_52, './miniprogram_npm/@vant/weapp/search/index.wxml'];else __wxAppCode__['miniprogram_npm/@vant/weapp/search/index.wxml'] = $gwx_XC_52( './miniprogram_npm/@vant/weapp/search/index.wxml' );
	;__wxRoute = "miniprogram_npm/@vant/weapp/search/index";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/@vant/weapp/search/index.js";define("miniprogram_npm/@vant/weapp/search/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../common/component"),t=require("../common/version");(0,e.VantComponent)({field:!0,classes:["field-class","input-class","cancel-class"],props:{label:String,focus:Boolean,error:Boolean,disabled:Boolean,readonly:Boolean,inputAlign:String,showAction:Boolean,useActionSlot:Boolean,useLeftIconSlot:Boolean,useRightIconSlot:Boolean,leftIcon:{type:String,value:"search"},rightIcon:String,placeholder:String,placeholderStyle:String,actionText:{type:String,value:"取消"},background:{type:String,value:"#ffffff"},maxlength:{type:Number,value:-1},shape:{type:String,value:"square"},clearable:{type:Boolean,value:!0},clearTrigger:{type:String,value:"focus"},clearIcon:{type:String,value:"clear"}},methods:{onChange:function(e){(0,t.canIUseModel)()&&this.setData({value:e.detail}),this.$emit("change",e.detail)},onCancel:function(){var e=this;setTimeout((function(){(0,t.canIUseModel)()&&e.setData({value:""}),e.$emit("cancel"),e.$emit("change","")}),200)},onSearch:function(e){this.$emit("search",e.detail)},onFocus:function(e){this.$emit("focus",e.detail)},onBlur:function(e){this.$emit("blur",e.detail)},onClear:function(e){this.$emit("clear",e.detail)},onClickInput:function(e){this.$emit("click-input",e.detail)}}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/@vant/weapp/search/index.js'});require("miniprogram_npm/@vant/weapp/search/index.js");