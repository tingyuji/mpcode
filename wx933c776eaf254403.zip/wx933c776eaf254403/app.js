App({
    onLaunch: function() {
        var n = wx.getStorageSync("logs") || [];
        n.unshift(Date.now()), wx.setStorageSync("logs", n), wx.getStorageSync("username") || wx.reLaunch({
            url: "/pages/login/component"
        });
    },
    onPullDownRefresh: function() {
        this.onRefresh();
    },
    globalData: {
        userInfo: null
    }
});