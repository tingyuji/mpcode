$gwx0_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_11 || [];
function gz$gwx0_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-24b840f4'])
Z([3,'width:100%;background-color:#fff;padding-bottom:200rpx;box-sizing:border-box;'])
Z([3,'__e'])
Z([3,'gochec fl_sb data-v-24b840f4'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'pickWl']],[[4],[[5],[1,2]]]]]]]]]]])
Z([3,'__l'])
Z(z[0])
Z([3,'#999'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([3,'724edb80-1'])
Z([3,'#07c160'])
Z([3,'4'])
Z([3,'300'])
Z([3,'f2f2f3'])
Z(z[5])
Z(z[2])
Z([1,false])
Z(z[0])
Z([[7],[3,'currentShequn']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'changeShequn']]]]]]]]])
Z([3,'90'])
Z(z[7])
Z(z[17])
Z([[7],[3,'listShequn']])
Z([3,'724edb80-2'])
Z([[2,'=='],[[7],[3,'currentShequn']],[1,0]])
Z([[2,'=='],[[7],[3,'currentShequn']],[1,1]])
Z(z[5])
Z(z[2])
Z([3,'14'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showInform']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'80%'])
Z([3,'center'])
Z([[7],[3,'showInform']])
Z([3,'724edb80-3'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_11=true;
var x=['./pages/pageRelay/awardSellZti.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_11_1()
var cYF=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var a2F=_mz(z,'view',['bindtap',2,'class',1,'data-event-opts',2],[],e,s,gg)
var t3F=_mz(z,'u-icon',['bind:__l',5,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(a2F,t3F)
_(cYF,a2F)
var e4F=_mz(z,'u-tabs',['activeColor',11,'barHeight',1,'barWidth',2,'bgColor',3,'bind:__l',4,'bind:change',5,'bold',6,'class',7,'current',8,'data-event-opts',9,'height',10,'inactiveColor',11,'isScroll',12,'list',13,'vueId',14],[],e,s,gg)
_(cYF,e4F)
var oZF=_v()
_(cYF,oZF)
if(_oz(z,26,e,s,gg)){oZF.wxVkey=1
}
var l1F=_v()
_(cYF,l1F)
if(_oz(z,27,e,s,gg)){l1F.wxVkey=1
}
var b5F=_mz(z,'u-popup',['bind:__l',28,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'length',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(cYF,b5F)
oZF.wxXCkey=1
l1F.wxXCkey=1
_(r,cYF)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSellZti.wxml'] = [$gwx0_XC_11, './pages/pageRelay/awardSellZti.wxml'];else __wxAppCode__['pages/pageRelay/awardSellZti.wxml'] = $gwx0_XC_11( './pages/pageRelay/awardSellZti.wxml' );
	;__wxRoute = "pages/pageRelay/awardSellZti";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/awardSellZti.js";define("pages/pageRelay/awardSellZti.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/awardSellZti"],{642:function(i,n,e){"use strict";(function(i){e(5),t(e(4));var n=t(e(643));function t(i){return i&&i.__esModule?i:{default:i}}wx.__webpack_require_UNI_MP_PLUGIN__=e,i(n.default)}).call(this,e(1).createPage)},643:function(i,n,e){"use strict";e.r(n);var t=e(644),o=e(646);for(var s in o)"default"!==s&&function(i){e.d(n,i,(function(){return o[i]}))}(s);e(648),e(650);var c=e(17),r=Object(c.default)(o.default,t.render,t.staticRenderFns,!1,null,"24b840f4",null,!1,t.components,void 0);r.options.__file="pages/pageRelay/awardSellZti.vue",n.default=r.exports},644:function(i,n,e){"use strict";e.r(n);var t=e(645);e.d(n,"render",(function(){return t.render})),e.d(n,"staticRenderFns",(function(){return t.staticRenderFns})),e.d(n,"recyclableRender",(function(){return t.recyclableRender})),e.d(n,"components",(function(){return t.components}))},645:function(i,n,e){"use strict";var t;e.r(n),e.d(n,"render",(function(){return o})),e.d(n,"staticRenderFns",(function(){return c})),e.d(n,"recyclableRender",(function(){return s})),e.d(n,"components",(function(){return t}));try{t={uIcon:function(){return e.e("uview-ui/components/u-icon/u-icon").then(e.bind(null,854))},uTabs:function(){return Promise.all([e.e("common/vendor"),e.e("uview-ui/components/u-tabs/u-tabs")]).then(e.bind(null,996))},uPopup:function(){return e.e("uview-ui/components/u-popup/u-popup").then(e.bind(null,939))}}}catch(i){if(-1===i.message.indexOf("Cannot find module")||-1===i.message.indexOf(".vue"))throw i;console.error(i.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){var i=this;i.$createElement,i._self._c,i._isMounted||(i.e0=function(n){i.commissionWay=1},i.e1=function(n){i.commissionWay=2},i.e2=function(n){i.showInform=!0},i.e3=function(n){i.showInform=!1})},s=!1,c=[];o._withStripped=!0},646:function(i,n,e){"use strict";e.r(n);var t=e(647),o=e.n(t);for(var s in t)"default"!==s&&function(i){e.d(n,i,(function(){return t[i]}))}(s);n.default=o.a},647:function(i,n,e){"use strict";(function(i){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t=function(i){return i&&i.__esModule?i:{default:i}}(e(61)),o={data:function(){return{informText:"",showInform:!1,ztiArr:"",ztList:[],currentShequn:0,listShequn:[{name:"按自提点管理员发佣金"},{name:"按商品发佣金"}],picknums:"全部",commissionWay:1,checkedDy:!0,speceImg:"http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",posInfo:{groupFlag:2,speceImg:"",groupPrice:"",groupPeople:"",groupPriceShow:"",rewardType:5,commodityIndex:0},commodityList:[{commodityName:"测试i",defaultPriceShow:1,spickupCmissionPercentMon:"",spickupCmissionPercentBfb:"",spickupCmissionPercent:""}],defaultPrice:0,defaultPriceShow:5,commodityName:"苹果",commodityIndex:0}},onLoad:function(n){i.hideShareMenu({}),console.log("自提信息==",n),this.ztiArr=n.id;var e=n.id.split(",");this.picknums="已选择"+e.length+"个",this.queryAddrManagByIds(),this.commissionWay=this.vuex_yongjin_zitif,console.log("自提信息==",this.commissionWay,this.vuex_yongjin_zitif);var t=JSON.parse(JSON.stringify(this.vuex_showShopList)),o=[];t.forEach((function(i){o=o.concat(i.shopList)})),console.log("今天中元节",o),o.forEach((function(i){if(i.spickupCmissionPercent||0==i.spickupCmissionPercent?(i.spickupCmissionPercent=i.spickupCmissionPercent,i.spickupCmissionPercentBfb=(i.spickupCmissionPercent/1e3).toFixed(2),i.spickupCmissionPercentMon=(i.spickupCmissionPercentBfb*i.defaultPriceShow/100).toFixed(2)):(i.spickupCmissionPercentBfb="",i.spickupCmissionPercentMon=""),i.commodityDetails.length>1&&i.commodityDetails[1].commodityDetail){var n=i.commodityDetails[1].commodityDetail.split(",");i.speceImg=n[0]}})),this.commodityList=o,console.log("this.posInfo==",this.posInfo)},methods:{plSzz:function(){},pickWl:function(n){i.navigateTo({url:"../subPage/addressListZti?id="+this.ztiArr})},otherFun:function(i){console.log("oteherFun==",i),this.ztiArr=i,this.picknums="已选择"+i.length+"个",this.queryAddrManagByIds()},carmerJis:function(i,n,e){if(console.log("失去焦点==",n),1==n){if(!i.spickupCmissionPercentMon)return i.spickupCmissionPercentBfb="",!1;i.spickupCmissionPercentMon>i.defaultPriceShow&&(i.spickupCmissionPercentMon=i.defaultPriceShow),i.spickupCmissionPercentBfb=(i.spickupCmissionPercentMon/i.defaultPriceShow*100).toFixed(2),console.log("失去焦点2==",n,i.spickupCmissionPercentBfb)}else{if(!i.spickupCmissionPercentBfb)return i.spickupCmissionPercentMon="",!1;i.spickupCmissionPercentBfb>100&&(i.spickupCmissionPercentBfb=100),i.spickupCmissionPercentMon=(i.spickupCmissionPercentBfb*i.defaultPriceShow/100).toFixed(2)}var t=JSON.parse(JSON.stringify(this.commodityList));t[e]=i,this.commodityList=t},informPost:function(){var i=this;if(1==this.currentShequn){var n=JSON.parse(JSON.stringify(this.commodityList));n.forEach((function(n){if(!i.informText)return n.spickupCmissionPercentBfb="",n.spickupCmissionPercentMon="",!1;i.informText>100?n.spickupCmissionPercentBfb=100:n.spickupCmissionPercentBfb=i.informText,n.spickupCmissionPercentMon=(n.spickupCmissionPercentBfb*n.defaultPriceShow/100).toFixed(2)})),this.commodityList=n}else{var e=JSON.parse(JSON.stringify(this.ztList));e.forEach((function(n){n.id&&(!i.informText>100?n.commissionPercentBfb=100:n.commissionPercentBfb=i.informText)})),this.ztList=e}this.showInform=!1},changeShequn:function(i){this.currentShequn=i},chageNums:function(){this.totalMou&&this.shuNiang?this.showNum=t.default.centTurnSmacker(this.totalMou):this.showNum="0.00"},goPage:function(n){i.navigateTo({url:"./topUp"})},gobacks:function(){var n={commissionWay:this.commissionWay};this.commodityList.forEach((function(i){i.spickupCmissionPercentBfb?i.spickupCmissionPercent=1e3*i.spickupCmissionPercentBfb:i.spickupCmissionPercent=0})),1==this.currentShequn?n.zitiCurrent=1:n.zitiCurrent=0,n.commodityList=this.commodityList,n.ztList=this.ztList;var e=getCurrentPages(),t=e[e.length-3];t.$vm.sellFunZiti(n);var o=this.ztiArr.split(","),s=getCurrentPages(),c=s[s.length-2];c.$vm.otherFun(o),console.log("funrun----",e,t,n,c,o),i.navigateBack()},queryAddrManagByIds:function(){var n=this;this.$server.queryAddrManagByIds({addressIds:this.ztiArr}).then((function(e){0==e.code?(e.data.forEach((function(i){i.commissionPercent="",i.commissionPercentBfb="",i.nickName||(i.nickName="群优选用户"),i.headImg||(i.headImg="https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg"),n.vuex_yongjin_ziti.length&&n.vuex_yongjin_ziti.forEach((function(n){i.addressId==n.addressId&&(i.commissionPercent=n.commissionPercent,i.commissionPercentBfb=n.commissionPercent/1e3)}))})),n.ztList=e.data,console.log("===",n.ztList,n.vuex_yongjin_ziti)):i.showToast({title:e.message,icon:"none"})}))}}};n.default=o}).call(this,e(1).default)},648:function(i,n,e){"use strict";e.r(n);var t=e(649),o=e.n(t);for(var s in t)"default"!==s&&function(i){e.d(n,i,(function(){return t[i]}))}(s);n.default=o.a},649:function(i,n,e){},650:function(i,n,e){"use strict";e.r(n);var t=e(651),o=e.n(t);for(var s in t)"default"!==s&&function(i){e.d(n,i,(function(){return t[i]}))}(s);n.default=o.a},651:function(i,n,e){}},[[642,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/awardSellZti.js'});require("pages/pageRelay/awardSellZti.js");