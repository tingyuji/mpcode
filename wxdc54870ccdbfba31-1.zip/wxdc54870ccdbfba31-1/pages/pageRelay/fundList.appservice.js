$gwx0_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_24 || [];
function gz$gwx0_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-1ca60769'])
Z([3,'width:100%;background-color:#ffff;min-height:100vh;padding-top:100rpx;box-sizing:border-box;'])
Z([3,'tab_bar fl data-v-1ca60769'])
Z([3,'__e'])
Z([3,'yiban_b fl data-v-1ca60769'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z(z[0])
Z([3,'#999'])
Z([3,'arrow-down-fill'])
Z([3,'24'])
Z([3,'781b66bd-1'])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[6])
Z(z[0])
Z(z[8])
Z(z[9])
Z(z[10])
Z([3,'781b66bd-2'])
Z(z[6])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'781b66bd-3'])
Z(z[6])
Z(z[3])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'timeCheck']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPick']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[4],[[5],[[5],[1,2]],[1,5]]])
Z([3,'multiSelector'])
Z([[7],[3,'multiSelector']])
Z([[7],[3,'showPick']])
Z([3,'781b66bd-4'])
Z(z[6])
Z(z[3])
Z([3,'40'])
Z(z[0])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openReling']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'openReling']])
Z([3,'781b66bd-5'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_24=true;
var x=['./pages/pageRelay/fundList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_24_1()
var oNL=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var fOL=_n('view')
_rz(z,fOL,'class',2,e,s,gg)
var cPL=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var hQL=_mz(z,'u-icon',['bind:__l',6,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(cPL,hQL)
_(fOL,cPL)
var oRL=_mz(z,'view',['bindtap',12,'class',1,'data-event-opts',2],[],e,s,gg)
var cSL=_mz(z,'u-icon',['bind:__l',15,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oRL,cSL)
_(fOL,oRL)
_(oNL,fOL)
var oTL=_mz(z,'u-loadmore',['bind:__l',21,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(oNL,oTL)
var lUL=_mz(z,'u-picker',['bind:__l',27,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'defaultSelector',5,'mode',6,'range',7,'value',8,'vueId',9],[],e,s,gg)
_(oNL,lUL)
var aVL=_mz(z,'u-popup',['bind:__l',37,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(oNL,aVL)
_(r,oNL)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/fundList.wxml'] = [$gwx0_XC_24, './pages/pageRelay/fundList.wxml'];else __wxAppCode__['pages/pageRelay/fundList.wxml'] = $gwx0_XC_24( './pages/pageRelay/fundList.wxml' );
	;__wxRoute = "pages/pageRelay/fundList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/fundList.js";define("pages/pageRelay/fundList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/fundList"],{536:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(537));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},537:function(e,n,t){"use strict";t.r(n);var o=t(538),i=t(540);for(var a in i)"default"!==a&&function(e){t.d(n,e,(function(){return i[e]}))}(a);t(542);var u=t(17),c=Object(u.default)(i.default,o.render,o.staticRenderFns,!1,null,"1ca60769",null,!1,o.components,void 0);c.options.__file="pages/pageRelay/fundList.vue",n.default=c.exports},538:function(e,n,t){"use strict";t.r(n);var o=t(539);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},539:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return i})),t.d(n,"staticRenderFns",(function(){return u})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))},uLoadmore:function(){return t.e("uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null,861))},uPicker:function(){return Promise.all([t.e("common/vendor"),t.e("uview-ui/components/u-picker/u-picker")]).then(t.bind(null,1017))},uPopup:function(){return t.e("uview-ui/components/u-popup/u-popup").then(t.bind(null,939))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(n){e.openReling=!0},e.e1=function(n){e.showPick=!0})},a=!1,u=[];i._withStripped=!0},540:function(e,n,t){"use strict";t.r(n);var o=t(541),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},541:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),i={data:function(){return{openReling:!1,params:{year:!0,month:!0,day:!1,hour:!1,minute:!1,second:!1},show:!0,actionList:[{text:"退出社群"}],showAct:!1,ctrlUserId:"",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多数据"},loadStatus:"loading",page:1,pageSize:20,showPick:!1,tagTexts:["全部","活动收款","活动退款","佣金","服务费","提现","活动奖励","充值","活动奖励金额返还","其他","红包奖励"],tagStatus:0,multiSelector:[["2020年","2021年","2022年","2023年","2024年","2025年","2026年","2027年","2028年","2029年","2030年","2031年","2032年","2033年"],["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"]],checkTime:"2022",checkTimeMo:""}},onLoad:function(){e.hideShareMenu({});var n=(new Date).getMonth();n++,this.checkTimeMo=n<10?"0".concat(n):n,this.queryBalanceLog()},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.queryBalanceLog())},methods:{queryBalanceLog:function(e){var n=this;console.log("data==",this.checkTime,this.checkTimeMo);var t=this.checkTime,i=this.checkTimeMo,a={page:this.page,pageSize:20};12==i?(a.startDate=t+"-"+i+"-01 00:00:00",a.endDate=1*t+1+"-01-01 00:00:00"):(a.startDate=t+"-"+i+"-01 00:00:00",a.endDate=t+"-"+(1*i+1)+"-01 00:00:00"),0==this.tagStatus||9==this.tagStatus?9==this.tagStatus?a.businessType="-1":a.businessType="":a.businessType=this.tagStatus,this.$server.queryBalanceLog(a).then((function(e){if(null!=e&&0==e.code){var t=e.data.balanceList.map((function(e){return e.userBalance=o.default.centTurnSmacker(e.userBalance/100),e.changeMoney=o.default.centTurnSmacker(e.changeMoney/100),-1==e.businessType&&(e.businessType=9),e}));n.list=n.list.concat(t),setTimeout((function(t){e.data.balanceList.length<n.pageSize?(n.finished=!0,n.loadStatus="nomore"):n.loadStatus="loadmore"}),500)}}))},pickClass:function(e){this.tagStatus=e,this.page=1,this.finished=!1,this.list=[],this.openReling=!1,this.queryBalanceLog()},timeCheck:function(e){var n=this.multiSelector[0],t=this.multiSelector[1];console.log("选择==",e),this.checkTime=n[e[0]].slice(0,n[e[0]].length-1),this.checkTimeMo=t[e[1]].slice(0,t[e[1]].length-1),this.page=1,this.finished=!1,this.list=[],this.queryBalanceLog()},opneMenu:function(e){this.ctrlUserId=e,this.showAct=!0}}};n.default=i}).call(this,t(1).default)},542:function(e,n,t){"use strict";t.r(n);var o=t(543),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},543:function(e,n,t){}},[[536,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/fundList.js'});require("pages/pageRelay/fundList.js");