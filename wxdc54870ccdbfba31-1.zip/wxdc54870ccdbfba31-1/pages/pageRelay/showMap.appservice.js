$gwx0_XC_48=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_48 || [];
function gz$gwx0_XC_48_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_48_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_48_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_48_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'getData']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_48_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_48_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_48=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_48=true;
var x=['./pages/pageRelay/showMap.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_48_1()
var cNU=_v()
_(r,cNU)
if(_oz(z,0,e,s,gg)){cNU.wxVkey=1
}
cNU.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_48";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_48();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/showMap.wxml'] = [$gwx0_XC_48, './pages/pageRelay/showMap.wxml'];else __wxAppCode__['pages/pageRelay/showMap.wxml'] = $gwx0_XC_48( './pages/pageRelay/showMap.wxml' );
	;__wxRoute = "pages/pageRelay/showMap";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/showMap.js";define("pages/pageRelay/showMap.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/showMap"],{740:function(e,t,n){"use strict";(function(e){n(5),i(n(4));var t=i(n(741));function i(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},741:function(e,t,n){"use strict";n.r(t);var i=n(742),o=n(744);for(var a in o)"default"!==a&&function(e){n.d(t,e,(function(){return o[e]}))}(a);n(746);var d=n(17),r=Object(d.default)(o.default,i.render,i.staticRenderFns,!1,null,"58e2e5ae",null,!1,i.components,void 0);r.options.__file="pages/pageRelay/showMap.vue",t.default=r.exports},742:function(e,t,n){"use strict";n.r(t);var i=n(743);n.d(t,"render",(function(){return i.render})),n.d(t,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(t,"recyclableRender",(function(){return i.recyclableRender})),n.d(t,"components",(function(){return i.components}))},743:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){}));var i=function(){this.$createElement,this._self._c},o=!1,a=[];i._withStripped=!0},744:function(e,t,n){"use strict";n.r(t);var i=n(745),o=n.n(i);for(var a in i)"default"!==a&&function(e){n.d(t,e,(function(){return i[e]}))}(a);t.default=o.a},745:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),o={data:function(){return{nickName:"",mobiles:"",id:0,title:"map",latitude:22.552196,longitude:113.887809,getData:!1,markers:[{id:10001,latitude:39.9,longitude:116.39842,iconPath:"../../static/uview/example/logossmall",callout:{content:"群优选 | 接龙团购",color:"#f00",fontSize:"48",display:"ALWAYS"}}],polyline:[{color:"#0000AA",width:10,arrowLine:!0,points:[{latitude:22.552196,longitude:113.887809},{latitude:22.554628,longitude:113.887171}]}],covers:[{id:10005,latitude:22.552196,longitude:113.887809,iconPath:"/static/uview/example/mappsy.png",width:16,height:16,callout:{content:"配送员 运输中",color:"#fff",fontSize:"12",display:"ALWAYS",padding:6,borderRadius:8,borderColor:"#fd5300",bgColor:"#fa6601"}},{id:10004,latitude:22.554628,longitude:113.887171,iconPath:"/static/uview/example/mapmyself.png",width:20,height:20,callout:{content:"自提点",color:"#fff",fontSize:"12",display:"ALWAYS",padding:6,borderRadius:8,borderColor:"#fd5300",bgColor:"#fa6601"}}],distanceKm:0,pageData:{}}},onLoad:function(t){e.hideShareMenu({});var n=JSON.parse(decodeURIComponent(t.item));this.pageData=n,this.operGetLocation(n.activityId,n.userAddresses[0].latitude+0,n.userAddresses[0].longitude+0),this.distanceKm=12.38,this.activityId=t.id},methods:{operGetLocation:function(t,n,o){var a=this;this.$server.operGetLocation({activityId:t,longitude:o,latitude:n}).then((function(t){if(0==t.code){var d=JSON.parse(JSON.stringify(a.covers));d[0].latitude=t.data.latitude,d[0].longitude=t.data.longitude,d[1].latitude=1*n,d[1].longitude=1*o,a.latitude=1*t.data.latitude,a.longitude=1*t.data.longitude,a.covers=d,t.data.nickName&&(a.nickName=t.data.nickName.slice(0,1)+"**",a.mobiles=t.data.mobile),console.log(a.covers),setTimeout((function(e){a.getData=!0}),500),a.distanceKm=i.default.distanceConversion(t.data.distance/1e3)}else e.showToast({title:t.message,icon:"none"})}))},showMode:function(t,n){e.showModal({title:t,content:n,showCancel:!1})}}};t.default=o}).call(this,n(1).default)},746:function(e,t,n){"use strict";n.r(t);var i=n(747),o=n.n(i);for(var a in i)"default"!==a&&function(e){n.d(t,e,(function(){return i[e]}))}(a);t.default=o.a},747:function(e,t,n){}},[[740,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/showMap.js'});require("pages/pageRelay/showMap.js");