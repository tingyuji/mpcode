$gwx0_XC_54=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_54 || [];
function gz$gwx0_XC_54_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_min data-v-35acd25c'])
Z([3,'min-height:100vh;background-color:#fff;'])
Z([[6],[[7],[3,'rewardList']],[3,'length']])
Z([3,'data-v-35acd25c'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'rewardList']])
Z(z[4])
Z([3,'in_bbxs fl_sb data-v-35acd25c'])
Z([3,'left_ff fl_c data-v-35acd25c'])
Z([3,'names data-v-35acd25c'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'formatName']]],[1,'']]])
Z([3,'nameit data-v-35acd25c'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'formatItem']]],[1,'']]])
Z([3,'rig_btns fl data-v-35acd25c'])
Z([3,'__e'])
Z([[4],[[5],[[5],[1,'data-v-35acd25c']],[[2,'?:'],[[6],[[7],[3,'item']],[3,'selfFlag']],[1,'bianji bianjis'],[1,'bianji']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'editSpece']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'rewardList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'编辑'])
Z(z[3])
Z([3,'width:14rpx;height:0;'])
Z(z[15])
Z(z[16])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'delSpece']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'rewardList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'删除'])
Z(z[15])
Z([3,'dfcbgdeepwh data-v-35acd25c'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'editSpece']],[[4],[[5],[[5],[1,99]],[1,99]]]]]]]]]]])
Z([3,'添加常用规格'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_54=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_54=true;
var x=['./pages/pageRelay/speceList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_54_1()
var t1ED=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var e2ED=_v()
_(t1ED,e2ED)
if(_oz(z,2,e,s,gg)){e2ED.wxVkey=1
var b3ED=_n('view')
_rz(z,b3ED,'class',3,e,s,gg)
var o4ED=_v()
_(b3ED,o4ED)
var x5ED=function(f7ED,o6ED,c8ED,gg){
var o0ED=_n('view')
_rz(z,o0ED,'class',8,f7ED,o6ED,gg)
var cAFD=_n('view')
_rz(z,cAFD,'class',9,f7ED,o6ED,gg)
var oBFD=_n('view')
_rz(z,oBFD,'class',10,f7ED,o6ED,gg)
var lCFD=_oz(z,11,f7ED,o6ED,gg)
_(oBFD,lCFD)
_(cAFD,oBFD)
var aDFD=_n('view')
_rz(z,aDFD,'class',12,f7ED,o6ED,gg)
var tEFD=_oz(z,13,f7ED,o6ED,gg)
_(aDFD,tEFD)
_(cAFD,aDFD)
_(o0ED,cAFD)
var eFFD=_n('view')
_rz(z,eFFD,'class',14,f7ED,o6ED,gg)
var bGFD=_mz(z,'view',['bindtap',15,'class',1,'data-event-opts',2],[],f7ED,o6ED,gg)
var oHFD=_oz(z,18,f7ED,o6ED,gg)
_(bGFD,oHFD)
_(eFFD,bGFD)
var xIFD=_mz(z,'view',['class',19,'style',1],[],f7ED,o6ED,gg)
_(eFFD,xIFD)
var oJFD=_mz(z,'view',['bindtap',21,'class',1,'data-event-opts',2],[],f7ED,o6ED,gg)
var fKFD=_oz(z,24,f7ED,o6ED,gg)
_(oJFD,fKFD)
_(eFFD,oJFD)
_(o0ED,eFFD)
_(c8ED,o0ED)
return c8ED
}
o4ED.wxXCkey=2
_2z(z,6,x5ED,e,s,gg,o4ED,'item','index','index')
_(e2ED,b3ED)
}
var cLFD=_mz(z,'view',['bindtap',25,'class',1,'data-event-opts',2],[],e,s,gg)
var hMFD=_oz(z,28,e,s,gg)
_(cLFD,hMFD)
_(t1ED,cLFD)
e2ED.wxXCkey=1
_(r,t1ED)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_54";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_54();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/speceList.wxml'] = [$gwx0_XC_54, './pages/pageRelay/speceList.wxml'];else __wxAppCode__['pages/pageRelay/speceList.wxml'] = $gwx0_XC_54( './pages/pageRelay/speceList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/speceList.wxss'] = setCssToHead([".",[1],"in_bbxs.",[1],"data-v-35acd25c{border-bottom:",[0,1]," solid #cacaca;box-sizing:border-box;height:",[0,140],";padding:",[0,30],"}\n.",[1],"in_bbxs .",[1],"left_ff.",[1],"data-v-35acd25c{-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"in_bbxs .",[1],"left_ff .",[1],"names.",[1],"data-v-35acd25c{color:#333;font-size:",[0,30],"}\n.",[1],"in_bbxs .",[1],"left_ff .",[1],"nameit.",[1],"data-v-35acd25c{color:#999;font-size:",[0,24],"}\n.",[1],"in_bbxs .",[1],"rig_btns .",[1],"bianji.",[1],"data-v-35acd25c{background-color:#fff;border:",[0,1]," solid #cacaca;border-radius:",[0,8],";box-sizing:border-box;color:#cacaca;font-size:",[0,24],";height:",[0,44],";line-height:",[0,44],";overflow:hidden;padding:",[0,0]," ",[0,12],";text-overflow:ellipsis;white-space:nowrap}\n.",[1],"in_bbxs .",[1],"rig_btns .",[1],"bianjis.",[1],"data-v-35acd25c{border:",[0,1]," solid #333;color:#333}\n",],undefined,{path:"./pages/pageRelay/speceList.wxss"});
}