$gwx0_XC_54=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_54 || [];
function gz$gwx0_XC_54_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'rewardList']],[3,'length']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_54_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_54=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_54=true;
var x=['./pages/pageRelay/speceList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_54_1()
var lQW=_v()
_(r,lQW)
if(_oz(z,0,e,s,gg)){lQW.wxVkey=1
}
lQW.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_54";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_54();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/speceList.wxml'] = [$gwx0_XC_54, './pages/pageRelay/speceList.wxml'];else __wxAppCode__['pages/pageRelay/speceList.wxml'] = $gwx0_XC_54( './pages/pageRelay/speceList.wxml' );
	;__wxRoute = "pages/pageRelay/speceList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/speceList.js";define("pages/pageRelay/speceList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/speceList"],{394:function(e,t,n){"use strict";(function(e){n(5),r(n(4));var t=r(n(395));function r(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},395:function(e,t,n){"use strict";n.r(t);var r=n(396),i=n(398);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);n(400),n(402);var c=n(17),a=Object(c.default)(i.default,r.render,r.staticRenderFns,!1,null,"35acd25c",null,!1,r.components,void 0);a.options.__file="pages/pageRelay/speceList.vue",t.default=a.exports},396:function(e,t,n){"use strict";n.r(t);var r=n(397);n.d(t,"render",(function(){return r.render})),n.d(t,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(t,"recyclableRender",(function(){return r.recyclableRender})),n.d(t,"components",(function(){return r.components}))},397:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return o})),n.d(t,"recyclableRender",(function(){return i})),n.d(t,"components",(function(){}));var r=function(){this.$createElement,this._self._c},i=!1,o=[];r._withStripped=!0},398:function(e,t,n){"use strict";n.r(t);var r=n(399),i=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=i.a},399:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={data:function(){return{rewardList:[],id:""}},onShow:function(){this.getFormatList()},onLoad:function(t){e.hideShareMenu({})},methods:{editSpece:function(t,n){if(99==n)e.navigateTo({url:"./speceEles"});else{if(0==t.selfFlag)return!1;var r={id:t.id,name:t.formatName,tagList:t.tagList},i=encodeURIComponent(JSON.stringify(r));e.navigateTo({url:"./speceEles?item="+i})}},delSpece:function(t,n){if(0==t.selfFlag)return fales;var r=this;e.showModal({title:"温馨提示",content:"是否确认删除",confirmText:"确认",confirmColor:"#FF0000",success:function(i){i.confirm?(console.log("用户点击确定",n),r.rewardList.splice(n,1),r.$server.deleteFormat({id:t.id}).then((function(t){0==t.code?e.showToast({title:"删除成功",icon:"success"}):e.showToast({title:t.message,icon:"none"})}))):i.cancel&&console.log("用户点击取消")}})},getFormatList:function(){var t=this;this.$server.formatList({businessType:1}).then((function(n){if(0==n.code){var r=n.data.map((function(e,t){return e.tagList=e.formatItem.split("/"),e}));t.rewardList=r,console.log(t.rewardList)}else e.showToast({title:n.message,icon:"none"})}))},gobacks:function(){encodeURIComponent(JSON.stringify(this.rewardList));var t=getCurrentPages();t[t.length-2].$vm.awardFun(this.rewardList),e.navigateBack()}}};t.default=n}).call(this,n(1).default)},400:function(e,t,n){"use strict";n.r(t);var r=n(401),i=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=i.a},401:function(e,t,n){},402:function(e,t,n){"use strict";n.r(t);var r=n(403),i=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=i.a},403:function(e,t,n){}},[[394,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/speceList.js'});require("pages/pageRelay/speceList.js");