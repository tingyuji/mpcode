$gwx0_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_7 || [];
function gz$gwx0_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join data-v-1a8314b1'])
Z([3,'min-height:100vh;background-color:#f5f5f5;'])
Z([[7],[3,'balanceNum']])
Z([3,'data-v-1a8314b1'])
Z([3,'in_bgx data-v-1a8314b1'])
Z([3,'one_tit data-v-1a8314b1'])
Z([3,'参与接龙的人将随机获得奖励'])
Z([3,'in_line fl_sb data-v-1a8314b1'])
Z(z[3])
Z([3,'奖励总金额'])
Z([3,'right_in data-v-1a8314b1'])
Z([3,'__e'])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'totalMou']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'text-align:right;'])
Z([3,'digit'])
Z([[7],[3,'totalMou']])
Z([3,'fix_t data-v-1a8314b1'])
Z([3,'元'])
Z([3,'in_tps data-v-1a8314b1'])
Z([3,'结束后未领取的金额将退回至账户资金'])
Z(z[3])
Z([3,'height:30rpx;width:100%;'])
Z(z[7])
Z(z[3])
Z([3,'奖励数量'])
Z(z[10])
Z(z[11])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'shuNiang']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[14])
Z([3,'number'])
Z([[7],[3,'shuNiang']])
Z(z[17])
Z([3,'个'])
Z([3,'now_gold data-v-1a8314b1'])
Z([3,'go_tit data-v-1a8314b1'])
Z([3,'当前账户资金'])
Z([3,'showg fl_sb data-v-1a8314b1'])
Z([3,'money_l data-v-1a8314b1'])
Z(z[3])
Z([3,'￥'])
Z([3,'rea_sh data-v-1a8314b1'])
Z([a,[[7],[3,'balanceNum']]])
Z(z[11])
Z([3,'r_bbtn dfcbtnb data-v-1a8314b1'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'充值'])
Z([3,'jiang_in data-v-1a8314b1'])
Z([3,'奖励费用将在当前账户资金中扣除'])
Z(z[3])
Z([3,'padding:100rpx 30rpx;'])
Z([3,'该页面正在升级维护，敬请期待'])
Z(z[11])
Z([3,'dfcbgdeepwh data-v-1a8314b1'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'gobacks']]]]]]]]])
Z([3,'确定'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_7=true;
var x=['./pages/pageRelay/awardJoin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_7_1()
var oF1=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var fG1=_v()
_(oF1,fG1)
if(_oz(z,2,e,s,gg)){fG1.wxVkey=1
var cH1=_n('view')
_rz(z,cH1,'class',3,e,s,gg)
var hI1=_n('view')
_rz(z,hI1,'class',4,e,s,gg)
var oJ1=_n('view')
_rz(z,oJ1,'class',5,e,s,gg)
var cK1=_oz(z,6,e,s,gg)
_(oJ1,cK1)
_(hI1,oJ1)
var oL1=_n('view')
_rz(z,oL1,'class',7,e,s,gg)
var lM1=_n('text')
_rz(z,lM1,'class',8,e,s,gg)
var aN1=_oz(z,9,e,s,gg)
_(lM1,aN1)
_(oL1,lM1)
var tO1=_n('view')
_rz(z,tO1,'class',10,e,s,gg)
var eP1=_mz(z,'input',['bindinput',11,'class',1,'data-event-opts',2,'style',3,'type',4,'value',5],[],e,s,gg)
_(tO1,eP1)
var bQ1=_n('text')
_rz(z,bQ1,'class',17,e,s,gg)
var oR1=_oz(z,18,e,s,gg)
_(bQ1,oR1)
_(tO1,bQ1)
var xS1=_n('view')
_rz(z,xS1,'class',19,e,s,gg)
var oT1=_oz(z,20,e,s,gg)
_(xS1,oT1)
_(tO1,xS1)
_(oL1,tO1)
_(hI1,oL1)
var fU1=_mz(z,'view',['class',21,'style',1],[],e,s,gg)
_(hI1,fU1)
var cV1=_n('view')
_rz(z,cV1,'class',23,e,s,gg)
var hW1=_n('text')
_rz(z,hW1,'class',24,e,s,gg)
var oX1=_oz(z,25,e,s,gg)
_(hW1,oX1)
_(cV1,hW1)
var cY1=_n('view')
_rz(z,cY1,'class',26,e,s,gg)
var oZ1=_mz(z,'input',['bindinput',27,'class',1,'data-event-opts',2,'style',3,'type',4,'value',5],[],e,s,gg)
_(cY1,oZ1)
var l11=_n('text')
_rz(z,l11,'class',33,e,s,gg)
var a21=_oz(z,34,e,s,gg)
_(l11,a21)
_(cY1,l11)
_(cV1,cY1)
_(hI1,cV1)
_(cH1,hI1)
var t31=_n('view')
_rz(z,t31,'class',35,e,s,gg)
var e41=_n('view')
_rz(z,e41,'class',36,e,s,gg)
var b51=_oz(z,37,e,s,gg)
_(e41,b51)
_(t31,e41)
var o61=_n('view')
_rz(z,o61,'class',38,e,s,gg)
var x71=_n('view')
_rz(z,x71,'class',39,e,s,gg)
var o81=_n('text')
_rz(z,o81,'class',40,e,s,gg)
var f91=_oz(z,41,e,s,gg)
_(o81,f91)
_(x71,o81)
var c01=_n('text')
_rz(z,c01,'class',42,e,s,gg)
var hA2=_oz(z,43,e,s,gg)
_(c01,hA2)
_(x71,c01)
_(o61,x71)
var oB2=_mz(z,'view',['bindtap',44,'class',1,'data-event-opts',2],[],e,s,gg)
var cC2=_oz(z,47,e,s,gg)
_(oB2,cC2)
_(o61,oB2)
_(t31,o61)
var oD2=_n('view')
_rz(z,oD2,'class',48,e,s,gg)
var lE2=_oz(z,49,e,s,gg)
_(oD2,lE2)
_(t31,oD2)
_(cH1,t31)
_(fG1,cH1)
}
else{fG1.wxVkey=2
var aF2=_mz(z,'view',['class',50,'style',1],[],e,s,gg)
var tG2=_oz(z,52,e,s,gg)
_(aF2,tG2)
_(fG1,aF2)
}
var eH2=_mz(z,'view',['bindtap',53,'class',1,'data-event-opts',2],[],e,s,gg)
var bI2=_oz(z,56,e,s,gg)
_(eH2,bI2)
_(oF1,eH2)
fG1.wxXCkey=1
_(r,oF1)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_7();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardJoin.wxml'] = [$gwx0_XC_7, './pages/pageRelay/awardJoin.wxml'];else __wxAppCode__['pages/pageRelay/awardJoin.wxml'] = $gwx0_XC_7( './pages/pageRelay/awardJoin.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/awardJoin.wxss'] = setCssToHead([".",[1],"in_bgx.",[1],"data-v-1a8314b1{background-color:#fff;box-sizing:border-box;color:#333;font-size:",[0,28],";padding:",[0,30],"}\n.",[1],"in_bgx .",[1],"one_tit.",[1],"data-v-1a8314b1{font-size:",[0,30],"}\n.",[1],"in_bgx .",[1],"in_line.",[1],"data-v-1a8314b1{margin-top:",[0,40],"}\n.",[1],"in_bgx .",[1],"in_line .",[1],"right_in.",[1],"data-v-1a8314b1{-webkit-flex:1;flex:1;height:",[0,60],";margin-left:",[0,20],";position:relative}\n.",[1],"in_bgx .",[1],"in_line .",[1],"right_in wx-input.",[1],"data-v-1a8314b1{border:",[0,1]," solid #d8d8d8;border-radius:",[0,10],";box-sizing:border-box;height:",[0,60],";padding-right:",[0,80],";width:100%}\n.",[1],"in_bgx .",[1],"in_line .",[1],"right_in .",[1],"fix_t.",[1],"data-v-1a8314b1{position:absolute;right:",[0,30],";top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%)}\n.",[1],"in_bgx .",[1],"in_line .",[1],"right_in .",[1],"in_tps.",[1],"data-v-1a8314b1{color:#999;font-size:",[0,24],";margin-top:",[0,8],"}\n.",[1],"now_gold.",[1],"data-v-1a8314b1{background-color:#fff;box-sizing:border-box;color:#333;font-size:",[0,28],";margin-top:",[0,30],";padding:",[0,30],"}\n.",[1],"now_gold .",[1],"showg.",[1],"data-v-1a8314b1{margin-top:",[0,40],"}\n.",[1],"now_gold .",[1],"showg .",[1],"money_l .",[1],"rea_sh.",[1],"data-v-1a8314b1{font-size:",[0,52],";margin-left:",[0,20],"}\n.",[1],"now_gold .",[1],"showg .",[1],"r_bbtn.",[1],"data-v-1a8314b1{border-radius:",[0,12],";font-size:",[0,30],";height:",[0,70],";line-height:",[0,70],";text-align:center;width:",[0,160],"}\n.",[1],"now_gold .",[1],"jiang_in.",[1],"data-v-1a8314b1{margin-top:",[0,20],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/awardJoin.wxss:1:350)",{path:"./pages/pageRelay/awardJoin.wxss"});
}