$gwx0_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_9 || [];
function gz$gwx0_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-951c9a4e'])
Z([3,'width:100%;background-color:#fff;padding-bottom:200rpx;box-sizing:border-box;'])
Z([3,'ccc_box data-v-951c9a4e'])
Z([3,'tit_bols fl_sb data-v-951c9a4e'])
Z(z[0])
Z([a,[[2,'?:'],[[2,'=='],[[6],[[6],[[6],[[7],[3,'posInfo']],[3,'commodityList']],[1,0]],[3,'activityType']],[1,2]],[1,'供货团佣金类型说明'],[1,'佣金类型说明']]])
Z(z[0])
Z([3,'color:#999;font-size:24rpx;'])
Z([a,[[2,'?:'],[[2,'=='],[[6],[[6],[[6],[[7],[3,'posInfo']],[3,'commodityList']],[1,0]],[3,'activityType']],[1,2]],[1,'*交易服务费3%由你支付'],[1,'*交易服务费由你支付']]])
Z([3,'gu_dt data-v-951c9a4e'])
Z([3,'固定佣金'])
Z([3,'gu_de data-v-951c9a4e'])
Z([3,'你设置商品售价和佣金比例后，帮卖团长卖出商品你的收益\x3d售价-佣金，帮卖团长获得相应佣金'])
Z(z[2])
Z([3,'tit_bols data-v-951c9a4e'])
Z([3,'设置佣金金额'])
Z([[6],[[7],[3,'posInfo']],[3,'commodityList']])
Z([3,'heard_box data-v-951c9a4e'])
Z([3,'idnex'])
Z([3,'item'])
Z(z[16])
Z(z[18])
Z([3,'top_boxs data-v-951c9a4e'])
Z([3,'img_he data-v-951c9a4e'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'speceImg']]])
Z(z[0])
Z([3,'scaleToFill'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png'])
Z(z[0])
Z(z[26])
Z([[6],[[7],[3,'item']],[3,'speceImg']])
Z([3,'r_tex data-v-951c9a4e'])
Z([3,'title_nm data-v-951c9a4e'])
Z([a,[[6],[[7],[3,'item']],[3,'commodityName']]])
Z([3,'num_mon data-v-951c9a4e'])
Z([3,'mon_ey data-v-951c9a4e'])
Z([a,[[2,'+'],[1,'¥'],[[6],[[7],[3,'item']],[3,'defaultPriceShow']]]])
Z([3,'inpu_t data-v-951c9a4e'])
Z([3,'lef_tt data-v-951c9a4e'])
Z([3,'佣金'])
Z([3,'__e'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'sellCommissionSh']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'posInfo.commodityList']],[1,'']],[[7],[3,'idnex']]]]]]]]]]]]]]]])
Z([3,'请输入'])
Z([3,'text-align:left;'])
Z([3,'digit'])
Z([[6],[[7],[3,'item']],[3,'sellCommissionSh']])
Z([3,'fix_t data-v-951c9a4e'])
Z([3,'元'])
Z([3,'re_mark data-v-951c9a4e'])
Z(z[2])
Z(z[40])
Z([3,'buy_btn dfcbg data-v-951c9a4e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'gobacks']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'确定'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_9=true;
var x=['./pages/pageRelay/awardSell.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_9_1()
var hG3=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var cI3=_n('view')
_rz(z,cI3,'class',2,e,s,gg)
_(hG3,cI3)
var oJ3=_n('view')
_rz(z,oJ3,'class',3,e,s,gg)
var lK3=_n('text')
_rz(z,lK3,'class',4,e,s,gg)
var aL3=_oz(z,5,e,s,gg)
_(lK3,aL3)
_(oJ3,lK3)
var tM3=_mz(z,'text',['class',6,'style',1],[],e,s,gg)
var eN3=_oz(z,8,e,s,gg)
_(tM3,eN3)
_(oJ3,tM3)
_(hG3,oJ3)
var bO3=_n('view')
_rz(z,bO3,'class',9,e,s,gg)
var oP3=_oz(z,10,e,s,gg)
_(bO3,oP3)
_(hG3,bO3)
var xQ3=_n('view')
_rz(z,xQ3,'class',11,e,s,gg)
var oR3=_oz(z,12,e,s,gg)
_(xQ3,oR3)
_(hG3,xQ3)
var fS3=_n('view')
_rz(z,fS3,'class',13,e,s,gg)
_(hG3,fS3)
var cT3=_n('view')
_rz(z,cT3,'class',14,e,s,gg)
var hU3=_oz(z,15,e,s,gg)
_(cT3,hU3)
_(hG3,cT3)
var oH3=_v()
_(hG3,oH3)
if(_oz(z,16,e,s,gg)){oH3.wxVkey=1
var oV3=_n('view')
_rz(z,oV3,'class',17,e,s,gg)
var cW3=_v()
_(oV3,cW3)
var oX3=function(aZ3,lY3,t13,gg){
var b33=_n('view')
_rz(z,b33,'class',22,aZ3,lY3,gg)
var o43=_n('view')
_rz(z,o43,'class',23,aZ3,lY3,gg)
var x53=_v()
_(o43,x53)
if(_oz(z,24,aZ3,lY3,gg)){x53.wxVkey=1
var o63=_mz(z,'image',['class',25,'mode',1,'src',2],[],aZ3,lY3,gg)
_(x53,o63)
}
else{x53.wxVkey=2
var f73=_mz(z,'image',['class',28,'mode',1,'src',2],[],aZ3,lY3,gg)
_(x53,f73)
}
x53.wxXCkey=1
_(b33,o43)
var c83=_n('view')
_rz(z,c83,'class',31,aZ3,lY3,gg)
var h93=_n('view')
_rz(z,h93,'class',32,aZ3,lY3,gg)
var o03=_oz(z,33,aZ3,lY3,gg)
_(h93,o03)
_(c83,h93)
var cA4=_n('view')
_rz(z,cA4,'class',34,aZ3,lY3,gg)
var oB4=_n('text')
_rz(z,oB4,'class',35,aZ3,lY3,gg)
var lC4=_oz(z,36,aZ3,lY3,gg)
_(oB4,lC4)
_(cA4,oB4)
_(c83,cA4)
var aD4=_n('view')
_rz(z,aD4,'class',37,aZ3,lY3,gg)
var tE4=_n('text')
_rz(z,tE4,'class',38,aZ3,lY3,gg)
var eF4=_oz(z,39,aZ3,lY3,gg)
_(tE4,eF4)
_(aD4,tE4)
var bG4=_mz(z,'input',['bindinput',40,'class',1,'data-event-opts',2,'placeholder',3,'style',4,'type',5,'value',6],[],aZ3,lY3,gg)
_(aD4,bG4)
var oH4=_n('text')
_rz(z,oH4,'class',47,aZ3,lY3,gg)
var xI4=_oz(z,48,aZ3,lY3,gg)
_(oH4,xI4)
_(aD4,oH4)
_(c83,aD4)
_(b33,c83)
_(t13,b33)
return t13
}
cW3.wxXCkey=2
_2z(z,20,oX3,e,s,gg,cW3,'item','idnex','idnex')
_(oH3,oV3)
}
var oJ4=_n('view')
_rz(z,oJ4,'class',49,e,s,gg)
_(hG3,oJ4)
var fK4=_n('view')
_rz(z,fK4,'class',50,e,s,gg)
_(hG3,fK4)
var cL4=_mz(z,'view',['bindtap',51,'class',1,'data-event-opts',2],[],e,s,gg)
var hM4=_oz(z,54,e,s,gg)
_(cL4,hM4)
_(hG3,cL4)
oH3.wxXCkey=1
_(r,hG3)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_9();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSell.wxml'] = [$gwx0_XC_9, './pages/pageRelay/awardSell.wxml'];else __wxAppCode__['pages/pageRelay/awardSell.wxml'] = $gwx0_XC_9( './pages/pageRelay/awardSell.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/awardSell.wxss'] = setCssToHead(["body{min-height:100vh}\n.",[1],"tit_bols.",[1],"data-v-951c9a4e{border-bottom:",[0,1]," solid #f0f0f0;box-sizing:border-box;font-size:",[0,28],";font-weight:700;height:",[0,100],";line-height:",[0,100],";padding:0 ",[0,30],"}\n.",[1],"gu_dt.",[1],"data-v-951c9a4e{font-size:",[0,28],";font-weight:700;margin-top:",[0,20],";padding-left:",[0,30],"}\n.",[1],"gu_de.",[1],"data-v-951c9a4e{box-sizing:border-box;color:#999;font-size:",[0,24],";padding:",[0,20]," ",[0,30],"}\n.",[1],"heard_box.",[1],"data-v-951c9a4e{box-sizing:border-box;padding:",[0,12]," ",[0,30]," ",[0,40],";text-align:left;width:100%}\n.",[1],"heard_box .",[1],"top_boxs.",[1],"data-v-951c9a4e{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:",[0,200],";-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,16],"}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"img_he wx-image.",[1],"data-v-951c9a4e,.",[1],"heard_box .",[1],"top_boxs .",[1],"img_he.",[1],"data-v-951c9a4e{height:",[0,200],";width:",[0,200],"}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"r_tex.",[1],"data-v-951c9a4e{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,200],";-webkit-justify-content:space-around;justify-content:space-around;width:100%}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"r_tex .",[1],"title_nm.",[1],"data-v-951c9a4e{color:#333;font-size:",[0,32],";font-weight:700;margin-left:",[0,28],"}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"r_tex .",[1],"num_mon.",[1],"data-v-951c9a4e{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;margin-left:",[0,28],"}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"r_tex .",[1],"num_mon .",[1],"mon_ey.",[1],"data-v-951c9a4e{color:#eb3737;font-size:",[0,30],";font-weight:700}\n.",[1],"heard_box .",[1],"top_boxs .",[1],"r_tex .",[1],"num_mon .",[1],"num_s.",[1],"data-v-951c9a4e{color:#333;font-size:",[0,28],";text-align:right}\n.",[1],"re_mark.",[1],"data-v-951c9a4e{box-sizing:border-box}\n.",[1],"ccc_box.",[1],"data-v-951c9a4e{background-color:#f0f0f0;height:",[0,20],";width:100%}\n.",[1],"buy_btn.",[1],"data-v-951c9a4e{background-color:#1777ff;bottom:0;color:#fff;font-size:",[0,32],";font-weight:700;height:",[0,100],";left:0;line-height:",[0,100],";position:fixed;text-align:center;width:",[0,750],"}\n.",[1],"jia_inus.",[1],"data-v-951c9a4e{color:#333;font-size:",[0,28],";height:",[0,100],";padding:",[0,0]," ",[0,30],"}\n.",[1],"jia_inus .",[1],"mini_ss.",[1],"data-v-951c9a4e{font-size:",[0,28],"}\n.",[1],"inpu_t.",[1],"data-v-951c9a4e{margin-left:",[0,28],";position:relative;width:",[0,210],"}\n.",[1],"inpu_t wx-text.",[1],"data-v-951c9a4e{color:#333;font-size:",[0,30],";position:absolute}\n.",[1],"inpu_t wx-input.",[1],"data-v-951c9a4e{border:",[0,1]," solid #d8d8d8;border-radius:",[0,10],";box-sizing:border-box;color:#ef7615;height:",[0,60],";padding-left:",[0,80],";padding-right:",[0,50],";width:",[0,210],"}\n.",[1],"inpu_t .",[1],"lef_tt.",[1],"data-v-951c9a4e{left:",[0,10],"}\n.",[1],"inpu_t .",[1],"fix_t.",[1],"data-v-951c9a4e,.",[1],"inpu_t .",[1],"lef_tt.",[1],"data-v-951c9a4e{top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%)}\n.",[1],"inpu_t .",[1],"fix_t.",[1],"data-v-951c9a4e{right:",[0,20],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/awardSell.wxss:1:2176)",{path:"./pages/pageRelay/awardSell.wxss"});
}