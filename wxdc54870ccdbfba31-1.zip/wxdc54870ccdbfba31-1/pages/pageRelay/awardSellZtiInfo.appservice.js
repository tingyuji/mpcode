$gwx0_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_12 || [];
function gz$gwx0_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'data-v-32d50b58'])
Z([3,'#07c160'])
Z([3,'map'])
Z([3,'48'])
Z([3,'27cb5d9c-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_12=true;
var x=['./pages/pageRelay/awardSellZtiInfo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_12_1()
var x7F=_mz(z,'u-icon',['bind:__l',0,'class',1,'color',1,'name',2,'size',3,'vueId',4],[],e,s,gg)
_(r,x7F)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSellZtiInfo.wxml'] = [$gwx0_XC_12, './pages/pageRelay/awardSellZtiInfo.wxml'];else __wxAppCode__['pages/pageRelay/awardSellZtiInfo.wxml'] = $gwx0_XC_12( './pages/pageRelay/awardSellZtiInfo.wxml' );
	;__wxRoute = "pages/pageRelay/awardSellZtiInfo";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/awardSellZtiInfo.js";define("pages/pageRelay/awardSellZtiInfo.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/awardSellZtiInfo"],{634:function(e,n,t){"use strict";(function(e){t(5),a(t(4));var n=a(t(635));function a(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},635:function(e,n,t){"use strict";t.r(n);var a=t(636),o=t(638);for(var r in o)"default"!==r&&function(e){t.d(n,e,(function(){return o[e]}))}(r);t(640);var s=t(17),i=Object(s.default)(o.default,a.render,a.staticRenderFns,!1,null,"32d50b58",null,!1,a.components,void 0);i.options.__file="pages/pageRelay/awardSellZtiInfo.vue",n.default=i.exports},636:function(e,n,t){"use strict";t.r(n);var a=t(637);t.d(n,"render",(function(){return a.render})),t.d(n,"staticRenderFns",(function(){return a.staticRenderFns})),t.d(n,"recyclableRender",(function(){return a.recyclableRender})),t.d(n,"components",(function(){return a.components}))},637:function(e,n,t){"use strict";var a;t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return s})),t.d(n,"recyclableRender",(function(){return r})),t.d(n,"components",(function(){return a}));try{a={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},r=!1,s=[];o._withStripped=!0},638:function(e,n,t){"use strict";t.r(n);var a=t(639),o=t.n(a);for(var r in a)"default"!==r&&function(e){t.d(n,e,(function(){return a[e]}))}(r);n.default=o.a},639:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),o={data:function(){return{showShares:!1,userInfos:{},shareObj:{},titleName:"我的成员",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多成员"},loadStatus:"loading",page:1,pageSize:20,shareImgMini:"",addressInfo:{id:"",userName:"",userMobile:"",provinces:"",address:"",defaultFlag:"",addressType:2,addressName:"",longitude:0,latitude:0,showName:"",spickupImg:"",category:"",managerUserId:"",managerInfo:{id:"",nickName:"",headImg:"",managerUserId:"",createTime:""}},userAddrData:{orderCount:0,commissionAmount:0,createTimeDay:0}}},onLoad:function(e){if(e&&e.item){var n=JSON.parse(decodeURIComponent(e.item));this.addressInfo=n,this.addrDataById()}},onShow:function(){this.addressInfo.id&&this.addrDataById()},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.listSubscribes())},onShareAppMessage:function(n){var t=e.getStorageSync("userInfo")||{},a={title:t.nickName+"邀请您成为自提点管理员",path:"/pages/subPage/myHome?zt="+t.userId,imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(e){},fail:function(){}};if("button"==n.from){n.target.dataset;var o=this}return o=this,a.imageUrl=o.shareImgMini,a},methods:{otherFun:function(e){console.log("上个页面传值",e),this.addressInfo.managerInfo={id:"",nickName:e.nickName,headImg:e.headImg,managerUserId:e.userId,createTime:"刚刚"},this.addressInfo.managerUserId=e.user},submitRelay:function(n){var t=this;if(1==n)e.showModal({title:"确定要移除自提点管理员吗？",content:"当前自提点管理员的记录将清空",confirmText:"确认设置",cancelText:"取消",confirmColor:"#07c160",success:function(n){n.cancel||n.confirm&&t.$server.delAddrManager({id:t.addressInfo.managerInfo.id}).then((function(n){0==n.code?(e.showToast({title:"移除成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),1200)):e.showToast({title:n.message,icon:"none"})}))}});else{var a=JSON.parse(JSON.stringify(this.addressInfo));a.pageType=2;var o=encodeURIComponent(JSON.stringify(a));e.navigateTo({url:"./snapList?item="+o})}},shareUrl:function(e){this.shareImgMini=e,this.showShares=!1,this.shareObj={}},addrDataById:function(){var n=this;e.getStorageSync("userInfo"),this.$server.addrDataById({addressId:this.addressInfo.id}).then((function(t){0==t.code?(t.data.commissionAmount=a.default.centTurnSmacker(t.data.commissionAmount/100),t.data.createTimeDay=a.default.getDifferTime(t.data.createTime,null,1),n.userAddrData=t.data):e.showToast({title:t.message,icon:"none"})}))},shareHelpOpen:function(){this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.memberCount=this.userInfos.memberCount||"1",this.shareObj.solitaireCount=this.userInfos.solitaireCount||"0",this.shareObj.introduction=this.userInfos.introduction.slice(0,14),this.shareObj.ztShare=1,this.showShares=!0},goMyhome:function(n){e.navigateTo({url:"./myHome?uid="+n})}}};n.default=o}).call(this,t(1).default)},640:function(e,n,t){"use strict";t.r(n);var a=t(641),o=t.n(a);for(var r in a)"default"!==r&&function(e){t.d(n,e,(function(){return a[e]}))}(r);n.default=o.a},641:function(e,n,t){}},[[634,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/awardSellZtiInfo.js'});require("pages/pageRelay/awardSellZtiInfo.js");