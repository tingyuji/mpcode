$gwx0_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_16 || [];
function gz$gwx0_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'xz_specs data-v-62333f54'])
Z([3,'background-color:#ebeced;min-height:100vh;padding-bottom:10vh;'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'classNameList']])
Z(z[2])
Z([[2,'!'],[[7],[3,'commodityId']]])
Z([[6],[[7],[3,'speceInfoLi']],[3,'length']])
Z(z[2])
Z(z[3])
Z([[7],[3,'speceInfoLi']])
Z(z[2])
Z([3,'__e'])
Z([3,'slot-btn fl data-v-62333f54'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'upBgimg']],[[4],[[5],[[7],[3,'index']]]]]]]]]]]])
Z([[2,'!'],[[2,'!'],[[6],[[7],[3,'item']],[3,'imgUrl']]]])
Z([3,'slot-btn__hover'])
Z([3,'150'])
Z([3,'addBtn'])
Z([3,'__l'])
Z([3,'data-v-62333f54'])
Z([3,'#999'])
Z([3,'camera-fill'])
Z([3,'40'])
Z([[2,'+'],[1,'0de62b70-1-'],[[7],[3,'index']]])
Z(z[19])
Z(z[12])
Z(z[12])
Z(z[20])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'changeName']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showInput']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,true])
Z([3,'修改规格项'])
Z([[7],[3,'showInput']])
Z([3,'0de62b70-2'])
Z([[4],[[5],[1,'default']]])
Z([3,'500'])
Z(z[19])
Z(z[12])
Z(z[12])
Z(z[20])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'addInName']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'swAddInput']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[30])
Z([3,'添加规格项'])
Z([[7],[3,'swAddInput']])
Z([3,'0de62b70-3'])
Z(z[34])
Z(z[35])
Z(z[19])
Z(z[12])
Z(z[12])
Z(z[20])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'plszChange']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPlsz']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[30])
Z([3,'批量设置'])
Z([[7],[3,'showPlsz']])
Z([3,'0de62b70-4'])
Z(z[34])
Z([3,'600'])
Z([3,'fl_cs data-v-62333f54'])
Z([[2,'!'],[[6],[[7],[3,'plszData']],[3,'imgUrl']]])
Z(z[12])
Z(z[13])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'upBgimg']],[[4],[[5],[1,999]]]]]]]]]]])
Z(z[16])
Z(z[17])
Z(z[18])
Z(z[19])
Z(z[20])
Z(z[21])
Z(z[22])
Z(z[23])
Z([[2,'+'],[[2,'+'],[1,'0de62b70-5'],[1,',']],[1,'0de62b70-4']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_16=true;
var x=['./pages/pageRelay/checkSpecs.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_16_1()
var c8H=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var o0H=_v()
_(c8H,o0H)
var cAI=function(lCI,oBI,aDI,gg){
var eFI=_v()
_(aDI,eFI)
if(_oz(z,6,lCI,oBI,gg)){eFI.wxVkey=1
}
eFI.wxXCkey=1
return aDI
}
o0H.wxXCkey=2
_2z(z,4,cAI,e,s,gg,o0H,'item','index','index')
var h9H=_v()
_(c8H,h9H)
if(_oz(z,7,e,s,gg)){h9H.wxVkey=1
var bGI=_v()
_(h9H,bGI)
var oHI=function(oJI,xII,fKI,gg){
var hMI=_mz(z,'view',['bindtap',12,'class',1,'data-event-opts',2,'hidden',3,'hoverClass',4,'hoverStayTime',5,'slot',6],[],oJI,xII,gg)
var oNI=_mz(z,'u-icon',['bind:__l',19,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oJI,xII,gg)
_(hMI,oNI)
_(fKI,hMI)
return fKI
}
bGI.wxXCkey=4
_2z(z,10,oHI,e,s,gg,bGI,'item','index','index')
}
var cOI=_mz(z,'u-modal',['content',-1,'bind:__l',25,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'showCancelButton',5,'title',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
_(c8H,cOI)
var oPI=_mz(z,'u-modal',['content',-1,'bind:__l',36,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'showCancelButton',5,'title',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
_(c8H,oPI)
var lQI=_mz(z,'u-modal',['content',-1,'bind:__l',47,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'showCancelButton',5,'title',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
var aRI=_n('view')
_rz(z,aRI,'class',58,e,s,gg)
var tSI=_v()
_(aRI,tSI)
if(_oz(z,59,e,s,gg)){tSI.wxVkey=1
var eTI=_mz(z,'view',['bindtap',60,'class',1,'data-event-opts',2,'hoverClass',3,'hoverStayTime',4,'slot',5],[],e,s,gg)
var bUI=_mz(z,'u-icon',['bind:__l',66,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(eTI,bUI)
_(tSI,eTI)
}
else{tSI.wxVkey=2
}
tSI.wxXCkey=1
tSI.wxXCkey=3
_(lQI,aRI)
_(c8H,lQI)
h9H.wxXCkey=1
h9H.wxXCkey=3
_(r,c8H)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/checkSpecs.wxml'] = [$gwx0_XC_16, './pages/pageRelay/checkSpecs.wxml'];else __wxAppCode__['pages/pageRelay/checkSpecs.wxml'] = $gwx0_XC_16( './pages/pageRelay/checkSpecs.wxml' );
	;__wxRoute = "pages/pageRelay/checkSpecs";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/checkSpecs.js";define("pages/pageRelay/checkSpecs.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/checkSpecs"],{386:function(e,t,i){"use strict";(function(e){i(5),s(i(4));var t=s(i(387));function s(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=i,e(t.default)}).call(this,i(1).createPage)},387:function(e,t,i){"use strict";i.r(t);var s=i(388),o=i(390);for(var n in o)"default"!==n&&function(e){i.d(t,e,(function(){return o[e]}))}(n);i(392);var a=i(17),c=Object(a.default)(o.default,s.render,s.staticRenderFns,!1,null,"62333f54",null,!1,s.components,void 0);c.options.__file="pages/pageRelay/checkSpecs.vue",t.default=c.exports},388:function(e,t,i){"use strict";i.r(t);var s=i(389);i.d(t,"render",(function(){return s.render})),i.d(t,"staticRenderFns",(function(){return s.staticRenderFns})),i.d(t,"recyclableRender",(function(){return s.recyclableRender})),i.d(t,"components",(function(){return s.components}))},389:function(e,t,i){"use strict";var s;i.r(t),i.d(t,"render",(function(){return o})),i.d(t,"staticRenderFns",(function(){return a})),i.d(t,"recyclableRender",(function(){return n})),i.d(t,"components",(function(){return s}));try{s={uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uModal:function(){return i.e("uview-ui/components/u-modal/u-modal").then(i.bind(null,961))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(t){e.showPlsz=!0})},n=!1,a=[];o._withStripped=!0},390:function(e,t,i){"use strict";i.r(t);var s=i(391),o=i.n(s);for(var n in s)"default"!==n&&function(e){i.d(t,e,(function(){return s[e]}))}(n);t.default=o.a},391:function(e,t,i){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var s=function(e){return e&&e.__esModule?e:{default:e}}(i(61)),o={data:function(){return{showInput:!1,swAddInput:!1,popText:"",fileList:[],checkedDy:!0,showPlsz:!1,plszData:{underlinePriceShow:"",weight:"",stock:"",sellPriceShow:"",imgUrl:""},xieyiCh:!0,tareaValue:"",autoHeight:!0,classList:[],classNameList:[],cousSty:{borderBottom:"1rpx solid #e5e5e5",fontSize:"38rpx",paddingBottom:"16rpx",boxSizing:"border-box"},showMenu:!1,titles:"",xiugai:{aIndex:0,bIndex:0},speceInfoLi:[],queryHeader:{},indexType:1,getListData:!1,commodityId:"",editTagName:!1,qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""},isEleEdit:!1,onesId:""}},watch:{classNameList:{handler:function(e,t){console.log(this.getListData,"cmid=",!this.commodityId,"edittag=",!this.editTagName),!this.getListData||this.commodityId||this.editTagName||this.listRefresh(1),this.getListData&&this.commodityId&&!this.editTagName&&this.listRefresh(2),this.editTagName&&(this.editTagName=!1)},immediate:!0,deep:!0}},onShow:function(){this.getFormatList()},onLoad:function(t){if(e.hideShareMenu({}),console.log("参数e===",t),this.qiniuInfo=e.getStorageSync("qiniuInfo"),console.log("页面传参",this.qiniuInfo),999!=t.type){var i=JSON.parse(decodeURIComponent(t.item));return this.indexType=i.indexType,i.commodityData.id&&(this.commodityId=i.commodityData.id),console.log("页面传参",i),this.classNameList=i.commodityData.classNameList||[],this.speceInfoLi=i.commodityData.formatDetailList||[],!1}this.isEleEdit=!0,this.indexType=0,this.vuex_specsOne.length&&(this.vuex_specsOne[this.indexType].speceInfoLi?(console.log("vuexdata1==",this.vuex_specsOne),this.vuex_specsOne[this.indexType].classList&&(this.classList=this.vuex_specsOne[this.indexType].classList),this.classNameList=this.vuex_specsOne[this.indexType].classNameList,this.speceInfoLi=this.vuex_specsOne[this.indexType].speceInfoLi):t.id&&this.formatDetailInfo()),t.id&&(this.onesId=t.id)},methods:{listRefresh:function(t){var i=this;console.log("listRefresh==",t);var o=this.$u.deepClone(this.speceInfoLi);if(0==this.classNameList.length)return this.speceInfoLi=[],!1;var n=[];this.classNameList.forEach((function(e,t){n[t]=[],e.tagList.forEach((function(e,i){n[t].push(e)}))})),console.log("breakArr==",n);var a=s.default.cartesian(n,"",this.commodityId);console.log("生成后的as",a);var c=[],r=[];a.forEach((function(e,t){if(console.log("cuirrr==",e),Array.isArray(e)){var s=e.join("/");r.push({id:"",commodityCode:"",commodityId:i.commodityId,formatItemName:s,sellPrice:"",sellPriceShow:"",groupPrice:"",groupPriceShow:"",stock:"",underlinePrice:"",underlinePriceShow:"",weight:"",imgUrl:""}),o.forEach((function(t){if(console.log("修改等值00000===",t,e),t.formatItemName==s){if(c.includes(t.formatItemName))return!1;c.push(t.formatItemName),console.log("修改等值1==="),console.log(t,e),r[r.length-1]=t}}))}else r.push(e),o.forEach((function(t){if(console.log("oldCur==oldCur",t,e),t.formatItemName==e.formatItemName){if(c.includes(t.formatItemName))return!1;c.push(t.formatItemName),console.log(t,e),console.log("修改等值2==="),r[r.length-1]=t}}))})),console.log("ppaasssddgg=====",r),this.speceInfoLi=r,setTimeout((function(){e.hideLoading()}),300)},goSpeceMore:function(){if(this.commodityId)return e.showToast({title:"编辑产品不可修改规格",icon:"none"}),!1;e.navigateTo({url:"./speceList"})},zzUpload:function(e,t){var i=e.data,s=JSON.parse(i).data,o=s[Object.keys(s)];console.log("imgUrl===",o),99==t?this.plszData.imgUrl=o:this.speceInfoLi[t].imgUrl=o},upBgimg:function(t){var i=this;e.chooseImage({count:1,sizeType:["compressed"],sourceType:["camera","album"],success:function(s){e.showLoading({title:"上传中"}),console.log("beij-=",s),console.log(JSON.stringify(s.tempFilePaths));var o=s.tempFilePaths[0],n="."+o.split(".")[1];console.log("图片类型后缀==",n);for(var a="",c=0;c<18;c++)a+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a=i.qiniuInfo.imgFolderPath+a+n,e.uploadFile({url:"https://up-z2.qiniup.com",filePath:o,name:"file",formData:{key:a,token:i.qiniuInfo.uploadToken},success:function(e){console.log("uploadFileRes",e);var s=i.qiniuInfo.urlPrefix+a;console.log("imgUrl===",s),999==t?i.plszData.imgUrl=s:i.speceInfoLi[t].imgUrl=s},complete:function(t){e.hideLoading()}})}})},changeName:function(){var e=this;if(console.log("修改",this.popText),this.popText){var t=this.classNameList[this.xiugai.aIndex].tagList[this.xiugai.bIndex];console.log("复制oldName",t);var i=JSON.parse(JSON.stringify(this.classNameList[this.xiugai.aIndex].tagList));i[this.xiugai.bIndex]=this.popText,this.editTagName=!0;var s=this.$u.deepClone(this.speceInfoLi);s.forEach((function(i){var s=i.formatItemName.split("/");console.log("aFormName",s,e.xiugai.aIndex),s[e.xiugai.aIndex]==t&&(s[e.xiugai.aIndex]=e.popText,i.formatItemName=s.join("/"))})),console.log("speceOld2222==",s),this.classNameList[this.xiugai.aIndex].tagList=i,this.speceInfoLi=s}},pickClass:function(t,i){return this.commodityId?(e.showToast({title:"编辑产品不可修改规格",icon:"none"}),!1):!this.classList[i].isChecks&&(e.showLoading({title:"加载中"}),this.classList[i].isChecks=!0,void this.classNameList.push({name:t.name,tagList:t.tagList}))},delRows:function(t){var i=this;e.showModal({content:"确认删除该规格类型吗",confirmText:"删除",confirmColor:"#FF0000",success:function(e){e.confirm?(console.log("用户点击确定",t),i.classNameList.splice(t,1),i.classList[t].isChecks=!1):e.cancel&&console.log("用户点击取消")}})},tagChange:function(e,t){var i=this.classNameList[e].tagList[t];this.popText=i,this.xiugai.aIndex=e,this.xiugai.bIndex=t,this.showInput=!0},addTag:function(e){this.popText&&(this.popText=""),this.xiugai.aIndex=e,this.swAddInput=!0},addInName:function(){console.log("添加规格项");var e=this.popText;this.classNameList[this.xiugai.aIndex].tagList.push(e)},delTag:function(e,t){console.log(e,t),this.classNameList[e].tagList.splice(t,1)},gobacks:function(){var t=this,i=[],s=[],o=[],n="",a=this.speceInfoLi.map((function(e,t){return e.sellPriceShow||n||(n="请输入‘"+e.formatItemName+"’商品售价"),e.underlinePrice=100*e.underlinePriceShow,e.sellPrice=100*e.sellPriceShow,i.push(e.sellPriceShow),s.push(e.underlinePriceShow),o.push(e.weight),e}));if(n)return e.showToast({title:n,icon:"none"}),!1;var c=i.sort((function(e,t){return e-t})),r=s.sort((function(e,t){return e-t})),l=o.sort((function(e,t){return e-t}));console.log("this.cardList",a);var u={},d="";u.formatDetailList=a;var h=JSON.parse(JSON.stringify(this.classNameList));console.log("classNameLiFORST",h),h.forEach((function(e){t.onesId?e.commodityId=t.onesId:t.commodityId?e.commodityId=t.commodityId:e.commodityId="",e.formatName=e.name,d=d.length?d+","+e.name:e.name,e.formatItems=e.tagList.join()})),c.length>1&&100*c[0]<100*c[c.length-1]?u.sellFormPrice=c[0]+"~"+c[c.length-1]:u.sellFormPrice=c[0],console.log("underPriceArr==",r),r.length>1&&100*r[0]<100*r[r.length-1]?""==r[0]?u.underFormPrice="0~"+r[r.length-1]:u.underFormPrice=r[0]+"~"+r[r.length-1]:u.underFormPrice=r[0],l.length>1&&l[0]<l[l.length-1]?""==l[0]?u.weightForm="0~"+l[l.length-1]:u.weightForm=l[0]+"~"+l[l.length-1]:u.weightForm=l[0],u.defaultPriceShow=c[0],u.underlinePriceShow=r[0],u.defaultPrice=100*c[0],u.underlinePrice=100*r[0],u.formatList=h,u.type=this.indexType,u.formatNameAdd=d,u.classNameList=this.classNameList,console.log("item==",u);var m={};m.classList=this.classList,m.classNameList=this.classNameList,m.speceInfoLi=this.speceInfoLi,m.formIndex=this.indexType;var f=[];this.isEleEdit?((f=this.$u.deepClone(this.vuex_specsOne))[this.indexType]=m,this.$u.vuex("vuex_specsOne",f)):((f=this.$u.deepClone(this.vuex_specs))[this.indexType]=m,this.$u.vuex("vuex_specs",f));var p=getCurrentPages();p[p.length-2].$vm.speceFun(u),e.navigateBack()},plszChange:function(){var e=this;this.speceInfoLi.forEach((function(t,i){t.underlinePriceShow=e.plszData.underlinePriceShow,t.weight=e.plszData.weight,t.stock=e.plszData.stock,t.sellPriceShow=e.plszData.sellPriceShow,t.imgUrl=e.plszData.imgUrl}))},getFormatList:function(){var t=this;this.$server.formatList({businessType:1}).then((function(i){if(0==i.code){var s=i.data.map((function(e,i){return e.name=e.formatName,e.isChecks=!1,t.commodityId?e.isChecks=!0:e.isChecks=!1,e.tagList=e.formatItem.split("/"),e})),o=JSON.parse(JSON.stringify(s));t.classList=o,console.log("this.vuex_specs==",t.vuex_specs),t.getListData=!0}else e.showToast({title:i.message,icon:"none"})}))},formatDetailInfo:function(t,i){var o=this;this.$server.formatDetailInfo({commodityId:this.commodityId}).then((function(t){if(0==t.code){var i=t.data.formatDetailList.map((function(e,t){return console.log("cur==",e),e.sellPriceShow=s.default.centTurnSmacker(e.sellPrice/100),e.underlinePriceShow=s.default.centTurnSmacker(e.underlinePrice/100),e.checkPriceShow=e.sellPriceShow,e})),n=[];t.data.formatList.map((function(e,t){return n.push({id:e.id,name:e.formatName,tagList:e.formatItems.split(",")}),e})),o.classNameList=n,o.speceInfoLi=i}else e.showToast({title:t.message,icon:"none"})}))}}};t.default=o}).call(this,i(1).default)},392:function(e,t,i){"use strict";i.r(t);var s=i(393),o=i.n(s);for(var n in s)"default"!==n&&function(e){i.d(t,e,(function(){return s[e]}))}(n);t.default=o.a},393:function(e,t,i){}},[[386,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/checkSpecs.js'});require("pages/pageRelay/checkSpecs.js");