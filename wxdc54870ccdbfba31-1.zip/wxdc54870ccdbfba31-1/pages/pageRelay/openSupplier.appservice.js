$gwx0_XC_33=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_33 || [];
function gz$gwx0_XC_33_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_33_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_33_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_33_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'picker_city data-v-9f8bc7c8'])
Z([3,'padding-bottom:60rpx;'])
Z([[2,'!='],[[6],[[7],[3,'formDatas']],[3,'suppliersStatus']],[1,1]])
Z([[2,'&&'],[[2,'>'],[[6],[[7],[3,'formDatas']],[3,'suppliersStatus']],[1,2]],[[6],[[7],[3,'formDatas']],[3,'auditMsg']]])
Z([3,'max_box data-v-9f8bc7c8'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'formDatas']],[3,'productList']])
Z(z[5])
Z([[2,'>'],[[6],[[6],[[7],[3,'formDatas']],[3,'productList']],[3,'length']],[1,1]])
Z([3,'__e'])
Z([3,'add_news fl data-v-9f8bc7c8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'addCommodity']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'data-v-9f8bc7c8'])
Z([3,'#07c160'])
Z([3,'plus-circle-fill'])
Z([3,'36'])
Z([3,'5709e86a-1'])
Z([3,'inp_boxs data-v-9f8bc7c8'])
Z([3,'big_imgg data-v-9f8bc7c8'])
Z([3,'k'])
Z([3,'j'])
Z([[7],[3,'businessLicensearr']])
Z(z[21])
Z(z[13])
Z(z[10])
Z(z[14])
Z([[7],[3,'iconStyles']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'delMiniImg']],[[4],[[5],[[5],[1,1]],[[7],[3,'k']]]]]]]]]]]])
Z([3,'close-circle-fill'])
Z(z[17])
Z([[2,'+'],[1,'5709e86a-2-'],[[7],[3,'k']]])
Z([[2,'<'],[[6],[[7],[3,'businessLicensearr']],[3,'length']],[1,3]])
Z(z[10])
Z([3,'up_btnb fl_cb aa_bbc data-v-9f8bc7c8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'upBgimg']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[1,'businessLicensearr']]]]]]]]]]])
Z(z[13])
Z(z[14])
Z([3,'#ccc'])
Z([3,'camera'])
Z([3,'50'])
Z([3,'5709e86a-3'])
Z(z[20])
Z(z[21])
Z(z[22])
Z([[7],[3,'otherLicensearr']])
Z(z[21])
Z(z[13])
Z(z[10])
Z(z[14])
Z(z[28])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'delMiniImg']],[[4],[[5],[[5],[1,2]],[[7],[3,'k']]]]]]]]]]]])
Z(z[30])
Z(z[17])
Z([[2,'+'],[1,'5709e86a-4-'],[[7],[3,'k']]])
Z([[2,'<'],[[6],[[7],[3,'otherLicensearr']],[3,'length']],[1,3]])
Z(z[10])
Z(z[35])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'upBgimg']],[[4],[[5],[[5],[1,'$0']],[1,2]]]],[[4],[[5],[1,'otherLicensearr']]]]]]]]]]])
Z(z[13])
Z(z[14])
Z(z[39])
Z(z[40])
Z(z[41])
Z([3,'5709e86a-5'])
Z(z[13])
Z(z[10])
Z(z[10])
Z(z[14])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirms']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'chooseCityBox']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'region'])
Z([[7],[3,'params']])
Z([[7],[3,'chooseCityBox']])
Z([3,'5709e86a-6'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_33_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_33_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_33=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_33=true;
var x=['./pages/pageRelay/openSupplier.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_33_1()
var b3O=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var o4O=_v()
_(b3O,o4O)
if(_oz(z,2,e,s,gg)){o4O.wxVkey=1
var x5O=_v()
_(o4O,x5O)
if(_oz(z,3,e,s,gg)){x5O.wxVkey=1
}
x5O.wxXCkey=1
}
var o6O=_n('view')
_rz(z,o6O,'class',4,e,s,gg)
var f7O=_v()
_(o6O,f7O)
var c8O=function(o0O,h9O,cAP,gg){
var lCP=_v()
_(cAP,lCP)
if(_oz(z,9,o0O,h9O,gg)){lCP.wxVkey=1
}
lCP.wxXCkey=1
return cAP
}
f7O.wxXCkey=2
_2z(z,7,c8O,e,s,gg,f7O,'item','index','index')
var aDP=_mz(z,'view',['bindtap',10,'class',1,'data-event-opts',2],[],e,s,gg)
var tEP=_mz(z,'u-icon',['bind:__l',13,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(aDP,tEP)
_(o6O,aDP)
var eFP=_n('view')
_rz(z,eFP,'class',19,e,s,gg)
var bGP=_n('view')
_rz(z,bGP,'class',20,e,s,gg)
var xIP=_v()
_(bGP,xIP)
var oJP=function(cLP,fKP,hMP,gg){
var cOP=_mz(z,'u-icon',['bind:__l',25,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],cLP,fKP,gg)
_(hMP,cOP)
return hMP
}
xIP.wxXCkey=4
_2z(z,23,oJP,e,s,gg,xIP,'j','k','k')
var oHP=_v()
_(bGP,oHP)
if(_oz(z,33,e,s,gg)){oHP.wxVkey=1
var oPP=_mz(z,'view',['bindtap',34,'class',1,'data-event-opts',2],[],e,s,gg)
var lQP=_mz(z,'u-icon',['bind:__l',37,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oPP,lQP)
_(oHP,oPP)
}
oHP.wxXCkey=1
oHP.wxXCkey=3
_(eFP,bGP)
var aRP=_n('view')
_rz(z,aRP,'class',43,e,s,gg)
var eTP=_v()
_(aRP,eTP)
var bUP=function(xWP,oVP,oXP,gg){
var cZP=_mz(z,'u-icon',['bind:__l',48,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],xWP,oVP,gg)
_(oXP,cZP)
return oXP
}
eTP.wxXCkey=4
_2z(z,46,bUP,e,s,gg,eTP,'j','k','k')
var tSP=_v()
_(aRP,tSP)
if(_oz(z,56,e,s,gg)){tSP.wxVkey=1
var h1P=_mz(z,'view',['bindtap',57,'class',1,'data-event-opts',2],[],e,s,gg)
var o2P=_mz(z,'u-icon',['bind:__l',60,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(h1P,o2P)
_(tSP,h1P)
}
tSP.wxXCkey=1
tSP.wxXCkey=3
_(eFP,aRP)
_(o6O,eFP)
_(b3O,o6O)
var c3P=_mz(z,'u-picker',['bind:__l',66,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'mode',5,'params',6,'value',7,'vueId',8],[],e,s,gg)
_(b3O,c3P)
o4O.wxXCkey=1
_(r,b3O)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_33";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_33();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/openSupplier.wxml'] = [$gwx0_XC_33, './pages/pageRelay/openSupplier.wxml'];else __wxAppCode__['pages/pageRelay/openSupplier.wxml'] = $gwx0_XC_33( './pages/pageRelay/openSupplier.wxml' );
	;__wxRoute = "pages/pageRelay/openSupplier";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/openSupplier.js";define("pages/pageRelay/openSupplier.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/openSupplier"],{696:function(e,t,n){"use strict";(function(e){n(5),o(n(4));var t=o(n(697));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},697:function(e,t,n){"use strict";n.r(t);var o=n(698),i=n(700);for(var r in i)"default"!==r&&function(e){n.d(t,e,(function(){return i[e]}))}(r);n(702);var s=n(17),a=Object(s.default)(i.default,o.render,o.staticRenderFns,!1,null,"9f8bc7c8",null,!1,o.components,void 0);a.options.__file="pages/pageRelay/openSupplier.vue",t.default=a.exports},698:function(e,t,n){"use strict";n.r(t);var o=n(699);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},699:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return s})),n.d(t,"recyclableRender",(function(){return r})),n.d(t,"components",(function(){return o}));try{o={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))},uPicker:function(){return Promise.all([n.e("common/vendor"),n.e("uview-ui/components/u-picker/u-picker")]).then(n.bind(null,1017))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},r=!1,s=[];i._withStripped=!0},700:function(e,t,n){"use strict";n.r(t);var o=n(701),i=n.n(o);for(var r in o)"default"!==r&&function(e){n.d(t,e,(function(){return o[e]}))}(r);t.default=i.a},701:function(e,t,n){"use strict";(function(e){function n(e){return function(e){if(Array.isArray(e))return o(e)}(e)||function(e){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(e))return Array.from(e)}(e)||function(e,t){if(e){if("string"==typeof e)return o(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);return"Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n?Array.from(e):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?o(e,t):void 0}}(e)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function o(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,o=new Array(t);n<t;n++)o[n]=e[n];return o}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i={data:function(){return{suppliersTe:["","","您的资料正在进行审核，请耐心等待","审核已通过，请重新进入","审核不通过"],iconStyles:{position:"absolute",top:"-10rpx",right:"-10rpx"},qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""},otherLicensearr:[],businessLicensearr:[],chooseCityBox:!1,params:{province:!0,city:!0,area:!1},formDatas:{suppliersName:"",suppliersMobile:"",cooperateCity:"",companyAddr:"",businessLicense:"",otherLicense:"",suppliersStatus:1,productList:[{id:"",userId:"",cooperateCustomer:"",suppliedBrands:"",suppliedArea:"",productDemo:""}]}}},onLoad:function(t){e.getStorageSync("userInfo"),this.qiniuInfo=e.getStorageSync("qiniuInfo"),this.querySupplierInfo()},methods:{moveUp:function(t,o){var i;if(0==o)return e.showToast({title:"已经最上面啦~",icon:"none"}),!1;var r=JSON.parse(JSON.stringify(this.formDatas.productList[o-1]));(i=this.formDatas.productList).splice.apply(i,[o-1,1].concat(n(this.formDatas.productList.splice(o,1,r))))},moveDown:function(t,o){var i;if(o+1==this.formDatas.productList.length)return e.showToast({title:"已经最下面啦~",icon:"none"}),!1;var r=JSON.parse(JSON.stringify(this.formDatas.productList[o]));(i=this.formDatas.productList).splice.apply(i,[o,1].concat(n(this.formDatas.productList.splice(o+1,1,r))))},moveRm:function(t,n){var o=this;e.showModal({title:"确认删除该模块内容",confirmColor:"#ff4d4d",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&o.formDatas.productList.splice(n,1)}})},addCommodity:function(){this.formDatas.productList.push({cooperateCustomer:"",suppliedBrands:"",suppliedArea:"",productDemo:""})},openChose:function(){if(2==this.formDatas.suppliersStatus)return e.showToast({title:"资料审核中，请耐心等待",icon:"none"}),!1;this.chooseCityBox=!0},confirms:function(e){var t;console.log("省市==",e),t=e.province.label+"/"+e.city.label,this.formDatas.cooperateCity=t,console.log("省市that==",this.formDatas.cooperateCity)},delMiniImg:function(t,n){if(2==this.formDatas.suppliersStatus)return e.showToast({title:"资料正在审核中，请耐心等待",icon:"none"}),!1;console.log(t,n),1==t?this.businessLicensearr.splice(n,1):this.otherLicensearr.splice(n,1)},upBgimg:function(t,n){if(2==this.formDatas.suppliersStatus)return e.showToast({title:"资料正在审核中，请耐心等待",icon:"none"}),!1;var o=this;e.chooseImage({count:3-t.length,sizeType:["compressed"],sourceType:["camera","album"],success:function(t){e.showLoading({title:"上传中"}),t.tempFilePaths.map((function(t,i){for(var r=t,s="."+r.split(".")[1],a="",u=0;u<18;u++)a+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a=o.qiniuInfo.imgFolderPath+a+s,e.uploadFile({url:"https://up-z2.qiniup.com",filePath:r,name:"file",formData:{key:a,token:o.qiniuInfo.uploadToken},success:function(t){var i=o.qiniuInfo.urlPrefix+a;1==n?o.businessLicensearr.push(i):o.otherLicensearr.push(i),e.hideLoading()}})}))}})},submitForms:function(){var t=this.formDatas,n=0;if(console.log("表单提交==",this.formDatas),t.productList.forEach((function(t,o){t.cooperateCustomer?t.suppliedArea?t.suppliedBrands?t.productDemo||(e.showToast({title:"请输入第"+(o+1)+"个供货历史产品举例",icon:"none"}),n++):(e.showToast({title:"请输入第"+(o+1)+"个供货历史供货品牌",icon:"none"}),n++):(e.showToast({title:"请输入第"+(o+1)+"个供货历史供货地域",icon:"none"}),n++):(e.showToast({title:"请输入第"+(o+1)+"个供货历史合作客户",icon:"none"}),n++)})),n)return!1;if(2==this.formDatas.suppliersStatus)return e.showToast({title:"资料正在审核中，请耐心等待",icon:"none"}),!1;if(!t.suppliersName)return e.showToast({title:"请输入供应商名称",icon:"none"}),!1;if(!t.suppliersMobile)return e.showToast({title:"请输入您的联系电话",icon:"none"}),!1;if(!t.cooperateCity)return e.showToast({title:"请选择合作城市",icon:"none"}),!1;if(!t.companyAddr)return e.showToast({title:"请输入公司地址",icon:"none"}),!1;if(!this.businessLicensearr.length)return e.showToast({title:"请上传营业执照图片",icon:"none"}),!1;if(!this.otherLicensearr.length)return e.showToast({title:"请上传其他证照图片",icon:"none"}),!1;var o=JSON.parse(JSON.stringify(this.formDatas));o.businessLicense=this.businessLicensearr.join(","),o.otherLicense=this.otherLicensearr.join(","),o.suppliersStatus=2,null==o.auditMsg&&(o.auditMsg=""),this.$server.modifySupplierInfo(o).then((function(t){0==t.code?(e.showToast({title:"提交成功",icon:"success"}),setTimeout((function(t){e.navigateBack()}),1500)):e.showToast({title:"提交失败，请稍后重试",icon:"none"})}))},querySupplierInfo:function(){var t=this;this.$server.querySupplierInfo().then((function(n){if(0==n.code){if(n.data)if(t.formDatas=n.data,t.businessLicensearr=n.data.businessLicense.split(","),t.otherLicensearr=n.data.otherLicense.split(","),2==n.data.suppliersStatus)e.showToast({title:"资料审核中，请耐心等待",icon:"none"});else if(4==n.data.suppliersStatus)e.showToast({title:"审核被拒，请修改后重新提交",icon:"none"});else if(3==n.data.suppliersStatus){var o=e.getStorageSync("userInfo")||{};o.suppliersStatus=3,e.showToast({title:"审核通过，请返回重新进入",icon:"none"}),e.setStorageSync("userInfo",o)}}else e.showToast({title:"查询失败，请稍后重试",icon:"none"})}))}}};t.default=i}).call(this,n(1).default)},702:function(e,t,n){"use strict";n.r(t);var o=n(703),i=n.n(o);for(var r in o)"default"!==r&&function(e){n.d(t,e,(function(){return o[e]}))}(r);t.default=i.a},703:function(e,t,n){}},[[696,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/openSupplier.js'});require("pages/pageRelay/openSupplier.js");