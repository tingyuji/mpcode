$gwx0_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_15 || [];
function gz$gwx0_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join data-v-2e87096e'])
Z([3,'min-height:100vh;background-color:#f4f4f4;padding-bottom:200rpx;'])
Z([3,'sai_xuan fl_sb data-v-2e87096e'])
Z([3,'__e'])
Z([3,'left_tg fl data-v-2e87096e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'border-right:2rpx solid #07c160;'])
Z([3,'__l'])
Z([3,'data-v-2e87096e'])
Z([3,'#ccc'])
Z([3,'arrow-down'])
Z([3,'28'])
Z([3,'2ed36edd-1'])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[7])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[11])
Z([3,'2ed36edd-2'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l1']])
Z(z[22])
Z([3,'righ_bmin data-v-2e87096e'])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'item']],[3,'l0']])
Z(z[27])
Z([3,'tc_main data-v-2e87096e'])
Z([3,'fl num_jis data-v-2e87096e'])
Z(z[7])
Z(z[3])
Z(z[8])
Z([3,'#07c160'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'setCarNum']],[[4],[[5],[[5],[[5],[[7],[3,'index']]],[[7],[3,'k']]],[[2,'-'],[1,1]]]]]]]]]]]])
Z([3,'minus-circle'])
Z([3,'46'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'2ed36edd-3-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'k']]])
Z(z[7])
Z(z[3])
Z(z[8])
Z(z[36])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setCarNum']],[[4],[[5],[[5],[[5],[[5],[[7],[3,'index']]],[[7],[3,'k']]],[1,1]],[1,'$0']]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]]]],[[4],[[5],[[5],[[5],[[5],[1,'commodityDetais']],[1,'']],[[7],[3,'k']]],[1,'commodityCountSh']]]]]]]]]]]]]]])
Z([3,'plus-circle-fill'])
Z(z[39])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'2ed36edd-4-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'k']]])
Z([[6],[[6],[[7],[3,'j']],[3,'$orig']],[3,'verifyCount']])
Z([[6],[[6],[[7],[3,'j']],[3,'$orig']],[3,'refundMoney']])
Z([[6],[[6],[[7],[3,'j']],[3,'$orig']],[3,'refundCount']])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'address']])
Z([3,'btn_foot fl_sb data-v-2e87096e'])
Z([[7],[3,'allPickNum']])
Z(z[3])
Z([3,'right_hex data-v-2e87096e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hexiaoOpen']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[54])
Z(z[7])
Z(z[3])
Z([3,'14'])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRemark']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showRemark']])
Z([3,'2ed36edd-5'])
Z([[4],[[5],[1,'default']]])
Z([3,'text_ar data-v-2e87096e'])
Z(z[7])
Z(z[3])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'logisticsName']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'公司'])
Z([3,'80'])
Z([3,'请输入快递公司'])
Z([[7],[3,'logisticsName']])
Z([[2,'+'],[[2,'+'],[1,'2ed36edd-6'],[1,',']],[1,'2ed36edd-5']])
Z(z[7])
Z(z[3])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'logisticsId']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'单号'])
Z(z[74])
Z([3,'请输入快递单号'])
Z([[7],[3,'logisticsId']])
Z([[2,'+'],[[2,'+'],[1,'2ed36edd-7'],[1,',']],[1,'2ed36edd-5']])
Z(z[7])
Z(z[3])
Z([3,'40'])
Z(z[8])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openSaixuan']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'openSaixuan']])
Z([3,'2ed36edd-8'])
Z(z[67])
Z(z[22])
Z(z[23])
Z([[7],[3,'listSai']])
Z(z[22])
Z(z[3])
Z([3,'list_saixu fl_sb data-v-2e87096e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'checkActName']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'listSai']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'=='],[[7],[3,'listSaiId']],[[6],[[7],[3,'item']],[3,'activityId']]])
Z(z[7])
Z(z[8])
Z(z[36])
Z([3,'checkbox-mark'])
Z(z[11])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'2ed36edd-9-'],[[7],[3,'index']]],[1,',']],[1,'2ed36edd-8']])
Z(z[7])
Z(z[3])
Z(z[89])
Z(z[8])
Z(z[91])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openSaixuanTi']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[93])
Z([[7],[3,'openSaixuanTi']])
Z([3,'2ed36edd-10'])
Z(z[67])
Z(z[7])
Z(z[3])
Z(z[89])
Z(z[8])
Z(z[91])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openHexiaoType']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[93])
Z([[7],[3,'openHexiaoType']])
Z([3,'2ed36edd-11'])
Z(z[67])
Z([3,'jiel_func data-v-2e87096e'])
Z(z[3])
Z(z[102])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e4']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'=='],[[7],[3,'listSaiHexiao']],[1,1]])
Z(z[7])
Z(z[8])
Z(z[36])
Z(z[108])
Z(z[11])
Z([[2,'+'],[[2,'+'],[1,'2ed36edd-12'],[1,',']],[1,'2ed36edd-11']])
Z(z[3])
Z(z[102])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e5']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'=='],[[7],[3,'listSaiHexiao']],[1,2]])
Z(z[7])
Z(z[8])
Z(z[36])
Z(z[108])
Z(z[11])
Z([[2,'+'],[[2,'+'],[1,'2ed36edd-13'],[1,',']],[1,'2ed36edd-11']])
Z(z[7])
Z(z[3])
Z(z[61])
Z(z[8])
Z(z[91])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showEmail']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[64])
Z([[7],[3,'showEmail']])
Z([3,'2ed36edd-14'])
Z(z[67])
Z([3,'10076'])
Z(z[7])
Z(z[3])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'emailAccount']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'邮箱'])
Z([3,'140'])
Z([3,'请输入邮箱地址'])
Z([[7],[3,'emailAccount']])
Z([[2,'+'],[[2,'+'],[1,'2ed36edd-15'],[1,',']],[1,'2ed36edd-14']])
Z(z[7])
Z(z[3])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showModel']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,false])
Z([3,'商品核销确认'])
Z([[7],[3,'showModel']])
Z([3,'2ed36edd-16'])
Z(z[67])
Z([[7],[3,'showShares']])
Z(z[7])
Z(z[3])
Z(z[3])
Z([3,'zuj_fix data-v-2e87096e'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'2ed36edd-17'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_15=true;
var x=['./pages/pageRelay/cancelRel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_15_1()
var oJG=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oLG=_n('view')
_rz(z,oLG,'class',2,e,s,gg)
var fMG=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var cNG=_mz(z,'u-icon',['bind:__l',7,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(fMG,cNG)
_(oLG,fMG)
var hOG=_mz(z,'view',['bindtap',13,'class',1,'data-event-opts',2],[],e,s,gg)
var oPG=_mz(z,'u-icon',['bind:__l',16,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(hOG,oPG)
_(oLG,hOG)
_(oJG,oLG)
var cQG=_v()
_(oJG,cQG)
var oRG=function(aTG,lSG,tUG,gg){
var bWG=_n('view')
_rz(z,bWG,'class',26,aTG,lSG,gg)
var xYG=_v()
_(bWG,xYG)
var oZG=function(c2G,f1G,h3G,gg){
var c5G=_n('view')
_rz(z,c5G,'class',31,c2G,f1G,gg)
var a8G=_n('view')
_rz(z,a8G,'class',32,c2G,f1G,gg)
var t9G=_mz(z,'u-icon',['bind:__l',33,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],c2G,f1G,gg)
_(a8G,t9G)
var e0G=_mz(z,'u-icon',['bind:__l',41,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],c2G,f1G,gg)
_(a8G,e0G)
_(c5G,a8G)
var o6G=_v()
_(c5G,o6G)
if(_oz(z,49,c2G,f1G,gg)){o6G.wxVkey=1
}
var l7G=_v()
_(c5G,l7G)
if(_oz(z,50,c2G,f1G,gg)){l7G.wxVkey=1
var bAH=_v()
_(l7G,bAH)
if(_oz(z,51,c2G,f1G,gg)){bAH.wxVkey=1
}
bAH.wxXCkey=1
}
o6G.wxXCkey=1
l7G.wxXCkey=1
_(h3G,c5G)
return h3G
}
xYG.wxXCkey=4
_2z(z,29,oZG,aTG,lSG,gg,xYG,'j','k','k')
var oXG=_v()
_(bWG,oXG)
if(_oz(z,52,aTG,lSG,gg)){oXG.wxVkey=1
}
oXG.wxXCkey=1
_(tUG,bWG)
return tUG
}
cQG.wxXCkey=4
_2z(z,24,oRG,e,s,gg,cQG,'item','index','index')
var oBH=_n('view')
_rz(z,oBH,'class',53,e,s,gg)
var xCH=_v()
_(oBH,xCH)
if(_oz(z,54,e,s,gg)){xCH.wxVkey=1
var oDH=_mz(z,'view',['bindtap',55,'class',1,'data-event-opts',2],[],e,s,gg)
var fEH=_v()
_(oDH,fEH)
if(_oz(z,58,e,s,gg)){fEH.wxVkey=1
}
fEH.wxXCkey=1
_(xCH,oDH)
}
else{xCH.wxVkey=2
}
xCH.wxXCkey=1
_(oJG,oBH)
var cFH=_mz(z,'u-popup',['bind:__l',59,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var hGH=_n('view')
_rz(z,hGH,'class',68,e,s,gg)
var oHH=_mz(z,'u-field',['bind:__l',69,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(hGH,oHH)
var cIH=_mz(z,'u-field',['bind:__l',78,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(hGH,cIH)
_(cFH,hGH)
_(oJG,cFH)
var oJH=_mz(z,'u-popup',['bind:__l',87,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
var lKH=_v()
_(oJH,lKH)
var aLH=function(eNH,tMH,bOH,gg){
var xQH=_mz(z,'view',['bindtap',101,'class',1,'data-event-opts',2],[],eNH,tMH,gg)
var oRH=_v()
_(xQH,oRH)
if(_oz(z,104,eNH,tMH,gg)){oRH.wxVkey=1
var fSH=_mz(z,'u-icon',['bind:__l',105,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],eNH,tMH,gg)
_(oRH,fSH)
}
else{oRH.wxVkey=2
}
oRH.wxXCkey=1
oRH.wxXCkey=3
_(bOH,xQH)
return bOH
}
lKH.wxXCkey=4
_2z(z,99,aLH,e,s,gg,lKH,'item','index','index')
_(oJG,oJH)
var cTH=_mz(z,'u-popup',['bind:__l',111,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(oJG,cTH)
var hUH=_mz(z,'u-popup',['bind:__l',121,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
var oVH=_n('view')
_rz(z,oVH,'class',131,e,s,gg)
var cWH=_mz(z,'view',['bindtap',132,'class',1,'data-event-opts',2],[],e,s,gg)
var oXH=_v()
_(cWH,oXH)
if(_oz(z,135,e,s,gg)){oXH.wxVkey=1
var lYH=_mz(z,'u-icon',['bind:__l',136,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oXH,lYH)
}
else{oXH.wxVkey=2
}
oXH.wxXCkey=1
oXH.wxXCkey=3
_(oVH,cWH)
var aZH=_mz(z,'view',['bindtap',142,'class',1,'data-event-opts',2],[],e,s,gg)
var t1H=_v()
_(aZH,t1H)
if(_oz(z,145,e,s,gg)){t1H.wxVkey=1
var e2H=_mz(z,'u-icon',['bind:__l',146,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(t1H,e2H)
}
else{t1H.wxVkey=2
}
t1H.wxXCkey=1
t1H.wxXCkey=3
_(oVH,aZH)
_(hUH,oVH)
_(oJG,hUH)
var b3H=_mz(z,'u-popup',['bind:__l',152,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9,'zIndex',10],[],e,s,gg)
var o4H=_mz(z,'u-field',['bind:__l',163,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(b3H,o4H)
_(oJG,b3H)
var x5H=_mz(z,'u-modal',['bind:__l',172,'bind:input',1,'class',2,'data-event-opts',3,'showConfirmButton',4,'title',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
_(oJG,x5H)
var xKG=_v()
_(oJG,xKG)
if(_oz(z,181,e,s,gg)){xKG.wxVkey=1
var o6H=_mz(z,'dc-hiro-painter',['bind:__l',182,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(xKG,o6H)
}
xKG.wxXCkey=1
xKG.wxXCkey=3
_(r,oJG)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/cancelRel.wxml'] = [$gwx0_XC_15, './pages/pageRelay/cancelRel.wxml'];else __wxAppCode__['pages/pageRelay/cancelRel.wxml'] = $gwx0_XC_15( './pages/pageRelay/cancelRel.wxml' );
	;__wxRoute = "pages/pageRelay/cancelRel";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/cancelRel.js";define("pages/pageRelay/cancelRel.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/cancelRel"],{478:function(t,i,e){"use strict";(function(t){e(5),o(e(4));var i=o(e(479));function o(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=e,t(i.default)}).call(this,e(1).createPage)},479:function(t,i,e){"use strict";e.r(i);var o=e(480),a=e(482);for(var n in a)"default"!==n&&function(t){e.d(i,t,(function(){return a[t]}))}(n);e(484),e(486);var s=e(17),r=Object(s.default)(a.default,o.render,o.staticRenderFns,!1,null,"2e87096e",null,!1,o.components,void 0);r.options.__file="pages/pageRelay/cancelRel.vue",i.default=r.exports},480:function(t,i,e){"use strict";e.r(i);var o=e(481);e.d(i,"render",(function(){return o.render})),e.d(i,"staticRenderFns",(function(){return o.staticRenderFns})),e.d(i,"recyclableRender",(function(){return o.recyclableRender})),e.d(i,"components",(function(){return o.components}))},481:function(t,i,e){"use strict";var o;e.r(i),e.d(i,"render",(function(){return a})),e.d(i,"staticRenderFns",(function(){return s})),e.d(i,"recyclableRender",(function(){return n})),e.d(i,"components",(function(){return o}));try{o={uIcon:function(){return e.e("uview-ui/components/u-icon/u-icon").then(e.bind(null,854))},uPopup:function(){return e.e("uview-ui/components/u-popup/u-popup").then(e.bind(null,939))},uField:function(){return e.e("uview-ui/components/u-field/u-field").then(e.bind(null,946))},uModal:function(){return e.e("uview-ui/components/u-modal/u-modal").then(e.bind(null,961))},dcHiroPainter:function(){return e.e("components/dc-hiro-painter/dc-hiro-painter").then(e.bind(null,875))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var a=function(){var t=this,i=(t.$createElement,t._self._c,t.__map(t.orderData,(function(i,e){return{$orig:t.__get_orig(i),l0:t.__map(i.commodityDetais,(function(i,e){return{$orig:t.__get_orig(i),g0:i.formatName.slice(0,5)}}))}})));t._isMounted||(t.e0=function(i){t.openSaixuan=!0},t.e1=function(i){t.openSaixuanTi=!0},t.e2=function(i){t.openHexiaoType=!0},t.e3=function(i){t.showRemark=!1},t.e4=function(i){t.listSaiHexiao=1},t.e5=function(i){t.listSaiHexiao=2},t.e6=function(i){t.showModel=!1}),t.$mp.data=Object.assign({},{$root:{l1:i}})},n=!1,s=[];a._withStripped=!0},482:function(t,i,e){"use strict";e.r(i);var o=e(483),a=e.n(o);for(var n in o)"default"!==n&&function(t){e.d(i,t,(function(){return o[t]}))}(n);i.default=a.a},483:function(t,i,e){"use strict";(function(t){Object.defineProperty(i,"__esModule",{value:!0}),i.default=void 0;var o=function(t){return t&&t.__esModule?t:{default:t}}(e(61)),a={data:function(){var t=o.default.getDefaulDate({format:!0});return{showEmail:!1,emailAccount:"",openHexiaoType:!1,listSaiHexiao:1,userInfos:{},shareObj:{},showShares:!1,shareImgMini:"",showModel:!1,cStyle:{fontSize:"26rpx"},page:1,showRemark:!1,remarkVa:"",verifyStatus:0,finished:!1,loading:!1,noData:!1,logisticsName:"",logisticsId:"",loadingText:"上拉可加载更多~",orderData:[],tagArray:["全部","未核销","部分核销","已核销"],tagArrayFix:["全部","未核销","部分核销","已核销"],remarkType:["","商家备注","用户备注"],editId:0,postArr:[],allPickNum:0,tagArraySai:["全部","我发布的","我帮卖的"],tagArraySaiTi:["全部","今日","昨日","本周"],openSaixuan:!1,openSaixuanTi:!1,listSai:[{activityId:0,activityName:"全部团购",createTime:""}],listSaiId:0,saixuanName:"全部团购",saixuanTime:"全部日期",startTiTe:"开始时间",endTiTe:"结束时间",date:t,dateTwo:t,isDiyTi:!1,orderStatusSai:0,orderStatusSaiTi:0}},onLoad:function(i){t.hideShareMenu({}),i.id&&(this.listSaiId=i.id,i.nm&&(this.saixuanName=i.nm));var e=t.getStorageSync("userInfo")||{};this.userInfos=e,this.getVerifyList(),this.actNameList(),this.orderVerifyData()},onReachBottom:function(){this.finished||(this.page++,this.getVerifyList())},computed:{startDate:function(){return o.default.getDefaulDate("start")},endDate:function(){return o.default.getDefaulDate("end")}},methods:{closeShare:function(t){console.log("关闭分享弹窗==",t),this.showShares=!1,this.shareObj={}},openShare:function(i,e){t.showLoading({title:"加载中",mask:!0}),this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.shareScene="z=0&u="+this.userInfos.userId,this.shareObj.ztShare=e,this.showShares=!0,setTimeout((function(i){t.hideLoading()}),2e3)},orderVerifyData:function(){var i=this,e={};if(this.isDiyTi)e.startDate=this.date,e.endDate=this.dateTwo;else if(this.orderStatusSaiTi>0){var a=o.default.getStarEndDate(this.orderStatusSaiTi);e.startDate=a.startDate,e.endDate=a.endDate}this.listSaiId&&(e.activityId=this.listSaiId),this.$server.orderVerifyData(e).then((function(e){if(0==e.code){var o=JSON.parse(JSON.stringify(i.tagArray));o[0]="全部(".concat(e.data.totalOrder,")"),o[1]="未核销(".concat(e.data.unVerifyCount,")"),o[2]="部分核销(".concat(e.data.partVerifyCount,")"),o[3]="已核销(".concat(e.data.allVerifyCount,")"),i.tagArray=o}else t.showToast({title:e.message,icon:"none"})}))},hexiaoQuerys:function(){1==this.listSaiHexiao?(this.openShare(!1,1),this.openHexiaoType=!1):this.showEmail=!0},giveExc:function(i){var e=this;t.showLoading({title:"导出中"});var o={};if(3==i){if(!this.emailAccount)return t.showToast({title:"请填写邮箱地址",icon:"none"}),!1;if(!/^\w+@[a-zA-Z0-9]{2,100}(?:\.[a-z]{2,4}){1,3}$/.test(this.emailAccount))return t.showToast({title:"请输入正确的邮箱地址",icon:"none"}),!1;o.emailAccount=this.emailAccount}this.$server.downloadVerifyCode(o).then((function(i){0==i.code?(t.hideLoading(),t.showToast({title:"已发送至邮箱",icon:"success"}),e.showEmail=!1,e.openHexiaoType=!1):(t.hideLoading(),t.showToast({title:i.message,icon:"none"}))}))},timeQuerys:function(){this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.isDiyTi?this.saixuanTime="　".concat(this.date,"\n~").concat(this.dateTwo):this.orderStatusSaiTi>0?(o.default.getStarEndDate(this.orderStatusSaiTi),this.saixuanTime=this.tagArraySaiTi[this.orderStatusSaiTi]):this.saixuanTime="全部日期",this.getVerifyList(),this.orderVerifyData(),this.openSaixuanTi=!1},bindDateChange:function(t){this.date=t.target.value,this.startTiTe=t.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"结束时间"==this.endTiTe&&(this.dateTwo=t.target.value,this.endTiTe=t.target.value),this.orderStatusSaiTi<4&&(this.orderStatusSaiTi=5)},bindDateChangeTwo:function(t){this.dateTwo=t.target.value,this.endTiTe=t.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"开始时间"==this.startTiTe&&(this.date=t.target.value,this.startTiTe=t.target.value),this.orderStatusSaiTi<4&&(this.orderStatusSaiTi=5)},actNameList:function(){var i=this,e={dataType:this.orderStatusSai,page:1,pageSize:50};this.$server.actNameList(e).then((function(e){0==e.code?i.listSai=i.listSai.concat(e.data):t.showToast({title:e.message,icon:"none"})}))},checkStausSai:function(t){this.orderStatusSai=t,this.listSai=[{activityId:0,activityName:"全部团购",createTime:""}],this.actNameList()},checkStausSaiTi:function(t){this.orderStatusSaiTi=t,this.isDiyTi&&(this.isDiyTi=!this.isDiyTi)},checkActName:function(t){if(this.listSaiId==t.activityId)return this.openSaixuan=!1,!1;this.listSaiId=t.activityId,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getVerifyList(),this.orderVerifyData(),this.openSaixuan=!1,t.activityName.length<7?this.saixuanName=t.activityName:this.saixuanName=t.activityName.slice(0,6)+"..."},scanCanale:function(){var i=this;t.scanCode({success:function(t){i.verifyCouponOrder(t.result),console.log("条码内容："+t.result)},fail:function(i){t.showToast({title:"请扫描用户订单核销码",icon:"none"})}})},verifyCouponOrder:function(i){var e=this,o=i.split(",");o.length<2&&t.showToast({title:"核销码有误，请重新核销",icon:"none"});var a={buyUserId:o[0],orderId:o[1]};this.$server.verifyOrderByCode(a).then((function(i){if(0==i.code)t.showToast({title:"核销成功",icon:"success"}),e.page=1,e.orderData=[],e.getVerifyList(),e.orderVerifyData();else if(i.message.length>8){var o=i.message.slice(0,9);t.showToast({title:o,icon:"none"})}else t.showToast({title:i.message,icon:"none"})}))},pickWl:function(i,e,o){if(0==o.commodityCountSh)return t.showToast({title:"此商品已全部核销",icon:"none"}),!1;this.orderData[e].commodityDetais[i].isPick=!this.orderData[e].commodityDetais[i].isPick;var a=0;this.orderData.forEach((function(t,i){t.commodityDetais.forEach((function(t,i){t.isPick&&(a+=t.commodityCountTo)}))})),this.allPickNum=a},setCarNum:function(i,e,o,a){if(this.orderData[i].commodityDetais[e].commodityCountTo+o<=0)return t.showToast({title:"核销数量不可小于1哦",icon:"none"}),!1;if(this.orderData[i].commodityDetais[e].commodityCountTo+o>a)return t.showToast({title:"核销数量已是最大值",icon:"none"}),!1;this.orderData[i].commodityDetais[e].commodityCountTo=this.orderData[i].commodityDetais[e].commodityCountTo+o;var n=0;this.orderData.forEach((function(t,i){t.commodityDetais.forEach((function(t,i){t.isPick&&(n+=t.commodityCountTo)}))})),this.allPickNum=n},goRefund:function(i){t.navigateTo({url:"./orderRefund?item="+encodeURIComponent(JSON.stringify(i))})},noRefund:function(i){var e=this;t.showModal({title:"是否确认拒绝退款",content:"",confirmText:"确认",success:function(o){o.confirm?e.$server.refuseRefund({orderId:i.orderId}).then((function(i){0==i.code?t.showToast({title:"已拒绝退款",icon:"success"}):t.showToast({title:i.message,icon:"none"})})):o.cancel&&console.log("用户点击取消")}})},hexiaoOpen:function(){var i=[];if(this.orderData.forEach((function(t,e){t.commodityDetais.forEach((function(e,o){if(e.isPick){if(0==e.commodityCountTo)return!1;var a={orderId:t.orderId,commodityId:e.commodityId,quantity:e.commodityCountTo};i.push(a)}}))})),!i.length)return t.showToast({title:"请先选择需核销商品",icon:"none"}),!1;this.showModel=!0},heXiao:function(){var i=this,e=[];this.orderData.forEach((function(t,i){t.commodityDetais.forEach((function(i,o){if(i.isPick){if(0==i.commodityCountTo)return!1;var a={orderId:t.orderId,commodityId:i.commodityId,quantity:i.commodityCountTo};e.push(a)}}))})),console.log("inits===",e),this.$server.verifyOrder(e).then((function(e){0==e.code?(t.showToast({title:"核销成功",icon:"success"}),i.showModel=!1,i.page=1,i.orderData=[],i.getVerifyList(),i.orderVerifyData()):(i.showModel=!1,t.showToast({title:e.message,icon:"none"}))}))},checkActCa:function(){if(this.listSaiId){var i=this;return t.showModal({title:"核销活动订单确认",content:"是否核销活动“"+i.saixuanName+"”下的所有订单",confirmText:"确认",success:function(e){e.confirm?i.$server.verifyOrderByActId({activityId:i.listSaiId}).then((function(e){0==e.code?(t.showToast({title:"核销成功",icon:"success"}),i.page=1,i.orderData=[],i.getVerifyList(),i.orderVerifyData()):t.showToast({title:e.message,icon:"none"})})):e.cancel&&console.log("用户点击取消")}}),!1}return t.showToast({title:"请选择需核销的活动后再操作",icon:"none",duration:2500}),this.openSaixuan=!0,!1},checkStaus:function(t){this.verifyStatus=t,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getVerifyList()},showRemarkFu:function(t,i){console.log("orderId==",t),this.showRemark=!0,this.editId=t,console.log("editId==",this.editId)},editRemark:function(){var i=this,e={orderId:this.orderData[this.editId].orderId,logisticsId:this.logisticsId,logisticsName:this.logisticsName};this.$server.modifyLogistics(e).then((function(e){0==e.code?(t.showToast({title:"发货成功",icon:"success"}),i.showRemark=!1):t.showToast({title:e.message,icon:"none"})}))},getVerifyList:function(){var i=this,e={page:this.page,pageSize:10};if(this.verifyStatus&&(e.verifyStatus=this.verifyStatus),this.isDiyTi)e.startDate=this.date,e.endDate=this.dateTwo;else if(this.orderStatusSaiTi>0){var a=o.default.getStarEndDate(this.orderStatusSaiTi);e.startDate=a.startDate,e.endDate=a.endDate}this.listSaiId&&(e.activityId=this.listSaiId),this.$server.verifyOrderList(e).then((function(e){if(0==e.code){if(1==i.page&&0==e.data.length)return i.orderData=[],i.noData=!0,i.loading=!1,i.finished=!0,void console.log("无数据");if(0==e.data.length)return i.loading=!1,void(i.finished=!0);e.data.map((function(t){return t.payPriceShow=o.default.centTurnSmacker(t.payPrice/100),t.createTimeShow=t.createTime.slice(0,16),t.isPick=!1,t.commodityDetais.forEach((function(t){t.isPick=!1,t.totalPriceShow=o.default.centTurnSmacker(t.totalPrice/100),t.commodityCountTo=t.commodityCount-t.verifyCount,t.refundCountSh=t.commodityCount-t.refundCount,t.commodityCountSh=t.commodityCount-t.verifyCount,t.refundMoneySh=o.default.centTurnSmacker((t.totalPrice-t.refundMoney)/100),t.refundMoneyInp=o.default.centTurnSmacker((t.totalPrice-t.refundMoney)/100),t.commodityName.length>16&&(t.commodityName=t.commodityName.slice(0,14)+"...")})),t.isPick=!1,t})),i.orderData=i.orderData.concat(e.data)}else t.showToast({title:e.message,icon:"none"})}))}}};i.default=a}).call(this,e(1).default)},484:function(t,i,e){"use strict";e.r(i);var o=e(485),a=e.n(o);for(var n in o)"default"!==n&&function(t){e.d(i,t,(function(){return o[t]}))}(n);i.default=a.a},485:function(t,i,e){},486:function(t,i,e){"use strict";e.r(i);var o=e(487),a=e.n(o);for(var n in o)"default"!==n&&function(t){e.d(i,t,(function(){return o[t]}))}(n);i.default=a.a},487:function(t,i,e){}},[[478,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/cancelRel.js'});require("pages/pageRelay/cancelRel.js");