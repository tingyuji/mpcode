$gwx0_XC_43=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_43 || [];
function gz$gwx0_XC_43_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'home_tz data-v-7d40c062'])
Z([3,'main_jb data-v-7d40c062'])
Z([3,'shequ_jl data-v-7d40c062'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityLi']])
Z(z[3])
Z([3,'__e'])
Z([3,'ele_shop data-v-7d40c062'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goCopy']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'activityLi']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'shop_infos data-v-7d40c062'])
Z([3,'name_tim fl_cs data-v-7d40c062'])
Z([3,'name_ss data-v-7d40c062'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'activityName']]],[1,'']]])
Z([3,'time_ss data-v-7d40c062'])
Z([a,[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'nickName']]],[1,' ']],[[6],[[7],[3,'item']],[3,'createTime']]],[1,'']]])
Z([3,'shop_price data-v-7d40c062'])
Z([3,'¥'])
Z([3,'data-v-7d40c062'])
Z([a,[[6],[[7],[3,'item']],[3,'maxSellPriceShow']]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'shop_img fl data-v-7d40c062'])
Z([3,'k'])
Z([3,'j'])
Z(z[20])
Z(z[22])
Z(z[18])
Z([3,'aspectFill'])
Z([[7],[3,'j']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,2]])
Z([3,'no_descs data-v-7d40c062'])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,1]])
Z(z[18])
Z(z[31])
Z(z[18])
Z([3,'btn_row fl data-v-7d40c062'])
Z([3,'ri_bttn data-v-7d40c062'])
Z([3,'复制该接龙'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_43=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_43=true;
var x=['./pages/pageRelay/relingListCopy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_43_1()
var tE2C=_n('view')
_rz(z,tE2C,'class',0,e,s,gg)
var eF2C=_n('view')
_rz(z,eF2C,'class',1,e,s,gg)
var bG2C=_n('view')
_rz(z,bG2C,'class',2,e,s,gg)
var oH2C=_v()
_(bG2C,oH2C)
var xI2C=function(fK2C,oJ2C,cL2C,gg){
var oN2C=_mz(z,'view',['bindtap',7,'class',1,'data-event-opts',2],[],fK2C,oJ2C,gg)
var cO2C=_n('view')
_rz(z,cO2C,'class',10,fK2C,oJ2C,gg)
var lQ2C=_n('view')
_rz(z,lQ2C,'class',11,fK2C,oJ2C,gg)
var aR2C=_n('view')
_rz(z,aR2C,'class',12,fK2C,oJ2C,gg)
var tS2C=_oz(z,13,fK2C,oJ2C,gg)
_(aR2C,tS2C)
_(lQ2C,aR2C)
var eT2C=_n('view')
_rz(z,eT2C,'class',14,fK2C,oJ2C,gg)
var bU2C=_oz(z,15,fK2C,oJ2C,gg)
_(eT2C,bU2C)
_(lQ2C,eT2C)
_(cO2C,lQ2C)
var oV2C=_n('view')
_rz(z,oV2C,'class',16,fK2C,oJ2C,gg)
var xW2C=_oz(z,17,fK2C,oJ2C,gg)
_(oV2C,xW2C)
var oX2C=_n('text')
_rz(z,oX2C,'class',18,fK2C,oJ2C,gg)
var fY2C=_oz(z,19,fK2C,oJ2C,gg)
_(oX2C,fY2C)
_(oV2C,oX2C)
_(cO2C,oV2C)
var oP2C=_v()
_(cO2C,oP2C)
if(_oz(z,20,fK2C,oJ2C,gg)){oP2C.wxVkey=1
var cZ2C=_n('view')
_rz(z,cZ2C,'class',21,fK2C,oJ2C,gg)
var o42C=_v()
_(cZ2C,o42C)
var l52C=function(t72C,a62C,e82C,gg){
var o02C=_mz(z,'image',['class',26,'mode',1,'src',2],[],t72C,a62C,gg)
_(e82C,o02C)
return e82C
}
o42C.wxXCkey=2
_2z(z,24,l52C,fK2C,oJ2C,gg,o42C,'j','k','k')
var h12C=_v()
_(cZ2C,h12C)
if(_oz(z,29,fK2C,oJ2C,gg)){h12C.wxVkey=1
var xA3C=_n('view')
_rz(z,xA3C,'class',30,fK2C,oJ2C,gg)
_(h12C,xA3C)
}
var o22C=_v()
_(cZ2C,o22C)
if(_oz(z,31,fK2C,oJ2C,gg)){o22C.wxVkey=1
var oB3C=_n('view')
_rz(z,oB3C,'class',32,fK2C,oJ2C,gg)
_(o22C,oB3C)
}
var c32C=_v()
_(cZ2C,c32C)
if(_oz(z,33,fK2C,oJ2C,gg)){c32C.wxVkey=1
var fC3C=_n('view')
_rz(z,fC3C,'class',34,fK2C,oJ2C,gg)
_(c32C,fC3C)
}
h12C.wxXCkey=1
o22C.wxXCkey=1
c32C.wxXCkey=1
_(oP2C,cZ2C)
}
var cD3C=_n('view')
_rz(z,cD3C,'class',35,fK2C,oJ2C,gg)
var hE3C=_n('view')
_rz(z,hE3C,'class',36,fK2C,oJ2C,gg)
var oF3C=_oz(z,37,fK2C,oJ2C,gg)
_(hE3C,oF3C)
_(cD3C,hE3C)
_(cO2C,cD3C)
oP2C.wxXCkey=1
_(oN2C,cO2C)
_(cL2C,oN2C)
return cL2C
}
oH2C.wxXCkey=2
_2z(z,5,xI2C,e,s,gg,oH2C,'item','index','index')
_(eF2C,bG2C)
_(tE2C,eF2C)
_(r,tE2C)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_43";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_43();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/relingListCopy.wxml'] = [$gwx0_XC_43, './pages/pageRelay/relingListCopy.wxml'];else __wxAppCode__['pages/pageRelay/relingListCopy.wxml'] = $gwx0_XC_43( './pages/pageRelay/relingListCopy.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/relingListCopy.wxss'] = setCssToHead([".",[1],"home_tz.",[1],"data-v-7d40c062{background-color:#fff}\n.",[1],"main_jb.",[1],"data-v-7d40c062{background-color:#fff;width:100%}\n.",[1],"top_in.",[1],"data-v-7d40c062{box-sizing:border-box;padding-left:",[0,35],"}\n.",[1],"top_in .",[1],"top_tit.",[1],"data-v-7d40c062{font-size:",[0,44],"}\n.",[1],"top_in .",[1],"top_tit .",[1],"app_name.",[1],"data-v-7d40c062{color:#333}\n.",[1],"top_in .",[1],"tong_j.",[1],"data-v-7d40c062{color:#999;font-size:",[0,22],";margin-top:",[0,16],"}\n.",[1],"top_in .",[1],"radiu_b.",[1],"data-v-7d40c062{margin-top:",[0,20],"}\n.",[1],"top_in .",[1],"radiu_b .",[1],"zuan_su.",[1],"data-v-7d40c062{background-color:#fff;border-radius:",[0,25],";font-size:",[0,28],";height:",[0,50],";line-height:",[0,50],";text-align:center;width:",[0,236],"}\n.",[1],"top_in .",[1],"radiu_b .",[1],"se_qun.",[1],"data-v-7d40c062{background-color:#c0e5bf;border-radius:",[0,18],";font-size:",[0,22],";height:",[0,36],";line-height:",[0,36],";margin-left:",[0,12],";text-align:center;width:",[0,207],"}\n.",[1],"top_in .",[1],"zuan_sus.",[1],"data-v-7d40c062{background-color:rgba(0,0,0,.12);border-radius:",[0,25],";box-sizing:border-box;color:#999;display:inline-block;font-size:",[0,24],";height:",[0,50],";line-height:",[0,50],";margin-top:",[0,10],";padding:0 ",[0,16],"}\n.",[1],"hea_info.",[1],"data-v-7d40c062{background-color:#fff;border-radius:",[0,15],";box-shadow:",[0,0]," ",[0,4]," ",[0,48]," ",[0,1]," rgba(39,39,39,.13);box-sizing:border-box;margin:",[0,64]," auto 0;padding:",[0,12]," ",[0,30]," ",[0,42]," ",[0,42],";position:relative;width:",[0,690],"}\n.",[1],"hea_info .",[1],"user_icon.",[1],"data-v-7d40c062{border:",[0,4]," solid #fff;border-radius:",[0,73],";display:block;height:",[0,146],";left:",[0,42],";overflow:hidden;position:absolute;top:",[0,-42],";width:",[0,146],"}\n.",[1],"hea_info .",[1],"user_lev.",[1],"data-v-7d40c062{border-radius:",[0,10],";display:block;height:",[0,42],";left:",[0,43],";position:absolute;top:",[0,76],";width:",[0,144],"}\n.",[1],"hea_info .",[1],"name_qm.",[1],"data-v-7d40c062{padding-left:",[0,170],"}\n.",[1],"hea_info .",[1],"name_qm .",[1],"left_nq .",[1],"left_name .",[1],"user_nz.",[1],"data-v-7d40c062,.",[1],"hea_info .",[1],"name_qm .",[1],"left_nq .",[1],"left_name wx-text.",[1],"data-v-7d40c062{color:#333;font-size:",[0,36],";font-weight:700}\n.",[1],"hea_info .",[1],"name_qm .",[1],"left_nq .",[1],"left_qm.",[1],"data-v-7d40c062{margin-top:",[0,12],"}\n.",[1],"hea_info .",[1],"name_qm .",[1],"left_nq .",[1],"left_qm wx-text.",[1],"data-v-7d40c062{color:#999;font-size:",[0,22],"}\n.",[1],"hea_info .",[1],"name_qm .",[1],"left_nq .",[1],"left_qm wx-image.",[1],"data-v-7d40c062{margin-left:",[0,4],";width:",[0,10],"}\n.",[1],"hea_info .",[1],"name_qm .",[1],"right_tab wx-image.",[1],"data-v-7d40c062{width:",[0,15],"}\n.",[1],"hea_info .",[1],"name_qm .",[1],"right_tab wx-text.",[1],"data-v-7d40c062{color:#999;font-size:",[0,22],";margin-left:",[0,10],"}\n.",[1],"hea_info .",[1],"can_apply.",[1],"data-v-7d40c062{color:#999;font-size:",[0,24],";height:",[0,86],";margin:",[0,48]," auto 0;width:100%}\n.",[1],"hea_info .",[1],"can_apply wx-text.",[1],"data-v-7d40c062{margin-top:",[0,16],"}\n.",[1],"hea_info .",[1],"faqi_jl.",[1],"data-v-7d40c062{background-image:linear-gradient(90deg,#58c146,#69d886);border-radius:",[0,18],";color:#fff;font-size:",[0,36],";height:",[0,100],";-webkit-justify-content:center;justify-content:center;margin:",[0,50]," auto 0;width:",[0,610],"}\n.",[1],"hea_info .",[1],"faqi_jl wx-text.",[1],"data-v-7d40c062{margin-left:",[0,12],"}\n.",[1],"hea_info .",[1],"faqi_jl wx-image.",[1],"data-v-7d40c062{width:",[0,38],"}\n.",[1],"help_buy.",[1],"data-v-7d40c062{background-color:#fefced;border-radius:",[0,10],";color:#eba945;font-size:",[0,24],";height:",[0,86],";margin:",[0,26]," auto 0;position:relative;width:",[0,690],"}\n.",[1],"help_buy wx-image.",[1],"data-v-7d40c062{height:",[0,24],";left:0;position:absolute;top:0;width:",[0,24],"}\n.",[1],"help_buy .",[1],"som_t.",[1],"data-v-7d40c062{left:",[0,34],"}\n.",[1],"help_buy .",[1],"js_btn.",[1],"data-v-7d40c062,.",[1],"help_buy .",[1],"som_t.",[1],"data-v-7d40c062{position:absolute;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%)}\n.",[1],"help_buy .",[1],"js_btn.",[1],"data-v-7d40c062{background-color:#eba945;border-radius:",[0,22],";color:#fff;font-size:",[0,24],";height:",[0,44],";line-height:",[0,44],";right:",[0,24],";text-align:center;width:",[0,104],"}\n.",[1],"shequ_jl.",[1],"data-v-7d40c062{background-color:#fff;margin:",[0,38]," auto 0;width:",[0,690],"}\n.",[1],"shequ_jl .",[1],"sjl_t.",[1],"data-v-7d40c062{color:#999;font-size:",[0,28],"}\n.",[1],"shequ_jl .",[1],"ele_shop.",[1],"data-v-7d40c062{margin-top:",[0,50],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_pol wx-image.",[1],"data-v-7d40c062{border-radius:",[0,35],";height:",[0,70],";width:",[0,70],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_pol .",[1],"name_tim.",[1],"data-v-7d40c062{margin-left:",[0,12],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_pol .",[1],"name_tim .",[1],"name_ss.",[1],"data-v-7d40c062{color:#333;font-size:",[0,26],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_pol .",[1],"name_tim .",[1],"time_ss.",[1],"data-v-7d40c062{color:#999;font-size:",[0,20],";margin-top:",[0,8],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos.",[1],"data-v-7d40c062{background-color:#fff;border-radius:",[0,12],";box-shadow:",[0,0]," ",[0,4]," ",[0,48]," ",[0,1]," rgba(39,39,39,.13);box-sizing:border-box;margin-top:",[0,42],";padding:",[0,16]," ",[0,22]," ",[0,32],";position:relative}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"name_tim.",[1],"data-v-7d40c062{margin-left:",[0,12],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"name_tim .",[1],"name_ss.",[1],"data-v-7d40c062{color:#333;font-size:",[0,32],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"name_tim .",[1],"time_ss.",[1],"data-v-7d40c062{color:#999;font-size:",[0,20],";margin-top:",[0,8],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"fix_sj.",[1],"data-v-7d40c062{left:",[0,22],";position:absolute;top:",[0,-24],";width:",[0,34],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_tit.",[1],"data-v-7d40c062{-webkit-box-orient:vertical;-webkit-line-clamp:2;color:#333;display:-webkit-box;font-size:",[0,30],";overflow:hidden;text-overflow:ellipsis}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_price.",[1],"data-v-7d40c062{color:#ed7f63;font-size:",[0,30],";font-weight:700}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_price wx-text.",[1],"data-v-7d40c062{font-size:",[0,38],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_img.",[1],"data-v-7d40c062{margin:",[0,20],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_img wx-image.",[1],"data-v-7d40c062{border-radius:",[0,10],";height:",[0,208],";width:",[0,208],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"shop_img wx-image.",[1],"data-v-7d40c062:nth-child(n+2){margin-left:",[0,8],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol.",[1],"data-v-7d40c062{color:#333;font-size:",[0,26],";margin-top:",[0,12],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol .",[1],"left_xl wx-view.",[1],"data-v-7d40c062{margin-left:",[0,8],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol .",[1],"left_xl .",[1],"po_icon wx-image.",[1],"data-v-7d40c062{border-radius:",[0,23],";height:",[0,46],";width:",[0,46],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol .",[1],"left_xl .",[1],"tiae_s.",[1],"data-v-7d40c062{color:#999;font-size:",[0,22],";margin-left:",[0,12],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol .",[1],"rig_num .",[1],"tao_can.",[1],"data-v-7d40c062{-webkit-box-orient:vertical;-webkit-line-clamp:1;color:#999;display:-webkit-box;overflow:hidden;text-overflow:ellipsis;width:",[0,320],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"list_pol .",[1],"rig_num .",[1],"nums.",[1],"data-v-7d40c062{margin-left:",[0,20],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row.",[1],"data-v-7d40c062{-webkit-justify-content:flex-end;justify-content:flex-end;margin-left:",[0,240],";margin-top:",[0,36],";text-align:right;width:",[0,400],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row .",[1],"ri_bttn.",[1],"data-v-7d40c062{background-color:#07c160;border:",[0,0]," solid #07c160;border-radius:",[0,28],";box-sizing:border-box;color:#fff;height:",[0,56],";line-height:",[0,56],";padding:0 ",[0,16],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row .",[1],"ri_bttn wx-text.",[1],"data-v-7d40c062{font-size:",[0,24],";margin-left:",[0,10],"}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row wx-button.",[1],"data-v-7d40c062::after,.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row wx-button[plain].",[1],"data-v-7d40c062{padding:0!important}\n.",[1],"shequ_jl .",[1],"ele_shop .",[1],"shop_infos .",[1],"btn_row wx-button.",[1],"data-v-7d40c062{background-color:#fefefe;border:",[0,2]," solid #ddd;border-radius:",[0,10],";box-sizing:border-box;color:#333;font-size:",[0,24],";height:",[0,58],";line-height:",[0,58],";margin-left:",[0,16],";padding:0 ",[0,16],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/relingListCopy.wxss:1:6553)",{path:"./pages/pageRelay/relingListCopy.wxss"});
}