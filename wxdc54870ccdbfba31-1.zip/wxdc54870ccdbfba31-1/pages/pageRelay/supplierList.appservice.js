$gwx0_XC_55=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_55 || [];
function gz$gwx0_XC_55_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'min-height:100vh;padding-bottom:60rpx;box-sizing:border-box;'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityOwnLi']])
Z(z[1])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrder']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z([3,'sc_tit shop_tit'])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]],[[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'item']],[3,'orderInfos']])
Z(z[12])
Z([[2,'!='],[[6],[[7],[3,'j']],[3,'formatName']],[1,'默认 ']])
Z([[7],[3,'specialListNoData']])
Z([3,'__l'])
Z([1,200])
Z([3,'history'])
Z([3,'供应商入驻中...'])
Z([3,'725dfe96-1'])
Z(z[18])
Z(z[5])
Z([3,'14'])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPop']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showPop']])
Z([3,'725dfe96-2'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_55=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_55=true;
var x=['./pages/pageRelay/supplierList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_55_1()
var tSW=_n('view')
_rz(z,tSW,'style',0,e,s,gg)
var bUW=_v()
_(tSW,bUW)
var oVW=function(oXW,xWW,fYW,gg){
var h1W=_mz(z,'view',['bindtap',5,'data-event-opts',1],[],oXW,xWW,gg)
var c3W=_n('view')
_rz(z,c3W,'class',7,oXW,xWW,gg)
var o4W=_v()
_(c3W,o4W)
if(_oz(z,8,oXW,xWW,gg)){o4W.wxVkey=1
}
var l5W=_v()
_(c3W,l5W)
if(_oz(z,9,oXW,xWW,gg)){l5W.wxVkey=1
}
else{l5W.wxVkey=2
var a6W=_v()
_(l5W,a6W)
if(_oz(z,10,oXW,xWW,gg)){a6W.wxVkey=1
}
a6W.wxXCkey=1
}
o4W.wxXCkey=1
l5W.wxXCkey=1
_(h1W,c3W)
var o2W=_v()
_(h1W,o2W)
if(_oz(z,11,oXW,xWW,gg)){o2W.wxVkey=1
}
var t7W=_v()
_(h1W,t7W)
var e8W=function(o0W,b9W,xAX,gg){
var fCX=_v()
_(xAX,fCX)
if(_oz(z,16,o0W,b9W,gg)){fCX.wxVkey=1
}
fCX.wxXCkey=1
return xAX
}
t7W.wxXCkey=2
_2z(z,14,e8W,oXW,xWW,gg,t7W,'j','k','k')
o2W.wxXCkey=1
_(fYW,h1W)
return fYW
}
bUW.wxXCkey=2
_2z(z,3,oVW,e,s,gg,bUW,'item','index','index')
var eTW=_v()
_(tSW,eTW)
if(_oz(z,17,e,s,gg)){eTW.wxVkey=1
var cDX=_mz(z,'u-empty',['bind:__l',18,'marginTop',1,'mode',2,'text',3,'vueId',4],[],e,s,gg)
_(eTW,cDX)
}
var hEX=_mz(z,'u-popup',['bind:__l',23,'bind:input',1,'borderRadius',2,'closeable',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
_(tSW,hEX)
eTW.wxXCkey=1
eTW.wxXCkey=3
_(r,tSW)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_55";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_55();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/supplierList.wxml'] = [$gwx0_XC_55, './pages/pageRelay/supplierList.wxml'];else __wxAppCode__['pages/pageRelay/supplierList.wxml'] = $gwx0_XC_55( './pages/pageRelay/supplierList.wxml' );
	;__wxRoute = "pages/pageRelay/supplierList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/supplierList.js";define("pages/pageRelay/supplierList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/supplierList"],{704:function(e,t,n){"use strict";(function(e){n(5),i(n(4));var t=i(n(705));function i(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},705:function(e,t,n){"use strict";n.r(t);var i=n(706),o=n(708);for(var a in o)"default"!==a&&function(e){n.d(t,e,(function(){return o[e]}))}(a);n(710);var s=n(17),r=Object(s.default)(o.default,i.render,i.staticRenderFns,!1,null,null,null,!1,i.components,void 0);r.options.__file="pages/pageRelay/supplierList.vue",t.default=r.exports},706:function(e,t,n){"use strict";n.r(t);var i=n(707);n.d(t,"render",(function(){return i.render})),n.d(t,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(t,"recyclableRender",(function(){return i.recyclableRender})),n.d(t,"components",(function(){return i.components}))},707:function(e,t,n){"use strict";var i;n.r(t),n.d(t,"render",(function(){return o})),n.d(t,"staticRenderFns",(function(){return s})),n.d(t,"recyclableRender",(function(){return a})),n.d(t,"components",(function(){return i}));try{i={uEmpty:function(){return n.e("uview-ui/components/u-empty/u-empty").then(n.bind(null,868))},uPopup:function(){return n.e("uview-ui/components/u-popup/u-popup").then(n.bind(null,939))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},a=!1,s=[];o._withStripped=!0},708:function(e,t,n){"use strict";n.r(t);var i=n(709),o=n.n(i);for(var a in i)"default"!==a&&function(e){n.d(t,e,(function(){return i[e]}))}(a);t.default=o.a},709:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),o={data:function(){return{specialListNoData:!1,firstCom:!1,showHomeBtn:!1,isMe:!1,showPop:!1,showMenu:!1,shareObj:{},showShares:!1,showSharesBox:!1,userInfoHome:{},shareImgMini:"",menuStyle:{},countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},loading:!0,activityLi:[],userInfos:{},nickName:"",activityOwnLi:[],page:1,finished:!1,userId:"",scanCode:!1,top:"",tabIndex:0,tabIndex1:0,helpSellUserId:"",enterTime:"Wed Jul 27 2022 15:24:31 GMT+0800 (中国标准时间)",ztUserId:""}},computed:{getIcon:function(){}},onShareAppMessage:function(t){e.getStorageSync("userInfo");var n={title:"快来接龙吧",path:"/pages/subPage/showRel",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(e){e.errMsg}};if("button"==t.from){t.target.dataset;var i=this;n.imageUrl=i.shareImgMini,n.title=i.shareObj.title,n.path="/pages/subPage/showRel?"+i.shareObj.shareScene}return n},onShow:function(){},onReachBottom:function(){this.finished||(this.page++,this.supplyList())},onLoad:function(e){this.supplyList()},methods:{routeTo:function(){var t=getCurrentPages();console.log("pages==",t),t.length>1?e.navigateBack():e.switchTab({url:"../example/home"})},goOrder:function(t){console.log("跳转"),e.navigateTo({url:"../subPage/showRel?id="+t})},gomyHome:function(t){console.log("跳转"),e.navigateTo({url:"../subPage/myHome?uid="+t})},goCode:function(t,n,i,o){o&&e.navigateTo({url:t+"?id="+n+"&type="+o}),i?e.navigateTo({url:t+"?id="+n+"&types="+i}):e.navigateTo({url:t+"?id="+n})},goCodeYj:function(t){this.$server.oneClickHelpSell({sourceActId:t}).then((function(t){0==t.code?(e.showToast({title:"帮卖成功",icon:"success",duration:2e3}),setTimeout((function(n){e.navigateTo({url:"../subPage/showRel?id="+t.data.activityId})}),1500)):e.showToast({title:t.message,icon:"none"})}))},switchTa:function(t){e.switchTab({url:t})},goPage:function(t){e.navigateTo({url:"./editHome"})},supplyList:function(){var t=this;this.$server.supplyList({page:this.page,pageSize:10,userId:this.userId}).then((function(n){if(0==n.code){if(1==t.page&&0==n.data.length)return t.specialListNoData=!0,t.finished=!0,void console.log("无数据");n.data.length<10&&(t.loading=!1,t.finished=!0,console.log("无更多数据"));var o=n.data.map((function(e){if(e.differTime=i.default.getDifferTime(e.createTime,!1),20==e.activityType)e.albumsDetails.length?e.albumsDetails.forEach((function(t){1==t.contentType?e.imgArrs=t.albumsDetail.split(","):2==t.contentType?e.imgArrs=t.albumsDetail:(e.imgArrs=t.albumsDetail.split(","),e.hasVideo=!0)})):(e.imgArrs=[],e.hasVideo=!1);else{if(e.activityDetails.length){var t="";e.activityDetails.forEach((function(n){1==n.contentType?e.showTexts=n.activityDetail:(2==n.contentType||5==n.contentType)&&(t=0!=t.length?t+","+n.activityDetail:n.activityDetail),e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=i.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="**"}))})),0!=t.length?(console.log("cur.imgArrs==",t),e.shareImgs=t.split(","),e.imgArrs=t.split(",",3),console.log("cur.imgArrs==",e.imgArrs)):e.imgArrs=!1}else e.imgArrs=!1,e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=i.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="**"}));e.minMaxPrice.maxSellPrice==e.minMaxPrice.minSellPrice?e.maxSellPriceShow=i.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100):e.maxSellPriceShow=i.default.centTurnSmacker(e.minMaxPrice.minSellPrice/100)+"~"+i.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100),e.minMaxPrice.maxSellCommission==e.minMaxPrice.minSellCommission?e.maxSellCommissionShow=i.default.centTurnSmacker(e.minMaxPrice.maxSellCommission/100):e.maxSellCommissionShow=i.default.centTurnSmacker(e.minMaxPrice.minSellCommission/100)+"~"+i.default.centTurnSmacker(e.minMaxPrice.maxSellCommission/100),2==e.freezeFlag?e.activityNameShow="&emsp;&emsp;&emsp;&emsp;&emsp;"+e.activityName:e.activityNameShow=e.activityName,e.activityStatusTex=["正在接龙","接龙待发布","正在跟团中","接龙已下架","接龙已暂停","接龙已结束","接龙已删除"][e.activityStatus]}return e}));t.activityOwnLi=t.activityOwnLi.concat(o),console.log("活动获取数据==",t.activityOwnLi)}else e.showToast({title:n.message,icon:"none"})}))},subscribeUser:function(t){var n=this;this.$server.subscribeUser({targetUserId:this.userId,subscribeType:t}).then((function(i){0==i.code?(n.userInfos.subscribe=!n.userInfos.subscribe,1==t?(e.showToast({title:"订阅成功",icon:"success"}),n.showPop&&(n.showPop=!1),n.userInfoHome.focusWechat||e.navigateTo({url:"./weAccount"})):e.showToast({title:"退订成功"})):e.showToast({title:i.message,icon:"none"})}))}}};t.default=o}).call(this,n(1).default)},710:function(e,t,n){"use strict";n.r(t);var i=n(711),o=n.n(i);for(var a in i)"default"!==a&&function(e){n.d(t,e,(function(){return i[e]}))}(a);t.default=o.a},711:function(e,t,n){}},[[704,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/supplierList.js'});require("pages/pageRelay/supplierList.js");