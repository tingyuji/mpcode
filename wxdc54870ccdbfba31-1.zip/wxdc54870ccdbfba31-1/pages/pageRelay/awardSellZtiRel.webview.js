$gwx0_XC_13=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_13 || [];
function gz$gwx0_XC_13_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_13_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_13_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_13_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-783eda3a'])
Z([3,'width:100%;min-height:100vh;background:#f5f5f5;'])
Z([3,'shi_ji fl data-v-783eda3a'])
Z([3,'text_w fl_c data-v-783eda3a'])
Z(z[0])
Z([3,'height:60rpx;'])
Z([a,[[6],[[7],[3,'addrData']],[3,'managers']]])
Z([3,'fl just-center data-v-783eda3a'])
Z([3,'自提点管理员'])
Z(z[3])
Z(z[0])
Z(z[5])
Z([a,[[6],[[7],[3,'addrData']],[3,'orderAmount']]])
Z(z[7])
Z([3,'订单总金额（元）'])
Z(z[3])
Z(z[0])
Z(z[5])
Z([a,[[6],[[7],[3,'addrData']],[3,'cmisionAmount']]])
Z(z[7])
Z([3,'奖励支出（元）'])
Z([3,'record-list data-v-783eda3a'])
Z([3,'margin-top:24rpx;'])
Z([3,'sai_xans fl_sb data-v-783eda3a'])
Z([3,'__e'])
Z([3,'let_bm fl data-v-783eda3a'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'searchChange']],[[4],[[5],[1,1]]]]]]]]]]])
Z(z[0])
Z([3,'订单金额'])
Z([[2,'||'],[[2,'=='],[[7],[3,'searchStatus']],[1,1]],[[2,'>'],[[7],[3,'searchStatus']],[1,3]]])
Z(z[0])
Z([3,'scaleToFill'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/defaultsort3.png'])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,2]])
Z(z[0])
Z(z[31])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/defaultsort1.png'])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,3]])
Z(z[0])
Z(z[31])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/defaultsort2.png'])
Z(z[24])
Z(z[25])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'searchChange']],[[4],[[5],[1,2]]]]]]]]]]])
Z(z[0])
Z([3,'订单数量'])
Z([[2,'||'],[[2,'=='],[[7],[3,'searchStatus']],[1,4]],[[2,'<'],[[7],[3,'searchStatus']],[1,4]]])
Z(z[0])
Z(z[31])
Z(z[32])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,5]])
Z(z[0])
Z(z[31])
Z(z[36])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,6]])
Z(z[0])
Z(z[31])
Z(z[40])
Z([3,'ziti_list data-v-783eda3a'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'addrDataList']])
Z(z[59])
Z([3,'list_ele data-v-783eda3a'])
Z([3,'zi_name fl_sb data-v-783eda3a'])
Z(z[0])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'addressName']]],[1,'']]])
Z(z[24])
Z([3,'goOutBtn data-v-783eda3a'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goZtOut']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'addrDataList']],[1,'']],[[7],[3,'index']]],[1,'addressId']]]]]]]]]]]]]]])
Z([3,'佣金明细'])
Z([3,'mi_ins fl data-v-783eda3a'])
Z([3,'当前自提点管理员：'])
Z([3,'image_te fl data-v-783eda3a'])
Z(z[0])
Z(z[31])
Z([[6],[[7],[3,'item']],[3,'headImg']])
Z(z[0])
Z([a,[[6],[[7],[3,'item']],[3,'nickName']]])
Z(z[2])
Z([3,'background-color:#f5f5f5;'])
Z(z[3])
Z([3,'font-size:28rpx;color:#232323;font-weight:normal;'])
Z(z[0])
Z([a,[[6],[[7],[3,'item']],[3,'orderCount']]])
Z(z[0])
Z([3,'text-align:center;'])
Z([3,'订单数'])
Z(z[3])
Z(z[82])
Z(z[0])
Z([a,[[2,'+'],[1,'¥ '],[[6],[[7],[3,'item']],[3,'orderAmount']]]])
Z(z[0])
Z(z[86])
Z([3,'订单总额'])
Z(z[3])
Z(z[82])
Z(z[0])
Z([a,[[2,'+'],[1,'¥ '],[[6],[[7],[3,'item']],[3,'commissionAmount']]]])
Z(z[0])
Z(z[86])
Z([3,'佣金'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_13_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_13_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_13=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_13=true;
var x=['./pages/pageRelay/awardSellZtiRel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_13_1()
var aL0=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var tM0=_n('view')
_rz(z,tM0,'class',2,e,s,gg)
var eN0=_n('view')
_rz(z,eN0,'class',3,e,s,gg)
var bO0=_mz(z,'view',['class',4,'style',1],[],e,s,gg)
var oP0=_oz(z,6,e,s,gg)
_(bO0,oP0)
_(eN0,bO0)
var xQ0=_n('view')
_rz(z,xQ0,'class',7,e,s,gg)
var oR0=_oz(z,8,e,s,gg)
_(xQ0,oR0)
_(eN0,xQ0)
_(tM0,eN0)
var fS0=_n('view')
_rz(z,fS0,'class',9,e,s,gg)
var cT0=_mz(z,'view',['class',10,'style',1],[],e,s,gg)
var hU0=_oz(z,12,e,s,gg)
_(cT0,hU0)
_(fS0,cT0)
var oV0=_n('view')
_rz(z,oV0,'class',13,e,s,gg)
var cW0=_oz(z,14,e,s,gg)
_(oV0,cW0)
_(fS0,oV0)
_(tM0,fS0)
var oX0=_n('view')
_rz(z,oX0,'class',15,e,s,gg)
var lY0=_mz(z,'view',['class',16,'style',1],[],e,s,gg)
var aZ0=_oz(z,18,e,s,gg)
_(lY0,aZ0)
_(oX0,lY0)
var t10=_n('view')
_rz(z,t10,'class',19,e,s,gg)
var e20=_oz(z,20,e,s,gg)
_(t10,e20)
_(oX0,t10)
_(tM0,oX0)
_(aL0,tM0)
var b30=_mz(z,'view',['class',21,'style',1],[],e,s,gg)
var o40=_n('view')
_rz(z,o40,'class',23,e,s,gg)
var x50=_mz(z,'view',['bindtap',24,'class',1,'data-event-opts',2],[],e,s,gg)
var f70=_n('text')
_rz(z,f70,'class',27,e,s,gg)
var c80=_oz(z,28,e,s,gg)
_(f70,c80)
_(x50,f70)
var o60=_v()
_(x50,o60)
if(_oz(z,29,e,s,gg)){o60.wxVkey=1
var h90=_mz(z,'image',['class',30,'mode',1,'src',2],[],e,s,gg)
_(o60,h90)
}
else{o60.wxVkey=2
var o00=_v()
_(o60,o00)
if(_oz(z,33,e,s,gg)){o00.wxVkey=1
var cAAB=_mz(z,'image',['class',34,'mode',1,'src',2],[],e,s,gg)
_(o00,cAAB)
}
else{o00.wxVkey=2
var oBAB=_v()
_(o00,oBAB)
if(_oz(z,37,e,s,gg)){oBAB.wxVkey=1
var lCAB=_mz(z,'image',['class',38,'mode',1,'src',2],[],e,s,gg)
_(oBAB,lCAB)
}
oBAB.wxXCkey=1
}
o00.wxXCkey=1
}
o60.wxXCkey=1
_(o40,x50)
var aDAB=_mz(z,'view',['bindtap',41,'class',1,'data-event-opts',2],[],e,s,gg)
var eFAB=_n('text')
_rz(z,eFAB,'class',44,e,s,gg)
var bGAB=_oz(z,45,e,s,gg)
_(eFAB,bGAB)
_(aDAB,eFAB)
var tEAB=_v()
_(aDAB,tEAB)
if(_oz(z,46,e,s,gg)){tEAB.wxVkey=1
var oHAB=_mz(z,'image',['class',47,'mode',1,'src',2],[],e,s,gg)
_(tEAB,oHAB)
}
else{tEAB.wxVkey=2
var xIAB=_v()
_(tEAB,xIAB)
if(_oz(z,50,e,s,gg)){xIAB.wxVkey=1
var oJAB=_mz(z,'image',['class',51,'mode',1,'src',2],[],e,s,gg)
_(xIAB,oJAB)
}
else{xIAB.wxVkey=2
var fKAB=_v()
_(xIAB,fKAB)
if(_oz(z,54,e,s,gg)){fKAB.wxVkey=1
var cLAB=_mz(z,'image',['class',55,'mode',1,'src',2],[],e,s,gg)
_(fKAB,cLAB)
}
fKAB.wxXCkey=1
}
xIAB.wxXCkey=1
}
tEAB.wxXCkey=1
_(o40,aDAB)
_(b30,o40)
var hMAB=_n('view')
_rz(z,hMAB,'class',58,e,s,gg)
var oNAB=_v()
_(hMAB,oNAB)
var cOAB=function(lQAB,oPAB,aRAB,gg){
var eTAB=_n('view')
_rz(z,eTAB,'class',63,lQAB,oPAB,gg)
var bUAB=_n('view')
_rz(z,bUAB,'class',64,lQAB,oPAB,gg)
var oVAB=_n('view')
_rz(z,oVAB,'class',65,lQAB,oPAB,gg)
var xWAB=_oz(z,66,lQAB,oPAB,gg)
_(oVAB,xWAB)
_(bUAB,oVAB)
var oXAB=_mz(z,'view',['bindtap',67,'class',1,'data-event-opts',2],[],lQAB,oPAB,gg)
var fYAB=_oz(z,70,lQAB,oPAB,gg)
_(oXAB,fYAB)
_(bUAB,oXAB)
_(eTAB,bUAB)
var cZAB=_n('view')
_rz(z,cZAB,'class',71,lQAB,oPAB,gg)
var h1AB=_oz(z,72,lQAB,oPAB,gg)
_(cZAB,h1AB)
var o2AB=_n('view')
_rz(z,o2AB,'class',73,lQAB,oPAB,gg)
var c3AB=_mz(z,'image',['class',74,'mode',1,'src',2],[],lQAB,oPAB,gg)
_(o2AB,c3AB)
var o4AB=_n('text')
_rz(z,o4AB,'class',77,lQAB,oPAB,gg)
var l5AB=_oz(z,78,lQAB,oPAB,gg)
_(o4AB,l5AB)
_(o2AB,o4AB)
_(cZAB,o2AB)
_(eTAB,cZAB)
var a6AB=_mz(z,'view',['class',79,'style',1],[],lQAB,oPAB,gg)
var t7AB=_mz(z,'view',['class',81,'style',1],[],lQAB,oPAB,gg)
var e8AB=_n('view')
_rz(z,e8AB,'class',83,lQAB,oPAB,gg)
var b9AB=_oz(z,84,lQAB,oPAB,gg)
_(e8AB,b9AB)
_(t7AB,e8AB)
var o0AB=_mz(z,'view',['class',85,'style',1],[],lQAB,oPAB,gg)
var xABB=_oz(z,87,lQAB,oPAB,gg)
_(o0AB,xABB)
_(t7AB,o0AB)
_(a6AB,t7AB)
var oBBB=_mz(z,'view',['class',88,'style',1],[],lQAB,oPAB,gg)
var fCBB=_n('view')
_rz(z,fCBB,'class',90,lQAB,oPAB,gg)
var cDBB=_oz(z,91,lQAB,oPAB,gg)
_(fCBB,cDBB)
_(oBBB,fCBB)
var hEBB=_mz(z,'view',['class',92,'style',1],[],lQAB,oPAB,gg)
var oFBB=_oz(z,94,lQAB,oPAB,gg)
_(hEBB,oFBB)
_(oBBB,hEBB)
_(a6AB,oBBB)
var cGBB=_mz(z,'view',['class',95,'style',1],[],lQAB,oPAB,gg)
var oHBB=_n('view')
_rz(z,oHBB,'class',97,lQAB,oPAB,gg)
var lIBB=_oz(z,98,lQAB,oPAB,gg)
_(oHBB,lIBB)
_(cGBB,oHBB)
var aJBB=_mz(z,'view',['class',99,'style',1],[],lQAB,oPAB,gg)
var tKBB=_oz(z,101,lQAB,oPAB,gg)
_(aJBB,tKBB)
_(cGBB,aJBB)
_(a6AB,cGBB)
_(eTAB,a6AB)
_(aRAB,eTAB)
return aRAB
}
oNAB.wxXCkey=2
_2z(z,61,cOAB,e,s,gg,oNAB,'item','index','index')
_(b30,hMAB)
_(aL0,b30)
_(r,aL0)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_13";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_13();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSellZtiRel.wxml'] = [$gwx0_XC_13, './pages/pageRelay/awardSellZtiRel.wxml'];else __wxAppCode__['pages/pageRelay/awardSellZtiRel.wxml'] = $gwx0_XC_13( './pages/pageRelay/awardSellZtiRel.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/awardSellZtiRel.wxss'] = setCssToHead([".",[1],"no_sass.",[1],"data-v-783eda3a{background-color:#fff;border-bottom:1px solid #f5f5f5;box-sizing:border-box;color:#ff621a;font-size:",[0,28],";height:",[0,100],";padding:0 ",[0,30],"}\n.",[1],"record-list.",[1],"data-v-783eda3a{background-color:#fff;box-sizing:border-box;padding-bottom:",[0,30],"}\n.",[1],"record-li.",[1],"data-v-783eda3a{background:#fff;border-bottom:",[0,1]," solid #e5e5e5;height:",[0,130],";margin:0 auto;padding-left:",[0,20],";width:",[0,690],"}\n.",[1],"record-li .",[1],"title.",[1],"data-v-783eda3a{color:#333;font-size:",[0,30],"}\n.",[1],"record-li .",[1],"time.",[1],"data-v-783eda3a{color:#999;font-size:",[0,24],";padding-top:",[0,20],"}\n.",[1],"record-li .",[1],"record-left wx-image.",[1],"data-v-783eda3a{border-radius:",[0,12],";height:",[0,90],";width:",[0,90],"}\n.",[1],"record-li .",[1],"record-right.",[1],"data-v-783eda3a{color:#333;font-size:",[0,30],";margin-left:",[0,30],"}\n.",[1],"record-li .",[1],"record-right .",[1],"war_tag.",[1],"data-v-783eda3a{background-color:#ffdfd5;color:#ff5e2e}\n.",[1],"dfcbtnb.",[1],"data-v-783eda3a{border-radius:",[0,8],";box-sizing:border-box;color:#333;font-size:",[0,24],";padding:",[0,6]," ",[0,24],"}\n.",[1],"boo_fix.",[1],"data-v-783eda3a{background-color:#fff;bottom:0;box-sizing:border-box;font-size:",[0,32],";height:",[0,182],";left:0;padding:0 ",[0,30]," ",[0,60],";position:fixed;width:",[0,750],";z-index:99}\n.",[1],"boo_fix .",[1],"fbts_s.",[1],"data-v-783eda3a{border-radius:",[0,8],";color:#fff;font-weight:500;height:",[0,90],";line-height:",[0,90],";text-align:center;width:",[0,690],"}\n.",[1],"boo_fix .",[1],"left_bbt.",[1],"data-v-783eda3a{background-color:#fff;border:",[0,2]," solid #07c160;border-radius:",[0,8],";box-sizing:border-box;color:#07c160!important;font-weight:500;height:",[0,90],";-webkit-justify-content:center;justify-content:center;text-align:center;width:",[0,336],"}\n.",[1],"boo_fix .",[1],"right_fbt.",[1],"data-v-783eda3a{border-radius:",[0,8],";color:#fff;font-weight:500;height:",[0,90],";line-height:",[0,90],";text-align:center;width:",[0,336],"}\n.",[1],"zuj_fixfirst.",[1],"data-v-783eda3a{background-color:#fff;left:",[0,-9999],";overflow:hidden;position:fixed;top:",[0,-9999],"}\n.",[1],"record_fc.",[1],"data-v-783eda3a{-webkit-justify-content:flex-start;justify-content:flex-start;margin-left:",[0,30],"}\n.",[1],"record_fc .",[1],"record-right.",[1],"data-v-783eda3a{color:#333;font-size:",[0,30],";font-weight:500}\n.",[1],"record_fc .",[1],"record-right wx-text.",[1],"data-v-783eda3a{color:#333;font-size:",[0,32],";font-weight:500}\n.",[1],"record_fc .",[1],"record-right wx-image.",[1],"data-v-783eda3a{height:",[0,32],";margin-left:",[0,6],";margin-top:",[0,8],";width:",[0,32],"}\n.",[1],"record_fc .",[1],"record-rights.",[1],"data-v-783eda3a{font-weight:700}\n.",[1],"record_fc wx-text.",[1],"data-v-783eda3a{color:#999;font-size:",[0,24],";margin-top:",[0,12],"}\n.",[1],"shi_ji.",[1],"data-v-783eda3a{background-color:#fff;box-sizing:border-box;-webkit-flex-wrap:wrap;flex-wrap:wrap;padding:0 ",[0,0]," ",[0,30]," 0}\n.",[1],"shi_ji .",[1],"text_w.",[1],"data-v-783eda3a{color:#ff621a;font-size:",[0,38],";font-weight:700;margin-top:",[0,40],";text-align:center;width:33.3%}\n.",[1],"shi_ji .",[1],"text_w .",[1],"just-center.",[1],"data-v-783eda3a{color:#999;font-size:",[0,26],";font-weight:400}\n.",[1],"sai_xans.",[1],"data-v-783eda3a{border-bottom:1px solid #f7f7f7;border-top:1px solid #f7f7f7;box-sizing:border-box;padding:",[0,20]," ",[0,120],"}\n.",[1],"sai_xans .",[1],"let_bm wx-text.",[1],"data-v-783eda3a{color:#333;font-size:",[0,28],"}\n.",[1],"sai_xans .",[1],"let_bm wx-image.",[1],"data-v-783eda3a{height:",[0,38],";margin-left:",[0,2],";width:",[0,38],"}\n.",[1],"ziti_list.",[1],"data-v-783eda3a{box-sizing:border-box;padding:",[0,30],"}\n.",[1],"ziti_list .",[1],"list_ele.",[1],"data-v-783eda3a{background-color:#f5f5f5;margin-top:",[0,20],";width:100%}\n.",[1],"ziti_list .",[1],"list_ele .",[1],"zi_name.",[1],"data-v-783eda3a{border-bottom:1px solid #f0f0f0;font-size:",[0,32],";padding:",[0,20],"}\n.",[1],"ziti_list .",[1],"list_ele .",[1],"zi_name .",[1],"goOutBtn.",[1],"data-v-783eda3a{background-color:#07c160;border:",[0,0]," solid #07c160;border-radius:",[0,6],";box-sizing:border-box;color:#fff;font-size:",[0,22],";height:",[0,42],";line-height:",[0,42],";padding:0 ",[0,10],"}\n.",[1],"ziti_list .",[1],"list_ele .",[1],"mi_ins.",[1],"data-v-783eda3a{color:#777;font-size:",[0,24],";margin-top:",[0,20],";padding:0 ",[0,30],"}\n.",[1],"ziti_list .",[1],"list_ele .",[1],"mi_ins .",[1],"image_te wx-image.",[1],"data-v-783eda3a{border-radius:",[0,8],";height:",[0,40],";width:",[0,40],"}\n.",[1],"ziti_list .",[1],"list_ele .",[1],"mi_ins .",[1],"image_te wx-text.",[1],"data-v-783eda3a{color:#121212;margin-left:",[0,6],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/awardSellZtiRel.wxss:1:3613)",{path:"./pages/pageRelay/awardSellZtiRel.wxss"});
}