$gwx0_XC_58=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_58 || [];
function gz$gwx0_XC_58_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_58_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_58_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_58_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join data-v-5c6f8d8f'])
Z([3,'min-height:100vh;background-color:#f4f4f4;padding-bottom:200rpx;'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l1']])
Z(z[2])
Z([3,'righ_bmin data-v-5c6f8d8f'])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'item']],[3,'l0']])
Z(z[7])
Z([3,'tc_main data-v-5c6f8d8f'])
Z([3,'fl num_jis data-v-5c6f8d8f'])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-5c6f8d8f'])
Z([3,'#07c160'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'setCarNum']],[[4],[[5],[[5],[[5],[[7],[3,'index']]],[[7],[3,'k']]],[[2,'-'],[1,1]]]]]]]]]]]])
Z([3,'minus-circle'])
Z([3,'46'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'3182a557-1-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'k']]])
Z(z[13])
Z(z[14])
Z(z[15])
Z(z[16])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setCarNum']],[[4],[[5],[[5],[[5],[[5],[[7],[3,'index']]],[[7],[3,'k']]],[1,1]],[1,'$0']]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]]]],[[4],[[5],[[5],[[5],[[5],[1,'commodityDetais']],[1,'']],[[7],[3,'k']]],[1,'commodityCountSh']]]]]]]]]]]]]]])
Z([3,'plus-circle-fill'])
Z(z[19])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'3182a557-2-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'k']]])
Z([[6],[[6],[[7],[3,'j']],[3,'$orig']],[3,'verifyCount']])
Z([[6],[[6],[[7],[3,'j']],[3,'$orig']],[3,'refundMoney']])
Z(z[14])
Z([3,'act_name  data-v-5c6f8d8f'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goShow']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z(z[13])
Z(z[15])
Z([3,'#a8a8a8'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([[2,'+'],[1,'3182a557-3-'],[[7],[3,'index']]])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'addressName']])
Z([[7],[3,'noData']])
Z(z[13])
Z(z[15])
Z([3,'32'])
Z([1,400])
Z([3,'order'])
Z([3,'暂无订单，请咨询团长确认订单信息'])
Z([3,'3182a557-4'])
Z(z[13])
Z(z[14])
Z(z[15])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showModel']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,false])
Z([3,'商品核销确认'])
Z([[7],[3,'showModel']])
Z([3,'3182a557-5'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_58_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_58_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_58=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_58=true;
var x=['./pages/pageRelay/userCancal.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_58_1()
var f5X=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var h7X=_v()
_(f5X,h7X)
var o8X=function(o0X,c9X,lAY,gg){
var tCY=_n('view')
_rz(z,tCY,'class',6,o0X,c9X,gg)
var bEY=_v()
_(tCY,bEY)
var oFY=function(oHY,xGY,fIY,gg){
var hKY=_n('view')
_rz(z,hKY,'class',11,oHY,xGY,gg)
var oNY=_n('view')
_rz(z,oNY,'class',12,oHY,xGY,gg)
var lOY=_mz(z,'u-icon',['bind:__l',13,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],oHY,xGY,gg)
_(oNY,lOY)
var aPY=_mz(z,'u-icon',['bind:__l',21,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],oHY,xGY,gg)
_(oNY,aPY)
_(hKY,oNY)
var oLY=_v()
_(hKY,oLY)
if(_oz(z,29,oHY,xGY,gg)){oLY.wxVkey=1
}
var cMY=_v()
_(hKY,cMY)
if(_oz(z,30,oHY,xGY,gg)){cMY.wxVkey=1
}
oLY.wxXCkey=1
cMY.wxXCkey=1
_(fIY,hKY)
return fIY
}
bEY.wxXCkey=4
_2z(z,9,oFY,o0X,c9X,gg,bEY,'j','k','k')
var tQY=_mz(z,'view',['bindtap',31,'class',1,'data-event-opts',2],[],o0X,c9X,gg)
var eRY=_mz(z,'u-icon',['bind:__l',34,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],o0X,c9X,gg)
_(tQY,eRY)
_(tCY,tQY)
var eDY=_v()
_(tCY,eDY)
if(_oz(z,40,o0X,c9X,gg)){eDY.wxVkey=1
}
eDY.wxXCkey=1
_(lAY,tCY)
return lAY
}
h7X.wxXCkey=4
_2z(z,4,o8X,e,s,gg,h7X,'item','index','index')
var c6X=_v()
_(f5X,c6X)
if(_oz(z,41,e,s,gg)){c6X.wxVkey=1
var bSY=_mz(z,'u-empty',['bind:__l',42,'class',1,'fontSize',2,'marginTop',3,'mode',4,'text',5,'vueId',6],[],e,s,gg)
_(c6X,bSY)
}
var oTY=_mz(z,'u-modal',['bind:__l',49,'bind:input',1,'class',2,'data-event-opts',3,'showConfirmButton',4,'title',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
_(f5X,oTY)
c6X.wxXCkey=1
c6X.wxXCkey=3
_(r,f5X)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_58";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_58();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/userCancal.wxml'] = [$gwx0_XC_58, './pages/pageRelay/userCancal.wxml'];else __wxAppCode__['pages/pageRelay/userCancal.wxml'] = $gwx0_XC_58( './pages/pageRelay/userCancal.wxml' );
	;__wxRoute = "pages/pageRelay/userCancal";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/userCancal.js";define("pages/pageRelay/userCancal.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/userCancal"],{578:function(t,e,o){"use strict";(function(t){o(5),i(o(4));var e=i(o(579));function i(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=o,t(e.default)}).call(this,o(1).createPage)},579:function(t,e,o){"use strict";o.r(e);var i=o(580),n=o(582);for(var r in n)"default"!==r&&function(t){o.d(e,t,(function(){return n[t]}))}(r);o(584);var a=o(17),c=Object(a.default)(n.default,i.render,i.staticRenderFns,!1,null,"5c6f8d8f",null,!1,i.components,void 0);c.options.__file="pages/pageRelay/userCancal.vue",e.default=c.exports},580:function(t,e,o){"use strict";o.r(e);var i=o(581);o.d(e,"render",(function(){return i.render})),o.d(e,"staticRenderFns",(function(){return i.staticRenderFns})),o.d(e,"recyclableRender",(function(){return i.recyclableRender})),o.d(e,"components",(function(){return i.components}))},581:function(t,e,o){"use strict";var i;o.r(e),o.d(e,"render",(function(){return n})),o.d(e,"staticRenderFns",(function(){return a})),o.d(e,"recyclableRender",(function(){return r})),o.d(e,"components",(function(){return i}));try{i={uIcon:function(){return o.e("uview-ui/components/u-icon/u-icon").then(o.bind(null,854))},uEmpty:function(){return o.e("uview-ui/components/u-empty/u-empty").then(o.bind(null,868))},uModal:function(){return o.e("uview-ui/components/u-modal/u-modal").then(o.bind(null,961))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var n=function(){var t=this,e=(t.$createElement,t._self._c,t.__map(t.orderData,(function(e,o){return{$orig:t.__get_orig(e),l0:t.__map(e.commodityDetais,(function(e,o){return{$orig:t.__get_orig(e),g0:e.formatName.slice(0,5)}}))}})));t._isMounted||(t.e0=function(e){t.showModel=!1}),t.$mp.data=Object.assign({},{$root:{l1:e}})},r=!1,a=[];n._withStripped=!0},582:function(t,e,o){"use strict";o.r(e);var i=o(583),n=o.n(i);for(var r in i)"default"!==r&&function(t){o.d(e,t,(function(){return i[t]}))}(r);e.default=n.a},583:function(t,e,o){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=function(t){return t&&t.__esModule?t:{default:t}}(o(61)),n={data:function(){return{showModel:!1,cStyle:{fontSize:"26rpx"},page:1,showRemark:!1,remarkVa:"",verifyStatus:0,finished:!1,loading:!1,noData:!1,logisticsName:"",logisticsId:"",loadingText:"上拉可加载更多~",orderData:[],tagArray:["全部","未核销","部分核销","已核销"],tagArrayFix:["全部","未核销","部分核销","已核销"],editId:0,postArr:[],allPickNum:0,openSaixuan:!1,openSaixuanTi:!1,listSai:[{activityId:0,activityName:"全部团购",createTime:""}],listSaiId:0,isDiyTi:!1,orderStatusSai:0,orderStatusSaiTi:0,activityUserId:"",zitiId:""}},onLoad:function(e){var o=decodeURIComponent(e.scene);if(o){var i=o.split("&"),n=i[0].split("=");this.zitiId=n[1];var r=i[1].split("=");this.activityUserId=r[1]}t.hideShareMenu({});var a=this;wx.login({success:function(e){e.code&&a.$server.login({agentId:a.$agentId,code:e.code}).then((function(e){var o=e;t.setStorageSync("userInfo",o),a.getVerifyList()}))}})},onReachBottom:function(){this.finished||(this.page++,this.getVerifyList())},methods:{goShow:function(e){t.navigateTo({url:"../subPage/showRel?id="+e})},orderVerifyData:function(){var e=this;this.$server.orderVerifyData().then((function(o){0==o.code?(e.tagArray[0]="全部(".concat(o.data.totalOrder,")"),e.tagArray[1]="未核销(".concat(o.data.unVerifyCount,")"),e.tagArray[2]="部分核销(".concat(o.data.partVerifyCount,")"),e.tagArray[3]="已核销(".concat(o.data.allVerifyCount,")")):t.showToast({title:o.message,icon:"none"})}))},pickWl:function(e,o,i){if(0==i.commodityCountSh)return t.showToast({title:"此商品已全部核销",icon:"none"}),!1;this.orderData[o].commodityDetais[e].isPick=!this.orderData[o].commodityDetais[e].isPick;var n=0;this.orderData.forEach((function(t,e){t.commodityDetais.forEach((function(t,e){t.isPick&&(n+=t.commodityCountTo)}))})),this.allPickNum=n},setCarNum:function(e,o,i,n){if(this.orderData[e].commodityDetais[o].commodityCountTo+i<=0)return t.showToast({title:"核销数量不可小于1哦",icon:"none"}),!1;if(this.orderData[e].commodityDetais[o].commodityCountTo+i>n)return 0==n?t.showToast({title:"该商品已全部核销",icon:"none"}):t.showToast({title:"核销数量已是最大值",icon:"none"}),!1;this.orderData[e].commodityDetais[o].commodityCountTo=this.orderData[e].commodityDetais[o].commodityCountTo+i;var r=0;this.orderData.forEach((function(t,e){t.commodityDetais.forEach((function(t,e){t.isPick&&(r+=t.commodityCountTo)}))})),this.allPickNum=r},hexiaoOpen:function(){var e=[];if(this.orderData.forEach((function(t,o){t.commodityDetais.forEach((function(o,i){if(o.isPick){if(0==o.commodityCountTo)return!1;var n={orderId:t.orderId,commodityId:o.commodityId,quantity:o.commodityCountTo};e.push(n)}}))})),!e.length)return t.showToast({title:"请先选择需核销商品",icon:"none"}),!1;this.showModel=!0},heXiao:function(){var e=this,o=[];this.orderData.forEach((function(t,e){t.commodityDetais.forEach((function(e,i){if(e.isPick){if(0==e.commodityCountTo)return!1;var n={orderId:t.orderId,commodityId:e.commodityId,quantity:e.commodityCountTo};o.push(n)}}))})),console.log("inits===",o),this.$server.verifyOrder(o).then((function(o){0==o.code?(t.showToast({title:"核销成功",icon:"success"}),e.showModel=!1,e.page=1,e.orderData=[],e.getVerifyList()):(e.showModel=!1,t.showToast({title:o.message,icon:"none"}))}))},checkStaus:function(t){this.verifyStatus=t,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getVerifyList()},getVerifyList:function(){var e=this,o={page:this.page,pageSize:10,activityUserId:this.activityUserId};this.verifyStatus&&(o.verifyStatus=this.verifyStatus),"0"==this.zitiId&&0==this.zitiId||(o.logisticsRecordId=this.zitiId),this.$server.userVerifyOrderList(o).then((function(o){if(0==o.code){if(1==e.page&&0==o.data.length)return e.orderData=[],e.noData=!0,e.loading=!1,e.finished=!0,void console.log("无数据");if(0==o.data.length)return e.loading=!1,void(e.finished=!0);o.data.map((function(t){return t.payPriceShow=i.default.centTurnSmacker(t.payPrice/100),t.createTimeShow=t.createTime.slice(0,16),t.isPick=!1,t.commodityDetais.forEach((function(t){t.isPick=!1,t.totalPriceShow=i.default.centTurnSmacker(t.totalPrice/100),t.commodityCountTo=t.commodityCount-t.verifyCount,t.refundCountSh=t.commodityCount-t.refundCount,t.commodityCountSh=t.commodityCount-t.verifyCount,t.refundMoneySh=i.default.centTurnSmacker((t.totalPrice-t.refundMoney)/100),t.refundMoneyInp=i.default.centTurnSmacker((t.totalPrice-t.refundMoney)/100)})),t.isPick=!1,t})),e.orderData=e.orderData.concat(o.data)}else t.showToast({title:o.message,icon:"none"})}))}}};e.default=n}).call(this,o(1).default)},584:function(t,e,o){"use strict";o.r(e);var i=o(585),n=o.n(i);for(var r in i)"default"!==r&&function(t){o.d(e,t,(function(){return i[t]}))}(r);e.default=n.a},585:function(t,e,o){}},[[578,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/userCancal.js'});require("pages/pageRelay/userCancal.js");