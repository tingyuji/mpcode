$gwx0_XC_57=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_57 || [];
function gz$gwx0_XC_57_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_57_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_57_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_57_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_min data-v-f67a754c'])
Z([3,'min-height:100vh;background-color:#f5f5f5;padding-bottom:160rpx;'])
Z([3,'#07c160'])
Z([3,'__l'])
Z([3,'__e'])
Z(z[4])
Z([3,'data-v-f67a754c'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'checkedDyCha']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'checkedDy']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'#eee'])
Z([[7],[3,'checkedDy']])
Z([3,'139666ec-1'])
Z([3,'big_imgg data-v-f67a754c'])
Z([[7],[3,'sendAutoImg']])
Z(z[3])
Z(z[4])
Z(z[6])
Z([[7],[3,'iconStyles']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'delMiniImg']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'close-circle-fill'])
Z([3,'36'])
Z([3,'139666ec-2'])
Z([[2,'!'],[[7],[3,'sendAutoImg']]])
Z(z[4])
Z([3,'up_btnb fl_cb aa_bbc data-v-f67a754c'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'upBgimg']],[[4],[[5],[1,1]]]]]]]]]]])
Z(z[3])
Z(z[6])
Z([3,'#ccc'])
Z([3,'camera'])
Z([3,'50'])
Z([3,'139666ec-3'])
Z(z[11])
Z([[7],[3,'sendAutoImgCode']])
Z(z[3])
Z(z[4])
Z(z[6])
Z(z[16])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'delMiniImg']],[[4],[[5],[1,2]]]]]]]]]]])
Z(z[18])
Z(z[19])
Z([3,'139666ec-4'])
Z([[2,'!'],[[7],[3,'sendAutoImgCode']]])
Z(z[4])
Z(z[23])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'upBgimg']],[[4],[[5],[1,2]]]]]]]]]]])
Z(z[3])
Z(z[6])
Z(z[27])
Z(z[28])
Z(z[29])
Z([3,'139666ec-5'])
Z(z[3])
Z(z[4])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showModel']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,false])
Z(z[55])
Z([3,' '])
Z([[7],[3,'showModel']])
Z([3,'139666ec-6'])
Z([[4],[[5],[1,'default']]])
Z(z[3])
Z(z[4])
Z([3,'14'])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'swAddInput']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'swAddInput']])
Z([3,'139666ec-7'])
Z(z[60])
Z([1,true])
Z(z[3])
Z(z[4])
Z(z[6])
Z(z[55])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'popText']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'200'])
Z([3,'-1'])
Z([3,'请输入'])
Z([3,'textarea'])
Z([[7],[3,'popText']])
Z([[2,'+'],[[2,'+'],[1,'139666ec-8'],[1,',']],[1,'139666ec-7']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_57_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_57_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_57=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_57=true;
var x=['./pages/pageRelay/tuiChatDiy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_57_1()
var bMX=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oNX=_mz(z,'u-switch',['activeColor',2,'bind:__l',1,'bind:change',2,'bind:input',3,'class',4,'data-event-opts',5,'inactiveColor',6,'value',7,'vueId',8],[],e,s,gg)
_(bMX,oNX)
var xOX=_n('view')
_rz(z,xOX,'class',11,e,s,gg)
var oPX=_v()
_(xOX,oPX)
if(_oz(z,12,e,s,gg)){oPX.wxVkey=1
var cRX=_mz(z,'u-icon',['bind:__l',13,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(oPX,cRX)
}
var fQX=_v()
_(xOX,fQX)
if(_oz(z,21,e,s,gg)){fQX.wxVkey=1
var hSX=_mz(z,'view',['bindtap',22,'class',1,'data-event-opts',2],[],e,s,gg)
var oTX=_mz(z,'u-icon',['bind:__l',25,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(hSX,oTX)
_(fQX,hSX)
}
oPX.wxXCkey=1
oPX.wxXCkey=3
fQX.wxXCkey=1
fQX.wxXCkey=3
_(bMX,xOX)
var cUX=_n('view')
_rz(z,cUX,'class',31,e,s,gg)
var oVX=_v()
_(cUX,oVX)
if(_oz(z,32,e,s,gg)){oVX.wxVkey=1
var aXX=_mz(z,'u-icon',['bind:__l',33,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(oVX,aXX)
}
var lWX=_v()
_(cUX,lWX)
if(_oz(z,41,e,s,gg)){lWX.wxVkey=1
var tYX=_mz(z,'view',['bindtap',42,'class',1,'data-event-opts',2],[],e,s,gg)
var eZX=_mz(z,'u-icon',['bind:__l',45,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(tYX,eZX)
_(lWX,tYX)
}
oVX.wxXCkey=1
oVX.wxXCkey=3
lWX.wxXCkey=1
lWX.wxXCkey=3
_(bMX,cUX)
var b1X=_mz(z,'u-modal',['bind:__l',51,'bind:input',1,'class',2,'data-event-opts',3,'showConfirmButton',4,'showTitle',5,'title',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(bMX,b1X)
var o2X=_mz(z,'u-popup',['bind:__l',61,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var x3X=_mz(z,'u-input',['autoHeight',70,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'data-event-opts',5,'height',6,'maxlength',7,'placeholder',8,'type',9,'value',10,'vueId',11],[],e,s,gg)
_(o2X,x3X)
_(bMX,o2X)
_(r,bMX)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_57";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_57();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/tuiChatDiy.wxml'] = [$gwx0_XC_57, './pages/pageRelay/tuiChatDiy.wxml'];else __wxAppCode__['pages/pageRelay/tuiChatDiy.wxml'] = $gwx0_XC_57( './pages/pageRelay/tuiChatDiy.wxml' );
	;__wxRoute = "pages/pageRelay/tuiChatDiy";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/tuiChatDiy.js";define("pages/pageRelay/tuiChatDiy.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/tuiChatDiy"],{686:function(t,o,e){"use strict";(function(t){e(5),n(e(4));var o=n(e(687));function n(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=e,t(o.default)}).call(this,e(1).createPage)},687:function(t,o,e){"use strict";e.r(o);var n=e(688),i=e(690);for(var s in i)"default"!==s&&function(t){e.d(o,t,(function(){return i[t]}))}(s);e(692),e(694);var u=e(17),a=Object(u.default)(i.default,n.render,n.staticRenderFns,!1,null,"f67a754c",null,!1,n.components,void 0);a.options.__file="pages/pageRelay/tuiChatDiy.vue",o.default=a.exports},688:function(t,o,e){"use strict";e.r(o);var n=e(689);e.d(o,"render",(function(){return n.render})),e.d(o,"staticRenderFns",(function(){return n.staticRenderFns})),e.d(o,"recyclableRender",(function(){return n.recyclableRender})),e.d(o,"components",(function(){return n.components}))},689:function(t,o,e){"use strict";var n;e.r(o),e.d(o,"render",(function(){return i})),e.d(o,"staticRenderFns",(function(){return u})),e.d(o,"recyclableRender",(function(){return s})),e.d(o,"components",(function(){return n}));try{n={uSwitch:function(){return e.e("uview-ui/components/u-switch/u-switch").then(e.bind(null,1034))},uIcon:function(){return e.e("uview-ui/components/u-icon/u-icon").then(e.bind(null,854))},uModal:function(){return e.e("uview-ui/components/u-modal/u-modal").then(e.bind(null,961))},uPopup:function(){return e.e("uview-ui/components/u-popup/u-popup").then(e.bind(null,939))},uInput:function(){return Promise.all([e.e("common/vendor"),e.e("uview-ui/components/u-input/u-input")]).then(e.bind(null,910))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var t=this;t.$createElement,t._self._c,t._isMounted||(t.e0=function(o){t.showModel=!1},t.e1=function(o){t.swAddInput=!1})},s=!1,u=[];i._withStripped=!0},690:function(t,o,e){"use strict";e.r(o);var n=e(691),i=e.n(n);for(var s in n)"default"!==s&&function(t){e.d(o,t,(function(){return n[t]}))}(s);o.default=i.a},691:function(t,o,e){"use strict";(function(t){Object.defineProperty(o,"__esModule",{value:!0}),o.default=void 0;var e={data:function(){return{iconStyles:{position:"absolute",top:"-10rpx",right:"-10rpx"},sendAutoImg:"",checkedDy:!1,showDiaData:{index:0,showNames:"",data:{}},showModel:!1,noSorts:!0,addEdit:1,canApply:["水果","蔬菜","零食","海鲜","美妆","服装","居家","鲜花","肉蛋","日用品"],list:[],showInput:!1,swAddInput:!1,popText:"",id:"",idx:0,xiugai:{aIndex:0,bIndex:0},nextList:[],qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""},userInfoHome:{},sendAutoImgCode:""}},onShow:function(){},onLoad:function(o){t.hideShareMenu({}),this.qiniuInfo=t.getStorageSync("qiniuInfo"),this.userInfoHome=t.getStorageSync("userInfo"),2==this.userInfoHome.chatAutoSwitch&&(this.checkedDy=!0),this.userInfoHome.chatAutoImg&&(this.sendAutoImg=this.userInfoHome.chatAutoImg),this.userInfoHome.chatWxQrcode&&(this.sendAutoImgCode=this.userInfoHome.chatWxQrcode),this.chatScriptList()},methods:{delMiniImg:function(t){1==t?(this.sendAutoImg="",this.deleteChatConfig({deleteType:1})):(this.sendAutoImgCode="",this.deleteChatConfig({deleteType:2}))},upBgimg:function(o){var e=this;t.chooseImage({count:1,sizeType:["compressed"],sourceType:["album"],success:function(n){t.showLoading({title:"上传中"}),n.tempFilePaths.map((function(n,i){for(var s=n,u="."+s.split(".")[1],a="",c=0;c<18;c++)a+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a=e.qiniuInfo.imgFolderPath+a+u,t.uploadFile({url:"https://up-z2.qiniup.com",filePath:s,name:"file",formData:{key:a,token:e.qiniuInfo.uploadToken},success:function(n){var i=e.qiniuInfo.urlPrefix+a;if(1==o){e.sendAutoImg=i;var s={autoImg:e.sendAutoImg};e.modifyChatConfig(s)}else{e.sendAutoImgCode=i;var u={qrcodeUrl:e.sendAutoImgCode};e.modifyChatConfig(u)}t.hideLoading()}})}))}})},confirmtop:function(){this.noSorts?this.noSorts=!this.noSorts:this.updateCategorySort()},sortConfirm:function(t){console.log("this.list: ",this.list),console.log("e.list: ",t.list);var o=[];t.list.forEach((function(t){o.push(t.id)})),this.nextList=o.join(","),console.log("=== confirm start ==="),console.log("被拖动行: "+JSON.stringify(t.moveRow)),console.log("原始下标：",t.index),console.log("移动到：",t.moveTo),console.log("=== confirm end ===")},addTag:function(t){this.popText&&(this.popText=""),this.xiugai.aIndex=t,this.swAddInput=!0},addInName:function(t,o,e){o?(this.id=o.id,this.idx=e,this.popText=o.content):this.popText=this.userInfoHome.chatAutoMsg,this.addEdit=t,this.swAddInput=!0},delDiago:function(t,o){this.showDiaData.data=t,this.showDiaData.showNames=t.categoryName,this.showDiaData.index=o,this.showModel=!0},deleteChatConfig:function(o){var e=this;this.$server.deleteChatConfig(o).then((function(n){0==n.code?(t.showToast({title:"已移除",icon:"none"}),2==o.deleteType?e.userInfoHome.chatWxQrcode="":1==o.deleteType&&(e.userInfoHome.chatAutoImg=""),t.setStorageSync("userInfo",e.userInfoHome)):t.showToast({title:n.message,icon:"none"})}))},delSpece:function(o,e){var n=this;this.$server.deleteCategory({id:this.showDiaData.data.id}).then((function(o){if(0==o.code){t.showToast({title:"分类已删除",icon:"none"});var e=n.vuex_category_ziti;n.list.splice(n.showDiaData.index,1),e.arr=n.list,n.$u.vuex("vuex_category_ziti",e),n.showModel=!1}else t.showToast({title:o.message,icon:"none"})}))},chatScriptList:function(){var o=this;this.$server.chatScriptList().then((function(e){0==e.code?o.list=e.data:t.showToast({title:e.message,icon:"none"})}))},updateCategorySort:function(){var o=this;this.$server.updateCategorySort({ids:this.nextList}).then((function(e){0==e.code?(o.noSorts=!0,t.showToast({title:"顺序调整成功",icon:"none"}),o.chatScriptList()):t.showToast({title:e.message,icon:"none"})}))},addCate:function(t,o){this.popText=t,this.id="",this.gobacks(o)},checkedDyCha:function(){var t={autoSwitch:1==this.checkedDy?"2":"1"};this.modifyChatConfig(t)},modifyChatConfig:function(o){var e=this;console.log("自动回复设置==",o),this.$server.modifyChatConfig(o).then((function(n){0==n.code?(o.autoMsg?(e.userInfoHome.chatAutoMsg=o.autoMsg,t.showToast({title:"修改成功",icon:"none"})):o.autoSwitch?(e.userInfoHome.chatAutoSwitch=o.autoSwitch,t.showToast({title:2==o.autoSwitch?"已开启":"已关闭",icon:2==o.autoSwitch?"success":"none"})):o.qrcodeUrl?(e.userInfoHome.chatWxQrcode=o.qrcodeUrl,t.showToast({title:"上传成功",icon:"success"})):o.autoImg&&(e.userInfoHome.chatAutoImg=o.autoImg,t.showToast({title:"上传成功",icon:"success"})),e.swAddInput=!1,e.popText="",e.id="",console.log("设置后===",e.userInfoHome),t.setStorageSync("userInfo",e.userInfoHome)):t.showToast({title:n.message,icon:"none"})}))},gobacks:function(o){var e=this;if(!this.popText)return t.showToast({title:"请输入最少一个字符",icon:"none"}),!1;if(1==this.addEdit){var n={autoMsg:this.popText};this.modifyChatConfig(n)}else{var i={id:this.id,chatScriptMsg:this.popText};this.$server.modifyChatScript(i).then((function(o){0==o.code?(""===e.id?(t.showToast({title:"添加成功",icon:"none"}),e.chatScriptList()):(t.showToast({title:"修改成功",icon:"none"}),e.list[e.idx].content=e.popText),e.swAddInput=!1,e.popText="",e.id=""):t.showToast({title:o.message,icon:"none"})}))}}}};o.default=e}).call(this,e(1).default)},692:function(t,o,e){"use strict";e.r(o);var n=e(693),i=e.n(n);for(var s in n)"default"!==s&&function(t){e.d(o,t,(function(){return n[t]}))}(s);o.default=i.a},693:function(t,o,e){},694:function(t,o,e){"use strict";e.r(o);var n=e(695),i=e.n(n);for(var s in n)"default"!==s&&function(t){e.d(o,t,(function(){return n[t]}))}(s);o.default=i.a},695:function(t,o,e){}},[[686,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/tuiChatDiy.js'});require("pages/pageRelay/tuiChatDiy.js");