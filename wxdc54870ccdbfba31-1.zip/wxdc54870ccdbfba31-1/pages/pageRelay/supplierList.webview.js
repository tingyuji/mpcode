$gwx0_XC_55=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_55 || [];
function gz$gwx0_XC_55_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'min-height:100vh;padding-bottom:60rpx;box-sizing:border-box;'])
Z([3,'plr24'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityOwnLi']])
Z(z[2])
Z([3,'tg_con mt20'])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrder']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z([3,'flex align-center yh_con'])
Z(z[7])
Z([3,'touxiang'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'gomyHome']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'userId']]]]]]]]]]]]]]])
Z([3,'aspectFill'])
Z([[6],[[7],[3,'item']],[3,'headImg']])
Z([3,'yh_name'])
Z([a,[[6],[[7],[3,'item']],[3,'nickName']]])
Z([3,'flex align-center'])
Z([3,'yh_tit'])
Z([a,[[6],[[7],[3,'item']],[3,'differTime']]])
Z([3,'fgimg'])
Z(z[13])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/tg/tgicon011.png'])
Z(z[18])
Z([a,[[2,'+'],[[6],[[7],[3,'item']],[3,'accessCount']],[1,'人查看']]])
Z(z[20])
Z(z[13])
Z(z[22])
Z(z[18])
Z([a,[[2,'+'],[[6],[[7],[3,'item']],[3,'joinCount']],[1,'次跟团']]])
Z([3,'sc_con'])
Z([3,'sc_tit shop_tit'])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]])
Z([3,'tag_yrj'])
Z([3,'置顶'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]],[[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]]])
Z([3,'tag_yrjimg'])
Z([3,'scaleToFill'])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/shouhouwuymn.png'])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]])
Z(z[36])
Z(z[37])
Z(z[38])
Z([3,'left:0;'])
Z([[2,'?:'],[[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]],[1,'text-indent: 80rpx;'],[1,'']])
Z([3,'true'])
Z([3,'font-family:\x27Times New Roman\x27;'])
Z([a,[[6],[[7],[3,'item']],[3,'activityNameShow']]])
Z([3,'flex align-center sc_jg felx_end'])
Z([3,'￥'])
Z([a,[[2,'+'],[[6],[[7],[3,'item']],[3,'maxSellPriceShow']],[1,'']]])
Z([3,'sc_yj_btn'])
Z([a,[[2,'+'],[[2,'+'],[1,'佣金￥'],[[6],[[7],[3,'item']],[3,'maxSellCommissionShow']]],[1,'']]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'tp_con flex align-center'])
Z([3,'k'])
Z([3,'j'])
Z(z[53])
Z(z[55])
Z(z[13])
Z([[7],[3,'j']])
Z([3,'gm_list'])
Z(z[55])
Z(z[56])
Z([[6],[[7],[3,'item']],[3,'orderInfos']])
Z(z[55])
Z([3,'gm_list_li flex align-center just-between'])
Z(z[17])
Z([3,'gtjl_list_sy'])
Z([a,[[6],[[7],[3,'j']],[3,'activityNumb']]])
Z([3,'xiaotouxang'])
Z(z[13])
Z([[2,'?:'],[[6],[[7],[3,'j']],[3,'headImg']],[[6],[[7],[3,'j']],[3,'headImg']],[1,'http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png']])
Z([3,'gtjl_list_sj'])
Z([a,[[6],[[7],[3,'j']],[3,'differTime']]])
Z([3,'flex '])
Z([3,'gtjl_list_ftit'])
Z([a,[[6],[[7],[3,'j']],[3,'commodityName']]])
Z([[2,'!='],[[6],[[7],[3,'j']],[3,'formatName']],[1,'默认 ']])
Z([a,[[2,'+'],[1,'：'],[[6],[[7],[3,'j']],[3,'formatName']]]])
Z([3,'gtjl_list_num'])
Z([a,[[2,'+'],[1,'+'],[[6],[[7],[3,'j']],[3,'commodityCount']]]])
Z([3,'flex align-center just-between fx_con'])
Z([3,'fx_tit'])
Z([a,[[6],[[7],[3,'item']],[3,'activityStatusTex']]])
Z([3,'fl'])
Z(z[7])
Z([3,'edit_bttn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goCode']],[[4],[[5],[[5],[[5],[[5],[1,'../solitaire/issueRelayPlus']],[1,'$0']],[1,'$1']],[1,2]]]],[[4],[[5],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityStatus']]]]]]]]]]]]]]])
Z([3,'编辑后帮卖'])
Z(z[7])
Z([3,'edit_bttn dfcbg'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goCodeYj']],[[4],[[5],[[5],[1,'$0']],[1,'$1']]]],[[4],[[5],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityStatus']]]]]]]]]]]]]]])
Z([3,'color:#fff;'])
Z([3,'一键帮卖'])
Z([[7],[3,'specialListNoData']])
Z([3,'__l'])
Z([1,200])
Z([3,'history'])
Z([3,'供应商入驻中...'])
Z([3,'725dfe96-1'])
Z(z[96])
Z(z[7])
Z([3,'14'])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPop']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showPop']])
Z([3,'725dfe96-2'])
Z([[4],[[5],[1,'default']]])
Z([3,'pop_vie'])
Z([3,'voe_tit'])
Z([3,'恭喜成为帮卖团长'])
Z([3,'voe_info'])
Z([a,[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'您已成为'],[[6],[[7],[3,'userInfos']],[3,'nickName']]],[1,'的帮卖团长，订阅']],[[6],[[7],[3,'userInfos']],[3,'nickName']]],[1,',获取Ta的最新团购消息']]])
Z(z[7])
Z([3,'voe_share'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'subscribeUser']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'一键订阅'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_55_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_55=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_55=true;
var x=['./pages/pageRelay/supplierList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_55_1()
var cOFD=_n('view')
_rz(z,cOFD,'style',0,e,s,gg)
var lQFD=_n('view')
_rz(z,lQFD,'class',1,e,s,gg)
var aRFD=_v()
_(lQFD,aRFD)
var tSFD=function(bUFD,eTFD,oVFD,gg){
var oXFD=_n('view')
_rz(z,oXFD,'class',6,bUFD,eTFD,gg)
var fYFD=_mz(z,'view',['bindtap',7,'data-event-opts',1],[],bUFD,eTFD,gg)
var h1FD=_n('view')
_rz(z,h1FD,'class',9,bUFD,eTFD,gg)
var o2FD=_mz(z,'image',['catchtap',10,'class',1,'data-event-opts',2,'mode',3,'src',4],[],bUFD,eTFD,gg)
_(h1FD,o2FD)
var c3FD=_n('view')
var o4FD=_n('view')
_rz(z,o4FD,'class',15,bUFD,eTFD,gg)
var l5FD=_oz(z,16,bUFD,eTFD,gg)
_(o4FD,l5FD)
_(c3FD,o4FD)
var a6FD=_n('view')
_rz(z,a6FD,'class',17,bUFD,eTFD,gg)
var t7FD=_n('view')
_rz(z,t7FD,'class',18,bUFD,eTFD,gg)
var e8FD=_oz(z,19,bUFD,eTFD,gg)
_(t7FD,e8FD)
_(a6FD,t7FD)
var b9FD=_mz(z,'image',['class',20,'mode',1,'src',2],[],bUFD,eTFD,gg)
_(a6FD,b9FD)
var o0FD=_n('view')
_rz(z,o0FD,'class',23,bUFD,eTFD,gg)
var xAGD=_oz(z,24,bUFD,eTFD,gg)
_(o0FD,xAGD)
_(a6FD,o0FD)
var oBGD=_mz(z,'image',['class',25,'mode',1,'src',2],[],bUFD,eTFD,gg)
_(a6FD,oBGD)
var fCGD=_n('view')
_rz(z,fCGD,'class',28,bUFD,eTFD,gg)
var cDGD=_oz(z,29,bUFD,eTFD,gg)
_(fCGD,cDGD)
_(a6FD,fCGD)
_(c3FD,a6FD)
_(h1FD,c3FD)
_(fYFD,h1FD)
var hEGD=_n('view')
_rz(z,hEGD,'class',30,bUFD,eTFD,gg)
var oFGD=_n('view')
_rz(z,oFGD,'class',31,bUFD,eTFD,gg)
var cGGD=_v()
_(oFGD,cGGD)
if(_oz(z,32,bUFD,eTFD,gg)){cGGD.wxVkey=1
var lIGD=_n('view')
_rz(z,lIGD,'class',33,bUFD,eTFD,gg)
var aJGD=_oz(z,34,bUFD,eTFD,gg)
_(lIGD,aJGD)
_(cGGD,lIGD)
}
var oHGD=_v()
_(oFGD,oHGD)
if(_oz(z,35,bUFD,eTFD,gg)){oHGD.wxVkey=1
var tKGD=_mz(z,'image',['class',36,'mode',1,'src',2],[],bUFD,eTFD,gg)
_(oHGD,tKGD)
}
else{oHGD.wxVkey=2
var eLGD=_v()
_(oHGD,eLGD)
if(_oz(z,39,bUFD,eTFD,gg)){eLGD.wxVkey=1
var bMGD=_mz(z,'image',['class',40,'mode',1,'src',2,'style',3],[],bUFD,eTFD,gg)
_(eLGD,bMGD)
}
eLGD.wxXCkey=1
}
var oNGD=_n('view')
_rz(z,oNGD,'style',44,bUFD,eTFD,gg)
var xOGD=_mz(z,'text',['decode',45,'style',1],[],bUFD,eTFD,gg)
var oPGD=_oz(z,47,bUFD,eTFD,gg)
_(xOGD,oPGD)
_(oNGD,xOGD)
_(oFGD,oNGD)
cGGD.wxXCkey=1
oHGD.wxXCkey=1
_(hEGD,oFGD)
var fQGD=_n('view')
_rz(z,fQGD,'class',48,bUFD,eTFD,gg)
var cRGD=_n('text')
var hSGD=_oz(z,49,bUFD,eTFD,gg)
_(cRGD,hSGD)
_(fQGD,cRGD)
var oTGD=_oz(z,50,bUFD,eTFD,gg)
_(fQGD,oTGD)
var cUGD=_n('view')
_rz(z,cUGD,'class',51,bUFD,eTFD,gg)
var oVGD=_oz(z,52,bUFD,eTFD,gg)
_(cUGD,oVGD)
_(fQGD,cUGD)
_(hEGD,fQGD)
_(fYFD,hEGD)
var cZFD=_v()
_(fYFD,cZFD)
if(_oz(z,53,bUFD,eTFD,gg)){cZFD.wxVkey=1
var lWGD=_n('view')
_rz(z,lWGD,'class',54,bUFD,eTFD,gg)
var aXGD=_v()
_(lWGD,aXGD)
var tYGD=function(b1GD,eZGD,o2GD,gg){
var o4GD=_mz(z,'image',['mode',59,'src',1],[],b1GD,eZGD,gg)
_(o2GD,o4GD)
return o2GD
}
aXGD.wxXCkey=2
_2z(z,57,tYGD,bUFD,eTFD,gg,aXGD,'j','k','k')
_(cZFD,lWGD)
}
var f5GD=_n('view')
_rz(z,f5GD,'class',61,bUFD,eTFD,gg)
var c6GD=_v()
_(f5GD,c6GD)
var h7GD=function(c9GD,o8GD,o0GD,gg){
var aBHD=_n('view')
_rz(z,aBHD,'class',66,c9GD,o8GD,gg)
var tCHD=_n('view')
_rz(z,tCHD,'class',67,c9GD,o8GD,gg)
var eDHD=_n('view')
_rz(z,eDHD,'class',68,c9GD,o8GD,gg)
var bEHD=_oz(z,69,c9GD,o8GD,gg)
_(eDHD,bEHD)
_(tCHD,eDHD)
var oFHD=_mz(z,'image',['class',70,'mode',1,'src',2],[],c9GD,o8GD,gg)
_(tCHD,oFHD)
var xGHD=_n('view')
_rz(z,xGHD,'class',73,c9GD,o8GD,gg)
var oHHD=_oz(z,74,c9GD,o8GD,gg)
_(xGHD,oHHD)
_(tCHD,xGHD)
_(aBHD,tCHD)
var fIHD=_n('view')
_rz(z,fIHD,'class',75,c9GD,o8GD,gg)
var cJHD=_n('view')
_rz(z,cJHD,'class',76,c9GD,o8GD,gg)
var oLHD=_oz(z,77,c9GD,o8GD,gg)
_(cJHD,oLHD)
var hKHD=_v()
_(cJHD,hKHD)
if(_oz(z,78,c9GD,o8GD,gg)){hKHD.wxVkey=1
var cMHD=_n('text')
var oNHD=_oz(z,79,c9GD,o8GD,gg)
_(cMHD,oNHD)
_(hKHD,cMHD)
}
var lOHD=_n('text')
_rz(z,lOHD,'class',80,c9GD,o8GD,gg)
var aPHD=_oz(z,81,c9GD,o8GD,gg)
_(lOHD,aPHD)
_(cJHD,lOHD)
hKHD.wxXCkey=1
_(fIHD,cJHD)
_(aBHD,fIHD)
_(o0GD,aBHD)
return o0GD
}
c6GD.wxXCkey=2
_2z(z,64,h7GD,bUFD,eTFD,gg,c6GD,'j','k','k')
_(fYFD,f5GD)
var tQHD=_n('view')
_rz(z,tQHD,'class',82,bUFD,eTFD,gg)
var eRHD=_n('view')
_rz(z,eRHD,'class',83,bUFD,eTFD,gg)
var bSHD=_oz(z,84,bUFD,eTFD,gg)
_(eRHD,bSHD)
_(tQHD,eRHD)
var oTHD=_n('view')
_rz(z,oTHD,'class',85,bUFD,eTFD,gg)
var xUHD=_mz(z,'view',['catchtap',86,'class',1,'data-event-opts',2],[],bUFD,eTFD,gg)
var oVHD=_oz(z,89,bUFD,eTFD,gg)
_(xUHD,oVHD)
_(oTHD,xUHD)
var fWHD=_mz(z,'view',['catchtap',90,'class',1,'data-event-opts',2,'style',3],[],bUFD,eTFD,gg)
var cXHD=_oz(z,94,bUFD,eTFD,gg)
_(fWHD,cXHD)
_(oTHD,fWHD)
_(tQHD,oTHD)
_(fYFD,tQHD)
cZFD.wxXCkey=1
_(oXFD,fYFD)
_(oVFD,oXFD)
return oVFD
}
aRFD.wxXCkey=2
_2z(z,4,tSFD,e,s,gg,aRFD,'item','index','index')
_(cOFD,lQFD)
var oPFD=_v()
_(cOFD,oPFD)
if(_oz(z,95,e,s,gg)){oPFD.wxVkey=1
var hYHD=_mz(z,'u-empty',['bind:__l',96,'marginTop',1,'mode',2,'text',3,'vueId',4],[],e,s,gg)
_(oPFD,hYHD)
}
var oZHD=_mz(z,'u-popup',['bind:__l',101,'bind:input',1,'borderRadius',2,'closeable',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var c1HD=_n('view')
_rz(z,c1HD,'class',110,e,s,gg)
var o2HD=_n('view')
_rz(z,o2HD,'class',111,e,s,gg)
var l3HD=_oz(z,112,e,s,gg)
_(o2HD,l3HD)
_(c1HD,o2HD)
var a4HD=_n('view')
_rz(z,a4HD,'class',113,e,s,gg)
var t5HD=_oz(z,114,e,s,gg)
_(a4HD,t5HD)
_(c1HD,a4HD)
var e6HD=_mz(z,'view',['bindtap',115,'class',1,'data-event-opts',2],[],e,s,gg)
var b7HD=_oz(z,118,e,s,gg)
_(e6HD,b7HD)
_(c1HD,e6HD)
_(oZHD,c1HD)
_(cOFD,oZHD)
oPFD.wxXCkey=1
oPFD.wxXCkey=3
_(r,cOFD)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_55";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_55();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/supplierList.wxml'] = [$gwx0_XC_55, './pages/pageRelay/supplierList.wxml'];else __wxAppCode__['pages/pageRelay/supplierList.wxml'] = $gwx0_XC_55( './pages/pageRelay/supplierList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/supplierList.wxss'] = setCssToHead([".",[1],"edit_bttn{background-color:#fefefe;border:",[0,2]," solid #ddd;border-radius:",[0,10],";box-sizing:border-box;color:#333;font-size:",[0,24],";height:",[0,50],";line-height:",[0,50],";margin-right:",[0,20],";padding:0 ",[0,16],"}\n.",[1],"shop_tit{-webkit-box-orient:vertical;-webkit-line-clamp:2;color:#333;display:-webkit-box;font-size:",[0,30],";overflow:hidden;position:relative;text-overflow:ellipsis}\n.",[1],"pop_vie{background-color:#fff;box-sizing:border-box;padding:",[0,40]," ",[0,50],";width:",[0,600],"}\n.",[1],"pop_vie .",[1],"voe_tit{color:#333;font-size:",[0,32],";font-weight:700;text-align:center}\n.",[1],"pop_vie .",[1],"voe_info{color:#555;font-size:",[0,28],";line-height:",[0,40],";margin-top:",[0,18],";text-align:center}\n.",[1],"pop_vie .",[1],"voe_share{background-color:#07c160!important;border:none;border-radius:",[0,10],";color:#fff;font-size:",[0,32],";height:",[0,90],";letter-spacing:",[0,1],";line-height:",[0,90],";margin-top:",[0,50],";text-align:center;width:",[0,500],"}\nbody{background:#f0f0f5}\n.",[1],"wei_xc{padding:0 ",[0,20],"}\n.",[1],"wei_xc .",[1],"shop_img{margin:",[0,20]," 0}\n.",[1],"wei_xc .",[1],"shop_img wx-view{height:",[0,210],";width:",[0,210],"}\n.",[1],"wei_xc .",[1],"shop_img{box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"wei_xc .",[1],"shop_img wx-image{border-radius:",[0,10],";height:",[0,210],";margin-top:",[0,8],";width:",[0,210],"}\n.",[1],"wei_xc .",[1],"action_bar{margin-top:",[0,24],"}\n.",[1],"wei_xc .",[1],"action_bar wx-text{color:#576b95;font-size:",[0,24],";padding-right:",[0,24],"}\n.",[1],"wei_xc .",[1],"share_eit{background-color:#fff;border:",[0,1]," solid #49c167;border-radius:",[0,8],";color:#49c167;font-size:",[0,32],";height:",[0,70],";letter-spacing:",[0,2],";line-height:",[0,70],";margin-top:",[0,20],";text-align:center}\n.",[1],"video_s{border-radius:",[0,10],";height:",[0,450],";width:",[0,300],"}\n.",[1],"dy_btn_bj{border:1px solid #49c265;border-radius:",[0,10],";box-sizing:border-box;color:#49c265;font-size:",[0,24],";height:",[0,46],";line-height:",[0,46],";text-align:center;width:",[0,128],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/supplierList.wxss:1:1336)",{path:"./pages/pageRelay/supplierList.wxss"});
}