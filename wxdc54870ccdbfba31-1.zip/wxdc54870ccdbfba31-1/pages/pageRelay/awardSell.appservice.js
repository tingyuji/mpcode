$gwx0_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_9 || [];
function gz$gwx0_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'posInfo']],[3,'commodityList']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_9=true;
var x=['./pages/pageRelay/awardSell.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_9_1()
var cVF=_v()
_(r,cVF)
if(_oz(z,0,e,s,gg)){cVF.wxVkey=1
}
cVF.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSell.wxml'] = [$gwx0_XC_9, './pages/pageRelay/awardSell.wxml'];else __wxAppCode__['pages/pageRelay/awardSell.wxml'] = $gwx0_XC_9( './pages/pageRelay/awardSell.wxml' );
	;__wxRoute = "pages/pageRelay/awardSell";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/awardSell.js";define("pages/pageRelay/awardSell.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/awardSell"],{352:function(e,n,o){"use strict";(function(e){o(5),t(o(4));var n=t(o(353));function t(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=o,e(n.default)}).call(this,o(1).createPage)},353:function(e,n,o){"use strict";o.r(n);var t=o(354),i=o(356);for(var s in i)"default"!==s&&function(e){o.d(n,e,(function(){return i[e]}))}(s);o(358),o(360);var r=o(17),l=Object(r.default)(i.default,t.render,t.staticRenderFns,!1,null,"951c9a4e",null,!1,t.components,void 0);l.options.__file="pages/pageRelay/awardSell.vue",n.default=l.exports},354:function(e,n,o){"use strict";o.r(n);var t=o(355);o.d(n,"render",(function(){return t.render})),o.d(n,"staticRenderFns",(function(){return t.staticRenderFns})),o.d(n,"recyclableRender",(function(){return t.recyclableRender})),o.d(n,"components",(function(){return t.components}))},355:function(e,n,o){"use strict";o.r(n),o.d(n,"render",(function(){return t})),o.d(n,"staticRenderFns",(function(){return s})),o.d(n,"recyclableRender",(function(){return i})),o.d(n,"components",(function(){}));var t=function(){this.$createElement,this._self._c},i=!1,s=[];t._withStripped=!0},356:function(e,n,o){"use strict";o.r(n);var t=o(357),i=o.n(t);for(var s in t)"default"!==s&&function(e){o.d(n,e,(function(){return t[e]}))}(s);n.default=i.a},357:function(e,n,o){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t=function(e){return e&&e.__esModule?e:{default:e}}(o(61)),i={data:function(){return{checkedDy:!0,speceImg:"http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",posInfo:{groupFlag:2,speceImg:"",groupPrice:"",groupPeople:"",groupPriceShow:"",rewardType:5,commodityIndex:0,commodityList:[]},defaultPrice:0,defaultPriceShow:5,commodityName:"苹果",commodityIndex:0}},onLoad:function(n){e.hideShareMenu({});var o=JSON.parse(decodeURIComponent(n.item));o.forEach((function(e){if(e.sellCommission||0==e.sellCommission?e.sellCommissionSh=e.sellCommission/100:(e.sellCommission=0,e.sellCommissionSh=0),e.commodityDetails.length>1&&e.commodityDetails[1].commodityDetail){var n=e.commodityDetails[1].commodityDetail.split(",");e.speceImg=n[0]}})),this.posInfo.commodityList=o,console.log("this.posInfo==",this.posInfo)},methods:{chageNums:function(){this.totalMou&&this.shuNiang?this.showNum=t.default.centTurnSmacker(this.totalMou):this.showNum="0.00"},goPage:function(n){e.navigateTo({url:"./topUp"})},gobacks:function(){var n=this,o=0;if(this.posInfo.commodityList.forEach((function(e){e.sellCommissionSh?(e.sellCommission=100*e.sellCommissionSh,2!=n.posInfo.helpSellFlag&&(n.posInfo.helpSellFlag=2),console.log("cur.sellCommissionSh",e.sellCommissionSh,e.defaultPriceShow),100*e.sellCommissionSh>=100*e.defaultPriceShow&&o++):(e.sellCommission=0,e.sellCommissionSh=0)})),o>0)return e.showToast({title:"佣金不可高于商品最低价格",icon:"none"}),!1;this.checkedDy?this.posInfo.subHelpSellFlag=2:this.posInfo.subHelpSellFlag=1;var t=getCurrentPages();t[t.length-2].$vm.sellFun(this.posInfo),e.navigateBack()},getBalance:function(){var n=this;this.$server.balance().then((function(o){0==o.code?(n.balanceNumres=o.data.balance,n.balanceNum=t.default.centTurnSmacker(o.data.balance/100)):e.showToast({title:o.message,icon:"none"})}))}}};n.default=i}).call(this,o(1).default)},358:function(e,n,o){"use strict";o.r(n);var t=o(359),i=o.n(t);for(var s in t)"default"!==s&&function(e){o.d(n,e,(function(){return t[e]}))}(s);n.default=i.a},359:function(e,n,o){},360:function(e,n,o){"use strict";o.r(n);var t=o(361),i=o.n(t);for(var s in t)"default"!==s&&function(e){o.d(n,e,(function(){return t[e]}))}(s);n.default=i.a},361:function(e,n,o){}},[[352,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/awardSell.js'});require("pages/pageRelay/awardSell.js");