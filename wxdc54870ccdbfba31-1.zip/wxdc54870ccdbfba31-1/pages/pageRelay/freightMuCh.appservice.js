$gwx0_XC_23=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_23 || [];
function gz$gwx0_XC_23_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_23_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_23_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_23_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'areaData']],[3,'length']])
Z([3,'index'])
Z([3,'pros'])
Z([[7],[3,'areaData']])
Z(z[1])
Z([3,'iprovs'])
Z([3,'provi'])
Z([[6],[[7],[3,'pros']],[3,'children']])
Z(z[5])
Z([3,'__l'])
Z([3,'data-v-5fe64ecc'])
Z([3,'#c0c4cc'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'318ebbac-1-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'iprovs']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_23_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_23_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_23=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_23=true;
var x=['./pages/pageRelay/freightMuCh.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_23_1()
var x9K=_v()
_(r,x9K)
if(_oz(z,0,e,s,gg)){x9K.wxVkey=1
var o0K=_v()
_(x9K,o0K)
var fAL=function(hCL,cBL,oDL,gg){
var oFL=_v()
_(oDL,oFL)
var lGL=function(tIL,aHL,eJL,gg){
var oLL=_mz(z,'u-icon',['bind:__l',9,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],tIL,aHL,gg)
_(eJL,oLL)
return eJL
}
oFL.wxXCkey=4
_2z(z,7,lGL,hCL,cBL,gg,oFL,'provi','iprovs','iprovs')
return oDL
}
o0K.wxXCkey=4
_2z(z,3,fAL,e,s,gg,o0K,'pros','index','index')
}
x9K.wxXCkey=1
x9K.wxXCkey=3
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_23";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_23();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/freightMuCh.wxml'] = [$gwx0_XC_23, './pages/pageRelay/freightMuCh.wxml'];else __wxAppCode__['pages/pageRelay/freightMuCh.wxml'] = $gwx0_XC_23( './pages/pageRelay/freightMuCh.wxml' );
	;__wxRoute = "pages/pageRelay/freightMuCh";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/freightMuCh.js";define("pages/pageRelay/freightMuCh.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/freightMuCh"],{370:function(e,n,t){"use strict";(function(e){t(5),a(t(4));var n=a(t(371));function a(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},371:function(e,n,t){"use strict";t.r(n);var a=t(372),o=t(374);for(var r in o)"default"!==r&&function(e){t.d(n,e,(function(){return o[e]}))}(r);t(376);var c=t(17),u=Object(c.default)(o.default,a.render,a.staticRenderFns,!1,null,"5fe64ecc",null,!1,a.components,void 0);u.options.__file="pages/pageRelay/freightMuCh.vue",n.default=u.exports},372:function(e,n,t){"use strict";t.r(n);var a=t(373);t.d(n,"render",(function(){return a.render})),t.d(n,"staticRenderFns",(function(){return a.staticRenderFns})),t.d(n,"recyclableRender",(function(){return a.recyclableRender})),t.d(n,"components",(function(){return a.components}))},373:function(e,n,t){"use strict";var a;t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return c})),t.d(n,"recyclableRender",(function(){return r})),t.d(n,"components",(function(){return a}));try{a={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},r=!1,c=[];o._withStripped=!0},374:function(e,n,t){"use strict";t.r(n);var a=t(375),o=t.n(a);for(var r in a)"default"!==r&&function(e){t.d(n,e,(function(){return a[e]}))}(r);n.default=o.a},375:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,function(e){e&&e.__esModule}(t(61));var a={data:function(){return{areaData:[],nowComing:!0}},watch:{areaData:{handler:function(e,n){},immediate:!0,deep:!0}},onLoad:function(n){var t=this;e.hideShareMenu({}),console.log("option==",n);var a=e.getStorageSync("teAreaData").map((function(e){return e.checkStatu=0,console.log("bigArea.children",e.children),e.children.forEach((function(e){e.checkStatu=0,e.openChildNode=!1,e.hasNums=0,e.children.forEach((function(e){e.checkStatu=0,e.openChildNode=!1,e.hasNums=0,e.children.forEach((function(e){e.checkStatu=0}))}))})),e}));this.areaData=a,setTimeout((function(e){t.nowComing=!1}),1500)},methods:{areaDataRefresh:function(e,n){console.log("Im Refreshs",this.areaData);var t=this.$u.deepClone(this.areaData);t.forEach((function(e){e.children.forEach((function(e){e.children.forEach((function(e){e.children.forEach((function(e){}))}))}))})),this.areaData=t},changeArea:function(e,n,t){if(3==e.checkStatu)return!1;0==e.checkStatu?e.checkStatu=2:e.checkStatu>1&&(e.checkStatu=0),this.areaDataRefresh(t,e.checkStatu)},openNode:function(e,n,t){if(3==e.checkStatu)return!1;e.openChildNode=!e.openChildNode,this.areaDataRefresh(0,0)},templateAreaData:function(){this.$server.templateAreaData().then((function(n){0==n.code?(console.log("teAreaData",n.data),e.setStorageSync("teAreaData",n.data)):e.showToast({title:n.message,icon:"none"})}))}}};n.default=a}).call(this,t(1).default)},376:function(e,n,t){"use strict";t.r(n);var a=t(377),o=t.n(a);for(var r in a)"default"!==r&&function(e){t.d(n,e,(function(){return a[e]}))}(r);n.default=o.a},377:function(e,n,t){}},[[370,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/freightMuCh.js'});require("pages/pageRelay/freightMuCh.js");