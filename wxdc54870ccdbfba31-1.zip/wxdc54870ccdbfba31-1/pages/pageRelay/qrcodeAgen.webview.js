$gwx0_XC_37=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_37 || [];
function gz$gwx0_XC_37_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_37_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_37_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_37_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container data-v-7ee0e9e3'])
Z([3,'qrimg data-v-7ee0e9e3'])
Z([3,'__e'])
Z([3,'data-v-7ee0e9e3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'globalYulan']],[[4],[[5],[[5],[[4],[[5],[[7],[3,'shareImgMini']]]]],[1,0]]]]]]]]]]])
Z([[2,'!'],[[7],[3,'shareImgMini']]])
Z([3,'scaleToFill'])
Z([[7],[3,'shareImgMini']])
Z([3,'width:660rpx;height:1080rpx;'])
Z(z[3])
Z([[2,'!'],[[2,'!'],[[7],[3,'shareImgMini']]]])
Z(z[6])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/hb/bnthree.png'])
Z(z[8])
Z([3,'__l'])
Z(z[2])
Z([3,'14'])
Z(z[3])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'swAddInput']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'swAddInput']])
Z([3,'5d3cd383-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'580rpx'])
Z([3,'wecou_nt data-v-7ee0e9e3'])
Z([3,'tit_nt data-v-7ee0e9e3'])
Z([3,'font-size:32rpx;'])
Z([3,'业务员手机号'])
Z([3,'pop_box data-v-7ee0e9e3'])
Z(z[2])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'val']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'11'])
Z([3,'请输入业务员手机号码'])
Z([3,'number'])
Z([[7],[3,'val']])
Z(z[2])
Z([3,'btn_wco data-v-7ee0e9e3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'getIsSalesUser']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'height:80rpx;line-height:80rpx;'])
Z([3,'确认'])
Z([3,'button_box data-v-7ee0e9e3'])
Z([3,'loginDiv data-v-7ee0e9e3'])
Z(z[2])
Z([3,'loginBtn data-v-7ee0e9e3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'getIsSalesUser']],[[4],[[5],[1,2]]]]]]]]]]])
Z([3,'生成用户推荐码'])
Z([3,'loginDivr data-v-7ee0e9e3'])
Z(z[2])
Z(z[45])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'getIsSalesOne']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'生成业务员推荐码'])
Z(z[43])
Z(z[2])
Z(z[45])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'globalDownsAs']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'保存至相册'])
Z([[7],[3,'showShares']])
Z(z[14])
Z(z[2])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'position:absolute;left:-9999rpx;top:0;'])
Z([3,'5d3cd383-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_37_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_37_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_37=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_37=true;
var x=['./pages/pageRelay/qrcodeAgen.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_37_1()
var eRIC=_n('view')
_rz(z,eRIC,'class',0,e,s,gg)
var oTIC=_n('view')
_rz(z,oTIC,'class',1,e,s,gg)
var xUIC=_mz(z,'image',['bindtap',2,'class',1,'data-event-opts',2,'hidden',3,'mode',4,'src',5,'style',6],[],e,s,gg)
_(oTIC,xUIC)
var oVIC=_mz(z,'image',['class',9,'hidden',1,'mode',2,'src',3,'style',4],[],e,s,gg)
_(oTIC,oVIC)
_(eRIC,oTIC)
var fWIC=_mz(z,'u-popup',['bind:__l',14,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
var cXIC=_n('view')
_rz(z,cXIC,'class',25,e,s,gg)
var hYIC=_mz(z,'view',['class',26,'style',1],[],e,s,gg)
var oZIC=_oz(z,28,e,s,gg)
_(hYIC,oZIC)
_(cXIC,hYIC)
var c1IC=_n('view')
_rz(z,c1IC,'class',29,e,s,gg)
var o2IC=_mz(z,'input',['bindinput',30,'class',1,'data-event-opts',2,'maxlength',3,'placeholder',4,'type',5,'value',6],[],e,s,gg)
_(c1IC,o2IC)
_(cXIC,c1IC)
var l3IC=_mz(z,'view',['bindtap',37,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var a4IC=_oz(z,41,e,s,gg)
_(l3IC,a4IC)
_(cXIC,l3IC)
_(fWIC,cXIC)
_(eRIC,fWIC)
var t5IC=_n('view')
_rz(z,t5IC,'class',42,e,s,gg)
var e6IC=_n('view')
_rz(z,e6IC,'class',43,e,s,gg)
var b7IC=_mz(z,'view',['bindtap',44,'class',1,'data-event-opts',2],[],e,s,gg)
var o8IC=_oz(z,47,e,s,gg)
_(b7IC,o8IC)
_(e6IC,b7IC)
_(t5IC,e6IC)
var x9IC=_n('view')
_rz(z,x9IC,'class',48,e,s,gg)
var o0IC=_mz(z,'view',['bindtap',49,'class',1,'data-event-opts',2],[],e,s,gg)
var fAJC=_oz(z,52,e,s,gg)
_(o0IC,fAJC)
_(x9IC,o0IC)
_(t5IC,x9IC)
var cBJC=_n('view')
_rz(z,cBJC,'class',53,e,s,gg)
var hCJC=_mz(z,'view',['bindtap',54,'class',1,'data-event-opts',2],[],e,s,gg)
var oDJC=_oz(z,57,e,s,gg)
_(hCJC,oDJC)
_(cBJC,hCJC)
_(t5IC,cBJC)
_(eRIC,t5IC)
var bSIC=_v()
_(eRIC,bSIC)
if(_oz(z,58,e,s,gg)){bSIC.wxVkey=1
var cEJC=_mz(z,'dc-hiro-painter',['bind:__l',59,'bind:shareUrl',1,'class',2,'data-event-opts',3,'shareObj',4,'style',5,'vueId',6],[],e,s,gg)
_(bSIC,cEJC)
}
bSIC.wxXCkey=1
bSIC.wxXCkey=3
_(r,eRIC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_37";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_37();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/qrcodeAgen.wxml'] = [$gwx0_XC_37, './pages/pageRelay/qrcodeAgen.wxml'];else __wxAppCode__['pages/pageRelay/qrcodeAgen.wxml'] = $gwx0_XC_37( './pages/pageRelay/qrcodeAgen.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/qrcodeAgen.wxss'] = setCssToHead([".",[1],"container{box-sizing:border-box;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"container,.",[1],"qrimg{display:-webkit-flex;display:flex}\n.",[1],"qrimg{-webkit-justify-content:center;justify-content:center}\n.",[1],"qrimg-i{background:url(\x22http://qiniuimg.kfmanager.com/qunjl/showrel/hb/bnthree.png\x22) no-repeat;background-size:",[0,750]," ",[0,1330],";box-sizing:border-box;height:",[0,1089],";margin:0 auto;padding:",[0,738]," 0 0 ",[0,264],";width:",[0,750],"}\n.",[1],"input{background-color:#fff;border:1px solid #b0b0b0;border-radius:5px;height:40px;margin:",[0,50]," 0;padding:0 ",[0,20],";width:100%}\n.",[1],"btns{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\nwx-button{margin-top:",[0,10],";width:100%}\n.",[1],"pop_box.",[1],"data-v-7ee0e9e3{box-sizing:border-box;padding-top:",[0,40],"}\n.",[1],"pop_box wx-input.",[1],"data-v-7ee0e9e3{background-color:#f5f5f5;border:none;border-radius:",[0,10],";box-sizing:border-box;height:",[0,76],";padding-left:",[0,20],";padding-right:",[0,6],";text-align:left;width:100%}\n.",[1],"loginDiv.",[1],"data-v-7ee0e9e3{margin-top:",[0,20],";padding:0 ",[0,50],"}\n.",[1],"loginDiv .",[1],"loginBtn.",[1],"data-v-7ee0e9e3{background-color:#07c160;border:0;border-radius:",[0,40],";color:#fff;height:",[0,80],";line-height:",[0,80],";margin-top:",[0,30],";text-align:center}\n.",[1],"loginDivr.",[1],"data-v-7ee0e9e3{padding:0 ",[0,50],"}\n.",[1],"loginDivr .",[1],"loginBtn.",[1],"data-v-7ee0e9e3{background-color:#fff;border:",[0,2]," solid #07c160;border-radius:",[0,40],";color:#07c160;height:",[0,80],";line-height:",[0,80],";margin-top:",[0,20],";text-align:center}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/qrcodeAgen.wxss:1:765)",{path:"./pages/pageRelay/qrcodeAgen.wxss"});
}