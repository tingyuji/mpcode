$gwx0_XC_49=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_49 || [];
function gz$gwx0_XC_49_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-0c360124'])
Z([3,'width:100%;padding-bottom:162rpx;box-sizing:border-box;background:#fff;'])
Z([3,'__l'])
Z(z[0])
Z([3,'#07c160'])
Z([3,'map'])
Z([3,'48'])
Z([3,'42bb6f58-1'])
Z(z[2])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'42bb6f58-2'])
Z([[7],[3,'showShares']])
Z(z[2])
Z([3,'__e'])
Z(z[16])
Z([3,'zuj_fix zuj_fixfirst data-v-0c360124'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'42bb6f58-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_49=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_49=true;
var x=['./pages/pageRelay/snapList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_49_1()
var oPU=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oRU=_mz(z,'u-icon',['bind:__l',2,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oPU,oRU)
var lSU=_mz(z,'u-loadmore',['bind:__l',8,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(oPU,lSU)
var cQU=_v()
_(oPU,cQU)
if(_oz(z,14,e,s,gg)){cQU.wxVkey=1
var aTU=_mz(z,'dc-hiro-painter',['bind:__l',15,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(cQU,aTU)
}
cQU.wxXCkey=1
cQU.wxXCkey=3
_(r,oPU)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_49";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_49();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/snapList.wxml'] = [$gwx0_XC_49, './pages/pageRelay/snapList.wxml'];else __wxAppCode__['pages/pageRelay/snapList.wxml'] = $gwx0_XC_49( './pages/pageRelay/snapList.wxml' );
	;__wxRoute = "pages/pageRelay/snapList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/snapList.js";define("pages/pageRelay/snapList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/snapList"],{626:function(e,n,t){"use strict";(function(e){t(5),s(t(4));var n=s(t(627));function s(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},627:function(e,n,t){"use strict";t.r(n);var s=t(628),o=t(630);for(var r in o)"default"!==r&&function(e){t.d(n,e,(function(){return o[e]}))}(r);t(632);var a=t(17),i=Object(a.default)(o.default,s.render,s.staticRenderFns,!1,null,"0c360124",null,!1,s.components,void 0);i.options.__file="pages/pageRelay/snapList.vue",n.default=i.exports},628:function(e,n,t){"use strict";t.r(n);var s=t(629);t.d(n,"render",(function(){return s.render})),t.d(n,"staticRenderFns",(function(){return s.staticRenderFns})),t.d(n,"recyclableRender",(function(){return s.recyclableRender})),t.d(n,"components",(function(){return s.components}))},629:function(e,n,t){"use strict";var s;t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return a})),t.d(n,"recyclableRender",(function(){return r})),t.d(n,"components",(function(){return s}));try{s={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))},uLoadmore:function(){return t.e("uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null,861))},dcHiroPainter:function(){return t.e("components/dc-hiro-painter/dc-hiro-painter").then(t.bind(null,875))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},r=!1,a=[];o._withStripped=!0},630:function(e,n,t){"use strict";t.r(n);var s=t(631),o=t.n(s);for(var r in s)"default"!==r&&function(e){t.d(n,e,(function(){return s[e]}))}(r);n.default=o.a},631:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,function(e){e&&e.__esModule}(t(61));var s={data:function(){return{showShares:!1,userInfos:{},shareObj:{},titleName:"我的成员",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多成员"},loadStatus:"loading",page:1,pageSize:20,shareImgMini:"",addressInfo:{id:"",userName:"",userMobile:"",provinces:"",address:"",defaultFlag:"",addressType:2,addressName:"",longitude:0,latitude:0,showName:"",addressImg:"",addressCategory:""}}},onLoad:function(e){if(this.getUserInfo(),this.preAddrManagers(),e&&e.item){var n=JSON.parse(decodeURIComponent(e.item));this.addressInfo.id=n.id,this.addressInfo.userName=n.userName,this.addressInfo.userMobile=n.userMobile,this.addressInfo.provinces=n.provinces,this.addressInfo.address=n.address,this.addressInfo.defaultFlag=n.defaultFlag,this.addressInfo.addressName=n.addressName,this.addressInfo.showName=n.address,this.addressInfo.latitude=n.latitude,this.addressInfo.longitude=n.longitude,this.addressInfo.pageType=n.pageType}},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.preAddrManagers())},onShareAppMessage:function(n){var t=e.getStorageSync("userInfo")||{},s={title:t.nickName+"邀请您成为自提点管理员",path:"/pages/subPage/myHome?zt="+this.addressInfo.id+"&uid="+t.userId,imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(e){},fail:function(){}};if("button"==n.from){n.target.dataset;var o=this}return o=this,s.imageUrl=o.shareImgMini,s},methods:{gobacks:function(n){if(1==this.addressInfo.pageType){encodeURIComponent(JSON.stringify(n));var t=getCurrentPages();t[t.length-2].$vm.otherFun(n),e.navigateBack()}else 2==this.addressInfo.pageType?this.$server.setAddrManager({addressId:this.addressInfo.id,userId:n.userId,type:1}).then((function(t){0==t.code?(e.showToast({title:"设置成功",icon:"none"}),setTimeout((function(t){encodeURIComponent(JSON.stringify(n));var s=getCurrentPages();s[s.length-2].$vm.otherFun(n),e.navigateBack()}),1200)):e.showToast({title:t.message,icon:"none"})})):this.$server.setAddrManager({addressId:this.addressInfo.id,userId:n.userId,type:1}).then((function(n){0==n.code?(e.showToast({title:"设置成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),1200)):e.showToast({title:n.message,icon:"none"})}))},shareUrl:function(e){this.shareImgMini=e,this.showShares=!1,this.shareObj={}},getUserInfo:function(){var n=this,t=e.getStorageSync("userInfo")||{};this.$server.userIndexInfo({userId:t.userId}).then((function(t){0==t.code?(!t.data.introduction&&(t.data.introduction="快来成为我的自提管理员吧"),n.userInfos=t.data,n.shareHelpOpen()):e.showToast({title:t.message,icon:"none"})}))},shareHelpOpen:function(){this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.memberCount=this.userInfos.memberCount||"1",this.shareObj.solitaireCount=this.userInfos.solitaireCount||"0",this.shareObj.introduction=this.userInfos.introduction.slice(0,14),this.shareObj.ztShareUser=1,this.showShares=!0},preAddrManagers:function(){var e=this;this.$server.preAddrManagers().then((function(n){if(null!=n&&0==n.code){var t=n.data.map((function(e){return e.nickName||(e.nickName="群优选用户"),e.headImg||(e.headImg="https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg"),e}));e.list=e.list.concat(t),setTimeout((function(t){n.data.length<e.pageSize?(e.finished=!0,e.loadStatus="nomore"):e.loadStatus="loadmore"}),500)}}))},goMyhome:function(n){e.navigateTo({url:"./myHome?uid="+n})}}};n.default=s}).call(this,t(1).default)},632:function(e,n,t){"use strict";t.r(n);var s=t(633),o=t.n(s);for(var r in s)"default"!==r&&function(e){t.d(n,e,(function(){return s[e]}))}(r);n.default=o.a},633:function(e,n,t){}},[[626,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/snapList.js'});require("pages/pageRelay/snapList.js");