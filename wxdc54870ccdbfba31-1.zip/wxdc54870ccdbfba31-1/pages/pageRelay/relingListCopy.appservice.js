$gwx0_XC_43=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_43 || [];
function gz$gwx0_XC_43_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityLi']])
Z(z[0])
Z([3,'__e'])
Z([3,'ele_shop data-v-7d40c062'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goCopy']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'activityLi']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'shop_img fl data-v-7d40c062'])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,1]])
Z(z[10])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_43_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_43=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_43=true;
var x=['./pages/pageRelay/relingListCopy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_43_1()
var oLT=_v()
_(r,oLT)
var lMT=function(tOT,aNT,ePT,gg){
var oRT=_mz(z,'view',['bindtap',4,'class',1,'data-event-opts',2],[],tOT,aNT,gg)
var xST=_v()
_(oRT,xST)
if(_oz(z,7,tOT,aNT,gg)){xST.wxVkey=1
var oTT=_n('view')
_rz(z,oTT,'class',8,tOT,aNT,gg)
var fUT=_v()
_(oTT,fUT)
if(_oz(z,9,tOT,aNT,gg)){fUT.wxVkey=1
}
var cVT=_v()
_(oTT,cVT)
if(_oz(z,10,tOT,aNT,gg)){cVT.wxVkey=1
}
var hWT=_v()
_(oTT,hWT)
if(_oz(z,11,tOT,aNT,gg)){hWT.wxVkey=1
}
fUT.wxXCkey=1
cVT.wxXCkey=1
hWT.wxXCkey=1
_(xST,oTT)
}
xST.wxXCkey=1
_(ePT,oRT)
return ePT
}
oLT.wxXCkey=2
_2z(z,2,lMT,e,s,gg,oLT,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_43";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_43();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/relingListCopy.wxml'] = [$gwx0_XC_43, './pages/pageRelay/relingListCopy.wxml'];else __wxAppCode__['pages/pageRelay/relingListCopy.wxml'] = $gwx0_XC_43( './pages/pageRelay/relingListCopy.wxml' );
	;__wxRoute = "pages/pageRelay/relingListCopy";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/relingListCopy.js";define("pages/pageRelay/relingListCopy.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/relingListCopy"],{268:function(t,e,n){"use strict";(function(t){n(5),i(n(4));var e=i(n(269));function i(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=n,t(e.default)}).call(this,n(1).createPage)},269:function(t,e,n){"use strict";n.r(e);var i=n(270),o=n(272);for(var r in o)"default"!==r&&function(t){n.d(e,t,(function(){return o[t]}))}(r);n(274);var c=n(17),a=Object(c.default)(o.default,i.render,i.staticRenderFns,!1,null,"7d40c062",null,!1,i.components,void 0);a.options.__file="pages/pageRelay/relingListCopy.vue",e.default=a.exports},270:function(t,e,n){"use strict";n.r(e);var i=n(271);n.d(e,"render",(function(){return i.render})),n.d(e,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(e,"recyclableRender",(function(){return i.recyclableRender})),n.d(e,"components",(function(){return i.components}))},271:function(t,e,n){"use strict";n.r(e),n.d(e,"render",(function(){return i})),n.d(e,"staticRenderFns",(function(){return r})),n.d(e,"recyclableRender",(function(){return o})),n.d(e,"components",(function(){}));var i=function(){this.$createElement,this._self._c},o=!1,r=[];i._withStripped=!0},272:function(t,e,n){"use strict";n.r(e);var i=n(273),o=n.n(i);for(var r in i)"default"!==r&&function(t){n.d(e,t,(function(){return i[t]}))}(r);e.default=o.a},273:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i=function(t){return t&&t.__esModule?t:{default:t}}(n(61)),o={data:function(){return{showMenu:!1,showAct:!1,menuStyle:{},shareObj:{},showShares:!1,showSharesBox:!1,shareImgMini:"",countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},picListInfo:{titleName:"",picItemList:[]},activityLi:[],nickName:"",activityOwnLi:[],checkActivityId:0,actionList:[{text:"开启接龙"},{text:"隐藏接龙"},{text:"暂停接龙"},{text:"结束接龙"},{text:"删除接龙"}],page:1,finished:!1}},computed:{getIcon:function(){}},onShow:function(){},onReachBottom:function(){this.finished||(this.page++,this.actAllList())},onLoad:function(){t.hideShareMenu({}),this.actAllList(),this.userInfoHome=t.getStorageSync("userInfo")||{}},methods:{goOrder:function(e){console.log("跳转"),t.navigateTo({url:"../subPage/showRel?cp=1&id="+e})},goCopy:function(e){console.log("跳转"),t.navigateTo({url:"../solitaire/issueRelayPlus?type=3&id="+e.activityId})},actAllList:function(){var e=this;this.$server.actOwnList({page:this.page,pageSize:10}).then((function(n){if(0==n.code){if(1==e.page&&0==n.data.length)return e.finished=!0,void console.log("无数据");n.data.length<10&&(e.loading=!1,e.finished=!0,console.log("无更多数据"));var o=n.data.map((function(t){if(t.activityDetails.length){var e="";t.activityDetails.forEach((function(n){1==n.contentType?t.showTexts=n.activityDetail:(2==n.contentType||5==n.contentType)&&(e=0!=e.length?e+","+n.activityDetail:n.activityDetail)})),0!=e.length?(console.log("cur.imgArrs==",e),t.imgArrs=e.split(",",3),console.log("cur.imgArrs==",t.imgArrs)):t.imgArrs=!1}else t.imgArrs=!1;return t.maxSellPriceShow=i.default.centTurnSmacker(t.minMaxPrice.maxSellPrice/100),t}));e.activityLi=e.activityLi.concat(o)}else t.showToast({title:n.message,icon:"none"})}))}}};e.default=o}).call(this,n(1).default)},274:function(t,e,n){"use strict";n.r(e);var i=n(275),o=n.n(i);for(var r in i)"default"!==r&&function(t){n.d(e,t,(function(){return i[t]}))}(r);e.default=o.a},275:function(t,e,n){}},[[268,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/relingListCopy.js'});require("pages/pageRelay/relingListCopy.js");