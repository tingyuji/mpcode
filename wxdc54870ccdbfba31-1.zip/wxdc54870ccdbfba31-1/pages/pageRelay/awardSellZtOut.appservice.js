$gwx0_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_10 || [];
function gz$gwx0_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_10=true;
var x=['./pages/pageRelay/awardSellZtOut.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_10_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_10();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSellZtOut.wxml'] = [$gwx0_XC_10, './pages/pageRelay/awardSellZtOut.wxml'];else __wxAppCode__['pages/pageRelay/awardSellZtOut.wxml'] = $gwx0_XC_10( './pages/pageRelay/awardSellZtOut.wxml' );
	;__wxRoute = "pages/pageRelay/awardSellZtOut";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/awardSellZtOut.js";define("pages/pageRelay/awardSellZtOut.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/awardSellZtOut"],{660:function(e,t,n){"use strict";(function(e){n(5),i(n(4));var t=i(n(661));function i(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},661:function(e,t,n){"use strict";n.r(t);var i=n(662),r=n(664);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);n(666);var s=n(17),a=Object(s.default)(r.default,i.render,i.staticRenderFns,!1,null,"2db3fe8b",null,!1,i.components,void 0);a.options.__file="pages/pageRelay/awardSellZtOut.vue",t.default=a.exports},662:function(e,t,n){"use strict";n.r(t);var i=n(663);n.d(t,"render",(function(){return i.render})),n.d(t,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(t,"recyclableRender",(function(){return i.recyclableRender})),n.d(t,"components",(function(){return i.components}))},663:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return o})),n.d(t,"recyclableRender",(function(){return r})),n.d(t,"components",(function(){}));var i=function(){this.$createElement,this._self._c},r=!1,o=[];i._withStripped=!0},664:function(e,t,n){"use strict";n.r(t);var i=n(665),r=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=r.a},665:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),r={data:function(){return{informTextId:"",informText:"您的商品已到达，请尽快取货",showInform:!1,recharge_num:10,recharge_price:1,recharge_idx:0,recommendDatas:{useSmsCount:0,oldUserCount:0,unUseSmsCount:0},recharge_success_isopne:!1,close_countdown:5,activityName:"",currentShequn:0,listShequn:[{name:"全部"},{name:"团购中"},{name:"已结束"}],showMenu:!1,menuStyle:{},shareObj:{},shareImgMini:"",countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},picListInfo:{titleName:"",picItemList:[]},activityLi:[],nickName:"",activityOwnLi:[],checkActivityId:0,page:1,finished:!1,noData:!1,activityEle:{},pageQuerys:{addressId:0,activityId:0}}},onShow:function(){},onReachBottom:function(){this.finished||(this.page++,this.queryAddrCmisionList())},onLoad:function(t){if(e.hideShareMenu({}),t&&t.item){var n=JSON.parse(decodeURIComponent(t.item));this.pageQuerys.activityId=n.activityId,this.pageQuerys.addressId=n.addressId,this.queryAddrCmisionList()}},methods:{sendCommission:function(t){var n=this;if(2==t.commissionStatus)return e.showToast({title:"该订单佣金已发送过啦",icon:"none"}),!1;var i={ids:t.id+""};this.$server.updateAddrCmsionStatus(i).then((function(i){0==i.code?(e.showToast({title:"发放佣金成功",icon:"success"}),n.showInform=!1,t.commissionStatus=2,t.activityStatusTex="已发放佣金"):e.showToast({title:i.message,icon:"none"})}))},goPage:function(t){if(!t)return e.showToast({title:"暂未开放",icon:"none"}),!1;e.navigateTo({url:"../subPage/"+t})},queryAddrCmisionList:function(){var t=this;1==this.currentShequn||this.currentShequn;var n={page:this.page,pageSize:10,addressId:this.pageQuerys.addressId,activityId:this.pageQuerys.activityId};this.$server.queryAddrCmisionList(n).then((function(n){if(0==n.code){if(1==t.page&&0==n.data.length)return t.finished=!0,void console.log("无数据");n.data.length<10&&(t.loading=!1,t.finished=!0,console.log("无更多数据"));var r=n.data.map((function(e){return e.orderAmount=i.default.centTurnSmacker(e.orderAmount/100),e.commissionAmount=i.default.centTurnSmacker(e.commissionAmount/100),e.activityStatusTex=["","待发放佣金","佣金已发放"][e.commissionStatus],e}));t.activityLi=t.activityLi.concat(r)}else e.showToast({title:n.message,icon:"none"})}))}}};t.default=r}).call(this,n(1).default)},666:function(e,t,n){"use strict";n.r(t);var i=n(667),r=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=r.a},667:function(e,t,n){}},[[660,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/awardSellZtOut.js'});require("pages/pageRelay/awardSellZtOut.js");