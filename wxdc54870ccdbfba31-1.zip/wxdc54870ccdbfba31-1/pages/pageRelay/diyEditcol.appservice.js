$gwx0_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_18 || [];
function gz$gwx0_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join data-v-200a5b68'])
Z([3,'min-height:100vh;background-color:#f4f4f4;padding-top:10rpx;box-sizing:border-box;'])
Z([[7],[3,'type']])
Z([[2,'=='],[[7],[3,'type']],[1,2]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_18=true;
var x=['./pages/pageRelay/diyEditcol.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_18_1()
var fCJ=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var cDJ=_v()
_(fCJ,cDJ)
if(_oz(z,2,e,s,gg)){cDJ.wxVkey=1
}
var hEJ=_v()
_(fCJ,hEJ)
if(_oz(z,3,e,s,gg)){hEJ.wxVkey=1
}
cDJ.wxXCkey=1
hEJ.wxXCkey=1
_(r,fCJ)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/diyEditcol.wxml'] = [$gwx0_XC_18, './pages/pageRelay/diyEditcol.wxml'];else __wxAppCode__['pages/pageRelay/diyEditcol.wxml'] = $gwx0_XC_18( './pages/pageRelay/diyEditcol.wxml' );
	;__wxRoute = "pages/pageRelay/diyEditcol";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/diyEditcol.js";define("pages/pageRelay/diyEditcol.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/diyEditcol"],{414:function(e,t,n){"use strict";(function(e){n(5),r(n(4));var t=r(n(415));function r(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},415:function(e,t,n){"use strict";n.r(t);var r=n(416),o=n(418);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);n(420);var u=n(17),c=Object(u.default)(o.default,r.render,r.staticRenderFns,!1,null,"200a5b68",null,!1,r.components,void 0);c.options.__file="pages/pageRelay/diyEditcol.vue",t.default=c.exports},416:function(e,t,n){"use strict";n.r(t);var r=n(417);n.d(t,"render",(function(){return r.render})),n.d(t,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(t,"recyclableRender",(function(){return r.recyclableRender})),n.d(t,"components",(function(){return r.components}))},417:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return i})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){}));var r=function(){this.$createElement,this._self._c},o=!1,i=[];r._withStripped=!0},418:function(e,t,n){"use strict";n.r(t);var r=n(419),o=n.n(r);for(var i in r)"default"!==i&&function(e){n.d(t,e,(function(){return r[e]}))}(i);t.default=o.a},419:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,function(e){e&&e.__esModule}(n(61));var r={data:function(){return{informText:"",type:0,placeholders:["请输入自定义填写项","请输入自定义填写项","请输入名称，如集赞截图"]}},onLoad:function(t){e.hideShareMenu({}),this.informText=t.text,this.type=t.type,console.log("qList=",this.placeholders[this.type])},methods:{gobacks:function(){var t={text:this.informText,type:this.type},n=(encodeURIComponent(JSON.stringify(t)),getCurrentPages());n[n.length-2].$vm.textFun(t),e.navigateBack()}}};t.default=r}).call(this,n(1).default)},420:function(e,t,n){"use strict";n.r(t);var r=n(421),o=n.n(r);for(var i in r)"default"!==i&&function(e){n.d(t,e,(function(){return r[e]}))}(i);t.default=o.a},421:function(e,t,n){}},[[414,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/diyEditcol.js'});require("pages/pageRelay/diyEditcol.js");