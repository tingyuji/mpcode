$gwx0_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_12 || [];
function gz$gwx0_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-32d50b58'])
Z([3,'width:100%;min-height:100vh;background:#f5f5f5;'])
Z([3,'record-list data-v-32d50b58'])
Z([3,'padding-bottom:0;'])
Z([3,'record-li fl data-v-32d50b58'])
Z([3,'border:none;'])
Z([3,'fl data-v-32d50b58'])
Z([3,'record-left data-v-32d50b58'])
Z([3,'__l'])
Z(z[0])
Z([3,'#07c160'])
Z([3,'map'])
Z([3,'48'])
Z([3,'27cb5d9c-1'])
Z([3,'record-right fl_c data-v-32d50b58'])
Z(z[0])
Z([a,[[6],[[7],[3,'addressInfo']],[3,'addressName']]])
Z(z[0])
Z([a,[[6],[[7],[3,'addressInfo']],[3,'address']]])
Z(z[2])
Z([3,'margin-top:24rpx;'])
Z([3,'record-li fl_sb data-v-32d50b58'])
Z([3,'__e'])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goMyhome']],[[4],[[5],[1,'$0']]]],[[4],[[5],[1,'addressInfo.managerInfo.managerUserId']]]]]]]]]]])
Z(z[7])
Z(z[0])
Z([[6],[[6],[[7],[3,'addressInfo']],[3,'managerInfo']],[3,'headImg']])
Z([3,'record_fc fl_c data-v-32d50b58'])
Z([3,'record-right bold fl data-v-32d50b58'])
Z([3,'margin:0;'])
Z(z[0])
Z([a,[[6],[[6],[[7],[3,'addressInfo']],[3,'managerInfo']],[3,'nickName']]])
Z(z[0])
Z([3,'scaleToFill'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/order/xinxia.png'])
Z(z[0])
Z([a,[[2,'+'],[[6],[[6],[[7],[3,'addressInfo']],[3,'managerInfo']],[3,'createTime']],[1,' 成为自提点管理员']]])
Z([3,'shi_ji fl data-v-32d50b58'])
Z([3,'text_w fl_c data-v-32d50b58'])
Z(z[0])
Z([3,'height:60rpx;'])
Z([a,[[6],[[7],[3,'userAddrData']],[3,'orderCount']]])
Z(z[22])
Z([3,'fl just-center data-v-32d50b58'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'showMode']],[[4],[[5],[1,'$0']]]],[[4],[[5],[1,'item.categoryName']]]]]]]]]]])
Z([3,'累计订单数'])
Z(z[39])
Z(z[0])
Z(z[41])
Z([a,[[2,'+'],[1,'¥'],[[6],[[7],[3,'userAddrData']],[3,'commissionAmount']]]])
Z(z[22])
Z(z[44])
Z(z[45])
Z([3,'自提点佣金'])
Z(z[39])
Z(z[0])
Z(z[41])
Z([a,[[6],[[7],[3,'userAddrData']],[3,'createTimeDay']]])
Z(z[22])
Z(z[44])
Z(z[45])
Z([3,'已管理天数'])
Z([3,'boo_fix fl_sb data-v-32d50b58'])
Z(z[22])
Z([3,'left_bbt fl data-v-32d50b58'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'submitRelay']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'移除管理员'])
Z(z[22])
Z([3,'right_fbt dfcbgdeep data-v-32d50b58'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'submitRelay']],[[4],[[5],[1,2]]]]]]]]]]])
Z([3,'更换管理员'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_12=true;
var x=['./pages/pageRelay/awardSellZtiInfo.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_12_1()
var cC9=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oD9=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var lE9=_mz(z,'view',['class',4,'style',1],[],e,s,gg)
var aF9=_n('view')
_rz(z,aF9,'class',6,e,s,gg)
var tG9=_n('view')
_rz(z,tG9,'class',7,e,s,gg)
var eH9=_mz(z,'u-icon',['bind:__l',8,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(tG9,eH9)
_(aF9,tG9)
var bI9=_n('view')
_rz(z,bI9,'class',14,e,s,gg)
var oJ9=_n('text')
_rz(z,oJ9,'class',15,e,s,gg)
var xK9=_oz(z,16,e,s,gg)
_(oJ9,xK9)
_(bI9,oJ9)
var oL9=_n('text')
_rz(z,oL9,'class',17,e,s,gg)
var fM9=_oz(z,18,e,s,gg)
_(oL9,fM9)
_(bI9,oL9)
_(aF9,bI9)
_(lE9,aF9)
_(oD9,lE9)
_(cC9,oD9)
var cN9=_mz(z,'view',['class',19,'style',1],[],e,s,gg)
var hO9=_n('view')
_rz(z,hO9,'class',21,e,s,gg)
var oP9=_mz(z,'view',['bindtap',22,'class',1,'data-event-opts',2],[],e,s,gg)
var cQ9=_n('view')
_rz(z,cQ9,'class',25,e,s,gg)
var oR9=_mz(z,'image',['class',26,'src',1],[],e,s,gg)
_(cQ9,oR9)
_(oP9,cQ9)
var lS9=_n('view')
_rz(z,lS9,'class',28,e,s,gg)
var aT9=_mz(z,'view',['class',29,'style',1],[],e,s,gg)
var tU9=_n('text')
_rz(z,tU9,'class',31,e,s,gg)
var eV9=_oz(z,32,e,s,gg)
_(tU9,eV9)
_(aT9,tU9)
var bW9=_mz(z,'image',['class',33,'mode',1,'src',2],[],e,s,gg)
_(aT9,bW9)
_(lS9,aT9)
var oX9=_n('text')
_rz(z,oX9,'class',36,e,s,gg)
var xY9=_oz(z,37,e,s,gg)
_(oX9,xY9)
_(lS9,oX9)
_(oP9,lS9)
_(hO9,oP9)
_(cN9,hO9)
var oZ9=_n('view')
_rz(z,oZ9,'class',38,e,s,gg)
var f19=_n('view')
_rz(z,f19,'class',39,e,s,gg)
var c29=_mz(z,'view',['class',40,'style',1],[],e,s,gg)
var h39=_oz(z,42,e,s,gg)
_(c29,h39)
_(f19,c29)
var o49=_mz(z,'view',['bindtap',43,'class',1,'data-event-opts',2],[],e,s,gg)
var c59=_oz(z,46,e,s,gg)
_(o49,c59)
_(f19,o49)
_(oZ9,f19)
var o69=_n('view')
_rz(z,o69,'class',47,e,s,gg)
var l79=_mz(z,'view',['class',48,'style',1],[],e,s,gg)
var a89=_oz(z,50,e,s,gg)
_(l79,a89)
_(o69,l79)
var t99=_mz(z,'view',['bindtap',51,'class',1,'data-event-opts',2],[],e,s,gg)
var e09=_oz(z,54,e,s,gg)
_(t99,e09)
_(o69,t99)
_(oZ9,o69)
var bA0=_n('view')
_rz(z,bA0,'class',55,e,s,gg)
var oB0=_mz(z,'view',['class',56,'style',1],[],e,s,gg)
var xC0=_oz(z,58,e,s,gg)
_(oB0,xC0)
_(bA0,oB0)
var oD0=_mz(z,'view',['bindtap',59,'class',1,'data-event-opts',2],[],e,s,gg)
var fE0=_oz(z,62,e,s,gg)
_(oD0,fE0)
_(bA0,oD0)
_(oZ9,bA0)
_(cN9,oZ9)
_(cC9,cN9)
var cF0=_n('view')
_rz(z,cF0,'class',63,e,s,gg)
var hG0=_mz(z,'view',['bindtap',64,'class',1,'data-event-opts',2],[],e,s,gg)
var oH0=_oz(z,67,e,s,gg)
_(hG0,oH0)
_(cF0,hG0)
var cI0=_mz(z,'view',['bindtap',68,'class',1,'data-event-opts',2],[],e,s,gg)
var oJ0=_oz(z,71,e,s,gg)
_(cI0,oJ0)
_(cF0,cI0)
_(cC9,cF0)
_(r,cC9)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_12();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardSellZtiInfo.wxml'] = [$gwx0_XC_12, './pages/pageRelay/awardSellZtiInfo.wxml'];else __wxAppCode__['pages/pageRelay/awardSellZtiInfo.wxml'] = $gwx0_XC_12( './pages/pageRelay/awardSellZtiInfo.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/awardSellZtiInfo.wxss'] = setCssToHead([".",[1],"record-list.",[1],"data-v-32d50b58{background-color:#fff;box-sizing:border-box;padding-bottom:",[0,30],"}\n.",[1],"record-li.",[1],"data-v-32d50b58{background:#fff;border-bottom:",[0,1]," solid #e5e5e5;height:",[0,130],";margin:0 auto;padding-left:",[0,20],";width:",[0,690],"}\n.",[1],"record-li .",[1],"title.",[1],"data-v-32d50b58{color:#333;font-size:",[0,30],"}\n.",[1],"record-li .",[1],"time.",[1],"data-v-32d50b58{color:#999;font-size:",[0,24],";padding-top:",[0,20],"}\n.",[1],"record-li .",[1],"record-left wx-image.",[1],"data-v-32d50b58{border-radius:",[0,12],";height:",[0,90],";width:",[0,90],"}\n.",[1],"record-li .",[1],"record-right.",[1],"data-v-32d50b58{color:#333;font-size:",[0,30],";margin-left:",[0,30],"}\n.",[1],"record-li .",[1],"record-right .",[1],"war_tag.",[1],"data-v-32d50b58{background-color:#ffdfd5;color:#ff5e2e}\n.",[1],"dfcbtnb.",[1],"data-v-32d50b58{border-radius:",[0,8],";box-sizing:border-box;color:#333;font-size:",[0,24],";padding:",[0,6]," ",[0,24],"}\n.",[1],"boo_fix.",[1],"data-v-32d50b58{background-color:#fff;bottom:0;box-sizing:border-box;font-size:",[0,32],";height:",[0,182],";left:0;padding:0 ",[0,30]," ",[0,60],";position:fixed;width:",[0,750],";z-index:99}\n.",[1],"boo_fix .",[1],"fbts_s.",[1],"data-v-32d50b58{border-radius:",[0,8],";color:#fff;font-weight:500;height:",[0,90],";line-height:",[0,90],";text-align:center;width:",[0,690],"}\n.",[1],"boo_fix .",[1],"left_bbt.",[1],"data-v-32d50b58{background-color:#fff;border:",[0,2]," solid #07c160;border-radius:",[0,8],";box-sizing:border-box;color:#07c160!important;font-weight:500;height:",[0,90],";-webkit-justify-content:center;justify-content:center;text-align:center;width:",[0,336],"}\n.",[1],"boo_fix .",[1],"right_fbt.",[1],"data-v-32d50b58{border-radius:",[0,8],";color:#fff;font-weight:500;height:",[0,90],";line-height:",[0,90],";text-align:center;width:",[0,336],"}\n.",[1],"zuj_fixfirst.",[1],"data-v-32d50b58{background-color:#fff;left:",[0,-9999],";overflow:hidden;position:fixed;top:",[0,-9999],"}\n.",[1],"record_fc.",[1],"data-v-32d50b58{-webkit-justify-content:flex-start;justify-content:flex-start;margin-left:",[0,30],"}\n.",[1],"record_fc .",[1],"record-right.",[1],"data-v-32d50b58{color:#333;font-size:",[0,30],";font-weight:500}\n.",[1],"record_fc .",[1],"record-right wx-text.",[1],"data-v-32d50b58{color:#333;font-size:",[0,32],";font-weight:500}\n.",[1],"record_fc .",[1],"record-right wx-image.",[1],"data-v-32d50b58{height:",[0,32],";margin-left:",[0,6],";margin-top:",[0,8],";width:",[0,32],"}\n.",[1],"record_fc .",[1],"record-rights.",[1],"data-v-32d50b58{font-weight:700}\n.",[1],"record_fc wx-text.",[1],"data-v-32d50b58{color:#999;font-size:",[0,24],";margin-top:",[0,12],"}\n.",[1],"shi_ji.",[1],"data-v-32d50b58{box-sizing:border-box;-webkit-flex-wrap:wrap;flex-wrap:wrap;padding-right:",[0,0],"}\n.",[1],"shi_ji .",[1],"text_w.",[1],"data-v-32d50b58{color:#000;font-size:",[0,38],";font-weight:700;margin-top:",[0,40],";text-align:center;width:33.3%}\n.",[1],"shi_ji .",[1],"text_w .",[1],"just-center.",[1],"data-v-32d50b58{color:#787878;font-size:",[0,26],";font-weight:400}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/awardSellZtiInfo.wxss:1:2035)",{path:"./pages/pageRelay/awardSellZtiInfo.wxss"});
}