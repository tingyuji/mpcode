$gwx0_XC_49=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_49 || [];
function gz$gwx0_XC_49_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-0c360124'])
Z([3,'width:100%;padding-bottom:162rpx;box-sizing:border-box;background:#fff;'])
Z([3,'record-list data-v-0c360124'])
Z([3,'padding-bottom:0;'])
Z([3,'record-li fl data-v-0c360124'])
Z([3,'border:none;'])
Z([3,'fl data-v-0c360124'])
Z([3,'record-left data-v-0c360124'])
Z([3,'__l'])
Z(z[0])
Z([3,'#07c160'])
Z([3,'map'])
Z([3,'48'])
Z([3,'42bb6f58-1'])
Z([3,'record-right fl_c data-v-0c360124'])
Z(z[0])
Z([a,[[6],[[7],[3,'addressInfo']],[3,'addressName']]])
Z(z[0])
Z([a,[[6],[[7],[3,'addressInfo']],[3,'address']]])
Z(z[0])
Z([3,'height:24rpx;background-color:#f5f5f5;'])
Z(z[2])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[22])
Z([3,'record-li fl_sb data-v-0c360124'])
Z([[7],[3,'item']])
Z([3,'__e'])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goMyhome']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]],[1,'userId']]]]]]]]]]]]]]])
Z(z[7])
Z(z[0])
Z([[6],[[7],[3,'item']],[3,'headImg']])
Z([3,'record-right bold data-v-0c360124'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'nickName']]],[1,'']]])
Z(z[28])
Z([3,'dfcbtnb data-v-0c360124'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'gobacks']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'设置'])
Z(z[8])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'42bb6f58-2'])
Z([3,'boo_fix fl_sb data-v-0c360124'])
Z(z[28])
Z([3,'right_fbt fbts_s dfcbgdeep data-v-0c360124'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'submitRelay']],[[4],[[5],[1,'$0']]]],[[4],[[5],[1,'editTypes']]]]]]]]]]])
Z([3,'1'])
Z([3,'sharebtn'])
Z([3,'share'])
Z([3,'true'])
Z([3,'padding:0;border:none;'])
Z([3,'发送微信邀请给本自提点管理员'])
Z([[7],[3,'showShares']])
Z(z[8])
Z(z[28])
Z(z[28])
Z([3,'zuj_fix zuj_fixfirst data-v-0c360124'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'42bb6f58-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_49_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_49=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_49=true;
var x=['./pages/pageRelay/snapList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_49_1()
var lC9C=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var tE9C=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var eF9C=_mz(z,'view',['class',4,'style',1],[],e,s,gg)
var bG9C=_n('view')
_rz(z,bG9C,'class',6,e,s,gg)
var oH9C=_n('view')
_rz(z,oH9C,'class',7,e,s,gg)
var xI9C=_mz(z,'u-icon',['bind:__l',8,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oH9C,xI9C)
_(bG9C,oH9C)
var oJ9C=_n('view')
_rz(z,oJ9C,'class',14,e,s,gg)
var fK9C=_n('text')
_rz(z,fK9C,'class',15,e,s,gg)
var cL9C=_oz(z,16,e,s,gg)
_(fK9C,cL9C)
_(oJ9C,fK9C)
var hM9C=_n('text')
_rz(z,hM9C,'class',17,e,s,gg)
var oN9C=_oz(z,18,e,s,gg)
_(hM9C,oN9C)
_(oJ9C,hM9C)
_(bG9C,oJ9C)
_(eF9C,bG9C)
_(tE9C,eF9C)
_(lC9C,tE9C)
var cO9C=_mz(z,'view',['class',19,'style',1],[],e,s,gg)
_(lC9C,cO9C)
var oP9C=_n('view')
_rz(z,oP9C,'class',21,e,s,gg)
var lQ9C=_v()
_(oP9C,lQ9C)
var aR9C=function(eT9C,tS9C,bU9C,gg){
var xW9C=_mz(z,'view',['class',26,'title',1],[],eT9C,tS9C,gg)
var oX9C=_mz(z,'view',['bindtap',28,'class',1,'data-event-opts',2],[],eT9C,tS9C,gg)
var fY9C=_n('view')
_rz(z,fY9C,'class',31,eT9C,tS9C,gg)
var cZ9C=_mz(z,'image',['class',32,'src',1],[],eT9C,tS9C,gg)
_(fY9C,cZ9C)
_(oX9C,fY9C)
var h19C=_n('view')
_rz(z,h19C,'class',34,eT9C,tS9C,gg)
var o29C=_oz(z,35,eT9C,tS9C,gg)
_(h19C,o29C)
_(oX9C,h19C)
_(xW9C,oX9C)
var c39C=_mz(z,'view',['bindtap',36,'class',1,'data-event-opts',2],[],eT9C,tS9C,gg)
var o49C=_oz(z,39,eT9C,tS9C,gg)
_(c39C,o49C)
_(xW9C,c39C)
_(bU9C,xW9C)
return bU9C
}
lQ9C.wxXCkey=2
_2z(z,24,aR9C,e,s,gg,lQ9C,'item','index','index')
var l59C=_mz(z,'u-loadmore',['bind:__l',40,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(oP9C,l59C)
_(lC9C,oP9C)
var a69C=_n('view')
_rz(z,a69C,'class',46,e,s,gg)
var t79C=_mz(z,'button',['bindtap',47,'class',1,'data-event-opts',2,'data-name',3,'id',4,'openType',5,'plain',6,'style',7],[],e,s,gg)
var e89C=_oz(z,55,e,s,gg)
_(t79C,e89C)
_(a69C,t79C)
_(lC9C,a69C)
var aD9C=_v()
_(lC9C,aD9C)
if(_oz(z,56,e,s,gg)){aD9C.wxVkey=1
var b99C=_mz(z,'dc-hiro-painter',['bind:__l',57,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(aD9C,b99C)
}
aD9C.wxXCkey=1
aD9C.wxXCkey=3
_(r,lC9C)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_49";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_49();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/snapList.wxml'] = [$gwx0_XC_49, './pages/pageRelay/snapList.wxml'];else __wxAppCode__['pages/pageRelay/snapList.wxml'] = $gwx0_XC_49( './pages/pageRelay/snapList.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/pageRelay/snapList.wxss'] = setCssToHead([".",[1],"record-list.",[1],"data-v-0c360124{background-color:#fff;box-sizing:border-box;padding-bottom:",[0,30],"}\n.",[1],"record-li.",[1],"data-v-0c360124{background:#fff;border-bottom:",[0,1]," solid #e5e5e5;height:",[0,130],";margin:0 auto;padding-left:",[0,20],";width:",[0,690],"}\n.",[1],"record-li .",[1],"title.",[1],"data-v-0c360124{color:#333;font-size:",[0,30],"}\n.",[1],"record-li .",[1],"time.",[1],"data-v-0c360124{color:#999;font-size:",[0,24],";padding-top:",[0,20],"}\n.",[1],"record-li .",[1],"record-left wx-image.",[1],"data-v-0c360124{border-radius:",[0,12],";height:",[0,90],";width:",[0,90],"}\n.",[1],"record-li .",[1],"record-right.",[1],"data-v-0c360124{color:#333;font-size:",[0,30],";margin-left:",[0,30],"}\n.",[1],"record-li .",[1],"record-right .",[1],"_span.",[1],"data-v-0c360124{background-color:#e2f3e6;border-radius:",[0,5],";color:#36b25c;display:inline-block;font-size:",[0,20],";font-weight:400;height:",[0,36],";line-height:",[0,36],";text-align:center;width:",[0,100],"}\n.",[1],"record-li .",[1],"record-right .",[1],"war_tag.",[1],"data-v-0c360124{background-color:#ffdfd5;color:#ff5e2e}\n.",[1],"dfcbtnb.",[1],"data-v-0c360124{border-radius:",[0,8],";box-sizing:border-box;color:#333;font-size:",[0,24],";padding:",[0,6]," ",[0,24],"}\n.",[1],"boo_fix.",[1],"data-v-0c360124{background-color:#fff;bottom:0;box-sizing:border-box;font-size:",[0,32],";height:",[0,142],";left:0;padding:0 ",[0,30]," ",[0,30],";position:fixed;width:",[0,750],";z-index:99}\n.",[1],"boo_fix .",[1],"fbts_s.",[1],"data-v-0c360124{border-radius:",[0,16],";color:#fff;font-weight:500;height:",[0,90],";line-height:",[0,90],";text-align:center;width:",[0,690],"}\n.",[1],"zuj_fixfirst.",[1],"data-v-0c360124{background-color:#fff;left:",[0,-9999],";overflow:hidden;position:fixed;top:",[0,-9999],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/pageRelay/snapList.wxss:1:394)",{path:"./pages/pageRelay/snapList.wxss"});
}