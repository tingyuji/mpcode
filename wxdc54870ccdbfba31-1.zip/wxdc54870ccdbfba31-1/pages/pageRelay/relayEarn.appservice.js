$gwx0_XC_41=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_41 || [];
function gz$gwx0_XC_41_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_41_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_41_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_41_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-3eb0aeda'])
Z([3,'padding-top:30rpx;box-sizing:border-box;background-color:#f3f4f5;min-height:100vh;'])
Z([3,'shou_fx data-v-3eb0aeda'])
Z([3,'__e'])
Z([3,'fl data-v-3eb0aeda'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'__l'])
Z(z[0])
Z([3,'#c0c4cc'])
Z([3,'arrow-right'])
Z([3,'28'])
Z([3,'344dead3-1'])
Z([[6],[[7],[3,'statisticsDatas']],[3,'helpSellFlag']])
Z(z[3])
Z([3,'fl review_zt data-v-3eb0aeda'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,3]]]]]]]]]]])
Z(z[6])
Z(z[0])
Z(z[8])
Z(z[9])
Z(z[10])
Z([3,'344dead3-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_41_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_41_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_41=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_41=true;
var x=['./pages/pageRelay/relayEarn.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_41_1()
var tIS=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var eJS=_n('view')
_rz(z,eJS,'class',2,e,s,gg)
var oLS=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var xMS=_mz(z,'u-icon',['bind:__l',6,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oLS,xMS)
_(eJS,oLS)
var bKS=_v()
_(eJS,bKS)
if(_oz(z,12,e,s,gg)){bKS.wxVkey=1
}
bKS.wxXCkey=1
_(tIS,eJS)
var oNS=_mz(z,'view',['bindtap',13,'class',1,'data-event-opts',2],[],e,s,gg)
var fOS=_mz(z,'u-icon',['bind:__l',16,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oNS,fOS)
_(tIS,oNS)
_(r,tIS)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_41";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_41();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/relayEarn.wxml'] = [$gwx0_XC_41, './pages/pageRelay/relayEarn.wxml'];else __wxAppCode__['pages/pageRelay/relayEarn.wxml'] = $gwx0_XC_41( './pages/pageRelay/relayEarn.wxml' );
	;__wxRoute = "pages/pageRelay/relayEarn";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/relayEarn.js";define("pages/pageRelay/relayEarn.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/relayEarn"],{562:function(e,t,n){"use strict";(function(e){n(5),a(n(4));var t=a(n(563));function a(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},563:function(e,t,n){"use strict";n.r(t);var a=n(564),o=n(566);for(var r in o)"default"!==r&&function(e){n.d(t,e,(function(){return o[e]}))}(r);n(568);var u=n(17),c=Object(u.default)(o.default,a.render,a.staticRenderFns,!1,null,"3eb0aeda",null,!1,a.components,void 0);c.options.__file="pages/pageRelay/relayEarn.vue",t.default=c.exports},564:function(e,t,n){"use strict";n.r(t);var a=n(565);n.d(t,"render",(function(){return a.render})),n.d(t,"staticRenderFns",(function(){return a.staticRenderFns})),n.d(t,"recyclableRender",(function(){return a.recyclableRender})),n.d(t,"components",(function(){return a.components}))},565:function(e,t,n){"use strict";var a;n.r(t),n.d(t,"render",(function(){return o})),n.d(t,"staticRenderFns",(function(){return u})),n.d(t,"recyclableRender",(function(){return r})),n.d(t,"components",(function(){return a}));try{a={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},r=!1,u=[];o._withStripped=!0},566:function(e,t,n){"use strict";n.r(t);var a=n(567),o=n.n(a);for(var r in a)"default"!==r&&function(e){n.d(t,e,(function(){return a[e]}))}(r);t.default=o.a},567:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),o={data:function(){return{id:"",statisticsDatas:{accessUserCount:0,activityId:0,buyCount:0,intoCount:0,notifyCount:0,orderUserCount:0,realIncomeMoney:0,salesCount:0,shareCount:0,totalIncomeMoney:0,totalOrderCount:0,totalRateMoney:0,totalRefundMoney:0,helpSellIncomeMoney:0,helpSellFlag:!1},addrData:{orderAmount:0,cmisionAmount:0,managers:0},balanceNum:.59}},onLoad:function(t){this.id=t.id,console.log("活动统计"),e.hideShareMenu({}),this.statisticsData(t.id),this.countAddrData(t.id),this.getBalance()},methods:{getBalance:function(){var t=this;this.$server.queryTradeRate({type:1}).then((function(n){0==n.code?(t.balanceNum=100*n.data.tradeRate,(t.balanceNum+"").length>4&&(t.balanceNum=t.balanceNum.toFixed(2))):e.showToast({title:n.message,icon:"none"})}))},countAddrData:function(t){var n=this;this.$server.countAddrData({activityId:t}).then((function(o){0==o.code?(o.data.orderAmount=a.default.centTurnSmacker(o.data.orderAmount/100),o.data.cmisionAmount=a.default.centTurnSmacker(o.data.cmisionAmount/100),o.data.activityId=t,n.addrData=o.data):e.showToast({title:o.message,icon:"none"})}))},goPage:function(t){if(2==t)e.navigateTo({url:"../subPage/myFund"});else if(1==t)e.navigateTo({url:"./fundList"});else{var n=encodeURIComponent(JSON.stringify(this.addrData));e.navigateTo({url:"./awardSellZtiRel?item="+n})}},statisticsData:function(t){var n=this;this.$server.statisticDetailData({activityId:t}).then((function(t){0==t.code?(t.data.totalRefundMoney=a.default.centTurnSmacker(t.data.totalRefundMoney/100),t.data.realIncomeMoney=a.default.centTurnSmacker(t.data.realIncomeMoney/100),t.data.totalIncomeMoney=a.default.centTurnSmacker(t.data.totalIncomeMoney/100),t.data.totalRateMoney=a.default.centTurnSmacker(t.data.totalRateMoney/100),t.data.helpSellIncomeMoney=a.default.centTurnSmacker(t.data.helpSellIncomeMoney/100),t.data.salesCount=a.default.centTurnSmacker(t.data.salesCount/100),0==t.data.orderUserCount||0==t.data.accessUserCount?t.data.buyRate=0:t.data.orderUserCount>=t.data.accessUserCount?t.data.buyRate=100:t.data.buyRate=(t.data.orderUserCount/t.data.accessUserCount*100).toFixed(2),n.statisticsDatas=t.data,console.log("this.orderUserCount",n.statisticsDatas)):e.showToast({title:t.message,icon:"none"})}))}}};t.default=o}).call(this,n(1).default)},568:function(e,t,n){"use strict";n.r(t);var a=n(569),o=n.n(a);for(var r in a)"default"!==r&&function(e){n.d(t,e,(function(){return a[e]}))}(r);t.default=o.a},569:function(e,t,n){}},[[562,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/relayEarn.js'});require("pages/pageRelay/relayEarn.js");