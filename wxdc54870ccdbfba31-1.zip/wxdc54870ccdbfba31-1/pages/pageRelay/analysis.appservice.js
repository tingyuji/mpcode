$gwx0_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_2 || [];
function gz$gwx0_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-60ca48c2'])
Z([3,'padding-top:200rpx;padding-bottom:60rpx;box-sizing:border-box;background-color:#f4f5f7;min-height:100vh;'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z(z[2])
Z([3,'__e'])
Z([3,'fl just-center data-v-60ca48c2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'showMode']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'listData']],[1,'']],[[7],[3,'index']]],[1,'categoryName']]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'g0']])
Z([3,'__l'])
Z(z[0])
Z([3,'#999'])
Z([3,'question-circle'])
Z([3,'30'])
Z([[2,'+'],[1,'8f015ef8-1-'],[[7],[3,'index']]])
Z([[7],[3,'shopListNoData']])
Z(z[10])
Z(z[0])
Z([1,100])
Z([3,'favor'])
Z([3,'暂无数据'])
Z([3,'8f015ef8-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_2=true;
var x=['./pages/pageRelay/analysis.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_2_1()
var eJE=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oLE=_v()
_(eJE,oLE)
var xME=function(fOE,oNE,cPE,gg){
var oRE=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],fOE,oNE,gg)
var cSE=_v()
_(oRE,cSE)
if(_oz(z,9,fOE,oNE,gg)){cSE.wxVkey=1
var oTE=_mz(z,'u-icon',['bind:__l',10,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],fOE,oNE,gg)
_(cSE,oTE)
}
cSE.wxXCkey=1
cSE.wxXCkey=3
_(cPE,oRE)
return cPE
}
oLE.wxXCkey=4
_2z(z,4,xME,e,s,gg,oLE,'item','index','index')
var bKE=_v()
_(eJE,bKE)
if(_oz(z,16,e,s,gg)){bKE.wxVkey=1
var lUE=_mz(z,'u-empty',['bind:__l',17,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(bKE,lUE)
}
bKE.wxXCkey=1
bKE.wxXCkey=3
_(r,eJE)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/analysis.wxml'] = [$gwx0_XC_2, './pages/pageRelay/analysis.wxml'];else __wxAppCode__['pages/pageRelay/analysis.wxml'] = $gwx0_XC_2( './pages/pageRelay/analysis.wxml' );
	;__wxRoute = "pages/pageRelay/analysis";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/analysis.js";define("pages/pageRelay/analysis.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/analysis"],{610:function(t,e,a){"use strict";(function(t){a(5),o(a(4));var e=o(a(611));function o(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=a,t(e.default)}).call(this,a(1).createPage)},611:function(t,e,a){"use strict";a.r(e);var o=a(612),s=a(614);for(var n in s)"default"!==n&&function(t){a.d(e,t,(function(){return s[t]}))}(n);a(616);var i=a(17),r=Object(i.default)(s.default,o.render,o.staticRenderFns,!1,null,"60ca48c2",null,!1,o.components,void 0);r.options.__file="pages/pageRelay/analysis.vue",e.default=r.exports},612:function(t,e,a){"use strict";a.r(e);var o=a(613);a.d(e,"render",(function(){return o.render})),a.d(e,"staticRenderFns",(function(){return o.staticRenderFns})),a.d(e,"recyclableRender",(function(){return o.recyclableRender})),a.d(e,"components",(function(){return o.components}))},613:function(t,e,a){"use strict";var o;a.r(e),a.d(e,"render",(function(){return s})),a.d(e,"staticRenderFns",(function(){return i})),a.d(e,"recyclableRender",(function(){return n})),a.d(e,"components",(function(){return o}));try{o={uIcon:function(){return a.e("uview-ui/components/u-icon/u-icon").then(a.bind(null,854))},uEmpty:function(){return a.e("uview-ui/components/u-empty/u-empty").then(a.bind(null,868))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){var t=this,e=(t.$createElement,t._self._c,t.__map(t.listData,(function(e,a){return{$orig:t.__get_orig(e),g0:t.tagTextsStr.includes(e.categoryName)}})));t.$mp.data=Object.assign({},{$root:{l0:e}})},n=!1,i=[];s._withStripped=!0},614:function(t,e,a){"use strict";a.r(e);var o=a(615),s=a.n(o);for(var n in o)"default"!==n&&function(t){a.d(e,t,(function(){return o[t]}))}(n);e.default=s.a},615:function(t,e,a){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o=function(t){return t&&t.__esModule?t:{default:t}}(a(61)),s={data:function(){var t=o.default.getDefaulDate({format:!0});return{showTimes:"",tagTextsStr:["佣金收入","佣金支出","新下单人数","转化率","支付金额","销售额"],tagTexts:["佣金收入==包含帮卖佣金、推荐佣金和推广员佣金的收入（未减去退款部分佣金）","佣金支出==包含帮卖佣金、推荐佣金和推广员佣金的支出（未减去退款部分佣金、不包含未发放佣金）","新下单人数==第一次参与接龙的用户数，仅统计自卖数据","转化率==转化率可有效反应活动对顾客的吸引程度","支付金额==用户实际支付金额（未减去用户退款总金额）","销售额==用户实际支付总金额减去用户退款总金额"],shopListNoData:!1,shopList:[],listData:[{businessType:3,categoryName:"订单数",categorySort:1,commodityCount:0,defaultFlag:1,id:118,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"支付金额",categorySort:1,commodityCount:0,defaultFlag:2,id:119,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"佣金收入",categorySort:1,commodityCount:0,defaultFlag:2,id:120,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"佣金支出",categorySort:1,commodityCount:0,defaultFlag:2,id:121,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"下单人数",categorySort:1,commodityCount:0,defaultFlag:1,id:122,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"销售额",categorySort:1,commodityCount:0,defaultFlag:2,id:123,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"退款金额",categorySort:1,commodityCount:0,defaultFlag:2,id:124,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"客单价",categorySort:1,commodityCount:0,defaultFlag:2,id:125,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"新下单人数",categorySort:1,commodityCount:0,defaultFlag:1,id:126,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"帮卖销售额",categorySort:1,commodityCount:0,defaultFlag:2,id:127,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"帮卖订单数",categorySort:1,commodityCount:0,defaultFlag:1,id:128,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"访问人数",categorySort:1,commodityCount:0,defaultFlag:1,id:128,switchFlag:1,userId:"1188631553"},{businessType:3,categoryName:"转化率",categorySort:1,commodityCount:0,defaultFlag:1,id:128,switchFlag:1,userId:"1188631553"}],date:t,dateTwo:t,dateThree:t,startTiTe:"开始时间",endTiTe:"结束时间",startTiTeTwo:"自然月",isDiyTi:!1,id:"",tagArray:["今日","昨日","近7日","近30日"],rankIcon:["http://qiniuimg.kfmanager.com/qunjl/showrel/medal1.png","http://qiniuimg.kfmanager.com/qunjl/showrel/medal2.png","http://qiniuimg.kfmanager.com/qunjl/showrel/medal3.png"],orderStatus:0,userInfoHome:null}},onLoad:function(e){var a=this;t.hideShareMenu({});var o={};if(e.scene){var s=decodeURIComponent(e.scene).split("&");console.log("msceneArr==",s);for(var n=0;n<s.length;n++){var i=s[n].split("=");o[i[0]]=i[1]}}var r=e.t||o.t;r&&(this.orderStatus=r);var u=getCurrentPages();console.log("我是pages",u);var c=t.getStorageSync("userInfo"),d=this;u.length>1?(console.log("非小程序进入跳转页==",u),this.getTotalData(),this.getSellRank(),setTimeout((function(t){a.userInfoHome=c}),1e3)):wx.login({success:function(e){e.code&&d.$server.login({agentId:d.$agentId,code:e.code}).then((function(e){t.setStorageSync("userInfo",e),d.getTotalData(),d.getSellRank(),d.userInfoHome=e}))}})},onShow:function(){this.userInfoHome&&(console.log("我是222==",this.userInfoHome),this.getTotalData(),this.getSellRank())},watch:{orderStatus:{handler:function(t,e){if(console.log("我是vuex的属性监听方法",this.orderStatus),!this.userInfoHome)return!1;4==this.orderStatus&&6==this.orderStatus||(this.getTotalData(),this.getSellRank())}}},computed:{startDate:function(){return o.default.getDefaulDate("start")},endDate:function(){return o.default.getDefaulDate("end")}},methods:{showMode:function(e){var a=this.tagTextsStr.indexOf(e);if(-1==a)return!1;console.log("==",a);var o=this.tagTexts[a];console.log("==",o);var s=o.split("==");t.showModal({title:s[0],content:s[1],showCancel:!1,confirmText:"我知道了",confirmColor:"#07c160"})},getTotalData:function(){var e=this,a={};this.orderStatus<4||5==this.orderStatus?(a.dayType=this.orderStatus,5==this.orderStatus&&(a.dayType=4)):4==this.orderStatus?a.yearMonth=this.startTiTeTwo:6==this.orderStatus&&(a.startDate=this.startTiTe,a.endDate=this.endTiTe),this.$server.userOrderTotalData(a).then((function(a){0==a.code?(a.data.categoryList.map((function(t){return 2==t.defaultFlag&&(t.commodityCount=o.default.centTurnSmacker(t.commodityCount/100)),t})),e.listData=a.data.categoryList,0==e.orderStatus?e.showTimes=a.data.endDate+" 更新":1==e.orderStatus?e.showTimes=a.data.startDate.slice(0,10):6==e.orderStatus?e.showTimes=e.startTiTe+" ~ "+e.endTiTe:e.showTimes=a.data.startDate.slice(0,10)+" ~ "+a.data.endDate.slice(0,10)):t.showToast({title:a.message,icon:"none"})}))},getSellRank:function(){var e=this,a={page:1,pageSize:50};this.orderStatus<4||5==this.orderStatus?(a.dayType=this.orderStatus,5==this.orderStatus&&(a.dayType=4)):4==this.orderStatus?a.yearMonth=this.startTiTeTwo:6==this.orderStatus&&(a.startDate=this.startTiTe,a.endDate=this.endTiTe),this.$server.userCommoditySellRank(a).then((function(a){0==a.code?a.data.length?(a.data.map((function(t){return 2==t.defaultFlag&&(t.commodityCount=o.default.centTurnSmacker(t.commodityCount/100)),t})),e.shopList=a.data,e.shopListNoData=!1):(e.shopListNoData=!0,e.shopList=[]):t.showToast({title:a.message,icon:"none"})}))},checkStaus:function(t){this.orderStatus=t,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.isDiyTi&&(this.isDiyTi=!1)},bindDateChange:function(t){this.date=t.target.value,this.startTiTe=t.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"结束时间"==this.endTiTe&&(this.dateTwo=t.target.value,this.endTiTe=t.target.value),6!=this.orderStatus&&(this.orderStatus=6),this.getTotalData(),this.getSellRank()},bindDateChangeTwo:function(t){console.log("结束时间",t),this.dateTwo=t.target.value,this.endTiTe=t.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"开始时间"==this.startTiTe&&(this.date=t.target.value,this.startTiTe=t.target.value),6!=this.orderStatus&&(this.orderStatus=6),this.getTotalData(),this.getSellRank()},bindDateChangeThree:function(t){console.log("结束时间",t),this.dateThree=t.target.value,this.startTiTeTwo=t.target.value,4!=this.orderStatus&&(this.orderStatus=4),this.getTotalData(),this.getSellRank()},getBalance:function(){var e=this;this.$server.queryTradeRate({type:1}).then((function(a){0==a.code?(e.balanceNum=100*a.data.tradeRate,(e.balanceNum+"").length>4&&(e.balanceNum=e.balanceNum.toFixed(2))):t.showToast({title:a.message,icon:"none"})}))},goPage:function(e){2==e?t.navigateTo({url:"../pageRelay/diyShowData"}):t.navigateTo({url:"./fundList"})}}};e.default=s}).call(this,a(1).default)},616:function(t,e,a){"use strict";a.r(e);var o=a(617),s=a.n(o);for(var n in o)"default"!==n&&function(t){a.d(e,t,(function(){return o[t]}))}(n);e.default=s.a},617:function(t,e,a){}},[[610,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/analysis.js'});require("pages/pageRelay/analysis.js");