$gwx0_XC_40=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_40 || [];
function gz$gwx0_XC_40_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_40_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_40_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_40_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_min data-v-64743312'])
Z([3,'min-height:100vh;background-color:#f5f5f5;padding-bottom:160rpx;'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[2])
Z([3,'row_els data-v-64743312'])
Z([3,'fl right_dels data-v-64743312'])
Z([[2,'=='],[[7],[3,'editStatus']],[1,0]])
Z(z[8])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'unfold']]])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-64743312'])
Z([3,'#787878'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'openUnflod']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'arrow-down'])
Z([3,'28'])
Z([[2,'+'],[1,'2a112d22-1-'],[[7],[3,'index']]])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[14])
Z(z[15])
Z([3,'arrow-up'])
Z([3,'30'])
Z([[2,'+'],[1,'2a112d22-2-'],[[7],[3,'index']]])
Z([[6],[[7],[3,'item']],[3,'unfold']])
Z([3,'ins'])
Z([3,'it'])
Z([[6],[[7],[3,'item']],[3,'shopList']])
Z(z[28])
Z(z[12])
Z([3,'shop_list fl data-v-64743312'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'pickShope']],[[4],[[5],[[5],[[5],[1,'$0']],[[7],[3,'index']]],[[7],[3,'ins']]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'ins']]]]]]]]]]]]]]]])
Z([[2,'&&'],[[6],[[7],[3,'it']],[3,'isPick']],[[2,'=='],[[7],[3,'editStatus']],[1,1]]])
Z([[2,'=='],[[7],[3,'editStatus']],[1,1]])
Z([[6],[[7],[3,'it']],[3,'commodityName']])
Z(z[11])
Z(z[12])
Z(z[13])
Z([[4],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'sortConfirm']]]]]]]]])
Z([1,false])
Z([1,true])
Z(z[42])
Z(z[4])
Z([1,55])
Z([3,'2a112d22-3'])
Z(z[36])
Z(z[11])
Z(z[12])
Z([3,'14'])
Z(z[13])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'swAddInput']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'swAddInput']])
Z([3,'2a112d22-4'])
Z([[4],[[5],[1,'default']]])
Z([3,'580rpx'])
Z(z[11])
Z(z[12])
Z(z[13])
Z(z[42])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showCate']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[42])
Z([3,'bottom'])
Z(z[42])
Z([[7],[3,'showCate']])
Z([3,'2a112d22-5'])
Z(z[58])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_40_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_40_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_40=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_40=true;
var x=['./pages/pageRelay/relayCategoty.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_40_1()
var lOR=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var tQR=_v()
_(lOR,tQR)
var eRR=function(oTR,bSR,xUR,gg){
var fWR=_n('view')
_rz(z,fWR,'class',6,oTR,bSR,gg)
var hYR=_n('view')
_rz(z,hYR,'class',7,oTR,bSR,gg)
var oZR=_v()
_(hYR,oZR)
if(_oz(z,8,oTR,bSR,gg)){oZR.wxVkey=1
}
var c1R=_v()
_(hYR,c1R)
if(_oz(z,9,oTR,bSR,gg)){c1R.wxVkey=1
}
var o2R=_v()
_(hYR,o2R)
if(_oz(z,10,oTR,bSR,gg)){o2R.wxVkey=1
var l3R=_mz(z,'u-icon',['bind:__l',11,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],oTR,bSR,gg)
_(o2R,l3R)
}
else{o2R.wxVkey=2
var a4R=_mz(z,'u-icon',['bind:__l',19,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],oTR,bSR,gg)
_(o2R,a4R)
}
oZR.wxXCkey=1
c1R.wxXCkey=1
o2R.wxXCkey=1
o2R.wxXCkey=3
o2R.wxXCkey=3
_(fWR,hYR)
var cXR=_v()
_(fWR,cXR)
if(_oz(z,27,oTR,bSR,gg)){cXR.wxVkey=1
var t5R=_v()
_(cXR,t5R)
var e6R=function(o8R,b7R,x9R,gg){
var fAS=_mz(z,'view',['bindtap',32,'class',1,'data-event-opts',2],[],o8R,b7R,gg)
var cBS=_v()
_(fAS,cBS)
if(_oz(z,35,o8R,b7R,gg)){cBS.wxVkey=1
}
else{cBS.wxVkey=2
var oDS=_v()
_(cBS,oDS)
if(_oz(z,36,o8R,b7R,gg)){oDS.wxVkey=1
}
oDS.wxXCkey=1
}
var hCS=_v()
_(fAS,hCS)
if(_oz(z,37,o8R,b7R,gg)){hCS.wxVkey=1
}
cBS.wxXCkey=1
hCS.wxXCkey=1
_(x9R,fAS)
return x9R
}
t5R.wxXCkey=2
_2z(z,30,e6R,oTR,bSR,gg,t5R,'it','ins','ins')
}
cXR.wxXCkey=1
_(xUR,fWR)
return xUR
}
tQR.wxXCkey=4
_2z(z,4,eRR,e,s,gg,tQR,'item','index','index')
var cES=_mz(z,'h-m-drag-sorts',['bind:__l',38,'bind:confirm',1,'class',2,'data-event-opts',3,'feedbackGeneratorState',4,'isAutoScroll',5,'isLongTouch',6,'list',7,'rowHeight',8,'vueId',9],[],e,s,gg)
_(lOR,cES)
var aPR=_v()
_(lOR,aPR)
if(_oz(z,48,e,s,gg)){aPR.wxVkey=1
}
var oFS=_mz(z,'u-popup',['bind:__l',49,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
_(lOR,oFS)
var lGS=_mz(z,'u-popup',['bind:__l',60,'bind:input',1,'class',2,'closeable',3,'data-event-opts',4,'mask',5,'mode',6,'safeAreaInsetBottom',7,'value',8,'vueId',9,'vueSlots',10],[],e,s,gg)
_(lOR,lGS)
aPR.wxXCkey=1
_(r,lOR)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_40";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_40();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/relayCategoty.wxml'] = [$gwx0_XC_40, './pages/pageRelay/relayCategoty.wxml'];else __wxAppCode__['pages/pageRelay/relayCategoty.wxml'] = $gwx0_XC_40( './pages/pageRelay/relayCategoty.wxml' );
	;__wxRoute = "pages/pageRelay/relayCategoty";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/relayCategoty.js";define("pages/pageRelay/relayCategoty.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/relayCategoty"],{526:function(t,e,o){"use strict";(function(t){o(5),n(o(4));var e=n(o(527));function n(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=o,t(e.default)}).call(this,o(1).createPage)},527:function(t,e,o){"use strict";o.r(e);var n=o(528),i=o(530);for(var s in i)"default"!==s&&function(t){o.d(e,t,(function(){return i[t]}))}(s);o(532),o(534);var a=o(17),r=Object(a.default)(i.default,n.render,n.staticRenderFns,!1,null,"64743312",null,!1,n.components,void 0);r.options.__file="pages/pageRelay/relayCategoty.vue",e.default=r.exports},528:function(t,e,o){"use strict";o.r(e);var n=o(529);o.d(e,"render",(function(){return n.render})),o.d(e,"staticRenderFns",(function(){return n.staticRenderFns})),o.d(e,"recyclableRender",(function(){return n.recyclableRender})),o.d(e,"components",(function(){return n.components}))},529:function(t,e,o){"use strict";var n;o.r(e),o.d(e,"render",(function(){return i})),o.d(e,"staticRenderFns",(function(){return a})),o.d(e,"recyclableRender",(function(){return s})),o.d(e,"components",(function(){return n}));try{n={uIcon:function(){return o.e("uview-ui/components/u-icon/u-icon").then(o.bind(null,854))},HMDragSorts:function(){return o.e("uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts").then(o.bind(null,1114))},uPopup:function(){return o.e("uview-ui/components/u-popup/u-popup").then(o.bind(null,939))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var t=this;t.$createElement,t._self._c,t._isMounted||(t.e0=function(e){t.showCate=!0},t.e1=function(e){t.showCate=!1},t.e2=function(e,o){var n=arguments[arguments.length-1].currentTarget.dataset,i=n.eventParams||n["event-params"];o=i.it,t.categoryCheck=o.categoryName})},s=!1,a=[];i._withStripped=!0},530:function(t,e,o){"use strict";o.r(e);var n=o(531),i=o.n(n);for(var s in n)"default"!==s&&function(t){o.d(e,t,(function(){return n[t]}))}(s);e.default=i.a},531:function(t,e,o){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o={data:function(){return{showCate:!1,categoryCheck:"",editStatus:0,noSorts:!0,addEdit:1,canApply:["水果","蔬菜","零食","海鲜","美妆","服装","居家","鲜花","肉蛋","日用品"],list:[],classNameList:[{name:"",tagList:[]}],categoryArr:[],showInput:!1,swAddInput:!1,popText:"",id:"",xiugai:{aIndex:0,bIndex:0},nextList:[],pickList:[],oldCateName:""}},onShow:function(){},onLoad:function(e){if(t.hideShareMenu({}),e.item){var o=JSON.parse(JSON.stringify(this.vuex_showShopList));o.forEach((function(t){t.unfold=!1,t.shopList.forEach((function(t){t.isPick=!1}))})),console.log("qList=",o),this.list=o}},methods:{addFenlei:function(){this.showCate=!1,this.swAddInput=!0},confirmtop:function(e){if(3==e)return t.showLoading(),this.list=JSON.parse(JSON.stringify(this.nextList)),this.$u.vuex("vuex_showShopList",this.list),this.editStatus=0,setTimeout((function(e){t.hideLoading()}),800),!1;this.editStatus=e},openUnflod:function(t,e){t.unfold,this.list[e].unfold=!t.unfold,console.log("item.unfold",this.list)},pickShope:function(t,e,o){if(1!=this.editStatus)return!1;this.list[e].shopList[o].isPick=!t.isPick},categoryChange:function(e,o){var n=this;t.showLoading(),this.list.forEach((function(t){t.shopList.forEach((function(e){e.isPick&&(e.category=n.categoryCheck,e.isPick=!1),e.unfold=t.unfold}))})),console.log("this.list===",this.list),this.shopListChange()},openShowCate:function(t,e){this.showCate=!0},shopListChange:function(){var e=[];this.list.forEach((function(t){e=e.concat(t.shopList)})),console.log("allArrLi===",e);for(var o=[],n=0;n<e.length;n++){var i=o.findIndex((function(t){return t.name===e[n].category}));-1!==i?(console.log("newArr[index]==",o[i]),o[i].shopList.push(e[n])):o.push({name:e[n].category,shopList:[e[n]],unfold:e[n].unfold})}this.list=o,t.hideLoading(),this.$u.vuex("vuex_showShopList",this.list),this.categoryCheck="",this.showCate=!1,console.log("newArrnewArr===",o,this.list)},sortConfirm:function(t){console.log("this.list: ",this.list),console.log("e.list: ",t.list),this.nextList=t.list,console.log("=== confirm start ==="),console.log("被拖动行: "+JSON.stringify(t.moveRow)),console.log("原始下标：",t.index),console.log("移动到：",t.moveTo),console.log("=== confirm end ===")},tagChange:function(t,e){var o=this.classNameList[t].tagList[e];this.popText=o,this.xiugai.aIndex=t,this.xiugai.bIndex=e,this.showInput=!0},delTag:function(t,e){this.classNameList[t].tagList.splice(e,1)},addTag:function(t){this.popText&&(this.popText=""),this.xiugai.aIndex=t,this.swAddInput=!0},changeName:function(){console.log("修改",this.popText),this.popText&&(console.log("修改",this.popText),this.classNameList[this.xiugai.aIndex].tagList[this.xiugai.bIndex]=this.popText)},addInName:function(t,e){t?(this.popText=t.name,this.oldCateName=t.name,this.id=e,this.addEdit=2):(this.addEdit=1,this.oldCateName=""),console.log("edit==",this.addEdit),this.swAddInput=!0},getCategoryList:function(){var e=this;this.$server.categoryList({businessType:1}).then((function(o){if(0==o.code){var n={};n.arr=o.data,n.status=1,e.$u.vuex("vuex_category",n)}else t.showToast({title:o.message,icon:"none"})}))},updateCategorySort:function(){var e=this;this.$server.updateCategorySort({ids:this.nextList}).then((function(o){0==o.code?(e.noSorts=!0,t.showToast({title:"顺序调整成功",icon:"none"}),e.getCategoryList()):t.showToast({title:o.message,icon:"none"})}))},addCate:function(t,e){this.popText=t,this.id="",this.gobacks(e)},gobacks:function(e){var o=this;if(!this.popText)return t.showToast({title:"请输入分类名称",icon:"none"}),!1;if(2==this.addEdit){var n=this.vuex_category;return this.list[this.id].name=this.popText,this.list[this.id].shopList.forEach((function(t){t.category=o.popText})),n.arr.forEach((function(t){t.categoryName==o.oldCateName&&(t.categoryName=o.popText)})),this.$u.vuex("vuex_showShopList",this.list),this.$u.vuex("vuex_category",n),this.swAddInput=!1,this.popText="",t.showToast({title:"修改成功",icon:"none"}),!1}var i={categoryName:this.popText,businessType:1};this.$server.updateCategory(i).then((function(e){if(0==e.code){if(o.id){t.showToast({title:"修改成功",icon:"none"});var n=o.vuex_category;o.list[o.id].categoryName=o.popText,o.list[o.id].categoryName.length>5?o.list[o.id].categoryNameShow=o.list[o.id].categoryName.slice(0,5):o.list[o.id].categoryNameShow=o.list[o.id].categoryName,n.arr=o.list,o.$u.vuex("vuex_category",n)}else t.showToast({title:"添加成功",icon:"none"}),o.getCategoryList();o.swAddInput=!1,o.popText="",o.id=""}else t.showToast({title:e.message,icon:"none"})}))}}};e.default=o}).call(this,o(1).default)},532:function(t,e,o){"use strict";o.r(e);var n=o(533),i=o.n(n);for(var s in n)"default"!==s&&function(t){o.d(e,t,(function(){return n[t]}))}(s);e.default=i.a},533:function(t,e,o){},534:function(t,e,o){"use strict";o.r(e);var n=o(535),i=o.n(n);for(var s in n)"default"!==s&&function(t){o.d(e,t,(function(){return n[t]}))}(s);e.default=i.a},535:function(t,e,o){}},[[526,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/relayCategoty.js'});require("pages/pageRelay/relayCategoty.js");