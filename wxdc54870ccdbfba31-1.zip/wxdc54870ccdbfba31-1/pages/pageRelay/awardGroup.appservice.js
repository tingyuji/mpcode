$gwx0_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_5 || [];
function gz$gwx0_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-04e334f0'])
Z([3,'width:100%;background-color:#fff;'])
Z([3,'__l'])
Z([3,'__e'])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'groupPeople']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'posInfo']]]]]]]]]]])
Z([3,'拼团人数(人)'])
Z([3,'180'])
Z([3,'请输入拼团人数'])
Z([3,'number'])
Z([[6],[[7],[3,'posInfo']],[3,'groupPeople']])
Z([3,'97826704-1'])
Z([3,'re_mark data-v-04e334f0'])
Z([[2,'!'],[[6],[[7],[3,'speceInfoLi']],[3,'length']]])
Z(z[2])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'groupPriceShow']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'posInfo']]]]]]]]]]])
Z([3,'拼团价格( ¥ )'])
Z(z[7])
Z([3,'请输入拼团价格'])
Z([3,'digit'])
Z([[6],[[7],[3,'posInfo']],[3,'groupPriceShow']])
Z([3,'97826704-2'])
Z([3,'#07c160'])
Z(z[2])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'checkedDy']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'#eee'])
Z([[7],[3,'checkedDy']])
Z([3,'97826704-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_5=true;
var x=['./pages/pageRelay/awardGroup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_5_1()
var c7E=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var o8E=_mz(z,'u-field',['bind:__l',2,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'type',7,'value',8,'vueId',9],[],e,s,gg)
_(c7E,o8E)
var l9E=_n('view')
_rz(z,l9E,'class',12,e,s,gg)
var a0E=_v()
_(l9E,a0E)
if(_oz(z,13,e,s,gg)){a0E.wxVkey=1
var tAF=_mz(z,'u-field',['bind:__l',14,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'type',7,'value',8,'vueId',9],[],e,s,gg)
_(a0E,tAF)
}
else{a0E.wxVkey=2
}
a0E.wxXCkey=1
a0E.wxXCkey=3
_(c7E,l9E)
var eBF=_mz(z,'u-switch',['activeColor',24,'bind:__l',1,'bind:input',2,'class',3,'data-event-opts',4,'inactiveColor',5,'value',6,'vueId',7],[],e,s,gg)
_(c7E,eBF)
_(r,c7E)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/awardGroup.wxml'] = [$gwx0_XC_5, './pages/pageRelay/awardGroup.wxml'];else __wxAppCode__['pages/pageRelay/awardGroup.wxml'] = $gwx0_XC_5( './pages/pageRelay/awardGroup.wxml' );
	;__wxRoute = "pages/pageRelay/awardGroup";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/awardGroup.js";define("pages/pageRelay/awardGroup.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/awardGroup"],{324:function(e,o,t){"use strict";(function(e){t(5),n(t(4));var o=n(t(325));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(o.default)}).call(this,t(1).createPage)},325:function(e,o,t){"use strict";t.r(o);var n=t(326),i=t(328);for(var r in i)"default"!==r&&function(e){t.d(o,e,(function(){return i[e]}))}(r);t(330),t(332);var s=t(17),u=Object(s.default)(i.default,n.render,n.staticRenderFns,!1,null,"04e334f0",null,!1,n.components,void 0);u.options.__file="pages/pageRelay/awardGroup.vue",o.default=u.exports},326:function(e,o,t){"use strict";t.r(o);var n=t(327);t.d(o,"render",(function(){return n.render})),t.d(o,"staticRenderFns",(function(){return n.staticRenderFns})),t.d(o,"recyclableRender",(function(){return n.recyclableRender})),t.d(o,"components",(function(){return n.components}))},327:function(e,o,t){"use strict";var n;t.r(o),t.d(o,"render",(function(){return i})),t.d(o,"staticRenderFns",(function(){return s})),t.d(o,"recyclableRender",(function(){return r})),t.d(o,"components",(function(){return n}));try{n={uField:function(){return t.e("uview-ui/components/u-field/u-field").then(t.bind(null,946))},uSwitch:function(){return t.e("uview-ui/components/u-switch/u-switch").then(t.bind(null,1034))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},r=!1,s=[];i._withStripped=!0},328:function(e,o,t){"use strict";t.r(o);var n=t(329),i=t.n(n);for(var r in n)"default"!==r&&function(e){t.d(o,e,(function(){return n[e]}))}(r);o.default=i.a},329:function(e,o,t){"use strict";(function(e){Object.defineProperty(o,"__esModule",{value:!0}),o.default=void 0;var n=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),i={data:function(){return{checkedDy:!0,speceImg:"http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",posInfo:{groupFlag:2,speceImg:"",groupPrice:"",groupPeople:"",groupPriceShow:"",rewardType:5,commodityIndex:0},defaultPrice:500,defaultPriceShow:5,commodityName:"",commodityIndex:0,speceInfoLi:[],groupFormPrice:""}},onLoad:function(o){e.hideShareMenu({});var t=JSON.parse(decodeURIComponent(o.item)),n=[];console.log("GroupList=",t.commodityDetails),this.posInfo.groupPrice=t.groupPrice,this.posInfo.groupPeople=t.groupPeople,this.posInfo.groupPriceShow=t.groupPriceShow,this.defaultPrice=t.defaultPrice,this.defaultPriceShow=t.defaultPriceShow,this.commodityName=t.commodityName,this.posInfo.commodityIndex=t.commodityIndex,t.commodityDetails.length>1&&t.commodityDetails[1].commodityDetail&&(n=t.commodityDetails[1].commodityDetail.split(","),this.posInfo.speceImg=n[0]),t.formatDetailList&&t.formatDetailList.length&&(t.groupFormPrice&&(this.groupFormPrice=t.groupFormPrice),this.speceInfoLi=t.formatDetailList),console.log("posInfo=",this.posInfo)},methods:{chageNums:function(){this.totalMou&&this.shuNiang?this.showNum=n.default.centTurnSmacker(this.totalMou):this.showNum="0.00"},goPage:function(o){e.navigateTo({url:"/pages/pageRelay/awardGroupList?item="+encodeURIComponent(JSON.stringify(this.speceInfoLi))})},gobacks:function(){if(!this.posInfo.groupPeople)return e.showToast({title:"请输入拼团人数",icon:"none"}),!1;if(this.posInfo.groupPeople<2||this.posInfo.groupPeople>10)return e.showToast({title:"拼团人数不能小于2，大于10",icon:"none"}),!1;if(this.speceInfoLi.length);else{if(!this.posInfo.groupPriceShow)return e.showToast({title:"请输入拼团价格",icon:"none"}),!1;if(1*this.posInfo.groupPriceShow>=1*this.defaultPriceShow)return e.showToast({title:"拼团价格需低于商品默认价格",icon:"none"}),!1}this.speceInfoLi.length?(this.posInfo.speceInfoLi=this.speceInfoLi,this.posInfo.groupFormPrice=this.groupFormPrice):this.posInfo.groupPrice=100*this.posInfo.groupPriceShow;var o=getCurrentPages();o[o.length-2].$vm.awardFun(this.posInfo),e.navigateBack()},groupList:function(e){console.log("groupList",e),this.speceInfoLi=e,this.groupFormPrice=e.groupFormPrice}}};o.default=i}).call(this,t(1).default)},330:function(e,o,t){"use strict";t.r(o);var n=t(331),i=t.n(n);for(var r in n)"default"!==r&&function(e){t.d(o,e,(function(){return n[e]}))}(r);o.default=i.a},331:function(e,o,t){},332:function(e,o,t){"use strict";t.r(o);var n=t(333),i=t.n(n);for(var r in n)"default"!==r&&function(e){t.d(o,e,(function(){return n[e]}))}(r);o.default=i.a},333:function(e,o,t){}},[[324,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/awardGroup.js'});require("pages/pageRelay/awardGroup.js");