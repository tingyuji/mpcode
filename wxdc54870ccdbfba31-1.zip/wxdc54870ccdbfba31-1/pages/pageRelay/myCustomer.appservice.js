$gwx0_XC_31=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_31 || [];
function gz$gwx0_XC_31_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_31_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_31_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_31_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'record-list data-v-26eb2de0'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[1])
Z([3,'__e'])
Z([3,'fl data-v-26eb2de0'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'gouUcharts']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'width:100%;'])
Z([3,'record_fc fl_c data-v-26eb2de0'])
Z([[6],[[7],[3,'item']],[3,'newUserFlag']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,1]])
Z([[6],[[7],[3,'item']],[3,'fromNickName']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,2]])
Z(z[12])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,3]])
Z(z[12])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,4]])
Z(z[12])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,5]])
Z(z[12])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'pageType']],[1,6]])
Z(z[12])
Z([3,'__l'])
Z([3,'data-v-26eb2de0'])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'b6798c14-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_31_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_31_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_31=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_31=true;
var x=['./pages/pageRelay/myCustomer.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_31_1()
var oZN=_n('view')
_rz(z,oZN,'class',0,e,s,gg)
var f1N=_v()
_(oZN,f1N)
var c2N=function(o4N,h3N,c5N,gg){
var l7N=_mz(z,'view',['bindtap',5,'class',1,'data-event-opts',2,'style',3],[],o4N,h3N,gg)
var a8N=_n('view')
_rz(z,a8N,'class',9,o4N,h3N,gg)
var t9N=_v()
_(a8N,t9N)
if(_oz(z,10,o4N,h3N,gg)){t9N.wxVkey=1
}
var e0N=_v()
_(a8N,e0N)
if(_oz(z,11,o4N,h3N,gg)){e0N.wxVkey=1
var cFO=_v()
_(e0N,cFO)
if(_oz(z,12,o4N,h3N,gg)){cFO.wxVkey=1
}
cFO.wxXCkey=1
}
var bAO=_v()
_(a8N,bAO)
if(_oz(z,13,o4N,h3N,gg)){bAO.wxVkey=1
var hGO=_v()
_(bAO,hGO)
if(_oz(z,14,o4N,h3N,gg)){hGO.wxVkey=1
}
hGO.wxXCkey=1
}
var oBO=_v()
_(a8N,oBO)
if(_oz(z,15,o4N,h3N,gg)){oBO.wxVkey=1
var oHO=_v()
_(oBO,oHO)
if(_oz(z,16,o4N,h3N,gg)){oHO.wxVkey=1
}
oHO.wxXCkey=1
}
var xCO=_v()
_(a8N,xCO)
if(_oz(z,17,o4N,h3N,gg)){xCO.wxVkey=1
var cIO=_v()
_(xCO,cIO)
if(_oz(z,18,o4N,h3N,gg)){cIO.wxVkey=1
}
cIO.wxXCkey=1
}
var oDO=_v()
_(a8N,oDO)
if(_oz(z,19,o4N,h3N,gg)){oDO.wxVkey=1
var oJO=_v()
_(oDO,oJO)
if(_oz(z,20,o4N,h3N,gg)){oJO.wxVkey=1
}
oJO.wxXCkey=1
}
var fEO=_v()
_(a8N,fEO)
if(_oz(z,21,o4N,h3N,gg)){fEO.wxVkey=1
var lKO=_v()
_(fEO,lKO)
if(_oz(z,22,o4N,h3N,gg)){lKO.wxVkey=1
}
lKO.wxXCkey=1
}
t9N.wxXCkey=1
e0N.wxXCkey=1
bAO.wxXCkey=1
oBO.wxXCkey=1
xCO.wxXCkey=1
oDO.wxXCkey=1
fEO.wxXCkey=1
_(l7N,a8N)
_(c5N,l7N)
return c5N
}
f1N.wxXCkey=2
_2z(z,3,c2N,e,s,gg,f1N,'item','index','index')
var aLO=_mz(z,'u-loadmore',['bind:__l',23,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(oZN,aLO)
_(r,oZN)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_31";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_31();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/myCustomer.wxml'] = [$gwx0_XC_31, './pages/pageRelay/myCustomer.wxml'];else __wxAppCode__['pages/pageRelay/myCustomer.wxml'] = $gwx0_XC_31( './pages/pageRelay/myCustomer.wxml' );
	;__wxRoute = "pages/pageRelay/myCustomer";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/myCustomer.js";define("pages/pageRelay/myCustomer.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/myCustomer"],{618:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(619));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},619:function(e,n,t){"use strict";t.r(n);var o=t(620),i=t(622);for(var a in i)"default"!==a&&function(e){t.d(n,e,(function(){return i[e]}))}(a);t(624);var r=t(17),s=Object(r.default)(i.default,o.render,o.staticRenderFns,!1,null,"26eb2de0",null,!1,o.components,void 0);s.options.__file="pages/pageRelay/myCustomer.vue",n.default=s.exports},620:function(e,n,t){"use strict";t.r(n);var o=t(621);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},621:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return i})),t.d(n,"staticRenderFns",(function(){return r})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={uLoadmore:function(){return t.e("uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null,861))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},a=!1,r=[];i._withStripped=!0},622:function(e,n,t){"use strict";t.r(n);var o=t(623),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},623:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),i={data:function(){return{total:0,today:0,actionList:[{text:"退出社群"}],showAct:!1,ctrlUserId:"",titleName:"我的成员",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多客户"},loadStatus:"loading",page:1,pageSize:12,pageStatu:0,userInfoHome:{}}},onLoad:function(n){var t=this;console.log("onLoad"),e.hideShareMenu({});var o=this,i=e.getStorageSync("userInfo")||{};if(n.type){if(2==i.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录groupList",i.userType),t.comunityList()}),800),!1;wx.login({success:function(n){var t=this;n.code&&o.$server.login({agentId:o.$agentId,code:n.code}).then((function(n){var i=n;t.userInfoHome=n,e.setStorageSync("userInfo",i),o.countAccessUser(),o.comunityList()}))}})}else this.userInfoHome=i,o.countAccessUser(),o.comunityList()},onShow:function(){console.log("woOnShow")},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.comunityList())},methods:{goUnList:function(){e.navigateTo({url:"../pageRelay/helpSells"})},gouUcharts:function(n){e.getStorageSync("userInfo"),e.navigateTo({url:"../ucharts/ucharts?id="+n.accessUserId})},comunityList:function(){var e=this,n={page:this.page,pageSize:this.pageSize};this.$server.userQueryAccessLog(n).then((function(n){if(null!=n&&0==n.code){var t=n.data.map((function(e){return e.headImg&&e.headImg.includes("http")||(e.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),e.createTime=e.createTime.slice(5,16),e.nickName?e.nickName.length>7?e.shownickName=e.nickName.slice(0,6)+"...":e.shownickName=e.nickName:(e.nickName="群优选用户",e.shownickName="群优选用户"),e.accessTime=o.default.countTimeMin(e.accessTime),e}));e.list=e.list.concat(t),setTimeout((function(t){n.data.length<e.pageSize?(e.finished=!0,e.loadStatus="nomore"):e.loadStatus="loadmore"}),500)}}))},countAccessUser:function(){var n=this;this.$server.countAccessUser().then((function(t){0==t.code?(n.total=t.data.total,n.today=t.data.today):e.showToast({title:t.message,icon:"none"})}))},goMyhome:function(n){e.navigateTo({url:"../subPage/myHome?uid="+n})},opneMenu:function(e){this.ctrlUserId=e,this.showAct=!0}}};n.default=i}).call(this,t(1).default)},624:function(e,n,t){"use strict";t.r(n);var o=t(625),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},625:function(e,n,t){}},[[618,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/myCustomer.js'});require("pages/pageRelay/myCustomer.js");