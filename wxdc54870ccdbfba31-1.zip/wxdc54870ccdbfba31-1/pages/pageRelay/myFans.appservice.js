$gwx0_XC_32=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_32 || [];
function gz$gwx0_XC_32_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_32_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_32_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_32_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-0ef4dcf2'])
Z([3,'width:100%;padding-bottom:200rpx;box-sizing:border-box;'])
Z([3,'searc_box data-v-0ef4dcf2'])
Z([3,'#07c160'])
Z([3,'4'])
Z([3,'120'])
Z([3,'f2f2f3'])
Z([3,'__l'])
Z([3,'__e'])
Z([1,false])
Z(z[0])
Z([[7],[3,'currentShequn']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'changeShequn']]]]]]]]])
Z([3,'80'])
Z([3,'#666'])
Z(z[9])
Z([[7],[3,'listShequn']])
Z([3,'60b17b58-1'])
Z([[8],'color',[1,'#07c160']])
Z([3,'#f7f7f7'])
Z(z[7])
Z(z[8])
Z(z[8])
Z(z[8])
Z(z[0])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^blur']],[[4],[[5],[[4],[[5],[1,'searchFun']]]]]]]],[[4],[[5],[[5],[1,'^search']],[[4],[[5],[[4],[[5],[1,'searchFun']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'activityName']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[13])
Z([3,'搜索昵称'])
Z([3,'square'])
Z(z[9])
Z([[7],[3,'activityName']])
Z([3,'60b17b58-2'])
Z([3,'record-list mt20 data-v-0ef4dcf2'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[33])
Z(z[8])
Z([3,'fbbs data-v-0ef4dcf2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imcImC']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]],[1,'userId']]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'unReadMsgCount']])
Z(z[7])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'60b17b58-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_32_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_32_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_32=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_32=true;
var x=['./pages/pageRelay/myFans.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_32_1()
var eNO=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var bOO=_n('view')
_rz(z,bOO,'class',2,e,s,gg)
var oPO=_mz(z,'u-tabs',['activeColor',3,'barHeight',1,'barWidth',2,'bgColor',3,'bind:__l',4,'bind:change',5,'bold',6,'class',7,'current',8,'data-event-opts',9,'height',10,'inactiveColor',11,'isScroll',12,'list',13,'vueId',14],[],e,s,gg)
_(bOO,oPO)
var xQO=_mz(z,'u-search',['actionStyle',18,'bgColor',1,'bind:__l',2,'bind:blur',3,'bind:input',4,'bind:search',5,'class',6,'data-event-opts',7,'height',8,'placeholder',9,'shape',10,'showAction',11,'value',12,'vueId',13],[],e,s,gg)
_(bOO,xQO)
_(eNO,bOO)
var oRO=_n('view')
_rz(z,oRO,'class',32,e,s,gg)
var fSO=_v()
_(oRO,fSO)
var cTO=function(oVO,hUO,cWO,gg){
var lYO=_mz(z,'view',['bindtap',37,'class',1,'data-event-opts',2],[],oVO,hUO,gg)
var aZO=_v()
_(lYO,aZO)
if(_oz(z,40,oVO,hUO,gg)){aZO.wxVkey=1
}
aZO.wxXCkey=1
_(cWO,lYO)
return cWO
}
fSO.wxXCkey=2
_2z(z,35,cTO,e,s,gg,fSO,'item','index','index')
var t1O=_mz(z,'u-loadmore',['bind:__l',41,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(oRO,t1O)
_(eNO,oRO)
_(r,eNO)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_32";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_32();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/myFans.wxml'] = [$gwx0_XC_32, './pages/pageRelay/myFans.wxml'];else __wxAppCode__['pages/pageRelay/myFans.wxml'] = $gwx0_XC_32( './pages/pageRelay/myFans.wxml' );
	;__wxRoute = "pages/pageRelay/myFans";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/myFans.js";define("pages/pageRelay/myFans.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/myFans"],{732:function(e,t,n){"use strict";(function(e){n(5),s(n(4));var t=s(n(733));function s(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},733:function(e,t,n){"use strict";n.r(t);var s=n(734),i=n(736);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);n(738);var a=n(17),r=Object(a.default)(i.default,s.render,s.staticRenderFns,!1,null,"0ef4dcf2",null,!1,s.components,void 0);r.options.__file="pages/pageRelay/myFans.vue",t.default=r.exports},734:function(e,t,n){"use strict";n.r(t);var s=n(735);n.d(t,"render",(function(){return s.render})),n.d(t,"staticRenderFns",(function(){return s.staticRenderFns})),n.d(t,"recyclableRender",(function(){return s.recyclableRender})),n.d(t,"components",(function(){return s.components}))},735:function(e,t,n){"use strict";var s;n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){return s}));try{s={uTabs:function(){return Promise.all([n.e("common/vendor"),n.e("uview-ui/components/u-tabs/u-tabs")]).then(n.bind(null,996))},uSearch:function(){return n.e("uview-ui/components/u-search/u-search").then(n.bind(null,925))},uLoadmore:function(){return n.e("uview-ui/components/u-loadmore/u-loadmore").then(n.bind(null,861))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},o=!1,a=[];i._withStripped=!0},736:function(e,t,n){"use strict";n.r(t);var s=n(737),i=n.n(s);for(var o in s)"default"!==o&&function(e){n.d(t,e,(function(){return s[e]}))}(o);t.default=i.a},737:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var s=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),i={data:function(){return{firstDy:!1,subscCount:"",totalCount:"",activityName:"",currentShequn:0,listShequn:[{name:"全部"},{name:"已订阅"}],userInfos:{},shareObj:{},showShares:!1,searchStatus:2,showAct:!1,ctrlUserId:"",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多社群"},loadStatus:"loading",page:1,pageSize:20,pageStatu:0,shareImgMini:""}},onLoad:function(t){var n=this;console.log("onLoad"),e.hideShareMenu({});var s=this,i=e.getStorageSync("userInfo")||{};if(this.userInfos=i,t.type){if(2==i.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录groupList",i.userType),n.comunityList()}),800),!1;wx.login({success:function(t){t.code&&s.$server.login({agentId:s.$agentId,code:t.code}).then((function(t){var n=t;e.setStorageSync("userInfo",n),s.comunityList()}))}})}else s.comunityList(),this.getUserInfo()},onShareAppMessage:function(t){e.getStorageSync("userInfo");var n={title:this.userInfos.nickName+"邀请你成为Ta的帮卖团长，轻松赚取佣金",path:"/pages/subPage/myHome",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/bmshares.png",success:function(e){e.errMsg}};return"button"==t.from&&(t.target.dataset,n.imageUrl=this.shareImgMini,n.path="/pages/subPage/myHome?"+this.shareObj.shareScene),n},onShow:function(){},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.comunityList())},methods:{searchFun:function(){console.log("触发搜索=="),this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.comunityList()},changeShequn:function(e){this.currentShequn=e,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.comunityList()},getUserInfo:function(){var t=this;this.$server.userIndexInfo({userId:this.userInfos.userId}).then((function(n){0==n.code?(!n.data.introduction&&(n.data.introduction=""),t.userInfos=n.data):e.showToast({title:n.message,icon:"none"})}))},shareUrl:function(e){this.shareImgMini=e},closeShare:function(e){console.log("关闭分享弹窗==",e),this.showShares=!1,this.shareObj={}},shareHelpOpen:function(){e.showLoading({title:"加载中",mask:!0}),this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.memberCount=this.userInfos.memberCount||"1",this.shareObj.solitaireCount=this.userInfos.solitaireCount||"0",this.shareObj.introduction=this.userInfos.introduction.slice(0,14)||"加入帮卖轻松赚取佣金",this.shareObj.shareScene="z=1&uid="+this.userInfos.userId,this.shareObj.bmtzShare=1,this.showShares=!0,setTimeout((function(t){e.hideLoading()}),2e3)},searchChange:function(e){1==e?1==this.searchStatus||this.searchStatus>3?this.searchStatus=2:2==this.searchStatus?this.searchStatus=3:3==this.searchStatus&&(this.searchStatus=2):4==this.searchStatus||this.searchStatus<4?this.searchStatus=5:5==this.searchStatus?this.searchStatus=6:6==this.searchStatus&&(this.searchStatus=5),this.finished=!1,this.page=1,this.comunityList()},comunityList:function(){var t=this,n={page:this.page,pageSize:this.pageSize,nickName:this.activityName,dataType:this.currentShequn};this.$server.queryFansList(n).then((function(i){if(0==i.code){var o=i.data.fansList.map((function(e){return e.headImg&&e.headImg.includes("http")||(e.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),e.tradeAmount=s.default.centTurnSmacker(e.tradeAmount/100),e}));1==n.page?(t.list=o,t.firstDy?t.firstDy=!0:(t.listShequn[0].name="全部("+i.data.totalCount+")",t.listShequn[1].name="已订阅("+i.data.subscCount+")")):t.list=t.list.concat(o),setTimeout((function(e){i.data.fansList.length<t.pageSize?(t.finished=!0,t.loadStatus="nomore"):t.loadStatus="loadmore"}),500)}else e.showToast({title:i.message,icon:"none"})}))},goMyhome:function(t){e.navigateTo({url:"../subPage/myHome?uid="+t})}}};t.default=i}).call(this,n(1).default)},738:function(e,t,n){"use strict";n.r(t);var s=n(739),i=n.n(s);for(var o in s)"default"!==o&&function(e){n.d(t,e,(function(){return s[e]}))}(o);t.default=i.a},739:function(e,t,n){}},[[732,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/myFans.js'});require("pages/pageRelay/myFans.js");