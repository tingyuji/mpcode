$gwx0_XC_42=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_42 || [];
function gz$gwx0_XC_42_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_42_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_42_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_42_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'home_tz data-v-8fd9dc66'])
Z([3,'fixed-b data-v-8fd9dc66'])
Z([[8],'color',[1,'#07c160']])
Z([3,'#f4f4f4'])
Z([3,'__l'])
Z([3,'__e'])
Z(z[5])
Z(z[5])
Z([3,'data-v-8fd9dc66'])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^blur']],[[4],[[5],[[4],[[5],[1,'searchFun']]]]]]]],[[4],[[5],[[5],[1,'^search']],[[4],[[5],[[4],[[5],[1,'searchFun']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'activityName']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'64'])
Z([3,'搜索活动'])
Z([3,'round'])
Z([1,false])
Z([[7],[3,'activityName']])
Z([3,'4a4fa8d9-1'])
Z([3,'#07c160'])
Z([3,'4'])
Z([3,'f2f2f3'])
Z(z[4])
Z(z[5])
Z(z[13])
Z(z[8])
Z([[7],[3,'currentShequn']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'changeShequn']]]]]]]]])
Z([3,'70'])
Z([3,'#999'])
Z(z[13])
Z([[7],[3,'listShequn']])
Z([3,'4a4fa8d9-2'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityLi']])
Z(z[30])
Z([3,'shop_infos data-v-8fd9dc66'])
Z(z[5])
Z([3,'shop_tit data-v-8fd9dc66'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goCode']],[[4],[[5],[[5],[1,'../subPage/showRel']],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]],[[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z(z[5])
Z([3,'shop_img fl data-v-8fd9dc66'])
Z(z[37])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'imgArrs']],[1,1]])
Z(z[46])
Z([3,'btn_row fl data-v-8fd9dc66'])
Z([3,'flex:1;'])
Z([[6],[[7],[3,'item']],[3,'promoCodeCount']])
Z(z[5])
Z([3,'ri_bttn data-v-8fd9dc66'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'openShare']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'activityLi']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z(z[4])
Z(z[8])
Z(z[16])
Z([3,'weixin-fill'])
Z([3,'32'])
Z([[2,'+'],[1,'4a4fa8d9-3-'],[[7],[3,'index']]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'logisticsWay']],[1,'2']])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'deliveryStatus']],[1,2]])
Z(z[4])
Z(z[5])
Z(z[5])
Z([[8],'fontWeight',[1,'500']])
Z(z[8])
Z(z[16])
Z(z[65])
Z([3,'确认'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'aaaTs']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'trueDl']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,true])
Z([3,'自提配送服务'])
Z([[7],[3,'trueDl']])
Z([3,'4a4fa8d9-4'])
Z([[4],[[5],[1,'default']]])
Z(z[4])
Z(z[5])
Z(z[5])
Z(z[8])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'clickAct']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showAct']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'actionList']])
Z([[7],[3,'showAct']])
Z([3,'4a4fa8d9-5'])
Z([[7],[3,'showShares']])
Z(z[4])
Z(z[5])
Z(z[5])
Z([3,'zuj_fix data-v-8fd9dc66'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'4a4fa8d9-6'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_42_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_42_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_42=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_42=true;
var x=['./pages/pageRelay/relingList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_42_1()
var hQS=_n('view')
_rz(z,hQS,'class',0,e,s,gg)
var cSS=_n('view')
_rz(z,cSS,'class',1,e,s,gg)
var oTS=_mz(z,'u-search',['actionStyle',2,'bgColor',1,'bind:__l',2,'bind:blur',3,'bind:input',4,'bind:search',5,'class',6,'data-event-opts',7,'height',8,'placeholder',9,'shape',10,'showAction',11,'value',12,'vueId',13],[],e,s,gg)
_(cSS,oTS)
var lUS=_mz(z,'u-tabs',['activeColor',16,'barHeight',1,'bgColor',2,'bind:__l',3,'bind:change',4,'bold',5,'class',6,'current',7,'data-event-opts',8,'height',9,'inactiveColor',10,'isScroll',11,'list',12,'vueId',13],[],e,s,gg)
_(cSS,lUS)
_(hQS,cSS)
var aVS=_v()
_(hQS,aVS)
var tWS=function(bYS,eXS,oZS,gg){
var o2S=_n('view')
_rz(z,o2S,'class',34,bYS,eXS,gg)
var h5S=_mz(z,'view',['bindtap',35,'class',1,'data-event-opts',2],[],bYS,eXS,gg)
var o6S=_v()
_(h5S,o6S)
if(_oz(z,38,bYS,eXS,gg)){o6S.wxVkey=1
}
var c7S=_v()
_(h5S,c7S)
if(_oz(z,39,bYS,eXS,gg)){c7S.wxVkey=1
}
else{c7S.wxVkey=2
var o8S=_v()
_(c7S,o8S)
if(_oz(z,40,bYS,eXS,gg)){o8S.wxVkey=1
}
o8S.wxXCkey=1
}
o6S.wxXCkey=1
c7S.wxXCkey=1
_(o2S,h5S)
var f3S=_v()
_(o2S,f3S)
if(_oz(z,41,bYS,eXS,gg)){f3S.wxVkey=1
var l9S=_mz(z,'view',['bindtap',42,'class',1,'data-event-opts',2],[],bYS,eXS,gg)
var a0S=_v()
_(l9S,a0S)
if(_oz(z,45,bYS,eXS,gg)){a0S.wxVkey=1
}
var tAT=_v()
_(l9S,tAT)
if(_oz(z,46,bYS,eXS,gg)){tAT.wxVkey=1
}
var eBT=_v()
_(l9S,eBT)
if(_oz(z,47,bYS,eXS,gg)){eBT.wxVkey=1
}
a0S.wxXCkey=1
tAT.wxXCkey=1
eBT.wxXCkey=1
_(f3S,l9S)
}
var bCT=_mz(z,'view',['class',48,'style',1],[],bYS,eXS,gg)
var oDT=_v()
_(bCT,oDT)
if(_oz(z,50,bYS,eXS,gg)){oDT.wxVkey=1
}
var xET=_mz(z,'view',['bindtap',51,'class',1,'data-event-opts',2],[],bYS,eXS,gg)
var oFT=_mz(z,'u-icon',['bind:__l',54,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],bYS,eXS,gg)
_(xET,oFT)
_(bCT,xET)
oDT.wxXCkey=1
_(o2S,bCT)
var c4S=_v()
_(o2S,c4S)
if(_oz(z,60,bYS,eXS,gg)){c4S.wxVkey=1
var fGT=_v()
_(c4S,fGT)
if(_oz(z,61,bYS,eXS,gg)){fGT.wxVkey=1
}
fGT.wxXCkey=1
}
f3S.wxXCkey=1
c4S.wxXCkey=1
_(oZS,o2S)
return oZS
}
aVS.wxXCkey=4
_2z(z,32,tWS,e,s,gg,aVS,'item','index','index')
var cHT=_mz(z,'u-modal',['bind:__l',62,'bind:confirm',1,'bind:input',2,'cancelStyle',3,'class',4,'confirmColor',5,'confirmStyle',6,'confirmText',7,'data-event-opts',8,'showCancelButton',9,'title',10,'value',11,'vueId',12,'vueSlots',13],[],e,s,gg)
_(hQS,cHT)
var hIT=_mz(z,'u-action-sheet',['bind:__l',76,'bind:click',1,'bind:input',2,'class',3,'data-event-opts',4,'list',5,'value',6,'vueId',7],[],e,s,gg)
_(hQS,hIT)
var oRS=_v()
_(hQS,oRS)
if(_oz(z,84,e,s,gg)){oRS.wxVkey=1
var oJT=_mz(z,'dc-hiro-painter',['bind:__l',85,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(oRS,oJT)
}
oRS.wxXCkey=1
oRS.wxXCkey=3
_(r,hQS)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_42";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_42();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/relingList.wxml'] = [$gwx0_XC_42, './pages/pageRelay/relingList.wxml'];else __wxAppCode__['pages/pageRelay/relingList.wxml'] = $gwx0_XC_42( './pages/pageRelay/relingList.wxml' );
	;__wxRoute = "pages/pageRelay/relingList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/relingList.js";define("pages/pageRelay/relingList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/relingList"],{276:function(t,e,i){"use strict";(function(t){i(5),n(i(4));var e=n(i(277));function n(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=i,t(e.default)}).call(this,i(1).createPage)},277:function(t,e,i){"use strict";i.r(e);var n=i(278),o=i(280);for(var a in o)"default"!==a&&function(t){i.d(e,t,(function(){return o[t]}))}(a);i(282);var s=i(17),c=Object(s.default)(o.default,n.render,n.staticRenderFns,!1,null,"8fd9dc66",null,!1,n.components,void 0);c.options.__file="pages/pageRelay/relingList.vue",e.default=c.exports},278:function(t,e,i){"use strict";i.r(e);var n=i(279);i.d(e,"render",(function(){return n.render})),i.d(e,"staticRenderFns",(function(){return n.staticRenderFns})),i.d(e,"recyclableRender",(function(){return n.recyclableRender})),i.d(e,"components",(function(){return n.components}))},279:function(t,e,i){"use strict";var n;i.r(e),i.d(e,"render",(function(){return o})),i.d(e,"staticRenderFns",(function(){return s})),i.d(e,"recyclableRender",(function(){return a})),i.d(e,"components",(function(){return n}));try{n={uSearch:function(){return i.e("uview-ui/components/u-search/u-search").then(i.bind(null,925))},uTabs:function(){return Promise.all([i.e("common/vendor"),i.e("uview-ui/components/u-tabs/u-tabs")]).then(i.bind(null,996))},uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uModal:function(){return i.e("uview-ui/components/u-modal/u-modal").then(i.bind(null,961))},uActionSheet:function(){return i.e("uview-ui/components/u-action-sheet/u-action-sheet").then(i.bind(null,896))},dcHiroPainter:function(){return i.e("components/dc-hiro-painter/dc-hiro-painter").then(i.bind(null,875))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},a=!1,s=[];o._withStripped=!0},280:function(t,e,i){"use strict";i.r(e);var n=i(281),o=i.n(n);for(var a in n)"default"!==a&&function(t){i.d(e,t,(function(){return n[t]}))}(a);e.default=o.a},281:function(t,e,i){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n=function(t){return t&&t.__esModule?t:{default:t}}(i(61)),o={data:function(){return{trueDl:!1,operId:"",activityName:"",currentShequn:0,listShequn:[{name:"全部"},{name:"团购中"},{name:"待发布"},{name:"已结束"}],showMenu:!1,showAct:!1,menuStyle:{},shareObj:{},showShares:!1,showSharesBox:!1,shareImgMini:"",countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},picListInfo:{titleName:"",picItemList:[]},activityLi:[],nickName:"",activityOwnLi:[],checkActivityId:0,actionList:[{text:"开启团购"},{text:"开启售后权益保障"},{text:"隐藏团购"},{text:"暂停团购"},{text:"结束团购"},{text:"删除团购"},{text:"置顶团购"},{text:"取消置顶"}],page:1,finished:!1,noData:!1,activityEle:{}}},onShareAppMessage:function(e){var i=this,n={title:(t.getStorageSync("userInfo")||{}).nickName+"给您推荐了一个群优选团购",path:"/pages/subPage/showRel",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(t){t.errMsg},fail:function(){"shareAppMessage:fail cancel"==res.errMsg||res.errMsg}};if("button"==e.from){var o=e.target.dataset;console.log("eData.name ==",o.name),i=this,n.imageUrl=i.shareImgMini,n.title=i.shareObj.title,n.path="/pages/subPage/showRel?"+i.shareObj.shareScene}return n},computed:{getIcon:function(){}},onShow:function(){},onReachBottom:function(){this.finished||(this.page++,this.actAllList())},onLoad:function(){t.hideShareMenu({}),this.actAllList(),this.userInfoHome=t.getStorageSync("userInfo")||{}},methods:{showMode:function(e,i){t.showModal({title:e,content:i,showCancel:!1})},searchFun:function(){console.log("触发搜索=="),this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.actAllList()},changeShequn:function(t){this.currentShequn=t,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.actAllList()},shareUrl:function(t){this.shareImgMini=t},closeShare:function(t){console.log("关闭分享弹窗==",t),this.showShares=!1},openShare:function(e){t.showLoading({title:"加载中",mask:!0}),this.shareObj.title=e.activityName,this.shareObj.freezeFlag=e.freezeFlag,this.shareObj.activityId=e.activityId,this.shareObj.headImg=e.headImg||"http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",this.shareObj.nickName=e.nickName||"群优选用户",this.shareObj.createTime=e.createTime.slice(0,10),this.shareObj.maxSellPriceShow="¥"+e.maxSellPriceShow,this.shareObj.shareBtn="我要团购",this.shareObj.shareScene="id="+e.activityId+"&uid="+this.userInfoHome.userId,this.shareObj.adminUserId=e.userId,e.imgArrs?this.shareObj.imgUrls=e.shareImgs:this.shareObj.imgUrls=[],e.orderInfos.length?this.shareObj.rankList=e.orderInfos:this.shareObj.rankList=!1,this.showShares=!0,setTimeout((function(e){t.hideLoading()}),3e3)},showMoring:function(t,e){this.activityEle=JSON.parse(JSON.stringify(t)),this.activityEle.indexRej=e,this.showAct=!0},showMols:function(e,i){var n=this;1==i?(this.operId=e,this.trueDl=!0):t.showModal({title:"关闭配送服务",content:"商品是否已送达，请在商品已送达后再关闭配送服务",confirmText:"已送达",cancelText:"取消",confirmColor:"#07c160",success:function(i){i.cancel?console.log("用户点击取消"):i.confirm&&n.$server.operDelLocation({activityId:e}).then((function(e){0==e.code?(t.showToast({title:"已关闭配送服务",icon:"none"}),n.page=1,n.noData&&(n.noData=!1),n.finished&&(n.finished=!1),n.actAllList()):t.showToast({title:e.message,icon:"none"})}))}})},getLoctions:function(e,i){var n=this;t.getLocation({type:"gcj02",isHighAccuracy:!0,success:function(o){console.log("当前位置的经度："+o.longitude),console.log("当前位置的纬度："+o.latitude),n.$server.operRptLocation({activityId:e,longitude:o.longitude,latitude:o.latitude}).then((function(e){0==e.code?(i?t.showToast({title:"同步成功",icon:"success"}):(n.page=1,n.noData&&(n.noData=!1),n.finished&&(n.finished=!1),n.actAllList()),n.operId=""):t.showToast({title:e.message,icon:"none"})}))},fail:function(e){t.showToast({title:"获取位置失败，请检查是否打开或授权位置信息",icon:"none",duration:2500})}})},aaaTs:function(){var e=this;this.$server.operStartLocation({activityId:this.operId}).then((function(i){0==i.code?(t.showToast({title:"开启成功",icon:"success"}),e.getLoctions(e.operId)):t.showToast({title:i.message,icon:"none"})}))},clickAct:function(e){console.log("eee==",e);var i=this;if(1==e)return 2==this.activityEle.freezeFlag?(t.showToast({title:"该活动已开启售后权益保障",icon:"none",duration:3e3}),!1):(t.showModal({title:"开启售后权益保障",content:"开启平台担保交易，提升客户对团购的信任，确保售后无忧，订单资金将在客户确认收货后，或满5天后，自动结算至可提现余额",confirmText:"确认",cancelText:"取消",confirmColor:"#07c160",success:function(t){t.cancel?console.log("用户点击取消"):t.confirm&&i.freezeFlagSwitch(2)}}),!1);var n=2;0!=e&&(n=e+1);var o="是否确认"+this.actionList[e].text,a="请确认是否"+this.actionList[e].text,s="#07c160",c="确定";5==e?(a="只能恢复近30天内删除的团购",s="#ff4d4d",c="删除"):3==e&&(a="暂停团购后，用户将不能下单",s="#ff4d4d",c="暂停"),t.showModal({title:o,content:a,confirmText:c,cancelText:"取消",confirmColor:s,success:function(t){t.cancel?console.log("用户点击取消"):t.confirm&&(e>=6?i.topOrCancel(e):i.updateStatus(n))}})},goOrder:function(e){t.navigateTo({url:"../subPage/showRel?id="+e})},goEdit:function(e){t.navigateTo({url:"../solitaire/issueRelayPlus?id="+e})},goCode:function(e,i,n){n?t.navigateTo({url:e+"?id="+i+"&types="+n}):t.navigateTo({url:e+"?id="+i})},switchTa:function(e){t.switchTab({url:e})},goPage:function(e){if(!e)return t.showToast({title:"暂未开放",icon:"none"}),!1;t.navigateTo({url:"../subPage/"+e})},actAllList:function(){var e=this,i="";1==this.currentShequn?i=2:2==this.currentShequn?i=1:3==this.currentShequn&&(i=5);var o={page:this.page,pageSize:10,actStatus:i,activityName:this.activityName};this.$server.actOwnList(o).then((function(i){if(0==i.code){if(1==e.page&&0==i.data.length)return e.finished=!0,void console.log("无数据");i.data.length<10&&(e.loading=!1,e.finished=!0,console.log("无更多数据"));var o=i.data.map((function(t){if(t.activityDetails.length){var e="";t.activityDetails.forEach((function(i){1==i.contentType?t.showTexts=i.activityDetail:(2==i.contentType||5==i.contentType)&&(e=0!=e.length?e+","+i.activityDetail:i.activityDetail)})),0!=e.length?(console.log("cur.imgArrs==",e),t.shareImgs=e.split(","),t.imgArrs=e.split(",",3),console.log("cur.imgArrs==",t.imgArrs)):t.imgArrs=!1}else t.imgArrs=!1;return t.orderInfos.length&&t.orderInfos.forEach((function(t){t.differTime=n.default.getDifferTime(t.createTime,!1),t.nickName?t.nickName=t.nickName.slice(0,1)+"**":t.nickName="**"})),2==t.freezeFlag?t.activityNameShow="&emsp;&emsp;&emsp;&emsp;&emsp;"+t.activityName:t.activityNameShow=t.activityName,t.maxSellPriceShow=n.default.centTurnSmacker(t.minMaxPrice.maxSellPrice/100),t.statisticDataVO.totalMoney=n.default.centTurnSmacker(t.statisticDataVO.totalMoney/100),t.activityStatusTex=["正在团购","团购待发布","正在团购","团购已隐藏","团购已暂停","团购已结束","团购已删除"][t.activityStatus],t}));1==e.page?e.activityLi=o:e.activityLi=e.activityLi.concat(o)}else t.showToast({title:i.message,icon:"none"})}))},updateStatus:function(e){var i=this;this.$server.updateStatus({activityId:this.activityEle.activityId,status:e}).then((function(e){0==e.code?(t.showToast({title:"操作成功",icon:"success"}),i.page=1,i.noData&&(i.noData=!1),i.finished&&(i.finished=!1),i.actAllList()):t.showToast({title:e.message,icon:"none"})}))},topOrCancel:function(e){var i=this;this.$server.topOrCancel({activityId:this.activityEle.activityId,operatorType:e-5}).then((function(e){0==e.code?(t.showToast({title:"操作成功",icon:"success"}),i.page=1,i.noData&&(i.noData=!1),i.finished&&(i.finished=!1),i.actAllList()):t.showToast({title:e.message,icon:"none"})}))},freezeFlagSwitch:function(e){var i=this;this.$server.freezeFlagSwitch({activityId:this.activityEle.activityId,changeFlag:e}).then((function(e){0==e.code?(t.showToast({title:"开启成功",icon:"success"}),i.activityLi[i.activityEle.indexRej].freezeFlag=2):t.showToast({title:e.message,icon:"none"})}))}}};e.default=o}).call(this,i(1).default)},282:function(t,e,i){"use strict";i.r(e);var n=i(283),o=i.n(n);for(var a in n)"default"!==a&&function(t){i.d(e,t,(function(){return n[t]}))}(a);e.default=o.a},283:function(t,e,i){}},[[276,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/relingList.js'});require("pages/pageRelay/relingList.js");