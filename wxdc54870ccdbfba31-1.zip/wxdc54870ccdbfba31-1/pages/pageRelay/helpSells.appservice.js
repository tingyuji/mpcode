$gwx0_XC_25=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_25 || [];
function gz$gwx0_XC_25_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_25_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_25_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_25_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-15c217aa'])
Z([3,'width:100%;padding-bottom:200rpx;box-sizing:border-box;'])
Z([3,'sai_xans fl_sb data-v-15c217aa'])
Z([3,'__e'])
Z([3,'let_bm fl data-v-15c217aa'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'searchChange']],[[4],[[5],[1,1]]]]]]]]]]])
Z([[2,'||'],[[2,'=='],[[7],[3,'searchStatus']],[1,1]],[[2,'>'],[[7],[3,'searchStatus']],[1,3]]])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,2]])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,3]])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'searchChange']],[[4],[[5],[1,2]]]]]]]]]]])
Z([[2,'||'],[[2,'=='],[[7],[3,'searchStatus']],[1,4]],[[2,'<'],[[7],[3,'searchStatus']],[1,4]]])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,5]])
Z([[2,'=='],[[7],[3,'searchStatus']],[1,6]])
Z([3,'record-list data-v-15c217aa'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[16])
Z(z[3])
Z([3,'fbbs data-v-15c217aa'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imcImC']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]],[1,'helpUserId']]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'unReadMsgCount']])
Z([3,'__l'])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'bafd42c8-1'])
Z([[7],[3,'showShares']])
Z(z[24])
Z(z[3])
Z(z[3])
Z([3,'zuj_fix data-v-15c217aa'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'bafd42c8-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_25_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_25_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_25=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_25=true;
var x=['./pages/pageRelay/helpSells.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_25_1()
var eXL=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oZL=_n('view')
_rz(z,oZL,'class',2,e,s,gg)
var x1L=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var o2L=_v()
_(x1L,o2L)
if(_oz(z,6,e,s,gg)){o2L.wxVkey=1
}
else{o2L.wxVkey=2
var f3L=_v()
_(o2L,f3L)
if(_oz(z,7,e,s,gg)){f3L.wxVkey=1
}
else{f3L.wxVkey=2
var c4L=_v()
_(f3L,c4L)
if(_oz(z,8,e,s,gg)){c4L.wxVkey=1
}
c4L.wxXCkey=1
}
f3L.wxXCkey=1
}
o2L.wxXCkey=1
_(oZL,x1L)
var h5L=_mz(z,'view',['bindtap',9,'class',1,'data-event-opts',2],[],e,s,gg)
var o6L=_v()
_(h5L,o6L)
if(_oz(z,12,e,s,gg)){o6L.wxVkey=1
}
else{o6L.wxVkey=2
var c7L=_v()
_(o6L,c7L)
if(_oz(z,13,e,s,gg)){c7L.wxVkey=1
}
else{c7L.wxVkey=2
var o8L=_v()
_(c7L,o8L)
if(_oz(z,14,e,s,gg)){o8L.wxVkey=1
}
o8L.wxXCkey=1
}
c7L.wxXCkey=1
}
o6L.wxXCkey=1
_(oZL,h5L)
_(eXL,oZL)
var l9L=_n('view')
_rz(z,l9L,'class',15,e,s,gg)
var a0L=_v()
_(l9L,a0L)
var tAM=function(bCM,eBM,oDM,gg){
var oFM=_mz(z,'view',['bindtap',20,'class',1,'data-event-opts',2],[],bCM,eBM,gg)
var fGM=_v()
_(oFM,fGM)
if(_oz(z,23,bCM,eBM,gg)){fGM.wxVkey=1
}
fGM.wxXCkey=1
_(oDM,oFM)
return oDM
}
a0L.wxXCkey=2
_2z(z,18,tAM,e,s,gg,a0L,'item','index','index')
var cHM=_mz(z,'u-loadmore',['bind:__l',24,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(l9L,cHM)
_(eXL,l9L)
var bYL=_v()
_(eXL,bYL)
if(_oz(z,30,e,s,gg)){bYL.wxVkey=1
var hIM=_mz(z,'dc-hiro-painter',['bind:__l',31,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(bYL,hIM)
}
bYL.wxXCkey=1
bYL.wxXCkey=3
_(r,eXL)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_25";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_25();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/helpSells.wxml'] = [$gwx0_XC_25, './pages/pageRelay/helpSells.wxml'];else __wxAppCode__['pages/pageRelay/helpSells.wxml'] = $gwx0_XC_25( './pages/pageRelay/helpSells.wxml' );
	;__wxRoute = "pages/pageRelay/helpSells";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/helpSells.js";define("pages/pageRelay/helpSells.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/helpSells"],{594:function(e,t,s){"use strict";(function(e){s(5),n(s(4));var t=n(s(595));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=s,e(t.default)}).call(this,s(1).createPage)},595:function(e,t,s){"use strict";s.r(t);var n=s(596),o=s(598);for(var a in o)"default"!==a&&function(e){s.d(t,e,(function(){return o[e]}))}(a);s(600);var r=s(17),i=Object(r.default)(o.default,n.render,n.staticRenderFns,!1,null,"15c217aa",null,!1,n.components,void 0);i.options.__file="pages/pageRelay/helpSells.vue",t.default=i.exports},596:function(e,t,s){"use strict";s.r(t);var n=s(597);s.d(t,"render",(function(){return n.render})),s.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),s.d(t,"recyclableRender",(function(){return n.recyclableRender})),s.d(t,"components",(function(){return n.components}))},597:function(e,t,s){"use strict";var n;s.r(t),s.d(t,"render",(function(){return o})),s.d(t,"staticRenderFns",(function(){return r})),s.d(t,"recyclableRender",(function(){return a})),s.d(t,"components",(function(){return n}));try{n={uLoadmore:function(){return s.e("uview-ui/components/u-loadmore/u-loadmore").then(s.bind(null,861))},dcHiroPainter:function(){return s.e("components/dc-hiro-painter/dc-hiro-painter").then(s.bind(null,875))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){this.$createElement,this._self._c},a=!1,r=[];o._withStripped=!0},598:function(e,t,s){"use strict";s.r(t);var n=s(599),o=s.n(n);for(var a in n)"default"!==a&&function(e){s.d(t,e,(function(){return n[e]}))}(a);t.default=o.a},599:function(e,t,s){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n=function(e){return e&&e.__esModule?e:{default:e}}(s(61)),o={data:function(){return{userInfos:{},shareObj:{},showShares:!1,searchStatus:2,showAct:!1,ctrlUserId:"",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多社群"},loadStatus:"loading",page:1,pageSize:20,pageStatu:0,shareImgMini:""}},onLoad:function(t){var s=this;console.log("onLoad"),e.hideShareMenu({});var n=this,o=e.getStorageSync("userInfo")||{};if(this.userInfos=o,t.type){if(2==o.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录groupList",o.userType),s.comunityList()}),800),!1;wx.login({success:function(t){t.code&&n.$server.login({agentId:n.$agentId,code:t.code}).then((function(t){var s=t;e.setStorageSync("userInfo",s),n.comunityList()}))}})}else n.comunityList()},onShareAppMessage:function(t){e.getStorageSync("userInfo");var s={title:this.userInfos.nickName+"邀请你成为Ta的帮卖团长，轻松赚取佣金",path:"/pages/subPage/myHome",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/bmshares.png",success:function(e){e.errMsg}};return"button"==t.from&&(t.target.dataset,s.imageUrl=this.shareImgMini,s.path="/pages/subPage/myHome?"+this.shareObj.shareScene),s},onShow:function(){},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.comunityList())},methods:{shareUrl:function(e){this.shareImgMini=e},closeShare:function(e){console.log("关闭分享弹窗==",e),this.showShares=!1,this.shareObj={}},shareHelpOpen:function(){e.showLoading({title:"加载中",mask:!0}),this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.memberCount=this.userInfos.memberCount||"1",this.shareObj.solitaireCount=this.userInfos.solitaireCount||"0",this.shareObj.introduction="加入帮卖轻松赚取佣金",this.shareObj.shareScene="z=1&uid="+this.userInfos.userId,this.shareObj.bmtzShare=1,this.showShares=!0,setTimeout((function(t){e.hideLoading()}),2e3)},cancalHelp:function(t){var s=this;e.showModal({title:"是否取消帮卖团长身份",content:"解除后该团长将无法为你帮卖，请谨慎操作",confirmText:"确认",confirmColor:"#07c160",cancelColor:"#999",success:function(n){n.confirm?s.$server.removeHelpSellUser({helpUserId:t}).then((function(t){0==t.code?(e.showToast({title:"已取消该帮卖团长",icon:"none"}),s.page=1,s.list=[],s.comunityList()):e.showToast({title:t.message,icon:"none"})})):n.cancel&&console.log("用户点击取消")}})},searchChange:function(e){1==e?1==this.searchStatus||this.searchStatus>3?this.searchStatus=2:2==this.searchStatus?this.searchStatus=3:3==this.searchStatus&&(this.searchStatus=2):4==this.searchStatus||this.searchStatus<4?this.searchStatus=5:5==this.searchStatus?this.searchStatus=6:6==this.searchStatus&&(this.searchStatus=5),this.finished=!1,this.page=1,this.list=[],this.comunityList()},comunityList:function(){var e=this,t={page:this.page,pageSize:20};2==this.searchStatus?(t.sortType=1,t.sortWay="desc"):3==this.searchStatus?(t.sortType=1,t.sortWay="asc"):5==this.searchStatus?(t.sortType=2,t.sortWay="desc"):6==this.searchStatus&&(t.sortType=2,t.sortWay="asc"),this.$server.userHelpSellList(t).then((function(t){if(null!=t&&0==t.code){var s=t.data.map((function(e){return e.headImg&&e.headImg.includes("http")||(e.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),e.lastAccessTime?(e.lastAccessTime=e.lastAccessTime.replace(/-/g,"/").replace("T"," "),e.days=Math.ceil((Date.parse(new Date)-new Date(e.lastAccessTime))/864e5)):e.days=30,e.tradeAmount=n.default.centTurnSmacker(e.tradeAmount/100),e.monthAmount=n.default.centTurnSmacker(e.monthAmount/100),e}));e.list=e.list.concat(s),setTimeout((function(s){t.data.length<e.pageSize?(e.finished=!0,e.loadStatus="nomore"):e.loadStatus="loadmore"}),500)}}))},goMyhome:function(t){e.navigateTo({url:"../subPage/myHome?uid="+t})}}};t.default=o}).call(this,s(1).default)},600:function(e,t,s){"use strict";s.r(t);var n=s(601),o=s.n(n);for(var a in n)"default"!==a&&function(e){s.d(t,e,(function(){return n[e]}))}(a);t.default=o.a},601:function(e,t,s){}},[[594,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/helpSells.js'});require("pages/pageRelay/helpSells.js");