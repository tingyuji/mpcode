$gwx0_XC_45=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_45 || [];
function gz$gwx0_XC_45_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_45_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_45_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_45_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'data-v-b7517cb2'])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'32dd1782-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_45_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_45_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_45=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_45=true;
var x=['./pages/pageRelay/shareList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_45_1()
var oZT=_mz(z,'u-loadmore',['bind:__l',0,'class',1,'loadText',1,'marginTop',2,'status',3,'vueId',4],[],e,s,gg)
_(r,oZT)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_45";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_45();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/shareList.wxml'] = [$gwx0_XC_45, './pages/pageRelay/shareList.wxml'];else __wxAppCode__['pages/pageRelay/shareList.wxml'] = $gwx0_XC_45( './pages/pageRelay/shareList.wxml' );
	;__wxRoute = "pages/pageRelay/shareList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/shareList.js";define("pages/pageRelay/shareList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/shareList"],{554:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(555));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},555:function(e,n,t){"use strict";t.r(n);var o=t(556),r=t(558);for(var a in r)"default"!==a&&function(e){t.d(n,e,(function(){return r[e]}))}(a);t(560);var i=t(17),u=Object(i.default)(r.default,o.render,o.staticRenderFns,!1,null,"b7517cb2",null,!1,o.components,void 0);u.options.__file="pages/pageRelay/shareList.vue",n.default=u.exports},556:function(e,n,t){"use strict";t.r(n);var o=t(557);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},557:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return r})),t.d(n,"staticRenderFns",(function(){return i})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={uLoadmore:function(){return t.e("uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null,861))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){this.$createElement,this._self._c},a=!1,i=[];r._withStripped=!0},558:function(e,n,t){"use strict";t.r(n);var o=t(559),r=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=r.a},559:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),r={data:function(){return{showAct:!1,ctrlUserId:"",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多收益"},loadStatus:"loading",page:1,pageSize:20,pageStatu:0}},onLoad:function(n){console.log("onLoad"),e.hideShareMenu({}),e.getStorageSync("userInfo"),this.incomeBalance()},onShow:function(){console.log("woOnShow")},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.incomeBalance())},methods:{incomeBalance:function(){var n=this,t={page:this.page,pageSize:20};this.$server.incomeBalance(t).then((function(t){if(null!=t)if(0==t.code){var r=t.data.map((function(e){return e.headImg&&e.headImg.includes("http")||(e.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),e.profitAmount=o.default.centTurnSmacker(e.profitAmount/100),e}));n.list=n.list.concat(r),setTimeout((function(e){t.data.length<n.pageSize?(n.finished=!0,n.loadStatus="nomore"):n.loadStatus="loadmore"}),500)}else e.showToast({title:t.message,icon:"none"})}))},goMyhome:function(n){e.navigateTo({url:"./myHome?uid="+n})},opneMenu:function(e){this.ctrlUserId=e,this.showAct=!0}}};n.default=r}).call(this,t(1).default)},560:function(e,n,t){"use strict";t.r(n);var o=t(561),r=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=r.a},561:function(e,n,t){}},[[554,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/shareList.js'});require("pages/pageRelay/shareList.js");