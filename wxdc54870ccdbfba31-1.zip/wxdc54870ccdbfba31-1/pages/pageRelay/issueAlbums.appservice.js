$gwx0_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_26 || [];
function gz$gwx0_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'edit_detl data-v-1cc5c3b2'])
Z([3,'min-height:100vh;background-color:#f5f5f5;padding-top:16rpx;box-sizing:border-box;'])
Z([3,'inpu_bbx data-v-1cc5c3b2'])
Z([[7],[3,'autoHeight']])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-1cc5c3b2'])
Z([1,false])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'contentText']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'commodityData']]]]]]]]]]])
Z([3,'100'])
Z([3,'-1'])
Z([3,'这一刻的想法'])
Z([3,'textarea'])
Z([[6],[[7],[3,'commodityData']],[3,'contentText']])
Z([3,'420727bf-1'])
Z([[7],[3,'isRedays']])
Z(z[4])
Z(z[5])
Z(z[5])
Z(z[6])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^add']],[[4],[[5],[[4],[[5],[1,'addImage']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'imageData']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'9'])
Z([[7],[3,'mediaType']])
Z([[7],[3,'serverUrl']])
Z(z[7])
Z([[7],[3,'imageData']])
Z([3,'420727bf-2'])
Z(z[5])
Z([3,'jia_inu fl_sb data-v-1cc5c3b2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[4])
Z(z[6])
Z([3,'#c0c4cc'])
Z([3,'arrow-right'])
Z([3,'420727bf-3'])
Z(z[4])
Z(z[5])
Z(z[5])
Z(z[6])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'selectorChOne']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'selectorOne']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[4],[[5],[1,0]]])
Z([3,'selector'])
Z([[7],[3,'selectorDaIne']])
Z([[7],[3,'selectorOne']])
Z([3,'420727bf-4'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_26=true;
var x=['./pages/pageRelay/issueAlbums.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_26_1()
var cKM=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oLM=_n('view')
_rz(z,oLM,'class',2,e,s,gg)
var aNM=_mz(z,'u-input',['autoHeight',3,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'data-event-opts',5,'height',6,'maxlength',7,'placeholder',8,'type',9,'value',10,'vueId',11],[],e,s,gg)
_(oLM,aNM)
var lMM=_v()
_(oLM,lMM)
if(_oz(z,15,e,s,gg)){lMM.wxVkey=1
var tOM=_mz(z,'robby-image-upload',['bind:__l',16,'bind:add',1,'bind:input',2,'class',3,'data-event-opts',4,'limit',5,'mediaT',6,'serverUrl',7,'showUploadProgress',8,'value',9,'vueId',10],[],e,s,gg)
_(lMM,tOM)
}
var ePM=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2],[],e,s,gg)
var bQM=_mz(z,'u-icon',['bind:__l',30,'class',1,'color',2,'name',3,'vueId',4],[],e,s,gg)
_(ePM,bQM)
_(oLM,ePM)
lMM.wxXCkey=1
lMM.wxXCkey=3
_(cKM,oLM)
var oRM=_mz(z,'u-picker',['bind:__l',35,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'defaultSelector',5,'mode',6,'range',7,'value',8,'vueId',9],[],e,s,gg)
_(cKM,oRM)
_(r,cKM)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/issueAlbums.wxml'] = [$gwx0_XC_26, './pages/pageRelay/issueAlbums.wxml'];else __wxAppCode__['pages/pageRelay/issueAlbums.wxml'] = $gwx0_XC_26( './pages/pageRelay/issueAlbums.wxml' );
	;__wxRoute = "pages/pageRelay/issueAlbums";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/issueAlbums.js";define("pages/pageRelay/issueAlbums.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/issueAlbums"],{722:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(723));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},723:function(e,n,t){"use strict";t.r(n);var o=t(724),i=t(726);for(var a in i)"default"!==a&&function(e){t.d(n,e,(function(){return i[e]}))}(a);t(728),t(730);var u=t(17),s=Object(u.default)(i.default,o.render,o.staticRenderFns,!1,null,"1cc5c3b2",null,!1,o.components,void 0);s.options.__file="pages/pageRelay/issueAlbums.vue",n.default=s.exports},724:function(e,n,t){"use strict";t.r(n);var o=t(725);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},725:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return i})),t.d(n,"staticRenderFns",(function(){return u})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={uInput:function(){return Promise.all([t.e("common/vendor"),t.e("uview-ui/components/u-input/u-input")]).then(t.bind(null,910))},robbyImageUpload:function(){return t.e("components/robby-image-upload/robby-image-upload").then(t.bind(null,918))},uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))},uPicker:function(){return Promise.all([t.e("common/vendor"),t.e("uview-ui/components/u-picker/u-picker")]).then(t.bind(null,1017))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(n){e.selectorOne=!0})},a=!1,u=[];i._withStripped=!0},726:function(e,n,t){"use strict";t.r(n);var o=t(727),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},727:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={components:{robbyImageUpload:function(){t.e("components/robby-image-upload/robby-image-upload").then(function(){return resolve(t(918))}.bind(null,t)).catch(t.oe)}},data:function(){return{isRedays:!1,isChecking:!0,isCheckingLong:!1,autoHeight:!0,commodityDetail:"",commodityName:"",commodityData:{id:"",contentText:"",albumsStatus:2,showFlag:1,albumsDetails:[]},mediaType:1,indexType:1,serverUrl:"https://up-z2.qiniup.com",imageData:[],xzBuyNum:"公开：所有粉丝可见",selectorOne:!1,selectorDaIne:["公开：所有粉丝可见","私密：仅自己可见"],id:"",activityOwner:2,commId:"",qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""}}},onShow:function(){},onLoad:function(n){e.showLoading({title:"加载中",mask:!0}),setTimeout((function(){}),1e3),this.getQiniuToken(),e.hideShareMenu({}),console.log("详情取值",n),n.id?(this.id=n.id,this.activityOwner=n.own,this.queryAlbums()):this.isRedays=!0},methods:{getQiniuToken:function(){var n=this;this.$server.qiniuToken({}).then((function(t){"0"==t.code?(n.qiniuInfo=t.data,setTimeout((function(){e.hideLoading()}),1200),e.setStorageSync("qiniuInfo",t.data)):console.log("qiniu==",t)}))},selectorChOne:function(e){console.log("e===",e);var n=e[0];this.xzBuyNum=this.selectorDaIne[n],this.commodityData.showFlag=n+1},addImage:function(e){console.log("addImage ==",e)},queryAlbums:function(){var n=this;this.$server.queryAlbums({albumsId:this.id}).then((function(t){if(0==t.code){var o=t.data;t.data.albumsDetails.length&&(n.imageData=t.data.albumsDetails[0].albumsDetail.split(","),n.commId=t.data.albumsDetails[0].id,n.mediaType=t.data.albumsDetails[0].contentType),o.albumsDetails=[],n.commodityData=o,n.isRedays=!0}else e.showToast({title:t.message,icon:"none"})}))},gobacks:function(){var n=JSON.parse(JSON.stringify(this.commodityData));this.imageData.length&&(this.imageData[0].includes(".mp4")||this.imageData[0].includes(".m3u8")?n.albumsDetails.push({contentType:3,contentSort:1,albumsDetail:this.imageData.join(),id:this.commId}):n.albumsDetails.push({contentType:1,contentSort:1,albumsDetail:this.imageData.join(),id:this.commId})),this.id&&1==this.activityOwner?this.$server.updateAlbums(n).then((function(n){0==n.code?(e.showToast({title:"修改成功",icon:"success"}),setTimeout((function(){e.reLaunch({url:"../example/home"})}),1e3)):e.showToast({title:n.message,icon:"none"})})):(n.id&&(n.id=""),this.$server.createAlbums(n).then((function(n){0==n.code?(e.showToast({title:"相册发布成功",icon:"success"}),setTimeout((function(){e.reLaunch({url:"../example/home"})}),1e3)):e.showToast({title:n.message,icon:"none"})})))}}};n.default=o}).call(this,t(1).default)},728:function(e,n,t){"use strict";t.r(n);var o=t(729),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},729:function(e,n,t){},730:function(e,n,t){"use strict";t.r(n);var o=t(731),i=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=i.a},731:function(e,n,t){}},[[722,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/issueAlbums.js'});require("pages/pageRelay/issueAlbums.js");