$gwx0_XC_44=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_44 || [];
function gz$gwx0_XC_44_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_44_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_44_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_44_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_44_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_44_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_44=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_44=true;
var x=['./pages/pageRelay/shareFund.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_44_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_44";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_44();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/shareFund.wxml'] = [$gwx0_XC_44, './pages/pageRelay/shareFund.wxml'];else __wxAppCode__['pages/pageRelay/shareFund.wxml'] = $gwx0_XC_44( './pages/pageRelay/shareFund.wxml' );
	;__wxRoute = "pages/pageRelay/shareFund";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/shareFund.js";define("pages/pageRelay/shareFund.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/shareFund"],{544:function(e,n,t){"use strict";(function(e){t(5),r(t(4));var n=r(t(545));function r(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},545:function(e,n,t){"use strict";t.r(n);var r=t(546),u=t(548);for(var a in u)"default"!==a&&function(e){t.d(n,e,(function(){return u[e]}))}(a);t(550),t(552);var o=t(17),c=Object(o.default)(u.default,r.render,r.staticRenderFns,!1,null,"b31d6f64",null,!1,r.components,void 0);c.options.__file="pages/pageRelay/shareFund.vue",n.default=c.exports},546:function(e,n,t){"use strict";t.r(n);var r=t(547);t.d(n,"render",(function(){return r.render})),t.d(n,"staticRenderFns",(function(){return r.staticRenderFns})),t.d(n,"recyclableRender",(function(){return r.recyclableRender})),t.d(n,"components",(function(){return r.components}))},547:function(e,n,t){"use strict";t.r(n),t.d(n,"render",(function(){return r})),t.d(n,"staticRenderFns",(function(){return a})),t.d(n,"recyclableRender",(function(){return u})),t.d(n,"components",(function(){}));var r=function(){this.$createElement,this._self._c},u=!1,a=[];r._withStripped=!0},548:function(e,n,t){"use strict";t.r(n);var r=t(549),u=t.n(r);for(var a in r)"default"!==a&&function(e){t.d(n,e,(function(){return r[e]}))}(a);n.default=u.a},549:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),u={data:function(){return{balanceNum:0,settleAmount:0,totalAmount:0}},onShow:function(){this.getBalance(),e.hideShareMenu({})},methods:{openPage:function(e){this.$u.route({url:"/pages/library/"+e+"/index"})},goPage:function(n){1==n?e.navigateTo({url:"./shareList"}):2==n?e.navigateTo({url:"../pageRelay/qrcodeAgen"}):3==n?e.navigateTo({url:"../subPage/groupListKf"}):e.navigateTo({url:"../authIdCard/withdrawCard"})},getBalance:function(){var n=this;this.$server.userTotalIncome().then((function(t){0==t.code?(n.balanceNum=r.default.centTurnSmacker(t.data.unSettleAmount/100),n.settleAmount=r.default.centTurnSmacker(t.data.settleAmount/100),n.totalAmount=r.default.centTurnSmacker(t.data.totalAmount/100)):e.showToast({title:t.message,icon:"none"})}))}}};n.default=u}).call(this,t(1).default)},550:function(e,n,t){"use strict";t.r(n);var r=t(551),u=t.n(r);for(var a in r)"default"!==a&&function(e){t.d(n,e,(function(){return r[e]}))}(a);n.default=u.a},551:function(e,n,t){},552:function(e,n,t){"use strict";t.r(n);var r=t(553),u=t.n(r);for(var a in r)"default"!==a&&function(e){t.d(n,e,(function(){return r[e]}))}(a);n.default=u.a},553:function(e,n,t){}},[[544,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/shareFund.js'});require("pages/pageRelay/shareFund.js");