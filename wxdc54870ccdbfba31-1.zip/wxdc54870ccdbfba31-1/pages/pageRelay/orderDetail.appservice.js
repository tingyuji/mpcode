$gwx0_XC_34=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_34 || [];
function gz$gwx0_XC_34_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_34_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_34_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_34_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'my_fund data-v-3958f849'])
Z([3,'min-height:100vh;background-color:#f5f5f5;padding-bottom:140rpx;box-sizing:border-box;'])
Z([[7],[3,'pageLoadings']])
Z([3,'__l'])
Z([3,'zuj_fixlo data-v-3958f849'])
Z([3,'1c72dc46-1'])
Z([3,'wu_lius mis_box data-v-3958f849'])
Z([3,'v'])
Z([3,'u'])
Z([[6],[[7],[3,'orderData']],[3,'orderLogistics']])
Z(z[7])
Z([3,'__e'])
Z([3,'wliu_inf fl_sb data-v-3958f849'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goLosis']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'orderData.orderLogistics']],[1,'']],[[7],[3,'v']]]]]]]]]]]]]]]])
Z(z[3])
Z([3,'data-v-3958f849'])
Z([3,'#999'])
Z([3,'arrow-right'])
Z([3,'24'])
Z([[2,'+'],[1,'1c72dc46-2-'],[[7],[3,'v']]])
Z([3,'user_add data-v-3958f849'])
Z(z[3])
Z(z[15])
Z([3,'#9a9a9a'])
Z([3,'account-fill'])
Z([3,'30'])
Z([3,'1c72dc46-3'])
Z(z[7])
Z(z[8])
Z([[6],[[7],[3,'orderData']],[3,'orderRemarks']])
Z(z[7])
Z(z[3])
Z(z[15])
Z(z[23])
Z([3,'file-text-fill'])
Z(z[25])
Z([[2,'+'],[1,'1c72dc46-4-'],[[7],[3,'v']]])
Z([[6],[[6],[[7],[3,'orderData']],[3,'deliverImgs']],[3,'length']])
Z([[6],[[7],[3,'orderData']],[3,'shipFeeMoney']])
Z([3,'btn_row fl data-v-3958f849'])
Z([[2,'=='],[[7],[3,'typeIds']],[1,0]])
Z([[2,'=='],[[7],[3,'typeIds']],[1,1]])
Z(z[3])
Z(z[11])
Z([3,'14'])
Z(z[15])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRefund']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showRefund']])
Z([3,'1c72dc46-5'])
Z([[4],[[5],[1,'default']]])
Z([1,true])
Z(z[3])
Z(z[11])
Z(z[15])
Z([1,false])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'remarkRefund']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'200'])
Z([3,'-1'])
Z([3,'请输入您要的备注,双方可见'])
Z([3,'font-size:26rpx;'])
Z([3,'textarea'])
Z([[7],[3,'remarkRefund']])
Z([[2,'+'],[[2,'+'],[1,'1c72dc46-6'],[1,',']],[1,'1c72dc46-5']])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_34_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_34_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_34=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_34=true;
var x=['./pages/pageRelay/orderDetail.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_34_1()
var l5P=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var a6P=_v()
_(l5P,a6P)
if(_oz(z,2,e,s,gg)){a6P.wxVkey=1
var e8P=_mz(z,'page-loading',['bind:__l',3,'class',1,'vueId',2],[],e,s,gg)
_(a6P,e8P)
}
var b9P=_n('view')
_rz(z,b9P,'class',6,e,s,gg)
var xAQ=_v()
_(b9P,xAQ)
var oBQ=function(cDQ,fCQ,hEQ,gg){
var cGQ=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2],[],cDQ,fCQ,gg)
var oHQ=_mz(z,'u-icon',['bind:__l',14,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],cDQ,fCQ,gg)
_(cGQ,oHQ)
_(hEQ,cGQ)
return hEQ
}
xAQ.wxXCkey=4
_2z(z,9,oBQ,e,s,gg,xAQ,'u','v','v')
var lIQ=_n('view')
_rz(z,lIQ,'class',20,e,s,gg)
var aJQ=_mz(z,'u-icon',['bind:__l',21,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(lIQ,aJQ)
var tKQ=_v()
_(lIQ,tKQ)
var eLQ=function(oNQ,bMQ,xOQ,gg){
var fQQ=_mz(z,'u-icon',['bind:__l',31,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oNQ,bMQ,gg)
_(xOQ,fQQ)
return xOQ
}
tKQ.wxXCkey=4
_2z(z,29,eLQ,e,s,gg,tKQ,'u','v','v')
_(b9P,lIQ)
var o0P=_v()
_(b9P,o0P)
if(_oz(z,37,e,s,gg)){o0P.wxVkey=1
}
o0P.wxXCkey=1
_(l5P,b9P)
var t7P=_v()
_(l5P,t7P)
if(_oz(z,38,e,s,gg)){t7P.wxVkey=1
}
var cRQ=_n('view')
_rz(z,cRQ,'class',39,e,s,gg)
var hSQ=_v()
_(cRQ,hSQ)
if(_oz(z,40,e,s,gg)){hSQ.wxVkey=1
}
var oTQ=_v()
_(cRQ,oTQ)
if(_oz(z,41,e,s,gg)){oTQ.wxVkey=1
}
hSQ.wxXCkey=1
oTQ.wxXCkey=1
_(l5P,cRQ)
var cUQ=_mz(z,'u-popup',['bind:__l',42,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var oVQ=_mz(z,'u-input',['autoHeight',51,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'data-event-opts',5,'height',6,'maxlength',7,'placeholder',8,'placeholderStyle',9,'type',10,'value',11,'vueId',12],[],e,s,gg)
_(cUQ,oVQ)
_(l5P,cUQ)
a6P.wxXCkey=1
a6P.wxXCkey=3
t7P.wxXCkey=1
_(r,l5P)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_34";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_34();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/orderDetail.wxml'] = [$gwx0_XC_34, './pages/pageRelay/orderDetail.wxml'];else __wxAppCode__['pages/pageRelay/orderDetail.wxml'] = $gwx0_XC_34( './pages/pageRelay/orderDetail.wxml' );
	;__wxRoute = "pages/pageRelay/orderDetail";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/orderDetail.js";define("pages/pageRelay/orderDetail.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/orderDetail"],{488:function(e,t,n){"use strict";(function(e){n(5),o(n(4));var t=o(n(489));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},489:function(e,t,n){"use strict";n.r(t);var o=n(490),r=n(492);for(var a in r)"default"!==a&&function(e){n.d(t,e,(function(){return r[e]}))}(a);n(494),n(496);var i=n(17),u=Object(i.default)(r.default,o.render,o.staticRenderFns,!1,null,"3958f849",null,!1,o.components,void 0);u.options.__file="pages/pageRelay/orderDetail.vue",t.default=u.exports},490:function(e,t,n){"use strict";n.r(t);var o=n(491);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},491:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return i})),n.d(t,"recyclableRender",(function(){return a})),n.d(t,"components",(function(){return o}));try{o={pageLoading:function(){return n.e("components/page-loading/page-loading").then(n.bind(null,1090))},uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))},uPopup:function(){return n.e("uview-ui/components/u-popup/u-popup").then(n.bind(null,939))},uInput:function(){return Promise.all([n.e("common/vendor"),n.e("uview-ui/components/u-input/u-input")]).then(n.bind(null,910))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){var e=this,t=(e.$createElement,e._self._c,e.__map(e.orderData.commodityDetais,(function(t,n){return{$orig:e.__get_orig(t),g0:t.formatName.slice(0,10)}})));e._isMounted||(e.e0=function(t){e.showRefund=!1}),e.$mp.data=Object.assign({},{$root:{l0:t}})},a=!1,i=[];r._withStripped=!0},492:function(e,t,n){"use strict";n.r(t);var o=n(493),r=n.n(o);for(var a in o)"default"!==a&&function(e){n.d(t,e,(function(){return o[e]}))}(a);t.default=r.a},493:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(e){return e&&e.__esModule?e:{default:e}}(n(61)),r={data:function(){return{showRefund:!1,pageLoadings:!0,typeIds:2,balanceNum:"",orderData:{orderId:"",createTime:"",headImg:"",nickName:"",payPriceShow:0,onscaleShow:0,commodityCount:0,orderPriceShow:0},remarkRefund:"",tagArray:["全部","待发货","已发货","待退款","已退款","未核销","部分核销","已核销"],orderStatuTe:["未知","待支付","待发货","支付失败","支付中","待发货","已发货"],remarkType:["","团长备注","用户备注","退款备注"]}},onShow:function(){e.hideShareMenu({})},onLoad:function(e){this.getOrderDetail(e.id),e.type&&(this.typeIds=e.type)},methods:{copyText:function(){var t;t=this.orderData.orderLogistics.length?"订单状态：".concat(this.orderStatuTe[this.orderData.orderStatus],"\n商品名称：").concat(this.orderData.commodityDetais[0].commodityName,"\n快递信息：").concat(this.orderData.orderLogistics[0].logisticsName,"：").concat(this.orderData.orderLogistics[0].logisticsId,"\n订单编号：").concat(this.orderData.orderId):"订单状态：".concat(this.orderStatuTe[this.orderData.orderStatus],"\n商品名称：").concat(this.orderData.commodityDetais[0].commodityName,"\n快递信息：暂无快递信息\n订单编号：").concat(this.orderData.orderId),e.setClipboardData({data:t,success:function(){e.showToast({title:"复制成功",icon:"success"})}})},showRefundFu:function(){this.typeIds,this.showRefund=!0},goRefund:function(){console.log("goRefund==",this.orderData),e.navigateTo({url:"./orderRefund?item="+encodeURIComponent(JSON.stringify(this.orderData))})},editRefund:function(){var t=this,n={orderId:this.orderData.orderId,remarkValue:this.remarkRefund,remarkType:3};this.$server.applyRefund(n).then((function(n){0==n.code?(e.showToast({title:"申请退款成功",icon:"success"}),t.showRefund=!1):e.showToast({title:n.message,icon:"none"})}))},goLosis:function(t){e.navigateTo({url:"./logisticsList?id="+t.logisticsId+"&name="+t.logisticsName+"&tm="+t.createTime})},goPage:function(t){1==t?e.navigateTo({url:"./withdraw"}):3==t?e.navigateTo({url:"./fundList"}):e.navigateTo({url:"./topUp"})},getOrderDetail:function(t){var n=this,r={orderId:t};this.$server.queryOrderDetail(r).then((function(t){0==t.code?(t.data.payPriceShow=o.default.centTurnSmacker(t.data.payPrice/100),t.data.shipFeeMoney&&(t.data.shipFeeMoneyShow=o.default.centTurnSmacker(t.data.shipFeeMoney/100),t.data.refundShipFeeMoneyShow=o.default.centTurnSmacker(t.data.refundShipFeeMoney/100),t.data.shipFeeMoneySh=o.default.centTurnSmacker((t.data.shipFeeMoney-t.data.refundShipFeeMoney)/100),t.data.shipFeeMoneyInp=o.default.centTurnSmacker((t.data.shipFeeMoney-t.data.refundShipFeeMoney)/100)),t.data.orderPriceShow=o.default.centTurnSmacker(t.data.orderPrice/100),t.data.onscaleShow=o.default.centTurnSmacker((t.data.orderPrice-t.data.payPrice)/100),t.data.createTimeShow=t.data.createTime.slice(0,16),t.data.isPick=!0,t.data.commodityDetais.forEach((function(e){e.isPick=!0,e.commodityPriceShow=o.default.centTurnSmacker(e.commodityPrice/100),e.commodityCountTo=1,e.refundCountSh=e.commodityCount-e.refundCount,e.commodityCountSh=e.commodityCount-e.verifyCount,e.refundMoneySh=o.default.centTurnSmacker((e.totalPrice-e.refundMoney)/100),e.refundMoneyInp=o.default.centTurnSmacker((e.totalPrice-e.refundMoney)/100)})),2==n.typeIds&&(e.getStorageSync("userInfo").userId==t.data.buyUserId?n.typeIds=0:n.typeIds=1),n.orderData=t.data,setTimeout((function(){n.pageLoadings=!1}),1200),console.log("this.orderData=",n.orderData,n.typeIds)):e.showToast({title:t.message,icon:"none"})}))}}};t.default=r}).call(this,n(1).default)},494:function(e,t,n){"use strict";n.r(t);var o=n(495),r=n.n(o);for(var a in o)"default"!==a&&function(e){n.d(t,e,(function(){return o[e]}))}(a);t.default=r.a},495:function(e,t,n){},496:function(e,t,n){"use strict";n.r(t);var o=n(497),r=n.n(o);for(var a in o)"default"!==a&&function(e){n.d(t,e,(function(){return o[e]}))}(a);t.default=r.a},497:function(e,t,n){}},[[488,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/orderDetail.js'});require("pages/pageRelay/orderDetail.js");