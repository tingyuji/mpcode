$gwx0_XC_56=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_56 || [];
function gz$gwx0_XC_56_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_56_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_56_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_56_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-73923e00'])
Z([[7],[3,'pageLoadings']])
Z([3,'__l'])
Z([3,'zuj_fixlo data-v-73923e00'])
Z([3,'z-index:1000;'])
Z([3,'0293f9f4-1'])
Z([[7],[3,'showTree']])
Z(z[2])
Z([3,'__e'])
Z(z[8])
Z([3,'data-v-73923e00 vue-ref'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^check']],[[4],[[5],[[4],[[5],[1,'handleCheck']]]]]]]],[[4],[[5],[[5],[1,'^checkChange']],[[4],[[5],[[4],[[5],[1,'handleCheckChange']]]]]]]]])
Z([3,'tree'])
Z([[7],[3,'defaultCheckedKeys']])
Z([[7],[3,'defaultExpandedKeys']])
Z([[7],[3,'expandOnCheckNode']])
Z([[7],[3,'expandOnClickNode']])
Z([[7],[3,'highlightCurrent']])
Z([3,'adCode'])
Z([[7],[3,'defaultProps']])
Z([1,true])
Z([[7],[3,'data']])
Z([3,'0293f9f4-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_56_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_56_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_56=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_56=true;
var x=['./pages/pageRelay/treeAddress.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_56_1()
var cGX=_n('view')
_rz(z,cGX,'class',0,e,s,gg)
var oHX=_v()
_(cGX,oHX)
if(_oz(z,1,e,s,gg)){oHX.wxVkey=1
var aJX=_mz(z,'page-loading',['bind:__l',2,'class',1,'style',2,'vueId',3],[],e,s,gg)
_(oHX,aJX)
}
var lIX=_v()
_(cGX,lIX)
if(_oz(z,6,e,s,gg)){lIX.wxVkey=1
var tKX=_mz(z,'ly-tree',['bind:__l',7,'bind:check',1,'bind:checkChange',2,'class',3,'data-event-opts',4,'data-ref',5,'defaultCheckedKeys',6,'defaultExpandedKeys',7,'expandOnCheckNode',8,'expandOnClickNode',9,'highlightCurrent',10,'nodeKey',11,'props',12,'showCheckbox',13,'treeData',14,'vueId',15],[],e,s,gg)
_(lIX,tKX)
}
oHX.wxXCkey=1
oHX.wxXCkey=3
lIX.wxXCkey=1
lIX.wxXCkey=3
_(r,cGX)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_56";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_56();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/treeAddress.wxml'] = [$gwx0_XC_56, './pages/pageRelay/treeAddress.wxml'];else __wxAppCode__['pages/pageRelay/treeAddress.wxml'] = $gwx0_XC_56( './pages/pageRelay/treeAddress.wxml' );
	;__wxRoute = "pages/pageRelay/treeAddress";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/treeAddress.js";define("pages/pageRelay/treeAddress.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/treeAddress"],{378:function(e,t,a){"use strict";(function(e){a(5),n(a(4));var t=n(a(379));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=a,e(t.default)}).call(this,a(1).createPage)},379:function(e,t,a){"use strict";a.r(t);var n=a(380),r=a(382);for(var i in r)"default"!==i&&function(e){a.d(t,e,(function(){return r[e]}))}(i);a(384);var s=a(17),o=Object(s.default)(r.default,n.render,n.staticRenderFns,!1,null,"73923e00",null,!1,n.components,void 0);o.options.__file="pages/pageRelay/treeAddress.vue",t.default=o.exports},380:function(e,t,a){"use strict";a.r(t);var n=a(381);a.d(t,"render",(function(){return n.render})),a.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),a.d(t,"recyclableRender",(function(){return n.recyclableRender})),a.d(t,"components",(function(){return n.components}))},381:function(e,t,a){"use strict";var n;a.r(t),a.d(t,"render",(function(){return r})),a.d(t,"staticRenderFns",(function(){return s})),a.d(t,"recyclableRender",(function(){return i})),a.d(t,"components",(function(){return n}));try{n={pageLoading:function(){return a.e("components/page-loading/page-loading").then(a.bind(null,1090))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){this.$createElement,this._self._c},i=!1,s=[];r._withStripped=!0},382:function(e,t,a){"use strict";a.r(t);var n=a(383),r=a.n(n);for(var i in n)"default"!==i&&function(e){a.d(t,e,(function(){return n[e]}))}(i);t.default=r.a},383:function(e,t,a){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,function(e){e&&e.__esModule}(a(61));var n={components:{LyTree:function(){Promise.all([a.e("pages/pageRelay/common/vendor"),a.e("pages/pageRelay/ly-tree/ly-tree")]).then(function(){return resolve(a(1097))}.bind(null,a)).catch(a.oe)}},data:function(){return{pageLoadings:!0,upPageData:{},showTree:!1,isCheckAll:!1,totalNums:0,expandOnCheckNode:!1,expandOnClickNode:!0,highlightCurrent:!1,data:[],dataTree:[],treeData:[],defaultProps:{children:"children",label:"adCodeName",disabled:"disabled"},defaultCheckedKeys:[],defaultExpandedKeys:[100001,100002,100003,100004,100005,100006,100007,100008]}},onLoad:function(t){var a=this,n=JSON.parse(decodeURIComponent(t.item));console.log("qList==",n),this.upPageData=n;var r=e.getStorageSync("teAreaData")||[];if(r.length){var i="",s=JSON.parse(JSON.stringify(r)),o=[];1==this.upPageData.forIndex?(this.upPageData.noDeliveryArea&&(this.defaultCheckedKeys=this.upPageData.noDeliveryArea.split(","),this.totalNums=this.defaultCheckedKeys.length),this.upPageData.unconditShippingArea&&(o=this.upPageData.unconditShippingArea.split(","),i=this.disabledTree(s,o)),this.data=i||s,this.showTree=!0):(this.upPageData.unconditShippingArea&&(this.defaultCheckedKeys=this.upPageData.unconditShippingArea.split(","),this.totalNums=this.defaultCheckedKeys.length),this.upPageData.noDeliveryArea&&(o=this.upPageData.noDeliveryArea.split(","),i=this.disabledTree(s,o)),this.data=i||s,this.showTree=!0),setTimeout((function(e){a.pageLoadings=!1}),1e3)}else this.templateAreaData()},methods:{disabledTree:function(e,t){for(var a=0;a<e.length;a++)e[a].disabled=t.includes(String(e[a].adCode)),e[a].children&&this.disabledTree(e[a].children,t);return e},getTreeName:function(e,t,a){for(var n=0;n<e.length;n++)t.includes(e[n].adCode)&&a.push(e[n].adCodeName),e[n].children&&this.getTreeName(e[n].children,t,a);return a},nameTree:function(e,t){for(var a=0;a<e.length;a++)e[a].disabled=t.includes(String(e[a].adCode)),e[a].children&&this.disabledTree(e[a].children,disabledArr);return e},handleCheck:function(e){var t=this.$refs.tree.getCheckedKeys();this.totalNums=t.length},getCheckedNodes:function(e,t){var a=this.$refs.tree.getCheckedNodes(!1,!1);console.log("getCheckedNodes==",a)},setCheckAll:function(){this.$refs.tree.setCheckAll(!this.isCheckAll),this.isCheckAll=!this.isCheckAll,console.log("isCheckAll==",this.isCheckAll);var e=this.$refs.tree.getCheckedKeys();this.totalNums=e.length},handleCheckChange:function(e){},getCheckedKeys:function(){console.log("仅叶子节点",this.$refs.tree.getCheckedKeys(!0)),console.log("不包含半选中状态的节点",this.$refs.tree.getCheckedKeys()),console.log("包含半选中状态的节点",this.$refs.tree.getCheckedKeys(!1,!0))},goback:function(){var t={forIndex:this.upPageData.forIndex};t.arr=this.$refs.tree.getCheckedKeys();var a=getCurrentPages();a[a.length-2].$vm.treeFun(t),e.navigateBack()},templateAreaData:function(){var t=this;this.$server.templateAreaData().then((function(a){if(0==a.code){console.log("teAreaData",a.data);var n="",r=JSON.parse(JSON.stringify(a.data)),i=[];1==t.upPageData.forIndex?(t.upPageData.noDeliveryArea&&(t.defaultCheckedKeys=t.upPageData.noDeliveryArea.split(","),t.totalNums=t.defaultCheckedKeys.length),t.upPageData.unconditShippingArea&&(i=t.upPageData.unconditShippingArea.split(","),n=t.disabledTree(r,i)),t.data=n||r,t.showTree=!0):(t.upPageData.unconditShippingArea&&(t.defaultCheckedKeys=t.upPageData.unconditShippingArea.split(","),t.totalNums=t.defaultCheckedKeys.length),r=JSON.parse(JSON.stringify(data)),t.upPageData.noDeliveryArea&&(i=t.upPageData.noDeliveryArea.split(","),n=t.disabledTree(r,i)),t.data=n||r,t.showTree=!0),setTimeout((function(e){t.pageLoadings=!1}),800),e.setStorageSync("teAreaData",a.data)}else t.pageLoadings=!1,e.showToast({title:a.message,icon:"none"})}))}}};t.default=n}).call(this,a(1).default)},384:function(e,t,a){"use strict";a.r(t);var n=a(385),r=a.n(n);for(var i in n)"default"!==i&&function(e){a.d(t,e,(function(){return n[e]}))}(i);t.default=r.a},385:function(e,t,a){}},[[378,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/treeAddress.js'});require("pages/pageRelay/treeAddress.js");