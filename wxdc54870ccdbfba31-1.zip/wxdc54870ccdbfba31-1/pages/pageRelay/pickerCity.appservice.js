$gwx0_XC_36=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_36 || [];
function gz$gwx0_XC_36_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_36_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_36_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_36_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_36_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_36_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_36=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_36=true;
var x=['./pages/pageRelay/pickerCity.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_36_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_36";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_36();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/pickerCity.wxml'] = [$gwx0_XC_36, './pages/pageRelay/pickerCity.wxml'];else __wxAppCode__['pages/pageRelay/pickerCity.wxml'] = $gwx0_XC_36( './pages/pageRelay/pickerCity.wxml' );
	;__wxRoute = "pages/pageRelay/pickerCity";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/pickerCity.js";define("pages/pageRelay/pickerCity.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/pickerCity"],{676:function(t,n,e){"use strict";(function(t){e(5),r(e(4));var n=r(e(677));function r(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=e,t(n.default)}).call(this,e(1).createPage)},677:function(t,n,e){"use strict";e.r(n);var r=e(678),i=e(680);for(var o in i)"default"!==o&&function(t){e.d(n,t,(function(){return i[t]}))}(o);e(682),e(684);var c=e(17),u=Object(c.default)(i.default,r.render,r.staticRenderFns,!1,null,"934a9a02",null,!1,r.components,void 0);u.options.__file="pages/pageRelay/pickerCity.vue",n.default=u.exports},678:function(t,n,e){"use strict";e.r(n);var r=e(679);e.d(n,"render",(function(){return r.render})),e.d(n,"staticRenderFns",(function(){return r.staticRenderFns})),e.d(n,"recyclableRender",(function(){return r.recyclableRender})),e.d(n,"components",(function(){return r.components}))},679:function(t,n,e){"use strict";e.r(n),e.d(n,"render",(function(){return r})),e.d(n,"staticRenderFns",(function(){return o})),e.d(n,"recyclableRender",(function(){return i})),e.d(n,"components",(function(){}));var r=function(){this.$createElement,this._self._c},i=!1,o=[];r._withStripped=!0},680:function(t,n,e){"use strict";e.r(n);var r=e(681),i=e.n(r);for(var o in r)"default"!==o&&function(t){e.d(n,t,(function(){return r[t]}))}(o);n.default=i.a},681:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={data:function(){return{scrollTop:0,list:[],indexList:["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"],customStyle:{width:"690rpx",height:"80rpx",backgroundColor:"#07c160",color:"#ffffff",border:"none"},cityList:[],countShareData:{totalAmount:0,userCount:0,otherAmount:0},nowSite:"未选择"}},onLoad:function(n){n&&n.i&&(this.nowSite=n.i);var e=t.getStorageSync("userInfo");e.cityList&&(this.cityList=e.cityList)},methods:{getCityList:function(){var t=this,n={agentId:this.$agentId};this.$server.couponCityList(n).then((function(n){if(0==n.code){t.cityList=n.data.cityList;var e=n.data.cityList;e.forEach((function(t,n){e[n].pyName=vPinyin.chineseToPinYin(t.city)}));var r=t.data_letter_sort(e,"pyName");t.list=r,console.log("list==",t.list)}}))},goBack:function(n){console.log("ee",n);var e=getCurrentPages();e[e.length-2].$vm.otherFun(n),t.navigateBack()}}};n.default=e}).call(this,e(1).default)},682:function(t,n,e){"use strict";e.r(n);var r=e(683),i=e.n(r);for(var o in r)"default"!==o&&function(t){e.d(n,t,(function(){return r[t]}))}(o);n.default=i.a},683:function(t,n,e){},684:function(t,n,e){"use strict";e.r(n);var r=e(685),i=e.n(r);for(var o in r)"default"!==o&&function(t){e.d(n,t,(function(){return r[t]}))}(o);n.default=i.a},685:function(t,n,e){}},[[676,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/pickerCity.js'});require("pages/pageRelay/pickerCity.js");