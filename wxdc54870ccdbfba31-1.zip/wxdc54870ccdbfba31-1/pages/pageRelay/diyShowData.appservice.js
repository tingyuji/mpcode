$gwx0_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx0_XC_19 || [];
function gz$gwx0_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx0_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx0_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx0_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z(z[0])
Z([3,'__e'])
Z([3,'fl_c data-v-a2ec23f6'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'showMode']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]],[1,'categoryName']]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'g0']])
Z([3,'__l'])
Z([3,'data-v-a2ec23f6'])
Z([3,'#999'])
Z([3,'question-circle'])
Z([3,'30'])
Z([[2,'+'],[1,'22b453a1-1-'],[[7],[3,'index']]])
})(__WXML_GLOBAL__.ops_cached.$gwx0_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx0_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx0_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx0_XC_19=true;
var x=['./pages/pageRelay/diyShowData.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx0_XC_19_1()
var cGJ=_v()
_(r,cGJ)
var oHJ=function(aJJ,lIJ,tKJ,gg){
var bMJ=_mz(z,'view',['bindtap',4,'class',1,'data-event-opts',2],[],aJJ,lIJ,gg)
var oNJ=_v()
_(bMJ,oNJ)
if(_oz(z,7,aJJ,lIJ,gg)){oNJ.wxVkey=1
var xOJ=_mz(z,'u-icon',['bind:__l',8,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],aJJ,lIJ,gg)
_(oNJ,xOJ)
}
oNJ.wxXCkey=1
oNJ.wxXCkey=3
_(tKJ,bMJ)
return tKJ
}
cGJ.wxXCkey=4
_2z(z,2,oHJ,e,s,gg,cGJ,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx0_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx0_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/pageRelay/diyShowData.wxml'] = [$gwx0_XC_19, './pages/pageRelay/diyShowData.wxml'];else __wxAppCode__['pages/pageRelay/diyShowData.wxml'] = $gwx0_XC_19( './pages/pageRelay/diyShowData.wxml' );
	;__wxRoute = "pages/pageRelay/diyShowData";__wxRouteBegin = true;__wxAppCurrentFile__="pages/pageRelay/diyShowData.js";define("pages/pageRelay/diyShowData.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
require("./common/vendor.js"),(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/pageRelay/diyShowData"],{602:function(e,t,n){"use strict";(function(e){n(5),o(n(4));var t=o(n(603));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},603:function(e,t,n){"use strict";n.r(t);var o=n(604),s=n(606);for(var i in s)"default"!==i&&function(e){n.d(t,e,(function(){return s[e]}))}(i);n(608);var c=n(17),r=Object(c.default)(s.default,o.render,o.staticRenderFns,!1,null,"a2ec23f6",null,!1,o.components,void 0);r.options.__file="pages/pageRelay/diyShowData.vue",t.default=r.exports},604:function(e,t,n){"use strict";n.r(t);var o=n(605);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},605:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return s})),n.d(t,"staticRenderFns",(function(){return c})),n.d(t,"recyclableRender",(function(){return i})),n.d(t,"components",(function(){return o}));try{o={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){var e=this,t=(e.$createElement,e._self._c,e.__map(e.list,(function(t,n){return{$orig:e.__get_orig(t),g0:e.tagTextsStr.includes(t.categoryName)}})));e.$mp.data=Object.assign({},{$root:{l0:t}})},i=!1,c=[];s._withStripped=!0},606:function(e,t,n){"use strict";n.r(t);var o=n(607),s=n.n(o);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);t.default=s.a},607:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,function(e){e&&e.__esModule}(n(61));var o={data:function(){return{openReling:!1,params:{year:!0,month:!0,day:!1,hour:!1,minute:!1,second:!1},show:!0,actionList:[{text:"退出社群"}],showAct:!1,ctrlUserId:"",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多数据"},loadStatus:"loading",page:1,pageSize:20,showPick:!1,tagTextsStr:["佣金收入","佣金支出","新下单人数","转化率"],tagTexts:["佣金收入==包含帮卖佣金、推荐佣金和推广员佣金的收入（未减去退款部分佣金）","佣金支出==包含帮卖佣金、推荐佣金和推广员佣金的支出（未减去退款部分佣金、不包含未发放佣金）","新下单人数==第一次参与接龙的用户数，仅统计自卖数据","转化率==转化率可有效反应活动对顾客的吸引程度，转化率=参与人数/访问人数"],tagStatus:0,checkTime:"2022",checkTimeMo:""}},onLoad:function(){var t=this;e.hideShareMenu({}),this.queryCategoryList(),setTimeout((function(e){console.log("list===",t.list)}),2e3)},methods:{showMode:function(t){var n=this.tagTextsStr.indexOf(t);if(-1==n)return!1;console.log("==",n);var o=this.tagTexts[n];console.log("==",o);var s=o.split("==");e.showModal({title:s[0],content:s[1],showCancel:!1,confirmText:"我知道了",confirmColor:"#07c160"})},queryCategoryList:function(e){var t=this;console.log("data==",this.checkTime,this.checkTimeMo),this.checkTime,this.checkTimeMo,this.$server.categoryList({businessType:3}).then((function(e){null!=e&&0==e.code&&(e.data.forEach((function(e){1==e.switchFlag?e.switchFlags=!0:e.switchFlags=!1})),setTimeout((function(n){t.list=e.data,console.log("list===",t.list)}),500))}))},updateCats:function(t,n){var o=this;console.log("item==",t);var s={id:t.id,categoryName:t.categoryName,businessType:t.businessType,switchFlag:!t.switchFlags};this.$server.updateCategory(s).then((function(s){0==s.code?(t.switchFlags?e.showToast({title:"已取消",icon:"success"}):e.showToast({title:"已添加",icon:"success"}),o.list[n].switchFlags=!t.switchFlags):(e.showToast({title:s.message,icon:"none"}),o.list[n].switchFlags=t.switchFlags)}))},opneMenu:function(e){this.ctrlUserId=e,this.showAct=!0}}};t.default=o}).call(this,n(1).default)},608:function(e,t,n){"use strict";n.r(t);var o=n(609),s=n.n(o);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);t.default=s.a},609:function(e,t,n){}},[[602,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/pageRelay/diyShowData.js'});require("pages/pageRelay/diyShowData.js");