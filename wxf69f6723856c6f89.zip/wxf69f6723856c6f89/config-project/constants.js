Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ROLES_TEXT_MAP = exports.ROLES = exports.PRIZE_TYPE_TEXT_MAP = exports.PRIZE_TYPE = exports.PRIZE_LOG_STATUS_TEXT_MAP = exports.PRIZE_LOG_STATUS = exports.LOTTERY_TEMPLATE_ID = exports.LABOR_CONGRATULATION_LIST = exports.EXPIRED_TEMPLATE_ID = exports.ERROR_STATUS = exports.COUPON_TYPE = exports.COUPON_STATUS = exports.COUPON_RECEIVE_STATUS = exports.CONGRATULATION_LIST = exports.BIRTH_TIPS = exports.BIRTH_COUPON_ERROR_TEXT_MAP = exports.BILL_TIPS = exports.BILL_STATUS = exports.BILL_COUPON_ERROR_TEXT_MAP = exports.ACTIVITY_STATUS_TEXT_MAP = exports.ACTIVITY_STATUS = exports.ACTIVITY_NOTICE_SUBSCRIBE_TEMPLATE_ID = exports.ACTIVITY_ALIAS = exports.ACTIONS_TYPE = exports.ACT9_BOOK_CATEGORY_TEXT_MAP = exports.ACT9_BOOK_CATEGORY = exports.ACT7_APPLICATION_STATUS = exports.ACT6_SECTION_STATUS = exports.ACT6_PRIZE_TYPE_TEXT_MAP = exports.ACT6_PRIZE_TYPE = exports.ACT6_PRIZE_STATUS_TEXT_MAP = exports.ACT6_PRIZE_STATUS = exports.ACT6_LOTTERY_STATUS_TEXT_MAP = exports.ACT6_LOTTERY_STATUS = exports.ACT6_LOTTERY_LEVEL_TEXT_MAP = exports.ACT6_LOTTERY_LEVEL = exports.ACT6_CHAPTER_STATUS_TEXT_MAP = exports.ACT6_CHAPTER_STATUS = exports.ACT5_ACTIVITY_STATUS = exports.ACT58_TRANSPORTATION = exports.ACT58_QUESTIONNAIRE_KEY = exports.ACT58_INDUSTRY_TEXT_MAP = exports.ACT58_INDUSTRY = exports.ACT3_ACTIVITY_STATUS = exports.ACT22_APPLICATION_STATUS = exports.ACT13_TIGER_CARD_TYPE = exports.ACT13_TIGER_CARD_NAME = exports.ACT13_TIGER_CARD_ERROR_TEXT_MAP = exports.ACT13_SOURCES_TEXT_MAP = exports.ACT13_SOURCES = exports.ACT13_BONUS_TYPE = exports.ACT13_ACTIVITY_STATUS = exports.ACT10_TEAM_FULL_ID = exports.ACT10_BTN_STATUS_TEXT_MAP = exports.ACT10_BTN_STATUS = exports.ACCEPT_IMG_EXT = exports.ACCEPT_AUDIO_EXT = void 0;

var T, E, _, e, A, I, t, r, N, o, C, s, O, S, R, i, a, p = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/defineProperty"), P = require("./miniprogram"), U = {
    SA: "sa"
};

exports.ROLES = U;

var x = n({}, U.SA, "超级管理员");

exports.ROLES_TEXT_MAP = x;

var L = {
    PENDING: "pending",
    PROCESSING: "processing",
    FINISHED: "finished"
};

exports.ACTIVITY_STATUS = L;

var D = (n(T = {}, L.PENDING, "待开始"), n(T, L.PROCESSING, "进行中"), n(T, L.FINISHED, "已结束"), 
T);

exports.ACTIVITY_STATUS_TEXT_MAP = D;

exports.ACTIONS_TYPE = {
    LOGIN: "login",
    REGISTER: "register",
    JOIN: "join",
    REGISTRATION: "registration"
};

exports.ACCEPT_IMG_EXT = ".png, .jpg, .jpeg, .gif";

exports.ACCEPT_AUDIO_EXT = ".mp3";

exports.LOTTERY_TEMPLATE_ID = "6KWARy0OE89w4-XBHrWgLBPlwZyENN0iSes6wWq_zG8";

exports.EXPIRED_TEMPLATE_ID = "pN13mODtRmVJl10IiycaeguaDZ6Vk8mM1mNWI0pQsKY";

exports.ACT10_TEAM_FULL_ID = "-0dy7NnhrSHvdTsBi66p15rvYnb3bTtzQ0jwVtV4DyE";

exports.ACTIVITY_NOTICE_SUBSCRIBE_TEMPLATE_ID = "_rkD8QzhUzV7ZIn7iKiPVhN0qX7h3u0LtpiYfljVEb0";

var d = {
    NOT_SEND: "not_send",
    SENDING: "sending",
    SENT_SUCCEEDED: "sent_succeeded",
    SENT_FAILED: "sent_failed",
    USED: "used",
    EXPIRED: "expired"
};

exports.PRIZE_LOG_STATUS = d;

var M = (n(E = {}, d.NOT_SEND, "未发放"), n(E, d.SENDING, "发放中"), n(E, d.SENT_SUCCEEDED, "发放成功"), 
n(E, d.SENT_FAILED, "发放失败"), n(E, d.USED, "已使用"), n(E, d.EXPIRED, "已过期"), E);

exports.PRIZE_LOG_STATUS_TEXT_MAP = M;

exports.BILL_STATUS = {
    DEFAULT: "default",
    PENDING: "pending",
    SUCCESS: "success",
    FAIL: "fail"
};

var c = {
    PENDING: "pending",
    PROGRESSING: "progressing",
    ENDED: "ended"
};

exports.ACT3_ACTIVITY_STATUS = c;

var G = c;

exports.ACT5_ACTIVITY_STATUS = G;

exports.CONGRATULATION_LIST = [ "不惧时光，活出风采", "绽放魅力，美丽人生", "巾帼展风华，拥抱新时代", "风采无限，世界因你而更美", "美丽绽放，邂逅最美女职工", "魅力巾帼，将精彩进行到底", "最美年华，遇见最好的自己", "活得精彩，成就更好的自己" ];

exports.LABOR_CONGRATULATION_LIST = [ "中国梦，劳动美", "拼搏逐梦，劳动光荣", "劳动，让世界更加美好", "劳动，用双手创造美好生活", "歌颂劳动，成就新时代梦想", "致敬劳动者，世界因你而精彩", "汗水浇灌梦想，劳动铸就辉煌", "劳动的汗水，浇灌梦想的花朵" ];

var l = {
    PENDING: "pending",
    USED: "used",
    EXPIRED: "expired",
    FAILED: "failed",
    SENT_SUCCEEDED: "sent_succeeded"
};

exports.COUPON_STATUS = l;

exports.COUPON_TYPE = {
    BIRTHDAY: "birthday",
    BILL: "bill"
};

var m = {
    PENDING: "pending",
    ENABLE: "enable",
    NOT_REDEEM: "not_redeem",
    REDEEMED: "redeemed",
    SENDING: "sending",
    SUCCESS: "success",
    FAIL: "fail",
    OUT_OF_STOCK: "out_of_stock",
    NO_QUALIFICATION: "no_qualification"
};

exports.COUPON_RECEIVE_STATUS = m;

var u = (n(A = {}, m.NOT_REDEEM, (n(_ = {}, P.ROUTE.ACT4_INDEX, {
    active: !0,
    text: "马上领取",
    method: "getBirthCoupon"
}), n(_, P.ROUTE.USER_CENTER, {
    text: "立即领取",
    method: "getBirthCoupon"
}), _)), n(A, m.PENDING, (n(e = {}, P.ROUTE.ACT4_INDEX, {
    active: !0,
    small: !0,
    text: "",
    template_text: "距离领取生日福利还有?天",
    method: "showPendingTips"
}), n(e, P.ROUTE.USER_CENTER, {
    text: "",
    template_text: "还有?天可领取",
    method: "showPendingTips"
}), e)), n(A, m.REDEEMED, {
    active: !1,
    text: "已领取"
}), n(A, m.OUT_OF_STOCK, {
    active: !1,
    text: "已领完"
}), n(A, m.ENABLE, {
    active: !1,
    text: "还有?天开启",
    method: "showEnableTips"
}), n(A, l.FAILED, {
    text: "领取失败",
    method: "showBirthFailedResult"
}), A);

exports.BIRTH_TIPS = u;

var h = (n(I = {}, m.NOT_REDEEM, {
    text: "立即领取",
    method: "getBillCoupon"
}), n(I, m.OUT_OF_STOCK, {
    text: "已领完",
    method: "showOutStockTips"
}), n(I, m.SUCCESS, {
    text: "前往充值",
    method: "rechargeBill"
}), n(I, m.REDEEMED, {
    text: "前往充值",
    method: "rechargeBill"
}), n(I, m.ENABLE, {
    text: "还有?天开启",
    method: "showEnableTips"
}), n(I, l.FAILED, {
    text: "领取失败",
    method: "showBillFailedResult"
}), I);

exports.BILL_TIPS = h;

var Y = {
    NOT_THIS_MONTH: "not_this_month",
    RECEIVE_COUPON: "receive_coupon",
    NOT_UNIONIZED: "not_unionized",
    WECHAT_ERROR: "wechat_error",
    REQUEST_TIMEOUT: "request_timeout",
    OUT_OF_STOCK: "out_of_stock",
    NO_QUALIFICATION: "no_qualification"
};

exports.ERROR_STATUS = Y;

var g = {
    "The user birth_month is not this month.": {
        status: Y.NOT_THIS_MONTH,
        msg: "领取「生日蛋糕券」时间未到，记得生日当月来领取哦"
    },
    "This user has already received a coupon.": {
        status: Y.RECEIVE_COUPON,
        msg: "每人限领一张，请勿重复领取"
    },
    "User is not unionized.": {
        status: Y.NOT_UNIONIZED,
        msg: "未获取到您的工会信息，请前往个人中心重新登录"
    },
    "Failed to send coupon.": {
        status: Y.WECHAT_ERROR,
        msg: "您的微信账号存在异常，请更换其他账号领取"
    },
    "Request timeout": {
        status: Y.REQUEST_TIMEOUT,
        msg: "抱歉，服务繁忙请重新领取"
    },
    "Out of stock.": {
        status: Y.OUT_OF_STOCK,
        msg: "抱歉，生日礼包已领完"
    }
};

exports.BIRTH_COUPON_ERROR_TEXT_MAP = g;

var v = p(p({}, g), {}, {
    "Out of stock.": {
        status: Y.OUT_OF_STOCK,
        msg: "抱歉，话费券已领完"
    },
    "User is not eligible.": {
        status: Y.NO_QUALIFICATION,
        msg: "抱歉，您不符合新人礼包的领取要求"
    }
});

exports.BILL_COUPON_ERROR_TEXT_MAP = v;

var B = {
    ACTIVE: "active",
    INACTIVE: "inactive"
};

exports.ACT6_PRIZE_STATUS = B;

var V = (n(t = {}, B.ACTIVE, "已上架"), n(t, B.INACTIVE, "已下架"), t);

exports.ACT6_PRIZE_STATUS_TEXT_MAP = V;

var H = {
    UNION_BUY: "union_buy",
    XIMALAYA: "ximalaya"
};

exports.ACT6_PRIZE_TYPE = H;

var F = (n(r = {}, H.UNION_BUY, "粤工惠购"), n(r, H.XIMALAYA, "喜马拉雅"), r);

exports.ACT6_PRIZE_TYPE_TEXT_MAP = F;

var X = {
    ACTIVE: "active",
    INACTIVE: "inactive"
};

exports.ACT6_CHAPTER_STATUS = X;

var b = (n(N = {}, X.ACTIVE, "已上架"), n(N, X.INACTIVE, "已下架"), N);

exports.ACT6_CHAPTER_STATUS_TEXT_MAP = b;

exports.ACT6_SECTION_STATUS = {
    INTRO: "intro",
    OPENING: "opening",
    SECTION: "section",
    ENDING: "ending",
    TRANSITION: "transition"
};

var f = {
    PROVINCE: "province",
    CITY: "city"
};

exports.ACT6_LOTTERY_LEVEL = f;

var y = (n(o = {}, f.PROVINCE, "省总工会"), n(o, f.CITY, "市总工会"), o);

exports.ACT6_LOTTERY_LEVEL_TEXT_MAP = y;

exports.ACT6_LOTTERY_STATUS = {
    ACTIVE: "active",
    INACTIVE: "inactive"
};

var K = (n(C = {}, X.ACTIVE, "已上架"), n(C, X.INACTIVE, "已下架"), C);

exports.ACT6_LOTTERY_STATUS_TEXT_MAP = K;

var Z = {
    PENDING: "pending",
    APPROVED: "approved",
    REJECTED: "rejected"
};

exports.ACT7_APPLICATION_STATUS = Z;

var w = p({}, Z);

exports.ACT22_APPLICATION_STATUS = w;

exports.ACTIVITY_ALIAS = {
    BIRTHDAY: "birthday",
    COOL_SUMMER_2021: "cool_summer_2021",
    BILL_REGULAR: "bill_regular",
    NEW_CLIENT: "new_client",
    ACT8_INVITE_GIFT: "act8_invite_gift"
};

var W = {
    LITERATURE: "literature",
    HUMANITIES: "humanities",
    TECHNOLOGY: "technology",
    INSPIRATIONAL: "inspirational",
    LIVELIHOOD: "livelihood"
};

exports.ACT9_BOOK_CATEGORY = W;

var k = (n(s = {}, W.LITERATURE, "文学小说"), n(s, W.HUMANITIES, "人文社科"), n(s, W.TECHNOLOGY, "科普读物"), 
n(s, W.INSPIRATIONAL, "经管励志"), n(s, W.LIVELIHOOD, "生活百科"), s);

exports.ACT9_BOOK_CATEGORY_TEXT_MAP = k;

var j = {
    PENDING: "pending",
    FINISHED: "finished",
    UN_BIND: "un_bind",
    UN_FULL: "un_full",
    PUNCH: "punch",
    PUNCHING: "punching",
    PUNCHED: "punched"
};

exports.ACT10_BTN_STATUS = j;

var Q = (n(O = {}, j.PENDING, {
    btnText: "活动将于 M 月 DD 号 HH:mm 开始",
    disabled: !0,
    method: "noop"
}), n(O, j.FINISHED, {
    btnText: "活动已结束",
    disabled: !0,
    method: "noop"
}), n(O, j.UN_BIND, {
    btnText: "立即组队打卡",
    disabled: !1,
    method: "askCreateMyTeam"
}), n(O, j.UN_FULL, {
    btnText: "查看组队情况",
    disabled: !1,
    method: "navToTeam"
}), n(O, j.PUNCH, {
    btnText: "立即打卡",
    disabled: !1,
    method: "punch"
}), n(O, j.PUNCHING, {
    btnText: "更新我的步数",
    disabled: !1,
    method: "punch"
}), n(O, j.PUNCHED, {
    btnText: "今日已打卡，分享给好友",
    disabled: !1,
    method: "share"
}), O);

exports.ACT10_BTN_STATUS_TEXT_MAP = Q;

var q = {
    OFFICIAL: "official",
    MINIPROGRAM: "miniprogram",
    GIVER: "giver"
};

exports.ACT13_SOURCES = q;

var z = (n(S = {}, q.OFFICIAL, "公众号"), n(S, q.MINIPROGRAM, "小程序"), n(S, q.GIVER, "好友互换"), 
S);

exports.ACT13_SOURCES_TEXT_MAP = z;

var J = {
    MERGE: "MERGE",
    BASE_1: "BASE_1",
    BASE_2: "BASE_2",
    BASE_3: "BASE_3",
    BASE_4: "BASE_4",
    BASE_5: "BASE_5"
};

exports.ACT13_TIGER_CARD_TYPE = J;

var $ = (n(R = {}, J.MERGE, "工会五虎"), n(R, J.BASE_1, "虎虎生威"), n(R, J.BASE_2, "生龙活虎"), 
n(R, J.BASE_3, "龙腾虎跃"), n(R, J.BASE_4, "藏龙卧虎"), n(R, J.BASE_5, "如虎添翼"), R);

exports.ACT13_TIGER_CARD_NAME = $;

exports.ACT13_BONUS_TYPE = {
    COUPON: "COUPON",
    TEXT: "TEXT",
    RED_PACKET_COVER: "RED_PACKET_COVER",
    VIDEO: "VIDEO",
    CONGRATULATION: "CONGRATULATION",
    MINIPROGRAM: "MINIPROGRAM",
    GIF: "GIF"
};

exports.ACT13_ACTIVITY_STATUS = {
    PENDING: "pending",
    PROCESSING: "processing",
    FINISHED: "finished"
};

exports.ACT13_TIGER_CARD_ERROR_TEXT_MAP = {
    "Activity not started.": {
        msg: "当前活动尚未开始"
    },
    "Activity has finished.": {
        msg: "当前活动已经结束"
    },
    "Invalid tiger card source.": {
        msg: "当前领取方式已失效，请更换其他方式"
    },
    "Reach daily limit of source.": {
        msg: "今日该领取方式的虎卡已领取，请更换其他方式"
    },
    "Activity only members can join.": {
        msg: "活动仅限粤工惠工会会员参与"
    },
    "Card has been redeemed.": {
        msg: "虎卡已被领取"
    },
    "Card cannot be given away.": {
        msg: "当前虎卡无法赠送"
    },
    "Invalid tiger card.": {
        msg: "虎卡已被领取"
    }
};

var TT = {
    WECHAT_DISCOUNT_COUPON: "wechat_discount_coupon",
    WECHAT_RECHARGE_COUPON: "wechat_recharge_coupon",
    WECHAT_TRANSFER: "wechat_transfer",
    GDFTU_BUY_COUPON: "gdftu_buy_coupon",
    REDEEMPTION_TICKET: "redemption_ticket",
    PACKAGE_DELIVERY: "package_delivery",
    LOTTERY_MISS: "lottery_miss",
    NAVIGATION: "navigation",
    OFFLINE_REDEMPTION: "offline_redemption"
};

exports.PRIZE_TYPE = TT;

var ET = (n(i = {}, TT.WECHAT_DISCOUNT_COUPON, "微信满减券"), n(i, TT.WECHAT_RECHARGE_COUPON, "微信话费充值券"), 
n(i, TT.WECHAT_TRANSFER, "微信转账到零钱"), n(i, TT.GDFTU_BUY_COUPON, "粤工惠购消费券"), n(i, TT.REDEEMPTION_TICKET, "卡密兑换票券"), 
n(i, TT.PACKAGE_DELIVERY, "邮寄包裹"), n(i, TT.NAVIGATION, "跳转小程序"), n(i, TT.LOTTERY_MISS, "未中奖，谢谢参与"), 
n(i, TT.OFFLINE_REDEMPTION, "线下兑奖"), i);

exports.PRIZE_TYPE_TEXT_MAP = ET;

exports.ACT58_QUESTIONNAIRE_KEY = {
    CAREER: "career",
    HOLIDAY_LOCATION: "holiday_location",
    HOMETOWN: "hometown",
    HOLIDAY_DATE: "holiday_date",
    HOME_DATE: "home_date",
    GO_HOME_TRANSPORTATION: "go_home_transportation",
    HOLIDAY_END_DATE: "holiday_end_date",
    GO_BACK_DATE: "go_back_date",
    GO_BACK_TRANSPORTATION: "go_back_transportation",
    ORIGINAL_COMPANY: "original_company",
    INDUSTRY: "industry",
    HOLIDAY_BENEFIT: "holiday_benefit",
    FIND_JOB: "find_job",
    WAGE_INCREASE: "wage_increase"
};

var _T = {
    FARMING: "farming",
    MINING: "mining",
    MANUFACTURING: "manufacturing",
    ENERGY_SUPPLY: "energy_supply",
    CONSTRUCTION: "construction",
    RETAIL: "retail",
    TRANSPORTATION: "transportation",
    CATERING: "catering",
    IT: "IT",
    FINANCE: "finance",
    REAL_ESTATE: "real_estate",
    BUSINESS_SERVICE: "business_service",
    SCIENTIFIC_RESEARCH: "scientific_research",
    FACILITIES_MANAGEMENT: "facilities_management",
    RESIDENTIAL_SERVICES: "residential_services",
    EDUCATION: "education",
    HEALTH: "health",
    CULTURE: "culture",
    PUBLIC_ADMINISTRATION: "public_administration",
    INTERNATIONAL_ORGANIZATION: "international_organization"
};

exports.ACT58_INDUSTRY = _T;

var eT = (n(a = {}, _T.FARMING, "农、林、牧、渔、水利业生产人员"), n(a, _T.MINING, "采矿业"), n(a, _T.MANUFACTURING, "制造业"), 
n(a, _T.ENERGY_SUPPLY, "电力、热力、燃气及水生产和供应业"), n(a, _T.CONSTRUCTION, "建筑业"), n(a, _T.RETAIL, "批发和零售业"), 
n(a, _T.TRANSPORTATION, "交通运输、仓储和邮政业"), n(a, _T.CATERING, "住宿和餐饮业"), n(a, _T.IT, "信息传输、软件和信息技术服务业"), 
n(a, _T.FINANCE, "金融业"), n(a, _T.REAL_ESTATE, "房地产业"), n(a, _T.BUSINESS_SERVICE, "租赁和商务服务业"), 
n(a, _T.SCIENTIFIC_RESEARCH, "科学研究和技术服务业"), n(a, _T.FACILITIES_MANAGEMENT, "水利、环境和公共设施管理业"), 
n(a, _T.RESIDENTIAL_SERVICES, "居民服务、修理和其他服务业"), n(a, _T.EDUCATION, "教育"), n(a, _T.HEALTH, "卫生和社会工作"), 
n(a, _T.CULTURE, "文化、体育和娱乐业"), n(a, _T.PUBLIC_ADMINISTRATION, "公共管理、社会保障和社会组织"), 
n(a, _T.INTERNATIONAL_ORGANIZATION, "国际组织"), a);

exports.ACT58_INDUSTRY_TEXT_MAP = eT;

exports.ACT58_TRANSPORTATION = {
    "飞机": "airplane",
    "高铁": "CHSR",
    "大巴": "bus",
    "自驾": "self_drive",
    "步行": "walking",
    "其他": "other"
};