Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.YUE_GONG_HUI_GOU_COUPON_PATH = exports.YUE_GONG_HUI_GOU = exports.YUE_GONG_HUI = exports.UNION_BUY_GOU_MINIPROGRAM = exports.TIGER_CARD_API = exports.TENCENT_RECHARGE_MINIPROGRAM = exports.TABLE = exports.SUBSCRIBE_MESSAGE_TEMPLATES = exports.STORAGE_KEYS = exports.RSA_PUBLIC_KEY = exports.QQ_MAP_KEY = exports.QA_5204_HOST = exports.OWNER_APP_ID = exports.NEW_YUE_GONG_HUI = exports.HSERVE_API = exports.GUANG_DONG_HONG_MINIPROGRAM = exports.GET_USER_PROFILE_V2 = exports.GET_USER_PROFILE = exports.GET_NEW_USER_GIFT_URL_V2 = exports.GET_NEW_USER_GIFT_URL = exports.GET_INVITE_GIFT_URL = exports.GET_BIRTH_COUPON_URL = exports.GET_BILL_COUPON_URL = exports.FUNCTION = exports.FILE_CATEGORY_DEV = exports.FILE_CATEGORY = exports.EVENTS_BUS = exports.ES_PRIVATE_KEY = exports.ENV_ID = exports.COOL_SUMMER_URL = exports.CLIENT_ID = exports.BIRTH_DAY_URL = exports.ACT9_WISH_LIST = exports.ACT9_SUBMIT_BOOK_COLLECT = exports.ACT30_DRAW_LOTTERY_API = exports.ACT24_SUBSCRIBE_MESSAGE_TEMPLATES = exports.ACT15_WOMENS_DAY_API = exports.ACT10_STEP_PUNCH = exports.ACT10_JOIN_TEAM = exports.ACT10_CREATE_TEAM = void 0;

exports.CLIENT_ID = "b4c8e4e14a9737f6f044";

exports.ENV_ID = "1d3d3dbba76396a82092";

exports.TABLE = {
    richtextcontent: "_richtextcontent",
    export_task: "export_task",
    userprofile: "_userprofile",
    admin: "admin",
    activity: "activity",
    token: "token",
    redirect: "redirect",
    registration: "registration",
    settings: "settings",
    frequently_asked_question: "frequently_asked_question",
    coupon_reminder: "coupon_reminder",
    discount_coupon: "discount_coupon",
    discount_coupon_log: "discount_coupon_log",
    prize: "prize",
    prize_log: "prize_log",
    subscribe_log: "subscribe_log",
    subscribe_send_log: "subscribe_send_log",
    act1_step: "act1_step",
    act1_step_log: "act1_step_log",
    act1_packet_log: "act1_packet_log",
    act1_red_packet: "act1_red_packet",
    act1_temp_lottery: "act1_temp_lottery",
    act1_lottery: "act1_lottery",
    act2_participate_cover: "act2_participate_cover",
    act2_participate_bill: "act2_participate_bill",
    act2_cover_prize: "act2_cover_prize",
    act2_temp_cover: "act2_temp_cover",
    act2_bill_prize: "act2_bill_prize",
    act2_bill_log: "act2_bill_log",
    act3_settings: "act3_settings",
    act3_participation_log: "act3_participation_log",
    act3_likes_log: "act3_likes_log",
    act3_gallery: "act3_gallery",
    act3_lottery: "act3_lottery",
    birthday_coupon_log: "birthday_coupon_log",
    bill_coupon_log: "bill_coupon_log",
    birthday_coupon: "birthday_coupon",
    bill_coupon: "bill_coupon",
    act5_participation_log: "act5_participation_log",
    act5_likes_log: "act5_likes_log",
    act5_settings: "act5_settings",
    act5_store: "act5_store",
    act5_brand: "act5_brand",
    act5_redeemed_log: "act5_redeemed_log",
    act5_model_work: "act5_model_work",
    act5_movie_ticket: "act5_movie_ticket",
    act5_ticket_redeemed_log: "act5_ticket_redeemed_log",
    act5_lottery: "act5_lottery",
    act6_lottery: "act6_lottery",
    act6_activity_log: "act6_activity_log",
    act6_points_log: "act6_points_log",
    act6_settings: "act6_settings",
    act6_chapter: "act6_chapter",
    act6_section: "act6_section",
    act6_prize: "act6_prize",
    act6_order: "act6_order",
    act6_completed_rank: "act6_completed_rank",
    act6_achievement_rank: "act6_achievement_rank",
    act6_lottery_chance: "act6_lottery_chance",
    act6_redemption: "act6_redemption",
    act6_lottery_log: "act6_lottery_log",
    server_app_setting: "server_app_setting",
    fission_register: "fission_register",
    credit_coupon_log: "credit_coupon_log",
    act7_whitelist: "act7_whitelist",
    act7_coupon: "act7_coupon",
    act7_coupon_log: "act7_coupon_log",
    act7_settings: "act7_settings",
    act7_daily_statistics_log: "act7_daily_statistics_log",
    act8_invite_register: "act8_invite_register",
    act7_application_log: "act7_application_log",
    act9_book: "act9_book",
    act9_collection_log: "act9_collection_log",
    act9_wish_log: "act9_wish_log",
    act10_lantern: "act10_lantern",
    act10_lantern_riddle: "act10_lantern_riddle",
    act10_team: "act10_team",
    act10_punch_log: "act10_punch_log",
    act10_redeem_log: "act10_redeem_log",
    act10_lottery_log: "act10_lottery_log",
    act11_product: "act11_product",
    act11_redeem_log: "act11_redeem_log",
    act11_comment: "act11_comment",
    act11_union_allowlist: "act11_union_allowlist",
    act11_phone_allowlist: "act11_phone_allowlist",
    act12_participate_log: "act12_participate_log",
    act12_lottery_log: "act12_lottery_log",
    act12_greeting_log: "act12_greeting_log",
    act12_movie_ticket: "act12_movie_ticket",
    act13_coupon: "act13_coupon",
    act13_reward: "act13_reward",
    act13_reward_log: "act13_reward_log",
    act13_bonus: "act13_bonus",
    act13_tiger_card: "act13_tiger_card",
    act13_tiger_card_log: "act13_tiger_card_log",
    act13_brand: "act13_brand",
    act13_store: "act13_store",
    act13_delivery_address: "act13_delivery_address",
    act14_stats: "act14_stats",
    act14_reward_log: "act14_reward_log",
    act14_reward: "act14_reward",
    act14_participation_log: "act14_participation_log",
    act15_prize: "act15_prize",
    act15_prize_log: "act15_prize_log",
    act15_chance_log: "act15_chance_log",
    act15_daily_log: "act15_daily_log",
    act16_book: "act16_book",
    act16_reading_log: "act16_reading_log",
    act16_ticket_log: "act16_ticket_log",
    act16_share_log: "act16_share_log",
    act16_participation_log: "act16_participation_log",
    act16_daily_book: "act16_daily_book",
    act17_participation_log: "act17_participation_log",
    act17_white_list: "act17_white_list",
    act18_receiving_log: "act18_receiving_log",
    act20_question: "act20_question",
    act20_participation_log: "act20_participation_log",
    act20_prize: "act20_prize",
    act20_prize_log: "act20_prize_log",
    act20_city_ranking: "act20_city_ranking",
    act21_participation_log: "act21_participation_log",
    act22_application_log: "act22_application_log",
    act22_ranking: "act22_ranking",
    act22_allow_trade_union: "act22_allow_trade_union",
    act22_deny_user_list: "act22_deny_user_list",
    act23_question: "act23_question",
    act23_answer_log: "act23_answer_log",
    act23_allow_member: "act23_allow_member",
    act23_personal_ranking: "act23_personal_ranking",
    act23_team_ranking: "act23_team_ranking",
    act24_question: "act24_question",
    act24_allow_trade_union: "act24_allow_trade_union",
    act24_participation_log: "act24_participation_log",
    act25_prize: "act25_prize",
    act25_prize_log: "act25_prize_log",
    act25_participation_log: "act25_participation_log",
    act26_white_list: "act26_white_list",
    act27_participation_log: "act27_participation_log",
    act27_question: "act27_question",
    act27_lottery_log: "act27_lottery_log",
    act28_prize: "act28_prize",
    act28_chance_log: "act28_chance_log",
    act28_participation_log: "act28_participation_log",
    act29_prize: "act29_prize",
    act29_prize_log: "act29_prize_log",
    act29_participation_log: "act29_participation_log",
    act30_answer_log: "act30_answer_log",
    act30_lantern: "act30_lantern",
    act30_question: "act30_question",
    act30_lottery_log: "act30_lottery_log",
    act30_city_rankings: "act30_city_rankings",
    act31_lottery_chance: "act31_lottery_chance",
    act31_lottery_log: "act31_lottery_log",
    act31_prize: "act31_prize",
    act31_redemption_ticket: "act31_redemption_ticket",
    act32_lottery_chance: "act32_lottery_chance",
    act32_lottery_log: "act32_lottery_log",
    act32_rankings: "act32_rankings",
    act33_lottery_chance: "act33_lottery_chance",
    act33_lottery_log: "act33_lottery_log",
    act33_team: "act33_team",
    act33_participation_log: "act33_participation_log",
    act34_participate_log: "act34_participate_log",
    act34_lottery_log: "act34_lottery_log",
    act34_video: "act34_video",
    act35_lottery_chance: "act35_lottery_chance",
    act35_lottery_log: "act35_lottery_log",
    act35_movie_ticket: "act35_movie_ticket",
    act36_lottery_chance: "act36_lottery_chance",
    act36_lottery_log: "act36_lottery_log",
    act37_lottery_chance: "act37_lottery_chance",
    act37_lottery_log: "act37_lottery_log",
    act37_prize: "act37_prize",
    act37_redemption_ticket: "act37_redemption_ticket",
    act38_lottery_chance: "act38_lottery_chance",
    act38_lottery_log: "act38_lottery_log",
    act39_questionnaire: "act39_questionnaire",
    act39_lottery_chance: "act39_lottery_chance",
    act39_lottery_log: "act39_lottery_log",
    act40_lottery_chance: "act40_lottery_chance",
    act40_lottery_log: "act40_lottery_log",
    act41_lottery_chance: "act41_lottery_chance",
    act41_lottery_log: "act41_lottery_log",
    act41_question: "act41_question",
    act42_answer_log: "act42_answer_log",
    act42_question: "act42_question",
    act42_lottery_log: "act42_lottery_log",
    act42_city_rankings: "act42_city_rankings",
    act42_lottery_chance: "act42_lottery_chance",
    act43_lottery_chance: "act43_lottery_chance",
    act43_lottery_log: "act43_lottery_log",
    act43_redemption_ticket: "act43_redemption_ticket",
    act44_lottery_chance: "act44_lottery_chance",
    act44_lottery_log: "act44_lottery_log",
    act44_question: "act44_question",
    act45_lottery_chance: "act45_lottery_chance",
    act45_lottery_log: "act45_lottery_log",
    act45_participation_log: "act45_participation_log",
    act46_answer_log: "act46_answer_log",
    act46_question: "act46_question",
    act46_lottery_log: "act46_lottery_log",
    act46_article: "act46_article",
    act46_lottery_chance: "act46_lottery_chance",
    act47_lottery_chance: "act47_lottery_chance",
    act47_lottery_log: "act47_lottery_log",
    act47_question: "act47_question",
    act48_store: "act48_store",
    act48_likes_log: "act48_likes_log",
    act48_lottery_chance: "act48_lottery_chance",
    act48_lottery_log: "act48_lottery_log",
    act49_lottery_chance: "act49_lottery_chance",
    act49_lottery_log: "act49_lottery_log",
    act49_redemption_ticket: "act49_redemption_ticket",
    act50_lottery_chance: "act50_lottery_chance",
    act50_lottery_log: "act50_lottery_log",
    act50_question: "act50_question",
    act51_lottery_chance: "act51_lottery_chance",
    act51_lottery_log: "act51_lottery_log",
    act52_lottery_chance: "act52_lottery_chance",
    act52_lottery_log: "act52_lottery_log",
    act52_movie_ticket: "act52_movie_ticket",
    act53_coupon: "act53_coupon",
    act53_bonus: "act53_bonus",
    act53_rabbit_card: "act53_rabbit_card",
    act53_rabbit_card_log: "act53_rabbit_card_log",
    act53_brand: "act53_brand",
    act53_store: "act53_store",
    act53_delivery_address: "act53_delivery_address",
    act53_path_config: "act53_path_config",
    act53_lottery_chance: "act53_lottery_chance",
    act53_lottery_log: "act53_lottery_log",
    act54_lottery_chance: "act54_lottery_chance",
    act54_poster_log: "act54_poster_log",
    act54_blessings: "act54_blessings",
    act54_participation_log: "act54_participation_log",
    act54_lottery_log: "act54_lottery_log",
    act55_lottery_chance: "act55_lottery_chance",
    act55_lottery_log: "act55_lottery_log",
    act55_movie_ticket: "act55_movie_ticket",
    act56_lottery_chance: "act56_lottery_chance",
    act56_lottery_log: "act56_lottery_log",
    act56_question: "act56_question",
    act57_lottery_chance: "act57_lottery_chance",
    act57_lottery_log: "act57_lottery_log",
    act57_redemption_ticket: "act57_redemption_ticket",
    act58_questionnaire: "act58_questionnaire",
    act58_lottery_chance: "act58_lottery_chance",
    act58_lottery_log: "act58_lottery_log",
    act58_stats: "act58_stats",
    act59_lottery_chance: "act59_lottery_chance",
    act59_lottery_log: "act59_lottery_log",
    act59_redemption_ticket: "act59_redemption_ticket",
    act60_lottery_chance: "act60_lottery_chance",
    act60_lottery_log: "act60_lottery_log",
    act60_redemption_ticket: "act60_redemption_ticket",
    act61_vote_log: "act61_vote_log",
    act61_lottery_chance: "act61_lottery_chance",
    act61_lottery_log: "act61_lottery_log",
    act62_lottery_chance: "act62_lottery_chance",
    act62_lottery_log: "act62_lottery_log",
    act62_redemption_ticket: "act62_redemption_ticket",
    act63_lottery_chance: "act63_lottery_chance",
    act63_lottery_log: "act63_lottery_log",
    act63_redemption_ticket: "act63_redemption_ticket",
    act64_participation_log: "act64_participation_log",
    act64_lottery_chance: "act64_lottery_chance",
    act64_lottery_log: "act64_lottery_log",
    act64_union_story: "act64_union_story",
    act65_lottery_chance: "act65_lottery_chance",
    act65_lottery_log: "act65_lottery_log",
    act65_article: "act65_article",
    act65_likes_log: "act65_likes_log",
    act66_participation_log: "act66_participation_log",
    act66_lottery_chance: "act66_lottery_chance",
    act66_lottery_log: "act66_lottery_log",
    act67_act68_lottery_chance: "act67_act68_lottery_chance",
    act67_act68_lottery_log: "act67_act68_lottery_log",
    act68_invitation_log: "act68_invitation_log",
    act67_act68_gigs_trade_union: "act67_act68_gigs_trade_union",
    act69_article: "act69_article",
    act69_lottery_log: "act69_lottery_log",
    act69_lottery_chance: "act69_lottery_chance",
    act69_participation_log: "act69_participation_log",
    act70_lottery_chance: "act70_lottery_chance",
    act70_lottery_log: "act70_lottery_log",
    act70_article: "act70_article",
    act70_likes_log: "act70_likes_log",
    act71_lottery_chance: "act71_lottery_chance",
    act71_lottery_log: "act71_lottery_log",
    act71_redemption_ticket: "act71_redemption_ticket",
    act72_lottery_chance: "act72_lottery_chance",
    act72_lottery_log: "act72_lottery_log",
    act73_lottery_chance: "act73_lottery_chance",
    act73_lottery_log: "act73_lottery_log",
    act73_answer_log: "act73_answer_log",
    act73_participation_log: "act73_participation_log",
    act73_subscribe_send_log: "act73_subscribe_send_log",
    act73_ranking: "act73_ranking",
    act74_lottery_chance: "act74_lottery_chance",
    act74_lottery_log: "act74_lottery_log",
    act74_ranking: "act74_ranking",
    act74_allow_trade_union: "act74_allow_trade_union",
    act74_block_list: "act74_block_list",
    act75_lottery_chance: "act75_lottery_chance",
    act75_lottery_log: "act75_lottery_log",
    act76_lottery_chance: "act76_lottery_chance",
    act76_lottery_log: "act76_lottery_log",
    act77_lottery_chance: "act77_lottery_chance",
    act77_lottery_log: "act77_lottery_log",
    act78_lottery_chance: "act78_lottery_chance",
    act78_lottery_log: "act78_lottery_log",
    act79_lottery_chance: "act79_lottery_chance",
    act79_voted_log: "act79_voted_log",
    act79_team_info: "act79_team_info",
    act79_lottery_log: "act79_lottery_log",
    act80_participation_log: "act80_participation_log",
    act80_answer_log: "act80_answer_log",
    act80_points_ranking: "act80_points_ranking",
    act80_city_ranking: "act80_city_ranking",
    act80_lottery_chance: "act80_lottery_chance",
    act80_lottery_log: "act80_lottery_log",
    act81_lottery_chance: "act81_lottery_chance",
    act81_lottery_log: "act81_lottery_log"
};

exports.FUNCTION = {
    GET_MEMBER_INFO: "get_member_info",
    GET_MEMBER_INFO_BY_UNIQUE: "get_member_info_by_unique",
    CHECK_JOIN_UNION_STATUS: "check_join_union_status",
    UPDATE_JOIN_UNION_STATUS: "update_join_union_status",
    UPDATE_USER_PRIZE_LOG_ADDRESS: "update_user_prize_log_address",
    CREATE_MONTHLY_BIRTHDAY_SETTINGS: "create_monthly_birthday_settings",
    get_task_id: "get_task_id",
    act2_recharge_bill: "act2_recharge_bill",
    ACT6_INIT_ACTIVITY_LOG: "act6_init_activity_log",
    ACT6_SET_COMPLETED_RANK: "act6_set_completed_rank",
    ACT6_COMPLETE_CHAPTER: "act6_complete_chapter",
    ACT6_REDEEM_PRIZE: "act6_redeem_prize",
    EXPORT_DATA: "export_data",
    CAN_REDEEM_NEWCOMER_GIFT: "can_redeem_newcomer_gift",
    EXPORT_JWT: "export_jwt",
    ACT7_CREATE_APPLICATION_LOG: "act7_create_application_log",
    ACT7_UPDATE_DAILY_STATISTICS: "act7_update_daily_statistics",
    ACT8_UPDATE_JOIN_UNION_STATUS: "act8_update_join_union_status",
    ACT8_UPDATE_REAL_NAME_STATUS: "act8_update_real_name_status",
    ACT8_REDEEM_COUPON: "act8_redeem_coupon",
    ACT8_BIND_INVITER: "act8_bind_inviter",
    ACT10_CREATE_TEAM: "act10_create_team",
    act10_JOIN_TEAM: "act10_join_team",
    ACT13_CREATE_DELIVERY_ADDRESS: "act13_create_delivery_address",
    ACT15_UPDATE_DELIVER_INFO: "act15_update_deliver_info",
    ACT16_UPDATE_READING_COMMENT: "act16_update_reading_comment",
    ACT16_CREATE_SHARE_LOG: "act16_create_share_log",
    ACT20_UPDATE_PRIZE_RESULT: "act20_update_prize_result",
    ACT23_ADD_ANSWER_LOG: "act23_add_answer_log",
    ACT25_UPDATE_USER_ADDRESS: "act25_update_user_address",
    ACT29_UPDATE_USER_ADDRESS: "act29_update_user_address",
    ACT37_UPDATE_USER_ADDRESS: "act37_update_user_address",
    ACT39_UPDATE_USER_ADDRESS: "act39_update_user_address",
    ACT43_UPDATE_USER_ADDRESS: "act43_update_user_address",
    ACT45_CREATE_PARTICIPATION_LOG: "act45_create_participation_log",
    ACT45_UPDATE_AVATAR_DATA: "act45_update_avatar_data",
    ACT49_UPDATE_ADDRESS: "act49_update_address",
    ACT53_CREATE_DELIVERY_ADDRESS: "act53_create_delivery_address",
    ACT53_CREATE_PAGE_URL: "act53_create_page_url",
    ACT57_UPDATE_ADDRESS: "act57_update_address",
    ACT58_CREATE_CHANCE: "act58_create_chance",
    ACT66_SEND_INCOMPLETE_SUBSCRIBE_MESSAGE: "act66_send_incomplete_subscribe_message",
    ACT66_CREATE_LOTTERY_CHANCE_LOG: "act66_create_lottery_chance",
    ACT68_CREATE_INVITATION_LOG: "act68_create_invitation_log",
    ACT68_UPDATE_INVITATION_LOG: "act68_update_invitation_log",
    ACT69_CREATE_OR_UPDATE_PARTICIPATION_LOG: "act69_create_or_update_participation_log",
    ACT73_UPDATE_PARTICIPATION_LOG: "act73_update_participation_log",
    ACT73_UPDATE_RANKING: "act73_update_ranking",
    ACT73_SEND_SUBSCRIBE_MESSAGE: "act73_send_subscribe_message",
    ACT80_GET_EXTRA_SHARE_CHANCE: "act80_get_extra_share_chance",
    ACT80_AUTO_UPDATE_CITY_RANKING: "act80_auto_update_city_ranking",
    ACT80_AUTO_SEND_SUBSCRIBE_MESSAGE: "act80_auto_send_subscribe_message"
};

exports.BIRTH_DAY_URL = "/hserve/v2.5/gdftu/days-until-birth/";

exports.GET_BILL_COUPON_URL = "/hserve/v2.6/gdftu/mobile-topup/";

exports.GET_BIRTH_COUPON_URL = "/hserve/v2.6/gdftu/birth-coupon/";

exports.GET_NEW_USER_GIFT_URL = "/hserve/v2.6/gdftu/register-coupon/";

exports.GET_NEW_USER_GIFT_URL_V2 = "/hserve/v2.7/gdftu/register-coupon/";

exports.GET_INVITE_GIFT_URL = "/dserve/v2.7/gdftu/invite-coupon/";

exports.COOL_SUMMER_URL = "/hserve/v2.7/gdftu/summer-event-coupon/";

exports.GET_USER_PROFILE = "/hserve/v2.6/gdftu/user-profile/";

exports.GET_USER_PROFILE_V2 = "/hserve/v2.7/gdftu/user-profile/";

exports.ACT9_SUBMIT_BOOK_COLLECT = "/hserve/v2.7/gdftu/aug-book-collection/";

exports.ACT9_WISH_LIST = "/hserve/v2.7/gdftu/aug-wish/";

exports.ACT10_JOIN_TEAM = "/hserve/v2.7/gdftu/sept-step/team/";

exports.ACT10_CREATE_TEAM = "/hserve/v2.7/gdftu/sept-step/team/";

exports.ACT10_STEP_PUNCH = "/hserve/v2.7/gdftu/sept-step/punch/";

exports.QA_5204_HOST = "https://v5204.eng.szx.ifanrx.com";

exports.HSERVE_API = {
    ACT11_REWARDS_CREDIT: "/hserve/v2.7/gdftu/rewards/credit/",
    ACT11_REDEEM_PRODUCT: "/hserve/v2.7/gdftu/rewards/product/",
    ACT12_ANNUAL_SUMMARY: "/hserve/v2.7/gdftu/2021-annual-summary/",
    DECODE_JWT: "/hserve/v2.8/gdftu/user-profile/"
};

exports.TIGER_CARD_API = {
    ACT13_TIGER_CARD_LOG: "/hserve/v2.8/gdftu/tiger-card/log/",
    ACT13_TIGER_CARD_BONUS: "/hserve/v2.8/gdftu/tiger-card/bonus/",
    ACT13_TIGER_CARD_REDEEM: "/hserve/v2.8/gdftu/tiger-card/redeem/",
    ACT13_TIGER_CARD_MERGE: "/hserve/v2.8/gdftu/tiger-card/merge/",
    ACT13_TIGER_CARD_SENT_DIALOG: "/hserve/v2.8/gdftu/tiger-card/sent-dialog/",
    ACT13_TIGER_CARD_SHARE_REWARD: "/hserve/v2.8/gdftu/tiger-card/card-reward/"
};

exports.ACT15_WOMENS_DAY_API = {
    getCurrentDateLog: "/hserve/v2.8/gdftu/2022/iwd/activity-daily-log/",
    consumptionChance: "/hserve/v2.8/gdftu/2022/iwd/chance-consumption/",
    dailyLottery: "/hserve/v2.8/gdftu/2022/iwd/daily-lottery/",
    chanceRedemption: "/hserve/v2.8/gdftu/2022/iwd/chance-redemption/"
};

exports.ACT30_DRAW_LOTTERY_API = "/hserve/v2.8/gdftu/activity/act30/draw/";

exports.STORAGE_KEYS = {
    USERINFO: "userinfo",
    REFERRERINFO: "referrerInfo"
};

exports.EVENTS_BUS = {
    INIT_WITH_USER_INFO: "INIT_WITH_USER_INFO"
};

exports.FILE_CATEGORY = {
    DEFAULT: "5fa4c8158a2efa03be55ce3c",
    ACTIVITY: "5fd741b9bd5435231acdf355",
    ACR3_WOMEN: "604b47f422a1864b23688666",
    ACT6_PARTY: "6086217377c7ee64c87f1d1c",
    EXPORT_EXCEL: "608b7c8323542b2e7e0973cd",
    PRIZE: "639fd9316e53e14c72938378",
    AVATAR: "6475c39b8f38c964be1945f4"
};

exports.FILE_CATEGORY_DEV = {
    DEFAULT: "5fd7415f7ac4992a1d89fb3b",
    ACTIVITY: "5fd7415f7ac4992a1d89fb3b",
    ACR3_WOMEN: "604b47c522a1864fe5e03cbf",
    ACT6_PARTY: "60862086482dd17e5e9da51b",
    EXPORT_EXCEL: "608b7c6023542b1c75098772",
    PRIZE: "639fd8cabfa32a1fdf93bff1",
    AVATAR: "6475c3268f38c964be194561"
};

exports.SUBSCRIBE_MESSAGE_TEMPLATES = {
    FEEDBACK_RESULT: "bxG1IIiYUvzEizAK8zB0t2ADutSKIQV9x5dTLmADe6M",
    SUBSCRIBE_REMIND: "-0dy7NnhrSHvdTsBi66p15rvYnb3bTtzQ0jwVtV4DyE",
    SUBSCRIBE_BIRTHDAY_OR_BILL_COUPON: "pN13mODtRmVJl10IiycaeguaDZ6Vk8mM1mNWI0pQsKY",
    ACT9_LOTTERY_RESULT: "uvg85OeYKP9gOyXpF4P4BC3SuljsKE_bFaMbmAqhZPI",
    ACT10_ACTIVITY_PROCESSING: "-0dy7NnhrSHvdTsBi66p15rvYnb3bTtzQ0jwVtV4DyE",
    ACT10_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BDZMXar8SWLUOmuGDkwkqjQ",
    ACT14_LOTTERY_NOTICE: "6KWARy0OE89w4-XBHrWgLBPlwZyENN0iSes6wWq_zG8",
    ACT15_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BDZMXar8SWLUOmuGDkwkqjQ",
    ACT20_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BDZMXar8SWLUOmuGDkwkqjQ",
    ACT20_REDEEM_LOTTERY_NOTICE: "-0dy7NnhrSHvdTsBi66p15rvYnb3bTtzQ0jwVtV4DyE",
    ACT27_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BKI7oG8wDlcsZh3huRNCSeU",
    ACT30_PARTICIPATE_NOTICE: "-0dy7NnhrSHvdTsBi66p102xqKCzddLbavW6-W1drI0",
    ACT32_REDEEM_LOTTERY_NOTICE: "3iyI9X1quh0kWYBHWOY2yUtcuH7Zi2GOMyFAs7GxSiE",
    ACT33_FULL_TEAM_NOTICE: "-0dy7NnhrSHvdTsBi66p102xqKCzddLbavW6-W1drI0",
    ACT33_LOTTERY_NOTICE: "7565_mcFYhvUGl7fHUD436Bs3GGkpEVhGc5Ac9W7g3k",
    ACT33_REDEEM_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BEx3dANw_B2YNWOn7NqJW38",
    ACT34_ACTIVITY_PROGRESS_NOTICE: "WbGHBwpUanzLQFio7T04ubyU0-odXaEnVmefgG8qpas",
    ACT39_LOTTERY_NOTICE: "uvg85OeYKP9gOyXpF4P4BDZMXar8SWLUOmuGDkwkqjQ",
    ACT39_LAST_REDEEM_LOTTERY_NOTICE: "-0dy7NnhrSHvdTsBi66p15rvYnb3bTtzQ0jwVtV4DyE",
    ACT42_PARTICIPATE_NOTICE: "",
    ACT48_SEND_PARTICIPATION_MESSAGE: "WbGHBwpUanzLQFio7T04ubyU0-odXaEnVmefgG8qpas",
    ACT48_SEND_SUBSCRIBE_MESSAGE: "uvg85OeYKP9gOyXpF4P4BKI7oG8wDlcsZh3huRNCSeU",
    ACT54_SEND_PARTICIPATION_MESSAGE: "-0dy7NnhrSHvdTsBi66p102xqKCzddLbavW6-W1drI0",
    ACT54_LAST_REDEEM_LOTTERY_NOTICE: "E2FUe_feQ7apk22k598pYLHiy1hD7GxPR4qMt0P5wV0",
    ACT61_LOTTERY_NOTICE: "6KWARy0OE89w4-XBHrWgLBPlwZyENN0iSes6wWq_zG8",
    ACT66_LOTTERY_NOTICE: "6KWARy0OE89w4-XBHrWgLBPlwZyENN0iSes6wWq_zG8",
    ACT66_SEND_PARTICIPATION_MESSAGE: "-0dy7NnhrSHvdTsBi66p102xqKCzddLbavW6-W1drI0"
};

exports.QQ_MAP_KEY = "JNHBZ-2TAWQ-HYA5K-GSWUR-CCYN7-RCBIT";

exports.RSA_PUBLIC_KEY = "";

exports.ES_PRIVATE_KEY = "";

exports.OWNER_APP_ID = "wxf69f6723856c6f89";

exports.YUE_GONG_HUI = {
    appId: {
        develop: "wx48a09ec1e5332fef",
        release: "wxa347528a6dddc56d"
    },
    path: "/pages/third/third",
    fwid: "1634293060410852",
    envVersion: {
        release: "release",
        trial: "trial",
        develop: "develop"
    }
};

exports.NEW_YUE_GONG_HUI = {
    appId: "wxfcc5a91b4f0d6e38",
    path: "/pages/auth/index"
};

var t = {
    APPID: "wx0f6ff4331a30adc9"
};

exports.YUE_GONG_HUI_GOU = t;

var _ = {
    APPID: t.APPID,
    PATH: "/pages/coupon-offer/coupon-offer"
};

exports.YUE_GONG_HUI_GOU_COUPON_PATH = _;

exports.GUANG_DONG_HONG_MINIPROGRAM = {
    APPID: "wx2478a87602a76401",
    PATH: "/pages/index/index"
};

exports.TENCENT_RECHARGE_MINIPROGRAM = {
    appId: "wxad3150031786d672",
    path: "indepent/pages/main"
};

var a = {
    appId: t.APPID,
    path: "pages/coupon-list/coupon-list?type=coupon"
};

exports.UNION_BUY_GOU_MINIPROGRAM = a;

exports.ACT24_SUBSCRIBE_MESSAGE_TEMPLATES = {
    FEEDBACK_RESULT: "WbGHBwpUanzLQFio7T04ubyU0-odXaEnVmefgG8qpas",
    SUBSCRIBE_REMIND: "-0dy7NnhrSHvdTsBi66p1x7G_jiBTIMArIDc47rmfL0",
    SUBSCRIBE_BIRTHDAY_OR_BILL_COUPON: "NLPiw32JXnhq00s5w2bwIpFYoWjvtFZwYN4kaG17E60"
};