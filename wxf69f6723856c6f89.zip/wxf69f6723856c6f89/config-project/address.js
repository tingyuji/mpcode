Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    440000: [ "广东省", "086" ],
    440100: [ "广州市", "440000" ],
    440200: [ "韶关市", "440000" ],
    440300: [ "深圳市", "440000" ],
    440400: [ "珠海市", "440000" ],
    440500: [ "汕头市", "440000" ],
    440600: [ "佛山市", "440000" ],
    440700: [ "江门市", "440000" ],
    440800: [ "湛江市", "440000" ],
    440900: [ "茂名市", "440000" ],
    441200: [ "肇庆市", "440000" ],
    441300: [ "惠州市", "440000" ],
    441400: [ "梅州市", "440000" ],
    441500: [ "汕尾市", "440000" ],
    441600: [ "河源市", "440000" ],
    441700: [ "阳江市", "440000" ],
    441800: [ "清远市", "440000" ],
    441900: [ "东莞市", "440000" ],
    442000: [ "中山市", "440000" ],
    445100: [ "潮州市", "440000" ],
    445200: [ "揭阳市", "440000" ],
    445300: [ "云浮市", "440000" ]
}, t = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "086", n = [];
    return Object.keys(e).map(function(o) {
        e[o][1] === t && n.push({
            id: o,
            name: e[o][0]
        });
    }), n;
}, n = {
    CN_AREA: e,
    findLocationObject: t,
    toLocationObjectMultiArray: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "086", n = [ [], [], [] ];
        return n[0] = t(e), n[0].length > 0 && (n[1] = t(n[0][0].id), n[1].length > 0 && (n[2] = t(n[1][0].id))), 
        n;
    }
};

exports.default = n;