var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../animate-modal/animate-position")), i = e(require("../../lib/wx-utils")), n = e(require("../../lib/device"));

Component({
    properties: {
        visible: Boolean,
        url: String,
        posterModalOpt: Object
    },
    data: {
        navbarHeight: n.default.getNavbarHeight(),
        CENTER_ZOOM: a.default.CENTER_ZOOM,
        defaultModal: {
            leftItem: {
                title: "分享给朋友",
                url: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1kkkK0M9WaYyRPuP.png"
            },
            rightItem: {
                title: "保存分享卡片",
                url: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1kkkK0QVEYpCpC8g.png"
            }
        }
    },
    methods: {
        previewShareImage: function() {
            wx.previewImage({
                urls: [ this.data.url ],
                current: this.data.url
            });
        },
        saveImage: function() {
            var e = this;
            return r(t().mark(function r() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, i.default.askSettingAuthorizeCall("saveImageToPhotosAlbum", {
                            filePath: e.data.url
                        });

                      case 2:
                        t.sent && wx.showToast({
                            title: "图片已保存相册"
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        tapClose: function() {
            this.triggerEvent("close");
        }
    }
});