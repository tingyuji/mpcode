var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/objectSpread2"), n = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../lib/baas")), i = e(require("../../lib/pubsub")), s = e(require("../../io/index")), u = e(require("../../lib/wx-utils"));

Component({
    externalClasses: [ "ext-class" ],
    properties: {
        withPhone: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    lifetimes: {
        attached: function() {
            this.init(), i.default.sub("INIT_WIHT_AUTH_PHONE", this.init, this);
        },
        detached: function() {
            i.default.unsub("INIT_WIHT_AUTH_PHONE", this.init, this);
        }
    },
    pageLifetimes: {
        show: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e = this;
            return r(n().mark(function t() {
                var r, i;
                return n().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, wx.BaaS.auth.getCurrentUser();

                      case 2:
                        r = t.sent, i = !!r._attribute.wechat_phone, e.setData({
                            isAuth: a.default.isAuth(),
                            hasPhone: i
                        });

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        getUserInfoByProfile: function() {
            var e = this;
            wx.getUserProfile({
                desc: "用户登录",
                success: function(t) {
                    wx.BaaS.auth.updateUserInfo(t).then(function(t) {
                        a.default.setStorage("userinfo", t), e.onAuthSuccess(t), e.init();
                    });
                },
                complete: function() {
                    wx.hideLoading();
                }
            });
        },
        getPhoneNumber: function(e) {
            var i = this;
            return r(n().mark(function r() {
                var s, u, o, c, h, f, l, p;
                return n().wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (wx.showLoading({
                            mask: !0
                        }), s = e.detail, u = s.errMsg, o = s.iv, c = s.encryptedData, !/user deny/.test(u)) {
                            n.next = 6;
                            break;
                        }
                        return console.log("请求手机号授权失败"), wx.hideLoading(), n.abrupt("return");

                      case 6:
                        return h = {}, n.prev = 7, n.next = 10, wx.BaaS.wxDecryptData(c, o, "phone-number");

                      case 10:
                        h = n.sent, n.next = 19;
                        break;

                      case 13:
                        return n.prev = 13, n.t0 = n.catch(7), wx.showToast({
                            title: "获取手机号失败",
                            icon: "none"
                        }), console.log("获取手机号失败"), wx.hideLoading(), n.abrupt("return");

                      case 19:
                        return f = h.purePhoneNumber, i.onAuthPhoneSuccess(f), n.next = 23, wx.BaaS.auth.getCurrentUser();

                      case 23:
                        return l = n.sent, n.next = 26, l.setMobilePhone(f);

                      case 26:
                        l = n.sent, p = a.default.getStorage("userinfo"), a.default.setStorage("userinfo", t(t({}, p), l)), 
                        i.init();

                      case 30:
                      case "end":
                        return n.stop();
                    }
                }, r, null, [ [ 7, 13 ] ]);
            }))();
        },
        getPhoneNumberMirror: function(e) {
            var a = this;
            wx.showLoading({
                mask: !0
            });
            var i, o, c = e.detail, h = c.iv, f = c.encryptedData;
            if (!h || !f) return u.default.showToast("使用该功能需授权手机号"), console.log("用户拒绝授权手机号码"), 
            void wx.hideLoading();
            wx.checkSession({
                success: (o = r(n().mark(function r(i) {
                    return n().wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            return n.prev = 0, n.next = 3, s.default.invoke("act3_decrypt_phone", t(t({}, e.detail), {}, {
                                type: "phone-number"
                            }));

                          case 3:
                            200 === n.sent.data.code ? a.init() : a.reLogin(), n.next = 12;
                            break;

                          case 8:
                            n.prev = 8, n.t0 = n.catch(0), console.log("授权手机号码失败: ", n.t0), a.reLogin();

                          case 12:
                          case "end":
                            return n.stop();
                        }
                    }, r, null, [ [ 0, 8 ] ]);
                })), function(e) {
                    return o.apply(this, arguments);
                }),
                fail: (i = r(n().mark(function e() {
                    return n().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            a.reLogin();

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function() {
                    return i.apply(this, arguments);
                }),
                complete: function() {
                    wx.hideLoading();
                }
            });
        },
        reLogin: function() {
            return r(n().mark(function e() {
                return n().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, wx.BaaS.auth.logout();

                      case 2:
                        wx.BaaS.auth.loginWithWechat(), u.default.showToast("登录信息过期，请重试");

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        onAuthSuccess: function(e) {
            i.default.pub("INIT_WIHT_AUTH_PHONE"), this.triggerEvent("onAuthSuccess", e, {});
        },
        onAuthPhoneSuccess: function(e) {
            i.default.pub("INIT_WIHT_AUTH_PHONE"), this.triggerEvent("onAuthPhoneSuccess", e, {});
        },
        triggerSuccess: function(e) {
            this.triggerEvent("done", e);
        },
        noop: function() {}
    }
});