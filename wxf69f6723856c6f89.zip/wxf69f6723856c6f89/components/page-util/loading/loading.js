var t = require("../../../@babel/runtime/helpers/toConsumableArray");

Component({
    lifetimes: {
        attached: function() {
            var t = this, e = wx.createSelectorQuery();
            e.in(this), e.select(".lds-spinner").boundingClientRect(function(e) {
                var n = e.width || e.height;
                n ? t.setData({
                    spin: t.generateSpin(n)
                }) : console.error("需要设置 <loading> 元素的宽或高");
            }), e.exec();
        }
    },
    data: {
        spin: []
    },
    methods: {
        generateSpin: function(e) {
            return t(new Array(12)).map(function(t, n) {
                var r = .08 * e, a = .25 * e, i = {
                    index: n,
                    left: "".concat((e - r) / 2, "px"),
                    width: "".concat(r, "px"),
                    height: "".concat(a, "px"),
                    transform: "rotate(".concat(30 * n, "deg)"),
                    "border-radius": "".concat(r / 2, "px"),
                    "transform-origin": "50% ".concat(e / 2, "px"),
                    "animation-delay": "".concat(.1 * (n - 12), "s")
                }, o = "";
                for (var c in i) o += "".concat(c, ": ").concat(i[c], ";");
                return {
                    style: o
                };
            });
        }
    }
});