Component({
    externalClasses: [ "custom-class" ],
    properties: {
        iconSrc: {
            type: String,
            value: ""
        },
        btnText: {
            type: String,
            value: ""
        },
        background: {
            type: String,
            value: "linear-gradient(180deg, #5B9DFE 0%, #1A6EEB 83.33%)"
        }
    },
    attached: function() {
        var t = this.data, n = t.iconSrc, e = t.btnText, a = t.background;
        this.setData({
            iconSrc: n,
            btnText: e,
            background: a
        });
    },
    methods: {
        onBtnTap: function() {
            this.triggerEvent("btnTap", {}, {});
        }
    }
});