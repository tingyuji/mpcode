var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), i = t(require("../../lib/device")), a = t(require("./animate-position")), o = t(require("../../utils/behaviors/util-behavior")), r = require("../../lib/common");

Component({
    options: {
        multipleSlots: !0
    },
    externalClasses: [ "modal-class", "modal-content-class" ],
    behaviors: [ o.default ],
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        enter: {
            type: String,
            value: a.default.OVER_TOP
        },
        leave: {
            type: String,
            value: a.default.BELOW_BOTTOM
        },
        closeOnClickOutside: {
            type: Boolean,
            value: !1
        },
        zIndex: {
            type: Number,
            value: 9998
        }
    },
    observers: {
        visible: function(t) {
            this.toggle(t);
        }
    },
    lifetimes: {
        created: function() {
            this.containerAnimation = wx.createAnimation(), this.modalAnimation = wx.createAnimation();
        },
        attached: function() {
            var t = this;
            return n(e().mark(function n() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        t.resetPromise = t.resetModalInitialPosition();

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, n);
            }))();
        }
    },
    data: {
        fadeInDuration: 220,
        fadeOutDuration: 220,
        contentVisible: !1,
        containerAnimation: null,
        modalAnimation: null,
        screenHeight: i.default.getScreenHeight()
    },
    methods: {
        toggle: function(t) {
            var i = this;
            return n(e().mark(function n() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, i.resetPromise;

                      case 2:
                        return e.abrupt("return", t ? i.show() : i.hide());

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, n);
            }))();
        },
        show: function() {
            var t = this;
            this.setDataPromise({
                contentVisible: !0
            }).then(function() {
                var e = t.containerAnimation, n = t.modalAnimation;
                t.setData({
                    contentVisible: !0,
                    containerAnimation: e.opacity(1).step({
                        duration: t.data.fadeInDuration
                    }).export(),
                    modalAnimation: n.translateY(0).scale(1).step({
                        duration: t.data.fadeInDuration,
                        timingFunction: "ease-out"
                    }).export() || null
                });
            });
        },
        hide: function() {
            var t = this, e = this.containerAnimation, n = this.data.fadeOutDuration;
            this.setDataPromise({
                containerAnimation: e.opacity(0).step({
                    duration: n
                }).export(),
                modalAnimation: this.exportAnimation(this.data.leave) || null
            }).then(function() {
                return (0, r.delay)(n);
            }).then(function() {
                t.setData({
                    contentVisible: !1
                }), t.resetPromise = t.resetModalInitialPosition();
            });
        },
        animationOverTop: function() {
            var t = this.data, e = t.fadeOutDuration, n = t.screenHeight;
            return this.modalAnimation.translateY(-n / 2).step({
                duration: e
            }).export();
        },
        animationBelowBottom: function() {
            var t = this.data, e = t.fadeOutDuration, n = t.screenHeight;
            return this.modalAnimation.translateY(n / 2).step({
                duration: e,
                timingFunction: "ease-out"
            }).export();
        },
        animationCenterZoom: function() {
            var t = this.data.fadeOutDuration;
            return this.modalAnimation.scale(0).step({
                duration: t,
                timingFunction: "ease-out"
            }).export();
        },
        exportAnimation: function(t) {
            switch (t) {
              case a.default.OVER_TOP:
                return this.animationOverTop();

              case a.default.BELOW_BOTTOM:
                return this.animationBelowBottom();

              case a.default.CENTER_ZOOM:
                return this.animationCenterZoom();
            }
        },
        resetModalInitialPosition: function() {
            var t = this;
            return n(e().mark(function n() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, t.setDataPromise({
                            fadeOutDuration: 0,
                            modalAnimation: t.exportAnimation(t.data.enter) || null
                        });

                      case 2:
                        return e.next = 4, t.setDataPromise({
                            fadeOutDuration: 220
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, n);
            }))();
        },
        clickOutside: function() {
            this.data.closeOnClickOutside && this.triggerEvent("close", {}, {
                bubbles: !0,
                composed: !0,
                capturePhase: !0
            });
        },
        stopPropagation: function() {}
    }
});