Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var O = {
    OVER_TOP: "OVER_TOP",
    BELOW_BOTTOM: "BELOW_BOTTOM",
    CENTER_ZOOM: "CENTER_ZOOM"
};

exports.default = O;