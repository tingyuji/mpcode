var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../../lib/wx-utils"));

Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        coverImage: {
            type: String,
            value: ""
        },
        posterHeight: {
            type: String,
            value: "800rpx"
        },
        shareIcon: {
            type: String,
            value: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1npR90WI5gnLGbku.png"
        },
        enableWechatShare: {
            type: Boolean,
            value: !0
        }
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        savePoster: function() {
            var e = this;
            return r(t().mark(function r() {
                var n, o;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.triggerEvent("savePoster"), n = e.data.coverImage) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", a.default.showToast("保存失败，请重试"));

                      case 4:
                        return t.prev = 4, t.next = 7, wx.getImageInfo({
                            src: n
                        });

                      case 7:
                        return o = t.sent, t.next = 10, a.default.askSettingAuthorizeCall("saveImageToPhotosAlbum", {
                            filePath: o.path
                        });

                      case 10:
                        t.sent && a.default.showToast("图片已保存到相册"), t.next = 17;
                        break;

                      case 14:
                        t.prev = 14, t.t0 = t.catch(4), a.default.showToast("保存失败，请重试");

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 4, 14 ] ]);
            }))();
        },
        noop: function() {}
    }
});