var e = require("../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../@babel/runtime/helpers/Arrayincludes");

var a = e(require("../../lib/device")), t = e(require("../../lib/router")), r = require("../../lib/common"), o = require("../../utils/string");

Component({
    externalClasses: [ "container-class" ],
    properties: {
        active: {
            type: Boolean,
            value: !0
        },
        isFixed: {
            type: Boolean,
            value: !1
        },
        showBackBtn: {
            type: Boolean,
            value: !0
        },
        frontColor: {
            type: String,
            value: "black"
        },
        homeColor: {
            type: String,
            value: "white"
        },
        placeholder: {
            type: Boolean,
            value: !0
        },
        title: {
            type: String,
            value: ""
        },
        titleColor: {
            type: String,
            value: "black"
        },
        backgroundColor: {
            type: String,
            value: "#ffffff"
        },
        whiteArraw: {
            type: Boolean,
            value: !1
        },
        blackArraw: {
            type: Boolean,
            value: !1
        },
        backgroundImage: {
            type: String,
            value: ""
        },
        iconBack: {
            type: String,
            value: "white"
        },
        fadeDuration: {
            type: Number,
            value: 300
        },
        fadeTimingFunc: {
            type: String,
            value: "ease-out"
        },
        backAgent: {
            type: Boolean,
            value: !1
        },
        onlyShowBtn: {
            type: Boolean,
            value: !1
        }
    },
    observers: {
        frontColor: function() {
            this.updateWxNavBarNextTick();
        }
    },
    attached: function() {
        var e = getCurrentPages(), t = this.data, r = t.active, o = t.titleColor, n = t.frontColor, i = t.backgroundColor, l = t.backgroundImage;
        this.setData({
            active: r,
            titleColor: o,
            frontColor: n,
            backgroundColor: i,
            backgroundImage: l,
            statusBarHeight: a.default.getStatusBarHeight(),
            navBarHeight: a.default.getNavbarHeight(),
            showHomeBtn: 1 === e.length && "pages/index/index" !== e[0].route
        }), this.updateWxNavBarNextTick();
    },
    methods: {
        navBack: function() {
            this.data.backAgent ? this.triggerEvent("back") : t.default.back();
        },
        navToIndex: function() {
            var e = getCurrentPages()[0].route;
            (e = e.split("/")).splice(-2, 2, "index", "index");
            var a = e.join("/");
            a.includes("packages2021") || a.includes("packages2022") || a.includes("packages2023") ? wx.switchTab({
                url: "/pages/index/index"
            }) : wx.switchTab({
                url: "/" + a
            });
        },
        updateWxNavBarNextTick: function() {
            var e = this;
            (0, r.delay)(0).then(function() {
                var a = e.data, t = a.frontColor, r = a.backgroundColor, n = a.fadeDuration, i = a.fadeTimingFunc;
                wx.setNavigationBarColor({
                    frontColor: "black" === t ? "#000000" : "#ffffff",
                    backgroundColor: r,
                    animation: {
                        duration: n,
                        timingFunc: (0, o.toCamelCase)(i)
                    }
                });
            });
        }
    }
});