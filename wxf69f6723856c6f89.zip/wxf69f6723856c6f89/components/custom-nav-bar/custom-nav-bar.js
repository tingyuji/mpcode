var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, t = (0, 
require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../lib/device")), a = require("../../config-project/miniprogram"), o = e(require("../../behaviors/intersection-observer"));

Component({
    behaviors: [ o.default ],
    properties: {
        active: {
            type: Boolean,
            value: !0
        },
        title: {
            type: String,
            value: ""
        },
        backgroundColor: {
            type: String,
            value: "transparent"
        },
        backgroundImage: {
            type: String,
            value: ""
        },
        showBackBtn: {
            type: Boolean,
            value: !0
        },
        frontColor: {
            type: String,
            value: "white"
        },
        homeColor: {
            type: String,
            value: "white"
        },
        hasLogo: {
            type: Boolean,
            value: !1
        },
        logoColor: {
            type: String,
            value: "white"
        },
        backAgent: {
            type: Boolean,
            value: !1
        },
        backHome: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: Boolean,
            value: !0
        },
        scrollBackgroundColor: {
            type: String,
            value: "transparent"
        },
        scrollOffset: {
            type: Number,
            value: 0
        }
    },
    attached: function() {
        this.observeToggleNavbar();
        var e = this.data, a = e.active, o = e.backgroundColor, r = e.backgroundImage, l = e.frontColor, i = e.homeColor;
        this.setData({
            active: a,
            backgroundColor: o,
            backgroundImage: r,
            frontColor: l,
            homeColor: i,
            statusBarHeight: t.default.getStatusBarHeight(),
            navBarHeight: t.default.getNavbarHeight(),
            hasBackBtn: getCurrentPages().length > 1
        }), wx.setNavigationBarColor({
            frontColor: "white" === l ? "#ffffff" : "#000000",
            backgroundColor: o
        });
    },
    methods: {
        observeToggleNavbar: function() {
            var e = this, t = this.data.backgroundColor, a = this.data.scrollOffset;
            this.createAutoIntersectionObserver().relativeToViewport({
                top: a
            }).observe(".ghost", function(a) {
                o.observeUtils.isLeft(a) ? e.setData({
                    backgroundColor: e.data.scrollBackgroundColor
                }) : e.setData({
                    backgroundColor: t
                });
            });
        },
        navBack: function() {
            this.data.backAgent ? this.triggerEvent("back") : this.data.backHome ? this.navHome() : wx.navigateBack({
                delta: 1
            });
        },
        navHome: function() {
            wx.switchTab({
                url: a.ROUTE.HOME
            });
        }
    }
});