Component({
    properties: {
        showZero: {
            type: Boolean,
            value: !1
        },
        overflowCount: {
            type: Number
        },
        count: {
            type: [ Number, String ]
        }
    }
});