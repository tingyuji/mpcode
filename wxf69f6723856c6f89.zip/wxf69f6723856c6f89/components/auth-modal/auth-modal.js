var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, i = require("../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../lib/auth")), r = e(require("../../lib/wx-utils")), a = e(require("../../lib/pubsub")), s = require("../../config-project/baas"), u = require("../../config/index");

Component({
    properties: {
        identifyTips: {
            type: String,
            value: "前往实名制"
        },
        pendingJoinUnionTips: {
            type: String,
            value: "入会审核中"
        },
        joinUnionTips: {
            type: String,
            value: "加入工会，享受更多权益"
        },
        memberTips: {
            type: String,
            value: "您已经是会员"
        },
        visible: {
            type: Boolean,
            value: !1
        }
    },
    lifetimes: {
        attached: function() {
            this.init(), a.default.sub(s.EVENTS_BUS.INIT_WITH_USER_INFO, this.init, this);
        },
        detached: function() {
            a.default.unsub(s.EVENTS_BUS.INIT_WITH_USER_INFO, this.init, this);
        }
    },
    data: {
        isIdentify: !1,
        isJoinedTradeUnion: !1,
        isPendingJoinTradeUnion: !1,
        userInfo: {}
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        },
        init: function() {
            var e = this;
            return t(i().mark(function t() {
                return i().wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return i.t0 = e, i.next = 3, n.default.getUserInfo();

                      case 3:
                        i.t1 = i.sent, i.t2 = n.default.isIdentify(), i.t3 = n.default.isJoinedTradeUnion(), 
                        i.t4 = n.default.isPendingJoinTradeUnion(), i.t5 = {
                            userInfo: i.t1,
                            isIdentify: i.t2,
                            isJoinedTradeUnion: i.t3,
                            isPendingJoinTradeUnion: i.t4
                        }, i.t0.setData.call(i.t0, i.t5);

                      case 9:
                      case "end":
                        return i.stop();
                    }
                }, t);
            }))();
        },
        navToAuth: function() {
            n.default.navToAuth({
                envVersion: u.DEV ? "develop" : "release"
            }).catch(function(e) {
                /fail cancel/.test(null == e ? void 0 : e.errMsg) ? r.default.showToast("取消跳转小程序") : r.default.showToast("跳转小程序失败");
            });
        }
    }
});