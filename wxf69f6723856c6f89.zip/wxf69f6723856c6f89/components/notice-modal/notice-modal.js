var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), i = e(require("../../io/index")), n = require("../../config/constants");

Component({
    properties: {
        activityAlias: {
            type: String,
            value: "global"
        }
    },
    lifetimes: {
        attached: function() {
            this.getNoticeInfo();
        }
    },
    data: {
        notice: {}
    },
    methods: {
        getNoticeInfo: function() {
            var e = this;
            return r(t().mark(function r() {
                var a, o;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, i.default.getGdftuSettingsByKey(n.SETTING_KEYS.NOTICE);

                      case 3:
                        a = t.sent, o = a[e.data.activityAlias] || {}, e.setData({
                            notice: o
                        }), t.next = 11;
                        break;

                      case 8:
                        t.prev = 8, t.t0 = t.catch(0), console.log("request notice modal config err", t.t0);

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 0, 8 ] ]);
            }))();
        },
        close: function() {
            this.setData({
                "notice.visible": !1
            });
        }
    }
});