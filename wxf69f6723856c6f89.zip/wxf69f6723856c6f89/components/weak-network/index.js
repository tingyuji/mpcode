var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), r = e(require("../../lib/promise/delay")), a = e(require("../../lib/wx-utils"));

Component({
    lifetimes: {
        ready: function() {
            this.getNetworkStatus();
        },
        detached: function() {
            var e, t, n, r;
            null === (e = (t = wx).offNetworkStatusChange) || void 0 === e || e.call(t), null === (n = (r = wx).offNetworkWeakChange) || void 0 === n || n.call(r), 
            this.resetStatus();
        }
    },
    data: {
        networkStatus: {
            isConnected: !0,
            weakNet: !1,
            networkType: "none"
        }
    },
    methods: {
        emptyTap: function() {},
        resetStatus: function() {
            this.setData({
                networkStatus: {
                    isConnected: !0,
                    weakNet: !1,
                    networkType: "none"
                }
            });
        },
        getNetworkStatus: function() {
            var e, t, n, r, a = this;
            null === (e = (t = wx).onNetworkStatusChange) || void 0 === e || e.call(t, function(e) {
                a.setData({
                    "networkStatus.isConnected": e.isConnected,
                    "networkStatus.networkType": e.networkType
                });
            }), null === (n = wx) || void 0 === n || null === (r = n.onNetworkWeakChange) || void 0 === r || r.call(n, function(e) {
                a.setData({
                    "networkStatus.weakNet": e.weakNet,
                    "networkStatus.networkType": e.networkType
                });
            });
        },
        fakeReconnect: function() {
            var e = this;
            return n(t().mark(function n() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return e.fakeReconnectCount++, e.setData({
                            triggerNetConnect: !0
                        }), t.next = 4, (0, r.default)(2e3);

                      case 4:
                        e.setData({
                            triggerNetConnect: !1
                        }), a.default.showToast("尝试重连失败，请检查网络", {
                            duration: 2e3
                        });

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        }
    }
});