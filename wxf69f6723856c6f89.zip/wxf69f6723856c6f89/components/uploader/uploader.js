var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../io/index")), n = require("../../utils/array"), o = require("../../utils/censor"), i = e(require("../../utils/behaviors/util-behavior")), u = e(require("../../lib/wx-utils"));

Component({
    behaviors: [ i.default ],
    properties: {
        mode: {
            type: String,
            value: "image"
        },
        categoryId: {
            type: String
        },
        multiple: {
            type: Boolean,
            value: !0
        },
        censor: {
            type: Boolean,
            value: !0
        },
        name: {
            type: String,
            value: ""
        },
        imageCount: {
            type: Number,
            value: 9
        },
        showLoading: {
            type: Boolean,
            value: !0
        },
        sourceType: {
            type: Array,
            value: [ "album", "camera" ]
        }
    },
    data: {
        imageObjList: [],
        videoObj: {
            path: "",
            poster: ""
        },
        uploading: !1
    },
    lifetimes: {
        attached: function() {
            this.error = !1;
        }
    },
    methods: {
        addImage: function() {
            var e = this;
            this.error = !1, wx.chooseImage({
                count: this.data.imageCount,
                sizeType: [ "original", "compressed" ],
                sourceType: this.data.sourceType,
                success: function(t) {
                    if (e.triggerEvent("uploading"), !e.data.uploading) {
                        e.setData({
                            uploading: !0
                        }), !e.data.showLoading && wx.showLoading({
                            title: "图片上传中...",
                            mask: !0
                        });
                        var r = e.data.imageObjList, a = t.tempFilePaths, n = a.map(function(e) {
                            return {
                                path: e
                            };
                        }), i = e.data.multiple ? r.concat(n) : [ n[0] ];
                        return e.setData({
                            imageObjList: i
                        }), (e.data.censor ? (0, o.censorImage)(a).then(function(t) {
                            return e.filterOutRiskyImages(t);
                        }) : Promise.resolve()).then(function() {
                            return e.uploadLocalImages();
                        }).catch(function(e) {
                            return console.error(e);
                        }).then(function() {
                            e.setData({
                                uploading: !1
                            }), !e.data.showLoading && !e.error && wx.hideLoading();
                        });
                    }
                },
                fail: function() {
                    console.log("图片上传失败");
                }
            });
        },
        addVideo: function() {
            var e = this;
            return r(t().mark(function r() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        wx.chooseVideo({
                            camera: "back",
                            sourceType: [ "album", "camera" ],
                            success: function(t) {
                                if (e.triggerEvent("uploading"), !e.data.uploading) {
                                    e.setData({
                                        uploading: !0
                                    });
                                    var r = t.tempFilePath;
                                    return e.setData({
                                        videoObj: {
                                            path: r
                                        }
                                    }), e.uploadVideo().catch(function(e) {
                                        return console.error(e);
                                    }).then(function() {
                                        e.triggerEvent("uploaded"), e.setData({
                                            uploading: !1
                                        });
                                    });
                                }
                            }
                        });

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        filterOutRiskyImages: function(e) {
            e.some(function(e) {
                return e.risky;
            }) ? (this.showRiskyToast(), this.error = !0) : e.some(function(e) {
                return e.err;
            }) && (this.showOverSizeToast(), this.error = !0);
            var t = (0, n.keyBy)(e, "key"), r = this.data.imageObjList.filter(function(e) {
                if (e.url) return !0;
                var r = t[e.path];
                return r && !r.risky && !r.err;
            });
            return this.setDataPromise({
                imageObjList: r
            });
        },
        showRiskyToast: function() {
            return r(t().mark(function e() {
                return t().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, u.default.showToast("图片有违规风险 请重新上传照片");

                      case 2:
                        wx.hideLoading();

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        showOverSizeToast: function() {
            wx.showToast({
                title: "图片大小超出微信审核限制，请压缩后上传",
                icon: "none",
                duration: 3e3
            });
        },
        showUploadErrorToast: function() {
            wx.showToast({
                title: "部分图片上传失败，请重新尝试",
                icon: "none",
                duration: 3e3
            });
        },
        uploadLocalImages: function() {
            var e = this;
            console.log("image list uploading...");
            var t = this.data.imageObjList, r = t.filter(function(e) {
                return !e.url;
            });
            return a.default.uploadBaaSFileObjects(r, this.data.categoryId).then(function(r) {
                console.log("image list uploaded."), r.some(function(e) {
                    return e.error;
                }) && (e.showUploadErrorToast(), e.error = !0);
                var a = r.filter(function(e) {
                    return Boolean(e.url);
                });
                if (a.length) {
                    var n = t.filter(function(e) {
                        return Boolean(e.url);
                    }), o = [];
                    return a.map(function(e) {
                        o.push(e.url);
                    }), e.triggerEvent("change", {
                        name: e.data.name,
                        value: o || null
                    }), e.setDataPromise({
                        imageObjList: n
                    });
                }
            });
        },
        uploadVideo: function() {
            var e = this;
            return r(t().mark(function r() {
                var o;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return o = e.data.videoObj.path, t.abrupt("return", a.default.uploadBaaSFileObjects((0, 
                        n.toArray)({
                            path: o
                        }), e.data.categoryId).then(function(t) {
                            var r = t[0].url;
                            e.triggerEvent("change", {
                                name: e.data.name,
                                value: r
                            });
                        }));

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        uploadVideoPoster: function() {
            var e = this.data.videoObj.poster;
            return a.default.uploadBaaSFileObjects((0, n.toArray)({
                path: e
            }), this.data.categoryId).then(function(e) {
                return e[0].url;
            });
        }
    }
});