var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../lib/device"));

Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        navBarHeight: e.default.getNavbarHeight()
    },
    methods: {
        close: function() {
            this.triggerEvent("close");
        }
    }
});