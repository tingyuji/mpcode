var e, t, r = require("../../@babel/runtime/helpers/interopRequireDefault").default, a = require("../../@babel/runtime/helpers/toConsumableArray"), n = require("../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../@babel/runtime/helpers/defineProperty"), s = r(require("../../io/index")), u = r(require("../../lib/auth")), c = require("../../config/index"), p = require("../../lib/common"), l = {
    SENT_SUCCEEDED: "sent_succeeded",
    USED: "used",
    EXPIRED: "expired"
}, d = (o(e = {}, c.CONSTANTS.PRIZE_TYPE.WECHAT_DISCOUNT_COUPON, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgeLOWU4dSx1ZNo.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.WECHAT_RECHARGE_COUPON, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgeLOWU4dSx1ZNo.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.REDEEMPTION_TICKET, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgeLOWU4dSx1ZNo.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.GDFTU_BUY_COUPON, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgeLOWU4dSx1ZNo.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.PACKAGE_DELIVERY, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pQ1P9CRC7a0sfH2.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.WECHAT_TRANSFER, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pQ1P9Li02TZazlt.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.NAVIGATION, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pQ1P9QHFSmvjzG4.png"), 
o(e, c.CONSTANTS.PRIZE_TYPE.OFFLINE_REDEMPTION, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pqrwy9Bcua07BnP.png"), 
e), f = (o(t = {}, l.USED, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPJoBxJe4ynjVOF.png"), 
o(t, l.EXPIRED, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPJoG8tDeQdyUQb.png"), 
t);

Component({
    data: {
        PRIZE_LOG_STATUS: l,
        PRIZE_LOG_STATUS_BRAND: f,
        PRIZE_TYPE_ICON_MAP: d,
        prizeLogList: [],
        offset: 0,
        limit: 20,
        searchValue: "",
        hasMore: !0,
        activityAlias: ""
    },
    methods: {
        onLoad: function(e) {
            var t = e.activityAlias;
            this.setData({
                activityAlias: t
            }), this.init(t);
        },
        init: function(e) {
            var t = this;
            return i(n().mark(function r() {
                var a, i, o, s;
                return n().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, u.default.getUserInfo();

                      case 2:
                        return a = r.sent, t.userinfo = a, r.next = 6, t.getPrizeLogList(e);

                      case 6:
                        i = r.sent, o = i.prizeLogList, s = i.hasMore, t.setData({
                            prizeLogList: o,
                            hasMore: s,
                            offset: t.data.offset + o.length
                        });

                      case 10:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }))();
        },
        getPrizeLogList: function(e) {
            var t = this;
            return i(n().mark(function r() {
                var a, i, o, u, c, p, d, f, h, E, T;
                return n().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return a = t.data, i = a.offset, o = a.limit, u = a.searchValue, c = s.default.query.compare("created_by", "=", t.userinfo.id).in("status", [ l.SENT_SUCCEEDED, l.USED, l.EXPIRED ]), 
                        e && c.compare("activity_alias", "=", e), p = s.default.query, u && (p = wx.BaaS.Query.or(s.default.query.contains("activity_name", u), s.default.query.contains("prize_name", u))), 
                        d = wx.BaaS.Query.and(c, p), r.prev = 6, wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), r.next = 10, s.default.prizeLog.find({
                            query: d,
                            offset: i,
                            limit: o,
                            plain: !1,
                            expand: "activity"
                        });

                      case 10:
                        return f = r.sent, h = f.data, E = h.meta.next, T = h.objects, r.abrupt("return", {
                            prizeLogList: T,
                            hasMore: !!E
                        });

                      case 17:
                        return r.prev = 17, r.t0 = r.catch(6), r.abrupt("return", {
                            prizeLogList: [],
                            hasMore: !1
                        });

                      case 20:
                        return r.prev = 20, wx.hideLoading(), r.finish(20);

                      case 23:
                      case "end":
                        return r.stop();
                    }
                }, r, null, [ [ 6, 17, 20, 23 ] ]);
            }))();
        },
        search: (0, p.debounce)(function() {
            var e = i(n().mark(function e(t) {
                var r, a, i, o;
                return n().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return r = t.detail.value, this.setData({
                            searchValue: r,
                            offset: 0
                        }), e.next = 4, this.getPrizeLogList();

                      case 4:
                        a = e.sent, i = a.prizeLogList, o = a.hasMore, this.setData({
                            prizeLogList: i,
                            hasMore: o,
                            offset: this.data.offset + i.length
                        });

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), 1500),
        navToCouponDetail: function(e) {
            var t = this.data.activityAlias, r = e.currentTarget.dataset.id, a = "".concat(c.ROUTE.COUPON_DETAIL, "?prizeLogId=").concat(r);
            t && (a += "&navigateBack=2"), wx.navigateTo({
                url: a
            });
        },
        onReachBottom: function() {
            var e = this;
            return i(n().mark(function t() {
                var r, i, o, s, u, c, p;
                return n().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (r = e.data, i = r.hasMore, o = r.offset, s = r.activityAlias, !i) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 4, e.getPrizeLogList(s);

                      case 4:
                        u = t.sent, c = u.prizeLogList, p = u.hasMore, e.setData({
                            prizeLogList: [].concat(a(e.data.prizeLogList), a(c)),
                            offset: o + c.length,
                            hasMore: p
                        });

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        }
    }
});