var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../lib/device")), i = e(require("../../io/index")), n = require("../../config/index"), u = e(require("../../lib/wx-utils"));

Component({
    data: {
        statusBarHeight: a.default.getStatusBarHeight(),
        archivedPageImage: ""
    },
    methods: {
        onLoad: function(e) {
            var t = e.activityAlias;
            if (!t) return u.default.showToast("配置出错，请稍后重试"), wx.switchTab({
                url: n.ROUTE.HOME
            });
            this.getActivity(t);
        },
        getActivity: function(e) {
            var a = this;
            return r(t().mark(function r() {
                var n;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, i.default.activity.first({
                            query: i.default.query.compare("alias", "=", e),
                            select: "archived_page_image"
                        });

                      case 2:
                        n = t.sent, a.setData({
                            archivedPageImage: n.archived_page_image
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        navBack: function() {
            wx.navigateBack();
        }
    }
});