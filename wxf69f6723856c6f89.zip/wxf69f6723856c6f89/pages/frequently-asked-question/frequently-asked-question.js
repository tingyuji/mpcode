var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../io/index"));

Component({
    data: {
        questions: []
    },
    methods: {
        onLoad: function() {
            this.getQuestions();
        },
        getQuestions: function() {
            var e = this;
            return r(t().mark(function r() {
                var i;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, n.default.frequentlyAskedQuestion.find({
                            limit: 50,
                            orderBy: "-priority,-created_at"
                        });

                      case 2:
                        i = t.sent, e.setData({
                            questions: i
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        }
    }
});