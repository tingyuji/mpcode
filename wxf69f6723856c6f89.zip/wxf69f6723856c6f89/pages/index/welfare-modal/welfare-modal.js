var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../../@babel/runtime/helpers/Arrayincludes");

var r = require("../../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../lib/licia"), s = e(require("../../../lib/dayjs.min")), a = e(require("../../../io/index")), u = e(require("../../../lib/auth")), o = e(require("../../../lib/wx-utils")), c = e(require("../../../lib/baas")), l = e(require("../../../lib/promise/debounce")), d = require("../../../config/constants"), f = "public", b = "only_allow_trade_union", p = "only_allow_admin_org";

Component({
    data: {
        welfare: {},
        visible: !1
    },
    observers: {
        visible: function(e) {
            void 0 !== e && this.toggleTabBar(e);
        }
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e = this;
            return t(r().mark(function t() {
                var n, s, o, c, l, f;
                return r().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, Promise.all([ u.default.getUserInfo(), a.default.getGdftuSettingsByKey(d.SETTING_KEYS.WELFARE_MODALS) ]);

                      case 2:
                        n = r.sent, s = i(n, 2), o = s[0], c = s[1], e.userinfo = o, (l = e.getPermissionWelfare(c)) && (f = e.getModalVisible(l), 
                        e.setData({
                            welfare: l,
                            visible: f
                        }));

                      case 9:
                      case "end":
                        return r.stop();
                    }
                }, t);
            }))();
        },
        getPermissionWelfare: function(e) {
            var r = this, i = e.find(function(e) {
                return r.isMatchTradeUnionPermission(e.allow_trade_union, e.visible_permission);
            });
            if (i) return i;
            var t = e.find(function(e) {
                return r.isMatchAdminOrgPermission(e.allow_admin_org, e.visible_permission);
            });
            if (t) return t;
            var n = e.find(function(e) {
                return r.isMatchPublicPermission(e.visible_permission);
            });
            return n || null;
        },
        getModalVisible: function(e) {
            var r = e.subscribe_template_ids;
            return !(!e.visible || !this.isSubscribeStorageExpried(r));
        },
        isMatchTradeUnionPermission: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            if (!r.includes(b)) return !1;
            var i = this.userinfo.trade_union_id;
            return e.some(function(e) {
                return e.id === i;
            });
        },
        isMatchAdminOrgPermission: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            if (!r.includes(p)) return !1;
            var i = this.userinfo.admin_org_chart, t = e.map(function(e) {
                return e.id;
            }).filter(Boolean), s = i.map(function(e) {
                return e.id;
            }).filter(Boolean), a = (0, n.intersect)(t, s);
            return !(0, n.isEmpty)(a);
        },
        isMatchPublicPermission: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            return !!e.includes(f) && !(!u.default.isIdentify() || !u.default.isJoinedTradeUnion());
        },
        isSubscribeStorageExpried: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = c.default.getStorage("subcribe_model_expries_in") || {}, i = e.sort().join("&"), t = r[i], n = (0, 
            s.default)().unix();
            return !(t && n <= t);
        },
        toggleTabBar: function(e) {
            e ? wx.hideTabBar() : wx.showTabBar();
        },
        askUserSubscribe: (0, l.default)(t(r().mark(function e() {
            var i = this;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.askActivityNoticeSubscribeMessage().catch(function(e) {
                        return o.default.showToast(e.message), i.close();
                    });

                  case 2:
                    this.patchSubscribeTempIdsStorage(), this.close();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), {
            wait: 5e3
        }),
        askActivityNoticeSubscribeMessage: function() {
            var e = this;
            return t(r().mark(function i() {
                var t, s, c, l, d, f, b, p, h, m, v;
                return r().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return t = e.data.welfare, s = (void 0 === t ? {} : t).subscribe_template_ids, r.next = 4, 
                        u.default.getUserInfo();

                      case 4:
                        if (c = r.sent, !(0, n.isEmpty)(s)) {
                            r.next = 7;
                            break;
                        }
                        throw new Error("授权失败，请退出小程序重试");

                      case 7:
                        return r.next = 9, e.askSubscribeMessage(s);

                      case 9:
                        if (l = r.sent, d = l.succeeded, f = l.succeeded_cnt, !d) {
                            r.next = 19;
                            break;
                        }
                        return o.default.showToast("订阅成功", {
                            icon: "success"
                        }), b = c.admin_org_chart, p = void 0 === b ? [] : b, h = c.trade_union_id, m = p.map(function(e) {
                            return e.id;
                        }), v = Array.from({
                            length: f
                        }, function() {
                            return {
                                trade_union_hierarchy: m,
                                trade_union_id: h
                            };
                        }), r.next = 19, a.default.subscribeLog.createMany(v);

                      case 19:
                      case "end":
                        return r.stop();
                    }
                }, i);
            }))();
        },
        patchSubscribeTempIdsStorage: function() {
            var e = this.data.welfare, r = void 0 === e ? {} : e, i = r.subscribe_template_ids, t = void 0 === i ? [] : i, n = r.expires_in, a = c.default.getStorage("subcribe_model_expries_in") || {};
            a[t.sort().join("&")] = (0, s.default)().unix() + n, c.default.setStorage("subcribe_model_expries_in", a);
        },
        askSubscribeMessage: function(e) {
            return t(r().mark(function i() {
                var t, s, a;
                return r().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (t = {
                            succeeded: !1,
                            succeeded_cnt: 0
                        }, wx.canIUse("requestSubscribeMessage")) {
                            r.next = 4;
                            break;
                        }
                        return o.default.showToast("当前微信版本过低，请升级"), r.abrupt("return", t);

                      case 4:
                        return r.prev = 4, r.next = 7, o.default.requestSubscribeMessage({
                            tmplIds: e
                        });

                      case 7:
                        if (s = r.sent, (a = (0, n.map)(e, function(e) {
                            return (0, n.isEqual)(s[e], "accept") ? {
                                template_id: e,
                                subscription_type: "once"
                            } : null;
                        }).filter(Boolean)).length) {
                            r.next = 11;
                            break;
                        }
                        return r.abrupt("return", t);

                      case 11:
                        return r.next = 13, wx.BaaS.subscribeMessage({
                            subscription: a
                        });

                      case 13:
                        return r.abrupt("return", {
                            succeeded: !0,
                            succeeded_cnt: a.length
                        });

                      case 16:
                        return r.prev = 16, r.t0 = r.catch(4), r.abrupt("return", t);

                      case 19:
                      case "end":
                        return r.stop();
                    }
                }, i, null, [ [ 4, 16 ] ]);
            }))();
        },
        navToActivity: function(e) {
            var r = e.currentTarget.dataset.item, i = r.path, t = r.miniapp_appid;
            return t ? (wx.navigateToMiniProgram({
                appId: t,
                path: i
            }), !1) : !!i && void wx.navigateTo({
                url: i,
                fail: function() {
                    wx.switchTab({
                        url: i
                    });
                }
            });
        },
        close: function() {
            this.setData({
                visible: !1
            });
        }
    }
});