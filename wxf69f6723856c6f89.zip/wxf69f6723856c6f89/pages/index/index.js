var t = require("../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../@babel/runtime/helpers/Arrayincludes");

var e = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = t(require("../../io/index")), r = t(require("../../config-project/address")), i = require("../../config-project/index"), s = t(require("../../lib/device")), o = t(require("../../utils/behaviors/fetch-data-with-paging")), u = require("../../config-project/miniprogram"), c = t(require("../../lib/auth")), d = t(require("../../lib/baas")), f = t(require("../../lib/dayjs.min")), l = t(require("../../lib/wx-utils")), h = t(require("../../lib/countdown"));

Component({
    behaviors: [ (0, o.default)({
        autoFetchDataAfterAttached: !1
    }) ],
    data: {
        STATUS: i.CONSTANTS.ACTIVITY_STATUS,
        isIpx: s.default.isIpx(),
        navBarHeight: s.default.getNavbarHeight(),
        status: "all",
        city: "广东省",
        cityCode: "440000",
        statusRange: [],
        cityRange: [],
        currentTabIndex: 0,
        showOffYearModal: !1,
        showOffYearWin: !1,
        userInfo: d.default.getUserInfoSync() || {},
        refreshButtonVisible: !1,
        secondCount: 30,
        refreshButton: {
            text: "点击刷新（?秒）",
            disabled: !0,
            method: "init"
        }
    },
    methods: {
        onLoad: function() {
            var t = this;
            return a(e().mark(function a() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        t.initDictionary(), t.init();

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        init: function() {
            var t = this;
            return a(e().mark(function a() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), e.next = 4, t.setCityCodeByUserinfo();

                      case 4:
                        return e.next = 6, t._getData();

                      case 6:
                        wx.hideLoading(), t.handleRabbitOffYear(), e.next = 16;
                        break;

                      case 10:
                        e.prev = 10, e.t0 = e.catch(0), console.log(e.t0), l.default.showToast("活动太火爆了，请稍后再来～"), 
                        t.data.secondCount <= 0 ? t.setData({
                            secondCount: 30,
                            refreshButtonVisible: !0
                        }) : t.setData({
                            refreshButtonVisible: !0
                        }), t.countDown();

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, a, null, [ [ 0, 10 ] ]);
            }))();
        },
        countDown: function() {
            var t = this, e = this.data.secondCount, a = (0, h.default)({
                timeRemaining: e,
                onChange: function(e) {
                    var a = e.remaining;
                    t.setData({
                        secondCount: a,
                        "refreshButton.text": "点击刷新（".concat(a, "秒)"),
                        "refreshButton.disabled": !0
                    });
                },
                onEnd: function() {
                    return t.setData({
                        "refreshButton.text": "点击刷新",
                        "refreshButton.disabled": !1
                    });
                }
            });
            this.countDownTimer = a;
        },
        clearTimer: function() {
            this.countDownTimer && clearInterval(this.countDownTimer);
        },
        initDictionary: function() {
            var t = r.default.findLocationObject("440000"), e = Object.keys(i.CONSTANTS.ACTIVITY_STATUS_TEXT_MAP).map(function(t) {
                return {
                    id: t,
                    name: i.CONSTANTS.ACTIVITY_STATUS_TEXT_MAP[t]
                };
            });
            t.unshift({
                id: "440000",
                name: "广东省"
            }), e.unshift({
                id: "all",
                name: "全部"
            }), this.setData({
                statusRange: e,
                cityRange: t
            });
        },
        setCityCodeByUserinfo: function() {
            var t = this;
            return a(e().mark(function a() {
                var n, r, i, s;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, c.default.getUserInfo();

                      case 2:
                        n = e.sent, r = "440000", i = "广东省", s = t.data.cityRange.map(function(t) {
                            return t.id;
                        }), c.default.isJoinedTradeUnion() && n.city_code && s.includes(n.city_code) && (r = n.city_code, 
                        i = t.data.cityRange.find(function(t) {
                            return t.id === n.city_code;
                        }).name), t.setData({
                            cityCode: r,
                            city: i
                        });

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        onCityChange: function(t) {
            var e = this.data.cityRange;
            this.setData({
                city: e[parseInt(t.detail.value)].name,
                cityCode: e[parseInt(t.detail.value)].id,
                dataList: [],
                _offset: 0
            }), this._getData();
        },
        onTabSelect: function(t) {
            var e = t.target.dataset.index;
            e !== this.data.currentTabIndex && (this.setData({
                currentTabIndex: e,
                status: this.data.statusRange[e].id,
                dataList: [],
                _offset: 0
            }), this._getData());
        },
        getDataList: function(t, r) {
            var i = this;
            return a(e().mark(function a() {
                var s, o, u;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s = i.data, o = s.cityCode, u = s.status, e.abrupt("return", n.default.getActivityList({
                            offset: t,
                            limit: r,
                            cityCode: o,
                            status: u
                        }));

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        navToTarget: function(t) {
            return a(e().mark(function a() {
                var n, r;
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (null == (n = t.currentTarget.dataset.activity) || !n.appid) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return", wx.navigateToMiniProgram({
                            appId: n.appid,
                            path: n.path
                        }));

                      case 3:
                        if (!n.archived) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return", wx.navigateTo({
                            url: "".concat(u.ROUTE.ARCHIVED_PAGE, "?activityAlias=").concat(n.alias)
                        }));

                      case 5:
                        r = null != n && n.path.startsWith("pages") ? n.path.replace("pages", "../../") : n.path, 
                        wx.navigateTo({
                            url: r
                        });

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        },
        handleRabbitOffYear: function() {
            var t = this.data.dataList.find(function(t) {
                return "act53" === t.alias;
            });
            if (t) {
                var e = (0, f.default)().unix(), a = t.settings, n = a.off_year_modal_starts_at, r = a.off_year_modal_ends_at;
                this.setData({
                    showOffYearWin: e >= n && e <= r
                });
            }
        },
        onShowOffYearModal: function() {
            this.setData({
                showOffYearModal: !0
            });
        },
        onUnload: function() {
            this.clearTimer();
        },
        onShareAppMessage: function(t) {
            return a(e().mark(function a() {
                return e().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ("button" !== t.from) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return", {
                            title: "我正在参加粤工惠活动，集兔卡，瓜分30万现金红包",
                            imageUrl: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pDjIFj6x8CKlb8Q.png",
                            path: u.ROUTE.ACT53_RABBIT_INDEX
                        });

                      case 2:
                        return e.abrupt("return", {
                            title: "一键注册会员参与活动！",
                            imageUrl: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lh156pFeSkC2i22.jpg",
                            path: "".concat(u.ROUTE.HOME, "?source=index")
                        });

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, a);
            }))();
        }
    }
});