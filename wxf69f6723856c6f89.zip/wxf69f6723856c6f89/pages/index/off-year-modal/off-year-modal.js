var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, a = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), r = e(require("../../../io/index")), n = e(require("../../../lib/dayjs.min"));

Component({
    properties: {
        showOffYearModal: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        coverImage: "https://cloud-minapp-37888.cloud.ifanrusercontent.com/1pG8ddHpBfUFBmlY.png",
        showShareModal: !1
    },
    ready: function() {
        var e = this;
        return t(a().mark(function t() {
            return a().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.next = 2, e.handleActivity();

                  case 2:
                  case "end":
                    return a.stop();
                }
            }, t);
        }))();
    },
    methods: {
        handleActivity: function() {
            var e = this;
            return t(a().mark(function t() {
                var o, s, i, u, f;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, r.default.activity.first({
                            query: r.default.query.compare("alias", "=", "act53")
                        });

                      case 2:
                        o = a.sent, s = (0, n.default)().unix(), i = o.settings, u = i.off_year_modal_starts_at, 
                        f = i.off_year_modal_ends_at, e.setData({
                            showOffYearModal: s >= u && s <= f
                        });

                      case 6:
                      case "end":
                        return a.stop();
                    }
                }, t);
            }))();
        },
        toggleShareModal: function() {
            wx.showTabBar(), this.setData({
                showShareModal: !this.data.showShareModal
            });
        },
        switchOffYearToShare: function() {
            wx.hideTabBar(), this.setData({
                showOffYearModal: !1,
                showShareModal: !0
            });
        },
        closeOffYear: function() {
            this.setData({
                showOffYearModal: !1
            });
        }
    }
});