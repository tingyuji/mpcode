var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../lib/licia"), s = e(require("../../../io/index")), a = require("../../../config/constants"), u = e(require("../../../lib/promise/debounce")), i = e(require("../../../lib/auth")), c = e(require("../../../lib/wx-utils"));

Component({
    data: {
        floatSubscribeButton: "",
        buttonVisible: !1
    },
    lifetimes: {
        attached: function() {
            this.getWelfareModalConfig();
        }
    },
    methods: {
        getWelfareModalConfig: function() {
            var e = this;
            return r(t().mark(function r() {
                var n, u;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, i.default.getUserInfo();

                      case 2:
                        return t.next = 4, s.default.getGdftuSettingsByKey(a.SETTING_KEYS.FLOAT_SUBSCRIBE_BUTTON);

                      case 4:
                        n = t.sent, u = (null == n ? void 0 : n.visible) && !(!i.default.isIdentify() || !i.default.isJoinedTradeUnion()), 
                        e.setData({
                            floatSubscribeButton: n,
                            buttonVisible: u
                        });

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        askActivityNoticeSubscribeMessage: (0, u.default)(r(t().mark(function e() {
            var r, a, u, o, d, l, b, f, p, h, g;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = this.data.floatSubscribeButton, a = (void 0 === r ? {} : r).subscribe_template_ids, 
                    e.next = 4, i.default.getUserInfo();

                  case 4:
                    if (u = e.sent, !(0, n.isEmpty)(a)) {
                        e.next = 7;
                        break;
                    }
                    throw new Error("授权失败，请退出小程序重试");

                  case 7:
                    return e.next = 9, this.askSubscribeMessage(a);

                  case 9:
                    if (o = e.sent, d = o.succeeded, l = o.succeeded_cnt, !d) {
                        e.next = 19;
                        break;
                    }
                    return c.default.showToast("订阅成功", {
                        icon: "success"
                    }), b = u.admin_org_chart, f = void 0 === b ? [] : b, p = u.trade_union_id, h = f.map(function(e) {
                        return e.id;
                    }), g = Array.from({
                        length: l
                    }, function() {
                        return {
                            trade_union_hierarchy: h,
                            trade_union_id: p
                        };
                    }), e.next = 19, s.default.subscribeLog.createMany(g);

                  case 19:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), {
            wait: 2e3
        }),
        askSubscribeMessage: function(e) {
            return r(t().mark(function r() {
                var s, a, u;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (s = {
                            succeeded: !1,
                            succeeded_cnt: 0
                        }, wx.canIUse("requestSubscribeMessage")) {
                            t.next = 4;
                            break;
                        }
                        return c.default.showToast("当前微信版本过低，请升级"), t.abrupt("return", s);

                      case 4:
                        return t.prev = 4, t.next = 7, c.default.requestSubscribeMessage({
                            tmplIds: e
                        });

                      case 7:
                        if (a = t.sent, (u = (0, n.map)(e, function(e) {
                            return (0, n.isEqual)(a[e], "accept") ? {
                                template_id: e,
                                subscription_type: "once"
                            } : null;
                        }).filter(Boolean)).length) {
                            t.next = 11;
                            break;
                        }
                        return t.abrupt("return", s);

                      case 11:
                        return t.next = 13, wx.BaaS.subscribeMessage({
                            subscription: u
                        });

                      case 13:
                        return t.abrupt("return", {
                            succeeded: !0,
                            succeeded_cnt: u.length
                        });

                      case 16:
                        return t.prev = 16, t.t0 = t.catch(4), t.abrupt("return", s);

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, r, null, [ [ 4, 16 ] ]);
            }))();
        }
    }
});