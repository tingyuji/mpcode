var e = require("../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../@babel/runtime/helpers/Arrayincludes");

var t, a = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../@babel/runtime/helpers/defineProperty"), i = e(require("../../io/index")), o = e(require("../../lib/wx-utils")), s = require("../../config/index"), u = e(require("../../utils/ga")), c = e(require("../../lib/baas")), d = require("../../lib/licia"), l = e(require("../../lib/promise/debounce")), p = e(require("../../lib/auth")), v = e(require("../../lib/device")), g = s.CONSTANTS.PRIZE_TYPE, h = s.CONSTANTS.COUPON_STATUS, f = (r(t = {}, h.USED, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPfQC6DzTlbknkC.png"), 
r(t, h.EXPIRED, "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPfQCHyWrhbMqB4.png"), 
t), m = "page", T = "embedded_wxmp", x = "wxmp", E = "webpage", b = "wx_channel", w = "memberId", y = "sequence";

Component({
    data: {
        COUPON_STATUS: h,
        PRIZE_TYPE: g,
        PRIZE_LOG_STATUS_BRAND: f,
        prizeLog: {},
        btnGroups: [],
        scrollHeight: 120,
        CUSTOM_RULE_TITLE: {
            DEFAULT: "使用规则",
            act79: "抽奖规则"
        }
    },
    methods: {
        onLoad: function(e) {
            var t = this;
            return n(a().mark(function n() {
                var r, i, o;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (r = e.prizeLogId, i = e.navigateBack, t.navigateBack = i, !r) {
                            a.next = 6;
                            break;
                        }
                        return a.next = 5, t.fetchPrizeLog(r);

                      case 5:
                        t.setBtnGroups();

                      case 6:
                        return a.next = 8, t.getScrollHeight();

                      case 8:
                        o = a.sent, t.setData({
                            scrollHeight: o
                        });

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, n);
            }))();
        },
        getScrollHeight: function() {
            var e = this;
            return n(a().mark(function t() {
                var n, r, i, o, s;
                return a().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = 98, r = v.default.getNavbarHeight(), t.next = 4, e.getElementHeight(".main");

                      case 4:
                        return i = t.sent, t.next = 7, e.getElementHeight(".btn-group");

                      case 7:
                        return o = t.sent, s = v.default.getWindowHeight() - i - o - r - n, t.abrupt("return", s);

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        getElementHeight: function(e) {
            return new Promise(function(t) {
                wx.createSelectorQuery().select(e).boundingClientRect(function(e) {
                    return t(e ? e.height : 0);
                }).exec();
            });
        },
        fetchPrizeLog: function(e) {
            var t = this;
            return n(a().mark(function n() {
                var r, o, s, u, l, v, g, h;
                return a().wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, p.default.getUserInfo();

                      case 2:
                        return r = a.sent, t.userinfo = r, a.next = 6, i.default.prizeLog.get(e, {
                            plain: !1,
                            expand: "activity"
                        });

                      case 6:
                        o = a.sent, s = o.data, t.now = c.default.getServerTimeUnix(o), (0, d.isEmpty)(s.address) || (u = s.address, 
                        l = u.provinceName, v = u.cityName, g = u.countyName, h = u.detailInfo, s.address.deliveryAddress = "".concat(l).concat(v).concat(g).concat(h)), 
                        t.setData({
                            prizeLog: s
                        });

                      case 11:
                      case "end":
                        return a.stop();
                    }
                }, n);
            }))();
        },
        setBtnGroups: function() {
            var e = this.data.prizeLog, t = [], a = this.getBtnGroup(e);
            a && t.push(a), t.push({
                text: "返回活动",
                method: "navToActivity"
            }), t[0].class = "btn--red", t.length > 1 && (t[1].class = "btn--white"), this.setData({
                btnGroups: t
            });
        },
        getBtnGroup: function(e) {
            var t, a = this, n = e.prize, i = e.status, o = n || {}, s = o.type, u = o.extension, c = function() {
                return i === h.EXPIRED || (0, d.isEmpty)(null == u ? void 0 : u.navigation) ? null : {
                    text: "前往使用",
                    method: "navToTarget",
                    navigation: u.navigation
                };
            }, l = (r(t = {}, g.WECHAT_RECHARGE_COUPON, function() {
                return i !== h.SENT_SUCCEEDED || (0, d.isEmpty)(null == u ? void 0 : u.navigation) ? null : {
                    text: "点击前往充值",
                    method: "navToTarget",
                    navigation: e.prize.extension.navigation
                };
            }), r(t, g.PACKAGE_DELIVERY, function() {
                return a.now > n.redeem_expires_at ? {
                    text: "已截止授权收货地址",
                    disabled: !0
                } : {
                    text: "授权收货地址",
                    method: "updateUserAddress"
                };
            }), r(t, g.GDFTU_BUY_COUPON, function() {
                return i !== h.SENT_SUCCEEDED || (0, d.isEmpty)(null == u ? void 0 : u.navigation) ? null : {
                    text: "前往兑换",
                    method: "navToTarget",
                    navigation: u.navigation
                };
            }), r(t, g.REDEEMPTION_TICKET, c), r(t, g.NAVIGATION, c), t);
            return l[s] ? l[s]() : null;
        },
        copy: function(e) {
            var t = e.currentTarget.dataset.value;
            wx.setClipboardData({
                data: t,
                success: function() {
                    wx.hideToast(), o.default.showToast("复制成功");
                }
            });
        },
        updateUserAddress: (0, l.default)(n(a().mark(function e() {
            var t, n, r, u, c, l, p, v, g, h, f, m, T, x, E, b, w, y, _, A;
            return a().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return u = this.data.prizeLog, e.next = 3, o.default.askSettingAuthorizeCall("chooseAddress");

                  case 3:
                    if (c = e.sent) {
                        e.next = 6;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 6:
                    if (null === (t = u.prize) || void 0 === t || null === (n = t.extension) || void 0 === n || null === (r = n.limitation) || void 0 === r || !r.address) {
                        e.next = 13;
                        break;
                    }
                    if (l = u.prize.extension.limitation.address, p = (0, d.keys)(l).every(function(e) {
                        return l[e] === c[e];
                    }), v = l.provinceName, g = void 0 === v ? "" : v, h = l.cityName, f = void 0 === h ? "" : h, 
                    m = l.countyName, T = void 0 === m ? "" : m, p) {
                        e.next = 13;
                        break;
                    }
                    return o.default.showToast("抱歉，地址需在".concat(g).concat(f).concat(T, "内")), e.abrupt("return");

                  case 13:
                    return e.prev = 13, e.next = 16, i.default.invoke(s.BAAS.FUNCTION.UPDATE_USER_PRIZE_LOG_ADDRESS, {
                        prizeLogId: u.id,
                        address: c
                    });

                  case 16:
                    x = e.sent, E = x.data, b = "ok" === E ? "修改成功" : "操作失败", w = c.provinceName, y = c.cityName, 
                    _ = c.countyName, A = c.detailInfo, c.deliveryAddress = "".concat(w).concat(y).concat(_).concat(A), 
                    this.setData({
                        "prizeLog.address": c
                    }), o.default.showToast(b, {
                        duration: 3e3
                    }), e.next = 31;
                    break;

                  case 25:
                    if (e.prev = 25, e.t0 = e.catch(13), !(0, d.startWith)(null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.message, "抱歉")) {
                        e.next = 30;
                        break;
                    }
                    return o.default.showToast(e.t0.message), e.abrupt("return");

                  case 30:
                    o.default.showToast("修改失败", {
                        duration: 3e3
                    });

                  case 31:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 13, 25 ] ]);
        })), {
            wait: 3e3
        }),
        navToTarget: function(e) {
            var t = e.currentTarget.dataset.navigation;
            if ((0, d.isEmpty)(t)) return o.default.showToast("跳转失败，请重新打开小程序重试");
            var a = this.data.prizeLog, n = t.type, r = t.appid, i = t.webpage_url, c = t.channel, l = t.extraData, p = this, v = t.path;
            switch (v && (v = v.replace(/\{\{((?:.|\r?\n)+?)\}\}/g, function(e, t) {
                switch (t) {
                  case y:
                    return a.prize.stock_id || a.prize.extension.sequence;

                  case w:
                    return p.userinfo.member_id;
                }
            })), n) {
              case m:
                return wx.navigateTo({
                    url: v
                });

              case T:
                var g, h;
                return r ? (null != a && null !== (g = a.activity) && void 0 !== g && null !== (h = g.name) && void 0 !== h && h.includes("粤工惠享日") && u.default.event("中奖详情页", "粤工惠享点击跳转粤工惠购", p.userinfo.id), 
                wx.openEmbeddedMiniProgram({
                    appId: r,
                    path: v,
                    extraData: l
                })) : o.default.showToast("跳转失败");

              case x:
                return wx.navigateToMiniProgram({
                    appId: r,
                    path: v,
                    extraData: l
                });

              case E:
                return wx.navigateTo({
                    url: "".concat(s.ROUTE.WEBVIEW, "?path=").concat(i)
                });

              case b:
                return (0, d.isEmpty)(c) ? o.default.showToast("打开视频号失败") : wx.openChannelsActivity({
                    finderUserName: c.finder_user_name,
                    feedId: c.feed_id
                });
            }
        },
        navToActivity: function() {
            var e, t = this.data.prizeLog;
            return (0, d.isEmpty)(null === (e = t.activity) || void 0 === e ? void 0 : e.path) ? o.default.showToast("跳转失败，活动路径不存在") : null != t && t.activity.archived ? wx.navigateTo({
                url: "".concat(s.ROUTE.ARCHIVED_PAGE, "?activityAlias=").concat(t.activity.alias)
            }) : void (this.navigateBack ? wx.navigateBack({
                delta: Number(this.navigateBack)
            }) : wx.navigateTo({
                url: t.activity.path
            }));
        }
    }
});