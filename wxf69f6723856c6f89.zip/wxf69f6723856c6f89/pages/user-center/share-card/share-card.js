var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, r = require("../../../@babel/runtime/helpers/slicedToArray"), t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../../lib/wxml2canvas/index")), i = require("../../../lib/common"), o = e(require("../../../utils/behaviors/util-behavior"));

Component({
    behaviors: [ o.default ],
    properties: {
        qrCodeUrl: String
    },
    data: {
        isTemplateShow: !1,
        isCanvasShow: !1,
        isShowShareModal: !1,
        drawHeight: 0,
        drawWidth: 0,
        shareImgUrl: ""
    },
    methods: {
        drawShareImage: function() {
            var e = arguments, r = this;
            return a(t().mark(function a() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!(!(e.length > 0 && void 0 !== e[0]) || e[0]) || !r.data.shareImgUrl) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return", Promise.resolve({
                            shareImgUrl: r.data.shareImgUrl
                        }));

                      case 3:
                        return t.abrupt("return", r.setDataPromise({
                            blurCover: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1kkhVKa1j5jp0Llp.png",
                            isCanvasShow: !0,
                            isTemplateShow: !0
                        }).then(function() {
                            return (0, i.delay)(500);
                        }).then(function() {
                            return r.calcShareImageSize();
                        }).then(function(e) {
                            var t = e.width, a = e.height;
                            return r.setDataPromise({
                                drawWidth: t,
                                drawHeight: a
                            });
                        }).then(function() {
                            var e = r.data, t = e.drawWidth, a = e.drawHeight;
                            return t = Math.floor(t), a = Math.floor(a), r.drawWxml2Canvas({
                                width: t,
                                height: a
                            });
                        }).then(function(e) {
                            return r.setDataPromise({
                                shareImgUrl: e,
                                isCanvasShow: !1,
                                isTemplateShow: !1
                            });
                        }).catch(function(e) {
                            throw r.setData({
                                isCanvasShow: !1,
                                isTemplateShow: !1
                            }), e;
                        }));

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        calcShareImageSize: function() {
            var e = this;
            return new Promise(function(t) {
                var a = wx.createSelectorQuery().in(e);
                a.select(".card-template").boundingClientRect(), a.exec(function(e) {
                    var a = r(e, 1)[0];
                    return t(a);
                });
            });
        },
        drawWxml2Canvas: function(e) {
            var r = this, t = e.height, a = e.width;
            return new Promise(function(e, i) {
                new n.default({
                    width: a,
                    height: t,
                    zoom: 1,
                    context: r,
                    element: "shareImageCanvas",
                    background: "transparent",
                    progress: function(e) {},
                    finish: function(r) {
                        return e(r);
                    },
                    error: function(e) {
                        console.error("drawError", e), i(e);
                    }
                }).draw({
                    list: [ {
                        type: "wxml",
                        class: ".card-template .draw",
                        limit: ".card-template",
                        x: 0,
                        y: 0
                    } ]
                }, r);
            });
        },
        showShareModal: function() {
            return this.setDataPromise({
                isShowShareModal: !0
            });
        },
        hideShareModal: function() {
            return this.setDataPromise({
                isShowShareModal: !1
            });
        }
    }
});