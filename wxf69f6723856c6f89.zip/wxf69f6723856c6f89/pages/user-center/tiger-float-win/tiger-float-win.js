var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, r = require("../../../@babel/runtime/helpers/regeneratorRuntime"), t = require("../../../@babel/runtime/helpers/asyncToGenerator"), i = e(require("../../../io/index")), n = require("../../../config-project/index").MINIPROGRAM.ROUTE;

Component({
    data: {
        isShowAct: !1
    },
    ready: function() {
        this.handleActivity();
    },
    methods: {
        handleActivity: function() {
            var e = this;
            return t(r().mark(function t() {
                var a;
                return r().wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, i.default.activity.first({
                            query: i.default.query.contains("path", n.ACT13_TIGER_INDEX)
                        });

                      case 2:
                        a = r.sent, e.setData({
                            isShowAct: "processing" === (null == a ? void 0 : a.status)
                        });

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, t);
            }))();
        },
        redirectActTiger: function() {
            wx.navigateTo({
                url: "".concat(n.ACT13_TIGER_INDEX, "?sourceType=miniprogram&source=MINIPROGRAM_YGHHYHD")
            });
        }
    }
});