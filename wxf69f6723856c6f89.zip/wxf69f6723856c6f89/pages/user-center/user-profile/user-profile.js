var e = require("../../../@babel/runtime/helpers/interopRequireDefault").default, i = require("../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), t = e(require("../../../lib/pubsub")), r = e(require("../../../lib/wx-utils")), a = e(require("../../../lib/auth")), s = require("../../../config/index"), o = e(require("../../../lib/baas"));

Component({
    properties: {
        identifyTips: {
            type: String,
            value: "授权会员注册手机号，登录会员"
        },
        pendingJoinUnionTips: {
            type: String,
            value: "入会审核中"
        },
        joinUnionTips: {
            type: String,
            value: "申请入会"
        },
        isBirthMonth: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isAuth: !1,
        isIdentify: !1,
        isJoinedTradeUnion: !1,
        isPendingJoinTradeUnion: !1,
        userInfo: {}
    },
    pageLifetimes: {
        show: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e = this;
            return n(i().mark(function n() {
                var t;
                return i().wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return i.next = 2, a.default.getUserInfo();

                      case 2:
                        t = i.sent, e.setData({
                            userInfo: t,
                            isAuth: o.default.hasWechatUserProfile(),
                            isIdentify: a.default.isIdentify(),
                            isJoinedTradeUnion: a.default.isJoinedTradeUnion(),
                            isPendingJoinTradeUnion: a.default.isPendingJoinTradeUnion()
                        });

                      case 4:
                      case "end":
                        return i.stop();
                    }
                }, n);
            }))();
        },
        navToAuth: function() {
            a.default.navToAuth({
                envVersion: s.DEV ? "develop" : "release",
                redirectPath: "/pages/index/index"
            }).catch(function(e) {
                /fail cancel/.test(null == e ? void 0 : e.errMsg) ? r.default.showToast("取消跳转小程序") : r.default.showToast("跳转小程序失败");
            });
        },
        getUserInfoByProfile: function() {
            var e = this;
            this.data.isAuth || wx.getUserProfile({
                desc: "用户登录",
                success: function(i) {
                    wx.BaaS.auth.updateUserInfo(i).then(function(i) {
                        o.default.setStorage("userinfo", i), t.default.pub("INIT_WIHT_AUTH_PHONE"), e.init();
                    });
                },
                complete: function() {}
            });
        }
    }
});