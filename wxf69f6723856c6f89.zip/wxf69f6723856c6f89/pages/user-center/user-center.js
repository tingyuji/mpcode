var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../lib/device")), r = e(require("../../lib/baas")), i = require("../../config-project/index"), o = require("../../config/index"), u = e(require("../../lib/wx-utils")), s = e(require("../../io/index")), c = e(require("../../lib/auth")), d = i.MINIPROGRAM.ROUTE, p = {
    RELEASE: "wxfcc5a91b4f0d6e38",
    DEVELOP: "wxd6b276ff6e0ae80b"
}, l = {
    USER: "/pages/member-info/index",
    POINT: "/pages/point-detail/point-detail"
};

Component({
    data: {
        TAB_LIST: [ {
            ICON: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPIAXNC5aKxakQG.png",
            NAME: "个人中心",
            METHOD: "navToYGHUserCenter"
        }, {
            ICON: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgmXcs0rte6SdGB.png",
            NAME: "生日礼包",
            METHOD: "navToAct4Index"
        }, {
            ICON: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lgmXc9i1kkgkfq6.png",
            NAME: "中奖记录",
            METHOD: "navToCouponList"
        }, {
            ICON: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPIAXO2I7OBqwDB.png",
            NAME: "我的积分",
            METHOD: "navToYGHPoint"
        }, {
            ICON: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1pPIAXou16kkDzaB.png",
            NAME: "常见问题",
            METHOD: "navToFAQ"
        } ],
        navBarHeight: a.default.getNavbarHeight(),
        tabList: [],
        userInfo: {},
        qrCodeUrl: "",
        defaultAvatar: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/default-avatar.png",
        showAuthModal: !1,
        inviteNum: 0,
        inviteAll: 9,
        activityState: "pending",
        couponCount: 0,
        daysUntilBirthday: null
    },
    methods: {
        onShow: function() {
            this.init();
        },
        init: function() {
            var e = this;
            return n(t().mark(function n() {
                var a, r;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return e.shareCard = e.shareCard || e.selectComponent("#share-card"), t.next = 3, 
                        c.default.getUserInfo();

                      case 3:
                        return a = t.sent, t.next = 6, e.getDaysUntilBirthday();

                      case 6:
                        r = t.sent, e.setData({
                            userInfo: a,
                            daysUntilBirthday: r,
                            isIdentify: c.default.isIdentify(),
                            isJoinedTradeUnion: c.default.isJoinedTradeUnion()
                        });

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        getDaysUntilBirthday: function() {
            return n(t().mark(function e() {
                return t().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, s.default.getDaysUntilBirthday();

                      case 3:
                        return e.abrupt("return", e.sent);

                      case 6:
                        e.prev = 6, e.t0 = e.catch(0), console.log("查询生日接口错误：", e.t0);

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 0, 6 ] ]);
            }))();
        },
        initInvite: function() {
            var e = this;
            return n(t().mark(function n() {
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return e.getSetting(), t.next = 3, e.getInviteNum();

                      case 3:
                        e.getCouponInfo();

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        getInviteNum: function() {
            var e = this;
            return n(t().mark(function n() {
                var a, i, o, u;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, r.default.ensureLogin();

                      case 2:
                        return a = t.sent, i = a.id, (o = s.default.query).compare("inviter", "=", i), o.compare("verified", "=", !0), 
                        o.compare("joined_union", "=", !0), t.next = 10, s.default.act8InviteRegister.find({
                            query: o,
                            expand: "created_by",
                            limit: 25
                        });

                      case 10:
                        u = t.sent, e.setData({
                            inviteNum: u.length > 25 ? 25 : u.length
                        });

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        getCouponInfo: function() {
            var e = this;
            return n(t().mark(function n() {
                var a, r;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        a = e.data.inviteNum, r = 0, a < 3 ? r = 3 : a < 9 ? r = 9 : (a < 25 || a >= 25) && (r = 25), 
                        e.setData({
                            inviteAll: r
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        getSetting: function() {
            var e = this;
            return n(t().mark(function n() {
                var a, r, i, o, u, c, d;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return (a = s.default.query).compare("key", "=", "invitation_activities"), t.next = 4, 
                        s.default.settings.first({
                            query: a
                        });

                      case 4:
                        r = t.sent, i = r.json.value, o = i.ends_at, u = i.starts_at, c = new Date().getTime() / 1e3, 
                        d = "pending", c < u ? d = "pending" : c > o ? d = "rejected" : c <= o && (d = "fulfilled"), 
                        e.setData({
                            activityState: d
                        });

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        initCalcCouponCount: function() {
            var e = this;
            return n(t().mark(function n() {
                var a, i, o;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.t0 = s.default.query.compare("status", "=", "pending"), t.next = 3, r.default.getUid();

                      case 3:
                        return t.t1 = t.sent, a = t.t0.compare.call(t.t0, "created_by", "=", t.t1), t.next = 7, 
                        Promise.all([ s.default.billCouponLog.count(a), s.default.discountCouponLog.count(a) ]);

                      case 7:
                        i = t.sent, o = i.reduce(function(e, t) {
                            return e + t;
                        }, 0), e.setData({
                            couponCount: o
                        });

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        showUnionTips: function() {
            var e = this.data, t = e.isIdentify, n = e.isJoinedTradeUnion;
            t ? n || u.default.showToast("请先完成入会") : u.default.showToast("请先完成会员登录");
        },
        showOutStockTips: function() {
            u.default.showToast("本月话费券已领完");
        },
        navToInviteFission: function() {
            wx.navigateTo({
                url: d.INVITE_FISSION
            });
        },
        navToInviteCourtesy: function() {
            wx.navigateTo({
                url: d.INVITE_INVITE
            });
        },
        navToAct4Index: function() {
            wx.navigateTo({
                url: d.ACT4_INDEX
            });
        },
        navToCouponList: function() {
            wx.navigateTo({
                url: d.COUPON_LIST
            });
        },
        navToFAQ: function() {
            wx.navigateTo({
                url: d.FREQUENTLY_ASKED_QUESTION
            });
        },
        navToYGHUserCenter: function() {
            this.navToYGH(l.USER);
        },
        navToYGHPoint: function() {
            this.navToYGH(l.POINT);
        },
        navToYGH: function(e) {
            var t = {
                appId: o.DEV ? p.DEVELOP : p.RELEASE,
                path: e
            };
            u.default.compareVersion(wx.getSystemInfoSync().SDKVersion, "2.21.4") >= 0 ? wx.openEmbeddedMiniProgram(t) : wx.navigateToMiniProgram(t);
        },
        onShareAppMessage: function() {
            return {
                title: "一键注册会员参与活动!",
                imageUrl: "https://cloud-minapp-37887.cloud.ifanrusercontent.com/1lh156pFeSkC2i22.jpg",
                path: d.USER_CENTER
            };
        },
        toggleAuthModal: function() {
            this.setData({
                showAuthModal: !this.data.showAuthModal
            });
        }
    }
});