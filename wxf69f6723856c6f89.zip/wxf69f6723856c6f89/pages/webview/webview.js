Component({
    data: {
        path: ""
    },
    methods: {
        onLoad: function(t) {
            var a = t.path;
            this.setData({
                path: a
            });
        }
    }
});