Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.deepClone = function(e) {
    var t, r, o, n = Object.prototype.toString.call(e);
    if ("[object Array]" === n) o = []; else {
        if ("[object Object]" !== n) return e;
        o = {};
    }
    if ("[object Array]" === n) {
        for (t = 0, r = e.length; t < r; t++) o.push(this.deepClone(e[t]));
        return o;
    }
    if ("[object Object]" === n) {
        for (t in e) o[t] = this.deepClone(e[t]);
        return o;
    }
}, exports.delay = void 0, exports.isEmpty = function(t) {
    if (void 0 === t) return !0;
    if ("function" == typeof t || "number" == typeof t || "boolean" == typeof t || "[object Date]" === Object.prototype.toString.call(t)) return !1;
    if (null === t || 0 === t.length) return !0;
    if ("object" === e(t) && 0 === Object.keys(t).length) return !0;
};

var e = require("../@babel/runtime/helpers/typeof");

exports.delay = function(e) {
    return new Promise(function(t) {
        return setTimeout(t, e);
    });
};