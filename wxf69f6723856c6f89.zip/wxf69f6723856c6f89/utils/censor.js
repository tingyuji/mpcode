Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.censorImage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
    if (0 === e.length) return Promise.resolve(!1);
    return (0, r.compressImage)(e).then(function(r) {
        var e = r.map(function(r) {
            return wx.BaaS.wxCensorImage(r.src).then(function(e) {
                return {
                    key: r.origin,
                    risky: e.risky,
                    err: !1
                };
            }).catch(function(e) {
                return console.error(e), {
                    key: r.origin,
                    risky: !1,
                    err: !0
                };
            });
        });
        return Promise.all(e);
    });
}, exports.censorText = function(r) {
    return r ? wx.BaaS.wxCensorText(r).then(function(r) {
        return r.data.risky;
    }) : Promise.resolve(!1);
};

var r = require("./file");