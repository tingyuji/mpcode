Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = Behavior({
    methods: {
        wxGetSetting: function() {
            return new Promise(function(t, e) {
                wx.getSetting({
                    success: t,
                    fail: e
                });
            });
        },
        wxOpenSetting: function() {
            return new Promise(function(t, e) {
                wx.openSetting({
                    success: t,
                    fail: e
                });
            });
        },
        wxAuthorize: function(t) {
            return new Promise(function(e) {
                wx.authorize({
                    scope: t,
                    success: function() {
                        return e(!0);
                    },
                    fail: function() {
                        return e(!1);
                    }
                });
            });
        },
        wxGetSettingAuthorize: function(t) {
            var e = this;
            return this.wxGetSetting().then(function(n) {
                return n.authSetting[t] || e.wxAuthorize(t);
            });
        },
        wxOpenSettingAuthorize: function(t) {
            return this.wxOpenSetting().then(function(e) {
                return e.authSetting[t];
            });
        }
    }
});

exports.default = t;