Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../array");

exports.default = function() {
    var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = a.autoFetchDataAfterAttached, i = void 0 === e || e, o = a.uniqueDataByCreatedBy, s = void 0 !== o && o;
    return Behavior({
        options: {
            pureDataPattern: /^_/
        },
        data: {
            dataList: [],
            loading: !1,
            loadingMore: !1,
            hasMore: !1,
            _offset: 0,
            _limit: 20
        },
        lifetimes: {
            attached: function() {
                i && this._getData();
            }
        },
        methods: {
            onReachBottom: function() {
                this.getNewData();
            },
            getNewData: function() {
                var t = this;
                this.data.hasMore && (wx.showLoading({
                    mask: !0,
                    title: "加载中"
                }), this.setData({
                    _offset: this.data._offset + this.data._limit,
                    loadingMore: !0
                }, function() {
                    t._getData().then(function() {
                        wx.hideLoading(), t.setData({
                            loadingMore: !1
                        });
                    });
                }));
            },
            _getData: function() {
                var a = this;
                return s && this.data.dataList.length >= 200 ? (this.setData({
                    hasMore: !1
                }), Promise.resolve()) : (this.setData({
                    loading: !0
                }), wx.showNavigationBarLoading(), this.getDataList(this.data._offset, this.data._limit).then(function(e) {
                    var i;
                    wx.hideNavigationBarLoading(), i = 0 == a.data._offset ? e.data.objects : a.data.dataList.concat(e.data.objects), 
                    s && (i = (0, t.uniqueByUserId)(i)), a.setData({
                        dataList: i,
                        hasMore: !!e.data.meta.next,
                        loading: !1
                    });
                }).catch(function(t) {
                    throw wx.hideNavigationBarLoading(), a.setData({
                        loading: !1
                    }), new Error(t);
                }));
            },
            resetPagination: function() {
                var t = this;
                this.setData({
                    _offset: 0,
                    hasMore: !1
                }, function() {
                    t._getData();
                });
            }
        }
    });
};