var e = require("../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../array"), n = e(require("./wx-setting")), r = e(require("../../lib/device")), s = e(require("../../lib/wx-utils")), i = "accept", u = Behavior({
    behaviors: [ n.default ],
    methods: {
        requestSubscribeMessage: function(e) {
            var n = this;
            return s.default.compareVersion(r.default.getSystemInfo().SDKVersion, "2.8.2") >= 0 && wx.canIUse("requestSubscribeMessage") && "function" == typeof wx.requestSubscribeMessage ? (e = (0, 
            t.toArray)(e), new Promise(function(t, n) {
                try {
                    wx.requestSubscribeMessage({
                        tmplIds: e,
                        success: t,
                        fail: n
                    });
                } catch (e) {
                    n(e);
                }
            }).then(function(t) {
                var r = n._assembleSubscription(e, t);
                return r.length === e.length && wx.BaaS.subscribeMessage({
                    subscription: r
                }).then(function() {
                    return !0;
                });
            })) : (wx.showToast({
                title: "当前微信版本过低，请升级",
                icon: "none"
            }), Promise.resolve(!0));
        },
        askSubscribeMessage: function(e) {
            return this.requestSubscribeMessage(e).catch(function() {
                return !1;
            });
        },
        ensureAgreeSubscribeMessage: function(e, t) {
            var n = this;
            return new Promise(function(r) {
                var s = Date.now();
                n.requestSubscribeMessage(e).then(function(e) {
                    e ? r(!0) : Date.now() - s < 1e3 ? n._showOpenSettingTip() : n._showReAuthTip(t);
                }).catch(function(e) {
                    if (20004 !== e.errCode) throw e;
                    n._showOpenSettingTip();
                });
            });
        },
        _showReAuthTip: function(e) {
            wx.showModal({
                title: "未授权订阅消息",
                content: "你可能无法收到消息通知，请再次授权",
                cancelText: "取消",
                confirmText: "确定",
                success: function(t) {
                    return t.confirm && e();
                }
            });
        },
        _showOpenSettingTip: function() {
            var e = this;
            wx.showModal({
                title: "您已关闭接收订阅消息",
                content: '想要收到最新通知，去设置开启"接收订阅消息"功能',
                cancelText: "取消",
                confirmText: "去开启",
                success: function(t) {
                    return t.confirm && e.wxOpenSetting();
                }
            });
        },
        _assembleSubscription: function(e, t) {
            return e.map(function(e) {
                return t[e] === i ? {
                    template_id: e,
                    subscription_type: "once"
                } : null;
            }).filter(Boolean);
        }
    }
});

exports.default = u;