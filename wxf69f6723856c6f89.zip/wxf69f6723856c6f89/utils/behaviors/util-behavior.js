var e = require("../../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/defineProperty"), a = e(require("../../lib/wx-utils")), i = require("../object"), u = e(require("../../lib/baas")), s = e(require("../../io/index")), o = e(require("../../lib/dayjs.min.js")), c = require("../../config-project/miniprogram"), f = Behavior({
    methods: {
        noop: function() {},
        setDataPromise: a.default.setDataPromise,
        toggleDataKey: function(e) {
            var t = (0, i.get)(e, "currentTarget.dataset.key");
            return t && "string" == typeof t || wx.showToast({
                title: "请设置元素的 data-key 为正确的 data 属性字符串值",
                icon: "none"
            }), this.setDataPromise(n({}, t, !(0, i.get)(this.data, t)));
        },
        isAuth: function() {
            var e = (u.default.getStorage("userinfo") || {}).member_id;
            return u.default.isLogin() && !!e;
        },
        isJoinUnion: function() {
            var e = u.default.getStorage("userinfo");
            return !!e && (!!e.trade_union && !!Number(e.trade_union_id) && !!e.member_name);
        },
        isLoginAndJoinUion: function() {
            return this.isJoinUnion() && this.isAuth();
        },
        getActivityInfo: function(e) {
            var n = arguments;
            return r(t().mark(function r() {
                var a, i, u, c, f, d, l, p, b, h;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a = n.length > 1 && void 0 !== n[1] ? n[1] : "活动将于M月DD日 HH:mm 开启", i = s.default.query.contains("path", e), 
                        t.next = 4, s.default.activity.first({
                            query: i,
                            plain: !1
                        });

                      case 4:
                        return u = t.sent, c = u.header, f = u.data, d = f.starts_at, l = f.ends_at, p = f.status, 
                        b = f.settings, h = (0, o.default)(c.Date).unix(), t.abrupt("return", {
                            startsAt: d,
                            endsAt: l,
                            status: p,
                            now: h,
                            startsTimeStr: (0, o.default)(1e3 * d).format(a),
                            settings: b
                        });

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        navToUserCenter: function() {
            wx.switchTab({
                url: c.ROUTE.USER_CENTER
            });
        },
        getCurrentUser: function() {
            return r(t().mark(function e() {
                var r;
                return t().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!(r = u.default.getUserInfoSync())) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return", r);

                      case 3:
                        return e.prev = 3, e.next = 6, wx.BaaS.auth.getCurrentUser();

                      case 6:
                        r = e.sent, e.next = 15;
                        break;

                      case 9:
                        if (e.prev = 9, e.t0 = e.catch(3), !e.t0 || 604 !== e.t0.code) {
                            e.next = 15;
                            break;
                        }
                        return e.next = 14, wx.BaaS.auth.loginWithWechat();

                      case 14:
                        r = e.sent;

                      case 15:
                        return e.abrupt("return", r);

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 3, 9 ] ]);
            }))();
        }
    }
});

exports.default = f;