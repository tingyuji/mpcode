Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createAccelerometerListener = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [ 2.5, 4, 7 ], a = e(r, 3), n = a[0], o = a[1], i = a[2], t = {
        small: {},
        medium: {},
        large: {}
    };
    function l(e, r) {
        var a;
        switch (e) {
          case "small":
            a = n;
            break;

          case "medium":
            a = o;
            break;

          case "large":
            a = i;
            break;

          default:
            a = o;
        }
        var l = function(e) {
            var n = e.x, o = e.y, i = e.z;
            Math.sqrt(n * n + o * o + i * i) > a && r && r();
        };
        return t[e][r] = l, wx.onAccelerometerChange(l);
    }
    function u(e, r) {
        var a = t[e][r];
        a && (wx.offAccelerometerChange(a), delete t[e][r]);
    }
    function s() {
        wx.offAccelerometerChange(), t.small = {}, t.medium = {}, t.large = {};
    }
    var c = {
        onSmallShake: function(e) {
            return l("small", e);
        },
        onMediumShake: function(e) {
            return l("medium", e);
        },
        onLargeShake: function(e) {
            return l("large", e);
        },
        removeListener: u,
        removeAllListeners: s
    };
    return c;
}, exports.isAllowMembers = function(e, t) {
    for (var l = e.participation_permission, u = e.allow_admin_org, s = e.allow_trade_union, c = e.allow_member_id, m = e.allow_phone, _ = t.admin_org_chart, d = t.trade_union_id, f = t.member_id, y = t._phone, A = !1, b = 0; b < l.length; b++) {
        if (A) return A;
        switch (l[b]) {
          case r:
            A = !0;
            break;

          case a:
            A = Array.isArray(u) && u.some(function(e) {
                return e.id === d || Array.isArray(_) && _.some(function(r) {
                    return r.id === e.id;
                });
            });
            break;

          case n:
            A = Array.isArray(s) && s.some(function(e) {
                return e.id === d;
            });
            break;

          case o:
            A = Array.isArray(c) && c.some(function(e) {
                return e === f;
            });
            break;

          case i:
            A = Array.isArray(m) && m.some(function(e) {
                return e === y;
            });
            break;

          default:
            A = !1;
        }
    }
    return A;
};

var e = require("../@babel/runtime/helpers/slicedToArray"), r = "public", a = "only_allow_admin_org", n = "only_allow_trade_union", o = "only_allow_member_id", i = "only_allow_phone";