Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.compressImage = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10;
    if (!wx.compressImage) return Promise.resolve(e.map(function(e) {
        return {
            src: e,
            origin: e
        };
    }));
    var t = e.map(function(e) {
        return new Promise(function(t, n) {
            wx.compressImage({
                src: e,
                quality: r,
                success: function(r) {
                    console.log(r), t({
                        src: r.tempFilePath,
                        origin: e
                    });
                },
                fail: function(r) {
                    "devtools" === wx.getSystemInfoSync().platform ? t({
                        src: e,
                        origin: e
                    }) : n(new Error(r));
                }
            });
        });
    });
    return Promise.all(t);
}, exports.writeFileSync = exports.readFileSync = exports.fileExist = void 0;

var e = wx.getFileSystemManager();

exports.fileExist = function(r) {
    try {
        e.accessSync(r);
    } catch (e) {
        return !1;
    }
    return !0;
};

exports.writeFileSync = function(r, t) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "binary";
    return e.writeFileSync(r, t, n);
};

exports.readFileSync = function(r) {
    return e.readFileSync(r);
};