Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCurrentPage = d, exports.getCurrentPath = function() {
    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], r = d();
    return f(r.route, e && r.options || {});
}, exports.getPageStackDelta = p, exports.getRedirectQrCodeUrl = function(e) {
    return b.apply(this, arguments);
}, exports.navBack = v, exports.navBackOrCreated = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    e.startsWith("http") && (e = f(c.WEBVIEW, {
        url: e
    }));
    var o = l(e);
    r = Object.assign(o.query, r);
    var a = p(o.path, r);
    if (a > 0) return v(a, t);
    if (a < 0) {
        var u = f(o.path, r);
        return s.includes(o.path) ? wx.switchTab(n({
            url: u
        }, t)) : wx.navigateTo(n({
            url: u
        }, t));
    }
}, exports.navToIndex = y, exports.obj2QueryStr = h, exports.parseRouteOptions = function(e) {
    var r = Object.keys(e).map(function(r) {
        return {
            key: decodeURIComponent(r),
            value: decodeURIComponent(e[r])
        };
    }).reduce(function(e, r) {
        return e[r.key] = r.value, e;
    }, {}), t = {};
    r.scene && (t = g(r.scene), delete r.scene);
    return n(n({}, r), t);
}, exports.parseUrl = l, exports.queryStr2Obj = g, exports.redirectToNotFound = function() {
    return x.apply(this, arguments);
}, exports.urlQuery = f;

var e = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), t = require("../@babel/runtime/helpers/slicedToArray"), n = require("../@babel/runtime/helpers/objectSpread2");

require("../@babel/runtime/helpers/Arrayincludes");

var o = require("../config-project/index"), a = require("./string"), u = require("./is"), i = o.MINIPROGRAM.REDIRECT_SCENE_KEY, c = o.MINIPROGRAM.ROUTE, s = o.MINIPROGRAM.ROUTE_TABS;

function p(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    return e = (0, a.cutStart)(e, "/"), getCurrentPages().reverse().findIndex(function(t) {
        var n = e === (0, a.cutStart)(t.route, "/"), o = (0, u.isDeepEqual)(t.options, r);
        return n && o;
    });
}

function d() {
    return getCurrentPages().slice(-1).pop();
}

function l(e) {
    var r = e.split("?"), n = t(r, 2), o = n[0], a = n[1];
    return {
        path: o,
        query: a ? g(a) : {}
    };
}

function v() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = getCurrentPages(), o = t.length <= 1;
    return o ? y(r) : wx.navigateBack(n({
        delta: e
    }, r));
}

function h(e) {
    return Object.keys(e).map(function(r) {
        return "".concat(r, "=").concat(encodeURIComponent(e[r]));
    }).join("&");
}

function g(e) {
    var r = e.split("&"), t = {};
    return r.forEach(function(e) {
        var r = e.split("=");
        t[decodeURIComponent(r[0])] = decodeURIComponent(r[1]);
    }), t;
}

function f(e, r) {
    var t = h(r);
    return t ? e + "?" + t : e;
}

function x() {
    return (x = r(e().mark(function r() {
        var t, n, o = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = o.length > 0 && void 0 !== o[0] ? o[0] : "", n = o.length > 1 && void 0 !== o[1] ? o[1] : c.HOME, 
                e.next = 4, wx.redirectTo({
                    url: f(c.HOME, {
                        message: t,
                        navTo: n
                    })
                });

              case 4:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function y() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    return wx.switchTab(n({
        url: c.INDEX
    }, e));
}

function b() {
    return (b = r(e().mark(function r(t) {
        var n, o, u, s, p, d, l, v, h, g, f, x, y = arguments;
        return e().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return n = y.length > 1 && void 0 !== y[1] ? y[1] : {}, o = n.type, u = void 0 === o ? "wxacodeunlimit" : o, 
                s = n.cdn, p = void 0 === s || s, d = n.width, l = void 0 === d ? 160 : d, v = n.is_hyaline, 
                h = void 0 !== v && v, g = n.categoryName, f = void 0 === g ? "share-qrcode" : g, 
                e.next = 3, wx.BaaS.getWXACode(u, {
                    scene: "".concat(i, "=").concat(t),
                    page: (0, a.cutStart)(c.USER_CENTER, "/"),
                    width: l,
                    is_hyaline: h
                }, p, f);

              case 3:
                return x = e.sent, e.abrupt("return", x.download_url);

              case 5:
              case "end":
                return e.stop();
            }
        }, r);
    }))).apply(this, arguments);
}