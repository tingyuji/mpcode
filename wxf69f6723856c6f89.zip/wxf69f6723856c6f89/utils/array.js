Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.deepClone = function r(e) {
    var t, n, o, u = Object.prototype.toString.call(e);
    if ("[object Array]" === u) o = []; else {
        if ("[object Object]" !== u) return e;
        o = {};
    }
    if ("[object Array]" === u) {
        for (t = 0, n = e.length; t < n; t++) o.push(r(e[t]));
        return o;
    }
    if ("[object Object]" === u) {
        for (t in e) o[t] = r(e[t]);
        return o;
    }
}, exports.duplicate = function(r, e) {
    var t = [];
    for (;e-- > 0; ) t = t.concat(r);
    return t;
}, exports.filter = function(r) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Boolean, t = Array.isArray(r), n = t ? [] : {};
    return i(r, function(o, u) {
        e(o, u, r) && (t ? n.push(o) : n[u] = o);
    }), n;
}, exports.flat = function r(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
    return e.reduce(function(e, n) {
        return e.concat(t > 1 && Array.isArray(n) ? r(n, t - 1) : n);
    }, []);
}, exports.groupBy = function(r, e) {
    var t = {};
    return r.forEach(function(r) {
        var n = r[e];
        Array.isArray(t[n]) ? t[n].push(r) : t[n] = [ r ];
    }), t;
}, exports.isSubSet = function(r, e) {
    return r = o(r), e = u(e), r.every(function(r) {
        return e.has(r);
    });
}, exports.keyBy = function(r, e) {
    var t = {};
    return r.forEach(function(r) {
        t[(0, n.get)(r, e)] = r;
    }), t;
}, exports.map = i, exports.pluck = function(r, e) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
    if (t) {
        var o = {};
        return r.forEach(function(r) {
            o[(0, n.get)(r, t)] = (0, n.get)(r, e);
        }), o;
    }
    return r.map(function(r) {
        return (0, n.get)(r, e);
    });
}, exports.range = function(r, e) {
    for (var t = [], n = r; n <= e; n++) t.push(n);
    return t;
}, exports.shuffle = function(r, e) {
    var t = -1, n = r.length, o = n - 1;
    e = void 0 === e ? n : e;
    for (;++t < e; ) {
        var u = t + Math.floor(Math.random() * (o - t + 1)), i = r[u];
        r[u] = r[t], r[t] = i;
    }
    return r.length = e, r;
}, exports.sortBy = function(r, e) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "ASC";
    return r.sort(function(r, n) {
        return "ASC" === t.toUpperCase() ? r[e] - n[e] : n[e] - r[e];
    });
}, exports.toArray = o, exports.toSet = u, exports.uniq = function(r) {
    return e(new Set(r).values());
}, exports.uniqueByUserId = function(e) {
    if (!Array.isArray(e)) throw new Error("非法数组格式");
    var t = {}, n = [];
    return e.forEach(function(e) {
        var o = "object" === r(e.created_by) ? e.created_by.id : e.created_by;
        t[o] || (t[o] = !0, n.push(e));
    }), n;
};

var r = require("../@babel/runtime/helpers/typeof"), e = require("../@babel/runtime/helpers/toConsumableArray"), t = require("./is"), n = require("./object");

function o(r) {
    return r instanceof Set ? e(r.values()) : Array.isArray(r) ? r : [ r ];
}

function u(r) {
    return r instanceof Set ? r : new Set(o(r));
}

function i(r, e) {
    if (Array.isArray(r)) return r.map(e);
    if ((0, t.isObject)(r)) {
        var n = {};
        return Object.keys(r).forEach(function(t, o) {
            n[t] = e(r[t], o, r);
        }), n;
    }
    return r;
}