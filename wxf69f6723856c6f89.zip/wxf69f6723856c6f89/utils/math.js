Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.add = function(t, e) {
    var r, a, o, i;
    try {
        r = t.toString().split(".")[1].length;
    } catch (t) {
        r = 0;
    }
    try {
        a = e.toString().split(".")[1].length;
    } catch (t) {
        a = 0;
    }
    if (i = Math.abs(r - a), o = Math.pow(10, Math.max(r, a)), i > 0) {
        var n = Math.pow(10, i);
        r > a ? (t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", "")) * n) : (t = Number(t.toString().replace(".", "")) * n, 
        e = Number(e.toString().replace(".", "")));
    } else t = Number(t.toString().replace(".", "")), e = Number(e.toString().replace(".", ""));
    return (t + e) / o;
};