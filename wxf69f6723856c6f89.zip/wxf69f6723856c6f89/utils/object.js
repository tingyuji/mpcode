Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.get = function(r, e) {
    if ("function" == typeof e) return e(r);
    "string" == typeof e && (e = (e = e.replace(/\[(.*?)]/g, ".$1")).split("."));
    if (!Array.isArray(e)) throw new Error("请传入取值函数、路径字符串、路径数组");
    return e.reduce(function(r, e) {
        return null != r ? r[e] : void 0;
    }, r);
}, exports.invert = function(r) {
    var e = {};
    return Object.keys(r).forEach(function(t) {
        e[r[t]] = t;
    }), e;
}, exports.omit = function(r) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], t = {};
    return Object.keys(r).forEach(function(n) {
        e.includes(n) || (t[n] = r[n]);
    }), t;
}, exports.pick = function(r) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
    if (!r) return r;
    var t = {};
    return e.forEach(function(e) {
        return t[e] = r[e];
    }), t;
}, exports.values = function(r) {
    return Object.keys(r).map(function(e) {
        return r[e];
    });
}, require("../@babel/runtime/helpers/Arrayincludes");