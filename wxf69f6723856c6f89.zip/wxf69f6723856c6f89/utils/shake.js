Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createShakeListener = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [ 1.8, 4, 7 ], t = e(r, 3), n = t[0], o = t[1], a = t[2], i = {
        light: {},
        moderate: {},
        strong: {}
    };
    function c(e, r) {
        var t;
        switch (e) {
          case "light":
            t = n;
            break;

          case "moderate":
            t = o;
            break;

          case "strong":
            t = a;
            break;

          default:
            t = o;
        }
        var c = function(e) {
            var n, o, a = e.x, i = e.y, c = e.z;
            Math.sqrt(a * a + i * i + c * c) > t && (null === (n = (o = wx).vibrateLong) || void 0 === n || n.call(o, {
                type: "heavy"
            }), r && r());
        };
        return i[e][r] = c, wx.onAccelerometerChange(c);
    }
    function l(e, r) {
        var t = i[e][r];
        t && (wx.offAccelerometerChange(t), delete i[e][r]);
    }
    function s() {
        wx.offAccelerometerChange(), i.light = {}, i.moderate = {}, i.strong = {};
    }
    var u = {
        onLightShake: function(e) {
            return c("light", e);
        },
        onModerateShake: function(e) {
            return c("moderate", e);
        },
        onStrongShake: function(e) {
            return c("strong", e);
        },
        removeShakeListener: l,
        removeAllShakeListeners: s
    };
    return u;
};

var e = require("../@babel/runtime/helpers/slicedToArray");