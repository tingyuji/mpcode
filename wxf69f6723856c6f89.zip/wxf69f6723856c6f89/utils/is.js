Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isDeepEqual = function e(t, n) {
    if (r(t) || r(n)) return t === n;
    var i = Object.keys(t);
    if (i.length !== Object.keys(n).length) return !1;
    return i.every(function(r) {
        return e(t[r], n[r]);
    });
}, exports.isEmptyObject = function(e) {
    return t(e) && !Object.keys(e).length;
}, exports.isNumber = function(e) {
    return "number" == typeof e && !isNaN(e);
}, exports.isNumeric = function(e) {
    return !isNaN(parseFloat(e)) && isFinite(e);
}, exports.isObject = t, exports.isPrimitive = r, exports.objectToString = e;

function e(e) {
    return Object.prototype.toString.call(e);
}

function t(t) {
    return "[object Object]" === e(t);
}

function r(e) {
    return !t(e) && !Array.isArray(e);
}