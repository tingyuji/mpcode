Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.cutStart = function(e, t) {
    return 0 === e.indexOf(t) ? e.substr(t.length) : e;
}, exports.start = function(e, t) {
    var r = t.length;
    return e.slice(0, r) === t ? e : t + e;
}, exports.toCamelCase = function(e) {
    return e.replace(/[_-](\w)/g, function(e, t) {
        return t.toUpperCase();
    });
};