Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.keyframe = void 0;

exports.keyframe = {
    zoomIn: [ {
        scale: [ 0, 0 ]
    }, {
        scale: [ 1, 1 ]
    } ],
    zoomInBounce: [ {
        scale: [ 0, 0 ]
    }, {
        scale: [ 1, 1 ],
        ease: "cubic-bezier(0.175, 0.885, 0.32, 1.275)"
    } ],
    zoomOut: [ {
        scale: [ 1, 1 ]
    }, {
        scale: [ 0, 0 ]
    } ],
    zoomOutBounce: [ {
        scale: [ 1, 1 ]
    }, {
        scale: [ 0, 0 ],
        ease: "cubic-bezier(0.6, -0.28, 0.735, 0.045)"
    } ],
    translateY100: [ {
        translateY: "0%"
    }, {
        translateY: "100%"
    } ],
    translateY0: [ {
        translateY: "100%"
    }, {
        translateY: "0%"
    } ],
    opacity0: [ {
        opacity: 1
    }, {
        opacity: 0
    } ],
    opacity1: [ {
        opacity: 0
    }, {
        opacity: 1
    } ]
};