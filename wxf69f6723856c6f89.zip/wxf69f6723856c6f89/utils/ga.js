Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../lib/ga-sdk.js"), t = null, r = null, n = function(n) {
    return r = n, t = e.GoogleAnalytics.getInstance(n).setAppName("粤工惠活动集").setAppVersion("v1").newTracker("UA-183804432-2");
}, o = function() {
    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
    t || (t = n(r));
    var o = wx.BaaS.storage.get("uid");
    return e && o && o && t.set("&uid", o), t;
}, a = function(t, r) {
    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
    if (t && r) {
        var i = o(), c = new e.HitBuilders.EventBuilder();
        c.setCategory(t).setAction(r).setLabel(n).setValue(a), i.send(c.build());
    }
}, i = function(t, r, n, o) {
    var a = [], i = new e.HitBuilders.EventBuilder(), c = Object.prototype.toString.call(t);
    return "[object Object]" === c ? a = [ t ] : "[object Array]" === c && (a = t), 
    a.forEach(function(t) {
        var r = new e.Product();
        [ "id", "name", "brand", "category", "price", "quantity", "variant" ].forEach(function(e) {
            var n = e.replace(/^\w/, function(e) {
                return e.toUpperCase();
            });
            null != t[e] && r["set" + n](t[e]);
        }), i.addProduct(r);
    }), i.setCategory(r).setAction(n).setLabel(o), i;
}, c = {
    initTracker: n,
    screenView: function(t) {
        var r = o();
        r.setScreenName(t), r.send(new e.HitBuilders.ScreenViewBuilder().build());
    },
    event: a,
    emitter: function(e) {
        var t = e.currentTarget.dataset.ga;
        try {
            var r = JSON.parse(t), n = r.category, o = r.action, i = r.label;
            a(n, o, i);
        } catch (e) {
            throw new Error('"data-ga" 请使用 JSON 格式');
        }
    },
    source: function(t) {
        var r = o(), n = e.CampaignParams.parseFromPageOptions(t).toUrl();
        r.setCampaignParamsOnNextHit(n);
    },
    ecommerce: function(t, r, n, a) {
        var c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "", u = o(), s = new e.ProductAction(r), d = i(t, n, a, c);
        d.setProductAction(s), u.send(d.build());
    },
    ecommerceCheckout: function(t, r, n, a) {
        var c = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "", u = o(), s = new e.ProductAction(e.ProductAction.ACTION_CHECKOUT);
        s.setCheckoutStep(r);
        var d = i(t, n, a, c);
        d.setProductAction(s), u.send(d.build());
    },
    ecommercePurchase: function(t, r, n, a, c) {
        var u = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "", s = o(), d = new e.ProductAction(e.ProductAction.ACTION_PURCHASE);
        d.setTransactionId(r).setTransactionAffiliation("coolbuy").setTransactionRevenue(n);
        var l = i(t, a, c, u);
        l.setProductAction(d), s.send(l.build());
    }
};

exports.default = c;