Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.observeUtils = exports.default = exports.INTERSECTION_RATIO = void 0;

var e = Behavior({
    lifetimes: {
        created: function() {
            this._observers = [];
        },
        detached: function() {
            this._disconnectObservers();
        }
    },
    methods: {
        createAutoIntersectionObserver: function(e) {
            var t = this.createIntersectionObserver(e);
            return this._observers.push(t), t;
        },
        _disconnectObservers: function() {
            this._observers.map(function(e) {
                return e.disconnect();
            }), this._observers = [];
        }
    }
});

exports.default = e;

var t = {
    FULLY_OUT: 0,
    FULLY_IN: 1
};

exports.INTERSECTION_RATIO = t;

var r = {
    isEntering: function(e) {
        return !r.isEntered(e);
    },
    isEntered: function(e) {
        return e.intersectionRatio === t.FULLY_IN;
    },
    isLeaving: function(e) {
        return !r.isLeft(e);
    },
    isLeft: function(e) {
        return e.intersectionRatio === t.FULLY_OUT;
    }
};

exports.observeUtils = r;