Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../@babel/runtime/helpers/slicedToArray");

require("../@babel/runtime/helpers/Objectentries");

var t = require("../@babel/runtime/helpers/objectSpread2"), r = require("../config/index"), n = {
    get query() {
        return new wx.BaaS.Query();
    },
    get user() {
        return new wx.BaaS.User();
    },
    get file() {
        return new wx.BaaS.File();
    },
    table: function(e) {
        return new wx.BaaS.TableObject(e);
    },
    pickObjects: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.data, r = void 0 === t ? {} : t, n = r.objects, i = void 0 === n ? [] : n;
        return i;
    },
    pickData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.data, r = void 0 === t ? null : t;
        return r;
    },
    invoke: function(e, t) {
        var r = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        return wx.BaaS.invoke(e, t, r).then(function(e) {
            if (0 !== e.code) throw new Error(e.error.message);
            return e;
        });
    }
}, i = function() {
    var i = r.TABLE[a];
    n[function(e) {
        /^_/.test(e) && (e = e.slice(1));
        return e.replace(/_(\w)/g, function(e, t) {
            return t.toUpperCase();
        });
    }(a)] = {
        get table() {
            return new wx.BaaS.TableObject(i);
        },
        find: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.query, r = e.offset, i = void 0 === r ? 0 : r, a = e.limit, o = void 0 === a ? 20 : a, u = e.orderBy, c = void 0 === u ? "-created_at" : u, l = e.expand, d = e.select, v = e.withCount, f = void 0 !== v && v, s = e.plain, h = void 0 === s || s, p = this.table;
            return t && p.setQuery(t), l && p.expand(l), d && p.select(d), p.offset(i).limit(o).orderBy(c).find({
                withCount: f
            }).then(h ? n.pickObjects : function(e) {
                return e;
            });
        },
        first: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return this.find(t(t({}, e), {}, {
                limit: 1
            })).then(function(t) {
                if (!1 === e.plain) {
                    var r = t.data.objects || [];
                    return t.data = r[0] || null, t;
                }
                return t[0];
            });
        },
        get: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = t.expand, i = t.select, a = t.plain, o = void 0 === a || a, u = this.table;
            return r && u.expand(r), i && u.select(i), u.get(e).then(o ? n.pickData : function(e) {
                return e;
            });
        },
        create: function(e) {
            var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], r = this.table.create();
            return r.set(e).save().then(t ? n.pickData : function(e) {
                return e;
            });
        },
        update: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.id, i = t.query, a = t.data, u = t.unset, c = t.incrementBy, l = t.append, d = t.uAppend, v = t.remove, f = t.patchObject, s = t.offset, h = void 0 === s ? 0 : s, p = t.limit, b = t.enableTrigger, g = void 0 === b || b, w = t.withCount, y = void 0 !== w && w, m = t.plain, x = void 0 === m || m;
            if (o(r, i)) return Promise.reject();
            var j = this.table;
            i && (j.offset(h), p > 0 && j.limit(p));
            var B = j.getWithoutData(r || i), q = function(t, r) {
                return Object.entries(r).forEach(function(r) {
                    var n = e(r, 2), i = n[0], a = n[1];
                    return B[t](i, a);
                });
            };
            return a && q("set", a), u && q("unset", u), c && q("incrementBy", c), l && q("append", l), 
            d && q("uAppend", d), v && q("remove", v), f && q("patchObject", f), B.update({
                enableTrigger: g,
                withCount: y
            }).then(x ? n.pickData : function(e) {
                return e;
            });
        },
        delete: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.id, r = e.query, n = e.offset, i = void 0 === n ? 0 : n, a = e.limit, u = e.enableTrigger, c = void 0 === u || u, l = e.withCount, d = void 0 !== l && l;
            if (o(t, r)) return Promise.reject();
            var v = this.table;
            return r && (v.offset(i), a > 0 && v.limit(a)), v.delete(t || r, {
                enableTrigger: c,
                withCount: d
            });
        },
        count: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.query;
            return this.table.setQuery(e).count();
        },
        createMany: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, r = t.enableTrigger, n = void 0 === r || r;
            return this.table.createMany(e, {
                enableTrigger: n
            });
        }
    };
};

for (var a in r.TABLE) i();

function o(e, t) {
    if (!e && !t) throw Error("id 和 query 参数必须传入其中之一");
    if (t && !(t instanceof wx.BaaS.Query)) throw Error("query 必须是 wx.BaaS.Query 的实例");
    return !1;
}

var u = n;

exports.default = u;