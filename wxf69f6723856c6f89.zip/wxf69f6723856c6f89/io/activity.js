var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/asyncToGenerator"), a = e(require("./base")), i = require("../config/index"), n = e(require("../lib/baas")), o = {
    getActivityList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.status, r = void 0 === t ? "all" : t, n = e.cityCode, o = void 0 === n ? "440000" : n, c = e.offset, u = void 0 === c ? 0 : c, d = e.limit, s = void 0 === d ? 20 : d, f = e.orderBy, l = void 0 === f ? "-priority,-created_at" : f, v = e.withCount, p = void 0 !== v && v, y = a.default.query;
        return y.in("city_code", [ o, "440000" ]).compare("active", "!=", !1), "all" !== r && y.compare("status", "=", r), 
        a.default.table(i.TABLE.activity).offset(u).limit(s).orderBy(l).setQuery(y).find({
            withCount: p
        });
    },
    getActParticipant: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var o, c, u, d, s, f, l, v, p, y, b, g, h, _, m, x, w, L;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = e.actType, c = void 0 === o ? "act3" : o, u = e.active, d = void 0 === u || u, 
                    s = e.offset, f = void 0 === s ? 0 : s, l = e.limit, v = void 0 === l ? 20 : l, 
                    p = e.orderBy, y = void 0 === p ? "-created_at" : p, b = e.withUserLikesLog, g = void 0 !== b && b, 
                    h = e.withCount, _ = void 0 !== h && h, m = a.default.query, d && m.compare("active", "=", d), 
                    x = "", w = "", "act3" === c ? (x = "act3_participation_log", w = "act3_likes_log") : "act5" === c && (x = "act5_participation_log", 
                    w = "act5_likes_log"), t.next = 8, a.default.table(i.TABLE[x]).setQuery(m).expand("created_by").offset(f).limit(v).orderBy(y).find({
                        withCount: _
                    });

                  case 8:
                    if (L = t.sent, !g) {
                        t.next = 12;
                        break;
                    }
                    return t.next = 12, n.withUserLikesLog(i.TABLE[w], L.data.objects, "isLiked");

                  case 12:
                    return t.abrupt("return", L);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    withUserLikesLog: function(e, i) {
        var o = arguments;
        return r(t().mark(function r() {
            var c, u, d, s, f, l, v, p, y, b, g;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (c = o.length > 2 && void 0 !== o[2] ? o[2] : "likesLog", u = n.default.getUidSync()) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return", i);

                  case 4:
                    return t.next = 6, wx.BaaS.getServerDate();

                  case 6:
                    return d = t.sent, s = d.data.time, f = new Date(s), l = "".concat(f.getMonth() + 1).padStart(2, 0), 
                    v = "".concat(f.getDate()).padStart(2, 0), p = "".concat(l).concat(v), (y = a.default.query).in("created_by", Array.isArray(u) ? u : [ u ]), 
                    y.compare("date", "=", p), t.next = 17, a.default.table(e).setQuery(y).offset(0).limit(20).orderBy("-created_at").find();

                  case 17:
                    return b = t.sent, g = b.data.objects, i.forEach(function(e) {
                        e[c] = -1 !== g.findIndex(function(t) {
                            return t.vote_to.id === e.id;
                        });
                    }), t.abrupt("return", i);

                  case 21:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    }
};

exports.default = o;