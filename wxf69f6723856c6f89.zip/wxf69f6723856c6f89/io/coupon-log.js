var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), r = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/asyncToGenerator"), o = e(require("./base")), u = require("../config-project/baas"), a = e(require("../lib/baas")), i = require("../config/index").CONSTANTS.PRIZE_TYPE;

function c(e) {
    return l.apply(this, arguments);
}

function l() {
    return (l = n(t().mark(function e(r) {
        var n, c, l, s, p, f, d, b, _, y, E, v, g, h;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (n = r.table, c = r.offset, l = void 0 === c ? 0 : c, s = r.limit, p = void 0 === s ? 20 : s, 
                f = r.orderBy, d = void 0 === f ? "-created_at" : f, b = r.expand, _ = r.withCount, 
                y = r.status, E = r.couponInfoKey, n) {
                    e.next = 3;
                    break;
                }
                throw new Error("table 不能为空");

              case 3:
                return v = a.default.getUidSync(), g = o.default.query.in("status", y).compare("created_by", "=", v), 
                n === u.TABLE.prize_log && g.in("prize.type", [ i.WECHAT_DISCOUNT_COUPON, i.WECHAT_RECHARGE_COUPON ]), 
                e.prev = 6, e.next = 9, o.default.table(n).offset(l).limit(p).expand(b).orderBy(d).setQuery(g).find({
                    withCount: _
                });

              case 9:
                return h = e.sent, E && h.data.objects.forEach(function(e) {
                    e.couponInfo = e[E], e.table = E, delete e[E];
                }), e.abrupt("return", h);

              case 14:
                return e.prev = 14, e.t0 = e.catch(6), e.abrupt("return", {
                    data: {
                        meta: {
                            limit: p,
                            offset: l,
                            next: null
                        },
                        objects: []
                    }
                });

              case 17:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 6, 14 ] ]);
    }))).apply(this, arguments);
}

var s = {
    getDiscountCouponLog: function(e) {
        return c(r({
            table: u.TABLE.discount_coupon_log,
            couponInfoKey: u.TABLE.discount_coupon,
            expand: [ u.TABLE.discount_coupon ]
        }, e));
    },
    getBillCouponLogList: function(e) {
        return c(r({
            table: u.TABLE.bill_coupon_log,
            couponInfoKey: u.TABLE.bill_coupon,
            expand: [ u.TABLE.bill_coupon ]
        }, e));
    },
    getPrizeList: function(e) {
        return c(r({
            table: u.TABLE.prize_log,
            couponInfoKey: "prize"
        }, e));
    },
    getCouponInfoByStockId: function(e, r) {
        return n(t().mark(function n() {
            var u, a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e && r) {
                        t.next = 2;
                        break;
                    }
                    throw new Error("tableName 和 stockId 不能为空");

                  case 2:
                    return t.prev = 2, (u = o.default.query).compare("stock_id", "=", r), t.next = 7, 
                    o.default.table(e).setQuery(u).find();

                  case 7:
                    return a = t.sent, t.abrupt("return", a);

                  case 11:
                    t.prev = 11, t.t0 = t.catch(2), console.log("获取卡券信息出错~", t.t0);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, n, null, [ [ 2, 11 ] ]);
        }))();
    }
};

exports.default = s;