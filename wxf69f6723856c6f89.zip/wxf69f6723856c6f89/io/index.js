var e = require("../@babel/runtime/helpers/interopRequireWildcard").default, r = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var u = require("../@babel/runtime/helpers/objectSpread2"), t = r(require("./base")), i = r(require("./userprofile")), a = r(require("./activity")), l = r(require("./baas-file")), d = r(require("./coupon")), s = r(require("./coupon-log")), f = e(require("./settings")), o = u(u(u(u(u(u({}, i.default), a.default), l.default), s.default), d.default), f);

Object.assign(t.default, o);

var p = t.default;

exports.default = p;