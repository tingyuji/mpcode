Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    uploadBaaSFileObjects: function(e, t) {
        return Promise.all(e.map(function(e) {
            return new wx.BaaS.File().upload({
                filePath: e.path
            }, {
                categoryID: t
            }).then(function(t) {
                return e.url = t.data.path, e.id = t.data.file.id, e;
            }).catch(function(t) {
                return e.error = t, e;
            });
        }));
    }
};

exports.default = e;