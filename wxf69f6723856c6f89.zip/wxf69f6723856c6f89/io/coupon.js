Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../@babel/runtime/helpers/regeneratorRuntime"), e = require("../@babel/runtime/helpers/asyncToGenerator"), t = require("../config-project/baas"), n = {
    getDaysUntilBirthday: function() {
        return e(r().mark(function e() {
            var n, a, u, s;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, wx.BaaS.request({
                        url: t.BIRTH_DAY_URL
                    });

                  case 2:
                    if (n = r.sent, a = n.data, u = a.days_until_birth, s = a.error_msg, 200 === n.statusCode) {
                        r.next = 9;
                        break;
                    }
                    throw new Error(s);

                  case 9:
                    return r.abrupt("return", u);

                  case 10:
                  case "end":
                    return r.stop();
                }
            }, e);
        }))();
    },
    getBirthdayCoupon: function() {
        return e(r().mark(function e() {
            var n, a, u, s;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, wx.BaaS.request({
                        url: t.GET_BIRTH_COUPON_URL,
                        method: "POST"
                    });

                  case 2:
                    if (n = r.sent, a = n.data, u = a.status, s = a.error_msg, 200 === n.statusCode) {
                        r.next = 9;
                        break;
                    }
                    throw new Error(s);

                  case 9:
                    return r.abrupt("return", u);

                  case 10:
                  case "end":
                    return r.stop();
                }
            }, e);
        }))();
    },
    getBillCoupon: function() {
        return e(r().mark(function e() {
            var n, a, u, s;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, wx.BaaS.request({
                        url: t.GET_BILL_COUPON_URL,
                        method: "POST"
                    });

                  case 2:
                    if (n = r.sent, a = n.data, u = a.status, s = a.error_msg, 200 === n.statusCode) {
                        r.next = 9;
                        break;
                    }
                    throw new Error(s);

                  case 9:
                    return r.abrupt("return", u);

                  case 10:
                  case "end":
                    return r.stop();
                }
            }, e);
        }))();
    }
};

exports.default = n;