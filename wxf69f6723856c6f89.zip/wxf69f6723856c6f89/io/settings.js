var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getGdftuSettingsByKey = function(e) {
    if ((0, t.isEmpty)(e)) throw new Error("缺少参数 key");
    var r = function(t) {
        var r = t.statusCode, n = t.data;
        if (200 !== r) throw new Error("获取 settings.json 数据失败");
        return n[e];
    };
    if (s) return s.then(r);
    return (s = n.default.request({
        url: "".concat("https://gdftu-settings.customer.minapp.com", "/").concat("wxf69f6723856c6f89", "-").concat(i)
    })).then(r).catch(function(e) {
        throw s = null, console.log("request settings.json error", e), e;
    });
};

var t = require("../lib/licia"), r = require("../config/index"), n = e(require("../lib/wx-utils")), i = r.DEV ? "settings-dev.json" : "settings.json", s = null;