var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../@babel/runtime/helpers/regeneratorRuntime"), t = require("../@babel/runtime/helpers/asyncToGenerator"), u = e(require("./base")), n = {
    getUserprofileList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.id, t = e.offset, n = void 0 === t ? 0 : t, i = e.limit, a = void 0 === i ? 20 : i, o = e.orderBy, s = void 0 === o ? "-created_at" : o, f = e.partyBranch, l = e.select, d = e.withCount, c = void 0 !== d && d, p = u.default.query;
        return r && p.in("id", Array.isArray(r) ? r : [ r ]), f && p.in("party_branch", Array.isArray(f) ? f : [ f ]), 
        u.default.userprofile.offset(n).limit(a).orderBy(s).select(l).setQuery(p).find({
            withCount: c
        });
    },
    updateUserProfile: function(e, r) {
        return u.default.userprofile.getWithoutData(e).set(r).update();
    },
    getUserProfileById: function(e) {
        return u.default.userprofile.get(e).then(function(e) {
            return e.data;
        });
    },
    getAccountInfo: function() {
        return t(r().mark(function e() {
            var t;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, wx.BaaS.auth.getCurrentUser();

                  case 2:
                    return t = e.sent, e.abrupt("return", t);

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    }
};

exports.default = n;