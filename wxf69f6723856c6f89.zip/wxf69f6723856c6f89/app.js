var e = require("@babel/runtime/helpers/interopRequireWildcard").default, t = require("@babel/runtime/helpers/interopRequireDefault").default, r = require("@babel/runtime/helpers/regeneratorRuntime"), n = require("@babel/runtime/helpers/asyncToGenerator"), a = require("./config/index"), u = require("./config-project/index"), i = t(require("./lib/baas")), s = require("./utils/is"), o = require("./lib/format"), c = t(require("./lib/wx-utils")), l = t(require("./lib/request-interceptor")), f = t(require("./io/index")), p = require("./utils/route"), d = e(require("./lib/auth")), v = t(require("./lib/device")), b = require("./lib/mock"), x = u.BAAS.FUNCTION, h = u.BAAS.NEW_YUE_GONG_HUI;

App({
    globalData: {
        scene: 0
    },
    onLaunch: function() {
        var e = this;
        return n(r().mark(function t() {
            var n;
            return r().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ((0, b.setApp)(e), wx.BaaS = requirePlugin("sdkPlugin"), wx.BaaS.wxExtend(wx.login, wx.getUserInfo, wx.requestPayment), 
                    (0, l.default)(wx.BaaS, "request"), wx.BaaS.init(a.BAAS_CLIENT_ID, {
                        autoLogin: !0,
                        env: a.DEV ? a.BAAS_ENV_ID : void 0
                    }), !b.isDevContainer) {
                        t.next = 8;
                        break;
                    }
                    return t.next = 8, (0, b.setMockUserprofile)();

                  case 8:
                    e.updateMemberInfo(), e.act46ShowFinishAllModal(), c.default.checkUpdateManager(), 
                    console.log("[运行环境] ".concat(a.DEV ? "开发" : "生产")), n = v.default.getSystemInfo().platform, 
                    /mac|window/i.test(n) && e.showDeviceTips();

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    onShow: function(e) {
        var t = this;
        return n(r().mark(function n() {
            var a, u, i;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return console.log("===options===", e), t.globalData.scene = e.scene, u = e.referrerInfo, 
                    t.updateUserInfoByReferrer(e), u && u.appId === h.appId && null != u && null !== (a = u.extraData) && void 0 !== a && a.ZAA && t.act8UpdateRealName(), 
                    r.next = 7, t.getCurrentUser();

                  case 7:
                    return i = r.sent, r.next = 10, t.updateUserSource(e, i);

                  case 10:
                    t.bindInviterInfo(e);

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, n);
        }))();
    },
    act46ShowFinishAllModal: function() {
        this.globalData.act46FinishAllModalVisible = !0;
    },
    updateMemberInfo: function() {
        return n(r().mark(function e() {
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    console.log("== updateMemberInfo =="), d.default.getUserInfo();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    updateUserInfoByReferrer: function(e) {
        d.default.updateUserInfoByReferrer(e).then(function(e) {
            e && c.default.showToast("授权登录成功");
        }).catch(function(e) {
            var t;
            c.default.showToast(d.ERROR_MESSAGE[null == e || null === (t = e.data) || void 0 === t ? void 0 : t.error_code] || "登录失败");
        });
    },
    act8UpdateRealName: function() {
        var e = this;
        return n(r().mark(function t() {
            return r().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return console.log("act8_update_real_name_status start"), t.prev = 1, t.next = 4, 
                    e.getInviteActivityStatus();

                  case 4:
                    if (!t.sent) {
                        t.next = 8;
                        break;
                    }
                    return t.next = 7, wx.BaaS.invoke(x.ACT8_UPDATE_REAL_NAME_STATUS);

                  case 7:
                    console.log("云函数更新成功：", x.ACT8_UPDATE_REAL_NAME_STATUS);

                  case 8:
                    t.next = 13;
                    break;

                  case 10:
                    t.prev = 10, t.t0 = t.catch(1), console.log("cloud function error: ", t.t0);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 10 ] ]);
        }))();
    },
    showDeviceTips: function() {
        wx.showModal({
            content: "请使用手机端微信打开，参与活动",
            showCancel: !1,
            success: function(e) {
                e.confirm && wx.exitMiniProgram();
            }
        });
    },
    bindInviterInfo: function(e) {
        var t = this;
        return n(r().mark(function n() {
            var a, u, c, l;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (!(0, s.isEmptyObject)(e.query)) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return");

                  case 2:
                    if (a = (0, o.parseOptionsScene)("rid", e.query)) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return");

                  case 5:
                    if (!i.default.getUserInfoSync().member_id) {
                        r.next = 8;
                        break;
                    }
                    return r.abrupt("return");

                  case 8:
                    return r.next = 10, t.getInviteActivityStatus();

                  case 10:
                    if (!r.sent) {
                        r.next = 17;
                        break;
                    }
                    return r.next = 13, f.default.redirect.get(a);

                  case 13:
                    u = r.sent, c = u.path, (l = (0, p.queryStr2Obj)(c.split("?")[1])).reg_inviter && f.default.invoke(x.ACT8_BIND_INVITER, {
                        inviter: l.reg_inviter
                    }).then(function(e) {
                        console.log("=== update inviter ===");
                    }).catch(function(e) {
                        console.log("=== update inviter ===", e);
                    });

                  case 17:
                  case "end":
                    return r.stop();
                }
            }, n);
        }))();
    },
    getInviteActivityStatus: function() {
        return n(r().mark(function e() {
            var t, n, a, u, i, s;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = new Date().setMilliseconds(0) / 1e3, n = f.default.query.compare("key", "=", "invitation_activities"), 
                    e.next = 4, f.default.settings.first({
                        query: n
                    });

                  case 4:
                    return a = e.sent, u = a.json.value, i = u.starts_at, s = u.ends_at, e.abrupt("return", i < t && s > t);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    getCurrentUser: function() {
        return n(r().mark(function e() {
            var t;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, wx.BaaS.auth.getCurrentUser();

                  case 3:
                    t = e.sent, e.next = 12;
                    break;

                  case 6:
                    if (e.prev = 6, e.t0 = e.catch(0), !e.t0 || 604 !== e.t0.code) {
                        e.next = 12;
                        break;
                    }
                    return e.next = 11, wx.BaaS.auth.loginWithWechat();

                  case 11:
                    t = e.sent;

                  case 12:
                    return e.abrupt("return", t);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 6 ] ]);
        }))();
    },
    updateUserSource: function(e, t) {
        return n(r().mark(function n() {
            var a, u, i, c;
            return r().wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (!(0, s.isEmptyObject)(e.query) && t) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return");

                  case 2:
                    if (a = (0, o.parseOptionsScene)("source", e.query), u = e.path, i = t.get("member_name"), 
                    c = t.get("member_id"), !(!!i && !!c)) {
                        r.next = 9;
                        break;
                    }
                    return r.abrupt("return");

                  case 9:
                    return r.prev = 9, r.next = 12, t.set({
                        source: a,
                        source_path: u
                    }).update();

                  case 12:
                    return r.abrupt("return", r.sent);

                  case 15:
                    throw r.prev = 15, r.t0 = r.catch(9), console.log("更新用户来源失败 ", r.t0.message), r.t0;

                  case 19:
                  case "end":
                    return r.stop();
                }
            }, n, null, [ [ 9, 15 ] ]);
        }))();
    }
});