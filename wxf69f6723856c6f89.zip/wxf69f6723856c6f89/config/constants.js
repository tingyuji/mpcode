Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.WECHAT_COUPON_OFFICIAL_ERROR_MSG_MAP = exports.WECHAT_COUPON_OFFICIAL_ERROR = exports.SETTING_KEYS = exports.PRIZE_STATUS = exports.INVITATION_STATUS = exports.HSERVE_API_ERROR_CODE_MSG_MAP = exports.COUPON_RECEIVE_STATUS = void 0;

var _, E = require("../@babel/runtime/helpers/defineProperty");

exports.COUPON_RECEIVE_STATUS = {
    SENDING: "sending",
    SUCCESS: "success",
    FAILED: "failed"
};

exports.HSERVE_API_ERROR_CODE_MSG_MAP = {
    10000: "活动太火爆了，请稍后重试",
    10001: "获取用户信息失败，请重新进入小程序",
    10002: "活动太火爆了，请稍后重试",
    10003: "活动太火爆了，请稍后重试",
    10004: "活动太火爆了，请稍后重试",
    10005: "活动未开始",
    10006: "活动已结束",
    10007: "您不符合本次活动参与资格",
    10008: "您还未达到领取条件",
    10009: "已领完",
    10010: "已领完",
    10011: "您已到领取上限",
    10012: "已领完",
    10013: "领取失败，请点击重新领取",
    10014: "领取失败，请点击重新领取",
    10016: "您已到领取上限",
    10018: "今日活动尚未开放",
    10019: "今日已领完，明日再来",
    10020: "您已达到领取次数上限，请勿重复领取"
};

var e = {
    NOT_ENOUGH: "NOT_ENOUGH",
    RULE_LIMIT: "RULE_LIMIT",
    USER_ACCOUNT_ABNORMAL: "USER_ACCOUNT_ABNORMAL"
};

exports.WECHAT_COUPON_OFFICIAL_ERROR = e;

var T = (E(_ = {}, e.NOT_ENOUGH, "券已领完"), E(_, e.RULE_LIMIT, "您已领过，请勿重复领取"), E(_, e.USER_ACCOUNT_ABNORMAL, "您的微信命中微信支付风控"), 
_);

exports.WECHAT_COUPON_OFFICIAL_ERROR_MSG_MAP = T;

exports.SETTING_KEYS = {
    NOTICE: "notice",
    WELFARE_MODALS: "welfare_modals",
    FLOAT_SUBSCRIBE_BUTTON: "float_subscribe_button"
};

exports.PRIZE_STATUS = {
    NOT_SEND: "not_send",
    SENDING: "sending",
    SENT_SUCCEEDED: "sent_succeeded",
    SENT_FAILED: "sent_failed",
    USED: "used",
    EXPIRED: "expired"
};

exports.INVITATION_STATUS = {
    MATCHED: "matched",
    PENDING: "pending",
    NOT_APPLIED: "not_applied",
    UNKNOWN: "unknown",
    DUPLICATED: "duplicated",
    NOT_TARGET_MEMBER: "not_target_member",
    INVALID_IDENTITY_VERIFIED_AT: "invalid_identity_verified_at",
    JOINED_BEFORE_INVITATION: "joined_before_invitation"
};