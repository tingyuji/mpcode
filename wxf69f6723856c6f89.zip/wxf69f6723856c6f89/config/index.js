Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ACT9_ACTIVITY_ID = exports.ACT13_MERGE_TIGER_CARD_ID = void 0, Object.defineProperty(exports, "ADDRESS", {
    enumerable: !0,
    get: function() {
        return e.ADDRESS;
    }
}), Object.defineProperty(exports, "BAAS", {
    enumerable: !0,
    get: function() {
        return e.BAAS;
    }
}), exports.BAAS_ENV_ID = exports.BAAS_CLIENT_ID = void 0, Object.defineProperty(exports, "CONSTANTS", {
    enumerable: !0,
    get: function() {
        return e.CONSTANTS;
    }
}), exports.FUNCTION = exports.FILE_CATEGORY = exports.DEV = void 0, Object.defineProperty(exports, "MINIPROGRAM", {
    enumerable: !0,
    get: function() {
        return e.MINIPROGRAM;
    }
}), exports.TABLE = exports.SETTING_RECORD_ID = exports.ROUTE = void 0;

var e = require("../config-project/index");

exports.DEV = !1;

var r = e.BAAS.CLIENT_ID;

exports.BAAS_CLIENT_ID = r;

var t = e.BAAS.ENV_ID;

exports.BAAS_ENV_ID = t;

var A = e.BAAS.TABLE;

exports.TABLE = A;

var o = e.MINIPROGRAM.ROUTE;

exports.ROUTE = o;

var I = e.BAAS.FUNCTION;

exports.FUNCTION = I;

var T = e.BAAS.FILE_CATEGORY;

exports.FILE_CATEGORY = T;

exports.SETTING_RECORD_ID = "607ff31d53ea6931e3020674";

exports.ACT9_ACTIVITY_ID = "61248bdee93cc3307e8090bf";

exports.ACT13_MERGE_TIGER_CARD_ID = "61d7ac5b85663e0d618274d7";