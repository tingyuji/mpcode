Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.formatDurationToMin = function(t) {
    if (!t) return "00:00";
    var e = parseInt(t / 60, 10), n = parseInt(t % 60, 10), r = function(t) {
        return "".concat(t > 9 ? "" : "0").concat(t);
    };
    return "".concat(r(e), ":").concat(r(n));
}, exports.timeago = function(t) {
    if (!t) return t;
    t = new Date(t.replace(/-/g, "/"));
    var e = new Date(), n = e.getTime() - t.getTime(), r = "", o = n / 36e5, a = n / 6e4, c = n / 864e5;
    s = e, g = t, r = s.getFullYear() === g.getFullYear() && s.getMonth() === g.getMonth() && s.getDate() === g.getDate() ? o >= 1 ? "".concat(Math.floor(o), "小时前") : a >= 1 ? "".concat(Math.floor(a), "分钟前") : "刚刚" : c < 1 ? "昨天" : t.formatDate("yyyy-MM-dd");
    var s, g;
    return r;
}, Date.prototype.formatDate = function(t) {
    var e = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        S: this.getMilliseconds()
    };
    for (var n in /(y+)/.test(t) && (t = t.replace(RegExp.$1, "".concat(this.getFullYear()).substr(4 - RegExp.$1.length))), 
    e) new RegExp("(".concat(n, ")")).test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? e[n] : "00".concat(e[n]).substr("".concat(e[n]).length)));
    return t;
};