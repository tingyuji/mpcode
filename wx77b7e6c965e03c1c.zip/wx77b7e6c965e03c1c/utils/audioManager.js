var a, e = (0, require("../@babel/runtime/helpers/interopRequireDefault").default)(require("./get")), t = require("./time"), o = require("./tools"), r = getApp(), n = r.globalData.audioTime, i = r.globalData.countTimer, u = {
    itemId: "",
    widgetTitle: ""
};

function d(a, o) {
    var r = (0, e.default)(a, "duration") || 0, n = (0, e.default)(a, "currentTime") || 0, i = (0, 
    e.default)(o, "data.dragProgress");
    i.pauseDrag && (n = i.newCurrentTime, r = (0, e.default)(o, "data.audio.duration")), 
    r = 0 === r ? r : r + 1;
    var u = {
        currentTime: n,
        paused: (0, e.default)(a, "paused") || !1,
        buffered: (0, e.default)(a, "buffered") || 0,
        formatedCurrentTime: (0, t.formatDurationToMin)(n),
        formatedDuration: (0, t.formatDurationToMin)(r),
        progress: parseInt(100 * n / r) / 100
    };
    i.keepProgress && (u.paused = !1), (0, e.default)(o, "data.finished") && (u.progress = 0), 
    o.setData({
        audioInfo: u
    });
}

function s(a, e) {
    var t = wx.getStorageSync("krtoken"), n = wx.getStorageSync("userId");
    if (t && n) {
        var d = u;
        "noCount" === e ? (0, o.recordUnfinishedAudio)(d, a) : i = setInterval(function() {
            (0, o.recordUnfinishedAudio)(d, a);
        }, 15e3), r.globalData.countTimer = i;
    }
}

function l() {
    clearInterval(i), r.globalData.countTimer = null;
}

module.exports = {
    createAudio: function(i, f, g) {
        var c = f.id, m = f.title, p = f.cover, D = f.author, T = f.column, I = f.duration_cut, v = void 0 === I ? 0 : I, y = wx.getBackgroundAudioManager();
        y.title = m, y.epname = T, y.singer = D, y.coverImgUrl = p, y.startTime = v;
        var S = wx.getStorageSync("progressData");
        if (S) {
            c === S.audioID && S.currentTime >= 10 && (y.startTime = S.currentTime);
            var b = (0, e.default)(g, "data.dragProgress");
            b && b.pauseDrag && (y.startTime = v);
        }
        return u = {
            itemId: c,
            widgetTitle: m
        }, y.src = i, y.onCanplay(function() {
            console.log("音频可以播放"), r.globalData.countTimer || s(y), g.setData({
                loading: !1,
                playAudioShowTitle: !0
            }), function(a, e) {
                e.data.loadingTimeOutData && a.stop();
            }(y, g), clearTimeout(a);
        }), y.onPlay(function() {
            console.log("播放中...");
            var a = (0, e.default)(g, "data.audioInfo");
            console.log(a, "audioInfo"), r.globalData.countTimer || s(y), a.paused = !1, g.setData({
                loading: !1,
                playAudioShowTitle: !0,
                audioInfo: a
            });
        }), y.onPause(function() {
            console.log("音频暂停"), s(y, "noCount"), l();
            var a = (0, e.default)(y, "duration") || 0, o = (0, e.default)(y, "currentTime") || 0;
            a = 0 === a ? a : a + 1;
            var r = {
                currentTime: o,
                paused: !0,
                buffered: (0, e.default)(y, "buffered") || 0,
                formatedCurrentTime: (0, t.formatDurationToMin)(o),
                formatedDuration: (0, t.formatDurationToMin)(a),
                progress: parseInt(100 * o / a) / 100
            };
            g.setData({
                audioInfo: r
            });
        }), y.onStop(function() {
            if (console.log("音频停止"), l(), "iOS" === g.data.system) {
                var a = (0, e.default)(y, "duration") || 0, o = (0, e.default)(y, "currentTime") || 0;
                a = 0 === a ? a : a + 1;
                var r = {
                    currentTime: o,
                    paused: !0,
                    buffered: (0, e.default)(y, "buffered") || 0,
                    formatedCurrentTime: (0, t.formatDurationToMin)(o),
                    formatedDuration: (0, t.formatDurationToMin)(a),
                    progress: parseInt(100 * o / a) / 100
                };
                g.setData({
                    audioInfo: r
                });
            }
        }), y.onEnded(function() {
            console.log("音频自然播放结束"), g.setData({}, function() {
                console.log("currentTime", g.data.audioPlayer.currentTime), console.log("duration", g.data.audioPlayer.duration), 
                d(y, g), function(a) {
                    var t = (0, e.default)(a, "data.audioData.itemId"), o = a.data.list, i = a.data.audioInfo, u = 0;
                    if (i.progress = 0, i.paused = !1, i.formatedCurrentTime = "00:00", i.formatedDuration = "00:00", 
                    a.setData({
                        audioInfo: i
                    }), a.removeDragData(), t) {
                        for (var d = 0, s = o.length; d < s; d++) o[d].itemId === t && (u = d);
                        var l = u + 1, f = o[l];
                        l < o.length && f ? (a.setData({
                            playListItem: !1
                        }), a.playAudio(f), a.play(), a.playDoneState(), a.changeCD()) : (r.sensors.track("appListenEnd", {
                            $url_path: "pages/home/home",
                            page_name: n
                        }), a.setData({
                            finished: !0,
                            playListItem: !1
                        }));
                    }
                }(g);
                var a = wx.getStorageSync("progressData");
                a.playDone = 0, wx.setStorageSync("progressData", a), g.setData({
                    playListItem: !1
                });
            });
        }), y.onTimeUpdate(function() {
            console.log("音频播放进度更新", JSON.stringify(y)), d(y, g), (0, o.readedAndProgress)(g);
            var a = (0, e.default)(g, "data.dragProgress");
            a.pauseDrag && a.keepProgress && (a.pauseDrag = !1, a.keepProgress = !1, g.setData({
                dragProgress: a
            }));
        }), y.onError(function(a) {
            console.log("音频播放错误"), console.log(a.errCode), console.log(a.errMsg), l();
        }), y.onWaiting(function() {
            console.log("音频加载中");
            var e = g.data.audioInfo;
            e.formatedDuration = "00:00", g.setData({
                loading: !0,
                audioInfo: e
            }), function(e, t) {
                var o = t.data.audioInfo;
                a = setTimeout(function() {
                    o.paused = !1, t.setData({
                        loading: !1,
                        audioInfo: o,
                        loadingTimeOutData: !0
                    });
                }, 15e3);
            }(0, g);
        }), y.onNext(function() {
            console.log("onNext"), g.setData({}, function() {
                g.playNext();
            });
        }), y;
    },
    setInfo: d
};