Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/typeof"), e = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, r = /^\w*$/, n = /^\./, o = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, i = /\\(\\)?/g, a = /^\[object .+?Constructor\]$/, u = "object" == ("undefined" == typeof global ? "undefined" : t(global)) && global && global.Object === Object && global, c = "object" == ("undefined" == typeof self ? "undefined" : t(self)) && self && self.Object === Object && self, l = u || c || Function("return this")();

var s, f = Array.prototype, p = Function.prototype, _ = Object.prototype, h = l["__core-js_shared__"], d = (s = /[^.]+$/.exec(h && h.keys && h.keys.IE_PROTO || "")) ? "Symbol(src)_1." + s : "", v = p.toString, y = _.hasOwnProperty, b = _.toString, g = RegExp("^" + v.call(y).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), j = l.Symbol, O = f.splice, m = M(l, "Map"), w = M(Object, "create"), $ = j ? j.prototype : void 0, S = $ ? $.toString : void 0;

function x(t) {
    var e = -1, r = t ? t.length : 0;
    for (this.clear(); ++e < r; ) {
        var n = t[e];
        this.set(n[0], n[1]);
    }
}

function E(t) {
    var e = -1, r = t ? t.length : 0;
    for (this.clear(); ++e < r; ) {
        var n = t[e];
        this.set(n[0], n[1]);
    }
}

function F(t) {
    var e = -1, r = t ? t.length : 0;
    for (this.clear(); ++e < r; ) {
        var n = t[e];
        this.set(n[0], n[1]);
    }
}

function P(t, e) {
    for (var r, n, o = t.length; o--; ) if ((r = t[o][0]) === (n = e) || r != r && n != n) return o;
    return -1;
}

function A(n, o) {
    for (var i, a = 0, u = (o = function(n, o) {
        if (G(n)) return !1;
        var i = t(n);
        if ("number" == i || "symbol" == i || "boolean" == i || null == n || z(n)) return !0;
        return r.test(n) || !e.test(n) || null != o && n in Object(o);
    }(o, n) ? [ o ] : G(i = o) ? i : R(i)).length; null != n && a < u; ) n = n[T(o[a++])];
    return a && a == u ? n : void 0;
}

function C(t) {
    return !(!I(t) || (e = t, d && d in e)) && (function(t) {
        var e = I(t) ? b.call(t) : "";
        return "[object Function]" == e || "[object GeneratorFunction]" == e;
    }(t) || function(t) {
        var e = !1;
        if (null != t && "function" != typeof t.toString) try {
            e = !!(t + "");
        } catch (t) {}
        return e;
    }(t) ? g : a).test(function(t) {
        if (null != t) {
            try {
                return v.call(t);
            } catch (t) {}
            try {
                return t + "";
            } catch (t) {}
        }
        return "";
    }(t));
    var e;
}

function k(e, r) {
    var n, o, i = e.__data__;
    return ("string" == (o = t(n = r)) || "number" == o || "symbol" == o || "boolean" == o ? "__proto__" !== n : null === n) ? i["string" == typeof r ? "string" : "hash"] : i.map;
}

function M(t, e) {
    var r = function(t, e) {
        return null == t ? void 0 : t[e];
    }(t, e);
    return C(r) ? r : void 0;
}

x.prototype.clear = function() {
    this.__data__ = w ? w(null) : {};
}, x.prototype.delete = function(t) {
    return this.has(t) && delete this.__data__[t];
}, x.prototype.get = function(t) {
    var e = this.__data__;
    if (w) {
        var r = e[t];
        return "__lodash_hash_undefined__" === r ? void 0 : r;
    }
    return y.call(e, t) ? e[t] : void 0;
}, x.prototype.has = function(t) {
    var e = this.__data__;
    return w ? void 0 !== e[t] : y.call(e, t);
}, x.prototype.set = function(t, e) {
    return this.__data__[t] = w && void 0 === e ? "__lodash_hash_undefined__" : e, this;
}, E.prototype.clear = function() {
    this.__data__ = [];
}, E.prototype.delete = function(t) {
    var e = this.__data__, r = P(e, t);
    return !(r < 0) && (r == e.length - 1 ? e.pop() : O.call(e, r, 1), !0);
}, E.prototype.get = function(t) {
    var e = this.__data__, r = P(e, t);
    return r < 0 ? void 0 : e[r][1];
}, E.prototype.has = function(t) {
    return P(this.__data__, t) > -1;
}, E.prototype.set = function(t, e) {
    var r = this.__data__, n = P(r, t);
    return n < 0 ? r.push([ t, e ]) : r[n][1] = e, this;
}, F.prototype.clear = function() {
    this.__data__ = {
        hash: new x(),
        map: new (m || E)(),
        string: new x()
    };
}, F.prototype.delete = function(t) {
    return k(this, t).delete(t);
}, F.prototype.get = function(t) {
    return k(this, t).get(t);
}, F.prototype.has = function(t) {
    return k(this, t).has(t);
}, F.prototype.set = function(t, e) {
    return k(this, t).set(t, e), this;
};

var R = q(function(t) {
    var e;
    t = null == (e = t) ? "" : function(t) {
        if ("string" == typeof t) return t;
        if (z(t)) return S ? S.call(t) : "";
        var e = t + "";
        return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
    }(e);
    var r = [];
    return n.test(t) && r.push(""), t.replace(o, function(t, e, n, o) {
        r.push(n ? o.replace(i, "$1") : e || t);
    }), r;
});

function T(t) {
    if ("string" == typeof t || z(t)) return t;
    var e = t + "";
    return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
}

function q(t, e) {
    if ("function" != typeof t || e && "function" != typeof e) throw new TypeError("Expected a function");
    var r = function r() {
        var n = arguments, o = e ? e.apply(this, n) : n[0], i = r.cache;
        if (i.has(o)) return i.get(o);
        var a = t.apply(this, n);
        return r.cache = i.set(o, a), a;
    };
    return r.cache = new (q.Cache || F)(), r;
}

q.Cache = F;

var G = Array.isArray;

function I(e) {
    var r = t(e);
    return !!e && ("object" == r || "function" == r);
}

function z(e) {
    return "symbol" == t(e) || function(e) {
        return !!e && "object" == t(e);
    }(e) && "[object Symbol]" == b.call(e);
}

var B = function(t, e, r) {
    var n = null == t ? void 0 : A(t, e);
    return void 0 === n ? r : n;
};

exports.default = B;