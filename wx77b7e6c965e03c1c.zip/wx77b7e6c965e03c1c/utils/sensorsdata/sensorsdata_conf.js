module.exports = {
    name: "sensors",
    server_url: "https://36kr.com/global/sensors/sa?project=default",
    max_string_length: 300,
    use_client_time: !1,
    autoTrack: {
        appLaunch: !0,
        appShow: !0,
        appHide: !0,
        pageShow: !1
    }
};