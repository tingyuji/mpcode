var t = require("../../@babel/runtime/helpers/typeof"), e = {}, n = {};

n.para = require("sensorsdata_conf.js"), n._queue = [], n.getSystemInfoComplete = !1;

var r = Array.prototype, i = Function.prototype, o = Object.prototype, s = r.slice, a = o.toString, u = o.hasOwnProperty, c = {
    1001: "发现栏小程序主入口",
    1005: "顶部搜索框的搜索结果页",
    1006: "发现栏小程序主入口搜索框的搜索结果页",
    1007: "单人聊天会话中的小程序消息卡片",
    1008: "群聊会话中的小程序消息卡片",
    1011: "扫描二维码",
    1012: "长按图片识别二维码",
    1013: "手机相册选取二维码",
    1014: "小程序模版消息",
    1017: "前往体验版的入口页",
    1019: "微信钱包",
    1020: "公众号 profile 页相关小程序列表",
    1022: "聊天顶部置顶小程序入口",
    1023: "安卓系统桌面图标",
    1024: "小程序 profile 页",
    1025: "扫描一维码",
    1026: "附近小程序列表",
    1027: "顶部搜索框搜索结果页“使用过的小程序”列表",
    1028: "我的卡包",
    1029: "卡券详情页",
    1030: "自动化测试下打开小程序",
    1031: "长按图片识别一维码",
    1032: "手机相册选取一维码",
    1034: "微信支付完成页",
    1035: "公众号自定义菜单",
    1036: "App 分享消息卡片",
    1037: "小程序打开小程序",
    1038: "从另一个小程序返回",
    1039: "摇电视",
    1042: "添加好友搜索框的搜索结果页",
    1043: "公众号模板消息",
    1044: "带 shareTicket 的小程序消息卡片（详情)",
    1047: "扫描小程序码",
    1048: "长按图片识别小程序码",
    1049: "手机相册选取小程序码",
    1052: "卡券的适用门店列表",
    1053: "搜一搜的结果页",
    1054: "顶部搜索框小程序快捷入口",
    1056: "音乐播放器菜单",
    1057: "钱包中的银行卡详情页",
    1058: "公众号文章",
    1059: "体验版小程序绑定邀请页",
    1064: "微信连Wi-Fi状态栏",
    1067: "公众号文章广告",
    1068: "附近小程序列表广告",
    1071: "钱包中的银行卡列表页",
    1072: "二维码收款页面",
    1073: "客服消息列表下发的小程序消息卡片",
    1074: "公众号会话下发的小程序消息卡片",
    1078: "连Wi-Fi成功页",
    1089: "微信聊天主界面下拉",
    1090: "长按小程序右上角菜单唤出最近使用历史",
    1092: "城市服务入口"
}, p = "直接打开";

n.lib_version = "1.0";

var f = "object" === t(f) ? f : {};

function l(t, e, n) {
    if (t[e]) {
        var r = t[e];
        t[e] = function(t) {
            n.call(this, t, e), r.call(this, t);
        };
    } else t[e] = function(t) {
        n.call(this, t, e);
    };
}

function h(t) {
    this[n.para.name] = n, n.init();
    var r = {};
    t && t.path && (r.$url_path = t.path), t && e.isObject(t.query) && t.query.q && e.extend(r, e.getUtm(t.query.q)), 
    r.$scene = e.getMPScene(t.scene), n.para.autoTrack && !0 === n.para.autoTrack.appLaunch && n.autoTrackCustom("appLaunch", r, "$MPLaunch");
}

function d(t) {
    var r = {};
    t && t.path && (r.$url_path = t.path), t && e.isObject(t.query) && t.query.q && e.extend(r, e.getUtm(t.query.q)), 
    r.$scene = e.getMPScene(t.scene), n.para.autoTrack && !0 === n.para.autoTrack.appShow && n.autoTrackCustom("appShow", r, "$MPShow");
}

function g() {
    n.para.autoTrack && !0 === n.para.autoTrack.appHide && n.autoTrackCustom("appHide", {}, "$MPHide");
}

f.info = function() {
    if ("object" === ("undefined" == typeof console ? "undefined" : t(console)) && console.log) try {
        return console.log.apply(console, arguments);
    } catch (t) {
        console.log(arguments[0]);
    }
}, function() {
    i.bind;
    var t = r.forEach, n = r.indexOf, o = Array.isArray, c = {}, p = e.each = function(e, n, r) {
        if (null == e) return !1;
        if (t && e.forEach === t) e.forEach(n, r); else if (e.length === +e.length) {
            for (var i = 0, o = e.length; i < o; i++) if (i in e && n.call(r, e[i], i, e) === c) return !1;
        } else for (var s in e) if (u.call(e, s) && n.call(r, e[s], s, e) === c) return !1;
    };
    e.logger = f, e.extend = function(t) {
        return p(s.call(arguments, 1), function(e) {
            for (var n in e) void 0 !== e[n] && (t[n] = e[n]);
        }), t;
    }, e.extend2Lev = function(t) {
        return p(s.call(arguments, 1), function(n) {
            for (var r in n) void 0 !== n[r] && (e.isObject(n[r]) && e.isObject(t[r]) ? e.extend(t[r], n[r]) : t[r] = n[r]);
        }), t;
    }, e.coverExtend = function(t) {
        return p(s.call(arguments, 1), function(e) {
            for (var n in e) void 0 !== e[n] && void 0 === t[n] && (t[n] = e[n]);
        }), t;
    }, e.isArray = o || function(t) {
        return "[object Array]" === a.call(t);
    }, e.isFunction = function(t) {
        try {
            return /^\s*\bfunction\b/.test(t);
        } catch (t) {
            return !1;
        }
    }, e.isArguments = function(t) {
        return !(!t || !u.call(t, "callee"));
    }, e.toArray = function(t) {
        return t ? t.toArray ? t.toArray() : e.isArray(t) || e.isArguments(t) ? s.call(t) : e.values(t) : [];
    }, e.values = function(t) {
        var e = [];
        return null == t || p(t, function(t) {
            e[e.length] = t;
        }), e;
    }, e.include = function(t, e) {
        var r = !1;
        return null == t ? r : n && t.indexOf === n ? -1 != t.indexOf(e) : (p(t, function(t) {
            if (r || (r = t === e)) return c;
        }), r);
    };
}(), e.trim = function(t) {
    return t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
}, e.isObject = function(t) {
    return "[object Object]" == a.call(t) && null != t;
}, e.isEmptyObject = function(t) {
    if (e.isObject(t)) {
        for (var n in t) if (u.call(t, n)) return !1;
        return !0;
    }
    return !1;
}, e.isUndefined = function(t) {
    return void 0 === t;
}, e.isString = function(t) {
    return "[object String]" == a.call(t);
}, e.isDate = function(t) {
    return "[object Date]" == a.call(t);
}, e.isBoolean = function(t) {
    return "[object Boolean]" == a.call(t);
}, e.isNumber = function(t) {
    return "[object Number]" == a.call(t) && /[\d\.]+/.test(String(t));
}, e.isJSONString = function(t) {
    try {
        JSON.parse(t);
    } catch (t) {
        return !1;
    }
    return !0;
}, e.decodeURIComponent = function(t) {
    var e = "";
    try {
        e = decodeURIComponent(t);
    } catch (n) {
        e = t;
    }
    return e;
}, e.encodeDates = function(t) {
    return e.each(t, function(n, r) {
        e.isDate(n) ? t[r] = e.formatDate(n) : e.isObject(n) && (t[r] = e.encodeDates(n));
    }), t;
}, e.formatDate = function(t) {
    function e(t) {
        return t < 10 ? "0" + t : t;
    }
    return t.getFullYear() + "-" + e(t.getMonth() + 1) + "-" + e(t.getDate()) + " " + e(t.getHours()) + ":" + e(t.getMinutes()) + ":" + e(t.getSeconds()) + "." + e(t.getMilliseconds());
}, e.searchObjDate = function(t) {
    e.isObject(t) && e.each(t, function(n, r) {
        e.isObject(n) ? e.searchObjDate(t[r]) : e.isDate(n) && (t[r] = e.formatDate(n));
    });
}, e.formatString = function(t) {
    return t.length > n.para.max_string_length ? (f.info("字符串长度超过限制，已经做截取--" + t), t.slice(0, n.para.max_string_length)) : t;
}, e.searchObjString = function(t) {
    e.isObject(t) && e.each(t, function(n, r) {
        e.isObject(n) ? e.searchObjString(t[r]) : e.isString(n) && (t[r] = e.formatString(n));
    });
}, e.unique = function(t) {
    for (var e, n = [], r = {}, i = 0; i < t.length; i++) (e = t[i]) in r || (r[e] = !0, 
    n.push(e));
    return n;
}, e.strip_sa_properties = function(t) {
    return e.isObject(t) ? (e.each(t, function(n, r) {
        if (e.isArray(n)) {
            var i = [];
            e.each(n, function(t) {
                e.isString(t) ? i.push(t) : f.info("您的数据-", n, "的数组里的值必须是字符串,已经将其删除");
            }), 0 !== i.length ? t[r] = i : (delete t[r], f.info("已经删除空的数组"));
        }
        e.isString(n) || e.isNumber(n) || e.isDate(n) || e.isBoolean(n) || e.isArray(n) || (f.info("您的数据-", n, "-格式不满足要求，我们已经将其删除"), 
        delete t[r]);
    }), t) : t;
}, e.strip_empty_properties = function(t) {
    var n = {};
    return e.each(t, function(t, e) {
        null != t && (n[e] = t);
    }), n;
}, e.utf8Encode = function(t) {
    var e, n, r, i, o = "";
    for (e = n = 0, r = (t = (t + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length, 
    i = 0; i < r; i++) {
        var s = t.charCodeAt(i), a = null;
        s < 128 ? n++ : a = s > 127 && s < 2048 ? String.fromCharCode(s >> 6 | 192, 63 & s | 128) : String.fromCharCode(s >> 12 | 224, s >> 6 & 63 | 128, 63 & s | 128), 
        null !== a && (n > e && (o += t.substring(e, n)), o += a, e = n = i + 1);
    }
    return n > e && (o += t.substring(e, t.length)), o;
}, e.base64Encode = function(t) {
    var n, r, i, o, s, a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", u = 0, c = 0, p = "", f = [];
    if (!t) return t;
    t = e.utf8Encode(t);
    do {
        n = (s = t.charCodeAt(u++) << 16 | t.charCodeAt(u++) << 8 | t.charCodeAt(u++)) >> 18 & 63, 
        r = s >> 12 & 63, i = s >> 6 & 63, o = 63 & s, f[c++] = a.charAt(n) + a.charAt(r) + a.charAt(i) + a.charAt(o);
    } while (u < t.length);
    switch (p = f.join(""), t.length % 3) {
      case 1:
        p = p.slice(0, -2) + "==";
        break;

      case 2:
        p = p.slice(0, -1) + "=";
    }
    return p;
}, e.getQueryParam = function(t, n) {
    t = e.decodeURIComponent(t);
    var r = new RegExp("[\\?&]" + n + "=([^&#]*)").exec(t);
    return null === r || r && "string" != typeof r[1] && r[1].length ? "" : e.decodeURIComponent(r[1]);
}, e.getUtm = function(t) {
    var r = "utm_source utm_medium utm_campaign utm_content utm_term".split(" "), i = "utm_source utm_medium utm_campaign utm_content utm_term".split(" "), o = "", s = {};
    return 2 !== (t = (t = e.decodeURIComponent(t)).split("?")).length ? {} : (t = "?" + (t = t[1]), 
    e.isArray(n.para.source_channel) && n.para.source_channel.length > 0 && (i = i.concat(n.para.source_channel), 
    i = e.unique(i)), e.each(i, function(n) {
        (o = e.getQueryParam(t, n)).length && (e.include(r, n) ? s["$" + n] = o : s[n] = o);
    }), s);
}, e.getMPScene = function(t) {
    return t = String(t), c[t] || t;
}, e.info = {
    properties: {
        $lib: "MiniProgram",
        $lib_version: String("1.0"),
        $user_agent: "SensorsAnalytics MP SDK"
    },
    getSystem: function() {
        var t = this.properties, e = this;
        function n() {
            wx.getSystemInfo({
                success: function(e) {
                    t.$model = e.model, t.$screen_width = Number(e.windowWidth), t.$screen_height = Number(e.windowHeight), 
                    t.$os = e.system.split(" ")[0], t.$os_version = e.system.split(" ")[1];
                },
                complete: e.setStatusComplete
            });
        }
        wx.getNetworkType({
            success: function(e) {
                t.$network_type = e.networkType;
            },
            complete: n
        });
    },
    setStatusComplete: function() {
        n.getSystemInfoComplete = !0, n._queue.length > 0 && (e.each(n._queue, function(t) {
            n.prepareData.apply(n, s.call(t));
        }), n._queue = []);
    }
}, n._ = e, n.prepareData = function(r, i) {
    if (!n.getSystemInfoComplete) return n._queue.push(arguments), !1;
    var o = {
        distinct_id: this.store.getDistinctId(),
        lib: {
            $lib: "MiniProgram",
            $lib_method: "code",
            $lib_version: String("1.0")
        },
        properties: {}
    };
    e.extend(o, r), e.isObject(r.properties) && !e.isEmptyObject(r.properties) && e.extend(o.properties, r.properties), 
    r.type && "profile" === r.type.slice(0, 7) || (o.properties = e.extend({}, e.info.properties, n.store.getProps(), o.properties), 
    "object" === t(n.store._state) && "number" == typeof n.store._state.first_visit_day_time && n.store._state.first_visit_day_time > new Date().getTime() ? o.properties.$is_first_day = !0 : o.properties.$is_first_day = !1), 
    o.properties.$time && e.isDate(o.properties.$time) ? (o.time = 1 * o.properties.$time, 
    delete o.properties.$time) : n.para.use_client_time && (o.time = 1 * new Date()), 
    e.searchObjDate(o), e.searchObjString(o), n.send(o, i);
}, n.store = {
    getUUID: function() {
        return Date.now() + "-" + Math.floor(1e7 * Math.random()) + "-" + Math.random().toString(16).replace(".", "") + "-" + String(31242 * Math.random()).replace(".", "").slice(0, 8);
    },
    setStorage: function() {},
    getStorage: function() {
        return wx.getStorageSync("sensorsdata2015_wechat") || "";
    },
    _state: {},
    toState: function(t) {
        var n = null;
        e.isJSONString(t) && (n = JSON.parse(t)).distinct_id ? this._state = n : this.set("distinct_id", this.getUUID());
    },
    getFirstId: function() {
        return this._state.first_id;
    },
    getDistinctId: function() {
        return this._state.distinct_id;
    },
    getProps: function() {
        return this._state.props || {};
    },
    setProps: function(t, n) {
        var r = this._state.props || {};
        n ? this.set("props", t) : (e.extend(r, t), this.set("props", r));
    },
    set: function(e, n) {
        var r = {};
        for (var i in "string" == typeof e ? r[e] = n : "object" === t(e) && (r = e), this._state = this._state || {}, 
        r) this._state[i] = r[i];
        this.save();
    },
    change: function(t, e) {
        this._state[t] = e;
    },
    save: function() {
        wx.setStorageSync("sensorsdata2015_wechat", JSON.stringify(this._state));
    },
    init: function() {
        var t = this.getStorage();
        if (t) this.toState(t); else {
            var e = new Date(), n = e.getTime();
            e.setHours(23), e.setMinutes(59), e.setSeconds(60), this.set({
                distinct_id: this.getUUID(),
                first_visit_time: n,
                first_visit_day_time: e.getTime()
            });
        }
    }
}, n.setProfile = function(t, e) {
    n.prepareData({
        type: "profile_set",
        properties: t
    }, e);
}, n.setOnceProfile = function(t, e) {
    n.prepareData({
        type: "profile_set_once",
        properties: t
    }, e);
}, n.track = function(t, e, n) {
    this.prepareData({
        type: "track",
        event: t,
        properties: e
    }, n);
}, n.identify = function(t, e) {
    if ("number" == typeof t) t = String(t); else if ("string" != typeof t) return !1;
    var r = n.store.getFirstId();
    !0 === e ? r ? n.store.set("first_id", t) : n.store.set("distinct_id", t) : r ? n.store.change("first_id", t) : n.store.change("distinct_id", t);
}, n.trackSignup = function(t, e, r, i) {
    n.prepareData({
        original_id: n.store.getFirstId() || n.store.getDistinctId(),
        distinct_id: t,
        type: "track_signup",
        event: e,
        properties: r
    }, i), n.store.set("distinct_id", t);
}, n.register = function(t) {
    e.isObject(t) && !e.isEmptyObject(t) && n.store.setProps(t);
}, n.clearAllRegister = function() {
    n.store.setProps({}, !0);
}, n.login = function(t) {
    var e = n.store.getFirstId(), r = n.store.getDistinctId();
    t !== r && (e || n.store.set("first_id", r), n.trackSignup(t, "$SignUp"));
}, n.init = function() {
    this._.info.getSystem(), this.store.init(), e.isObject(this.para.register) && (e.info.properties = e.extend(e.info.properties, this.para.register));
}, e.autoExeQueue = function() {
    return {
        items: [],
        enqueue: function(t) {
            this.items.push(t), this.start();
        },
        dequeue: function() {
            return this.items.shift();
        },
        getCurrentItem: function() {
            return this.items[0];
        },
        isRun: !1,
        start: function() {
            this.items.length > 0 && !this.isRun && (this.isRun = !0, this.getCurrentItem().start());
        },
        close: function() {
            this.dequeue(), this.isRun = !1, this.start();
        }
    };
}, n.requestQueue = function(t) {
    this.url = t.url;
}, n.requestQueue.prototype.isEnd = function() {
    this.received || (this.received = !0, this.close());
}, n.requestQueue.prototype.start = function() {
    var t = this;
    setTimeout(function() {
        t.isEnd();
    }, 300), wx.request({
        url: this.url,
        method: "GET",
        complete: function() {
            t.isEnd();
        }
    });
}, n.dataQueue = e.autoExeQueue(), n.send = function(t) {
    var r = "";
    t._nocache = (String(Math.random()) + String(Math.random()) + String(Math.random())).slice(2, 15), 
    f.info(t), t = JSON.stringify(t), r = -1 !== n.para.server_url.indexOf("?") ? n.para.server_url + "&data=" + encodeURIComponent(e.base64Encode(t)) : n.para.server_url + "?data=" + encodeURIComponent(e.base64Encode(t));
    var i = new n.requestQueue({
        url: r
    });
    i.close = function() {
        n.dataQueue.close();
    }, n.dataQueue.enqueue(i);
}, n.autoTrackCustom = function(t, r, i) {
    var o = n.para.autoTrack[t], s = "";
    n.para.autoTrack && o && ("function" == typeof o ? (s = o(), e.isObject(s) && e.extend(r, s)) : e.isObject(o) && e.extend(r, o), 
    n.track(i, r));
};

var m = App;

App = function(t) {
    l(t, "onLaunch", h), l(t, "onShow", d), l(t, "onHide", g), m(t);
};

var _ = Page;

Page = function(r) {
    l(r, "onLoad", function(t) {
        t && e.isObject(t) && t.q && (this.sensors_mp_load_utm = e.getUtm(t.q));
    }), l(r, "onShow", function() {
        var r = "系统没有取到值";
        "object" === t(this) && ("string" == typeof this.route ? r = this.route : "string" == typeof this.__route__ && (r = this.__route__));
        var i = {};
        i.$referrer = p, i.$url_path = r, this.sensors_mp_load_utm && (e.extend(i, this.sensors_mp_load_utm), 
        this.sensors_mp_load_utm = null), n.para.onshow ? n.para.onshow(n, r, this) : n.autoTrackCustom("pageShow", i, "$MPViewScreen"), 
        p = r;
    }), _(r);
}, module.exports = n;