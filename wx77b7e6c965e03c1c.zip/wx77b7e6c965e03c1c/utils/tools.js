var e = require("../@babel/runtime/helpers/interopRequireDefault").default, t = require("../@babel/runtime/helpers/regeneratorRuntime"), a = require("../@babel/runtime/helpers/asyncToGenerator");

require("../@babel/runtime/helpers/Arrayincludes");

var r = e(require("./get")), i = e(require("./request.js")), n = getApp(), o = n.globalData.audioTime;

function s(e, t) {
    var a = {
        success: function(e) {
            console.log("上报计数");
        },
        statusError: function(e) {
            console.log(e);
        }
    }, r = {
        itemType: 0 === e ? 5 : 50,
        itemId: e,
        channel: 0
    };
    i.default.fetchMis("/sns/share", i.default.genGatewayParams(r), a);
}

function u() {
    return new Promise(function(e) {
        wx.login({
            success: function(t) {
                e(t);
            }
        });
    });
}

function d() {
    return (d = a(t().mark(function e() {
        var a;
        return t().wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, u();

              case 2:
                if (a = e.sent, "login:ok" !== (0, r.default)(a, "errMsg")) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return", new Promise(function(e) {
                    var t = {
                        success: function(t) {
                            wx.setStorageSync("wechatUserSessionObj", t), wx.setStorageSync("deviceId", t.deviceId), 
                            e("ok");
                        },
                        statusError: function(t) {
                            console.log(t), e(null);
                        }
                    }, r = {
                        appId: n.globalData.appid,
                        wechatMiniCode: a.code
                    };
                    i.default.fetchMus("/thirdparty/wechat/mini/session", i.default.genGatewayParams(r), t);
                }));

              case 5:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

module.exports = {
    checkExpiration: function() {
        var e = wx.getStorageSync("listDate").date, t = new Date().getTime();
        t - e >= 36e5 && wx.removeStorageSync("progressData"), t - e >= 1728e5 && (wx.removeStorageSync("readedList"), 
        wx.removeStorageSync("listDate"));
    },
    tapFeedback: function() {
        n.sensors.track("appAdvice", {
            $url_path: "pages/home/home",
            page_name: o
        });
    },
    readedAndProgress: function(e) {
        var t = (0, r.default)(e, "data.audioInfo.formatedCurrentTime"), a = (0, r.default)(e, "data.audioInfo.currentTime"), i = parseInt((0, 
        r.default)(e, "data.audio.duration_cut")) || 0, n = (0, r.default)(e, "data.audioData.itemId"), o = (e.data.list, 
        {
            formatedCurrentTime: t,
            audioID: n,
            currentTime: a,
            playDone: 1
        });
        if (wx.setStorage({
            key: "progressData",
            data: o
        }), a - i < 10 && (o.playDone = 0, wx.setStorage({
            key: "progressData",
            data: o
        })), a >= i + 10) {
            var s = wx.getStorageSync("readedList") || [];
            0 === s.length ? s.push(n) : s.includes(n) || s.push(n), wx.setStorage({
                key: "readedList",
                data: s
            }), wx.setStorage({
                key: "listDate",
                data: {
                    description: "记录的是已读list列表最后一项的存储时间，在经过48小时后，清空已读列表",
                    date: new Date().getTime()
                }
            });
        }
    },
    checkAudioListsUpdateStatu: function(e) {
        wx.getStorageSync("progressData");
        var t = wx.getStorageSync("readedList") || [], a = (e.data.list, (0, r.default)(e.data, "audioList[0].items")), i = (0, 
        r.default)(e.data, "audioList[1].items"), n = (0, r.default)(a, "0"), o = (0, r.default)(i, "0"), s = {
            updateListUpdated: !1,
            recommendListUpdated: !1,
            updateList: i,
            recommendList: a
        };
        return o && !t.includes(o.itemId) && (s.updateListUpdated = !0), n && !t.includes(n.itemId) && (s.recommendListUpdated = !0), 
        s;
    },
    onShareAppMessage: function(e, t) {
        var a = t.data, r = a.audioData, i = a.shareInfo, u = {};
        return "button" === e.from ? (u = {
            title: r.title || "",
            path: "/pages/home/home?id=".concat(r.itemId),
            imageUrl: r.imageUrl || ""
        }, s(r.itemId)) : (u = {
            title: i.title || "",
            path: "/pages/home/home",
            imageUrl: i.imageUrl || ""
        }, s(0)), n.sensors.track("appShare", {
            $url_path: "pages/home/home",
            page_name: o
        }), u;
    },
    getUnfinishedAudio: function() {
        var e = wx.getStorageSync("userId");
        if (e) return new Promise(function(t) {
            var a = {
                success: function(e) {
                    t(e);
                },
                statusError: function(e) {
                    console.log(e), t("");
                }
            }, r = {
                userId: e
            };
            i.default.fetchMis("/page/audio/unfinished/show", i.default.genGatewayParams(r), a);
        });
    },
    recombineList: function(e, t) {
        var a = t.filter(function(t) {
            return e.itemId !== t.itemId;
        });
        return a.unshift(e), a;
    },
    recordUnfinishedAudio: function(e, t) {
        var a = (0, r.default)(t, "duration") || 0, n = (0, r.default)(t, "currentTime") || 0, o = {
            success: function(e) {},
            statusError: function(e) {
                console.log(e);
            }
        }, s = {
            userId: wx.getStorageSync("userId"),
            audioId: e.itemId,
            audioName: e.widgetTitle,
            audioInterruptTime: n,
            audioDuration: a
        };
        i.default.fetchMis("/page/audio/unfinished/record", i.default.genGatewayParams(s), o);
    },
    getDeviceId: function() {
        return d.apply(this, arguments);
    }
};