var a = (0, require("../@babel/runtime/helpers/interopRequireDefault").default)(require("./get")), e = require("./time"), t = getApp(), r = {};

function u(e) {
    if ((0, a.default)(e, "data.finished") || (0, a.default)(e, "data.requestFail") || (0, 
    a.default)(e, "data.loading") || (0, a.default)(e, "data.loadingTimeOutData")) return !0;
}

module.exports = {
    touchstartfunc: function(e, t) {
        if (!u(t)) {
            console.log("touchstartfunc", e.detail.touches);
            var o = e.detail.touches[0].clientX;
            r = {
                dragStartX: o,
                formatNewCurrentTime: (0, a.default)(t, "data.audioInfo.formatedCurrentTime"),
                newProgress: (0, a.default)(t, "data.audioInfo.progress"),
                touch: !0
            }, t.setData({
                dragProgress: r
            });
        }
    },
    touchmovefunc: function(o, d) {
        if (clearInterval(t.globalData.countTimer), !u(d)) {
            console.log("touchmovefunc");
            var n = (0, a.default)(d, "data.dragProgress.dragStartX"), i = o.detail.touches[0].clientX - n, s = (0, 
            a.default)(d, "data.audio.duration") ? (0, a.default)(d, "data.audio.duration") : (0, 
            a.default)(d, "data.audioData.duration");
            s < 180 ? i /= 4 : s > 600 && s < 1500 ? i *= 2 : s >= 1500 && (i *= 4);
            var f = (0, a.default)(d, "data.audioInfo.currentTime") + parseInt(i);
            f > s && (f = s - 2), f < 0 && (f = 0);
            var l = parseInt(100 * f / s) / 100;
            r.newCurrentTime = f, r.newProgress = l, r.formatNewCurrentTime = (0, e.formatDurationToMin)(f), 
            d.setData({
                dragProgress: r
            });
        }
    },
    touchendfunc: function(t, o) {
        if (!u(o)) {
            (0, a.default)(o, "data.dragProgress.pauseDrag") && o.play(), console.log("touchendfunc");
            var d = wx.getBackgroundAudioManager(), n = (0, a.default)(o, "data.audioInfo"), i = d.paused, s = (0, 
            a.default)(r, "newCurrentTime");
            (0, a.default)(o, "data.audio.duration");
            if (s || 0 === s) {
                if (i || !(0, a.default)(o, "data.audioPlayer") && !i) {
                    r.pauseDrag = !0, r.pauseDragSrc = (0, a.default)(o, "data.audioData.url"), o.setData({
                        dragProgress: r
                    });
                    var f = {
                        pauseDrag: !0,
                        newCurrentTime: s
                    };
                    wx.setStorageSync("pauseDragData", f), d.stop();
                } else d.seek(s);
                n.currentTime = s, n.progress = r.newProgress, n.formatedCurrentTime = (0, e.formatDurationToMin)(s), 
                r.touch = !1, o.setData({
                    dragProgress: r,
                    audioInfo: n
                });
            } else r.touch = !1, o.setData({
                dragProgress: r
            });
        }
    }
};