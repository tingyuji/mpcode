var e = require("../@babel/runtime/helpers/interopRequireDefault").default, t = require("../@babel/runtime/helpers/objectSpread2"), r = require("../@babel/runtime/helpers/typeof"), a = e(require("../config/index")), o = function(e, t, r, a, o) {
    e = e || "GET";
    var u = Object.assign({}, r);
    "GET" === e && (u._ = Date.now(), t = t + "?" + c(u)), t = "".concat(n(o)).concat(t);
    var i = a || {};
    wx.request({
        url: t,
        data: u,
        method: e,
        header: {
            "content-type": "application/json"
        },
        success: function(e) {
            if (200 === e.statusCode) {
                var t = e.data;
                t ? 0 === parseInt(t.code, 10) ? s(i.success) && i.success(t.data || "") : (console.error(t.msg), 
                s(i.statusError) && i.statusError(t, e)) : (console.error("请求没有数据返回"), s(i.statusError) && i.statusError(t, e));
            } else console.error(e.text), s(i.statusError) && i.statusError(e);
            return s(i.complete) && i.complete(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), 
            e;
        },
        fail: function(e) {
            return console.error(e), wx.showToast({
                title: "请求失败，请稍后再试！",
                icon: "none",
                duration: 3e3
            }), s(i.statusError) && i.statusError(e), s(i.complete) && i.complete(e), wx.hideNavigationBarLoading(), 
            wx.stopPullDownRefresh(), e;
        }
    });
}, n = function(e) {
    var t = "";
    switch (e) {
      case "mis":
        t = "".concat(a.default.mis.url).concat(a.default.mis.path);
        break;

      case "mus":
        t = "".concat(a.default.mus.url).concat(a.default.mus.path);
        break;

      case "gateway":
        t = "".concat(a.default.gateway.url).concat(a.default.gateway.path);
        break;

      default:
        t = "";
    }
    return t;
}, s = function(e) {
    return "function" == typeof e;
}, c = function(e) {
    var t = "";
    if ("object" == r(e)) for (var a in e) "function" != typeof e[a] && "object" != r(e[a]) && (t += a + "=" + e[a] + "&");
    return t.replace(/&$/g, "");
};

module.exports = {
    fetchMis: function(e, t, r) {
        o("POST", e, t, r, "mis");
    },
    fetchMus: function(e, t, r) {
        o("POST", e, t, r, "mus");
    },
    fetchGateway: function(e, t, r) {
        o("POST", e, t, r, "gateway");
    },
    genGatewayParams: function(e) {
        return {
            partner_id: "stereo-wechat-mini",
            device_id: wx.getStorageSync("deviceId"),
            krtoken: wx.getStorageSync("krtoken"),
            param: t({
                siteId: 1,
                platformId: 5
            }, e)
        };
    }
};