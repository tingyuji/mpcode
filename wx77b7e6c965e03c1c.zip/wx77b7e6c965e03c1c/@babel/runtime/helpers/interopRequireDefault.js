module.exports = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}, module.exports.__esModule = !0, module.exports.default = module.exports;