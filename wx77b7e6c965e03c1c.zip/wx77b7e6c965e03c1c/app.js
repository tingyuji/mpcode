require("./utils/sensorsdata/sensorsdata.js");

App({
    onLaunch: function() {},
    globalData: {
        appid: "wx77b7e6c965e03c1c",
        audioTime: "page_15",
        pauseDragData: {},
        countTimer: null
    }
});