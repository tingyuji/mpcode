Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = "undefined" != typeof __wxConfig && __wxConfig.envVersion || "release", t = "https://gateway-test.36kr.com", a = {
    mis: {
        url: "https://gateway.36kr.com",
        path: "/api/mis"
    },
    mus: {
        url: "https://gateway.36kr.com",
        path: "/api/mus"
    },
    gateway: {
        url: t,
        path: "/api"
    }
}, p = "develop" === e ? {
    mis: {
        url: t,
        path: "/api/mis"
    },
    mus: {
        url: t,
        path: "/api/mus"
    },
    gateway: {
        url: t,
        path: "/api"
    }
} : a;

exports.default = p;