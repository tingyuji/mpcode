var e = require("../../@babel/runtime/helpers/interopRequireDefault").default;

require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), i = require("../../utils/time"), r = e(require("../../utils/get"));

getApp();

Component({
    properties: {
        list: {
            type: Array
        },
        audioList: {
            type: Array,
            observer: function(e, t, i) {
                var a = (0, r.default)(e, "0"), n = (0, r.default)(a, "items.length");
                this.setData({
                    recommendListLen: n || 0
                });
            }
        },
        audioData: {
            type: Object
        },
        showMenu: {
            type: Boolean,
            observer: function(e, t) {
                e && this.scrollTopFun();
            }
        },
        playListItem: Boolean,
        playAudioIndex: Number
    },
    data: {
        scrollTop: 0,
        list: [],
        recommendListLen: 0
    },
    ready: function() {},
    methods: {
        hideList: function() {
            this.triggerEvent("hideMenu");
        },
        _propertyListChange: function(e) {
            var r, a = e, n = t(a);
            try {
                for (n.s(); !(r = n.n()).done; ) {
                    var o = r.value;
                    o.formatDuration = (0, i.formatDurationToMin)(o.duration);
                }
            } catch (e) {
                n.e(e);
            } finally {
                n.f();
            }
            this.setData({
                list: a
            });
        },
        playItemAudio: function(e) {
            e.currentTarget.dataset.audioIndex + 1 !== this.data.playAudioIndex && this.triggerEvent("playItemAudio", e.currentTarget.dataset);
        },
        scrollTopFun: function() {
            var e, t = this, i = this.data, a = i.playAudioIndex, n = i.playListItem, o = i.audioList, l = (0, 
            r.default)(o, "0").items, s = wx.createSelectorQuery().in(this), u = a > 1 ? this.data.list[a - 2] : void 0, d = wx.getStorageInfoSync(), c = wx.getStorageSync("readedList");
            s.selectAll(".lisItem").boundingClientRect(function(i) {
                var o = (0, r.default)((0, r.default)(i, "0"), "height") || "60px";
                e = a > l.length ? 1 === a && 0 === l.length ? 0 : o * a : o * (a - 1), !n && (d.keys.includes("readedList") && u && c.includes(u.itemId) || 1 === a || a === l.length + 1) || (e = a > l.length ? o * (a + 1) : o * (a - 1) + o), 
                t.setData({
                    scrollTop: e
                });
            }).exec();
        }
    }
});