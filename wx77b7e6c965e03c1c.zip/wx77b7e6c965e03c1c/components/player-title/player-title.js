Component({
    properties: {
        playAudioShowTitle: {
            type: Boolean
        },
        audioData: {
            type: Object
        },
        finished: {
            type: Boolean
        }
    },
    data: {}
});