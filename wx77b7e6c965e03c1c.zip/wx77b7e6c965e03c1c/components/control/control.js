Component({
    properties: {
        audioInfo: {
            type: Object
        },
        isIpx: {
            type: Boolean
        },
        requestFail: {
            type: Boolean
        },
        finished: {
            type: Boolean
        },
        loading: {
            type: Boolean
        },
        loadingTimeOutData: {
            type: Boolean
        },
        collectCount: {
            type: String,
            value: "",
            observer: function(t, e, o) {
                this.setData({
                    collectCount: t
                });
            }
        },
        collectState: {
            type: Number,
            observer: function(t, e, o) {
                this.changeCommentData(t);
            }
        }
    },
    data: {
        hasCollected: !1
    },
    methods: {
        tapCollect: function() {
            var t = {
                actionType: this.data.hasCollected ? 0 : 1
            };
            this.triggerEvent("tapCollect", t);
        },
        showMenu: function() {
            this.triggerEvent("showMenu");
        },
        play: function() {
            this.triggerEvent("play");
        },
        pause: function() {
            this.triggerEvent("pause");
        },
        reload: function() {
            this.triggerEvent("reload");
        },
        reloadAudio: function() {
            this.triggerEvent("reloadAudio");
        },
        playNext: function() {
            this.triggerEvent("playNext");
        },
        changeCommentData: function(t) {
            var e = 1 === t;
            this.setData({
                hasCollected: e
            });
        }
    },
    ready: function() {
        this.setData({
            hasCollected: 1 === this.data.collectState
        });
    }
});