var e, t = require("../../@babel/runtime/helpers/interopRequireDefault").default, u = require("../../@babel/runtime/helpers/regeneratorRuntime"), i = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = t(require("../../utils/request"));

Component({
    properties: {
        unfinishedAudioInfo: {
            type: Object,
            value: {}
        }
    },
    data: {
        showModuleStatus: !0
    },
    methods: {
        hideModal: function() {
            this.setData({
                showModuleStatus: !1
            });
        },
        playAudio: (e = r(u().mark(function e() {
            var t;
            return u().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return this.setData({
                        showModuleStatus: !1
                    }), e.next = 3, this.getAudioInfo();

                  case 3:
                    t = e.sent, t = i({
                        audioInterruptTime: this.data.unfinishedAudioInfo.audioInterruptTime
                    }, t && t.audio), this.triggerEvent("parentAddAudio", {
                        unfinishedAudioInfo: t || ""
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return e.apply(this, arguments);
        }),
        getAudioInfo: function() {
            var e = this.data.unfinishedAudioInfo.audioId;
            return new Promise(function(t) {
                var u = {
                    success: function(e) {
                        t(e);
                    },
                    statusError: function(e) {
                        console.log(e), t(null);
                    }
                }, i = {
                    audioId: e,
                    userId: wx.getStorageSync("userId")
                };
                n.default.fetchMis("/page/audio/unfinished/detail", n.default.genGatewayParams(i), u);
            });
        }
    }
});