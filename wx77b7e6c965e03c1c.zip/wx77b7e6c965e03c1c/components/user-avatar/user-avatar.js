var a = require("../../@babel/runtime/helpers/defineProperty");

Component({
    properties: {
        className: {
            type: String
        },
        noAction: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        avatar: "",
        defaultAvatarImagePath: ""
    },
    attached: function() {
        this.adaptImagePath("defaultAvatarImagePath", "../../assets/images/img_user_default@2x.png", "../../assets/images-dark/img_user_default_dark@2x.png");
    },
    methods: {
        gotoUserCenter: function() {
            this.data.noAction || wx.navigateTo({
                url: "../../pages/userCenter/userCenter"
            });
        },
        adaptImagePath: function(e, t, r) {
            var s = "dark" !== wx.getSystemInfoSync().theme ? t : r;
            this.setData(a({}, e, s));
        }
    },
    ready: function() {
        this.setData({
            avatar: wx.getStorageSync("userAvatar") || ""
        });
    }
});