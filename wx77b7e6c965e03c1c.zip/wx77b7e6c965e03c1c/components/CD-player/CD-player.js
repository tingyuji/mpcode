var a = require("../../@babel/runtime/helpers/defineProperty");

Component({
    properties: {
        requestFail: Boolean,
        finished: Boolean,
        loading: Boolean,
        changeCDImg: Boolean,
        isIpx: Boolean,
        audioInfo: Object,
        audioData: {
            type: Object,
            observer: function(a, t, e) {
                "{}" !== JSON.stringify(a) && this._keepAudiocolumnName(a, t);
            }
        },
        system: String,
        list: Array
    },
    data: {
        dragDistanceStart: 0,
        dragDistance: 0,
        scrollLeft: 0,
        audioColumnName: "",
        nextColumnName: "",
        bottomImagePath: "../../assets/images/cd_player@3x.png",
        topImagePath: "../../assets/images/CD@2x.png"
    },
    attached: function() {
        this.getDarkImagePath("bottomImagePath", "../../assets/images-dark/cd_player@3x.png"), 
        this.getDarkImagePath("topImagePath", "../../assets/images-dark/cd_dark@2x.png");
    },
    methods: {
        changeCDplayerStart: function(a) {
            this.setData({
                dragDistanceStart: a.touches[0].pageX
            });
        },
        changeCDplayerMove: function(a) {
            var t = a.touches[0].pageX, e = this.data.dragDistanceStart;
            t - e < 0 && this.setData({
                scrollLeft: Math.abs(t - e)
            });
        },
        changeCDplayerEnd: function(a) {
            a.touches[0].pageX - this.data.dragDistanceStart < -40 && (this.triggerEvent("playNextAudio"), 
            this.showNextAudiocolumnName()), this.setData({
                scrollLeft: 0
            });
        },
        showNextAudiocolumnName: function() {
            var a = this.data.audioData, t = this;
            this.setData({
                nextColumnName: a.columnName
            }), setTimeout(function() {
                t.setData({
                    audioColumnName: a.columnName
                });
            }, 800);
        },
        _keepAudiocolumnName: function(a, t) {
            var e = this;
            "{}" === JSON.stringify(t) ? this.setData({
                audioColumnName: a.columnName
            }) : (this.setData({
                audioColumnName: t.columnName,
                nextColumnName: a.columnName
            }), setTimeout(function() {
                e.setData({
                    audioColumnName: a.columnName
                });
            }, 800));
        },
        getDarkImagePath: function(t, e) {
            "dark" === wx.getSystemInfoSync().theme && this.setData(a({}, t, e));
        }
    }
});