Component({
    properties: {
        dragProgress: {
            type: Object
        },
        audioInfo: {
            type: Object
        },
        finished: {
            type: Boolean
        },
        requestFail: {
            type: Boolean
        }
    },
    data: {},
    methods: {
        touchStart: function(t) {
            this.triggerEvent("touchStart", t);
        },
        touchMove: function(t) {
            this.triggerEvent("touchMove", t);
        },
        touchEnd: function(t) {
            this.triggerEvent("touchEnd", t);
        }
    }
});