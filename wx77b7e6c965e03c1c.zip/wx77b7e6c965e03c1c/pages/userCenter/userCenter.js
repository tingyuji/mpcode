var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/objectSpread2"), o = require("../../@babel/runtime/helpers/defineProperty"), i = e(require("../../utils/get")), r = require("../../utils/time"), s = require("../../utils/tools"), u = e(require("../../utils/request")), c = getApp().globalData;

Page({
    data: {
        collectList: null,
        pageCallback: "",
        showLoading: !0,
        showBindPhone: !0,
        userInfo: {},
        noCollectImagePath: ""
    },
    onLoad: function(e) {
        this.adaptImagePath("noCollectImagePath", "./images/img_collection_default@2x.png", "../../assets/images-dark/img_collection_default_dark@2x.png");
        var t = wx.getStorageSync("krtoken");
        this.setData({
            showBindPhone: !t
        }), this.getUserInfo(), this.getCollectList();
    },
    adaptImagePath: function(e, t, a) {
        var n = "dark" !== wx.getSystemInfoSync().theme ? t : a;
        this.setData(o({}, e, n));
    },
    getUserInfo: function() {
        var e = this, t = wx.getStorageSync("userId");
        if (t) {
            var a = {
                success: function(t) {
                    if (t) {
                        var a = {
                            userNick: t.userNick,
                            userFace: t.userFace
                        };
                        wx.setStorageSync("userAvatar", t.userFace), e.setData({
                            userInfo: a
                        });
                    }
                },
                statusError: function(e) {
                    console.log(e);
                }
            }, n = {
                userId: t
            };
            u.default.fetchMis("/user/info", u.default.genGatewayParams(n), a);
        }
    },
    getCollectList: function() {
        var e = this, t = this.data, a = t.pageCallback, o = t.collectList, s = {
            success: function(t) {
                var s = [];
                (0, i.default)(t, "itemList") && (0, i.default)(t, "itemList").length > 0 && (0, 
                i.default)(t, "itemList").map(function(e, t) {
                    s.push(n(n({}, e), {
                        publishTime: (0, r.timeago)((0, i.default)(e, "templateMaterial.publishTime"))
                    }));
                });
                var u = o && a ? o.concat(s) : s;
                e.setData({
                    collectList: u,
                    pageCallback: (0, i.default)(t, "hasNextPage") ? (0, i.default)(t, "pageCallback") : ""
                });
            },
            statusError: function(e) {
                console.log(e);
            },
            complete: function() {
                e.setData({
                    showLoading: !1
                });
            }
        }, c = {
            pageSize: 20,
            pageEvent: a ? 1 : 0,
            pageCallback: a,
            userId: wx.getStorageSync("userId")
        };
        u.default.fetchMis("/me/collect/audio", u.default.genGatewayParams(c), s);
    },
    getPhoneNumber: function(e) {
        var n = this;
        "getPhoneNumber:fail user deny" !== e.detail.errMsg && wx.checkSession({
            success: function() {
                n.doLoginWidthMoblie(e);
            },
            fail: function() {
                return a(t().mark(function a() {
                    return t().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, (0, s.getDeviceId)();

                          case 2:
                            n.doLoginWidthMoblie(e);

                          case 3:
                          case "end":
                            return t.stop();
                        }
                    }, a);
                }))();
            }
        });
    },
    doLoginWidthMoblie: function(e) {
        var t = this, a = wx.getStorageSync("wechatUserSessionObj"), n = {
            success: function(e) {
                e && (wx.setStorageSync("krtoken", e.krtoken), wx.setStorageSync("userId", e.userId), 
                t.onLoad());
            },
            statusError: function(e) {
                console.log(e);
            }
        }, o = {
            openid: a.openid,
            openidCheck: a.openidCheck,
            appId: c.appid,
            encryptedData: e.detail.encryptedData,
            encryptedIv: e.detail.iv
        };
        u.default.fetchMus("/login/byMiniMobile", u.default.genGatewayParams(o), n);
    },
    playAudio: function(e) {
        var t = e.currentTarget.dataset.item, a = {
            formatedCurrentTime: "00:00",
            audioID: (0, i.default)(t, "itemId"),
            currentTime: 0,
            playDone: 0
        };
        wx.setStorageSync("progressData", a), wx.setStorageSync("collectAudio", t), wx.navigateTo({
            url: "../home/home?type=collected"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.pageCallback && this.getCollectList();
    },
    onShareAppMessage: function() {}
});