var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/slicedToArray"), i = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/regeneratorRuntime"), o = require("../../@babel/runtime/helpers/asyncToGenerator"), s = t(require("../../utils/get")), u = require("../../utils/time"), n = t(require("../../utils/request")), d = require("../../utils/dragProgress"), l = require("../../utils/tools"), c = require("../../utils/audioManager"), f = getApp(), h = f.globalData.audioTime;

Page({
    data: {
        loading: !1,
        finished: !1,
        playAudioShowTitle: !1,
        audioInfo: {
            duration: 0,
            currentTime: 0,
            paused: !0,
            buffered: 0,
            progress: 0,
            formatedCurrentTime: "00:00",
            formatedDuration: "00:00"
        },
        audioPlayer: null,
        list: [],
        audioList: [],
        audio: {},
        audioData: {},
        dragProgress: {
            touch: !1
        },
        requestFail: !1,
        isIpx: !1,
        system: "",
        getListPlayState: !1,
        menuState: !1,
        playAudioIndex: 1,
        playListItem: !1,
        loadingTimeOutData: !1,
        changeCDImg: !1,
        remindOnce: !1,
        showUnfinishedModule: !1,
        pageActionType: ""
    },
    onLoad: function(t) {
        var e = this;
        return o(r().mark(function a() {
            return r().wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if ((wx.getStorageSync("isFirstOpen") || "" === wx.getStorageSync("isFirstOpen")) && (e.setData({
                        remindOnce: !0
                    }), wx.setStorageSync("isFirstOpen", !1)), f.sensors.track("appPageLoad", {
                        page_name: h
                    }), e.getSystemInfo(), e.setData({
                        pageActionType: (0, s.default)(t, "type") || ""
                    }), wx.getStorageSync("deviceId")) {
                        a.next = 8;
                        break;
                    }
                    return a.next = 8, (0, l.getDeviceId)();

                  case 8:
                    return a.next = 10, e.getAudioList(t);

                  case 10:
                    e.showUnfinishedModule();

                  case 11:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    onShow: function() {},
    onShareAppMessage: function(t) {
        return (0, l.onShareAppMessage)(t, this);
    },
    getSystemInfo: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                var a = e.model.substring(0, e.model.indexOf("X")) + "X";
                "iOS" === e.system.substring(0, 3) && t.setData({
                    system: "iOS"
                }), "iPhone X" == a && t.setData({
                    isIpx: !0
                });
            }
        });
    },
    play: function() {
        var t = this.data.audioPlayer, e = this.data.audioInfo;
        f.globalData.pauseDragData.pauseDrag ? this.playOrDragPlay() : this.data.getListPlayState ? this.playFirstOneAuido() : t && t.src ? t.play() : this.playFirstOneAuido(), 
        e.paused = !1, this.setData({
            audioInfo: e
        });
    },
    playOrDragPlay: function() {
        var t = (0, s.default)(this, "data.dragProgress"), e = f.globalData.pauseDragData, a = this.data.audio;
        a.duration_cut = t.newCurrentTime, this.playAudio(a), t.newCurrentTime = t.newCurrentTime ? t.newCurrentTime : e.newCurrentTime, 
        t.keepProgress = !0, t.pauseDrag = e.pauseDrag, this.setData({
            dragProgress: t
        });
    },
    pause: function() {
        var t = (0, s.default)(this, "data.audioData.itemId");
        this.data.audioPlayer.pause(), f.sensors.track("switch", {
            switch_type: "pause",
            $url_path: "pages/home/home",
            audio_id: t,
            page_name: h
        }), f.globalData.pauseDragData = {};
    },
    playNext: function() {
        var t = wx.getStorageSync("krtoken"), e = wx.getStorageSync("userId");
        t && e && (clearInterval(f.globalData.countTimer), f.globalData.countTimer = null);
        var a = (0, s.default)(this, "data.audioData.itemId"), i = this.data, r = i.list, o = i.audioInfo;
        i.audioData;
        if (a) {
            f.sensors.track("switch", {
                switch_type: "down",
                $url_path: "pages/home/home",
                audio_id: a,
                page_name: h
            }), o.progress = 0, o.paused = !1, o.formatedCurrentTime = "00:00", o.formatedDuration = "00:00", 
            this.setData({
                audioInfo: o
            }), this.removeDragData();
            for (var u = 0, n = 0, d = r.length; n < d; n++) r[n].itemId === a && (u = n);
            var l = r.length, c = u + 1, m = r[c];
            if (c <= l && m) this.setData({
                loading: !0,
                playListItem: !1
            }), this.playAudio(m), this.playDoneState(), this.changeCD(), this.requestInterfaceCount(m.itemId); else {
                var p = this.data.audioPlayer;
                p && p.stop(), this.setData({
                    finished: !0,
                    playListItem: !1
                });
            }
        }
    },
    requestInterfaceCount: function(t) {
        var e = this, a = {
            success: function(t) {},
            statusError: function(t) {
                e.setData({
                    requestFail: !0
                });
            }
        }, i = {
            itemType: 50,
            itemId: t
        };
        n.default.fetchMis("/sns/browse", n.default.genGatewayParams(i), a);
    },
    getAudioData: function() {
        var t = this;
        return new Promise(function(e) {
            var a = {
                success: function(a) {
                    var i = (0, s.default)(a, "recomList", []), r = (0, s.default)(a, "itemList", []), o = {
                        title: (0, s.default)(a, "miniShare.title", ""),
                        imageUrl: (0, s.default)(a, "miniShare.imageUrl", "")
                    }, u = wx.getStorageSync("collectAudio") || null;
                    "collected" === t.data.pageActionType && u && (u = t.formatCollectAudioData(i, r, u), 
                    i = (0, l.recombineList)(u, i), r = r.filter(function(t) {
                        return u.itemId !== t.itemId;
                    }));
                    var n = [ {}, {} ];
                    n[0].title = "推荐收听", n[0].items = i, n[1].title = "最近更新", n[1].items = r;
                    var d = n[0].items.concat(n[1].items);
                    t.setData({
                        list: d,
                        audioList: n,
                        shareInfo: o
                    }), e({
                        list: d,
                        audioList: n
                    });
                },
                statusError: function(e) {
                    t.setData({
                        requestFail: !0
                    }), resolve(null);
                }
            }, i = wx.getStorageSync("userId") || "";
            n.default.fetchMis("/page/audio/flow", n.default.genGatewayParams({
                userId: i
            }), a);
        });
    },
    getAudioList: function(t, e) {
        var a = this;
        return o(r().mark(function i() {
            var o, u, n;
            return r().wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return (0, l.checkExpiration)(), i.next = 3, a.getAudioData();

                  case 3:
                    if (!(o = i.sent)) {
                        i.next = 16;
                        break;
                    }
                    if (u = a.data.audioPlayer, a.setData({
                        requestFail: !1,
                        getListPlayState: !0
                    }), !(o.length <= 0)) {
                        i.next = 11;
                        break;
                    }
                    return a.setData({
                        finished: !0
                    }), u && u.stop(), i.abrupt("return");

                  case 11:
                    "tapCollect" !== e && a.regressPlayProgress(), t && t.id && a.playAudioIndex(parseInt(t.id)), 
                    a.showFirstAudioInfo((0, s.default)(a, "data.playAudioIndex")), a.playDoneState(), 
                    t && "collected" === t.type && (n = wx.getStorageSync("collectAudio") || null, a.playItemAudio({
                        detail: {
                            audioId: n.itemId,
                            audioIndex: 0
                        },
                        type: "collected"
                    }));

                  case 16:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    playFirstOneAuido: function() {
        var t = this.data.list;
        this.playAudio(t[(0, s.default)(this, "data.playAudioIndex") - 1]), this.setData({
            getListPlayState: !1
        }), this.requestInterfaceCount(t[(0, s.default)(this, "data.playAudioIndex") - 1].itemId);
    },
    showFirstAudioInfo: function(t) {
        var e = this.data.list, a = (0, s.default)(e, t - 1);
        if (a) {
            var i = wx.getStorageSync("progressData"), r = (0, l.checkAudioListsUpdateStatu)(this), o = this.data.audioInfo, n = this.data.audioData;
            n = this.formatAudioData(a), o.formatedDuration = (0, u.formatDurationToMin)((0, 
            s.default)(a, "duration")), 0 !== a.duration_cut && (o.formatedCurrentTime = (0, 
            u.formatDurationToMin)((0, s.default)(a, "duration_cut")), o.progress = parseInt(100 * (0, 
            s.default)(a, "duration_cut") / (0, s.default)(a, "duration")) / 100), !i || 1 !== i.playDone || r.updateListUpdated || r.recommendListUpdated || (o.formatedCurrentTime = i.formatedCurrentTime, 
            o.progress = parseInt(100 * i.currentTime / (0, s.default)(a, "duration")) / 100), 
            this.setData({
                audioData: n,
                audioInfo: o,
                playAudioShowTitle: !0,
                audio: a,
                hasCollect: (0, s.default)(a, "hasCollect")
            }), this.playAudioIndex((0, s.default)(a, "itemId"));
        }
    },
    playAudio: function(t) {
        var e = (0, s.default)(t, "url"), a = (0, s.default)(t, "column.cover"), i = (0, 
        s.default)(t, "widgetTitle"), r = (0, s.default)(t, "widgetImage"), o = (0, s.default)(t, "categoryTitle"), u = (0, 
        s.default)(t, "duration_cut") || 0;
        if (e) {
            this.playAudioIndex((0, s.default)(t, "itemId")), this.setData({
                audio: t,
                audioPlayer: (0, c.createAudio)(e, {
                    id: (0, s.default)(t, "itemId"),
                    title: i,
                    cover: a,
                    column: o,
                    duration_cut: u
                }, this)
            });
            var n = {
                itemId: (0, s.default)(t, "itemId"),
                title: i,
                cover: a,
                avatar: (0, s.default)(t, "editor.avatar_url"),
                columnName: o,
                url: e,
                shareTitle: i,
                imageUrl: r,
                collectNum: (0, s.default)(t, "collectNum"),
                hasCollect: (0, s.default)(t, "hasCollect")
            };
            this.setData({
                audioData: n,
                loadingTimeOutData: !1,
                hasCollect: (0, s.default)(t, "hasCollect")
            });
        }
    },
    playDoneState: function() {
        var t = this.data, e = (t.list, t.audioList), a = e[0].items, i = e[1].items;
        a = this.audioListAudioAddPlayDone(a), i = this.audioListAudioAddPlayDone(i), this.setData({
            list: a.concat(i),
            "audioList[0].items": a,
            "audioList[1].items": i
        });
    },
    audioListAudioAddPlayDone: function(t) {
        var e, a = wx.getStorageSync("readedList"), r = i(t);
        try {
            for (r.s(); !(e = r.n()).done; ) {
                var o = e.value;
                o.playDone = !1;
                var s, u = i(a);
                try {
                    for (u.s(); !(s = u.n()).done; ) {
                        var n = s.value;
                        o.itemId === n && (o.playDone = !0);
                    }
                } catch (t) {
                    u.e(t);
                } finally {
                    u.f();
                }
            }
        } catch (t) {
            r.e(t);
        } finally {
            r.f();
        }
        return t;
    },
    showMenu: function() {
        var t = (0, s.default)(this, "data.menuState");
        this.setData({
            menuState: !t
        });
    },
    playItemAudio: function(t) {
        var e = this.data.list, a = t.detail.audioId, r = e[t.detail.audioIndex], o = (0, 
        s.default)(this, "data.audioInfo");
        if (f.globalData.pauseDragData = {}, r.itemId === a) this.playAudio(r); else {
            var u, n = i(e);
            try {
                for (n.s(); !(u = n.n()).done; ) {
                    var d = u.value;
                    d.itemId === a && this.playAudio(d);
                }
            } catch (t) {
                n.e(t);
            } finally {
                n.f();
            }
        }
        o.paused = !1, this.setData({
            finished: !1,
            playListItem: !0,
            audioInfo: o
        }), this.playDoneState(), "collected" !== t.type && this.changeCD(), this.requestInterfaceCount(a);
    },
    playAudioIndex: function(t) {
        var e, r = this.data.list, o = i(r.entries());
        try {
            for (o.s(); !(e = o.n()).done; ) {
                var s = a(e.value, 2), u = s[0];
                s[1].itemId === t && this.setData({
                    playAudioIndex: u + 1
                });
            }
        } catch (t) {
            o.e(t);
        } finally {
            o.f();
        }
    },
    regressPlayProgress: function() {
        var t = this.data.list, e = (0, l.checkAudioListsUpdateStatu)(this), r = wx.getStorageSync("progressData");
        if (e.updateListUpdated && this.setData({
            playAudioIndex: e.recommendList.length + 1
        }), e.recommendListUpdated && this.setData({
            playAudioIndex: 1
        }), !e.updateListUpdated && !e.recommendListUpdated) {
            var o, s = i(t.entries());
            try {
                for (s.s(); !(o = s.n()).done; ) {
                    var u = a(o.value, 2), n = u[0], d = u[1];
                    r.audioID === d.itemId && this.setData({
                        playAudioIndex: n + 1
                    });
                }
            } catch (t) {
                s.e(t);
            } finally {
                s.f();
            }
        }
    },
    removeDragData: function() {
        var t = (0, s.default)(this, "data.dragProgress");
        f.globalData.pauseDragData = {}, t.newCurrentTime && (t = {
            touch: !1
        }, this.setData({
            dragProgress: t
        }));
    },
    tapCollect: function(t) {
        var e = this, a = this.data, i = a.audioData;
        if (!a.collectLoading) {
            this.setData({
                collectLoading: !0
            });
            var u, d = (0, s.default)(t, "detail.actionType", 0), l = {
                success: (u = o(r().mark(function t(a) {
                    return r().wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            e.getAudioList(null, "tapCollect");

                          case 1:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                })), function(t) {
                    return u.apply(this, arguments);
                }),
                statusError: function(t) {
                    console.log(t), wx.showToast({
                        title: t.msg,
                        icon: "none",
                        duration: 3e3
                    });
                },
                complete: function() {
                    e.setData({
                        collectLoading: !1
                    });
                }
            }, c = {
                collectId: i.itemId,
                type: 50,
                event: d
            };
            n.default.fetchMis("/sns/collect", n.default.genGatewayParams(c), l);
        }
    },
    tapFeedback: l.tapFeedback,
    touchStart: function(t) {
        (0, d.touchstartfunc)(t, this);
    },
    touchMove: function(t) {
        (0, d.touchmovefunc)(t, this);
    },
    touchEnd: function(t) {
        (0, d.touchendfunc)(t, this);
    },
    reload: function() {
        this.onLoad();
    },
    reloadAudio: function() {
        var t = (0, s.default)(this, "data.playAudioIndex"), e = this.data.list[t - 1];
        this.playAudio(e), this.setData({
            loadingTimeOutData: !1
        });
    },
    changeCD: function() {
        var t = this;
        this.setData({
            changeCDImg: !0
        }), setTimeout(function() {
            t.setData({
                changeCDImg: !1
            });
        }, 1e3);
    },
    closeRemindOnce: function() {
        this.setData({
            remindOnce: !1
        });
    },
    showUnfinishedModule: function() {
        var t = this;
        return o(r().mark(function e() {
            var a;
            return r().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, l.getUnfinishedAudio)();

                  case 2:
                    if (!(a = e.sent)) {
                        e.next = 8;
                        break;
                    }
                    if ((0, s.default)(t, "data.audioData.itemId") !== (0, s.default)(a, "audioId")) {
                        e.next = 7;
                        break;
                    }
                    return e.abrupt("return");

                  case 7:
                    t.setData({
                        showUnfinishedModule: !0,
                        unfinishedAudioInfo: a
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    onPlayUnfinishedAudio: function(t) {
        var e = t.detail.unfinishedAudioInfo, a = this.data, i = a.audioList, r = a.list;
        if (e) {
            var o = (0, l.recombineList)(e, r);
            i[0].items = (0, l.recombineList)(e, i[0].items);
            var n = i[1].items.filter(function(t) {
                return e.itemId !== t.itemId;
            });
            i[1].items = n;
            var d = {
                formatedCurrentTime: (0, u.formatDurationToMin)((0, s.default)(e, "audioInterruptTime")),
                audioID: (0, s.default)(e, "itemId"),
                currentTime: (0, s.default)(e, "audioInterruptTime"),
                playDone: 0
            };
            wx.setStorageSync("progressData", d), this.setData({
                list: o,
                formatAudioData: this.formatAudioData(e),
                audioList: i
            }), this.playItemAudio({
                detail: {
                    audioId: (0, s.default)(e, "itemId"),
                    audioIndex: 0
                }
            });
        }
    },
    formatAudioData: function(t) {
        var e = {};
        return e.title = (0, s.default)(t, "widgetTitle"), e.columnName = (0, s.default)(t, "categoryTitle"), 
        e.itemId = (0, s.default)(t, "itemId"), e.duration = (0, s.default)(t, "duration"), 
        e.url = (0, s.default)(t, "url"), e.shareTitle = (0, s.default)(t, "widgetTitle"), 
        e.imageUrl = (0, s.default)(t, "widgetImage"), e.collectNum = (0, s.default)(t, "collectNum"), 
        e.hasCollect = (0, s.default)(t, "hasCollect"), e;
    },
    formatCollectAudioData: function(t, a, i) {
        var r = i, o = t.find(function(t) {
            return t.itemId === i.itemId;
        }), s = a.find(function(t) {
            return t.itemId === i.itemId;
        });
        return o ? r = e(e({}, i), {
            collectNum: o.collectNum,
            hasCollect: o.hasCollect
        }) : s && (r = e(e({}, i), {
            collectNum: s.collectNum,
            hasCollect: s.hasCollect
        })), r;
    }
});