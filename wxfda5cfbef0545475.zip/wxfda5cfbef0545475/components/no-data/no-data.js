(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/no-data/no-data" ], {
    "1f81": function(n, t, e) {
        "use strict";
        var a = e("751e");
        e.n(a).a;
    },
    "751e": function(n, t, e) {},
    c3c3: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("d9c0"), o = e.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        t.default = o.a;
    },
    d117: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    d21c: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("d117"), o = e("c3c3");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        e("1f81");
        var u = e("f0c5"), r = Object(u.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = r.exports;
    },
    d9c0: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = {
            data: function() {
                return {
                    imageUrla: ""
                };
            },
            props: {
                imageUrl: {
                    type: String,
                    default: "default value"
                },
                text: {
                    type: String,
                    default: "暂无收藏"
                }
            },
            onLoad: function() {}
        };
        t.default = a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/no-data/no-data-create-component", {
    "components/no-data/no-data-create-component": function(n, t, e) {
        e("543d").createComponent(e("d21c"));
    }
}, [ [ "components/no-data/no-data-create-component" ] ] ]);