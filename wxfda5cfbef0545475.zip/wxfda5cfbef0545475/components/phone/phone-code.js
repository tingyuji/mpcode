(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/phone/phone-code" ], {
    "0140": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("41d0"), a = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = a.a;
    },
    "41d0": function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("7037");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t("963d"), i = function(e, n) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" != typeof e) return {
                    default: e
                };
                var t = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var n = new WeakMap(), t = new WeakMap();
                    return function(e) {
                        return e ? t : n;
                    }(e);
                }(n);
                if (t && t.has(e)) return t.get(e);
                var a = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                    var s = i ? Object.getOwnPropertyDescriptor(e, c) : null;
                    s && (s.get || s.set) ? Object.defineProperty(a, c, s) : a[c] = e[c];
                }
                return a.default = e, t && t.set(e, a), a;
            }(t("b253")), c = t("a195");
            t("9673");
            var s = getApp(), r = {
                name: "phone-code",
                data: function() {
                    return {
                        bindCode: "",
                        agreement: !0,
                        showPhoneBtn: !1,
                        showPhoneCode: !1,
                        phone: "",
                        code: "",
                        ref: "",
                        sendDisabled: !1,
                        sendLoading: !1,
                        logged: null
                    };
                },
                created: function() {
                    this.ref = e.getStorageSync("ref");
                },
                methods: {
                    openAgreement: function() {
                        (0, c.openWebView)(a.userAgreementUrl, "用户协议");
                    },
                    switchAgreement: function() {
                        this.setData({
                            agreement: !this.agreement
                        });
                    },
                    quertUserInfo: function(n, t, o, a) {
                        var c = this;
                        i.default.post("login/wechat-miniprogram", {
                            code: n,
                            nickname: a.userInfo.nickName,
                            avatar: a.userInfo.avatarUrl,
                            access_token: t,
                            openid: o,
                            session_key: "",
                            platform: 3
                        }).then(function(n) {
                            e.hideLoading(), c.triggerLoginSuccess(n.data);
                        }, function(n) {
                            console.log(n), 404 == n.statusCode ? (c.setData({
                                bindCode: n.data.data.bindCode
                            }), e.hideLoading(), c.setData({
                                showPhoneBtn: !0,
                                showPhoneCode: !0
                            })) : (e.hideLoading(), c.showFailModal(n));
                        });
                    },
                    sendCode: function() {
                        var n = this;
                        console.log(this.sendLoading), this.sendLoading || ("" != this.phone ? (this.setData({
                            sendLoading: !0,
                            sendDisabled: !0
                        }), i.default.post("login/code", {
                            bindCode: this.bindCode,
                            phone: this.phone
                        }).then(function() {
                            e.showToast({
                                title: "短信已发送"
                            });
                        }, function(n) {
                            console.log(n), e.showModal({
                                title: "短信发送失败",
                                content: n.message,
                                showCancel: !1
                            });
                        }).catch(function() {
                            n.sendLoading = !1, setTimeout(function() {
                                n.setData({
                                    sendDisabled: !1
                                });
                            }, 6e4);
                        })) : e.showModal({
                            content: "请输入手机号",
                            showCancel: !1
                        }));
                    },
                    phoneLogin: function() {
                        var n = this;
                        "" != this.phone && "" != this.code ? "" != this.bindCode ? (e.showLoading({
                            title: "登录中",
                            mask: !0
                        }), i.default.post("login/phone-code", {
                            phone: this.phone,
                            code: this.code,
                            bindCode: this.bindCode
                        }).then(function(e) {
                            n.triggerLoginSuccess(e.data);
                        }, function(t) {
                            e.hideLoading(), n.showFailModal(t);
                        })) : e.showModal({
                            content: "请点击获取验证码",
                            showCancel: !1
                        }) : e.showModal({
                            content: "请输入手机号和验证码",
                            showCancel: !1
                        });
                    },
                    triggerLoginSuccess: function(n) {
                        this.showPhoneCode = !1, s.globalData.trigger("login-status-changed"), (0, i.setToken)(n.token), 
                        e.hideLoading(), this.replaceActive();
                    },
                    getconversionCode: function() {
                        var n = this;
                        i.default.get("conversionCode/exists").then(function(t) {
                            if (t.data.exists) {
                                var o = n;
                                e.showModal({
                                    title: "兑换会员提醒",
                                    content: "检测到您有未激活的兑换码，请到兑换会员页面进行兑换",
                                    cancelText: "暂不兑换",
                                    confirmText: "去兑换",
                                    success: function(n) {
                                        n.confirm ? (e.hideLoading(), e.redirectTo({
                                            url: "/pages/exchange-vip/exchange-vip"
                                        })) : n.cancel && o.nvabackers();
                                    }
                                });
                            } else n.nvabackers();
                        }, function(e) {
                            n.showFailModal(e);
                        });
                    },
                    replaceActive: function() {
                        var e = this;
                        i.default.get("conversionCode/replaceActive").then(function(n) {
                            e.nvabackers();
                        }, function(n) {
                            console.log(n), e.getconversionCode();
                        });
                    },
                    showFailModal: function(n) {
                        var t = this;
                        e.hideLoading(), e.showModal({
                            title: "登录失败",
                            content: n.message || n.errMsg,
                            confirmText: "继续登录",
                            cancelText: "返回",
                            success: function(e) {
                                e.cancel && t.triggerLoginCancel();
                            }
                        });
                    },
                    triggerLoginCancel: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    s.globalData.afterLoginCancel && (s.globalData.afterLoginCancel(), s.globalData.afterLoginCancel = null);
                                }, 0), s.globalData.afterLoginSuccess && (s.globalData.afterLoginSuccess = null);
                            }
                        });
                    },
                    nvabackers: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    s.globalData.afterLoginSuccess && (s.globalData.afterLoginSuccess(), s.globalData.afterLoginSuccess = null);
                                }, 0), s.globalData.afterLoginCancel && (s.globalData.afterLoginCancel = null);
                            }
                        }), s.globalData.trigger("login-status-changed");
                    }
                }
            };
            n.default = r;
        }).call(this, t("543d").default);
    },
    "486b": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement, e._self._c, e._isMounted || (e.e0 = function(n) {
                e.showPhoneCode = !1;
            });
        }, a = [];
    },
    a660: function(e, n, t) {
        "use strict";
        var o = t("b6ca");
        t.n(o).a;
    },
    b6ca: function(e, n, t) {},
    d0df: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("486b"), a = t("0140");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        t("a660");
        var c = t("f0c5"), s = Object(c.a)(a.default, o.b, o.c, !1, null, "47c754d0", null, !1, o.a, void 0);
        n.default = s.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/phone/phone-code-create-component", {
    "components/phone/phone-code-create-component": function(e, n, t) {
        t("543d").createComponent(t("d0df"));
    }
}, [ [ "components/phone/phone-code-create-component" ] ] ]);