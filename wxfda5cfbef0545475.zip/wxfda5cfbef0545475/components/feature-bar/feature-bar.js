(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/feature-bar/feature-bar" ], {
    "1db7": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4"), i = n("7037");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = n("a195"), r = a(n("b253")), u = n("9673"), c = n("628d"), f = (function(t, e) {
                if (t && t.__esModule) return t;
                if (null === t || "object" !== i(t) && "function" != typeof t) return {
                    default: t
                };
                var n = function(t) {
                    if ("function" != typeof WeakMap) return null;
                    var e = new WeakMap(), n = new WeakMap();
                    return function(t) {
                        return t ? n : e;
                    }(t);
                }(e);
                if (n && n.has(t)) return n.get(t);
                var a = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var r in t) if ("default" !== r && Object.prototype.hasOwnProperty.call(t, r)) {
                    var u = o ? Object.getOwnPropertyDescriptor(t, r) : null;
                    u && (u.get || u.set) ? Object.defineProperty(a, r, u) : a[r] = t[r];
                }
                a.default = t, n && n.set(t, a);
            }(n("b5b5")), n("963d")), s = {
                data: function() {
                    return {
                        isFav: !1,
                        faving: !1,
                        isInit: !1
                    };
                },
                options: {
                    addGlobalClass: !0
                },
                props: {
                    formulaUrl: {
                        type: String,
                        default: ""
                    },
                    feature: {
                        type: Object,
                        default: null
                    }
                },
                watch: {
                    feature: {
                        handler: function() {
                            this.init();
                        },
                        immediate: !0,
                        deep: !0
                    }
                },
                beforeMount: function() {
                    this.init();
                },
                methods: {
                    init: function() {
                        var t = this;
                        this.isInit || null != this.feature && ((0, u.getUser)().then(function() {
                            r.default.get("favorites/" + t.feature.type + "/" + t.feature.id).then(function(e) {
                                e.data && t.setData({
                                    isFav: !0
                                });
                            }, function() {});
                        }, function() {}), this.isInit = !0);
                    },
                    goFx: function() {
                        var e = this;
                        (0, u.loginRequired)().then(function() {
                            (0, u.getUser)().then(function(n) {
                                1 == n.vip_state ? (0, o.openWebView)(e.formulaUrl) : t.navigateTo({
                                    url: "/pages/vip/vip"
                                });
                            }, function() {});
                        }, function() {});
                    },
                    fav: function() {
                        var e = this;
                        (0, u.loginRequired)().then(function() {
                            e.setData({
                                faving: !0
                            });
                            var n = e.feature;
                            (0, c.addFav)(n.type, n.id).then(function() {
                                e.setData({
                                    faving: !1,
                                    isFav: !0
                                }), t.showToast({
                                    title: "已收藏成功",
                                    icon: "none"
                                });
                            }, function(n) {
                                e.setData({
                                    faving: !1
                                }), t.showToast({
                                    title: n.message,
                                    icon: "none"
                                });
                            });
                        }, function() {
                            t.showToast({
                                title: "需要登录才能进行收藏",
                                icon: "none"
                            });
                        });
                    },
                    cancelFav: function() {
                        var e = this;
                        this.setData({
                            faving: !0
                        });
                        var n = this.feature;
                        (0, c.cancelFav)(n.type, n.id).then(function() {
                            e.setData({
                                faving: !1,
                                isFav: !1
                            }), t.showToast({
                                title: "已取消收藏",
                                icon: "none"
                            });
                        }, function(n) {
                            e.setData({
                                faving: !1
                            }), t.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    },
                    shareApp: function() {
                        t.share({
                            provider: "weixin",
                            scene: "WXSceneSession",
                            type: 5,
                            imageUrl: f.BaseUrl + "electrician-master/images/logo.png",
                            title: "电工大师",
                            miniProgram: {
                                id: "gh_4230d5981364",
                                path: this.$mp.page.route,
                                type: 0,
                                webUrl: "http://uniapp.dcloud.io"
                            },
                            success: function(t) {
                                console.log(JSON.stringify(t));
                            },
                            fail: function(t) {
                                console.log(JSON.stringify(t));
                            }
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, n("543d").default);
    },
    "7eec": function(t, e, n) {},
    8651: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("1db7"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    },
    "8c0f": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    d94c: function(t, e, n) {
        "use strict";
        var a = n("7eec");
        n.n(a).a;
    },
    e526: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("8c0f"), i = n("8651");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("d94c");
        var r = n("f0c5"), u = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = u.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/feature-bar/feature-bar-create-component", {
    "components/feature-bar/feature-bar-create-component": function(t, e, n) {
        n("543d").createComponent(n("e526"));
    }
}, [ [ "components/feature-bar/feature-bar-create-component" ] ] ]);