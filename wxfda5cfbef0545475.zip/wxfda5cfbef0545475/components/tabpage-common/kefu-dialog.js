(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/tabpage-common/kefu-dialog" ], {
    "0d06": function(e, t, o) {},
    "1d91": function(e, t, o) {
        "use strict";
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return a;
        }), o.d(t, "a", function() {});
        var n = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    3281: function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("7305"), a = o.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = a.a;
    },
    "4e90": function(e, t, o) {
        "use strict";
        var n = o("0d06");
        o.n(n).a;
    },
    7305: function(e, t, o) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = o("963d"), a = getApp(), i = a.globalData, u = {
                data: function() {
                    return {
                        showModal: !1,
                        keep: !0,
                        BaseUrl: n.BaseUrl
                    };
                },
                options: {
                    styleIsolation: "apply-shared"
                },
                methods: {
                    close: function() {
                        this.hide(), this.keep && e.setStorage({
                            key: "hide_kefu_dialog",
                            data: 1
                        });
                    },
                    hide: function() {
                        this.showModal && (this.setData({
                            showModal: !1
                        }), i.kefuDialogClosed = !0);
                    },
                    checkChange: function(e) {
                        this.keep = "1" == e.detail.value[0];
                    },
                    initdata: function() {
                        var t = this;
                        i.kefuDialogClosed ? this.hide() : i.kefuDialogLogged || a.globalData.getUser().then(function() {
                            !1 === i.kefuDialogLogged && (e.getStorage({
                                key: "hide_kefu_dialog",
                                success: function() {
                                    t.hide();
                                },
                                fail: function() {
                                    t.setData({
                                        showModal: !0
                                    });
                                }
                            }), i.kefuDialogLogged = !0);
                        }, function() {
                            i.kefuDialogLogged = !1;
                        });
                    }
                },
                onPageShow: function() {
                    this.initdata();
                }
            };
            t.default = u;
        }).call(this, o("543d").default);
    },
    a9df: function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("1d91"), a = o("3281");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(t, e, function() {
                return a[e];
            });
        }(i);
        o("4e90");
        var u = o("f0c5"), c = Object(u.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = c.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/tabpage-common/kefu-dialog-create-component", {
    "components/tabpage-common/kefu-dialog-create-component": function(e, t, o) {
        o("543d").createComponent(o("a9df"));
    }
}, [ [ "components/tabpage-common/kefu-dialog-create-component" ] ] ]);