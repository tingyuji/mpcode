(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/nav-item/nav-item" ], {
    "231d": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("7958"), o = e("df6d");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("bacc");
        var c = e("f0c5"), u = Object(c.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        n.default = u.exports;
    },
    7958: function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return i;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var i = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    "9c5e": function(t, n, e) {},
    bacc: function(t, n, e) {
        "use strict";
        var i = e("9c5e");
        e.n(i).a;
    },
    df6d: function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("fd8e"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        n.default = o.a;
    },
    fd8e: function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = e("9673"), o = getApp(), a = {
                data: function() {
                    return {
                        isVip: !0,
                        clone_check: null,
                        iconType: 0
                    };
                },
                options: {
                    styleIsolation: "apply-shared",
                    pureDataPattern: /^_/
                },
                props: {
                    icon: {
                        type: String,
                        default: ""
                    },
                    url: String,
                    name: String,
                    requirement: {
                        type: Number,
                        default: 0
                    },
                    customTap: {
                        type: Boolean,
                        default: !1
                    }
                },
                watch: {
                    icon: {
                        handler: function(t) {
                            var n;
                            n = "" == t ? 0 : t.includes("/") ? 2 : 1, this.setData({
                                iconType: n
                            });
                        },
                        immediate: !0,
                        deep: !0
                    }
                },
                beforeMount: function() {
                    this._check = function(t) {
                        var n = !(!t || 1 != t.vip_state);
                        n != this.isVip && this.setData({
                            isVip: n
                        });
                    }.bind(this), o.globalData.on("user-info-updated", this._check), (0, i.getUser)().then(this._check, this._check);
                },
                destroyed: function() {
                    null != this._check && o.globalData.off("user-info-updated", this._check);
                },
                methods: {
                    open: function() {
                        var t = this;
                        this.customTap || (this.requirement > 0 ? (0, i.loginRequired)().then(function() {
                            return t.go();
                        }, function() {}) : this.go());
                    },
                    go: function() {
                        t.navigateTo({
                            url: this.url
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, e("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/nav-item/nav-item-create-component", {
    "components/nav-item/nav-item-create-component": function(t, n, e) {
        e("543d").createComponent(e("231d"));
    }
}, [ [ "components/nav-item/nav-item-create-component" ] ] ]);