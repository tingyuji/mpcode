(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "29b3": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("7037");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(e, t) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" != typeof e) return {
                    default: e
                };
                var n = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var t = new WeakMap(), n = new WeakMap();
                    return function(e) {
                        return e ? n : t;
                    }(e);
                }(t);
                if (n && n.has(e)) return n.get(e);
                var o = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
                    var u = a ? Object.getOwnPropertyDescriptor(e, i) : null;
                    u && (u.get || u.set) ? Object.defineProperty(o, i, u) : o[i] = e[i];
                }
                return o.default = e, n && n.set(e, o), o;
            }(n("b253")), a = {
                data: function() {
                    return {};
                },
                globalData: {
                    userInfo: null,
                    afterLoginSuccess: null,
                    afterLoginCancel: null,
                    onUnhandledRejection: function(e) {
                        console.error(e);
                    },
                    state: {
                        getUserPending: !1,
                        getUserQueue: []
                    },
                    getUser: function() {
                        var e = this;
                        return new Promise(function(t, n) {
                            if (null == e.userInfo) if ((0, o.hasToken)()) {
                                var r = e.state.getUserQueue;
                                r.push([ t, n ]), e.state.getUserPending || (e.state.getUserPending = !0, o.default.get("user").then(function(t) {
                                    for (e.userInfo = t.data; r.length > 0; ) r.pop()[0](t.data);
                                }, function(e) {
                                    for (;r.length > 0; ) r.pop()[1](e);
                                }).finally(function() {
                                    e.state.getUserPending = !1;
                                }));
                            } else n(); else t(e.userInfo);
                        });
                    },
                    updateUser: function() {
                        var e = getApp().globalData;
                        e.userInfo = null, e.getUser().then(function(t) {
                            e.userInfo = t, e.trigger("user-info-updated", t);
                        }, function() {
                            e.trigger("user-info-updated", null);
                        });
                    },
                    events: {},
                    on: function(e, t, n, r) {
                        var o = this.events;
                        if (o[e] || (o[e] = []), n) for (var a, i = 0; a = o[e][i]; i++) if (a.uniqid == n) return void Object.assign(o[e][i], {
                            callback: t,
                            once: !!r
                        });
                        o[e].push({
                            callback: t,
                            uniqid: n,
                            once: !!r
                        });
                    },
                    off: function(e, t) {
                        var n = this.events;
                        if (n[e]) if (null == t) delete n[e]; else {
                            for (var r, o = 0; r = n[e][o]; o++) if (r.callback === t) n[e].splice(o--, 1); else if ("string" == typeof t && r.uniqid == t) {
                                n[e].splice(o--, 1);
                                break;
                            }
                            0 == n[e].length && delete n[e];
                        }
                    },
                    trigger: function(e, t) {
                        var n = this.events;
                        if (n[e]) {
                            for (var r, o = 0; r = n[e][o]; o++) r.once && n[e].splice(o--, 1), r.callback(t);
                            0 == n[e].length && delete n[e];
                        }
                        console.log("event triggered: " + e, t);
                    }
                },
                onShow: function() {},
                onLaunch: function() {
                    this.globalData.getUser().then(function() {}, function(e) {
                        e && console.error("Get user error: " + e.message);
                    }), this.globalData.on("login-status-changed", this.globalData.updateUser), this.globalData.on("vip-updated", this.globalData.updateUser), 
                    "android" !== e.getSystemInfoSync().platform && "ios" !== e.getSystemInfoSync().platform || plus.screen.lockOrientation("portrait-primary");
                }
            };
            t.default = a, Promise.prototype.finally || (Promise.prototype.finally = function(e) {
                var t = this.constructor;
                return this.then(function(n) {
                    return t.resolve(e()).then(function() {
                        return n;
                    });
                }, function(n) {
                    return t.resolve(e()).then(function() {
                        throw n;
                    });
                });
            }), Promise.prototype.silent || (Promise.prototype.silent = function() {
                this.then(function() {}, function() {});
            });
        }).call(this, n("543d").default);
    },
    "516d": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("fa14");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("e4ac");
        var a = n("f0c5"), i = Object(a.a)(r.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = i.exports;
    },
    afba: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4"), o = r(n("9523"));
            n("8a42");
            var a = r(n("516d")), i = r(n("8e0e")), u = r(n("fdd9")), f = r(n("1df1")), c = r(n("66fd"));
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            e.__webpack_require_UNI_MP_PLUGIN__ = n, u.default.init(), c.default.mixin(f.default), 
            c.default.config.productionTip = !1, c.default.prototype.$store = i.default, a.default.mpType = "app";
            var s = new c.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        (0, o.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, a.default));
            t(s).$mount();
        }).call(this, n("bc2e").default, n("543d").createApp);
    },
    b4ac: function(e, t, n) {},
    e4ac: function(e, t, n) {
        "use strict";
        var r = n("b4ac");
        n.n(r).a;
    },
    fa14: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("29b3"), o = n.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = o.a;
    }
}, [ [ "afba", "common/runtime", "common/vendor" ] ] ]);