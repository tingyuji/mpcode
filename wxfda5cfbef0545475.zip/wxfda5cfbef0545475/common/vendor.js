(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/vendor" ], {
    "00cd": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Unit = void 0, t.format = c, t.formatDouble = s, t.formatFromUnits = function(e, t, n) {
            var r = function(e) {
                var t = [];
                for (var n in e) e.hasOwnProperty(n) && t.push(e[n]);
                return t.sort(function(e, t) {
                    return t.mul - e.mul;
                }), t;
            }(n);
            1 != t.mul && (e *= t.mul);
            for (var i, o = 0; i = r[o]; o++) if (e >= i.mul) return c(e / i.mul, i);
            var a = r[r.length - 1];
            return c(e / a.mul, a);
        }, t.formatLength = function(e, t) {
            var n = parseInt(e), r = t - n.toString().length;
            return r > 0 ? s(e, r) : n;
        }, t.unitConvert = u, t.unitFormatTo = function(e, t, n) {
            return c(e = u(e, t, n), n);
        };
        var i = r(n("5bc3")), o = r(n("970b")), a = (0, i.default)(function e(t, n, r) {
            (0, o.default)(this, e), this.name = t, n = n || 1, r = r || 1, this.mul = 1 == n || 1 == r ? n : Math.pow(n, r);
        });
        function c(e, t) {
            return s(e, 3) + " " + t.name;
        }
        function s(e, t) {
            var n = e.toFixed(t).split(".");
            return n[1] = n[1].replace(/0+$/, ""), n[1] ? n.join(".") : n[0];
        }
        function u(e, t, n) {
            return t.mul != n.mul ? e * (t.mul / n.mul) : e;
        }
        t.Unit = a;
    },
    "028b": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Materials = void 0;
        var i = r(n("5bc3")), o = r(n("970b")), a = (0, i.default)(function e(t, n, r, i) {
            (0, o.default)(this, e), this.name = t, this.label = n, this.resistivity = r, this.temperature = i;
        }), c = {
            COPPER: new a("铜", "copper", .0176, .00393),
            ALUMINUM: new a("铝", "aluminum", .0282, .00403),
            SILVER: new a("银", "silver", .0159, .0038),
            GOLD: new a("金", "gold", .0244, .0038),
            TUNGSTEN: new a("钨", "tungsten", .056, .0045),
            BRASS: new a("黄铜（铜锌合金）", "brass", .07, .002),
            COSTANTANA: new a("康斯坦镍铜合金", "costantana", .49, 3e-4),
            FERRUM: new a("铁", "ferrum", .1, .0045),
            PLATINUM: new a("铂", "platinum", .11, .0039),
            LEAD: new a("铅", "lead", .206, .0039),
            NICKEL: new a("镍", "nickel", .43, 23e-5),
            NICHROME: new a("镍铬合金", "nichrome", 1.5, 25e-5),
            MAGNESIUM: new a("镁", "magnesium", .043, .0041),
            MERCURY: new a("汞", "mercury", .941, 92e-5),
            ZINC: new a("锌", "zinc", .06, 42e-5),
            SILICON: new a("硅", "silicon", 640, -.075)
        };
        t.Materials = c;
    },
    "035c": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("9523")), o = r(n("b253")), a = n("e308"), c = n("9673"), s = n("628d"), u = {
                data: function() {
                    return {
                        feature: null,
                        vipRequired: !1
                    };
                },
                onShow: function() {
                    null != this.feature && this.checkRequirement();
                },
                onShareAppMessage: function() {
                    return {};
                },
                destroyed: function() {
                    var e = this.feature, t = (0, a.getFeatureConfig)(e.key, e.ori_type);
                    (0, s.setRecentUsed)("feature_" + e.type + "_" + e.id, t.icon, t.name, "/pages/" + t.page, e.requirement);
                },
                methods: {
                    initFeature: function(t, n) {
                        var r = this;
                        (0, a.getFeature)(n).then(function(e) {
                            var n = e[t];
                            n && (n.ori_type = n.type, n.type = s.FavType.Calculator, r.setData({
                                feature: n
                            }), r.checkRequirement(), o.default.get("features/" + n.id).silent());
                        }, function(t) {
                            e.showModal({
                                title: "加载计算器失败"
                            });
                        });
                    },
                    checkRequirement: function() {
                        var e = this, t = this.feature.requirement;
                        t > 0 && (0, c.getUser)().then(function(n) {
                            2 == t && 0 == n.vip_state && e.setData({
                                vipRequired: !0
                            });
                        }, function() {
                            (0, c.loginRequired)().silent();
                        });
                    },
                    use: function() {
                        var e;
                        null != this && null !== (e = this.feature) && void 0 !== e && e.id && o.default.put("features/" + this.feature.id).silent();
                    },
                    checkNaN: function() {
                        for (var t = !1, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                        return r.forEach(function(e) {
                            ("" === e || null === e || isNaN(e)) && (t = !0);
                        }), t && e.showModal({
                            content: "输入值不正确。",
                            showCancel: !1
                        }), t;
                    },
                    inputNumber: function(e) {
                        var t = e.detail.value;
                        t = isNaN(t) || "" === t || "." == t.substring(0, 1) || "." == t.slice(-1) ? t : parseFloat(t), 
                        this.setData((0, i.default)({}, e.currentTarget.dataset.name, t));
                    },
                    change: function(e) {
                        this.setData((0, i.default)({}, e.currentTarget.dataset.name, e.detail.value));
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    "0676": function(e, t) {
        e.exports = function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "0bfc": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("9a2b"), i = n("9bc7"), o = n("028b"), a = n("9912"), c = n("00cd"), s = {
            data: function() {
                return {
                    cableCoreAreaUnits: [ {
                        option: i.ElectricalSpecifications.IEC,
                        label: "mm²"
                    }, {
                        option: i.ElectricalSpecifications.NEC,
                        label: "awg"
                    } ],
                    cableCoreAreaUnitIndex: 0,
                    cableCoreAreValueOptions: r.cableCoreAreaConfig[i.ElectricalSpecifications.IEC].units,
                    cableCoreAreValueOptionIndex: 0,
                    conductorOptions: [ 1, 2, 3, 4, 5, 6, 7, 8 ],
                    conductorOptionIndex: 0,
                    cableLineUnits: [ a.MeasuringUnits.m, a.MeasuringUnits.ft, a.MeasuringUnits.yd ],
                    cableLineUnitIndex: 0,
                    cableLineUnitValue: void 0,
                    materialOptions: [ o.Materials.COPPER, o.Materials.ALUMINUM ],
                    materialOptionIndex: 0,
                    cableCoreType: [ {
                        option: r.CableCoreType.SINGLE_CORE,
                        label: "单芯"
                    }, {
                        option: r.CableCoreType.MULTI_CORE,
                        label: "多芯"
                    } ],
                    cableCoreTypeIndex: 0
                };
            },
            methods: {
                changeCableCoreAreaUnit: function(e, t) {
                    var n = parseInt(e.detail.value);
                    n ? this.setData({
                        cableCoreAreaUnitIndex: n,
                        cableCoreAreValueOptionIndex: 0,
                        cableCoreAreValueOptions: r.cableCoreAreaConfig[i.ElectricalSpecifications.NEC].units
                    }) : this.setData({
                        cableCoreAreaUnitIndex: n,
                        cableCoreAreValueOptionIndex: 0,
                        cableCoreAreValueOptions: r.cableCoreAreaConfig[i.ElectricalSpecifications.IEC].units
                    }), "function" == typeof t && t(n);
                },
                getCableCoreAreValue: function() {
                    return this.cableCoreAreValueOptions[this.cableCoreAreValueOptionIndex];
                },
                getCableLineUnitValue: function() {
                    return (0, c.unitConvert)(this.cableLineUnitValue, this.cableLineUnits[this.cableLineUnitIndex], a.MeasuringUnits.m);
                },
                getCableCoreAreaCollection: function(e, t, n) {
                    var i = this.cableCoreAreaUnits[this.cableCoreAreaUnitIndex].option, o = this.cableCoreAreValueOptionIndex, a = this.materialOptions[this.materialOptionIndex].label, c = this.conductorOptions[this.conductorOptionIndex], s = this.cableCoreType[this.cableCoreTypeIndex].option, u = (0, 
                    r.calculateReactance)(i, o, s, e, c), l = (0, r.calculateResistance)(i, o, a, e, c, t, n);
                    return {
                        currentType: n,
                        cableCoreAreaUnit: i,
                        cableCoreAreaIndex: o,
                        cableCoreType: s,
                        conductor: c,
                        material: a,
                        temperature: t,
                        length: e,
                        resistance: l,
                        reactance: u,
                        impedance: (0, r.calculateImpedance)(u, l)
                    };
                }
            }
        };
        t.default = s;
    },
    "0db1": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.VoltageUnits = t.InputTerminal = void 0, t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case s.CURRENT_POWER:
                t = function(e, t, n, r, c) {
                    var s = 0;
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    switch (u(c), e) {
                      case a.CurrentType.DIRECT_CURRENT:
                        s = n / t;
                        break;

                      case a.CurrentType.SINGLE_PHASE_CURRENT:
                      case a.CurrentType.TWO_PHASE_CURRENT:
                        if (90 === c[o.TrigonometricType.DEG]) return c[o.TrigonometricType.TAN] * n / t;
                        s = "P" === r ? n / (t * c[o.TrigonometricType.COS]) : "S" === r ? n / t : n / (t * c[o.TrigonometricType.SIN]);
                        break;

                      case a.CurrentType.THREE_PHASE_CURRENT:
                        if (90 === c[o.TrigonometricType.DEG]) return c[o.TrigonometricType.TAN] * n / (Math.sqrt(3) * t);
                        s = "P" === r ? n / (Math.sqrt(3) * t * c[o.TrigonometricType.COS]) : "S" === r ? n / (Math.sqrt(3) * t) : n / (Math.sqrt(3) * t * c[o.TrigonometricType.SIN]);
                    }
                    return s;
                }(e.currentType, e.currentValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case s.CURRENT_IMPEDANCE:
                t = function(e, t, n) {
                    var r = 0;
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (e) {
                      case a.CurrentType.SINGLE_PHASE_CURRENT:
                      case a.CurrentType.TWO_PHASE_CURRENT:
                      case a.CurrentType.THREE_PHASE_CURRENT:
                        r = t * n;
                    }
                    return r;
                }(e.currentType, e.currentValue, e.impedanceValue);
                break;

              case s.CURRENT_RESISTANCE:
                t = function(e, t, n, r) {
                    var c = 0;
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    switch (u(r), e) {
                      case a.CurrentType.DIRECT_CURRENT:
                        c = t * n;
                        break;

                      case a.CurrentType.SINGLE_PHASE_CURRENT:
                      case a.CurrentType.TWO_PHASE_CURRENT:
                      case a.CurrentType.THREE_PHASE_CURRENT:
                        if (90 === r[o.TrigonometricType.DEG]) return r[o.TrigonometricType.TAN] * t * n;
                        c = t * n / r[o.TrigonometricType.COS];
                    }
                    return c;
                }(e.currentType, e.currentValue, e.resistanceValue, e.triangleCollection);
                break;

              case s.POWER_IMPEDANCE:
                t = function(e, t, n, r, c) {
                    var s = 0;
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("阻抗数值无效");
                    switch (u(c), e) {
                      case a.CurrentType.SINGLE_PHASE_CURRENT:
                      case a.CurrentType.TWO_PHASE_CURRENT:
                        if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t);
                        s = "P" === r ? Math.sqrt(n * t / c[o.TrigonometricType.COS]) : "S" === r ? Math.sqrt(n * t) : Math.sqrt(n * t / c[o.TrigonometricType.SIN]);
                        break;

                      case a.CurrentType.THREE_PHASE_CURRENT:
                        if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t / Math.sqrt(3));
                        s = "P" === r ? Math.sqrt(n * t / (Math.sqrt(3) * c[o.TrigonometricType.COS])) : "S" === r ? Math.sqrt(n * t / Math.sqrt(3)) : Math.sqrt(n * t / (Math.sqrt(3) * c[o.TrigonometricType.SIN]));
                    }
                    return s;
                }(e.currentType, e.impedanceValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case s.POWER_RESISTANCE:
                t = function(e, t, n, r, c) {
                    var s = 0;
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电阻数值无效");
                    if (u(c), 0 === c[o.TrigonometricType.TAN]) throw new Error("∞");
                    switch (e) {
                      case a.CurrentType.DIRECT_CURRENT:
                        s = Math.sqrt(n * t);
                        break;

                      case a.CurrentType.SINGLE_PHASE_CURRENT:
                      case a.CurrentType.TWO_PHASE_CURRENT:
                        if ("P" === r) {
                            if (90 === c[o.TrigonometricType.DEG]) return c[o.TrigonometricType.TAN] * Math.sqrt(n * t);
                            s = Math.sqrt(n * t) / c[o.TrigonometricType.COS];
                        } else if ("S" === r) {
                            if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t);
                            s = Math.sqrt(n * t / c[o.TrigonometricType.COS]);
                        } else {
                            if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t);
                            s = Math.sqrt(n * t / (c[o.TrigonometricType.SIN] * c[o.TrigonometricType.COS]));
                        }
                        break;

                      case a.CurrentType.THREE_PHASE_CURRENT:
                        if ("P" === r) {
                            if (90 === c[o.TrigonometricType.DEG]) return c[o.TrigonometricType.TAN] * Math.sqrt(n * t / Math.sqrt(3));
                            s = Math.sqrt(n * t / (Math.sqrt(3) * Math.pow(c[o.TrigonometricType.COS], 2)));
                        } else if ("S" === r) {
                            if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t / Math.sqrt(3));
                            s = Math.sqrt(n * t / (Math.sqrt(3) * c[o.TrigonometricType.COS]));
                        } else {
                            if (90 === c[o.TrigonometricType.DEG]) return Math.sqrt(c[o.TrigonometricType.TAN] * n * t / Math.sqrt(3));
                            s = Math.sqrt(n * t / (Math.sqrt(3) * c[o.TrigonometricType.SIN] * c[o.TrigonometricType.COS]));
                        }
                    }
                    return s;
                }(e.currentType, e.resistanceValue, e.powerValue, e.powerType, e.triangleCollection);
            }
            return t;
        };
        var r = n("00cd"), i = n("d417"), o = n("2e64"), a = n("d055"), c = {
            mV: new r.Unit("mV", .001),
            V: new r.Unit("V"),
            kV: new r.Unit("kV", 1e3)
        };
        t.VoltageUnits = c;
        var s = {
            CURRENT_POWER: "current_power",
            CURRENT_IMPEDANCE: "current_impedance",
            CURRENT_RESISTANCE: "current_resistance",
            POWER_IMPEDANCE: "power_impedance",
            POWER_RESISTANCE: "power_resistance"
        };
        function u(e) {
            if (e.type === o.TrigonometricType.COS && 0 === e[o.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
        t.InputTerminal = s;
    },
    "109e": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("035c")), o = n("00cd"), a = {
            data: function() {
                return {
                    units: [],
                    inputSeriesValue: "",
                    inputSeriesUnit: 0,
                    inputSeriesList: [],
                    outputSeriesUnit: 0,
                    outputSeriesResult: 0,
                    inputParallelValue: "",
                    inputParallelUnit: 0,
                    inputParallelList: [],
                    outputParallelUnit: 0,
                    outputParallelResult: 0
                };
            },
            mixins: [ i.default ],
            seriesUsed: !1,
            parallelUsed: !1,
            methods: {
                setDefaultUnit: function(e) {
                    this.setData({
                        inputSeriesUnit: e,
                        outputSeriesUnit: e,
                        inputParallelUnit: e,
                        outputParallelUnit: e
                    });
                },
                inputSeriesUnitChange: function(e) {
                    this.setData({
                        inputSeriesUnit: e.detail.value
                    });
                },
                outputSeriesUnitChange: function(e) {
                    this.setData({
                        outputSeriesUnit: e.detail.value
                    }), this.calculateSeries();
                },
                inputParallelUnitChange: function(e) {
                    this.setData({
                        inputParallelUnit: e.detail.value
                    });
                },
                outputParallelUnitChange: function(e) {
                    this.setData({
                        outputParallelUnit: e.detail.value
                    }), this.calculateParallel();
                },
                addSeries: function() {
                    var e = this.inputSeriesValue;
                    this.checkNaN(e) || (this.setData({
                        inputSeriesList: this.inputSeriesList.concat([ [ e, this.inputSeriesUnit ] ])
                    }), this.calculateSeries(), this.clearDelay("inputSeriesValue"), this.seriesUsed || (this.use(), 
                    this.seriesUsed = !0));
                },
                clearSeries: function() {
                    this.setData({
                        inputSeriesList: [],
                        outputSeriesResult: 0
                    }), this.seriesUsed = !1;
                },
                calculateSeries: function() {
                    var e = this.getResistances(this.inputSeriesList, this.outputSeriesUnit);
                    this.output("outputSeriesResult", this.series(e));
                },
                addParallel: function() {
                    var e = this.inputParallelValue;
                    this.checkNaN(e) || (this.setData({
                        inputParallelList: this.inputParallelList.concat([ [ e, this.inputParallelUnit ] ])
                    }), this.calculateParallel(), this.clearDelay("inputParallelValue"), this.parallelUsed || (this.use(), 
                    this.parallelUsed = !0));
                },
                clearParallel: function() {
                    this.setData({
                        inputParallelList: [],
                        outputParallelResult: 0
                    }), this.parallelUsed = !1;
                },
                calculateParallel: function() {
                    var e = this.getResistances(this.inputParallelList, this.outputParallelUnit);
                    this.output("outputParallelResult", this.parallel(e));
                },
                getResistances: function(e, t) {
                    var n = this, r = [];
                    return e.forEach(function(e) {
                        r.push((0, o.unitConvert)(e[0], n.units[e[1]], n.units[t]));
                    }), r;
                },
                output: function(e, t) {
                    switch (t = 0 != t ? parseFloat(t.toFixed(10)) : 0, e) {
                      case "outputParallelResult":
                        this.outputParallelResult = t;
                        break;

                      case "outputSeriesResult":
                        this.outputSeriesResult = t;
                    }
                },
                clearDelay: function(e) {
                    var t = this;
                    setTimeout(function() {
                        switch (e) {
                          case "inputSeriesValue":
                            t.inputSeriesValue = "";
                            break;

                          case "inputParallelValue":
                            t.inputParallelValue = "";
                        }
                    });
                }
            }
        };
        t.default = a;
    },
    "11b0": function(e, t) {
        e.exports = function(e) {
            if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e);
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    1733: function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("b253")), o = getApp(), a = {
                data: function() {
                    return {};
                },
                onLoad: function() {
                    this.updateAnnouncement();
                },
                onShow: function() {
                    this.checkRedDot();
                },
                methods: {
                    updateAnnouncement: function() {
                        var t = this;
                        if (void 0 === o.globalData.redDot) {
                            var n = function(e) {
                                var n = e ? {
                                    last_time: e
                                } : null;
                                i.default.get("announcement/has-update", n).then(function(e) {
                                    o.globalData.redDot = e.data.count > 0, getApp().globalData.trigger("announcement", o.globalData.redDot), 
                                    t.checkRedDot();
                                }, function() {});
                            };
                            e.getStorage({
                                key: "notice_last_view",
                                success: function(e) {
                                    return n(e.data);
                                },
                                fail: function() {
                                    return n();
                                }
                            });
                        }
                    },
                    checkRedDot: function() {
                        void 0 !== o.globalData.redDot && (o.globalData.redDot ? e.showTabBarRedDot({
                            index: 4
                        }) : e.hideTabBarRedDot({
                            index: 4
                        }));
                    }
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    "1c29": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OhmUnits = t.InputTerminal = void 0, t.calculateCapacitiveReactance = function(e, t) {
            return 1 / (s(e) * t);
        }, t.calculateConductivity = function(e) {
            return 1 / e;
        }, t.calculateFrequency = function(e, t, n) {
            return 0 == n ? e / (2 * Math.PI * t) : 1 / (2 * Math.PI * t * e);
        }, t.calculateInductance = function(e, t) {
            return e / s(t);
        }, t.calculateInductiveReactance = function(e, t) {
            return s(e) * t;
        }, t.calculateParallelResistance = function() {
            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            return 1 / t.map(function(e) {
                return 1 / e;
            }).reduce(function(e, t, n, r) {
                return e + t;
            });
        }, t.calculateReactance = function(e, t) {
            return 1 / (s(t) * e);
        }, t.calculateResistivity = function(e, t, n) {
            return e * (1 + t * (n - 20));
        }, t.inductanceUnits = t.capacitanceUnits = void 0, t.ohmConvert = c, t.ohmFormat = function(e, t) {
            var n = i;
            return t && t.name != n.O.name && (e *= t.mul), e < n.O.mul ? (0, r.format)(e / n.m.mul, n.m) : e >= n.M.mul ? (0, 
            r.format)(e / n.M.mul, n.M) : e >= n.k.mul ? (0, r.format)(e / n.k.mul, n.k) : (0, 
            r.format)(e, n.O);
        }, t.ohmFormatTo = function(e, t, n) {
            return e = c(e, t, n), (0, r.format)(e, t);
        };
        var r = n("00cd"), i = {
            m: new r.Unit("mΩ", .001),
            O: new r.Unit("Ω", 1),
            k: new r.Unit("kΩ", 1e3),
            M: new r.Unit("MΩ", 1e6)
        };
        t.OhmUnits = i;
        var o = {
            H: new r.Unit("H"),
            mH: new r.Unit("mH", 1e3, -1),
            uH: new r.Unit("μH", 1e3, -2)
        };
        t.inductanceUnits = o;
        var a = {
            F: new r.Unit("F"),
            mF: new r.Unit("mF", 1e3, -1),
            uF: new r.Unit("μF", 1e3, -2),
            nF: new r.Unit("nF", 1e3, -3),
            pF: new r.Unit("pF", 1e3, -4)
        };
        function c(e, t, n) {
            return null == n && (n = i.O), (0, r.unitConvert)(e, n, t);
        }
        function s(e) {
            return 2 * Math.PI * e;
        }
        t.capacitanceUnits = a, t.InputTerminal = {
            VOLTAGE_CURRENT: "voltage_current",
            VOLTAGE_POWER: "voltage_power",
            CURRENT_POWER: "current_power",
            IMPEDANCE: "impedance",
            RESISTANCE: "resistance"
        };
    },
    "1df1": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            methods: {
                escape2Html: function(e) {
                    if (!e) return e;
                    var t = {
                        lt: "<",
                        gt: ">",
                        nbsp: " ",
                        amp: "&",
                        quot: '"'
                    };
                    return e.replace(/&(lt|gt|nbsp|amp|quot);/gi, function(e, n) {
                        return t[n];
                    });
                },
                html2Escape: function(e) {
                    return e ? e.replace(/[<>&"]/g, function(e) {
                        return {
                            "<": "&lt;",
                            ">": "&gt;",
                            "&": "&amp;",
                            '"': "&quot;"
                        }[e];
                    }) : e;
                },
                setData: function(e, t) {
                    var n = this;
                    Object.keys(e).forEach(function(t) {
                        var r, i, o = e[t], a = (t = t.replace(/\]/g, "").replace(/\[/g, ".")).lastIndexOf(".");
                        -1 != a ? (i = t.slice(a + 1), r = function(e, t, n) {
                            var r = e;
                            return (t = t.split(".")).forEach(function(t) {
                                null === e[t] || void 0 === e[t] ? (e[t] = /^[0-9]+$/.test(n) ? [] : {}, r = e[t]) : r = e[t];
                            }), r;
                        }(n, t.slice(0, a), i)) : (i = t, r = n), r.$data && void 0 === r.$data[i] ? (Object.defineProperty(r, i, {
                            get: function() {
                                return r.$data[i];
                            },
                            set: function(e) {
                                r.$data[i] = e, n.hasOwnProperty("$forceUpdate") && n.$forceUpdate();
                            },
                            enumerable: !0,
                            configurable: !0
                        }), r[i] = o) : n.$set(r, i, o);
                    }), function(e) {
                        return "function" == typeof e || !1;
                    }(t) && this.$nextTick(t);
                },
                parseEventDynamicCode: function(e, t) {
                    "function" == typeof this[t] && this[t](e);
                },
                deepClone: function(e) {
                    return JSON.parse(JSON.stringify(e));
                },
                datasetHandle: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    e && !e.currentTarget && (t.tagId ? e.currentTarget = {
                        id: t.tagId
                    } : e.currentTarget = {
                        dataset: t
                    });
                }
            }
        };
        t.default = r;
    },
    2236: function(e, t, n) {
        var r = n("5a43");
        e.exports = function(e) {
            if (Array.isArray(e)) return r(e);
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "26cb": function(e, t, n) {
        "use strict";
        (function(t) {
            var n = ("undefined" != typeof window ? window : void 0 !== t ? t : {}).__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function r(e, t) {
                if (void 0 === t && (t = []), null === e || "object" != typeof e) return e;
                var n = function(e, t) {
                    return e.filter(t)[0];
                }(t, function(t) {
                    return t.original === e;
                });
                if (n) return n.copy;
                var i = Array.isArray(e) ? [] : {};
                return t.push({
                    original: e,
                    copy: i
                }), Object.keys(e).forEach(function(n) {
                    i[n] = r(e[n], t);
                }), i;
            }
            function i(e, t) {
                Object.keys(e).forEach(function(n) {
                    return t(e[n], n);
                });
            }
            function o(e) {
                return null !== e && "object" == typeof e;
            }
            var a = function(e, t) {
                this.runtime = t, this._children = Object.create(null), this._rawModule = e;
                var n = e.state;
                this.state = ("function" == typeof n ? n() : n) || {};
            }, c = {
                namespaced: {
                    configurable: !0
                }
            };
            c.namespaced.get = function() {
                return !!this._rawModule.namespaced;
            }, a.prototype.addChild = function(e, t) {
                this._children[e] = t;
            }, a.prototype.removeChild = function(e) {
                delete this._children[e];
            }, a.prototype.getChild = function(e) {
                return this._children[e];
            }, a.prototype.hasChild = function(e) {
                return e in this._children;
            }, a.prototype.update = function(e) {
                this._rawModule.namespaced = e.namespaced, e.actions && (this._rawModule.actions = e.actions), 
                e.mutations && (this._rawModule.mutations = e.mutations), e.getters && (this._rawModule.getters = e.getters);
            }, a.prototype.forEachChild = function(e) {
                i(this._children, e);
            }, a.prototype.forEachGetter = function(e) {
                this._rawModule.getters && i(this._rawModule.getters, e);
            }, a.prototype.forEachAction = function(e) {
                this._rawModule.actions && i(this._rawModule.actions, e);
            }, a.prototype.forEachMutation = function(e) {
                this._rawModule.mutations && i(this._rawModule.mutations, e);
            }, Object.defineProperties(a.prototype, c);
            var s, u = function(e) {
                this.register([], e, !1);
            };
            u.prototype.get = function(e) {
                return e.reduce(function(e, t) {
                    return e.getChild(t);
                }, this.root);
            }, u.prototype.getNamespace = function(e) {
                var t = this.root;
                return e.reduce(function(e, n) {
                    return e + ((t = t.getChild(n)).namespaced ? n + "/" : "");
                }, "");
            }, u.prototype.update = function(e) {
                !function e(t, n, r) {
                    if (n.update(r), r.modules) for (var i in r.modules) {
                        if (!n.getChild(i)) return;
                        e(t.concat(i), n.getChild(i), r.modules[i]);
                    }
                }([], this.root, e);
            }, u.prototype.register = function(e, t, n) {
                var r = this;
                void 0 === n && (n = !0);
                var o = new a(t, n);
                0 === e.length ? this.root = o : this.get(e.slice(0, -1)).addChild(e[e.length - 1], o), 
                t.modules && i(t.modules, function(t, i) {
                    r.register(e.concat(i), t, n);
                });
            }, u.prototype.unregister = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1], r = t.getChild(n);
                r && r.runtime && t.removeChild(n);
            }, u.prototype.isRegistered = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1];
                return !!t && t.hasChild(n);
            };
            var l = function(e) {
                var t = this;
                void 0 === e && (e = {}), !s && "undefined" != typeof window && window.Vue && y(window.Vue);
                var r = e.plugins;
                void 0 === r && (r = []);
                var i = e.strict;
                void 0 === i && (i = !1), this._committing = !1, this._actions = Object.create(null), 
                this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), 
                this._modules = new u(e), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], 
                this._watcherVM = new s(), this._makeLocalGettersCache = Object.create(null);
                var o = this, a = this.dispatch, c = this.commit;
                this.dispatch = function(e, t) {
                    return a.call(o, e, t);
                }, this.commit = function(e, t, n) {
                    return c.call(o, e, t, n);
                }, this.strict = i;
                var l = this._modules.root.state;
                g(this, l, [], this._modules.root), d(this, l), r.forEach(function(e) {
                    return e(t);
                }), (void 0 !== e.devtools ? e.devtools : s.config.devtools) && function(e) {
                    n && (e._devtoolHook = n, n.emit("vuex:init", e), n.on("vuex:travel-to-state", function(t) {
                        e.replaceState(t);
                    }), e.subscribe(function(e, t) {
                        n.emit("vuex:mutation", e, t);
                    }, {
                        prepend: !0
                    }), e.subscribeAction(function(e, t) {
                        n.emit("vuex:action", e, t);
                    }, {
                        prepend: !0
                    }));
                }(this);
            }, p = {
                state: {
                    configurable: !0
                }
            };
            function f(e, t, n) {
                return t.indexOf(e) < 0 && (n && n.prepend ? t.unshift(e) : t.push(e)), function() {
                    var n = t.indexOf(e);
                    n > -1 && t.splice(n, 1);
                };
            }
            function h(e, t) {
                e._actions = Object.create(null), e._mutations = Object.create(null), e._wrappedGetters = Object.create(null), 
                e._modulesNamespaceMap = Object.create(null);
                var n = e.state;
                g(e, n, [], e._modules.root, !0), d(e, n, t);
            }
            function d(e, t, n) {
                var r = e._vm;
                e.getters = {}, e._makeLocalGettersCache = Object.create(null);
                var o = e._wrappedGetters, a = {};
                i(o, function(t, n) {
                    a[n] = function(e, t) {
                        return function() {
                            return e(t);
                        };
                    }(t, e), Object.defineProperty(e.getters, n, {
                        get: function() {
                            return e._vm[n];
                        },
                        enumerable: !0
                    });
                });
                var c = s.config.silent;
                s.config.silent = !0, e._vm = new s({
                    data: {
                        $$state: t
                    },
                    computed: a
                }), s.config.silent = c, e.strict && function(e) {
                    e._vm.$watch(function() {
                        return this._data.$$state;
                    }, function() {}, {
                        deep: !0,
                        sync: !0
                    });
                }(e), r && (n && e._withCommit(function() {
                    r._data.$$state = null;
                }), s.nextTick(function() {
                    return r.$destroy();
                }));
            }
            function g(e, t, n, r, i) {
                var o = !n.length, a = e._modules.getNamespace(n);
                if (r.namespaced && (e._modulesNamespaceMap[a], e._modulesNamespaceMap[a] = r), 
                !o && !i) {
                    var c = m(t, n.slice(0, -1)), u = n[n.length - 1];
                    e._withCommit(function() {
                        s.set(c, u, r.state);
                    });
                }
                var l = r.context = function(e, t, n) {
                    var r = "" === t, i = {
                        dispatch: r ? e.dispatch : function(n, r, i) {
                            var o = v(n, r, i), a = o.payload, c = o.options, s = o.type;
                            return c && c.root || (s = t + s), e.dispatch(s, a);
                        },
                        commit: r ? e.commit : function(n, r, i) {
                            var o = v(n, r, i), a = o.payload, c = o.options, s = o.type;
                            c && c.root || (s = t + s), e.commit(s, a, c);
                        }
                    };
                    return Object.defineProperties(i, {
                        getters: {
                            get: r ? function() {
                                return e.getters;
                            } : function() {
                                return function(e, t) {
                                    if (!e._makeLocalGettersCache[t]) {
                                        var n = {}, r = t.length;
                                        Object.keys(e.getters).forEach(function(i) {
                                            if (i.slice(0, r) === t) {
                                                var o = i.slice(r);
                                                Object.defineProperty(n, o, {
                                                    get: function() {
                                                        return e.getters[i];
                                                    },
                                                    enumerable: !0
                                                });
                                            }
                                        }), e._makeLocalGettersCache[t] = n;
                                    }
                                    return e._makeLocalGettersCache[t];
                                }(e, t);
                            }
                        },
                        state: {
                            get: function() {
                                return m(e.state, n);
                            }
                        }
                    }), i;
                }(e, a, n);
                r.forEachMutation(function(t, n) {
                    !function(e, t, n, r) {
                        (e._mutations[t] || (e._mutations[t] = [])).push(function(t) {
                            n.call(e, r.state, t);
                        });
                    }(e, a + n, t, l);
                }), r.forEachAction(function(t, n) {
                    var r = t.root ? n : a + n, i = t.handler || t;
                    !function(e, t, n, r) {
                        (e._actions[t] || (e._actions[t] = [])).push(function(t) {
                            var i = n.call(e, {
                                dispatch: r.dispatch,
                                commit: r.commit,
                                getters: r.getters,
                                state: r.state,
                                rootGetters: e.getters,
                                rootState: e.state
                            }, t);
                            return function(e) {
                                return e && "function" == typeof e.then;
                            }(i) || (i = Promise.resolve(i)), e._devtoolHook ? i.catch(function(t) {
                                throw e._devtoolHook.emit("vuex:error", t), t;
                            }) : i;
                        });
                    }(e, r, i, l);
                }), r.forEachGetter(function(t, n) {
                    !function(e, t, n, r) {
                        e._wrappedGetters[t] || (e._wrappedGetters[t] = function(e) {
                            return n(r.state, r.getters, e.state, e.getters);
                        });
                    }(e, a + n, t, l);
                }), r.forEachChild(function(r, o) {
                    g(e, t, n.concat(o), r, i);
                });
            }
            function m(e, t) {
                return t.reduce(function(e, t) {
                    return e[t];
                }, e);
            }
            function v(e, t, n) {
                return o(e) && e.type && (n = t, t = e, e = e.type), {
                    type: e,
                    payload: t,
                    options: n
                };
            }
            function y(e) {
                s && e === s || function(e) {
                    if (Number(e.version.split(".")[0]) >= 2) e.mixin({
                        beforeCreate: n
                    }); else {
                        var t = e.prototype._init;
                        e.prototype._init = function(e) {
                            void 0 === e && (e = {}), e.init = e.init ? [ n ].concat(e.init) : n, t.call(this, e);
                        };
                    }
                    function n() {
                        var e = this.$options;
                        e.store ? this.$store = "function" == typeof e.store ? e.store() : e.store : e.parent && e.parent.$store && (this.$store = e.parent.$store);
                    }
                }(s = e);
            }
            p.state.get = function() {
                return this._vm._data.$$state;
            }, p.state.set = function(e) {}, l.prototype.commit = function(e, t, n) {
                var r = this, i = v(e, t, n), o = i.type, a = i.payload, c = (i.options, {
                    type: o,
                    payload: a
                }), s = this._mutations[o];
                s && (this._withCommit(function() {
                    s.forEach(function(e) {
                        e(a);
                    });
                }), this._subscribers.slice().forEach(function(e) {
                    return e(c, r.state);
                }));
            }, l.prototype.dispatch = function(e, t) {
                var n = this, r = v(e, t), i = r.type, o = r.payload, a = {
                    type: i,
                    payload: o
                }, c = this._actions[i];
                if (c) {
                    try {
                        this._actionSubscribers.slice().filter(function(e) {
                            return e.before;
                        }).forEach(function(e) {
                            return e.before(a, n.state);
                        });
                    } catch (e) {}
                    var s = c.length > 1 ? Promise.all(c.map(function(e) {
                        return e(o);
                    })) : c[0](o);
                    return new Promise(function(e, t) {
                        s.then(function(t) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.after;
                                }).forEach(function(e) {
                                    return e.after(a, n.state);
                                });
                            } catch (e) {}
                            e(t);
                        }, function(e) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.error;
                                }).forEach(function(t) {
                                    return t.error(a, n.state, e);
                                });
                            } catch (e) {}
                            t(e);
                        });
                    });
                }
            }, l.prototype.subscribe = function(e, t) {
                return f(e, this._subscribers, t);
            }, l.prototype.subscribeAction = function(e, t) {
                return f("function" == typeof e ? {
                    before: e
                } : e, this._actionSubscribers, t);
            }, l.prototype.watch = function(e, t, n) {
                var r = this;
                return this._watcherVM.$watch(function() {
                    return e(r.state, r.getters);
                }, t, n);
            }, l.prototype.replaceState = function(e) {
                var t = this;
                this._withCommit(function() {
                    t._vm._data.$$state = e;
                });
            }, l.prototype.registerModule = function(e, t, n) {
                void 0 === n && (n = {}), "string" == typeof e && (e = [ e ]), this._modules.register(e, t), 
                g(this, this.state, e, this._modules.get(e), n.preserveState), d(this, this.state);
            }, l.prototype.unregisterModule = function(e) {
                var t = this;
                "string" == typeof e && (e = [ e ]), this._modules.unregister(e), this._withCommit(function() {
                    var n = m(t.state, e.slice(0, -1));
                    s.delete(n, e[e.length - 1]);
                }), h(this);
            }, l.prototype.hasModule = function(e) {
                return "string" == typeof e && (e = [ e ]), this._modules.isRegistered(e);
            }, l.prototype[[ 104, 111, 116, 85, 112, 100, 97, 116, 101 ].map(function(e) {
                return String.fromCharCode(e);
            }).join("")] = function(e) {
                this._modules.update(e), h(this, !0);
            }, l.prototype._withCommit = function(e) {
                var t = this._committing;
                this._committing = !0, e(), this._committing = t;
            }, Object.defineProperties(l.prototype, p);
            var _ = C(function(e, t) {
                var n = {};
                return b(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        var t = this.$store.state, n = this.$store.getters;
                        if (e) {
                            var r = A(this.$store, 0, e);
                            if (!r) return;
                            t = r.context.state, n = r.context.getters;
                        }
                        return "function" == typeof i ? i.call(this, t, n) : t[i];
                    }, n[r].vuex = !0;
                }), n;
            }), T = C(function(e, t) {
                var n = {};
                return b(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.commit;
                        if (e) {
                            var o = A(this.$store, 0, e);
                            if (!o) return;
                            r = o.context.commit;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ i ].concat(t));
                    };
                }), n;
            }), w = C(function(e, t) {
                var n = {};
                return b(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    i = e + i, n[r] = function() {
                        if (!e || A(this.$store, 0, e)) return this.$store.getters[i];
                    }, n[r].vuex = !0;
                }), n;
            }), E = C(function(e, t) {
                var n = {};
                return b(t).forEach(function(t) {
                    var r = t.key, i = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.dispatch;
                        if (e) {
                            var o = A(this.$store, 0, e);
                            if (!o) return;
                            r = o.context.dispatch;
                        }
                        return "function" == typeof i ? i.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ i ].concat(t));
                    };
                }), n;
            });
            function b(e) {
                return function(e) {
                    return Array.isArray(e) || o(e);
                }(e) ? Array.isArray(e) ? e.map(function(e) {
                    return {
                        key: e,
                        val: e
                    };
                }) : Object.keys(e).map(function(t) {
                    return {
                        key: t,
                        val: e[t]
                    };
                }) : [];
            }
            function C(e) {
                return function(t, n) {
                    return "string" != typeof t ? (n = t, t = "") : "/" !== t.charAt(t.length - 1) && (t += "/"), 
                    e(t, n);
                };
            }
            function A(e, t, n) {
                return e._modulesNamespaceMap[n];
            }
            function S(e, t, n) {
                var r = n ? e.groupCollapsed : e.group;
                try {
                    r.call(e, t);
                } catch (n) {
                    e.log(t);
                }
            }
            function R(e) {
                try {
                    e.groupEnd();
                } catch (t) {
                    e.log("—— log end ——");
                }
            }
            function N() {
                var e = new Date();
                return " @ " + O(e.getHours(), 2) + ":" + O(e.getMinutes(), 2) + ":" + O(e.getSeconds(), 2) + "." + O(e.getMilliseconds(), 3);
            }
            function O(e, t) {
                return function(e, t) {
                    return new Array(t + 1).join("0");
                }(0, t - e.toString().length) + e;
            }
            var I = {
                Store: l,
                install: y,
                version: "3.6.2",
                mapState: _,
                mapMutations: T,
                mapGetters: w,
                mapActions: E,
                createNamespacedHelpers: function(e) {
                    return {
                        mapState: _.bind(null, e),
                        mapGetters: w.bind(null, e),
                        mapMutations: T.bind(null, e),
                        mapActions: E.bind(null, e)
                    };
                },
                createLogger: function(e) {
                    void 0 === e && (e = {});
                    var t = e.collapsed;
                    void 0 === t && (t = !0);
                    var n = e.filter;
                    void 0 === n && (n = function(e, t, n) {
                        return !0;
                    });
                    var i = e.transformer;
                    void 0 === i && (i = function(e) {
                        return e;
                    });
                    var o = e.mutationTransformer;
                    void 0 === o && (o = function(e) {
                        return e;
                    });
                    var a = e.actionFilter;
                    void 0 === a && (a = function(e, t) {
                        return !0;
                    });
                    var c = e.actionTransformer;
                    void 0 === c && (c = function(e) {
                        return e;
                    });
                    var s = e.logMutations;
                    void 0 === s && (s = !0);
                    var u = e.logActions;
                    void 0 === u && (u = !0);
                    var l = e.logger;
                    return void 0 === l && (l = console), function(e) {
                        var p = r(e.state);
                        void 0 !== l && (s && e.subscribe(function(e, a) {
                            var c = r(a);
                            if (n(e, p, c)) {
                                var s = N(), u = o(e), f = "mutation " + e.type + s;
                                S(l, f, t), l.log("%c prev state", "color: #9E9E9E; font-weight: bold", i(p)), l.log("%c mutation", "color: #03A9F4; font-weight: bold", u), 
                                l.log("%c next state", "color: #4CAF50; font-weight: bold", i(c)), R(l);
                            }
                            p = c;
                        }), u && e.subscribeAction(function(e, n) {
                            if (a(e, n)) {
                                var r = N(), i = c(e), o = "action " + e.type + r;
                                S(l, o, t), l.log("%c action", "color: #03A9F4; font-weight: bold", i), R(l);
                            }
                        }));
                    };
                }
            };
            e.exports = I;
        }).call(this, n("c8ba"));
    },
    "278c": function(e, t, n) {
        var r = n("c135"), i = n("9b42"), o = n("6613"), a = n("c240");
        e.exports = function(e, t) {
            return r(e) || i(e, t) || o(e, t) || a();
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "2c16": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT:
                t = c(e.currentType, e.voltageValue, e.currentValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_RESISTANCE:
                t = s(e.currentType, e.voltageValue, e.resistanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_IMPEDANCE:
                t = u(e.currentType, e.voltageValue, e.impedanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_RESISTANCE:
                t = l(e.currentType, e.currentValue, e.resistanceValue);
                break;

              case o.InputTerminal.CURRENT_IMPEDANCE:
                t = p(e.currentType, e.currentValue, e.impedanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.APPARENT_REACTIVE:
                t = f(e.currentType, e.apparentPowerValue, e.reactivePowerValue);
                break;

              case o.InputTerminal.APPARENT_POWER:
                t = h(e.currentType, e.apparentPowerValue, e.triangleCollection);
                break;

              case o.InputTerminal.REACTIVE_POWER:
                t = d(e.currentType, e.reactivePowerValue, e.triangleCollection);
            }
            return t;
        }, t.calculateApparent = h, t.calculateApparentReactive = f, t.calculateCurrentImpedance = p, 
        t.calculateCurrentResistance = l, t.calculateReactive = d, t.calculateVoltageCurrent = c, 
        t.calculateVoltageImpedance = u, t.calculateVoltageResistance = s;
        var r = n("d417"), i = n("d055"), o = n("fad4"), a = n("2e64");
        function c(e, t, n, o) {
            var c = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
            switch (e !== i.CurrentType.DIRECT_CURRENT && g(o), e) {
              case i.CurrentType.DIRECT_CURRENT:
                c = t * n;
                break;

              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
                c = t * n * o[a.TrigonometricType.COS];
                break;

              case i.CurrentType.THREE_PHASE_CURRENT:
                c = Math.sqrt(3) * t * n * o[a.TrigonometricType.COS];
            }
            return c;
        }
        function s(e, t, n, o) {
            var c = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
            switch (e !== i.CurrentType.DIRECT_CURRENT && g(o), e) {
              case i.CurrentType.DIRECT_CURRENT:
                c = Math.pow(t, 2) * n;
                break;

              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
                c = Math.pow(t, 2) * Math.pow(o[a.TrigonometricType.COS], 2) / n;
                break;

              case i.CurrentType.THREE_PHASE_CURRENT:
                c = Math.sqrt(3) * Math.pow(t, 2) * Math.pow(o[a.TrigonometricType.COS], 2) / n;
            }
            return c;
        }
        function u(e, t, n, o) {
            var c = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
            switch (g(o), e) {
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
                c = Math.pow(t, 2) * o[a.TrigonometricType.COS] / n;
                break;

              case i.CurrentType.THREE_PHASE_CURRENT:
                c = Math.sqrt(3) * Math.pow(t, 2) * o[a.TrigonometricType.COS] / n;
            }
            return c;
        }
        function l(e, t, n) {
            var o = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
            switch (e) {
              case i.CurrentType.DIRECT_CURRENT:
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
                o = Math.pow(t, 2) * n;
                break;

              case i.CurrentType.THREE_PHASE_CURRENT:
                o = Math.sqrt(3) * Math.pow(t, 2) * n;
            }
            return o;
        }
        function p(e, t, n, o) {
            var c = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
            switch (g(o), e) {
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
                c = Math.pow(t, 2) * n * o[a.TrigonometricType.COS];
                break;

              case i.CurrentType.THREE_PHASE_CURRENT:
                c = Math.sqrt(3) * Math.pow(t, 2) * n * o[a.TrigonometricType.COS];
            }
            return c;
        }
        function f(e, t, n) {
            var o = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("视在功率数值无效");
            if (!(0, r.isNonzeroNumber)(n)) throw new Error("无功功率数值无效");
            switch (e) {
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
              case i.CurrentType.THREE_PHASE_CURRENT:
                o = Math.sqrt(Math.pow(t, 2) - Math.pow(n, 2));
            }
            return o;
        }
        function h(e, t, n) {
            var o = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("视在功率数值无效");
            switch (g(n), e) {
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
              case i.CurrentType.THREE_PHASE_CURRENT:
                o = t * n[a.TrigonometricType.COS];
            }
            return o;
        }
        function d(e, t, n) {
            var o = 0;
            if (!(0, r.isNonzeroNumber)(t)) throw new Error("视在功率数值无效");
            if (g(n), 0 === n[a.TrigonometricType.TAN]) throw new Error("∞");
            switch (e) {
              case i.CurrentType.SINGLE_PHASE_CURRENT:
              case i.CurrentType.TWO_PHASE_CURRENT:
              case i.CurrentType.THREE_PHASE_CURRENT:
                o = t / n[a.TrigonometricType.TAN];
            }
            return o;
        }
        function g(e) {
            if (e.type === a.TrigonometricType.COS && 0 === e[a.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
    },
    "2d0b": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculateCodeResistance = function(e, t, n, r) {
            var i = (e = e.toString()).length;
            if (i < 3 || i > 5) throw new Error("无效参数（-1001）");
            if (t && n) throw new Error("无效参数（-1003）");
            var o = function(e) {
                var t, n = u.map(function(e) {
                    return e.label;
                }), r = l.map(function(e) {
                    return e.label;
                });
                if (-1 !== e.indexOf("R")) {
                    if (t = new RegExp("[A-QS-Z]"), !e.match(t)) return p.DECIMAL;
                } else {
                    if (t = new RegExp("^[0-9]+$"), e.match(t)) return p.DIGIT;
                    if (t = new RegExp("^[0-9]{2}[" + n.join("") + "]$"), e.match(t)) return p.EIA96;
                    if (t = new RegExp("^[" + n.join("") + "][0-9]{2}$"), e.match(t) && parseInt(e.slice(1, 3)) <= 60) return p.EIA96_60;
                    if (t = new RegExp("^[0-9]{3,4}[" + r.join("") + "]$"), e.match(t)) return p.BS1852;
                }
                return p.INVALID;
            }(e = e.toUpperCase());
            if (o === p.INVALID) throw new Error("无效参数（-1002）");
            var a = e.slice(-1), c = "up", s = 0, v = 0;
            if (n && (c = "down"), r) {
                var y = l.findIndex(function(e) {
                    return e.label === a;
                });
                if (-1 === y || i < 4) throw new Error("无效参数（-1101）");
                if (v = l[y].value, o !== p.BS1852) throw new Error("无效参数（-1102）");
                s = f(e, c);
            } else if (4 === i && (v = 1), n) if (o === p.DIGIT) s = g(e, c); else if (o === p.EIA96) s = h(e); else if (o === p.EIA96_60) s = d(e); else {
                if (o !== p.BS1852) throw new Error("无效参数（-1202）");
                s = f(e, c);
            } else if (o === p.DIGIT) s = g(e, c); else if (o === p.DECIMAL) s = m(e); else if (o === p.EIA96) s = h(e); else {
                if (o !== p.EIA96_60) throw new Error("无效参数（-1201）");
                s = d(e);
            }
            return {
                type: o,
                resistance: s,
                mistake: v
            };
        };
        var i = r(n("5bc3")), o = r(n("970b")), a = (0, i.default)(function e(t, n) {
            (0, o.default)(this, e), this.label = t, this.value = n;
        }), c = [ 0, 100, 102, 105, 107, 110, 113, 115, 118, 121, 124, 127, 130, 133, 137, 140, 143, 147, 150, 154, 158, 162, 165, 169, 174, 178, 182, 187, 191, 196, 200, 205, 210, 215, 221, 226, 232, 237, 243, 249, 255, 261, 267, 274, 280, 287, 294, 301, 309, 316, 324, 332, 340, 348, 357, 365, 374, 383, 392, 402, 412, 422, 432, 442, 453, 464, 475, 487, 499, 511, 523, 536, 549, 562, 576, 590, 604, 619, 634, 649, 665, 681, 698, 715, 732, 750, 768, 787, 806, 825, 845, 866, 887, 909, 931, 953, 976 ], s = [ 0, 100, 110, 120, 130, 150, 160, 180, 200, 220, 240, 270, 300, 330, 360, 390, 430, 470, 510, 560, 620, 680, 750, 820, 910, 100, 110, 120, 130, 150, 160, 180, 200, 220, 240, 270, 300, 330, 360, 390, 430, 470, 510, 560, 620, 680, 750, 820, 910, 100, 120, 150, 180, 220, 270, 330, 390, 470, 560, 680, 820 ], u = [ new a("Z", .001), new a("Y", .01), new a("X", .1), new a("S", .1), new a("A", 1), new a("B", 10), new a("H", 10), new a("C", 100), new a("D", 1e3), new a("E", 1e4), new a("F", 1e5) ], l = [ new a("M", 20), new a("K", 10), new a("J", 5), new a("F", 1), new a("G", 2), new a("D", .5), new a("C", .25), new a("B", .1) ], p = {
            DECIMAL: "DECIMAL",
            DIGIT: "DIGIT",
            EIA96: "EIA_96",
            EIA96_60: "EIA_96_60",
            BS1852: "BS_1852",
            INVALID: "INVALID"
        };
        function f(e, t) {
            var n = e.length;
            return g(e.slice(0, n - 1), t);
        }
        function h(e) {
            var t = parseInt(e.slice(0, 2)), n = e.slice(-1);
            if (!c[t]) throw new Error("无效参数（-1010）");
            var r = u.find(function(e) {
                return e.label === n;
            }).value;
            return c[t] * r;
        }
        function d(e) {
            var t = parseInt(e.slice(1, e.length)), n = e.slice(0, 1);
            if (!s[t]) throw new Error("无效参数（-1011）");
            var r = u.find(function(e) {
                return e.label === n;
            }).value;
            return s[t] * r;
        }
        function g(e, t) {
            if ("down" === t) return parseInt(e.padEnd(5, "0")) / 100 / 1e3;
            var n = e.length, r = e.slice(-1), i = 2;
            switch (n) {
              case 4:
                i = 3;
                break;

              case 5:
                i = 4;
            }
            var o = new RegExp("^(0{1,3})[0-9]+"), a = e.match(o), c = 0;
            if (a && (c = a[1].length), c > 0) {
                var s = e.split("");
                switch (c) {
                  case 1:
                    s[0] = "R";
                    break;

                  default:
                    s[1] = "R";
                }
                return m(s.join(""));
            }
            return parseInt(e.slice(0, i)) * Math.pow(10, parseInt(r));
        }
        function m(e) {
            return parseFloat(e.replace("R", "."));
        }
    },
    "2e64": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TrigonometricType = void 0, t.deg2rad = o, t.rad2deg = a, t.triangleCollection = function(e, t) {
            if (isNaN(e)) throw new Error("请输入所有参数");
            var n = e;
            switch (t) {
              case "cos":
                if (e < 0 || e > 1) throw new Error("CosΦ参数无效");
                n = Math.acos(e);
                break;

              case "sin":
                if (e < 0 || e > 1) throw new Error("SinΦ参数无效");
                n = Math.asin(e);
                break;

              case "tan":
                n = Math.atan(e);
                break;

              case "rad":
                if (e < 0 || e > 1.5707963267948966) throw new Error("Φ(RAD)参数无效");
                break;

              case "deg":
                if (e < 0 || e > 90) throw new Error("Φ(DEG)参数无效");
                n = o(e);
            }
            var c = {
                type: t
            };
            return c[i.COS] = parseFloat((0, r.formatDouble)(Math.cos(n), 8)), c[i.SIN] = parseFloat((0, 
            r.formatDouble)(Math.sin(n), 8)), c[i.TAN] = parseFloat((0, r.formatDouble)(Math.tan(n), 8)), 
            c[i.RAD] = parseFloat((0, r.formatDouble)(n, 8)), c[i.DEG] = parseFloat((0, r.formatDouble)(a(n), 8)), 
            c;
        };
        var r = n("00cd"), i = {
            COS: "cos",
            SIN: "sin",
            TAN: "tan",
            RAD: "rad",
            DEG: "deg"
        };
        function o(e) {
            return e * (Math.PI / 180);
        }
        function a(e) {
            return e * (180 / Math.PI);
        }
        t.TrigonometricType = i;
    },
    "2eee": function(e, t, n) {
        var r = n("7ec2")();
        e.exports = r;
    },
    "37af": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("5ce9"), i = n("00cd"), o = {
            data: function() {
                return {
                    hzAllUnits: r.hzUnits,
                    frequencyUnits: [ r.hzUnits.Hz, r.hzUnits.kHz, r.hzUnits.MHz ],
                    frequencyUnitIndex: 0,
                    frequencyUnitValue: void 0
                };
            },
            methods: {
                getFrequencyUnitValue: function() {
                    return (0, i.unitConvert)(this.frequencyUnitValue, this.frequencyUnits[this.frequencyUnitIndex], r.hzUnits.Hz);
                }
            }
        };
        t.default = o;
    },
    "37dc": function(e, t, n) {
        "use strict";
        (function(e, r) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.LOCALE_ZH_HANT = t.LOCALE_ZH_HANS = t.LOCALE_FR = t.LOCALE_ES = t.LOCALE_EN = t.I18n = t.Formatter = void 0, 
            t.compileI18nJsonStr = function(e, t) {
                var n = t.locale, r = t.locales, i = t.delimiters;
                if (!A(e, i)) return e;
                b || (b = new p());
                var o = [];
                Object.keys(r).forEach(function(e) {
                    e !== n && o.push({
                        locale: e,
                        values: r[e]
                    });
                }), o.unshift({
                    locale: n,
                    values: r[n]
                });
                try {
                    return JSON.stringify(function e(t, n, r) {
                        return R(t, function(t, i) {
                            !function(t, n, r, i) {
                                var o = t[n];
                                if (C(o)) {
                                    if (A(o, i) && (t[n] = S(o, r[0].values, i), r.length > 1)) {
                                        var a = t[n + "Locales"] = {};
                                        r.forEach(function(e) {
                                            a[e.locale] = S(o, e.values, i);
                                        });
                                    }
                                } else e(o, r, i);
                            }(t, i, n, r);
                        }), t;
                    }(JSON.parse(e), o, i), null, 2);
                } catch (e) {}
                return e;
            }, t.hasI18nJson = function e(t, n) {
                return b || (b = new p()), R(t, function(t, r) {
                    var i = t[r];
                    return C(i) ? !!A(i, n) || void 0 : e(i, n);
                });
            }, t.initVueI18n = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 ? arguments[2] : void 0, r = arguments.length > 3 ? arguments[3] : void 0;
                if ("string" != typeof e) {
                    var i = [ t, e ];
                    e = i[0], t = i[1];
                }
                "string" != typeof e && (e = E()), "string" != typeof n && (n = "undefined" != typeof __uniConfig && __uniConfig.fallbackLocale || "en");
                var o = new T({
                    locale: e,
                    fallbackLocale: n,
                    messages: t,
                    watcher: r
                }), a = function(e, t) {
                    if ("function" != typeof getApp) a = function(e, t) {
                        return o.t(e, t);
                    }; else {
                        var n = !1;
                        a = function(e, t) {
                            var r = getApp().$vm;
                            return r && (r.$locale, n || (n = !0, w(r, o))), o.t(e, t);
                        };
                    }
                    return a(e, t);
                };
                return {
                    i18n: o,
                    f: function(e, t, n) {
                        return o.f(e, t, n);
                    },
                    t: function(e, t) {
                        return a(e, t);
                    },
                    add: function(e, t) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        return o.add(e, t, n);
                    },
                    watch: function(e) {
                        return o.watchLocale(e);
                    },
                    getLocale: function() {
                        return o.getLocale();
                    },
                    setLocale: function(e) {
                        return o.setLocale(e);
                    }
                };
            }, t.isI18nStr = A, t.isString = void 0, t.normalizeLocale = _, t.parseI18nJson = function e(t, n, r) {
                return b || (b = new p()), R(t, function(t, i) {
                    var o = t[i];
                    C(o) ? A(o, r) && (t[i] = S(o, n, r)) : e(o, n, r);
                }), t;
            }, t.resolveLocale = function(e) {
                return function(t) {
                    return t ? function(e) {
                        for (var t = [], n = e.split("-"); n.length; ) t.push(n.join("-")), n.pop();
                        return t;
                    }(t = _(t) || t).find(function(t) {
                        return e.indexOf(t) > -1;
                    }) : t;
                };
            };
            var o = i(n("278c")), a = i(n("970b")), c = i(n("5bc3")), s = i(n("7037")), u = function(e) {
                return null !== e && "object" === (0, s.default)(e);
            }, l = [ "{", "}" ], p = function() {
                function e() {
                    (0, a.default)(this, e), this._caches = Object.create(null);
                }
                return (0, c.default)(e, [ {
                    key: "interpolate",
                    value: function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : l;
                        if (!t) return [ e ];
                        var r = this._caches[e];
                        return r || (r = d(e, n), this._caches[e] = r), g(r, t);
                    }
                } ]), e;
            }();
            t.Formatter = p;
            var f = /^(?:\d)+/, h = /^(?:\w)+/;
            function d(e, t) {
                for (var n = (0, o.default)(t, 2), r = n[0], i = n[1], a = [], c = 0, s = ""; c < e.length; ) {
                    var u = e[c++];
                    if (u === r) {
                        s && a.push({
                            type: "text",
                            value: s
                        }), s = "";
                        var l = "";
                        for (u = e[c++]; void 0 !== u && u !== i; ) l += u, u = e[c++];
                        var p = u === i, d = f.test(l) ? "list" : p && h.test(l) ? "named" : "unknown";
                        a.push({
                            value: l,
                            type: d
                        });
                    } else s += u;
                }
                return s && a.push({
                    type: "text",
                    value: s
                }), a;
            }
            function g(e, t) {
                var n = [], r = 0, i = Array.isArray(t) ? "list" : u(t) ? "named" : "unknown";
                if ("unknown" === i) return n;
                for (;r < e.length; ) {
                    var o = e[r];
                    switch (o.type) {
                      case "text":
                        n.push(o.value);
                        break;

                      case "list":
                        n.push(t[parseInt(o.value, 10)]);
                        break;

                      case "named":
                        "named" === i && n.push(t[o.value]);
                    }
                    r++;
                }
                return n;
            }
            t.LOCALE_ZH_HANS = "zh-Hans", t.LOCALE_ZH_HANT = "zh-Hant", t.LOCALE_EN = "en", 
            t.LOCALE_FR = "fr", t.LOCALE_ES = "es";
            var m = Object.prototype.hasOwnProperty, v = function(e, t) {
                return m.call(e, t);
            }, y = new p();
            function _(e, t) {
                if (e) {
                    if (e = e.trim().replace(/_/g, "-"), t && t[e]) return e;
                    if ("chinese" === (e = e.toLowerCase())) return "zh-Hans";
                    if (0 === e.indexOf("zh")) return e.indexOf("-hans") > -1 ? "zh-Hans" : e.indexOf("-hant") > -1 || function(e, t) {
                        return !![ "-tw", "-hk", "-mo", "-cht" ].find(function(t) {
                            return -1 !== e.indexOf(t);
                        });
                    }(e) ? "zh-Hant" : "zh-Hans";
                    var n = [ "en", "fr", "es" ];
                    return t && Object.keys(t).length > 0 && (n = Object.keys(t)), function(e, t) {
                        return t.find(function(t) {
                            return 0 === e.indexOf(t);
                        });
                    }(e, n) || void 0;
                }
            }
            var T = function() {
                function e(t) {
                    var n = t.locale, r = t.fallbackLocale, i = t.messages, o = t.watcher, c = t.formater;
                    (0, a.default)(this, e), this.locale = "en", this.fallbackLocale = "en", this.message = {}, 
                    this.messages = {}, this.watchers = [], r && (this.fallbackLocale = r), this.formater = c || y, 
                    this.messages = i || {}, this.setLocale(n || "en"), o && this.watchLocale(o);
                }
                return (0, c.default)(e, [ {
                    key: "setLocale",
                    value: function(e) {
                        var t = this, n = this.locale;
                        this.locale = _(e, this.messages) || this.fallbackLocale, this.messages[this.locale] || (this.messages[this.locale] = {}), 
                        this.message = this.messages[this.locale], n !== this.locale && this.watchers.forEach(function(e) {
                            e(t.locale, n);
                        });
                    }
                }, {
                    key: "getLocale",
                    value: function() {
                        return this.locale;
                    }
                }, {
                    key: "watchLocale",
                    value: function(e) {
                        var t = this, n = this.watchers.push(e) - 1;
                        return function() {
                            t.watchers.splice(n, 1);
                        };
                    }
                }, {
                    key: "add",
                    value: function(e, t) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], r = this.messages[e];
                        r ? n ? Object.assign(r, t) : Object.keys(t).forEach(function(e) {
                            v(r, e) || (r[e] = t[e]);
                        }) : this.messages[e] = t;
                    }
                }, {
                    key: "f",
                    value: function(e, t, n) {
                        return this.formater.interpolate(e, t, n).join("");
                    }
                }, {
                    key: "t",
                    value: function(e, t, n) {
                        var r = this.message;
                        return "string" == typeof t ? (t = _(t, this.messages)) && (r = this.messages[t]) : n = t, 
                        v(r, e) ? this.formater.interpolate(r[e], n).join("") : (console.warn("Cannot translate the value of keypath ".concat(e, ". Use the value of keypath as default.")), 
                        e);
                    }
                } ]), e;
            }();
            function w(e, t) {
                e.$watchLocale ? e.$watchLocale(function(e) {
                    t.setLocale(e);
                }) : e.$watch(function() {
                    return e.$locale;
                }, function(e) {
                    t.setLocale(e);
                });
            }
            function E() {
                return void 0 !== e && e.getLocale ? e.getLocale() : void 0 !== r && r.getLocale ? r.getLocale() : "en";
            }
            t.I18n = T;
            var b, C = function(e) {
                return "string" == typeof e;
            };
            function A(e, t) {
                return e.indexOf(t[0]) > -1;
            }
            function S(e, t, n) {
                return b.interpolate(e, t, n).join("");
            }
            function R(e, t) {
                if (Array.isArray(e)) {
                    for (var n = 0; n < e.length; n++) if (t(e, n)) return !0;
                } else if (u(e)) for (var r in e) if (t(e, r)) return !0;
                return !1;
            }
            t.isString = C;
        }).call(this, n("543d").default, n("c8ba"));
    },
    3853: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT_ACTIVE_POWER:
                t = function(e, t, n, o) {
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    var a = 0;
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        a = t * n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        a = Math.sqrt(3) * t * n;
                    }
                    if (o > a) throw new Error("功率因数数值无效");
                    return o / a;
                }(e.currentType, e.voltageValue, e.currentValue, e.activePowerValue);
                break;

              case o.InputTerminal.VOLTAGE_CURRENT_REACTIVE_POWER:
                t = function(e, t, n, o) {
                    var a;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    var c = 0;
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        c = t * n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        c = Math.sqrt(3) * t * n;
                    }
                    if (o > c) throw new Error("功率因数数值无效");
                    return a = o / c, Math.cos(Math.asin(a));
                }(e.currentType, e.voltageValue, e.currentValue, e.reactivePowerValue);
                break;

              case o.InputTerminal.VOLTAGE_ACTIVE_POWER_IMPEDANCE:
                t = function(e, t, n, o) {
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(o)) throw new Error("阻抗数值无效");
                    var a = 0;
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        a = Math.pow(t, 2);
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        a = Math.sqrt(3) * Math.pow(t, 2);
                    }
                    if (n * o > a) throw new Error("功率因数数值无效");
                    return n * o / a;
                }(e.currentType, e.voltageValue, e.activePowerValue, e.impedanceValue);
                break;

              case o.InputTerminal.CURRENT_ACTIVE_POWER_IMPEDANCE:
                t = function(e, t, n, o) {
                    var a = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(o)) throw new Error("阻抗数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        a = n / (Math.pow(t, 2) * o);
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        a = n / (Math.sqrt(3) * Math.pow(t, 2) * o);
                    }
                    return a;
                }(e.currentType, e.currentValue, e.activePowerValue, e.impedanceValue);
                break;

              case o.InputTerminal.ACTIVE_APPARENT:
                t = function(e, t, n) {
                    var r = 0;
                    if (t > n) throw new Error("功率因数数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        r = t / n;
                    }
                    return r;
                }(e.currentType, e.activePowerValue, e.apparentPowerValue);
                break;

              case o.InputTerminal.ACTIVE_REACTIVE:
                t = function(e, t, n) {
                    var r = 0;
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        r = n / t;
                    }
                    return Math.cos(Math.atan(r));
                }(e.currentType, e.activePowerValue, e.reactivePowerValue);
                break;

              case o.InputTerminal.APPARENT_REACTIVE:
                t = function(e, t, n) {
                    var r = 0;
                    if (t < n) throw new Error("功率因数数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        r = n / t;
                    }
                    return Math.cos(Math.asin(r));
                }(e.currentType, e.apparentPowerValue, e.reactivePowerValue);
                break;

              case o.InputTerminal.RESISTANCE_IMPEDANCE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电阻数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    if (t > n) throw new Error("功率因数数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t / n;
                    }
                    return o;
                }(e.currentType, e.resistanceValue, e.impedanceValue);
            }
            return t;
        };
        var r = n("d417"), i = n("d055"), o = n("fad4");
    },
    "3bc8": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.electromotors = t.converters = t.calculates = void 0, t.calculates = [ {
            icon: "icon-xianxinjiemianjijisuanicon",
            name: "线芯截面积计算",
            key: "cable_core_area",
            page: "calculate/sectional-area/sectional-area"
        }, {
            icon: "icon-dianyajiangjisuanicon",
            name: "电压降计算",
            key: "voltage_drop",
            page: "calculate/form7/form7"
        }, {
            icon: "icon-dianliujisuanicon",
            name: "电流计算",
            key: "current",
            page: "calculate/form5/form5"
        }, {
            icon: "icon-dianyajisuanicon",
            name: "电压计算",
            key: "voltage",
            page: "calculate/form6/form6"
        }, {
            icon: "icon-yougonggongshuaijisuanicon",
            name: "有功功率计算",
            key: "power_active",
            page: "calculate/form9/form9"
        }, {
            icon: "icon-shizaigongshuaijisuanicon",
            name: "视在功率计算",
            key: "power_apparent",
            page: "calculate/form11/form11"
        }, {
            icon: "icon-wugonggongshuaijisuanicon",
            name: "无功功率计算",
            key: "power_reactive",
            page: "calculate/form10/form10"
        }, {
            icon: "icon-gongshuaiyinshubuchangjisuanicon",
            name: "功率因数计算",
            key: "power_factor",
            page: "calculate/form12/form12"
        }, {
            icon: "icon-fuzaizuzhijisuanicon",
            name: "负载阻值计算",
            key: "load_resistance",
            page: "calculate/form13/form13"
        }, {
            icon: "icon-zukangicon",
            name: "计算阻抗",
            key: "impedance",
            page: "calculate/form14/form14"
        }, {
            icon: "icon-zuidaxianlanchangdujisuanicon",
            name: "最大线缆长度计算",
            key: "maximum_cable_length",
            page: "calculate/form8/form8"
        }, {
            icon: "icon-jueyuandaoxiandezailiuliangicon",
            name: "绝缘导线的载流量",
            key: "carrying_capacity_of_insulated_conductor",
            page: "calculate/form15/form15"
        }, {
            icon: "icon-xiexian",
            name: "裸导体的载流量",
            key: "carrying_capacity_of_bear_conductor",
            page: "calculate/form16/form16"
        }, {
            icon: "icon-luodianxiandejieliuliangicon",
            name: "母线载流量"
        }, {
            icon: "icon-jisuanicon",
            name: "导管管径计算"
        }, {
            icon: "icon-duanluqidexuanzeicon",
            name: "断路器的选型",
            key: "circuit_breaker_selection",
            page: "calculate/form19/form19"
        }, {
            icon: "icon-nengliang",
            name: "电缆的允许通过能量 (K²S²)",
            key: "allowable_transmission_of_cable",
            page: "calculate/allowable-transmission-of-cable/index"
        }, {
            icon: "icon-diankangicon",
            name: "电抗",
            key: "reactance",
            page: "calculate/form20/form20"
        }, {
            icon: "icon-zukang",
            name: "阻抗由电阻和电抗组成",
            key: "impedance_consist_of",
            page: "calculate/form21/form21"
        }, {
            icon: "icon-gongshuaiyinshubuchangicon",
            name: "功率因数补偿",
            key: "power_factor_compensation",
            page: "calculate/form22/form22"
        }, {
            icon: "icon-gaodiyaqigongshuaiyinshuxiaozhengicon",
            name: "高/低压变压器功率因数校正",
            key: "transformer_power_correction",
            page: "calculate/form23/form23"
        }, {
            icon: "icon-butongdianyaxiadedianrongqigongshuaiicon",
            name: "不同电压下的电容器功率",
            key: "capacitor_power",
            page: "calculate/form24/form24"
        }, {
            icon: "icon-tedianshandianfahuo",
            name: "最大短路电流",
            key: "short_current_maximum_value",
            page: "calculate/short-current-maximum-value/short-current-maximum-value"
        }, {
            icon: "icon-suoxiao",
            name: "短路电流最小值",
            key: "short_current_least_value",
            page: "calculate/short-current-least-value/short-current-least-value"
        }, {
            icon: "icon-dianzu",
            name: "变电站短路电流"
        }, {
            icon: "icon-dianzu",
            name: "导体电阻",
            key: "conductor_resistance",
            page: "calculate/conductor-resistance/conductor-resistance"
        }, {
            icon: "icon-wendu",
            name: "电缆温度计算",
            key: "cable_temperature",
            page: "calculate/cable-temperature/cable-temperature"
        }, {
            icon: "icon-suoxiao",
            name: "电缆功率损耗",
            key: "cable_power_loss",
            page: "calculate/cable-power-loss/cable-power-loss"
        }, {
            icon: "icon-sehuandianzushibieicon",
            name: "色环电阻识别",
            key: "color_ring_resistance",
            page: "calculate/form1/form1"
        }, {
            icon: "icon-sehuandianganshibieicon",
            name: "色环电感识别",
            key: "color_ring_inductance",
            page: "calculate/form2/form2"
        }, {
            icon: "icon-zuzhizhuansehuanicon",
            name: "阻值转色环",
            key: "resistance_to_color_ring",
            page: "calculate/form4/form4"
        }, {
            icon: "icon-tiepiandianzushibieicon",
            name: "贴片电阻识别",
            key: "smd_resistor_code",
            page: "calculate/form3/form3"
        }, {
            icon: "icon-rongduanqi",
            name: "熔断器",
            key: "fuse",
            page: "calculate/fuse/index"
        }, {
            icon: "icon-dianzuqiuzong",
            name: "电阻求总",
            key: "resistance_sum",
            page: "calculate/resistance-sum/resistance-sum"
        }, {
            icon: "icon-dianrongqiuzong",
            name: "电容求总",
            key: "capacitance_sum",
            page: "calculate/resistance-sum/capacitance-sum"
        }, {
            icon: "icon-LCxiezhenpinshuaijisuanicon",
            name: "LC谐振频率计算",
            key: "lc_resonance_frequency",
            page: "calculate/form25/form25"
        }, {
            icon: "icon-dianzufenyadianluicon",
            name: "电阻分压电路",
            key: "resistance_divider_circuit",
            page: "calculate/form26/form26"
        }, {
            icon: "icon-fenliuqiicon",
            name: "分流器",
            key: "current_shunt",
            page: "calculate/form27/form27"
        }, {
            icon: "icon-wenyaerjiguanwenyadianluicon",
            name: "稳压二极管稳压电路",
            key: "zener_diode",
            page: "calculate/form28/form28"
        }, {
            icon: "icon-fenyadianzuicon",
            name: "分压电阻",
            key: "partial_voltage_resistance",
            page: "calculate/partial-voltage-resistance/partial-voltage-resistance"
        }, {
            icon: "icon-LEDxianliudianzuicon",
            name: "LED限流电阻",
            key: "led_current_limiting_resistance",
            page: "calculate/led-current-limiting-resistance/led-current-limiting-resistance"
        }, {
            icon: "icon-dianchishouming",
            name: "电池续航",
            key: "battery_life",
            page: "calculate/battery-life/battery-life"
        }, {
            icon: "icon-tianxian",
            name: "天线长度计算",
            key: "length_antenna",
            page: "calculate/length-antenna/length-antenna"
        }, {
            icon: "icon-wenduchuanganqiicon",
            name: "温度传感器",
            key: "temperature_sensor",
            page: "calculate/form29/form29"
        }, {
            icon: "icon-monixinhaozhiicon",
            name: "模拟信号值",
            key: "simulator_single_value",
            page: "calculate/form30/form30"
        }, {
            icon: "icon-jiaoerxiaoyingsunhao",
            name: "焦耳效应损耗",
            key: "joule_loss",
            page: "calculate/joule-loss/joule-loss"
        } ], t.converters = [ {
            icon: "icon-zhuanhuanYicon",
            name: "转换Y-△",
            key: "delta_y",
            page: "switch/form1/form1"
        }, {
            icon: "icon-gongshuaizhuanhuanicon",
            name: "功率转换",
            key: "power_convert",
            page: "switch/form2/form2"
        }, {
            icon: "icon-AWGzhuanhuanbiaoicon",
            name: "AWG转换表",
            key: "awg",
            page: "switch/form3/form3"
        }, {
            icon: "icon-SWGzhuanhuanbiaoicon",
            name: "SWG转换表",
            key: "swg",
            page: "switch/form4/form4"
        }, {
            icon: "icon-xianxinjiemianjijisuanicon",
            name: "截面积转换",
            key: "cross_sectional_convert",
            page: "switch/form5/form5"
        }, {
            icon: "icon-changdu",
            name: "转换长度",
            key: "length_convert",
            page: "switch/length/length"
        }, {
            icon: "icon-zhuanhuansincostanicon",
            name: "转换sin/cos/tanφ",
            key: "phi_convert",
            page: "switch/form6/form6"
        }, {
            icon: "icon-zhuanhuanwenduicon",
            name: "转换温度",
            key: "temperature_convert",
            page: "switch/form8/form8"
        }, {
            icon: "icon-zhuanhuananshiqianwashiicon",
            name: "转换安时/千瓦时",
            key: "ah_kwh_convert",
            page: "switch/form9/form9"
        }, {
            icon: "icon-zhuanhuannengliangicon",
            name: "转换能量",
            key: "enegry_convert",
            page: "switch/form10/form10"
        }, {
            icon: "icon-VAruFicon",
            name: "VAr/μF 转换",
            page: "switch/form7/form7"
        } ], t.electromotors = [ {
            icon: "icon-dianliujisuanicon",
            name: "电机电流",
            key: "motor_current",
            page: "electromotor/current"
        }, {
            icon: "icon-dianyajisuanicon",
            name: "电机电压",
            key: "motor_voltage",
            page: "electromotor/voltage"
        }, {
            icon: "icon-yougonggongshuaijisuanicon",
            name: "电机功率",
            key: "motor_power",
            page: "electromotor/power"
        }, {
            icon: "icon-gongshuaiyinshubuchangjisuanicon",
            name: "电机功率因数",
            key: "motor_power_fator",
            page: "electromotor/power-factor"
        }, {
            icon: "icon-yibiao",
            name: "电机效率",
            key: "motor_efficiency",
            page: "electromotor/efficiency"
        }, {
            icon: "icon-sanxiang",
            name: "三相电机变单相",
            key: "motor_trifase_a_monofase",
            page: "electromotor/trifase-a-monofase"
        }, {
            icon: "icon-danxiang",
            name: "单相电机启动电容",
            key: "motor_motore_monofase",
            page: "electromotor/motore-monofase"
        }, {
            icon: "icon-dianjizhuansu",
            name: "电机转速",
            key: "motor_rotate_speed",
            page: "electromotor/rotate-speed"
        }, {
            icon: "icon-dianjizhuanchasu",
            name: "电机转差率",
            key: "motor_slippage_rate",
            page: "electromotor/slippage-rate"
        }, {
            icon: "icon-dianjigonglv",
            name: "功率 / 最大扭矩",
            key: "motor_maximum_torque",
            page: "electromotor/maximum-torque"
        }, {
            icon: "icon-dianjimanfuhe",
            name: "电机满负荷电流",
            key: "motor_full_load_current",
            page: "electromotor/full-load-current"
        }, {
            icon: "icon-shuzi6",
            name: "三相电机接线图（6引线）",
            key: "motor_trifase6",
            page: "electromotor/trifase6"
        }, {
            icon: "icon-shuzi9",
            name: "三相电机接线图（9引线）",
            key: "motor_trifase9",
            page: "electromotor/trifase9"
        }, {
            icon: "icon-shuzi12",
            name: "三相电机接线图（12引线）",
            key: "motor_trifase12",
            page: "electromotor/trifase12"
        } ];
    },
    "3beb": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("d633"), i = n("00cd"), o = {
            data: function() {
                return {
                    allCapacityUnits: r.BatteryCapacityUnits,
                    capacityUnits: [ r.BatteryCapacityUnits.mAh, r.BatteryCapacityUnits.Ah ],
                    capacityUnitIndex: 0,
                    capacityUnitValue: void 0
                };
            },
            methods: {
                getBatteryCapacityValue: function() {
                    return (0, i.unitConvert)(this.capacityUnitValue, this.capacityUnits[this.capacityUnitIndex], r.BatteryCapacityUnits.Ah);
                }
            }
        };
        t.default = o;
    },
    "3d83": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            data: function() {
                return {};
            },
            format: function(e, t) {
                t || (t = new Date());
                var n = {
                    "M+": t.getMonth() + 1,
                    "d+": t.getDate(),
                    "H+": t.getHours(),
                    "m+": t.getMinutes(),
                    "s+": t.getSeconds(),
                    "q+": Math.floor((t.getMonth() + 3) / 3),
                    S: t.getMilliseconds()
                };
                for (var r in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (t.getFullYear() + "").substr(4 - RegExp.$1.length))), 
                n) new RegExp("(" + r + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
                return e;
            }
        };
        t.default = r;
    },
    "3de9": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("9523")), o = n("fad4"), a = n("00cd"), c = n("d055");
        function s(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function u(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? s(Object(n), !0).forEach(function(t) {
                    (0, i.default)(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        var l = u(u({}, o.ActivePowerUnits), {}, {
            A: new a.Unit("A"),
            kA: new a.Unit("kA", 1e3),
            HP: new a.Unit("HP", o.HPUnitValue),
            VA: new a.Unit("VA"),
            kVA: new a.Unit("kVA", 1e3),
            MVA: new a.Unit("MVA", 1e3, 2),
            VAr: new a.Unit("VAr"),
            kVAr: new a.Unit("kVAr", 1e3),
            MVAr: new a.Unit("MVAr", 1e3, 2)
        }), p = {
            data: function() {
                return {
                    powerAllUnits: l,
                    activePowerUnits: [ l.W, l.kW, l.MW, l.HP ],
                    activePowerUnitIndex: 0,
                    activePowerUnitValue: void 0,
                    apparentPowerUnits: [ o.ApparentPowerUnits.VA, o.ApparentPowerUnits.kVA, o.ApparentPowerUnits.MVA ],
                    apparentPowerUnitIndex: 0,
                    apparentPowerUnitValue: void 0,
                    reactivePowerUnits: [ o.ReactivePowerUnits.VAr, o.ReactivePowerUnits.kVAr, o.ReactivePowerUnits.MVAr ],
                    reactivePowerUnitIndex: 0,
                    reactivePowerUnitValue: void 0,
                    powerUnits: [ l.W, l.kW, l.MW, l.HP, l.VA, l.kVA, l.MVA, l.VAr, l.kVAr, l.MVAr ],
                    powerUnitIndex: 0,
                    powerUnitValue: void 0,
                    loadUnits: [ l.W, l.kW, l.A, l.HP, l.VA, l.kVA, l.MVA, l.VAr, l.kVAr, l.MVAr ],
                    loadUnitIndex: 0,
                    loadUnitValue: void 0,
                    discontinuousLoadUnits: [ l.W, l.kW, l.A, l.HP ],
                    discontinuousLoadUnitIndex: 0,
                    discontinuousLoadUnitValue: void 0
                };
            },
            methods: {
                getActivePowerUnitValue: function() {
                    return (0, a.unitConvert)(this.activePowerUnitValue, this.activePowerUnits[this.activePowerUnitIndex], o.ActivePowerUnits.W);
                },
                getApparentPowerUnitValue: function() {
                    return (0, a.unitConvert)(this.apparentPowerUnitValue, this.apparentPowerUnits[this.apparentPowerUnitIndex], o.ApparentPowerUnits.VA);
                },
                getReactivePowerUnitValue: function() {
                    return (0, a.unitConvert)(this.reactivePowerUnitValue, this.reactivePowerUnits[this.reactivePowerUnitIndex], o.ReactivePowerUnits.VAr);
                },
                getPowerUnitValue: function() {
                    return (0, a.unitConvert)(this.powerUnitValue, this.powerUnits[this.powerUnitIndex], l.W);
                },
                getLoadUnitValue: function() {
                    return (0, a.unitConvert)(this.loadUnitValue, this.loadUnits[this.loadUnitIndex], l.W);
                },
                getDiscontinuousLoadUnitValue: function() {
                    return (0, a.unitConvert)(this.discontinuousLoadUnitValue, this.discontinuousLoadUnits[this.discontinuousLoadUnitIndex], l.W);
                },
                getLoadCurrent: function(e, t, n) {
                    var r = (0, o.toPowerType)(this.loadUnits[this.loadUnitIndex].name), i = this.getLoadUnitValue(), a = (0, 
                    c.calculateVoltagePower)(e, t, i, r, n);
                    return [ c.CurrentUnits.mA.name, c.CurrentUnits.A.name, c.CurrentUnits.kA.name ].includes(r) && (a = i), 
                    a;
                },
                getDiscontinuousLoadCurrent: function(e, t, n) {
                    var r = (0, o.toPowerType)(this.discontinuousLoadUnits[this.discontinuousLoadUnitIndex].name), i = this.getDiscontinuousLoadUnitValue(), a = (0, 
                    c.calculateVoltagePower)(e, t, i, r, n);
                    return [ c.CurrentUnits.mA.name, c.CurrentUnits.A.name, c.CurrentUnits.kA.name ].includes(r) && (a = i), 
                    a;
                }
            }
        };
        t.default = p;
    },
    "3e17": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e, t) {
            var n = null;
            switch (e) {
              case o.ElectricalSpecifications.IEC:
                n = function(e) {
                    e.cableCoreAreaType = o.ElectricalSpecifications.IEC, e.temperature = 80, e.cableCoreType = e.layingMode.isSingleCore ? a.CableCoreType.SINGLE_CORE : a.CableCoreType.MULTI_CORE;
                    var t, n = h.IEC, r = e.isEnabled ? 0 : 3, i = d(e, n, e.length), u = i.length, p = 7 * e.current / 100 + e.current, f = null, m = 0;
                    for (t = 1; t < 101; t++) {
                        for (var v = !1, y = 0; y < u; y++) if (!(y < r) && !(i[y].label > e.maximumAllowableCableCoreArea) && (e.cableCoreAreaIndex = y, 
                        (m = (0, c.calculate)(e.cableCoreAreaType, e) * t) > p)) {
                            var _ = g(e, n, y, e.length).voltage_drop_rate / t;
                            if (_ <= e.voltageDropRateValue) {
                                (f = i[y]).multiple = t, f.voltage_drop_rate = _, f.voltage_drop = e.voltageValue * f.voltage_drop_rate / 100, 
                                f.voltage_load = e.voltageValue - f.voltage_drop, m /= t, v = !0;
                                break;
                            }
                        }
                        if (v) break;
                    }
                    if (t > 100) throw new Error("检查输入的值！");
                    var T = {
                        params: e,
                        collection: i,
                        finalCableCoreArea: f,
                        cableCoreArea: f.label + " mm²",
                        cableCoreAreaCentre: "",
                        groundingWireSize: "",
                        currentRating: (0, s.unitFormatTo)(parseFloat((m * f.multiple).toFixed(2)), l.CurrentUnits.A, l.CurrentUnits.A),
                        current: e.current,
                        voltageDropRate: f.voltage_drop_rate,
                        voltageLoad: f.voltage_load ? f.voltage_load : 0
                    };
                    if (f.multiple > 1 && (m = (0, s.formatDouble)(m, 2), T.cableCoreArea = f.multiple + " x " + T.cableCoreArea, 
                    T.currentRating = T.currentRating + " (".concat(f.multiple, " x ").concat(m, " ").concat(l.CurrentUnits.A.name, ")")), 
                    f.index <= 8) T.groundingWireSize = T.cableCoreArea; else if (f.index > 10) if (f.multiple > 1) {
                        var w = Math.ceil(f.multiple / 2);
                        T.groundingWireSize = w > 1 ? w + " x " + f.label + " mm²" : f.label + " mm²";
                    } else {
                        var E = f.label / 2, b = i.findIndex(function(e) {
                            return e.label >= E;
                        });
                        T.groundingWireSize = i[b].label + " mm²";
                    } else if (f.multiple > 1) {
                        var C = Math.ceil(f.multiple / 2);
                        T.groundingWireSize = C > 1 ? C + " x " + f.label + " mm²" : f.label + " mm²";
                    } else T.groundingWireSize = i[f.index - 1].label + " mm²";
                    switch (e.currentType) {
                      case l.CurrentType.DIRECT_CURRENT:
                        T.cableCoreAreaCentre = "", T.groundingWireSize = "";
                        break;

                      case l.CurrentType.SINGLE_PHASE_CURRENT:
                        T.cableCoreAreaCentre = T.cableCoreArea;
                        break;

                      case l.CurrentType.TWO_PHASE_CURRENT:
                        T.cableCoreAreaCentre = "-";
                        break;

                      case l.CurrentType.THREE_PHASE_CURRENT:
                        T.cableCoreAreaCentre = T.groundingWireSize;
                    }
                    return T;
                }(t);
                break;

              case o.ElectricalSpecifications.NEC:
                n = function(e) {
                    e.cableCoreAreaType = o.ElectricalSpecifications.NEC, e.temperature = o.InsulatedConductorConfig.NEC.maximumOperatingTemperature[e.layingMode.identifier][e.maximumOperatingTemperatureIndex], 
                    e.temperature = parseInt(e.temperature.substring(0, 2)), e.cableCoreType = a.CableCoreType.SINGLE_CORE;
                    var t, n = o.InsulatedConductorConfig.NEC.cableCoreArea[e.layingMode.identifier], r = d(e, n, e.length), i = r.length, u = 7 * e.current / 100 + e.current, f = null, h = 0, m = r.findIndex(function(t) {
                        return e.maximumAllowableCableCoreArea === t.label;
                    });
                    for (t = 1; t < 101; t++) {
                        for (var v = !1, y = 0; y < i; y++) if (e.cableCoreAreaIndex = y, h = (0, c.calculate)(e.cableCoreAreaType, e) * t, 
                        !(y > m) && h > u) {
                            var _ = g(e, n, y, e.length).voltage_drop_rate / t;
                            if (_ <= e.voltageDropRateValue) {
                                (f = r[y]).multiple = t, f.voltage_drop_rate = _, f.voltage_drop = e.voltageValue * f.voltage_drop_rate / 100, 
                                f.voltage_load = e.voltageValue - f.voltage_drop, h /= t, v = !0;
                                break;
                            }
                        }
                        if (v) break;
                    }
                    if (t > 100) throw new Error("检查输入的值！");
                    var T = (0, s.formatDouble)((0, p.awg2squareMillieter)(f.label.replace(/ [a-z]+$/, "")) * f.multiple, 1);
                    h = (0, s.formatDouble)(h, 2);
                    var w = {
                        params: e,
                        collection: r,
                        finalCableCoreArea: f,
                        cableCoreArea: f.label + "\n" + T + " mm²",
                        cableCoreAreaCentre: "",
                        groundingWireSize: "",
                        currentRating: (0, s.unitFormatTo)(parseFloat((h * f.multiple).toFixed(2)), l.CurrentUnits.A, l.CurrentUnits.A),
                        voltageDropRate: f.voltage_drop_rate,
                        voltageLoad: f.voltage_load ? f.voltage_load : 0
                    };
                    return f.multiple > 1 && (h = (0, s.formatDouble)(h, 2), w.cableCoreArea = f.multiple + " x " + w.cableCoreArea, 
                    w.currentRating = w.currentRating + " (".concat(f.multiple, " x ").concat(h, " ").concat(l.CurrentUnits.A.name, ")")), 
                    w;
                }(t);
                break;

              default:
                throw new Error("无效的计算类型");
            }
            return {
                cableCoreArea: n.cableCoreArea,
                cableCoreAreaCentre: n.cableCoreAreaCentre,
                groundingWireSize: n.groundingWireSize,
                current: (0, s.unitFormatTo)(parseFloat(t.current.toFixed(2)), l.CurrentUnits.A, l.CurrentUnits.A),
                currentRating: n.currentRating,
                voltageDropRate: (0, s.formatDouble)(n.voltageDropRate, 3) + "%",
                voltageLoad: (0, s.unitFormatTo)(parseFloat(n.voltageLoad.toFixed(2)), u.VoltageUnits.V, u.VoltageUnits.V)
            };
        };
        var i = r(n("9523")), o = n("9bc7"), a = n("9a2b"), c = n("e827"), s = n("00cd"), u = n("0db1"), l = n("d055"), p = n("7325");
        function f(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        var h = {
            IEC: [ .5, .75, 1, 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500, 630 ],
            NEC: [ "28 awg", "26 awg", "24 awg", "22 awg", "20 awg", "18 awg", "16 awg", "14 awg", "12 awg", "10 awg", "8 awg", "6 awg", "4 awg", "3 awg", "2 awg", "1 awg", "1/0 awg", "2/0 awg", "3/0 awg", "4/0 awg", "250 kcmil", "300 kcmil", "350 kcmil", "400 kcmil", "500 kcmil", "600 kcmil", "700 kcmil", "750 kcmil", "800 kcmil", "900 kcmil", "1000 kcmil", "1250 kcmil", "1500 kcmil", "1750 kcmil", "2000 kcmil" ]
        };
        function d(e, t, n) {
            var r = [];
            return t.forEach(function(o, a) {
                var c = g(e, t, a, n);
                r.push(function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? f(Object(n), !0).forEach(function(t) {
                            (0, i.default)(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({
                    index: a,
                    label: o
                }, c));
            }), r;
        }
        function g(e, t, n, r) {
            var i = (0, a.calculateReactance)(e.cableCoreAreaType, n, e.cableCoreType, 1, e.conductorNumber), o = (0, 
            a.calculateResistance)(e.cableCoreAreaType, n, e.material, 1, e.conductorNumber, e.temperature, e.currentType), c = (0, 
            a.calculateMaximumCableLength)(e.currentType, e.current, e.voltageValue, o, i, e.voltageDropValue, e.triangleCollection), u = (0, 
            a.calculateVoltageDrop)(e.currentType, e.current, e.voltageValue, o, i, r, e.triangleCollection, !1);
            return {
                index: n,
                label: t[n],
                length: parseFloat((0, s.formatDouble)(1e3 * c, 2)),
                voltage_drop_rate: u.voltage_drop_rate,
                voltage_drop: u.voltage_drop,
                voltage_load: u.voltage_load,
                multiple: 1
            };
        }
    },
    "435a": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    switch (c(e, o), e) {
                      case i.CurrentType.DIRECT_CURRENT:
                        s = t / n;
                        break;

                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = t * o[a.TrigonometricType.COS] / n;
                    }
                    return s;
                }(e.currentType, e.voltageValue, e.currentValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_POWER:
                t = function(e, t, n, o, s) {
                    var u = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    switch (c(e, s), e) {
                      case i.CurrentType.DIRECT_CURRENT:
                        u = Math.pow(t, 2) / n;
                        break;

                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        u = "P" === o ? Math.pow(t, 2) * Math.pow(s[a.TrigonometricType.COS], 2) / n : "S" === o ? Math.pow(t, 2) * s[a.TrigonometricType.COS] / n : Math.pow(t, 2) * s[a.TrigonometricType.SIN] * s[a.TrigonometricType.COS] / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        u = "P" === o ? Math.sqrt(3) * Math.pow(t, 2) * Math.pow(s[a.TrigonometricType.COS], 2) / n : "S" === o ? Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.COS] / n : Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.SIN] * s[a.TrigonometricType.COS] / n;
                    }
                    return u;
                }(e.currentType, e.voltageValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_POWER:
                t = function(e, t, n, o, s) {
                    var u = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    switch (c(e, s), e) {
                      case i.CurrentType.DIRECT_CURRENT:
                        u = n / Math.pow(t, 2);
                        break;

                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        if ("P" === o) u = n / Math.pow(t, 2); else if ("S" === o) u = n * s[a.TrigonometricType.COS] / Math.pow(t, 2); else {
                            if (0 === s[a.TrigonometricType.SIN]) throw new Error("∞");
                            u = n * s[a.TrigonometricType.COS] / (Math.pow(t, 2) * s[a.TrigonometricType.SIN]);
                        }
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        if ("P" === o) u = n / (Math.sqrt(3) * Math.pow(t, 2)); else if ("S" === o) u = n * s[a.TrigonometricType.COS] / (Math.sqrt(3) * Math.pow(t, 2)); else {
                            if (0 === s[a.TrigonometricType.SIN]) throw new Error("∞");
                            u = n * s[a.TrigonometricType.COS] / (Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.SIN]);
                        }
                    }
                    return u;
                }(e.currentType, e.currentValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case o.InputTerminal.IMPEDANCE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("阻抗数值无效");
                    switch (c(e, n), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t * n[a.TrigonometricType.COS];
                    }
                    return o;
                }(e.currentType, e.impedanceValue, e.triangleCollection);
            }
            return t;
        };
        var r = n("d417"), i = n("d055"), o = n("1c29"), a = n("2e64");
        function c(e, t) {
            if (e !== i.CurrentType.DIRECT_CURRENT && t.type === a.TrigonometricType.COS && 0 === t[a.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
    },
    "448a": function(e, t, n) {
        var r = n("2236"), i = n("11b0"), o = n("6613"), a = n("0676");
        e.exports = function(e) {
            return r(e) || i(e) || o(e) || a();
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "4a4b": function(e, t) {
        function n(t, r) {
            return e.exports = n = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                return e.__proto__ = t, e;
            }, e.exports.__esModule = !0, e.exports.default = e.exports, n(t, r);
        }
        e.exports = n, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "4ea4": function(e, t) {
        e.exports = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    5223: function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ShortCurrent = void 0, t.calculateLeastValueLL = function(e, t, n, r, i) {
            return .8 * e * r * i / (1.5 * n * 2 * t);
        }, t.calculateLeastValueLN = function(e, t, n, r, i, o, a) {
            var c = r * i / (o * a);
            return .8 * e * r / (1.5 * Math.sqrt(3) * n * (c + 1) * t);
        }, t.calculateMaximumResistance = function(e, t, n) {
            var r = 1.05 * e / (Math.sqrt(3) * t), i = Math.sin(n[a.TrigonometricType.RAD]) * r;
            return new c(r * n[a.TrigonometricType.COS], i);
        }, t.calculateMaximumValue = function(e, t, n) {
            return 1.05 * e / (Math.sqrt(3) * Math.sqrt(Math.pow(t, 2) + Math.pow(n, 2)));
        };
        var i = r(n("5bc3")), o = r(n("970b")), a = n("2e64"), c = (0, i.default)(function e(t, n) {
            (0, o.default)(this, e), this.resistance = t, this.reactance = n;
        });
        t.ShortCurrent = c;
    },
    5345: function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("3d83")), o = {
                namespaced: !0,
                state: {
                    userInfo: null,
                    newMessageCount: void 0,
                    lastMessageTimeKey: "lastMessageTime",
                    isConversionCode: !1
                },
                getters: {},
                mutations: {
                    setUserInfo: function(e, t) {
                        console.log(t), e.userInfo = Object.assign({}, t);
                    },
                    setIsConversionCode: function(e, t) {
                        e.isConversionCode = t;
                    },
                    setNewMessageCount: function(e, t) {
                        e.newMessageCount = t;
                    },
                    setLastMessageTime: function(t) {
                        e.setStorage({
                            key: t.lastMessageTimeKey,
                            data: i.default.format("yyyy-MM-dd HH:mm:ss")
                        }), t.newMessageCount = 0;
                    }
                },
                actions: {
                    AtmSetUserInfo: function(e, t) {
                        e.commit("setlogin", t);
                    }
                }
            };
            t.default = o;
        }).call(this, n("543d").default);
    },
    "543d": function(e, t, n) {
        "use strict";
        (function(e, r) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.createApp = bt, t.createComponent = Pt, t.createPage = xt, t.createPlugin = Ut, 
            t.createSubpackageApp = kt, t.default = void 0;
            var o, a = i(n("278c")), c = i(n("9523")), s = i(n("b17c")), u = i(n("448a")), l = i(n("7037")), p = n("37dc"), f = i(n("66fd"));
            function h(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(n), !0).forEach(function(t) {
                        (0, c.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", m = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;
            function v() {
                var t, n = e.getStorageSync("uni_id_token") || "", r = n.split(".");
                if (!n || 3 !== r.length) return {
                    uid: null,
                    role: [],
                    permission: [],
                    tokenExpired: 0
                };
                try {
                    t = JSON.parse(function(e) {
                        return decodeURIComponent(o(e).split("").map(function(e) {
                            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
                        }).join(""));
                    }(r[1]));
                } catch (e) {
                    throw new Error("获取当前用户信息出错，详细错误信息为：" + e.message);
                }
                return t.tokenExpired = 1e3 * t.exp, delete t.exp, delete t.iat, t;
            }
            o = "function" != typeof atob ? function(e) {
                if (e = String(e).replace(/[\t\n\f\r ]+/g, ""), !m.test(e)) throw new Error("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
                var t;
                e += "==".slice(2 - (3 & e.length));
                for (var n, r, i = "", o = 0; o < e.length; ) t = g.indexOf(e.charAt(o++)) << 18 | g.indexOf(e.charAt(o++)) << 12 | (n = g.indexOf(e.charAt(o++))) << 6 | (r = g.indexOf(e.charAt(o++))), 
                i += 64 === n ? String.fromCharCode(t >> 16 & 255) : 64 === r ? String.fromCharCode(t >> 16 & 255, t >> 8 & 255) : String.fromCharCode(t >> 16 & 255, t >> 8 & 255, 255 & t);
                return i;
            } : atob;
            var y = Object.prototype.toString, _ = Object.prototype.hasOwnProperty;
            function T(e) {
                return "function" == typeof e;
            }
            function w(e) {
                return "string" == typeof e;
            }
            function E(e) {
                return "[object Object]" === y.call(e);
            }
            function b(e, t) {
                return _.call(e, t);
            }
            function C() {}
            function A(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            var S = /-(\w)/g, R = A(function(e) {
                return e.replace(S, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            });
            function N(e) {
                var t = {};
                return E(e) && Object.keys(e).sort().forEach(function(n) {
                    t[n] = e[n];
                }), Object.keys(t) ? t : e;
            }
            var O = [ "invoke", "success", "fail", "complete", "returnValue" ], I = {}, x = {};
            function P(e, t) {
                Object.keys(t).forEach(function(n) {
                    -1 !== O.indexOf(n) && T(t[n]) && (e[n] = function(e, t) {
                        var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                        return n ? function(e) {
                            for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                            return t;
                        }(n) : n;
                    }(e[n], t[n]));
                });
            }
            function k(e, t) {
                e && t && Object.keys(t).forEach(function(n) {
                    -1 !== O.indexOf(n) && T(t[n]) && function(e, t) {
                        var n = e.indexOf(t);
                        -1 !== n && e.splice(n, 1);
                    }(e[n], t[n]);
                });
            }
            function U(e, t) {
                return function(n) {
                    return e(n, t) || n;
                };
            }
            function M(e) {
                return !!e && ("object" === (0, l.default)(e) || "function" == typeof e) && "function" == typeof e.then;
            }
            function V(e, t, n) {
                for (var r = !1, i = 0; i < e.length; i++) {
                    var o = e[i];
                    if (r) r = Promise.resolve(U(o, n)); else {
                        var a = o(t, n);
                        if (M(a) && (r = Promise.resolve(a)), !1 === a) return {
                            then: function() {}
                        };
                    }
                }
                return r || {
                    then: function(e) {
                        return e(t);
                    }
                };
            }
            function H(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return [ "success", "fail", "complete" ].forEach(function(n) {
                    if (Array.isArray(e[n])) {
                        var r = t[n];
                        t[n] = function(i) {
                            V(e[n], i, t).then(function(e) {
                                return T(r) && r(e) || e;
                            });
                        };
                    }
                }), t;
            }
            function D(e, t) {
                var n = [];
                Array.isArray(I.returnValue) && n.push.apply(n, (0, u.default)(I.returnValue));
                var r = x[e];
                return r && Array.isArray(r.returnValue) && n.push.apply(n, (0, u.default)(r.returnValue)), 
                n.forEach(function(e) {
                    t = e(t) || t;
                }), t;
            }
            function L(e) {
                var t = Object.create(null);
                Object.keys(I).forEach(function(e) {
                    "returnValue" !== e && (t[e] = I[e].slice());
                });
                var n = x[e];
                return n && Object.keys(n).forEach(function(e) {
                    "returnValue" !== e && (t[e] = (t[e] || []).concat(n[e]));
                }), t;
            }
            function j(e, t, n) {
                for (var r = arguments.length, i = new Array(r > 3 ? r - 3 : 0), o = 3; o < r; o++) i[o - 3] = arguments[o];
                var a = L(e);
                if (a && Object.keys(a).length) {
                    if (Array.isArray(a.invoke)) {
                        var c = V(a.invoke, n);
                        return c.then(function(n) {
                            return t.apply(void 0, [ H(L(e), n) ].concat(i));
                        });
                    }
                    return t.apply(void 0, [ H(a, n) ].concat(i));
                }
                return t.apply(void 0, [ n ].concat(i));
            }
            var $ = {
                returnValue: function(e) {
                    return M(e) ? new Promise(function(t, n) {
                        e.then(function(e) {
                            e[0] ? n(e[0]) : t(e[1]);
                        });
                    }) : e;
                }
            }, F = /^\$|Window$|WindowStyle$|sendHostEvent|sendNativeEvent|restoreGlobal|requireGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64|getLocale|setLocale|invokePushCallback|getWindowInfo|getDeviceInfo|getAppBaseInfo|getSystemSetting|getAppAuthorizeSetting|initUTS|requireUTS|registerUTS/, B = /^create|Manager$/, W = [ "createBLEConnection" ], z = [ "createBLEConnection", "createPushMessage" ], q = /^on|^off/;
            function G(e) {
                return B.test(e) && -1 === W.indexOf(e);
            }
            function K(e) {
                return F.test(e) && -1 === z.indexOf(e);
            }
            function X(e) {
                return e.then(function(e) {
                    return [ null, e ];
                }).catch(function(e) {
                    return [ e ];
                });
            }
            function J(e, t) {
                return function(e) {
                    return !(G(e) || K(e) || function(e) {
                        return q.test(e) && "onPush" !== e;
                    }(e));
                }(e) && T(t) ? function() {
                    for (var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
                    return T(n.success) || T(n.fail) || T(n.complete) ? D(e, j.apply(void 0, [ e, t, n ].concat(i))) : D(e, X(new Promise(function(r, o) {
                        j.apply(void 0, [ e, t, Object.assign({}, n, {
                            success: r,
                            fail: o
                        }) ].concat(i));
                    })));
                } : t;
            }
            Promise.prototype.finally || (Promise.prototype.finally = function(e) {
                var t = this.constructor;
                return this.then(function(n) {
                    return t.resolve(e()).then(function() {
                        return n;
                    });
                }, function(n) {
                    return t.resolve(e()).then(function() {
                        throw n;
                    });
                });
            });
            var Z, Y = !1, Q = 0, ee = 0, te = {};
            Z = ie(e.getSystemInfoSync().language) || "en", function() {
                if ("undefined" != typeof __uniConfig && __uniConfig.locales && Object.keys(__uniConfig.locales).length) {
                    var e = Object.keys(__uniConfig.locales);
                    e.length && e.forEach(function(e) {
                        var t = te[e], n = __uniConfig.locales[e];
                        t ? Object.assign(t, n) : te[e] = n;
                    });
                }
            }();
            var ne = (0, p.initVueI18n)(Z, {}), re = ne.t;
            function ie(e, t) {
                if (e) return e = e.trim().replace(/_/g, "-"), t && t[e] ? e : "chinese" === (e = e.toLowerCase()) ? "zh-Hans" : 0 === e.indexOf("zh") ? e.indexOf("-hans") > -1 ? "zh-Hans" : e.indexOf("-hant") > -1 || function(e, t) {
                    return !![ "-tw", "-hk", "-mo", "-cht" ].find(function(t) {
                        return -1 !== e.indexOf(t);
                    });
                }(e) ? "zh-Hant" : "zh-Hans" : function(e, t) {
                    return [ "en", "fr", "es" ].find(function(t) {
                        return 0 === e.indexOf(t);
                    });
                }(e) || void 0;
            }
            function oe() {
                if (T(getApp)) {
                    var t = getApp({
                        allowDefault: !0
                    });
                    if (t && t.$vm) return t.$vm.$locale;
                }
                return ie(e.getSystemInfoSync().language) || "en";
            }
            ne.mixin = {
                beforeCreate: function() {
                    var e = this, t = ne.i18n.watchLocale(function() {
                        e.$forceUpdate();
                    });
                    this.$once("hook:beforeDestroy", function() {
                        t();
                    });
                },
                methods: {
                    $$t: function(e, t) {
                        return re(e, t);
                    }
                }
            }, ne.setLocale, ne.getLocale;
            var ae = [];
            void 0 !== r && (r.getLocale = oe);
            var ce, se = {
                promiseInterceptor: $
            }, ue = Object.freeze({
                __proto__: null,
                upx2px: function(t, n) {
                    if (0 === Q && function() {
                        var t = e.getSystemInfoSync(), n = t.platform, r = t.pixelRatio, i = t.windowWidth;
                        Q = i, ee = r, Y = "ios" === n;
                    }(), 0 === (t = Number(t))) return 0;
                    var r = t / 750 * (n || Q);
                    return r < 0 && (r = -r), 0 === (r = Math.floor(r + 1e-4)) && (r = 1 !== ee && Y ? .5 : 1), 
                    t < 0 ? -r : r;
                },
                getLocale: oe,
                setLocale: function(e) {
                    var t = !!T(getApp) && getApp();
                    return !!t && t.$vm.$locale !== e && (t.$vm.$locale = e, ae.forEach(function(t) {
                        return t({
                            locale: e
                        });
                    }), !0);
                },
                onLocaleChange: function(e) {
                    -1 === ae.indexOf(e) && ae.push(e);
                },
                addInterceptor: function(e, t) {
                    "string" == typeof e && E(t) ? P(x[e] || (x[e] = {}), t) : E(e) && P(I, e);
                },
                removeInterceptor: function(e, t) {
                    "string" == typeof e ? E(t) ? k(x[e], t) : delete x[e] : E(e) && k(I, e);
                },
                interceptors: se
            });
            function le(t) {
                (ce = ce || e.getStorageSync("__DC_STAT_UUID")) || (ce = Date.now() + "" + Math.floor(1e7 * Math.random()), 
                e.setStorage({
                    key: "__DC_STAT_UUID",
                    data: ce
                })), t.deviceId = ce;
            }
            function pe(e) {
                if (e.safeArea) {
                    var t = e.safeArea;
                    e.safeAreaInsets = {
                        top: t.top,
                        left: t.left,
                        right: e.windowWidth - t.right,
                        bottom: e.screenHeight - t.bottom
                    };
                }
            }
            function fe(e, t) {
                for (var n = e.deviceType || "phone", r = {
                    ipad: "pad",
                    windows: "pc",
                    mac: "pc"
                }, i = Object.keys(r), o = t.toLocaleLowerCase(), a = 0; a < i.length; a++) {
                    var c = i[a];
                    if (-1 !== o.indexOf(c)) {
                        n = r[c];
                        break;
                    }
                }
                return n;
            }
            function he(e) {
                var t = e;
                return t && (t = e.toLocaleLowerCase()), t;
            }
            function de(e) {
                return oe ? oe() : e;
            }
            function ge(e) {
                var t = e.hostName || "WeChat";
                return e.environment ? t = e.environment : e.host && e.host.env && (t = e.host.env), 
                t;
            }
            var me = {
                returnValue: function(e) {
                    le(e), pe(e), function(e) {
                        var t, n = e.brand, r = void 0 === n ? "" : n, i = e.model, o = void 0 === i ? "" : i, a = e.system, c = void 0 === a ? "" : a, s = e.language, u = void 0 === s ? "" : s, l = e.theme, p = e.version, f = (e.platform, 
                        e.fontSizeSetting), h = e.SDKVersion, d = e.pixelRatio, g = e.deviceOrientation, m = "";
                        m = c.split(" ")[0] || "", t = c.split(" ")[1] || "";
                        var v = p, y = fe(e, o), _ = he(r), T = ge(e), w = g, E = d, b = h, C = u.replace(/_/g, "-"), A = {
                            appId: "__UNI__CBD8613",
                            appName: "电工大师",
                            appVersion: "1.2.0",
                            appVersionCode: "120",
                            appLanguage: de(C),
                            uniCompileVersion: "3.8.7",
                            uniRuntimeVersion: "3.8.7",
                            uniPlatform: "mp-weixin",
                            deviceBrand: _,
                            deviceModel: o,
                            deviceType: y,
                            devicePixelRatio: E,
                            deviceOrientation: w,
                            osName: m.toLocaleLowerCase(),
                            osVersion: t,
                            hostTheme: l,
                            hostVersion: v,
                            hostLanguage: C,
                            hostName: T,
                            hostSDKVersion: b,
                            hostFontSizeSetting: f,
                            windowTop: 0,
                            windowBottom: 0,
                            osLanguage: void 0,
                            osTheme: void 0,
                            ua: void 0,
                            hostPackageName: void 0,
                            browserName: void 0,
                            browserVersion: void 0
                        };
                        Object.assign(e, A, {});
                    }(e);
                }
            }, ve = {
                redirectTo: {
                    name: function(e) {
                        return "back" === e.exists && e.delta ? "navigateBack" : "redirectTo";
                    },
                    args: function(e) {
                        if ("back" === e.exists && e.url) {
                            var t = function(e) {
                                for (var t = getCurrentPages(), n = t.length; n--; ) {
                                    var r = t[n];
                                    if (r.$page && r.$page.fullPath === e) return n;
                                }
                                return -1;
                            }(e.url);
                            if (-1 !== t) {
                                var n = getCurrentPages().length - 1 - t;
                                n > 0 && (e.delta = n);
                            }
                        }
                    }
                },
                previewImage: {
                    args: function(e) {
                        var t = parseInt(e.current);
                        if (!isNaN(t)) {
                            var n = e.urls;
                            if (Array.isArray(n)) {
                                var r = n.length;
                                if (r) return t < 0 ? t = 0 : t >= r && (t = r - 1), t > 0 ? (e.current = n[t], 
                                e.urls = n.filter(function(e, r) {
                                    return !(r < t) || e !== n[t];
                                })) : e.current = n[0], {
                                    indicator: !1,
                                    loop: !1
                                };
                            }
                        }
                    }
                },
                getSystemInfo: me,
                getSystemInfoSync: me,
                showActionSheet: {
                    args: function(e) {
                        "object" === (0, l.default)(e) && (e.alertText = e.title);
                    }
                },
                getAppBaseInfo: {
                    returnValue: function(e) {
                        var t = e, n = t.version, r = t.language, i = t.SDKVersion, o = t.theme, a = ge(e), c = r.replace("_", "-");
                        e = N(Object.assign(e, {
                            appId: "__UNI__CBD8613",
                            appName: "电工大师",
                            appVersion: "1.2.0",
                            appVersionCode: "120",
                            appLanguage: de(c),
                            hostVersion: n,
                            hostLanguage: c,
                            hostName: a,
                            hostSDKVersion: i,
                            hostTheme: o
                        }));
                    }
                },
                getDeviceInfo: {
                    returnValue: function(e) {
                        var t = e, n = t.brand, r = t.model, i = fe(e, r), o = he(n);
                        le(e), e = N(Object.assign(e, {
                            deviceType: i,
                            deviceBrand: o,
                            deviceModel: r
                        }));
                    }
                },
                getWindowInfo: {
                    returnValue: function(e) {
                        pe(e), e = N(Object.assign(e, {
                            windowTop: 0,
                            windowBottom: 0
                        }));
                    }
                },
                getAppAuthorizeSetting: {
                    returnValue: function(e) {
                        var t = e.locationReducedAccuracy;
                        e.locationAccuracy = "unsupported", !0 === t ? e.locationAccuracy = "reduced" : !1 === t && (e.locationAccuracy = "full");
                    }
                },
                compressImage: {
                    args: function(e) {
                        e.compressedHeight && !e.compressHeight && (e.compressHeight = e.compressedHeight), 
                        e.compressedWidth && !e.compressWidth && (e.compressWidth = e.compressedWidth);
                    }
                }
            }, ye = [ "success", "fail", "cancel", "complete" ];
            function _e(e, t, n) {
                return function(r) {
                    return t(we(e, r, n));
                };
            }
            function Te(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
                if (E(t)) {
                    var o = !0 === i ? t : {};
                    for (var a in T(n) && (n = n(t, o) || {}), t) if (b(n, a)) {
                        var c = n[a];
                        T(c) && (c = c(t[a], t, o)), c ? w(c) ? o[c] = t[a] : E(c) && (o[c.name ? c.name : a] = c.value) : console.warn("The '".concat(e, "' method of platform '微信小程序' does not support option '").concat(a, "'"));
                    } else -1 !== ye.indexOf(a) ? T(t[a]) && (o[a] = _e(e, t[a], r)) : i || (o[a] = t[a]);
                    return o;
                }
                return T(t) && (t = _e(e, t, r)), t;
            }
            function we(e, t, n) {
                var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return T(ve.returnValue) && (t = ve.returnValue(e, t)), Te(e, t, n, {}, r);
            }
            function Ee(t, n) {
                if (b(ve, t)) {
                    var r = ve[t];
                    return r ? function(n, i) {
                        var o = r;
                        T(r) && (o = r(n));
                        var a = [ n = Te(t, n, o.args, o.returnValue) ];
                        void 0 !== i && a.push(i), T(o.name) ? t = o.name(n) : w(o.name) && (t = o.name);
                        var c = e[t].apply(e, a);
                        return K(t) ? we(t, c, o.returnValue, G(t)) : c;
                    } : function() {
                        console.error("Platform '微信小程序' does not support '".concat(t, "'."));
                    };
                }
                return n;
            }
            var be = Object.create(null);
            [ "onTabBarMidButtonTap", "subscribePush", "unsubscribePush", "onPush", "offPush", "share" ].forEach(function(e) {
                be[e] = function(e) {
                    return function(t) {
                        var n = t.fail, r = t.complete, i = {
                            errMsg: "".concat(e, ":fail method '").concat(e, "' not supported")
                        };
                        T(n) && n(i), T(r) && r(i);
                    };
                }(e);
            });
            var Ce = {
                oauth: [ "weixin" ],
                share: [ "weixin" ],
                payment: [ "wxpay" ],
                push: [ "weixin" ]
            }, Ae = Object.freeze({
                __proto__: null,
                getProvider: function(e) {
                    var t = e.service, n = e.success, r = e.fail, i = e.complete, o = !1;
                    Ce[t] ? (o = {
                        errMsg: "getProvider:ok",
                        service: t,
                        provider: Ce[t]
                    }, T(n) && n(o)) : (o = {
                        errMsg: "getProvider:fail service not found"
                    }, T(r) && r(o)), T(i) && i(o);
                }
            }), Se = function() {
                var e;
                return function() {
                    return e || (e = new f.default()), e;
                };
            }();
            function Re(e, t, n) {
                return e[t].apply(e, n);
            }
            var Ne, Oe, Ie, xe = Object.freeze({
                __proto__: null,
                $on: function() {
                    return Re(Se(), "$on", Array.prototype.slice.call(arguments));
                },
                $off: function() {
                    return Re(Se(), "$off", Array.prototype.slice.call(arguments));
                },
                $once: function() {
                    return Re(Se(), "$once", Array.prototype.slice.call(arguments));
                },
                $emit: function() {
                    return Re(Se(), "$emit", Array.prototype.slice.call(arguments));
                }
            });
            function Pe(e) {
                return function() {
                    try {
                        return e.apply(e, arguments);
                    } catch (e) {
                        console.error(e);
                    }
                };
            }
            function ke(e) {
                try {
                    return JSON.parse(e);
                } catch (e) {}
                return e;
            }
            var Ue = [];
            function Me(e, t) {
                Ue.forEach(function(n) {
                    n(e, t);
                }), Ue.length = 0;
            }
            var Ve = [], He = e.getAppBaseInfo && e.getAppBaseInfo();
            He || (He = e.getSystemInfoSync());
            var De = He ? He.host : null, Le = De && "SAAASDK" === De.env ? e.miniapp.shareVideoMessage : e.shareVideoMessage, je = Object.freeze({
                __proto__: null,
                shareVideoMessage: Le,
                getPushClientId: function(e) {
                    E(e) || (e = {});
                    var t = function(e) {
                        var t = {};
                        for (var n in e) {
                            var r = e[n];
                            T(r) && (t[n] = Pe(r), delete e[n]);
                        }
                        return t;
                    }(e), n = t.success, r = t.fail, i = t.complete, o = T(n), a = T(r), c = T(i);
                    Promise.resolve().then(function() {
                        void 0 === Ie && (Ie = !1, Ne = "", Oe = "uniPush is not enabled"), Ue.push(function(e, t) {
                            var s;
                            e ? (s = {
                                errMsg: "getPushClientId:ok",
                                cid: e
                            }, o && n(s)) : (s = {
                                errMsg: "getPushClientId:fail" + (t ? " " + t : "")
                            }, a && r(s)), c && i(s);
                        }), void 0 !== Ne && Me(Ne, Oe);
                    });
                },
                onPushMessage: function(e) {
                    -1 === Ve.indexOf(e) && Ve.push(e);
                },
                offPushMessage: function(e) {
                    if (e) {
                        var t = Ve.indexOf(e);
                        t > -1 && Ve.splice(t, 1);
                    } else Ve.length = 0;
                },
                invokePushCallback: function(e) {
                    if ("enabled" === e.type) Ie = !0; else if ("clientId" === e.type) Ne = e.cid, Oe = e.errMsg, 
                    Me(Ne, e.errMsg); else if ("pushMsg" === e.type) for (var t = {
                        type: "receive",
                        data: ke(e.message)
                    }, n = 0; n < Ve.length && ((0, Ve[n])(t), !t.stopped); n++) ; else "click" === e.type && Ve.forEach(function(t) {
                        t({
                            type: "click",
                            data: ke(e.message)
                        });
                    });
                }
            }), $e = [ "__route__", "__wxExparserNodeId__", "__wxWebviewId__" ];
            function Fe(e) {
                return Behavior(e);
            }
            function Be() {
                return !!this.route;
            }
            function We(e) {
                this.triggerEvent("__l", e);
            }
            function ze(e) {
                var t = e.$scope, n = {};
                Object.defineProperty(e, "$refs", {
                    get: function() {
                        var e = {};
                        return function e(t, n, r) {
                            (t.selectAllComponents(n) || []).forEach(function(t) {
                                var i = t.dataset.ref;
                                r[i] = t.$vm || Ke(t), "scoped" === t.dataset.vueGeneric && t.selectAllComponents(".scoped-ref").forEach(function(t) {
                                    e(t, n, r);
                                });
                            });
                        }(t, ".vue-ref", e), (t.selectAllComponents(".vue-ref-in-for") || []).forEach(function(t) {
                            var n = t.dataset.ref;
                            e[n] || (e[n] = []), e[n].push(t.$vm || Ke(t));
                        }), function(e, t) {
                            var n = (0, s.default)(Set, (0, u.default)(Object.keys(e)));
                            return Object.keys(t).forEach(function(r) {
                                var i = e[r], o = t[r];
                                Array.isArray(i) && Array.isArray(o) && i.length === o.length && o.every(function(e) {
                                    return i.includes(e);
                                }) || (e[r] = o, n.delete(r));
                            }), n.forEach(function(t) {
                                delete e[t];
                            }), e;
                        }(n, e);
                    }
                });
            }
            function qe(e) {
                var t, n = e.detail || e.value, r = n.vuePid, i = n.vueOptions;
                r && (t = function e(t, n) {
                    for (var r, i = t.$children, o = i.length - 1; o >= 0; o--) {
                        var a = i[o];
                        if (a.$scope._$vueId === n) return a;
                    }
                    for (var c = i.length - 1; c >= 0; c--) if (r = e(i[c], n)) return r;
                }(this.$vm, r)), t || (t = this.$vm), i.parent = t;
            }
            function Ge(e) {
                return Object.defineProperty(e, "__v_isMPComponent", {
                    configurable: !0,
                    enumerable: !1,
                    value: !0
                }), e;
            }
            function Ke(e) {
                return function(e) {
                    return null !== e && "object" === (0, l.default)(e);
                }(e) && Object.isExtensible(e) && Object.defineProperty(e, "__ob__", {
                    configurable: !0,
                    enumerable: !1,
                    value: (0, c.default)({}, "__v_skip", !0)
                }), e;
            }
            var Xe = /_(.*)_worklet_factory_/, Je = Page, Ze = Component, Ye = /:/g, Qe = A(function(e) {
                return R(e.replace(Ye, "-"));
            });
            function et(e) {
                var t = e.triggerEvent, n = function(e) {
                    for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) r[i - 1] = arguments[i];
                    if (this.$vm || this.dataset && this.dataset.comType) e = Qe(e); else {
                        var o = Qe(e);
                        o !== e && t.apply(this, [ o ].concat(r));
                    }
                    return t.apply(this, [ e ].concat(r));
                };
                try {
                    e.triggerEvent = n;
                } catch (t) {
                    e._triggerEvent = n;
                }
            }
            function tt(e, t, n) {
                var r = t[e];
                t[e] = function() {
                    if (Ge(this), et(this), r) {
                        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                        return r.apply(this, t);
                    }
                };
            }
            function nt(e, t, n) {
                t.forEach(function(t) {
                    (function e(t, n) {
                        if (!n) return !0;
                        if (f.default.options && Array.isArray(f.default.options[t])) return !0;
                        if (T(n = n.default || n)) return !!T(n.extendOptions[t]) || !!(n.super && n.super.options && Array.isArray(n.super.options[t]));
                        if (T(n[t]) || Array.isArray(n[t])) return !0;
                        var r = n.mixins;
                        return Array.isArray(r) ? !!r.find(function(n) {
                            return e(t, n);
                        }) : void 0;
                    })(t, n) && (e[t] = function(e) {
                        return this.$vm && this.$vm.__call_hook(t, e);
                    });
                });
            }
            function rt(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                it(t).forEach(function(t) {
                    return ot(e, t, n);
                });
            }
            function it(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                return e && Object.keys(e).forEach(function(n) {
                    0 === n.indexOf("on") && T(e[n]) && t.push(n);
                }), t;
            }
            function ot(e, t, n) {
                -1 !== n.indexOf(t) || b(e, t) || (e[t] = function(e) {
                    return this.$vm && this.$vm.__call_hook(t, e);
                });
            }
            function at(e, t) {
                var n;
                return [ n = T(t = t.default || t) ? t : e.extend(t), t = n.options ];
            }
            function ct(e, t) {
                if (Array.isArray(t) && t.length) {
                    var n = Object.create(null);
                    t.forEach(function(e) {
                        n[e] = !0;
                    }), e.$scopedSlots = e.$slots = n;
                }
            }
            function st(e, t) {
                var n = (e = (e || "").split(",")).length;
                1 === n ? t._$vueId = e[0] : 2 === n && (t._$vueId = e[0], t._$vuePid = e[1]);
            }
            function ut(e, t) {
                var n = e.data || {}, r = e.methods || {};
                if ("function" == typeof n) try {
                    n = n.call(t);
                } catch (e) {
                    Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "电工大师",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.warn("根据 Vue 的 data 函数初始化小程序 data 失败，请尽量确保 data 函数中不访问 vm 对象，否则可能影响首次数据渲染速度。", n);
                } else try {
                    n = JSON.parse(JSON.stringify(n));
                } catch (e) {}
                return E(n) || (n = {}), Object.keys(r).forEach(function(e) {
                    -1 !== t.__lifecycle_hooks__.indexOf(e) || b(n, e) || (n[e] = r[e]);
                }), n;
            }
            Je.__$wrappered || (Je.__$wrappered = !0, Page = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return tt("onLoad", e), Je(e);
            }, Page.after = Je.after, Component = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return tt("created", e), Ze(e);
            });
            var lt = [ String, Number, Boolean, Object, Array, null ];
            function pt(e) {
                return function(t, n) {
                    this.$vm && (this.$vm[e] = t);
                };
            }
            function ft(e, t) {
                var n = e.behaviors, r = e.extends, i = e.mixins, o = e.props;
                o || (e.props = o = []);
                var a = [];
                return Array.isArray(n) && n.forEach(function(e) {
                    a.push(e.replace("uni://", "wx".concat("://"))), "uni://form-field" === e && (Array.isArray(o) ? (o.push("name"), 
                    o.push("value")) : (o.name = {
                        type: String,
                        default: ""
                    }, o.value = {
                        type: [ String, Number, Boolean, Array, Object, Date ],
                        default: ""
                    }));
                }), E(r) && r.props && a.push(t({
                    properties: dt(r.props, !0)
                })), Array.isArray(i) && i.forEach(function(e) {
                    E(e) && e.props && a.push(t({
                        properties: dt(e.props, !0)
                    }));
                }), a;
            }
            function ht(e, t, n, r) {
                return Array.isArray(t) && 1 === t.length ? t[0] : t;
            }
            function dt(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = arguments.length > 3 ? arguments[3] : void 0, r = {};
                return t || (r.vueId = {
                    type: String,
                    value: ""
                }, n.virtualHost && (r.virtualHostStyle = {
                    type: null,
                    value: ""
                }, r.virtualHostClass = {
                    type: null,
                    value: ""
                }), r.scopedSlotsCompiler = {
                    type: String,
                    value: ""
                }, r.vueSlots = {
                    type: null,
                    value: [],
                    observer: function(e, t) {
                        var n = Object.create(null);
                        e.forEach(function(e) {
                            n[e] = !0;
                        }), this.setData({
                            $slots: n
                        });
                    }
                }), Array.isArray(e) ? e.forEach(function(e) {
                    r[e] = {
                        type: null,
                        observer: pt(e)
                    };
                }) : E(e) && Object.keys(e).forEach(function(t) {
                    var n = e[t];
                    if (E(n)) {
                        var i = n.default;
                        T(i) && (i = i()), n.type = ht(0, n.type), r[t] = {
                            type: -1 !== lt.indexOf(n.type) ? n.type : null,
                            value: i,
                            observer: pt(t)
                        };
                    } else {
                        var o = ht(0, n);
                        r[t] = {
                            type: -1 !== lt.indexOf(o) ? o : null,
                            observer: pt(t)
                        };
                    }
                }), r;
            }
            function gt(e, t, n, r) {
                var i = {};
                return Array.isArray(t) && t.length && t.forEach(function(t, o) {
                    "string" == typeof t ? t ? "$event" === t ? i["$" + o] = n : "arguments" === t ? i["$" + o] = n.detail && n.detail.__args__ || r : 0 === t.indexOf("$event.") ? i["$" + o] = e.__get_value(t.replace("$event.", ""), n) : i["$" + o] = e.__get_value(t) : i["$" + o] = e : i["$" + o] = function(e, t) {
                        var n = e;
                        return t.forEach(function(t) {
                            var r = t[0], i = t[2];
                            if (r || void 0 !== i) {
                                var o, a = t[1], c = t[3];
                                Number.isInteger(r) ? o = r : r ? "string" == typeof r && r && (o = 0 === r.indexOf("#s#") ? r.substr(3) : e.__get_value(r, n)) : o = n, 
                                Number.isInteger(o) ? n = i : a ? Array.isArray(o) ? n = o.find(function(t) {
                                    return e.__get_value(a, t) === i;
                                }) : E(o) ? n = Object.keys(o).find(function(t) {
                                    return e.__get_value(a, o[t]) === i;
                                }) : console.error("v-for 暂不支持循环数据：", o) : n = o[i], c && (n = e.__get_value(c, n));
                            }
                        }), n;
                    }(e, t);
                }), i;
            }
            function mt(e) {
                for (var t = {}, n = 1; n < e.length; n++) {
                    var r = e[n];
                    t[r[0]] = r[1];
                }
                return t;
            }
            function vt(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [], i = arguments.length > 4 ? arguments[4] : void 0, o = arguments.length > 5 ? arguments[5] : void 0, a = !1, c = E(t.detail) && t.detail.__args__ || [ t.detail ];
                if (i && (a = t.currentTarget && t.currentTarget.dataset && "wx" === t.currentTarget.dataset.comType, 
                !n.length)) return a ? [ t ] : c;
                var s = gt(e, r, t, c), u = [];
                return n.forEach(function(e) {
                    "$event" === e ? "__set_model" !== o || i ? i && !a ? u.push(c[0]) : u.push(t) : u.push(t.target.value) : Array.isArray(e) && "o" === e[0] ? u.push(mt(e)) : "string" == typeof e && b(s, e) ? u.push(s[e]) : u.push(e);
                }), u;
            }
            function yt(e) {
                var t = this, n = ((e = function(e) {
                    try {
                        e.mp = JSON.parse(JSON.stringify(e));
                    } catch (e) {}
                    return e.stopPropagation = C, e.preventDefault = C, e.target = e.target || {}, b(e, "detail") || (e.detail = {}), 
                    b(e, "markerId") && (e.detail = "object" === (0, l.default)(e.detail) ? e.detail : {}, 
                    e.detail.markerId = e.markerId), E(e.detail) && (e.target = Object.assign({}, e.target, e.detail)), 
                    e;
                }(e)).currentTarget || e.target).dataset;
                if (!n) return console.warn("事件信息不存在");
                var r = n.eventOpts || n["event-opts"];
                if (!r) return console.warn("事件信息不存在");
                var i = e.type, o = [];
                return r.forEach(function(n) {
                    var r = n[0], a = n[1], c = "^" === r.charAt(0), s = "~" === (r = c ? r.slice(1) : r).charAt(0);
                    r = s ? r.slice(1) : r, a && function(e, t) {
                        return e === t || "regionchange" === t && ("begin" === e || "end" === e);
                    }(i, r) && a.forEach(function(n) {
                        var r = n[0];
                        if (r) {
                            var i = t.$vm;
                            if (i.$options.generic && (i = function(e) {
                                for (var t = e.$parent; t && t.$parent && (t.$options.generic || t.$parent.$options.generic || t.$scope._$vuePid); ) t = t.$parent;
                                return t && t.$parent;
                            }(i) || i), "$emit" === r) return void i.$emit.apply(i, vt(t.$vm, e, n[1], n[2], c, r));
                            var a = i[r];
                            if (!T(a)) {
                                var u = "page" === t.$vm.mpType ? "Page" : "Component", l = t.route || t.is;
                                throw new Error("".concat(u, ' "').concat(l, '" does not have a method "').concat(r, '"'));
                            }
                            if (s) {
                                if (a.once) return;
                                a.once = !0;
                            }
                            var p = vt(t.$vm, e, n[1], n[2], c, r);
                            p = Array.isArray(p) ? p : [], /=\s*\S+\.eventParams\s*\|\|\s*\S+\[['"]event-params['"]\]/.test(a.toString()) && (p = p.concat([ , , , , , , , , , , e ])), 
                            o.push(a.apply(i, p));
                        }
                    });
                }), "input" === i && 1 === o.length && void 0 !== o[0] ? o[0] : void 0;
            }
            var _t = {}, Tt = [ "onShow", "onHide", "onError", "onPageNotFound", "onThemeChange", "onUnhandledRejection" ];
            function wt(t, n) {
                var r = n.mocks, i = n.initRefs;
                (function() {
                    f.default.prototype.getOpenerEventChannel = function() {
                        return this.$scope.getOpenerEventChannel();
                    };
                    var e = f.default.prototype.__call_hook;
                    f.default.prototype.__call_hook = function(t, n) {
                        return "onLoad" === t && n && n.__id__ && (this.__eventChannel__ = function(e) {
                            var t = _t[e];
                            return delete _t[e], t;
                        }(n.__id__), delete n.__id__), e.call(this, t, n);
                    };
                })(), function() {
                    var e = {}, t = {};
                    function n(e) {
                        var t = this.$options.propsData.vueId;
                        t && e(t.split(",")[0]);
                    }
                    f.default.prototype.$hasSSP = function(n) {
                        var r = e[n];
                        return r || (t[n] = this, this.$on("hook:destroyed", function() {
                            delete t[n];
                        })), r;
                    }, f.default.prototype.$getSSP = function(t, n, r) {
                        var i = e[t];
                        if (i) {
                            var o = i[n] || [];
                            return r ? o : o[0];
                        }
                    }, f.default.prototype.$setSSP = function(t, r) {
                        var i = 0;
                        return n.call(this, function(n) {
                            var o = e[n], a = o[t] = o[t] || [];
                            a.push(r), i = a.length - 1;
                        }), i;
                    }, f.default.prototype.$initSSP = function() {
                        n.call(this, function(t) {
                            e[t] = {};
                        });
                    }, f.default.prototype.$callSSP = function() {
                        n.call(this, function(e) {
                            t[e] && t[e].$forceUpdate();
                        });
                    }, f.default.mixin({
                        destroyed: function() {
                            var n = this.$options.propsData, r = n && n.vueId;
                            r && (delete e[r], delete t[r]);
                        }
                    });
                }(), t.$options.store && (f.default.prototype.$store = t.$options.store), function(e) {
                    e.prototype.uniIDHasRole = function(e) {
                        return v().role.indexOf(e) > -1;
                    }, e.prototype.uniIDHasPermission = function(e) {
                        var t = v().permission;
                        return this.uniIDHasRole("admin") || t.indexOf(e) > -1;
                    }, e.prototype.uniIDTokenValid = function() {
                        return v().tokenExpired > Date.now();
                    };
                }(f.default), f.default.prototype.mpHost = "mp-weixin", f.default.mixin({
                    beforeCreate: function() {
                        if (this.$options.mpType) {
                            if (this.mpType = this.$options.mpType, this.$mp = (0, c.default)({
                                data: {}
                            }, this.mpType, this.$options.mpInstance), this.$scope = this.$options.mpInstance, 
                            delete this.$options.mpType, delete this.$options.mpInstance, "page" === this.mpType && "function" == typeof getApp) {
                                var e = getApp();
                                e.$vm && e.$vm.$i18n && (this._i18n = e.$vm.$i18n);
                            }
                            "app" !== this.mpType && (i(this), function(e, t) {
                                var n = e.$mp[e.mpType];
                                t.forEach(function(t) {
                                    b(n, t) && (e[t] = n[t]);
                                });
                            }(this, r));
                        }
                    }
                });
                var o = {
                    onLaunch: function(n) {
                        this.$vm || (e.canIUse && !e.canIUse("nextTick") && console.error("当前微信基础库版本过低，请将 微信开发者工具-详情-项目设置-调试基础库版本 更换为`2.3.0`以上"), 
                        this.$vm = t, this.$vm.$mp = {
                            app: this
                        }, this.$vm.$scope = this, this.$vm.globalData = this.globalData, this.$vm._isMounted = !0, 
                        this.$vm.__call_hook("mounted", n), this.$vm.__call_hook("onLaunch", n));
                    }
                };
                o.globalData = t.$options.globalData || {};
                var a = t.$options.methods;
                return a && Object.keys(a).forEach(function(e) {
                    o[e] = a[e];
                }), function(e, t, n) {
                    var r = e.observable({
                        locale: n || ne.getLocale()
                    }), i = [];
                    t.$watchLocale = function(e) {
                        i.push(e);
                    }, Object.defineProperty(t, "$locale", {
                        get: function() {
                            return r.locale;
                        },
                        set: function(e) {
                            r.locale = e, i.forEach(function(t) {
                                return t(e);
                            });
                        }
                    });
                }(f.default, t, ie(e.getSystemInfoSync().language) || "en"), nt(o, Tt), rt(o, t.$options), 
                o;
            }
            function Et(e) {
                return wt(e, {
                    mocks: $e,
                    initRefs: ze
                });
            }
            function bt(e) {
                return App(Et(e)), e;
            }
            var Ct = /[!'()*]/g, At = function(e) {
                return "%" + e.charCodeAt(0).toString(16);
            }, St = /%2C/g, Rt = function(e) {
                return encodeURIComponent(e).replace(Ct, At).replace(St, ",");
            };
            function Nt(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Rt, n = e ? Object.keys(e).map(function(n) {
                    var r = e[n];
                    if (void 0 === r) return "";
                    if (null === r) return t(n);
                    if (Array.isArray(r)) {
                        var i = [];
                        return r.forEach(function(e) {
                            void 0 !== e && (null === e ? i.push(t(n)) : i.push(t(n) + "=" + t(e)));
                        }), i.join("&");
                    }
                    return t(n) + "=" + t(r);
                }).filter(function(e) {
                    return e.length > 0;
                }).join("&") : null;
                return n ? "?".concat(n) : "";
            }
            function Ot(e, t) {
                return function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.isPage, r = t.initRelation, i = arguments.length > 2 ? arguments[2] : void 0, o = at(f.default, e), c = (0, 
                    a.default)(o, 2), s = c[0], u = c[1], l = d({
                        multipleSlots: !0,
                        addGlobalClass: !0
                    }, u.options || {});
                    u["mp-weixin"] && u["mp-weixin"].options && Object.assign(l, u["mp-weixin"].options);
                    var p = {
                        options: l,
                        data: ut(u, f.default.prototype),
                        behaviors: ft(u, Fe),
                        properties: dt(u.props, !1, u.__file, l),
                        lifetimes: {
                            attached: function() {
                                var e = this.properties, t = {
                                    mpType: n.call(this) ? "page" : "component",
                                    mpInstance: this,
                                    propsData: e
                                };
                                st(e.vueId, this), r.call(this, {
                                    vuePid: this._$vuePid,
                                    vueOptions: t
                                }), this.$vm = new s(t), ct(this.$vm, e.vueSlots), this.$vm.$mount();
                            },
                            ready: function() {
                                this.$vm && (this.$vm._isMounted = !0, this.$vm.__call_hook("mounted"), this.$vm.__call_hook("onReady"));
                            },
                            detached: function() {
                                this.$vm && this.$vm.$destroy();
                            }
                        },
                        pageLifetimes: {
                            show: function(e) {
                                this.$vm && this.$vm.__call_hook("onPageShow", e);
                            },
                            hide: function() {
                                this.$vm && this.$vm.__call_hook("onPageHide");
                            },
                            resize: function(e) {
                                this.$vm && this.$vm.__call_hook("onPageResize", e);
                            }
                        },
                        methods: {
                            __l: qe,
                            __e: yt
                        }
                    };
                    return u.externalClasses && (p.externalClasses = u.externalClasses), Array.isArray(u.wxsCallMethods) && u.wxsCallMethods.forEach(function(e) {
                        p.methods[e] = function(t) {
                            return this.$vm[e](t);
                        };
                    }), i ? [ p, u, s ] : n ? p : [ p, s ];
                }(e, {
                    isPage: Be,
                    initRelation: We
                }, t);
            }
            var It = [ "onShow", "onHide", "onUnload" ];
            function xt(e) {
                return Component(function(e) {
                    return function(e) {
                        var t = Ot(e, !0), n = (0, a.default)(t, 2), r = n[0], i = n[1];
                        return nt(r.methods, It, i), r.methods.onLoad = function(e) {
                            this.options = e;
                            var t = Object.assign({}, e);
                            delete t.__id__, this.$page = {
                                fullPath: "/" + (this.route || this.is) + Nt(t)
                            }, this.$vm.$mp.query = e, this.$vm.__call_hook("onLoad", e);
                        }, rt(r.methods, e, [ "onReady" ]), function(e, t) {
                            t && Object.keys(t).forEach(function(n) {
                                var r = n.match(Xe);
                                if (r) {
                                    var i = r[1];
                                    e[n] = t[n], e[i] = t[i];
                                }
                            });
                        }(r.methods, i.methods), r;
                    }(e);
                }(e));
            }
            function Pt(e) {
                return Component(Ot(e));
            }
            function kt(t) {
                var n = Et(t), r = getApp({
                    allowDefault: !0
                });
                t.$scope = r;
                var i = r.globalData;
                if (i && Object.keys(n.globalData).forEach(function(e) {
                    b(i, e) || (i[e] = n.globalData[e]);
                }), Object.keys(n).forEach(function(e) {
                    b(r, e) || (r[e] = n[e]);
                }), T(n.onShow) && e.onAppShow && e.onAppShow(function() {
                    for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                    t.__call_hook("onShow", n);
                }), T(n.onHide) && e.onAppHide && e.onAppHide(function() {
                    for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                    t.__call_hook("onHide", n);
                }), T(n.onLaunch)) {
                    var o = e.getLaunchOptionsSync && e.getLaunchOptionsSync();
                    t.__call_hook("onLaunch", o);
                }
                return t;
            }
            function Ut(t) {
                var n = Et(t);
                if (T(n.onShow) && e.onAppShow && e.onAppShow(function() {
                    for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                    t.__call_hook("onShow", n);
                }), T(n.onHide) && e.onAppHide && e.onAppHide(function() {
                    for (var e = arguments.length, n = new Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                    t.__call_hook("onHide", n);
                }), T(n.onLaunch)) {
                    var r = e.getLaunchOptionsSync && e.getLaunchOptionsSync();
                    t.__call_hook("onLaunch", r);
                }
                return t;
            }
            It.push.apply(It, [ "onPullDownRefresh", "onReachBottom", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ]), 
            [ "vibrate", "preloadPage", "unPreloadPage", "loadSubPackage" ].forEach(function(e) {
                ve[e] = !1;
            }), [].forEach(function(t) {
                var n = ve[t] && ve[t].name ? ve[t].name : t;
                e.canIUse(n) || (ve[t] = !1);
            });
            var Mt = {};
            "undefined" != typeof Proxy ? Mt = new Proxy({}, {
                get: function(t, n) {
                    return b(t, n) ? t[n] : ue[n] ? ue[n] : je[n] ? J(n, je[n]) : Ae[n] ? J(n, Ae[n]) : be[n] ? J(n, be[n]) : xe[n] ? xe[n] : J(n, Ee(n, e[n]));
                },
                set: function(e, t, n) {
                    return e[t] = n, !0;
                }
            }) : (Object.keys(ue).forEach(function(e) {
                Mt[e] = ue[e];
            }), Object.keys(be).forEach(function(e) {
                Mt[e] = J(e, be[e]);
            }), Object.keys(Ae).forEach(function(e) {
                Mt[e] = J(e, Ae[e]);
            }), Object.keys(xe).forEach(function(e) {
                Mt[e] = xe[e];
            }), Object.keys(je).forEach(function(e) {
                Mt[e] = J(e, je[e]);
            }), Object.keys(e).forEach(function(t) {
                (b(e, t) || b(ve, t)) && (Mt[t] = J(t, Ee(t, e[t])));
            })), e.createApp = bt, e.createPage = xt, e.createComponent = Pt, e.createSubpackageApp = kt, 
            e.createPlugin = Ut;
            var Vt = Mt;
            t.default = Vt;
        }).call(this, n("bc2e").default, n("c8ba"));
    },
    "576b": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = t * n * o[a.TrigonometricType.SIN];
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * t * n * o[a.TrigonometricType.SIN];
                    }
                    return s;
                }(e.currentType, e.voltageValue, e.currentValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_RESISTANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * o[a.TrigonometricType.SIN] * o[a.TrigonometricType.COS] / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * o[a.TrigonometricType.SIN] * o[a.TrigonometricType.COS] / n;
                    }
                    return s;
                }(e.currentType, e.voltageValue, e.resistanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_IMPEDANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * o[a.TrigonometricType.SIN] / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * o[a.TrigonometricType.SIN] / n;
                    }
                    return s;
                }(e.currentType, e.voltageValue, e.impedanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_RESISTANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    if (c(o), 90 === o[a.TrigonometricType.DEG]) return t * n * o[a.TrigonometricType.TAN];
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * n * o[a.TrigonometricType.SIN] / o[a.TrigonometricType.COS];
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * n * o[a.TrigonometricType.SIN] / o[a.TrigonometricType.COS];
                    }
                    return s;
                }(e.currentType, e.currentValue, e.resistanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_IMPEDANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * n * o[a.TrigonometricType.SIN];
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * n * o[a.TrigonometricType.SIN];
                    }
                    return s;
                }(e.currentType, e.currentValue, e.impedanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.ACTIVE_APPARENT:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("视在功率数值无效");
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("无功功率数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = Math.sqrt(Math.pow(n, 2) - Math.pow(t, 2));
                    }
                    return o;
                }(e.currentType, e.activePowerValue, e.apparentPowerValue);
                break;

              case o.InputTerminal.ACTIVE_POWER:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("有功功率数值无效");
                    if (c(n), 90 === n[a.TrigonometricType.DEG]) return t * n[a.TrigonometricType.TAN];
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t * n[a.TrigonometricType.TAN];
                    }
                    return o;
                }(e.currentType, e.activePowerValue, e.triangleCollection);
                break;

              case o.InputTerminal.APPARENT_POWER:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("视在功率数值无效");
                    switch (c(n), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t * n[a.TrigonometricType.SIN];
                    }
                    return o;
                }(e.currentType, e.apparentPowerValue, e.triangleCollection);
            }
            return t;
        };
        var r = n("d417"), i = n("d055"), o = n("fad4"), a = n("2e64");
        function c(e) {
            if (e.type === a.TrigonometricType.COS && 0 === e[a.TrigonometricType.COS]) throw new Error("功率因数数值无效");
            if (e.type === a.TrigonometricType.SIN && 0 === e[a.TrigonometricType.SIN] || e.type === a.TrigonometricType.TAN && 0 === e[a.TrigonometricType.TAN] || e.type === a.TrigonometricType.RAD && 0 === e[a.TrigonometricType.RAD] || e.type === a.TrigonometricType.DEG && 0 === e[a.TrigonometricType.DEG]) throw new Error("功率数数值无效");
        }
    },
    "5a03": function(e, t, n) {
        "use strict";
        (function(e, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = {
                trustTags: l("a,abbr,ad,audio,b,blockquote,br,code,col,colgroup,dd,del,dl,dt,div,em,fieldset,h1,h2,h3,h4,h5,h6,hr,i,img,ins,label,legend,li,ol,p,q,ruby,rt,source,span,strong,sub,sup,table,tbody,td,tfoot,th,thead,tr,title,ul,video"),
                blockTags: l("address,article,aside,body,caption,center,cite,footer,header,html,nav,pre,section"),
                ignoreTags: l("area,base,canvas,embed,frame,head,iframe,input,link,map,meta,param,rp,script,source,style,textarea,title,track,wbr"),
                voidTags: l("area,base,br,col,circle,ellipse,embed,frame,hr,img,input,line,link,meta,param,path,polygon,rect,source,track,use,wbr"),
                entities: {
                    lt: "<",
                    gt: ">",
                    quot: '"',
                    apos: "'",
                    ensp: " ",
                    emsp: " ",
                    nbsp: " ",
                    semi: ";",
                    ndash: "–",
                    mdash: "—",
                    middot: "·",
                    lsquo: "‘",
                    rsquo: "’",
                    ldquo: "“",
                    rdquo: "”",
                    bull: "•",
                    hellip: "…",
                    larr: "←",
                    uarr: "↑",
                    rarr: "→",
                    darr: "↓"
                },
                tagStyle: {
                    address: "font-style:italic",
                    big: "display:inline;font-size:1.2em",
                    caption: "display:table-caption;text-align:center",
                    center: "text-align:center",
                    cite: "font-style:italic",
                    dd: "margin-left:40px",
                    mark: "background-color:yellow",
                    pre: "font-family:monospace;white-space:pre",
                    s: "text-decoration:line-through",
                    small: "display:inline;font-size:0.8em",
                    strike: "text-decoration:line-through",
                    u: "text-decoration:underline"
                },
                svgDict: {
                    animatetransform: "animateTransform",
                    lineargradient: "linearGradient",
                    viewbox: "viewBox",
                    attributename: "attributeName",
                    repeatcount: "repeatCount",
                    repeatdur: "repeatDur"
                }
            }, i = {}, o = e.getSystemInfoSync(), a = o.windowWidth, c = o.system, s = l(" ,\r,\n,\t,\f"), u = 0;
            function l(e) {
                for (var t = Object.create(null), n = e.split(","), r = n.length; r--; ) t[n[r]] = !0;
                return t;
            }
            function p(e, t) {
                for (var n = e.indexOf("&"); -1 !== n; ) {
                    var i = e.indexOf(";", n + 3), o = void 0;
                    if (-1 === i) break;
                    "#" === e[n + 1] ? (o = parseInt(("x" === e[n + 2] ? "0" : "") + e.substring(n + 2, i)), 
                    isNaN(o) || (e = e.substr(0, n) + String.fromCharCode(o) + e.substr(i + 1))) : (o = e.substring(n + 1, i), 
                    (r.entities[o] || "amp" === o && t) && (e = e.substr(0, n) + (r.entities[o] || "&") + e.substr(i + 1))), 
                    n = e.indexOf("&", n + 1);
                }
                return e;
            }
            function f(e) {
                for (var t = e.length - 1, n = t; n >= -1; n--) (-1 === n || e[n].c || !e[n].name || "div" !== e[n].name && "p" !== e[n].name && "h" !== e[n].name[0] || (e[n].attrs.style || "").includes("inline")) && (t - n >= 5 && e.splice(n + 1, t - n, {
                    name: "div",
                    attrs: {},
                    children: e.slice(n + 1, t + 1)
                }), t = n - 1);
            }
            function h(e) {
                this.options = e || {}, this.tagStyle = Object.assign({}, r.tagStyle, this.options.tagStyle), 
                this.imgList = e.imgList || [], this.imgList._unloadimgs = 0, this.plugins = e.plugins || [], 
                this.attrs = Object.create(null), this.stack = [], this.nodes = [], this.pre = (this.options.containerStyle || "").includes("white-space") && this.options.containerStyle.includes("pre") ? 2 : 0;
            }
            function d(e) {
                this.handler = e;
            }
            h.prototype.parse = function(e) {
                for (var t = this.plugins.length; t--; ) this.plugins[t].onUpdate && (e = this.plugins[t].onUpdate(e, r) || e);
                for (new d(this).parse(e); this.stack.length; ) this.popNode();
                return this.nodes.length > 50 && f(this.nodes), this.nodes;
            }, h.prototype.expose = function() {
                for (var e = this.stack.length; e--; ) {
                    var t = this.stack[e];
                    if (t.c || "a" === t.name || "video" === t.name || "audio" === t.name) return;
                    t.c = 1;
                }
            }, h.prototype.hook = function(e) {
                for (var t = this.plugins.length; t--; ) if (this.plugins[t].onParse && !1 === this.plugins[t].onParse(e, this)) return !1;
                return !0;
            }, h.prototype.getUrl = function(e) {
                var t = this.options.domain;
                return "/" === e[0] ? "/" === e[1] ? e = (t ? t.split("://")[0] : "http") + ":" + e : t && (e = t + e) : e.includes("data:") || e.includes("://") || t && (e = t + "/" + e), 
                e;
            }, h.prototype.parseStyle = function(e) {
                var t = e.attrs, n = (this.tagStyle[e.name] || "").split(";").concat((t.style || "").split(";")), r = {}, i = "";
                t.id && !this.xml && (this.options.useAnchor ? this.expose() : "img" !== e.name && "a" !== e.name && "video" !== e.name && "audio" !== e.name && (t.id = void 0)), 
                t.width && (r.width = parseFloat(t.width) + (t.width.includes("%") ? "%" : "px"), 
                t.width = void 0), t.height && (r.height = parseFloat(t.height) + (t.height.includes("%") ? "%" : "px"), 
                t.height = void 0);
                for (var o = 0, c = n.length; o < c; o++) {
                    var u = n[o].split(":");
                    if (!(u.length < 2)) {
                        var l = u.shift().trim().toLowerCase(), p = u.join(":").trim();
                        if ("-" === p[0] && p.lastIndexOf("-") > 0 || p.includes("safe")) i += ";".concat(l, ":").concat(p); else if (!r[l] || p.includes("import") || !r[l].includes("import")) {
                            if (p.includes("url")) {
                                var f = p.indexOf("(") + 1;
                                if (f) {
                                    for (;'"' === p[f] || "'" === p[f] || s[p[f]]; ) f++;
                                    p = p.substr(0, f) + this.getUrl(p.substr(f));
                                }
                            } else p.includes("rpx") && (p = p.replace(/[0-9.]+\s*rpx/g, function(e) {
                                return parseFloat(e) * a / 750 + "px";
                            }));
                            r[l] = p;
                        }
                    }
                }
                return e.attrs.style = i, r;
            }, h.prototype.onTagName = function(e) {
                this.tagName = this.xml ? e : e.toLowerCase(), "svg" === this.tagName && (this.xml = (this.xml || 0) + 1);
            }, h.prototype.onAttrName = function(e) {
                "data-" === (e = this.xml ? e : e.toLowerCase()).substr(0, 5) ? "data-src" !== e || this.attrs.src ? "img" === this.tagName || "a" === this.tagName ? this.attrName = e : this.attrName = void 0 : this.attrName = "src" : (this.attrName = e, 
                this.attrs[e] = "T");
            }, h.prototype.onAttrVal = function(e) {
                var t = this.attrName || "";
                "style" === t || "href" === t ? this.attrs[t] = p(e, !0) : t.includes("src") ? this.attrs[t] = this.getUrl(p(e, !0)) : t && (this.attrs[t] = e);
            }, h.prototype.onOpenTag = function(e) {
                var t = Object.create(null);
                t.name = this.tagName, t.attrs = this.attrs, this.options.nodes.length && (t.type = "node"), 
                this.attrs = Object.create(null);
                var n = t.attrs, o = this.stack[this.stack.length - 1], c = o ? o.children : this.nodes, s = this.xml ? e : r.voidTags[t.name];
                if (i[t.name] && (n.class = i[t.name] + (n.class ? " " + n.class : "")), "embed" === t.name) {
                    var l = n.src || "";
                    l.includes(".mp4") || l.includes(".3gp") || l.includes(".m3u8") || (n.type || "").includes("video") ? t.name = "video" : (l.includes(".mp3") || l.includes(".wav") || l.includes(".aac") || l.includes(".m4a") || (n.type || "").includes("audio")) && (t.name = "audio"), 
                    n.autostart && (n.autoplay = "T"), n.controls = "T";
                }
                if ("video" !== t.name && "audio" !== t.name || ("video" !== t.name || n.id || (n.id = "v" + u++), 
                n.controls || n.autoplay || (n.controls = "T"), t.src = [], n.src && (t.src.push(n.src), 
                n.src = void 0), this.expose()), s) {
                    if (!this.hook(t) || r.ignoreTags[t.name]) return void ("base" !== t.name || this.options.domain ? "source" === t.name && o && ("video" === o.name || "audio" === o.name) && n.src && o.src.push(n.src) : this.options.domain = n.href);
                    var p = this.parseStyle(t);
                    if ("img" === t.name) {
                        if (n.src && (n.src.includes("webp") && (t.webp = "T"), n.src.includes("data:") && !n["original-src"] && (n.ignore = "T"), 
                        !n.ignore || t.webp || n.src.includes("cloud://"))) {
                            for (var f = this.stack.length; f--; ) {
                                var h = this.stack[f];
                                "a" === h.name && (t.a = h.attrs), "table" !== h.name || t.webp || n.src.includes("cloud://") || (!p.display || p.display.includes("inline") ? t.t = "inline-block" : t.t = p.display, 
                                p.display = void 0);
                                var d = h.attrs.style || "";
                                if (!d.includes("flex:") || d.includes("flex:0") || d.includes("flex: 0") || p.width && !(parseInt(p.width) > 100)) if (d.includes("flex") && "100%" === p.width) for (var g = f + 1; g < this.stack.length; g++) {
                                    var m = this.stack[g].attrs.style || "";
                                    if (!m.includes(";width") && !m.includes(" width") && 0 !== m.indexOf("width")) {
                                        p.width = "";
                                        break;
                                    }
                                } else d.includes("inline-block") && (p.width && "%" === p.width[p.width.length - 1] ? (h.attrs.style += ";max-width:" + p.width, 
                                p.width = "") : h.attrs.style += ";max-width:100%"); else {
                                    p.width = "100% !important", p.height = "";
                                    for (var v = f + 1; v < this.stack.length; v++) this.stack[v].attrs.style = (this.stack[v].attrs.style || "").replace("inline-", "");
                                }
                                h.c = 1;
                            }
                            n.i = this.imgList.length.toString();
                            var y = n["original-src"] || n.src;
                            if (this.imgList.includes(y)) {
                                var _ = y.indexOf("://");
                                if (-1 !== _) {
                                    _ += 3;
                                    for (var T = y.substr(0, _); _ < y.length && "/" !== y[_]; _++) T += Math.random() > .5 ? y[_].toUpperCase() : y[_];
                                    T += y.substr(_), y = T;
                                }
                            }
                            this.imgList.push(y), t.t || (this.imgList._unloadimgs += 1);
                        }
                        "inline" === p.display && (p.display = ""), n.ignore && (p["max-width"] = p["max-width"] || "100%", 
                        n.style += ";-webkit-touch-callout:none"), parseInt(p.width) > a && (p.height = void 0), 
                        isNaN(parseInt(p.width)) || (t.w = "T"), !isNaN(parseInt(p.height)) && (!p.height.includes("%") || o && (o.attrs.style || "").includes("height")) && (t.h = "T");
                    } else if ("svg" === t.name) return c.push(t), this.stack.push(t), void this.popNode();
                    for (var w in p) p[w] && (n.style += ";".concat(w, ":").concat(p[w].replace(" !important", "")));
                    n.style = n.style.substr(1) || void 0;
                } else ("pre" === t.name || (n.style || "").includes("white-space") && n.style.includes("pre")) && 2 !== this.pre && (this.pre = t.pre = 1), 
                t.children = [], this.stack.push(t);
                c.push(t);
            }, h.prototype.onCloseTag = function(e) {
                var t;
                for (e = this.xml ? e : e.toLowerCase(), t = this.stack.length; t-- && this.stack[t].name !== e; ) ;
                if (-1 !== t) for (;this.stack.length > t; ) this.popNode(); else "p" !== e && "br" !== e || (this.stack.length ? this.stack[this.stack.length - 1].children : this.nodes).push({
                    name: e,
                    attrs: {
                        class: i[e] || "",
                        style: this.tagStyle[e] || ""
                    }
                });
            }, h.prototype.popNode = function() {
                var t = this.stack.pop(), i = t.attrs, o = t.children, c = this.stack[this.stack.length - 1], s = c ? c.children : this.nodes;
                if (!this.hook(t) || r.ignoreTags[t.name]) return "title" === t.name && o.length && "text" === o[0].type && this.options.setTitle && e.setNavigationBarTitle({
                    title: o[0].text
                }), void s.pop();
                if (t.pre && 2 !== this.pre) {
                    this.pre = t.pre = void 0;
                    for (var u = this.stack.length; u--; ) this.stack[u].pre && (this.pre = 1);
                }
                var l = {};
                if ("svg" === t.name) {
                    if (this.xml > 1) return void this.xml--;
                    var p = "", h = i.style;
                    return i.style = "", i.xmlns = "http://www.w3.org/2000/svg", function e(t) {
                        if ("text" !== t.type) {
                            var n = r.svgDict[t.name] || t.name;
                            for (var i in p += "<" + n, t.attrs) {
                                var o = t.attrs[i];
                                o && (p += " ".concat(r.svgDict[i] || i, '="').concat(o, '"'));
                            }
                            if (t.children) {
                                p += ">";
                                for (var a = 0; a < t.children.length; a++) e(t.children[a]);
                                p += "</" + n + ">";
                            } else p += "/>";
                        } else p += t.text;
                    }(t), t.name = "img", t.attrs = {
                        src: "data:image/svg+xml;utf8," + p.replace(/#/g, "%23"),
                        style: h,
                        ignore: "T"
                    }, t.children = void 0, void (this.xml = !1);
                }
                if (i.align && ("table" === t.name ? "center" === i.align ? l["margin-inline-start"] = l["margin-inline-end"] = "auto" : l.float = i.align : l["text-align"] = i.align, 
                i.align = void 0), i.dir && (l.direction = i.dir, i.dir = void 0), "font" === t.name && (i.color && (l.color = i.color, 
                i.color = void 0), i.face && (l["font-family"] = i.face, i.face = void 0), i.size)) {
                    var d = parseInt(i.size);
                    isNaN(d) || (d < 1 ? d = 1 : d > 7 && (d = 7), l["font-size"] = [ "x-small", "small", "medium", "large", "x-large", "xx-large", "xxx-large" ][d - 1]), 
                    i.size = void 0;
                }
                if ((i.class || "").includes("align-center") && (l["text-align"] = "center"), Object.assign(l, this.parseStyle(t)), 
                "table" !== t.name && parseInt(l.width) > a && (l["max-width"] = "100%", l["box-sizing"] = "border-box"), 
                r.blockTags[t.name] ? t.name = "div" : r.trustTags[t.name] || this.xml || (t.name = "span"), 
                "a" === t.name || "ad" === t.name) this.expose(); else if ("video" === t.name) (l.height || "").includes("auto") && (l.height = void 0); else if ("ul" !== t.name && "ol" !== t.name || !t.c) {
                    if ("table" === t.name) {
                        var g = parseFloat(i.cellpadding), m = parseFloat(i.cellspacing), v = parseFloat(i.border), y = l["border-color"], _ = l["border-style"];
                        if (t.c && (isNaN(g) && (g = 2), isNaN(m) && (m = 2)), v && (i.style += ";border:".concat(v, "px ").concat(_ || "solid", " ").concat(y || "gray")), 
                        t.flag && t.c) {
                            l.display = "grid", m ? (l["grid-gap"] = m + "px", l.padding = m + "px") : v && (i.style += ";border-left:0;border-top:0");
                            var T = [], w = [], E = [], b = {};
                            !function e(t) {
                                for (var n = 0; n < t.length; n++) "tr" === t[n].name ? w.push(t[n]) : e(t[n].children || []);
                            }(o);
                            for (var C = 1; C <= w.length; C++) {
                                for (var A = 1, S = 0; S < w[C - 1].children.length; S++) {
                                    var R = w[C - 1].children[S];
                                    if ("td" === R.name || "th" === R.name) {
                                        for (;b[C + "." + A]; ) A++;
                                        var N = R.attrs.style || "", O = N.indexOf("width") ? N.indexOf(";width") : 0;
                                        if (-1 !== O) {
                                            var I = N.indexOf(";", O + 6);
                                            -1 === I && (I = N.length), R.attrs.colspan || (T[A] = N.substring(O ? O + 7 : 6, I)), 
                                            N = N.substr(0, O) + N.substr(I);
                                        }
                                        if (-1 !== (O = (N += ";display:flex").indexOf("vertical-align"))) {
                                            var x = N.substr(O + 15, 10);
                                            x.includes("middle") ? N += ";align-items:center" : x.includes("bottom") && (N += ";align-items:flex-end");
                                        } else N += ";align-items:center";
                                        if (-1 !== (O = N.indexOf("text-align"))) {
                                            var P = N.substr(O + 11, 10);
                                            P.includes("center") ? N += ";justify-content: center" : P.includes("right") && (N += ";justify-content: right");
                                        }
                                        if (N = (v ? ";border:".concat(v, "px ").concat(_ || "solid", " ").concat(y || "gray") + (m ? "" : ";border-right:0;border-bottom:0") : "") + (g ? ";padding:".concat(g, "px") : "") + ";" + N, 
                                        R.attrs.colspan && (N += ";grid-column-start:".concat(A, ";grid-column-end:").concat(A + parseInt(R.attrs.colspan)), 
                                        R.attrs.rowspan || (N += ";grid-row-start:".concat(C, ";grid-row-end:").concat(C + 1)), 
                                        A += parseInt(R.attrs.colspan) - 1), R.attrs.rowspan) {
                                            N += ";grid-row-start:".concat(C, ";grid-row-end:").concat(C + parseInt(R.attrs.rowspan)), 
                                            R.attrs.colspan || (N += ";grid-column-start:".concat(A, ";grid-column-end:").concat(A + 1));
                                            for (var k = 1; k < R.attrs.rowspan; k++) for (var U = 0; U < (R.attrs.colspan || 1); U++) b[C + k + "." + (A - U)] = 1;
                                        }
                                        N && (R.attrs.style = N), E.push(R), A++;
                                    }
                                }
                                if (1 === C) {
                                    for (var M = "", V = 1; V < A; V++) M += (T[V] ? T[V] : "auto") + " ";
                                    l["grid-template-columns"] = M;
                                }
                            }
                            t.children = E;
                        } else t.c && (l.display = "table"), isNaN(m) || (l["border-spacing"] = m + "px"), 
                        (v || g) && function e(t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                "th" === r.name || "td" === r.name ? (v && (r.attrs.style = "border:".concat(v, "px ").concat(_ || "solid", " ").concat(y || "gray", ";").concat(r.attrs.style || "")), 
                                g && (r.attrs.style = "padding:".concat(g, "px;").concat(r.attrs.style || ""))) : r.children && e(r.children);
                            }
                        }(o);
                        if (this.options.scrollTable && !(i.style || "").includes("inline")) {
                            var H = Object.assign({}, t);
                            t.name = "div", t.attrs = {
                                style: "overflow:auto"
                            }, t.children = [ H ], i = H.attrs;
                        }
                    } else if ("td" !== t.name && "th" !== t.name || !i.colspan && !i.rowspan) if ("ruby" === t.name) {
                        t.name = "span";
                        for (var D = 0; D < o.length - 1; D++) "text" === o[D].type && "rt" === o[D + 1].name && (o[D] = {
                            name: "div",
                            attrs: {
                                style: "display:inline-block;text-align:center"
                            },
                            children: [ {
                                name: "div",
                                attrs: {
                                    style: "font-size:50%;" + (o[D + 1].attrs.style || "")
                                },
                                children: o[D + 1].children
                            }, o[D] ]
                        }, o.splice(D + 1, 1));
                    } else t.c && function(e) {
                        e.c = 2;
                        for (var t = e.children.length; t--; ) {
                            var n = e.children[t];
                            n.c && "table" !== n.name || (e.c = 1);
                        }
                    }(t); else for (var L = this.stack.length; L--; ) if ("table" === this.stack[L].name) {
                        this.stack[L].flag = 1;
                        break;
                    }
                } else {
                    var j = {
                        a: "lower-alpha",
                        A: "upper-alpha",
                        i: "lower-roman",
                        I: "upper-roman"
                    };
                    j[i.type] && (i.style += ";list-style-type:" + j[i.type], i.type = void 0);
                    for (var $ = o.length; $--; ) "li" === o[$].name && (o[$].c = 1);
                }
                if ((l.display || "").includes("flex") && !t.c) for (var F = o.length; F--; ) {
                    var B = o[F];
                    B.f && (B.attrs.style = (B.attrs.style || "") + B.f, B.f = void 0);
                }
                var W = c && ((c.attrs.style || "").includes("flex") || (c.attrs.style || "").includes("grid")) && !(t.c && n.getNFCAdapter);
                for (var z in W && (t.f = ";max-width:100%"), o.length >= 50 && t.c && !(l.display || "").includes("flex") && f(o), 
                l) if (l[z]) {
                    var q = ";".concat(z, ":").concat(l[z].replace(" !important", ""));
                    W && (z.includes("flex") && "flex-direction" !== z || "align-self" === z || z.includes("grid") || "-" === l[z][0] || z.includes("width") && q.includes("%")) ? (t.f += q, 
                    "width" === z && (i.style += ";width:100%")) : i.style += q;
                }
                i.style = i.style.substr(1) || void 0;
            }, h.prototype.onText = function(t) {
                if (!this.pre) {
                    for (var n, r = "", i = 0, o = t.length; i < o; i++) s[t[i]] ? (" " !== r[r.length - 1] && (r += " "), 
                    "\n" !== t[i] || n || (n = !0)) : r += t[i];
                    if (" " === r && n) return;
                    t = r;
                }
                var a = Object.create(null);
                a.type = "text", a.text = p(t), this.hook(a) && ("force" === this.options.selectable && c.includes("iOS") && !e.canIUse("rich-text.user-select") && this.expose(), 
                (this.stack.length ? this.stack[this.stack.length - 1].children : this.nodes).push(a));
            }, d.prototype.parse = function(e) {
                this.content = e || "", this.i = 0, this.start = 0, this.state = this.text;
                for (var t = this.content.length; -1 !== this.i && this.i < t; ) this.state();
            }, d.prototype.checkClose = function(e) {
                var t = "/" === this.content[this.i];
                return !!(">" === this.content[this.i] || t && ">" === this.content[this.i + 1]) && (e && this.handler[e](this.content.substring(this.start, this.i)), 
                this.i += t ? 2 : 1, this.start = this.i, this.handler.onOpenTag(t), "script" === this.handler.tagName ? (this.i = this.content.indexOf("</", this.i), 
                -1 !== this.i && (this.i += 2, this.start = this.i), this.state = this.endTag) : this.state = this.text, 
                !0);
            }, d.prototype.text = function() {
                if (this.i = this.content.indexOf("<", this.i), -1 !== this.i) {
                    var e = this.content[this.i + 1];
                    if (e >= "a" && e <= "z" || e >= "A" && e <= "Z") this.start !== this.i && this.handler.onText(this.content.substring(this.start, this.i)), 
                    this.start = ++this.i, this.state = this.tagName; else if ("/" === e || "!" === e || "?" === e) {
                        this.start !== this.i && this.handler.onText(this.content.substring(this.start, this.i));
                        var t = this.content[this.i + 2];
                        if ("/" === e && (t >= "a" && t <= "z" || t >= "A" && t <= "Z")) return this.i += 2, 
                        this.start = this.i, void (this.state = this.endTag);
                        var n = "--\x3e";
                        "!" === e && "-" === this.content[this.i + 2] && "-" === this.content[this.i + 3] || (n = ">"), 
                        this.i = this.content.indexOf(n, this.i), -1 !== this.i && (this.i += n.length, 
                        this.start = this.i);
                    } else this.i++;
                } else this.start < this.content.length && this.handler.onText(this.content.substring(this.start, this.content.length));
            }, d.prototype.tagName = function() {
                if (s[this.content[this.i]]) {
                    for (this.handler.onTagName(this.content.substring(this.start, this.i)); s[this.content[++this.i]]; ) ;
                    this.i < this.content.length && !this.checkClose() && (this.start = this.i, this.state = this.attrName);
                } else this.checkClose("onTagName") || this.i++;
            }, d.prototype.attrName = function() {
                var e = this.content[this.i];
                if (s[e] || "=" === e) {
                    this.handler.onAttrName(this.content.substring(this.start, this.i));
                    for (var t = "=" === e, n = this.content.length; ++this.i < n; ) if (e = this.content[this.i], 
                    !s[e]) {
                        if (this.checkClose()) return;
                        if (t) return this.start = this.i, void (this.state = this.attrVal);
                        if ("=" !== this.content[this.i]) return this.start = this.i, void (this.state = this.attrName);
                        t = !0;
                    }
                } else this.checkClose("onAttrName") || this.i++;
            }, d.prototype.attrVal = function() {
                var e = this.content[this.i], t = this.content.length;
                if ('"' === e || "'" === e) {
                    if (this.start = ++this.i, this.i = this.content.indexOf(e, this.i), -1 === this.i) return;
                    this.handler.onAttrVal(this.content.substring(this.start, this.i));
                } else for (;this.i < t; this.i++) {
                    if (s[this.content[this.i]]) {
                        this.handler.onAttrVal(this.content.substring(this.start, this.i));
                        break;
                    }
                    if (this.checkClose("onAttrVal")) return;
                }
                for (;s[this.content[++this.i]]; ) ;
                this.i < t && !this.checkClose() && (this.start = this.i, this.state = this.attrName);
            }, d.prototype.endTag = function() {
                var e = this.content[this.i];
                if (s[e] || ">" === e || "/" === e) {
                    if (this.handler.onCloseTag(this.content.substring(this.start, this.i)), ">" !== e && (this.i = this.content.indexOf(">", this.i), 
                    -1 === this.i)) return;
                    this.start = ++this.i, this.state = this.text;
                } else this.i++;
            };
            var g = h;
            t.default = g;
        }).call(this, n("543d").default, n("bc2e").default);
    },
    "5a43": function(e, t) {
        e.exports = function(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "5bc3": function(e, t, n) {
        var r = n("a395");
        function i(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                Object.defineProperty(e, r(i.key), i);
            }
        }
        e.exports = function(e, t, n) {
            return t && i(e.prototype, t), n && i(e, n), Object.defineProperty(e, "prototype", {
                writable: !1
            }), e;
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "5c05": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CompensationType = void 0, t.calculate = function(e) {
            if (!(0, r.isNonzeroNumber)(e.voltageValue)) throw new Error("电压数值无效");
            if (!(0, r.isNonzeroNumber)(e.frequencyValue)) throw new Error("评率数值无效");
            if (e.powerFactorValue < 0 || e.powerFactorValue > 1) throw new Error("功率因数数值无效");
            if (e.needPowerFactorValue < 0 || e.needPowerFactorValue > 1) throw new Error("所需功率因数数值无效");
            if (!(0, r.isNonzeroNumber)(e.capacitorVoltage)) throw new Error("电容器电压数值无效");
            var t = function(e, t, n, r, i) {
                var o = e * (Math.tan(Math.acos(t)) - Math.tan(Math.acos(n)));
                return r !== i && (o = Math.pow(i / r, 2) * o), o;
            }(e.powerValue, e.powerFactorValue, e.needPowerFactorValue, e.voltageValue, e.capacitorVoltage), n = 0;
            return 0 !== t && (n = function(e, t, n, r) {
                var o = e / (2 * Math.PI * t * Math.pow(n, 2));
                return r === i.THREE_PHASE_TRIANGLE && (o /= 3), o;
            }(t, e.frequencyValue, e.voltageValue, e.type)), {
                reactivePower: t,
                capacitance: n
            };
        };
        var r = n("d417"), i = {
            SINGLE_PHASE: "single_phase",
            THREE_PHASE_Y: "three_phase_y",
            THREE_PHASE_TRIANGLE: "three_phase_triangle"
        };
        t.CompensationType = i;
    },
    "5ce9": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculateLengthAntenna = function(e, t) {
            if (e < 0 || e > 1) throw new Error("速率数值无效");
            if (t < 0) throw new Error("频率数值无效");
            return 299792.458 * e / t;
        }, t.hzFormat = function(e) {
            return e >= i.MHz.mul ? (0, r.format)(e / i.MHz.mul, i.MHz) : e >= i.kHz.mul ? (0, 
            r.format)(e / i.kHz.mul, i.kHz) : (0, r.format)(e, i.Hz);
        }, t.hzUnits = void 0;
        var r = n("00cd"), i = {
            Hz: new r.Unit("Hz"),
            kHz: new r.Unit("kHz", 1e3),
            MHz: new r.Unit("MHz", 1e3, 2)
        };
        t.hzUnits = i;
    },
    "628d": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.TypeIcons = t.FavType = void 0, t.addFav = function(e, t) {
                return new Promise(function(n, r) {
                    i.default.post("favorites", {
                        resource_type: e,
                        resource_key: t
                    }).then(function() {
                        n(), setTimeout(function() {
                            getApp().globalData.trigger("fav-updated", {
                                type: e,
                                id: t,
                                add: !0
                            });
                        }, 500);
                    }, r);
                });
            }, t.cancelFav = function(e, t) {
                return new Promise(function(n, r) {
                    i.default.delete("favorites/" + e + "/" + t).then(function() {
                        n(), setTimeout(function() {
                            getApp().globalData.trigger("fav-updated", {
                                type: e,
                                id: t,
                                add: !1
                            });
                        }, 500);
                    }, r);
                });
            }, t.getRecentUsed = function() {
                return new Promise(function(t, n) {
                    e.getStorage({
                        key: "recent_used_data2",
                        success: function(e) {
                            t(e.data);
                        },
                        fail: function() {
                            t([]);
                        }
                    });
                });
            }, t.setRecentUsed = function(t, n, r, i, o) {
                var a = {
                    uniq: t,
                    icon: n,
                    name: r,
                    url: i,
                    requirement: o
                }, c = "recent_used_data2", s = [];
                e.getStorage({
                    key: c,
                    success: function(e) {
                        s = e.data;
                    },
                    fail: function() {},
                    complete: function() {
                        if (!(s.length > 0 && s[0].uniq == t)) {
                            for (var n, r = 0; n = s[r]; r++) if (n.uniq == t) {
                                s.splice(r, 1);
                                break;
                            }
                            s.unshift(a), s.length > 30 && s.splice(30), e.setStorage({
                                key: c,
                                data: s,
                                success: function(e) {
                                    getApp().globalData.trigger("recent-used-updated");
                                }
                            });
                        }
                    }
                });
            };
            var i = r(n("b253"));
            getApp(), t.FavType = {
                Calculator: 1,
                Document: 2,
                Catalog: 3
            }, t.TypeIcons = [ "icon-file-text-fill", "icon-file-pdf-fill", "icon-image-fill" ];
        }).call(this, n("543d").default);
    },
    6379: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT:
                t = function(e, t, n, o) {
                    var a = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        a = t / n;
                    }
                    return a;
                }(e.currentType, e.voltageValue, e.currentValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_POWER:
                t = function(e, t, n, o, s) {
                    var u = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    switch (c(s), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        u = "P" === o ? Math.pow(t, 2) * s[a.TrigonometricType.COS] / n : "S" === o ? Math.pow(t, 2) / n : Math.pow(t, 2) * s[a.TrigonometricType.SIN] / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        u = "P" === o ? Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.COS] / n : "S" === o ? Math.sqrt(3) * Math.pow(t, 2) / n : Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.SIN] / n;
                    }
                    return u;
                }(e.currentType, e.voltageValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_POWER:
                t = function(e, t, n, o, s) {
                    var u = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    switch (c(s), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        if ("P" === o) {
                            if (90 === s[a.TrigonometricType.DEG]) return n * s[a.TrigonometricType.TAN] / Math.pow(t, 2);
                            u = n / (Math.pow(t, 2) * s[a.TrigonometricType.COS]);
                        } else if ("S" === o) u = n / Math.pow(t, 2); else {
                            if (0 === s[a.TrigonometricType.SIN]) throw new Error("∞");
                            u = n / (Math.pow(t, 2) * s[a.TrigonometricType.SIN]);
                        }
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        if ("P" === o) {
                            if (90 === s[a.TrigonometricType.DEG]) return n * s[a.TrigonometricType.TAN] / (Math.sqrt(3) * Math.pow(t, 2));
                            u = n / (Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.COS]);
                        } else if ("S" === o) u = n / (Math.sqrt(3) * Math.pow(t, 2)); else {
                            if (0 === s[a.TrigonometricType.SIN]) throw new Error("∞");
                            u = n / (Math.sqrt(3) * Math.pow(t, 2) * s[a.TrigonometricType.SIN]);
                        }
                    }
                    return u;
                }(e.currentType, e.currentValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case o.InputTerminal.RESISTANCE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电阻数值无效");
                    if (c(n), 90 === n[a.TrigonometricType.DEG]) return t * n[a.TrigonometricType.TAN];
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t / n[a.TrigonometricType.COS];
                    }
                    return o;
                }(e.currentType, e.resistanceValue, e.triangleCollection);
            }
            return t;
        };
        var r = n("d417"), i = n("d055"), o = n("1c29"), a = n("2e64");
        function c(e) {
            if (e.type === a.TrigonometricType.COS && 0 === e[a.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
    },
    6613: function(e, t, n) {
        var r = n("5a43");
        e.exports = function(e, t) {
            if (e) {
                if ("string" == typeof e) return r(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(e, t) : void 0;
            }
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "66fd": function(e, t, n) {
        "use strict";
        n.r(t), function(e) {
            var n = Object.freeze({});
            function r(e) {
                return null == e;
            }
            function i(e) {
                return null != e;
            }
            function o(e) {
                return !0 === e;
            }
            function a(e) {
                return "string" == typeof e || "number" == typeof e || "symbol" == typeof e || "boolean" == typeof e;
            }
            function c(e) {
                return null !== e && "object" == typeof e;
            }
            var s = Object.prototype.toString;
            function u(e) {
                return "[object Object]" === s.call(e);
            }
            function l(e) {
                var t = parseFloat(String(e));
                return t >= 0 && Math.floor(t) === t && isFinite(e);
            }
            function p(e) {
                return i(e) && "function" == typeof e.then && "function" == typeof e.catch;
            }
            function f(e) {
                return null == e ? "" : Array.isArray(e) || u(e) && e.toString === s ? JSON.stringify(e, null, 2) : String(e);
            }
            function h(e) {
                var t = parseFloat(e);
                return isNaN(t) ? e : t;
            }
            function d(e, t) {
                for (var n = Object.create(null), r = e.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return t ? function(e) {
                    return n[e.toLowerCase()];
                } : function(e) {
                    return n[e];
                };
            }
            d("slot,component", !0);
            var g = d("key,ref,slot,slot-scope,is");
            function m(e, t) {
                if (e.length) {
                    var n = e.indexOf(t);
                    if (n > -1) return e.splice(n, 1);
                }
            }
            var v = Object.prototype.hasOwnProperty;
            function y(e, t) {
                return v.call(e, t);
            }
            function _(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            var T = /-(\w)/g, w = _(function(e) {
                return e.replace(T, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            }), E = _(function(e) {
                return e.charAt(0).toUpperCase() + e.slice(1);
            }), b = /\B([A-Z])/g, C = _(function(e) {
                return e.replace(b, "-$1").toLowerCase();
            }), A = Function.prototype.bind ? function(e, t) {
                return e.bind(t);
            } : function(e, t) {
                function n(n) {
                    var r = arguments.length;
                    return r ? r > 1 ? e.apply(t, arguments) : e.call(t, n) : e.call(t);
                }
                return n._length = e.length, n;
            };
            function S(e, t) {
                t = t || 0;
                for (var n = e.length - t, r = new Array(n); n--; ) r[n] = e[n + t];
                return r;
            }
            function R(e, t) {
                for (var n in t) e[n] = t[n];
                return e;
            }
            function N(e) {
                for (var t = {}, n = 0; n < e.length; n++) e[n] && R(t, e[n]);
                return t;
            }
            function O(e, t, n) {}
            var I = function(e, t, n) {
                return !1;
            }, x = function(e) {
                return e;
            };
            function P(e, t) {
                if (e === t) return !0;
                var n = c(e), r = c(t);
                if (!n || !r) return !n && !r && String(e) === String(t);
                try {
                    var i = Array.isArray(e), o = Array.isArray(t);
                    if (i && o) return e.length === t.length && e.every(function(e, n) {
                        return P(e, t[n]);
                    });
                    if (e instanceof Date && t instanceof Date) return e.getTime() === t.getTime();
                    if (i || o) return !1;
                    var a = Object.keys(e), s = Object.keys(t);
                    return a.length === s.length && a.every(function(n) {
                        return P(e[n], t[n]);
                    });
                } catch (e) {
                    return !1;
                }
            }
            function k(e, t) {
                for (var n = 0; n < e.length; n++) if (P(e[n], t)) return n;
                return -1;
            }
            function U(e) {
                var t = !1;
                return function() {
                    t || (t = !0, e.apply(this, arguments));
                };
            }
            var M = [ "component", "directive", "filter" ], V = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], H = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: I,
                isReservedAttr: I,
                isUnknownElement: I,
                getTagNamespace: O,
                parsePlatformTagName: x,
                mustUseProp: I,
                async: !0,
                _lifecycleHooks: V
            };
            function D(e) {
                var t = (e + "").charCodeAt(0);
                return 36 === t || 95 === t;
            }
            function L(e, t, n, r) {
                Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            var j, $ = new RegExp("[^" + /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/.source + ".$_\\d]"), F = "__proto__" in {}, B = "undefined" != typeof window, W = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, z = W && WXEnvironment.platform.toLowerCase(), q = B && window.navigator.userAgent.toLowerCase(), G = q && /msie|trident/.test(q), K = (q && q.indexOf("msie 9.0"), 
            q && q.indexOf("edge/"), q && q.indexOf("android"), q && /iphone|ipad|ipod|ios/.test(q) || "ios" === z), X = (q && /chrome\/\d+/.test(q), 
            q && /phantomjs/.test(q), q && q.match(/firefox\/(\d+)/), {}.watch);
            if (B) try {
                var J = {};
                Object.defineProperty(J, "passive", {
                    get: function() {}
                }), window.addEventListener("test-passive", null, J);
            } catch (e) {}
            var Z = function() {
                return void 0 === j && (j = !B && !W && void 0 !== e && e.process && "server" === e.process.env.VUE_ENV), 
                j;
            }, Y = B && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function Q(e) {
                return "function" == typeof e && /native code/.test(e.toString());
            }
            var ee, te = "undefined" != typeof Symbol && Q(Symbol) && "undefined" != typeof Reflect && Q(Reflect.ownKeys);
            ee = "undefined" != typeof Set && Q(Set) ? Set : function() {
                function e() {
                    this.set = Object.create(null);
                }
                return e.prototype.has = function(e) {
                    return !0 === this.set[e];
                }, e.prototype.add = function(e) {
                    this.set[e] = !0;
                }, e.prototype.clear = function() {
                    this.set = Object.create(null);
                }, e;
            }();
            var ne = O, re = 0, ie = function() {
                this.id = re++, this.subs = [];
            };
            function oe(e) {
                ie.SharedObject.targetStack.push(e), ie.SharedObject.target = e, ie.target = e;
            }
            function ae() {
                ie.SharedObject.targetStack.pop(), ie.SharedObject.target = ie.SharedObject.targetStack[ie.SharedObject.targetStack.length - 1], 
                ie.target = ie.SharedObject.target;
            }
            ie.prototype.addSub = function(e) {
                this.subs.push(e);
            }, ie.prototype.removeSub = function(e) {
                m(this.subs, e);
            }, ie.prototype.depend = function() {
                ie.SharedObject.target && ie.SharedObject.target.addDep(this);
            }, ie.prototype.notify = function() {
                for (var e = this.subs.slice(), t = 0, n = e.length; t < n; t++) e[t].update();
            }, (ie.SharedObject = {}).target = null, ie.SharedObject.targetStack = [];
            var ce = function(e, t, n, r, i, o, a, c) {
                this.tag = e, this.data = t, this.children = n, this.text = r, this.elm = i, this.ns = void 0, 
                this.context = o, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = t && t.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = c, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, se = {
                child: {
                    configurable: !0
                }
            };
            se.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(ce.prototype, se);
            var ue = function(e) {
                void 0 === e && (e = "");
                var t = new ce();
                return t.text = e, t.isComment = !0, t;
            };
            function le(e) {
                return new ce(void 0, void 0, void 0, String(e));
            }
            var pe = Array.prototype, fe = Object.create(pe);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(e) {
                var t = pe[e];
                L(fe, e, function() {
                    for (var n = [], r = arguments.length; r--; ) n[r] = arguments[r];
                    var i, o = t.apply(this, n), a = this.__ob__;
                    switch (e) {
                      case "push":
                      case "unshift":
                        i = n;
                        break;

                      case "splice":
                        i = n.slice(2);
                    }
                    return i && a.observeArray(i), a.dep.notify(), o;
                });
            });
            var he = Object.getOwnPropertyNames(fe), de = !0;
            function ge(e) {
                de = e;
            }
            var me = function(e) {
                this.value = e, this.dep = new ie(), this.vmCount = 0, L(e, "__ob__", this), Array.isArray(e) ? (F ? e.push !== e.__proto__.push ? ve(e, fe, he) : function(e, t) {
                    e.__proto__ = t;
                }(e, fe) : ve(e, fe, he), this.observeArray(e)) : this.walk(e);
            };
            function ve(e, t, n) {
                for (var r = 0, i = n.length; r < i; r++) {
                    var o = n[r];
                    L(e, o, t[o]);
                }
            }
            function ye(e, t) {
                var n;
                if (c(e) && !(e instanceof ce)) return y(e, "__ob__") && e.__ob__ instanceof me ? n = e.__ob__ : !de || Z() || !Array.isArray(e) && !u(e) || !Object.isExtensible(e) || e._isVue || e.__v_isMPComponent || (n = new me(e)), 
                t && n && n.vmCount++, n;
            }
            function _e(e, t, n, r, i) {
                var o = new ie(), a = Object.getOwnPropertyDescriptor(e, t);
                if (!a || !1 !== a.configurable) {
                    var c = a && a.get, s = a && a.set;
                    c && !s || 2 !== arguments.length || (n = e[t]);
                    var u = !i && ye(n);
                    Object.defineProperty(e, t, {
                        enumerable: !0,
                        configurable: !0,
                        get: function() {
                            var t = c ? c.call(e) : n;
                            return ie.SharedObject.target && (o.depend(), u && (u.dep.depend(), Array.isArray(t) && Ee(t))), 
                            t;
                        },
                        set: function(t) {
                            var r = c ? c.call(e) : n;
                            t === r || t != t && r != r || c && !s || (s ? s.call(e, t) : n = t, u = !i && ye(t), 
                            o.notify());
                        }
                    });
                }
            }
            function Te(e, t, n) {
                if (Array.isArray(e) && l(t)) return e.length = Math.max(e.length, t), e.splice(t, 1, n), 
                n;
                if (t in e && !(t in Object.prototype)) return e[t] = n, n;
                var r = e.__ob__;
                return e._isVue || r && r.vmCount ? n : r ? (_e(r.value, t, n), r.dep.notify(), 
                n) : (e[t] = n, n);
            }
            function we(e, t) {
                if (Array.isArray(e) && l(t)) e.splice(t, 1); else {
                    var n = e.__ob__;
                    e._isVue || n && n.vmCount || y(e, t) && (delete e[t], n && n.dep.notify());
                }
            }
            function Ee(e) {
                for (var t = void 0, n = 0, r = e.length; n < r; n++) (t = e[n]) && t.__ob__ && t.__ob__.dep.depend(), 
                Array.isArray(t) && Ee(t);
            }
            me.prototype.walk = function(e) {
                for (var t = Object.keys(e), n = 0; n < t.length; n++) _e(e, t[n]);
            }, me.prototype.observeArray = function(e) {
                for (var t = 0, n = e.length; t < n; t++) ye(e[t]);
            };
            var be = H.optionMergeStrategies;
            function Ce(e, t) {
                if (!t) return e;
                for (var n, r, i, o = te ? Reflect.ownKeys(t) : Object.keys(t), a = 0; a < o.length; a++) "__ob__" !== (n = o[a]) && (r = e[n], 
                i = t[n], y(e, n) ? r !== i && u(r) && u(i) && Ce(r, i) : Te(e, n, i));
                return e;
            }
            function Ae(e, t, n) {
                return n ? function() {
                    var r = "function" == typeof t ? t.call(n, n) : t, i = "function" == typeof e ? e.call(n, n) : e;
                    return r ? Ce(r, i) : i;
                } : t ? e ? function() {
                    return Ce("function" == typeof t ? t.call(this, this) : t, "function" == typeof e ? e.call(this, this) : e);
                } : t : e;
            }
            function Se(e, t) {
                var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                return n ? function(e) {
                    for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                    return t;
                }(n) : n;
            }
            function Re(e, t, n, r) {
                var i = Object.create(e || null);
                return t ? R(i, t) : i;
            }
            be.data = function(e, t, n) {
                return n ? Ae(e, t, n) : t && "function" != typeof t ? e : Ae(e, t);
            }, V.forEach(function(e) {
                be[e] = Se;
            }), M.forEach(function(e) {
                be[e + "s"] = Re;
            }), be.watch = function(e, t, n, r) {
                if (e === X && (e = void 0), t === X && (t = void 0), !t) return Object.create(e || null);
                if (!e) return t;
                var i = {};
                for (var o in R(i, e), t) {
                    var a = i[o], c = t[o];
                    a && !Array.isArray(a) && (a = [ a ]), i[o] = a ? a.concat(c) : Array.isArray(c) ? c : [ c ];
                }
                return i;
            }, be.props = be.methods = be.inject = be.computed = function(e, t, n, r) {
                if (!e) return t;
                var i = Object.create(null);
                return R(i, e), t && R(i, t), i;
            }, be.provide = Ae;
            var Ne = function(e, t) {
                return void 0 === t ? e : t;
            };
            function Oe(e, t, n) {
                if ("function" == typeof t && (t = t.options), function(e, t) {
                    var n = e.props;
                    if (n) {
                        var r, i, o = {};
                        if (Array.isArray(n)) for (r = n.length; r--; ) "string" == typeof (i = n[r]) && (o[w(i)] = {
                            type: null
                        }); else if (u(n)) for (var a in n) i = n[a], o[w(a)] = u(i) ? i : {
                            type: i
                        };
                        e.props = o;
                    }
                }(t), function(e, t) {
                    var n = e.inject;
                    if (n) {
                        var r = e.inject = {};
                        if (Array.isArray(n)) for (var i = 0; i < n.length; i++) r[n[i]] = {
                            from: n[i]
                        }; else if (u(n)) for (var o in n) {
                            var a = n[o];
                            r[o] = u(a) ? R({
                                from: o
                            }, a) : {
                                from: a
                            };
                        }
                    }
                }(t), function(e) {
                    var t = e.directives;
                    if (t) for (var n in t) {
                        var r = t[n];
                        "function" == typeof r && (t[n] = {
                            bind: r,
                            update: r
                        });
                    }
                }(t), !t._base && (t.extends && (e = Oe(e, t.extends, n)), t.mixins)) for (var r = 0, i = t.mixins.length; r < i; r++) e = Oe(e, t.mixins[r], n);
                var o, a = {};
                for (o in e) c(o);
                for (o in t) y(e, o) || c(o);
                function c(r) {
                    var i = be[r] || Ne;
                    a[r] = i(e[r], t[r], n, r);
                }
                return a;
            }
            function Ie(e, t, n, r) {
                if ("string" == typeof n) {
                    var i = e[t];
                    if (y(i, n)) return i[n];
                    var o = w(n);
                    if (y(i, o)) return i[o];
                    var a = E(o);
                    return y(i, a) ? i[a] : i[n] || i[o] || i[a];
                }
            }
            function xe(e, t, n, r) {
                var i = t[e], o = !y(n, e), a = n[e], c = Ue(Boolean, i.type);
                if (c > -1) if (o && !y(i, "default")) a = !1; else if ("" === a || a === C(e)) {
                    var s = Ue(String, i.type);
                    (s < 0 || c < s) && (a = !0);
                }
                if (void 0 === a) {
                    a = function(e, t, n) {
                        if (y(t, "default")) {
                            var r = t.default;
                            return e && e.$options.propsData && void 0 === e.$options.propsData[n] && void 0 !== e._props[n] ? e._props[n] : "function" == typeof r && "Function" !== Pe(t.type) ? r.call(e) : r;
                        }
                    }(r, i, e);
                    var u = de;
                    ge(!0), ye(a), ge(u);
                }
                return a;
            }
            function Pe(e) {
                var t = e && e.toString().match(/^\s*function (\w+)/);
                return t ? t[1] : "";
            }
            function ke(e, t) {
                return Pe(e) === Pe(t);
            }
            function Ue(e, t) {
                if (!Array.isArray(t)) return ke(t, e) ? 0 : -1;
                for (var n = 0, r = t.length; n < r; n++) if (ke(t[n], e)) return n;
                return -1;
            }
            function Me(e, t, n) {
                oe();
                try {
                    if (t) for (var r = t; r = r.$parent; ) {
                        var i = r.$options.errorCaptured;
                        if (i) for (var o = 0; o < i.length; o++) try {
                            if (!1 === i[o].call(r, e, t, n)) return;
                        } catch (e) {
                            He(e, r, "errorCaptured hook");
                        }
                    }
                    He(e, t, n);
                } finally {
                    ae();
                }
            }
            function Ve(e, t, n, r, i) {
                var o;
                try {
                    (o = n ? e.apply(t, n) : e.call(t)) && !o._isVue && p(o) && !o._handled && (o.catch(function(e) {
                        return Me(e, r, i + " (Promise/async)");
                    }), o._handled = !0);
                } catch (e) {
                    Me(e, r, i);
                }
                return o;
            }
            function He(e, t, n) {
                if (H.errorHandler) try {
                    return H.errorHandler.call(null, e, t, n);
                } catch (t) {
                    t !== e && De(t);
                }
                De(e);
            }
            function De(e, t, n) {
                if (!B && !W || "undefined" == typeof console) throw e;
                console.error(e);
            }
            var Le, je = [], $e = !1;
            function Fe() {
                $e = !1;
                var e = je.slice(0);
                je.length = 0;
                for (var t = 0; t < e.length; t++) e[t]();
            }
            if ("undefined" != typeof Promise && Q(Promise)) {
                var Be = Promise.resolve();
                Le = function() {
                    Be.then(Fe), K && setTimeout(O);
                };
            } else if (G || "undefined" == typeof MutationObserver || !Q(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString()) Le = "undefined" != typeof setImmediate && Q(setImmediate) ? function() {
                setImmediate(Fe);
            } : function() {
                setTimeout(Fe, 0);
            }; else {
                var We = 1, ze = new MutationObserver(Fe), qe = document.createTextNode(String(We));
                ze.observe(qe, {
                    characterData: !0
                }), Le = function() {
                    We = (We + 1) % 2, qe.data = String(We);
                };
            }
            function Ge(e, t) {
                var n;
                if (je.push(function() {
                    if (e) try {
                        e.call(t);
                    } catch (e) {
                        Me(e, t, "nextTick");
                    } else n && n(t);
                }), $e || ($e = !0, Le()), !e && "undefined" != typeof Promise) return new Promise(function(e) {
                    n = e;
                });
            }
            var Ke = new ee();
            function Xe(e) {
                (function e(t, n) {
                    var r, i, o = Array.isArray(t);
                    if (!(!o && !c(t) || Object.isFrozen(t) || t instanceof ce)) {
                        if (t.__ob__) {
                            var a = t.__ob__.dep.id;
                            if (n.has(a)) return;
                            n.add(a);
                        }
                        if (o) for (r = t.length; r--; ) e(t[r], n); else for (r = (i = Object.keys(t)).length; r--; ) e(t[i[r]], n);
                    }
                })(e, Ke), Ke.clear();
            }
            var Je = _(function(e) {
                var t = "&" === e.charAt(0), n = "~" === (e = t ? e.slice(1) : e).charAt(0), r = "!" === (e = n ? e.slice(1) : e).charAt(0);
                return {
                    name: e = r ? e.slice(1) : e,
                    once: n,
                    capture: r,
                    passive: t
                };
            });
            function Ze(e, t) {
                function n() {
                    var e = arguments, r = n.fns;
                    if (!Array.isArray(r)) return Ve(r, null, arguments, t, "v-on handler");
                    for (var i = r.slice(), o = 0; o < i.length; o++) Ve(i[o], null, e, t, "v-on handler");
                }
                return n.fns = e, n;
            }
            function Ye(e, t, n, o) {
                var a = t.options.mpOptions && t.options.mpOptions.properties;
                if (r(a)) return n;
                var c = t.options.mpOptions.externalClasses || [], s = e.attrs, u = e.props;
                if (i(s) || i(u)) for (var l in a) {
                    var p = C(l);
                    (Qe(n, u, l, p, !0) || Qe(n, s, l, p, !1)) && n[l] && -1 !== c.indexOf(p) && o[w(n[l])] && (n[l] = o[w(n[l])]);
                }
                return n;
            }
            function Qe(e, t, n, r, o) {
                if (i(t)) {
                    if (y(t, n)) return e[n] = t[n], o || delete t[n], !0;
                    if (y(t, r)) return e[n] = t[r], o || delete t[r], !0;
                }
                return !1;
            }
            function et(e) {
                return a(e) ? [ le(e) ] : Array.isArray(e) ? function e(t, n) {
                    var c, s, u, l, p = [];
                    for (c = 0; c < t.length; c++) r(s = t[c]) || "boolean" == typeof s || (l = p[u = p.length - 1], 
                    Array.isArray(s) ? s.length > 0 && (tt((s = e(s, (n || "") + "_" + c))[0]) && tt(l) && (p[u] = le(l.text + s[0].text), 
                    s.shift()), p.push.apply(p, s)) : a(s) ? tt(l) ? p[u] = le(l.text + s) : "" !== s && p.push(le(s)) : tt(s) && tt(l) ? p[u] = le(l.text + s.text) : (o(t._isVList) && i(s.tag) && r(s.key) && i(n) && (s.key = "__vlist" + n + "_" + c + "__"), 
                    p.push(s)));
                    return p;
                }(e) : void 0;
            }
            function tt(e) {
                return i(e) && i(e.text) && function(e) {
                    return !1 === e;
                }(e.isComment);
            }
            function nt(e) {
                var t = e.$options.provide;
                t && (e._provided = "function" == typeof t ? t.call(e) : t);
            }
            function rt(e) {
                var t = it(e.$options.inject, e);
                t && (ge(!1), Object.keys(t).forEach(function(n) {
                    _e(e, n, t[n]);
                }), ge(!0));
            }
            function it(e, t) {
                if (e) {
                    for (var n = Object.create(null), r = te ? Reflect.ownKeys(e) : Object.keys(e), i = 0; i < r.length; i++) {
                        var o = r[i];
                        if ("__ob__" !== o) {
                            for (var a = e[o].from, c = t; c; ) {
                                if (c._provided && y(c._provided, a)) {
                                    n[o] = c._provided[a];
                                    break;
                                }
                                c = c.$parent;
                            }
                            if (!c && "default" in e[o]) {
                                var s = e[o].default;
                                n[o] = "function" == typeof s ? s.call(t) : s;
                            }
                        }
                    }
                    return n;
                }
            }
            function ot(e, t) {
                if (!e || !e.length) return {};
                for (var n = {}, r = 0, i = e.length; r < i; r++) {
                    var o = e[r], a = o.data;
                    if (a && a.attrs && a.attrs.slot && delete a.attrs.slot, o.context !== t && o.fnContext !== t || !a || null == a.slot) o.asyncMeta && o.asyncMeta.data && "page" === o.asyncMeta.data.slot ? (n.page || (n.page = [])).push(o) : (n.default || (n.default = [])).push(o); else {
                        var c = a.slot, s = n[c] || (n[c] = []);
                        "template" === o.tag ? s.push.apply(s, o.children || []) : s.push(o);
                    }
                }
                for (var u in n) n[u].every(at) && delete n[u];
                return n;
            }
            function at(e) {
                return e.isComment && !e.asyncFactory || " " === e.text;
            }
            function ct(e, t, r) {
                var i, o = Object.keys(t).length > 0, a = e ? !!e.$stable : !o, c = e && e.$key;
                if (e) {
                    if (e._normalized) return e._normalized;
                    if (a && r && r !== n && c === r.$key && !o && !r.$hasNormal) return r;
                    for (var s in i = {}, e) e[s] && "$" !== s[0] && (i[s] = st(t, s, e[s]));
                } else i = {};
                for (var u in t) u in i || (i[u] = ut(t, u));
                return e && Object.isExtensible(e) && (e._normalized = i), L(i, "$stable", a), L(i, "$key", c), 
                L(i, "$hasNormal", o), i;
            }
            function st(e, t, n) {
                var r = function() {
                    var e = arguments.length ? n.apply(null, arguments) : n({});
                    return (e = e && "object" == typeof e && !Array.isArray(e) ? [ e ] : et(e)) && (0 === e.length || 1 === e.length && e[0].isComment) ? void 0 : e;
                };
                return n.proxy && Object.defineProperty(e, t, {
                    get: r,
                    enumerable: !0,
                    configurable: !0
                }), r;
            }
            function ut(e, t) {
                return function() {
                    return e[t];
                };
            }
            function lt(e, t) {
                var n, r, o, a, s;
                if (Array.isArray(e) || "string" == typeof e) for (n = new Array(e.length), r = 0, 
                o = e.length; r < o; r++) n[r] = t(e[r], r, r, r); else if ("number" == typeof e) for (n = new Array(e), 
                r = 0; r < e; r++) n[r] = t(r + 1, r, r, r); else if (c(e)) if (te && e[Symbol.iterator]) {
                    n = [];
                    for (var u = e[Symbol.iterator](), l = u.next(); !l.done; ) n.push(t(l.value, n.length, r, r++)), 
                    l = u.next();
                } else for (a = Object.keys(e), n = new Array(a.length), r = 0, o = a.length; r < o; r++) s = a[r], 
                n[r] = t(e[s], s, r, r);
                return i(n) || (n = []), n._isVList = !0, n;
            }
            function pt(e, t, n, r) {
                var i, o = this.$scopedSlots[e];
                o ? (n = n || {}, r && (n = R(R({}, r), n)), i = o(n, this, n._i) || t) : i = this.$slots[e] || t;
                var a = n && n.slot;
                return a ? this.$createElement("template", {
                    slot: a
                }, i) : i;
            }
            function ft(e) {
                return Ie(this.$options, "filters", e) || x;
            }
            function ht(e, t) {
                return Array.isArray(e) ? -1 === e.indexOf(t) : e !== t;
            }
            function dt(e, t, n, r, i) {
                var o = H.keyCodes[t] || n;
                return i && r && !H.keyCodes[t] ? ht(i, r) : o ? ht(o, e) : r ? C(r) !== t : void 0;
            }
            function gt(e, t, n, r, i) {
                if (n && c(n)) {
                    var o;
                    Array.isArray(n) && (n = N(n));
                    var a = function(a) {
                        if ("class" === a || "style" === a || g(a)) o = e; else {
                            var c = e.attrs && e.attrs.type;
                            o = r || H.mustUseProp(t, c, a) ? e.domProps || (e.domProps = {}) : e.attrs || (e.attrs = {});
                        }
                        var s = w(a), u = C(a);
                        s in o || u in o || (o[a] = n[a], !i) || ((e.on || (e.on = {}))["update:" + a] = function(e) {
                            n[a] = e;
                        });
                    };
                    for (var s in n) a(s);
                }
                return e;
            }
            function mt(e, t) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[e];
                return r && !t || yt(r = n[e] = this.$options.staticRenderFns[e].call(this._renderProxy, null, this), "__static__" + e, !1), 
                r;
            }
            function vt(e, t, n) {
                return yt(e, "__once__" + t + (n ? "_" + n : ""), !0), e;
            }
            function yt(e, t, n) {
                if (Array.isArray(e)) for (var r = 0; r < e.length; r++) e[r] && "string" != typeof e[r] && _t(e[r], t + "_" + r, n); else _t(e, t, n);
            }
            function _t(e, t, n) {
                e.isStatic = !0, e.key = t, e.isOnce = n;
            }
            function Tt(e, t) {
                if (t && u(t)) {
                    var n = e.on = e.on ? R({}, e.on) : {};
                    for (var r in t) {
                        var i = n[r], o = t[r];
                        n[r] = i ? [].concat(i, o) : o;
                    }
                }
                return e;
            }
            function wt(e, t, n, r) {
                t = t || {
                    $stable: !n
                };
                for (var i = 0; i < e.length; i++) {
                    var o = e[i];
                    Array.isArray(o) ? wt(o, t, n) : o && (o.proxy && (o.fn.proxy = !0), t[o.key] = o.fn);
                }
                return r && (t.$key = r), t;
            }
            function Et(e, t) {
                for (var n = 0; n < t.length; n += 2) {
                    var r = t[n];
                    "string" == typeof r && r && (e[t[n]] = t[n + 1]);
                }
                return e;
            }
            function bt(e, t) {
                return "string" == typeof e ? t + e : e;
            }
            function Ct(e) {
                e._o = vt, e._n = h, e._s = f, e._l = lt, e._t = pt, e._q = P, e._i = k, e._m = mt, 
                e._f = ft, e._k = dt, e._b = gt, e._v = le, e._e = ue, e._u = wt, e._g = Tt, e._d = Et, 
                e._p = bt;
            }
            function At(e, t, r, i, a) {
                var c, s = this, u = a.options;
                y(i, "_uid") ? (c = Object.create(i))._original = i : (c = i, i = i._original);
                var l = o(u._compiled), p = !l;
                this.data = e, this.props = t, this.children = r, this.parent = i, this.listeners = e.on || n, 
                this.injections = it(u.inject, i), this.slots = function() {
                    return s.$slots || ct(e.scopedSlots, s.$slots = ot(r, i)), s.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return ct(e.scopedSlots, this.slots());
                    }
                }), l && (this.$options = u, this.$slots = this.slots(), this.$scopedSlots = ct(e.scopedSlots, this.$slots)), 
                u._scopeId ? this._c = function(e, t, n, r) {
                    var o = Pt(c, e, t, n, r, p);
                    return o && !Array.isArray(o) && (o.fnScopeId = u._scopeId, o.fnContext = i), o;
                } : this._c = function(e, t, n, r) {
                    return Pt(c, e, t, n, r, p);
                };
            }
            function St(e, t, n, r, i) {
                var o = function(e) {
                    var t = new ce(e.tag, e.data, e.children && e.children.slice(), e.text, e.elm, e.context, e.componentOptions, e.asyncFactory);
                    return t.ns = e.ns, t.isStatic = e.isStatic, t.key = e.key, t.isComment = e.isComment, 
                    t.fnContext = e.fnContext, t.fnOptions = e.fnOptions, t.fnScopeId = e.fnScopeId, 
                    t.asyncMeta = e.asyncMeta, t.isCloned = !0, t;
                }(e);
                return o.fnContext = n, o.fnOptions = r, t.slot && ((o.data || (o.data = {})).slot = t.slot), 
                o;
            }
            function Rt(e, t) {
                for (var n in t) e[w(n)] = t[n];
            }
            Ct(At.prototype);
            var Nt = {
                init: function(e, t) {
                    if (e.componentInstance && !e.componentInstance._isDestroyed && e.data.keepAlive) {
                        var n = e;
                        Nt.prepatch(n, n);
                    } else (e.componentInstance = function(e, t) {
                        var n = {
                            _isComponent: !0,
                            _parentVnode: e,
                            parent: t
                        }, r = e.data.inlineTemplate;
                        return i(r) && (n.render = r.render, n.staticRenderFns = r.staticRenderFns), new e.componentOptions.Ctor(n);
                    }(e, $t)).$mount(t ? e.elm : void 0, t);
                },
                prepatch: function(e, t) {
                    var r = t.componentOptions;
                    !function(e, t, r, i, o) {
                        var a = i.data.scopedSlots, c = e.$scopedSlots, s = !!(a && !a.$stable || c !== n && !c.$stable || a && e.$scopedSlots.$key !== a.$key), u = !!(o || e.$options._renderChildren || s);
                        if (e.$options._parentVnode = i, e.$vnode = i, e._vnode && (e._vnode.parent = i), 
                        e.$options._renderChildren = o, e.$attrs = i.data.attrs || n, e.$listeners = r || n, 
                        t && e.$options.props) {
                            ge(!1);
                            for (var l = e._props, p = e.$options._propKeys || [], f = 0; f < p.length; f++) {
                                var h = p[f], d = e.$options.props;
                                l[h] = xe(h, d, t, e);
                            }
                            ge(!0), e.$options.propsData = t;
                        }
                        e._$updateProperties && e._$updateProperties(e), r = r || n;
                        var g = e.$options._parentListeners;
                        e.$options._parentListeners = r, jt(e, r, g), u && (e.$slots = ot(o, i.context), 
                        e.$forceUpdate());
                    }(t.componentInstance = e.componentInstance, r.propsData, r.listeners, t, r.children);
                },
                insert: function(e) {
                    var t = e.context, n = e.componentInstance;
                    n._isMounted || (Wt(n, "onServiceCreated"), Wt(n, "onServiceAttached"), n._isMounted = !0, 
                    Wt(n, "mounted")), e.data.keepAlive && (t._isMounted ? function(e) {
                        e._inactive = !1, qt.push(e);
                    }(n) : Bt(n, !0));
                },
                destroy: function(e) {
                    var t = e.componentInstance;
                    t._isDestroyed || (e.data.keepAlive ? function e(t, n) {
                        if (!(n && (t._directInactive = !0, Ft(t)) || t._inactive)) {
                            t._inactive = !0;
                            for (var r = 0; r < t.$children.length; r++) e(t.$children[r]);
                            Wt(t, "deactivated");
                        }
                    }(t, !0) : t.$destroy());
                }
            }, Ot = Object.keys(Nt);
            function It(e, t, a, s, u) {
                if (!r(e)) {
                    var l = a.$options._base;
                    if (c(e) && (e = l.extend(e)), "function" == typeof e) {
                        var f;
                        if (r(e.cid) && void 0 === (e = function(e, t) {
                            if (o(e.error) && i(e.errorComp)) return e.errorComp;
                            if (i(e.resolved)) return e.resolved;
                            var n = Ut;
                            if (n && i(e.owners) && -1 === e.owners.indexOf(n) && e.owners.push(n), o(e.loading) && i(e.loadingComp)) return e.loadingComp;
                            if (n && !i(e.owners)) {
                                var a = e.owners = [ n ], s = !0, u = null, l = null;
                                n.$on("hook:destroyed", function() {
                                    return m(a, n);
                                });
                                var f = function(e) {
                                    for (var t = 0, n = a.length; t < n; t++) a[t].$forceUpdate();
                                    e && (a.length = 0, null !== u && (clearTimeout(u), u = null), null !== l && (clearTimeout(l), 
                                    l = null));
                                }, h = U(function(n) {
                                    e.resolved = Mt(n, t), s ? a.length = 0 : f(!0);
                                }), d = U(function(t) {
                                    i(e.errorComp) && (e.error = !0, f(!0));
                                }), g = e(h, d);
                                return c(g) && (p(g) ? r(e.resolved) && g.then(h, d) : p(g.component) && (g.component.then(h, d), 
                                i(g.error) && (e.errorComp = Mt(g.error, t)), i(g.loading) && (e.loadingComp = Mt(g.loading, t), 
                                0 === g.delay ? e.loading = !0 : u = setTimeout(function() {
                                    u = null, r(e.resolved) && r(e.error) && (e.loading = !0, f(!1));
                                }, g.delay || 200)), i(g.timeout) && (l = setTimeout(function() {
                                    l = null, r(e.resolved) && d(null);
                                }, g.timeout)))), s = !1, e.loading ? e.loadingComp : e.resolved;
                            }
                        }(f = e, l))) return function(e, t, n, r, i) {
                            var o = ue();
                            return o.asyncFactory = e, o.asyncMeta = {
                                data: t,
                                context: n,
                                children: r,
                                tag: i
                            }, o;
                        }(f, t, a, s, u);
                        t = t || {}, pn(e), i(t.model) && function(e, t) {
                            var n = e.model && e.model.prop || "value", r = e.model && e.model.event || "input";
                            (t.attrs || (t.attrs = {}))[n] = t.model.value;
                            var o = t.on || (t.on = {}), a = o[r], c = t.model.callback;
                            i(a) ? (Array.isArray(a) ? -1 === a.indexOf(c) : a !== c) && (o[r] = [ c ].concat(a)) : o[r] = c;
                        }(e.options, t);
                        var h = function(e, t, n, o) {
                            var a = t.options.props;
                            if (r(a)) return Ye(e, t, {}, o);
                            var c = {}, s = e.attrs, u = e.props;
                            if (i(s) || i(u)) for (var l in a) {
                                var p = C(l);
                                Qe(c, u, l, p, !0) || Qe(c, s, l, p, !1);
                            }
                            return Ye(e, t, c, o);
                        }(t, e, 0, a);
                        if (o(e.options.functional)) return function(e, t, r, o, a) {
                            var c = e.options, s = {}, u = c.props;
                            if (i(u)) for (var l in u) s[l] = xe(l, u, t || n); else i(r.attrs) && Rt(s, r.attrs), 
                            i(r.props) && Rt(s, r.props);
                            var p = new At(r, s, a, o, e), f = c.render.call(null, p._c, p);
                            if (f instanceof ce) return St(f, r, p.parent, c);
                            if (Array.isArray(f)) {
                                for (var h = et(f) || [], d = new Array(h.length), g = 0; g < h.length; g++) d[g] = St(h[g], r, p.parent, c);
                                return d;
                            }
                        }(e, h, t, a, s);
                        var d = t.on;
                        if (t.on = t.nativeOn, o(e.options.abstract)) {
                            var g = t.slot;
                            t = {}, g && (t.slot = g);
                        }
                        !function(e) {
                            for (var t = e.hook || (e.hook = {}), n = 0; n < Ot.length; n++) {
                                var r = Ot[n], i = t[r], o = Nt[r];
                                i === o || i && i._merged || (t[r] = i ? xt(o, i) : o);
                            }
                        }(t);
                        var v = e.options.name || u;
                        return new ce("vue-component-" + e.cid + (v ? "-" + v : ""), t, void 0, void 0, void 0, a, {
                            Ctor: e,
                            propsData: h,
                            listeners: d,
                            tag: u,
                            children: s
                        }, f);
                    }
                }
            }
            function xt(e, t) {
                var n = function(n, r) {
                    e(n, r), t(n, r);
                };
                return n._merged = !0, n;
            }
            function Pt(e, t, n, s, u, l) {
                return (Array.isArray(n) || a(n)) && (u = s, s = n, n = void 0), o(l) && (u = 2), 
                function(e, t, n, a, s) {
                    return i(n) && i(n.__ob__) ? ue() : (i(n) && i(n.is) && (t = n.is), t ? (Array.isArray(a) && "function" == typeof a[0] && ((n = n || {}).scopedSlots = {
                        default: a[0]
                    }, a.length = 0), 2 === s ? a = et(a) : 1 === s && (a = function(e) {
                        for (var t = 0; t < e.length; t++) if (Array.isArray(e[t])) return Array.prototype.concat.apply([], e);
                        return e;
                    }(a)), "string" == typeof t ? (l = e.$vnode && e.$vnode.ns || H.getTagNamespace(t), 
                    u = H.isReservedTag(t) ? new ce(H.parsePlatformTagName(t), n, a, void 0, void 0, e) : n && n.pre || !i(p = Ie(e.$options, "components", t)) ? new ce(t, n, a, void 0, void 0, e) : It(p, n, e, a, t)) : u = It(t, n, e, a), 
                    Array.isArray(u) ? u : i(u) ? (i(l) && function e(t, n, a) {
                        if (t.ns = n, "foreignObject" === t.tag && (n = void 0, a = !0), i(t.children)) for (var c = 0, s = t.children.length; c < s; c++) {
                            var u = t.children[c];
                            i(u.tag) && (r(u.ns) || o(a) && "svg" !== u.tag) && e(u, n, a);
                        }
                    }(u, l), i(n) && function(e) {
                        c(e.style) && Xe(e.style), c(e.class) && Xe(e.class);
                    }(n), u) : ue()) : ue());
                    var u, l, p;
                }(e, t, n, s, u);
            }
            var kt, Ut = null;
            function Mt(e, t) {
                return (e.__esModule || te && "Module" === e[Symbol.toStringTag]) && (e = e.default), 
                c(e) ? t.extend(e) : e;
            }
            function Vt(e) {
                return e.isComment && e.asyncFactory;
            }
            function Ht(e, t) {
                kt.$on(e, t);
            }
            function Dt(e, t) {
                kt.$off(e, t);
            }
            function Lt(e, t) {
                var n = kt;
                return function r() {
                    var i = t.apply(null, arguments);
                    null !== i && n.$off(e, r);
                };
            }
            function jt(e, t, n) {
                kt = e, function(e, t, n, i, a, c) {
                    var s, u, l, p;
                    for (s in e) u = e[s], l = t[s], p = Je(s), r(u) || (r(l) ? (r(u.fns) && (u = e[s] = Ze(u, c)), 
                    o(p.once) && (u = e[s] = a(p.name, u, p.capture)), n(p.name, u, p.capture, p.passive, p.params)) : u !== l && (l.fns = u, 
                    e[s] = l));
                    for (s in t) r(e[s]) && i((p = Je(s)).name, t[s], p.capture);
                }(t, n || {}, Ht, Dt, Lt, e), kt = void 0;
            }
            var $t = null;
            function Ft(e) {
                for (;e && (e = e.$parent); ) if (e._inactive) return !0;
                return !1;
            }
            function Bt(e, t) {
                if (t) {
                    if (e._directInactive = !1, Ft(e)) return;
                } else if (e._directInactive) return;
                if (e._inactive || null === e._inactive) {
                    e._inactive = !1;
                    for (var n = 0; n < e.$children.length; n++) Bt(e.$children[n]);
                    Wt(e, "activated");
                }
            }
            function Wt(e, t) {
                oe();
                var n = e.$options[t], r = t + " hook";
                if (n) for (var i = 0, o = n.length; i < o; i++) Ve(n[i], e, null, e, r);
                e._hasHookEvent && e.$emit("hook:" + t), ae();
            }
            var zt = [], qt = [], Gt = {}, Kt = !1, Xt = !1, Jt = 0, Zt = Date.now;
            if (B && !G) {
                var Yt = window.performance;
                Yt && "function" == typeof Yt.now && Zt() > document.createEvent("Event").timeStamp && (Zt = function() {
                    return Yt.now();
                });
            }
            function Qt() {
                var e, t;
                for (Zt(), Xt = !0, zt.sort(function(e, t) {
                    return e.id - t.id;
                }), Jt = 0; Jt < zt.length; Jt++) (e = zt[Jt]).before && e.before(), t = e.id, Gt[t] = null, 
                e.run();
                var n = qt.slice(), r = zt.slice();
                Jt = zt.length = qt.length = 0, Gt = {}, Kt = Xt = !1, function(e) {
                    for (var t = 0; t < e.length; t++) e[t]._inactive = !0, Bt(e[t], !0);
                }(n), function(e) {
                    for (var t = e.length; t--; ) {
                        var n = e[t], r = n.vm;
                        r._watcher === n && r._isMounted && !r._isDestroyed && Wt(r, "updated");
                    }
                }(r), Y && H.devtools && Y.emit("flush");
            }
            var en = 0, tn = function(e, t, n, r, i) {
                this.vm = e, i && (e._watcher = this), e._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++en, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new ee(), this.newDepIds = new ee(), this.expression = "", 
                "function" == typeof t ? this.getter = t : (this.getter = function(e) {
                    if (!$.test(e)) {
                        var t = e.split(".");
                        return function(e) {
                            for (var n = 0; n < t.length; n++) {
                                if (!e) return;
                                e = e[t[n]];
                            }
                            return e;
                        };
                    }
                }(t), this.getter || (this.getter = O)), this.value = this.lazy ? void 0 : this.get();
            };
            tn.prototype.get = function() {
                var e;
                oe(this);
                var t = this.vm;
                try {
                    e = this.getter.call(t, t);
                } catch (e) {
                    if (!this.user) throw e;
                    Me(e, t, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && Xe(e), ae(), this.cleanupDeps();
                }
                return e;
            }, tn.prototype.addDep = function(e) {
                var t = e.id;
                this.newDepIds.has(t) || (this.newDepIds.add(t), this.newDeps.push(e), this.depIds.has(t) || e.addSub(this));
            }, tn.prototype.cleanupDeps = function() {
                for (var e = this.deps.length; e--; ) {
                    var t = this.deps[e];
                    this.newDepIds.has(t.id) || t.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, tn.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : function(e) {
                    var t = e.id;
                    if (null == Gt[t]) {
                        if (Gt[t] = !0, Xt) {
                            for (var n = zt.length - 1; n > Jt && zt[n].id > e.id; ) n--;
                            zt.splice(n + 1, 0, e);
                        } else zt.push(e);
                        Kt || (Kt = !0, Ge(Qt));
                    }
                }(this);
            }, tn.prototype.run = function() {
                if (this.active) {
                    var e = this.get();
                    if (e !== this.value || c(e) || this.deep) {
                        var t = this.value;
                        if (this.value = e, this.user) try {
                            this.cb.call(this.vm, e, t);
                        } catch (e) {
                            Me(e, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, e, t);
                    }
                }
            }, tn.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, tn.prototype.depend = function() {
                for (var e = this.deps.length; e--; ) this.deps[e].depend();
            }, tn.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || m(this.vm._watchers, this);
                    for (var e = this.deps.length; e--; ) this.deps[e].removeSub(this);
                    this.active = !1;
                }
            };
            var nn = {
                enumerable: !0,
                configurable: !0,
                get: O,
                set: O
            };
            function rn(e, t, n) {
                nn.get = function() {
                    return this[t][n];
                }, nn.set = function(e) {
                    this[t][n] = e;
                }, Object.defineProperty(e, n, nn);
            }
            var on = {
                lazy: !0
            };
            function an(e, t, n) {
                var r = !Z();
                "function" == typeof n ? (nn.get = r ? cn(t) : sn(n), nn.set = O) : (nn.get = n.get ? r && !1 !== n.cache ? cn(t) : sn(n.get) : O, 
                nn.set = n.set || O), Object.defineProperty(e, t, nn);
            }
            function cn(e) {
                return function() {
                    var t = this._computedWatchers && this._computedWatchers[e];
                    if (t) return t.dirty && t.evaluate(), ie.SharedObject.target && t.depend(), t.value;
                };
            }
            function sn(e) {
                return function() {
                    return e.call(this, this);
                };
            }
            function un(e, t, n, r) {
                return u(n) && (r = n, n = n.handler), "string" == typeof n && (n = e[n]), e.$watch(t, n, r);
            }
            var ln = 0;
            function pn(e) {
                var t = e.options;
                if (e.super) {
                    var n = pn(e.super);
                    if (n !== e.superOptions) {
                        e.superOptions = n;
                        var r = function(e) {
                            var t, n = e.options, r = e.sealedOptions;
                            for (var i in n) n[i] !== r[i] && (t || (t = {}), t[i] = n[i]);
                            return t;
                        }(e);
                        r && R(e.extendOptions, r), (t = e.options = Oe(n, e.extendOptions)).name && (t.components[t.name] = e);
                    }
                }
                return t;
            }
            function fn(e) {
                this._init(e);
            }
            function hn(e) {
                return e && (e.Ctor.options.name || e.tag);
            }
            function dn(e, t) {
                return Array.isArray(e) ? e.indexOf(t) > -1 : "string" == typeof e ? e.split(",").indexOf(t) > -1 : !!function(e) {
                    return "[object RegExp]" === s.call(e);
                }(e) && e.test(t);
            }
            function gn(e, t) {
                var n = e.cache, r = e.keys, i = e._vnode;
                for (var o in n) {
                    var a = n[o];
                    if (a) {
                        var c = hn(a.componentOptions);
                        c && !t(c) && mn(n, o, r, i);
                    }
                }
            }
            function mn(e, t, n, r) {
                var i = e[t];
                !i || r && i.tag === r.tag || i.componentInstance.$destroy(), e[t] = null, m(n, t);
            }
            (function(e) {
                e.prototype._init = function(e) {
                    var t = this;
                    t._uid = ln++, t._isVue = !0, e && e._isComponent ? function(e, t) {
                        var n = e.$options = Object.create(e.constructor.options), r = t._parentVnode;
                        n.parent = t.parent, n._parentVnode = r;
                        var i = r.componentOptions;
                        n.propsData = i.propsData, n._parentListeners = i.listeners, n._renderChildren = i.children, 
                        n._componentTag = i.tag, t.render && (n.render = t.render, n.staticRenderFns = t.staticRenderFns);
                    }(t, e) : t.$options = Oe(pn(t.constructor), e || {}, t), t._renderProxy = t, t._self = t, 
                    function(e) {
                        var t = e.$options, n = t.parent;
                        if (n && !t.abstract) {
                            for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                            n.$children.push(e);
                        }
                        e.$parent = n, e.$root = n ? n.$root : e, e.$children = [], e.$refs = {}, e._watcher = null, 
                        e._inactive = null, e._directInactive = !1, e._isMounted = !1, e._isDestroyed = !1, 
                        e._isBeingDestroyed = !1;
                    }(t), function(e) {
                        e._events = Object.create(null), e._hasHookEvent = !1;
                        var t = e.$options._parentListeners;
                        t && jt(e, t);
                    }(t), function(e) {
                        e._vnode = null, e._staticTrees = null;
                        var t = e.$options, r = e.$vnode = t._parentVnode, i = r && r.context;
                        e.$slots = ot(t._renderChildren, i), e.$scopedSlots = n, e._c = function(t, n, r, i) {
                            return Pt(e, t, n, r, i, !1);
                        }, e.$createElement = function(t, n, r, i) {
                            return Pt(e, t, n, r, i, !0);
                        };
                        var o = r && r.data;
                        _e(e, "$attrs", o && o.attrs || n, null, !0), _e(e, "$listeners", t._parentListeners || n, null, !0);
                    }(t), Wt(t, "beforeCreate"), !t._$fallback && rt(t), function(e) {
                        e._watchers = [];
                        var t = e.$options;
                        t.props && function(e, t) {
                            var n = e.$options.propsData || {}, r = e._props = {}, i = e.$options._propKeys = [];
                            !e.$parent || ge(!1);
                            var o = function(o) {
                                i.push(o);
                                var a = xe(o, t, n, e);
                                _e(r, o, a), o in e || rn(e, "_props", o);
                            };
                            for (var a in t) o(a);
                            ge(!0);
                        }(e, t.props), t.methods && function(e, t) {
                            for (var n in e.$options.props, t) e[n] = "function" != typeof t[n] ? O : A(t[n], e);
                        }(e, t.methods), t.data ? function(e) {
                            var t = e.$options.data;
                            u(t = e._data = "function" == typeof t ? function(e, t) {
                                oe();
                                try {
                                    return e.call(t, t);
                                } catch (e) {
                                    return Me(e, t, "data()"), {};
                                } finally {
                                    ae();
                                }
                            }(t, e) : t || {}) || (t = {});
                            for (var n = Object.keys(t), r = e.$options.props, i = (e.$options.methods, n.length); i--; ) {
                                var o = n[i];
                                r && y(r, o) || D(o) || rn(e, "_data", o);
                            }
                            ye(t, !0);
                        }(e) : ye(e._data = {}, !0), t.computed && function(e, t) {
                            var n = e._computedWatchers = Object.create(null), r = Z();
                            for (var i in t) {
                                var o = t[i], a = "function" == typeof o ? o : o.get;
                                r || (n[i] = new tn(e, a || O, O, on)), i in e || an(e, i, o);
                            }
                        }(e, t.computed), t.watch && t.watch !== X && function(e, t) {
                            for (var n in t) {
                                var r = t[n];
                                if (Array.isArray(r)) for (var i = 0; i < r.length; i++) un(e, n, r[i]); else un(e, n, r);
                            }
                        }(e, t.watch);
                    }(t), !t._$fallback && nt(t), !t._$fallback && Wt(t, "created"), t.$options.el && t.$mount(t.$options.el);
                };
            })(fn), function(e) {
                Object.defineProperty(e.prototype, "$data", {
                    get: function() {
                        return this._data;
                    }
                }), Object.defineProperty(e.prototype, "$props", {
                    get: function() {
                        return this._props;
                    }
                }), e.prototype.$set = Te, e.prototype.$delete = we, e.prototype.$watch = function(e, t, n) {
                    if (u(t)) return un(this, e, t, n);
                    (n = n || {}).user = !0;
                    var r = new tn(this, e, t, n);
                    if (n.immediate) try {
                        t.call(this, r.value);
                    } catch (e) {
                        Me(e, this, 'callback for immediate watcher "' + r.expression + '"');
                    }
                    return function() {
                        r.teardown();
                    };
                };
            }(fn), function(e) {
                var t = /^hook:/;
                e.prototype.$on = function(e, n) {
                    var r = this;
                    if (Array.isArray(e)) for (var i = 0, o = e.length; i < o; i++) r.$on(e[i], n); else (r._events[e] || (r._events[e] = [])).push(n), 
                    t.test(e) && (r._hasHookEvent = !0);
                    return r;
                }, e.prototype.$once = function(e, t) {
                    var n = this;
                    function r() {
                        n.$off(e, r), t.apply(n, arguments);
                    }
                    return r.fn = t, n.$on(e, r), n;
                }, e.prototype.$off = function(e, t) {
                    var n = this;
                    if (!arguments.length) return n._events = Object.create(null), n;
                    if (Array.isArray(e)) {
                        for (var r = 0, i = e.length; r < i; r++) n.$off(e[r], t);
                        return n;
                    }
                    var o, a = n._events[e];
                    if (!a) return n;
                    if (!t) return n._events[e] = null, n;
                    for (var c = a.length; c--; ) if ((o = a[c]) === t || o.fn === t) {
                        a.splice(c, 1);
                        break;
                    }
                    return n;
                }, e.prototype.$emit = function(e) {
                    var t = this, n = t._events[e];
                    if (n) {
                        n = n.length > 1 ? S(n) : n;
                        for (var r = S(arguments, 1), i = 'event handler for "' + e + '"', o = 0, a = n.length; o < a; o++) Ve(n[o], t, r, t, i);
                    }
                    return t;
                };
            }(fn), function(e) {
                e.prototype._update = function(e, t) {
                    var n = this, r = n.$el, i = n._vnode, o = function(e) {
                        var t = $t;
                        return $t = e, function() {
                            $t = t;
                        };
                    }(n);
                    n._vnode = e, n.$el = i ? n.__patch__(i, e) : n.__patch__(n.$el, e, t, !1), o(), 
                    r && (r.__vue__ = null), n.$el && (n.$el.__vue__ = n), n.$vnode && n.$parent && n.$vnode === n.$parent._vnode && (n.$parent.$el = n.$el);
                }, e.prototype.$forceUpdate = function() {
                    this._watcher && this._watcher.update();
                }, e.prototype.$destroy = function() {
                    var e = this;
                    if (!e._isBeingDestroyed) {
                        Wt(e, "beforeDestroy"), e._isBeingDestroyed = !0;
                        var t = e.$parent;
                        !t || t._isBeingDestroyed || e.$options.abstract || m(t.$children, e), e._watcher && e._watcher.teardown();
                        for (var n = e._watchers.length; n--; ) e._watchers[n].teardown();
                        e._data.__ob__ && e._data.__ob__.vmCount--, e._isDestroyed = !0, e.__patch__(e._vnode, null), 
                        Wt(e, "destroyed"), e.$off(), e.$el && (e.$el.__vue__ = null), e.$vnode && (e.$vnode.parent = null);
                    }
                };
            }(fn), function(e) {
                Ct(e.prototype), e.prototype.$nextTick = function(e) {
                    return Ge(e, this);
                }, e.prototype._render = function() {
                    var e, t = this, n = t.$options, r = n.render, i = n._parentVnode;
                    i && (t.$scopedSlots = ct(i.data.scopedSlots, t.$slots, t.$scopedSlots)), t.$vnode = i;
                    try {
                        Ut = t, e = r.call(t._renderProxy, t.$createElement);
                    } catch (n) {
                        Me(n, t, "render"), e = t._vnode;
                    } finally {
                        Ut = null;
                    }
                    return Array.isArray(e) && 1 === e.length && (e = e[0]), e instanceof ce || (e = ue()), 
                    e.parent = i, e;
                };
            }(fn);
            var vn = [ String, RegExp, Array ], yn = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: vn,
                        exclude: vn,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var e in this.cache) mn(this.cache, e, this.keys);
                    },
                    mounted: function() {
                        var e = this;
                        this.$watch("include", function(t) {
                            gn(e, function(e) {
                                return dn(t, e);
                            });
                        }), this.$watch("exclude", function(t) {
                            gn(e, function(e) {
                                return !dn(t, e);
                            });
                        });
                    },
                    render: function() {
                        var e = this.$slots.default, t = function(e) {
                            if (Array.isArray(e)) for (var t = 0; t < e.length; t++) {
                                var n = e[t];
                                if (i(n) && (i(n.componentOptions) || Vt(n))) return n;
                            }
                        }(e), n = t && t.componentOptions;
                        if (n) {
                            var r = hn(n), o = this.include, a = this.exclude;
                            if (o && (!r || !dn(o, r)) || a && r && dn(a, r)) return t;
                            var c = this.cache, s = this.keys, u = null == t.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : t.key;
                            c[u] ? (t.componentInstance = c[u].componentInstance, m(s, u), s.push(u)) : (c[u] = t, 
                            s.push(u), this.max && s.length > parseInt(this.max) && mn(c, s[0], s, this._vnode)), 
                            t.data.keepAlive = !0;
                        }
                        return t || e && e[0];
                    }
                }
            };
            (function(e) {
                var t = {
                    get: function() {
                        return H;
                    }
                };
                Object.defineProperty(e, "config", t), e.util = {
                    warn: ne,
                    extend: R,
                    mergeOptions: Oe,
                    defineReactive: _e
                }, e.set = Te, e.delete = we, e.nextTick = Ge, e.observable = function(e) {
                    return ye(e), e;
                }, e.options = Object.create(null), M.forEach(function(t) {
                    e.options[t + "s"] = Object.create(null);
                }), e.options._base = e, R(e.options.components, yn), function(e) {
                    e.use = function(e) {
                        var t = this._installedPlugins || (this._installedPlugins = []);
                        if (t.indexOf(e) > -1) return this;
                        var n = S(arguments, 1);
                        return n.unshift(this), "function" == typeof e.install ? e.install.apply(e, n) : "function" == typeof e && e.apply(null, n), 
                        t.push(e), this;
                    };
                }(e), function(e) {
                    e.mixin = function(e) {
                        return this.options = Oe(this.options, e), this;
                    };
                }(e), function(e) {
                    e.cid = 0;
                    var t = 1;
                    e.extend = function(e) {
                        e = e || {};
                        var n = this, r = n.cid, i = e._Ctor || (e._Ctor = {});
                        if (i[r]) return i[r];
                        var o = e.name || n.options.name, a = function(e) {
                            this._init(e);
                        };
                        return (a.prototype = Object.create(n.prototype)).constructor = a, a.cid = t++, 
                        a.options = Oe(n.options, e), a.super = n, a.options.props && function(e) {
                            var t = e.options.props;
                            for (var n in t) rn(e.prototype, "_props", n);
                        }(a), a.options.computed && function(e) {
                            var t = e.options.computed;
                            for (var n in t) an(e.prototype, n, t[n]);
                        }(a), a.extend = n.extend, a.mixin = n.mixin, a.use = n.use, M.forEach(function(e) {
                            a[e] = n[e];
                        }), o && (a.options.components[o] = a), a.superOptions = n.options, a.extendOptions = e, 
                        a.sealedOptions = R({}, a.options), i[r] = a, a;
                    };
                }(e), function(e) {
                    M.forEach(function(t) {
                        e[t] = function(e, n) {
                            return n ? ("component" === t && u(n) && (n.name = n.name || e, n = this.options._base.extend(n)), 
                            "directive" === t && "function" == typeof n && (n = {
                                bind: n,
                                update: n
                            }), this.options[t + "s"][e] = n, n) : this.options[t + "s"][e];
                        };
                    });
                }(e);
            })(fn), Object.defineProperty(fn.prototype, "$isServer", {
                get: Z
            }), Object.defineProperty(fn.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(fn, "FunctionalRenderContext", {
                value: At
            }), fn.version = "2.6.11";
            var _n = "[object Array]", Tn = "[object Object]";
            function wn(e, t, n) {
                e[t] = n;
            }
            function En(e) {
                return Object.prototype.toString.call(e);
            }
            function bn(e) {
                if (e.__next_tick_callbacks && e.__next_tick_callbacks.length) {
                    if (Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "电工大师",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var t = e.$scope;
                        console.log("[" + +new Date() + "][" + (t.is || t.route) + "][" + e._uid + "]:flushCallbacks[" + e.__next_tick_callbacks.length + "]");
                    }
                    var n = e.__next_tick_callbacks.slice(0);
                    e.__next_tick_callbacks.length = 0;
                    for (var r = 0; r < n.length; r++) n[r]();
                }
            }
            function Cn(e, t) {
                return t && (t._isVue || t.__v_isMPComponent) ? {} : t;
            }
            function An() {}
            var Sn = _(function(e) {
                var t = {}, n = /:(.+)/;
                return e.split(/;(?![^(]*\))/g).forEach(function(e) {
                    if (e) {
                        var r = e.split(n);
                        r.length > 1 && (t[r[0].trim()] = r[1].trim());
                    }
                }), t;
            }), Rn = [ "createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent" ], Nn = [ "onLaunch", "onShow", "onHide", "onUniNViewMessage", "onPageNotFound", "onThemeChange", "onError", "onUnhandledRejection", "onInit", "onLoad", "onReady", "onUnload", "onPullDownRefresh", "onReachBottom", "onTabItemTap", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onResize", "onPageScroll", "onNavigationBarButtonTap", "onBackPress", "onNavigationBarSearchInputChanged", "onNavigationBarSearchInputConfirmed", "onNavigationBarSearchInputClicked", "onUploadDouyinVideo", "onNFCReadMessage", "onPageShow", "onPageHide", "onPageResize" ];
            fn.prototype.__patch__ = function(e, t) {
                var n = this;
                if (null !== t && ("page" === this.mpType || "component" === this.mpType)) {
                    var r = this.$scope, i = Object.create(null);
                    try {
                        i = function(e) {
                            var t = Object.create(null);
                            [].concat(Object.keys(e._data || {}), Object.keys(e._computedWatchers || {})).reduce(function(t, n) {
                                return t[n] = e[n], t;
                            }, t);
                            var n = e.__composition_api_state__ || e.__secret_vfa_state__, r = n && n.rawBindings;
                            return r && Object.keys(r).forEach(function(n) {
                                t[n] = e[n];
                            }), Object.assign(t, e.$mp.data || {}), Array.isArray(e.$options.behaviors) && -1 !== e.$options.behaviors.indexOf("uni://form-field") && (t.name = e.name, 
                            t.value = e.value), JSON.parse(JSON.stringify(t, Cn));
                        }(this);
                    } catch (e) {
                        console.error(e);
                    }
                    i.__webviewId__ = r.data.__webviewId__;
                    var o = Object.create(null);
                    Object.keys(i).forEach(function(e) {
                        o[e] = r.data[e];
                    });
                    var a = !1 === this.$shouldDiffData ? i : function(e, t) {
                        var n = {};
                        return function e(t, n) {
                            if (t !== n) {
                                var r = En(t), i = En(n);
                                if (r == Tn && i == Tn) {
                                    if (Object.keys(t).length >= Object.keys(n).length) for (var o in n) {
                                        var a = t[o];
                                        void 0 === a ? t[o] = null : e(a, n[o]);
                                    }
                                } else r == _n && i == _n && t.length >= n.length && n.forEach(function(n, r) {
                                    e(t[r], n);
                                });
                            }
                        }(e, t), function e(t, n, r, i) {
                            if (t !== n) {
                                var o = En(t), a = En(n);
                                if (o == Tn) if (a != Tn || Object.keys(t).length < Object.keys(n).length) wn(i, r, t); else {
                                    var c = function(o) {
                                        var a = t[o], c = n[o], s = En(a), u = En(c);
                                        if (s != _n && s != Tn) a !== n[o] && function(e, t) {
                                            return "[object Null]" !== e && "[object Undefined]" !== e || "[object Null]" !== t && "[object Undefined]" !== t;
                                        }(s, u) && wn(i, ("" == r ? "" : r + ".") + o, a); else if (s == _n) u != _n || a.length < c.length ? wn(i, ("" == r ? "" : r + ".") + o, a) : a.forEach(function(t, n) {
                                            e(t, c[n], ("" == r ? "" : r + ".") + o + "[" + n + "]", i);
                                        }); else if (s == Tn) if (u != Tn || Object.keys(a).length < Object.keys(c).length) wn(i, ("" == r ? "" : r + ".") + o, a); else for (var l in a) e(a[l], c[l], ("" == r ? "" : r + ".") + o + "." + l, i);
                                    };
                                    for (var s in t) c(s);
                                } else o == _n ? a != _n || t.length < n.length ? wn(i, r, t) : t.forEach(function(t, o) {
                                    e(t, n[o], r + "[" + o + "]", i);
                                }) : wn(i, r, t);
                            }
                        }(e, t, "", n), n;
                    }(i, o);
                    Object.keys(a).length ? (Object({
                        VUE_APP_DARK_MODE: "false",
                        VUE_APP_NAME: "电工大师",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + this._uid + "]差量更新", JSON.stringify(a)), 
                    this.__next_tick_pending = !0, r.setData(a, function() {
                        n.__next_tick_pending = !1, bn(n);
                    })) : bn(this);
                }
            }, fn.prototype.$mount = function(e, t) {
                return function(e, t, n) {
                    return e.mpType ? ("app" === e.mpType && (e.$options.render = An), e.$options.render || (e.$options.render = An), 
                    !e._$fallback && Wt(e, "beforeMount"), new tn(e, function() {
                        e._update(e._render(), n);
                    }, O, {
                        before: function() {
                            e._isMounted && !e._isDestroyed && Wt(e, "beforeUpdate");
                        }
                    }, !0), n = !1, e) : e;
                }(this, 0, t);
            }, function(e) {
                var t = e.extend;
                e.extend = function(e) {
                    var n = (e = e || {}).methods;
                    return n && Object.keys(n).forEach(function(t) {
                        -1 !== Nn.indexOf(t) && (e[t] = n[t], delete n[t]);
                    }), t.call(this, e);
                };
                var n = e.config.optionMergeStrategies, r = n.created;
                Nn.forEach(function(e) {
                    n[e] = r;
                }), e.prototype.__lifecycle_hooks__ = Nn;
            }(fn), function(e) {
                e.config.errorHandler = function(t, n, r) {
                    e.util.warn("Error in " + r + ': "' + t.toString() + '"', n), console.error(t);
                    var i = "function" == typeof getApp && getApp();
                    i && i.onError && i.onError(t);
                };
                var t = e.prototype.$emit;
                e.prototype.$emit = function(e) {
                    if (this.$scope && e) {
                        var n = this.$scope._triggerEvent || this.$scope.triggerEvent;
                        if (n) try {
                            n.call(this.$scope, e, {
                                __args__: S(arguments, 1)
                            });
                        } catch (e) {}
                    }
                    return t.apply(this, arguments);
                }, e.prototype.$nextTick = function(e) {
                    return function(e, t) {
                        if (!e.__next_tick_pending && !function(e) {
                            return zt.find(function(t) {
                                return e._watcher === t;
                            });
                        }(e)) {
                            if (Object({
                                VUE_APP_DARK_MODE: "false",
                                VUE_APP_NAME: "电工大师",
                                VUE_APP_PLATFORM: "mp-weixin",
                                NODE_ENV: "production",
                                BASE_URL: "/"
                            }).VUE_APP_DEBUG) {
                                var n = e.$scope;
                                console.log("[" + +new Date() + "][" + (n.is || n.route) + "][" + e._uid + "]:nextVueTick");
                            }
                            return Ge(t, e);
                        }
                        if (Object({
                            VUE_APP_DARK_MODE: "false",
                            VUE_APP_NAME: "电工大师",
                            VUE_APP_PLATFORM: "mp-weixin",
                            NODE_ENV: "production",
                            BASE_URL: "/"
                        }).VUE_APP_DEBUG) {
                            var r = e.$scope;
                            console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + e._uid + "]:nextMPTick");
                        }
                        var i;
                        if (e.__next_tick_callbacks || (e.__next_tick_callbacks = []), e.__next_tick_callbacks.push(function() {
                            if (t) try {
                                t.call(e);
                            } catch (t) {
                                Me(t, e, "nextTick");
                            } else i && i(e);
                        }), !t && "undefined" != typeof Promise) return new Promise(function(e) {
                            i = e;
                        });
                    }(this, e);
                }, Rn.forEach(function(t) {
                    e.prototype[t] = function(e) {
                        return this.$scope && this.$scope[t] ? this.$scope[t](e) : "undefined" != typeof my ? "createSelectorQuery" === t ? my.createSelectorQuery(e) : "createIntersectionObserver" === t ? my.createIntersectionObserver(e) : void 0 : void 0;
                    };
                }), e.prototype.__init_provide = nt, e.prototype.__init_injections = rt, e.prototype.__call_hook = function(e, t) {
                    var n = this;
                    oe();
                    var r, i = n.$options[e], o = e + " hook";
                    if (i) for (var a = 0, c = i.length; a < c; a++) r = Ve(i[a], n, t ? [ t ] : null, n, o);
                    return n._hasHookEvent && n.$emit("hook:" + e, t), ae(), r;
                }, e.prototype.__set_model = function(t, n, r, i) {
                    Array.isArray(i) && (-1 !== i.indexOf("trim") && (r = r.trim()), -1 !== i.indexOf("number") && (r = this._n(r))), 
                    t || (t = this), e.set(t, n, r);
                }, e.prototype.__set_sync = function(t, n, r) {
                    t || (t = this), e.set(t, n, r);
                }, e.prototype.__get_orig = function(e) {
                    return u(e) && e.$orig || e;
                }, e.prototype.__get_value = function(e, t) {
                    return function e(t, n) {
                        var r = n.split("."), i = r[0];
                        return 0 === i.indexOf("__$n") && (i = parseInt(i.replace("__$n", ""))), 1 === r.length ? t[i] : e(t[i], r.slice(1).join("."));
                    }(t || this, e);
                }, e.prototype.__get_class = function(e, t) {
                    return function(e, t) {
                        return i(e) || i(t) ? function(e, t) {
                            return e ? t ? e + " " + t : e : t || "";
                        }(e, function e(t) {
                            return Array.isArray(t) ? function(t) {
                                for (var n, r = "", o = 0, a = t.length; o < a; o++) i(n = e(t[o])) && "" !== n && (r && (r += " "), 
                                r += n);
                                return r;
                            }(t) : c(t) ? function(e) {
                                var t = "";
                                for (var n in e) e[n] && (t && (t += " "), t += n);
                                return t;
                            }(t) : "string" == typeof t ? t : "";
                        }(t)) : "";
                    }(t, e);
                }, e.prototype.__get_style = function(e, t) {
                    if (!e && !t) return "";
                    var n = function(e) {
                        return Array.isArray(e) ? N(e) : "string" == typeof e ? Sn(e) : e;
                    }(e), r = t ? R(t, n) : n;
                    return Object.keys(r).map(function(e) {
                        return C(e) + ":" + r[e];
                    }).join(";");
                }, e.prototype.__map = function(e, t) {
                    var n, r, i, o, a;
                    if (Array.isArray(e)) {
                        for (n = new Array(e.length), r = 0, i = e.length; r < i; r++) n[r] = t(e[r], r);
                        return n;
                    }
                    if (c(e)) {
                        for (o = Object.keys(e), n = Object.create(null), r = 0, i = o.length; r < i; r++) n[a = o[r]] = t(e[a], a, r);
                        return n;
                    }
                    if ("number" == typeof e) {
                        for (n = new Array(e), r = 0, i = e; r < i; r++) n[r] = t(r, r);
                        return n;
                    }
                    return [];
                };
            }(fn), t.default = fn;
        }.call(this, n("c8ba"));
    },
    "6b01": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("00cd"), i = {
            N_M: new r.Unit("N·m"),
            KGF_M: new r.Unit("kgf·m", 9.80665),
            FT_LBF: new r.Unit("ft·lbf", 1.3558179482896),
            IN_LBF: new r.Unit("in·lbf", .1129848263637)
        }, o = {
            data: function() {
                return {
                    torqueAllUnits: i,
                    torqueUnits: [ i.N_M, i.KGF_M, i.FT_LBF, i.IN_LBF ],
                    torqueUnitIndex: 0,
                    torqueUnitValue: void 0,
                    efficiency: void 0
                };
            },
            methods: {
                getTorqueValue: function() {
                    return (0, r.unitConvert)(this.torqueUnitValue, this.torqueUnits[this.torqueUnitIndex], i.N_M);
                },
                convertTorqueValue: function(e) {
                    return {
                        N_M: (0, r.unitConvert)(e, i.N_M, i.N_M),
                        KGF_M: (0, r.unitConvert)(e, i.N_M, i.KGF_M),
                        FT_LBF: (0, r.unitConvert)(e, i.N_M, i.FT_LBF),
                        IN_LBF: (0, r.unitConvert)(e, i.N_M, i.IN_LBF)
                    };
                },
                getEfficiencyValue: function() {
                    return this.efficiency;
                }
            }
        };
        t.default = o;
    },
    "6d71c": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("9912"), i = n("00cd"), o = {
            data: function() {
                return {
                    measuringUnits: [ r.MeasuringUnits.km, r.MeasuringUnits.m, r.MeasuringUnits.cm, r.MeasuringUnits.mm, r.MeasuringUnits.ft, r.MeasuringUnits.in, r.MeasuringUnits.mil, r.MeasuringUnits.yd, r.MeasuringUnits.mi, r.MeasuringUnits.nmi ],
                    measuringUnitIndex: 1,
                    measuringUnitValue: void 0
                };
            },
            methods: {
                getMeasuringUnitValue: function() {
                    return (0, i.unitConvert)(this.measuringUnitValue, this.measuringUnits[this.measuringUnitIndex], r.MeasuringUnits.m);
                }
            }
        };
        t.default = o;
    },
    "6e05": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.colors = void 0;
        var i = r(n("970b")), o = r(n("5bc3")), a = function() {
            function e(t, n, r) {
                (0, i.default)(this, e), this.color = t, this.name = n, this.fontColor = r;
            }
            return (0, o.default)(e, [ {
                key: "withValue",
                value: function(t) {
                    var n = new e(this.color, this.name, this.fontColor);
                    return n.value = t, n;
                }
            }, {
                key: "withImage",
                value: function(t) {
                    var n = new e(this.color, this.name, this.fontColor);
                    return n.image = t, n;
                }
            } ]), e;
        }(), c = {
            black: new a("black", "黑", "#fff"),
            brown: new a("brown", "棕", "#fff"),
            red: new a("red", "红", "#fff"),
            orange: new a("orange", "橙", "#fff"),
            yellow: new a("yellow", "黄", "#333"),
            green: new a("green", "绿", "#fff"),
            blue: new a("blue", "蓝", "#fff"),
            purple: new a("purple", "紫", "#fff"),
            gray: new a("gray", "灰", "#fff"),
            white: new a("white", "白", "#333"),
            gold: new a("gold", "金", "#333"),
            silver: new a("silver", "银", "#333"),
            none: new a("none", "无", "#333"),
            pink: new a("pink", "粉", "#333"),
            lightblue: new a("lightblue", "浅蓝", "#fff")
        };
        t.colors = c;
    },
    "6f8f": function(e, t) {
        e.exports = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                !0;
            } catch (e) {
                return !1;
            }
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    7037: function(e, t) {
        function n(t) {
            return e.exports = n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e;
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
            }, e.exports.__esModule = !0, e.exports.default = e.exports, n(t);
        }
        e.exports = n, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    7325: function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CrossSectionalConvert = void 0, t.awg2squareMillieter = f, t.millimeter2inch = l, 
        t.square2millimeter = c;
        var i = r(n("970b")), o = r(n("5bc3"));
        function a(e) {
            return parseInt(e) > 212;
        }
        function c(e) {
            return 2 * Math.sqrt(e / Math.PI);
        }
        function s(e) {
            return e / .5067;
        }
        function u(e) {
            return .5067 * e;
        }
        function l(e) {
            return e / 100 / .254;
        }
        function p(e) {
            if (a(e)) throw new Error("Invalid awg number");
            if ("4/0" == e) return -3;
            if ("3/0" == e) return -2;
            if ("2/0" == e) return -1;
            if ("1/0" == e) return 0;
            var t = parseInt(e);
            if (isNaN(t)) throw new Error("AWG " + e + " error.");
            return t;
        }
        function f(e) {
            if (a(e)) return u(e);
            var t = p(e);
            return t >= -3 && function(e) {
                return .7853981633974483 * Math.pow(.127 * Math.pow(92, (36 - e) / 39), 2);
            }(t);
        }
        var h = function() {
            function e() {
                (0, i.default)(this, e), this.squareMillimeter = void 0, this.millimeter = void 0, 
                this.kcmil = void 0, this.inch = void 0, this.awg = void 0;
            }
            return (0, o.default)(e, [ {
                key: "setSquareMillimeter",
                value: function(e) {
                    if (e <= 0) throw new Error("mm2 输入错误");
                    this.squareMillimeter = e;
                }
            }, {
                key: "setAwg",
                value: function(e) {
                    "-" != e && p(e), this.awg = e;
                }
            }, {
                key: "setMillimeter",
                value: function(e) {
                    if (e <= 0) throw new Error("mm 输入错误");
                    this.millimeter = e;
                }
            }, {
                key: "setKcmil",
                value: function(e) {
                    if (e <= 0) throw new Error("kcmil 输入错误");
                    this.kcmil = e;
                }
            }, {
                key: "setInch",
                value: function(e) {
                    if (e <= 0) throw new Error("inch 输入错误");
                    this.inch = e;
                }
            }, {
                key: "calculate",
                value: function() {
                    if (null != this.awg) {
                        var e = f(this.awg);
                        if (!1 === e) throw new Error("错误的 awg 输入");
                        this.squareMillimeter = e;
                    } else null != this.kcmil ? this.squareMillimeter = u(this.kcmil) : null != this.millimeter ? this.squareMillimeter = function(e) {
                        return Math.pow(e / 2, 2) * Math.PI;
                    }(this.millimeter) : null != this.inch && (this.squareMillimeter = function(e) {
                        return Math.pow(.254 * e * 100 / 2, 2) * Math.PI;
                    }(this.inch));
                    if (null == this.awg && this.squareMillimeter > 0) {
                        var t = function(e, t) {
                            return e >= 0 ? parseInt(e) : e >= -1 ? "2/0" : e >= -2 ? "3/0" : e >= -3 ? "4/0" : parseInt(s(t));
                        }(function(e) {
                            var t = Math.sqrt(4 * e / Math.PI);
                            return Math.log(t / .127) / Math.log(92) * -39 + 36;
                        }(this.squareMillimeter), this.squareMillimeter);
                        try {
                            p(t), this.awg = t;
                        } catch (e) {
                            this.awg = "-";
                        }
                    }
                    return null == this.millimeter && (this.millimeter = c(this.squareMillimeter)), 
                    null == this.kcmil && (this.kcmil = s(this.squareMillimeter)), null == this.inch && (this.inch = l(this.millimeter)), 
                    {
                        squareMillimeter: this.squareMillimeter,
                        millimeter: this.millimeter,
                        kcmil: this.kcmil,
                        inch: this.inch,
                        awg: this.awg
                    };
                }
            } ]), e;
        }();
        t.CrossSectionalConvert = h;
    },
    7572: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e, t, n) {
            var o = 0;
            switch (e) {
              case r.ElectricalSpecifications.IEC:
                o = function(e, t, n, r) {
                    var o = 0, a = i[e][r];
                    r > 0 && (n *= .906);
                    var c = a.findIndex(function(e) {
                        return e > t && e < n;
                    });
                    return -1 !== c && (o = a[c]), o;
                }(e, t.current, n, t.protectorIndex);
                break;

              case r.ElectricalSpecifications.NEC:
                o = function(e, t, n, r, o) {
                    var a = 0, c = i[e][o];
                    t = 1.25 * n + t;
                    var s = c.findIndex(function(e) {
                        return e > t && e < r;
                    });
                    return -1 !== s && (a = c[s]), a;
                }(e, t.current, t.discontinuousCurrent, n, t.protectorIndex);
            }
            return o;
        };
        var r = n("9bc7"), i = {
            IEC: [ [ 6, 10, 13, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 150, 160, 190, 200, 225, 250, 275, 300, 325, 350, 375, 400, 450, 500, 630, 800, 1e3, 1250, 1600, 2e3, 2500, 3200 ], [ 2, 4, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1e3, 1250 ] ],
            NEC: [ [ 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100, 110, 125, 150, 175, 200, 225, 250, 300, 350, 400, 450, 500, 600, 700, 800, 1e3, 1200, 1600, 2e3, 2500, 3e3, 4e3, 5e3, 6e3 ], [ 1, 3, 6, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100, 110, 125, 150, 175, 200, 225, 250, 300, 350, 400, 450, 500, 601, 700, 800, 1e3, 1200, 1600, 2e3, 2500, 3e3, 4e3, 5e3, 6e3 ] ]
        };
    },
    7659: function(e, t, n) {
        var r = n("448a")("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="), i = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, o = function(e) {
            var t = {};
            return e.forEach(function(e, n) {
                return t[e] = n;
            }), t;
        }(r), a = String.fromCharCode.bind(String);
        e.exports = {
            base64ToArrayBuffer: function(e) {
                for (var t = function(e) {
                    if (e = e.replace(/\s+/g, ""), !i.test(e)) throw new TypeError("malformed base64.");
                    e += "==".slice(2 - (3 & e.length));
                    for (var t, n, r, c = "", s = 0; s < e.length; ) t = o[e.charAt(s++)] << 18 | o[e.charAt(s++)] << 12 | (n = o[e.charAt(s++)]) << 6 | (r = o[e.charAt(s++)]), 
                    c += 64 === n ? a(t >> 16 & 255) : 64 === r ? a(t >> 16 & 255, t >> 8 & 255) : a(t >> 16 & 255, t >> 8 & 255, 255 & t);
                    return c;
                }(e).length, n = new Uint8Array(t), r = 0; r < t; r++) n[r] = binary.charCodeAt(r);
                return n.buffer;
            },
            arrayBufferToBase64: function(e) {
                for (var t = "", n = new Uint8Array(e), i = n.byteLength, o = 0; o < i; o++) t += String.fromCharCode(n[o]);
                return function(e) {
                    for (var t, n, i, o, a = "", c = e.length % 3, s = 0; s < e.length; ) {
                        if ((n = e.charCodeAt(s++)) > 255 || (i = e.charCodeAt(s++)) > 255 || (o = e.charCodeAt(s++)) > 255) throw new TypeError("invalid character found");
                        a += r[(t = n << 16 | i << 8 | o) >> 18 & 63] + r[t >> 12 & 63] + r[t >> 6 & 63] + r[63 & t];
                    }
                    return c ? a.slice(0, c - 3) + "===".substring(c) : a;
                }(t);
            }
        };
    },
    "7ec2": function(e, t, n) {
        var r = n("7037").default;
        function i() {
            "use strict";
            e.exports = i = function() {
                return t;
            }, e.exports.__esModule = !0, e.exports.default = e.exports;
            var t = {}, n = Object.prototype, o = n.hasOwnProperty, a = Object.defineProperty || function(e, t, n) {
                e[t] = n.value;
            }, c = "function" == typeof Symbol ? Symbol : {}, s = c.iterator || "@@iterator", u = c.asyncIterator || "@@asyncIterator", l = c.toStringTag || "@@toStringTag";
            function p(e, t, n) {
                return Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), e[t];
            }
            try {
                p({}, "");
            } catch (e) {
                p = function(e, t, n) {
                    return e[t] = n;
                };
            }
            function f(e, t, n, r) {
                var i = t && t.prototype instanceof g ? t : g, o = Object.create(i.prototype), c = new N(r || []);
                return a(o, "_invoke", {
                    value: C(e, n, c)
                }), o;
            }
            function h(e, t, n) {
                try {
                    return {
                        type: "normal",
                        arg: e.call(t, n)
                    };
                } catch (e) {
                    return {
                        type: "throw",
                        arg: e
                    };
                }
            }
            t.wrap = f;
            var d = {};
            function g() {}
            function m() {}
            function v() {}
            var y = {};
            p(y, s, function() {
                return this;
            });
            var _ = Object.getPrototypeOf, T = _ && _(_(O([])));
            T && T !== n && o.call(T, s) && (y = T);
            var w = v.prototype = g.prototype = Object.create(y);
            function E(e) {
                [ "next", "throw", "return" ].forEach(function(t) {
                    p(e, t, function(e) {
                        return this._invoke(t, e);
                    });
                });
            }
            function b(e, t) {
                var n;
                a(this, "_invoke", {
                    value: function(i, a) {
                        function c() {
                            return new t(function(n, c) {
                                !function n(i, a, c, s) {
                                    var u = h(e[i], e, a);
                                    if ("throw" !== u.type) {
                                        var l = u.arg, p = l.value;
                                        return p && "object" == r(p) && o.call(p, "__await") ? t.resolve(p.__await).then(function(e) {
                                            n("next", e, c, s);
                                        }, function(e) {
                                            n("throw", e, c, s);
                                        }) : t.resolve(p).then(function(e) {
                                            l.value = e, c(l);
                                        }, function(e) {
                                            return n("throw", e, c, s);
                                        });
                                    }
                                    s(u.arg);
                                }(i, a, n, c);
                            });
                        }
                        return n = n ? n.then(c, c) : c();
                    }
                });
            }
            function C(e, t, n) {
                var r = "suspendedStart";
                return function(i, o) {
                    if ("executing" === r) throw new Error("Generator is already running");
                    if ("completed" === r) {
                        if ("throw" === i) throw o;
                        return {
                            value: void 0,
                            done: !0
                        };
                    }
                    for (n.method = i, n.arg = o; ;) {
                        var a = n.delegate;
                        if (a) {
                            var c = A(a, n);
                            if (c) {
                                if (c === d) continue;
                                return c;
                            }
                        }
                        if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                            if ("suspendedStart" === r) throw r = "completed", n.arg;
                            n.dispatchException(n.arg);
                        } else "return" === n.method && n.abrupt("return", n.arg);
                        r = "executing";
                        var s = h(e, t, n);
                        if ("normal" === s.type) {
                            if (r = n.done ? "completed" : "suspendedYield", s.arg === d) continue;
                            return {
                                value: s.arg,
                                done: n.done
                            };
                        }
                        "throw" === s.type && (r = "completed", n.method = "throw", n.arg = s.arg);
                    }
                };
            }
            function A(e, t) {
                var n = t.method, r = e.iterator[n];
                if (void 0 === r) return t.delegate = null, "throw" === n && e.iterator.return && (t.method = "return", 
                t.arg = void 0, A(e, t), "throw" === t.method) || "return" !== n && (t.method = "throw", 
                t.arg = new TypeError("The iterator does not provide a '" + n + "' method")), d;
                var i = h(r, e.iterator, t.arg);
                if ("throw" === i.type) return t.method = "throw", t.arg = i.arg, t.delegate = null, 
                d;
                var o = i.arg;
                return o ? o.done ? (t[e.resultName] = o.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", 
                t.arg = void 0), t.delegate = null, d) : o : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), 
                t.delegate = null, d);
            }
            function S(e) {
                var t = {
                    tryLoc: e[0]
                };
                1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), 
                this.tryEntries.push(t);
            }
            function R(e) {
                var t = e.completion || {};
                t.type = "normal", delete t.arg, e.completion = t;
            }
            function N(e) {
                this.tryEntries = [ {
                    tryLoc: "root"
                } ], e.forEach(S, this), this.reset(!0);
            }
            function O(e) {
                if (e) {
                    var t = e[s];
                    if (t) return t.call(e);
                    if ("function" == typeof e.next) return e;
                    if (!isNaN(e.length)) {
                        var n = -1, r = function t() {
                            for (;++n < e.length; ) if (o.call(e, n)) return t.value = e[n], t.done = !1, t;
                            return t.value = void 0, t.done = !0, t;
                        };
                        return r.next = r;
                    }
                }
                return {
                    next: I
                };
            }
            function I() {
                return {
                    value: void 0,
                    done: !0
                };
            }
            return m.prototype = v, a(w, "constructor", {
                value: v,
                configurable: !0
            }), a(v, "constructor", {
                value: m,
                configurable: !0
            }), m.displayName = p(v, l, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                var t = "function" == typeof e && e.constructor;
                return !!t && (t === m || "GeneratorFunction" === (t.displayName || t.name));
            }, t.mark = function(e) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(e, v) : (e.__proto__ = v, p(e, l, "GeneratorFunction")), 
                e.prototype = Object.create(w), e;
            }, t.awrap = function(e) {
                return {
                    __await: e
                };
            }, E(b.prototype), p(b.prototype, u, function() {
                return this;
            }), t.AsyncIterator = b, t.async = function(e, n, r, i, o) {
                void 0 === o && (o = Promise);
                var a = new b(f(e, n, r, i), o);
                return t.isGeneratorFunction(n) ? a : a.next().then(function(e) {
                    return e.done ? e.value : a.next();
                });
            }, E(w), p(w, l, "Generator"), p(w, s, function() {
                return this;
            }), p(w, "toString", function() {
                return "[object Generator]";
            }), t.keys = function(e) {
                var t = Object(e), n = [];
                for (var r in t) n.push(r);
                return n.reverse(), function e() {
                    for (;n.length; ) {
                        var r = n.pop();
                        if (r in t) return e.value = r, e.done = !1, e;
                    }
                    return e.done = !0, e;
                };
            }, t.values = O, N.prototype = {
                constructor: N,
                reset: function(e) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, 
                    this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(R), 
                    !e) for (var t in this) "t" === t.charAt(0) && o.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0);
                },
                stop: function() {
                    this.done = !0;
                    var e = this.tryEntries[0].completion;
                    if ("throw" === e.type) throw e.arg;
                    return this.rval;
                },
                dispatchException: function(e) {
                    if (this.done) throw e;
                    var t = this;
                    function n(n, r) {
                        return a.type = "throw", a.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), 
                        !!r;
                    }
                    for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                        var i = this.tryEntries[r], a = i.completion;
                        if ("root" === i.tryLoc) return n("end");
                        if (i.tryLoc <= this.prev) {
                            var c = o.call(i, "catchLoc"), s = o.call(i, "finallyLoc");
                            if (c && s) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc);
                            } else if (c) {
                                if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                            } else {
                                if (!s) throw new Error("try statement without catch or finally");
                                if (this.prev < i.finallyLoc) return n(i.finallyLoc);
                            }
                        }
                    }
                },
                abrupt: function(e, t) {
                    for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                        var r = this.tryEntries[n];
                        if (r.tryLoc <= this.prev && o.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                            var i = r;
                            break;
                        }
                    }
                    i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                    var a = i ? i.completion : {};
                    return a.type = e, a.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, 
                    d) : this.complete(a);
                },
                complete: function(e, t) {
                    if ("throw" === e.type) throw e.arg;
                    return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, 
                    this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), 
                    d;
                },
                finish: function(e) {
                    for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                        var n = this.tryEntries[t];
                        if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), R(n), d;
                    }
                },
                catch: function(e) {
                    for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                        var n = this.tryEntries[t];
                        if (n.tryLoc === e) {
                            var r = n.completion;
                            if ("throw" === r.type) {
                                var i = r.arg;
                                R(n);
                            }
                            return i;
                        }
                    }
                    throw new Error("illegal catch attempt");
                },
                delegateYield: function(e, t, n) {
                    return this.delegate = {
                        iterator: O(e),
                        resultName: t,
                        nextLoc: n
                    }, "next" === this.method && (this.arg = void 0), d;
                }
            }, t;
        }
        e.exports = i, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "83af": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BearTypes = void 0, t.calculate = function(e, t) {
            var n = 0;
            switch (e) {
              case r.ElectricalSpecifications.IEC:
                n = function(e, t, n, r, a, c, s) {
                    return n === o.CONTACTLESS && (c = 0), (t === i.Materials.ALUMINUM.label ? .78 : 1) * e.serialNumberType.config[n][r] * {
                        contact: [ 1.26, 1.2, 1.14, 1.07, 1, .93, .85, .78, .67, .57, .45 ],
                        contactless: [ 1.14, 1.11, 1.07, 1.04, 1, .96, .92, .88, .84, .8, .75, .7, .65, .6, .54, .47, .4, .32 ]
                    }[n][a] * [ 1, .8, .7, .65, .6, .57, .54, .52, .5 ][c] * s;
                }(t.layingMode, t.material, t.type, t.cableCoreAreaIndex, t.temperatureAmbientIndex, t.pipeCircuitIndex, t.conductorNumber);
                break;

              case r.ElectricalSpecifications.NEC:
                n = function(e, t, n, r, i) {
                    return {
                        copper: [ 98, 124, 155, 209, 282, 329, 382, 444, 494, 556, 773, 1e3, 1193 ],
                        aluminum: [ 76, 96, 121, 163, 220, 255, 297, 346, 403, 468, 522, 588, 650, 709, 819, 920, 968, 1103, 1267, 1454 ]
                    }[e][t] * [ 1.26, 1.22, 1.18, 1.14, 1.1, 1.05, 1, .95, .89, .84, .77, .71, .63, .55 ][n] * [ 1, .8, .7, .5, .45, .4, .35 ][r] * i;
                }(t.material, t.cableCoreAreaIndex, t.temperatureAmbientIndex, t.totalConductorIndex, t.conductorNumber);
            }
            return n;
        };
        var r = n("9bc7"), i = n("028b"), o = {
            CONTACT: "contact",
            CONTACTLESS: "contactless"
        };
        t.BearTypes = o;
    },
    8760: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("d9d4"), i = {
            data: function() {
                return {
                    temperatureUnits: [ r.TemperatureUnit.CELSIUS, r.TemperatureUnit.FAHRENHEIT ],
                    temperatureUnitIndex: 0,
                    temperatureUnitValue: 20
                };
            },
            methods: {
                getTemperatureUnitValue: function() {
                    return (0, r.temperatureConvert)(this.temperatureUnitValue, this.temperatureUnits[this.temperatureUnitIndex], r.TemperatureUnit.CELSIUS);
                }
            }
        };
        t.default = i;
    },
    "8a42": function(e, t) {},
    "8d26": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e, t) {
            var n, o = t.current, a = t.carrying, c = i(t.temperatureAmbientLabel);
            return n = e === r.ElectricalSpecifications.IEC ? "pvc" === t.insulation ? 70 : 90 : i(t.maximumOperatingTemperatureLabel), 
            Math.pow(o / a, 2) * (n - c) + c;
        };
        var r = n("9bc7");
        function i(e) {
            var t = e.match(/[1-9]\d+/g);
            if (null === t) throw new Error("参数错误");
            return parseInt(t[0]);
        }
    },
    "8e0e": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = r(n("66fd")), o = r(n("26cb")), a = r(n("5345"));
        i.default.use(o.default);
        var c = new o.default.Store({
            modules: {
                user: a.default
            },
            strict: !0
        });
        t.default = c;
    },
    9108: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("9bc7"), i = n("e615"), o = n("d417"), a = n("83af"), c = n("028b"), s = {
            data: function() {
                return {
                    electricalSpecifications: r.ElectricalSpecifications,
                    currentElectricalSpecification: r.ElectricalSpecifications.IEC,
                    pipeCircuits: [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ],
                    pipeCircuitIndex: 0,
                    layingModeOptions: [],
                    layingModeOptionIndex: 0,
                    layingMode: null,
                    cableCoreAreaOptions: [],
                    cableCoreAreaOptionIndex: 0,
                    temperatureAmbientOptions: [],
                    temperatureAmbientOptionIndex: 0,
                    totalConductorOptions: r.InsulatedConductorConfig.NEC.totalConductors,
                    totalConductorOptionIndex: 0
                };
            },
            methods: {
                onDisplayLayingMode: function() {
                    this.$refs.layingMode.onDisplay();
                },
                setLayingMode: function() {
                    var e = this.$refs.layingMode;
                    this.currentElectricalSpecification === r.ElectricalSpecifications.IEC ? e.initLayingMode(this.currentElectricalSpecification) : (this.layingModeOptions = i.LayingModeConfig[e.getMaterial()].NEC, 
                    this.layingModeOptionIndex = 0);
                },
                getLayingMode: function() {
                    var e = this.layingMode;
                    return this.currentElectricalSpecification === r.ElectricalSpecifications.NEC && (e = this.layingModeOptions[this.layingModeOptionIndex]), 
                    e;
                },
                handleTemperatureAmbient: function(e) {
                    var t = [], n = 4, c = this.temperatureAmbientOptions[this.temperatureAmbientOptionIndex];
                    if (this.currentElectricalSpecification === r.ElectricalSpecifications.IEC) {
                        var s;
                        t = r.InsulatedConductorConfig.IEC.temperatureAmbient, e === a.BearTypes.CONTACT ? t = t.slice(0, t.length - 4) : (s = t).push.apply(s, [ "85°C (185°F)", "90°C (194°F)", "95°C (203°F)" ]), 
                        n = (0, o.keepCurrentIndexOfOptions)(c, t, n);
                    } else {
                        var u = this.layingModeOptions[this.layingModeOptionIndex];
                        t = r.InsulatedConductorConfig.NEC.temperatureAmbient, u.identifier === i.NECIdentifier.OVERHEAD_LAYING && (n = 6);
                    }
                    this.temperatureAmbientOptions = t, this.temperatureAmbientOptionIndex = n;
                },
                handleCableCoreAre: function(e) {
                    var t = [], n = 0, i = this.cableCoreAreaOptions[this.cableCoreAreaOptionIndex];
                    this.currentElectricalSpecification === r.ElectricalSpecifications.IEC ? ([ 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240 ].forEach(function(e) {
                        t.push({
                            option: e,
                            label: "".concat(e, " mm²")
                        });
                    }), n = (0, o.keepCurrentIndexOfOptions)(i, t, 0, "label")) : (t = [ "8 awg", "6 awg", "4 awg", "2 awg", "1/0 awg", "2/0 awg", "3/0 awg", "4/0 awg", "250 kcmil", "300 kcmil", "500 kcmil", "750 kcmil", "1000 kcmil" ], 
                    e === c.Materials.ALUMINUM.label && (t = [ "8 awg", "6 awg", "4 awg", "2 awg", "1/0 awg", "2/0 awg", "3/0 awg", "4/0 awg", "266.8 kcmil", "336.4 kcmil", "397.5 kcmil", "477 kcmil", "556.5 kcmil", "636 kcmil", "795 kcmil", "954 kcmil", "1033.5 kcmil", "1272 kcmil", "1590 kcmil", "2000 kcmil" ]), 
                    n = (0, o.keepCurrentIndexOfOptions)(i, t, 0)), this.cableCoreAreaOptions = t, this.cableCoreAreaOptionIndex = n;
                }
            }
        };
        t.default = s;
    },
    "933e": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.EIA = void 0, t.convert = function(e, t) {
            for (var n = [], r = e.length, i = 100 / t, o = t / 100; o < 1e6; o *= 10) for (var a = 0; a < r; ) {
                var c = Math.floor(e[a] * o * i) / i;
                if (c > 22e6) break;
                a++, n.push(c);
            }
            return n;
        }, t.EIA = {
            e6: [ 100, 150, 220, 330, 470, 680 ],
            e12: [ 100, 120, 150, 180, 220, 270, 330, 390, 470, 560, 680, 820 ],
            e24: [ 100, 110, 120, 130, 150, 160, 180, 200, 220, 240, 270, 300, 330, 360, 390, 430, 470, 510, 560, 620, 680, 750, 820, 910 ],
            e48: [ 100, 105, 110, 115, 121, 127, 133, 140, 147, 154, 162, 169, 178, 187, 196, 205, 215, 226, 237, 249, 261, 274, 287, 301, 316, 332, 348, 365, 383, 402, 422, 442, 464, 487, 511, 536, 562, 590, 619, 649, 681, 715, 750, 787, 825, 866, 909, 953 ],
            e96: [ 100, 102, 105, 107, 110, 113, 115, 118, 121, 124, 127, 130, 133, 137, 140, 143, 147, 150, 154, 158, 162, 165, 169, 174, 178, 182, 187, 191, 196, 200, 205, 210, 215, 221, 226, 232, 237, 243, 249, 255, 261, 267, 274, 280, 287, 294, 301, 309, 316, 324, 332, 340, 348, 357, 365, 374, 383, 392, 402, 412, 422, 432, 442, 453, 464, 475, 487, 499, 511, 523, 536, 549, 562, 576, 590, 604, 619, 634, 649, 665, 681, 698, 715, 732, 750, 768, 787, 806, 825, 845, 866, 887, 909, 931, 953, 976 ],
            e192: [ 100, 101, 102, 104, 105, 106, 107, 109, 110, 111, 113, 114, 115, 117, 118, 120, 121, 123, 124, 126, 127, 129, 130, 132, 133, 135, 137, 138, 140, 142, 143, 145, 147, 149, 150, 152, 154, 156, 158, 160, 162, 164, 165, 167, 169, 172, 174, 176, 178, 180, 182, 184, 187, 189, 191, 193, 196, 198, 200, 203, 205, 208, 210, 213, 215, 218, 221, 223, 226, 229, 232, 234, 237, 240, 243, 246, 249, 252, 255, 258, 261, 264, 267, 271, 274, 277, 280, 284, 287, 291, 294, 298, 301, 305, 309, 312, 316, 320, 324, 328, 332, 336, 340, 344, 348, 352, 357, 361, 365, 370, 374, 379, 383, 388, 392, 397, 402, 407, 412, 417, 422, 427, 432, 437, 442, 448, 453, 459, 464, 470, 475, 481, 487, 493, 499, 505, 511, 517, 523, 530, 536, 542, 549, 556, 562, 569, 576, 583, 590, 597, 604, 612, 619, 626, 634, 642, 649, 657, 665, 673, 681, 690, 698, 706, 715, 723, 732, 741, 750, 759, 768, 777, 787, 796, 806, 816, 825, 835, 845, 856, 866, 876, 887, 898, 909, 919, 931, 942, 953, 965, 976, 988 ]
        };
    },
    9523: function(e, t, n) {
        var r = n("a395");
        e.exports = function(e, t, n) {
            return (t = r(t)) in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "963d": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.userAgreementUrl = t.termsServiceUrl = t.staticExamUrl = t.privacyPolicyUrl = t.platformId = t.baseExamUrl = t.apiExamUrl = t.apiBaseUrl = t.BaseUrl = void 0, 
        t.apiBaseUrl = "https://ts.pp.cc/api/electrician/", t.BaseUrl = "https://ts.pp.cc/", 
        t.apiExamUrl = "https://ee.pp.cc/api/", t.baseExamUrl = "https://ee.pp.cc/", t.staticExamUrl = "https://ee.pp.cc/exam/", 
        t.userAgreementUrl = "https://ts.pp.cc/res/terms/user_agreement.html", t.privacyPolicyUrl = "https://ts.pp.cc/res/terms/privacy_policy.html", 
        t.termsServiceUrl = "https://ts.pp.cc/res/terms/terms_service.html", t.platformId = 1;
    },
    9673: function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getLoginUserInfo = function() {
                return new Promise(function(e, t) {
                    i.default.get("user").then(function(t) {
                        e(t.data);
                    }, function(e) {
                        console.log(e), t(e);
                    });
                });
            }, t.getUser = function() {
                return o.globalData.getUser();
            }, t.loginRequired = function() {
                return new Promise(function(t, n) {
                    o.globalData.getUser().then(function() {
                        return t();
                    }, function() {
                        o.globalData.afterLoginSuccess = t, o.globalData.afterLoginCancel = n, e.navigateTo({
                            url: "/pages/login/login_new"
                        });
                    });
                });
            }, r(n("8e0e"));
            var i = r(n("b253")), o = getApp();
        }).call(this, n("543d").default);
    },
    "970b": function(e, t) {
        e.exports = function(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    9912: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MeasuringUnits = void 0;
        var r = n("00cd"), i = {
            km: new r.Unit("km", 1e3),
            m: new r.Unit("m"),
            cm: new r.Unit("cm", .01),
            mm: new r.Unit("mm", .001),
            ft: new r.Unit("ft", 1 / 3.280839895013),
            in: new r.Unit("in", .0254),
            mil: new r.Unit("mil", 254e-7),
            yd: new r.Unit("yd", 1 / 1.093613298338),
            mi: new r.Unit("mi", 1609.3439999930947),
            nmi: new r.Unit("nmi", 1851.9999999853321)
        };
        t.MeasuringUnits = i;
    },
    "9a2b": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.cableCoreAreaConfig = t.CableCoreType = void 0, t.calculateAllowableTransmission = function(e, t, n, r) {
            return Math.pow([ [ [ 115, 135, 143, 200 ], [ 143, 166, 176, 228 ], [ 115, 135, 143, 228 ] ], [ [ 74, 87, 87, 0 ], [ 95, 110, 116, 0 ], [ 76, 89, 94, 0 ] ] ][t][r][n], 2) * Math.pow(e, 2);
        }, t.calculateCablePowerLoss = function(e, t, n) {
            var r = 2;
            return e === i.CurrentType.THREE_PHASE_CURRENT && (r = 3), Math.pow(t, 2) * n * r;
        }, t.calculateImpedance = function(e, t) {
            return Math.sqrt(Math.pow(e, 2) + Math.pow(t, 2));
        }, t.calculateMaximumCableLength = function(e, t, n, r, a, c, s) {
            if (c >= n) throw new Error("电压降数值无效");
            var u = 2;
            return e === i.CurrentType.THREE_PHASE_CURRENT && (u = Math.sqrt(3)), c / (u * t * (r * s[o.TrigonometricType.COS] + a * s[o.TrigonometricType.SIN])) / 1e3;
        }, t.calculateReactance = function(e, t, n, r, i) {
            if (![ a.ElectricalSpecifications.IEC, a.ElectricalSpecifications.NEC ].includes(e)) throw new Error("线芯截面积无效");
            if (![ u.SINGLE_CORE, u.MULTI_CORE ].includes(n)) throw new Error("缆芯类型无效");
            if (!r) throw new Error("线长数值无效");
            var o = s[e].cableCoreTypeReactance[n], c = 0;
            return t < o.length && (c = o[t]), c * r / i / 1e3;
        }, t.calculateResistance = function(e, t, n, o, c, u, l) {
            if (![ a.ElectricalSpecifications.IEC, a.ElectricalSpecifications.NEC ].includes(e)) throw new Error("线芯截面积无效");
            if (![ r.Materials.COPPER.label, r.Materials.ALUMINUM.label ].includes(n)) throw new Error("缆芯无效");
            if (!o) throw new Error("线长数值无效");
            if (!(l = (0, i.toSimplifyCurrentType)(l))) throw new Error("电流类型无效");
            var p = 20;
            e === a.ElectricalSpecifications.NEC && (p = 75);
            var f = 0;
            return n === r.Materials.COPPER.label ? f = r.Materials.COPPER.temperature : n === r.Materials.ALUMINUM.label && (f = r.Materials.ALUMINUM.temperature), 
            ((u - p) * f + 1) * s[e].materialResistance[n][l][t] * o / c / 1e3;
        }, t.calculateVoltageDrop = function(e, t, n, r, a, s, u) {
            var l = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7];
            if (!(0, c.isNonzeroNumber)(s)) throw new Error("长度数值无效");
            var p = {
                voltage_drop: 0,
                voltage_drop_rate: 0,
                voltage_load: 0
            }, f = 2;
            return e === i.CurrentType.THREE_PHASE_CURRENT && (f = Math.sqrt(3)), p.voltage_drop = f * t * (r * u[o.TrigonometricType.COS] + a * u[o.TrigonometricType.SIN]) * s, 
            p.voltage_drop >= n && l && (p.voltage_drop = n), p.voltage_drop_rate = 100 * p.voltage_drop / n, 
            p.voltage_load = n - p.voltage_drop, p;
        };
        var r = n("028b"), i = n("d055"), o = n("2e64"), a = n("9bc7"), c = n("d417"), s = {
            IEC: {
                units: [ .5, .75, 1, 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500, 630 ],
                cableCoreTypeReactance: {
                    single_core: [ .19, .18, .176, .168, .155, .143, .135, .119, .112, .106, .101, .101, .0965, .0975, .0939, .0928, .0908, .0902, .0895, .0876, .0867, .0865 ],
                    multi_core: [ .142, .132, .125, .118, .109, .101, .0955, .0861, .0817, .0813, .0783, .0779, .0751, .0762, .074, .0745, .0742, .0752, .075, .0742, .0744, .0749 ]
                },
                materialResistance: {
                    copper: {
                        DC: [ 39, 26, 19.5, 13.3, 7.98, 4.95, 3.3, 1.91, 1.21, .78, .554, .386, .272, .206, .161, .129, .106, .0801, .0641, .0486, .0384, .0287 ],
                        AC: [ 39, 26, 19.5, 13.3, 7.98, 4.95, 3.3, 1.91, 1.21, .78, .554, .386, .272, .206, .161, .129, .106, .0801, .0641, .0486, .0384, .0287 ]
                    },
                    aluminum: {
                        DC: [ 61.6, 41.07, 30.8, 20.53, 12.32, 7.7, 5.13, 3.08, 1.91, 1.2, .868, .641, .443, .32, .253, .206, .164, .125, .1, .0778, .0605, .0469 ],
                        AC: [ 61.6, 41.07, 30.8, 20.53, 12.32, 7.7, 5.13, 3.08, 1.91, 1.2, .868, .641, .443, .32, .253, .206, .164, .125, .1, .0778, .0605, .0469 ]
                    }
                }
            },
            NEC: {
                units: [ "28", "26", "24", "22", "20", "18", "16", "14", "12", "10", "8", "6", "4", "3", "2", "1", "1/0", "2/0", "3/0", "4/0", "250 kcmil", "300 kcmil", "350 kcmil", "400 kcmil", "500 kcmil", "600 kcmil", "700 kcmil", "750 kcmil", "800 kcmil", "900 kcmil", "1000 kcmil", "1250 kcmil", "1500 kcmil", "1750 kcmil", "2000 kcmil" ],
                cableCoreTypeReactance: {
                    single_core: [ .253, .246, .239, .232, .225, .218, .203, .19, .177, .164, .171, .167, .157, .154, .148, .151, .144, .141, .138, .135, .135, .135, .131, .131, .128, .128, .126, .125, .124, .122, .121, .118, .116, .115, .114 ],
                    multi_core: [ .253, .246, .239, .232, .225, .218, .203, .19, .177, .164, .171, .167, .157, .154, .148, .151, .144, .141, .138, .135, .135, .135, .131, .131, .128, .128, .126, .125, .124, .122, .121, .118, .116, .115, .114 ]
                },
                materialResistance: {
                    copper: {
                        DC: [ 258.9, 162.8, 102.4, 64.4, 40.5, 25.5, 16, 10.1, 6.34, 3.984, 2.506, 1.608, 1.01, .802, .634, .505, .399, .317, .2512, .1996, .1687, .1409, .1205, .1053, .0845, .0704, .0603, .0563, .0528, .047, .0423, .0338, .02814, .0241, .02109 ],
                        AC: [ 262.3, 165, 103.7, 65.2, 41, 25.8, 16.2, 10.2, 6.6, 3.9, 2.56, 1.61, 1.02, .82, .62, .49, .39, .33, .253, .203, .171, .144, .125, .108, .089, .075, .066, .062, .06, .054, .049, .043, .037, .032, .028 ]
                    },
                    aluminum: {
                        DC: [ 426.8, 268.4, 168.8, 106.2, 66.8, 42, 26.4, 16.6, 10.45, 6.561, 4.125, 2.652, 1.666, 1.32, 1.045, .829, .66, .523, .413, .328, .2778, .2318, .1984, .1737, .1391, .1159, .0994, .0927, .0868, .077, .0695, .0554, .0464, .0397, .0348 ],
                        AC: [ 432.3, 271.9, 171, 107.5, 67.6, 42.5, 26.7, 16.8, 10.5, 6.6, 4.3, 2.66, 1.67, 1.31, 1.05, .82, .66, .52, .43, .33, .279, .233, .2, .177, .141, .118, .103, .095, .091, .083, .075, .056, .053, .05, .047 ]
                    }
                }
            }
        };
        t.cableCoreAreaConfig = s;
        var u = {
            SINGLE_CORE: "single_core",
            MULTI_CORE: "multi_core"
        };
        t.CableCoreType = u;
    },
    "9add": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case o.InputTerminal.VOLTAGE_CURRENT:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电流数值无效");
                    switch (e) {
                      case i.CurrentType.DIRECT_CURRENT:
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        o = t * n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = Math.sqrt(3) * t * n;
                    }
                    return o;
                }(e.currentType, e.voltageValue, e.currentValue);
                break;

              case o.InputTerminal.VOLTAGE_RESISTANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    switch (e !== i.CurrentType.DIRECT_CURRENT && c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * o[a.TrigonometricType.COS] / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * o[a.TrigonometricType.COS] / n;
                    }
                    return s;
                }(e.currentType, e.voltageValue, e.resistanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.VOLTAGE_IMPEDANCE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        o = Math.pow(t, 2) / n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = Math.sqrt(3) * Math.pow(t, 2) / n;
                    }
                    return o;
                }(e.currentType, e.voltageValue, e.impedanceValue);
                break;

              case o.InputTerminal.CURRENT_RESISTANCE:
                t = function(e, t, n, o) {
                    var s = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    switch (c(o), e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        s = Math.pow(t, 2) * n / o[a.TrigonometricType.COS];
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        s = Math.sqrt(3) * Math.pow(t, 2) * n / o[a.TrigonometricType.COS];
                    }
                    return s;
                }(e.currentType, e.currentValue, e.resistanceValue, e.triangleCollection);
                break;

              case o.InputTerminal.CURRENT_IMPEDANCE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("电流数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        o = Math.pow(t, 2) * n;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = Math.sqrt(3) * Math.pow(t, 2) * n;
                    }
                    return o;
                }(e.currentType, e.currentValue, e.impedanceValue);
                break;

              case o.InputTerminal.ACTIVE_REACTIVE:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("有功功率数值无效");
                    if (!(0, r.isNonzeroNumber)(n)) throw new Error("无功功率数值无效");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = Math.sqrt(Math.pow(t, 2) + Math.pow(n, 2));
                    }
                    return o;
                }(e.currentType, e.activePowerValue, e.reactivePowerValue);
                break;

              case o.InputTerminal.ACTIVE_POWER:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("有功功率数值无效");
                    if (c(n), 90 === n[a.TrigonometricType.DEG]) return t * n[a.TrigonometricType.TAN];
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t / n[a.TrigonometricType.COS];
                    }
                    return o;
                }(e.currentType, e.activePowerValue, e.triangleCollection);
                break;

              case o.InputTerminal.REACTIVE_POWER:
                t = function(e, t, n) {
                    var o = 0;
                    if (!(0, r.isNonzeroNumber)(t)) throw new Error("视在功率数值无效");
                    if (c(n), 0 === n[a.TrigonometricType.SIN]) throw new Error("∞");
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                      case i.CurrentType.THREE_PHASE_CURRENT:
                        o = t / n[a.TrigonometricType.SIN];
                    }
                    return o;
                }(e.currentType, e.reactivePowerValue, e.triangleCollection);
            }
            return t;
        };
        var r = n("d417"), i = n("d055"), o = n("fad4"), a = n("2e64");
        function c(e) {
            if (e.type === a.TrigonometricType.COS && 0 === e[a.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
    },
    "9b42": function(e, t) {
        e.exports = function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, i, o, a, c = [], s = !0, u = !1;
                try {
                    if (o = (n = n.call(e)).next, 0 === t) {
                        if (Object(n) !== n) return;
                        s = !1;
                    } else for (;!(s = (r = o.call(n)).done) && (c.push(r.value), c.length !== t); s = !0) ;
                } catch (e) {
                    u = !0, i = e;
                } finally {
                    try {
                        if (!s && null != n.return && (a = n.return(), Object(a) !== a)) return;
                    } finally {
                        if (u) throw i;
                    }
                }
                return c;
            }
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    "9bc7": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InsulationType = t.InsulatedConductorConfig = t.ElectricalSpecifications = void 0, 
        t.ElectricalSpecifications = {
            IEC: "IEC",
            NEC: "NEC"
        }, t.InsulationType = {
            PVC: "pvc",
            G2: "g2",
            XLPE_EPR: "xlpe_epr",
            BARE_CONDUCTOR: "bare"
        };
        var r = {
            cableCoreArea: [ "14 awg", "12 awg", "10 awg", "8 awg", "6 awg", "4 awg", "3 awg", "2 awg", "1 awg", "1/0 awg", "2/0 awg", "3/0 awg", "4/0 awg", "250 kcmil", "300 kcmil", "350 kcmil", "400 kcmil", "500 kcmil", "600 kcmil", "700 kcmil", "750 kcmil", "800 kcmil", "900 kcmil", "1000 kcmil", "1250 kcmil", "1500 kcmil", "1750 kcmil", "2000 kcmil" ],
            maximumOperatingTemperature: [ "60 °C (140 °F)", "75 °C (167 °F)", "90 °C (194 °F)" ]
        }, i = {
            IEC: {
                cableCoreArea: [ .5, .75, 1, 1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500, 630 ],
                temperatureAmbient: [ "10°C (50°F)", "15°C (59°F)", "20°C (68°F)", "25°C (77°F)", "30°C (86°F)", "35°C (95°F)", "40°C (104°F)", "45°C (113°F)", "50°C (122°F)", "55°C (131°F)", "60°C (140°F)", "65°C (149°F)", "70°C (158°F)", "75°C (167°F)", "80°C (176°F)" ],
                soilThermalResistivity: [ .5, .7, 1, 1.5, 2, 2.5, 3 ],
                conductorsOfCircuit: [ 2, 3 ],
                conductorsInParallel: [ 1, 2, 3, 4, 5, 6, 7, 8 ],
                circuitsInTheConduit: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 16, 20 ]
            },
            NEC: {
                cableCoreArea: {
                    trench_pipe_buried_laying: r.cableCoreArea,
                    overhead_laying: r.cableCoreArea,
                    communication_devices: [ "8 awg", "6 awg", "4 awg", "3 awg", "2 awg", "1 awg", "1/0 awg", "2/0 awg", "3/0 awg", "4/0 awg", "250 kcmil", "300 kcmil", "350 kcmil", "400 kcmil", "500 kcmil", "600 kcmil", "700 kcmil", "750 kcmil", "800 kcmil", "900 kcmil", "1000 kcmil" ]
                },
                cableCoreAreaConfig: {
                    copper: {
                        trench_pipe_buried_laying: [ [ 15, 20, 30, 40, 55, 70, 85, 95, 110, 125, 145, 165, 195, 215, 240, 260, 280, 320, 350, 385, 400, 410, 435, 455, 495, 525, 545, 555 ], [ 20, 25, 35, 50, 65, 85, 100, 115, 130, 150, 175, 200, 230, 255, 285, 310, 335, 380, 420, 460, 475, 490, 520, 545, 590, 625, 650, 665 ], [ 25, 30, 40, 55, 75, 95, 115, 130, 145, 170, 195, 225, 260, 290, 320, 350, 380, 430, 475, 520, 535, 555, 585, 615, 665, 705, 735, 750 ] ],
                        overhead_laying: [ [ 25, 30, 40, 60, 80, 105, 120, 140, 165, 195, 225, 260, 300, 340, 375, 420, 455, 515, 575, 630, 655, 680, 730, 780, 890, 980, 1070, 1155 ], [ 30, 35, 50, 70, 95, 125, 145, 170, 195, 230, 265, 310, 360, 405, 445, 505, 545, 620, 690, 755, 785, 815, 870, 935, 1065, 1175, 1280, 1385 ], [ 35, 40, 55, 80, 105, 140, 165, 190, 220, 260, 300, 350, 405, 455, 500, 570, 615, 700, 780, 850, 885, 920, 980, 1055, 1200, 1325, 1445, 1560 ] ],
                        communication_devices: [ [ 57, 76, 101, 118, 135, 158, 183, 212, 245, 287, 320, 359, 397, 430, 496, 553, 610, 638, 660, 704, 748 ], [ 66, 89, 117, 138, 158, 185, 214, 247, 287, 335, 374, 419, 464, 503, 580, 647, 714, 747, 773, 826, 879 ] ]
                    },
                    aluminum: {
                        trench_pipe_buried_laying: [ [ 0, 15, 25, 35, 40, 55, 65, 75, 85, 100, 115, 130, 150, 170, 195, 210, 225, 260, 285, 315, 320, 330, 355, 375, 405, 435, 455, 470 ], [ 0, 20, 30, 40, 50, 65, 75, 90, 100, 120, 135, 155, 180, 205, 230, 250, 270, 310, 340, 375, 385, 395, 425, 445, 485, 520, 545, 560 ], [ 0, 25, 35, 45, 55, 75, 85, 100, 115, 135, 150, 175, 205, 230, 260, 280, 305, 350, 385, 425, 435, 445, 480, 500, 545, 585, 615, 630 ] ],
                        overhead_laying: [ [ 0, 25, 35, 45, 60, 80, 95, 110, 130, 150, 175, 200, 235, 265, 290, 330, 355, 405, 455, 500, 515, 535, 580, 625, 710, 795, 875, 960 ], [ 0, 30, 40, 55, 75, 100, 115, 135, 155, 180, 210, 240, 280, 315, 350, 395, 425, 485, 545, 595, 620, 645, 700, 750, 855, 950, 1050, 1150 ], [ 0, 35, 45, 60, 85, 115, 130, 150, 175, 205, 235, 270, 315, 355, 395, 445, 480, 545, 615, 670, 700, 725, 790, 845, 965, 1070, 1185, 1295 ] ],
                        communication_devices: [ [ 44, 59, 78, 92, 106, 123, 143, 165, 192, 224, 251, 282, 312, 339, 392, 440, 488, 512, 532, 572, 612 ], [ 51, 69, 91, 107, 123, 144, 167, 193, 224, 262, 292, 328, 364, 395, 458, 514, 570, 598, 622, 669, 716 ] ]
                    }
                },
                maximumOperatingTemperature: {
                    trench_pipe_buried_laying: r.maximumOperatingTemperature,
                    overhead_laying: r.maximumOperatingTemperature,
                    communication_devices: [ "75 °C (167 °F)", "90 °C (194 °F)" ]
                },
                totalConductors: [ {
                    option: 1,
                    label: "< 4"
                }, {
                    option: .8,
                    label: "4-6"
                }, {
                    option: .7,
                    label: "7-9"
                }, {
                    option: .5,
                    label: "10-20"
                }, {
                    option: .45,
                    label: "21-30"
                }, {
                    option: .4,
                    label: "31-40"
                }, {
                    option: .35,
                    label: "> 40"
                } ],
                temperatureAmbient: [ {
                    option: 10,
                    label: "<11°C (<50°F)",
                    label_cable: "10°C (50°F)",
                    config: {
                        trench_pipe_buried_laying: [ 1.29, 1.2, 1.15 ],
                        overhead_laying: [ 1.29, 1.2, 1.15 ],
                        communication_devices: [ 1.36, 1.26 ]
                    }
                }, {
                    option: 15,
                    label: "11°-15°C (51°-59°F)",
                    label_cable: "15°C (59°F)",
                    config: {
                        trench_pipe_buried_laying: [ 1.22, 1.15, 1.12 ],
                        overhead_laying: [ 1.22, 1.15, 1.12 ],
                        communication_devices: [ 1.31, 1.22 ]
                    }
                }, {
                    option: 20,
                    label: "16°-20° (60-68°F)",
                    label_cable: "20°C (68°F)",
                    config: {
                        trench_pipe_buried_laying: [ 1.15, 1.11, 1.08 ],
                        overhead_laying: [ 1.15, 1.11, 1.08 ],
                        communication_devices: [ 1.25, 1.18 ]
                    }
                }, {
                    option: 25,
                    label: "21°-25°C (69°-77°F)",
                    label_cable: "25°C (77°F)",
                    config: {
                        trench_pipe_buried_laying: [ 1.08, 1.05, 1.04 ],
                        overhead_laying: [ 1.08, 1.05, 1.04 ],
                        communication_devices: [ 1.2, 1.14 ]
                    }
                }, {
                    option: 30,
                    label: "26°-30°C (78°-86°F)",
                    label_cable: "30°C (86°F)",
                    config: {
                        trench_pipe_buried_laying: [ 1, 1, 1 ],
                        overhead_laying: [ 1, 1, 1 ],
                        communication_devices: [ 1.13, 1.1 ]
                    }
                }, {
                    option: 35,
                    label: "31°-35°C (87°-95°F)",
                    label_cable: "35°C (95°F)",
                    config: {
                        trench_pipe_buried_laying: [ .91, .94, .96 ],
                        overhead_laying: [ .91, .94, .96 ],
                        communication_devices: [ 1.07, 1.05 ]
                    }
                }, {
                    option: 40,
                    label: "36°-40°C (96°-104°F)",
                    label_cable: "40°C (104°F)",
                    config: {
                        trench_pipe_buried_laying: [ .82, .88, .91 ],
                        overhead_laying: [ .82, .88, .91 ],
                        communication_devices: [ 1, 1 ]
                    }
                }, {
                    option: 45,
                    label: "41°-45°C (105°-113°F)",
                    label_cable: "45°C (113°F)",
                    config: {
                        trench_pipe_buried_laying: [ .71, .82, .87 ],
                        overhead_laying: [ .71, .82, .87 ],
                        communication_devices: [ .93, .95 ]
                    }
                }, {
                    option: 50,
                    label: "46°-50°C (114°-122°F)",
                    label_cable: "50°C (122°F)",
                    config: {
                        trench_pipe_buried_laying: [ .58, .75, .82 ],
                        overhead_laying: [ .58, .75, .82 ],
                        communication_devices: [ .85, .89 ]
                    }
                }, {
                    option: 55,
                    label: "51°-55°C (123°-131°F)",
                    label_cable: "55°C (131°F)",
                    config: {
                        trench_pipe_buried_laying: [ .41, .67, .76 ],
                        overhead_laying: [ .41, .67, .76 ],
                        communication_devices: [ .76, .84 ]
                    }
                }, {
                    option: 60,
                    label: "56°-60°C (132°-140°F)",
                    label_cable: "60°C (140°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, .58, .71 ],
                        overhead_laying: [ 0, .58, .71 ],
                        communication_devices: [ .65, .77 ]
                    }
                }, {
                    option: 65,
                    label: "61°-65°C (141°-149°F)",
                    label_cable: "65°C (149°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, .47, .65 ],
                        overhead_laying: [ 0, .47, .65 ],
                        communication_devices: [ .53, .71 ]
                    }
                }, {
                    option: 70,
                    label: "66°-70°C (150°-158°F)",
                    label_cable: "70°C (158°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, .33, .58 ],
                        overhead_laying: [ 0, .33, .58 ],
                        communication_devices: [ .38, .63 ]
                    }
                }, {
                    option: 75,
                    label: "71°-75°C (159°-167°F)",
                    label_cable: "75°C (167°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, 0, .5 ],
                        overhead_laying: [ 0, 0, .5 ],
                        communication_devices: [ 0, .55 ]
                    }
                }, {
                    option: 80,
                    label: "76°-80°C (168°-176°F)",
                    label_cable: "80°C (176°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, 0, .41 ],
                        overhead_laying: [ 0, 0, .41 ],
                        communication_devices: [ 0, .45 ]
                    }
                }, {
                    option: 85,
                    label: "81°-85°C (177°-185°F)",
                    label_cable: "85°C (185°F)",
                    config: {
                        trench_pipe_buried_laying: [ 0, 0, .29 ],
                        overhead_laying: [ 0, 0, .29 ],
                        communication_devices: [ 0, 0 ]
                    }
                } ],
                style: {
                    copper: {
                        trench_pipe_buried_laying: [ "TW, UF", "RHW, THHW, THW, THWN, XHHW, USE, ZW", "TBS, SA, SIS, FEP, FEPB, MI, RHH, RHW-2, THHN, THHW, THW-2, THWN-2, USE-2, XHH, XHHW, XHHW-2, ZW-2" ],
                        overhead_laying: [ "TW, UF", "RHW, THHW, THW, THWN, XHHW, ZW", "TBS, SA, SIS, FEP, FEPB, MI, RHH, RHW-2, THHN, THHW, THW-2, THWN-2, USE-2, XHH, XHHW, XHHW-2, ZW-2" ],
                        communication_devices: [ "RHW, THHW, THW, THWN, XHHW, ZW", "MI, THHN, THHW, THW-2, THWN-2, RHH, RHW-2, USE-2, XHHW, XHHW-2, ZW-2" ]
                    },
                    aluminum: {
                        trench_pipe_buried_laying: [ "TW, UF", "RHW, THHW, THW, THWN, XHHW, USE", "TBS, SA, SIS, THHN, THHW, THW-2, THWN-2, RHH, RHW-2, USE-2, XHH, XHHW, XHHW-2, ZW-2" ],
                        overhead_laying: [ "TW, UF", "RHW, THHW, THW, THWN, XHHW", "TBS, SA, SIS, THHN, THHW, THW-2, THWN-2, RHH, RHW-2, USE-2, XHH, XHHW, XHHW-2, ZW-2" ],
                        communication_devices: [ "RHW, THW, THWN, THHW, XHHW", "THHN, THHW, RHH, XHHW, RHW-2, XHHW-2, THW-2, THWN-2, USE-2, ZW-2" ]
                    }
                }
            }
        };
        t.InsulatedConductorConfig = i;
    },
    a195: function(e, t, n) {
        "use strict";
        (function(e) {
            function n(e, t) {
                return e = "/pages/about/webview?url=" + encodeURIComponent(e), t && (e += "&title=" + encodeURIComponent(t)), 
                e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getWebViewUrl = n, t.openWebView = function(t, r) {
                e.navigateTo({
                    url: n(t, r)
                });
            };
        }).call(this, n("543d").default);
    },
    a395: function(e, t, n) {
        var r = n("7037").default, i = n("e50d");
        e.exports = function(e) {
            var t = i(e, "string");
            return "symbol" === r(t) ? t : String(t);
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    a896: function(e, t, n) {
        "use strict";
        function r(e, t) {
            if (e <= 0) throw new Error("磁场转速数值无效");
            if (t <= 0 || e < t) throw new Error("转子转速数值无效");
            return e - t;
        }
        function i(e) {
            if (e < 40 || e > 100) throw new Error("效率数值无效");
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculateActivePower = function(e, t) {
            return i(t), e * t / 100;
        }, t.calculateCurrent = function(e, t) {
            return i(t), 100 * e / t;
        }, t.calculateEfficiency = function(e, t) {
            var n = t / e * 100;
            if (n < 40) throw new Error("无效参数：\n效率 = " + n);
            if (n > 100) throw new Error("无效参数：\n效率 = " + n);
            return n;
        }, t.calculateFullLoadCurrent = function(e, t) {
            if (e <= 0) throw new Error("电压数值无效");
            return t / e;
        }, t.calculateMagneticSpeed = function(e, t) {
            if (t <= 0 || t % 2 != 0) throw new Error("极数数值无效");
            if (e <= 0) throw new Error("频率数值无效");
            return 60 * e / (t / 2);
        }, t.calculateMaximumTorque = function(e, t) {
            if (t <= 0) throw new Error("转速数值无效");
            if (e <= 0) throw new Error("功率数值无效");
            return 60 * e / (2 * Math.PI * t);
        }, t.calculateMotoreMonofasee = function(e, t, n, r) {
            if (e <= 0) throw new Error("功率数值无效");
            if (t <= 0 || t > 250) throw new Error("电压数值无效");
            if (n <= 0 || n > 400) throw new Error("频率数值无效");
            return i(r), e * r * 1e3 / (Math.pow(t, 2) * n);
        }, t.calculatePower = function(e, t) {
            if (t <= 0) throw new Error("转速数值无效");
            if (e <= 0) throw new Error("扭矩数值无效");
            return 2 * e * Math.PI * t / 60;
        }, t.calculatePowerFactor = function(e, t) {
            return i(t), 100 * e / t;
        }, t.calculateRotorSpeed = function(e, t, n) {
            if (t <= 0 || t % 2 != 0) throw new Error("极数数值无效");
            if (e <= 0) throw new Error("频率数值无效");
            if (n <= 0 || n > 1) throw new Error("转差率数值无效");
            return 60 * e * (1 - n) / (t / 2);
        }, t.calculateSlippage = r, t.calculateSlippageRate = function(e, t) {
            return r(e, t) / e * 100;
        }, t.calculateTrifaseAMonofasee = function(e, t, n) {
            if (e <= 0) throw new Error("功率数值无效");
            if (t <= 0 || t > 250) throw new Error("电压数值无效");
            if (n <= 0 || n > 400) throw new Error("频率数值无效");
            return e * Math.pow(10, 6) / (2 * Math.PI * n * Math.pow(t, 2));
        }, t.calculateVoltage = function(e, t) {
            return i(t), 100 * e / t;
        };
    },
    ac2e: function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, r(n("8e0e"));
        var i = getApp(), o = {
            data: function() {
                return {
                    user: null
                };
            },
            mounted: function() {
                i.globalData.getUser().then(this._updateUser, function() {}), i.globalData.on("user-info-updated", this._updateUser);
            },
            unmounted: function() {
                i.globalData.off("user-info-updated", this._updateUser);
            },
            methods: {
                _updateUser: function(e) {
                    this.user = e;
                }
            }
        };
        t.default = o;
    },
    b17c: function(e, t, n) {
        var r = n("4a4b"), i = n("6f8f");
        function o(t, n, a) {
            return i() ? (e.exports = o = Reflect.construct.bind(), e.exports.__esModule = !0, 
            e.exports.default = e.exports) : (e.exports = o = function(e, t, n) {
                var i = [ null ];
                i.push.apply(i, t);
                var o = new (Function.bind.apply(e, i))();
                return n && r(o, n.prototype), o;
            }, e.exports.__esModule = !0, e.exports.default = e.exports), o.apply(null, arguments);
        }
        e.exports = o, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    b253: function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.buildQuery = s, t.default = void 0, t.hasToken = function() {
                return !!c;
            }, t.setToken = function(t) {
                c = t || null, e.setStorageSync("access_token", c);
            };
            var i = r(n("7037")), o = n("963d"), a = e.getStorageSync("session_id"), c = e.getStorageSync("access_token") || null;
            function s(e) {
                var t = [];
                for (var n in e) e.hasOwnProperty(n) && t.push(n + "=" + encodeURIComponent(e[n]));
                return t.join("&");
            }
            function u(e, t) {
                return e[t] || e[t.toLowerCase()];
            }
            function l(t, n) {
                if (n.header || (n.header = {}), n.enableHttp2 = !0, n.header["X-Platform"] = o.platformId, 
                c && (n.header.Authorization = "Bearer " + c), a && (n.header["Session-Id"] = a), 
                n.url || (n.url = o.apiBaseUrl + t), n.header["Content-Type"] = "application/x-www-form-urlencoded", 
                "object" == (0, i.default)(n.data) && Object.keys(n).length > 0) if ("DELETE" == n.method) {
                    var r = s(n.data);
                    delete n.data, n.url += (-1 != n.url.indexOf("?") ? "&" : "?") + r;
                } else !function e(t, n, r) {
                    for (var o in n) n.hasOwnProperty(o) && ("object" == (0, i.default)(n[o]) ? (e(t, n[o], r ? r + "[" + o + "]" : o), 
                    delete n[o]) : r && (t[r + "[" + o + "]"] = n[o]));
                }(n.data, n.data);
                return new Promise(function(t, r) {
                    n.success || (n.success = function(n) {
                        var o = u(n.header, "Session-Id");
                        if (o && (a = o, e.setStorage({
                            key: "session_id",
                            data: a
                        })), n.statusCode >= 400 && n.statusCode < 600) {
                            var c = n ? n.data : null;
                            return 401 == n.statusCode ? n.message = "未登录或登录已失效，请重新登录。" : "object" != (0, i.default)(c) || void 0 === c.message ? (n.message = n.statusCode + " Request Error.", 
                            n.code = 0) : (n.message = c.message, n.code = c.code), void r(n);
                        }
                        if (!u(n.header, "Content-Type").includes("json")) return n.code = 0, n.message = "Response data error.", 
                        void r(n);
                        t(n);
                    }), n.fail || (n.fail = function(e) {
                        r({
                            message: e ? e.errMsg : "Request unknown error",
                            code: 0,
                            status: 0
                        });
                    }), e.request(n);
                });
            }
            var p = {
                data: function() {
                    return {};
                },
                request: l,
                get: function(e, t) {
                    return l(e, {
                        data: t
                    });
                },
                post: function(e, t) {
                    return l(e, {
                        method: "POST",
                        data: t
                    });
                },
                put: function(e, t) {
                    return l(e, {
                        method: "PUT",
                        data: t
                    });
                },
                delete: function(e, t) {
                    return l(e, {
                        method: "DELETE",
                        data: t
                    });
                },
                getUrl: function(e) {
                    return o.apiBaseUrl + e;
                },
                commonHeader: function() {
                    var e = {
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Platform": o.platformId
                    };
                    return c && (e.Authorization = "Bearer " + c), a && (e["Session-Id"] = a), e;
                },
                getExam: function(e) {
                    return l("", {
                        url: e
                    });
                },
                postExam: function(e, t) {
                    return l("", {
                        url: e,
                        method: "POST",
                        data: t
                    });
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    b461: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e, t, n, r, i, o, a, c, s, u, l, p) {
            if (e <= 0) throw new Error("宽度数值无效");
            if (t <= 0) throw new Error("厚度数值无效");
            if (i > 0 && o <= 0) throw new Error("线间距数值无效");
            var f = [ 30, 35, 40, 45, 50 ][c], h = {
                copper: 1.7241,
                aluminum: 2.873
            }[n.label], d = 24.9 * Math.pow(e * t, .5) * Math.pow(e * t * 2, .39);
            d *= Math.pow(f, .61) / Math.sqrt(1 + h * (f + 25) * n.temperature);
            var g = 1.32, m = [ 1, 1.1, 1.2 ][s] * [ 1.05, 1.04, 1.03, 1.02, 1.01, 1, .99, .98, .97, .965, .96, .95, .94, .93, .925, .92, .91 ][a] * [ 1, 1.08, 1.16, 1.24, 1.32 ][c];
            if (1 === p) {
                switch (i) {
                  case 0:
                    g = e <= 50 ? 1.25 : g;
                    break;

                  case 1:
                    g = e > 50 ? 1.22 : 1.18;
                    break;

                  case 2:
                    g = e > 50 ? 1.13 : 1.14;
                    break;

                  case 3:
                    g = e > 50 ? 1.08 : 1.12;
                    break;

                  case 4:
                    g = e > 50 ? 1.06 : 1.1;
                    break;

                  case 5:
                    g = e > 50 ? 1.05 : 1.1;
                }
                o = 1;
                var v = m * g * [ 1, .71, .77 ][l] * [ [ 1, 1, 1, 1, 1, 1, 1, 1, 1 ], [ 1.69, 1.73, 1.76, 1.8, 1.83, 1.85, 1.87, 1.89, 1.91 ], [ 2.4, 2.45, 2.5, 2.55, 2.6, 2.63, 2.65, 2.68, 2.7 ], [ 3.05, 3.12, 3.18, 3.25, 3.31, 3.35, 3.38, 3.41, 3.44 ], [ 3.67, 3.74, 3.82, 3.9, 3.98, 4.02, 4.06, 4.09, 4.13 ], [ 4.23, 4.32, 4.41, 4.5, 4.59, 4.63, 4.68, 4.72, 4.77 ], [ 4.75, 4.85, 4.95, 5.05, 5.15, 5.2, 5.25, 5.3, 5.35 ] ][i][0], y = .75, _ = 1;
                if (0 === u) switch (i) {
                  case 0:
                    _ = .85;
                    break;

                  case 1:
                    _ = .8;
                    break;

                  case 2:
                    _ = .75;
                    break;

                  default:
                    _ = .65;
                }
                var T = v * _, w = 1;
                if ("copper" !== n.label) switch (i) {
                  case 0:
                    w = 1;
                    break;

                  case 1:
                    w = .83;
                    break;

                  default:
                    w = .68;
                } else switch (i) {
                  case 0:
                    w = 1;
                    break;

                  case 1:
                    w = .9;
                    break;

                  default:
                    w = .82;
                }
                var E = 1;
                1 === r && (E = 1 / (e * t / 200 + 1));
                var b = T * w * d * E;
                "copper" !== n.label && (y = .89), d = b * y;
            } else d = 222;
            return d;
        };
    },
    b5b5: function(e, t) {},
    bc2e: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = [ "qy", "env", "error", "version", "lanDebug", "cloud", "serviceMarket", "router", "worklet", "__webpack_require_UNI_MP_PLUGIN__" ], i = [ "lanDebug", "router", "worklet" ], o = "undefined" != typeof globalThis ? globalThis : function() {
            return this;
        }(), a = [ "w", "x" ].join(""), c = o[a], s = c.getLaunchOptionsSync ? c.getLaunchOptionsSync() : null;
        function u(e) {
            return (!s || 1154 !== s.scene || !i.includes(e)) && (r.indexOf(e) > -1 || "function" == typeof c[e]);
        }
        o[a] = function() {
            var e = {};
            for (var t in c) u(t) && (e[t] = c[t]);
            return e;
        }();
        var l = o[a];
        t.default = l;
    },
    c135: function(e, t) {
        e.exports = function(e) {
            if (Array.isArray(e)) return e;
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    c240: function(e, t) {
        e.exports = function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    c297: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.StandardQuery = t.PinDefinition = void 0, t.StandardQuery = [ {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "熔断器应用类型",
            is_vip: !0,
            url: "/pages/standard-data/fuse-type/fuse-type"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "UL(美)/CSA(加)熔断器类型",
            is_vip: !0,
            url: "/pages/standard-data/uc-fuse-type/uc-fuse-type"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "脱扣曲线",
            is_vip: !0,
            url: "/pages/standard-data/tripping-curve/tripping-curve"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电缆电抗表",
            is_vip: !0,
            url: "/pages/standard-data/cable-reactance/cable-reactance"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电阻率和电导率表",
            is_vip: !0,
            url: "/pages/standard-data/resistivity/resistivity"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电器防触电类型",
            is_vip: !0,
            url: "/pages/standard-data/electric-shock-protection/electric-shock-protection"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "闭路电视分辨率",
            is_vip: !0,
            url: "/pages/standard-data/cctv-resolution/cctv-resolution"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "ANSI标准设备编号",
            is_vip: !0,
            url: "/pages/standard-data/ansi-device-number/ansi-device-number"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电路符号大全",
            is_vip: !0,
            url: "/pages/standard-data/electrical-symbol/electrical-symbol"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电源插头和插座类型",
            is_vip: !0,
            url: "/pages/standard-data/power-plug/power-plug"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "IEC 60320电源插头标准",
            is_vip: !0,
            url: "/pages/standard-data/iec60320/iec60320"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "C型插座（IEC 60309）",
            is_vip: !0,
            url: "/pages/standard-data/c-socket/c-socket"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "Nema插座",
            is_vip: !0,
            url: "/pages/standard-data/nema-socket/nema-socket"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电动汽车充电插头",
            is_vip: !0,
            url: "/pages/standard-data/ev-charging-plugs/ev-charging-plugs"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "电线颜色标准",
            is_vip: !0,
            url: "/pages/standard-data/wire-color/wire-color"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "国际单位前缀",
            is_vip: !0,
            url: "/pages/standard-data/unit-prefix/unit-prefix"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "计量单位",
            is_vip: !0,
            url: "/pages/standard-data/unit-of-measurement/unit-of-measurement"
        }, {
            type: "standard-query",
            icon: "/static/images/icon_detail.png",
            name: "管道尺寸",
            is_vip: !0,
            url: "/pages/standard-data/pipe-size/pipe-size"
        } ], t.PinDefinition = [ {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "PoE以太网引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin1/pin1"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "以太网线（RJ-45）引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin2/pin2"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "RJ-9,11,14,25,48引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin3/pin3"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Scart引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin4/pin4"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "USB引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin5/pin5"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "HDMI引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin6/pin6"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "VGA引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin7/pin7"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "DVI引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin8/pin8"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "RS-232引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin9/pin9"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "FireWire引脚(IEEE1394)",
            is_vip: !0,
            url: "/pages/data/pin/pin10/pin10"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Molex引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin11/pin11"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Sata引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin12/pin12"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Lightning引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin13/pin13"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Dock连接器引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin14/pin14"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "DisplayPort 端口",
            is_vip: !0,
            url: "/pages/data/pin/pin15/pin15"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "PS/2引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin16/pin16"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "光纤颜色代码",
            is_vip: !0,
            url: "/pages/data/pin/pin17/pin17"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "LED引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin18/pin18"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "树莓派引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin19/pin19"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "ISO 10487（车载音响）引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin20/pin20"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "OBD II 端口",
            is_vip: !0,
            url: "/pages/data/pin/pin21/pin21"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "XLR（音频-DMX）引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin22/pin22"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "MIDI引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin23/pin23"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Jack 端口",
            is_vip: !0,
            url: "/pages/data/pin/pin24/pin24"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "RCA颜色编码",
            is_vip: !0,
            url: "/pages/data/pin/pin25/pin25"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Thunderbolt引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin26/pin26"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "SD卡引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin27/pin27"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "Sim卡引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin28/pin28"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "16x2 LCD显示端口",
            is_vip: !0,
            url: "/pages/data/pin/pin29/pin29"
        }, {
            type: "pin-definition",
            icon: "/static/images/icon_detail.png",
            name: "IO-Link引脚",
            is_vip: !0,
            url: "/pages/data/pin/pin30/pin30"
        } ];
    },
    c8ba: function(e, t) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == typeof window && (n = window);
        }
        e.exports = n;
    },
    c973: function(e, t) {
        function n(e, t, n, r, i, o, a) {
            try {
                var c = e[o](a), s = c.value;
            } catch (e) {
                return void n(e);
            }
            c.done ? t(s) : Promise.resolve(s).then(r, i);
        }
        e.exports = function(e) {
            return function() {
                var t = this, r = arguments;
                return new Promise(function(i, o) {
                    var a = e.apply(t, r);
                    function c(e) {
                        n(a, i, o, c, s, "next", e);
                    }
                    function s(e) {
                        n(a, i, o, c, s, "throw", e);
                    }
                    c(void 0);
                });
            };
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    d055: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SimplifyCurrentType = t.InputTerminal = t.CurrentUnits = t.CurrentType = void 0, 
        t.calculate = function(e) {
            var t = 0;
            switch (e.inputTerminal) {
              case u.VOLTAGE_POWER:
                t = l(e.currentType, e.voltageValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case u.VOLTAGE_IMPEDANCE:
                t = function(e, t, n) {
                    var r = 0;
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("阻抗数值无效");
                    switch (e) {
                      case c.SINGLE_PHASE_CURRENT:
                      case c.TWO_PHASE_CURRENT:
                      case c.THREE_PHASE_CURRENT:
                        r = t / n;
                    }
                    return r;
                }(e.currentType, e.voltageValue, e.impedanceValue);
                break;

              case u.VOLTAGE_RESISTANCE:
                t = function(e, t, n, r) {
                    var a = 0;
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电压数值无效");
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("电阻数值无效");
                    switch (p(r), e) {
                      case c.DIRECT_CURRENT:
                        a = t / n;
                        break;

                      case c.SINGLE_PHASE_CURRENT:
                      case c.TWO_PHASE_CURRENT:
                      case c.THREE_PHASE_CURRENT:
                        a = t * r[o.TrigonometricType.COS] / n;
                    }
                    return a;
                }(e.currentType, e.voltageValue, e.resistanceValue, e.triangleCollection);
                break;

              case u.POWER_IMPEDANCE:
                t = function(e, t, n, r, a) {
                    var s = 0;
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("阻抗数值无效");
                    switch (p(a), e) {
                      case c.SINGLE_PHASE_CURRENT:
                      case c.TWO_PHASE_CURRENT:
                        if (90 === a[o.TrigonometricType.DEG]) return Math.sqrt(a[o.TrigonometricType.TAN] * n / t);
                        s = "P" === r ? Math.sqrt(n / (t * a[o.TrigonometricType.COS])) : "S" === r ? Math.sqrt(n / t) : Math.sqrt(n / (t * a[o.TrigonometricType.SIN]));
                        break;

                      case c.THREE_PHASE_CURRENT:
                        if (90 === a[o.TrigonometricType.DEG]) return Math.sqrt(a[o.TrigonometricType.TAN] * n / (Math.sqrt(3) * t));
                        s = "P" === r ? Math.sqrt(n / (Math.sqrt(3) * t * a[o.TrigonometricType.COS])) : "S" === r ? Math.sqrt(n / (Math.sqrt(3) * t)) : Math.sqrt(n / (Math.sqrt(3) * t * a[o.TrigonometricType.SIN]));
                    }
                    return s;
                }(e.currentType, e.impedanceValue, e.powerValue, e.powerType, e.triangleCollection);
                break;

              case u.POWER_RESISTANCE:
                t = function(e, t, n, r, a) {
                    var s = 0;
                    if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
                    if (!(0, i.isNonzeroNumber)(t)) throw new Error("电阻数值无效");
                    if (p(a), 0 === a[o.TrigonometricType.TAN]) throw new Error("∞");
                    switch (e) {
                      case c.DIRECT_CURRENT:
                        s = Math.sqrt(n * t);
                        break;

                      case c.SINGLE_PHASE_CURRENT:
                      case c.TWO_PHASE_CURRENT:
                        s = "P" === r ? Math.sqrt(n / t) : "S" === r ? Math.sqrt(n * a[o.TrigonometricType.COS] / t) : Math.sqrt(n * a[o.TrigonometricType.COS] / (t * a[o.TrigonometricType.SIN]));
                        break;

                      case c.THREE_PHASE_CURRENT:
                        s = "P" === r ? Math.sqrt(n / (Math.sqrt(3) * t)) : "S" === r ? Math.sqrt(n * a[o.TrigonometricType.COS] / (Math.sqrt(3) * t)) : Math.sqrt(n * a[o.TrigonometricType.COS] / (Math.sqrt(3) * t * a[o.TrigonometricType.SIN]));
                    }
                    return s;
                }(e.currentType, e.resistanceValue, e.powerValue, e.powerType, e.triangleCollection);
            }
            return t;
        }, t.calculateVoltagePower = l, t.toSimplifyCurrentType = function(e) {
            var t = "";
            switch (e) {
              case c.DIRECT_CURRENT:
                t = s.DIRECT_CURRENT;
                break;

              case c.SINGLE_PHASE_CURRENT:
              case c.TWO_PHASE_CURRENT:
              case c.THREE_PHASE_CURRENT:
                t = s.ALTERNATING_CURRENT;
            }
            if ("" === t) throw new Error("电流类型无效");
            return t;
        };
        var r = n("00cd"), i = n("d417"), o = n("2e64"), a = {
            mA: new r.Unit("mA", .001),
            A: new r.Unit("A"),
            kA: new r.Unit("kA", 1e3)
        };
        t.CurrentUnits = a;
        var c = {
            DIRECT_CURRENT: "direct_current",
            SINGLE_PHASE_CURRENT: "single_phase_current",
            TWO_PHASE_CURRENT: "two_phase_current",
            THREE_PHASE_CURRENT: "three_phase_current"
        };
        t.CurrentType = c;
        var s = {
            DIRECT_CURRENT: "DC",
            ALTERNATING_CURRENT: "AC"
        };
        t.SimplifyCurrentType = s;
        var u = {
            VOLTAGE_POWER: "voltage_power",
            VOLTAGE_IMPEDANCE: "voltage_impedance",
            VOLTAGE_RESISTANCE: "voltage_resistance",
            POWER_IMPEDANCE: "power_impedance",
            POWER_RESISTANCE: "power_resistance"
        };
        function l(e, t, n, r, a) {
            var s = 0;
            if (!(0, i.isNonzeroNumber)(t)) throw new Error("电压数值无效");
            if (!(0, i.isNonzeroNumber)(n)) throw new Error("功率数值无效");
            switch (p(a), e) {
              case c.DIRECT_CURRENT:
                s = n / t;
                break;

              case c.SINGLE_PHASE_CURRENT:
              case c.TWO_PHASE_CURRENT:
                if (90 === a[o.TrigonometricType.DEG]) return a[o.TrigonometricType.TAN] * n / t;
                s = "P" === r ? n / (t * a[o.TrigonometricType.COS]) : "S" === r ? n / t : n / (t * a[o.TrigonometricType.SIN]);
                break;

              case c.THREE_PHASE_CURRENT:
                if (90 === a[o.TrigonometricType.DEG]) return a[o.TrigonometricType.TAN] * n / (Math.sqrt(3) * t);
                s = "P" === r ? n / (Math.sqrt(3) * t * a[o.TrigonometricType.COS]) : "S" === r ? n / (Math.sqrt(3) * t) : n / (Math.sqrt(3) * t * a[o.TrigonometricType.SIN]);
            }
            return s;
        }
        function p(e) {
            if (e.type === o.TrigonometricType.COS && 0 === e[o.TrigonometricType.COS]) throw new Error("功率因数数值无效");
        }
        t.InputTerminal = u;
    },
    d417: function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.calculatePageScroll = function(t) {
                e.pageScrollTo({
                    duration: 200,
                    scrollTop: t
                });
            }, t.each = function(e, t, n) {
                for (var r in e) e.hasOwnProperty(r) && (n ? t.call(n, e[r], r) : t(e[r], r));
            }, t.isNonzeroNumber = function(e) {
                return !isNaN(e) && parseFloat(e) > 0;
            }, t.isVoidNumber = function(e) {
                return "" === e || void 0 === e || isNaN(e);
            }, t.keepCurrentIndexOfOptions = function(e, t, n) {
                var r, i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
                return n = e ? (r = i ? t.findIndex(function(t) {
                    return t[i] === e[i];
                }) : t.findIndex(function(t) {
                    return t === e;
                })) > -1 ? r : n : 0;
            };
        }).call(this, n("543d").default);
    },
    d633: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BatteryCapacityUnits = void 0;
        var r = n("00cd"), i = {
            mAh: new r.Unit("mAh", .001),
            Ah: new r.Unit("Ah")
        };
        t.BatteryCapacityUnits = i;
    },
    d9d4: function(e, t, n) {
        "use strict";
        function r(e) {
            return 1.8 * e + 32;
        }
        function i(e) {
            return e + 273.15;
        }
        function o(e) {
            return (e - 32) / 1.8;
        }
        function a(e) {
            return e - 273.15;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TemperatureUnit = void 0, t.celsius2fahrenheit = r, t.celsius2kelvin = i, 
        t.fahrenheit2celsius = o, t.kelvin2celsius = a, t.temperatureConvert = function(e, t, n) {
            if (t === n) return e;
            switch (t) {
              case c.CELSIUS:
                switch (n) {
                  case c.FAHRENHEIT:
                    return r(e);

                  case c.KELVIN:
                    return i(e);
                }
                break;

              case c.FAHRENHEIT:
                switch (n) {
                  case c.CELSIUS:
                    return o(e);

                  case c.KELVIN:
                    return i(o(e));
                }
                break;

              case c.KELVIN:
                switch (n) {
                  case c.CELSIUS:
                    return a(e);

                  case c.FAHRENHEIT:
                    return r(a(e));
                }
            }
            return NaN;
        };
        var c = {
            CELSIUS: "°C",
            FAHRENHEIT: "°F",
            KELVIN: "°K"
        };
        t.TemperatureUnit = c;
    },
    e308: function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FeatureType = void 0, t.getCalcFeatures = p, t.getConfig = g, t.getConvertFeatures = f, 
            t.getElectromotorFeatures = h, t.getFeature = function(e) {
                return new Promise(function(t, n) {
                    switch (e) {
                      case l.Calculate:
                        t(p());
                        break;

                      case l.Converter:
                        t(f());
                        break;

                      case l.Electromotor:
                        t(h());
                        break;

                      default:
                        n("计算器类型错误");
                    }
                });
            }, t.getFeatureConfig = function(e, t) {
                var n = g(t), r = "";
                return n.forEach(function(t) {
                    t.key == e && (r = t);
                }), r;
            }, t.openFeature = d, t.openFeatureByKey = function(e, t) {
                g(t).forEach(function(t) {
                    t.key == e && d(t);
                });
            };
            var i = r(n("b253")), o = n("9673"), a = n("3bc8"), c = getApp();
            function s(t, n) {
                return i.default.get("features", {
                    type: n
                }).then(function(r) {
                    var i = {};
                    return r.data.forEach(function(e) {
                        i[e.key] = e;
                    }), new Promise(function(r, o) {
                        e.setStorage({
                            key: t,
                            data: i,
                            success: function() {
                                c.globalData["features_" + n + "_updated"] = !0, r(i);
                            },
                            fail: function(e) {
                                return o({
                                    statusCode: 0,
                                    message: e.errMsg
                                });
                            }
                        });
                    });
                });
            }
            function u(t, n) {
                return new Promise(function(r, i) {
                    e.getStorage({
                        key: t,
                        success: function(e) {
                            r(e.data), c.globalData["features_" + n + "_updated"] || s(t, n).silent();
                        },
                        fail: function() {
                            s(t, n).then(r, i);
                        }
                    });
                });
            }
            var l = {
                Calculate: 1,
                Converter: 2,
                Electromotor: 3
            };
            function p() {
                return u("features_calc", l.Calculate);
            }
            function f() {
                return u("features_convert", l.Converter);
            }
            function h() {
                return u("features_electromotor", l.Electromotor);
            }
            function d(t) {
                var n = "/pages/" + t.page;
                0 == t.requirement ? e.navigateTo({
                    url: n
                }) : (0, o.loginRequired)().then(function() {
                    e.navigateTo({
                        url: n
                    });
                }, function() {});
            }
            function g(e) {
                var t = [];
                switch (e) {
                  case l.Calculate:
                    t = a.calculates;
                    break;

                  case l.Converter:
                    t = a.converters;
                    break;

                  case l.Electromotor:
                    t = a.electromotors;
                }
                return t;
            }
            t.FeatureType = l;
        }).call(this, n("543d").default);
    },
    e50d: function(e, t, n) {
        var r = n("7037").default;
        e.exports = function(e, t) {
            if ("object" !== r(e) || null === e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 !== n) {
                var i = n.call(e, t || "default");
                if ("object" !== r(i)) return i;
                throw new TypeError("@@toPrimitive must return a primitive value.");
            }
            return ("string" === t ? String : Number)(e);
        }, e.exports.__esModule = !0, e.exports.default = e.exports;
    },
    e615: function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.NECIdentifier = t.LayingModeConfig = void 0, t.getCableCoreAreConfig = function(e, t, n) {
            var r = t + "_" + n;
            return e.serialNumberType.config[r];
        }, t.getTemperatureAmbientConfig = function(e, t) {
            return e.isHighTemperature ? t === a.InsulationType.PVC ? [ 1.1, 1.05, 1, .95, .89, .84, .77, .71, .63, .55, .45 ] : [ 1.07, 1.04, 1, .96, .93, .89, .85, .8, .76, .71, .65, .6, .53, .46, .38 ] : t === a.InsulationType.PVC ? [ 1.22, 1.17, 1.12, 1.06, 1, .94, .87, .79, .71, .61, .5 ] : [ 1.15, 1.12, 1.08, 1.04, 1, .96, .91, .87, .82, .76, .71, .65, .58, .5, .41 ];
        };
        var i = r(n("5bc3")), o = r(n("970b")), a = n("9bc7"), c = (0, i.default)(function e(t, n, r, i, a, c, s, u) {
            (0, o.default)(this, e), this.serialNumber = t, this.serialNumberType = n, this.description = r, 
            this.cover = i, this.illustrate = a, this.isSingleCore = c, this.bool1 = s, this.isHighTemperature = u, 
            this.title = (t ? t + " - " : "") + n.label;
        }), s = (0, i.default)(function e(t, n) {
            (0, o.default)(this, e), this.title = t, this.identifier = n;
        }), u = {
            TRENCH_PIPE_BURIED_LAYING: "trench_pipe_buried_laying",
            OVERHEAD_LAYING: "overhead_laying",
            COMMUNICATION_DEVICES: "communication_devices"
        };
        t.NECIdentifier = u;
        var l = {
            value: 0,
            label: "A1",
            config: {
                pvc_2: [ 7, 9.5, 11, 14.5, 19.5, 26, 34, 46, 61, 80, 99, 119, 151, 182, 210, 240, 273, 320, 367 ],
                pvc_3: [ 7, 9, 10.5, 13.5, 18, 24, 31, 42, 56, 73, 89, 108, 136, 164, 188, 216, 245, 286, 327 ],
                xlpe_epr_2: [ 10, 12.5, 15, 19, 26, 36, 45, 61, 81, 106, 131, 158, 200, 241, 278, 318, 362, 424, 485 ],
                xlpe_epr_3: [ 8.5, 11, 13, 17, 23, 31, 40, 54, 73, 95, 117, 141, 179, 216, 249, 285, 324, 380, 434 ]
            }
        }, p = {
            value: 1,
            label: "A2",
            config: {
                pvc_2: [ 7, 9, 11, 14, 18.5, 25, 32, 43, 57, 75, 92, 110, 139, 167, 192, 219, 248, 291, 334 ],
                pvc_3: [ 6.5, 8.5, 10, 13, 17.5, 23, 29, 39, 52, 68, 83, 99, 125, 150, 172, 196, 223, 261, 298 ],
                xlpe_epr_2: [ 9.5, 12, 14.5, 18.5, 25, 33, 42, 57, 76, 99, 121, 145, 183, 220, 253, 290, 329, 386, 442 ],
                xlpe_epr_3: [ 8.5, 11, 13, 16.5, 22, 30, 38, 51, 68, 89, 109, 130, 164, 197, 227, 259, 295, 346, 396 ]
            }
        }, f = {
            value: 2,
            label: "B1",
            config: {
                pvc_2: [ 9, 11.5, 13.5, 17.5, 24, 32, 41, 57, 76, 101, 125, 151, 192, 232, 269, 300, 341, 400, 458 ],
                pvc_3: [ 8, 10, 12, 15.5, 21, 28, 36, 50, 68, 89, 110, 134, 171, 207, 239, 262, 296, 347, 394 ],
                xlpe_epr_2: [ 11, 14.5, 17, 23, 31, 42, 54, 75, 100, 133, 164, 198, 253, 306, 354, 393, 449, 528, 603 ],
                xlpe_epr_3: [ 10, 12.5, 15, 20, 28, 37, 48, 66, 88, 117, 144, 175, 222, 269, 312, 342, 384, 450, 514 ]
            }
        }, h = {
            value: 3,
            label: "B2",
            config: {
                pvc_2: [ 8.5, 11, 13.5, 16.5, 23, 30, 38, 52, 69, 90, 111, 133, 168, 201, 232, 258, 294, 344, 394 ],
                pvc_3: [ 8, 10, 12, 15, 20, 27, 34, 46, 62, 80, 99, 118, 149, 179, 206, 225, 255, 297, 339 ],
                xlpe_epr_2: [ 11.5, 14.5, 17, 22, 30, 40, 51, 69, 91, 119, 146, 175, 221, 265, 305, 334, 384, 459, 532 ],
                xlpe_epr_3: [ 10, 12.5, 15, 19.5, 26, 35, 44, 60, 80, 105, 128, 154, 194, 233, 268, 300, 340, 398, 455 ]
            }
        }, d = {
            value: 4,
            label: "C",
            config: {
                pvc_2: [ 10, 12.5, 15, 19.5, 26, 35, 46, 63, 85, 112, 138, 168, 213, 258, 299, 344, 392, 461, 530 ],
                pvc_3: [ 7, 9.5, 11.5, 17.5, 24, 32, 41, 57, 76, 96, 119, 144, 184, 223, 259, 299, 341, 403, 464 ],
                xlpe_epr_2: [ 12, 15.5, 18.5, 24, 33, 45, 58, 80, 107, 142, 175, 212, 270, 327, 382, 441, 506, 599, 693 ],
                xlpe_epr_3: [ 9.5, 12.5, 15, 20, 28, 37, 48, 71, 96, 127, 157, 190, 242, 293, 322, 371, 424, 500, 576 ],
                contact: [ 18.9, 25.2, 33.3, 43.2, 58.5, 77.4, 100.8, 123.3, 152.1, 186.3, 224.1, 257.4, 294.3, 333.9, 390.6 ],
                contactless: [ 26, 35, 47, 59, 81, 107, 140, 171, 212, 260, 312, 359, 410, 465, 544 ]
            }
        }, g = {
            value: 5,
            label: "D1",
            config: {
                pvc_2: [ 10, 12.5, 14.5, 19, 25, 33, 41, 56, 73, 94, 115, 143, 175, 208, 240, 273, 307, 360 ],
                pvc_3: [ 8, 10.5, 12.5, 16, 21, 28, 35, 47, 61, 79, 97, 120, 148, 175, 202, 231, 259, 304 ],
                xlpe_epr_2: [ 11.5, 15, 17.5, 23, 30, 39, 49, 66, 86, 111, 136, 168, 207, 245, 284, 324, 364, 428 ],
                xlpe_epr_3: [ 10, 12.5, 14.5, 19, 25, 32, 41, 55, 72, 93, 114, 141, 174, 206, 238, 272, 306, 360 ]
            }
        }, m = {
            value: 6,
            label: "D1",
            config: {
                pvc_2: [ 11, 14, 16, 21, 27, 36, 45, 61, 78, 101, 123, 153, 187, 222, 256, 292, 328, 385 ],
                pvc_3: [ 9, 11.5, 14, 18, 23, 30, 38, 51, 66, 86, 104, 129, 158, 187, 216, 246, 277, 325 ],
                xlpe_epr_2: [ 12.5, 16, 18.5, 24, 32, 41, 52, 70, 91, 118, 144, 178, 218, 258, 298, 340, 383, 450, 510, 595, 671, 767 ],
                xlpe_epr_3: [ 11, 13.5, 16, 21, 27, 35, 44, 59, 77, 100, 121, 150, 184, 217, 251, 287, 323, 379, 429, 500, 565, 645 ]
            }
        }, v = {
            value: 7,
            label: "D2",
            config: {
                pvc_2: [ 12, 15, 17, 22, 28, 38, 48, 64, 83, 110, 132, 156, 192, 230, 261, 293, 331, 382, 427 ],
                pvc_3: [ 10, 12.5, 16, 19, 24, 33, 41, 54, 70, 92, 110, 130, 162, 193, 220, 246, 278, 320, 359 ],
                xlpe_epr_2: [ 13.5, 16, 21, 27, 35, 46, 58, 77, 100, 129, 155, 183, 225, 270, 306, 343, 387, 448, 502 ],
                xlpe_epr_3: [ 12.5, 15.5, 18, 23, 30, 39, 49, 65, 84, 107, 129, 153, 188, 226, 257, 287, 324, 375, 419 ]
            }
        }, y = {
            value: 8,
            label: "E",
            config: {
                pvc_2: [ 10, 13, 15, 22, 30, 40, 51, 70, 94, 119, 148, 180, 232, 282, 328, 379, 434, 514, 593 ],
                pvc_3: [ 9, 12, 13.6, 18.5, 25, 34, 43, 60, 80, 101, 126, 153, 196, 238, 276, 319, 364, 430, 497 ],
                xlpe_epr_2: [ 13, 16.5, 19, 26, 36, 49, 63, 86, 115, 149, 185, 225, 289, 352, 410, 473, 542, 641, 741 ],
                xlpe_epr_3: [ 11.5, 15, 17, 23, 32, 42, 54, 75, 100, 127, 158, 192, 246, 298, 346, 399, 456, 538, 621 ],
                contact: [ 19.8, 27, 36, 45.9, 62.1, 82.8, 108, 132.3, 163.8, 200.7, 240.3, 272.2, 316.8, 359.1, 419.4 ],
                contactless: [ 28, 38, 50, 64, 87, 115, 150, 184, 228, 279, 335, 385, 441, 500, 584 ]
            }
        }, _ = {
            value: 9,
            label: "F",
            config: {
                pvc_2: [ 11, 14, 16.5, 22, 30, 40, 52, 71, 96, 131, 162, 196, 251, 304, 352, 406, 463, 546, 629, 754, 868, 1005 ],
                pvc_3: [ 9.5, 12, 14.5, 19.5, 26, 35, 46, 63, 85, 114, 143, 174, 225, 275, 321, 372, 427, 507, 587, 689, 789, 905 ],
                xlpe_epr_2: [ 13, 17, 20.5, 27, 37, 50, 64, 88, 119, 161, 200, 242, 310, 377, 437, 504, 575, 679, 783, 940, 1083, 1254 ],
                xlpe_epr_3: [ 12, 15, 18.5, 24, 33, 45, 58, 80, 107, 141, 176, 216, 279, 342, 400, 464, 533, 634, 736, 868, 998, 1151 ],
                contact: [ 23.4, 30.6, 40.5, 51.3, 69.3, 91.8, 118.8, 144.9, 178.2, 216.9, 260.1, 297.9, 339.3, 383.4, 446.4 ],
                contactless: [ 32, 43, 56, 71, 96, 127, 164, 200, 247, 300, 359, 411, 469, 530, 617 ]
            }
        }, T = {
            value: 10,
            label: "G",
            config: {
                pvc_2: [ 12.06, 15.61, 18.75, 24.28, 33.61, 45.34, 58.71, 81.28, 109.65, 146, 181, 219, 281, 341, 396, 456, 521, 615, 709, 852, 982, 1138 ],
                pvc_3: [ 12.06, 15.61, 18.75, 24.28, 33.61, 45.34, 58.71, 81.28, 109.65, 146, 181, 219, 281, 341, 396, 456, 521, 615, 709, 852, 982, 1138 ],
                xlpe_epr_2: [ 14.65, 19.03, 22.9, 29.73, 41.32, 55.92, 72.6, 100.89, 136.55, 182, 226, 275, 353, 430, 500, 577, 661, 781, 902, 1085, 1253, 1454 ],
                xlpe_epr_3: [ 14.65, 19.03, 22.9, 29.73, 41.32, 55.92, 72.6, 100.89, 136.55, 182, 226, 275, 353, 430, 500, 577, 661, 781, 902, 1085, 1253, 1454 ],
                contact: [ 28.8, 38.7, 50.4, 63.9, 85.5, 112.5, 145.8, 177.3, 217.8, 264.6, 315.9, 361.8, 408.6, 456.3, 508.5 ],
                contactless: [ 40, 54, 70, 89, 120, 157, 204, 248, 304, 370, 441, 505, 565, 629, 704 ]
            }
        }, w = {
            cable: {
                IEC: [ new c(1, l, "隔热墙内导管内的绝缘导体或单芯电缆", "posa_01.png", "", !0, !1, !1), new c(2, p, "隔热墙内导管中的多芯电缆", "posa_02.png", "", !1, !0, !1), new c(3, l, "多芯电缆直接敷设在隔热墙内", "posa_03.png", "", !1, !0, !1), new c(4, f, "绝缘导线或单芯电缆，位于木制或砖石墙上的导管内，或与之间隔小于0.3×导管直径", "posa_04.png", "", !0, !1, !1), new c(5, h, "木质或砖石墙上的导管中的多芯电缆，或与导管之间的间距小于0.3×导管直径", "posa_05.png", "", !1, !0, !1), new c(6, f, "水平或垂直敷设在木制或砖石墙上的电缆槽（包括多室线槽）中的绝缘导体或单芯电缆", "posa_06_07.png", "", !0, !1, !1), new c(8, h, "水平或垂直敷设在木制或砖石墙上的电缆槽（包括多室线槽）中的多芯电缆", "posa_08_09.png", "", !1, !0, !1), new c(10, f, "悬空电缆槽中的绝缘导体或单芯电缆", "posa_10.png", "", !0, !1, !1), new c(11, h, "悬空电缆槽中的多芯电缆", "posa_11.png", "", !1, !0, !1), new c(12, l, "绝缘导体或单芯电缆嵌模", "posa_12.png", "", !0, !1, !1), new c(15, l, "导管内绝缘导体或单芯或多芯电缆", "posa_15.png", "", !0, !0, !1), new c(16, l, "导管中的绝缘导体或窗框中的单芯或多芯电缆", "posa_16.png", "", !0, !0, !1), new c(20, d, "单芯或多芯电缆固定在木质或砖石墙上，或与木质或砖石墙上的电缆直径间隔小于0.3×10", "posa_20.png", "", !0, !0, !1), new c(21, d, "单芯或多芯电缆直接固定在木制或砖石天花板下", "posa_21.png", "", !0, !0, !1), new c(22, y, "与天花板隔开的单芯或多芯电缆", "posa_22.png", "", !0, !0, !1), new c(30, d, "未穿孔托盘上的单芯或多芯电缆水平或垂直敷设", "posa_30.png", "", !0, !0, !1), new c(31, _, "穿孔托盘上的单芯电缆水平或垂直敷设", "posa_31.png", "", !0, !1, !1), new c(31, y, "多孔托盘上的多芯电缆水平或垂直敷设", "posa_31.png", "", !1, !0, !1), new c(32, _, "单芯电缆在支架或钢丝网托盘上水平或垂直敷设", "posa_32.png", "", !0, !1, !1), new c(32, y, "多芯电缆在支架或钢丝网托盘上水平或垂直敷设", "posa_32.png", "", !1, !0, !1), new c(33, _, "单芯电缆，距离墙壁的距离大于电缆直径的0.3倍", "posa_33_1.png", "", !0, !1, !1), new c(33, y, "多芯电缆，距离墙壁的距离大于电缆直径的0.3倍", "posa_33_2.png", "", !1, !0, !1), new c(34, _, "梯架单芯电缆", "posa_34.png", "", !0, !1, !1), new c(34, y, "梯架多芯电缆", "posa_34.png", "", !1, !0, !1), new c(35, _, "单芯电缆，悬挂在或包含在支撑线或线束上", "posa_35_1.png", "", !0, !1, !1), new c(35, y, "多芯电缆悬挂在或包含在支撑线或线束上", "posa_35_2.png", "", !1, !0, !1), new c(36, T, "绝缘子上的裸导体或绝缘导体", "posa_36.png", "", !0, !1, !1), new c(40, h, "建筑物空隙中的单芯或多芯电缆", "posa_40.png", "1.5 De ≤ V < 5 De", !0, !0, !0), new c(40, f, "建筑物空隙中的单芯或多芯电缆", "posa_40.png", "5 De ≤ V < 20 De", !0, !0, !0), new c(42, h, "建筑物空隙中导管中的单芯或多芯电缆", "posa_42.png", "1.5 De ≤ V < 20 De", !0, !0, !0), new c(42, f, "建筑物空隙中导管中的单芯或多芯电缆", "posa_42.png", "V ≥ 20 De", !0, !0, !0), new c(44, h, "建筑物空隙中的单芯或多芯电缆管道", "posa_44.png", "1.5 De ≤ V < 20 De", !0, !0, !0), new c(44, f, "建筑物空隙中的单芯或多芯电缆管道", "posa_44.png", "V ≥ 20 De", !0, !0, !0), new c(46, h, "砖石结构电缆管道中的单芯或多芯电缆，热阻率不大于2k·m/W", "posa_46.png", "1.5 De ≤ V < 20 De", !0, !0, !0), new c(46, f, "砖石结构电缆管道中的单芯或多芯电缆，热阻率不大于2k·m/W", "posa_46.png", "V ≥ 20 De", !0, !0, !0), new c(47, h, "天花板或活动地板中的单芯或多芯电缆", "posa_47.png", "1.5 De ≤ V < 5 De", !0, !0, !1), new c(47, f, "天花板或活动地板中的单芯或多芯电缆", "posa_47.png", "5 De ≤ V < 50 De", !0, !0, !1), new c(50, f, "地板内埋入电缆槽的绝缘导体或单芯电缆", "posa_50.png", "", !0, !1, !1), new c(51, h, "地板内埋入式电缆槽的多芯电缆", "posa_51.png", "", !1, !0, !1), new c(52, f, "埋入电缆槽的绝缘导体或单芯电缆", "posa_52.png", "", !0, !1, !1), new c(53, h, "埋入线槽的多芯电缆", "posa_53.png", "", !1, !0, !1), new c(54, h, "水平或垂直敷设在不通风电缆通道中的导管中的绝缘导体或单芯电缆", "posa_54.png", "1.5 De ≤ V < 20 De", !0, !1, !0), new c(54, f, "水平或垂直敷设在不通风电缆通道中的导管中的绝缘导体或单芯电缆", "posa_54.png", "V ≥ 20 De", !0, !1, !0), new c(56, f, "在水平或垂直敷设的开放或通风电缆通道中的单芯或多芯电缆", "posa_56.png", "", !0, !0, !0), new c(57, d, "热阻率不大于2k·m/W的单芯或多芯直接电缆", "posa_57.png", "", !0, !0, !0), new c(59, f, "砌体管道中的绝缘导体或单芯电缆", "posa_59.png", "", !0, !1, !0), new c(60, h, "砌体管道中的多芯电缆", "posa_60.png", "", !1, !0, !0), new c(70, g, "多芯电缆在导管内或在地下电缆管道内", "posa_70.png", "", !1, !0, !0), new c(71, m, "单芯电缆在导管内或在地下电缆管道内", "posa_71.png", "", !0, !1, !0), new c(72, v, "直接接地的单芯或多芯护套电缆", "posa_72.png", "", !0, !0, !0) ],
                NEC: [ new s("地沟、穿管或埋地敷设", u.TRENCH_PIPE_BURIED_LAYING), new s("架空敷设", u.OVERHEAD_LAYING), new s("在通信设备的支持下", u.COMMUNICATION_DEVICES) ]
            },
            conductor: {
                IEC: [ new c(0, d, "墙上的单芯或多芯电缆", "posa_bare_c.png", "", !0, !0, !1), new c(0, y, "自由空气中的多芯电缆（与墙壁的间隙不小于电缆直径的0.3倍）", "posa_bare_e.png", "", !1, !0, !1), new c(0, _, "单芯电缆，在自由空气中接触（与墙壁的间隙不小于一个电缆直径）", "posa_bare_f.png", "", !0, !1, !1), new c(0, T, "单芯电缆，在自由空气中间隔（至少一个电缆直径）", "posa_bare_g.png", "", !0, !1, !1) ],
                NEC: [ new s("架空敷设", u.OVERHEAD_LAYING) ]
            }
        };
        t.LayingModeConfig = w;
    },
    e827: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculate = function(e, t) {
            var n = 0;
            switch (e) {
              case r.ElectricalSpecifications.IEC:
                var a = t.cableCoreAreaConfig[t.cableCoreAreaIndex], c = t.temperatureAmbientConfig[t.temperatureAmbientIndex];
                n = function(e, t, n, r, a, c, s) {
                    var u = e.serialNumber, l = e.serialNumberType.value, p = t === i.Materials.ALUMINUM.label ? .78 : 1, f = [];
                    switch (l) {
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 5:
                      case 6:
                      case 7:
                        f = [ 1, .8, .7, .65, .6, .57, .54, .52, .5, .45, .41, .38 ];
                        break;

                      case 4:
                        f = 21 !== u ? [ 1, .85, .79, .75, .73, .72, .72, .71, .7, .7, .7, .7 ] : [ .95, .81, .72, .68, .66, .64, .63, .62, .61, .61, .61, .61 ];
                        break;

                      case 8:
                      case 9:
                      case 10:
                        f = 34 !== u ? [ 1, .88, .82, .77, .75, .73, .73, .72, .72, .72, .72, .72 ] : [ 1, .87, .82, .8, .8, .79, .79, .78, .78, .78, .78, .78 ];
                    }
                    var h = n * p * f[a] * r, d = 1;
                    return 5 === l || 6 === l ? d = o[0][s] : 7 === l && (d = o[1][s]), h = h * d * c;
                }(t.layingMode, t.material, a, c, t.pipeCircuitIndex, t.conductorNumber, t.soilThermalResistivityIndex);
                break;

              case r.ElectricalSpecifications.NEC:
                n = function(e, t, n, i, o, a, c) {
                    return r.InsulatedConductorConfig.NEC.cableCoreAreaConfig[t][e][i][n] * o.config[e][i] * a.option * c;
                }(t.layingMode.identifier, t.material, t.cableCoreAreaIndex, t.maximumOperatingTemperatureIndex, t.temperatureAmbient, t.totalConductor, t.conductorNumber);
            }
            return n;
        };
        var r = n("9bc7"), i = n("028b"), o = [ [ 1.28, 1.2, 1.18, 1.1, 1.05, 1, .96 ], [ 1.88, 1.62, 1.5, 1.28, 1.12, 1, .9 ] ];
    },
    e954: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.calculateLossEnergy = function(e, t) {
            return e * Math.pow(t, 2);
        }, t.calculateLossPower = function(e, t) {
            return e * t;
        }, t.enegryUnits = void 0;
        var r = n("00cd"), i = {
            J: new r.Unit("J"),
            kJ: new r.Unit("kJ", 1e3),
            MJ: new r.Unit("MJ", 1e3, 2),
            Wh: new r.Unit("Wh", 3600),
            kWh: new r.Unit("kWh", 36e5),
            MWh: new r.Unit("MWh", 36e8),
            BTU: new r.Unit("BTU", 1055.06),
            cal: new r.Unit("cal", 4.18679),
            Kcal: new r.Unit("Kcal", 4186.79),
            Mcal: new r.Unit("Mcal", 4186790)
        };
        t.enegryUnits = i;
    },
    ed61: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("2e64"), i = n("d055"), o = 1, a = .9, c = .8, s = {
            data: function() {
                return {
                    trigonometricTypeIndex: 0,
                    trigonometricType: [ {
                        option: r.TrigonometricType.COS,
                        label: "CosΦ"
                    }, {
                        option: r.TrigonometricType.SIN,
                        label: "SinΦ"
                    }, {
                        option: r.TrigonometricType.TAN,
                        label: "TanΦ"
                    }, {
                        option: r.TrigonometricType.RAD,
                        label: "Φ(RAD)"
                    }, {
                        option: r.TrigonometricType.DEG,
                        label: "Φ(DEG)"
                    } ],
                    trigonometricTypeValue: a
                };
            },
            methods: {
                getTriangleCollection: function() {
                    return (0, r.triangleCollection)(this.trigonometricTypeValue, this.trigonometricType[this.trigonometricTypeIndex].option);
                },
                setTrigonometricTypeValue: function(e) {
                    var t = o;
                    switch (e) {
                      case i.CurrentType.SINGLE_PHASE_CURRENT:
                      case i.CurrentType.TWO_PHASE_CURRENT:
                        t = a;
                        break;

                      case i.CurrentType.THREE_PHASE_CURRENT:
                        t = c;
                    }
                    this.setData({
                        trigonometricTypeIndex: 0,
                        trigonometricTypeValue: t
                    });
                }
            }
        };
        t.default = s;
    },
    f0c5: function(e, t, n) {
        "use strict";
        function r(e, t, n, r, i, o, a, c, s, u) {
            var l, p = "function" == typeof e ? e.options : e;
            if (s) {
                p.components || (p.components = {});
                var f = Object.prototype.hasOwnProperty;
                for (var h in s) f.call(s, h) && !f.call(p.components, h) && (p.components[h] = s[h]);
            }
            if (u && ("function" == typeof u.beforeCreate && (u.beforeCreate = [ u.beforeCreate ]), 
            (u.beforeCreate || (u.beforeCreate = [])).unshift(function() {
                this[u.__module] = this;
            }), (p.mixins || (p.mixins = [])).push(u)), t && (p.render = t, p.staticRenderFns = n, 
            p._compiled = !0), r && (p.functional = !0), o && (p._scopeId = "data-v-" + o), 
            a ? (l = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), 
                i && i.call(this, e), e && e._registeredComponents && e._registeredComponents.add(a);
            }, p._ssrRegister = l) : i && (l = c ? function() {
                i.call(this, this.$root.$options.shadowRoot);
            } : i), l) if (p.functional) {
                p._injectStyles = l;
                var d = p.render;
                p.render = function(e, t) {
                    return l.call(t), d(e, t);
                };
            } else {
                var g = p.beforeCreate;
                p.beforeCreate = g ? [].concat(g, l) : [ l ];
            }
            return {
                exports: e,
                options: p
            };
        }
        n.d(t, "a", function() {
            return r;
        });
    },
    f73d: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("d055"), i = n("00cd"), o = n("0db1"), a = n("1c29"), c = {
            data: function() {
                return {
                    currentUnits: [ r.CurrentUnits.mA, r.CurrentUnits.A, r.CurrentUnits.kA ],
                    currentUnitIndex: 1,
                    currentUnitValue: void 0,
                    currentType: [ {
                        option: r.CurrentType.DIRECT_CURRENT,
                        label: "直流电流"
                    }, {
                        option: r.CurrentType.SINGLE_PHASE_CURRENT,
                        label: "单相交流"
                    }, {
                        option: r.CurrentType.TWO_PHASE_CURRENT,
                        label: "两相交流"
                    }, {
                        option: r.CurrentType.THREE_PHASE_CURRENT,
                        label: "三相交流"
                    } ],
                    currentTypeIndex: 1,
                    voltageUnits: [ o.VoltageUnits.mV, o.VoltageUnits.V, o.VoltageUnits.kV ],
                    voltageUnitIndex: 1,
                    voltageUnitValue: void 0,
                    voltageDropOptions: [ "%", "V" ],
                    voltageDropOptionIndex: 0,
                    voltageDropValue: 4,
                    resistanceUnits: [ a.OhmUnits.m, a.OhmUnits.O, a.OhmUnits.k, a.OhmUnits.M ],
                    resistanceUnitIndex: 1,
                    resistanceUnitValue: void 0,
                    impedanceUnits: [ a.OhmUnits.m, a.OhmUnits.O, a.OhmUnits.k, a.OhmUnits.M ],
                    impedanceUnitIndex: 1,
                    impedanceUnitValue: void 0
                };
            },
            methods: {
                setCurrentType: function(e) {
                    switch (e) {
                      case "AC":
                        this.currentType = [ {
                            option: r.CurrentType.DIRECT_CURRENT,
                            label: "直流电流"
                        } ];
                        break;

                      case "DC":
                        this.currentType = [ {
                            option: r.CurrentType.SINGLE_PHASE_CURRENT,
                            label: "单相交流"
                        }, {
                            option: r.CurrentType.TWO_PHASE_CURRENT,
                            label: "两相交流"
                        }, {
                            option: r.CurrentType.THREE_PHASE_CURRENT,
                            label: "三相交流"
                        } ];
                        break;

                      case "general":
                        this.currentType = [ {
                            option: r.CurrentType.DIRECT_CURRENT,
                            label: "直流电流"
                        }, {
                            option: r.CurrentType.SINGLE_PHASE_CURRENT,
                            label: "单相交流"
                        }, {
                            option: r.CurrentType.THREE_PHASE_CURRENT,
                            label: "三相交流"
                        } ];
                        break;

                      default:
                        this.currentType = [ {
                            option: r.CurrentType.DIRECT_CURRENT,
                            label: "直流电流"
                        }, {
                            option: r.CurrentType.SINGLE_PHASE_CURRENT,
                            label: "单相交流"
                        }, {
                            option: r.CurrentType.TWO_PHASE_CURRENT,
                            label: "两相交流"
                        }, {
                            option: r.CurrentType.THREE_PHASE_CURRENT,
                            label: "三相交流"
                        } ];
                    }
                    this.currentTypeIndex = 0;
                },
                getCurrentType: function() {
                    return this.currentType[this.currentTypeIndex].option;
                },
                getCurrentUnitValue: function() {
                    return (0, i.unitConvert)(this.currentUnitValue, this.currentUnits[this.currentUnitIndex], r.CurrentUnits.A);
                },
                getVoltageUnitValue: function() {
                    return (0, i.unitConvert)(this.voltageUnitValue, this.voltageUnits[this.voltageUnitIndex], o.VoltageUnits.V);
                },
                getResistanceUnitValue: function() {
                    return (0, i.unitConvert)(this.resistanceUnitValue, this.resistanceUnits[this.resistanceUnitIndex], a.OhmUnits.O);
                },
                getImpedanceUnitValue: function() {
                    return (0, i.unitConvert)(this.impedanceUnitValue, this.impedanceUnits[this.impedanceUnitIndex], a.OhmUnits.O);
                },
                getVoltageDropValue: function() {
                    var e = this.voltageDropValue;
                    return "%" === this.voltageDropOptions[this.voltageDropOptionIndex] && (e = e * this.voltageUnitValue / 100), 
                    e;
                },
                getVoltageDropRateValue: function() {
                    var e = this.voltageDropValue;
                    return "%" !== this.voltageDropOptions[this.voltageDropOptionIndex] && (e = e / this.getVoltageUnitValue() * 100, 
                    e = parseFloat(e.toFixed(2))), e;
                }
            }
        };
        t.default = c;
    },
    f772: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            range: {
                b: {
                    t: {
                        min: 0,
                        max: 1820
                    },
                    v: {
                        min: .291,
                        max: 13.82
                    }
                },
                e: {
                    t: {
                        min: -270,
                        max: 1e3
                    },
                    v: {
                        min: -8.825,
                        max: 76.373
                    }
                },
                j: {
                    t: {
                        min: -210,
                        max: 1200
                    },
                    v: {
                        min: -8.095,
                        max: 69.553
                    }
                },
                k: {
                    t: {
                        min: -270,
                        max: 1372
                    },
                    v: {
                        min: -5.891,
                        max: 54.886
                    }
                },
                n: {
                    t: {
                        min: -270,
                        max: 1300
                    },
                    v: {
                        min: -3.99,
                        max: 47.513
                    }
                },
                r: {
                    t: {
                        min: -50,
                        max: 1768.1
                    },
                    v: {
                        min: -.226,
                        max: 21.103
                    }
                },
                s: {
                    t: {
                        min: -50,
                        max: 1768.1
                    },
                    v: {
                        min: -.235,
                        max: 18.693
                    }
                },
                t: {
                    t: {
                        min: -270,
                        max: 400
                    },
                    v: {
                        min: -5.603,
                        max: 20.872
                    }
                }
            },
            supported_types: [ "b", "e", "j", "k", "n", "r", "s", "t" ],
            converter: {
                to_type_b: function(e) {
                    var t;
                    if (e >= 0 && e <= 630.615) t = [ 0, -.00024650818346, 59040421171e-16, -1.3257931636e-9, 1.5668291901e-12, -1.694452924e-15, 6.2990347094e-19 ]; else {
                        if (!(e > 630.615 && e <= 1820)) throw new RangeError("Temperature specified is out of range for Type B thermocouple");
                        t = [ -3.8938168621, .02857174747, -84885104785e-15, 1.5785280164e-7, -1.6835344864e-10, 1.1109794013e-13, -4.4515431033e-17, 9.8975640821e-21, -9.3791330289e-25 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_b: function(e) {
                    var t;
                    if (e >= .291 && e <= 2.431) t = [ 98.423321, 699.715, -847.65304, 1005.2644, -833.45952, 455.08542, -155.23037, 29.88675, -2.474286 ]; else {
                        if (!(e > 2.431 && e <= 13.82)) throw new RangeError("Voltage specified is out of range for Type B thermocouple");
                        t = [ 213.15071, 285.10504, -52.742887, 9.9160804, -1.2965303, .1119587, -.0060625199, .00018661696, -24878585e-13 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_e: function(e) {
                    var t;
                    if (e >= -270 && e <= 0) t = [ 0, .058665508708, 45410977124e-15, -7.7998048686e-7, -2.5800160843e-8, -5.9452583057e-10, -9.3214058667e-12, -1.0287605534e-13, -8.0370123621e-16, -4.3979497391e-18, -1.6414776355e-20, -3.9673619516e-23, -5.5827328721e-26, -3.4657842013e-29 ]; else {
                        if (!(e > 0 && e <= 1e3)) throw new RangeError("Temperature specified is out of range for Type E thermocouple");
                        t = [ 0, .05866550871, 45032275582e-15, 2.8908407212e-8, -3.3056896652e-10, 6.502440327e-13, -1.9197495504e-16, -1.2536600497e-18, 2.1489217569e-21, -1.4388041782e-24, 3.5960899481e-28 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_e: function(e) {
                    var t;
                    if (e >= -8.825 && e <= 0) t = [ 0, 16.977288, -.4351497, -.15859697, -.092502871, -.026084314, -.0041360199, -.0003403403, -1156489e-11, 0 ]; else {
                        if (!(e > 0 && e <= 76.373)) throw new RangeError("Voltage specified is out of range for Type E thermocouple");
                        t = [ 0, 17.057035, -.23301759, .0065435585, -73562749e-12, -17896001e-13, 8.4036165e-8, -1.3735879e-9, 1.0629823e-11, -3.2447087e-14 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_j: function(e) {
                    var t;
                    if (e >= -210 && e <= 760) t = [ 0, .050381187815, 3047583693e-14, -8.568106572e-8, 1.3228195295e-10, -1.7052958337e-13, 2.0948090697e-16, -1.2538395336e-19, 1.5631725697e-23 ]; else {
                        if (!(e > 760 && e <= 1200)) throw new RangeError("Temperature specified is out of range for Type J thermocouple");
                        t = [ 296.45625681, -1.4976127786, .0031787103924, -31847686701e-16, 1.5720819004e-9, -3.0691369056e-13 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_j: function(e) {
                    var t;
                    if (e >= -8.095 && e <= 0) t = [ 0, 19.528268, -1.2286185, -1.0752178, -.59086933, -.17256713, -.028131513, -.002396337, -83823321e-12 ]; else if (e > 0 && e <= 42.914) t = [ 0, 19.78425, -.2001204, .01036969, -.0002549687, 3585153e-12, -5.344285e-8, 5.09989e-10, 0 ]; else {
                        if (!(e > 42.914 && e <= 69.553)) throw new RangeError("Voltage specified is out of range for Type J thermocouple");
                        t = [ -3113.58187, 300.543684, -9.9477323, .17027663, -.00143033468, 473886084e-14, 0, 0, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_k: function(e) {
                    var t;
                    if (e >= -270 && e <= 0) t = [ 0, .039450128025, 23622373598e-15, -3.2858906784e-7, -4.9904828777e-9, -6.7509059173e-11, -5.7410327428e-13, -3.1088872894e-15, -1.0451609365e-17, -1.9889266878e-20, -1.6322697486e-23 ]; else {
                        if (!(e > 0 && e <= 1372)) throw new RangeError("Temperature specified is out of range for Type K thermocouple");
                        t = [ -.017600413686, .038921204975, 18558770032e-15, -9.9457592874e-8, 3.1840945719e-10, -5.6072844889e-13, 5.6075059059e-16, -3.2020720003e-19, 9.7151147152e-23, -1.2104721275e-26 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return e > 0 && (n += .1185976 * Math.exp(-.0001183432 * Math.pow(e - 126.9686, 2))), 
                    n;
                },
                from_type_k: function(e) {
                    var t;
                    if (e >= -5.891 && e <= 0) t = [ 0, 25.173462, -1.1662878, -1.0833638, -.8977354, -.37342377, -.086632643, -.010450598, -.00051920577, 0 ]; else if (e > 0 && e <= 20.644) t = [ 0, 25.08355, .07860106, -.2503131, .0831527, -.01228034, .0009804036, -441303e-10, 1057734e-12, -1.052755e-8 ]; else {
                        if (!(e > 20.644 && e <= 54.886)) throw new RangeError("Voltage specified is out of range for Type K thermocouple");
                        t = [ -131.8058, 48.30222, -1.646031, .05464731, -.0009650715, 8802193e-12, -3.11081e-8, 0, 0, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_n: function(e) {
                    var t;
                    if (e >= -270 && e <= 0) t = [ 0, .026159105962, 10957484228e-15, -9.3841111554e-8, -4.6412039759e-11, -2.6303357716e-12, -2.2653438003e-14, -7.6089300791e-17, -9.3419667835e-20 ]; else {
                        if (!(e > 0 && e <= 1300)) throw new RangeError("Temperature specified is out of range for Type N thermocouple");
                        t = [ 0, .025929394601, 1571014188e-14, 4.3825627237e-8, -2.5261169794e-10, 6.4311819339e-13, -1.0063471519e-15, 9.9745338992e-19, -6.0863245607e-22, 2.0849229339e-25, -3.0682196151e-29 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_n: function(e) {
                    var t;
                    if (e >= -3.99 && e <= 0) t = [ 0, 38.436847, 1.1010485, 5.2229312, 7.2060525, 5.8488586, 2.7754916, .77075166, .11582665, .0073138868 ]; else if (e > 0 && e <= 20.613) t = [ 0, 38.6896, -1.08267, .0470205, -212169e-11, -117272e-9, 53928e-10, -7.98156e-8, 0, 0 ]; else {
                        if (!(e > 20.613 && e <= 47.513)) throw new RangeError("Voltage specified is out of range for Type N thermocouple");
                        t = [ 19.72485, 33.00943, -.3915159, .009855391, -.0001274371, 7.767022e-7, 0, 0, 0, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_r: function(e) {
                    var t;
                    if (e >= -50 && e <= 1064.18) t = [ 0, .00528961729765, 139166589782e-16, -2.38855693017e-8, 3.56916001063e-11, -4.62347666298e-14, 5.00777441034e-17, -3.73105886191e-20, 1.57716482367e-23, -2.81038625251e-27 ]; else if (e > 1064.18 && e <= 1664.5) t = [ 2.95157925316, -.00252061251332, 159564501865e-16, -7.64085947576e-9, 2.05305291024e-12, -2.93359668173e-16 ]; else {
                        if (!(e > 1664.5 && e <= 1768.1)) throw new RangeError("Temperature specified is out of range for Type R thermocouple");
                        t = [ 152.232118209, -.268819888545, .000171280280471, -3.45895706453e-8, -9.34633971046e-15 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_r: function(e) {
                    var t;
                    if (e >= -.226 && e <= 1.923) t = [ 0, 188.9138, -93.83529, 130.68619, -227.0358, 351.45659, -389.539, 282.39471, -126.07281, 31.353611, -3.3187769 ]; else if (e > 1.923 && e <= 11.361) t = [ 13.34584505, 147.2644573, -18.44024844, 4.031129726, -.624942836, .06468412046, -.004458750426, .0001994710149, -531340179e-14, 6.481976217e-8, 0 ]; else if (e > 11.361 && e <= 19.739) t = [ -81.99599416, 155.3962042, -8.342197663, .4279433549, -.0119157791, .0001492290091, 0, 0, 0, 0, 0 ]; else {
                        if (!(e > 19.739 && e <= 21.103)) throw new RangeError("Voltage specified is out of range for Type R thermocouple");
                        t = [ 34061.77836, -7023.729171, 558.2903813, -19.52394635, .2560740231, 0, 0, 0, 0, 0, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_s: function(e) {
                    var t;
                    if (e >= -50 && e <= 1064.18) t = [ 0, .00540313308631, 12593428974e-15, -2.32477968689e-8, 3.22028823036e-11, -3.31465196389e-14, 2.55744251786e-17, -1.25068871393e-20, 2.71443176145e-24 ]; else if (e > 1064.18 && e <= 1664.5) t = [ 1.32900444085, .00334509311344, 654805192818e-17, -1.64856259209e-9, 1.29989605174e-14 ]; else {
                        if (!(e > 1664.5 && e <= 1768.1)) throw new RangeError("Temperature specified is out of range for Type S thermocouple");
                        t = [ 146.628232636, -.258430516752, .000163693574641, -3.30439046987e-8, -9.43223690612e-15 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_s: function(e) {
                    var t;
                    if (e >= -.235 && e <= 1.874) t = [ 0, 184.94946, -80.0504062, 102.23743, -152.248592, 188.821343, -159.085941, 82.302788, -23.4181944, 2.7978626 ]; else if (e > 1.874 && e <= 10.332) t = [ 12.91507177, 146.6298863, -15.34713402, 3.145945973, -.4163257839, .03187963771, -.0012916375, 2183475087e-14, -1.447379511e-7, 8.211272125e-9 ]; else if (e > 10.332 && e <= 17.536) t = [ -80.87801117, 162.1573104, -8.536869453, .4719686976, -.01441693666, .000208161889, 0, 0, 0, 0 ]; else {
                        if (!(e > 17.536 && e <= 18.693)) throw new RangeError("Voltage specified is out of range for Type S thermocouple");
                        t = [ 53338.75126, -12358.92298, 1092.657613, -42.65693686, .624720542, 0, 0, 0, 0, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                to_type_t: function(e) {
                    var t;
                    if (e >= -270 && e <= 0) t = [ 0, .038748106364, 44194434347e-15, 1.1844323105e-7, 2.0032973554e-8, 9.0138019559e-10, 2.2651156593e-11, 3.6071154205e-13, 3.8493939883e-15, 2.8213521925e-17, 1.4251594779e-19, 4.8768662286e-22, 1.079553927e-24, 1.3945027062e-27, 7.9795153927e-31 ]; else {
                        if (!(e > 0 && e <= 400)) throw new RangeError("Temperature specified is out of range for Type T thermocouple");
                        t = [ 0, .038748106364, 3329222788e-14, 2.0618243404e-7, -2.1882256846e-9, 1.0996880928e-11, -3.0815758772e-14, 4.547913529e-17, -2.7512901673e-20 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                },
                from_type_t: function(e) {
                    var t;
                    if (e >= -5.603 && e <= 0) t = [ 0, 25.949192, -.21316967, .79018692, .42527777, .13304473, .020241446, .0012668171 ]; else {
                        if (!(e > 0 && e <= 20.872)) throw new RangeError("Voltage specified is out of range for Type T thermocouple");
                        t = [ 0, 25.928, -.7602961, .04637791, -.002165394, 6048144e-11, -7.293422e-7, 0 ];
                    }
                    for (var n = 0, r = 0; r < t.length; r++) n += t[r] * Math.pow(e, r);
                    return n;
                }
            },
            convert: function(e, t) {
                if (e = parseFloat(e), isNaN(e)) throw new TypeError("Input is not a number");
                var n, r = function(e) {
                    e = e || {};
                    for (var t = 1; t < arguments.length; t++) if (arguments[t]) for (var n in arguments[t]) arguments[t].hasOwnProperty(n) && (e[n] = arguments[t][n]);
                    return e;
                }({
                    type: "k",
                    input: "mv"
                }, t);
                if (!this.supported_types.includes(r.type)) throw new RangeError("Invalid thermocouple type");
                if ("mv" == r.input) n = "from_type_" + r.type; else {
                    if ("degc" != r.input) throw new RangeError("Only 'mv' or 'degc' is permitted as property 'input'");
                    n = "to_type_" + r.type;
                }
                return this.converter[n](e);
            }
        };
        t.default = r;
    },
    fad4: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ReactivePowerUnits = t.InputTerminal = t.HPUnitValue = t.ApparentPowerUnits = t.ActivePowerUnits = void 0, 
        t.toPowerType = function(e) {
            var t = e;
            return [ i.W.name, i.kW.name, i.MW.name, "HP" ].includes(e) ? t = "P" : [ o.VA.name, o.kVA.name, o.MVA.name ].includes(e) ? t = "S" : [ a.VAr.name, a.kVAr.name, a.MVAr.name ].includes(e) && (t = "Q"), 
            t;
        };
        var r = n("00cd");
        t.HPUnitValue = 745.6998715822702;
        var i = {
            W: new r.Unit("W"),
            kW: new r.Unit("kW", 1e3),
            MW: new r.Unit("MW", 1e3, 2)
        };
        t.ActivePowerUnits = i;
        var o = {
            VA: new r.Unit("VA"),
            kVA: new r.Unit("kVA", 1e3),
            MVA: new r.Unit("MVA", 1e3, 2)
        };
        t.ApparentPowerUnits = o;
        var a = {
            VAr: new r.Unit("VAr"),
            kVAr: new r.Unit("kVAr", 1e3),
            MVAr: new r.Unit("MVAr", 1e3, 2)
        };
        t.ReactivePowerUnits = a, t.InputTerminal = {
            VOLTAGE_CURRENT: "voltage_current",
            VOLTAGE_IMPEDANCE: "voltage_impedance",
            VOLTAGE_RESISTANCE: "voltage_resistance",
            CURRENT_IMPEDANCE: "current_impedance",
            CURRENT_RESISTANCE: "current_resistance",
            RESISTANCE_IMPEDANCE: "resistance_impedance",
            ACTIVE_POWER: "active_power",
            APPARENT_POWER: "apparent_power",
            REACTIVE_POWER: "reactive_power",
            APPARENT_REACTIVE: "apparent_reactive",
            ACTIVE_REACTIVE: "active_reactive",
            ACTIVE_APPARENT: "active_apparent",
            VOLTAGE_CURRENT_ACTIVE_POWER: "voltage_current_active_power",
            VOLTAGE_CURRENT_REACTIVE_POWER: "voltage_current_reactive_power",
            VOLTAGE_ACTIVE_POWER_IMPEDANCE: "voltage_active_power_impedance",
            CURRENT_ACTIVE_POWER_IMPEDANCE: "current_active_power_impedance"
        };
    },
    fd69: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("9bc7"), i = n("e615"), o = n("d417"), a = {
            data: function() {
                return {
                    electricalSpecifications: r.ElectricalSpecifications,
                    currentElectricalSpecification: r.ElectricalSpecifications.IEC,
                    pipeCircuits: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 16, 20 ],
                    pipeCircuitIndex: 0,
                    layingModeOptions: [],
                    layingModeOptionIndex: 0,
                    layingMode: null,
                    insulationOptions: [ {
                        option: r.InsulationType.PVC,
                        label: "PVC（聚氯乙烯）"
                    }, {
                        option: r.InsulationType.XLPE_EPR,
                        label: "XLPE（交联聚乙烯）/EPR（乙丙橡胶）"
                    } ],
                    insulationOptionIndex: 0,
                    singleCircuitCores: r.InsulatedConductorConfig.IEC.conductorsOfCircuit,
                    singleCircuitCoreIndex: 0,
                    cableCoreAreaOptions: [],
                    cableCoreAreaOptionIndex: 0,
                    cableCoreAreaConfig: [],
                    temperatureAmbientOptions: [],
                    temperatureAmbientOptionIndex: 0,
                    temperatureAmbientConfig: [],
                    soilThermalResistivityOptions: [],
                    soilThermalResistivityOptionIndex: 5,
                    maximumOperatingTemperatureOptions: [],
                    maximumOperatingTemperatureOptionIndex: 0,
                    style: "",
                    totalConductorOptions: r.InsulatedConductorConfig.NEC.totalConductors,
                    totalConductorOptionIndex: 0
                };
            },
            methods: {
                onDisplayLayingMode: function() {
                    this.$refs.layingMode.onDisplay();
                },
                setLayingMode: function() {
                    var e = this.$refs.layingMode;
                    this.currentElectricalSpecification === r.ElectricalSpecifications.IEC ? e.initLayingMode(this.currentElectricalSpecification) : this.setData({
                        layingModeOptions: i.LayingModeConfig[e.getMaterial()].NEC,
                        layingModeOptionIndex: 0
                    });
                },
                getLayingMode: function() {
                    var e = this.layingMode;
                    return this.currentElectricalSpecification === r.ElectricalSpecifications.NEC && (e = this.layingModeOptions[this.layingModeOptionIndex]), 
                    e;
                },
                handleTemperatureAmbient: function() {
                    var e = [], t = 4, n = [], a = this.temperatureAmbientOptions[this.temperatureAmbientOptionIndex];
                    if (this.currentElectricalSpecification === r.ElectricalSpecifications.IEC) {
                        var c = this.insulationOptions[this.insulationOptionIndex].option, s = (n = (0, 
                        i.getTemperatureAmbientConfig)(this.layingMode, c)).length;
                        e = r.InsulatedConductorConfig.IEC.temperatureAmbient.slice(0, s), t = (0, o.keepCurrentIndexOfOptions)(a, e, t);
                    } else {
                        var u = this.layingModeOptions[this.layingModeOptionIndex];
                        e = r.InsulatedConductorConfig.NEC.temperatureAmbient, u.identifier === i.NECIdentifier.COMMUNICATION_DEVICES && (t = 6);
                    }
                    this.setData({
                        temperatureAmbientOptions: e,
                        temperatureAmbientOptionIndex: t,
                        temperatureAmbientConfig: n
                    });
                },
                handleSoilThermalResistivity: function() {
                    var e = [], t = 5;
                    if (this.layingMode.isHighTemperature) {
                        var n = r.InsulatedConductorConfig.IEC.soilThermalResistivity, i = this.soilThermalResistivityOptions[this.soilThermalResistivityOptionIndex];
                        n.forEach(function(t) {
                            e.push({
                                option: t,
                                label: "".concat(t, " K·m/W")
                            });
                        }), t = (0, o.keepCurrentIndexOfOptions)(i, e, 5, "label");
                    }
                    this.setData({
                        soilThermalResistivityOptions: e,
                        soilThermalResistivityOptionIndex: t
                    });
                },
                handleCableCoreAre: function() {
                    var e = [], t = 0, n = [], a = this.cableCoreAreaOptions[this.cableCoreAreaOptionIndex];
                    if (this.currentElectricalSpecification === r.ElectricalSpecifications.IEC) {
                        var c = (n = (0, i.getCableCoreAreConfig)(this.layingMode, this.insulationOptions[this.insulationOptionIndex].option, this.singleCircuitCores[this.singleCircuitCoreIndex])).length;
                        r.InsulatedConductorConfig.IEC.cableCoreArea.slice(0, c).forEach(function(t) {
                            e.push({
                                option: t,
                                label: "".concat(t, " mm²")
                            });
                        }), t = (0, o.keepCurrentIndexOfOptions)(a, e, 0, "label");
                    } else {
                        var s = this.layingModeOptions[this.layingModeOptionIndex].identifier;
                        e = r.InsulatedConductorConfig.NEC.cableCoreArea[s], t = (0, o.keepCurrentIndexOfOptions)(a, e, 0);
                    }
                    this.setData({
                        cableCoreAreaOptions: e,
                        cableCoreAreaOptionIndex: t,
                        cableCoreAreaConfig: n
                    });
                },
                handleMaximumOperatingTemperature: function() {
                    var e = this.maximumOperatingTemperatureOptions[this.maximumOperatingTemperatureOptionIndex], t = this.layingModeOptions[this.layingModeOptionIndex].identifier, n = r.InsulatedConductorConfig.NEC.maximumOperatingTemperature[t], i = (0, 
                    o.keepCurrentIndexOfOptions)(e, n, 0);
                    this.setData({
                        maximumOperatingTemperatureOptions: n,
                        maximumOperatingTemperatureOptionIndex: i
                    });
                },
                handleStyle: function() {
                    var e = this.materialOptions[this.materialOptionIndex].label, t = this.layingModeOptions[this.layingModeOptionIndex].identifier, n = this.maximumOperatingTemperatureOptionIndex;
                    this.setData({
                        style: r.InsulatedConductorConfig.NEC.style[e][t][n]
                    });
                }
            }
        };
        t.default = a;
    },
    fdd9: function(e, t, n) {
        (function(t) {
            var r = n("7659");
            function i() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                    var t = 16 * Math.random() | 0;
                    return ("x" == e ? t : 3 & t | 8).toString(16);
                });
            }
            function o(e) {
                return void 0 === t[e] || t[e].toString().indexOf("is not yet implemented") > -1;
            }
            var a = !1;
            e.exports = {
                init: function() {
                    a || (a = !0, console.log("Api polyfill start"), o("login") && (t.login = function(e) {
                        console.warn("api: uni.login 登录 在当前平台不支持，【关键流程函数】 回调成功"), e.success && e.success({
                            code: i(),
                            errMsg: "login:ok"
                        });
                    }), o("checkSession") && (t.checkSession = function(e) {
                        console.warn("api: uni.checkSession 检查登录状态是否过期 在当前平台不支持，【关键流程函数】 回调成功"), e.success && e.success();
                    }), o("getUserInfo") && (t.getUserInfo = function(e) {
                        console.warn("api: uni.getUserInfo 获取用户信息 在当前平台不支持，【关键流程函数】回调成功"), e.success && e.success({
                            userInfo: ""
                        });
                    }), o("getUserProfile") && (t.getUserProfile = function(e) {
                        console.warn("api: uni.getUserProfile 获取用户授权信息 在当前平台不支持，【关键流程函数】回调成功"), e.success && e.success({
                            userInfo: ""
                        });
                    }), o("base64ToArrayBuffer") && (t.base64ToArrayBuffer = function(e) {
                        return r.base64ToArrayBuffer(e);
                    }), o("arrayBufferToBase64") && (t.arrayBufferToBase64 = function(e) {
                        return r.arrayBufferToBase64(e);
                    }), o("canIUse") && (t.canIUse = function(e) {
                        return console.warn("api: uni.canIUse 判断API在当前平台是否可用 返回true"), !0;
                    }), o("startDeviceMotionListening") && (t.startDeviceMotionListening = function(e) {
                        console.warn("api: uni.startDeviceMotionListening 开始监听设备方向的变化 在当前平台不支持"), e.success && e.success();
                    }), o("onMemoryWarning") && (t.onMemoryWarning = function(e) {
                        console.warn("监听内存不足告警事件，仅支持微信小程序、支付宝小程序、百度小程序、QQ小程序，当前平台不支持，已注释");
                    }), o("offNetworkStatusChange") && (t.offNetworkStatusChange = function(e) {}), 
                    o("offAccelerometerChange") && (t.offAccelerometerChange = function(e) {}), o("startAccelerometer") && (t.startAccelerometer = function(e) {
                        console.warn("api: uni.startAccelerometer 开始监听加速度数据 在当前平台不支持");
                    }), o("offCompassChange") && (t.offCompassChange = function(e) {
                        console.warn("api: uni.offCompassChange 取消监听罗盘数据 在当前平台不支持");
                    }), o("startCompass") && (t.startCompass = function(e) {
                        console.warn("api: uni.startCompass 开始监听罗盘数据 在当前平台不支持");
                    }), o("onGyroscopeChange") && (t.onGyroscopeChange = function(e) {
                        console.warn("api: uni.onGyroscopeChange 监听陀螺仪数据变化事件 在当前平台不支持");
                    }), o("startGyroscope") && (t.startGyroscope = function(e) {
                        console.warn("api: uni.startGyroscope 监听陀螺仪数据变化事件 在当前平台不支持");
                    }), o("stopGyroscope") && (t.stopGyroscope = function(e) {
                        console.warn("api: uni.stopGyroscope 停止监听陀螺仪数据 在当前平台不支持");
                    }), o("scanCode") && (t.scanCode = function(e) {
                        console.warn("api: uni.scanCode 扫描二维码 在当前平台不支持");
                    }), o("setClipboardData") && (t.setClipboardData = function(e) {
                        console.warn("api: uni.setClipboardData 设置系统剪贴板的内容 在当前平台不支持");
                    }), o("getClipboardData") && (t.getClipboardData = function(e) {
                        console.warn("api: uni.getClipboardData 获取系统剪贴板内容 在当前平台不支持");
                    }), o("setScreenBrightness") && (t.setScreenBrightness = function(e) {
                        console.warn("api: uni.setScreenBrightness 设置屏幕亮度 在当前平台不支持");
                    }), o("getScreenBrightness") && (t.getScreenBrightness = function(e) {
                        console.warn("api: uni.getScreenBrightness 获取屏幕亮度 在当前平台不支持");
                    }), o("setKeepScreenOn") && (t.setKeepScreenOn = function(e) {
                        console.warn("api: uni.setKeepScreenOn 设置是否保持常亮状态 在当前平台不支持");
                    }), o("onUserCaptureScreen") && (t.onUserCaptureScreen = function(e) {
                        console.warn("api: uni.onUserCaptureScreen 监听用户主动截屏事件 在当前平台不支持");
                    }), o("addPhoneContact") && (t.addPhoneContact = function(e) {
                        console.warn("api: uni.addPhoneContact 添加联系人 在当前平台不支持");
                    }), o("saveImageToPhotosAlbum") && (t.saveImageToPhotosAlbum = function(e) {
                        console.warn("api: uni.saveImageToPhotosAlbum 保存图片到系统相册 在当前平台不支持，回调失败"), e.fail && e.fail();
                    }), o("compressImage") && (t.compressImage = function(e) {
                        console.warn("api: uni.compressImage 压缩图片接口 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("chooseMessageFile") && (t.chooseMessageFile = function(e) {
                        console.warn("api: uni.chooseMessageFile 从微信聊天会话中选择文件。 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("getRecorderManager") && (t.getRecorderManager = function(e) {
                        console.warn("api: uni.getRecorderManager 获取全局唯一的录音管理器 在当前平台不支持");
                    }), o("getBackgroundAudioManager") && (t.getBackgroundAudioManager = function(e) {
                        console.warn("api: uni.getBackgroundAudioManager 获取全局唯一的背景音频管理器 在当前平台不支持");
                    }), o("chooseMedia") && (t.chooseMedia = function(e) {
                        console.warn("api: uni.chooseMedia 拍摄或从手机相册中选择图片或视频 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("saveVideoToPhotosAlbum") && (t.saveVideoToPhotosAlbum = function(e) {
                        console.warn("api: uni.saveVideoToPhotosAlbum 保存视频到系统相册 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("getVideoInfo") && (t.getVideoInfo = function(e) {
                        console.warn("api: uni.getVideoInfo 获取视频详细信息 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("compressVideo") && (t.compressVideo = function(e) {
                        console.warn("api: uni.compressVideo 压缩视频接口 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("openVideoEditor") && (t.openVideoEditor = function(e) {
                        console.warn("api: uni.openVideoEditor 打开视频编辑器 在当前平台不支持，回调失败"), options.fail && options.fail();
                    }), o("openBluetoothAdapter") && (t.openBluetoothAdapter = function(e) {
                        console.warn("api: uni.openBluetoothAdapter 初始化蓝牙模块 在当前平台不支持");
                    }), o("startBluetoothDevicesDiscovery") && (t.startBluetoothDevicesDiscovery = function(e) {
                        console.warn("api: uni.startBluetoothDevicesDiscovery 开始搜寻附近的蓝牙外围设备 在当前平台不支持");
                    }), o("onBluetoothDeviceFound") && (t.onBluetoothDeviceFound = function(e) {
                        console.warn("api: uni.onBluetoothDeviceFound 监听寻找到新设备的事件 在当前平台不支持");
                    }), o("stopBluetoothDevicesDiscovery") && (t.stopBluetoothDevicesDiscovery = function(e) {
                        console.warn("api: uni.stopBluetoothDevicesDiscovery 停止搜寻附近的蓝牙外围设备 在当前平台不支持");
                    }), o("onBluetoothAdapterStateChange") && (t.onBluetoothAdapterStateChange = function(e) {
                        console.warn("api: uni.onBluetoothAdapterStateChange 监听蓝牙适配器状态变化事件 在当前平台不支持");
                    }), o("getConnectedBluetoothDevices") && (t.getConnectedBluetoothDevices = function(e) {
                        console.warn("api: uni.getConnectedBluetoothDevices 根据 uuid 获取处于已连接状态的设备 在当前平台不支持");
                    }), o("getBluetoothDevices") && (t.getBluetoothDevices = function(e) {
                        console.warn("api: uni.getBluetoothDevices 获取在蓝牙模块生效期间所有已发现的蓝牙设备 在当前平台不支持");
                    }), o("getBluetoothAdapterState") && (t.getBluetoothAdapterState = function(e) {
                        console.warn("api: uni.getBluetoothAdapterState 获取本机蓝牙适配器状态 在当前平台不支持");
                    }), o("closeBluetoothAdapter") && (t.closeBluetoothAdapter = function(e) {
                        console.warn("api: uni.closeBluetoothAdapter 关闭蓝牙模块 在当前平台不支持");
                    }), o("setBLEMTU") && (t.setBLEMTU = function(e) {
                        console.warn("api: uni.setBLEMTU 设置蓝牙最大传输单元 在当前平台不支持");
                    }), o("readBLECharacteristicValue") && (t.readBLECharacteristicValue = function(e) {
                        console.warn("api: uni.readBLECharacteristicValue 读取低功耗蓝牙设备的特征值的二进制数据值 在当前平台不支持");
                    }), o("onBLEConnectionStateChange") && (t.onBLEConnectionStateChange = function(e) {
                        console.warn("api: uni.onBLEConnectionStateChange 监听低功耗蓝牙连接状态的改变事件 在当前平台不支持");
                    }), o("notifyBLECharacteristicValueChange") && (t.notifyBLECharacteristicValueChange = function(e) {
                        console.warn("api: uni.notifyBLECharacteristicValueChange 启用低功耗蓝牙设备特征值变化时的 notify 功能 在当前平台不支持");
                    }), o("getBLEDeviceServices") && (t.getBLEDeviceServices = function(e) {
                        console.warn("api: uni.getBLEDeviceServices 获取蓝牙设备所有服务 在当前平台不支持");
                    }), o("getBLEDeviceRSSI") && (t.getBLEDeviceRSSI = function(e) {
                        console.warn("api: uni.getBLEDeviceRSSI 获取蓝牙设备的信号强度 在当前平台不支持");
                    }), o("createBLEConnection") && (t.createBLEConnection = function(e) {
                        console.warn("api: uni.createBLEConnection 连接低功耗蓝牙设备 在当前平台不支持");
                    }), o("closeBLEConnection") && (t.closeBLEConnection = function(e) {
                        console.warn("api: uni.closeBLEConnection 断开与低功耗蓝牙设备的连接 在当前平台不支持");
                    }), o("onBeaconServiceChange") && (t.onBeaconServiceChange = function(e) {
                        console.warn("api: uni.onBeaconServiceChange 监听 iBeacon 服务状态变化事件 在当前平台不支持");
                    }), o("onBeaconUpdate") && (t.onBeaconUpdate = function(e) {
                        console.warn("api: uni.onBeaconUpdate 监听 iBeacon 设备更新事件 在当前平台不支持");
                    }), o("getBeacons") && (t.getBeacons = function(e) {
                        console.warn("api: uni.getBeacons 获取所有已搜索到的 iBeacon 设备 在当前平台不支持");
                    }), o("startBeaconDiscovery") && (t.startBeaconDiscovery = function(e) {
                        console.warn("api: uni.startBeaconDiscovery 开始搜索附近的 iBeacon 设备 在当前平台不支持");
                    }), o("stopBeaconDiscovery") && (t.stopBeaconDiscovery = function(e) {
                        console.warn("api: uni.stopBeaconDiscovery 停止搜索附近的 iBeacon 设备 在当前平台不支持");
                    }), o("startWifi") && (t.startWifi = function(e) {
                        console.warn("api: uni.startWifi 初始化 Wi-Fi 模块 在当前平台不支持"), e.success && e.success();
                    }), o("getConnectedWifi") && (t.getConnectedWifi = function(e) {
                        console.warn("api: uni.getConnectedWifi 初获取设备当前所连的 WiFi 信息 在当前平台不支持"), e.success && e.success();
                    }), o("getBatteryInfo") && (t.getBatteryInfo = function(e) {
                        console.warn("api: uni.getBatteryInfo 获取设备电量 在当前平台不支持"), e.success && e.success();
                    }), o("getBatteryInfoSync") && (t.getBatteryInfoSync = function(e) {
                        console.warn("api: uni.getBatteryInfoSync 同步获取设备电量 在当前平台不支持");
                    }), o("startHCE") && (t.startHCE = function(e) {
                        console.warn("api: uni.startHCE 初始化 NFC 模块 在当前平台不支持"), e.success && e.success();
                    }), o("startSoterAuthentication") && (t.startSoterAuthentication = function(e) {
                        console.warn("api: uni.startSoterAuthentication 开始 SOTER 生物认证 在当前平台不支持"), e.success && e.success();
                    }), o("checkIsSupportSoterAuthentication") && (t.checkIsSupportSoterAuthentication = function(e) {
                        console.warn("api: uni.checkIsSupportSoterAuthentication 开获取本机支持的 SOTER 生物认证方式 在当前平台不支持"), 
                        e.success && e.success();
                    }), o("checkIsSoterEnrolledInDevice") && (t.checkIsSoterEnrolledInDevice = function(e) {
                        console.warn("api: uni.checkIsSoterEnrolledInDevice 获取设备内是否录入如指纹等生物信息的接口 在当前平台不支持"), 
                        e.success && e.success();
                    }), o("hideNavigationBarLoading") && (t.hideNavigationBarLoading = function(e) {
                        console.warn("api: uni.hideNavigationBarLoading 在当前页面隐藏导航条加载动画 在当前平台不支持，回调成功"), 
                        e.success && e.success();
                    }), o("hideHomeButton") && (t.hideHomeButton = function(e) {
                        console.warn("api: uni.hideHomeButton 隐藏返回首页按钮 在当前平台不支持，回调成功"), e.success && e.success();
                    }), o("setTabBarItem") && (t.setTabBarItem = function(e) {
                        console.warn("api: uni.setTabBarItem 动态设置 tabBar 某一项的内容 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("setTabBarStyle") && (t.setTabBarStyle = function(e) {
                        console.warn("api: uni.setTabBarStyle 动态设置 tabBar 的整体样式 在当前平台不支持，回调成功"), e.success && e.success();
                    }), o("hideTabBar") && (t.hideTabBar = function(e) {
                        console.warn("api: uni.hideTabBar 隐藏 tabBar 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("showTabBar") && (t.showTabBar = function(e) {
                        console.warn("api: uni.showTabBar 显示 tabBar 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("setTabBarBadge") && (t.setTabBarBadge = function(e) {
                        console.warn("api: uni.setTabBarBadge 为 tabBar 某一项的右上角添加文本 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("removeTabBarBadge") && (t.removeTabBarBadge = function(e) {
                        console.warn("api: uni.removeTabBarBadge 移除 tabBar 某一项右上角的文本 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("showTabBarRedDot") && (t.showTabBarRedDot = function(e) {
                        console.warn("api: uni.showTabBarRedDot 显示 tabBar 某一项的右上角的红点 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("hideTabBarRedDot") && (t.hideTabBarRedDot = function(e) {
                        console.warn("api: uni.hideTabBarRedDot 隐藏 tabBar 某一项的右上角的红点 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("setBackgroundColor") && (t.setBackgroundColor = function(e) {
                        console.warn("api: uni.setBackgroundColor 动态设置窗口的背景色 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("setBackgroundTextStyle") && (t.setBackgroundTextStyle = function(e) {
                        console.warn("api: uni.setBackgroundTextStyle 动态设置下拉背景字体、loading 图的样式 在当前平台不支持，执行失败"), 
                        e.fail && e.fail();
                    }), o("onWindowResize") && (t.onWindowResize = function(e) {
                        console.warn("api: uni.onWindowResize 监听窗口尺寸变化事件 在当前平台不支持，执行失败"), e && e();
                    }), o("offWindowResize") && (t.offWindowResize = function(e) {
                        console.warn("api: uni.offWindowResize 取消监听窗口尺寸变化事件 在当前平台不支持，执行失败"), e && e();
                    }), o("loadFontFace") && (t.loadFontFace = function(e) {
                        console.warn("api: uni.loadFontFace 动态加载网络字体 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getMenuButtonBoundingClientRect") && (t.getMenuButtonBoundingClientRect = function() {
                        console.warn("api: uni.getMenuButtonBoundingClientRect 微信胶囊按钮布局信息 在当前平台不支持，执行失败");
                    }), o("saveFile") && (t.saveFile = function(e) {
                        console.warn("api: uni.saveFile 保存文件到本地 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getSavedFileList") && (t.getSavedFileList = function(e) {
                        console.warn("api: uni.getSavedFileList 获取本地已保存的文件列表 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getSavedFileInfo") && (t.getSavedFileInfo = function(e) {
                        console.warn("api: uni.getSavedFileInfo 获取本地文件的文件信息 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("removeSavedFile") && (t.removeSavedFile = function(e) {
                        console.warn("api: uni.removeSavedFile 删除本地存储的文件 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getFileInfo") && (t.getFileInfo = function(e) {
                        console.warn("api: uni.getFileInfo 获取文件信息 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("openDocument") && (t.openDocument = function(e) {
                        console.warn("api: uni.openDocument 新开页面打开文档 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getFileSystemManager") && (t.getFileSystemManager = function() {
                        console.warn("api: uni.getFileSystemManager 获取全局唯一的文件管理器 在当前平台不支持，执行失败");
                    }), o("createOffscreenCanvas") && (t.createOffscreenCanvas = function() {
                        console.warn("api: uni.createOffscreenCanvas 创建离屏 canvas 实例 在当前平台不支持，执行失败");
                    }), o("canvasToTempFilePath") && (t.canvasToTempFilePath = function() {
                        console.warn("api: uni.canvasToTempFilePath 把当前画布指定区域的内容导出生成指定大小的图片 在当前平台不支持，执行失败");
                    }), o("createRewardedVideoAd") && (t.createRewardedVideoAd = function() {
                        return console.warn("api: uni.createRewardedVideoAd 激励视频广告 在当前平台不支持，执行失败"), {
                            show: function() {},
                            onLoad: function() {},
                            offLoad: function() {},
                            load: function() {},
                            onError: function() {},
                            offError: function() {},
                            onClose: function() {},
                            offClose: function() {}
                        };
                    }), o("createInterstitialAd") && (t.createInterstitialAd = function() {
                        console.warn("api: uni.createInterstitialAd 插屏广告组件 在当前平台不支持，执行失败");
                    }), o("getProvider") && (t.getProvider = function(e) {
                        console.warn("api: uni.getProvider 获取服务供应商 在当前平台不支持，执行失败"), e && e.fail && e.fail();
                    }), o("showShareMenu") && (t.showShareMenu = function(e) {
                        console.warn("api: uni.showShareMenu 小程序的原生菜单中显示分享按钮 在当前平台不支持，执行失败"), e && e.fail && e.fail();
                    }), o("hideShareMenu") && (t.hideShareMenu = function(e) {
                        console.warn("api: uni.hideShareMenu 小程序的原生菜单中隐藏分享按钮 在当前平台不支持，执行失败"), e && e.fail && e.fail();
                    }), o("requestPayment") && (t.requestPayment = function(e) {
                        console.error("api: uni.requestPayment 支付 在当前平台不支持(需自行参考文档封装)，执行失败"), e && e.fail && e.fail();
                    }), o("createWorker") && (t.createWorker = function() {
                        console.error("api: uni.createWorker 创建一个 Worker 线程 在当前平台不支持，执行失败");
                    }), o("authorize") && (t.authorize = function(e) {
                        console.warn("api: uni.authorize 提前向用户发起授权请求 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("openSetting") && (t.openSetting = function(e) {
                        console.warn("api: uni.openSetting 调起客户端小程序设置界面 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getSetting") && (t.getSetting = function(e) {
                        console.warn("api: uni.getSetting 获取用户的当前设置 在当前平台不支持，【关键流程函数】回调成功"), e.success && e.success({
                            authSetting: {
                                scope: {
                                    userInfo: !1
                                }
                            }
                        });
                    }), o("chooseAddress") && (t.chooseAddress = function(e) {
                        console.warn("api: uni.chooseAddress 获取用户收货地址 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("chooseInvoiceTitle") && (t.chooseInvoiceTitle = function(e) {
                        console.warn("api: uni.chooseInvoiceTitle 选择用户的发票抬头 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("navigateToMiniProgram") && (t.navigateToMiniProgram = function(e) {
                        console.warn("api: uni.navigateToMiniProgram 打开另一个小程序 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("navigateBackMiniProgram") && (t.navigateBackMiniProgram = function(e) {
                        console.warn("api: uni.navigateBackMiniProgram 跳转回上一个小程序 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getAccountInfoSync") && (t.getAccountInfoSync = function(e) {
                        console.warn("api: uni.getAccountInfoSync 获取当前帐号信息 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("requestSubscribeMessage") && (t.requestSubscribeMessage = function(e) {
                        console.warn("api: uni.requestSubscribeMessage 订阅消息 在当前平台不支持，执行失败"), e.fail && e.fail();
                    }), o("getUpdateManager") && (t.getUpdateManager = function(e) {
                        console.error("api: uni.getUpdateManager 管理小程序更新 在当前平台不支持，执行失败");
                    }), o("setEnableDebug") && (t.setEnableDebug = function(e) {
                        console.error("api: uni.setEnableDebug 设置是否打开调试开关 在当前平台不支持，执行失败");
                    }), o("getExtConfig") && (t.getExtConfig = function(e) {
                        console.error("api: uni.getExtConfig 获取第三方平台自定义的数据字段 在当前平台不支持，执行失败");
                    }), o("getExtConfigSync") && (t.getExtConfigSync = function(e) {
                        console.error("api: uni.getExtConfigSync uni.getExtConfig 的同步版本 在当前平台不支持，执行失败");
                    }), function() {
                        var e = function(e, n) {
                            if (e.errMsg.indexOf("tabbar page") > -1) {
                                console.error("res.errMsg: " + e.errMsg);
                                var r = e.errMsg.match(/not\s(\w+)\sa/)[1];
                                console.log(r);
                                var i = n.url;
                                if (i) {
                                    var o = i.split("?")[1];
                                    o && console.error(r + " 的参数将被忽略：" + o), t.switchTab({
                                        url: i
                                    });
                                }
                            }
                        }, n = function(t) {
                            return function(n) {
                                try {
                                    n.fail ? n.fail = function(t) {
                                        return function(r) {
                                            e(r, n), t(r);
                                        };
                                    }(n.fail) : n.fail = function(t) {
                                        e(t, n);
                                    }, t.call(t, n);
                                } catch (e) {
                                    console.error("uni.navigateTo or uni.redirectTo error", e);
                                }
                            };
                        };
                        t.navigateTo = n(t.navigateTo), t.redirectTo = n(t.redirectTo);
                    }());
                },
                guid: i
            };
        }).call(this, n("543d").default);
    }
} ]);