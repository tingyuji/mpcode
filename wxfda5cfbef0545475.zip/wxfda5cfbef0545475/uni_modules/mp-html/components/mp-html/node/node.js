(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/mp-html/components/mp-html/node/node" ], {
    "34a5": function(t, o, e) {
        "use strict";
        var n = e("bc58");
        e.n(n).a;
    },
    "3c1f": function(t, o, e) {
        "use strict";
        e.d(o, "b", function() {
            return n;
        }), e.d(o, "c", function() {
            return i;
        }), e.d(o, "a", function() {});
        var n = function() {
            var t = this, o = (t.$createElement, t._self._c, t.__map(t.childs, function(o, e) {
                return {
                    $orig: t.__get_orig(o),
                    a0: "img" === o.name && o.t ? "<img class='_img' style='" + o.attrs.style + "' src='" + o.attrs.src + "'>" : null
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: o
                }
            });
        }, i = [];
    },
    4155: function(t, o, e) {
        "use strict";
        o.a = function(t) {
            t.options.wxsCallMethods || (t.options.wxsCallMethods = []);
        };
    },
    a618: function(t, o, e) {
        "use strict";
        e.r(o);
        var n = e("3c1f"), i = e("b75b");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(o, t, function() {
                return i[t];
            });
        }(r);
        e("34a5");
        var s = e("f0c5"), a = e("4155"), c = Object(s.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        "function" == typeof a.a && Object(a.a)(c), o.default = c.exports;
    },
    b75b: function(t, o, e) {
        "use strict";
        e.r(o);
        var n = e("cb1f"), i = e.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            e.d(o, t, function() {
                return n[t];
            });
        }(r);
        o.default = i.a;
    },
    bc58: function(t, o, e) {},
    cb1f: function(t, o, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var n = {
                name: "node",
                options: {
                    virtualHost: !0
                },
                data: function() {
                    return {
                        ctrl: {},
                        isiOS: t.getSystemInfoSync().system.includes("iOS")
                    };
                },
                props: {
                    name: String,
                    attrs: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    childs: Array,
                    opts: Array
                },
                components: {
                    node: function() {
                        Promise.resolve().then(function() {
                            return resolve(e("a618"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                mounted: function() {
                    var t = this;
                    this.$nextTick(function() {
                        for (t.root = t.$parent; "mp-html" !== t.root.$options.name; t.root = t.root.$parent) ;
                    });
                },
                beforeDestroy: function() {},
                methods: {
                    toJSON: function() {
                        return this;
                    },
                    play: function(o) {
                        if (this.root.$emit("play"), this.root.pauseVideo) {
                            for (var e = !1, n = o.target.id, i = this.root._videos.length; i--; ) this.root._videos[i].id === n ? e = !0 : this.root._videos[i].pause();
                            if (!e) {
                                var r = t.createVideoContext(n, this);
                                r.id = n, this.root.playbackRate && r.playbackRate(this.root.playbackRate), this.root._videos.push(r);
                            }
                        }
                    },
                    imgTap: function(o) {
                        var e = this.childs[o.currentTarget.dataset.i];
                        e.a ? this.linkTap(e.a) : e.attrs.ignore || (this.root.$emit("imgtap", e.attrs), 
                        this.root.previewImg && t.previewImage({
                            showmenu: this.root.showImgMenu,
                            current: parseInt(e.attrs.i),
                            urls: this.root.imgList
                        }));
                    },
                    imgLongTap: function(t) {},
                    imgLoad: function(t) {
                        var o = t.currentTarget.dataset.i;
                        this.childs[o].w ? (this.opts[1] && !this.ctrl[o] || -1 === this.ctrl[o]) && this.$set(this.ctrl, o, 1) : this.$set(this.ctrl, o, t.detail.width), 
                        this.checkReady();
                    },
                    checkReady: function() {
                        var t = this;
                        this.root.lazyLoad || (this.root._unloadimgs -= 1, this.root._unloadimgs || setTimeout(function() {
                            t.root.getRect().then(function(o) {
                                t.root.$emit("ready", o);
                            });
                        }, 350));
                    },
                    linkTap: function(o) {
                        var e = o.currentTarget ? this.childs[o.currentTarget.dataset.i] : {}, n = e.attrs || o, i = n.href;
                        this.root.$emit("linktap", Object.assign({
                            innerText: this.root.getText(e.children || [])
                        }, n)), i && ("#" === i[0] ? this.root.navigateTo(i.substring(1)).catch(function() {}) : i.split("?")[0].includes("://") ? this.root.copyLink && t.setClipboardData({
                            data: i,
                            success: function() {
                                return t.showToast({
                                    title: "链接已复制"
                                });
                            }
                        }) : t.navigateTo({
                            url: i,
                            fail: function() {
                                t.switchTab({
                                    url: i,
                                    fail: function() {}
                                });
                            }
                        }));
                    },
                    mediaError: function(t) {
                        var o = t.currentTarget.dataset.i, e = this.childs[o];
                        if ("video" === e.name || "audio" === e.name) {
                            var n = (this.ctrl[o] || 0) + 1;
                            if (n > e.src.length && (n = 0), n < e.src.length) return void this.$set(this.ctrl, o, n);
                        } else "img" === e.name && (this.opts[2] && this.$set(this.ctrl, o, -1), this.checkReady());
                        this.root && this.root.$emit("error", {
                            source: e.name,
                            attrs: e.attrs,
                            errMsg: t.detail.errMsg
                        });
                    }
                }
            };
            o.default = n;
        }).call(this, e("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/mp-html/components/mp-html/node/node-create-component", {
    "uni_modules/mp-html/components/mp-html/node/node-create-component": function(t, o, e) {
        e("543d").createComponent(e("a618"));
    }
}, [ [ "uni_modules/mp-html/components/mp-html/node/node-create-component" ] ] ]);