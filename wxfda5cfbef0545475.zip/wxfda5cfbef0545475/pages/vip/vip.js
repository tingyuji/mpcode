(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/vip/vip" ], {
    "0e90": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = a(n("2eee")), i = a(n("c973")), s = n("963d"), c = n("963d"), r = a(n("b253")), u = a(n("ac2e")), l = n("a195"), d = getApp(), f = {
                data: function() {
                    return {
                        behaviors: [ u.default ],
                        selectedPack: 0,
                        packages: [],
                        BaseUrl: s.BaseUrl,
                        platformId: s.platformId,
                        user: {
                            avatar_url: "",
                            nickname: "",
                            vip_state: 0,
                            vip_expiration: ""
                        },
                        price: "",
                        title: "iap",
                        loading: !1,
                        disabled: !0,
                        productId: "",
                        productList: [],
                        iosOrder: [],
                        pull: "",
                        platform: t.getSystemInfoSync().platform,
                        safeAreaInsetsBottom: "",
                        isIosWechat: !1
                    };
                },
                onLoad: function() {
                    "ios" == t.getSystemInfoSync().platform && (this.isIosWechat = !0);
                },
                onShow: function() {
                    var e = this;
                    t.getProvider({
                        service: "payment",
                        success: function(t) {
                            console.log(t.provider);
                        }
                    }), t.showLoading({
                        title: "加载中",
                        mask: !0
                    }), "4" == this.platformId && this.iosPay(), this.iosOrder = [], r.default.get("vip").then(function(t) {
                        e.setData({
                            packages: t.data
                        }), console.log(e.packages), "4" == e.platformId && (e.packages.forEach(function(t) {
                            e.iosOrder.push(t.ios_id);
                        }), console.log(e.iosOrder));
                    }, function(e) {
                        t.showModal({
                            title: "加载服务套餐失败",
                            content: e.message
                        });
                    }).finally(function() {
                        t.hideLoading();
                    }), d.globalData.getUser().then(function(t) {
                        return e.setData({
                            user: t
                        });
                    }, function() {});
                },
                methods: {
                    selectPackage: function(t) {
                        this.setData({
                            selectedPack: t.currentTarget.dataset.idx
                        });
                    },
                    openTermServices: function() {
                        (0, l.openWebView)(c.termsServiceUrl, "会员服务条款");
                    },
                    pay: function() {
                        var e = this;
                        t.showLoading({
                            title: "支付中",
                            mask: !0
                        }), t.getSystemInfoSync().platform, this.getOpenid().then(function(t) {
                            e.mpPlay();
                        }).catch(function(t) {
                            e.setOpenid().then(function() {
                                e.mpPlay();
                            });
                        });
                    },
                    getOpenid: function() {
                        return new Promise(function(t, e) {
                            r.default.get("login/openid").then(function() {
                                t();
                            }).catch(function() {
                                e();
                            });
                        });
                    },
                    setOpenid: function() {
                        return new Promise(function(e, n) {
                            t.login({
                                success: function(t) {
                                    r.default.post("login/openid", {
                                        code: t.code
                                    }).then(function(t) {
                                        console.log(t), e(t.data.openId);
                                    });
                                },
                                fail: function(e) {
                                    t.hideLoading(), t.showModal({
                                        title: "错误",
                                        content: e.message,
                                        showCancel: !1
                                    });
                                }
                            });
                        });
                    },
                    mpPlay: function() {
                        var e = this, n = this.packages[this.selectedPack];
                        r.default.post("order", {
                            vip_type: n.vip_type
                        }).then(function(t) {
                            return r.default.post("payment", {
                                order_no: t.data.order_no
                            });
                        }).then(function(a) {
                            t.showLoading({
                                title: "支付中",
                                mask: !0
                            }), a.data.payment.getOrderStatus = e.getOrderStatus(), t.requestPayment(Object.assign(a.data.payment, {
                                success: function(o) {
                                    if ("2" == e.platformId && 4 == o.code) return t.hideLoading(), e.failedModal("您已取消支付"), 
                                    void setTimeout(e.pull, 1500);
                                    e.pull = function() {
                                        r.default.get("payment/" + a.data.id).then(function(a) {
                                            1 == a.data.status ? (d.globalData.trigger("vip-updated", n), e.successPayment(), 
                                            t.showModal({
                                                title: "支付成功",
                                                content: "恭喜，您已成功成为电工大师" + n.title + "!",
                                                showCancel: !1,
                                                confirmText: "返回",
                                                success: function() {
                                                    t.navigateBack();
                                                }
                                            })) : setTimeout(e.pull, 1500);
                                        }, function(e) {
                                            t.showModal({
                                                title: "查询订单状态异常",
                                                content: e.message,
                                                showCancel: !1
                                            });
                                        }).finally(function() {
                                            t.hideLoading();
                                        });
                                    }, console.log(o), t.showLoading({
                                        title: "等待支付结果",
                                        mask: !0
                                    }), e.pull();
                                },
                                fail: function(n) {
                                    console.log(n), t.hideLoading();
                                    var a = n.errMsg.substring(20).trim();
                                    "cancel" == a && (a = "您已取消支付。"), e.failedModal(a);
                                }
                            }));
                        }).catch(function(n) {
                            t.hideLoading(), e.failedModal(n.message);
                        });
                    },
                    getOrderStatus: function() {},
                    successPayment: function() {
                        t.$emit("user-payment-vip");
                    },
                    appPlay: function() {
                        var e = this, n = this.packages[this.selectedPack];
                        r.default.post("order", {
                            vip_type: n.vip_type
                        }).then(function(t) {
                            return r.default.post("payment", {
                                order_no: t.data.order_no
                            });
                        }).then(function(a) {
                            t.showLoading({
                                title: "支付中",
                                mask: !0
                            }), console.log(a.data.payment), t.requestPayment({
                                provider: "wxpay",
                                orderInfo: a.data.payment,
                                success: function() {
                                    t.showLoading({
                                        title: "等待支付结果",
                                        mask: !0
                                    }), function o() {
                                        r.default.get("payment/" + a.data.id).then(function(a) {
                                            1 == a.data.status ? (d.globalData.trigger("vip-updated", n), e.successPayment(), 
                                            t.showModal({
                                                title: "支付成功",
                                                content: "恭喜，您已成功成为电工大师" + n.title + "!",
                                                showCancel: !1,
                                                confirmText: "返回",
                                                success: function() {
                                                    t.navigateBack();
                                                }
                                            })) : setTimeout(o, 1500);
                                        }, function(e) {
                                            t.showModal({
                                                title: "查询订单状态异常",
                                                content: e.message,
                                                showCancel: !1
                                            });
                                        }).finally(function() {
                                            t.hideLoading();
                                        });
                                    }();
                                },
                                fail: function(n) {
                                    console.error(n), t.hideLoading(), e.failedModal("您已取消支付。");
                                }
                            });
                        }).catch(function(n) {
                            t.hideLoading(), e.failedModal(n.message);
                        });
                    },
                    failedModal: function(e) {
                        var n = this;
                        t.showModal({
                            title: "支付失败",
                            content: e,
                            cancelText: "取消",
                            confirmText: "重新支付",
                            success: function(t) {
                                t.confirm && n.pay();
                            }
                        });
                    },
                    iosPay: function() {
                        var e = this;
                        return (0, i.default)(o.default.mark(function n() {
                            var a, i;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return console.log("ios 订单支付关闭"), n.next = 3, new Promise(function(e, n) {
                                        t.getProvider({
                                            service: "payment",
                                            success: function(t) {
                                                return e(t.providers.find(function(t) {
                                                    return "appleiap" == t.id;
                                                }));
                                            },
                                            fail: function(t) {
                                                return n(t);
                                            }
                                        });
                                    });

                                  case 3:
                                    return a = n.sent, console.log(a), n.next = 7, new Promise(function(t, e) {
                                        a.restoreComplateRequest({
                                            manualFinishTransaction: !0
                                        }, function(e) {
                                            t(e);
                                        }, function(t) {
                                            console.log(t), e(t);
                                        });
                                    });

                                  case 7:
                                    i = n.sent, console.log("ios 恢复支付"), console.log(i);
                                    try {
                                        i.forEach(function(t) {
                                            t.transactionIdentifier && t.transactionReceipt && e.iosPayRequest(t, a, !1);
                                        });
                                    } catch (t) {
                                        console.error(t);
                                    }

                                  case 11:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    iosPayment: function() {
                        var e = this;
                        return (0, i.default)(o.default.mark(function n() {
                            var a, i, s;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.prev = 0, n.next = 3, new Promise(function(e, n) {
                                        t.getProvider({
                                            service: "payment",
                                            success: function(t) {
                                                return e(t.providers.find(function(t) {
                                                    return "appleiap" == t.id;
                                                }));
                                            },
                                            fail: function(t) {
                                                return n(t);
                                            }
                                        });
                                    });

                                  case 3:
                                    return a = n.sent, n.next = 6, new Promise(function(t, n) {
                                        a.requestProduct(e.iosOrder, function(e) {
                                            return t(e);
                                        }, n);
                                    });

                                  case 6:
                                    return i = n.sent, console.log(i), n.next = 10, new Promise(function(n, a) {
                                        t.requestPayment({
                                            provider: "appleiap",
                                            orderInfo: {
                                                productid: e.packages[e.selectedPack].ios_id,
                                                manualFinishTransaction: !0
                                            },
                                            success: n,
                                            fail: a
                                        });
                                    });

                                  case 10:
                                    s = n.sent, e.iosPayRequest(s, a, !0), n.next = 19;
                                    break;

                                  case 14:
                                    n.prev = 14, n.t0 = n.catch(0), console.error(n.t0), t.hideLoading(), t.showModal({
                                        title: "取消支付",
                                        content: n.t0.message,
                                        showCancel: !1
                                    });

                                  case 19:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 0, 14 ] ]);
                        }))();
                    },
                    iosPayRequest: function(e, n) {
                        var a = this, o = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        if (e.payment && e.transactionIdentifier) {
                            var i = this.packages[this.selectedPack];
                            console.log(e), r.default.post("payment/iosPay", {
                                transactionReceipt: e.transactionReceipt,
                                transactionIdentifier: e.transactionIdentifier
                            }).then(function(s) {
                                d.globalData.trigger("vip-updated", i), a.successPayment(), t.hideLoading(), a.finishTransaction(n, e), 
                                o && t.showModal({
                                    title: "支付成功",
                                    content: "恭喜，您已成功成为电工大师" + i.title + "!",
                                    showCancel: !1,
                                    confirmText: "返回",
                                    success: function() {
                                        t.navigateBack();
                                    }
                                });
                            }, function(i) {
                                console.log(i), t.hideLoading(), o && a.failedModal(i.message), a.finishTransaction(n, e);
                            });
                        }
                    },
                    finishTransaction: function(t, e) {
                        return new Promise(function(n, a) {
                            t.finishTransaction(e, function(t) {
                                console.log("关闭订单成功"), n(t);
                            }, function(t) {
                                e(t), console.log("关闭订单失败");
                            });
                        });
                    }
                }
            };
            e.default = f;
        }).call(this, n("543d").default);
    },
    "94d4": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            var t = (this._self._c, this.isIosWechat || 4 == this.platformId ? null : this.packages.length), e = this.isIosWechat || 4 != this.platformId ? null : this.packages.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: e
                }
            });
        }, o = [];
    },
    aae8: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("0e90"), o = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = o.a;
    },
    b8c7: function(t, e, n) {
        "use strict";
        var a = n("f9ef");
        n.n(a).a;
    },
    e81a: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("94d4"), o = n("aae8");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n("b8c7");
        var s = n("f0c5"), c = Object(s.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    },
    f74a: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var o = a(n("e81a"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    f9ef: function(t, e, n) {}
}, [ [ "f74a", "common/runtime", "common/vendor" ] ] ]);