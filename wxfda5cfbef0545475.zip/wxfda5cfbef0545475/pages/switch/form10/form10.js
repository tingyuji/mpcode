(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form10/form10" ], {
    "8b95": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a73f"), a = t("8e86");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        var u = t("f0c5"), o = Object(u.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        n.default = o.exports;
    },
    "8e86": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a981"), a = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = a.a;
    },
    a73f: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    a981: function(e, n, t) {
        "use strict";
        var r = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = r(t("035c")), i = t("e308"), u = t("e954"), o = t("00cd"), c = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    uidx: 0,
                    units: [ u.enegryUnits.J, u.enegryUnits.kJ, u.enegryUnits.MJ, u.enegryUnits.Wh, u.enegryUnits.kWh, u.enegryUnits.MWh, u.enegryUnits.BTU, u.enegryUnits.cal, u.enegryUnits.Kcal, u.enegryUnits.Mcal ],
                    value: "",
                    result: ""
                };
            },
            mixins: [ a.default ],
            onLoad: function() {
                this.initFeature("enegry_convert", i.FeatureType.Converter);
            },
            methods: {
                calculate: function() {
                    var e = this;
                    if (!this.checkNaN(this.value)) {
                        var n = [];
                        this.units.forEach(function(t, r) {
                            if (r != e.uidx) {
                                var a = (0, o.unitConvert)(e.value, e.units[e.uidx], t), i = (0, o.formatLength)(a, 10);
                                n.push(i + " " + t.name);
                            }
                        }), this.setData({
                            result: n.join("\n")
                        }), this.use();
                    }
                }
            }
        };
        n.default = c;
    },
    fb43: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t("4ea4");
            t("8a42"), r(t("66fd"));
            var a = r(t("8b95"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    }
}, [ [ "fb43", "common/runtime", "common/vendor" ] ] ]);