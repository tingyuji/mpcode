(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/length/length" ], {
    "09b9": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("17ea"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = i.a;
    },
    "17ea": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n("035c")), r = a(n("6d71c")), u = n("e308"), o = n("9912"), s = n("00cd"), c = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        list: [],
                        label: {
                            km: "千米",
                            m: "米",
                            cm: "公分",
                            mm: "毫米",
                            ft: "英尺",
                            in: "英寸",
                            mil: "千分之一英寸",
                            yd: "码",
                            mi: "英里",
                            nmi: "海里"
                        }
                    };
                },
                mixins: [ i.default, r.default ],
                onLoad: function() {
                    this.initFeature("length_convert", u.FeatureType.Converter);
                },
                methods: {
                    calculate: function() {
                        var t = this;
                        if (this.checkNaN(this.measuringUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var n = this.getMeasuringUnitValue(), a = this.measuringUnits[this.measuringUnitIndex].name, i = [];
                            Object.keys(o.MeasuringUnits).map(function(e) {
                                for (var r = (0, s.formatDouble)((0, s.unitConvert)(n, o.MeasuringUnits.m, o.MeasuringUnits[e]), 8), u = [ 7, 6, 5, 4, 3, 2, 1 ], c = 0; c < u.length; c++) if (new RegExp(".0{" + u[c] + ",}").test(r)) {
                                    r = (0, s.formatDouble)(parseFloat(r), u[c] + 1);
                                    break;
                                }
                                e !== a && i.push({
                                    name: o.MeasuringUnits[e].name,
                                    label: t.label[e],
                                    value: r + " " + o.MeasuringUnits[e].name
                                });
                            }), this.list = i, this.use();
                        } catch (t) {
                            this.list = [], e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    "3d1e": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("8de9"), i = n("09b9");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("478b");
        var u = n("f0c5"), o = Object(u.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = o.exports;
    },
    "46d7": function(e, t, n) {},
    "478b": function(e, t, n) {
        "use strict";
        var a = n("46d7");
        n.n(a).a;
    },
    "8de9": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement;
            var e = (this._self._c, this.list.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, r = [];
    },
    "9fee": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("3d1e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "9fee", "common/runtime", "common/vendor" ] ] ]);