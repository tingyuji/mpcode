(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form1/form1" ], {
    7301: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("efea"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = i.a;
    },
    a640: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("ae19"), i = n("7301");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("b1ec");
        var u = n("f0c5"), c = Object(u.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    aaa9: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("a640"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    ae19: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    b1ec: function(e, t, n) {
        "use strict";
        var a = n("cce7");
        n.n(a).a;
    },
    cce7: function(e, t, n) {},
    efea: function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = a(n("035c")), r = n("e308"), u = n("1c29"), c = n("00cd"), o = n("d417"), s = (getApp(), 
        {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    mode: 0,
                    units: [ u.OhmUnits.m, u.OhmUnits.O, u.OhmUnits.k, u.OhmUnits.M ],
                    aIndex: 1,
                    aValue: "",
                    aNames: [ "Rab", "Ra" ],
                    bIndex: 1,
                    bValue: "",
                    bNames: [ "Rbc", "Rb" ],
                    cIndex: 1,
                    cValue: "",
                    cNames: [ "Rac", "Rc" ],
                    result: ""
                };
            },
            mixins: [ i.default ],
            onLoad: function() {
                this.initFeature("delta_y", r.FeatureType.Converter);
            },
            methods: {
                switchMode: function(e) {
                    this.setData({
                        mode: parseInt(e.currentTarget.dataset.mode)
                    });
                },
                calculate: function() {
                    var e = this.aValue, t = this.bValue, n = this.cValue;
                    if (!this.checkNaN(e, t, n)) {
                        var a, i, r, s;
                        if (e = (0, c.unitConvert)(e, this.units[this.aIndex], u.OhmUnits.O), t = (0, c.unitConvert)(t, this.units[this.bIndex], u.OhmUnits.O), 
                        n = (0, c.unitConvert)(n, this.units[this.cIndex], u.OhmUnits.O), 0 == this.mode) {
                            var f = e + t + n;
                            a = e * n / f, i = e * t / f, r = t * n / f, s = 1;
                        } else {
                            var l = e * t + e * n + t * n;
                            a = l / n, i = l / e, r = l / t, s = 0;
                        }
                        a = this.aNames[s] + " = " + (0, u.ohmFormat)(a), i = this.bNames[s] + " = " + (0, 
                        u.ohmFormat)(i), r = this.cNames[s] + " = " + (0, u.ohmFormat)(r), this.setData({
                            result: a + "\n" + i + "\n" + r
                        }), this.use(), this.$nextTick(function() {
                            (0, o.calculatePageScroll)(1e3);
                        });
                    }
                }
            }
        });
        t.default = s;
    }
}, [ [ "aaa9", "common/runtime", "common/vendor" ] ] ]);