(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form5/form5" ], {
    "24bb": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("c4ad"), r = n("a967");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("e402");
        var i = n("f0c5"), o = Object(i.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = o.exports;
    },
    "6f3e": function(e, t, n) {},
    8901: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(n("035c")), c = n("7325"), i = n("e308"), o = n("00cd"), u = (getApp(), 
            {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        index: 0,
                        units: [ "mm²", "awg", "kcmil", "mm", "in" ],
                        value: "",
                        result: ""
                    };
                },
                mixins: [ r.default ],
                onLoad: function() {
                    this.initFeature("cross_sectional_convert", i.FeatureType.Converter);
                },
                methods: {
                    calculate: function() {
                        var t = this, n = this.value, a = this.index;
                        if (!this.checkNaN(n)) {
                            var r = new c.CrossSectionalConvert();
                            try {
                                switch (parseInt(a)) {
                                  case 0:
                                    r.setSquareMillimeter(n);
                                    break;

                                  case 1:
                                    r.setAwg(n);
                                    break;

                                  case 2:
                                    r.setKcmil(n);
                                    break;

                                  case 3:
                                    r.setMillimeter(n);
                                    break;

                                  case 4:
                                    r.setInch(n);
                                }
                                var i = r.calculate(), u = [ i.squareMillimeter, i.awg, i.kcmil, i.millimeter, i.inch ], s = [];
                                u.forEach(function(e, n) {
                                    n != a && (1 != n && (e = (0, o.formatDouble)(e, 4)), s.push(e + " " + t.units[n]));
                                }), this.setData({
                                    result: s.join("\n")
                                }), this.use();
                            } catch (t) {
                                console.error(t), e.showModal({
                                    title: "输入错误",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            });
            t.default = u;
        }).call(this, n("543d").default);
    },
    a25c: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var r = a(n("24bb"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    a967: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("8901"), r = n.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        t.default = r.a;
    },
    c4ad: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    e402: function(e, t, n) {
        "use strict";
        var a = n("6f3e");
        n.n(a).a;
    }
}, [ [ "a25c", "common/runtime", "common/vendor" ] ] ]);