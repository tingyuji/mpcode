(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form4/form4" ], {
    2527: function(e, n, t) {
        "use strict";
        var r = t("4c12");
        t.n(r).a;
    },
    "4c12": function(e, n, t) {},
    "52b2": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("6a74"), a = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = a.a;
    },
    "572f": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t("4ea4");
            t("8a42"), r(t("66fd"));
            var a = r(t("6c87"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "6a74": function(e, n, t) {
        "use strict";
        var r = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = r(t("278c")), o = r(t("035c")), u = t("7325"), i = t("e308"), c = [ [ "7/0", 126.6769 ], [ "6/0", 109.0921 ], [ "5/0", 94.5638 ], [ "4/0", 81.0732 ], [ "3/0", 70.1202 ], [ "2/0", 61.3643 ], [ "0", 53.1921 ], [ "1", 45.6037 ], [ "2", 38.5989 ], [ "3", 32.178 ], [ "4", 27.273 ], [ "5", 22.7735 ], [ "6", 18.6793 ], [ "7", 15.6958 ], [ "8", 12.9717 ], [ "9", 10.5071 ], [ "10", 8.3019 ], [ "11", 6.8183 ], [ "12", 5.4805 ], [ "13", 4.2888 ], [ "14", 3.2429 ], [ "15", 2.6268 ], [ "16", 2.0755 ], [ "17", 1.589 ], [ "18", 1.1675 ], [ "19", .8107 ], [ "20", .6567 ], [ "21", .5189 ], [ "22", .3973 ], [ "23", .2919 ], [ "24", .2452 ], [ "25", .2027 ], [ "26", .1642 ], [ "27", .1363 ], [ "28", .111 ], [ "29", .0937 ], [ "30", .0779 ], [ "31", .0682 ], [ "32", .0591 ], [ "33", .0507 ], [ "34", .0429 ], [ "35", .0358 ], [ "36", .0293 ], [ "37", .0234 ], [ "38", .0182 ], [ "39", .0137 ], [ "40", .0117 ], [ "41", .0098 ], [ "42", .0081 ], [ "43", .0066 ], [ "44", .0052 ], [ "45", .004 ], [ "46", .0029 ], [ "47", .002 ], [ "48", .0013 ], [ "49", 7e-4 ], [ "50", 5e-4 ] ], f = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    list: []
                };
            },
            mixins: [ o.default ],
            onLoad: function() {
                this.initFeature("swg", i.FeatureType.Converter);
                var e = [];
                c.forEach(function(n) {
                    var t = (0, a.default)(n, 2), r = t[0], o = t[1], i = (0, u.square2millimeter)(o), c = (0, 
                    u.millimeter2inch)(i);
                    e.push({
                        swg: r,
                        mm2: o.toFixed(4),
                        mm: i.toFixed(4),
                        inv: c.toFixed(4)
                    });
                }), this.setData({
                    list: e
                });
            },
            methods: {}
        };
        n.default = f;
    },
    "6c87": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a562"), a = t("52b2");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(o);
        t("2527");
        var u = t("f0c5"), i = Object(u.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        n.default = i.exports;
    },
    a562: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    }
}, [ [ "572f", "common/runtime", "common/vendor" ] ] ]);