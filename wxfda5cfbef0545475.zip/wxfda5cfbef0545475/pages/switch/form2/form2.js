(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form2/form2" ], {
    "0528": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {
            return u;
        });
        var u = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "2cfd": function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t("4e55"), r = t.n(u);
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(a);
        n.default = r.a;
    },
    "4e55": function(e, n, t) {
        "use strict";
        var u = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = u(t("035c")), a = t("e308"), i = t("00cd"), o = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    uidx: 0,
                    units: [ new i.Unit("W"), new i.Unit("kW", 1e3), new i.Unit("HP", 735), new i.Unit("BTU/h", .293), new i.Unit("kcal/h", 1.163) ],
                    value: "",
                    result: ""
                };
            },
            mixins: [ r.default ],
            onLoad: function() {
                this.initFeature("power_convert", a.FeatureType.Converter);
            },
            methods: {
                calculate: function() {
                    var e = this;
                    if (!this.checkNaN(this.value)) {
                        var n = [];
                        this.units.forEach(function(t, u) {
                            u != e.uidx && n.push((0, i.unitFormatTo)(e.value, e.units[e.uidx], t));
                        }), this.setData({
                            result: n.join("\n")
                        }), this.use();
                    }
                }
            }
        };
        n.default = o;
    },
    "50fc": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var u = t("4ea4");
            t("8a42"), u(t("66fd"));
            var r = u(t("ad17"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    ad17: function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t("0528"), r = t("2cfd");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(a);
        var i = t("f0c5"), o = Object(i.a)(r.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        n.default = o.exports;
    }
}, [ [ "50fc", "common/runtime", "common/vendor" ] ] ]);