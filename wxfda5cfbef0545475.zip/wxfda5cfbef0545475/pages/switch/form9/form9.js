(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form9/form9" ], {
    "5ab2": function(e, t, n) {},
    "67cd": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var c = a(n("aa79"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "9e07": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    aa79: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("9e07"), c = n("abeb");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(r);
        n("f6bb");
        var o = n("f0c5"), i = Object(o.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    },
    abeb: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("c5a2"), c = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = c.a;
    },
    c5a2: function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = a(n("035c")), r = n("e308"), o = n("00cd"), i = n("d417"), u = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    capacityUnitIndex: 0,
                    capacityUnitRanges: [ "Ah", "kWh" ],
                    capacity: "",
                    voltage: "",
                    dod: 100,
                    result: ""
                };
            },
            mixins: [ c.default ],
            onLoad: function() {
                this.initFeature("ah_kwh_convert", r.FeatureType.Converter);
            },
            methods: {
                calculate: function() {
                    var e = this.capacity, t = this.voltage, n = this.dod;
                    if (!this.checkNaN(e, t, n)) {
                        var a, c, r = this.capacityUnitRanges, u = this.capacityUnitIndex;
                        if (100 != n) {
                            var f = 100 - n;
                            e = e / 100 * n, a = "\n充电状态(SOC): " + (0, o.formatDouble)(f, 2) + "%\n可用容量: " + (0, 
                            o.formatDouble)(e, 2) + " " + r[u];
                        }
                        c = 0 == u ? e * t / 1e3 : 1e3 * e / t, c = parseFloat(c.toFixed(3)) + " " + r[0 == u ? 1 : 0], 
                        a = a ? c + a : c, this.setData({
                            result: a
                        }), this.use(), this.$nextTick(function() {
                            (0, i.calculatePageScroll)(1e3);
                        });
                    }
                }
            }
        };
        t.default = u;
    },
    f6bb: function(e, t, n) {
        "use strict";
        var a = n("5ab2");
        n.n(a).a;
    }
}, [ [ "67cd", "common/runtime", "common/vendor" ] ] ]);