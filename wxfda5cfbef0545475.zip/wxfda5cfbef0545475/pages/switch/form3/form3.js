(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form3/form3" ], {
    "08c6": function(e, n, t) {},
    "34c7": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t("4ea4");
            t("8a42"), r(t("66fd"));
            var a = r(t("ec33"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "69b9": function(e, n, t) {
        "use strict";
        var r = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        for (var a = r(t("035c")), o = t("7325"), i = t("e308"), u = [ "1000", "900", "800", "700", "600", "500", "450", "400", "350", "300", "250", "4/0", "3/0", "2/0" ], c = 0; c < 51; c++) u.push(c);
        var f = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    list: []
                };
            },
            mixins: [ a.default ],
            onLoad: function() {
                this.initFeature("awg", i.FeatureType.Converter);
                var e = [];
                u.forEach(function(n) {
                    var t = (0, o.awg2squareMillieter)(n), r = (0, o.square2millimeter)(t), a = (0, 
                    o.millimeter2inch)(r);
                    e.push({
                        awg: parseInt(n) > 212 ? n + " kcmil" : n,
                        mm2: t.toFixed(4),
                        mm: r.toFixed(4),
                        inch: a.toFixed(4)
                    });
                }), this.setData({
                    list: e
                });
            },
            methods: {}
        };
        n.default = f;
    },
    9030: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("69b9"), a = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = a.a;
    },
    ba14: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    dbd1: function(e, n, t) {
        "use strict";
        var r = t("08c6");
        t.n(r).a;
    },
    ec33: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("ba14"), a = t("9030");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(o);
        t("dbd1");
        var i = t("f0c5"), u = Object(i.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        n.default = u.exports;
    }
}, [ [ "34c7", "common/runtime", "common/vendor" ] ] ]);