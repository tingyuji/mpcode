(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form6/form6" ], {
    "02bd": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("3ea9"), a = n("78e3");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("e5a9");
        var o = n("f0c5"), u = Object(o.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = u.exports;
    },
    "051b": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("035c")), i = n("e308"), o = n("2e64"), u = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        index: 0,
                        units: [ "φ(DEG)", "φ(RAD)", "Sin φ", "Cos φ", "Tan φ" ],
                        value: "",
                        result: ""
                    };
                },
                mixins: [ a.default ],
                onLoad: function() {
                    this.initFeature("phi_convert", i.FeatureType.Converter);
                },
                methods: {
                    calculate: function() {
                        var e, t, n, r, a, i = this;
                        if (!this.checkNaN(this.value)) {
                            var u = this.index, c = parseFloat(this.value);
                            if (0 == u) {
                                if (c < 0 || c > 90) return void this.error(c);
                                t = (0, o.deg2rad)(c), e = c;
                            } else if (1 == u) {
                                if (c < 0 || c > 1.5707963267948966) return void this.error(c);
                                t = c;
                            } else if (2 == u) {
                                if (c < 0 || c > 1) return void this.error(c);
                                t = Math.asin(c), n = c;
                            } else if (3 == u) {
                                if (c < 0 || c > 1) return void this.error(c);
                                t = Math.acos(c), r = c;
                            } else {
                                if ((t = Math.atan(c)) < 0 || t > 1.5707963267948966) return void this.error(c);
                                a = c;
                            }
                            null == e && (e = (0, o.rad2deg)(t)), null == n && (n = Math.sin(t)), null == r && (r = Math.cos(t)), 
                            null == a && 90 != e && (a = Math.tan(t));
                            var l = "";
                            [ e, t, n, r, a ].forEach(function(e, t) {
                                t != u && ("" != l && (l += "\n"), l += i.units[t] + ": " + (null != e ? parseFloat(e.toFixed(4)) : "-"));
                            }), this.setData({
                                result: l
                            }), this.use();
                        }
                    },
                    error: function(t) {
                        e.showModal({
                            title: "输入错误",
                            content: "输入数字 " + t + " 不在正确范围内。",
                            showCancel: !1
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    "3ea9": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "492a": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4");
            n("8a42"), r(n("66fd"));
            var a = r(n("02bd"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "78e3": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("051b"), a = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = a.a;
    },
    8255: function(e, t, n) {},
    e5a9: function(e, t, n) {
        "use strict";
        var r = n("8255");
        n.n(r).a;
    }
}, [ [ "492a", "common/runtime", "common/vendor" ] ] ]);