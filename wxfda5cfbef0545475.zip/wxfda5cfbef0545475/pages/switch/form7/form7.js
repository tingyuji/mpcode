(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form7/form7" ], {
    "229e": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("c392"), a = n("dd9d");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        n("d077");
        var c = n("f0c5"), i = Object(c.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = i.exports;
    },
    "2f55": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4");
            n("8a42"), r(n("66fd"));
            var a = r(n("229e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "357c": function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = r(n("035c")), o = n("e308"), c = n("1c29"), i = n("00cd"), u = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    powerUnitIndex: 0,
                    powerUnits: [ "VAr", "kVAr", "μF" ],
                    power: "",
                    voltage: "",
                    frequency: "",
                    result: ""
                };
            },
            mixins: [ a.default ],
            onLoad: function() {
                this.initFeature("var_uf_convert", o.FeatureType.Converter);
            },
            methods: {
                calculate: function() {
                    var e = this.power, t = this.voltage, n = this.frequency;
                    if (!this.checkNaN(e, t, n)) {
                        var r, a = this.powerUnitIndex, o = 2 * Math.PI * n * Math.pow(t, 2);
                        if (0 == a || 1 == a) {
                            var u = (0 == a ? e : 1e3 * e) / o;
                            r = (0, i.unitFormatTo)(u, c.capacitanceUnits.F, c.capacitanceUnits.uF);
                        } else {
                            var f = (0, i.unitConvert)(e, c.capacitanceUnits.uF, c.capacitanceUnits.F) * o;
                            r = parseFloat(f.toFixed(3)) + " " + this.powerUnits[0];
                        }
                        this.setData({
                            result: r
                        }), this.use();
                    }
                }
            }
        };
        t.default = u;
    },
    b504: function(e, t, n) {},
    c392: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    d077: function(e, t, n) {
        "use strict";
        var r = n("b504");
        n.n(r).a;
    },
    dd9d: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("357c"), a = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = a.a;
    }
}, [ [ "2f55", "common/runtime", "common/vendor" ] ] ]);