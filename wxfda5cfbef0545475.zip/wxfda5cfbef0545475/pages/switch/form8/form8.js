(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/switch/form8/form8" ], {
    9104: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return u;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    acfd: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("e694"), a = n.n(r);
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(u);
        t.default = a.a;
    },
    c9ba: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("9104"), a = n("acfd");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        var i = n("f0c5"), o = Object(i.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = o.exports;
    },
    db43: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4");
            n("8a42"), r(n("66fd"));
            var a = r(n("c9ba"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    e694: function(e, t, n) {
        "use strict";
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = r(n("035c")), u = n("e308"), i = n("d9d4"), o = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    index: 0,
                    units: [ i.TemperatureUnit.CELSIUS, i.TemperatureUnit.FAHRENHEIT, i.TemperatureUnit.KELVIN ],
                    value: "",
                    result: "",
                    chineseUnits: [ "摄氏", "飞轮海", "开尔文" ],
                    feature: {},
                    vipRequired: !1
                };
            },
            mixins: [ a.default ],
            onLoad: function() {
                this.initFeature("temperature_convert", u.FeatureType.Converter);
            },
            methods: {
                calculate: function() {
                    var e = this, t = this.value;
                    if (!this.checkNaN(t)) {
                        var n = "";
                        this.units.forEach(function(r, a) {
                            if (e.index != a) {
                                "" != n && (n += "\n");
                                var u = (0, i.temperatureConvert)(t, e.units[e.index], r);
                                n += e.chineseUnits[a] + ": " + parseFloat(u.toFixed(3)) + " " + r;
                            }
                        }), this.setData({
                            result: n
                        }), this.use();
                    }
                }
            }
        };
        t.default = o;
    }
}, [ [ "db43", "common/runtime", "common/vendor" ] ] ]);