(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/invitation/invitation-record" ], {
    "1a9b": function(t, n, a) {
        "use strict";
        a.d(n, "b", function() {
            return i;
        }), a.d(n, "c", function() {
            return e;
        }), a.d(n, "a", function() {});
        var i = function() {
            this.$createElement;
            var t = (this._self._c, !this.invitationList.length && !this.loading);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, e = [];
    },
    4563: function(t, n, a) {
        "use strict";
        a.r(n);
        var i = a("573c"), e = a.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(n, t, function() {
                return i[t];
            });
        }(o);
        n.default = e.a;
    },
    "573c": function(t, n, a) {
        "use strict";
        (function(t) {
            var i = a("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = i(a("448a")), o = i(a("b253")), s = a("963d"), u = {
                data: function() {
                    return {
                        invitationUsers: {
                            payment_user_total: 0,
                            invitation_total: 0,
                            not_payment_user_total: 0
                        },
                        BaseUrl: s.BaseUrl,
                        page: 1,
                        last_page: 1,
                        loading: !1,
                        payment: "",
                        invitationList: [],
                        typeList: [ {
                            type: "",
                            name: "全部"
                        }, {
                            type: "1",
                            name: "已付费"
                        }, {
                            type: "0",
                            name: "未付费"
                        } ],
                        typeIndex: 0
                    };
                },
                onLoad: function(t) {
                    this.initDataCount(), this.relationsPage();
                },
                onReachBottom: function() {
                    this.page++, this.relationsPage();
                },
                onPullDownRefresh: function() {
                    console.log("下拉刷新"), this.invitationList = [], this.page = 1, this.last_page = 1, 
                    this.initDataCount(), this.relationsPage();
                },
                methods: {
                    initDataCount: function() {
                        var n = this;
                        o.default.get("invitation/relations-count").then(function(a) {
                            t.stopPullDownRefresh(), n.invitationUsers = a.data;
                        }, function(n) {
                            t.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        }).catch(function(t) {});
                    },
                    relationsPage: function() {
                        var n = this;
                        if (this.last_page <= this.page) {
                            var a = {
                                page: this.page,
                                is_payment: this.typeList[this.typeIndex].type,
                                payment: this.payment
                            };
                            this.loading = !0, o.default.get("invitation/relations-log", a).then(function(t) {
                                var a;
                                (a = n.invitationList).push.apply(a, (0, e.default)(t.data.data)), n.last_page = t.data.last_page, 
                                n.loading = !1;
                            }, function(n) {
                                t.showToast({
                                    title: n.message,
                                    icon: "none"
                                });
                            }).catch(function(t) {
                                n.loading = !1;
                            });
                        }
                    },
                    cikType: function(t) {
                        this.typeIndex = t, this.invitationList = [], this.last_page = 1, this.page = 1, 
                        this.relationsPage();
                    }
                }
            };
            n.default = u;
        }).call(this, a("543d").default);
    },
    "699f": function(t, n, a) {
        "use strict";
        (function(t, n) {
            var i = a("4ea4");
            a("8a42"), i(a("66fd"));
            var e = i(a("84aa"));
            t.__webpack_require_UNI_MP_PLUGIN__ = a, n(e.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    "84aa": function(t, n, a) {
        "use strict";
        a.r(n);
        var i = a("1a9b"), e = a("4563");
        for (var o in e) [ "default" ].indexOf(o) < 0 && function(t) {
            a.d(n, t, function() {
                return e[t];
            });
        }(o);
        a("ab73");
        var s = a("f0c5"), u = Object(s.a)(e.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        n.default = u.exports;
    },
    ab73: function(t, n, a) {
        "use strict";
        var i = a("ea17");
        a.n(i).a;
    },
    ea17: function(t, n, a) {}
}, [ [ "699f", "common/runtime", "common/vendor" ] ] ]);