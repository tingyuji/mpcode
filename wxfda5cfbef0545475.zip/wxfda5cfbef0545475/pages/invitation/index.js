(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/invitation/index" ], {
    1967: function(e, t, n) {
        "use strict";
        (function(e, i) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(n("b253")), o = n("963d"), u = {
                data: function() {
                    return {
                        BaseUrlC: o.BaseUrl,
                        ref: ""
                    };
                },
                mixins: [ a(n("ac2e")).default ],
                onLoad: function() {
                    e.showShareMenu({
                        withShareTicket: !0,
                        menus: [ "shareAppMessage", "shareTimeline" ]
                    });
                },
                onShow: function() {
                    this.initData();
                },
                onShareAppMessage: function(e) {
                    return "button" === e.from && console.log(e.target), {
                        title: "快来和我一起学习电工技术及电工电路图解！",
                        path: "/pages/index/index?ref=" + this.ref,
                        imageUrl: o.BaseUrl + "/static/images/invitation/share_img.jpg"
                    };
                },
                onShareTimeline: function(e) {
                    return {
                        title: "快来和我一起学习电工技术及电工电路图解！",
                        path: "/pages/index/index?ref=" + this.ref,
                        imageUrl: o.BaseUrl + "/static/images/invitation/share_img.jpg"
                    };
                },
                methods: {
                    initData: function() {
                        var e = this;
                        r.default.get("invitation/user-url").then(function(t) {
                            e.ref = t.data.ref;
                        }), r.default.get("invitation/user-create");
                    },
                    shareApp: function() {
                        i.share({
                            provider: "weixin",
                            scene: "WXSceneSession",
                            type: 5,
                            imageUrl: o.BaseUrl + "/static/images/invitation/share_img.jpg",
                            title: "快来和我一起学习电工技术及电工电路图解！",
                            miniProgram: {
                                id: "gh_4230d5981364",
                                path: "/pages/index/index?ref=" + this.ref,
                                type: 0,
                                webUrl: "http://uniapp.dcloud.io"
                            },
                            success: function(e) {
                                console.log(JSON.stringify(e));
                            },
                            fail: function(e) {
                                console.log(JSON.stringify(e));
                            }
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("bc2e").default, n("543d").default);
    },
    "373e": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("1967"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    "48f6": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("5ee5"), a = n("373e");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("823f");
        var o = n("f0c5"), u = Object(o.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = u.exports;
    },
    "5e14": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("48f6"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "5ee5": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var i = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "823f": function(e, t, n) {
        "use strict";
        var i = n("d4a0");
        n.n(i).a;
    },
    d4a0: function(e, t, n) {}
}, [ [ "5e14", "common/runtime", "common/vendor" ] ] ]);