(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form22/form22" ], {
    "3dcd": function(e, t, a) {},
    "939e": function(e, t, a) {
        "use strict";
        (function(e) {
            var n = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(a("035c")), i = n(a("0bfc")), c = n(a("3de9")), r = n(a("f73d")), l = n(a("37af")), u = n(a("ed61")), s = a("e308"), f = a("fad4"), d = a("5c05"), p = a("00cd"), m = a("1c29"), v = a("d417"), h = {
                components: {
                    featureBar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(a("e526"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    vipMask: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                            return resolve(a("e665"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        powerFactorValue: void 0,
                        needPowerFactorValue: void 0,
                        capacitorVoltage: void 0,
                        typeOptions: [ {
                            option: d.CompensationType.SINGLE_PHASE,
                            label: "单相",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batteria_condensatori_monofase.png"
                        }, {
                            option: d.CompensationType.THREE_PHASE_Y,
                            label: "三相Y",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batteria_condensatori_stella.png"
                        }, {
                            option: d.CompensationType.THREE_PHASE_TRIANGLE,
                            label: "三相△",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batteria_condensatori_triangolo.png"
                        } ],
                        typeOptionIndex: 0,
                        results: null
                    };
                },
                mixins: [ o.default, i.default, c.default, r.default, l.default, u.default ],
                onShow: function() {
                    this.setData({
                        powerUnits: [ f.ActivePowerUnits.W, f.ActivePowerUnits.kW ],
                        powerUnitIndex: 0
                    }), this.initFeature("power_factor_compensation", s.FeatureType.Calculate);
                },
                methods: {
                    inputVoltageValue: function(e) {
                        var t = parseInt(e.detail.value);
                        this.setData({
                            voltageUnitValue: t,
                            capacitorVoltage: t
                        });
                    },
                    calculate: function() {
                        if ((0, v.isVoidNumber)(this.voltageUnitValue) || (0, v.isVoidNumber)(this.frequencyUnitValue) || (0, 
                        v.isVoidNumber)(this.powerUnitValue) || (0, v.isVoidNumber)(this.powerFactorValue) || (0, 
                        v.isVoidNumber)(this.needPowerFactorValue) || (0, v.isVoidNumber)(this.capacitorVoltage)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t, a = {
                                voltageValue: this.voltageUnitValue,
                                frequencyValue: this.frequencyUnitValue,
                                powerValue: this.getPowerUnitValue(),
                                powerFactorValue: this.powerFactorValue,
                                needPowerFactorValue: this.needPowerFactorValue,
                                capacitorVoltage: this.capacitorVoltage,
                                type: this.typeOptions[this.typeOptionIndex].option
                            }, n = (0, d.calculate)(a);
                            t = n.reactivePower > 0 ? {
                                r: (0, p.formatFromUnits)(n.reactivePower, f.ReactivePowerUnits.VAr, f.ReactivePowerUnits),
                                c: (0, p.formatDouble)((0, p.unitConvert)(n.capacitance, m.capacitanceUnits.F, m.capacitanceUnits.uF), 1) + " " + m.capacitanceUnits.uF.name
                            } : {
                                r: (0, p.formatDouble)(n.reactivePower, 10) + " " + f.ReactivePowerUnits.VAr.name,
                                c: (0, p.formatDouble)((0, p.unitConvert)(n.capacitance, m.capacitanceUnits.F, m.capacitanceUnits.uF), 3) + " " + m.capacitanceUnits.uF.name
                            }, this.setData({
                                results: t
                            }), this.use(), this.$nextTick(function() {
                                (0, v.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            console.log(t), this.setData({
                                results: null
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = h;
        }).call(this, a("543d").default);
    },
    d0fb: function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return o;
        }), a.d(t, "c", function() {
            return i;
        }), a.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    d3cf: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("939e"), o = a.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = o.a;
    },
    e18f: function(e, t, a) {
        "use strict";
        (function(e, t) {
            var n = a("4ea4");
            a("8a42"), n(a("66fd"));
            var o = n(a("ea73"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, t(o.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    ea73: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("d0fb"), o = a("d3cf");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return o[e];
            });
        }(i);
        a("fcb8");
        var c = a("f0c5"), r = Object(c.a)(o.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = r.exports;
    },
    fcb8: function(e, t, a) {
        "use strict";
        var n = a("3dcd");
        a.n(n).a;
    }
}, [ [ "e18f", "common/runtime", "common/vendor" ] ] ]);