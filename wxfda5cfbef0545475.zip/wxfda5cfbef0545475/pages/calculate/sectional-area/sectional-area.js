(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/sectional-area/sectional-area" ], {
    "4ed5": function(e, t, i) {},
    "68f5": function(e, t, i) {
        "use strict";
        i.d(t, "b", function() {
            return n;
        }), i.d(t, "c", function() {
            return l;
        }), i.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(i.bind(null, "e526"));
            }
        }, n = function() {
            this.$createElement;
            var e = (this._self._c, this.currentElectricalSpecification === this.electricalSpecifications.IEC ? this.soilThermalResistivityOptions.length : null);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, l = [];
    },
    7398: function(e, t, i) {
        "use strict";
        (function(e) {
            var a = i("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = a(i("035c")), l = a(i("f73d")), r = a(i("0bfc")), o = a(i("3de9")), c = a(i("ed61")), u = a(i("fd69")), s = i("e308"), d = i("9bc7"), h = i("d417"), m = i("3e17"), p = {
                components: {
                    featureBar: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(i("e526"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    vipMask: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                            return resolve(i("e665"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    layingMode: function() {
                        i.e("components/laying-mode/laying-mode").then(function() {
                            return resolve(i("9f3d"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                mixins: [ n.default, l.default, r.default, u.default, o.default, c.default ],
                data: function() {
                    return {
                        maximumAllowableCableCoreAreaOptions: [],
                        maximumAllowableCableCoreAreaOptionIndex: 0,
                        isEnabled: !1,
                        calculateResult: null
                    };
                },
                onLoad: function() {
                    this.initFeature("cable_core_area", s.FeatureType.Calculate);
                },
                methods: {
                    onTab: function(e) {
                        var t = e.currentTarget.dataset.type;
                        t !== this.currentElectricalSpecification && (this.setData({
                            currentElectricalSpecification: t,
                            materialOptionIndex: 0,
                            insulationOptionIndex: 0,
                            singleCircuitCoreIndex: 0,
                            conductorOptionIndex: 0,
                            pipeCircuitIndex: 0,
                            totalConductorOptionIndex: 0,
                            maximumOperatingTemperatureOptionIndex: 0,
                            maximumAllowableCableCoreAreaOptionIndex: 0,
                            calculateResult: null
                        }), this.setLayingMode(), this.init());
                    },
                    listenerLayingMode: function(e) {
                        this.setData({
                            layingMode: e.detail,
                            maximumAllowableCableCoreAreaOptionIndex: 0,
                            calculateResult: null
                        }), this.handleCableCoreAre(), this.handleMaximumAllowableCableCoreArea(), this.init();
                    },
                    changeLayingMode: function(e) {
                        this.setData({
                            layingModeOptionIndex: e.detail.value
                        }), this.init();
                    },
                    changeCurrentType: function(e) {
                        var t = parseInt(e.detail.value);
                        this.setData({
                            currentTypeIndex: t,
                            singleCircuitCoreIndex: 3 === t ? 1 : 0
                        }), this.handleCableCoreAre(), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInsulation: function(e) {
                        this.setData({
                            insulationOptionIndex: e.detail.value
                        }), this.handleTemperatureAmbient(), this.handleCableCoreAre(), this.handleMaximumAllowableCableCoreArea();
                    },
                    changeMaterial: function(e) {
                        this.setData({
                            materialOptionIndex: e.detail.value
                        }), this.currentElectricalSpecification === d.ElectricalSpecifications.NEC && this.handleStyle();
                    },
                    changeMaximumOperatingTemperature: function(e) {
                        this.setData({
                            maximumOperatingTemperatureOptionIndex: e.detail.value
                        }), this.handleStyle();
                    },
                    switchChange: function(e) {
                        this.setData({
                            isEnabled: e.detail.value
                        });
                    },
                    init: function() {
                        this.currentElectricalSpecification === d.ElectricalSpecifications.IEC ? (this.handleTemperatureAmbient(), 
                        this.handleSoilThermalResistivity()) : (this.handleCableCoreAre(), this.handleMaximumAllowableCableCoreArea(), 
                        this.handleMaximumOperatingTemperature(), this.handleTemperatureAmbient(), this.handleStyle());
                    },
                    handleMaximumAllowableCableCoreArea: function() {
                        var e = [];
                        e = (e = this.currentElectricalSpecification === d.ElectricalSpecifications.IEC ? this.cableCoreAreaOptions.slice(3, this.cableCoreAreaOptions.length) : this.cableCoreAreaOptions.slice(0, this.cableCoreAreaOptions.length)).reverse(), 
                        this.setData({
                            maximumAllowableCableCoreAreaOptions: e
                        });
                    },
                    calculate: function() {
                        if ((0, h.isVoidNumber)(this.voltageUnitValue) || (0, h.isVoidNumber)(this.loadUnitValue) || (0, 
                        h.isVoidNumber)(this.cableLineUnitValue) || (0, h.isVoidNumber)(this.voltageDropValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                layingMode: this.getLayingMode(),
                                currentType: this.getCurrentType(),
                                voltageValue: this.getVoltageUnitValue(),
                                voltageDropValue: this.getVoltageDropValue(),
                                voltageDropRateValue: this.getVoltageDropRateValue(),
                                length: this.getCableLineUnitValue(),
                                material: this.materialOptions[this.materialOptionIndex].label,
                                conductorNumber: 1,
                                triangleCollection: this.getTriangleCollection()
                            };
                            this.currentElectricalSpecification === d.ElectricalSpecifications.IEC ? (t.isEnabled = this.isEnabled, 
                            t.insulation = this.insulationOptions[this.insulationOptionIndex].option, t.cableCoreAreaConfig = this.cableCoreAreaConfig, 
                            t.temperatureAmbientIndex = this.temperatureAmbientOptionIndex, t.temperatureAmbientConfig = this.temperatureAmbientConfig, 
                            t.soilThermalResistivityIndex = this.soilThermalResistivityOptionIndex, t.singleCircuitCoreIndex = 0, 
                            t.pipeCircuitIndex = this.pipeCircuitIndex, t.maximumAllowableCableCoreArea = this.maximumAllowableCableCoreAreaOptions[this.maximumAllowableCableCoreAreaOptionIndex].option) : (t.maximumOperatingTemperatureIndex = this.maximumOperatingTemperatureOptionIndex, 
                            t.temperatureAmbient = this.temperatureAmbientOptions[this.temperatureAmbientOptionIndex], 
                            t.totalConductor = this.totalConductorOptions[0], t.maximumAllowableCableCoreArea = this.maximumAllowableCableCoreAreaOptions[this.maximumAllowableCableCoreAreaOptionIndex]), 
                            t.current = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection);
                            var i = (0, m.calculate)(this.currentElectricalSpecification, t);
                            this.setData({
                                calculateResult: i
                            }), this.use(), this.$nextTick(function() {
                                (0, h.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.setData({
                                calculateResult: null
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = p;
        }).call(this, i("543d").default);
    },
    "73a0": function(e, t, i) {
        "use strict";
        var a = i("4ed5");
        i.n(a).a;
    },
    8713: function(e, t, i) {
        "use strict";
        i.r(t);
        var a = i("7398"), n = i.n(a);
        for (var l in a) [ "default" ].indexOf(l) < 0 && function(e) {
            i.d(t, e, function() {
                return a[e];
            });
        }(l);
        t.default = n.a;
    },
    9753: function(e, t, i) {
        "use strict";
        (function(e, t) {
            var a = i("4ea4");
            i("8a42"), a(i("66fd"));
            var n = a(i("b3c1"));
            e.__webpack_require_UNI_MP_PLUGIN__ = i, t(n.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    b3c1: function(e, t, i) {
        "use strict";
        i.r(t);
        var a = i("68f5"), n = i("8713");
        for (var l in n) [ "default" ].indexOf(l) < 0 && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(l);
        i("73a0");
        var r = i("f0c5"), o = Object(r.a)(n.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = o.exports;
    }
}, [ [ "9753", "common/runtime", "common/vendor" ] ] ]);