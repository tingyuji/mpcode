(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form14/form14" ], {
    "0b92": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("5582"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    "210a": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("420b"), a = n("0b92");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("eede");
        var l = n("f0c5"), u = Object(l.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = u.exports;
    },
    "420b": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    5582: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = i(n("035c")), r = i(n("f73d")), l = i(n("3de9")), u = i(n("ed61")), s = n("e308"), o = n("1c29"), c = n("6379"), p = n("00cd"), d = n("fad4"), f = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        inputTerminal: [ {
                            option: o.InputTerminal.VOLTAGE_CURRENT,
                            label: "电压/电流"
                        }, {
                            option: o.InputTerminal.VOLTAGE_POWER,
                            label: "电压/功率"
                        }, {
                            option: o.InputTerminal.CURRENT_POWER,
                            label: "电流/功率"
                        }, {
                            option: o.InputTerminal.RESISTANCE,
                            label: "电阻"
                        } ],
                        inputTerminalIndex: 0,
                        voltageDisplay: !0,
                        currentDisplay: !0,
                        resistanceDisplay: !1,
                        powerDisplay: !1,
                        trigonometricTypeDisplay: !1,
                        result: ""
                    };
                },
                mixins: [ a.default, r.default, l.default, u.default ],
                onLoad: function() {
                    this.initFeature("impedance", s.FeatureType.Calculate);
                },
                onShow: function() {
                    this.setCurrentType("DC");
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.setData({
                            currentTypeIndex: parseInt(e.detail.value)
                        }), this.handleDisplay(), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    changePowerUnit: function(e) {
                        this.setData({
                            powerUnitIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option, t = this.powerUnits[this.powerUnitIndex].name, n = !1;
                        ([ o.InputTerminal.RESISTANCE ].includes(e) || [ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.CURRENT_POWER ].includes(e) && ![ this.powerAllUnits.VA.name, this.powerAllUnits.kVA.name, this.powerAllUnits.MVA.name ].includes(t)) && (n = !0), 
                        this.setData({
                            voltageDisplay: [ o.InputTerminal.VOLTAGE_CURRENT, o.InputTerminal.VOLTAGE_POWER ].includes(e),
                            currentDisplay: [ o.InputTerminal.VOLTAGE_CURRENT, o.InputTerminal.CURRENT_POWER ].includes(e),
                            resistanceDisplay: [ o.InputTerminal.RESISTANCE ].includes(e),
                            powerDisplay: [ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.CURRENT_POWER ].includes(e),
                            trigonometricTypeDisplay: n
                        }), n || this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                voltageValue: this.getVoltageUnitValue(),
                                currentValue: this.getCurrentUnitValue(),
                                resistanceValue: this.getResistanceUnitValue(),
                                powerValue: this.getPowerUnitValue(),
                                powerType: (0, d.toPowerType)(this.powerUnits[this.powerUnitIndex].name),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, c.calculate)(t);
                            if (isNaN(n)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, p.formatFromUnits)(n, o.OhmUnits.O, o.OhmUnits)
                            }), this.use();
                        } catch (t) {
                            if ("∞" === t.message) return void this.setData({
                                result: "∞" + o.OhmUnits.M.name
                            });
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = f;
        }).call(this, n("543d").default);
    },
    "58a9": function(e, t, n) {},
    c40d: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("210a"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    eede: function(e, t, n) {
        "use strict";
        var i = n("58a9");
        n.n(i).a;
    }
}, [ [ "c40d", "common/runtime", "common/vendor" ] ] ]);