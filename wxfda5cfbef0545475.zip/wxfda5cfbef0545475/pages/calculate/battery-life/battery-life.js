(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/battery-life/battery-life" ], {
    "35c6": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "3ced": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var o = i(n("949b"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "5e64": function(e, t, n) {
        "use strict";
        var i = n("7848");
        n.n(i).a;
    },
    7848: function(e, t, n) {},
    "949b": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("35c6"), o = n("c476");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("5e64");
        var r = n("f0c5"), l = Object(r.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = l.exports;
    },
    c476: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("ffc0"), o = n.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        t.default = o.a;
    },
    ffc0: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = i(n("035c")), a = i(n("f73d")), r = i(n("3de9")), l = i(n("ed61")), c = i(n("3beb")), s = n("e308"), u = n("d417"), f = n("00cd"), d = n("d055"), h = n("0db1"), m = n("2c16"), p = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ o.default, a.default, r.default, l.default, c.default ],
                data: function() {
                    return {
                        connectOptions: [ {
                            option: "single",
                            label: "单个",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batteria_singola.png"
                        }, {
                            option: "series",
                            label: "串联",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batterie_serie.png"
                        }, {
                            option: "parallel",
                            label: "并联",
                            image: "https://ts.pp.cc/storage/electrical_symbol/calculate/batterie_parallelo.png"
                        } ],
                        connectOptionIndex: 0,
                        form: {
                            number: 1,
                            peukert: 1,
                            dod: 100
                        },
                        historyNumber: 2,
                        result: null
                    };
                },
                onLoad: function() {
                    this.loadUnits = [ this.powerAllUnits.W, this.powerAllUnits.A, new f.Unit("mA", .001), this.powerAllUnits.VA ], 
                    this.setCurrentType("AC"), this.initFeature("battery_life", s.FeatureType.Calculate);
                },
                methods: {
                    changeConnect: function(e) {
                        this.connectOptionIndex = parseInt(e.detail.value), this.connectOptionIndex > 0 ? this.form.number = this.historyNumber : this.form.number = 1;
                    },
                    changeNumber: function(e) {
                        this.form.number = this.historyNumber = parseInt(e.detail.value);
                    },
                    calculate: function() {
                        if ((0, u.isVoidNumber)(this.capacityUnitValue) || (0, u.isVoidNumber)(this.form.peukert) || (0, 
                        u.isVoidNumber)(this.form.dod) || (0, u.isVoidNumber)(this.loadUnitValue) || (0, 
                        u.isVoidNumber)(this.voltageUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else if (this.connectOptionIndex > 0 && (0, u.isVoidNumber)(this.form.number)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else if (this.form.peukert < 1 || this.form.peukert > 1.5) e.showModal({
                            title: "注意！",
                            content: "Peukert常数 = " + this.form.peukert,
                            showCancel: !1
                        }); else if (this.form.dod <= 0 || this.form.dod > 100) e.showModal({
                            title: "注意！",
                            content: "放电深度（DOD）= " + this.form.dod,
                            showCancel: !1
                        }); else {
                            var t = this.loadUnits[this.loadUnitIndex].name, n = this.getVoltageUnitValue(), i = this.getBatteryCapacityValue();
                            1 === this.connectOptionIndex && (n *= this.form.number), 2 === this.connectOptionIndex && (i *= this.form.number);
                            try {
                                var o = this.getLoadCurrent(this.getCurrentType(), n, this.getTriangleCollection()), a = o;
                                [ d.CurrentUnits.mA.name, d.CurrentUnits.A.name ].includes(t) ? (a = (0, m.calculateVoltageCurrent)(this.getCurrentType(), n, o, this.getTriangleCollection()), 
                                a = (0, f.formatDouble)(a, 2) + " " + this.powerAllUnits.W.name) : a = (0, f.formatDouble)(a, 2) + " " + d.CurrentUnits.A.name;
                                var r = this.calculateDuration(i * this.form.dod / 100, o, this.form.peukert);
                                this.connectOptionIndex ? this.result = {
                                    voltage: n + " " + h.VoltageUnits.V.name,
                                    capacity: i + "Ah",
                                    load: a,
                                    duration: r,
                                    efficiency: "100 %"
                                } : this.result = {
                                    load: a,
                                    duration: r,
                                    efficiency: "100 %"
                                }, this.use(), this.$nextTick(function() {
                                    (0, u.calculatePageScroll)(1e3);
                                });
                            } catch (t) {
                                this.result = null, e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    },
                    calculateDuration: function(e, t, n) {
                        var i = 20 * Math.pow(e / (20 * t), n) * 60, o = i % 1440, a = Math.floor(i / 1440), r = Math.floor(o / 60), l = Math.floor(o % 60), c = [];
                        return a > 0 && c.push(a + "天"), r > 0 && c.push(r + "小时"), l > 0 && c.push(l + "分钟"), 
                        c.join(" ");
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    }
}, [ [ "3ced", "common/runtime", "common/vendor" ] ] ]);