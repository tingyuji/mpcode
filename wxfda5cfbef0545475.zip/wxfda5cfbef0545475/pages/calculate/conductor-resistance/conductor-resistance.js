(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/conductor-resistance/conductor-resistance" ], {
    1244: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = a(n("035c")), r = a(n("0bfc")), o = a(n("8760")), i = n("e308"), u = n("d055"), l = n("1c29"), s = n("00cd"), d = n("d417"), f = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ c.default, r.default, o.default ],
                data: function() {
                    return {
                        conductor: null
                    };
                },
                onLoad: function() {
                    this.initFeature("conductor_resistance", i.FeatureType.Calculate);
                },
                methods: {
                    calculate: function() {
                        if ((0, d.isVoidNumber)(this.cableLineUnitValue) || (0, d.isVoidNumber)(this.temperatureUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                length: this.getCableLineUnitValue(),
                                temperature: this.getTemperatureUnitValue()
                            }, n = this.getCableCoreAreaCollection(t.length, t.temperature, u.CurrentType.SINGLE_PHASE_CURRENT);
                            this.setData({
                                conductor: {
                                    reactance: (0, s.formatFromUnits)(n.reactance, l.OhmUnits.O, l.OhmUnits),
                                    resistance: (0, s.formatFromUnits)(n.resistance, l.OhmUnits.O, l.OhmUnits),
                                    impedance: (0, s.formatFromUnits)(n.impedance, l.OhmUnits.O, l.OhmUnits)
                                }
                            }), this.use(), this.$nextTick(function() {
                                (0, d.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.setData({
                                conductor: null
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = f;
        }).call(this, n("543d").default);
    },
    "17a4": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("cec9"), c = n("ede4");
        for (var r in c) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(r);
        n("5976");
        var o = n("f0c5"), i = Object(o.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    },
    "20c1": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var c = a(n("17a4"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "24dd": function(e, t, n) {},
    5976: function(e, t, n) {
        "use strict";
        var a = n("24dd");
        n.n(a).a;
    },
    cec9: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    ede4: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("1244"), c = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = c.a;
    }
}, [ [ "20c1", "common/runtime", "common/vendor" ] ] ]);