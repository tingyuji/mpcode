(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form20/form20" ], {
    "00cc": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var c = a(n("13c8"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "0262": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("da20"), c = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t.default = c.a;
    },
    "13c8": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("96f2"), c = n("0262");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(i);
        n("f92b");
        var r = n("f0c5"), u = Object(r.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = u.exports;
    },
    "96f2": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    b174: function(e, t, n) {},
    da20: function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = a(n("035c")), i = n("e308"), r = n("5ce9"), u = n("1c29"), s = n("00cd"), o = n("d417"), l = "感性电抗", f = "容性电抗", d = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    targetIndex: 0,
                    targetRanges: [ l, f, "电感", "电容", "频率" ],
                    reactanceTypeRanges: [],
                    reactanceTypeIndex: 0,
                    reactanceValue: "",
                    reactanceUnitIndex: 1,
                    reactanceUnitRanges: [ u.OhmUnits.m, u.OhmUnits.O, u.OhmUnits.k, u.OhmUnits.M ],
                    freqValue: "",
                    freqUnitIndex: 0,
                    freqUnitRanges: [ r.hzUnits.Hz, r.hzUnits.kHz, r.hzUnits.MHz ],
                    capacitanceValue: "",
                    capacitanceUnitIndex: 2,
                    capacitanceUnitRanges: [ u.capacitanceUnits.pF, u.capacitanceUnits.nF, u.capacitanceUnits.uF, u.capacitanceUnits.mF, u.capacitanceUnits.F ],
                    inductanceValue: "",
                    inductanceUnitIndex: 2,
                    inductanceUnitRanges: [ u.inductanceUnits.uH, u.inductanceUnits.mH, u.inductanceUnits.H ],
                    result: ""
                };
            },
            mixins: [ c.default ],
            onLoad: function() {
                this.initFeature("reactance", i.FeatureType.Calculate);
            },
            methods: {
                getFreq: function() {
                    return (0, s.unitConvert)(this.freqValue, this.freqUnitRanges[this.freqUnitIndex], r.hzUnits.Hz);
                },
                getReactance: function() {
                    return (0, s.unitConvert)(this.reactanceValue, this.reactanceUnitRanges[this.reactanceUnitIndex], u.OhmUnits.O);
                },
                getInductance: function() {
                    return (0, s.unitConvert)(this.inductanceValue, this.inductanceUnitRanges[this.inductanceUnitIndex], u.inductanceUnits.H);
                },
                getCapacitance: function() {
                    return (0, s.unitConvert)(this.capacitanceValue, this.capacitanceUnitRanges[this.capacitanceUnitIndex], u.capacitanceUnits.F);
                },
                targetChange: function(e) {
                    var t = parseInt(e.detail.value), n = {
                        targetIndex: t
                    };
                    switch (t) {
                      case 2:
                        n.reactanceTypeRanges = [ l ], n.reactanceTypeIndex = 0;
                        break;

                      case 3:
                        n.reactanceTypeRanges = [ f ], n.reactanceTypeIndex = 0;
                        break;

                      case 4:
                        n.reactanceTypeRanges = [ l, f ], n.reactanceTypeIndex = 0;
                    }
                    this.setData(n);
                },
                calculate: function() {
                    var e, t = this.reactanceValue, n = this.freqValue, a = this.inductanceValue, c = this.capacitanceValue;
                    switch (parseInt(this.targetIndex)) {
                      case 0:
                        if (this.checkNaN(n, a)) return;
                        e = (0, u.calculateInductiveReactance)(this.getFreq(), this.getInductance()), e = (0, 
                        u.ohmFormat)(e);
                        break;

                      case 1:
                        if (this.checkNaN(n, c)) return;
                        e = (0, u.calculateCapacitiveReactance)(this.getFreq(), this.getCapacitance()), 
                        e = (0, u.ohmFormat)(e);
                        break;

                      case 2:
                        if (this.checkNaN(n, t)) return;
                        e = (0, u.calculateInductance)(this.getReactance(), this.getFreq()), e = (0, s.formatFromUnits)(e, u.inductanceUnits.H, u.inductanceUnits);
                        break;

                      case 3:
                        if (this.checkNaN(n, t)) return;
                        e = (0, u.calculateReactance)(this.getReactance(), this.getFreq()), e = (0, s.formatFromUnits)(e, u.capacitanceUnits.F, u.capacitanceUnits);
                        break;

                      case 4:
                        var i = parseInt(this.reactanceTypeIndex), l = 0 == i ? this.getInductance() : this.getCapacitance();
                        if (this.checkNaN(t, l)) return;
                        e = (0, u.calculateFrequency)(this.getReactance(), l, i), e = (0, s.formatFromUnits)(e, r.hzUnits.Hz, r.hzUnits);
                    }
                    this.setData({
                        result: e
                    }), this.use(), this.$nextTick(function() {
                        (0, o.calculatePageScroll)(1e3);
                    });
                }
            }
        };
        t.default = d;
    },
    f92b: function(e, t, n) {
        "use strict";
        var a = n("b174");
        n.n(a).a;
    }
}, [ [ "00cc", "common/runtime", "common/vendor" ] ] ]);