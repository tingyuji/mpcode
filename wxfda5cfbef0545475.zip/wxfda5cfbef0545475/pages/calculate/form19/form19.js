(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form19/form19" ], {
    "056f": function(e, t, i) {
        "use strict";
        (function(e) {
            var n = i("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(i("035c")), r = n(i("f73d")), o = n(i("0bfc")), l = n(i("3de9")), c = n(i("ed61")), u = n(i("fd69")), s = i("e308"), d = i("9bc7"), h = i("d417"), p = i("d055"), f = i("00cd"), m = i("7572"), C = i("e827"), g = {
                components: {
                    featureBar: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(i("e526"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    vipMask: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                            return resolve(i("e665"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    layingMode: function() {
                        i.e("components/laying-mode/laying-mode").then(function() {
                            return resolve(i("9f3d"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                mixins: [ a.default, r.default, o.default, u.default, l.default, c.default ],
                data: function() {
                    return {
                        protectorOptions: [ "断路器", "保险丝" ],
                        protectorOptionIndex: 0,
                        calculateResult: null
                    };
                },
                onLoad: function() {
                    this.loadUnits = this.loadUnits.slice(0, 4), this.initFeature("circuit_breaker_selection", s.FeatureType.Calculate);
                },
                methods: {
                    onTab: function(e) {
                        var t = e.currentTarget.dataset.type;
                        t !== this.currentElectricalSpecification && (this.currentElectricalSpecification = t, 
                        this.materialOptionIndex = 0, this.materialOptionIndex = 0, this.insulationOptionIndex = 0, 
                        this.conductorOptionIndex = 0, this.pipeCircuitIndex = 0, this.calculateResult = null, 
                        this.setLayingMode(), this.init());
                    },
                    listenerLayingMode: function(e) {
                        this.layingMode = e.detail, this.calculateResult = null, this.init();
                    },
                    changeLayingMode: function(e) {
                        this.layingModeOptionIndex = parseInt(e.detail.value), this.init();
                    },
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value), this.currentType[this.currentTypeIndex].option === p.CurrentType.THREE_PHASE_CURRENT ? this.singleCircuitCoreIndex = 1 : this.singleCircuitCoreIndex = 0, 
                        this.handleCableCoreAre(), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInsulation: function(e) {
                        this.insulationOptionIndex = parseInt(e.detail.value), this.handleCableCoreAre();
                    },
                    changeMaterial: function(e) {
                        this.materialOptionIndex = parseInt(e.detail.value), this.currentElectricalSpecification === d.ElectricalSpecifications.NEC && this.handleStyle();
                    },
                    changeMaximumOperatingTemperature: function(e) {
                        this.maximumOperatingTemperatureOptionIndex = parseInt(e.detail.value), this.handleStyle();
                    },
                    init: function() {
                        if (this.currentElectricalSpecification === d.ElectricalSpecifications.IEC) {
                            this.handleCableCoreAre(), this.handleTemperatureAmbient(), this.handleSoilThermalResistivity();
                            var e = this.cableCoreAreaOptions.length;
                            this.cableCoreAreaOptions = this.cableCoreAreaOptions.slice(3, e), this.cableCoreAreaConfig = this.cableCoreAreaConfig.slice(3, e);
                        } else this.handleCableCoreAre(), this.handleMaximumOperatingTemperature(), this.handleTemperatureAmbient(), 
                        this.handleStyle();
                    },
                    calculate: function() {
                        if ((0, h.isVoidNumber)(this.voltageUnitValue) || (0, h.isVoidNumber)(this.loadUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else if (this.currentElectricalSpecification === d.ElectricalSpecifications.NEC && (0, 
                        h.isVoidNumber)(this.discontinuousLoadUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                layingMode: this.getLayingMode(),
                                currentType: this.getCurrentType(),
                                voltageValue: this.getVoltageUnitValue(),
                                triangleCollection: this.getTriangleCollection(),
                                material: this.materialOptions[this.materialOptionIndex].label,
                                cableCoreAreaIndex: this.cableCoreAreaOptionIndex,
                                conductorNumber: this.conductorOptions[this.conductorOptionIndex],
                                current: 0,
                                discontinuousCurrent: 0,
                                protectorIndex: this.protectorOptionIndex
                            };
                            this.currentElectricalSpecification === d.ElectricalSpecifications.IEC ? (t.insulation = this.insulationOptions[this.insulationOptionIndex].option, 
                            t.cableCoreAreaConfig = this.cableCoreAreaConfig, t.temperatureAmbientIndex = 4, 
                            t.temperatureAmbientConfig = this.temperatureAmbientConfig, t.soilThermalResistivityIndex = this.soilThermalResistivityOptionIndex, 
                            t.singleCircuitCoreIndex = this.singleCircuitCoreIndex, t.pipeCircuitIndex = this.pipeCircuitIndex, 
                            t.current = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection)) : (t.maximumOperatingTemperatureIndex = this.maximumOperatingTemperatureOptionIndex, 
                            t.temperatureAmbient = this.temperatureAmbientOptions[this.temperatureAmbientOptionIndex], 
                            t.totalConductor = this.totalConductorOptions[this.totalConductorOptionIndex], this.loadUnitValue && (t.current = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection)), 
                            this.discontinuousLoadUnitValue && (t.discontinuousCurrent = this.getDiscontinuousLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection)));
                            var i = (0, C.calculate)(this.currentElectricalSpecification, t), n = (0, m.calculate)(this.currentElectricalSpecification, t, i), a = t.current + t.discontinuousCurrent;
                            i = (0, f.unitFormatTo)(i, p.CurrentUnits.A, p.CurrentUnits.A), a = (0, f.unitFormatTo)(a, p.CurrentUnits.A, p.CurrentUnits.A), 
                            n <= 0 ? (e.showModal({
                                title: "注意！",
                                content: "需要更大的线缆",
                                showCancel: !1
                            }), n = "-") : n = (0, f.unitFormatTo)(n, p.CurrentUnits.A, p.CurrentUnits.A), this.calculateResult = {
                                current: a,
                                ratedCurrent: n,
                                carryingCapacity: i
                            }, this.use(), this.$nextTick(function() {
                                (0, h.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.calculateResult = null, e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = g;
        }).call(this, i("543d").default);
    },
    "0959": function(e, t, i) {
        "use strict";
        (function(e, t) {
            var n = i("4ea4");
            i("8a42"), n(i("66fd"));
            var a = n(i("f157"));
            e.__webpack_require_UNI_MP_PLUGIN__ = i, t(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    "56af": function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("056f"), a = i.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = a.a;
    },
    "833f": function(e, t, i) {},
    "93a5": function(e, t, i) {
        "use strict";
        var n = i("833f");
        i.n(n).a;
    },
    aab2: function(e, t, i) {
        "use strict";
        i.d(t, "b", function() {
            return a;
        }), i.d(t, "c", function() {
            return r;
        }), i.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(i.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement;
            var e = (this._self._c, this.currentElectricalSpecification === this.electricalSpecifications.IEC ? this.cableCoreAreaOptions.length : null);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, r = [];
    },
    f157: function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("aab2"), a = i("56af");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            i.d(t, e, function() {
                return a[e];
            });
        }(r);
        i("93a5");
        var o = i("f0c5"), l = Object(o.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = l.exports;
    }
}, [ [ "0959", "common/runtime", "common/vendor" ] ] ]);