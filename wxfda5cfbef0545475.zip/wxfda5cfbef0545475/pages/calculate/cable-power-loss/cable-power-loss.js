(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/cable-power-loss/cable-power-loss" ], {
    "041a": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var r = a(n("7a23"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    1461: function(e, t, n) {},
    "607f": function(e, t, n) {
        "use strict";
        var a = n("1461");
        n.n(a).a;
    },
    "7a23": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("f275"), r = n("a594");
        for (var l in r) [ "default" ].indexOf(l) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(l);
        n("607f");
        var i = n("f0c5"), o = Object(i.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = o.exports;
    },
    "9aa5": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(n("035c")), l = a(n("0bfc")), i = a(n("8760")), o = a(n("3de9")), u = a(n("f73d")), c = a(n("ed61")), s = n("e308"), f = n("d417"), d = n("00cd"), p = n("d055"), h = n("2c16"), m = n("9a2b"), v = n("fad4"), b = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ r.default, l.default, i.default, o.default, u.default, c.default ],
                data: function() {
                    return {
                        lossResult: null
                    };
                },
                onLoad: function() {
                    this.initFeature("cable_power_loss", s.FeatureType.Calculate), this.loadUnits = [ this.powerAllUnits.A, this.powerAllUnits.kA, this.powerAllUnits.W, this.powerAllUnits.kW ], 
                    this.temperatureUnitValue = 70;
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value);
                        var t = this.currentType[this.currentTypeIndex].option;
                        this.cableCoreTypeIndex = t === p.CurrentType.THREE_PHASE_CURRENT ? 1 : 0, this.setTrigonometricTypeValue(t);
                    },
                    calculate: function() {
                        if ((0, f.isVoidNumber)(this.voltageUnitValue) || (0, f.isVoidNumber)(this.loadUnitValue) || (0, 
                        f.isVoidNumber)(this.cableLineUnitValue) || (0, f.isVoidNumber)(this.temperatureUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                currentType: this.getCurrentType(),
                                voltageValue: this.getVoltageUnitValue(),
                                length: this.getCableLineUnitValue(),
                                temperature: this.getTemperatureUnitValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, n = this.getCableCoreAreaCollection(t.length, t.temperature, t.currentType), a = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection), r = (0, 
                            h.calculate)({
                                currentType: t.currentType,
                                inputTerminal: v.InputTerminal.VOLTAGE_CURRENT,
                                voltageValue: t.voltageValue,
                                currentValue: a,
                                triangleCollection: t.triangleCollection
                            }), l = (0, m.calculateCablePowerLoss)(t.currentType, a, n.resistance), i = 100 * l / r;
                            this.lossResult = {
                                activePower: (0, d.formatFromUnits)(r, v.ActivePowerUnits.W, v.ActivePowerUnits),
                                lossPower: (0, d.formatFromUnits)(l, v.ActivePowerUnits.W, v.ActivePowerUnits),
                                lossPowerRate: (0, d.formatDouble)(i, 3) + " %"
                            }, this.use(), this.$nextTick(function() {
                                (0, f.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.lossResult = null, e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = b;
        }).call(this, n("543d").default);
    },
    a594: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("9aa5"), r = n.n(a);
        for (var l in a) [ "default" ].indexOf(l) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(l);
        t.default = r.a;
    },
    f275: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return l;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, l = [];
    }
}, [ [ "041a", "common/runtime", "common/vendor" ] ] ]);