(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form24/form24" ], {
    "30a6": function(e, t, n) {},
    "4a67": function(e, t, n) {
        "use strict";
        var a = n("30a6");
        n.n(a).a;
    },
    9037: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("aee1"), r = n("d6bb");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("4a67");
        var o = n("f0c5"), i = Object(o.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    },
    "92e8": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var r = a(n("9037"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    aee1: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    ceda: function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = a(n("035c")), c = n("e308"), o = n("d417"), i = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    cpUnitIndex: 0,
                    cpUnitRanges: [ "VAr", "kVAr" ],
                    inputVoltage: "",
                    powerFrequency: "",
                    capacitorPower: "",
                    capacitorVoltage: "",
                    capacitorFrequency: "",
                    result: ""
                };
            },
            mixins: [ r.default ],
            onLoad: function() {
                this.initFeature("capacitor_power", c.FeatureType.Calculate);
            },
            methods: {
                cpUnitChange: function(e) {
                    this.setData({
                        cpUnitIndex: e.detail.value
                    });
                },
                calculate: function() {
                    var e = this.inputVoltage, t = this.powerFrequency, n = this.capacitorPower, a = this.capacitorVoltage, r = t / this.capacitorFrequency * Math.pow(e / a, 2) * n, c = parseFloat(r.toFixed(3)) + " " + this.cpUnitRanges[this.cpUnitIndex];
                    this.setData({
                        result: c
                    }), this.use(), this.$nextTick(function() {
                        (0, o.calculatePageScroll)(1e3);
                    });
                }
            }
        };
        t.default = i;
    },
    d6bb: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("ceda"), r = n.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        t.default = r.a;
    }
}, [ [ "92e8", "common/runtime", "common/vendor" ] ] ]);