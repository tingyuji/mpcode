(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/joule-loss/joule-loss" ], {
    "514b": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("96f7"), c = n("6b6c");
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(u);
        n("a805");
        var r = n("f0c5"), o = Object(r.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = o.exports;
    },
    "6b6c": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("a2e9"), c = n.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        t.default = c.a;
    },
    "96f7": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return u;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    a2e9: function(e, t, n) {
        "use strict";
        var a = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = n("e308"), u = a(n("035c")), r = n("e954"), o = n("d417"), i = {
            components: {
                featureBar: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(n("e526"));
                    }.bind(null, n)).catch(n.oe);
                },
                vipMask: function() {
                    Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                        return resolve(n("e665"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            data: function() {
                return {
                    sourceRanges: [ "电阻", "功率" ],
                    sourceIndex: 0,
                    sourceValue: "",
                    electricCurrent: "",
                    sec: "",
                    result: ""
                };
            },
            mixins: [ u.default ],
            onLoad: function() {
                this.initFeature("joule_loss", c.FeatureType.Calculate);
            },
            methods: {
                sourceChange: function(e) {
                    this.setData({
                        sourceIndex: e.detail.value
                    });
                },
                calculate: function() {
                    var e = this.sourceValue, t = this.electricCurrent, n = this.sec;
                    if (!this.checkNaN(e, t, n)) {
                        var a;
                        if (0 == this.sourceIndex) {
                            var c = (0, r.calculateLossEnergy)(e, t), u = (0, r.calculateLossPower)(c, n);
                            a = "损耗功率: ".concat(c, " W\n损耗能量: ").concat(u, " J");
                        } else {
                            var i = (0, r.calculateLossPower)(e, n);
                            a = "损耗能量: ".concat(i, " J");
                        }
                        this.setData({
                            result: a
                        }), this.use(), this.$nextTick(function() {
                            (0, o.calculatePageScroll)(1e3);
                        });
                    }
                }
            }
        };
        t.default = i;
    },
    a805: function(e, t, n) {
        "use strict";
        var a = n("a839");
        n.n(a).a;
    },
    a839: function(e, t, n) {},
    ab55: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var c = a(n("514b"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "ab55", "common/runtime", "common/vendor" ] ] ]);