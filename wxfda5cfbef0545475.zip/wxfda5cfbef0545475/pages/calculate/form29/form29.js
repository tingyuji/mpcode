(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form29/form29" ], {
    "3ee2": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("aff3"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "475f": function(t, e, n) {
        "use strict";
        var a = n("666b");
        n.n(a).a;
    },
    "666b": function(t, e, n) {},
    "66c2": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("a1ed"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        e.default = i.a;
    },
    7269: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    a1ed: function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("035c")), r = a(n("f772")), s = n("e308"), c = n("1c29"), u = n("d9d4"), o = n("d417");
            function h(t) {
                var e = parseFloat((0, u.celsius2fahrenheit)(t)).toFixed(3), n = parseFloat((0, 
                u.celsius2kelvin)(t)).toFixed(3);
                return t = parseFloat(t.toFixed(3)), "".concat(t, " °C\n").concat(e, " °F\n").concat(n, " °K");
            }
            var l = {
                key: "R",
                name: "电阻"
            }, f = {
                key: "T",
                name: "温度"
            }, p = {
                key: "V",
                name: "电压"
            }, d = [ c.OhmUnits.m.name, c.OhmUnits.O.name, c.OhmUnits.k.name ], m = [ u.TemperatureUnit.CELSIUS, u.TemperatureUnit.FAHRENHEIT, u.TemperatureUnit.KELVIN ], U = [ "mV" ], v = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        tab: "pnc",
                        pncTargetRanges: [ l, f ],
                        pncTargetIndex: 0,
                        pncTypeRanges: [ "PT", "NI", "CU" ],
                        pncTypeIndex: 0,
                        pncResistanceValue: "",
                        pncXUnitRanges: [],
                        pncXUnitIndex: 0,
                        pncXValue: "",
                        pncResult: "",
                        ntcTargetRanges: [ l, f ],
                        ntcTargetIndex: 0,
                        ntcRefResistValue: "",
                        ntcRefResistUnitRanges: d,
                        ntcRefResistUnitIndex: 1,
                        ntcRefTempValue: "",
                        ntcRefTempUnitRanges: m,
                        ntcRefTempUnitIndex: 0,
                        ntcBeta: "",
                        ntcXValue: "",
                        ntcXUnitRanges: [],
                        ntcXUnitIndex: 0,
                        thrTargetIndex: 0,
                        thrTargetRanges: [ p, f ],
                        thrTypeIndex: 0,
                        thrTypeRanges: [ "B", "E", "J", "K", "N", "R", "S", "T" ],
                        thrXUnitRanges: [],
                        thrXUnitIndex: 0,
                        thrXValue: "",
                        thrResult: ""
                    };
                },
                mixins: [ i.default ],
                onLoad: function() {
                    this.initFeature("temperature_sensor", s.FeatureType.Calculate), this.setData({
                        pncXUnitRanges: 0 == this.pncTargetIndex ? m : d,
                        thrXUnitRanges: 0 == this.thrTargetIndex ? m : U,
                        ntcXUnitRanges: 0 == this.ntcTargetIndex ? m : d
                    });
                },
                methods: {
                    switchTab: function(t) {
                        var e = t.currentTarget.dataset.tab;
                        this.setData({
                            tab: e
                        });
                    },
                    pncTargetChange: function(t) {
                        var e = t.detail.value;
                        this.setData({
                            pncTargetIndex: e,
                            pncXUnitRanges: 0 == e ? m : d,
                            pncXUnitIndex: 0 == e ? 0 : 1
                        });
                    },
                    pncTypeChange: function(t) {
                        this.setData({
                            pncTypeIndex: t.detail.value
                        });
                    },
                    pncResistanceInput: function(t) {
                        this.pncResistanceValue = t.detail.value;
                    },
                    pncXInput: function(t) {
                        this.pncXValue = t.detail.value;
                    },
                    pncXUnitChange: function(t) {
                        this.setData({
                            pncXUnitIndex: t.detail.value
                        });
                    },
                    pncCalculate: function() {
                        var e = this.pncTargetRanges[this.pncTargetIndex], n = this.pncTypeRanges[this.pncTypeIndex], a = this.pncXValue, i = this.pncXUnitRanges[this.pncXUnitIndex];
                        try {
                            var r;
                            if (e.key == l.key) {
                                switch (i != u.TemperatureUnit.CELSIUS && (a = (0, u.temperatureConvert)(a, i, u.TemperatureUnit.CELSIUS)), 
                                n) {
                                  case "PT":
                                    r = function(t, e) {
                                        var n = 0;
                                        if (t <= 0) throw new Error("阻值输入无效。");
                                        if (e <= -273.15) throw new Error("温度输入无效。");
                                        return e < 0 && (n = -4.183e-12), (.0039083 * e + 1 + -5.775e-7 * Math.pow(e, 2) + (e - 100) * Math.pow(e, 3) * n) * t;
                                    }(this.pncResistanceValue, a);
                                    break;

                                  case "NI":
                                    r = function(t, e) {
                                        if (t <= 0) throw new Error("阻值输入无效。");
                                        if (e <= -273.15) throw new Error("温度输入无效。");
                                        return (.005485 * e + 1 + 665e-8 * Math.pow(e, 2) + 2.805e-11 * Math.pow(e, 4) + -2e-17 * Math.pow(e, 6)) * t;
                                    }(this.pncResistanceValue, a);
                                    break;

                                  case "CU":
                                    r = function(t, e) {
                                        if (t <= 0) throw new Error("阻值输入无效。");
                                        if (e <= -273.15) throw new Error("温度输入无效。");
                                        var n, a = 0;
                                        return e < 0 ? (a = -6.2032e-7, n = 8.5154e-10) : n = 0, (.00428 * e + 1 + (6.7 + e) * a * e + Math.pow(e, 3) * n) * t;
                                    }(this.pncResistanceValue, a);
                                }
                                r = (0, c.ohmFormat)(r);
                            } else {
                                switch (i != c.OhmUnits.O.name && (a = (0, c.ohmConvert)(a, c.OhmUnits.O, i == c.OhmUnits.m.name ? c.OhmUnits.m : c.OhmUnits.k)), 
                                n) {
                                  case "PT":
                                    r = function(t, e) {
                                        if (t <= 0 || e <= 0) throw new Error("阻值输入无效。");
                                        var n = .0039083 * t, a = Math.pow(n, 2) - 4 * t * -5.775e-7 * (t - e);
                                        return (Math.sqrt(a) + -n) / (2 * t * -5.775e-7);
                                    }(this.pncResistanceValue, a);
                                    break;

                                  case "NI":
                                    r = function(t, e) {
                                        if (t <= 0 || e <= 0) throw new Error("阻值输入无效。");
                                        var n = (Math.sqrt(Math.pow(.005485, 2) - 266e-7 * (1 - e / t)) - .005485) / 133e-7;
                                        return n - Math.pow(10, -9) * Math.pow(Math.abs(n), 3.8) * 9.2;
                                    }(this.pncResistanceValue, a);
                                    break;

                                  case "CU":
                                    r = function(t, e) {
                                        if (t <= 0 || e <= 0) throw new Error("阻值输入无效。");
                                        return (e / t - 1) / .00428;
                                    }(this.pncResistanceValue, a);
                                }
                                r = h(r);
                            }
                            this.setData({
                                pncResult: r
                            }), this.use(), this.$nextTick(function() {
                                (0, o.calculatePageScroll)(1e3);
                            });
                        } catch (e) {
                            t.showModal({
                                content: e.message,
                                showCancel: !1
                            });
                        }
                    },
                    ntcTargetChange: function(t) {
                        var e = t.detail.value;
                        this.setData({
                            ntcTargetIndex: e,
                            ntcXUnitRanges: 0 == e ? m : d,
                            ntcXUnitIndex: 0 == e ? 0 : 1
                        });
                    },
                    ntcRefResistInput: function(t) {
                        this.setData({
                            ntcRefResistValue: t.detail.value
                        });
                    },
                    ntcRefResistChange: function(t) {
                        this.setData({
                            ntcRefResistUnitIndex: t.detail.value
                        });
                    },
                    ntcRefTempInput: function(t) {
                        this.setData({
                            ntcRefTempValue: t.detail.value
                        });
                    },
                    ntcRefTempChange: function(t) {
                        this.setData({
                            ntcRefTempUnitIndex: t.detail.value
                        });
                    },
                    ntcBetaInput: function(t) {
                        this.setData({
                            ntcBeta: t.detail.value
                        });
                    },
                    ntcXInput: function(t) {
                        this.setData({
                            ntcXValue: t.detail.value
                        });
                    },
                    ntcXUnitChange: function(t) {
                        this.setData({
                            ntcXUnitIndex: t.detail.value
                        });
                    },
                    ntcCalculate: function() {
                        var e = this.ntcRefResistValue, n = this.ntcRefTempValue, a = this.ntcBeta, i = this.ntcXValue;
                        if (isNaN(e) || isNaN(n) || isNaN(a) || isNaN(i)) t.showModal({
                            content: "输入值不正确。",
                            showCancel: !1
                        }); else {
                            var r, s = this.ntcTargetRanges[this.ntcTargetIndex], o = parseFloat(e), f = parseFloat(n), p = parseFloat(a), d = parseFloat(i), m = this.ntcRefResistUnitRanges[this.ntcRefResistUnitIndex], U = this.ntcRefTempUnitRanges[this.ntcRefTempUnitIndex], v = this.ntcXUnitRanges[this.ntcXUnitIndex];
                            m != c.OhmUnits.O.name && (o = (0, c.ohmConvert)(o, c.OhmUnits.O, m == c.OhmUnits.m.name ? c.OhmUnits.m : c.OhmUnits.k)), 
                            U != u.TemperatureUnit.CELSIUS && (f = (0, u.temperatureConvert)(f, U, u.TemperatureUnit.CELSIUS)), 
                            s.key == l.key ? (v != u.TemperatureUnit.CELSIUS && (d = (0, u.temperatureConvert)(d, v, u.TemperatureUnit.CELSIUS)), 
                            r = function(t, e, n, a) {
                                var i = (0, u.celsius2kelvin)(e), r = (0, u.celsius2kelvin)(a);
                                return Math.pow(2.718281828459045, (1 / r - 1 / i) * n) * t;
                            }(o, f, p, d), r = (0, c.ohmFormat)(r)) : (v != c.OhmUnits.O.name && (o = (0, c.ohmConvert)(rx, c.OhmUnits.O, v == c.OhmUnits.m.name ? c.OhmUnits.m : c.OhmUnits.k)), 
                            r = function(t, e, n, a) {
                                var i = 1 / (Math.log(a / t) * (1 / n) + 1 / (0, u.celsius2kelvin)(e)) - .01510162353515625;
                                return i >= -273.15 ? i : 0;
                            }(o, f, p, d), r = h(r = (0, u.kelvin2celsius)(r))), this.setData({
                                ntcResult: r
                            });
                        }
                    },
                    thrTargetChange: function(t) {
                        var e = t.detail.value;
                        this.setData({
                            thrTargetIndex: e,
                            thrXUnitRanges: 0 == e ? m : U,
                            thrXUnitIndex: 0
                        });
                    },
                    thrTypeChange: function(t) {
                        this.setData({
                            thrTypeIndex: t.detail.value
                        });
                    },
                    thrXUnitChange: function(t) {
                        this.setData({
                            thrXUnitIndex: t.detail.value
                        });
                    },
                    thrXInput: function(t) {
                        this.setData({
                            thrXValue: t.detail.value
                        });
                    },
                    thrCalculate: function() {
                        var e = this.thrXValue;
                        if (isNaN(e)) t.showModal({
                            content: "输入值不正确。",
                            showCancel: !1
                        }); else {
                            var n = this.thrTargetRanges[this.thrTargetIndex], a = this.thrXUnitRanges[this.thrXUnitIndex];
                            n.key == p.key && a != u.TemperatureUnit.CELSIUS && (e = (0, u.temperatureConvert)(e, a, u.TemperatureUnit.CELSIUS));
                            var i = this.thrTypeRanges[this.thrTypeIndex].toLocaleLowerCase(), s = n.key == p.key ? "degc" : "mv";
                            try {
                                var c = r.default.convert(e, {
                                    type: i,
                                    input: s
                                });
                                c = n.key == p.key ? parseFloat(c.toFixed(3)) + " mV" : h(c), this.setData({
                                    thrResult: c
                                }), this.use(), this.$nextTick(function() {
                                    (0, o.calculatePageScroll)(1e3);
                                });
                            } catch (e) {
                                t.showModal({
                                    content: "输入值 ".concat(this.thrXValue, " 不在有效范围。"),
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            e.default = v;
        }).call(this, n("543d").default);
    },
    aff3: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("7269"), i = n("66c2");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("475f");
        var s = n("f0c5"), c = Object(s.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    }
}, [ [ "3ee2", "common/runtime", "common/vendor" ] ] ]);