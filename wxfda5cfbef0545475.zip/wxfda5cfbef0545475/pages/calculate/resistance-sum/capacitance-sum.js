(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/resistance-sum/capacitance-sum" ], {
    "10f3": function(e, n, t) {},
    "2a8c": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return c;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement;
            var e = (this._self._c, this.inputSeriesList.length), n = this.inputParallelList.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    g1: n
                }
            });
        }, i = [];
    },
    "95c2": function(e, n, t) {
        "use strict";
        var a = t("10f3");
        t.n(a).a;
    },
    a047: function(e, n, t) {
        "use strict";
        var a = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = a(t("448a")), i = t("e308"), u = t("1c29"), r = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    units: [ u.capacitanceUnits.F, u.capacitanceUnits.mF, u.capacitanceUnits.uF, u.capacitanceUnits.nF, u.capacitanceUnits.pF ]
                };
            },
            mixins: [ a(t("109e")).default ],
            onLoad: function() {
                this.initFeature("capacitance_sum", i.FeatureType.Calculate), this.setDefaultUnit(2);
            },
            methods: {
                series: function(e) {
                    return e.length > 0 ? u.calculateParallelResistance.apply(void 0, (0, c.default)(e)) : 0;
                },
                parallel: function(e) {
                    return e.length > 0 ? e.reduce(function(e, n) {
                        return e + n;
                    }) : 0;
                }
            }
        };
        n.default = r;
    },
    d3bc3: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var c = a(t("eb82"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(c.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    e8a5: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("a047"), c = t.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        n.default = c.a;
    },
    eb82: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("2a8c"), c = t("e8a5");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(i);
        t("95c2");
        var u = t("f0c5"), r = Object(u.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = r.exports;
    }
}, [ [ "d3bc3", "common/runtime", "common/vendor" ] ] ]);