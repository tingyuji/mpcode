(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/resistance-sum/resistance-sum" ], {
    2030: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("cf8e"), r = t("2e06");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(u);
        t("aa43");
        var i = t("f0c5"), c = Object(i.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = c.exports;
    },
    "2e06": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("ac2a"), r = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = r.a;
    },
    a324: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var r = a(t("2030"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    aa43: function(e, n, t) {
        "use strict";
        var a = t("f7c2");
        t.n(a).a;
    },
    ac2a: function(e, n, t) {
        "use strict";
        var a = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = a(t("448a")), u = t("e308"), i = t("1c29"), c = {
            components: {
                featureBar: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(t("e526"));
                    }.bind(null, t)).catch(t.oe);
                },
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    units: [ i.OhmUnits.m, i.OhmUnits.O, i.OhmUnits.k, i.OhmUnits.M ]
                };
            },
            mixins: [ a(t("109e")).default ],
            onLoad: function() {
                this.initFeature("resistance_sum", u.FeatureType.Calculate), this.setDefaultUnit(1);
            },
            methods: {
                series: function(e) {
                    return e.length > 0 ? e.reduce(function(e, n) {
                        return e + n;
                    }) : 0;
                },
                parallel: function(e) {
                    return e.length > 0 ? i.calculateParallelResistance.apply(void 0, (0, r.default)(e)) : 0;
                }
            }
        };
        n.default = c;
    },
    cf8e: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return u;
        }), t.d(n, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement;
            var e = (this._self._c, this.inputParallelList.length), n = this.inputSeriesList.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    g1: n
                }
            });
        }, u = [];
    },
    f7c2: function(e, n, t) {}
}, [ [ "a324", "common/runtime", "common/vendor" ] ] ]);