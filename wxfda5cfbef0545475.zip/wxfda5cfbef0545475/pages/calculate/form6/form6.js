(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form6/form6" ], {
    "135f": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    1707: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = i(n("035c")), r = i(n("f73d")), l = i(n("3de9")), u = i(n("ed61")), s = n("e308"), o = n("d055"), p = n("0db1"), c = n("fad4"), d = n("00cd"), T = {
                default: [ {
                    option: p.InputTerminal.CURRENT_POWER,
                    label: "电流/功率"
                }, {
                    option: p.InputTerminal.CURRENT_IMPEDANCE,
                    label: "电流/阻抗"
                }, {
                    option: p.InputTerminal.CURRENT_RESISTANCE,
                    label: "电流/电阻"
                }, {
                    option: p.InputTerminal.POWER_IMPEDANCE,
                    label: "功率/阻抗"
                }, {
                    option: p.InputTerminal.POWER_RESISTANCE,
                    label: "功率/电阻"
                } ],
                dc: [ {
                    option: p.InputTerminal.CURRENT_POWER,
                    label: "电流/功率"
                }, {
                    option: p.InputTerminal.CURRENT_RESISTANCE,
                    label: "电流/电阻"
                }, {
                    option: p.InputTerminal.POWER_RESISTANCE,
                    label: "功率/电阻"
                } ]
            }, m = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        defaultPowerUnits: null,
                        inputTerminalIndex: 0,
                        inputTerminal: T.default,
                        currentDisplay: !0,
                        resistanceDisplay: !1,
                        impedanceDisplay: !1,
                        powerDisplay: !0,
                        trigonometricTypeDisplay: !0,
                        result: ""
                    };
                },
                mixins: [ a.default, r.default, l.default, u.default ],
                onLoad: function() {
                    this.defaultPowerUnits = this.powerUnits, this.initFeature("voltage", s.FeatureType.Calculate);
                },
                methods: {
                    changeCurrentType: function(e) {
                        var t = parseInt(e.detail.value);
                        this.currentType[t].option === o.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: T.dc,
                            powerUnitIndex: 0,
                            powerUnits: this.activePowerUnits
                        }), this.handleDisplay()) : this.currentType[this.currentTypeIndex].option === o.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: T.default,
                            powerUnitIndex: 0,
                            powerUnits: this.defaultPowerUnits
                        }), this.handleDisplay()) : this.setData({
                            currentTypeIndex: t
                        }), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value),
                            powerUnitIndex: 0
                        }), this.handleDisplay();
                    },
                    changePowerUnit: function(e) {
                        this.setData({
                            powerUnitIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option, t = this.powerUnits[this.powerUnitIndex].name, n = !1;
                        this.currentTypeIndex > 0 && ([ p.InputTerminal.CURRENT_POWER, p.InputTerminal.POWER_IMPEDANCE ].includes(e) && ![ this.powerAllUnits.VA.name, this.powerAllUnits.kVA.name, this.powerAllUnits.MVA.name ].includes(t) || [ p.InputTerminal.CURRENT_RESISTANCE, p.InputTerminal.POWER_RESISTANCE ].includes(e)) && (n = !0), 
                        this.setData({
                            currentDisplay: [ p.InputTerminal.CURRENT_POWER, p.InputTerminal.CURRENT_IMPEDANCE, p.InputTerminal.CURRENT_RESISTANCE ].includes(e),
                            resistanceDisplay: [ p.InputTerminal.CURRENT_RESISTANCE, p.InputTerminal.POWER_RESISTANCE ].includes(e),
                            impedanceDisplay: [ p.InputTerminal.CURRENT_IMPEDANCE, p.InputTerminal.POWER_IMPEDANCE ].includes(e),
                            powerDisplay: [ p.InputTerminal.CURRENT_POWER, p.InputTerminal.POWER_IMPEDANCE, p.InputTerminal.POWER_RESISTANCE ].includes(e),
                            trigonometricTypeDisplay: n
                        }), n || this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                currentValue: this.getCurrentUnitValue(),
                                impedanceValue: this.getImpedanceUnitValue(),
                                resistanceValue: this.getResistanceUnitValue(),
                                powerValue: this.getPowerUnitValue(),
                                powerType: (0, c.toPowerType)(this.powerUnits[this.powerUnitIndex].name),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, p.calculate)(t);
                            if (isNaN(n)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, d.formatFromUnits)(n, p.VoltageUnits.V, p.VoltageUnits)
                            }), this.use();
                        } catch (t) {
                            if ("∞" === t.message) return void this.setData({
                                result: "∞" + p.VoltageUnits.kV.name
                            });
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = m;
        }).call(this, n("543d").default);
    },
    "2bba": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("1707"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    "8bd2": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("bfc0"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    bfc0: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("135f"), a = n("2bba");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        var l = n("f0c5"), u = Object(l.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = u.exports;
    }
}, [ [ "8bd2", "common/runtime", "common/vendor" ] ] ]);