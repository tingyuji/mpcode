(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form3/form3" ], {
    "107e": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var r = o(n("1675"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    1675: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("f58c"), r = n("42a3");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        var i = n("f0c5"), c = Object(i.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "42a3": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("ea8d"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    ea8d: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = o(n("035c")), a = n("e308"), i = n("2d0b"), c = n("00cd"), u = n("1c29"), s = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ r.default ],
                data: function() {
                    return {
                        form: {
                            code: "",
                            up: !1,
                            down: !1,
                            bs: !1
                        },
                        result: ""
                    };
                },
                onLoad: function() {
                    this.initFeature("smd_resistor_code", a.FeatureType.Calculate);
                },
                methods: {
                    changeSwitch: function(e, t) {
                        this.form[t] = e.detail.value, this.form[t] && ("up" === t ? this.form.down = !1 : "down" === t && (this.form.up = !1));
                    },
                    calculate: function() {
                        if (this.form.code) try {
                            var t = (0, i.calculateCodeResistance)(this.form.code, this.form.up, this.form.down, this.form.bs);
                            console.log(t), t.mistake ? this.result = (0, c.formatFromUnits)(t.resistance, u.OhmUnits.O, u.OhmUnits) + " ± " + t.mistake + " %" : this.result = (0, 
                            c.formatFromUnits)(t.resistance, u.OhmUnits.O, u.OhmUnits), this.use();
                        } catch (t) {
                            e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            }), this.result = "";
                        } else e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        });
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d").default);
    },
    f58c: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, a = [];
    }
}, [ [ "107e", "common/runtime", "common/vendor" ] ] ]);