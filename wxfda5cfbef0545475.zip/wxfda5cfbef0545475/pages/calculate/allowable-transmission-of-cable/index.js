(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/allowable-transmission-of-cable/index" ], {
    2479: function(n, t, e) {
        "use strict";
        (function(n) {
            var i = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = i(e("035c")), o = i(e("0bfc")), l = i(e("fd69")), s = e("e308"), u = e("00cd"), r = e("d417"), c = e("7325"), f = e("9a2b"), d = e("9bc7"), p = {
                components: {
                    featureBar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(e("e526"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    vipMask: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                            return resolve(e("e665"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                mixins: [ a.default, o.default, l.default ],
                data: function() {
                    return {
                        typeOptionIndex: 0,
                        typeOptions: [ "相导体", "保护导体（单极）", "保护导体（多极）" ],
                        allInsulationOptions: [ {
                            option: d.InsulationType.PVC,
                            label: "PVC（聚氯乙烯）"
                        }, {
                            option: d.InsulationType.G2,
                            label: "G2"
                        }, {
                            option: d.InsulationType.XLPE_EPR,
                            label: "XLPE（交联聚乙烯）/EPR（乙丙橡胶）"
                        }, {
                            option: d.InsulationType.BARE_CONDUCTOR,
                            label: "裸导体"
                        } ],
                        result: ""
                    };
                },
                onLoad: function() {
                    this.init(), this.initFeature("allowable_transmission_of_cable", s.FeatureType.Calculate);
                },
                methods: {
                    init: function() {
                        this.cableCoreAreValueOptionIndex = 3, this.insulationOptions = this.allInsulationOptions;
                    },
                    changeAfterCableCoreAreaUnit: function(n) {
                        0 === n && (this.cableCoreAreValueOptionIndex = 3);
                    },
                    changeMaterial: function(n) {
                        this.materialOptionIndex = parseInt(n.detail.value), 0 === this.materialOptionIndex ? this.insulationOptions = this.allInsulationOptions : this.insulationOptions = this.allInsulationOptions.slice(0, 3), 
                        this.insulationOptionIndex = (0, r.keepCurrentIndexOfOptions)(this.insulationOptions[this.insulationOptionIndex], this.insulationOptions, this.insulationOptionIndex);
                    },
                    calculate: function() {
                        try {
                            var t = this.getCableCoreAreValue();
                            "awg" === this.cableCoreAreaUnits[this.cableCoreAreaUnitIndex].label && (t = (0, 
                            c.awg2squareMillieter)(t)), this.result = (0, u.formatDouble)((0, f.calculateAllowableTransmission)(t, this.materialOptionIndex, this.insulationOptionIndex, this.typeOptionIndex), 2), 
                            this.use(), this.$nextTick(function() {
                                (0, r.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            n.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            }), this.result = "";
                        }
                    }
                }
            };
            t.default = p;
        }).call(this, e("543d").default);
    },
    "3bf0": function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("2479"), a = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = a.a;
    },
    7622: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e("8ec0"), a = e("3bf0");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(o);
        var l = e("f0c5"), s = Object(l.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = s.exports;
    },
    "8ec0": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/feature-bar/feature-bar") ]).then(e.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    ab7f: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var i = e("4ea4");
            e("8a42"), i(e("66fd"));
            var a = i(e("7622"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(a.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    }
}, [ [ "ab7f", "common/runtime", "common/vendor" ] ] ]);