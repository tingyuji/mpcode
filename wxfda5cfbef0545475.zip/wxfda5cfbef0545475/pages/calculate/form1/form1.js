(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form1/form1" ], {
    "0079": function(e, t, o) {},
    "476c": function(e, t, o) {
        "use strict";
        o.r(t);
        var r = o("5c8c"), l = o("a7d6");
        for (var n in l) [ "default" ].indexOf(n) < 0 && function(e) {
            o.d(t, e, function() {
                return l[e];
            });
        }(n);
        o("eed1");
        var a = o("f0c5"), i = Object(a.a)(l.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = i.exports;
    },
    "5c8c": function(e, t, o) {
        "use strict";
        o.d(t, "b", function() {
            return l;
        }), o.d(t, "c", function() {
            return n;
        }), o.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ o.e("common/vendor"), o.e("components/feature-bar/feature-bar") ]).then(o.bind(null, "e526"));
            }
        }, l = function() {
            this.$createElement, this._self._c;
        }, n = [];
    },
    a7d6: function(e, t, o) {
        "use strict";
        o.r(t);
        var r = o("bffc"), l = o.n(r);
        for (var n in r) [ "default" ].indexOf(n) < 0 && function(e) {
            o.d(t, e, function() {
                return r[e];
            });
        }(n);
        t.default = l.a;
    },
    bffc: function(e, t, o) {
        "use strict";
        var r = o("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var l = r(o("035c")), n = o("e308"), a = o("1c29"), i = o("6e05"), u = [ i.colors.black, i.colors.brown, i.colors.red, i.colors.orange, i.colors.yellow, i.colors.green, i.colors.blue, i.colors.purple, i.colors.gray, i.colors.white ], c = [ i.colors.black.withValue(1), i.colors.brown.withValue(10), i.colors.red.withValue(100), i.colors.orange.withValue(1e3), i.colors.yellow.withValue(1e4), i.colors.green.withValue(1e5), i.colors.blue.withValue(1e6), i.colors.purple.withValue(1e7), i.colors.gray.withValue(1e8), i.colors.white.withValue(1e9), i.colors.gold.withValue(.1), i.colors.silver.withValue(.01) ], s = [ i.colors.brown.withValue(1), i.colors.red.withValue(2), i.colors.orange.withValue(3), i.colors.green.withValue(.5), i.colors.blue.withValue(.25), i.colors.purple.withValue(.1), i.colors.gray.withValue(.05), i.colors.gold.withValue(5), i.colors.silver.withValue(10), i.colors.none.withValue(20) ], h = [ i.colors.black.withValue(250), i.colors.brown.withValue(100), i.colors.red.withValue(50), i.colors.orange.withValue(15), i.colors.yellow.withValue(25), i.colors.green.withValue(20), i.colors.blue.withValue(10), i.colors.purple.withValue(5), i.colors.gray.withValue(1), i.colors.none.withValue(0) ], f = {
            components: {
                featureBar: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(o("e526"));
                    }.bind(null, o)).catch(o.oe);
                },
                vipMask: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/vip/vip") ]).then(function() {
                        return resolve(o("e665"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            data: function() {
                return {
                    rings: [],
                    ringsCount: 4,
                    indexes: [],
                    roll: null,
                    result: "",
                    used: !1,
                    feature: {},
                    color: "",
                    name: "",
                    colors: [],
                    m: "",
                    vipRequired: !1
                };
            },
            mixins: [ l.default ],
            onLoad: function() {
                this.initFeature("color_ring_resistance", n.FeatureType.Calculate), this.switchRingLength(4);
            },
            methods: {
                onRingChange: function(e) {
                    var t = e.detail.value, o = e.currentTarget.dataset.index;
                    this.$set(this.indexes, o, t[0]);
                    var r = this.rings, l = this.indexes, n = [], i = 0, u = 0, c = "";
                    4 == r.length || 5 == r.length ? (n = l.slice(0, -2), i = r[r.length - 2][l[l.length - 2]].value, 
                    u = r[r.length - 1][l[l.length - 1]].value) : 3 == r.length ? (n = l.slice(0, 2), 
                    i = r[2][l[2]].value, u = 20) : (n = l.slice(0, 3), i = r[3][l[3]].value, u = r[4][l[4]].value, 
                    c = "\n" + r[5][l[5]].value + " ppm");
                    var s = 0;
                    n.forEach(function(e, t) {
                        var o = n.length - t - 1;
                        s += o > 0 ? e * Math.pow(10, o) : e;
                    }), i > 0 && (s *= i), this.setData({
                        result: (0, a.ohmFormat)(s) + " ± " + u + " %" + c
                    }), this.used || (this.use(), this.used = !0);
                },
                onRingStart: function(e) {
                    this.setData({
                        roll: e.currentTarget.dataset.index
                    });
                },
                onRingStop: function(e) {
                    this.setData({
                        roll: null
                    });
                },
                switchRings: function(e) {
                    var t = parseInt(e.currentTarget.dataset.rings);
                    this.switchRingLength(t);
                },
                switchRingLength: function(e) {
                    var t = [];
                    4 == e ? t = [ u, u, c, s.slice(-3) ] : 5 == e ? t = [ u, u, u, c, s ] : 6 == e ? t = [ u, u, u, c, s, h ] : 3 == e && (t = [ u, u, c ]), 
                    this.setData({
                        rings: t,
                        ringsCount: t.length,
                        indexes: Array(e).fill(0),
                        result: ""
                    }), this.used = !1;
                }
            }
        };
        t.default = f;
    },
    cff7: function(e, t, o) {
        "use strict";
        (function(e, t) {
            var r = o("4ea4");
            o("8a42"), r(o("66fd"));
            var l = r(o("476c"));
            e.__webpack_require_UNI_MP_PLUGIN__ = o, t(l.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    },
    eed1: function(e, t, o) {
        "use strict";
        var r = o("0079");
        o.n(r).a;
    }
}, [ [ "cff7", "common/runtime", "common/vendor" ] ] ]);