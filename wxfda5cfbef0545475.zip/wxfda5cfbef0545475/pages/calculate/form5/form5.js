(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form5/form5" ], {
    "04e3": function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = i(n("035c")), r = i(n("f73d")), l = i(n("3de9")), u = i(n("ed61")), s = n("e308"), o = n("d055"), p = n("00cd"), c = n("fad4"), d = {
                default: [ {
                    option: o.InputTerminal.VOLTAGE_POWER,
                    label: "电压/功率"
                }, {
                    option: o.InputTerminal.VOLTAGE_IMPEDANCE,
                    label: "电压/阻抗"
                }, {
                    option: o.InputTerminal.VOLTAGE_RESISTANCE,
                    label: "电压/电阻"
                }, {
                    option: o.InputTerminal.POWER_IMPEDANCE,
                    label: "功率/阻抗"
                }, {
                    option: o.InputTerminal.POWER_RESISTANCE,
                    label: "功率/电阻"
                } ],
                dc: [ {
                    option: o.InputTerminal.VOLTAGE_POWER,
                    label: "电压/功率"
                }, {
                    option: o.InputTerminal.VOLTAGE_RESISTANCE,
                    label: "电压/电阻"
                }, {
                    option: o.InputTerminal.POWER_RESISTANCE,
                    label: "功率/电阻"
                } ]
            }, T = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        defaultPowerUnits: null,
                        inputTerminalIndex: 0,
                        inputTerminal: d.default,
                        voltageDisplay: !0,
                        resistanceDisplay: !1,
                        impedanceDisplay: !1,
                        powerDisplay: !0,
                        trigonometricTypeDisplay: !0,
                        result: ""
                    };
                },
                mixins: [ a.default, r.default, l.default, u.default ],
                onLoad: function() {
                    this.defaultPowerUnits = this.powerUnits, this.initFeature("current", s.FeatureType.Calculate);
                },
                methods: {
                    changeCurrentType: function(e) {
                        var t = parseInt(e.detail.value);
                        this.currentType[t].option === o.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: d.dc,
                            powerUnitIndex: 0,
                            powerUnits: this.activePowerUnits
                        }), this.handleDisplay()) : this.currentType[this.currentTypeIndex].option === o.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: d.default,
                            powerUnitIndex: 0,
                            powerUnits: this.defaultPowerUnits
                        }), this.handleDisplay()) : this.setData({
                            currentTypeIndex: t
                        }), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value),
                            powerUnitIndex: 0
                        }), this.handleDisplay();
                    },
                    changePowerUnit: function(e) {
                        this.setData({
                            powerUnitIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option, t = this.powerUnits[this.powerUnitIndex].name, n = !1;
                        this.currentTypeIndex > 0 && ([ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.POWER_IMPEDANCE ].includes(e) && ![ this.powerAllUnits.VA.name, this.powerAllUnits.kVA.name, this.powerAllUnits.MVA.name ].includes(t) || [ o.InputTerminal.VOLTAGE_RESISTANCE ].includes(e) || [ o.InputTerminal.POWER_RESISTANCE ].includes(e) && ![ this.powerAllUnits.W.name, this.powerAllUnits.kW.name, this.powerAllUnits.MW.name, this.powerAllUnits.HP.name ].includes(t)) && (n = !0), 
                        this.setData({
                            voltageDisplay: [ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.VOLTAGE_IMPEDANCE, o.InputTerminal.VOLTAGE_RESISTANCE ].includes(e),
                            resistanceDisplay: [ o.InputTerminal.VOLTAGE_RESISTANCE, o.InputTerminal.POWER_RESISTANCE ].includes(e),
                            impedanceDisplay: [ o.InputTerminal.VOLTAGE_IMPEDANCE, o.InputTerminal.POWER_IMPEDANCE ].includes(e),
                            powerDisplay: [ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.POWER_IMPEDANCE, o.InputTerminal.POWER_RESISTANCE ].includes(e),
                            trigonometricTypeDisplay: n
                        }), n || this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                voltageValue: this.getVoltageUnitValue(),
                                impedanceValue: this.getImpedanceUnitValue(),
                                resistanceValue: this.getResistanceUnitValue(),
                                powerValue: this.getPowerUnitValue(),
                                powerType: (0, c.toPowerType)(this.powerUnits[this.powerUnitIndex].name),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, o.calculate)(t);
                            if (isNaN(n)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, p.formatFromUnits)(n, o.CurrentUnits.A, o.CurrentUnits)
                            }), this.use();
                        } catch (t) {
                            if ("∞" === t.message) return void this.setData({
                                result: "∞" + o.CurrentUnits.kA.name
                            });
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = T;
        }).call(this, n("543d").default);
    },
    2315: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    "8fe2": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("04e3"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    fd1d: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("2315"), a = n("8fe2");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        var l = n("f0c5"), u = Object(l.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = u.exports;
    },
    ffdc: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("fd1d"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "ffdc", "common/runtime", "common/vendor" ] ] ]);