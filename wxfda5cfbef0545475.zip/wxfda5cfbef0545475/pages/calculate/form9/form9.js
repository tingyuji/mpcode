(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form9/form9" ], {
    "4f27": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("69fc"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "69fc": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("cb2d"), i = n("af05");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        var l = n("f0c5"), u = Object(l.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = u.exports;
    },
    a3dc: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = a(n("035c")), r = a(n("f73d")), l = a(n("3de9")), u = a(n("ed61")), o = n("2c16"), s = n("fad4"), p = n("00cd"), c = n("d055"), T = n("e308"), E = {
                default: [ {
                    option: s.InputTerminal.VOLTAGE_CURRENT,
                    label: "电压/电流"
                }, {
                    option: s.InputTerminal.VOLTAGE_IMPEDANCE,
                    label: "电压/阻抗"
                }, {
                    option: s.InputTerminal.VOLTAGE_RESISTANCE,
                    label: "电压/电阻"
                }, {
                    option: s.InputTerminal.CURRENT_IMPEDANCE,
                    label: "电流/阻抗"
                }, {
                    option: s.InputTerminal.CURRENT_RESISTANCE,
                    label: "电流/电阻"
                }, {
                    option: s.InputTerminal.APPARENT_REACTIVE,
                    label: "视在功率/无功功率"
                }, {
                    option: s.InputTerminal.APPARENT_POWER,
                    label: "视在功率"
                }, {
                    option: s.InputTerminal.REACTIVE_POWER,
                    label: "无功功率"
                } ],
                dc: [ {
                    option: s.InputTerminal.VOLTAGE_CURRENT,
                    label: "电压/电流"
                }, {
                    option: s.InputTerminal.VOLTAGE_RESISTANCE,
                    label: "电压/电阻"
                }, {
                    option: s.InputTerminal.CURRENT_RESISTANCE,
                    label: "电流/电阻"
                } ]
            }, d = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        inputTerminalIndex: 0,
                        inputTerminal: E.default,
                        voltageDisplay: !0,
                        currentDisplay: !0,
                        resistanceDisplay: !1,
                        impedanceDisplay: !1,
                        apparentPowerDisplay: !1,
                        reactivePowerDisplay: !1,
                        trigonometricTypeDisplay: !0,
                        result: ""
                    };
                },
                mixins: [ i.default, r.default, l.default, u.default ],
                onLoad: function() {
                    this.initFeature("power_active", T.FeatureType.Calculate);
                },
                methods: {
                    changeCurrentType: function(e) {
                        var t = parseInt(e.detail.value);
                        this.currentType[t].option === c.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: E.dc
                        }), this.handleDisplay()) : this.currentType[this.currentTypeIndex].option === c.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: E.default
                        }), this.handleDisplay()) : this.setData({
                            currentTypeIndex: t
                        }), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option, t = !1;
                        this.currentTypeIndex > 0 && [ s.InputTerminal.VOLTAGE_CURRENT, s.InputTerminal.VOLTAGE_IMPEDANCE, s.InputTerminal.VOLTAGE_RESISTANCE, s.InputTerminal.CURRENT_IMPEDANCE, s.InputTerminal.APPARENT_POWER, s.InputTerminal.REACTIVE_POWER ].includes(e) && (t = !0), 
                        this.setData({
                            voltageDisplay: [ s.InputTerminal.VOLTAGE_CURRENT, s.InputTerminal.VOLTAGE_IMPEDANCE, s.InputTerminal.VOLTAGE_RESISTANCE ].includes(e),
                            currentDisplay: [ s.InputTerminal.VOLTAGE_CURRENT, s.InputTerminal.CURRENT_IMPEDANCE, s.InputTerminal.CURRENT_RESISTANCE ].includes(e),
                            resistanceDisplay: [ s.InputTerminal.VOLTAGE_RESISTANCE, s.InputTerminal.CURRENT_RESISTANCE ].includes(e),
                            impedanceDisplay: [ s.InputTerminal.VOLTAGE_IMPEDANCE, s.InputTerminal.CURRENT_IMPEDANCE ].includes(e),
                            apparentPowerDisplay: [ s.InputTerminal.APPARENT_REACTIVE, s.InputTerminal.APPARENT_POWER ].includes(e),
                            reactivePowerDisplay: [ s.InputTerminal.APPARENT_REACTIVE, s.InputTerminal.REACTIVE_POWER ].includes(e),
                            trigonometricTypeDisplay: t
                        }), t || this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                voltageValue: this.getVoltageUnitValue(),
                                currentValue: this.getCurrentUnitValue(),
                                impedanceValue: this.getImpedanceUnitValue(),
                                resistanceValue: this.getResistanceUnitValue(),
                                apparentPowerValue: this.getApparentPowerUnitValue(),
                                reactivePowerValue: this.getReactivePowerUnitValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, o.calculate)(t);
                            if (isNaN(n)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, p.formatFromUnits)(n, s.ActivePowerUnits.W, s.ActivePowerUnits)
                            }), this.use();
                        } catch (t) {
                            if ("∞" === t.message) return void this.setData({
                                result: "∞" + s.ActivePowerUnits.kW.name
                            });
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = d;
        }).call(this, n("543d").default);
    },
    af05: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("a3dc"), i = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = i.a;
    },
    cb2d: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    }
}, [ [ "4f27", "common/runtime", "common/vendor" ] ] ]);