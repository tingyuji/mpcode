(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form17/form17" ], {
    "038d": function(e, t, n) {},
    "0914": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var s = i(n("41d8"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(s.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "2c6f": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return s;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, s = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    "41d8": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("2c6f"), s = n("b5f1");
        for (var o in s) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(o);
        n("9a89");
        var a = n("f0c5"), r = Object(a.a)(s.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = r.exports;
    },
    5338: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s = i(n("035c")), o = i(n("0bfc")), a = n("9912"), r = n("e308"), c = n("00cd"), u = n("d417"), d = n("d055"), p = n("b461"), l = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ s.default, o.default ],
                data: function() {
                    return {
                        widthOptions: [],
                        widthOptionIndex: 0,
                        widthValue: void 0,
                        thicknessOptions: [],
                        thicknessOptionIndex: 0,
                        thicknessValue: void 0,
                        spaceOptions: [],
                        spaceOptionIndex: 0,
                        spaceValue: void 0,
                        currentTypeOptionIndex: 1,
                        currentTypeOptions: [ "直流电流", "交流电流" ],
                        temperatureOptionIndex: 5,
                        temperatureOptions: [ "20°C (68°F)", "25°C (77°F)", "30°C (86°F)", "35°C (95°F)", "40°C (104°F)", "45°C (113°F)", "50°C (122°F)", "55°C (131°F)", "60°C (140°F)", "65°C (149°F)", "70°C (158°F)", "75°C (167°F)", "80°C (176°F)", "85°C (185°F)", "90°C (194°F)", "95°C (203°F)", "100°C (212°F)" ],
                        excessTemperatureOptionIndex: 0,
                        excessTemperatureOptions: [ "30°C (86°F)", "35°C (95°F)", "40°C (104°F)", "45°C (113°F)", "50°C (122°F)" ],
                        ventilateOptionIndex: 0,
                        ventilateOptions: [ "内部-不透气", "内部-透气", "外部-正常通风" ],
                        positionOptionIndex: 0,
                        positionOptions: [ "垂直", "横" ],
                        shapeOptionIndex: 0,
                        shapeOptions: [ "扁排", "圆", "方" ],
                        surfaceOptionIndex: 0,
                        surfaceOptions: [ "粗糙", "漆黑" ],
                        result: ""
                    };
                },
                onLoad: function() {
                    this.init(), this.initFeature("carrying_capacity_of_master_conductor", r.FeatureType.Calculate);
                },
                methods: {
                    init: function() {
                        this.widthOptions = [ a.MeasuringUnits.mm, a.MeasuringUnits.in ], this.thicknessOptions = [ a.MeasuringUnits.mm, a.MeasuringUnits.in ], 
                        this.spaceOptions = [ a.MeasuringUnits.mm, a.MeasuringUnits.in ], this.conductorOptions = this.conductorOptions.slice(0, this.conductorOptions.length - 1);
                    },
                    changeConductor: function(e) {
                        this.conductorOptionIndex = parseInt(e.detail.value), this.conductorOptionIndex > 0 && (this.spaceValue = this.thicknessValue);
                    },
                    calculate: function() {
                        if ((0, u.isVoidNumber)(this.widthValue) || (0, u.isVoidNumber)(this.thicknessValue) || this.conductorOptionIndex > 0 && (0, 
                        u.isVoidNumber)(this.spaceValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t = {
                                width: (0, c.unitConvert)(this.widthValue, this.widthOptions[this.widthOptionIndex], a.MeasuringUnits.cm),
                                thickness: (0, c.unitConvert)(this.thicknessValue, this.thicknessOptions[this.thicknessOptionIndex], a.MeasuringUnits.cm),
                                material: this.materialOptions[this.materialOptionIndex],
                                currentTypeIndex: parseInt(this.currentTypeOptionIndex),
                                parallelIndex: parseInt(this.conductorOptionIndex),
                                parallel: this.conductorOptions[this.conductorOptionIndex],
                                space: (0, c.unitConvert)(this.spaceValue, this.spaceOptions[this.spaceOptionIndex], a.MeasuringUnits.cm),
                                temperatureIndex: parseInt(this.temperatureOptionIndex),
                                excessTemperatureIndex: parseInt(this.excessTemperatureOptionIndex),
                                ventilateIndex: parseInt(this.ventilateOptionIndex),
                                positionIndex: parseInt(this.positionOptionIndex),
                                shapeIndex: parseInt(this.shapeOptionIndex),
                                surfaceIndex: parseInt(this.surfaceOptionIndex)
                            };
                            console.log(t);
                            try {
                                var n = (0, p.calculate)(t.width, t.thickness, t.material, t.currentTypeIndex, t.parallelIndex, t.space, t.temperatureIndex, t.excessTemperatureIndex, t.ventilateIndex, t.positionIndex, t.shapeIndex, t.surfaceIndex);
                                this.result = n > 0 ? (0, c.unitFormatTo)(n, d.CurrentUnits.A, d.CurrentUnits.A) : "-", 
                                this.use(), this.$nextTick(function() {
                                    (0, u.calculatePageScroll)(1e3);
                                });
                            } catch (t) {
                                e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                }), this.result = "";
                            }
                        }
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    "9a89": function(e, t, n) {
        "use strict";
        var i = n("038d");
        n.n(i).a;
    },
    b5f1: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("5338"), s = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        t.default = s.a;
    }
}, [ [ "0914", "common/runtime", "common/vendor" ] ] ]);