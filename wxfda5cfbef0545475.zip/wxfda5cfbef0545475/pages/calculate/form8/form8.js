(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form8/form8" ], {
    "53ca": function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("566d"), r = a("e31c");
        for (var l in r) [ "default" ].indexOf(l) < 0 && function(e) {
            a.d(t, e, function() {
                return r[e];
            });
        }(l);
        a("cde2");
        var o = a("f0c5"), u = Object(o.a)(r.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = u.exports;
    },
    "566d": function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return r;
        }), a.d(t, "c", function() {
            return l;
        }), a.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, l = [];
    },
    "71a0": function(e, t, a) {
        "use strict";
        (function(e) {
            var n = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n(a("035c")), l = n(a("0bfc")), o = n(a("8760")), u = n(a("3de9")), i = n(a("f73d")), c = n(a("ed61")), s = a("e308"), f = a("9a2b"), d = a("00cd"), h = a("9912"), m = a("7325"), g = a("d417"), b = {
                components: {
                    featureBar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(a("e526"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    vipMask: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                            return resolve(a("e665"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        cableLength: null
                    };
                },
                mixins: [ r.default, l.default, o.default, u.default, i.default, c.default ],
                onLoad: function() {
                    this.initFeature("maximum_cable_length", s.FeatureType.Calculate);
                },
                onShow: function() {
                    this.setData({
                        temperatureUnitValue: 80
                    });
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.setData({
                            currentTypeIndex: parseInt(e.detail.value)
                        }), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        if ((0, g.isVoidNumber)(this.voltageUnitValue) || (0, g.isVoidNumber)(this.loadUnitValue) || (0, 
                        g.isVoidNumber)(this.voltageDropValue) || (0, g.isVoidNumber)(this.temperatureUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                currentType: this.getCurrentType(),
                                voltageValue: this.getVoltageUnitValue(),
                                voltageDropValue: this.getVoltageDropValue(),
                                temperature: this.getTemperatureUnitValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, a = this.getCableCoreAreaCollection(1, t.temperature, t.currentType), n = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection), r = (0, 
                            f.calculateMaximumCableLength)(t.currentType, n, t.voltageValue, a.resistance, a.reactance, t.voltageDropValue, t.triangleCollection), l = this.getCableCoreAreValue();
                            "awg" === this.cableCoreAreaUnits[this.cableCoreAreaUnitIndex].label && (l = (0, 
                            m.awg2squareMillieter)(l)), 11.2 * Math.pow(l, .6118) < n && e.showModal({
                                title: "注意！",
                                content: "检验电缆容量是否足以与所选负载匹配",
                                showCancel: !1
                            }), this.setData({
                                cableLength: {
                                    m: (0, d.formatDouble)(1e3 * r, 2),
                                    ft: (0, d.formatDouble)(1e3 * r / h.MeasuringUnits.ft.mul, 2)
                                }
                            }), this.use(), this.$nextTick(function() {
                                (0, g.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.setData({
                                cableLength: null
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = b;
        }).call(this, a("543d").default);
    },
    "7b91": function(e, t, a) {
        "use strict";
        (function(e, t) {
            var n = a("4ea4");
            a("8a42"), n(a("66fd"));
            var r = n(a("53ca"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, t(r.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    "9cd9": function(e, t, a) {},
    cde2: function(e, t, a) {
        "use strict";
        var n = a("9cd9");
        a.n(n).a;
    },
    e31c: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("71a0"), r = a.n(n);
        for (var l in n) [ "default" ].indexOf(l) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(l);
        t.default = r.a;
    }
}, [ [ "7b91", "common/runtime", "common/vendor" ] ] ]);