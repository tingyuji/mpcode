(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form27/form27" ], {
    "02fb": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("32fc"), i = r("96d0");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            r.d(t, e, function() {
                return i[e];
            });
        }(a);
        r("29e1");
        var o = r("f0c5"), c = Object(o.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = c.exports;
    },
    "29e1": function(e, t, r) {
        "use strict";
        var n = r("d7e8");
        r.n(n).a;
    },
    "32fc": function(e, t, r) {
        "use strict";
        r.d(t, "b", function() {
            return i;
        }), r.d(t, "c", function() {
            return a;
        }), r.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ r.e("common/vendor"), r.e("components/feature-bar/feature-bar") ]).then(r.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    7013: function(e, t, r) {
        "use strict";
        (function(e, t) {
            var n = r("4ea4");
            r("8a42"), n(r("66fd"));
            var i = n(r("02fb"));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, t(i.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    "747b": function(e, t, r) {
        "use strict";
        (function(e) {
            var n = r("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(r("035c")), a = r("e308"), o = r("d417"), c = r("00cd"), u = r("d055"), s = r("1c29"), l = {
                components: {
                    featureBar: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(r("e526"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    vipMask: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/vip/vip") ]).then(function() {
                            return resolve(r("e665"));
                        }.bind(null, r)).catch(r.oe);
                    }
                },
                data: function() {
                    return {
                        calculateOptionIndex: 0,
                        calculateOptions: [ "I", "I1", "I2", "R1", "R2" ],
                        currentOptionIndex: 0,
                        currentOptions: [ "I1", "I2" ],
                        currentOptionValue: void 0,
                        currentValue: void 0,
                        currentOneValue: void 0,
                        currentTwoValue: void 0,
                        resistanceOneValue: void 0,
                        resistanceTwoValue: void 0,
                        currentOptionDisplay: !0,
                        currentDisplay: !1,
                        currentOneDisplay: !1,
                        currentTwoDisplay: !1,
                        resistanceOneDisplay: !0,
                        resistanceTwoDisplay: !0,
                        result: ""
                    };
                },
                mixins: [ i.default ],
                onLoad: function() {
                    this.initFeature("current_shunt", a.FeatureType.Calculate);
                },
                methods: {
                    changeCalculateOption: function(e) {
                        this.setData({
                            calculateOptionIndex: parseInt(e.detail.value),
                            currentOptionIndex: 0
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.calculateOptions[this.calculateOptionIndex];
                        this.setData({
                            currentOptionDisplay: [ "I" ].includes(e),
                            currentDisplay: [ "I1", "I2", "R1", "R2" ].includes(e),
                            currentOneDisplay: [ "R2" ].includes(e),
                            currentTwoDisplay: [ "R1" ].includes(e),
                            resistanceOneDisplay: [ "I", "I1", "I2", "R2" ].includes(e),
                            resistanceTwoDisplay: [ "I", "I1", "I2", "R1" ].includes(e)
                        });
                    },
                    calculate: function() {
                        var t = this.calculateOptions[this.calculateOptionIndex];
                        try {
                            switch (t) {
                              case "I":
                                this.calculateCurrentOption(t, this.currentOptionValue, this.resistanceOneValue, this.resistanceTwoValue);
                                break;

                              case "I1":
                              case "I2":
                                this.calculateCurrent(t, this.currentValue, this.resistanceOneValue, this.resistanceTwoValue);
                                break;

                              case "R1":
                                this.calculateResistanceOne(t, this.currentValue, this.currentTwoValue, this.resistanceTwoValue);
                                break;

                              case "R2":
                                this.calculateResistanceTwo(t, this.currentValue, this.currentOneValue, this.resistanceOneValue);
                            }
                            this.use();
                        } catch (t) {
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    },
                    calculateCurrentOption: function(e, t, r, n) {
                        if ((0, o.isVoidNumber)(t) || (0, o.isVoidNumber)(r) || (0, o.isVoidNumber)(n)) throw new Error("请输入所有参数");
                        var i, a = this.currentOptions[this.currentOptionIndex];
                        if (!(0, o.isNonzeroNumber)(t)) throw new Error("无效参数：".concat(a, " = 0"));
                        if (!(0, o.isNonzeroNumber)(r)) throw new Error("无效参数：R1 = 0");
                        if (!(0, o.isNonzeroNumber)(n)) throw new Error("无效参数：R2 = 0");
                        i = "I1" === a ? (0, c.formatDouble)(t * (r + n) / n, 3) : (0, c.formatDouble)(t * (r + n) / r, 3), 
                        this.setData({
                            result: "".concat(e, " = ").concat(i, " ").concat(u.CurrentUnits.A.name)
                        });
                    },
                    calculateCurrent: function(e, t, r, n) {
                        if ((0, o.isVoidNumber)(t) || (0, o.isVoidNumber)(r) || (0, o.isVoidNumber)(n)) throw new Error("请输入所有参数");
                        if (!(0, o.isNonzeroNumber)(t)) throw new Error("无效参数：I = 0");
                        if (!(0, o.isNonzeroNumber)(r)) throw new Error("无效参数：R1 = 0");
                        if (!(0, o.isNonzeroNumber)(n)) throw new Error("无效参数：R2 = 0");
                        var i;
                        i = "I1" === e ? (0, c.formatDouble)(t * n / (r + n), 3) : (0, c.formatDouble)(t * r / (r + n), 3), 
                        this.setData({
                            result: "".concat(e, " = ").concat(i, " ").concat(u.CurrentUnits.A.name)
                        });
                    },
                    calculateResistanceOne: function(e, t, r, n) {
                        if ((0, o.isVoidNumber)(t) || (0, o.isVoidNumber)(r) || (0, o.isVoidNumber)(n)) throw new Error("请输入所有参数");
                        if (!(0, o.isNonzeroNumber)(t)) throw new Error("无效参数：I = 0");
                        if (!(0, o.isNonzeroNumber)(r)) throw new Error("无效参数：I2 = 0");
                        if (!(0, o.isNonzeroNumber)(n)) throw new Error("无效参数：R2 = 0");
                        var i;
                        i = t === r ? "∞" : (0, c.formatDouble)(r * n / (t - r), 3), this.setData({
                            result: "".concat(e, " = ").concat(i, " ").concat(s.OhmUnits.O.name)
                        });
                    },
                    calculateResistanceTwo: function(e, t, r, n) {
                        if ((0, o.isVoidNumber)(t) || (0, o.isVoidNumber)(r) || (0, o.isVoidNumber)(n)) throw new Error("请输入所有参数");
                        if (!(0, o.isNonzeroNumber)(t)) throw new Error("无效参数：I = 0");
                        if (!(0, o.isNonzeroNumber)(r)) throw new Error("无效参数：I1 = 0");
                        if (!(0, o.isNonzeroNumber)(n)) throw new Error("无效参数：R1 = 0");
                        var i;
                        i = t === r ? "∞" : (0, c.formatDouble)(r * n / (t - r), 3), this.setData({
                            result: "".concat(e, " = ").concat(i, " ").concat(s.OhmUnits.O.name)
                        });
                    }
                }
            };
            t.default = l;
        }).call(this, r("543d").default);
    },
    "96d0": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("747b"), i = r.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(a);
        t.default = i.a;
    },
    d7e8: function(e, t, r) {}
}, [ [ "7013", "common/runtime", "common/vendor" ] ] ]);