(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form25/form25" ], {
    "167a": function(n, e, a) {
        "use strict";
        a.r(e);
        var t = a("75ba"), c = a.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(n) {
            a.d(e, n, function() {
                return t[n];
            });
        }(i);
        e.default = c.a;
    },
    "245a": function(n, e, a) {
        "use strict";
        var t = a("8191");
        a.n(t).a;
    },
    "3f6c": function(n, e, a) {
        "use strict";
        (function(n, e) {
            var t = a("4ea4");
            a("8a42"), t(a("66fd"));
            var c = t(a("715e"));
            n.__webpack_require_UNI_MP_PLUGIN__ = a, e(c.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    "4fc7": function(n, e, a) {
        "use strict";
        a.d(e, "b", function() {
            return c;
        }), a.d(e, "c", function() {
            return i;
        }), a.d(e, "a", function() {
            return t;
        });
        var t = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "715e": function(n, e, a) {
        "use strict";
        a.r(e);
        var t = a("4fc7"), c = a("167a");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(n) {
            a.d(e, n, function() {
                return c[n];
            });
        }(i);
        a("245a");
        var u = a("f0c5"), r = Object(u.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = r.exports;
    },
    "75ba": function(n, e, a) {
        "use strict";
        var t = a("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = t(a("035c")), i = a("e308"), u = a("5ce9"), r = a("1c29"), o = {
            components: {
                featureBar: function() {
                    Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(a("e526"));
                    }.bind(null, a)).catch(a.oe);
                },
                vipMask: function() {
                    Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                        return resolve(a("e665"));
                    }.bind(null, a)).catch(a.oe);
                }
            },
            data: function() {
                return {
                    capacitanceUnitIndex: 2,
                    capacitanceUnitRanges: [ r.capacitanceUnits.pF, r.capacitanceUnits.nF, r.capacitanceUnits.uF, r.capacitanceUnits.F ],
                    capacitanceValue: "",
                    inductanceUnitIndex: 1,
                    inductanceUnitRanges: [ r.inductanceUnits.uH, r.inductanceUnits.mH, r.inductanceUnits.H ],
                    inductanceValue: "",
                    result: ""
                };
            },
            mixins: [ c.default ],
            onLoad: function() {
                this.initFeature("lc_resonance_frequency", i.FeatureType.Calculate);
            },
            methods: {
                inductanceChange: function(n) {
                    this.setData({
                        inductanceUnitIndex: n.detail.value
                    });
                },
                inductanceInput: function(n) {
                    this.setData({
                        inductanceValue: n.detail.value
                    });
                },
                capacitanceChange: function(n) {
                    this.setData({
                        capacitanceUnitIndex: n.detail.value
                    });
                },
                capacitanceInput: function(n) {
                    this.setData({
                        capacitanceValue: n.detail.value
                    });
                },
                calculate: function() {
                    var n = this;
                    if (!this.checkNaN(n.capacitanceValue, n.inductanceValue)) {
                        var e = n.inductanceUnitRanges[n.inductanceUnitIndex], a = n.inductanceValue;
                        1 != e.mul && (a *= e.mul);
                        var t = n.capacitanceUnitRanges[n.capacitanceUnitIndex], c = n.capacitanceValue;
                        1 != r.capacitanceUnits.mul && (c *= t.mul);
                        var i = 1 / (2 * Math.PI * Math.sqrt(c * a));
                        this.setData({
                            result: (0, u.hzFormat)(i)
                        }), this.use();
                    }
                }
            }
        };
        e.default = o;
    },
    8191: function(n, e, a) {}
}, [ [ "3f6c", "common/runtime", "common/vendor" ] ] ]);