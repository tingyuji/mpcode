(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form16/form16" ], {
    "0c6d": function(t, e, i) {
        "use strict";
        (function(t, e) {
            var n = i("4ea4");
            i("8a42"), n(i("66fd"));
            var a = n(i("9530"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, e(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    "1fb1": function(t, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return a;
        }), i.d(e, "c", function() {
            return o;
        }), i.d(e, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(i.bind(null, "e526"));
            },
            layingMode: function() {
                return i.e("components/laying-mode/laying-mode").then(i.bind(null, "9f3d"));
            }
        }, a = function() {
            this.$createElement;
            var t = (this._self._c, this.currentElectricalSpecification === this.electricalSpecifications.IEC ? this.cableCoreAreaOptions.length : null);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, o = [];
    },
    "39a3": function(t, e, i) {
        "use strict";
        (function(t) {
            var n = i("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n(i("035c")), o = n(i("0bfc")), r = n(i("9108")), c = i("e308"), l = i("9bc7"), s = i("83af"), u = i("00cd"), d = i("d055"), p = i("d417"), h = {
                components: {
                    featureBar: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(i("e526"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    vipMask: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                            return resolve(i("e665"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    LayingMode: function() {
                        i.e("components/laying-mode/laying-mode").then(function() {
                            return resolve(i("9f3d"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                mixins: [ a.default, o.default, r.default ],
                data: function() {
                    return {
                        typeOptions: [ {
                            option: s.BearTypes.CONTACT,
                            label: "接触"
                        }, {
                            option: s.BearTypes.CONTACTLESS,
                            label: "不接触"
                        } ],
                        typeOptionIndex: 0,
                        pipeCircuitDisabled: !1,
                        result: ""
                    };
                },
                onLoad: function() {
                    this.initFeature("carrying_capacity_of_bear_conductor", c.FeatureType.Calculate);
                },
                methods: {
                    init: function() {
                        this.currentElectricalSpecification === l.ElectricalSpecifications.IEC ? (this.handleCableCoreAre(this.materialOptions[this.materialOptionIndex].label), 
                        this.handleTemperatureAmbient(this.typeOptions[this.typeOptionIndex].option)) : (this.setLayingMode(), 
                        this.handleCableCoreAre(this.materialOptions[this.materialOptionIndex].label), this.handleTemperatureAmbient(this.typeOptions[this.typeOptionIndex].option));
                    },
                    onTab: function(t) {
                        var e = t.currentTarget.dataset.type;
                        e !== this.currentElectricalSpecification && (this.currentElectricalSpecification = e, 
                        this.materialOptionIndex = 0, this.conductorOptionIndex = 0, this.pipeCircuitIndex = 0, 
                        this.totalConductorOptionIndex = 0, this.typeOptionIndex = 0, this.pipeCircuitDisabled = !1, 
                        this.result = "", this.init());
                    },
                    listenerLayingMode: function(t) {
                        this.layingMode = t.detail, this.result = "", this.init();
                    },
                    changeLayingMode: function(t) {
                        this.layingModeOptionIndex = parseInt(t.detail.value), this.result = "", this.init();
                    },
                    changeType: function(t) {
                        this.typeOptionIndex = parseInt(t.detail.value), this.pipeCircuitDisabled = !this.pipeCircuitDisabled, 
                        this.init();
                    },
                    changeMaterial: function(t) {
                        this.materialOptionIndex = parseInt(t.detail.value), this.init();
                    },
                    calculate: function() {
                        var e = {
                            layingMode: this.getLayingMode(),
                            material: this.materialOptions[this.materialOptionIndex].label,
                            cableCoreAreaIndex: this.cableCoreAreaOptionIndex,
                            conductorNumber: this.conductorOptions[this.conductorOptionIndex],
                            type: this.typeOptions[this.typeOptionIndex].option,
                            temperatureAmbientIndex: this.temperatureAmbientOptionIndex
                        };
                        this.currentElectricalSpecification === l.ElectricalSpecifications.IEC ? e.pipeCircuitIndex = this.pipeCircuitIndex : e.totalConductorIndex = this.totalConductorOptionIndex;
                        try {
                            var i = (0, s.calculate)(this.currentElectricalSpecification, e);
                            this.result = i > 0 ? (0, u.unitFormatTo)(i, d.CurrentUnits.A, d.CurrentUnits.A) : "-", 
                            this.use(), this.$nextTick(function() {
                                (0, p.calculatePageScroll)(1e3);
                            });
                        } catch (e) {
                            t.showModal({
                                title: "注意！",
                                content: e.message,
                                showCancel: !1
                            }), this.result = "";
                        }
                    }
                }
            };
            e.default = h;
        }).call(this, i("543d").default);
    },
    9530: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("1fb1"), a = i("ad36");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(o);
        i("9e88");
        var r = i("f0c5"), c = Object(r.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        e.default = c.exports;
    },
    "9e88": function(t, e, i) {
        "use strict";
        var n = i("e07a");
        i.n(n).a;
    },
    ad36: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("39a3"), a = i.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(o);
        e.default = a.a;
    },
    e07a: function(t, e, i) {}
}, [ [ "0c6d", "common/runtime", "common/vendor" ] ] ]);