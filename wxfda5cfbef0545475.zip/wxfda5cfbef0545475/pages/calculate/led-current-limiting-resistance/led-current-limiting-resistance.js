(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/led-current-limiting-resistance/led-current-limiting-resistance" ], {
    "0c30": function(e, t, n) {
        "use strict";
        n.r(t);
        var l = n("95c1"), o = n.n(l);
        for (var r in l) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return l[e];
            });
        }(r);
        t.default = o.a;
    },
    1704: function(e, t, n) {
        "use strict";
        var l = n("8adf");
        n.n(l).a;
    },
    "7e9d": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return l;
        });
        var l = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, o = function() {
            var e = this;
            e.$createElement, e._self._c, e._isMounted || (e.e0 = function(t) {
                e.voltageSelector = !0;
            });
        }, r = [];
    },
    "884a": function(e, t, n) {
        "use strict";
        n.r(t);
        var l = n("7e9d"), o = n("0c30");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("1704");
        var c = n("f0c5"), a = Object(c.a)(o.default, l.b, l.c, !1, null, null, null, !1, l.a, void 0);
        t.default = a.exports;
    },
    "8adf": function(e, t, n) {},
    "95c1": function(e, t, n) {
        "use strict";
        (function(e) {
            var l = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n("e308"), r = l(n("035c")), c = n("d417"), a = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    BottomDrawer: function() {
                        n.e("components/bottom-drawer").then(function() {
                            return resolve(n("6842"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        connectRanges: [ "单个", "串联", "并联" ],
                        connect: 0,
                        ledCount: 2,
                        inputVoltage: "",
                        ledVoltage: "",
                        lineElectricCurrent: "",
                        voltageSelector: !1,
                        result: "",
                        ledVoltageList: [ {
                            color: "c-666",
                            text: "Infrared",
                            value: 1.5
                        }, {
                            color: "c-999",
                            text: "Infrared",
                            value: 1.7
                        }, {
                            color: "c-c0",
                            text: "Infrared",
                            value: 1.7
                        }, {
                            color: "c-ultrared",
                            text: "Ultra red",
                            value: 1.8
                        }, {
                            color: "c-red",
                            text: "High eff. red",
                            value: 2
                        }, {
                            color: "c-sred",
                            text: "Super red",
                            value: 2.2
                        }, {
                            color: "c-sorange",
                            text: "Super orange",
                            value: 2.2
                        }, {
                            color: "c-orange",
                            text: "Orange",
                            value: 2.1
                        }, {
                            color: "c-syellow",
                            text: "Super yellow",
                            value: 2.2
                        }, {
                            color: "c-spureyellow",
                            text: "Super pure yellow",
                            value: 2.1
                        }, {
                            color: "c-yellow",
                            text: "Yellow",
                            value: 2.1
                        }, {
                            color: "c-iwhite",
                            text: "Incandescent white",
                            value: 3.6
                        }, {
                            color: "c-palewhite",
                            text: "Pale white",
                            value: 3.6
                        }, {
                            color: "c-coolwhite",
                            text: "Cool white",
                            value: 3.6
                        }, {
                            color: "c-slimeyellow",
                            text: "Super lime yellow",
                            value: 2.4
                        }, {
                            color: "c-slimegreen",
                            text: "Super lime green",
                            value: 2
                        }, {
                            color: "c-hgreen",
                            text: "High eff. green",
                            value: 2.1
                        }, {
                            color: "c-spuregreen",
                            text: "Super pure green",
                            value: 2.1
                        }, {
                            color: "c-puregreen",
                            text: "Pure green",
                            value: 2.1
                        }, {
                            color: "c-aquagreen",
                            text: "Aqua green",
                            value: 3.5
                        }, {
                            color: "c-bluegreen",
                            text: "Blue green",
                            value: 3.5
                        }, {
                            color: "c-sblue",
                            text: "Super blue",
                            value: 3.6
                        }, {
                            color: "c-ultrablue",
                            text: "Ultra blue",
                            value: 3.8
                        } ]
                    };
                },
                mixins: [ r.default ],
                onLoad: function() {
                    this.initFeature("led_current_limiting_resistance", o.FeatureType.Calculate);
                },
                methods: {
                    connectChange: function(e) {
                        this.setData({
                            connect: e.detail.value
                        });
                    },
                    selectVoltage: function(e) {
                        var t = this, n = this.ledVoltageList[e.currentTarget.dataset.index];
                        this.setData({
                            ledVoltage: n.value,
                            result: ""
                        }, function() {
                            t.voltageSelector = !1;
                        });
                    },
                    calculate: function() {
                        var t = this.inputVoltage, n = this.ledVoltage, l = this.ledCount, o = this.lineElectricCurrent;
                        if (!this.checkNaN(t, n, o)) {
                            var r = this.connect;
                            if (!(r > 0 && this.checkNaN(l))) if (o /= 1e3, 1 == r ? n *= l : 2 == r && (o *= l), 
                            n > t) e.showModal({
                                content: "输入值不正确，LED 电压 ".concat(n, "V 大于输入电压。"),
                                showCancel: !1
                            }); else {
                                var a = t - n, u = a / o, i = a * o;
                                u = parseFloat(u.toFixed(3)), i = parseFloat(i.toFixed(3)), this.setData({
                                    result: "".concat(u, " Ω\n").concat(i, " W")
                                }), this.use(), this.$nextTick(function() {
                                    (0, c.calculatePageScroll)(1e3);
                                });
                            }
                        }
                    }
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    f4ac: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var l = n("4ea4");
            n("8a42"), l(n("66fd"));
            var o = l(n("884a"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "f4ac", "common/runtime", "common/vendor" ] ] ]);