(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form15/form15" ], {
    "47e0": function(e, t, i) {
        "use strict";
        var n = i("89bd");
        i.n(n).a;
    },
    6297: function(e, t, i) {
        "use strict";
        i.d(t, "b", function() {
            return a;
        }), i.d(t, "c", function() {
            return r;
        }), i.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(i.bind(null, "e526"));
            },
            layingMode: function() {
                return i.e("components/laying-mode/laying-mode").then(i.bind(null, "9f3d"));
            }
        }, a = function() {
            this.$createElement;
            var e = (this._self._c, this.currentElectricalSpecification === this.electricalSpecifications.IEC ? this.cableCoreAreaOptions.length : null), t = this.currentElectricalSpecification === this.electricalSpecifications.IEC ? this.soilThermalResistivityOptions.length : null;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    g1: t
                }
            });
        }, r = [];
    },
    "89bd": function(e, t, i) {},
    "9afa": function(e, t, i) {
        "use strict";
        (function(e, t) {
            var n = i("4ea4");
            i("8a42"), n(i("66fd"));
            var a = n(i("b0d8"));
            e.__webpack_require_UNI_MP_PLUGIN__ = i, t(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    a6fb: function(e, t, i) {
        "use strict";
        (function(e) {
            var n = i("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(i("035c")), r = n(i("0bfc")), o = n(i("fd69")), c = i("e308"), l = i("9bc7"), u = i("e827"), s = i("00cd"), d = i("d055"), h = i("d417"), p = {
                components: {
                    featureBar: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(i("e526"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    vipMask: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                            return resolve(i("e665"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    layingMode: function() {
                        i.e("components/laying-mode/laying-mode").then(function() {
                            return resolve(i("9f3d"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        result: ""
                    };
                },
                mixins: [ a.default, r.default, o.default ],
                onLoad: function() {
                    this.initFeature("carrying_capacity_of_insulated_conductor", c.FeatureType.Calculate);
                },
                methods: {
                    onTab: function(e) {
                        var t = e.currentTarget.dataset.type;
                        t !== this.currentElectricalSpecification && (this.setData({
                            currentElectricalSpecification: t,
                            materialOptionIndex: 0,
                            insulationOptionIndex: 0,
                            singleCircuitCoreIndex: 0,
                            conductorOptionIndex: 0,
                            pipeCircuitIndex: 0,
                            totalConductorOptionIndex: 0,
                            maximumOperatingTemperatureOptionIndex: 0,
                            result: ""
                        }), this.setLayingMode(), this.init());
                    },
                    listenerLayingMode: function(e) {
                        this.setData({
                            layingMode: e.detail,
                            result: ""
                        }), this.handleCableCoreAre(), this.init();
                    },
                    changeLayingMode: function(e) {
                        this.setData({
                            layingModeOptionIndex: e.detail.value,
                            result: ""
                        }), this.init();
                    },
                    changeInsulation: function(e) {
                        this.setData({
                            insulationOptionIndex: e.detail.value,
                            result: ""
                        }), this.handleTemperatureAmbient(), this.handleCableCoreAre();
                    },
                    changeMaterial: function(e) {
                        this.setData({
                            materialOptionIndex: e.detail.value,
                            result: ""
                        }), this.currentElectricalSpecification === l.ElectricalSpecifications.NEC && this.handleStyle();
                    },
                    changeCableCoreArea: function(e) {
                        this.setData({
                            cableCoreAreaOptionIndex: e.detail.value,
                            result: ""
                        });
                    },
                    changeConductor: function(e) {
                        this.setData({
                            conductorOptionIndex: e.detail.value,
                            result: ""
                        });
                    },
                    changePipeCircuit: function(e) {
                        this.setData({
                            pipeCircuitIndex: e.detail.value,
                            result: ""
                        });
                    },
                    changeSingleCircuitCore: function(e) {
                        this.setData({
                            singleCircuitCoreIndex: e.detail.value,
                            result: ""
                        }), this.handleCableCoreAre();
                    },
                    changeTemperatureAmbient: function(e) {
                        this.setData({
                            temperatureAmbientOptionIndex: e.detail.value,
                            result: ""
                        });
                    },
                    changeMaximumOperatingTemperature: function(e) {
                        this.setData({
                            maximumOperatingTemperatureOptionIndex: e.detail.value,
                            result: ""
                        }), this.handleStyle();
                    },
                    changeSoilThermalResistivity: function(e) {
                        this.setData({
                            soilThermalResistivityOptionIndex: e.detail.value,
                            result: ""
                        });
                    },
                    changeTotalConductor: function(e) {
                        this.setData({
                            totalConductorOptionIndex: e.detail.value,
                            result: ""
                        });
                    },
                    init: function() {
                        this.currentElectricalSpecification === l.ElectricalSpecifications.IEC ? (this.handleTemperatureAmbient(), 
                        this.handleSoilThermalResistivity()) : (this.handleCableCoreAre(), this.handleMaximumOperatingTemperature(), 
                        this.handleTemperatureAmbient(), this.handleStyle());
                    },
                    calculate: function() {
                        var t = {
                            layingMode: this.getLayingMode(),
                            material: this.materialOptions[this.materialOptionIndex].label,
                            cableCoreAreaIndex: this.cableCoreAreaOptionIndex,
                            conductorNumber: this.conductorOptions[this.conductorOptionIndex]
                        };
                        this.currentElectricalSpecification === l.ElectricalSpecifications.IEC ? (t.insulation = this.insulationOptions[this.insulationOptionIndex].option, 
                        t.cableCoreAreaConfig = this.cableCoreAreaConfig, t.temperatureAmbientIndex = this.temperatureAmbientOptionIndex, 
                        t.temperatureAmbientConfig = this.temperatureAmbientConfig, t.soilThermalResistivityIndex = this.soilThermalResistivityOptionIndex, 
                        t.singleCircuitCoreIndex = this.singleCircuitCoreIndex, t.pipeCircuitIndex = this.pipeCircuitIndex) : (t.maximumOperatingTemperatureIndex = this.maximumOperatingTemperatureOptionIndex, 
                        t.temperatureAmbient = this.temperatureAmbientOptions[this.temperatureAmbientOptionIndex], 
                        t.totalConductor = this.totalConductorOptions[this.totalConductorOptionIndex]);
                        try {
                            var i = (0, u.calculate)(this.currentElectricalSpecification, t);
                            this.setData({
                                result: i > 0 ? (0, s.unitFormatTo)(i, d.CurrentUnits.A, d.CurrentUnits.A) : "-"
                            }), this.use(), this.$nextTick(function() {
                                (0, h.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = p;
        }).call(this, i("543d").default);
    },
    b0d8: function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("6297"), a = i("e443");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            i.d(t, e, function() {
                return a[e];
            });
        }(r);
        i("47e0");
        var o = i("f0c5"), c = Object(o.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = c.exports;
    },
    e443: function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("a6fb"), a = i.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = a.a;
    }
}, [ [ "9afa", "common/runtime", "common/vendor" ] ] ]);