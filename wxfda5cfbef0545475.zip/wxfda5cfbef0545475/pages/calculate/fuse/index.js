(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/fuse/index" ], {
    "0b5f": function(o, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return s;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {
            return t;
        });
        var t = {
            featureBar: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/feature-bar/feature-bar") ]).then(e.bind(null, "e526"));
            }
        }, s = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    2119: function(o, n, e) {
        "use strict";
        var t = e("ce90");
        e.n(t).a;
    },
    "58b2": function(o, n, e) {
        "use strict";
        (function(o) {
            var t = e("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var s = t(e("035c")), i = e("e308"), r = e("00cd"), a = (e("d417"), e("6e05")), l = e("d055"), u = {
                components: {
                    featureBar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(e("e526"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    vipMask: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                            return resolve(e("e665"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    BottomDrawer: function() {
                        e.e("components/bottom-drawer").then(function() {
                            return resolve(e("6842"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                mixins: [ s.default ],
                data: function() {
                    return {
                        display: !1,
                        imagePrefix: "https://ts.pp.cc/storage/electrical_symbol/calculate/fuse/",
                        firstColorsOptionIndex: 0,
                        firstColorsOptions: [ a.colors.black.withImage("fus_banda_nera.png"), a.colors.brown.withImage("fus_banda_marrone.png"), a.colors.red.withImage("fus_banda_rossa.png"), a.colors.orange.withImage("fus_banda_arancio.png"), a.colors.yellow.withImage("fus_banda_gialla.png"), a.colors.green.withImage("fus_banda_verde.png"), a.colors.blue.withImage("fus_banda_blu.png"), a.colors.purple.withImage("fus_banda_viola.png"), a.colors.gray.withImage("fus_banda_grigia.png"), a.colors.white.withImage("fus_banda_bianca.png") ],
                        secondColorsOptionIndex: 0,
                        secondColorsOptions: [ a.colors.black.withImage("fus_banda_nera.png"), a.colors.brown.withImage("fus_banda_marrone.png"), a.colors.red.withImage("fus_banda_rossa.png"), a.colors.orange.withImage("fus_banda_arancio.png"), a.colors.yellow.withImage("fus_banda_gialla.png"), a.colors.green.withImage("fus_banda_verde.png"), a.colors.blue.withImage("fus_banda_blu.png"), a.colors.purple.withImage("fus_banda_viola.png"), a.colors.gray.withImage("fus_banda_grigia.png"), a.colors.white.withImage("fus_banda_bianca.png") ],
                        thirdColorsOptionIndex: 0,
                        thirdColorsOptions: [ a.colors.black.withImage("fus_banda_nera.png"), a.colors.brown.withImage("fus_banda_marrone.png"), a.colors.red.withImage("fus_banda_rossa.png") ],
                        fourthColorsOptionIndex: 0,
                        fourthColorsOptions: [ a.colors.red.withImage("fus_banda_rossa.png"), a.colors.blue.withImage("fus_banda_blu.png") ],
                        singleColorsOptionIndex: 0,
                        singleColorsOptions: [ a.colors.pink.withImage("fus_punto_rosa.png"), a.colors.black.withImage("fus_punto_nero.png"), a.colors.gray.withImage("fus_punto_grigio.png"), a.colors.red.withImage("fus_punto_rosso.png"), a.colors.brown.withImage("fus_punto_marrone.png"), a.colors.yellow.withImage("fus_punto_giallo.png"), a.colors.green.withImage("fus_punto_verde.png"), a.colors.blue.withImage("fus_punto_blu.png"), a.colors.lightblue.withImage("fus_punto_azzurro.png") ],
                        singleColorsValues: [ 50, 60, 100, 150, 250, 500, 750, 1e3, 1500 ],
                        singleColorValue: "",
                        colorValue: "",
                        popupOptionIndex: 0,
                        popupOptions: [],
                        popupType: "first"
                    };
                },
                onLoad: function() {
                    this.init(), this.initFeature("fuse", i.FeatureType.Calculate);
                },
                methods: {
                    init: function() {
                        this.popupOptionIndex = 0, this.popupOptions = this.firstColorsOptions, this.changeSingleColorValue(0);
                    },
                    openPopup: function(o) {
                        switch (o) {
                          case "first":
                            this.popupOptionIndex = this.firstColorsOptionIndex, this.popupOptions = this.firstColorsOptions;
                            break;

                          case "second":
                            this.popupOptionIndex = this.secondColorsOptionIndex, this.popupOptions = this.secondColorsOptions;
                            break;

                          case "third":
                            this.popupOptionIndex = this.thirdColorsOptionIndex, this.popupOptions = this.thirdColorsOptions;
                            break;

                          case "fourth":
                            this.popupOptionIndex = this.fourthColorsOptionIndex, this.popupOptions = this.fourthColorsOptions;
                            break;

                          case "single":
                            this.popupOptionIndex = this.singleColorsOptionIndex, this.popupOptions = this.singleColorsOptions;
                        }
                        this.popupType = o, this.display = !0;
                    },
                    closePopup: function(o) {
                        switch (this.popupType) {
                          case "first":
                            this.firstColorsOptionIndex = o;
                            break;

                          case "second":
                            this.secondColorsOptionIndex = o;
                            break;

                          case "third":
                            this.thirdColorsOptionIndex = o;
                            break;

                          case "fourth":
                            this.fourthColorsOptionIndex = o;
                            break;

                          case "single":
                            this.singleColorsOptionIndex = o;
                        }
                        "single" === this.popupType && this.changeSingleColorValue(o), this.popupOptionIndex = o, 
                        this.display = !1;
                    },
                    changeSingleColorValue: function(o) {
                        this.singleColorValue = (0, r.formatFromUnits)(this.singleColorsValues[o] / 1e3, l.CurrentUnits.A, l.CurrentUnits);
                    },
                    calculate: function() {
                        try {
                            var n = (10 * this.firstColorsOptionIndex + this.secondColorsOptionIndex) * [ 1, 10, 100 ][this.thirdColorsOptionIndex];
                            n = n > 0 ? (0, r.formatFromUnits)(n / 1e3, l.CurrentUnits.A, l.CurrentUnits) : "0 " + l.CurrentUnits.A.name, 
                            this.colorValue = n + " + " + [ "快", "慢" ][this.fourthColorsOptionIndex], this.use();
                        } catch (n) {
                            o.showModal({
                                title: "注意！",
                                content: n.message,
                                showCancel: !1
                            }), this.colorValue = "";
                        }
                    }
                }
            };
            n.default = u;
        }).call(this, e("543d").default);
    },
    "704b": function(o, n, e) {
        "use strict";
        e.r(n);
        var t = e("58b2"), s = e.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(o) {
            e.d(n, o, function() {
                return t[o];
            });
        }(i);
        n.default = s.a;
    },
    b0a4: function(o, n, e) {
        "use strict";
        e.r(n);
        var t = e("0b5f"), s = e("704b");
        for (var i in s) [ "default" ].indexOf(i) < 0 && function(o) {
            e.d(n, o, function() {
                return s[o];
            });
        }(i);
        e("2119");
        var r = e("f0c5"), a = Object(r.a)(s.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = a.exports;
    },
    ce90: function(o, n, e) {},
    f807: function(o, n, e) {
        "use strict";
        (function(o, n) {
            var t = e("4ea4");
            e("8a42"), t(e("66fd"));
            var s = t(e("b0a4"));
            o.__webpack_require_UNI_MP_PLUGIN__ = e, n(s.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    }
}, [ [ "f807", "common/runtime", "common/vendor" ] ] ]);