(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/partial-voltage-resistance/partial-voltage-resistance" ], {
    "0460": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("f6a3"), r = n.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        t.default = r.a;
    },
    "18f6": function(e, t, n) {},
    5397: function(e, t, n) {
        "use strict";
        var a = n("18f6");
        n.n(a).a;
    },
    b0a6: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var r = a(n("f9b3"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    ce63: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return u;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    f6a3: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n("e308"), u = a(n("035c")), i = n("1c29"), c = n("d417"), o = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        inputVoltage: "",
                        outputVoltage: "",
                        lineCurrent: "",
                        result: "",
                        currentUnitRanges: [ "W", "A", "mA" ],
                        currentUnitIndex: 0
                    };
                },
                mixins: [ u.default ],
                onLoad: function() {
                    this.initFeature("partial_voltage_resistance", r.FeatureType.Calculate);
                },
                methods: {
                    currentUnitChange: function(e) {
                        this.setData({
                            currentUnitIndex: e.detail.value
                        });
                    },
                    calculate: function() {
                        var t = this.inputVoltage, n = this.outputVoltage, a = this.lineCurrent;
                        if (!this.checkNaN(t, n, a)) if (t <= n) e.showModal({
                            content: "电压值输入不正确。",
                            showCancel: !1
                        }); else {
                            var r = t - n, u = this.currentUnitRanges[this.currentUnitIndex];
                            "W" == u ? a /= n : "mA" == u && (a /= 1e3);
                            var o = (0, i.ohmFormat)(r / a), l = parseFloat((r * a).toFixed(3)), s = "".concat(o, "\n").concat(l, " W");
                            this.setData({
                                result: s
                            }), this.use(), this.$nextTick(function() {
                                (0, c.calculatePageScroll)(1e3);
                            });
                        }
                    }
                }
            };
            t.default = o;
        }).call(this, n("543d").default);
    },
    f9b3: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("ce63"), r = n("0460");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(u);
        n("5397");
        var i = n("f0c5"), c = Object(i.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    }
}, [ [ "b0a6", "common/runtime", "common/vendor" ] ] ]);