(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form2/form2" ], {
    "09a5": function(e, t, o) {
        "use strict";
        var n = o("c03c");
        o.n(n).a;
    },
    "4e7f": function(e, t, o) {
        "use strict";
        o.d(t, "b", function() {
            return r;
        }), o.d(t, "c", function() {
            return l;
        }), o.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ o.e("common/vendor"), o.e("components/feature-bar/feature-bar") ]).then(o.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, l = [];
    },
    "5ee1": function(e, t, o) {
        "use strict";
        var n = o("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n(o("035c")), l = o("e308"), a = o("6e05"), c = o("1c29"), u = o("00cd"), i = [ a.colors.black.withValue(0), a.colors.brown.withValue(1), a.colors.red.withValue(2), a.colors.orange.withValue(3), a.colors.yellow.withValue(4), a.colors.green.withValue(5), a.colors.blue.withValue(6), a.colors.purple.withValue(7), a.colors.gray.withValue(8), a.colors.white.withValue(9) ], s = [ a.colors.black.withValue(1), a.colors.brown.withValue(10), a.colors.red.withValue(100), a.colors.orange.withValue(1e3), a.colors.yellow.withValue(1e4), a.colors.green.withValue(1e5), a.colors.blue.withValue(1e6), a.colors.purple.withValue(1e7), a.colors.gray.withValue(1e8), a.colors.white.withValue(1e9), a.colors.silver.withValue(.01), a.colors.gold.withValue(.1) ], f = [ a.colors.black.withValue(20), a.colors.brown.withValue(1), a.colors.red.withValue(2), a.colors.orange.withValue(3), a.colors.yellow.withValue(4), a.colors.silver.withValue(10), a.colors.gold.withValue(5), a.colors.none.withValue(20) ], d = {
            components: {
                featureBar: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/feature-bar/feature-bar") ]).then(function() {
                        return resolve(o("e526"));
                    }.bind(null, o)).catch(o.oe);
                },
                vipMask: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/vip/vip") ]).then(function() {
                        return resolve(o("e665"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            data: function() {
                return {
                    rings: [ i, i, s, f ],
                    ringsIndex: [ 0, 0, 0, 0 ],
                    result: ""
                };
            },
            mixins: [ r.default ],
            onLoad: function() {
                this.initFeature("color_ring_inductance", l.FeatureType.Calculate);
            },
            methods: {
                onRingChange: function(e) {
                    var t = e.detail.value, o = e.currentTarget.dataset.index;
                    this.$set(this.ringsIndex, o, t[0]), this.calculate();
                },
                calculate: function() {
                    var e = (10 * i[this.ringsIndex[0]].value + i[this.ringsIndex[1]].value) * s[this.ringsIndex[2]].value, t = f[this.ringsIndex[3]].value;
                    this.setData({
                        result: "".concat((0, u.formatFromUnits)(e, c.inductanceUnits.uH, c.inductanceUnits), " ± ").concat(t, "%")
                    }), this.use();
                }
            }
        };
        t.default = d;
    },
    "6e31": function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("5ee1"), r = o.n(n);
        for (var l in n) [ "default" ].indexOf(l) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(l);
        t.default = r.a;
    },
    c03c: function(e, t, o) {},
    cd0c: function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("4e7f"), r = o("6e31");
        for (var l in r) [ "default" ].indexOf(l) < 0 && function(e) {
            o.d(t, e, function() {
                return r[e];
            });
        }(l);
        o("09a5");
        var a = o("f0c5"), c = Object(a.a)(r.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = c.exports;
    },
    f947: function(e, t, o) {
        "use strict";
        (function(e, t) {
            var n = o("4ea4");
            o("8a42"), n(o("66fd"));
            var r = n(o("cd0c"));
            e.__webpack_require_UNI_MP_PLUGIN__ = o, t(r.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    }
}, [ [ "f947", "common/runtime", "common/vendor" ] ] ]);