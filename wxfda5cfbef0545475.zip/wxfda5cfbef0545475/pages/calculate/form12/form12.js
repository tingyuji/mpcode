(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form12/form12" ], {
    "1ef5": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("d569"), i = t("6428");
        for (var l in i) [ "default" ].indexOf(l) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(l);
        var r = t("f0c5"), u = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = u.exports;
    },
    6428: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("db09"), i = t.n(a);
        for (var l in a) [ "default" ].indexOf(l) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(l);
        n.default = i.a;
    },
    a467: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var i = a(t("1ef5"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    d569: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return i;
        }), t.d(n, "c", function() {
            return l;
        }), t.d(n, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, l = [];
    },
    db09: function(e, n, t) {
        "use strict";
        (function(e) {
            var a = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = a(t("035c")), l = a(t("f73d")), r = a(t("3de9")), u = t("e308"), o = t("fad4"), E = t("00cd"), s = t("3853"), T = {
                components: {
                    featureBar: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(t("e526"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    vipMask: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                            return resolve(t("e665"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        inputTerminalIndex: 0,
                        inputTerminal: [ {
                            option: o.InputTerminal.VOLTAGE_CURRENT_ACTIVE_POWER,
                            label: "电压/电流/有功功率"
                        }, {
                            option: o.InputTerminal.VOLTAGE_CURRENT_REACTIVE_POWER,
                            label: "电压/电流/无功功率"
                        }, {
                            option: o.InputTerminal.VOLTAGE_ACTIVE_POWER_IMPEDANCE,
                            label: "电压/有功功率/阻抗"
                        }, {
                            option: o.InputTerminal.CURRENT_ACTIVE_POWER_IMPEDANCE,
                            label: "电流/有功功率/阻抗"
                        }, {
                            option: o.InputTerminal.ACTIVE_APPARENT,
                            label: "有功功率/视在功率"
                        }, {
                            option: o.InputTerminal.ACTIVE_REACTIVE,
                            label: "有功功率/无功功率"
                        }, {
                            option: o.InputTerminal.APPARENT_REACTIVE,
                            label: "视在功率/无功功率"
                        }, {
                            option: o.InputTerminal.RESISTANCE_IMPEDANCE,
                            label: "电阻/阻抗"
                        } ],
                        voltageDisplay: !0,
                        currentDisplay: !0,
                        resistanceDisplay: !1,
                        impedanceDisplay: !1,
                        activePowerDisplay: !0,
                        apparentPowerDisplay: !1,
                        reactivePowerDisplay: !1,
                        result: ""
                    };
                },
                mixins: [ i.default, l.default, r.default ],
                onShow: function() {
                    this.setCurrentType("DC"), this.initFeature("power_factor", u.FeatureType.Calculate);
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.setData({
                            currentTypeIndex: parseInt(e.detail.value)
                        });
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option;
                        this.setData({
                            voltageDisplay: [ o.InputTerminal.VOLTAGE_CURRENT_ACTIVE_POWER, o.InputTerminal.VOLTAGE_CURRENT_REACTIVE_POWER, o.InputTerminal.VOLTAGE_ACTIVE_POWER_IMPEDANCE ].includes(e),
                            currentDisplay: [ o.InputTerminal.VOLTAGE_CURRENT_ACTIVE_POWER, o.InputTerminal.VOLTAGE_CURRENT_REACTIVE_POWER, o.InputTerminal.CURRENT_ACTIVE_POWER_IMPEDANCE ].includes(e),
                            resistanceDisplay: [ o.InputTerminal.RESISTANCE_IMPEDANCE ].includes(e),
                            impedanceDisplay: [ o.InputTerminal.VOLTAGE_ACTIVE_POWER_IMPEDANCE, o.InputTerminal.CURRENT_ACTIVE_POWER_IMPEDANCE, o.InputTerminal.RESISTANCE_IMPEDANCE ].includes(e),
                            activePowerDisplay: [ o.InputTerminal.VOLTAGE_CURRENT_ACTIVE_POWER, o.InputTerminal.VOLTAGE_ACTIVE_POWER_IMPEDANCE, o.InputTerminal.CURRENT_ACTIVE_POWER_IMPEDANCE, o.InputTerminal.ACTIVE_APPARENT, o.InputTerminal.ACTIVE_REACTIVE ].includes(e),
                            apparentPowerDisplay: [ o.InputTerminal.ACTIVE_APPARENT, o.InputTerminal.APPARENT_REACTIVE ].includes(e),
                            reactivePowerDisplay: [ o.InputTerminal.VOLTAGE_CURRENT_REACTIVE_POWER, o.InputTerminal.ACTIVE_REACTIVE, o.InputTerminal.APPARENT_REACTIVE ].includes(e)
                        });
                    },
                    calculate: function() {
                        try {
                            var n = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                voltageValue: this.getVoltageUnitValue(),
                                currentValue: this.getCurrentUnitValue(),
                                impedanceValue: this.getImpedanceUnitValue(),
                                resistanceValue: this.getResistanceUnitValue(),
                                activePowerValue: this.getActivePowerUnitValue(),
                                apparentPowerValue: this.getApparentPowerUnitValue(),
                                reactivePowerValue: this.getReactivePowerUnitValue()
                            }, t = (0, s.calculate)(n);
                            if (isNaN(t)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, E.formatDouble)(t, 3)
                            }), this.use();
                        } catch (n) {
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: n.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            n.default = T;
        }).call(this, t("543d").default);
    }
}, [ [ "a467", "common/runtime", "common/vendor" ] ] ]);