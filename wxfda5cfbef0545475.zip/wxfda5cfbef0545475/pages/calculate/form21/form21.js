(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form21/form21" ], {
    "0292": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("e827a"), o = n.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        t.default = o.a;
    },
    "70ea": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var o = a(n("9afa4"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    9345: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "9afa4": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("9345"), o = n("0292");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        n("d19c");
        var r = n("f0c5"), i = Object(r.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    },
    cbbe: function(e, t, n) {},
    d19c: function(e, t, n) {
        "use strict";
        var a = n("cbbe");
        n.n(a).a;
    },
    e827a: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(n("035c")), c = n("e308"), r = n("d417"), i = n("1c29"), u = n("00cd"), s = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        connectionIndex: 0,
                        connection: [ "串联", "并联" ],
                        resistance: void 0,
                        reactance: void 0,
                        result: ""
                    };
                },
                mixins: [ o.default ],
                onLoad: function() {
                    this.initFeature("impedance_consist_of", c.FeatureType.Calculate);
                },
                methods: {
                    calculate: function() {
                        if ((0, r.isVoidNumber)(this.resistance) || (0, r.isVoidNumber)(this.reactance)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t, n = parseFloat(this.resistance), a = parseFloat(this.reactance), o = i.OhmUnits.O.name;
                            t = this.connectionIndex ? (0, u.formatDouble)(n, 3) + " " + o + " + j" + (0, u.formatDouble)(a, 3) + " " + o : (0, 
                            u.formatDouble)(Math.sqrt(Math.pow(n, 2) + Math.pow(a, 2)), 3) + " " + o, this.setData({
                                result: t
                            });
                        }
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d").default);
    }
}, [ [ "70ea", "common/runtime", "common/vendor" ] ] ]);