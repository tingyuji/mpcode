(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form7/form7" ], {
    1173: function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return o;
        }), a.d(t, "c", function() {
            return r;
        }), a.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    "1c74": function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("2c2b"), o = a.n(n);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(r);
        t.default = o.a;
    },
    "2c2b": function(e, t, a) {
        "use strict";
        (function(e) {
            var n = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(a("035c")), r = n(a("0bfc")), l = n(a("8760")), i = n(a("3de9")), u = n(a("f73d")), c = n(a("ed61")), s = a("e308"), d = a("0db1"), f = a("9a2b"), g = a("00cd"), p = a("d417"), h = {
                components: {
                    featureBar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(a("e526"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    vipMask: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                            return resolve(a("e665"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        voltageDrop: null
                    };
                },
                mixins: [ o.default, r.default, l.default, i.default, u.default, c.default ],
                onLoad: function() {
                    this.initFeature("voltage_drop", s.FeatureType.Calculate);
                },
                onShow: function() {
                    this.setData({
                        temperatureUnitValue: 70
                    }), this.setCurrentType("DC");
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        if ((0, p.isVoidNumber)(this.voltageUnitValue) || (0, p.isVoidNumber)(this.loadUnitValue) || (0, 
                        p.isVoidNumber)(this.cableLineUnitValue) || (0, p.isVoidNumber)(this.temperatureUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                currentType: this.getCurrentType(),
                                voltageValue: this.getVoltageUnitValue(),
                                length: this.getCableLineUnitValue(),
                                temperature: this.getTemperatureUnitValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, a = this.getCableCoreAreaCollection(1, t.temperature, t.currentType), n = this.getLoadCurrent(t.currentType, t.voltageValue, t.triangleCollection), o = (0, 
                            f.calculateVoltageDrop)(t.currentType, n, t.voltageValue, a.resistance, a.reactance, t.length, t.triangleCollection);
                            o.voltage_drop = (0, g.formatFromUnits)(o.voltage_drop, d.VoltageUnits.V, d.VoltageUnits), 
                            o.voltage_drop_rate = (0, g.formatDouble)(o.voltage_drop_rate, 3) + "%", o.voltage_load ? o.voltage_load = (0, 
                            g.formatFromUnits)(o.voltage_load, d.VoltageUnits.V, d.VoltageUnits) : o.voltage_load = "0 V", 
                            this.setData({
                                voltageDrop: o
                            }), this.use(), this.$nextTick(function() {
                                (0, p.calculatePageScroll)(1e3);
                            });
                        } catch (t) {
                            this.setData({
                                voltageDrop: null
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = h;
        }).call(this, a("543d").default);
    },
    "784a": function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("1173"), o = a("1c74");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            a.d(t, e, function() {
                return o[e];
            });
        }(r);
        a("e6b0");
        var l = a("f0c5"), i = Object(l.a)(o.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = i.exports;
    },
    cbb9: function(e, t, a) {
        "use strict";
        (function(e, t) {
            var n = a("4ea4");
            a("8a42"), n(a("66fd"));
            var o = n(a("784a"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, t(o.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    dd2d: function(e, t, a) {},
    e6b0: function(e, t, a) {
        "use strict";
        var n = a("dd2d");
        a.n(n).a;
    }
}, [ [ "cbb9", "common/runtime", "common/vendor" ] ] ]);