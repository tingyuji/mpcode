(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/length-antenna/length-antenna" ], {
    "0acf": function(e, n, t) {},
    "19db": function(e, n, t) {
        "use strict";
        var a = t("0acf");
        t.n(a).a;
    },
    "841b": function(e, n, t) {
        "use strict";
        (function(e) {
            var a = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = a(t("035c")), u = a(t("37af")), r = t("e308"), o = t("00cd"), s = t("d417"), c = t("5ce9"), l = t("9912"), f = {
                components: {
                    featureBar: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(t("e526"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    vipMask: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                            return resolve(t("e665"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                mixins: [ i.default, u.default ],
                data: function() {
                    return {
                        form: {
                            speedRate: .95
                        },
                        result: null
                    };
                },
                onLoad: function() {
                    this.initFeature("length-antenna", r.FeatureType.Calculate), this.frequencyUnits = [ this.hzAllUnits.kHz, this.hzAllUnits.MHz ], 
                    this.frequencyUnitIndex = 0;
                },
                methods: {
                    calculate: function() {
                        if ((0, s.isVoidNumber)(this.form.speedRate) || (0, s.isVoidNumber)(this.frequencyUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var n = this.getFrequencyUnitValue(), t = (0, c.calculateLengthAntenna)(this.form.speedRate, n / 1e3);
                            this.result = {
                                full: (0, o.unitFormatTo)(t, l.MeasuringUnits.m, l.MeasuringUnits.cm) + " - " + (0, 
                                o.unitFormatTo)(t, l.MeasuringUnits.m, l.MeasuringUnits.in),
                                half: (0, o.unitFormatTo)(t / 2, l.MeasuringUnits.m, l.MeasuringUnits.cm) + " - " + (0, 
                                o.unitFormatTo)(t / 2, l.MeasuringUnits.m, l.MeasuringUnits.in),
                                quarter: (0, o.unitFormatTo)(t / 4, l.MeasuringUnits.m, l.MeasuringUnits.cm) + " - " + (0, 
                                o.unitFormatTo)(t / 4, l.MeasuringUnits.m, l.MeasuringUnits.in)
                            }, this.use();
                        } catch (n) {
                            this.result = null, e.showModal({
                                title: "注意！",
                                content: n.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            n.default = f;
        }).call(this, t("543d").default);
    },
    aeed3: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("e450"), i = t("caa7");
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(u);
        t("19db");
        var r = t("f0c5"), o = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = o.exports;
    },
    caa7: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("841b"), i = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = i.a;
    },
    caab: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var i = a(t("aeed3"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    e450: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return i;
        }), t.d(n, "c", function() {
            return u;
        }), t.d(n, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ t.e("common/vendor"), t.e("components/feature-bar/feature-bar") ]).then(t.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, u = [];
    }
}, [ [ "caab", "common/runtime", "common/vendor" ] ] ]);