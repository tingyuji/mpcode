(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form30/form30" ], {
    "0c37": function(t, e, n) {},
    "188a": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("b7e6"), i = n.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(u);
        e.default = i.a;
    },
    "2bae": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("65e6"), i = n("188a");
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(u);
        n("9a62");
        var o = n("f0c5"), r = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = r.exports;
    },
    "65e6": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    "9a62": function(t, e, n) {
        "use strict";
        var a = n("0c37");
        n.n(a).a;
    },
    a367: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("2bae"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    b7e6: function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("035c")), u = n("e308"), o = n("d417"), r = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        inputRangeIndex: 0,
                        outputRangeIndex: 0,
                        ranges: [ {
                            name: "自定义",
                            unit: "-",
                            min: null,
                            max: null
                        }, {
                            name: "0-10 V",
                            unit: "V",
                            min: 0,
                            max: 10
                        }, {
                            name: "0-20 mA",
                            unit: "mA",
                            min: 0,
                            max: 20
                        }, {
                            name: "4-20 mA",
                            unit: "mA",
                            min: 4,
                            max: 20
                        } ],
                        inputMin: "",
                        inputMax: "",
                        value: "",
                        outputMin: "",
                        outputMax: "",
                        result: ""
                    };
                },
                mixins: [ i.default ],
                onLoad: function() {
                    this.initFeature("simulator_single_value", u.FeatureType.Calculate);
                },
                methods: {
                    inputRangeChange: function(t) {
                        var e = t.detail.value, n = {
                            inputRangeIndex: e
                        };
                        if (0 != e) {
                            var a = this.ranges[e];
                            n.inputMin = a.min, n.inputMax = a.max;
                        }
                        this.setData(n);
                    },
                    outputRangeChange: function(t) {
                        var e = t.detail.value, n = {
                            outputRangeIndex: e
                        };
                        if (0 != e) {
                            var a = this.ranges[e];
                            n.outputMin = a.min, n.outputMax = a.max;
                        }
                        this.setData(n);
                    },
                    inputMinChange: function(t) {
                        this.inputMin = parseFloat(t.detail.value);
                    },
                    inputMaxChange: function(t) {
                        this.inputMax = parseFloat(t.detail.value);
                    },
                    inputValueChange: function(t) {
                        this.value = parseFloat(t.detail.value);
                    },
                    outputMinChange: function(t) {
                        this.outputMin = parseFloat(t.detail.value);
                    },
                    outputMaxChange: function(t) {
                        this.outputMax = parseFloat(t.detail.value);
                    },
                    calculate: function() {
                        var t = this.inputMin, e = this.inputMax, n = this.value, a = this.outputMin, i = this.outputMax;
                        if (isNaN(t) || isNaN(e) || isNaN(n) || isNaN(i) || isNaN(i)) this.error("输入的值不合法。"); else if (t > e) this.error("输入最大最小值错误。"); else if (n < t || n > e) this.error("输入值不在范围内。"); else if (a > i) this.error("输出最大小最值错误。"); else {
                            var u = (n - t) * (i - a) / (e - t) + a, r = this.ranges[this.outputRangeIndex].unit;
                            "-" != r && (u += " " + r), this.setData({
                                result: u
                            }), this.$nextTick(function() {
                                (0, o.calculatePageScroll)(1e3);
                            }), this.use();
                        }
                    },
                    error: function(e) {
                        t.showModal({
                            title: "输入错误",
                            content: e,
                            showCancel: !1,
                            confirmText: "确定"
                        });
                    }
                }
            };
            e.default = r;
        }).call(this, n("543d").default);
    }
}, [ [ "a367", "common/runtime", "common/vendor" ] ] ]);