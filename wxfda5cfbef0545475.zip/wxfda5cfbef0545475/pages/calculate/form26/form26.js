(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form26/form26" ], {
    1796: function(e, t, a) {},
    "2d5a": function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("7d97"), o = a("5d3f");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return o[e];
            });
        }(i);
        a("987c");
        var r = a("f0c5"), c = Object(r.a)(o.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = c.exports;
    },
    "42df": function(e, t, a) {
        "use strict";
        (function(e, t) {
            var n = a("4ea4");
            a("8a42"), n(a("66fd"));
            var o = n(a("2d5a"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, t(o.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    "5d3f": function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("af89"), o = a.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = o.a;
    },
    "7d97": function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return o;
        }), a.d(t, "c", function() {
            return i;
        }), a.d(t, "a", function() {
            return n;
        });
        var n = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "987c": function(e, t, a) {
        "use strict";
        var n = a("1796");
        a.n(n).a;
    },
    af89: function(e, t, a) {
        "use strict";
        (function(e) {
            var n = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(a("035c")), i = a("e308"), r = a("d417"), c = a("00cd"), u = a("0db1"), s = a("1c29"), l = [ 1, 2, 4, 8 ], f = {
                components: {
                    featureBar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(a("e526"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    vipMask: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                            return resolve(a("e665"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        calculateOptionIndex: 0,
                        calculateOptions: [ "V out", "V in", "R1", "R2" ],
                        voltageOutValue: void 0,
                        voltageInValue: void 0,
                        resistanceOneValue: void 0,
                        resistanceTwoValue: void 0,
                        display: 14,
                        result: ""
                    };
                },
                mixins: [ o.default ],
                onLoad: function() {
                    this.initFeature("resistance_divider_circuit", i.FeatureType.Calculate);
                },
                methods: {
                    changeCalculateOption: function(e) {
                        var t = parseInt(e.detail.value);
                        this.setData({
                            calculateOptionIndex: t,
                            display: 15 - l[t]
                        });
                    },
                    calculate: function() {
                        try {
                            switch (this.calculateOptionIndex) {
                              case 0:
                                this.calculateVoltageOut(this.voltageInValue, this.resistanceOneValue, this.resistanceTwoValue);
                                break;

                              case 1:
                                this.calculateVoltageIn(this.voltageOutValue, this.resistanceOneValue, this.resistanceTwoValue);
                                break;

                              case 2:
                                this.calculateResistanceOne(this.voltageInValue, this.voltageOutValue, this.resistanceTwoValue);
                                break;

                              case 3:
                                this.calculateResistanceTwo(this.voltageInValue, this.voltageOutValue, this.resistanceOneValue);
                            }
                            this.use();
                        } catch (t) {
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    },
                    calculateVoltageOut: function(e, t, a) {
                        if ((0, r.isVoidNumber)(e) || (0, r.isVoidNumber)(t) || (0, r.isVoidNumber)(a)) throw new Error("请输入所有参数");
                        if (!(0, r.isNonzeroNumber)(e)) throw new Error("电压数值无效");
                        if (!(0, r.isNonzeroNumber)(t) || !(0, r.isNonzeroNumber)(a)) throw new Error("电阻数值无效");
                        var n = (0, c.formatDouble)(e * a / (t + a), 3);
                        this.setData({
                            result: "".concat(this.calculateOptions[this.calculateOptionIndex], " = ").concat(n, " ").concat(u.VoltageUnits.V.name)
                        });
                    },
                    calculateVoltageIn: function(e, t, a) {
                        if ((0, r.isVoidNumber)(e) || (0, r.isVoidNumber)(t) || (0, r.isVoidNumber)(a)) throw new Error("请输入所有参数");
                        if (!(0, r.isNonzeroNumber)(e)) throw new Error("电压数值无效");
                        if (!(0, r.isNonzeroNumber)(t) || !(0, r.isNonzeroNumber)(a)) throw new Error("电阻数值无效");
                        var n = (0, c.formatDouble)(e * (t + a) / a, 3);
                        this.setData({
                            result: "".concat(this.calculateOptions[this.calculateOptionIndex], " = ").concat(n, " ").concat(u.VoltageUnits.V.name)
                        });
                    },
                    calculateResistanceOne: function(e, t, a) {
                        if ((0, r.isVoidNumber)(e) || (0, r.isVoidNumber)(t) || (0, r.isVoidNumber)(a)) throw new Error("请输入所有参数");
                        if (!(0, r.isNonzeroNumber)(e) || !(0, r.isNonzeroNumber)(t) || e < t) throw new Error("电压数值无效");
                        if (!(0, r.isNonzeroNumber)(a)) throw new Error("电阻数值无效");
                        var n = (0, c.formatDouble)(e * a / t - a, 3);
                        n < 0 && (n = 0), this.setData({
                            result: "".concat(this.calculateOptions[this.calculateOptionIndex], " = ").concat(n, " ").concat(s.OhmUnits.O.name)
                        });
                    },
                    calculateResistanceTwo: function(e, t, a) {
                        if ((0, r.isVoidNumber)(e) || (0, r.isVoidNumber)(t) || (0, r.isVoidNumber)(a)) throw new Error("请输入所有参数");
                        if (!(0, r.isNonzeroNumber)(e) || !(0, r.isNonzeroNumber)(t) || e < t) throw new Error("电压数值无效");
                        if (!(0, r.isNonzeroNumber)(a)) throw new Error("电阻数值无效");
                        var n;
                        n = e === t ? "∞" : (0, c.formatDouble)(t * a / (e - t), 3), this.setData({
                            result: "".concat(this.calculateOptions[this.calculateOptionIndex], " = ").concat(n, " ").concat(s.OhmUnits.O.name)
                        });
                    }
                }
            };
            t.default = f;
        }).call(this, a("543d").default);
    }
}, [ [ "42df", "common/runtime", "common/vendor" ] ] ]);