(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form28/form28" ], {
    "06a6": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("035c")), i = n("e308"), o = n("1c29"), u = n("d417"), c = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        targetIndex: 3,
                        targetRanges: [ "输入电压", "稳压二极管稳压值", "线电流", "电阻" ],
                        showVoltage: !0,
                        showZenerDiode: !0,
                        showLineCurrent: !0,
                        showResistance: !1,
                        voltage: "",
                        zenerDiode: "",
                        lineCurrent: "",
                        lineCurrentUnitRanges: [ "mA", "A" ],
                        lineCurrentUnitIndex: 0,
                        resistance: "",
                        result: ""
                    };
                },
                mixins: [ a.default ],
                onLoad: function() {
                    this.initFeature("zener_diode", i.FeatureType.Calculate);
                },
                methods: {
                    targetChange: function(e) {
                        var t = e.detail.value;
                        this.setData({
                            targetIndex: parseInt(t),
                            showVoltage: 0 != t,
                            showZenerDiode: 1 != t,
                            showLineCurrent: 2 != t,
                            showResistance: 3 != t
                        });
                    },
                    lineCurrentUnitChange: function(e) {
                        this.setData({
                            lineCurrentUnitIndex: e.detail.value
                        });
                    },
                    calculate: function() {
                        var t = this.voltage, n = this.zenerDiode, r = this.lineCurrent, a = this.resistance;
                        if (2 != this.targetIndex && "mA" == this.lineCurrentUnitRanges[this.lineCurrentUnitIndex] && (r /= 1e3), 
                        this.targetIndex >= 2 && parseFloat(t) <= parseFloat(n)) e.showModal({
                            content: "输入的电压值不正确。",
                            showCancel: !1
                        }); else {
                            var i;
                            switch (this.targetIndex) {
                              case 0:
                                if (this.checkNaN(n, r, a)) return;
                                i = function(e, t, n) {
                                    return e * t + n;
                                }(r, a, n), i = parseFloat(i.toFixed(3)) + " V";
                                break;

                              case 1:
                                if (this.checkNaN(t, r, a)) return;
                                i = function(e, t, n) {
                                    return e - t * n;
                                }(t, r, a), i = parseFloat(i.toFixed(3)) + " V";
                                break;

                              case 2:
                                if (this.checkNaN(t, n, a)) return;
                                i = function(e, t, n) {
                                    return (e - t) / n;
                                }(t, n, a), i = parseFloat(i.toFixed(3)) + " A";
                                break;

                              case 3:
                                if (this.checkNaN(t, n, r)) return;
                                i = function(e, t, n) {
                                    return (e - t) / n;
                                }(t, n, r), i = (0, o.ohmFormat)(i);
                            }
                            this.setData({
                                result: i
                            }), this.use(), this.$nextTick(function() {
                                (0, u.calculatePageScroll)(1e3);
                            });
                        }
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default);
    },
    "0790": function(e, t, n) {},
    "246d": function(e, t, n) {
        "use strict";
        var r = n("0790");
        n.n(r).a;
    },
    "47d9": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4");
            n("8a42"), r(n("66fd"));
            var a = r(n("70f8"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "6b5c": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "70f8": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("6b5c"), a = n("a546");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("246d");
        var o = n("f0c5"), u = Object(o.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = u.exports;
    },
    a546: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("06a6"), a = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t.default = a.a;
    }
}, [ [ "47d9", "common/runtime", "common/vendor" ] ] ]);