(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form13/form13" ], {
    "0a07": function(e, t, n) {
        "use strict";
        var i = n("153d");
        n.n(i).a;
    },
    "153d": function(e, t, n) {},
    "3bb2": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    5694: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("c19f"), a = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = a.a;
    },
    7602: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("8947"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    8947: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("3bb2"), a = n("5694");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("0a07");
        var l = n("f0c5"), u = Object(l.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = u.exports;
    },
    c19f: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = i(n("035c")), r = i(n("f73d")), l = i(n("3de9")), u = i(n("ed61")), s = n("e308"), o = n("1c29"), p = n("d055"), c = n("435a"), d = n("00cd"), T = n("fad4"), m = {
                default: [ {
                    option: o.InputTerminal.VOLTAGE_CURRENT,
                    label: "电压/电流"
                }, {
                    option: o.InputTerminal.VOLTAGE_POWER,
                    label: "电压/功率"
                }, {
                    option: o.InputTerminal.CURRENT_POWER,
                    label: "电流/功率"
                }, {
                    option: o.InputTerminal.IMPEDANCE,
                    label: "阻抗"
                } ],
                dc: [ {
                    option: o.InputTerminal.VOLTAGE_CURRENT,
                    label: "电压/电流"
                }, {
                    option: o.InputTerminal.VOLTAGE_POWER,
                    label: "电压/功率"
                }, {
                    option: o.InputTerminal.CURRENT_POWER,
                    label: "电流/功率"
                } ]
            }, f = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        inputTerminal: m.default,
                        inputTerminalIndex: 0,
                        defaultPowerUnits: null,
                        voltageDisplay: !0,
                        currentDisplay: !0,
                        impedanceDisplay: !1,
                        powerDisplay: !1,
                        trigonometricTypeDisplay: !0,
                        result: ""
                    };
                },
                mixins: [ a.default, r.default, l.default, u.default ],
                onLoad: function() {
                    this.defaultPowerUnits = this.powerUnits, this.initFeature("load_resistance", s.FeatureType.Calculate);
                },
                methods: {
                    changeCurrentType: function(e) {
                        var t = parseInt(e.detail.value);
                        this.currentType[t].option === p.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: m.dc,
                            powerUnitIndex: 0,
                            powerUnits: this.activePowerUnits
                        }), this.handleDisplay()) : this.currentType[this.currentTypeIndex].option === p.CurrentType.DIRECT_CURRENT ? (this.setData({
                            currentTypeIndex: t,
                            inputTerminalIndex: 0,
                            inputTerminal: m.default,
                            powerUnitIndex: 0,
                            powerUnits: this.defaultPowerUnits
                        }), this.handleDisplay()) : this.setData({
                            currentTypeIndex: t
                        }), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    changeInputTerminal: function(e) {
                        this.setData({
                            inputTerminalIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    changePowerUnit: function(e) {
                        this.setData({
                            powerUnitIndex: parseInt(e.detail.value)
                        }), this.handleDisplay();
                    },
                    handleDisplay: function() {
                        var e = this.inputTerminal[this.inputTerminalIndex].option, t = this.powerUnits[this.powerUnitIndex].name, n = !1;
                        this.currentTypeIndex > 0 && ([ o.InputTerminal.VOLTAGE_CURRENT, o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.IMPEDANCE ].includes(e) || [ o.InputTerminal.CURRENT_POWER ].includes(e) && ![ this.powerAllUnits.W.name, this.powerAllUnits.kW.name, this.powerAllUnits.MW.name, this.powerAllUnits.HP.name ].includes(t)) && (n = !0), 
                        this.setData({
                            voltageDisplay: [ o.InputTerminal.VOLTAGE_CURRENT, o.InputTerminal.VOLTAGE_POWER ].includes(e),
                            currentDisplay: [ o.InputTerminal.VOLTAGE_CURRENT, o.InputTerminal.CURRENT_POWER ].includes(e),
                            impedanceDisplay: [ o.InputTerminal.IMPEDANCE ].includes(e),
                            powerDisplay: [ o.InputTerminal.VOLTAGE_POWER, o.InputTerminal.CURRENT_POWER ].includes(e),
                            trigonometricTypeDisplay: n
                        }), n || this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: this.inputTerminal[this.inputTerminalIndex].option,
                                voltageValue: this.getVoltageUnitValue(),
                                currentValue: this.getCurrentUnitValue(),
                                impedanceValue: this.getImpedanceUnitValue(),
                                powerValue: this.getPowerUnitValue(),
                                powerType: (0, T.toPowerType)(this.powerUnits[this.powerUnitIndex].name),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, c.calculate)(t);
                            if (isNaN(n)) return void this.setData({
                                result: "NaN"
                            });
                            this.setData({
                                result: (0, d.formatFromUnits)(n, o.OhmUnits.O, o.OhmUnits)
                            }), this.use();
                        } catch (t) {
                            if ("∞" === t.message) return void this.setData({
                                result: "∞" + o.OhmUnits.M.name
                            });
                            this.setData({
                                result: ""
                            }), e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = f;
        }).call(this, n("543d").default);
    }
}, [ [ "7602", "common/runtime", "common/vendor" ] ] ]);