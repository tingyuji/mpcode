(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form23/form23" ], {
    "4d4a": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(n("035c")), o = n("e308"), u = n("d417"), i = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        power: "",
                        nloadCurrent: "",
                        result: ""
                    };
                },
                mixins: [ r.default ],
                onLoad: function() {
                    this.initFeature("transformer_power_correction", o.FeatureType.Calculate);
                },
                methods: {
                    powerInput: function(e) {
                        this.setData({
                            power: e.detail.value
                        });
                    },
                    loadInput: function(e) {
                        this.setData({
                            nloadCurrent: e.detail.value
                        });
                    },
                    calculate: function() {
                        if (isNaN(this.power) || isNaN(this.nloadCurrent)) e.showModal({
                            content: "输入值不正确。",
                            showCancel: !1
                        }); else {
                            var t = parseFloat(this.power) * parseFloat(this.nloadCurrent) / 100;
                            this.setData({
                                result: t + " kVAr"
                            }), this.use(), this.$nextTick(function() {
                                (0, u.calculatePageScroll)(1e3);
                            });
                        }
                    }
                }
            };
            t.default = i;
        }).call(this, n("543d").default);
    },
    5379: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("4d4a"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = r.a;
    },
    "5df4": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var r = a(n("a9f7"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    6627: function(e, t, n) {
        "use strict";
        var a = n("6e28");
        n.n(a).a;
    },
    "6e23": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    "6e28": function(e, t, n) {},
    a9f7: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("6e23"), r = n("5379");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("6627");
        var u = n("f0c5"), i = Object(u.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = i.exports;
    }
}, [ [ "5df4", "common/runtime", "common/vendor" ] ] ]);