(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calculate/form4/form4" ], {
    4941: function(e, o, r) {},
    "6d61": function(e, o, r) {
        "use strict";
        r.d(o, "b", function() {
            return l;
        }), r.d(o, "c", function() {
            return n;
        }), r.d(o, "a", function() {
            return a;
        });
        var a = {
            featureBar: function() {
                return Promise.all([ r.e("common/vendor"), r.e("components/feature-bar/feature-bar") ]).then(r.bind(null, "e526"));
            }
        }, l = function() {
            this.$createElement, this._self._c;
        }, n = [];
    },
    "8f90": function(e, o, r) {
        "use strict";
        (function(e) {
            var a = r("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var l = a(r("9523")), n = a(r("035c")), t = a(r("f73d")), c = r("e308"), u = r("933e"), s = r("6e05"), i = r("1c29"), f = r("00cd");
            function d(e, o) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    o && (a = a.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), r.push.apply(r, a);
                }
                return r;
            }
            function b(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var r = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? d(Object(r), !0).forEach(function(o) {
                        (0, l.default)(e, o, r[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : d(Object(r)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(r, o));
                    });
                }
                return e;
            }
            var m = [ s.colors.black.withValue(1), s.colors.brown.withValue(10), s.colors.red.withValue(100), s.colors.orange.withValue(1e3), s.colors.yellow.withValue(1e4), s.colors.green.withValue(1e5), s.colors.blue.withValue(1e6), s.colors.purple.withValue(1e7), s.colors.gray.withValue(1e8), s.colors.white.withValue(1e9), s.colors.silver.withValue(.01), s.colors.gold.withValue(.1) ], v = {
                components: {
                    featureBar: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(r("e526"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    vipMask: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/vip/vip") ]).then(function() {
                            return resolve(r("e665"));
                        }.bind(null, r)).catch(r.oe);
                    }
                },
                data: function() {
                    return {
                        capacitanceDifferences: [ {
                            label: "5% (E24)",
                            value: 5,
                            standard: u.EIA.e24,
                            number: 4,
                            color: s.colors.gold
                        }, {
                            label: "10% (E12)",
                            value: 10,
                            standard: u.EIA.e12,
                            number: 4,
                            color: s.colors.silver
                        }, {
                            label: "20% (E6)",
                            value: 20,
                            standard: u.EIA.e6,
                            number: 4,
                            color: s.colors.none
                        }, {
                            label: "1% (E96)",
                            value: 1,
                            standard: u.EIA.e96,
                            number: 5,
                            color: s.colors.brown
                        }, {
                            label: "2% (E48)",
                            value: 2,
                            standard: u.EIA.e48,
                            number: 5,
                            color: s.colors.red
                        }, {
                            label: "0.5% (E192)",
                            value: .5,
                            standard: u.EIA.e192,
                            number: 5,
                            color: s.colors.green
                        }, {
                            label: "0.25% (E192)",
                            value: .25,
                            standard: u.EIA.e192,
                            number: 5,
                            color: s.colors.blue
                        }, {
                            label: "0.1% (E192)",
                            value: .1,
                            standard: u.EIA.e192,
                            number: 5,
                            color: s.colors.purple
                        }, {
                            label: "0.05% (E192)",
                            value: .05,
                            standard: u.EIA.e192,
                            number: 5,
                            color: s.colors.gray
                        } ],
                        capacitanceDifferencesIndex: 0,
                        ppm: [ {
                            label: 250,
                            value: 250,
                            color: s.colors.black
                        }, {
                            label: 100,
                            value: 100,
                            color: s.colors.brown
                        }, {
                            label: 50,
                            value: 50,
                            color: s.colors.red
                        }, {
                            label: 15,
                            value: 15,
                            color: s.colors.orange
                        }, {
                            label: 25,
                            value: 25,
                            color: s.colors.yellow
                        }, {
                            label: 20,
                            value: 20,
                            color: s.colors.green
                        }, {
                            label: 10,
                            value: 10,
                            color: s.colors.blue
                        }, {
                            label: 5,
                            value: 5,
                            color: s.colors.purple
                        }, {
                            label: 1,
                            value: 1,
                            color: s.colors.gray
                        }, {
                            label: "无",
                            value: 0,
                            color: s.colors.none
                        } ],
                        ppmIndex: 9,
                        loading: !0,
                        colors: [],
                        result: "",
                        resistanceUnits: [],
                        resistanceUnitIndex: 0,
                        feature: {},
                        resistanceUnitValue: "",
                        name: "",
                        label: "",
                        vipRequired: !1
                    };
                },
                mixins: [ n.default, t.default ],
                onLoad: function() {
                    this.initFeature("resistance_to_color_ring", c.FeatureType.Calculate);
                },
                onShow: function() {
                    this.setData({
                        resistanceUnits: [ i.OhmUnits.O, i.OhmUnits.k, i.OhmUnits.M ],
                        resistanceUnitIndex: 0
                    });
                },
                methods: {
                    calculate: function() {
                        var o = this.getResistanceUnitValue(), r = this.capacitanceDifferences[this.capacitanceDifferencesIndex], a = this.ppm[this.ppmIndex];
                        try {
                            o = this.calculateResistance(o, r.standard);
                            var l = this.getColors(o, r, a);
                            this.setData({
                                loading: !1,
                                colors: l,
                                result: "".concat((0, f.formatFromUnits)(o, i.OhmUnits.O, i.OhmUnits), " ± ").concat(r.value, "%")
                            });
                        } catch (o) {
                            this.setData({
                                loading: !0
                            }), "-1" !== o.message && e.showModal({
                                title: "注意！",
                                content: o.message,
                                showCancel: !1
                            });
                        }
                    },
                    calculateResistance: function(e, o) {
                        if (e < .1 || e > 99e7) throw new Error("电阻数值无效");
                        var r = (0, u.convert)(o, .001), a = r.length - 1;
                        if (a < 0) return e;
                        for (var l = Number.MAX_VALUE, n = 0, t = 1e4; t; ) {
                            var c = n + 1, s = Math.abs(e - r[n]);
                            if (s >= l) {
                                e = r[n - 1];
                                break;
                            }
                            c <= a && (n = c, l = s), t--;
                        }
                        return console.log(r, e), e;
                    },
                    getColors: function(e, o, r) {
                        var a = 2;
                        if (o.number > 4 && (a = 3, e < 1)) throw new Error("-1");
                        e = parseFloat(String(e).replace(/9{2,}/, ""));
                        var l, n = JSON.parse(JSON.stringify(m));
                        n = (n = n.map(function(e) {
                            return b(b({}, e), {}, {
                                value: e.value * Math.pow(10, a)
                            });
                        })).sort(function(e, o) {
                            return o.value - e.value;
                        });
                        var t = Math.pow(10, a - 1);
                        e = Math.round(e * Math.pow(10, a)), l = n.findIndex(function(o) {
                            var r = e / o.value;
                            if (r >= t && -1 === String(r).indexOf(".")) return !0;
                        });
                        var c, u = (e = Math.ceil(e / n[l].value)) % 10, s = Math.floor(e / 10) % 10, i = Math.floor(e / 100) % 10;
                        return c = o.number > 4 ? [ {
                            name: m[i].name,
                            color: m[i].color
                        }, {
                            name: m[s].name,
                            color: m[s].color
                        }, {
                            name: m[u].name,
                            color: m[u].color
                        }, {
                            name: n[l].name,
                            color: n[l].color
                        }, {
                            name: o.color.name,
                            color: o.color.color
                        }, {
                            name: r.color.name,
                            color: r.color.color
                        } ] : [ {
                            name: m[s].name,
                            color: m[s].color
                        }, {
                            name: m[u].name,
                            color: m[u].color
                        }, {
                            name: n[l].name,
                            color: n[l].color
                        }, {
                            name: o.color.name,
                            color: o.color.color
                        } ], console.log("".concat(i).concat(s).concat(u), e, b(b({}, n[l]), {}, {
                            value: n[l].value / Math.pow(10, a)
                        }), c), c;
                    }
                }
            };
            o.default = v;
        }).call(this, r("543d").default);
    },
    "9ebe": function(e, o, r) {
        "use strict";
        (function(e, o) {
            var a = r("4ea4");
            r("8a42"), a(r("66fd"));
            var l = a(r("eb19"));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, o(l.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    adb9: function(e, o, r) {
        "use strict";
        r.r(o);
        var a = r("8f90"), l = r.n(a);
        for (var n in a) [ "default" ].indexOf(n) < 0 && function(e) {
            r.d(o, e, function() {
                return a[e];
            });
        }(n);
        o.default = l.a;
    },
    d77f: function(e, o, r) {
        "use strict";
        var a = r("4941");
        r.n(a).a;
    },
    eb19: function(e, o, r) {
        "use strict";
        r.r(o);
        var a = r("6d61"), l = r("adb9");
        for (var n in l) [ "default" ].indexOf(n) < 0 && function(e) {
            r.d(o, e, function() {
                return l[e];
            });
        }(n);
        r("d77f");
        var t = r("f0c5"), c = Object(t.a)(l.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        o.default = c.exports;
    }
}, [ [ "9ebe", "common/runtime", "common/vendor" ] ] ]);