(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exam/buy" ], {
    "160a": function(e, t, a) {
        "use strict";
        a.r(t);
        var i = a("dc91"), n = a.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            a.d(t, e, function() {
                return i[e];
            });
        }(s);
        t.default = n.a;
    },
    4619: function(e, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return i;
        }), a.d(t, "c", function() {
            return n;
        }), a.d(t, "a", function() {});
        var i = function() {
            this.$createElement, this._self._c;
        }, n = [];
    },
    "48cf": function(e, t, a) {
        "use strict";
        (function(e, t) {
            var i = a("4ea4");
            a("8a42"), i(a("66fd"));
            var n = i(a("bb72"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, t(n.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    5000: function(e, t, a) {
        "use strict";
        var i = a("e2af");
        a.n(i).a;
    },
    bb72: function(e, t, a) {
        "use strict";
        a.r(t);
        var i = a("4619"), n = a("160a");
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(s);
        a("5000");
        var o = a("f0c5"), d = Object(o.a)(n.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = d.exports;
    },
    dc91: function(e, t, a) {
        "use strict";
        (function(e) {
            var i = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = i(a("b253")), s = a("963d"), o = i(a("ac2e")), d = a("9673"), c = {
                data: function() {
                    return {
                        address: [],
                        provinceList: [],
                        cityAllList: [],
                        provinceIdList: [],
                        cityIdList: [],
                        areaIdList: [],
                        areaAllList: [],
                        addressIndex: [ 0, 0, 0 ],
                        addressNode: {
                            province: "请选择城市",
                            city: "",
                            area: ""
                        },
                        addressId: {
                            provinceId: 0,
                            cityId: 0,
                            areaId: 0
                        },
                        provinceIndex: 0,
                        subjects: [],
                        currenSubjectId: "",
                        subjectName: "",
                        price: "",
                        countdown: "",
                        timer: null,
                        openId: null,
                        imgBaseUrl: s.staticExamUrl
                    };
                },
                mixins: [ o.default ],
                onLoad: function() {
                    this.getAddressData(), this.getSubjectData(), this.initTime();
                },
                methods: {
                    goPay: function() {
                        this.user ? this.openId ? this.pay() : this.wechatLogin() : this.login();
                    },
                    login: function() {
                        (0, d.loginRequired)().then(function() {}, function() {
                            e.showToast({
                                title: "已取消登录",
                                icon: "none"
                            });
                        });
                    },
                    pay: function() {
                        "" !== this.addressNode.province && "" !== this.addressNode.city && "" !== this.addressNode.area ? this.mpPay() : e.showToast({
                            title: "请选择省市区",
                            icon: "none"
                        });
                    },
                    getPlaceId: function() {
                        var e = this;
                        this.provinceIdList.forEach(function(t) {
                            t.name === e.addressNode.province && (e.addressId.provinceId = t.id);
                        }), this.cityIdList.forEach(function(t) {
                            t.name === e.addressNode.city && (e.addressId.cityId = t.id);
                        }), this.areaIdList.forEach(function(t) {
                            t.name === e.addressNode.area && (e.addressId.areaId = t.id);
                        });
                    },
                    mpPay: function() {
                        var t = this;
                        this.getPlaceId();
                        var a = {
                            username: this.user.nickname,
                            phone_number: this.user.phone_number,
                            province: this.addressId.provinceId,
                            city: this.addressId.cityId,
                            area: this.addressId.areaId,
                            source: "电工大师",
                            subject_id: this.currenSubjectId,
                            openid: this.openId,
                            pay_type: 1
                        };
                        e.showLoading({
                            title: "支付中",
                            mask: !0
                        });
                        var i = this;
                        n.default.postExam(s.apiExamUrl + "exams", a).then(function(o) {
                            e.requestPayment({
                                provider: "wxpay",
                                timeStamp: o.data.payment.timeStamp,
                                nonceStr: o.data.payment.nonceStr,
                                package: o.data.payment.package,
                                signType: o.data.payment.signType,
                                paySign: o.data.payment.paySign,
                                success: function(t) {
                                    var d = this;
                                    this.pull = function() {
                                        n.default.getExam(s.apiExamUrl + "exams/" + o.data.order_no).then(function(t) {
                                            1 == t.data.status ? (e.hideLoading(), a.subject_name = i.subjectName, a.province = i.addressNode.province, 
                                            a.city = i.addressNode.city, a.area = i.addressNode.area, e.$on("exam-success-data-on", function() {
                                                e.$emit("exam-success-data", a);
                                            }), e.showToast({
                                                title: "支付成功",
                                                icon: "success"
                                            }), setTimeout(function() {
                                                e.reLaunch({
                                                    url: "/pages/exam/success"
                                                });
                                            }, 1500)) : setTimeout(d.pull, 1500);
                                        }, function(t) {
                                            e.showModal({
                                                title: "查询订单状态异常",
                                                content: t.message,
                                                showCancel: !1
                                            });
                                        });
                                    }, e.showLoading({
                                        title: "等待支付结果",
                                        mask: !0
                                    }), this.pull();
                                },
                                fail: function(a) {
                                    e.hideLoading();
                                    var i = a.errMsg.substring(20).trim();
                                    "cancel" == i && (i = "您已取消支付。"), t.failedModal(i);
                                }
                            });
                        }, function(a) {
                            e.hideLoading(), t.failedModal(a.message);
                        });
                    },
                    failedModal: function(t) {
                        var a = this;
                        e.showModal({
                            title: "支付失败",
                            content: t,
                            cancelText: "取消",
                            confirmText: "重新支付",
                            success: function(e) {
                                e.confirm && a.mpPay();
                            }
                        });
                    },
                    wechatLogin: function() {
                        var t = this;
                        e.login({
                            success: function(a) {
                                e.showLoading(), n.default.postExam(s.apiExamUrl + "auth/wechat-miniprogram", {
                                    code: a.code
                                }).then(function(a) {
                                    e.hideLoading(), t.openId = a.data.openid, t.pay();
                                }, function(t) {
                                    e.hideLoading(), e.showModal({
                                        content: t.message,
                                        showCancel: !1
                                    });
                                });
                            }
                        });
                    },
                    initTime: function() {
                        var e = this;
                        this.showtime(), this.timer = setInterval(function() {
                            e.showtime();
                        }, 1e3);
                    },
                    showtime: function() {
                        var t = new Date(), a = e.getStorageSync("exam_endTime");
                        a || (a = new Date(t.getTime() + 86399e3), e.setStorageSync("exam_endTime", a));
                        var i = a.getTime() - t.getTime(), n = Math.floor(i / 864e5), s = Math.floor(i / 36e5 % 24 + 24 * n) < 10 ? "0" + Math.floor(i / 36e5 % 24 + 24 * n) : Math.floor(i / 36e5 % 24 + 24 * n), o = Math.floor(i / 6e4 % 60) < 10 ? "0" + Math.floor(i / 6e4 % 60) : Math.floor(i / 6e4 % 60), d = Math.floor(i / 1e3 % 60) < 10 ? "0" + Math.floor(i / 1e3 % 60) : Math.floor(i / 1e3 % 60);
                        this.countdown = s + ":" + o + ":" + d + " 后过期 ", i < 0 && (s = o = d = "00", this.countdown = "即将结束");
                    },
                    choose: function(e) {
                        this.currenSubjectId = e.id, this.subjectName = e.name, this.price = e.price;
                    },
                    getSubjectData: function() {
                        var t = this;
                        e.showLoading(), n.default.getExam(s.apiExamUrl + "subject").then(function(a) {
                            e.hideLoading(), t.subjects = a.data, t.currenSubjectId = t.subjects[0].id, t.subjectName = t.subjects[0].name, 
                            t.price = t.subjects[0].price;
                        }, function(t) {
                            e.hideLoading(), e.showModal({
                                content: t.message,
                                showCancel: !1
                            });
                        });
                    },
                    selCity: function(e) {
                        var t = e.target.value;
                        this.setCity(t);
                    },
                    setCity: function(e) {
                        this.addressNode = {
                            province: this.address[0][e[0]],
                            city: this.address[1][e[1]],
                            area: this.address[2][e[2]]
                        };
                    },
                    selMonitor: function(e) {
                        var t = this, a = e.detail.column, i = e.detail.value, n = [];
                        switch (a) {
                          case 0:
                            this.address[1] = this.cityAllList[i], this.areaAllList[i].forEach(function(e) {
                                e.key == i && 0 == e.key2 && n.push(e.name);
                            }), this.address[2] = n, this.setCity([ i, 0, 0 ]), this.provinceIndex = i, this.addressIndex = [ i, 0, 0 ];
                            break;

                          case 1:
                            this.areaAllList[this.provinceIndex].forEach(function(e) {
                                e.key == t.provinceIndex && e.key2 == i && n.push(e.name);
                            }), this.addressNode.city = this.address[1][i], this.address[2] = n, this.addressIndex = [ this.provinceIndex, i, 0 ];
                        }
                    },
                    getAddressData: function() {
                        var t = this, a = [], i = [], n = [], o = [], d = [], c = [];
                        e.request({
                            url: s.staticExamUrl + "address.json",
                            success: function(e) {
                                var s = e.data, r = function(e) {
                                    var t = [], r = [];
                                    if (s[e].children) {
                                        var u = function(a) {
                                            t.push(s[e].children[a].name), d.push({
                                                id: s[e].children[a].id,
                                                name: s[e].children[a].name
                                            }), s[e].children[a].children && s[e].children[a].children.forEach(function(t) {
                                                r.push({
                                                    key: e,
                                                    key2: a,
                                                    name: t.name
                                                }), c.push({
                                                    id: t.id,
                                                    name: t.name
                                                });
                                            });
                                        };
                                        for (var h in s[e].children) u(h);
                                    }
                                    a.push(s[e].name), o.push({
                                        id: s[e].id,
                                        name: s[e].name
                                    }), i.push(t), n.push(r);
                                };
                                for (var u in s) r(u);
                                t.provinceList = a, t.provinceIdList = o, t.cityAllList = i, t.cityIdList = d, t.areaAllList = n, 
                                t.areaIdList = c;
                                var h = [];
                                t.areaAllList[0].forEach(function(e) {
                                    h.push(e.name);
                                }), t.address = [ a, i[0], h ];
                            }
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, a("543d").default);
    },
    e2af: function(e, t, a) {}
}, [ [ "48cf", "common/runtime", "common/vendor" ] ] ]);