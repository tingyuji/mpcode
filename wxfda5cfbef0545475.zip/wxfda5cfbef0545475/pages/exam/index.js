(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exam/index" ], {
    "0db8": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {});
        var i = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "2e21": function(t, e, n) {},
    "6bb6": function(t, e, n) {
        "use strict";
        var i = n("2e21");
        n.n(i).a;
    },
    bd01: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("0db8"), c = n("fe17");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(o);
        n("6bb6");
        var r = n("f0c5"), s = Object(r.a)(c.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = s.exports;
    },
    cdbf: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("963d"), c = {
                data: function() {
                    return {
                        currentType: "value",
                        menus: [ {
                            id: "value",
                            name: "证书价值",
                            top: 0
                        }, {
                            id: "introduce",
                            name: "报考介绍",
                            top: 0
                        }, {
                            id: "gift",
                            name: "限量礼包",
                            top: 0
                        }, {
                            id: "question",
                            name: "常见问题",
                            top: 0
                        } ],
                        imgBaseUrl: i.staticExamUrl,
                        clickScroll: !1
                    };
                },
                computed: {
                    halfHeight: function() {
                        var e = t.getSystemInfoSync();
                        return parseInt(e.windowHeight) / 2;
                    }
                },
                onPageScroll: function(t) {
                    if (!this.clickScroll) {
                        var e = parseInt(t.scrollTop);
                        e >= parseInt(this.menus[0].top) - this.halfHeight && e <= parseInt(this.menus[1].top) - this.halfHeight ? this.currentType = this.menus[0].id : e > parseInt(this.menus[1].top) - this.halfHeight && e <= parseInt(this.menus[2].top) - this.halfHeight ? this.currentType = this.menus[1].id : e > parseInt(this.menus[2].top) - this.halfHeight && e <= parseInt(this.menus[3].top) - this.halfHeight ? this.currentType = this.menus[2].id : e > parseInt(this.menus[3].top) - this.halfHeight && (this.currentType = this.menus[3].id);
                    }
                },
                onReady: function() {
                    var e = this;
                    setTimeout(function() {
                        var n = t.createSelectorQuery().in(e);
                        e.menus.forEach(function(t) {
                            n.select("#" + t.id).boundingClientRect(function(e) {
                                console.log("节点离页面顶部的距离为" + e.top), t.top = parseInt(e.top) - 50;
                            }).exec();
                        });
                    }, 500);
                },
                methods: {
                    scrollTo: function(e, n) {
                        var i = this;
                        this.clickScroll = !0, this.currentType = e, t.pageScrollTo({
                            scrollTop: n,
                            duration: 300
                        }), setTimeout(function() {
                            i.clickScroll = !1;
                        }, 350);
                    }
                }
            };
            e.default = c;
        }).call(this, n("543d").default);
    },
    ec82: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var c = i(n("bd01"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    fe17: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("cdbf"), c = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = c.a;
    }
}, [ [ "ec82", "common/runtime", "common/vendor" ] ] ]);