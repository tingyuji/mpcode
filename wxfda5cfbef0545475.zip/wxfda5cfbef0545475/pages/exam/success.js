(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exam/success" ], {
    "08a5": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var c = a(t("8d0e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(c.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "0b56": function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t("963d"), c = {
                data: function() {
                    return {
                        username: "",
                        phoneNumber: "",
                        subjectName: "",
                        place: "",
                        imgBaseUrl: a.staticExamUrl
                    };
                },
                onLoad: function() {
                    var n = this;
                    e.$on("exam-success-data", function(e) {
                        n.username = e.username, n.phoneNumber = e.phone_number, n.subjectName = e.subject_name, 
                        n.place = e.province + e.city + e.area;
                    }), e.$emit("exam-success-data-on");
                },
                onUnload: function() {
                    e.$off("exam-success-data"), e.$off("exam-success-data-on");
                }
            };
            n.default = c;
        }).call(this, t("543d").default);
    },
    "1f32": function(e, n, t) {},
    "5c40": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("0b56"), c = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = c.a;
    },
    "83f7": function(e, n, t) {
        "use strict";
        var a = t("1f32");
        t.n(a).a;
    },
    "8c29": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "8d0e": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("8c29"), c = t("5c40");
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(u);
        t("83f7");
        var o = t("f0c5"), r = Object(o.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = r.exports;
    }
}, [ [ "08a5", "common/runtime", "common/vendor" ] ] ]);