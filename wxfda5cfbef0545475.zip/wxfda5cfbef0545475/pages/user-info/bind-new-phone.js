(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user-info/bind-new-phone" ], {
    "2b37": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("75ff"), a = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = a.a;
    },
    "37f9": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    6206: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var a = o(t("e171"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "6f98": function(e, n, t) {
        "use strict";
        var o = t("9e25");
        t.n(o).a;
    },
    "75ff": function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = o(t("b253")), i = getApp(), c = {
                data: function() {
                    return {
                        phone: "",
                        code: "",
                        codeSend: !1,
                        codeText: "获取验证码",
                        codeTimout: 120
                    };
                },
                methods: {
                    sendPhoneCode: function() {
                        var n = this;
                        e.showLoading({
                            title: "短信发送中"
                        }), a.default.post("getPhoneCode", {
                            phone: this.phone,
                            type: "new_phone_validate"
                        }).then(function(t) {
                            console.log(t), e.hideLoading(), n.codeTimout = t.data.leftSeconds, n.codeSend = !0;
                            var o = setInterval(function() {
                                n.codeTimout <= 1 && (n.codeSend = !1, n.codeText = "重新获取验证码", clearInterval(o)), 
                                n.codeTimout -= 1;
                            }, 1e3);
                        }).catch(function(n) {
                            e.hideLoading(), e.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    },
                    submit: function() {
                        var n = {
                            phone: this.phone,
                            code: this.code,
                            type: "new_phone_validate"
                        };
                        e.showLoading(), a.default.post("newPhoneBind", n).then(function(n) {
                            e.hideLoading(), e.showToast({
                                title: "绑定成功",
                                icon: "success"
                            }), i.globalData.updateUser(), setTimeout(function() {
                                e.navigateBack({
                                    delta: 2
                                });
                            }, 2e3);
                        }).catch(function(n) {
                            e.hideLoading(), e.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, t("543d").default);
    },
    "9e25": function(e, n, t) {},
    e171: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("37f9"), a = t("2b37");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        t("6f98");
        var c = t("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = u.exports;
    }
}, [ [ "6206", "common/runtime", "common/vendor" ] ] ]);