(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user-info/verify-original-phone" ], {
    1409: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var a = o(t("35da"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "35da": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("d374"), a = t("6a69");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        t("f976");
        var c = t("f0c5"), d = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = d.exports;
    },
    "6a69": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("b0d5"), a = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = a.a;
    },
    a120: function(e, n, t) {},
    b0d5: function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = o(t("b253")), i = (getApp(), {
                data: function() {
                    return {
                        phone: "",
                        code: "",
                        codeSend: !1,
                        codeText: "获取验证码",
                        codeTimout: 120
                    };
                },
                methods: {
                    sendPhoneCode: function() {
                        var n = this;
                        e.showLoading({
                            title: "短信发送中"
                        }), a.default.post("getPhoneCode", {
                            phone: this.phone,
                            type: "old_phone_validate"
                        }).then(function(t) {
                            console.log(t), e.hideLoading(), n.codeTimout = t.data.leftSeconds, n.codeSend = !0;
                            var o = setInterval(function() {
                                n.codeTimout <= 1 && (n.codeSend = !1, n.codeText = "重新获取验证码", clearInterval(o)), 
                                n.codeTimout -= 1;
                            }, 1e3);
                        }).catch(function(n) {
                            e.hideLoading(), e.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    },
                    submit: function() {
                        var n = {
                            phone: this.phone,
                            code: this.code,
                            type: "old_phone_validate"
                        };
                        e.showLoading(), a.default.post("phoneValidate", n).then(function(n) {
                            e.hideLoading(), e.showToast({
                                title: "验证成功",
                                icon: "success"
                            }), setTimeout(function() {
                                e.navigateTo({
                                    url: "/pages/user-info/bind-new-phone"
                                });
                            }, 2e3);
                        }).catch(function(n) {
                            e.hideLoading(), e.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    }
                }
            });
            n.default = i;
        }).call(this, t("543d").default);
    },
    d374: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    f976: function(e, n, t) {
        "use strict";
        var o = t("a120");
        t.n(o).a;
    }
}, [ [ "1409", "common/runtime", "common/vendor" ] ] ]);