(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user-info/change-name" ], {
    3934: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var i = a(t("f44a"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "66df": function(n, e, t) {
        "use strict";
        var a = t("6da9");
        t.n(a).a;
    },
    6777: function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "6da9": function(n, e, t) {},
    a83e: function(n, e, t) {
        "use strict";
        t.r(e);
        var a = t("b82c"), i = t.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        e.default = i.a;
    },
    b82c: function(n, e, t) {
        "use strict";
        (function(n) {
            var a = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(t("b253")), c = getApp(), o = {
                data: function() {
                    return {
                        nickname: null
                    };
                },
                onLoad: function(n) {
                    this.nickname = n.nickname;
                },
                methods: {
                    getNickname: function(n) {
                        console.log(n), this.nickname = n.detail.value;
                    },
                    editNickname: function() {
                        var e = this;
                        n.showLoading({
                            title: "加载中"
                        });
                        var t = {
                            nickname: this.nickname
                        };
                        i.default.post("editNickname", t).then(function(t) {
                            n.hideLoading(), e.nickname = t.nickname, c.globalData.updateUser(), n.showToast({
                                title: "修改成功",
                                icon: "success"
                            }), setTimeout(function() {
                                n.navigateBack();
                            }, 2e3);
                        }, function(e) {
                            n.hideLoading(), n.showToast({
                                title: e.message,
                                icon: "none"
                            });
                        });
                    }
                }
            };
            e.default = o;
        }).call(this, t("543d").default);
    },
    f44a: function(n, e, t) {
        "use strict";
        t.r(e);
        var a = t("6777"), i = t("a83e");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(c);
        t("66df");
        var o = t("f0c5"), u = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = u.exports;
    }
}, [ [ "3934", "common/runtime", "common/vendor" ] ] ]);