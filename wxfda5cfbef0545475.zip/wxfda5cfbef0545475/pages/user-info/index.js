(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user-info/index" ], {
    2867: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("fce2"), a = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = a.a;
    },
    "2c2c": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var a = o(t("fb69"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    3970: function(e, n, t) {
        "use strict";
        var o = t("6d87");
        t.n(o).a;
    },
    "6d87": function(e, n, t) {},
    e663: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    fb69: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("e663"), a = t("2867");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        t("3970");
        var c = t("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = u.exports;
    },
    fce2: function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = o(t("b253")), i = o(t("ac2e")), c = (t("a195"), getApp()), u = {
                mixins: [ i.default ],
                methods: {
                    location: function(n) {
                        e.navigateTo({
                            url: n
                        });
                    },
                    onChooseAvatar: function(e) {
                        var n = e.detail.avatarUrl;
                        this.uploadImg(n);
                    },
                    editHeadImg: function() {
                        var n = this;
                        e.chooseImage({
                            count: 1,
                            mediaType: [ "image" ],
                            sourceType: [ "album" ],
                            success: function(e) {
                                console.log(e);
                                var t = e.tempFilePaths[0];
                                n.uploadImg(t);
                            },
                            fail: function(n) {
                                console.log(n), e.showToast({
                                    title: n,
                                    duration: 2e3
                                });
                            }
                        });
                    },
                    uploadImg: function(n) {
                        e.showLoading({
                            title: "加载中"
                        }), console.log(n), e.uploadFile({
                            url: a.default.getUrl("uploadUserHead"),
                            header: a.default.commonHeader(),
                            filePath: n,
                            name: "file",
                            success: function(e) {
                                console.log(JSON.parse(e.data)), c.globalData.updateUser();
                            },
                            fail: function(n) {
                                e.showToast({
                                    title: n,
                                    duration: 2e3
                                });
                            },
                            complete: function() {
                                e.hideLoading();
                            }
                        });
                    },
                    confirm: function(n) {
                        e.showModal({
                            title: "更换绑定的手机号？",
                            content: "当前绑定手机号码为\n" + n,
                            confirmText: "更换",
                            cancelText: "取消",
                            success: function(n) {
                                n.confirm && e.navigateTo({
                                    url: "/pages/user-info/verify-original-phone"
                                });
                            }
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, t("543d").default);
    }
}, [ [ "2c2c", "common/runtime", "common/vendor" ] ] ]);