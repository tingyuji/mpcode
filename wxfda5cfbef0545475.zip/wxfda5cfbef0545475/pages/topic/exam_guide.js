(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/exam_guide" ], {
    "0524": function(t, e, a) {
        "use strict";
        var i = a("9739");
        a.n(i).a;
    },
    "281d": function(t, e, a) {
        "use strict";
        (function(t, e) {
            var i = a("4ea4");
            a("8a42"), i(a("66fd"));
            var n = i(a("5f27"));
            t.__webpack_require_UNI_MP_PLUGIN__ = a, e(n.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    "56f3": function(t, e, a) {
        "use strict";
        (function(t) {
            var i = a("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = i(a("b253")), r = i(a("ac2e")), o = (i(a("1733")), {
                data: function() {
                    return {
                        library_id: "",
                        type: 2,
                        qualified: 0,
                        average: 0,
                        scoresList: []
                    };
                },
                mixins: [ r.default ],
                onShow: function() {
                    this.initData();
                },
                onLoad: function(t) {
                    void 0 !== t.library_id && (this.library_id = t.library_id);
                },
                methods: {
                    initData: function() {
                        var t = this;
                        n.default.get("topic/scoresList").then(function(e) {
                            t.scoresList = e.data;
                            var a = 0;
                            t.scoresList.forEach(function(e) {
                                a += e.score_total, e.score_total >= 60 && t.qualified++;
                            }), t.average = a ? a / t.scoresList.length : 0, t.average = t.average.toFixed(2);
                        });
                    },
                    starta: function() {
                        t.navigateTo({
                            url: "/pages/topic/record?library_id=" + this.library_id + "&type=2"
                        });
                    }
                }
            });
            e.default = o;
        }).call(this, a("543d").default);
    },
    "5b16": function(t, e, a) {
        "use strict";
        a.d(e, "b", function() {
            return i;
        }), a.d(e, "c", function() {
            return n;
        }), a.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            var t = (this._self._c, this.scoresList.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, n = [];
    },
    "5f27": function(t, e, a) {
        "use strict";
        a.r(e);
        var i = a("5b16"), n = a("a24e");
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(r);
        a("0524");
        var o = a("f0c5"), c = Object(o.a)(n.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = c.exports;
    },
    9739: function(t, e, a) {},
    a24e: function(t, e, a) {
        "use strict";
        a.r(e);
        var i = a("56f3"), n = a.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            a.d(e, t, function() {
                return i[t];
            });
        }(r);
        e.default = n.a;
    }
}, [ [ "281d", "common/runtime", "common/vendor" ] ] ]);