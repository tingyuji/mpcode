(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/records_null" ], {
    "058e": function(t, e, o) {
        "use strict";
        o.r(e);
        var r = o("39a4"), i = o("ff0e");
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(s);
        o("0e41");
        var n = o("f0c5"), c = Object(n.a)(i.default, r.b, r.c, !1, null, "d851be98", null, !1, r.a, void 0);
        e.default = c.exports;
    },
    "0e41": function(t, e, o) {
        "use strict";
        var r = o("da03");
        o.n(r).a;
    },
    "1dd9": function(t, e, o) {
        "use strict";
        (function(t) {
            var r = o("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = r(o("b253")), s = {
                name: "record",
                data: function() {
                    return {
                        selectanswer: "",
                        library_id: "",
                        answers_total: 0,
                        show_total: "",
                        type: "",
                        record_list: [],
                        records_id: "",
                        null_record_list: []
                    };
                },
                onLoad: function(t) {
                    void 0 !== t.records_id && (this.records_id = t.records_id, this.initData());
                },
                methods: {
                    initData: function() {
                        var t = this;
                        i.default.get("topic/recordsError?records_id=" + this.records_id).then(function(e) {
                            console.log(e.data), t.record_list = e.data.records, t.answers_total = 0, t.show_total = 0;
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    confirmtopic: function(t) {
                        this.selectanswer = t;
                    },
                    ontopic: function() {
                        this.show_total--, this.answers_total;
                    },
                    nexttopic: function() {
                        var t = this;
                        if ("" === this.selectanswer) return this.null_record_list.push(this.show_total), 
                        this.show_total++, this.answers_total++, void (this.selectanswer = "");
                        var e = {
                            result: this.record_list[this.show_total].topics.topicoptions[this.selectanswer].correct,
                            topics_id: this.record_list[this.show_total].id,
                            records_id: this.records_id
                        };
                        i.default.post("topic/testrecords", e).then(function(e) {
                            t.show_total++, t.answers_total++, t.selectanswer = "", t.answers_total == t.record_list.length && t.complete();
                        }, function(t) {
                            console.log(t);
                        });
                    },
                    complete: function() {
                        t.redirectTo({
                            url: "/pages/topic/results?records_id=" + this.records_id + "&library_id=" + this.library_id
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, o("543d").default);
    },
    "39a4": function(t, e, o) {
        "use strict";
        o.d(e, "b", function() {
            return r;
        }), o.d(e, "c", function() {
            return i;
        }), o.d(e, "a", function() {});
        var r = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    da03: function(t, e, o) {},
    f885: function(t, e, o) {
        "use strict";
        (function(t, e) {
            var r = o("4ea4");
            o("8a42"), r(o("66fd"));
            var i = r(o("058e"));
            t.__webpack_require_UNI_MP_PLUGIN__ = o, e(i.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    },
    ff0e: function(t, e, o) {
        "use strict";
        o.r(e);
        var r = o("1dd9"), i = o.n(r);
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(t) {
            o.d(e, t, function() {
                return r[t];
            });
        }(s);
        e.default = i.a;
    }
}, [ [ "f885", "common/runtime", "common/vendor" ] ] ]);