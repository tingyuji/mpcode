(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/index" ], {
    "08cc": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("e8d2"), o = e.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        n.default = o.a;
    },
    2966: function(t, n, e) {},
    "4ffc": function(t, n, e) {
        "use strict";
        var i = e("2966");
        e.n(i).a;
    },
    "5e52": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("602e"), o = e("08cc");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("4ffc");
        var r = e("f0c5"), c = Object(r.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        n.default = c.exports;
    },
    "602e": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            vip: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(e.bind(null, "e665"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "8bc3": function(t, n, e) {
        "use strict";
        (function(t, n) {
            var i = e("4ea4");
            e("8a42"), i(e("66fd"));
            var o = i(e("5e52"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(o.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    e8d2: function(t, n, e) {
        "use strict";
        (function(t) {
            var i = e("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = i(e("b253")), a = e("9673"), r = e("963d"), c = {
                data: function() {
                    return {
                        id: "",
                        BaseUrl: r.BaseUrl,
                        library: {
                            name: "请选择题库",
                            answers_total: 0
                        },
                        topicUserRecord: {
                            answers_total: 0
                        },
                        score_total: ""
                    };
                },
                mixins: [ i(e("ac2e")).default ],
                components: {
                    vip: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                            return resolve(e("e665"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                onShow: function() {
                    this.initData();
                },
                onLoad: function(n) {
                    void 0 !== n.id ? (this.id = n.id, t.setStorageSync("LibraryId", this.id)) : this.id = t.getStorageSync("LibraryId");
                },
                methods: {
                    initData: function() {
                        var t = this;
                        o.default.get("topic/index?id=" + this.id).then(function(n) {
                            t.library.name = n.data.topicLibrary.name, t.topicUserRecord = n.data.topicUserRecord, 
                            t.library.answers_total = n.data.librarytotal, t.score_total = n.data.score_total, 
                            t.id = n.data.topicLibrary.id;
                        }, function(n) {
                            403 == n.data.code && (t.library.name = "VIP题库", t.library.answers_total = 0);
                        });
                    },
                    exchangeRecord: function() {
                        var n = this;
                        this.login(function() {
                            t.navigateTo({
                                url: "/pages/topic/record?library_id=" + n.id + "&type=1"
                            });
                        });
                    },
                    exchangeTest: function() {
                        var n = this;
                        this.login(function() {
                            t.navigateTo({
                                url: "/pages/topic/exam_guide?library_id=" + n.id + "&type=2"
                            });
                        });
                    },
                    exchangeFavorites: function(n) {
                        this.login(function() {
                            t.navigateTo({
                                url: "/pages/topic/record?record_model=" + n
                            });
                        });
                    },
                    login: function(n) {
                        (0, a.loginRequired)().then(function() {
                            "function" == typeof n && n();
                        }, function() {
                            t.showToast({
                                title: "已取消登录",
                                icon: "none"
                            });
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, e("543d").default);
    }
}, [ [ "8bc3", "common/runtime", "common/vendor" ] ] ]);