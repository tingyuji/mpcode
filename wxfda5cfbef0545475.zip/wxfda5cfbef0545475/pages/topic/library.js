(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/library" ], {
    "254c": function(t, n, i) {
        "use strict";
        (function(t) {
            var e = i("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = e(i("b253")), u = {
                data: function() {
                    return {
                        libraryList: [],
                        id: ""
                    };
                },
                onShow: function() {
                    this.initData();
                },
                onLoad: function(t) {
                    void 0 !== t.id && (this.id = t.id);
                },
                methods: {
                    initData: function() {
                        var t = this;
                        a.default.get("topic/subjectLibrary").then(function(n) {
                            t.libraryList = n.data;
                        });
                    },
                    sellibrary: function(n) {
                        console.log(n), t.reLaunch({
                            url: "/pages/topic/index?id=" + n.id
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, i("543d").default);
    },
    5388: function(t, n, i) {
        "use strict";
        i.d(n, "b", function() {
            return e;
        }), i.d(n, "c", function() {
            return a;
        }), i.d(n, "a", function() {});
        var e = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    6295: function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("5388"), a = i("d613");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            i.d(n, t, function() {
                return a[t];
            });
        }(u);
        i("6d71");
        var c = i("f0c5"), r = Object(c.a)(a.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        n.default = r.exports;
    },
    "6d71": function(t, n, i) {
        "use strict";
        var e = i("df87");
        i.n(e).a;
    },
    a82e: function(t, n, i) {
        "use strict";
        (function(t, n) {
            var e = i("4ea4");
            i("8a42"), e(i("66fd"));
            var a = e(i("6295"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, n(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    d613: function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("254c"), a = i.n(e);
        for (var u in e) [ "default" ].indexOf(u) < 0 && function(t) {
            i.d(n, t, function() {
                return e[t];
            });
        }(u);
        n.default = a.a;
    },
    df87: function(t, n, i) {}
}, [ [ "a82e", "common/runtime", "common/vendor" ] ] ]);