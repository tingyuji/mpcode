(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/record" ], {
    1064: function(t, i, o) {
        "use strict";
        o.r(i);
        var s = o("44b7"), r = o("5fce");
        for (var e in r) [ "default" ].indexOf(e) < 0 && function(t) {
            o.d(i, t, function() {
                return r[t];
            });
        }(e);
        o("c435");
        var a = o("f0c5"), c = Object(a.a)(r.default, s.b, s.c, !1, null, null, null, !1, s.a, void 0);
        i.default = c.exports;
    },
    2484: function(t, i, o) {
        "use strict";
        (function(t) {
            var s = o("4ea4");
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var r = s(o("b253")), e = o("963d"), a = {
                name: "record",
                components: {
                    comp: function() {
                        o.e("components/tabpage-common/index").then(function() {
                            return resolve(o("caaa"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    no_data: function() {
                        o.e("components/no-data/no-data").then(function() {
                            return resolve(o("d21c"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        abcd: [ "A", "B", "C", "D" ],
                        selectanswer: "",
                        BaseUrl: e.BaseUrl,
                        library_id: "",
                        answers_total: 0,
                        show_total: 0,
                        type: "",
                        right: 0,
                        error: 0,
                        record_list_show: !1,
                        IsCollect: !1,
                        kefu: !1,
                        scroll_top: 0,
                        loading: !1,
                        record_list: [],
                        list: [],
                        record_data: [],
                        records_id: "",
                        null_record_list: [],
                        is_init: !0,
                        page: 1,
                        show_page: 1,
                        list_page: 1,
                        topic_page: 1,
                        quantity_topic: 0,
                        clickpage: !1,
                        is_top: !1,
                        pageData: {
                            last_page: 0,
                            per_page: 0,
                            total: 0
                        },
                        Continue: 0,
                        confirmarr: [],
                        record_model: 0,
                        appId: "wx8abaf00ee8c3202e",
                        extraData: {
                            id: "376236"
                        },
                        isscrolltolower: !0,
                        Suggestyouha: !1
                    };
                },
                onLoad: function(t) {
                    void 0 !== t.library_id && (this.library_id = t.library_id), void 0 !== t.records_id && (this.records_id = t.records_id), 
                    void 0 !== t.record_model && (this.record_model = t.record_model), void 0 !== t.type && (this.type = t.type), 
                    void 0 !== t.Continue && (this.Continue = t.Continue), this.record_init_data(), 
                    this.setTltie();
                },
                onUnload: function(i) {
                    var o = this.record_list.length - 1 - (this.error + this.right);
                    if (2 == this.type && 0 == this.Suggestyouha) {
                        var s = this.records_id, r = this.library_id;
                        t.showModal({
                            title: "退出考试",
                            content: "还有" + o + "道题目没有作答",
                            confirmText: "继续考试",
                            cancelText: "退出",
                            success: function(i) {
                                i.confirm ? t.navigateTo({
                                    url: "/pages/topic/record?library_id=" + r + "&type=2&Continue=1&records_id=" + s
                                }) : i.cancel;
                            }
                        });
                    }
                },
                methods: {
                    initData: function() {
                        var i = this;
                        r.default.get("topic/records?library_id=" + this.library_id + "&type=" + this.type + "&Continue=" + this.Continue + "&records_id=" + this.records_id + "&page=" + this.page + "&is_init=" + this.is_init + "&record_model=" + this.record_model).then(function(o) {
                            if (i.show_page = i.page, i.clickpage) return t.hideLoading(), void (i.list = i.processList(o.data.topicList));
                            1 != i.record_model && (i.error = o.data.error, i.right = o.data.right), i.records_id = o.data.records.id, 
                            i.list = i.processList(o.data.topicList), i.record_data = o.data.topicList, i.answers_total = o.data.answers_total, 
                            i.loading = !0, i.pageData = o.data.page, i.t_record_list(), setTimeout(function() {
                                t.hideLoading();
                            }, 500), i.record_list = i.processList(o.data.topicList), 1 != i.page || i.is_top || i.is_init || (i.show_total = i.answers_total == i.record_list.length ? i.record_list.length - 1 : i.answers_total), 
                            o.data.currentLocation && (i.quantity_topic = o.data.currentLocation + 1 + 100 * (o.data.currentpage - 1), 
                            i.show_page = o.data.currentpage, i.list_page = o.data.currentpage, i.topic_page = o.data.currentpage, 
                            i.page = o.data.currentpage, i.show_total = o.data.currentLocation), i.is_init = !1, 
                            i.start_record();
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    recordsError: function() {
                        var i = this;
                        r.default.get("topic/recordsError?records_id=" + this.records_id + "&page=" + this.page).then(function(o) {
                            if (i.show_page = i.page, i.clickpage) return t.hideLoading(), void (i.list = i.processList(o.data.topicList));
                            i.records_id = "", i.list = o.data.topicList, i.record_list = i.processList(o.data.topicList), 
                            i.record_data = o.data.topicList, i.answers_total = o.data.answers_total, i.pageData = o.data.page, 
                            i.t_record_list(), i.loading = !0, setTimeout(function() {
                                t.hideLoading();
                            }, 500), i.record_list.forEach(function(t, i) {
                                t.result = 0, t.confirm = null;
                            }), i.start_record();
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    scroll: function(t) {
                        this.scroll_top = t.detail.scrollTop;
                    },
                    recordsfavorites: function() {
                        var i = this;
                        r.default.post("topic/recordsfavorites?page=" + this.page).then(function(o) {
                            if (i.show_page = i.page, i.clickpage) return t.hideLoading(), void (i.list = i.processList(o.data.topicList));
                            i.records_id = "", i.list = o.data.topicList, i.record_list = i.processList(o.data.topicList), 
                            i.record_data = o.data.topicList, i.answers_total = o.data.answers_total, i.pageData = o.data.page, 
                            1 == i.page ? i.show_total = i.answers_total : i.show_total = 0, i.t_record_list(), 
                            i.loading = !0, setTimeout(function() {
                                t.hideLoading();
                            }, 500), i.record_list.forEach(function(t, i) {
                                t.result = 0, t.confirm = null;
                            }), i.start_record();
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    is_favorites: function() {
                        var t = this;
                        this.confirmarr = [], this.record_list[this.show_total] && r.default.get("favorites/6/" + this.record_list[this.show_total].id).then(function(i) {
                            t.IsCollect = !0;
                        }, function(i) {
                            t.IsCollect = !1;
                        });
                    },
                    processList: function(t) {
                        var i = this, o = !0;
                        return this.null_record_list = [], t.forEach(function(t, s) {
                            if (t.result = t.recordoptions ? t.recordoptions.result : 0, t.confirm = null, t.selectanswer = null, 
                            t.result || i.null_record_list.push(t), 2 == i.type) {
                                if (t.recordoptions) if (2 == t.type) {
                                    var r = t.recordoptions.topic_options_id, e = r.substr(0, r.length - 1);
                                    t.confirm = e, t.confirmarr = e.split("|");
                                } else t.confirm = t.recordoptions.topic_options_id, t.confirm && i.answers_total++;
                                t.confirm || 0 == i.Continue || 1 != i.page || o && (o = !1, i.show_total = s);
                            }
                        }), this.clickpage || (console.log(this.is_top), 1 == this.page || this.is_top ? this.is_top && (this.show_total = t.length - 1) : this.show_total = 0), 
                        1 == this.record_model ? this.null_record_list : t;
                    },
                    choose_topic: function(t) {
                        this.page = this.list_page, this.topic_page = this.list_page, this.clickpage = !1, 
                        this.record_list = this.list, this.show_total = t, this.record_list_show = !1, this.quantity_topic = t + 1 + 100 * (this.page - 1);
                    },
                    setTltie: function() {
                        1 == this.type && 0 == this.record_model ? t.setNavigationBarTitle({
                            title: "顺序练习"
                        }) : 2 == this.type ? t.setNavigationBarTitle({
                            title: "模拟考试"
                        }) : 2 == this.record_model ? t.setNavigationBarTitle({
                            title: "错误练习"
                        }) : 3 == this.record_model ? t.setNavigationBarTitle({
                            title: "收藏练习"
                        }) : t.setNavigationBarTitle({
                            title: "空题练习"
                        });
                    },
                    record_init_data: function() {
                        1 == this.record_model && (this.type = 1, this.initData()), 0 === this.record_model ? this.initData() : 2 == this.record_model ? this.recordsError() : 3 == this.record_model && this.recordsfavorites(), 
                        t.showLoading({
                            title: "加载中",
                            mask: !0
                        });
                    },
                    start_record: function() {
                        1 == this.record_model && (this.show_total = 0, this.record_list = this.null_record_list, 
                        this.list = this.null_record_list), this.is_favorites();
                    },
                    confirmtopic: function(t, i) {
                        var o = this;
                        if (2 == this.record_list[this.show_total].type) this.multiple(t, i); else {
                            this.selectanswer = t, this.record_list[this.show_total].confirm = i.id;
                            var s = this.record_list[this.show_total].topicoptions[this.selectanswer].correct;
                            if (0 == this.record_list[this.show_total].result) {
                                1 == s ? this.right++ : this.error++, this.record_list[this.show_total].result = s;
                                var e = this.record_list[this.show_total].topicoptions[this.selectanswer].id, a = this.record_list[this.show_total].id, c = {
                                    result: s,
                                    topics_id: a,
                                    topic_options_id: e,
                                    records_id: this.records_id,
                                    type: this.type
                                };
                                2 != this.record_model && 1 != this.record_model && 3 != this.record_model ? r.default.post("topic/testrecords", c).then(function(t) {
                                    o.selectanswer = "", o.answers_total = t.data.answers_total, o.t_record_list(), 
                                    1 == o.type ? 1 == s && (o.show_total, o.record_list.length) : (o.show_total, o.record_list.length);
                                }, function(t) {
                                    console.log(t);
                                }) : 1 == this.type && 0 == this.record_model && (this.show_total, this.record_list.length);
                            }
                            this.show_total + 1 + 100 * (this.page - 1) >= this.pageData.total && (1 == this.type && 0 == this.record_model ? this.complete() : 2 == this.type && (this.Suggestyouha = !0)), 
                            2 != this.record_model && 3 != this.record_model || (this.record_list[this.show_total].recordoptions = {}, 
                            this.record_list[this.show_total].recordoptions.result = s, this.t_record_list()), 
                            this.$forceUpdate();
                        }
                    },
                    multiple: function(t, i) {
                        this.confirmarr.some(function(i) {
                            if (i === t) return !0;
                        }) ? (console.log(t), this.confirmarr = this.confirmarr.filter(function(i) {
                            return t !== i;
                        }), console.log(this.confirmarr)) : this.confirmarr.push(t);
                    },
                    ontopic: function() {
                        1 != this.quantity_topic && (this.topic_page > 1 && 0 == this.show_total && (this.is_top = !0, 
                        this.topic_page--, this.page = this.topic_page, this.list_page = this.page, this.clickpage = !1, 
                        this.record_init_data()), this.show_total > 0 && (this.is_top = !0, this.show_total--));
                    },
                    switchmodel: function(t) {
                        this.confirmarr = [], this.record_model !== t && (this.record_model = t, 2 == this.record_model ? this.recordsError() : 3 == this.record_model && this.recordsfavorites()), 
                        this.setTltie();
                    },
                    multiselectconfirm: function() {
                        var t = this;
                        if (!(this.confirmarr.length <= 0)) {
                            var i = [];
                            this.record_list[this.show_total].topicoptions.forEach(function(t, o) {
                                1 == t.correct && i.push(o);
                            }), this.record_list[this.show_total].confirmarr = this.confirmarr;
                            var o = "";
                            this.confirmarr.forEach(function(i) {
                                o += t.record_list[t.show_total].topicoptions[i].id + "|";
                            });
                            var s = this.confirmarr.length === i.length && this.confirmarr.sort().toString() === i.sort().toString();
                            s = s ? 1 : 2, this.record_list[this.show_total].confirm = s;
                            var e = {
                                result: s,
                                topics_id: this.record_list[this.show_total].id,
                                topic_options_id: o,
                                records_id: this.records_id,
                                type: this.type
                            };
                            this.t_record_list(), 0 == this.record_list[this.show_total].result && (this.record_list[this.show_total].result = s, 
                            2 != this.record_model && 1 != this.record_model && 3 != this.record_model ? (1 == this.type ? 1 == s && this.show_total < this.record_list.length - 1 && this.show_total++ : this.show_total < this.record_list.length - 1 && this.show_total++, 
                            r.default.post("topic/testrecords", e).then(function(i) {
                                t.selectanswer = "", t.answers_total = i.data.answers_total, t.t_record_list(), 
                                t.answers_total >= t.record_list.length && (2 == t.type && (t.Suggestyouha = !0), 
                                t.complete()), t.$forceUpdate();
                            }, function(t) {
                                console.log(t);
                            })) : 1 == this.type && 0 == this.record_model && this.show_total < this.record_list.length - 1 && this.show_total++), 
                            2 != this.record_model && 3 != this.record_model || (this.record_list[this.show_total].recordoptions = {}, 
                            this.record_list[this.show_total].recordoptions.result = s), this.$forceUpdate();
                        }
                    },
                    nexttopic: function() {
                        if (this.quantity_topic != this.pageData.total) {
                            if (this.show_total == this.record_list.length - 1) return this.clickpage = !1, 
                            this.topic_page++, this.page = this.topic_page, this.list_page = this.page, this.is_top = !1, 
                            void this.record_init_data();
                            if (this.clickpage = !1, "" === this.selectanswer) return this.show_total >= this.record_list.length - 1 && this.complete(), 
                            this.selectanswer = "", void this.show_total++;
                            if (0 !== this.record_list[this.show_total].result) return this.selectanswer = "", 
                            void this.show_total++;
                            this.answers_total >= this.record_list.length - 1 ? this.complete() : this.show_total++, 
                            this.$forceUpdate();
                        }
                    },
                    t_record_list: function() {},
                    delErro: function() {
                        var t = this, i = this.record_list[this.show_total].id;
                        r.default.post("topic/delRecordsError", {
                            topics_id: i
                        }).then(function(i) {
                            t.record_list.splice(t.show_total, 1), t.$forceUpdate();
                        });
                    },
                    complete: function() {
                        2 == this.type ? t.redirectTo({
                            url: "/pages/topic/exam_finish?records_id=" + this.records_id + "&library_id=" + this.library_id
                        }) : (this.record_model, t.redirectTo({
                            url: "/pages/topic/results?records_id=" + this.records_id + "&library_id=" + this.library_id
                        }));
                    },
                    submit: function(i) {
                        1 == i ? t.redirectTo({
                            url: "/pages/topic/exam_finish?records_id=" + this.records_id + "&library_id=" + this.library_id
                        }) : this.Suggestyouha = !1;
                    },
                    feedback: function() {
                        t.navigateTo({
                            url: "/pages/topic/feedback_error?id=" + this.record_list[this.show_total].id
                        });
                    },
                    favorites: function() {
                        var i = this;
                        this.IsCollect ? r.default.post("v2/favorites/destroy", {
                            resource_type: 6,
                            resource_key: this.record_list[this.show_total].id
                        }).then(function(o) {
                            3 == i.record_model ? (i.record_list.splice(i.show_total, 1), i.IsCollect = !0, 
                            i.$forceUpdate()) : i.IsCollect = !1, t.showToast({
                                icon: "none",
                                title: "取消收藏"
                            });
                        }, function(t) {
                            console.error(t);
                        }) : r.default.post("v2/favorites/store", {
                            resource_type: 6,
                            resource_key: this.record_list[this.show_total].id
                        }).then(function(o) {
                            t.showToast({
                                icon: "none",
                                title: "收藏成功"
                            }), i.IsCollect = !0;
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    shareApp: function() {
                        t.share({
                            provider: "weixin",
                            scene: "WXSceneSession",
                            type: 5,
                            imageUrl: e.BaseUrl + "electrician-master/images/logo.png",
                            title: "电工大师",
                            miniProgram: {
                                id: "gh_4230d5981364",
                                path: "pages/index/index",
                                type: 0,
                                webUrl: "http://uniapp.dcloud.io"
                            },
                            success: function(t) {
                                console.log(JSON.stringify(t));
                            },
                            fail: function(t) {
                                console.log(JSON.stringify(t));
                            }
                        });
                    },
                    net_page: function() {
                        if (this.list_page <= this.pageData.last_page) return this.clickpage = !0, this.list_page++, 
                        this.page = this.list_page, void this.record_init_data();
                    },
                    top_page: function() {
                        this.list_page > 1 && (this.clickpage = !0, this.list_page--, this.page = this.list_page, 
                        this.record_init_data());
                    }
                },
                watch: {
                    show_total: {
                        handler: function() {
                            this.is_favorites(), this.quantity_topic = this.show_total + 1 + 100 * (this.page - 1), 
                            console.log(this.show_total);
                        },
                        deep: !0,
                        immediate: !0
                    },
                    record_list_show: function() {
                        this.record_list_show ? this.clickpage = !0 : this.clickpage = !1;
                    }
                }
            };
            i.default = a;
        }).call(this, o("543d").default);
    },
    "44b7": function(t, i, o) {
        "use strict";
        o.d(i, "b", function() {
            return r;
        }), o.d(i, "c", function() {
            return e;
        }), o.d(i, "a", function() {
            return s;
        });
        var s = {
            noData: function() {
                return o.e("components/no-data/no-data").then(o.bind(null, "d21c"));
            }
        }, r = function() {
            var t = this, i = (t.$createElement, t._self._c, t.loading ? t.record_list.length : null), o = t.loading && i && 2 === t.record_list[t.show_total].type ? t.__map(t.record_list[t.show_total].topicoptions, function(i, o) {
                var s = t.__get_orig(i), r = t.record_list[t.show_total].confirm ? null : t.confirmarr.indexOf(o), e = t.record_list[t.show_total].confirm ? null : t.confirmarr.indexOf(o), a = t.record_list[t.show_total].confirm ? t.record_list[t.show_total].confirmarr.indexOf(o) > -1 && 1 == i.correct : null;
                return {
                    $orig: s,
                    g1: r,
                    g2: e,
                    g3: a,
                    g4: t.record_list[t.show_total].confirm && !a ? t.record_list[t.show_total].confirmarr.indexOf(o) > -1 && 2 == i.correct : null
                };
            }) : null, s = t.loading && i ? t.record_list.length : null, r = t.loading && 1 == t.record_model ? t.list.length : null, e = t.loading ? t.record_list.length : null, a = t.loading && e - t.error - t.right != 0 ? t.record_list.length : null, c = t.loading ? t.record_list.length : null, l = t.loading ? t.record_list.length : null;
            t._isMounted || (t.e0 = function(i) {
                t.record_list_show = !t.record_list_show;
            }, t.e1 = function(i) {
                t.Suggestyouha = !t.Suggestyouha;
            }, t.e2 = function(i) {
                t.record_list_show = !t.record_list_show;
            }, t.e3 = function(i) {
                t.kefu = !t.kefu;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    g0: i,
                    l0: o,
                    g5: s,
                    g6: r,
                    g7: e,
                    g8: a,
                    g9: c,
                    g10: l
                }
            });
        }, e = [];
    },
    "5fce": function(t, i, o) {
        "use strict";
        o.r(i);
        var s = o("2484"), r = o.n(s);
        for (var e in s) [ "default" ].indexOf(e) < 0 && function(t) {
            o.d(i, t, function() {
                return s[t];
            });
        }(e);
        i.default = r.a;
    },
    a7d9: function(t, i, o) {},
    c435: function(t, i, o) {
        "use strict";
        var s = o("a7d9");
        o.n(s).a;
    },
    d80c: function(t, i, o) {
        "use strict";
        (function(t, i) {
            var s = o("4ea4");
            o("8a42"), s(o("66fd"));
            var r = s(o("1064"));
            t.__webpack_require_UNI_MP_PLUGIN__ = o, i(r.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    }
}, [ [ "d80c", "common/runtime", "common/vendor" ] ] ]);