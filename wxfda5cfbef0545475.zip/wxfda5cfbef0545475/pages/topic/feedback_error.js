(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/feedback_error" ], {
    5145: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("8bdf"), a = i.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(o);
        e.default = a.a;
    },
    "65b3": function(t, e, i) {
        "use strict";
        (function(t, e) {
            var n = i("4ea4");
            i("8a42"), n(i("66fd"));
            var a = n(i("bd99"));
            t.__webpack_require_UNI_MP_PLUGIN__ = i, e(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    "66c1": function(t, e, i) {
        "use strict";
        var n = i("8793");
        i.n(n).a;
    },
    "7cec": function(t, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return a;
        }), i.d(e, "a", function() {});
        var n = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    8793: function(t, e, i) {},
    "8bdf": function(t, e, i) {
        "use strict";
        (function(t) {
            var n = i("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n(i("b253")), o = {
                data: function() {
                    return {
                        id: "",
                        type: void 0,
                        remark: "",
                        isSubmit: !1
                    };
                },
                onLoad: function(t) {
                    t.id && (this.id = parseInt(t.id));
                },
                methods: {
                    radioChange: function(t) {
                        this.type = t.detail.value, console.log(this.type);
                    },
                    submit: function() {
                        var e = this;
                        if ("" !== this.type && void 0 !== this.type) {
                            if (!this.isSubmit) {
                                this.isSubmit = !0;
                                var i = {
                                    topic_id: this.id,
                                    remark: this.remark,
                                    type: this.type
                                };
                                t.showLoading({
                                    title: "保存中",
                                    mask: !0
                                }), a.default.post("topic/correction", i).then(function(i) {
                                    t.showTabBar(), t.showToast({
                                        title: "提交成功",
                                        icon: "success",
                                        mask: !0
                                    }), e.isSubmit = !1, setTimeout(function() {
                                        t.navigateBack();
                                    }, 1e3);
                                }).catch(function(i) {
                                    t.showTabBar(), t.showModal({
                                        content: i.message,
                                        showCancel: !1
                                    }), e.isSubmit = !1;
                                });
                            }
                        } else t.showToast({
                            title: "报错类型必须选择一个",
                            icon: "none",
                            mask: !0
                        });
                    }
                }
            };
            e.default = o;
        }).call(this, i("543d").default);
    },
    bd99: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("7cec"), a = i("5145");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(o);
        i("66c1");
        var c = i("f0c5"), s = Object(c.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        e.default = s.exports;
    }
}, [ [ "65b3", "common/runtime", "common/vendor" ] ] ]);