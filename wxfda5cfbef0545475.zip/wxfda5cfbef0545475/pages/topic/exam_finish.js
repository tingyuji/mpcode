(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/exam_finish" ], {
    5621: function(t, i, r) {
        "use strict";
        (function(t) {
            var n = r("4ea4");
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var e = n(r("b253")), o = {
                data: function() {
                    return {
                        library_id: "",
                        records_id: "",
                        right: "",
                        error: "",
                        notTopic: ""
                    };
                },
                onLoad: function(t) {
                    void 0 !== t.library_id && (this.library_id = t.library_id, this.records_id = t.records_id, 
                    this.initData());
                },
                methods: {
                    initData: function() {
                        var t = this, i = {
                            library_id: this.library_id,
                            records_id: this.records_id
                        };
                        e.default.post("topic/finisrecords", i).then(function(i) {
                            console.log(i.data), t.right = i.data.right, t.error = i.data.error, t.notTopic = i.data.notTopic;
                        }, function(t) {
                            console.log(t);
                        });
                    },
                    newpractice: function() {
                        var i = this, r = {
                            records_id: this.records_id
                        };
                        e.default.post("topic/newpractice", r).then(function(r) {
                            t.redirectTo({
                                url: "/pages/topic/record?library_id=" + i.library_id + "&type=1"
                            });
                        });
                    }
                }
            };
            i.default = o;
        }).call(this, r("543d").default);
    },
    "6d3b": function(t, i, r) {
        "use strict";
        (function(t, i) {
            var n = r("4ea4");
            r("8a42"), n(r("66fd"));
            var e = n(r("e801"));
            t.__webpack_require_UNI_MP_PLUGIN__ = r, i(e.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    b2d2: function(t, i, r) {
        "use strict";
        r.d(i, "b", function() {
            return n;
        }), r.d(i, "c", function() {
            return e;
        }), r.d(i, "a", function() {});
        var n = function() {
            this.$createElement, this._self._c;
        }, e = [];
    },
    d52d: function(t, i, r) {
        "use strict";
        r.r(i);
        var n = r("5621"), e = r.n(n);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(t) {
            r.d(i, t, function() {
                return n[t];
            });
        }(o);
        i.default = e.a;
    },
    e70d: function(t, i, r) {},
    e801: function(t, i, r) {
        "use strict";
        r.r(i);
        var n = r("b2d2"), e = r("d52d");
        for (var o in e) [ "default" ].indexOf(o) < 0 && function(t) {
            r.d(i, t, function() {
                return e[t];
            });
        }(o);
        r("f669");
        var a = r("f0c5"), d = Object(a.a)(e.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        i.default = d.exports;
    },
    f669: function(t, i, r) {
        "use strict";
        var n = r("e70d");
        r.n(n).a;
    }
}, [ [ "6d3b", "common/runtime", "common/vendor" ] ] ]);