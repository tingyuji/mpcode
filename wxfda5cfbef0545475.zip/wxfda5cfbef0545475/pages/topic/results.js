(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/results" ], {
    "04cf": function(t, i, r) {
        "use strict";
        r.d(i, "b", function() {
            return e;
        }), r.d(i, "c", function() {
            return n;
        }), r.d(i, "a", function() {});
        var e = function() {
            this.$createElement, this._self._c;
        }, n = [];
    },
    "6fdc": function(t, i, r) {
        "use strict";
        (function(t, i) {
            var e = r("4ea4");
            r("8a42"), e(r("66fd"));
            var n = e(r("cf27"));
            t.__webpack_require_UNI_MP_PLUGIN__ = r, i(n.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    "772f": function(t, i, r) {
        "use strict";
        (function(t) {
            var e = r("4ea4");
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var n = e(r("b253")), c = {
                data: function() {
                    return {
                        library_id: "",
                        records_id: "",
                        right: "",
                        error: "",
                        notTopic: ""
                    };
                },
                onLoad: function(t) {
                    void 0 !== t.library_id && (this.library_id = t.library_id, this.records_id = t.records_id, 
                    this.initData());
                },
                methods: {
                    initData: function() {
                        var t = this, i = {
                            library_id: this.library_id,
                            records_id: this.records_id
                        };
                        n.default.post("topic/finisrecords", i).then(function(i) {
                            console.log(i.data), t.right = i.data.right, t.error = i.data.error, t.notTopic = i.data.notTopic;
                        }, function(t) {
                            console.log(t);
                        });
                    },
                    newpractice: function() {
                        var i = this, r = {
                            records_id: this.records_id
                        };
                        n.default.post("topic/newpractice", r).then(function(r) {
                            t.redirectTo({
                                url: "/pages/topic/record?library_id=" + i.library_id + "&type=1"
                            });
                        });
                    }
                }
            };
            i.default = c;
        }).call(this, r("543d").default);
    },
    "7e34": function(t, i, r) {},
    cf27: function(t, i, r) {
        "use strict";
        r.r(i);
        var e = r("04cf"), n = r("f14e");
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            r.d(i, t, function() {
                return n[t];
            });
        }(c);
        r("d5c6");
        var o = r("f0c5"), a = Object(o.a)(n.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        i.default = a.exports;
    },
    d5c6: function(t, i, r) {
        "use strict";
        var e = r("7e34");
        r.n(e).a;
    },
    f14e: function(t, i, r) {
        "use strict";
        r.r(i);
        var e = r("772f"), n = r.n(e);
        for (var c in e) [ "default" ].indexOf(c) < 0 && function(t) {
            r.d(i, t, function() {
                return e[t];
            });
        }(c);
        i.default = n.a;
    }
}, [ [ "6fdc", "common/runtime", "common/vendor" ] ] ]);