(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/exam_record" ], {
    1866: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var i = a(e("e76b"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "1f5c": function(t, n, e) {
        "use strict";
        var a = e("8153");
        e.n(a).a;
    },
    "24ad": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            var t = (this._self._c, this.scoresList.length), n = this.scoresList.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n
                }
            });
        }, i = [];
    },
    "58ba": function(t, n, e) {
        "use strict";
        var a = e("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = a(e("b253")), c = {
            data: function() {
                return {
                    scoresList: []
                };
            },
            onLoad: function(t) {
                this.initData();
            },
            methods: {
                initData: function() {
                    var t = this;
                    i.default.get("topic/scoresList").then(function(n) {
                        t.scoresList = n.data;
                    });
                }
            }
        };
        n.default = c;
    },
    "6d28": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("58ba"), i = e.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        n.default = i.a;
    },
    8153: function(t, n, e) {},
    e76b: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("24ad"), i = e("6d28");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(c);
        e("1f5c");
        var r = e("f0c5"), o = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = o.exports;
    }
}, [ [ "1866", "common/runtime", "common/vendor" ] ] ]);