(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/ui/change" ], {
    "2f08": function(n, t, c) {
        "use strict";
        var e = c("cbd7");
        c.n(e).a;
    },
    "31a9": function(n, t) {},
    "5f65": function(n, t, c) {
        "use strict";
        c.r(t);
        var e = c("6919"), u = c("6201");
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            c.d(t, n, function() {
                return u[n];
            });
        }(a);
        c("2f08");
        var f = c("f0c5"), i = Object(f.a)(u.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        t.default = i.exports;
    },
    6201: function(n, t, c) {
        "use strict";
        c.r(t);
        var e = c("31a9"), u = c.n(e);
        for (var a in e) [ "default" ].indexOf(a) < 0 && function(n) {
            c.d(t, n, function() {
                return e[n];
            });
        }(a);
        t.default = u.a;
    },
    6919: function(n, t, c) {
        "use strict";
        c.d(t, "b", function() {
            return e;
        }), c.d(t, "c", function() {
            return u;
        }), c.d(t, "a", function() {});
        var e = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    cbd7: function(n, t, c) {},
    f981: function(n, t, c) {
        "use strict";
        (function(n, t) {
            var e = c("4ea4");
            c("8a42"), e(c("66fd"));
            var u = e(c("5f65"));
            n.__webpack_require_UNI_MP_PLUGIN__ = c, t(u.default);
        }).call(this, c("bc2e").default, c("543d").createPage);
    }
}, [ [ "f981", "common/runtime", "common/vendor" ] ] ]);