(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/ui/index" ], {
    "1d3d": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return u;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var u = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "2ebd": function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t("e72b"), c = t.n(u);
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(a);
        n.default = c.a;
    },
    5573: function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t("1d3d"), c = t("2ebd");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(a);
        t("c342");
        var r = t("f0c5"), i = Object(r.a)(c.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        n.default = i.exports;
    },
    "707d": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var u = t("4ea4");
            t("8a42"), u(t("66fd"));
            var c = u(t("5573"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(c.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    c342: function(e, n, t) {
        "use strict";
        var u = t("ce0b");
        t.n(u).a;
    },
    ce0b: function(e, n, t) {},
    e72b: function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = t("963d"), c = {
            data: function() {
                return {
                    BaseUrl: u.BaseUrl
                };
            }
        };
        n.default = c;
    }
}, [ [ "707d", "common/runtime", "common/vendor" ] ] ]);