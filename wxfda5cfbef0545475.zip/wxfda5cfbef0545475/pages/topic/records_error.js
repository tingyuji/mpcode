(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/topic/records_error" ], {
    "0e7a": function(t, e, r) {
        "use strict";
        r.r(e);
        var o = r("b5c7"), i = r.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(t) {
            r.d(e, t, function() {
                return o[t];
            });
        }(s);
        e.default = i.a;
    },
    "4ce9": function(t, e, r) {
        "use strict";
        var o = r("df26");
        r.n(o).a;
    },
    "5c66": function(t, e, r) {
        "use strict";
        (function(t, e) {
            var o = r("4ea4");
            r("8a42"), o(r("66fd"));
            var i = o(r("b69b"));
            t.__webpack_require_UNI_MP_PLUGIN__ = r, e(i.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    "9e44": function(t, e, r) {
        "use strict";
        r.d(e, "b", function() {
            return o;
        }), r.d(e, "c", function() {
            return i;
        }), r.d(e, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    b5c7: function(t, e, r) {
        "use strict";
        (function(t) {
            var o = r("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = o(r("b253")), s = {
                name: "record",
                data: function() {
                    return {
                        selectanswer: "",
                        library_id: "",
                        answers_total: 0,
                        show_total: "",
                        type: "",
                        record_list: [],
                        records_id: "",
                        null_record_list: []
                    };
                },
                onLoad: function(t) {
                    void 0 !== t.records_id && (this.records_id = t.records_id, this.initData());
                },
                methods: {
                    initData: function() {
                        var t = this;
                        i.default.get("topic/recordsError?records_id=" + this.records_id).then(function(e) {
                            console.log(e.data), t.record_list = e.data.records, t.answers_total = 0, t.show_total = 0;
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    confirmtopic: function(t) {
                        this.selectanswer = t;
                    },
                    ontopic: function() {
                        this.show_total--, this.answers_total;
                    },
                    nexttopic: function() {
                        if ("" === this.selectanswer) return this.null_record_list.push(this.show_total), 
                        this.show_total++, this.answers_total++, void (this.selectanswer = "");
                        this.record_list[this.show_total].topics.topicoptions[this.selectanswer].correct, 
                        this.record_list[this.show_total].id, this.records_id, this.show_total++, this.answers_total++, 
                        this.selectanswer = "";
                    },
                    complete: function() {
                        t.redirectTo({
                            url: "/pages/topic/results?records_id=" + this.records_id + "&library_id=" + this.library_id
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, r("543d").default);
    },
    b69b: function(t, e, r) {
        "use strict";
        r.r(e);
        var o = r("9e44"), i = r("0e7a");
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(t) {
            r.d(e, t, function() {
                return i[t];
            });
        }(s);
        r("4ce9");
        var n = r("f0c5"), c = Object(n.a)(i.default, o.b, o.c, !1, null, "bf86db40", null, !1, o.a, void 0);
        e.default = c.exports;
    },
    df26: function(t, e, r) {}
}, [ [ "5c66", "common/runtime", "common/vendor" ] ] ]);