(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/me/me" ], {
    "0099": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("8393"), a = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = a.a;
    },
    "05f6": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "0743": function(n, t, e) {},
    8393: function(n, t, e) {
        "use strict";
        (function(n) {
            var o = e("4ea4"), a = e("7037");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = e("9673"), c = o(e("ac2e")), u = o(e("1733")), r = (e("9673"), function(n, t) {
                if (n && n.__esModule) return n;
                if (null === n || "object" !== a(n) && "function" != typeof n) return {
                    default: n
                };
                var e = function(n) {
                    if ("function" != typeof WeakMap) return null;
                    var t = new WeakMap(), e = new WeakMap();
                    return function(n) {
                        return n ? e : t;
                    }(n);
                }(t);
                if (e && e.has(n)) return e.get(n);
                var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in n) if ("default" !== c && Object.prototype.hasOwnProperty.call(n, c)) {
                    var u = i ? Object.getOwnPropertyDescriptor(n, c) : null;
                    u && (u.get || u.set) ? Object.defineProperty(o, c, u) : o[c] = n[c];
                }
                return o.default = n, e && e.set(n, o), o;
            }(e("b253"))), l = e("963d"), f = getApp(), s = {
                components: {
                    comp: function() {
                        e.e("components/tabpage-common/index").then(function() {
                            return resolve(e("caaa"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        showNoticeDot: !1,
                        BaseUrl: l.BaseUrl,
                        appId: "wx8abaf00ee8c3202e",
                        platform: "",
                        extraData: {
                            id: "376236"
                        }
                    };
                },
                mixins: [ c.default, u.default ],
                onLoad: function() {
                    var n = this;
                    f.globalData.on("announcement", function() {
                        return n.attachAnnouncement();
                    }, "me");
                },
                onShow: function() {
                    this.attachAnnouncement();
                },
                onUnload: function() {
                    f.globalData.off("notice-view", "me");
                },
                onPullDownRefresh: function() {
                    f.globalData.updateUser(), f.globalData.getUser().finally(function() {
                        n.stopPullDownRefresh();
                    });
                },
                methods: {
                    openVip: function() {
                        this.login(function() {
                            n.navigateTo({
                                url: "/pages/vip/vip"
                            });
                        });
                    },
                    vipTrial: function() {
                        n.showModal({
                            title: "恭喜您",
                            content: "获得电工大师三天VIP会员，领取后立即体验",
                            confirmText: "立即领取",
                            success: function(t) {
                                t.confirm && r.default.get("vipTial").then(function(t) {
                                    n.hideLoading(), n.showToast({
                                        title: "VIP会员领取成功",
                                        icon: "success",
                                        duration: 5e3
                                    }), f.globalData.trigger("vip-updated");
                                }).catch(function(t) {
                                    n.showModal({
                                        title: "温馨提示",
                                        showCancel: !1,
                                        content: t.message
                                    });
                                });
                            }
                        });
                    },
                    login: function(t) {
                        (0, i.loginRequired)().then(function() {
                            "function" == typeof t && t();
                        }, function() {
                            n.showToast({
                                title: "已取消登录",
                                icon: "none"
                            });
                        });
                    },
                    cancellation: function() {
                        n.showModal({
                            title: "温馨提示",
                            content: "您正在申请注销电工大师账号，注销后，您的兑换码，积分，会员特权，邀请，收藏等数据将会失效，且不可恢复。确定注销吗？",
                            confirmText: "确认",
                            cancelText: "取消",
                            success: function(t) {
                                t.confirm && ((0, r.setToken)(""), getApp().globalData.trigger("user-info-updated", null), 
                                getApp().globalData.userInfo = null, n.switchTab({
                                    url: "/pages/index/index"
                                }));
                            }
                        });
                    },
                    logout: function() {
                        n.showModal({
                            title: "温馨提示",
                            content: "确认当前用户退出登录吗？",
                            confirmText: "确认",
                            cancelText: "取消",
                            success: function(t) {
                                t.confirm && ((0, r.setToken)(""), getApp().globalData.trigger("user-info-updated", null), 
                                getApp().globalData.userInfo = null, n.switchTab({
                                    url: "/pages/index/index"
                                }));
                            }
                        });
                    },
                    cilInvitation: function() {
                        n.navigateTo({
                            url: "/pages/invitation/my-reward"
                        });
                    },
                    exchangeVip: function() {
                        this.login(function() {
                            n.navigateTo({
                                url: "/pages/exchange-vip/exchange-vip"
                            });
                        });
                    },
                    attachAnnouncement: function() {
                        this.setData({
                            showNoticeDot: f.globalData.redDot
                        });
                    },
                    location: function(t) {
                        n.navigateTo({
                            url: t
                        });
                    }
                }
            };
            t.default = s;
        }).call(this, e("543d").default);
    },
    "9f6e": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("05f6"), a = e("0099");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(i);
        e("e8d9");
        var c = e("f0c5"), u = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    a5cd: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var a = o(e("9f6e"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(a.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    e8d9: function(n, t, e) {
        "use strict";
        var o = e("0743");
        e.n(o).a;
    }
}, [ [ "a5cd", "common/runtime", "common/vendor" ] ] ]);