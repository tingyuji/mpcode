(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/index" ], {
    "08be": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.items, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.child.length
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
    },
    "14eb": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("814e"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "1cd3": function(t, e, n) {},
    "2ea7": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("b253")), o = a(n("1733")), c = (getApp(), {
                components: {
                    comp: function() {
                        n.e("components/tabpage-common/index").then(function() {
                            return resolve(n("caaa"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        navHeight: 0,
                        searchHeight: "",
                        items: [],
                        updateInfo: null,
                        showTip: !1,
                        showMore: !1,
                        navTop: "",
                        idx2: 0,
                        heightTop: "",
                        isTouTiao: !1
                    };
                },
                mixins: [ o.default ],
                onLoad: function(e) {
                    var n = this;
                    e.ref && t.setStorageSync("ref", e.ref), this.fixLayout(), t.showLoading({
                        title: "加载中"
                    }), i.default.get("catalogs").then(function(t) {
                        for (var e = t.data, a = e.length - 1; a >= 0; a--) 0 == e[a].child.length && e.splice(a, 1);
                        n.setData({
                            items: e
                        });
                    }, function(e) {
                        t.showModal({
                            title: "加载失败",
                            content: e.message,
                            showCancel: !1
                        });
                    }).finally(function() {
                        t.hideLoading();
                    }), i.default.get("has-document").then(function(t) {
                        n.setData({
                            updateInfo: t.data
                        });
                    }, function() {}), t.getStorage({
                        key: "hide_data_index_tip",
                        success: function() {},
                        fail: function() {
                            n.setData({
                                showTip: !0
                            });
                        }
                    });
                },
                onShareAppMessage: function() {
                    return {
                        title: "电工大师-资料",
                        path: "/pages/index/index"
                    };
                },
                methods: {
                    goSearchUrl: function() {
                        t.navigateTo({
                            url: "/pages/search/search"
                        });
                    },
                    goCatalog: function(e) {
                        var n = "/pages/data/list?id=" + e.currentTarget.dataset.id + "&title=" + e.currentTarget.dataset.title;
                        t.navigateTo({
                            url: n
                        });
                    },
                    fixLayout: function() {
                        var e = this, n = t.getMenuButtonBoundingClientRect();
                        void 0 === n && (n = {
                            top: 35,
                            height: 35
                        }), t.getSystemInfo({
                            success: function(t) {
                                var a = t.statusBarHeight, i = n.top;
                                e.heightTop = "margin-top: " + 1.4 * t.statusBarHeight + "rpx;";
                                var o = a + n.height + 2 * (n.top - a);
                                console.log(o), e.setData({
                                    navTop: i,
                                    navHeight: o,
                                    searchHeight: n.height
                                });
                            }
                        });
                    },
                    listToggle: function() {
                        this.setData({
                            showMore: !this.showMore
                        });
                    },
                    hideTip: function() {
                        var e = this;
                        t.setStorage({
                            key: "hide_data_index_tip",
                            data: 1,
                            success: function() {
                                e.setData({
                                    showTip: !1
                                });
                            }
                        });
                    }
                }
            });
            e.default = c;
        }).call(this, n("543d").default);
    },
    "5bc6": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("2ea7"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    },
    "814e": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("08be"), i = n("5bc6");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("e95a");
        var c = n("f0c5"), u = Object(c.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = u.exports;
    },
    e95a: function(t, e, n) {
        "use strict";
        var a = n("1cd3");
        n.n(a).a;
    }
}, [ [ "14eb", "common/runtime", "common/vendor" ] ] ]);