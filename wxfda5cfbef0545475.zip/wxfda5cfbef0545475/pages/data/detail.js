(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/detail" ], {
    "03c7": function(t, e, n) {},
    "17e8": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("9f7e"), a = n("49c2");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("50a7");
        var c = n("f0c5"), s = Object(c.a)(a.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = s.exports;
    },
    3507: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var a = i(n("17e8"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "49c2": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("cb77"), a = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = a.a;
    },
    "50a7": function(t, e, n) {
        "use strict";
        var i = n("03c7");
        n.n(i).a;
    },
    "9f7e": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return i;
        });
        var i = {
            mpHtml: function() {
                return Promise.all([ n.e("common/vendor"), n.e("uni_modules/mp-html/components/mp-html/mp-html") ]).then(n.bind(null, "fb6c"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    cb77: function(t, e, n) {
        "use strict";
        (function(t) {
            var i = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n("963d"), o = (n("a195"), i(n("b253"))), c = n("9673"), s = n("628d"), l = {
                components: {
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        detail: [],
                        feature: [],
                        isFav: !1,
                        faving: !1,
                        vipRequired: !1,
                        document: null,
                        tagStyle: {
                            table: "margin:10px 0",
                            a: "color:blue",
                            tr: "border-top:1px solid #ccc",
                            td: "border:1px solid #ccc;padding:10px"
                        },
                        picTip: !1,
                        id: null
                    };
                },
                onLoad: function(e) {
                    var n = this, i = e.id, a = {
                        type: 2,
                        id: i
                    };
                    this.id = i, this.document = a, t.$on("user-payment-vip", function() {
                        console.log("user-payment-vip"), n.loadData();
                    }), (0, c.loginRequired)().then(this.loadData, function() {
                        getCurrentPages().length > 1 ? t.navigateBack() : t.reLaunch({
                            url: "/pages/data/index"
                        });
                    }), t.getStorage({
                        key: "hide_data_pic_tip",
                        success: function() {},
                        fail: function() {
                            n.setData({
                                picTip: !0
                            });
                        }
                    });
                },
                onUnload: function() {
                    t.$off("user-payment-vip");
                },
                onShow: function() {
                    var t = this;
                    (0, c.getUser)().then(function(e) {
                        t.setData({
                            vipRequired: 0 == e.vip_state
                        });
                    }, function(t) {
                        console.error(t);
                    });
                },
                onShareAppMessage: function() {
                    return {
                        title: "电工大师-资料详情",
                        path: "/pages/data/detail?id=" + this.id
                    };
                },
                methods: {
                    loadData: function() {
                        var e = this;
                        t.showLoading({
                            title: "加载中"
                        });
                        var n = this.document, i = n.type, a = n.id;
                        o.default.get("documents/" + a).then(function(t) {
                            t.data.content = e.optimizeRichText(t.data.content), e.setData({
                                detail: t.data
                            }), (0, s.setRecentUsed)("document_" + a, s.TypeIcons[t.data.type] || s.TypeIcons[0], t.data.title, "/pages/data/detail?id=" + a, 2);
                        }, function(e) {
                            t.showModal({
                                title: "加载失败",
                                content: e.message,
                                showCancel: !1
                            });
                        }).finally(function() {
                            t.hideLoading();
                        }), o.default.get("favorites/" + i + "/" + a).then(function(t) {
                            t.data && e.setData({
                                isFav: !0
                            });
                        }, function() {});
                    },
                    previewPDF: function(t) {
                        var e = t.currentTarget.dataset.content;
                        this.openPdf(e);
                    },
                    openPdf: function(e) {
                        t.showLoading({
                            title: "加载中..."
                        }), t.downloadFile({
                            url: e,
                            success: function(e) {
                                console.log("downloadFile", e);
                                var n = e.tempFilePath;
                                t.openDocument({
                                    filePath: n,
                                    success: function(e) {
                                        t.hideLoading();
                                    },
                                    fail: function(e) {
                                        t.hideLoading(), console.log(e), t.showModal({
                                            title: "打开文件失败",
                                            content: e.message,
                                            showCancel: !1
                                        });
                                    }
                                });
                            },
                            fail: function(e) {
                                t.hideLoading(), t.showModal({
                                    title: "下载文件失败",
                                    content: e.message,
                                    showCancel: !1
                                });
                            }
                        });
                    },
                    previewImage: function() {
                        t.previewImage({
                            urls: [ this.detail.content ],
                            showmenu: !1
                        });
                    },
                    shareApp: function() {
                        t.share({
                            provider: "weixin",
                            scene: "WXSceneSession",
                            type: 5,
                            imageUrl: a.BaseUrl + "electrician-master/images/logo.png",
                            title: "电工大师",
                            miniProgram: {
                                id: "gh_4230d5981364",
                                path: "/pages/data/detail?id=" + this.id,
                                type: 0,
                                webUrl: "http://uniapp.dcloud.io"
                            },
                            success: function(t) {
                                console.log(JSON.stringify(t));
                            },
                            fail: function(t) {
                                console.log(JSON.stringify(t));
                            }
                        });
                    },
                    fav: function() {
                        var e = this;
                        this.setData({
                            faving: !0
                        });
                        var n = this.document;
                        (0, s.addFav)(n.type, n.id).then(function() {
                            e.setData({
                                faving: !1,
                                isFav: !0
                            }), t.showToast({
                                title: "已收藏成功",
                                icon: "none"
                            });
                        }, function(n) {
                            e.setData({
                                faving: !1
                            }), t.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    },
                    cancelFav: function() {
                        var e = this;
                        this.setData({
                            faving: !0
                        });
                        var n = this.document;
                        (0, s.cancelFav)(n.type, n.id).then(function(n) {
                            e.setData({
                                faving: !1,
                                isFav: !1
                            }), t.showToast({
                                title: "已取消收藏",
                                icon: "none"
                            });
                        }, function(n) {
                            e.setData({
                                faving: !1
                            }), t.showToast({
                                title: n.message,
                                icon: "none"
                            });
                        });
                    },
                    optimizeRichText: function(t) {
                        return t.replace(/(class=)[\"|'](.*?)[\"|'].*?/g, "").replace(/\<(img|p|table)/gi, function(t) {
                            return "<p" == t ? '<p class="rich-p"' : "<table" == t ? '<table class="rich-table"' : '<img class="rich-img"';
                        });
                    },
                    closePicTip: function() {
                        t.setStorage({
                            key: "hide_data_pic_tip",
                            data: 1
                        }), this.setData({
                            picTip: !1
                        });
                    }
                }
            };
            e.default = l;
        }).call(this, n("543d").default);
    }
}, [ [ "3507", "common/runtime", "common/vendor" ] ] ]);