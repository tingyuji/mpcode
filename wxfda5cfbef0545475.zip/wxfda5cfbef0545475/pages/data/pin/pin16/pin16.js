(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin16/pin16" ], {
    "051e": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("41f0"), c = e.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = c.a;
    },
    "2a49": function(n, t, e) {},
    "2b1c": function(n, t, e) {
        "use strict";
        var o = e("2a49");
        e.n(o).a;
    },
    "41f0": function(n, t, e) {
        "use strict";
        var o = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Key data", "Not connected (Data2 for dual PS2)", "Ground", "Power +5V", "Clock", "Not connected (Clock2 for dual PS2)" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(e("ac2e")).default ],
            methods: {}
        };
        t.default = c;
    },
    "8a1e": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var c = o(e("aef8"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(c.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    aef8: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("d677"), c = e("051e");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(a);
        e("2b1c");
        var u = e("f0c5"), i = Object(u.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    },
    d677: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return c;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, a = [];
    }
}, [ [ "8a1e", "common/runtime", "common/vendor" ] ] ]);