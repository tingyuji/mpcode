(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin8/pin8" ], {
    "07fd": function(n, t, a) {
        "use strict";
        (function(n, t) {
            var e = a("4ea4");
            a("8a42"), e(a("66fd"));
            var i = e(a("fa98"));
            n.__webpack_require_UNI_MP_PLUGIN__ = a, t(i.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    1140: function(n, t, a) {
        "use strict";
        a.d(t, "b", function() {
            return i;
        }), a.d(t, "c", function() {
            return l;
        }), a.d(t, "a", function() {
            return e;
        });
        var e = {
            pinContent: function() {
                return a.e("components/pin-content/pin-content").then(a.bind(null, "55f1"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, l = [];
    },
    "1a57": function(n, t, a) {
        "use strict";
        var e = a("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                        return resolve(a("e665"));
                    }.bind(null, a)).catch(a.oe);
                },
                pinContent: function() {
                    a.e("components/pin-content/pin-content").then(function() {
                        return resolve(a("55f1"));
                    }.bind(null, a)).catch(a.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "TMDS data 2− (Digital red- link 1)", "TMDS data 2+ (Digital red+ link 1)", "TMDS data 2/4 shield", "TMDS data 4− (Digital green− link 2)", "TMDS data 4+ (Digital green+ link 2)", "DDC clock", "DDC data", "Analog vertical sync", "TMDS data 1− (Digital green− link 1)", "TMDS data 1+ (Digital green+ link 1)", "TMDS data 1/3 shield", "TMDS data 3- (Digital blue− link 2)", "TMDS data 3+ (Digital blue+ link 2)", "+5 V (Power for monitor when in standby)", "Ground (Return for pin 14 and analog sync)", "Hot plug detect", "TMDS data 0− (Digital blue− link 1 and digital sync)", "TMDS data 0+ (Digital blue+ link 1 and digital sync)", "TMDS data 0/5 shield", "TMDS data 5− (Digital red− link 2)", "TMDS data 5+ (Digital red+ link 2)", "TMDS clock shield", "TMDS clock+ (Digital clock+ links 1 and 2)", "TMDS clock− (Digital clock− links 1 and 2)", "[C1] Analog red", "[C2] Analog green", "[C3] Analog blue", "[C4] Analog horizontal sync", "[C5] Analog ground (Return for R, G, and B signals)" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ e(a("ac2e")).default ],
            methods: {}
        };
        t.default = i;
    },
    7877: function(n, t, a) {},
    cd35: function(n, t, a) {
        "use strict";
        a.r(t);
        var e = a("1a57"), i = a.n(e);
        for (var l in e) [ "default" ].indexOf(l) < 0 && function(n) {
            a.d(t, n, function() {
                return e[n];
            });
        }(l);
        t.default = i.a;
    },
    d176: function(n, t, a) {
        "use strict";
        var e = a("7877");
        a.n(e).a;
    },
    fa98: function(n, t, a) {
        "use strict";
        a.r(t);
        var e = a("1140"), i = a("cd35");
        for (var l in i) [ "default" ].indexOf(l) < 0 && function(n) {
            a.d(t, n, function() {
                return i[n];
            });
        }(l);
        a("d176");
        var o = a("f0c5"), c = Object(o.a)(i.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        t.default = c.exports;
    }
}, [ [ "07fd", "common/runtime", "common/vendor" ] ] ]);