(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin10/pin10" ], {
    "50ab": function(n, e, i) {
        "use strict";
        (function(n, e) {
            var t = i("4ea4");
            i("8a42"), t(i("66fd"));
            var a = t(i("b052"));
            n.__webpack_require_UNI_MP_PLUGIN__ = i, e(a.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    9667: function(n, e, i) {
        "use strict";
        var t = i("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            components: {
                vipMask: function() {
                    Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                        return resolve(i("e665"));
                    }.bind(null, i)).catch(i.oe);
                },
                pinContent: function() {
                    i.e("components/pin-content/pin-content").then(function() {
                        return resolve(i("55f1"));
                    }.bind(null, i)).catch(i.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Twisted-pair B-, differential signals", "Twisted-pair B+, differential signals", "Twisted-pair A-, differential signals", "Twisted-pair A+, differential signals" ],
                    contentList1: [ "Unregulated DC; 30 V no load", "Ground return for power and inner cable shield", "Twisted-pair B-, differential signals", "Twisted-pair B+, differential signals", "Twisted-pair A-, differential signals", "Twisted-pair A+, differential signals" ],
                    contentList2: [ "Twisted-pair B-, differential signals", "Twisted-pair B+, differential signals", "Twisted-pair A-, differential signals", "Twisted-pair A+, differential signals", "A shield", "Ground return for power and inner cable shield", "-", "Unregulated DC; 30 V no load", "B shield" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ t(i("ac2e")).default ],
            methods: {}
        };
        e.default = a;
    },
    "9ee0": function(n, e, i) {
        "use strict";
        i.r(e);
        var t = i("9667"), a = i.n(t);
        for (var r in t) [ "default" ].indexOf(r) < 0 && function(n) {
            i.d(e, n, function() {
                return t[n];
            });
        }(r);
        e.default = a.a;
    },
    "9fa5": function(n, e, i) {},
    a8fd: function(n, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return a;
        }), i.d(e, "c", function() {
            return r;
        }), i.d(e, "a", function() {
            return t;
        });
        var t = {
            pinContent: function() {
                return i.e("components/pin-content/pin-content").then(i.bind(null, "55f1"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    b052: function(n, e, i) {
        "use strict";
        i.r(e);
        var t = i("a8fd"), a = i("9ee0");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(n) {
            i.d(e, n, function() {
                return a[n];
            });
        }(r);
        i("facb");
        var s = i("f0c5"), f = Object(s.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = f.exports;
    },
    facb: function(n, e, i) {
        "use strict";
        var t = i("9fa5");
        i.n(t).a;
    }
}, [ [ "50ab", "common/runtime", "common/vendor" ] ] ]);