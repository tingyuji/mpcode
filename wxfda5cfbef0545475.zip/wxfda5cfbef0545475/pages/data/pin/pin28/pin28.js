(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin28/pin28" ], {
    3305: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var u = o(t("7de7"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "5e9b": function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return u;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "7de7": function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("5e9b"), u = t("d324");
        for (var i in u) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(i);
        t("c018");
        var r = t("f0c5"), c = Object(r.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = c.exports;
    },
    c018: function(n, e, t) {
        "use strict";
        var o = t("edec");
        t.n(o).a;
    },
    cfd6: function(n, e, t) {
        "use strict";
        var o = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "[VCC] +5V or 3.3V DC power supply input", "[RESET] Card reset, used to reset the card's communications (optional)", "[CLOCK] Card clock", "[RESERVED] AUX1, optionally used for USB interfaces and other uses", "[GND] Ground", "[VPP] +21V DC programing voltage input (optional)", "[I/O] Input or Output for serial data (half-duplex)", "[RESERVED] AUX2, optionally used for USB interfaces and other uses" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(t("ac2e")).default ],
            methods: {}
        };
        e.default = u;
    },
    d324: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("cfd6"), u = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(i);
        e.default = u.a;
    },
    edec: function(n, e, t) {}
}, [ [ "3305", "common/runtime", "common/vendor" ] ] ]);