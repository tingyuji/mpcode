(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin20/pin20" ], {
    "044e": function(e, n, t) {
        "use strict";
        var r = t("eac2");
        t.n(r).a;
    },
    "1d8b": function(e, n, t) {
        "use strict";
        var r = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Speed-dependent volume control", "Mute control", "Reversing light switch", "Permanent +12V input to the radio from the battery", "+12V output from the radio (max 350 mA)", "+12V input to the radio when the car's lights are on", "+12V input to the radio when the ignition is on", "Ground" ],
                    contentList1: [ "Right rear speaker +", "Right rear speaker -", "Right front speaker +", "Right front speaker -", "Left front speaker +", "Left front speaker -", "Left rear speaker +", "Left rear speaker -" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ r(t("ac2e")).default ],
            methods: {}
        };
        n.default = o;
    },
    6893: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {
            return r;
        });
        var r = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "7afd": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t("4ea4");
            t("8a42"), r(t("66fd"));
            var o = r(t("d207"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    9118: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("1d8b"), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    d207: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("6893"), o = t("9118");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        t("044e");
        var a = t("f0c5"), u = Object(a.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        n.default = u.exports;
    },
    eac2: function(e, n, t) {}
}, [ [ "7afd", "common/runtime", "common/vendor" ] ] ]);