(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin3/pin3" ], {
    "031d": function(n, e, t) {
        "use strict";
        (function(n, e) {
            var i = t("4ea4");
            t("8a42"), i(t("66fd"));
            var o = i(t("03c9"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "03c9": function(n, e, t) {
        "use strict";
        t.r(e);
        var i = t("5dad"), o = t("38a8");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        t("4ed7");
        var r = t("f0c5"), u = Object(r.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = u.exports;
    },
    1652: function(n, e, t) {
        "use strict";
        var i = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Microphone -", "Speaker +", "Speaker -", "Microphone +" ],
                    contentList1: [ "R1 -", "T1 +" ],
                    contentList2: [ "T2 +", "R1 -", "T1 +", "R2 -" ],
                    contentList3: [ "T3 +", "T2 +", "R1 -", "T1 +", "R2 -", "R3 -" ],
                    contentList4: [ "RX Ring -", "RX Tip +", "Reserved", "TX Ring -", "TX Tip +", "Reserved", "Shield", "Shield" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ i(t("ac2e")).default ],
            methods: {}
        };
        e.default = o;
    },
    "299e": function(n, e, t) {},
    "38a8": function(n, e, t) {
        "use strict";
        t.r(e);
        var i = t("1652"), o = t.n(i);
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(c);
        e.default = o.a;
    },
    "4ed7": function(n, e, t) {
        "use strict";
        var i = t("299e");
        t.n(i).a;
    },
    "5dad": function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {
            return i;
        });
        var i = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    }
}, [ [ "031d", "common/runtime", "common/vendor" ] ] ]);