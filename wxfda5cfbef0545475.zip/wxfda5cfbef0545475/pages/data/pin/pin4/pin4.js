(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin4/pin4" ], {
    "04b6": function(n, t, e) {
        "use strict";
        var o = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Audio output (Right)", "Audio input (Right)", "Audio output (Left/Mono)", "Audio ground", "RGB Blue ground", "Audio input (Left/Mono)", "RGB Blue up\\10S-Video C down\\10Component PB up", "Status & Aspect Ratio up", "RGB Green ground", "Clock / Data 2\\10Control bus (AV.link)", "RGB Green up\\10Component Y up", "Reserved / Data 1", "RGB Red ground", "Usually Data signal ground", "RGB Red up\\10S-Video C up\\10Component PR up", "Blanking signal up\\10RGB-selection voltage up", "Composite video ground", "Blanking signal ground", "Composite video output\\10S-Video Y output", "Composite video input\\10S-Video Y input", "Shell/Chassis" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(e("ac2e")).default ],
            methods: {}
        };
        t.default = u;
    },
    "0f64": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "1e73": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("04b6"), u = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = u.a;
    },
    "3cd6": function(n, t, e) {
        "use strict";
        var o = e("aa6c");
        e.n(o).a;
    },
    4702: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var u = o(e("d277"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    aa6c: function(n, t, e) {},
    d277: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("0f64"), u = e("1e73");
        for (var i in u) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(i);
        e("3cd6");
        var a = e("f0c5"), c = Object(a.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    }
}, [ [ "4702", "common/runtime", "common/vendor" ] ] ]);