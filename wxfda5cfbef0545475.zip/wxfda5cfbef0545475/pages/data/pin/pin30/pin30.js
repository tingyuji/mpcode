(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin30/pin30" ], {
    "202a": function(n, t, e) {},
    5267: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return r;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    5998: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("77af"), i = e.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = i.a;
    },
    "77af": function(n, t, e) {
        "use strict";
        var o = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "[L+] +24V DC device power [Brown]", "[I/Q] Manufacturer's discretion for input, output or configurable I/O with common on pin 3 [White]", "[L-] 0V DC ground for device power [Blue]", "[C/Q] SIO standard input/output or IO-Link communication [Black]" ],
                    contentList1: [ "[L+] +24V DC device power [Brown]", "[I/Q] Manufacturer's discretion for input, output or configurable I/O with common on pin 3 [White]", "[L-] 0V DC ground for device power [Blue]", "[C/Q] SIO standard input/output or IO-Link communication [Black]" ],
                    contentList2: [ "[L+] +24V DC device power [Brown]", "[I/Q] Manufacturer's discretion for input, output or configurable I/O with common on pin 3 [White]", "[L-] 0V DC ground for device power [Blue]", "[C/Q] SIO standard input/output or IO-Link communication [Black]" ],
                    contentList3: [ "[L+] +24V DC device power [Brown]", "[2L+] +24V DC additional power [Color not defined]", "[L-] 0V DC ground for device power [Blue]", "[C/Q] SIO standard input/output or IO-Link communication [Black]", "[2L-] 0V DC ground for additional power [Color not defined]" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(e("ac2e")).default ],
            methods: {}
        };
        t.default = i;
    },
    "9e4a": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var i = o(e("c835"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(i.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    c835: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("5267"), i = e("5998");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(r);
        e("dcbf");
        var u = e("f0c5"), c = Object(u.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    dcbf: function(n, t, e) {
        "use strict";
        var o = e("202a");
        e.n(o).a;
    }
}, [ [ "9e4a", "common/runtime", "common/vendor" ] ] ]);