(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin11/pin11" ], {
    1662: function(n, t, o) {
        "use strict";
        var e = o("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            components: {
                vipMask: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/vip/vip") ]).then(function() {
                        return resolve(o("e665"));
                    }.bind(null, o)).catch(o.oe);
                },
                pinContent: function() {
                    o.e("components/pin-content/pin-content").then(function() {
                        return resolve(o("55f1"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "+12 V", "Ground", "Ground", "+5 V" ],
                    contentList1: [ "+3.3 V", "+3.3 V", "Ground", "+5 V", "Ground", "+5 V", "Ground", "Power OK", "+5 V Standby", "+12 V", "+3.3 V", "-12 V", "Ground", "Power On", "Ground", "Ground", "Ground", "-5 V", "+5 V", "+5 V" ],
                    contentList2: [ "+3.3 V", "+3.3 V", "Ground", "+5 V", "Ground", "+5 V", "Ground", "Power OK", "+5 V Standby", "+12 V", "+12 V", "+3.3 V", "+3.3 V", "-12 V", "Ground", "Power On", "Ground", "Ground", "Ground", "-5 V", "+5 V", "+5 V", "+5 V", "Ground" ],
                    contentList3: [ "Ground", "Ground", "+12 V", "+12 V" ],
                    contentList4: [ "+12 V", "+12 V", "+12 V", "Ground", "Ground", "Ground", "Ground", "Ground" ],
                    contentList5: [ "Ground", "Ground", "Ground", "+3.3 V", "+3.3 V", "+5 V" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ e(o("ac2e")).default ],
            methods: {}
        };
        t.default = u;
    },
    "540d": function(n, t, o) {
        "use strict";
        o.d(t, "b", function() {
            return u;
        }), o.d(t, "c", function() {
            return r;
        }), o.d(t, "a", function() {
            return e;
        });
        var e = {
            pinContent: function() {
                return o.e("components/pin-content/pin-content").then(o.bind(null, "55f1"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    "5a52": function(n, t, o) {
        "use strict";
        o.r(t);
        var e = o("1662"), u = o.n(e);
        for (var r in e) [ "default" ].indexOf(r) < 0 && function(n) {
            o.d(t, n, function() {
                return e[n];
            });
        }(r);
        t.default = u.a;
    },
    6849: function(n, t, o) {
        "use strict";
        var e = o("d536");
        o.n(e).a;
    },
    c9f6: function(n, t, o) {
        "use strict";
        (function(n, t) {
            var e = o("4ea4");
            o("8a42"), e(o("66fd"));
            var u = e(o("ed49"));
            n.__webpack_require_UNI_MP_PLUGIN__ = o, t(u.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    },
    d536: function(n, t, o) {},
    ed49: function(n, t, o) {
        "use strict";
        o.r(t);
        var e = o("540d"), u = o("5a52");
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(n) {
            o.d(t, n, function() {
                return u[n];
            });
        }(r);
        o("6849");
        var d = o("f0c5"), c = Object(d.a)(u.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        t.default = c.exports;
    }
}, [ [ "c9f6", "common/runtime", "common/vendor" ] ] ]);