(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin17/pin17" ], {
    "04ce": function(e, l, o) {
        "use strict";
        var n = o("4ea4");
        Object.defineProperty(l, "__esModule", {
            value: !0
        }), l.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/vip/vip") ]).then(function() {
                        return resolve(o("e665"));
                    }.bind(null, o)).catch(o.oe);
                },
                pinContent: function() {
                    o.e("components/pin-content/pin-content").then(function() {
                        return resolve(o("55f1"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Blue", "Orange", "Green", "Brown", "Slate", "White", "Red", "Black", "Yellow", "Violet", "Rose", "Aqua", "Blue/Black", "Orange/Black", "Green/Black", "Brown/Black", "Slate/Black", "White/Black", "Red/Black", "Black/Yellow", "Yellow/Black", "Violet/Black", "Rose/Black", "Aqua/Black" ],
                    color: [ "filo_blue", "filo_orange", "filo_green", "filo_brown", "filo_slate", "filo_white", "filo_red", "filo_black", "filo_yellow", "filo_violet", "filo_rose", "filo_aqua", "filo_blue_black", "filo_orange_black", "filo_green_black", "filo_brown_black", "filo_slate_black", "filo_white_black", "filo_red_black", "filo_black_yellow", "filo_yellow_black", "filo_violet_black", "filo_rose_black", "filo_aqua_black" ],
                    leixing: [ "Multimode 1a", "Multimode 1a", "Multimode 1a", "Multimode 1a", "Singlemode IVa", "Singlemode IVb" ],
                    zhijin: [ "50/125µm (Orange)", "62.5/125µm (Slate)", "85/125µm (Blue)", "100/140µm (Green)", "All (Yellow)", "All (Red)" ],
                    color1: [ "filo_orange", "filo_slate", "filo_blue", "filo_green", "filo_yellow", "filo_red" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ n(o("ac2e")).default ],
            methods: {}
        };
        l.default = i;
    },
    3038: function(e, l, o) {},
    "4d35": function(e, l, o) {
        "use strict";
        o.d(l, "b", function() {
            return n;
        }), o.d(l, "c", function() {
            return i;
        }), o.d(l, "a", function() {});
        var n = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "719f": function(e, l, o) {
        "use strict";
        o.r(l);
        var n = o("04ce"), i = o.n(n);
        for (var t in n) [ "default" ].indexOf(t) < 0 && function(e) {
            o.d(l, e, function() {
                return n[e];
            });
        }(t);
        l.default = i.a;
    },
    "94fd": function(e, l, o) {
        "use strict";
        o.r(l);
        var n = o("4d35"), i = o("719f");
        for (var t in i) [ "default" ].indexOf(t) < 0 && function(e) {
            o.d(l, e, function() {
                return i[e];
            });
        }(t);
        o("97f3");
        var a = o("f0c5"), c = Object(a.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        l.default = c.exports;
    },
    "97f3": function(e, l, o) {
        "use strict";
        var n = o("3038");
        o.n(n).a;
    },
    d3c7: function(e, l, o) {
        "use strict";
        (function(e, l) {
            var n = o("4ea4");
            o("8a42"), n(o("66fd"));
            var i = n(o("94fd"));
            e.__webpack_require_UNI_MP_PLUGIN__ = o, l(i.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    }
}, [ [ "d3c7", "common/runtime", "common/vendor" ] ] ]);