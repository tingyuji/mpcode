(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin24/pin24" ], {
    "070a": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("cb62"), c = e.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = c.a;
    },
    2073: function(n, t, e) {
        "use strict";
        var o = e("dce9");
        e.n(o).a;
    },
    "3c17": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("6e70"), c = e("070a");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(a);
        e("2073");
        var i = e("f0c5"), u = Object(i.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "6e70": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return c;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, c = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "9f24": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var c = o(e("3c17"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(c.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    cb62: function(n, t, e) {
        "use strict";
        var o = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var c = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "[T] Signal", "[S] Ground" ],
                    contentList1: [ "[T] Unbalanced stereo: Left\\10[T] Balanced mono: Hot (+)", "[R] Unbalanced stereo: Right\\10[R] Balanced mono: Cold (-)", "[S] Ground" ],
                    contentList2: [ "[T] Left", "[R1] Right", "[R2] Variant A (OMTP): Aux\\10[R2] Variant B (CTIA): Ground", "[S] Variant A (OMTP): Ground\\10[S] Variant B (CTIA): Aux" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(e("ac2e")).default ],
            methods: {}
        };
        t.default = c;
    },
    dce9: function(n, t, e) {}
}, [ [ "9f24", "common/runtime", "common/vendor" ] ] ]);