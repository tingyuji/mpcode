(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin6/pin6" ], {
    "0282": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {
            return u;
        });
        var u = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "08db": function(n, t, e) {
        "use strict";
        var u = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Ground (A1)", "TX1+ (A2)", "TX1- (A3)", "Vbus (A4)", "CC1 (A5)", "D+ (A6)", "D- (A7)", "SBU1 (A8)", "Vbus (A9)", "RX2- (A10)", "RX2+ (A11)", "Ground (A12)", "Ground (B12)", "RX1+ (B11)", "RX1- (B10)", "Vbus (B9)", "SBU2 (B8)", "D- (B7)", "D+ (B6)", "CC2 (B5)", "Vbus (B4)", "TX2- (B3)", "TX2+ (B2)", "Ground (B1)" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ u(e("ac2e")).default ],
            methods: {}
        };
        t.default = o;
    },
    5017: function(n, t, e) {},
    "5d7a": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("08db"), o = e.n(u);
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        t.default = o.a;
    },
    aa4e: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var u = e("4ea4");
            e("8a42"), u(e("66fd"));
            var o = u(e("e6d5"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(o.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    dcf9: function(n, t, e) {
        "use strict";
        var u = e("5017");
        e.n(u).a;
    },
    e6d5: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("0282"), o = e("5d7a");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        e("dcf9");
        var i = e("f0c5"), r = Object(i.a)(o.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        t.default = r.exports;
    }
}, [ [ "aa4e", "common/runtime", "common/vendor" ] ] ]);