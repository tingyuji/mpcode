(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin23/pin23" ], {
    "2e23": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("8019"), u = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = u.a;
    },
    4694: function(n, t, e) {
        "use strict";
        var o = e("e962");
        e.n(o).a;
    },
    8019: function(n, t, e) {
        "use strict";
        var o = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Not connected", "Ground", "Not connected", "Current Sink (CSINK)", "Current Source (CSRC)" ],
                    contentList1: [ "+5V DC", "Button 1", "X axis for joystick 1 (0–100 kΩ)", "Ground for Button 1", "Ground for Button 2", "Y axis for joystick 1 (0–100 kΩ)", "Button 2", "+5V DC", "+5V DC", "Button 4", "X axis for joystick 2 (0–100 kΩ)", "Ground for buttons 3 and 4 (or MIDI out)", "Y axis for joystick 2 (0–100 kΩ)", "Button 3", "+5 V DC (or MIDI in)" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(e("ac2e")).default ],
            methods: {}
        };
        t.default = u;
    },
    a071: function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    e028: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var u = o(e("f539"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    e962: function(n, t, e) {},
    f539: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("a071"), u = e("2e23");
        for (var i in u) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(i);
        e("4694");
        var r = e("f0c5"), c = Object(r.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    }
}, [ [ "e028", "common/runtime", "common/vendor" ] ] ]);