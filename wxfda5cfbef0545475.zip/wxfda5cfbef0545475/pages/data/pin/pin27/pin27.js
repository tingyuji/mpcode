(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin27/pin27" ], {
    1321: function(e, n, t) {
        "use strict";
        var o = t("81eb");
        t.n(o).a;
    },
    "1b3e": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var a = o(t("b806"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(a.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "2a0e": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("c9e5"), a = t.n(o);
        for (var d in o) [ "default" ].indexOf(d) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(d);
        n.default = a.a;
    },
    "3cb1": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return d;
        }), t.d(n, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, d = [];
    },
    "81eb": function(e, n, t) {},
    b806: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("3cb1"), a = t("2a0e");
        for (var d in a) [ "default" ].indexOf(d) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(d);
        t("1321");
        var i = t("f0c5"), c = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = c.exports;
    },
    c9e5: function(e, n, t) {
        "use strict";
        var o = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "SD Mode: Card detection / Connector data line 3\\10SPI Mode: Chip selection in low status", "SD Mode: Command/Response line\\10SPI Mode: Master Out / Slave In", "Ground", "Power supply", "Clock", "Ground", "SD Mode: Connector data line 0\\10SPI Mode: Master In / Slave Out", "SD Mode: Connector data line 1\\10SPI Mode: Unused or IRQ", "SD Mode: Connector data line 2\\10SPI Mode: Unused" ],
                    contentList1: [ "SD Mode: Card detection / Connector data line 3\\10SPI Mode: Chip selection in low status", "SD Mode: Command/Response line\\10SPI Mode: Master Out / Slave In", "Ground", "Power supply", "Clock", "Ground", "SD Mode: Connector data line 0\\10SPI Mode: Master In / Slave Out", "SD Mode: Connector data line 1\\10SPI Mode: Unused", "SD Mode: Connector data line 2\\10SPI Mode: Unused", "Reserved", "Reserved" ],
                    contentList2: [ "SD Mode: Data bit 2\\10SPI Mode: Not connected", "SD Mode: Card Detect / Data Bit 3\\10SPI Mode: Chip Select", "SD Mode: Command Line\\10SPI Mode: Master Out / Slave In", "Power supply", "Clock", "Ground", "SD Mode: Data Bit 0\\10SPI Mode: Master In / Slave Out", "SD Mode: Data Bit 1\\10SPI Mode: Reserved" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(t("ac2e")).default ],
            methods: {}
        };
        n.default = a;
    }
}, [ [ "1b3e", "common/runtime", "common/vendor" ] ] ]);