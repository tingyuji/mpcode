(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin13/pin13" ], {
    "7ba4": function(n, e, t) {
        "use strict";
        (function(n, e) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var i = o(t("ba63"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "7c83": function(n, e, t) {
        "use strict";
        var o = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Ground", "Lane 0 positive", "Lane 0 negative", "Identification/control 0", "Power (charger or battery)", "Lane 1 negative", "Lane 1 positive", "Identification/control 1" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(t("ac2e")).default ],
            methods: {}
        };
        e.default = i;
    },
    ba63: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("bb57"), i = t("e89d");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(c);
        t("edef");
        var a = t("f0c5"), r = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = r.exports;
    },
    bb57: function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return i;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    e89d: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("7c83"), i = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = i.a;
    },
    edef: function(n, e, t) {
        "use strict";
        var o = t("ff82");
        t.n(o).a;
    },
    ff82: function(n, e, t) {}
}, [ [ "7ba4", "common/runtime", "common/vendor" ] ] ]);