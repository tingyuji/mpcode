(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin19/pin19" ], {
    "003c": function(I, n, P) {},
    6439: function(I, n, P) {
        "use strict";
        var e = P("003c");
        P.n(e).a;
    },
    "793e": function(I, n, P) {
        "use strict";
        P.r(n);
        var e = P("cb9f"), t = P.n(e);
        for (var G in e) [ "default" ].indexOf(G) < 0 && function(I) {
            P.d(n, I, function() {
                return e[I];
            });
        }(G);
        n.default = t.a;
    },
    "8be2": function(I, n, P) {
        "use strict";
        P.d(n, "b", function() {
            return t;
        }), P.d(n, "c", function() {
            return G;
        }), P.d(n, "a", function() {
            return e;
        });
        var e = {
            pinContent: function() {
                return P.e("components/pin-content/pin-content").then(P.bind(null, "55f1"));
            }
        }, t = function() {
            this.$createElement, this._self._c;
        }, G = [];
    },
    ab1b: function(I, n, P) {
        "use strict";
        P.r(n);
        var e = P("8be2"), t = P("793e");
        for (var G in t) [ "default" ].indexOf(G) < 0 && function(I) {
            P.d(n, I, function() {
                return t[I];
            });
        }(G);
        P("6439");
        var S = P("f0c5"), o = Object(S.a)(t.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        n.default = o.exports;
    },
    cb9f: function(I, n, P) {
        "use strict";
        var e = P("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var t = {
            components: {
                vipMask: function() {
                    Promise.all([ P.e("common/vendor"), P.e("components/vip/vip") ]).then(function() {
                        return resolve(P("e665"));
                    }.bind(null, P)).catch(P.oe);
                },
                pinContent: function() {
                    P.e("components/pin-content/pin-content").then(function() {
                        return resolve(P("55f1"));
                    }.bind(null, P)).catch(P.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "+3.3V (50mA max)", "+5V", "GPIO2 - I2C1 SDA", "+5V", "GPIO3 - I2C1 SCL", "Ground", "GPIO4 - 1-wire default", "GPIO14 - UART0 TX", "Ground", "GPIO15 - UART0 RX", "GPIO17 - SPI1 CE1", "GPIO18 - SPI1 CE0", "GPIO27", "Ground", "GPIO22", "GPIO23", "+3.3V (50mA max)", "GPIO24", "GPIO10 - SPI0 MOSI", "Ground", "GPIO9 - SPI0 MISO", "GPIO25", "GPIO11 - SPI0 SCLK", "GPIO8 - SPI0 CE0 N", "Ground", "GPIO7 - SPI0 CE1 N", "GPIO0 - I2C0 SDA", "GPIO1 - I2C0 SCL", "GPIO5", "Ground", "GPIO6", "GPIO12", "GPIO13", "Ground", "GPIO19 - SPI1 MISO", "GPIO16 - SPI1 CE2", "GPIO26", "GPIO20 - SPI1 MOSI", "Ground", "GPIO21 - SPI1 SCLK" ],
                    contentList1: [ "+3.3V (50mA max)", "+5V", "Rev1: GPIO0 - I2C0 SDA\\10Rev2: GPIO2 - I2C1 SDA", "+5V", "Rev1: GPIO1 - I2C0 SCL\\10Rev2: GPIO3 - I2C1 SCL", "Ground", "GPIO4 - 1-wire default", "GPIO14 - UART TX", "Ground", "GPIO15 - UART RX", "GPIO17", "GPIO18", "Rev1: GPIO21\\10Rev2: GPIO27", "Ground", "GPIO22", "GPIO23", "+3.3V (50mA max)", "GPIO24", "GPIO10 - SPI0 MOSI", "Ground", "GPIO9 - SPI0 MISO", "GPIO25", "GPIO11 - SPI0 SCLK", "GPIO8 - SPI0 CE0 N", "Ground", "GPIO7 - SPI0 CE1 N" ],
                    contentList2: [ "GPIO 0 - SPI0 RX - I2C0 SDA - UART0 TX (Default)", "GPIO 1 - SPI0 CS - I2C0 SCL - UART0 RX (Default)", "Ground", "GPIO 2 - SPI0 SCLK - I2C1 SDA", "GPIO 3 - SPI0 TX - I2C1 SCL", "GPIO 4 - SPI0 RX - I2C0 SDA - UART1 TX", "GPIO 5 - SPI0 CS - I2C0 SCL - UART1 RX", "Ground", "GPIO 6 - SPI0 SCLK - I2C1 SDA", "GPIO 7 - SPI0 TX - I2C1 SCL", "GPIO 8 - SPI1 RX - I2C0 SDA - UART1 TX", "GPIO 9 - SPI1 CS - I2C0 SCL - UART1 RX", "Ground", "GPIO 10 - SPI1 SCLK - I2C1 SDA", "GPIO 11 - SPI1 TX - I2C1 SCL", "GPIO 12 - SPI1 RX - I2C0 SDA - UART0 TX", "GPIO 13 - SPI1 CS - I2C0 SCL - UART0 RX", "Ground", "GPIO 14 - SPI1 SCLK - I2C1 SDA", "GPIO 15 - SPI1 TX - I2C1 SCL", "GPIO 16 - SPI0 RX - I2C0 SDA - UART0 TX", "GPIO 17 - SPI0 CS - I2C0 SCL - UART0 RX", "Ground", "GPIO 18 - SPI0 SCLK - I2C1 SDA", "GPIO 19 - SPI0 TX - I2C1 SCL", "GPIO 20", "GPIO 21", "Ground", "GPIO 22", "Run", "GPIO 26 - ADC0 - I2C1 SDA", "GPIO 27 - ADC1 - I2C1 SCL", "Ground - AGND", "GPIO 28 - ADC2", "ADC VREF", "3.3V (out)", "3.3V EN", "Ground", "VSYS", "VBUS", "SWDIO", "Ground", "SWCLK", "GPIO 25" ],
                    indexArr: {
                        41: "D1",
                        42: "D2",
                        43: "D3",
                        44: "LED"
                    },
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ e(P("ac2e")).default ],
            methods: {}
        };
        n.default = t;
    },
    e5e7: function(I, n, P) {
        "use strict";
        (function(I, n) {
            var e = P("4ea4");
            P("8a42"), e(P("66fd"));
            var t = e(P("ab1b"));
            I.__webpack_require_UNI_MP_PLUGIN__ = P, n(t.default);
        }).call(this, P("bc2e").default, P("543d").createPage);
    }
}, [ [ "e5e7", "common/runtime", "common/vendor" ] ] ]);