(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin14/pin14" ], {
    5244: function(n, e, o) {
        "use strict";
        o.r(e);
        var t = o("824a"), i = o("cf30");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(n) {
            o.d(e, n, function() {
                return i[n];
            });
        }(r);
        o("a714");
        var a = o("f0c5"), u = Object(a.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = u.exports;
    },
    "5d54": function(n, e, o) {
        "use strict";
        var t = o("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ o.e("common/vendor"), o.e("components/vip/vip") ]).then(function() {
                        return resolve(o("e665"));
                    }.bind(null, o)).catch(o.oe);
                },
                pinContent: function() {
                    o.e("components/pin-content/pin-content").then(function() {
                        return resolve(o("55f1"));
                    }.bind(null, o)).catch(o.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Ground (-), internaly connected with Pin 2 on iPod motherboard", "Audio and Video ground (-), internaly connected with Pin 2 on iPod motherboard", "Line Out R+ (Audio output, right channel)", "Line Out L+ (Audio output, left channel)", "Line In R+ (Audio input, right channel)", "Line In L+ (Audio input, left channel)", "Unknown", "Composite video output (only when the slideshow mode is active on iPod Photo) or Component Video Pb", "S-Video Chrominance output for iPod Color (Photo only) or Component Video Y", "S-Video Luminance output for iPod Color (Photo only) or Component Video Pr", "Serial ground", "iPod sending line (Serial Tx)", "iPod receiving line (Serial Rx)", "Reserved", "Ground (-), internaly connected with pin 16 on iPod motherboard", "USB Ground (-), internaly connected with pin 15 on iPod motherboard", "Reserved", "3.3V Power (+)", "Firewire Power 12V (+)", "Firewire Power 12V (+)", "Accessory Indicator/Serial enable", "FireWire Data TPA (-)", "USB Power 5V (+)", "FireWire Data TPA (+)", "USB Data (-)", "FireWire Data TPB (-)", "USB Data (+)", "FireWire Data TPB (+)", "FireWire Ground (-)", "FireWire Ground (-)" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ t(o("ac2e")).default ],
            methods: {}
        };
        e.default = i;
    },
    "824a": function(n, e, o) {
        "use strict";
        o.d(e, "b", function() {
            return i;
        }), o.d(e, "c", function() {
            return r;
        }), o.d(e, "a", function() {
            return t;
        });
        var t = {
            pinContent: function() {
                return o.e("components/pin-content/pin-content").then(o.bind(null, "55f1"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    a714: function(n, e, o) {
        "use strict";
        var t = o("eb43");
        o.n(t).a;
    },
    cf30: function(n, e, o) {
        "use strict";
        o.r(e);
        var t = o("5d54"), i = o.n(t);
        for (var r in t) [ "default" ].indexOf(r) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(r);
        e.default = i.a;
    },
    d214: function(n, e, o) {
        "use strict";
        (function(n, e) {
            var t = o("4ea4");
            o("8a42"), t(o("66fd"));
            var i = t(o("5244"));
            n.__webpack_require_UNI_MP_PLUGIN__ = o, e(i.default);
        }).call(this, o("bc2e").default, o("543d").createPage);
    },
    eb43: function(n, e, o) {}
}, [ [ "d214", "common/runtime", "common/vendor" ] ] ]);