(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin5/pin5" ], {
    "088c": function(n, e, i) {},
    "5ee4": function(n, e, i) {
        "use strict";
        (function(n, e) {
            var t = i("4ea4");
            i("8a42"), t(i("66fd"));
            var o = t(i("ac2ad"));
            n.__webpack_require_UNI_MP_PLUGIN__ = i, e(o.default);
        }).call(this, i("bc2e").default, i("543d").createPage);
    },
    9282: function(n, e, i) {
        "use strict";
        var t = i("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            components: {
                vipMask: function() {
                    Promise.all([ i.e("common/vendor"), i.e("components/vip/vip") ]).then(function() {
                        return resolve(i("e665"));
                    }.bind(null, i)).catch(i.oe);
                },
                pinContent: function() {
                    i.e("components/pin-content/pin-content").then(function() {
                        return resolve(i("55f1"));
                    }.bind(null, i)).catch(i.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Vcc (+5V) [Red]", "Data - [White]", "Data + [Green]", "Ground [Black]" ],
                    contentList1: [ "Vcc (+5V)", "Data -", "Data +", "None (Permits distinction of host connection from slave connection\\10• host: connected to Signal ground\\10• slave: not connected)", "Ground" ],
                    contentList2: [ "Vcc (+5V)", "USB 2.0 differential pair (D−)", "USB 2.0 differential pair (D+)", "Ground for power", "USB 3.0 signal receiving line (−)", "USB 3.0 signal receiving line (+)", "Ground for signal", "USB 3.0 signal transmission line (−)", "USB 3.0 signal transmission line (+)" ],
                    contentList3: [ "Vcc (+5V)", "USB 2.0 differential pair (D−)", "USB 2.0 differential pair (D+)", "Ground for power", "USB 3.0 signal transmission line (−)", "USB 3.0 signal transmission line (+)", "Ground for signal", "USB 3.0 signal receiving line (−)", "USB 3.0 signal receiving line (+)", "Power provided by device", "Ground return for DPWR" ],
                    contentList4: [ "Vcc (+5V)", "USB 2.0 differential pair (D−)", "USB 2.0 differential pair (D+)", "USB OTG ID for identifying lines", "Ground for power", "USB 3.0 signal transmission line (−)", "USB 3.0 signal transmission line (+)", "Ground for signal", "USB 3.0 signal receiving line (−)", "USB 3.0 signal receiving line (+)" ],
                    contentList5: [ "Ground (A1)", "TX1+ (A2)", "TX1- (A3)", "Vbus (A4)", "CC1 (A5)", "D+ (A6)", "D- (A7)", "SBU1 (A8)", "Vbus (A9)", "RX2- (A10)", "RX2+ (A11)", "Ground (A12)", "Ground (B12)", "RX1+ (B11)", "RX1- (B10)", "Vbus (B9)", "SBU2 (B8)", "D- (B7)", "D+ (B6)", "CC2 (B5)", "Vbus (B4)", "TX2- (B3)", "TX2+ (B2)", "Ground (B1)" ]
                };
            },
            mixins: [ t(i("ac2e")).default ],
            methods: {}
        };
        e.default = o;
    },
    aac4: function(n, e, i) {
        "use strict";
        i.r(e);
        var t = i("9282"), o = i.n(t);
        for (var r in t) [ "default" ].indexOf(r) < 0 && function(n) {
            i.d(e, n, function() {
                return t[n];
            });
        }(r);
        e.default = o.a;
    },
    ac2ad: function(n, e, i) {
        "use strict";
        i.r(e);
        var t = i("bb1b"), o = i("aac4");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(n) {
            i.d(e, n, function() {
                return o[n];
            });
        }(r);
        i("f139");
        var a = i("f0c5"), c = Object(a.a)(o.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = c.exports;
    },
    bb1b: function(n, e, i) {
        "use strict";
        i.d(e, "b", function() {
            return o;
        }), i.d(e, "c", function() {
            return r;
        }), i.d(e, "a", function() {
            return t;
        });
        var t = {
            pinContent: function() {
                return i.e("components/pin-content/pin-content").then(i.bind(null, "55f1"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    f139: function(n, e, i) {
        "use strict";
        var t = i("088c");
        i.n(t).a;
    }
}, [ [ "5ee4", "common/runtime", "common/vendor" ] ] ]);