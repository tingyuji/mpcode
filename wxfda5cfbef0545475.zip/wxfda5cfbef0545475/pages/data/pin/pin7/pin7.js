(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin7/pin7" ], {
    "35e6": function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return r;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {
            return o;
        });
        var o = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "38e2": function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("881d"), r = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(i);
        e.default = r.a;
    },
    "49b4": function(n, e, t) {
        "use strict";
        (function(n, e) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var r = o(t("9ceb"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(r.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "516b": function(n, e, t) {
        "use strict";
        var o = t("bfee");
        t.n(o).a;
    },
    "881d": function(n, e, t) {
        "use strict";
        var o = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Red video", "Green video", "Blue video", "Formerly Monitor ID bit 2, reserved since E-DDC", "Ground (HSync)", "Red return", "Green return", "Blue return", "Formerly key, now +5V DC", "Ground (VSync, DDC)", "Formerly Monitor ID bit 0, reserved since E-DDC", "Formerly Monitor ID bit 1, I²C data since DDC2", "Horizontal sync", "Vertical sync", "Formerly Monitor ID bit 3, I²C clock since DDC2" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ o(t("ac2e")).default ],
            methods: {}
        };
        e.default = r;
    },
    "9ceb": function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("35e6"), r = t("38e2");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(i);
        t("516b");
        var c = t("f0c5"), u = Object(c.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = u.exports;
    },
    bfee: function(n, e, t) {}
}, [ [ "49b4", "common/runtime", "common/vendor" ] ] ]);