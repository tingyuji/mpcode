(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin25/pin25" ], {
    "5e19": function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t("8213"), o = t.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(c);
        e.default = o.a;
    },
    8213: function(n, e, t) {
        "use strict";
        var r = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            components: {
                vipMask: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/vip/vip") ]).then(function() {
                        return resolve(t("e665"));
                    }.bind(null, t)).catch(t.oe);
                },
                pinContent: function() {
                    t.e("components/pin-content/pin-content").then(function() {
                        return resolve(t("55f1"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "Ground", "Signal" ],
                    contentList1: [ "Left/Mono", "Right", "Center", "Left surround", "Right surround", "Left back surround", "Right back surround", "Subwoofer" ],
                    color1: [ "rca_white", "rca_red", "rca_green", "rca_blue", "rca_grey", "rca_brown", "rca_tan", "rca_purple" ],
                    contentList2: [ "S/PDIF" ],
                    color2: [ "rca_orange" ],
                    contentList3: [ "Composite" ],
                    color3: [ "rca_yellow" ],
                    contentList4: [ "Y", "Pb/Cb", "Pr/Cr" ],
                    color4: [ "rca_green", "rca_blue", "rca_red" ],
                    contentList5: [ "R", "G", "B", "H (Horizontal sync)\\10S (Composite sync)", "V (Vertical sync)" ],
                    color5: [ "rca_red", "rca_green", "rca_blue", "rca_yellow", "rca_white" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ r(t("ac2e")).default ],
            methods: {}
        };
        e.default = o;
    },
    a087: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var r = t("4ea4");
            t("8a42"), r(t("66fd"));
            var o = r(t("b1b0"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    b1b0: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t("c02f"), o = t("5e19");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        var a = t("f0c5"), i = Object(a.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        e.default = i.exports;
    },
    c02f: function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {
            return r;
        });
        var r = {
            pinContent: function() {
                return t.e("components/pin-content/pin-content").then(t.bind(null, "55f1"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    }
}, [ [ "a087", "common/runtime", "common/vendor" ] ] ]);