(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/pin/pin2/pin2" ], {
    "19ce": function(n, t, e) {
        "use strict";
        var a = e("bd58");
        e.n(a).a;
    },
    "620e": function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("dc4e"), i = e.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        t.default = i.a;
    },
    "64a3": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            pinContent: function() {
                return e.e("components/pin-content/pin-content").then(e.bind(null, "55f1"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    bd58: function(n, t, e) {},
    c78a: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var i = a(e("edcc"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(i.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    dc4e: function(n, t, e) {
        "use strict";
        var a = e("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = {
            components: {
                vipMask: function() {
                    Promise.all([ e.e("common/vendor"), e.e("components/vip/vip") ]).then(function() {
                        return resolve(e("e665"));
                    }.bind(null, e)).catch(e.oe);
                },
                pinContent: function() {
                    e.e("components/pin-content/pin-content").then(function() {
                        return resolve(e("55f1"));
                    }.bind(null, e)).catch(e.oe);
                }
            },
            data: function() {
                return {
                    contentList: [ "( TX D1 + ) Transmit data +", "( TX D1- ) Transmit data - ", "( RX D2 + ) Receive data +", "( BI D3 + ) Bi-directional data +", "( BI D3- ) Bi-directional data -", "( RX D2- ) Receive data -", " ( BI D4 + ) Bi-directional data +", " ( BI D4- ) Bi-directional data -" ],
                    user: {
                        vip_state: 0
                    }
                };
            },
            mixins: [ a(e("ac2e")).default ],
            methods: {}
        };
        t.default = i;
    },
    edcc: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("64a3"), i = e("620e");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(c);
        e("19ce");
        var o = e("f0c5"), r = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = r.exports;
    }
}, [ [ "c78a", "common/runtime", "common/vendor" ] ] ]);