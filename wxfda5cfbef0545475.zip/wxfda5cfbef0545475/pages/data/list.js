(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/data/list" ], {
    "42f2": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("b253")), o = n("9673"), s = n("628d"), c = getApp(), u = [ {
                type: "created_at",
                name: "最新"
            }, {
                type: "collects",
                name: "收藏最多"
            }, {
                type: "views",
                name: "浏览最多"
            } ], l = {
                components: {
                    navItem: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/nav-item/nav-item") ]).then(function() {
                            return resolve(n("231d"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        title: "",
                        id: 0,
                        isFav: !1,
                        catalogs: [],
                        documents: [],
                        isVip: !1,
                        loading: !0,
                        sortType: "created_at",
                        sortMethods: u
                    };
                },
                onShow: function() {
                    var t = this;
                    c.globalData.getUser().then(function(e) {
                        t.setData({
                            isVip: 1 == e.vip_state
                        }), i.default.get("favorites/".concat(s.FavType.Catalog, "/").concat(t.id)).then(function() {
                            t.setData({
                                isFav: !0
                            });
                        }, function() {
                            t.setData({
                                isFav: !1
                            });
                        });
                    }, function() {
                        t.setData({
                            isVip: !1
                        });
                    });
                },
                onLoad: function(t) {
                    var e = t.id, n = t.title;
                    this.id = e, this.title = decodeURIComponent(n), this.loadData();
                },
                onShareAppMessage: function() {
                    return {
                        title: "电工大师-资料列表",
                        path: "/pages/data/list?id=" + this.id + "&title=" + this.title
                    };
                },
                methods: {
                    sort: function(t) {
                        this.setData({
                            sortType: t.currentTarget.dataset.type
                        }), this.loadData();
                    },
                    loadData: function() {
                        var e = this;
                        t.showLoading({
                            title: "加载中"
                        }), i.default.get("catalogs/" + this.id + "?sort=" + this.sortType).then(function(n) {
                            var a = [], i = [];
                            n.data.forEach(function(t) {
                                var e = {
                                    id: t.id,
                                    name: t.title,
                                    isFav: t.is_favorite
                                };
                                1 == t.file_type ? a.push(e) : (Object.assign(e, {
                                    icon: s.TypeIcons[t.type] || s.TypeIcons[0],
                                    views: t.views,
                                    collects: t.collects
                                }), i.push(e));
                            }), e.setData({
                                catalogs: a,
                                documents: i
                            }), t.setNavigationBarTitle({
                                title: e.title
                            });
                        }, function(e) {
                            t.showModal({
                                title: "加载失败",
                                content: e.message,
                                showCancel: !1
                            });
                        }).finally(function() {
                            t.hideLoading(), e.setData({
                                loading: !1
                            });
                        });
                    },
                    openCatalog: function(e) {
                        t.navigateTo({
                            url: "/pages/data/list?id=" + e.id + "&title=" + encodeURIComponent(e.name)
                        });
                    },
                    openDoc: function(e) {
                        var n = "/pages/data/detail?id=" + e.id;
                        this.isVip ? t.navigateTo({
                            url: n
                        }) : (0, o.loginRequired)().then(function() {
                            return t.navigateTo({
                                url: n
                            });
                        }, function() {});
                    },
                    fav: function(e, n) {
                        (e.isFav ? (0, s.cancelFav)(n, e.id) : (0, s.addFav)(n, e.id)).then(function() {
                            e.isFav = !e.isFav, t.showToast({
                                title: e.isFav ? "已收藏成功" : "已取消收藏",
                                icon: "none"
                            });
                        }, function(e) {
                            t.showToast({
                                title: e.message,
                                icon: "none"
                            });
                        });
                    },
                    favCurrent: function() {
                        var e = this;
                        (0, o.loginRequired)().then(function() {
                            (e.isFav ? (0, s.cancelFav)(s.FavType.Catalog, e.id) : (0, s.addFav)(s.FavType.Catalog, e.id)).then(function() {
                                e.setData({
                                    isFav: !e.isFav
                                }, function() {
                                    t.showToast({
                                        title: e.isFav ? "已收藏成功" : "已取消收藏",
                                        icon: "none"
                                    });
                                });
                            }, function(e) {
                                t.showToast({
                                    title: e.message,
                                    icon: "none"
                                });
                            });
                        }, function() {});
                    }
                }
            };
            e.default = l;
        }).call(this, n("543d").default);
    },
    "4fc1": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("d9d8"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    afcb: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("42f2"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    },
    c4ef: function(t, e, n) {},
    ce9f: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            var t = (this._self._c, this.catalogs.length), e = this.documents.length, n = !this.loading && 0 == this.documents.length;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: e,
                    g2: n
                }
            });
        }, i = [];
    },
    d9d8: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("ce9f"), i = n("afcb");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("fa9e");
        var s = n("f0c5"), c = Object(s.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    },
    fa9e: function(t, e, n) {
        "use strict";
        var a = n("c4ef");
        n.n(a).a;
    }
}, [ [ "4fc1", "common/runtime", "common/vendor" ] ] ]);