(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/maximum-torque" ], {
    1674: function(t, e, n) {
        "use strict";
        (function(t) {
            var o = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = o(n("035c")), r = o(n("6b01")), u = o(n("3de9")), a = n("e308"), l = n("00cd"), s = n("fad4"), c = n("a896"), f = n("d417"), d = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ i.default, r.default, u.default ],
                data: function() {
                    return {
                        form: {
                            rpm: void 0
                        },
                        calculateOptions: [ {
                            label: "扭矩",
                            value: "torque"
                        }, {
                            label: "功率",
                            value: "power"
                        } ],
                        calculateOptionIndex: 0,
                        result: null
                    };
                },
                onLoad: function() {
                    this.powerUnits = [ this.powerAllUnits.W, this.powerAllUnits.kW, this.powerAllUnits.HP ], 
                    this.initFeature("motor_maximum_torque", a.FeatureType.Electromotor);
                },
                methods: {
                    changeType: function(t) {
                        this.calculateOptionIndex = parseInt(t.detail.value);
                    },
                    calculate: function() {
                        var e = this.calculateOptions[this.calculateOptionIndex].value, n = parseFloat(this.form.rpm), o = this.getPowerUnitValue(), i = this.getTorqueValue();
                        try {
                            if ("power" === e) {
                                if ((0, f.isVoidNumber)(this.form.rpm) || (0, f.isVoidNumber)(this.torqueUnitValue)) return void t.showModal({
                                    title: "注意！",
                                    content: "请输入所有参数",
                                    showCancel: !1
                                });
                                this.result = {
                                    power: (0, l.formatFromUnits)((0, c.calculatePower)(i, n), s.ActivePowerUnits.W, s.ActivePowerUnits)
                                };
                            } else {
                                if ((0, f.isVoidNumber)(this.powerUnitValue) || (0, f.isVoidNumber)(this.form.rpm)) return void t.showModal({
                                    title: "注意！",
                                    content: "请输入所有参数",
                                    showCancel: !1
                                });
                                var r = this.convertTorqueValue((0, c.calculateMaximumTorque)(o, n));
                                this.result = {
                                    N_M: (0, l.unitFormatTo)(r.N_M, this.torqueAllUnits.N_M, this.torqueAllUnits.N_M),
                                    KGF_M: (0, l.unitFormatTo)(r.KGF_M, this.torqueAllUnits.KGF_M, this.torqueAllUnits.KGF_M),
                                    FT_LBF: (0, l.unitFormatTo)(r.FT_LBF, this.torqueAllUnits.FT_LBF, this.torqueAllUnits.FT_LBF),
                                    IN_LBF: (0, l.unitFormatTo)(r.IN_LBF, this.torqueAllUnits.IN_LBF, this.torqueAllUnits.IN_LBF)
                                };
                            }
                            this.use();
                        } catch (e) {
                            this.result = null, t.showModal({
                                title: "注意！",
                                content: e.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            e.default = d;
        }).call(this, n("543d").default);
    },
    5996: function(t, e, n) {},
    "8c44": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("1674"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e.default = i.a;
    },
    9844: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    bd9c: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("9844"), i = n("8c44");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("e916");
        var u = n("f0c5"), a = Object(u.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = a.exports;
    },
    cfbb: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var i = o(n("bd9c"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    e916: function(t, e, n) {
        "use strict";
        var o = n("5996");
        n.n(o).a;
    }
}, [ [ "cfbb", "common/runtime", "common/vendor" ] ] ]);