(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/trifase-a-monofase" ], {
    "0544": function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("3de9")), r = o(n("f73d")), u = o(n("035c")), i = n("e308"), c = n("00cd"), l = n("a896"), s = n("d417"), f = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ u.default, a.default, r.default ],
                data: function() {
                    return {
                        form: {
                            frequency: void 0
                        },
                        result: ""
                    };
                },
                onLoad: function() {
                    this.powerUnits = [ this.powerAllUnits.kW, this.powerAllUnits.HP ], this.initFeature("motor_trifase_a_monofase", i.FeatureType.Electromotor);
                },
                methods: {
                    calculate: function() {
                        if ((0, s.isVoidNumber)(this.form.frequency) || (0, s.isVoidNumber)(this.powerUnitValue) || (0, 
                        s.isVoidNumber)(this.voltageUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t = {
                                motorPowerValue: this.getPowerUnitValue(),
                                frequency: this.form.frequency,
                                voltageValue: this.getVoltageUnitValue()
                            };
                            t.motorPowerValue >= 3e3 && e.showModal({
                                title: "注意！",
                                content: "电机功率过大，不能使用单相",
                                showCancel: !1
                            });
                            try {
                                this.result = (0, c.formatDouble)((0, l.calculateTrifaseAMonofasee)(t.motorPowerValue, t.voltageValue, t.frequency), 2), 
                                this.use();
                            } catch (t) {
                                this.result = "", e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            t.default = f;
        }).call(this, n("543d").default);
    },
    "30c6": function(e, t, n) {
        "use strict";
        var o = n("3184");
        n.n(o).a;
    },
    3184: function(e, t, n) {},
    3764: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("ea82"), a = n("839f");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("30c6");
        var u = n("f0c5"), i = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    },
    "839f": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("0544"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    "9ac0": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var a = o(n("3764"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    ea82: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    }
}, [ [ "9ac0", "common/runtime", "common/vendor" ] ] ]);