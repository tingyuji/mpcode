(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/motore-monofase" ], {
    1318: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = o(n("3de9")), a = o(n("f73d")), i = o(n("6b01")), u = o(n("035c")), c = n("e308"), l = n("00cd"), f = n("a896"), s = n("d417"), d = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ u.default, r.default, a.default, i.default ],
                data: function() {
                    return {
                        form: {
                            frequency: void 0
                        },
                        result: ""
                    };
                },
                onLoad: function() {
                    this.powerUnits = [ this.powerAllUnits.W, this.powerAllUnits.kW, this.powerAllUnits.HP ], 
                    this.powerUnitIndex = 1, this.initFeature("motor_motore_monofase", c.FeatureType.Electromotor);
                },
                methods: {
                    calculate: function() {
                        if ((0, s.isVoidNumber)(this.form.frequency) || (0, s.isVoidNumber)(this.powerUnitValue) || (0, 
                        s.isVoidNumber)(this.voltageUnitValue) || (0, s.isVoidNumber)(this.efficiency)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t = {
                                motorPowerValue: this.getPowerUnitValue(),
                                frequency: this.form.frequency,
                                voltageValue: this.getVoltageUnitValue(),
                                efficiencyValue: this.getEfficiencyValue()
                            };
                            try {
                                this.result = (0, l.formatDouble)((0, f.calculateMotoreMonofasee)(t.motorPowerValue, t.voltageValue, t.frequency, t.efficiencyValue), 2), 
                                this.use();
                            } catch (t) {
                                this.result = "", e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            t.default = d;
        }).call(this, n("543d").default);
    },
    "6e66": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("1318"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    9095: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var r = o(n("e7c1"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "916e": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, a = [];
    },
    "9e32": function(e, t, n) {
        "use strict";
        var o = n("aab4");
        n.n(o).a;
    },
    aab4: function(e, t, n) {},
    e7c1: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("916e"), r = n("6e66");
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        n("9e32");
        var i = n("f0c5"), u = Object(i.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    }
}, [ [ "9095", "common/runtime", "common/vendor" ] ] ]);