(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/slippage-rate" ], {
    "31f9": function(e, t, n) {
        "use strict";
        var o = n("bfce");
        n.n(o).a;
    },
    "34dd": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("4fe2"), a = n("d029");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("31f9");
        var i = n("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "4fe2": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    "549d": function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("035c")), r = n("e308"), i = n("00cd"), u = n("a896"), c = n("d417"), l = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ a.default ],
                data: function() {
                    return {
                        form: {
                            magnetic: void 0,
                            rotor: void 0
                        },
                        result: null
                    };
                },
                onLoad: function() {
                    this.initFeature("motor_slippage_rate", r.FeatureType.Electromotor);
                },
                methods: {
                    calculate: function() {
                        if ((0, c.isVoidNumber)(this.form.magnetic) || (0, c.isVoidNumber)(this.form.rotor)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t = parseFloat(this.form.magnetic), n = parseFloat(this.form.rotor);
                            try {
                                this.result = {
                                    slippage: (0, i.formatDouble)((0, u.calculateSlippage)(t, n), 2),
                                    slippageRate: (0, i.formatDouble)((0, u.calculateSlippageRate)(t, n), 2)
                                }, this.use();
                            } catch (t) {
                                this.result = null, e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    bae1: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var a = o(n("34dd"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    bfce: function(e, t, n) {},
    d029: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("549d"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    }
}, [ [ "bae1", "common/runtime", "common/vendor" ] ] ]);