(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/efficiency" ], {
    "1a38": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var r = n("4ea4");
            n("8a42"), r(n("66fd"));
            var i = r(n("a056"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "2f43": function(e, t, n) {},
    "864e": function(e, t, n) {
        "use strict";
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = r(n("035c")), o = r(n("f73d")), a = r(n("3de9")), u = r(n("ed61")), l = r(n("6b01")), c = n("e308"), s = n("2c16"), f = n("00cd"), d = n("fad4"), h = n("d417"), m = n("a896"), p = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ i.default, o.default, a.default, u.default, l.default ],
                data: function() {
                    return {
                        result: ""
                    };
                },
                onLoad: function() {
                    this.powerUnits = [ this.powerAllUnits.W, this.powerAllUnits.kW, this.powerAllUnits.HP ], 
                    this.initFeature("motor_efficiency", c.FeatureType.Electromotor);
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        if ((0, h.isVoidNumber)(this.voltageUnitValue) || (0, h.isVoidNumber)(this.powerUnitValue) || (0, 
                        h.isVoidNumber)(this.currentUnitValue) || (0, h.isVoidNumber)(this.trigonometricTypeValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: d.InputTerminal.VOLTAGE_CURRENT,
                                voltageValue: this.getVoltageUnitValue(),
                                currentValue: this.getCurrentUnitValue(),
                                motorPowerValue: this.getPowerUnitValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, s.calculate)(t), r = (0, m.calculateEfficiency)(n, t.motorPowerValue);
                            this.result = (0, f.formatDouble)(r, 2) + " %", this.use();
                        } catch (t) {
                            this.result = "", e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    a056: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("bc93"), i = n("f567");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        n("f34d");
        var a = n("f0c5"), u = Object(a.a)(i.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = u.exports;
    },
    bc93: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, i = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    f34d: function(e, t, n) {
        "use strict";
        var r = n("2f43");
        n.n(r).a;
    },
    f567: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("864e"), i = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = i.a;
    }
}, [ [ "1a38", "common/runtime", "common/vendor" ] ] ]);