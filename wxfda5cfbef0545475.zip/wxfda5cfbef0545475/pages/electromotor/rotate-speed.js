(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/rotate-speed" ], {
    b1af: function(e, t, n) {
        "use strict";
        var o = n("b8e6");
        n.n(o).a;
    },
    b2b5: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("035c")), r = n("e308"), i = n("00cd"), u = n("a896"), c = n("d417"), l = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ a.default ],
                data: function() {
                    return {
                        form: {
                            poles: void 0,
                            frequency: 50,
                            slippageRate: void 0
                        },
                        slippageRateOptions: [ {
                            label: "[0-1]",
                            type: "number"
                        }, {
                            label: "%",
                            type: "rate"
                        } ],
                        slippageRateOptionIndex: 0,
                        result: null
                    };
                },
                onLoad: function() {
                    this.initFeature("motor_rotate_speed", r.FeatureType.Electromotor);
                },
                methods: {
                    calculate: function() {
                        if ((0, c.isVoidNumber)(this.form.poles) || (0, c.isVoidNumber)(this.form.frequency) || (0, 
                        c.isVoidNumber)(this.form.slippageRate)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var t = parseFloat(this.form.poles), n = parseFloat(this.form.frequency), o = parseFloat(this.form.slippageRate);
                            "rate" === this.slippageRateOptions[this.slippageRateOptionIndex].type && (o /= 100);
                            try {
                                this.result = {
                                    magneticSpeed: (0, i.formatDouble)((0, u.calculateMagneticSpeed)(n, t), 2),
                                    rotorSpeed: (0, i.formatDouble)((0, u.calculateRotorSpeed)(n, t, o), 2)
                                }, this.use();
                            } catch (t) {
                                this.result = null, e.showModal({
                                    title: "注意！",
                                    content: t.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    b8e6: function(e, t, n) {},
    bc62: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("b2b5"), a = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = a.a;
    },
    c2b6: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, a = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    eafd: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var a = o(n("f23c"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    f23c: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("c2b6"), a = n("bc62");
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        n("b1af");
        var i = n("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    }
}, [ [ "eafd", "common/runtime", "common/vendor" ] ] ]);