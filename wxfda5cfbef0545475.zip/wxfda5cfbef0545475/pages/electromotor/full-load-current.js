(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/full-load-current" ], {
    "0c18": function(e, l, a) {
        "use strict";
        a.r(l);
        var t = a("22aa"), u = a("f107");
        for (var n in u) [ "default" ].indexOf(n) < 0 && function(e) {
            a.d(l, e, function() {
                return u[e];
            });
        }(n);
        var r = a("f0c5"), o = Object(r.a)(u.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        l.default = o.exports;
    },
    "22aa": function(e, l, a) {
        "use strict";
        a.d(l, "b", function() {
            return u;
        }), a.d(l, "c", function() {
            return n;
        }), a.d(l, "a", function() {
            return t;
        });
        var t = {
            featureBar: function() {
                return Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(a.bind(null, "e526"));
            }
        }, u = function() {
            this.$createElement, this._self._c;
        }, n = [];
    },
    ecda: function(e, l, a) {
        "use strict";
        (function(e, l) {
            var t = a("4ea4");
            a("8a42"), t(a("66fd"));
            var u = t(a("0c18"));
            e.__webpack_require_UNI_MP_PLUGIN__ = a, l(u.default);
        }).call(this, a("bc2e").default, a("543d").createPage);
    },
    f107: function(e, l, a) {
        "use strict";
        a.r(l);
        var t = a("f316"), u = a.n(t);
        for (var n in t) [ "default" ].indexOf(n) < 0 && function(e) {
            a.d(l, e, function() {
                return t[e];
            });
        }(n);
        l.default = u.a;
    },
    f316: function(e, l, a) {
        "use strict";
        (function(e) {
            var t = a("4ea4");
            Object.defineProperty(l, "__esModule", {
                value: !0
            }), l.default = void 0;
            var u = t(a("035c")), n = t(a("f73d")), r = a("e308"), o = a("d055"), i = a("00cd"), v = a("d417"), c = a("a896"), s = [ {
                label: "1/4 HP - 0.186 kW",
                value: 384
            }, {
                label: "1/3 HP - 0.246 kW",
                value: 480
            }, {
                label: "1/2 HP - 0.373 kW",
                value: 648
            }, {
                label: "3/4 HP - 0.559 kW",
                value: 912
            }, {
                label: "1 HP - 0.746 kW",
                value: 1128
            }, {
                label: "1 1/2 HP - 1.12 kW",
                value: 1584
            }, {
                label: "2 HP - 1.49 kW",
                value: 2040
            }, {
                label: "3 HP - 2.24 kW",
                value: 2928
            }, {
                label: "5 HP - 3.73 kW",
                value: 4800
            }, {
                label: "7 1/2 HP - 5.59 kW",
                value: 6960
            }, {
                label: "10 HP - 7.46 kW",
                value: 9120
            }, {
                label: "15 HP - 11.19 kW",
                value: 13200
            }, {
                label: "20 HP - 14.91 kW",
                value: 17280
            }, {
                label: "25 HP - 18.64 kW",
                value: 21360
            }, {
                label: "30 HP - 22.37 kW",
                value: 25440
            }, {
                label: "40 HP - 29.83 kW",
                value: 33600
            }, {
                label: "50 HP - 37.28 kW",
                value: 41520
            }, {
                label: "60 HP - 44.74 kW",
                value: 49440
            }, {
                label: "75 HP - 55.93 kW",
                value: 61200
            }, {
                label: "100 HP - 74.57 kW",
                value: 81840
            }, {
                label: "125 HP - 93.21 kW",
                value: 102e3
            }, {
                label: "150 HP - 111.85 kW",
                value: 121440
            }, {
                label: "200 HP - 149.14 kW",
                value: 162e3
            } ], b = [ {
                label: "1/6 HP - 0.119 kW",
                value: 506
            }, {
                label: "1/4 HP - 0.186 kW",
                value: 667
            }, {
                label: "1/3 HP - 0.246 kW",
                value: 828
            }, {
                label: "1/2 HP - 0.373 kW",
                value: 1127
            }, {
                label: "3/4 HP - 0.559 kW",
                value: 1587
            }, {
                label: "1 HP - 0.746 kW",
                value: 1840
            }, {
                label: "1 1/2 HP - 1.12 kW",
                value: 2300
            }, {
                label: "2 HP - 1.49 kW",
                value: 2760
            }, {
                label: "3 HP - 2.24 kW",
                value: 3910
            }, {
                label: "5 HP - 3.73 kW",
                value: 6440
            }, {
                label: "7 1/2 HP - 5.59 kW",
                value: 9200
            }, {
                label: "10 HP - 7.46 kW",
                value: 11500
            } ], P = [ {
                label: "1/2 HP - 0.373 kW",
                value: 517.5
            }, {
                label: "3/4 HP - 0.559 kW",
                value: 747.5
            }, {
                label: "1 HP - 0.746 kW",
                value: 977.5
            }, {
                label: "1 1/2 HP - 1.12 kW",
                value: 1380
            }, {
                label: "2 HP - 1.49 kW",
                value: 1552.5
            }, {
                label: "3 HP - 2.24 kW",
                value: 2242.5
            }, {
                label: "5 HP - 3.73 kW",
                value: 3507.5
            }, {
                label: "7 1/2 HP - 5.59 kW",
                value: 5175
            }, {
                label: "10 HP - 7.46 kW",
                value: 6325
            }, {
                label: "15 HP - 11.19 kW",
                value: 9775
            }, {
                label: "20 HP - 14.91 kW",
                value: 12650
            }, {
                label: "25 HP - 18.64 kW",
                value: 15525
            }, {
                label: "30 HP - 22.37 kW",
                value: 18400
            }, {
                label: "40 HP - 29.83 kW",
                value: 23575
            }, {
                label: "50 HP - 37.28 kW",
                value: 29900
            }, {
                label: "60 HP - 44.74 kW",
                value: 35650
            }, {
                label: "75 HP - 55.93 kW",
                value: 44275
            }, {
                label: "100 HP - 74.57 kW",
                value: 56925
            }, {
                label: "125 HP - 93.21 kW",
                value: 71875
            }, {
                label: "150 HP - 111.85 kW",
                value: 82800
            }, {
                label: "200 HP - 149.14 kW",
                value: 110400
            }, {
                label: "250 HP - 186.42 kW",
                value: 139150
            }, {
                label: "300 HP - 223.71 kW",
                value: 166175
            }, {
                label: "350 HP - 260.99 kW",
                value: 193200
            }, {
                label: "400 HP - 298.28 kW",
                value: 219650
            }, {
                label: "450 HP - 335.56 kW",
                value: 236900
            }, {
                label: "500 HP - 372.85 kW",
                value: 271400
            } ], k = {
                components: {
                    featureBar: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(a("e526"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    vipMask: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/vip/vip") ]).then(function() {
                            return resolve(a("e665"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                mixins: [ u.default, n.default ],
                data: function() {
                    return {
                        powerOptions: [],
                        powerOptionIndex: 0,
                        result: ""
                    };
                },
                onLoad: function() {
                    this.setCurrentType("general"), this.currentTypeIndex = 1, this.changePowerOptions(), 
                    this.initFeature("motor_full_load_current", r.FeatureType.Electromotor);
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value), this.changePowerOptions();
                    },
                    changePowerOptions: function() {
                        var e, l = null === (e = this.powerOptions[this.powerOptionIndex]) || void 0 === e ? void 0 : e.label;
                        switch (this.currentType[this.currentTypeIndex].option) {
                          case o.CurrentType.DIRECT_CURRENT:
                            this.powerOptions = s;
                            break;

                          case o.CurrentType.SINGLE_PHASE_CURRENT:
                            this.powerOptions = b;
                            break;

                          case o.CurrentType.THREE_PHASE_CURRENT:
                            this.powerOptions = P;
                        }
                        var a = 0;
                        l && (a = this.powerOptions.findIndex(function(e) {
                            return e.label === l;
                        })), this.powerOptionIndex = -1 !== a ? a : 0;
                    },
                    calculate: function() {
                        if ((0, v.isVoidNumber)(this.voltageUnitValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else {
                            var l = this.getVoltageUnitValue(), a = this.powerOptions[this.powerOptionIndex].value;
                            try {
                                this.result = (0, i.unitFormatTo)((0, c.calculateFullLoadCurrent)(l, a), o.CurrentUnits.A, o.CurrentUnits.A), 
                                this.use();
                            } catch (l) {
                                this.result = null, e.showModal({
                                    title: "注意！",
                                    content: l.message,
                                    showCancel: !1
                                });
                            }
                        }
                    }
                }
            };
            l.default = k;
        }).call(this, a("543d").default);
    }
}, [ [ "ecda", "common/runtime", "common/vendor" ] ] ]);