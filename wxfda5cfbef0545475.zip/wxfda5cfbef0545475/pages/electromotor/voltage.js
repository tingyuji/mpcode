(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/electromotor/voltage" ], {
    "16e8": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n("4ea4");
            n("8a42"), i(n("66fd"));
            var r = i(n("a9c4"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "627a": function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return i;
        });
        var i = {
            featureBar: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(n.bind(null, "e526"));
            }
        }, r = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    7509: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(n("035c")), o = i(n("f73d")), a = i(n("3de9")), l = i(n("ed61")), u = i(n("6b01")), c = n("e308"), s = n("0db1"), f = n("00cd"), d = n("fad4"), h = n("d417"), p = n("a896"), m = {
                components: {
                    featureBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/feature-bar/feature-bar") ]).then(function() {
                            return resolve(n("e526"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    vipMask: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/vip/vip") ]).then(function() {
                            return resolve(n("e665"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                mixins: [ r.default, o.default, a.default, l.default, u.default ],
                data: function() {
                    return {
                        result: ""
                    };
                },
                onLoad: function() {
                    this.powerUnits = [ this.powerAllUnits.W, this.powerAllUnits.kW, this.powerAllUnits.HP, this.powerAllUnits.VA, this.powerAllUnits.kVA, this.powerAllUnits.VAr, this.powerAllUnits.kVAr ], 
                    this.initFeature("motor_voltage", c.FeatureType.Electromotor);
                },
                methods: {
                    changeCurrentType: function(e) {
                        this.currentTypeIndex = parseInt(e.detail.value), this.setTrigonometricTypeValue(this.getCurrentType());
                    },
                    calculate: function() {
                        if ((0, h.isVoidNumber)(this.currentUnitValue) || (0, h.isVoidNumber)(this.powerUnitValue) || (0, 
                        h.isVoidNumber)(this.efficiency) || (0, h.isVoidNumber)(this.trigonometricTypeValue)) e.showModal({
                            title: "注意！",
                            content: "请输入所有参数",
                            showCancel: !1
                        }); else try {
                            var t = {
                                currentType: this.getCurrentType(),
                                inputTerminal: s.InputTerminal.CURRENT_POWER,
                                currentValue: this.getCurrentUnitValue(),
                                powerValue: this.getPowerUnitValue(),
                                powerType: (0, d.toPowerType)(this.powerUnits[this.powerUnitIndex].name),
                                efficiencyValue: this.getEfficiencyValue(),
                                triangleCollection: this.getTriangleCollection()
                            }, n = (0, s.calculate)(t);
                            n = (0, p.calculateVoltage)(n, t.efficiencyValue), this.result = (0, f.formatFromUnits)(n, s.VoltageUnits.V, s.VoltageUnits), 
                            this.use();
                        } catch (t) {
                            this.result = "", e.showModal({
                                title: "注意！",
                                content: t.message,
                                showCancel: !1
                            });
                        }
                    }
                }
            };
            t.default = m;
        }).call(this, n("543d").default);
    },
    "829c": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("7509"), r = n.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(o);
        t.default = r.a;
    },
    a9c4: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("627a"), r = n("829c");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        var a = n("f0c5"), l = Object(a.a)(r.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = l.exports;
    }
}, [ [ "16e8", "common/runtime", "common/vendor" ] ] ]);