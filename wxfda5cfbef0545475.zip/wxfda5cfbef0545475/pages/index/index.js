(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "2e09": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("5d8e"), o = n.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(r);
        t.default = o.a;
    },
    "3e72": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("bb3c"), o = n("2e09");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("56e7");
        var i = n("f0c5"), c = Object(i.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    "48ae": function(e, t, n) {},
    "56e7": function(e, t, n) {
        "use strict";
        var a = n("48ae");
        n.n(a).a;
    },
    "5d8e": function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n("e308"), r = n("3bc8"), i = a(n("1733")), c = a(n("b253")), s = n("963d"), u = n("a195"), l = (getApp(), 
            {
                components: {
                    navItem: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/nav-item/nav-item") ]).then(function() {
                            return resolve(n("231d"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    comp: function() {
                        n.e("components/tabpage-common/index").then(function() {
                            return resolve(n("caaa"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        navHeight: "",
                        searchHeight: "",
                        featureType: o.FeatureType,
                        calculates: [],
                        converters: [],
                        electromotors: [],
                        currentIndex: 0,
                        winWidth: 0,
                        winHeight: 0,
                        currentTab: 0,
                        navTop: "",
                        favoritesList: [],
                        heightTop: "",
                        toolsClose: !1,
                        isTouTiao: !1,
                        imgBaseUrl: s.staticExamUrl,
                        banner: []
                    };
                },
                mixins: [ i.default ],
                onLoad: function(t) {
                    if (t.ref) {
                        var n = decodeURIComponent(t.ref);
                        e.setStorageSync("ref", n), console.log("分享的携带的链接信息", t.ref);
                    }
                    if (t.scene) {
                        var a = decodeURIComponent(t.scene);
                        console.log("获取二维码的携带的链接信息", a), e.setStorage({
                            key: "ref",
                            data: a
                        });
                    }
                    if (t.q) {
                        console.log("普通二维码链接", t.q);
                        var o = decodeURIComponent(t.q);
                        o = this.getQueryParams(o), console.log("普通二维码链接解析的参数", o), o.ref && e.setStorage({
                            key: "ref",
                            data: o.ref
                        });
                    }
                    this.getBanner();
                },
                onShow: function() {
                    var t = this, n = this;
                    e.getSystemInfo({
                        success: function(e) {
                            n.setData({
                                winWidth: e.windowWidth,
                                winHeight: e.windowHeight
                            });
                        }
                    }), this.fixLayout();
                    var a = function(n, a, r) {
                        r().then(function(e) {
                            if (e) {
                                switch (n.forEach(function(t) {
                                    t.key && e[t.key] ? t.requirement = e[t.key].requirement : t.requirement = 0;
                                }), n.forEach(function(e) {
                                    !t.favoritesList.some(function(t, n) {
                                        if (t.name == e.name) return e.sort = n, !0;
                                    }) && (e.sort = 999);
                                }), t.favoritesList.length && (n = n.sort(function(e, t) {
                                    return e.sort - t.sort;
                                })), a) {
                                  case o.FeatureType.Calculate:
                                    t.calculates = n;
                                    break;

                                  case o.FeatureType.Converter:
                                    t.converters = n;
                                    break;

                                  case o.FeatureType.Electromotor:
                                    t.electromotors = n;
                                }
                                t.$forceUpdate;
                            }
                        }, function(t) {
                            e.showToast({
                                title: t.message
                            });
                        });
                    };
                    this.favoritesListData().then(function(e) {
                        a(r.calculates, o.FeatureType.Calculate, o.getCalcFeatures), a(r.converters, o.FeatureType.Converter, o.getConvertFeatures), 
                        a(r.electromotors, o.FeatureType.Electromotor, o.getElectromotorFeatures);
                    }), this.closeTools();
                },
                onShareAppMessage: function() {
                    return {
                        title: "电工大师-计算器",
                        path: "/pages/index/index"
                    };
                },
                methods: {
                    openFeatureUrl: function(e, t) {
                        var n = null;
                        switch (t) {
                          case o.FeatureType.Calculate:
                            n = this.calculates[e.currentTarget.dataset.index];
                            break;

                          case o.FeatureType.Converter:
                            n = this.converters[e.currentTarget.dataset.index];
                            break;

                          case o.FeatureType.Electromotor:
                            n = this.electromotors[e.currentTarget.dataset.index];
                        }
                        (0, o.openFeature)(n);
                    },
                    openSearchUrl: function(t) {
                        e.navigateTo({
                            url: "/pages/search/search"
                        });
                    },
                    changeIndex: function(e) {
                        this.setData({
                            currentIndex: e.currentTarget.dataset.index
                        });
                    },
                    getQueryParams: function(e) {
                        var t = new Object();
                        if (-1 != e.indexOf("?")) for (var n = (e = e.slice(e.indexOf("?") + 1)).split("&"), a = 0; a < n.length; a++) t[n[a].split("=")[0]] = decodeURIComponent(n[a].split("=")[1]);
                        return t;
                    },
                    fixLayout: function() {
                        var t = this, n = e.getMenuButtonBoundingClientRect();
                        n ? e.getSystemInfo({
                            success: function(e) {
                                var a = e.statusBarHeight, o = n.top, r = a + n.height + 2 * (n.top - a);
                                console.log(r), t.setData({
                                    navTop: o,
                                    searchHeight: n.height,
                                    navHeight: r
                                }), t.isTouTiao && (t.navHeight = 60);
                            }
                        }) : e.getSystemInfo({
                            success: function(e) {
                                t.heightTop = "margin-top: " + 1.2 * e.statusBarHeight + "rpx;";
                                var n = e.statusBarHeight, a = n + 35 + 2 * (35 - n);
                                console.log(a), t.setData({
                                    navTop: 35,
                                    searchHeight: 35,
                                    navHeight: a
                                }), t.isTouTiao && (t.navHeight = 60);
                            }
                        });
                    },
                    swichNav: function(e) {
                        if (this.currentTab === e.target.dataset.current) return !1;
                        this.setData({
                            currentTab: e.target.dataset.current
                        });
                    },
                    bindChange: function(e) {
                        this.setData({
                            currentTab: e.detail.current
                        });
                    },
                    favoritesListData: function() {
                        var e = this;
                        return new Promise(function(t, n) {
                            c.default.get("favorites", {
                                resource_type: "1"
                            }).then(function(n) {
                                e.favoritesList = n.data, t();
                            }, function() {
                                t();
                            });
                        });
                    },
                    closeTools: function() {
                        var e = this;
                        setTimeout(function() {
                            e.toolsClose = !0;
                        }, 5e3);
                    },
                    goTools: function() {
                        e.navigateTo({
                            url: "/pages/tools/index"
                        });
                    },
                    getBanner: function() {
                        var t = this;
                        e.showLoading(), c.default.get("banner").then(function(n) {
                            e.hideLoading(), t.banner = n.data;
                        }, function(t) {
                            e.hideLoading(), e.showModal({
                                content: t.message,
                                showCancel: !1
                            });
                        });
                    },
                    static: function(t) {
                        c.default.post("banner-static", {
                            banner_id: t
                        }).then(function(e) {}, function(t) {
                            e.showModal({
                                content: t.message,
                                showCancel: !1
                            });
                        });
                    },
                    navigate: function(t) {
                        console.log(t), this.static(t.id);
                        var n = t.page.match(/wxapp:\/\/(.*)/), a = t.page.match(/(http|https):\/\/(\S+)/g);
                        if (console.log(n, 1), console.log(a, 2), n) {
                            var o = n[1].match(/^([^\/]+)\/(.*)$/);
                            o ? e.navigateToMiniProgram({
                                appId: o[1],
                                path: o[2],
                                success: function(e) {
                                    console.log(e);
                                }
                            }) : e.showModal({
                                content: "链接错误",
                                showCancel: !1
                            });
                        } else a ? (0, u.openWebView)(a[0]) : e.navigateTo({
                            url: t.page
                        });
                    }
                }
            });
            t.default = l;
        }).call(this, n("543d").default);
    },
    bb3c: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return a;
        });
        var a = {
            navItem: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/nav-item/nav-item") ]).then(n.bind(null, "231d"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, r = [];
    },
    eb0c: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var o = a(n("3e72"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "eb0c", "common/runtime", "common/vendor" ] ] ]);