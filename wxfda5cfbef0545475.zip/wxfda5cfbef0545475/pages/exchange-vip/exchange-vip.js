(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/exchange-vip/exchange-vip" ], {
    "17ac": function(t, e, n) {},
    "361d": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("d9b1"), a = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e.default = a.a;
    },
    "5fc4": function(t, e, n) {
        "use strict";
        (function(t, e) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var a = o(n("73fc"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(a.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    "73fc": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("b4e3"), a = n("361d");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(c);
        n("b043");
        var i = n("f0c5"), s = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = s.exports;
    },
    b043: function(t, e, n) {
        "use strict";
        var o = n("17ac");
        n.n(o).a;
    },
    b4e3: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            var t = (this._self._c, this.codeList.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, a = [];
    },
    d9b1: function(t, e, n) {
        "use strict";
        (function(t) {
            var o = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = o(n("b253")), c = (n("9673"), getApp()), i = {
                data: function() {
                    return {
                        code: "",
                        codeList: []
                    };
                },
                onLoad: function() {
                    this.getClipboardCode(), this.initCodelist();
                },
                methods: {
                    getClipboardCode: function() {
                        var e = this;
                        t.getClipboardData({
                            success: function(t) {
                                var n = t.data.match(/[A-Za-z0-9]{18}/g);
                                n ? e.setData({
                                    code: n[0]
                                }) : e.setData({
                                    code: null
                                });
                            },
                            fail: function(t) {
                                console.log(t);
                            }
                        });
                    },
                    initCodelist: function() {
                        var t = this;
                        a.default.get("conversionCode/index").then(function(e) {
                            t.codeList = e.data, console.log(t.codeList);
                        }, function(t) {
                            console.error(t);
                        });
                    },
                    activation: function(t) {
                        var e = t.currentTarget.dataset.code;
                        console.log(e), this.setData({
                            code: e.redemption_code
                        }), this.exchange();
                    },
                    inputCode: function(t) {
                        this.setData({
                            code: t.detail.value
                        });
                    },
                    exchange: function() {
                        this.code ? this.doExchange() : t.showModal({
                            content: "请输入兑换码",
                            showCancel: !1
                        });
                    },
                    doExchange: function() {
                        var e = this;
                        t.showLoading({
                            mask: !0,
                            title: "兑换中"
                        }), a.default.post("codeDetails", {
                            code: this.code.trim()
                        }).then(function(n) {
                            t.hideLoading(), n = n.data, t.showModal({
                                title: "温馨提示",
                                content: "您输入的兑换码可兑换" + n.vip_expire + "VIP会员，是否确认兑换？",
                                showCancel: !0,
                                confirmText: "确认兑换",
                                success: function(n) {
                                    n.confirm && (t.showLoading({
                                        title: "兑换中"
                                    }), a.default.post("exchangeVip", {
                                        code: e.code
                                    }).then(function(e) {
                                        t.hideLoading(), c.globalData.trigger("vip-updated"), t.showToast({
                                            title: "VIP会员兑换成功",
                                            icon: "success",
                                            duration: 5e3
                                        }), setTimeout(function() {
                                            t.navigateBack();
                                        }, 5e3);
                                    }).catch(function(e) {
                                        t.hideLoading(), t.showModal({
                                            title: "温馨提示",
                                            content: e.message,
                                            showCancel: !1,
                                            confirmText: "我知道了"
                                        });
                                    }));
                                }
                            });
                        }).catch(function(e) {
                            t.hideLoading(), t.showModal({
                                title: "温馨提示",
                                content: e.message,
                                showCancel: !1,
                                confirmText: "我知道了"
                            });
                        });
                    },
                    paste: function() {
                        var e = this;
                        t.getClipboardData({
                            success: function(t) {
                                var n = t.data;
                                console.log(n);
                                var o = n.match(/[A-Za-z0-9]{18}/g);
                                console.log(o), o ? e.setData({
                                    code: o[0]
                                }) : e.setData({
                                    code: null
                                });
                            },
                            fail: function(t) {
                                console.log(t);
                            }
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, n("543d").default);
    }
}, [ [ "5fc4", "common/runtime", "common/vendor" ] ] ]);