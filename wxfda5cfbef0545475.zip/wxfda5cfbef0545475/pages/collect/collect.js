(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/collect/collect" ], {
    "4dde": function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = o(n("ac2e")), a = o(n("1733")), u = n("9673"), i = o(n("b253")), l = n("e308"), r = n("628d"), s = (n("d417"), 
            getApp()), d = 1, f = 2, g = {
                components: {
                    noData: function() {
                        n.e("components/no-data/no-data").then(function() {
                            return resolve(n("d21c"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    navItem: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/nav-item/nav-item") ]).then(function() {
                            return resolve(n("231d"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    comp: function() {
                        n.e("components/tabpage-common/index").then(function() {
                            return resolve(n("caaa"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        navHeight: "",
                        searchHeight: "",
                        currentIndex: 0,
                        recentlyUsedItems: [],
                        toolsItems: [],
                        documentItems: [],
                        user: {
                            vip_state: 0
                        }
                    };
                },
                mixins: [ c.default, a.default ],
                onLoad: function() {
                    var e = this;
                    this.getRecentlyUsedItems(), (0, u.getUser)().then(function() {
                        e.getCollectList(d), e.getCollectList(f);
                    }, function() {}), s.globalData.on("fav-updated", function(t) {
                        setTimeout(function() {
                            1 == t.type ? e.getCollectList(d) : e.getCollectList(f);
                        }, 500);
                    }, "collect"), s.globalData.on("login-status-changed", function() {
                        setTimeout(function() {
                            e.getCollectList(d), e.getCollectList(f);
                        }, 300);
                    }, "collect"), s.globalData.on("recent-used-updated", function() {
                        setTimeout(e.getRecentlyUsedItems, 200);
                    }, "collect");
                },
                onUnload: function() {
                    s.globalData.off("fav-updated", "collect"), s.globalData.off("login-status-changed", "collect"), 
                    s.globalData.off("recent-used-updated", "collect");
                },
                methods: {
                    changeIndex: function(e) {
                        this.setData({
                            currentIndex: e.currentTarget.dataset.index
                        });
                    },
                    login: function() {
                        (0, u.loginRequired)().silent();
                    },
                    getRecentlyUsedItems: function() {
                        var e = this;
                        (0, r.getRecentUsed)().then(function(t) {
                            var n = [], o = {};
                            console.log(t), t.forEach(function(e, t) {
                                if (e.hasOwnProperty("name")) {
                                    var c = e.uniq.split("_");
                                    "feature" == c[0] ? (e.type = "calc", e.id = c[2]) : (e.type = "doc", e.id = c[1], 
                                    o[e.id] = t, e.views = 0, e.collects = 0), n.push(e);
                                }
                            }), Object.keys(o).length > 0 ? i.default.get("documents?document_ids=" + Object.keys(o).join(",")).then(function(t) {
                                t.data.forEach(function(e) {
                                    var t = n[o[e.id]];
                                    t.views = e.views, t.collects = e.collects;
                                }), e.setData({
                                    recentlyUsedItems: n
                                });
                            }, function() {
                                e.setData({
                                    recentlyUsedItems: n
                                });
                            }) : e.setData({
                                recentlyUsedItems: n
                            });
                        });
                    },
                    getCollectList: function(e) {
                        var t = this;
                        return 2 == e && (e = "2,3"), i.default.get("favorites", {
                            resource_type: e
                        }).then(function(n) {
                            var o = n.data;
                            switch (o.forEach(function(t) {
                                switch (e) {
                                  case 1:
                                    var n = (0, l.getFeatureConfig)(t.key, t.type);
                                    t.icon = n.icon, t.url = "/pages/" + n.page;
                                    break;

                                  case "2,3":
                                    t.url = "/pages/data/detail?id=" + t.id, t.icon = r.TypeIcons[t.type] || r.TypeIcons[0], 
                                    t.views = 0, t.collects = 0;
                                }
                            }), e) {
                              case 1:
                                t.setData({
                                    toolsItems: o
                                });
                                break;

                              case "2,3":
                                var c = {};
                                o.forEach(function(e, t) {
                                    c[e.id] = t;
                                }), o.length > 0 && i.default.get("documents?document_ids=" + Object.keys(c).join(",")).then(function(e) {
                                    e.data.forEach(function(e) {
                                        var t = o[c[e.id]];
                                        t.views = e.views, t.collects = e.collects;
                                    }), t.setData({
                                        documentItems: o
                                    });
                                }, function() {
                                    t.setData({
                                        documentItems: o
                                    });
                                });
                            }
                        }).catch(function(e) {
                            console.log(e);
                        });
                    },
                    openRecent: function(t) {
                        console.log(t), 2 == t.requirement ? (0, u.loginRequired)().then(function() {
                            return e.navigateTo({
                                url: t.url
                            });
                        }, function() {}) : e.navigateTo({
                            url: t.url
                        });
                    },
                    openCalc: function(t) {
                        var n = this.toolsItems[t.currentTarget.dataset.index];
                        2 == n.requirement ? (0, u.loginRequired)().then(function() {
                            return e.navigateTo({
                                url: n.url
                            });
                        }, function() {}) : e.navigateTo({
                            url: n.url
                        });
                    },
                    openDoc: function(t) {
                        console.log(t);
                        var n = this.documentItems[t.currentTarget.dataset.index];
                        2 == n.requirement ? (0, u.loginRequired)().then(function() {
                            return e.navigateTo({
                                url: n.url
                            });
                        }, function() {}) : 4 == n.type ? e.navigateTo({
                            url: "/pages/data/list?id=" + n.id + "&title=" + n.name
                        }) : e.navigateTo({
                            url: n.url
                        });
                    }
                }
            };
            t.default = g;
        }).call(this, n("543d").default);
    },
    5302: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return c;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            noData: function() {
                return n.e("components/no-data/no-data").then(n.bind(null, "d21c"));
            }
        }, c = function() {
            var e = this, t = (e.$createElement, e._self._c, 0 == e.currentIndex ? e.recentlyUsedItems.length : null), n = 0 != e.currentIndex && 1 == e.currentIndex && null != e.user ? e.toolsItems.length : null, o = 0 != e.currentIndex && 1 != e.currentIndex && 2 == e.currentIndex && null != e.user ? e.documentItems.length : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t,
                    g1: n,
                    g2: o
                }
            });
        }, a = [];
    },
    "5a0d": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("5302"), c = n("691d");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(a);
        n("6a2e");
        var u = n("f0c5"), i = Object(u.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    },
    "691d": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("4dde"), c = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = c.a;
    },
    "6a2e": function(e, t, n) {
        "use strict";
        var o = n("da12");
        n.n(o).a;
    },
    "763c": function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n("4ea4");
            n("8a42"), o(n("66fd"));
            var c = o(n("5a0d"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(c.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    da12: function(e, t, n) {}
}, [ [ "763c", "common/runtime", "common/vendor" ] ] ]);