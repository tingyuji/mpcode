(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/update-log/update-log" ], {
    1842: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var o = a(e("f6ab"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(o.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "1cc9": function(t, n, e) {
        "use strict";
        (function(t) {
            var a = e("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = a(e("b253")), c = a(e("3d83")), i = getApp(), u = {
                components: {
                    noData: function() {
                        e.e("components/no-data/no-data").then(function() {
                            return resolve(e("d21c"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        page: 1,
                        total: 1,
                        list: []
                    };
                },
                onLoad: function(n) {
                    t.showLoading({
                        title: "加载中"
                    }), this.fetchArticleList(1), t.setStorage({
                        key: "notice_last_view",
                        data: c.default.format("yyyy-MM-dd HH:mm:ss")
                    }), i.globalData.redDot = !1;
                },
                onReachBottom: function() {
                    console.log(this.loading), !this.loading && this.page < this.total && this.fetchArticleList(this.page + 1);
                },
                methods: {
                    fetchArticleList: function(n) {
                        var e = this;
                        return this.loading = !0, o.default.get("announcement", {
                            page: n
                        }).then(function(a) {
                            var o = a.data.data;
                            e.setData({
                                page: n,
                                total: a.data.total,
                                list: e.list.concat(o)
                            }), t.hideLoading();
                        }).catch(function(n) {
                            401 == n.statusCode ? (t.showLoading({
                                title: "请先登录"
                            }), setTimeout(function() {
                                t.switchTab({
                                    url: "/pages/me/me"
                                });
                            }, 1e3)) : t.showModal({
                                title: "请求失败",
                                content: n.message,
                                cancelText: "返回",
                                success: function(n) {
                                    t.navigateBack();
                                }
                            });
                        }).then(function() {
                            e.loading = !1;
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, e("543d").default);
    },
    "4a5c": function(t, n, e) {
        "use strict";
        var a = e("cb4e");
        e.n(a).a;
    },
    "93dc": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return a;
        });
        var a = {
            noData: function() {
                return e.e("components/no-data/no-data").then(e.bind(null, "d21c"));
            }
        }, o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    "9f63": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("1cc9"), o = e.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        n.default = o.a;
    },
    cb4e: function(t, n, e) {},
    f6ab: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("93dc"), o = e("9f63");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        e("4a5c");
        var i = e("f0c5"), u = Object(i.a)(o.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = u.exports;
    }
}, [ [ "1842", "common/runtime", "common/vendor" ] ] ]);