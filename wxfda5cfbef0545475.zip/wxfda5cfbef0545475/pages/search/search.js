(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/search/search" ], {
    "39f4": function(t, e, n) {},
    "3b81": function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return a;
        });
        var a = {
            noData: function() {
                return n.e("components/no-data/no-data").then(n.bind(null, "d21c"));
            }
        }, i = function() {
            var t = this, e = (t.$createElement, t._self._c, !t.showResult && t.searchHistory.length > 0), n = t.calcList.length, a = t.basicList.length, i = t.docList.length, c = t.showResult && 0 === t.docList.length && 0 === t.calcList.length && 0 === t.basicList.length;
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    g1: n,
                    g2: a,
                    g3: i,
                    g4: c
                }
            });
        }, c = [];
    },
    "7a18": function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("448a")), c = a(n("ac2e")), o = a(n("b253")), s = n("e308"), u = n("9673"), r = n("c297"), l = getApp(), f = {
                components: {
                    noData: function() {
                        n.e("components/no-data/no-data").then(function() {
                            return resolve(n("d21c"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    navItem: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/nav-item/nav-item") ]).then(function() {
                            return resolve(n("231d"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        showResult: !1,
                        q: "",
                        docList: [],
                        calcList: [],
                        basicList: [],
                        searchHistory: [],
                        search: "",
                        isVip: !1,
                        clacList: [],
                        user: {
                            vip_state: 0
                        }
                    };
                },
                mixins: [ c.default ],
                onLoad: function(e) {
                    var n = this;
                    t.getStorage({
                        key: "search_history",
                        success: function(t) {
                            n.setData({
                                searchHistory: t.data
                            }), console.log(t);
                        }
                    }), l.globalData.getUser().then(function(t) {
                        n.setData({
                            isVip: 1 == t.vip_state
                        });
                    }, function() {
                        n.setData({
                            isVip: !1
                        });
                    });
                },
                methods: {
                    changeQuery: function(t) {
                        this.setData({
                            q: t.detail.value
                        });
                    },
                    searchFun: function() {
                        var e = this, n = this.q;
                        "" != n ? (t.showLoading({
                            title: "搜索中"
                        }), o.default.get("search/v2", {
                            title: n
                        }).then(function(a) {
                            console.log(a), t.hideLoading();
                            var i = [], c = [];
                            if (a.data.forEach(function(t) {
                                if (t.type < 10) {
                                    var e = (0, s.getFeatureConfig)(t.key, t.type);
                                    t.icon = e.icon, i.push(t);
                                } else c.push(t);
                            }), c.length > 0) {
                                var u = [];
                                c.forEach(function(t, e) {
                                    u[t.id] = e;
                                }), o.default.get("documents?document_ids=" + Object.keys(u).join(",")).then(function(t) {
                                    t.data.forEach(function(t) {
                                        var e = c[u[t.id]];
                                        e.views = t.views, e.collects = t.collects;
                                    }), e.calcList = i, e.docList = c, e.showResult = !0;
                                }, function() {
                                    e.calcList = i, e.docList = c, e.showResult = !0;
                                });
                            } else e.calcList = i, e.docList = c, e.showResult = !0;
                            e.searchBasicData(n), e.addHistory(n);
                        }).catch(function(e) {
                            t.showModal({
                                title: "搜索失败",
                                content: e.message,
                                showCancel: !1
                            });
                        })) : t.showToast({
                            title: "请输入关键词",
                            icon: "none",
                            duration: 2e3
                        });
                    },
                    searchBasicData: function(t) {
                        var e = r.StandardQuery;
                        e.push.apply(e, (0, i.default)(r.PinDefinition));
                        var n = t.split(/[,，\s]+/), a = {};
                        n.length > 0 && n.forEach(function(t) {
                            e.forEach(function(e) {
                                -1 !== e.name.indexOf(t) && (a[e.name] = e);
                            });
                        });
                        var c = [];
                        for (var o in a) c.push(a[o]);
                        this.basicList = c;
                    },
                    searchFromHistory: function(t) {
                        var e = t.currentTarget.dataset.q;
                        this.setData({
                            q: e
                        }), this.searchFun();
                    },
                    addHistory: function(e) {
                        var n = "search_history";
                        t.getStorage({
                            key: n,
                            success: function(a) {
                                var i = a.data, c = i.indexOf(e);
                                -1 != c && i.splice(c, 1), i.unshift(e), i.length > 10 && i.splice(10), t.setStorage({
                                    key: n,
                                    data: i,
                                    success: function() {},
                                    fail: function() {}
                                });
                            },
                            fail: function() {
                                t.setStorage({
                                    key: n,
                                    data: [ e ],
                                    success: function() {},
                                    fail: function() {}
                                });
                            }
                        });
                    },
                    clearHistory: function(e) {
                        t.removeStorage({
                            key: "search_history",
                            success: function(t) {},
                            fail: function(t) {}
                        }), this.setData({
                            searchHistory: []
                        });
                    },
                    clear: function(t) {
                        this.setData({
                            q: "",
                            showResult: !1,
                            clacList: [],
                            docList: []
                        });
                    },
                    openCalc: function(t) {
                        (0, s.openFeatureByKey)(t.key, t.type);
                    },
                    openDoc: function(e) {
                        var n = "/pages/data/detail?id=" + e.id;
                        2 == e.requirement ? (0, u.loginRequired)().then(function() {
                            return t.navigateTo({
                                url: n
                            });
                        }, function() {}) : t.navigateTo({
                            url: n
                        });
                    },
                    openBasic: function(e) {
                        t.navigateTo({
                            url: e.url
                        });
                    }
                }
            };
            e.default = f;
        }).call(this, n("543d").default);
    },
    "979e": function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("3b81"), i = n("ce2b");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(c);
        n("d82c");
        var o = n("f0c5"), s = Object(o.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = s.exports;
    },
    b602: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("979e"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    ce2b: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("7a18"), i = n.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(c);
        e.default = i.a;
    },
    d82c: function(t, e, n) {
        "use strict";
        var a = n("39f4");
        n.n(a).a;
    }
}, [ [ "b602", "common/runtime", "common/vendor" ] ] ]);