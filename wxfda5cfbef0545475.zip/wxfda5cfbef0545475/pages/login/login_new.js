(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login_new" ], {
    "04f4": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("29e0"), i = t("9fa3");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("6702");
        var c = t("f0c5"), r = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = r.exports;
    },
    1501: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var i = o(t("bf83b"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "29e0": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "35d9": function(e, n, t) {},
    "46a4": function(e, n, t) {
        "use strict";
        var o = t("981e");
        t.n(o).a;
    },
    6702: function(e, n, t) {
        "use strict";
        var o = t("35d9");
        t.n(o).a;
    },
    6943: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("bcc5"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    "7d1c": function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("7037");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = t("963d"), a = function(e, n) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" != typeof e) return {
                    default: e
                };
                var t = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var n = new WeakMap(), t = new WeakMap();
                    return function(e) {
                        return e ? t : n;
                    }(e);
                }(n);
                if (t && t.has(e)) return t.get(e);
                var i = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                    var r = a ? Object.getOwnPropertyDescriptor(e, c) : null;
                    r && (r.get || r.set) ? Object.defineProperty(i, c, r) : i[c] = e[c];
                }
                return i.default = e, t && t.set(e, i), i;
            }(t("b253")), c = t("a195");
            t("9673");
            var r = getApp(), s = {
                data: function() {
                    return {
                        agreement: !1,
                        showPhoneBtn: !1,
                        phone: "",
                        code: "",
                        sendDisabled: !1,
                        sendLoading: !1,
                        logged: null,
                        ref: "",
                        times: "",
                        count: 0,
                        bindCode: "",
                        isVipTrial: !1
                    };
                },
                onLoad: function(n) {
                    n.bindCode && (this.bindCode = n.bindCode, e.setNavigationBarTitle({
                        title: "绑定手机号码"
                    })), this.phone = e.getStorageSync("login_phone");
                },
                onShow: function() {
                    this.ref = e.getStorageSync("ref"), e.getStorageSync("agreement") && (this.agreement = e.getStorageSync("agreement"));
                },
                methods: {
                    openAgreement: function(e) {
                        1 == e ? (0, c.openWebView)(i.userAgreementUrl, "用户协议") : (0, c.openWebView)(i.privacyPolicyUrl, "隐私协议");
                    },
                    switchAgreement: function() {
                        this.setData({
                            agreement: !this.agreement
                        }), e.setStorageSync("agreement", this.agreement);
                    },
                    countdown: function() {
                        var e = this;
                        this.count && (this.times = setInterval(function() {
                            e.count--, e.count <= 0 && clearInterval(e.times);
                        }, 1e3));
                    },
                    sendCode: function() {
                        var n = this;
                        this.sendLoading || ("" != this.phone ? (this.setData({
                            sendLoading: !0,
                            sendDisabled: !0
                        }), a.default.post("login/code", {
                            phone: this.phone,
                            type: "login_code"
                        }).then(function(t) {
                            e.showToast({
                                title: "短信已发送"
                            }), n.count = 60, n.countdown();
                        }, function(t) {
                            e.showModal({
                                title: "短信发送失败",
                                content: t.message,
                                showCancel: !1
                            }), n.sendLoading = !1;
                        }).finally(function() {
                            n.setData({
                                sendLoading: !1
                            }), setTimeout(function() {
                                n.setData({
                                    sendDisabled: !1
                                });
                            }, 6e4);
                        })) : e.showModal({
                            content: "请输入手机号",
                            showCancel: !1
                        }));
                    },
                    phoneLogin: function() {
                        var n = this;
                        if ("" != this.phone && "" != this.code) {
                            e.showLoading({
                                title: "登录中",
                                mask: !0
                            });
                            var t = {
                                phone: this.phone,
                                code: this.code,
                                type: "login_code",
                                ref: this.ref
                            }, o = "login/phone-login";
                            this.bindCode && (t.bindCode = this.bindCode, o = "login/phone-code"), a.default.post(o, t).then(function(e) {
                                n.isVipTrial = e.data.isInvitation, console.log("isVipTrial", e.data.isInvitation), 
                                n.triggerLoginSuccess(e.data);
                            }, function(t) {
                                e.hideLoading(), n.showFailModal(t);
                            });
                        } else e.showModal({
                            content: "请输入手机号和验证码",
                            showCancel: !1
                        });
                    },
                    triggerLoginSuccess: function(n) {
                        e.hideLoading(), (0, a.setToken)(n.token), r.globalData.trigger("login-status-changed"), 
                        this.getconversionCode(), e.setStorageSync("login_phone", this.phone);
                    },
                    getconversionCode: function() {
                        var n = this;
                        a.default.get("conversionCode/exists").then(function(t) {
                            if (t.data.exists) {
                                var o = n;
                                e.showModal({
                                    title: "兑换会员提醒",
                                    content: "检测到您有未激活的兑换码，请到兑换会员页面进行兑换",
                                    cancelText: "暂不兑换",
                                    confirmText: "去兑换",
                                    success: function(n) {
                                        n.confirm ? (e.hideLoading(), e.redirectTo({
                                            url: "/pages/exchange-vip/exchange-vip"
                                        })) : n.cancel && o.nvabackers();
                                    }
                                });
                            } else n.nvabackers();
                        }, function(e) {
                            n.showFailModal(e);
                        });
                    },
                    replaceActive: function() {
                        var e = this;
                        a.default.get("conversionCode/replaceActive").then(function(n) {
                            e.nvabackers();
                        }, function(n) {
                            console.log(n), e.getconversionCode();
                        });
                    },
                    showFailModal: function(n) {
                        var t = this;
                        e.hideLoading(), e.showModal({
                            title: "登录失败",
                            content: n.message || n.errMsg,
                            confirmText: "继续登录",
                            cancelText: "返回",
                            success: function(e) {
                                e.cancel && t.triggerLoginCancel();
                            }
                        });
                    },
                    vipTrial: function() {
                        e.showModal({
                            title: "恭喜您",
                            content: "获得电工大师三天VIP会员，领取后立即体验",
                            confirmText: "立即领取",
                            success: function(n) {
                                n.confirm && a.default.get("vipTial").then(function(n) {
                                    e.hideLoading(), e.showToast({
                                        title: "VIP会员领取成功",
                                        icon: "success",
                                        duration: 2e3
                                    }), r.globalData.trigger("vip-updated");
                                }).catch(function(n) {
                                    e.showModal({
                                        title: "温馨提示",
                                        showCancel: !1,
                                        content: n.message
                                    });
                                });
                            }
                        });
                    },
                    nvabackers: function() {
                        var n = this;
                        this.isVipTrial && setTimeout(function() {
                            n.vipTrial();
                        }, 1500), e.navigateBack({
                            delta: 2,
                            success: function() {
                                setTimeout(function() {
                                    r.globalData.afterLoginSuccess && (r.globalData.afterLoginSuccess(), r.globalData.afterLoginSuccess = null);
                                }, 0), r.globalData.afterLoginCancel && (r.globalData.afterLoginCancel = null);
                            }
                        }), r.globalData.trigger("login-status-changed");
                    },
                    triggerLoginCancel: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    r.globalData.afterLoginCancel && (r.globalData.afterLoginCancel(), r.globalData.afterLoginCancel = null);
                                }, 0), r.globalData.afterLoginSuccess && (r.globalData.afterLoginSuccess = null);
                            }
                        }), r.globalData.trigger("login-status-changed");
                    }
                }
            };
            n.default = s;
        }).call(this, t("543d").default);
    },
    "981e": function(e, n, t) {},
    "9fa3": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("7d1c"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    bcc5: function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("4ea4"), i = t("7037");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t("963d"), c = t("963d"), r = t("963d"), s = function(e, n) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== i(e) && "function" != typeof e) return {
                    default: e
                };
                var t = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var n = new WeakMap(), t = new WeakMap();
                    return function(e) {
                        return e ? t : n;
                    }(e);
                }(n);
                if (t && t.has(e)) return t.get(e);
                var o = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                    var r = a ? Object.getOwnPropertyDescriptor(e, c) : null;
                    r && (r.get || r.set) ? Object.defineProperty(o, c, r) : o[c] = e[c];
                }
                return o.default = e, t && t.set(e, o), o;
            }(t("b253")), l = t("a195"), u = (t("9673"), o(t("04f4"))), g = getApp(), d = {
                data: function() {
                    return {
                        agreement: !1,
                        BaseUrl: a.BaseUrl,
                        showPhoneBtn: !1,
                        showAgreement: !1,
                        ref: "",
                        userAgreementUrl: r.userAgreementUrl,
                        privacyPolicyUrl: r.privacyPolicyUrl,
                        type: 1,
                        bindCode: ""
                    };
                },
                components: {
                    phoneNew: u.default
                },
                onShow: function() {
                    this.ref = e.getStorageSync("ref"), e.getStorageSync("agreement") && (this.agreement = e.getStorageSync("agreement"));
                },
                onLoad: function() {},
                methods: {
                    login: function() {
                        if (!this.agreement) return this.type = 1, void (this.showAgreement = !0);
                        this.mpGetUserProfile();
                    },
                    agree: function() {
                        this.showAgreement = !1, this.agreement = !0, 1 == this.type ? this.login() : this.phoneLogin();
                    },
                    tiktokAgree: function() {
                        this.showAgreement = !0, this.agreement = !0;
                    },
                    tiktokCodeLogin: function() {
                        var n = this;
                        e.login({
                            success: function(t) {
                                s.default.post("login/wechat-miniprogram", {
                                    code: t.code,
                                    nickname: "微信用户",
                                    platform: 1,
                                    avatar: "https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"
                                }).then(function(n) {
                                    e.hideLoading();
                                }, function(t) {
                                    404 == t.statusCode ? (e.hideLoading(), n.bindCode = t.data.data.bindCode) : (e.hideLoading(), 
                                    n.showFailModal(t));
                                });
                            },
                            fail: function(e) {
                                n.showFailModal(e);
                            }
                        });
                    },
                    mpGetUserProfile: function() {
                        var n = this;
                        0 != this.agreement ? e.login({
                            success: function(t) {
                                s.default.post("login/wechat-miniprogram", {
                                    code: t.code,
                                    nickname: "微信用户",
                                    platform: 1,
                                    avatar: "https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"
                                }).then(function(t) {
                                    e.hideLoading(), n.triggerLoginSuccess(t.data);
                                }, function(t) {
                                    404 == t.statusCode ? (e.hideLoading(), e.navigateTo({
                                        url: "/pages/login/phone_new?bindCode=" + t.data.data.bindCode
                                    })) : (e.hideLoading(), n.showFailModal(t));
                                });
                            },
                            fail: function(e) {
                                n.showFailModal(e);
                            }
                        }) : this.showAgreement = !0;
                    },
                    getPhoneNumberHandler: function(n) {
                        var t = this;
                        console.log(n);
                        var o = n.detail, i = o.errMsg.substring(15);
                        console.log(n), this.showAgreement = !1, "ok" == i ? (e.showLoading({
                            title: "登录中",
                            mask: !0
                        }), this.showPhoneBtn = !1, s.default.post("login/wechat-phone", {
                            bindCode: this.bindCode,
                            iv: o.iv,
                            ref: this.ref,
                            encryptedData: o.encryptedData
                        }).then(function(n) {
                            e.setStorageSync("ref", ""), e.hideLoading(), t.triggerLoginSuccess(n.data);
                        }, function(n) {
                            e.hideLoading(), t.showFailModal(n);
                        })) : this.showFailModal({
                            message: "取消登录"
                        });
                    },
                    showFailModal: function(n) {
                        var t = this;
                        console.log(n), e.hideLoading(), e.showModal({
                            title: "登录失败",
                            content: n.message,
                            confirmText: "继续登录",
                            cancelText: "返回",
                            success: function(e) {
                                e.cancel && t.triggerLoginCancel();
                            }
                        });
                    },
                    appGetUserProfile: function() {
                        var n = this;
                        console.log("登录中"), e.getProvider({
                            service: "oauth",
                            success: function(t) {
                                console.log(t.provider), t.provider.indexOf("weixin") > -1 ? e.login({
                                    provider: "weixin",
                                    onlyAuthorize: !0,
                                    success: function(e) {
                                        n.quertUserInfo(e.code);
                                    },
                                    fail: function(e) {
                                        console.log(e), n.showFailModal(e);
                                    }
                                }) : n.showFailModal({
                                    message: "不支持微信登录"
                                });
                            },
                            fail: function(e) {
                                console.log(e);
                            }
                        });
                    },
                    quertUserInfo: function(n) {
                        var t = this;
                        console.log(c.platformId), s.default.post("login/wechat-miniprogram", {
                            code: n,
                            platform: 3
                        }).then(function(n) {
                            console.log(n.data), e.hideLoading(), t.triggerLoginSuccess(n.data);
                        }, function(n) {
                            console.log(n), 404 == n.statusCode ? (e.hideLoading(), e.navigateTo({
                                url: "/pages/login/phone_new?bindCode=" + n.data.data.bindCode
                            })) : (e.hideLoading(), t.showFailModal(n));
                        });
                    },
                    triggerLoginSuccess: function(n) {
                        console.log(n), (0, s.setToken)(n.token), g.globalData.trigger("login-status-changed"), 
                        e.hideLoading(), this.getconversionCode();
                    },
                    getconversionCode: function() {
                        var n = this;
                        s.default.get("conversionCode/exists").then(function(t) {
                            if (t.data.exists) {
                                var o = n;
                                e.showModal({
                                    title: "兑换会员提醒",
                                    content: "检测到您有未激活的兑换码，请到兑换会员页面进行兑换",
                                    cancelText: "暂不兑换",
                                    confirmText: "去兑换",
                                    success: function(n) {
                                        n.confirm ? (e.hideLoading(), e.redirectTo({
                                            url: "/pages/exchange-vip/exchange-vip"
                                        })) : n.cancel && o.nvabackers();
                                    }
                                });
                            } else n.nvabackers();
                        });
                    },
                    replaceActive: function() {
                        var e = this;
                        s.default.get("conversionCode/replaceActive").then(function(n) {
                            e.nvabackers();
                        }, function(n) {
                            console.log(n), e.getconversionCode();
                        });
                    },
                    nvabackers: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    g.globalData.afterLoginSuccess && (g.globalData.afterLoginSuccess(), g.globalData.afterLoginSuccess = null);
                                }, 0), g.globalData.afterLoginCancel && (g.globalData.afterLoginCancel = null);
                            }
                        }), g.globalData.trigger("login-status-changed");
                    },
                    phoneLogin: function() {
                        if (!this.agreement) return this.type = 2, void (this.showAgreement = !0);
                        e.navigateTo({
                            url: "/pages/login/phone_new"
                        });
                    },
                    openAgreement: function(e) {
                        (0, l.openWebView)(e, "协议");
                    },
                    agreementChange: function(n) {
                        this.agreement = !this.agreement, e.setStorageSync("agreement", this.agreement);
                    }
                }
            };
            n.default = d;
        }).call(this, t("543d").default);
    },
    bf83b: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("c348"), i = t("6943");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("46a4");
        var c = t("f0c5"), r = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = r.exports;
    },
    c348: function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement, e._self._c, e._isMounted || (e.e0 = function(n) {
                e.agreement = !0;
            }, e.e1 = function(n) {
                e.agreement = !0;
            }, e.e2 = function(n) {
                e.showPhoneBtn = !1;
            }, e.e3 = function(n) {
                e.showAgreement = !1;
            });
        }, i = [];
    }
}, [ [ "1501", "common/runtime", "common/vendor" ] ] ]);