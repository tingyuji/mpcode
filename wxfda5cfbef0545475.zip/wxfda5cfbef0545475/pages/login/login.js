(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login" ], {
    "2a6f": function(e, n, t) {},
    "2b66": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("88c0"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    "472f": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement, e._self._c, e._isMounted || (e.e0 = function(n) {
                e.showAgreement = !0;
            }, e.e1 = function(n) {
                e.showAgreement = !1;
            });
        }, i = [];
    },
    "61d9": function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var i = o(t("87d7"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    6523: function(e, n, t) {
        "use strict";
        var o = t("2a6f");
        t.n(o).a;
    },
    "87d7": function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t("472f"), i = t("2b66");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("6523");
        var r = t("f0c5"), c = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = c.exports;
    },
    "88c0": function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t("7037");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = t("963d"), a = t("963d"), r = t("963d"), c = function(e, n) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== o(e) && "function" != typeof e) return {
                    default: e
                };
                var t = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var n = new WeakMap(), t = new WeakMap();
                    return function(e) {
                        return e ? t : n;
                    }(e);
                }(n);
                if (t && t.has(e)) return t.get(e);
                var i = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var r in e) if ("default" !== r && Object.prototype.hasOwnProperty.call(e, r)) {
                    var c = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    c && (c.get || c.set) ? Object.defineProperty(i, r, c) : i[r] = e[r];
                }
                return i.default = e, t && t.set(e, i), i;
            }(t("b253")), s = t("a195");
            t("9673");
            var l = getApp(), u = {
                data: function() {
                    return {
                        bindCode: "",
                        agreement: !1,
                        BaseUrl: i.BaseUrl,
                        showPhoneBtn: !1,
                        ref: "",
                        showAgreement: !1,
                        userAgreementUrl: r.userAgreementUrl,
                        privacyPolicyUrl: r.privacyPolicyUrl,
                        isVipTrial: !1
                    };
                },
                computed: {},
                components: {
                    phone: function() {
                        t.e("components/phone/phone-code").then(function() {
                            return resolve(t("d0df"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                onShow: function() {
                    this.ref = e.getStorageSync("ref"), e.getStorageSync("agreement") && (this.agreement = e.getStorageSync("agreement"));
                },
                methods: {
                    login: function() {
                        this.agreement || (this.showAgreement = !0);
                    },
                    agreeLogin: function() {
                        this.agreement = !0, this.showAgreement = !1, this.login();
                    },
                    confirmAppLogin: function() {
                        this.agreement = !0, this.showAgreement = !1, this.login();
                    },
                    appGetUserProfile: function() {
                        var n = this;
                        console.log("登录中"), e.getProvider({
                            service: "oauth",
                            success: function(t) {
                                console.log(t.provider), t.provider.indexOf("weixin") > -1 ? e.login({
                                    provider: "weixin",
                                    onlyAuthorize: !0,
                                    success: function(e) {
                                        n.quertUserInfo(e.code);
                                    },
                                    fail: function(e) {
                                        console.log(e), n.showFailModal(e);
                                    }
                                }) : n.showFailModal({
                                    message: "不支持微信登录"
                                });
                            },
                            fail: function(e) {
                                console.log(e);
                            }
                        });
                    },
                    quertUserInfo: function(n) {
                        var t = this;
                        console.log(a.platformId), c.default.post("login/wechat-miniprogram", {
                            code: n,
                            platform: 3
                        }).then(function(n) {
                            console.log(n.data), e.hideLoading(), t.triggerLoginSuccess(n.data);
                        }, function(n) {
                            console.log(n), 404 == n.statusCode ? (t.$refs.phoneCode.showPhoneCode = !0, t.$refs.phoneCode.bindCode = n.data.data.bindCode, 
                            e.hideLoading()) : (e.hideLoading(), t.showFailModal(n));
                        });
                    },
                    mpGetUserProfile: function() {
                        var n = this;
                        e.login({
                            success: function(t) {
                                c.default.post("login/wechat-miniprogram", {
                                    code: t.code,
                                    nickname: "微信用户",
                                    platform: 1,
                                    avatar: "https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"
                                }).then(function(t) {
                                    e.hideLoading(), n.triggerLoginSuccess(t.data);
                                }, function(t) {
                                    404 == t.statusCode ? (n.$refs.phoneCode.showPhoneCode = !0, n.$refs.phoneCode.bindCode = t.data.data.bindCode) : (e.hideLoading(), 
                                    n.showFailModal(t));
                                });
                            },
                            fail: function(e) {
                                n.showFailModal(e);
                            }
                        });
                    },
                    agree: function() {
                        this.agreement = !0, this.showAgreement = !1, e.setStorageSync("agreement", !0), 
                        this.mpGetUserProfile();
                    },
                    getPhoneNumber: function(n) {
                        var t = this, o = n.detail, i = o.errMsg.substring(15);
                        console.log(n), this.showAgreement = !1, "ok" == i ? (e.showLoading({
                            title: "登录中",
                            mask: !0
                        }), this.showPhoneBtn = !1, c.default.post("login/wechat-phone", {
                            bindCode: this.bindCode,
                            iv: o.iv,
                            ref: this.ref,
                            encryptedData: o.encryptedData
                        }).then(function(n) {
                            e.setStorageSync("ref", ""), e.hideLoading(), t.triggerLoginSuccess(n.data);
                        }, function(n) {
                            e.hideLoading(), t.showFailModal(n);
                        })) : this.showFailModal({
                            message: "取消登录"
                        });
                    },
                    switchAgreement: function() {
                        this.setData({
                            agreement: !this.agreement
                        }), e.setStorageSync("agreement", this.agreement);
                    },
                    showFailModal: function(n) {
                        var t = this;
                        console.log(n), e.hideLoading(), e.showModal({
                            title: "登录失败",
                            content: n.message,
                            confirmText: "继续登录",
                            cancelText: "返回",
                            success: function(e) {
                                e.cancel && t.triggerLoginCancel();
                            }
                        });
                    },
                    triggerLoginSuccess: function(n) {
                        (0, c.setToken)(n.token), this.isVipTrial = n.isInvitation, l.globalData.trigger("login-status-changed"), 
                        e.hideLoading(), this.replaceActive(n);
                    },
                    vipTrial: function() {
                        e.showModal({
                            title: "恭喜您",
                            content: "获得电工大师三天VIP会员，领取后立即体验",
                            confirmText: "立即领取",
                            success: function(n) {
                                n.confirm && c.default.get("vipTial").then(function(n) {
                                    e.hideLoading(), e.showToast({
                                        title: "VIP会员领取成功",
                                        icon: "success",
                                        duration: 2e3
                                    }), l.globalData.trigger("vip-updated");
                                }).catch(function(n) {
                                    e.showModal({
                                        title: "温馨提示",
                                        showCancel: !1,
                                        content: n.message
                                    });
                                });
                            }
                        });
                    },
                    getconversionCode: function() {
                        var n = this;
                        c.default.get("conversionCode/exists").then(function(t) {
                            if (t.data.exists) {
                                var o = n;
                                e.showModal({
                                    title: "兑换会员提醒",
                                    content: "检测到您有未激活的兑换码，请到兑换会员页面进行兑换",
                                    cancelText: "暂不兑换",
                                    confirmText: "去兑换",
                                    success: function(n) {
                                        n.confirm ? (e.hideLoading(), e.redirectTo({
                                            url: "/pages/exchange-vip/exchange-vip"
                                        })) : n.cancel && o.nvabackers();
                                    }
                                });
                            } else n.nvabackers();
                        });
                    },
                    replaceActive: function(e) {
                        var n = this;
                        c.default.get("conversionCode/replaceActive").then(function(e) {
                            n.nvabackers();
                        }, function(t) {
                            n.getconversionCode(e);
                        });
                    },
                    nvabackers: function() {
                        var n = this;
                        this.isVipTrial && setTimeout(function() {
                            n.vipTrial();
                        }, 1500), e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    l.globalData.afterLoginSuccess && (l.globalData.afterLoginSuccess(), l.globalData.afterLoginSuccess = null);
                                }, 0), l.globalData.afterLoginCancel && (l.globalData.afterLoginCancel = null);
                            }
                        }), l.globalData.trigger("login-status-changed");
                    },
                    triggerLoginCancel: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    l.globalData.afterLoginCancel && (l.globalData.afterLoginCancel(), l.globalData.afterLoginCancel = null);
                                }, 0), l.globalData.afterLoginSuccess && (l.globalData.afterLoginSuccess = null);
                            }
                        });
                    },
                    openAgreement: function(e) {
                        (0, s.openWebView)(e, "协议");
                    }
                }
            };
            n.default = u;
        }).call(this, t("543d").default);
    }
}, [ [ "61d9", "common/runtime", "common/vendor" ] ] ]);