(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/phone" ], {
    "0b17": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("3c5a"), o = t("169f");
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        t("ce9e");
        var c = t("f0c5"), r = Object(c.a)(o.default, a.b, a.c, !1, null, "4929af05", null, !1, a.a, void 0);
        n.default = r.exports;
    },
    1436: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var a = t("4ea4");
            t("8a42"), a(t("66fd"));
            var o = a(t("0b17"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "169f": function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t("a50d"), o = t.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(i);
        n.default = o.a;
    },
    "3c5a": function(e, n, t) {
        "use strict";
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, o = [];
    },
    "7c6c": function(e, n, t) {},
    a50d: function(e, n, t) {
        "use strict";
        (function(e) {
            var a = t("7037");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = t("963d"), i = function(e, n) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== a(e) && "function" != typeof e) return {
                    default: e
                };
                var t = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var n = new WeakMap(), t = new WeakMap();
                    return function(e) {
                        return e ? t : n;
                    }(e);
                }(n);
                if (t && t.has(e)) return t.get(e);
                var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var c in e) if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                    var r = i ? Object.getOwnPropertyDescriptor(e, c) : null;
                    r && (r.get || r.set) ? Object.defineProperty(o, c, r) : o[c] = e[c];
                }
                return o.default = e, t && t.set(e, o), o;
            }(t("b253")), c = t("a195");
            t("9673");
            var r = getApp(), s = {
                name: "phone",
                data: function() {
                    return {
                        agreement: !1,
                        showPhoneBtn: !1,
                        phone: "",
                        code: "",
                        sendDisabled: !1,
                        sendLoading: !1,
                        logged: null,
                        ref: ""
                    };
                },
                onShow: function() {
                    this.ref = e.getStorageSync("ref"), e.getStorageSync("agreement") && (this.agreement = e.getStorageSync("agreement"));
                },
                methods: {
                    openAgreement: function(e) {
                        1 == e ? (0, c.openWebView)(o.userAgreementUrl, "用户协议") : (0, c.openWebView)(o.privacyPolicyUrl, "隐私协议");
                    },
                    switchAgreement: function() {
                        this.setData({
                            agreement: !this.agreement
                        }), e.setStorageSync("agreement", this.agreement);
                    },
                    sendCode: function() {
                        var n = this;
                        this.sendLoading || ("" != this.phone ? (this.setData({
                            sendLoading: !0,
                            sendDisabled: !0
                        }), i.default.post("login/code", {
                            phone: this.phone,
                            type: "login_code"
                        }).then(function(n) {
                            e.showToast({
                                title: "短信已发送"
                            });
                        }, function(t) {
                            e.showModal({
                                title: "短信发送失败",
                                content: t.message,
                                showCancel: !1
                            }), n.sendLoading = !1;
                        }).finally(function() {
                            n.setData({
                                sendLoading: !1
                            }), setTimeout(function() {
                                n.setData({
                                    sendDisabled: !1
                                });
                            }, 6e4);
                        })) : e.showModal({
                            content: "请输入手机号",
                            showCancel: !1
                        }));
                    },
                    phoneLogin: function() {
                        var n = this;
                        this.agreement ? "" != this.phone && "" != this.code ? (e.showLoading({
                            title: "登录中",
                            mask: !0
                        }), i.default.post("login/phone-login", {
                            phone: this.phone,
                            code: this.code,
                            type: "login_code"
                        }).then(function(e) {
                            n.triggerLoginSuccess(e.data);
                        }, function(t) {
                            e.hideLoading(), n.showFailModal(t);
                        })) : e.showModal({
                            content: "请输入手机号和验证码",
                            showCancel: !1
                        }) : e.showModal({
                            content: "您需要阅读并同意《用户协议》《隐私协议》才能继续登录。",
                            showCancel: !1
                        });
                    },
                    triggerLoginSuccess: function(n) {
                        e.hideLoading(), (0, i.setToken)(n.token), r.globalData.trigger("login-status-changed"), 
                        this.replaceActive();
                    },
                    getconversionCode: function() {
                        var n = this;
                        i.default.get("conversionCode/exists").then(function(t) {
                            if (t.data.exists) {
                                var a = n;
                                e.showModal({
                                    title: "兑换会员提醒",
                                    content: "检测到您有未激活的兑换码，请到兑换会员页面进行兑换",
                                    cancelText: "暂不兑换",
                                    confirmText: "去兑换",
                                    success: function(n) {
                                        n.confirm ? (e.hideLoading(), e.redirectTo({
                                            url: "/pages/exchange-vip/exchange-vip"
                                        })) : n.cancel && a.nvabackers();
                                    }
                                });
                            } else n.nvabackers();
                        }, function(e) {
                            n.showFailModal(e);
                        });
                    },
                    replaceActive: function() {
                        var e = this;
                        i.default.get("conversionCode/replaceActive").then(function(n) {
                            e.nvabackers();
                        }, function(n) {
                            console.log(n), e.getconversionCode();
                        });
                    },
                    showFailModal: function(n) {
                        var t = this;
                        e.hideLoading(), e.showModal({
                            title: "登录失败",
                            content: n.message || n.errMsg,
                            confirmText: "继续登录",
                            cancelText: "返回",
                            success: function(e) {
                                e.cancel && t.triggerLoginCancel();
                            }
                        });
                    },
                    nvabackers: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    r.globalData.afterLoginSuccess && (r.globalData.afterLoginSuccess(), r.globalData.afterLoginSuccess = null);
                                }, 0), r.globalData.afterLoginCancel && (r.globalData.afterLoginCancel = null);
                            }
                        }), r.globalData.trigger("login-status-changed");
                    },
                    triggerLoginCancel: function() {
                        e.navigateBack({
                            success: function() {
                                setTimeout(function() {
                                    r.globalData.afterLoginCancel && (r.globalData.afterLoginCancel(), r.globalData.afterLoginCancel = null);
                                }, 0), r.globalData.afterLoginSuccess && (r.globalData.afterLoginSuccess = null);
                            }
                        }), r.globalData.trigger("login-status-changed");
                    }
                }
            };
            n.default = s;
        }).call(this, t("543d").default);
    },
    ce9e: function(e, n, t) {
        "use strict";
        var a = t("7c6c");
        t.n(a).a;
    }
}, [ [ "1436", "common/runtime", "common/vendor" ] ] ]);