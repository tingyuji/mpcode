(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/iec60320/iec60320" ], {
    "4e76": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("881f"), u = e("d944");
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(a);
        e("65f3");
        var c = e("f0c5"), f = Object(c.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = f.exports;
    },
    "65f3": function(n, t, e) {
        "use strict";
        var o = e("b9ab");
        e.n(o).a;
    },
    "881f": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    b9ab: function(n, t, e) {},
    d8f0: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {};
            },
            onLoad: function(n) {},
            onReady: function() {},
            onShow: function() {},
            onHide: function() {},
            onUnload: function() {},
            onPullDownRefresh: function() {},
            onReachBottom: function() {},
            onShareAppMessage: function() {},
            methods: {}
        };
    },
    d944: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("d8f0"), u = e.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = u.a;
    },
    e224: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var u = o(e("4e76"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    }
}, [ [ "e224", "common/runtime", "common/vendor" ] ] ]);