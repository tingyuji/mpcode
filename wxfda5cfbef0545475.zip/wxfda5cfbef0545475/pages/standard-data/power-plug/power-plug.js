(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/power-plug/power-plug" ], {
    "002c": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {};
            },
            onLoad: function(n) {},
            onReady: function() {},
            onShow: function() {},
            onHide: function() {},
            onUnload: function() {},
            onPullDownRefresh: function() {},
            onReachBottom: function() {},
            onShareAppMessage: function() {},
            methods: {}
        };
    },
    "0c5f": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var u = o(e("b731"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "3a99": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    9392: function(n, t, e) {
        "use strict";
        var o = e("f956");
        e.n(o).a;
    },
    9894: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("002c"), u = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = u.a;
    },
    b731: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("3a99"), u = e("9894");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        e("9392");
        var a = e("f0c5"), f = Object(a.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = f.exports;
    },
    f956: function(n, t, e) {}
}, [ [ "0c5f", "common/runtime", "common/vendor" ] ] ]);