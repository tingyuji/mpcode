(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/ansi-device-number/ansi-device-number" ], {
    "0e9a": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("43b3"), i = e("72ab");
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(u);
        e("9d1f");
        var r = e("f0c5"), c = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = c.exports;
    },
    2606: function(t, n, e) {},
    "304a": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                data: function() {
                    return {
                        winWidth: 0,
                        winHeight: 0,
                        currentTab: 0
                    };
                },
                onLoad: function() {
                    var n = this;
                    t.getSystemInfo({
                        success: function(t) {
                            n.setData({
                                winWidth: t.windowWidth,
                                winHeight: t.windowHeight
                            });
                        }
                    });
                },
                methods: {
                    swichNav: function(t) {
                        if (this.currentTab === t.target.dataset.current) return !1;
                        this.setData({
                            currentTab: t.target.dataset.current
                        });
                    },
                    bindChange: function(t) {
                        this.setData({
                            currentTab: t.detail.current
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e("543d").default);
    },
    "43b3": function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "72ab": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("304a"), i = e.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(u);
        n.default = i.a;
    },
    "9d1f": function(t, n, e) {
        "use strict";
        var a = e("2606");
        e.n(a).a;
    },
    eaab: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var i = a(e("0e9a"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    }
}, [ [ "eaab", "common/runtime", "common/vendor" ] ] ]);