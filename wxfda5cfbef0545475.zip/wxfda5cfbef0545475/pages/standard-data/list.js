(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/list" ], {
    "068b": function(n, t, e) {
        "use strict";
        var a = e("fbc1");
        e.n(a).a;
    },
    "2dc6": function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = e("c297"), r = {
                components: {
                    navItem: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/nav-item/nav-item") ]).then(function() {
                            return resolve(e("231d"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        list: a.StandardQuery
                    };
                },
                methods: {
                    openUrl: function(t) {
                        n.navigateTo({
                            url: t.currentTarget.dataset.url
                        });
                    }
                }
            };
            t.default = r;
        }).call(this, e("543d").default);
    },
    "5fe8": function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("8ffe"), r = e("d96e");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(u);
        e("068b");
        var o = e("f0c5"), c = Object(o.a)(r.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = c.exports;
    },
    80195: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var r = a(e("5fe8"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(r.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "8ffe": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return r;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {
            return a;
        });
        var a = {
            navItem: function() {
                return Promise.all([ e.e("common/vendor"), e.e("components/nav-item/nav-item") ]).then(e.bind(null, "231d"));
            }
        }, r = function() {
            this.$createElement;
            var n = (this._self._c, this.list.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, u = [];
    },
    d96e: function(n, t, e) {
        "use strict";
        e.r(t);
        var a = e("2dc6"), r = e.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(u);
        t.default = r.a;
    },
    fbc1: function(n, t, e) {}
}, [ [ "80195", "common/runtime", "common/vendor" ] ] ]);