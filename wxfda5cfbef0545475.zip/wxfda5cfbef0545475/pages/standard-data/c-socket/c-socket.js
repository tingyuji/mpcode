(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/c-socket/c-socket" ], {
    "0628": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    1734: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("31f0"), u = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = u.a;
    },
    "29e4": function(n, t, e) {},
    "31f0": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {};
            },
            onLoad: function(n) {},
            onReady: function() {},
            onShow: function() {},
            onHide: function() {},
            onUnload: function() {},
            onPullDownRefresh: function() {},
            onReachBottom: function() {},
            onShareAppMessage: function() {},
            methods: {}
        };
    },
    "421a": function(n, t, e) {
        "use strict";
        var o = e("29e4");
        e.n(o).a;
    },
    "4d4e": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var u = o(e("d997"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    d997: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("0628"), u = e("1734");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        e("421a");
        var a = e("f0c5"), f = Object(a.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = f.exports;
    }
}, [ [ "4d4e", "common/runtime", "common/vendor" ] ] ]);