(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/cable-reactance/cable-reactance" ], {
    "0581": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                data: function() {
                    return {
                        winWidth: 0,
                        winHeight: 0,
                        currentTab: 0
                    };
                },
                onLoad: function() {
                    var n = this;
                    t.getSystemInfo({
                        success: function(t) {
                            n.setData({
                                winWidth: t.windowWidth,
                                winHeight: t.windowHeight
                            });
                        }
                    });
                },
                methods: {
                    swichNav: function(t) {
                        if (this.currentTab === t.target.dataset.current) return !1;
                        this.setData({
                            currentTab: t.target.dataset.current
                        });
                    },
                    bindChange: function(t) {
                        this.setData({
                            currentTab: t.detail.current
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e("543d").default);
    },
    "4ca7": function(t, n, e) {},
    "76be": function(t, n, e) {
        "use strict";
        (function(t, n) {
            var a = e("4ea4");
            e("8a42"), a(e("66fd"));
            var c = a(e("fcdf"));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(c.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    9278: function(t, n, e) {
        "use strict";
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    aae3: function(t, n, e) {
        "use strict";
        var a = e("4ca7");
        e.n(a).a;
    },
    dc53: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("0581"), c = e.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        n.default = c.a;
    },
    fcdf: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("9278"), c = e("dc53");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return c[t];
            });
        }(i);
        e("aae3");
        var r = e("f0c5"), u = Object(r.a)(c.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = u.exports;
    }
}, [ [ "76be", "common/runtime", "common/vendor" ] ] ]);