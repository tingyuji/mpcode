(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/nema-socket/nema-socket" ], {
    "1eea": function(n, e, t) {
        "use strict";
        (function(n, e) {
            var o = t("4ea4");
            t("8a42"), o(t("66fd"));
            var c = o(t("30ce"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(c.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    2891: function(n, e, t) {
        "use strict";
        var o = t("c7fb");
        t.n(o).a;
    },
    "30ce": function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("f05b"), c = t("4916");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(a);
        t("2891");
        var u = t("f0c5"), i = Object(u.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = i.exports;
    },
    4916: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("8399"), c = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = c.a;
    },
    8399: function(n, e, t) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            components: {
                navItem: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/nav-item/nav-item") ]).then(function() {
                        return resolve(t("231d"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {};
            },
            onLoad: function(n) {},
            onReady: function() {},
            onShow: function() {},
            onHide: function() {},
            onUnload: function() {},
            onPullDownRefresh: function() {},
            onReachBottom: function() {},
            onShareAppMessage: function() {},
            methods: {}
        };
        e.default = o;
    },
    c7fb: function(n, e, t) {},
    f05b: function(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    }
}, [ [ "1eea", "common/runtime", "common/vendor" ] ] ]);