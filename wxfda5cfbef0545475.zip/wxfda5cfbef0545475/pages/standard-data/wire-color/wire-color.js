(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/standard-data/wire-color/wire-color" ], {
    "1d6c": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("63f88"), c = e.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        t.default = c.a;
    },
    "33ab": function(n, t, e) {
        "use strict";
        (function(n, t) {
            var o = e("4ea4");
            e("8a42"), o(e("66fd"));
            var c = o(e("e391"));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(c.default);
        }).call(this, e("bc2e").default, e("543d").createPage);
    },
    "44c7": function(n, t, e) {},
    "63f88": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {};
            },
            onLoad: function(n) {},
            onReady: function() {},
            onShow: function() {},
            onHide: function() {},
            onUnload: function() {},
            onPullDownRefresh: function() {},
            onReachBottom: function() {},
            onShareAppMessage: function() {},
            methods: {}
        };
    },
    "82ac": function(n, t, e) {
        "use strict";
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement, this._self._c;
        }, c = [];
    },
    bc00: function(n, t, e) {
        "use strict";
        var o = e("44c7");
        e.n(o).a;
    },
    e391: function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("82ac"), c = e("1d6c");
        for (var u in c) [ "default" ].indexOf(u) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(u);
        e("bc00");
        var a = e("f0c5"), i = Object(a.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    }
}, [ [ "33ab", "common/runtime", "common/vendor" ] ] ]);