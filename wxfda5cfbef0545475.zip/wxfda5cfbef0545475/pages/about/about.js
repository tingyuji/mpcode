(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/about/about" ], {
    "46e7": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("6bdb"), u = r.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(a);
        t.default = u.a;
    },
    "4f85": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("82c4"), u = r("46e7");
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(e) {
            r.d(t, e, function() {
                return u[e];
            });
        }(a);
        r("f730");
        var c = r("f0c5"), i = Object(c.a)(u.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = i.exports;
    },
    "6bdb": function(e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = r("963d"), u = r("a195"), a = {
            data: function() {
                return {
                    userAgreementUrl: "",
                    privacyPolicyUrl: "",
                    termsServiceUrl: ""
                };
            },
            onLoad: function(e) {
                this.setData({
                    userAgreementUrl: (0, u.getWebViewUrl)(n.userAgreementUrl, "隐私政策"),
                    privacyPolicyUrl: (0, u.getWebViewUrl)(n.privacyPolicyUrl, "用户协议"),
                    termsServiceUrl: (0, u.getWebViewUrl)(n.termsServiceUrl, "会员服务条款")
                });
            },
            methods: {}
        };
        t.default = a;
    },
    "82c4": function(e, t, r) {
        "use strict";
        r.d(t, "b", function() {
            return n;
        }), r.d(t, "c", function() {
            return u;
        }), r.d(t, "a", function() {});
        var n = function() {
            this.$createElement, this._self._c;
        }, u = [];
    },
    ab9b: function(e, t, r) {},
    e364: function(e, t, r) {
        "use strict";
        (function(e, t) {
            var n = r("4ea4");
            r("8a42"), n(r("66fd"));
            var u = n(r("4f85"));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, t(u.default);
        }).call(this, r("bc2e").default, r("543d").createPage);
    },
    f730: function(e, t, r) {
        "use strict";
        var n = r("ab9b");
        r.n(n).a;
    }
}, [ [ "e364", "common/runtime", "common/vendor" ] ] ]);