(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/about/webview" ], {
    3104: function(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement, this._self._c;
        }, i = [];
    },
    "45cd": function(t, e, n) {
        "use strict";
        var a = n("af51");
        n.n(a).a;
    },
    6432: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("3104"), i = n("af40");
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("45cd");
        var r = n("f0c5"), u = Object(r.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = u.exports;
    },
    af40: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("bb62"), i = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        e.default = i.a;
    },
    af51: function(t, e, n) {},
    bb62: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = n("a195"), i = {
                data: function() {
                    return {
                        url: "",
                        title: ""
                    };
                },
                onLoad: function(e) {
                    if (e.url) {
                        if (t.showNavigationBarLoading(), this.setData({
                            url: decodeURIComponent(e.url)
                        }), e.title) {
                            var n = decodeURIComponent(e.title);
                            t.setNavigationBarTitle({
                                title: n
                            }), this.title = n;
                        }
                    } else t.navigateBack();
                },
                methods: {
                    onWebPageLoad: function(e) {
                        t.hideNavigationBarLoading();
                    },
                    onWebPageError: function(e) {
                        var n = this;
                        t.hideNavigationBarLoading(), t.showModal({
                            title: "页面加载失败",
                            content: "很抱歉，目标页面未能成功加载，您可以返回或尝试重新加载。",
                            confirmText: "重新加载",
                            cancelText: "返回",
                            success: function(e) {
                                if (e.confirm) {
                                    var i = (0, a.getWebViewUrl)(n.url, n.title);
                                    t.redirectTo({
                                        url: i
                                    });
                                } else t.navigateBack();
                            }
                        });
                    }
                }
            };
            e.default = i;
        }).call(this, n("543d").default);
    },
    fb6b: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var a = n("4ea4");
            n("8a42"), a(n("66fd"));
            var i = a(n("6432"));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    }
}, [ [ "fb6b", "common/runtime", "common/vendor" ] ] ]);