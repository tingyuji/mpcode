var t = require("config.js"), e = (require("http.js"), wx.getUpdateManager());

App({
    onLaunch: function() {
        var o = this;
        wx.setStorageSync("appid", t.appid), this.login(), wx.getSetting({
            success: function(t) {
                wx.getUserProfile({
                    success: function(t) {
                        wx.setStorageSync("userInfo", t.userInfo), o.globalData.userInfo = t.userInfo, o.userInfoReadyCallback && o.userInfoReadyCallback(t);
                    }
                });
            }
        }), wx.getSystemInfo({
            success: function(t) {
                o.globalData.StatusBar = t.statusBarHeight;
                var e = wx.getMenuButtonBoundingClientRect();
                o.globalData.Custom = e;
                var a = e.bottom + e.top - t.statusBarHeight;
                o.globalData.CustomBar = a, a > 75 && (o.globalData.tabbar_bottom = "y");
            }
        }), e.onCheckForUpdate(function(t) {}), e.onUpdateReady(function() {
            wx.showModal({
                title: "更新提示",
                content: "新版本已经准备好，是否重启应用？",
                success: function(t) {
                    t.confirm && e.applyUpdate();
                }
            });
        }), e.onUpdateFailed(function() {});
    },
    login: function() {
        wx.login({
            success: function(e) {
                wx.showLoading({
                    title: "正在加载中..."
                }), wx.request({
                    url: t.login,
                    data: {
                        code: e.code
                    },
                    header: {
                        Cookie: "sessionid=" + wx.getStorageSync("sessionId") + ";appid=" + wx.getStorageSync("appid")
                    },
                    method: "POST",
                    success: function(t) {
                        wx.hideLoading(), null != t.data.data && wx.setStorageSync("sessionId", t.data.data);
                    },
                    fail: function(t) {
                        wx.hideLoading();
                    }
                });
            }
        });
    },
    globalData: {
        userInfo: null,
        userMsg: null,
        haslogin: !1,
        examMsg: null,
        question: {
            zero: !1,
            one: !1,
            two: !1,
            three: !1,
            four: !1
        },
        score: {
            zero: 0,
            one: 0,
            two: 0,
            three: 0,
            four: 0,
            total: 0
        },
        examTitle: null
    }
});